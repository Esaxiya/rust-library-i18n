// ignore-tidy-filelength Den här filen består nästan uteslutande av definitionen av `Iterator`.
// Vi kan inte dela det i flera filer.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Ett gränssnitt för hantering av iteratorer.
///
/// Detta är den viktigaste itatorn trait.
/// För mer information om begreppet iteratorer i allmänhet, se [module-level documentation].
/// I synnerhet kanske du vill veta hur man ska [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Typen av element som itereras över.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Avancerar iteratorn och returnerar nästa värde.
    ///
    /// Returnerar [`None`] när iterationen är klar.
    /// Enskilda iteratorimplementeringar kan välja att återuppta iteration, och att ringa till `next()` igen kanske eller inte kan sluta börja returnera [`Some(Item)`] igen någon gång.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Ett samtal till next() returnerar nästa värde ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... och sedan ingen när det är över.
    /// assert_eq!(None, iter.next());
    ///
    /// // Fler samtal kan returnera `None` eller inte.Här kommer de alltid att göra det.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Returnerar gränserna för återstående längd på iteratorn.
    ///
    /// Specifikt returnerar `size_hint()` en tupel där det första elementet är den nedre gränsen och det andra elementet är den övre gränsen.
    ///
    /// Den andra halvan av tupeln som returneras är ett [`Option`]`<`[`usize`] `>`.
    /// En [`None`] betyder här att antingen det inte finns någon känd övre gräns eller så är den övre gränsen större än [`usize`].
    ///
    /// # Implementeringsanmärkningar
    ///
    /// Det verkställs inte att en iteratorimplementering ger det deklarerade antalet element.En buggy iterator kan ge mindre än den nedre gränsen eller mer än den övre gränsen för element.
    ///
    /// `size_hint()` är främst avsedd att användas för optimeringar som att reservera utrymme för iteratorns element, men får inte lita på att t.ex. utelämna gränskontroller i osäker kod.
    /// Felaktig implementering av `size_hint()` bör inte leda till brott mot minnessäkerheten.
    ///
    /// Med detta sagt ska implementeringen ge en korrekt uppskattning, för annars skulle det vara ett brott mot trait s protokoll.
    ///
    /// Standardimplementeringen returnerar `(0,` [`None`]`), vilket är korrekt för alla iteratorer.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Ett mer komplext exempel:
    ///
    /// ```
    /// // Jämna siffror från noll till tio.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Vi kan iterera från noll till tio gånger.
    /// // Att veta att det är fem exakt skulle inte vara möjligt utan att köra filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Låt oss lägga till ytterligare fem nummer med chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // nu höjs båda gränserna med fem
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Returnerar `None` för en övre gräns:
    ///
    /// ```
    /// // en oändlig iterator har ingen övre gräns och högsta möjliga nedre gräns
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Konsumerar iteratorn, räknar antalet iterationer och returnerar den.
    ///
    /// Denna metod kommer att anropa [`next`] upprepade gånger tills [`None`] påträffas, vilket returnerar antalet gånger den såg [`Some`].
    /// Observera att [`next`] måste anropas minst en gång även om iteratorn inte har några element.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Överflödsbeteende
    ///
    /// Metoden skyddar inte mot överflöd, så att räkna element i en iterator med mer än [`usize::MAX`]-element ger antingen fel resultat eller panics.
    ///
    /// Om felsöknings påståenden är aktiverade garanteras en panic.
    ///
    /// # Panics
    ///
    /// Denna funktion kan panic om iteratorn har mer än [`usize::MAX`]-element.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Konsumerar iteratorn och returnerar det sista elementet.
    ///
    /// Denna metod utvärderar iteratorn tills den returnerar [`None`].
    /// Samtidigt håller den reda på det aktuella elementet.
    /// Efter att [`None`] returneras returnerar `last()` sedan det sista elementet det såg.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Avancerar iteratorn med `n`-element.
    ///
    /// Denna metod hoppar ivrigt över `n`-element genom att ringa [`next`] upp till `n` gånger tills [`None`] påträffas.
    ///
    /// `advance_by(n)` returnerar [`Ok(())`][Ok] om iteratorn framgångsrikt avancerar med `n`-element, eller [`Err(k)`][Err] om [`None`] påträffas, där `k` är antalet element iteratorn avanceras med innan det går tom för element (dvs.
    /// längden på iteratorn).
    /// Observera att `k` alltid är mindre än `n`.
    ///
    /// Att ringa till `advance_by(0)` förbrukar inga element och returnerar alltid [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // endast `&4` hoppades över
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Returnerar iteratorns n-element.
    ///
    /// Liksom de flesta indexeringsoperationer börjar räkningen från noll, så `nth(0)` returnerar det första värdet, `nth(1)` det andra och så vidare.
    ///
    /// Observera att alla föregående element, såväl som det returnerade elementet, kommer att konsumeras från iteratorn.
    /// Det betyder att de föregående elementen kommer att kasseras, och att samtal `nth(0)` flera gånger på samma iterator kommer att returnera olika element.
    ///
    ///
    /// `nth()` returnerar [`None`] om `n` är större än eller lika med iteratorns längd.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Att ringa `nth()` flera gånger spolar inte iteratorn tillbaka:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Återgår till `None` om det finns mindre än `n + 1`-element:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Skapar en iterator som börjar vid samma punkt, men steg med det angivna beloppet vid varje iteration.
    ///
    /// Anmärkning 1: Det första elementet i iteratorn returneras alltid, oavsett vilket steg som ges.
    ///
    /// Anmärkning 2: Den tidpunkt då ignorerade element dras är inte fast.
    /// `StepBy` beter sig som sekvensen `next(), nth(step-1), nth(step-1),…`, men är också fri att bete sig som sekvensen
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Vilket sätt som används kan ändras för vissa iteratorer av prestationsskäl.
    /// Det andra sättet kommer att framföra iteratorn tidigare och kan konsumera fler saker.
    ///
    /// `advance_n_and_return_first` motsvarar:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Metoden panic om det angivna steget är `0`.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Tar två iteratorer och skapar en ny iterator över båda i följd.
    ///
    /// `chain()` returnerar en ny iterator som först itererar över värden från den första iteratorn och sedan över värden från den andra iteratorn.
    ///
    /// Med andra ord länkar den två iteratorer ihop, i en kedja.🔗
    ///
    /// [`once`] används ofta för att anpassa ett enda värde till en kedja av andra typer av iteration.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Eftersom argumentet till `chain()` använder [`IntoIterator`] kan vi skicka allt som kan konverteras till en [`Iterator`], inte bara en [`Iterator`] i sig.
    /// Till exempel kan skivor (`&[T]`) implementera [`IntoIterator`], och så kan de skickas till `chain()` direkt:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Om du arbetar med Windows API kanske du vill konvertera [`OsStr`] till `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// "Zippar upp" två iteratorer till en enda iterator av par.
    ///
    /// `zip()` returnerar en ny iterator som kommer att iterera över två andra iteratorer, och returnerar en tupel där det första elementet kommer från det första iteratorn, och det andra elementet kommer från det andra iteratorn.
    ///
    ///
    /// Med andra ord zippar den två iteratorer tillsammans, till en enda.
    ///
    /// Om någon iterator returnerar [`None`], returnerar [`next`] från den zippade iteratorn [`None`].
    /// Om den första itatorn returnerar [`None`] kommer `zip` att kortsluta och `next` kommer inte att anropas på den andra iteratorn.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Eftersom argumentet till `zip()` använder [`IntoIterator`] kan vi skicka allt som kan konverteras till en [`Iterator`], inte bara en [`Iterator`] i sig.
    /// Till exempel kan skivor (`&[T]`) implementera [`IntoIterator`], och så kan de skickas till `zip()` direkt:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` används ofta för att zip en oändlig iterator till en ändlig.
    /// Detta fungerar eftersom den slutliga iteratorn så småningom kommer att returnera [`None`] och avsluta blixtlåset.Zippa med `(0..)` kan se ut som [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Skapar en ny iterator som placerar en kopia av `separator` mellan intilliggande objekt i original iteratorn.
    ///
    /// Om `separator` inte implementerar [`Clone`] eller behöver beräknas varje gång, använd [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Det första elementet från `a`.
    /// assert_eq!(a.next(), Some(&100)); // Avskiljaren.
    /// assert_eq!(a.next(), Some(&1));   // Nästa element från `a`.
    /// assert_eq!(a.next(), Some(&100)); // Avskiljaren.
    /// assert_eq!(a.next(), Some(&2));   // Det sista elementet från `a`.
    /// assert_eq!(a.next(), None);       // Iteratorn är klar.
    /// ```
    ///
    /// `intersperse` kan vara mycket användbart för att gå med i en iterators objekt med ett gemensamt element:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Skapar en ny iterator som placerar ett objekt som genereras av `separator` mellan intilliggande objekt i den ursprungliga iteratorn.
    ///
    /// Förslutningen kommer att anropas exakt en gång varje gång ett objekt placeras mellan två intilliggande objekt från den underliggande iteratorn;
    /// specifikt kallas inte stängningen om den underliggande itatorn ger mindre än två artiklar och efter att den sista artikeln har givits.
    ///
    ///
    /// Om iteratorns objekt implementerar [`Clone`] kan det vara lättare att använda [`intersperse`].
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Det första elementet från `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Avskiljaren.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Nästa element från `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Avskiljaren.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Det sista elementet från `v`.
    /// assert_eq!(it.next(), None);               // Iteratorn är klar.
    /// ```
    ///
    /// `intersperse_with` kan användas i situationer där separatorn behöver beräknas:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Avslutningen lånar sitt sammanhang mutabelt för att generera ett objekt.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Tar en stängning och skapar en iterator som anropar stängningen för varje element.
    ///
    /// `map()` förvandlar en iterator till en annan, med hjälp av dess argument:
    /// något som implementerar [`FnMut`].Det producerar en ny iterator som kallar denna stängning på varje element i den ursprungliga iteratorn.
    ///
    /// Om du är bra på att tänka i typer kan du tänka på `map()` så här:
    /// Om du har en iterator som ger dig element av någon typ `A`, och du vill ha en iterator av någon annan typ `B`, kan du använda `map()`, passera en förslutning som tar en `A` och returnerar en `B`.
    ///
    ///
    /// `map()` liknar konceptuellt en [`for`]-slinga.Eftersom `map()` är lat, används den dock bäst när du redan arbetar med andra iteratorer.
    /// Om du gör någon form av looping för en bieffekt anses det vara mer idiomatiskt att använda [`for`] än `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Om du gör någon form av biverkning, föredrar du [`for`] framför `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // gör inte detta:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // det kommer inte ens att köras, eftersom det är lat.Rust kommer att varna dig för detta.
    ///
    /// // Använd istället för:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Anropar en stängning för varje element i en iterator.
    ///
    /// Detta motsvarar att använda en [`for`]-slinga på iteratorn, även om `break` och `continue` inte är möjliga från en förslutning.
    /// Det är i allmänhet mer idiomatiskt att använda en `for`-slinga, men `for_each` kan vara mer läsbar när man bearbetar artiklar i slutet av längre iteratorkedjor.
    ///
    /// I vissa fall kan `for_each` också vara snabbare än en loop, eftersom den använder intern iteration på adaptrar som `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// För ett så litet exempel kan en `for`-slinga vara renare, men `for_each` kan vara att föredra för att behålla en funktionell stil med längre iteratorer:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Skapar en iterator som använder en stängning för att avgöra om ett element ska ges.
    ///
    /// Givet ett element måste stängningen returnera `true` eller `false`.Den returnerade iteratorn ger endast de element för vilka stängningen returnerar sant.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Eftersom stängningen som överförs till `filter()` tar en referens, och många iteratorer itererar över referenser, leder detta till en eventuellt förvirrande situation, där typen av stängning är en dubbelreferens:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // behöver två * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Det är vanligt att istället använda destrukturerar argumentet för att ta bort en:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // både och *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// eller båda:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // två &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// av dessa lager.
    ///
    /// Observera att `iter.filter(f).next()` motsvarar `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Skapar en iterator som både filtrerar och kartlägger.
    ///
    /// Den returnerade iteratorn ger endast 'värdet' för vilket den medföljande stängningen returnerar `Some(value)`.
    ///
    /// `filter_map` kan användas för att göra kedjor av [`filter`] och [`map`] mer kortfattade.
    /// Exemplet nedan visar hur en `map().filter().map()` kan förkortas till ett enda samtal till `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Här är samma exempel, men med [`filter`] och [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Skapar en iterator som ger den aktuella iterationsräkningen samt nästa värde.
    ///
    /// Den returnerade iteratorn ger par `(i, val)`, där `i` är det aktuella iterationsindexet och `val` är det värde som returneras av iteratorn.
    ///
    ///
    /// `enumerate()` behåller sin räkning som en [`usize`].
    /// Om du vill räkna med ett heltal av olika storlek, ger [`zip`]-funktionen liknande funktioner.
    ///
    /// # Överflödsbeteende
    ///
    /// Metoden skyddar inte överflöden, så att räkna mer än [`usize::MAX`]-element ger antingen fel resultat eller panics.
    /// Om felsöknings påståenden är aktiverade garanteras en panic.
    ///
    /// # Panics
    ///
    /// Den returnerade iteratorn kan panic om indexet som ska returneras skulle översvämma en [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Skapar en iterator som kan använda [`peek`] för att titta på nästa element i iteratorn utan att konsumera den.
    ///
    /// Lägger till en [`peek`]-metod till en iterator.Se dess dokumentation för mer information.
    ///
    /// Observera att den underliggande iteratorn fortfarande är avancerad när [`peek`] anropas för första gången: För att hämta nästa element anropas [`next`] till den underliggande iteratorn, därav eventuella biverkningar (dvs.
    ///
    /// allt annat än att hämta nästa värde) av [`next`]-metoden kommer att inträffa.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() låter oss se in i future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // vi kan peek() flera gånger, iteratorn kommer inte framåt
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // efter att iteratorn är klar, så är peek() också
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Skapar en iterator som ["hoppar över"] element baserat på ett predikat.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` tar en avslutning som ett argument.Det kommer att kalla denna stängning på varje element i iteratorn och ignorera element tills den returnerar `false`.
    ///
    /// Efter att `false` har returnerats är `skip_while()`'s-jobbet över och resten av elementen ges.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Eftersom stängningen som överförs till `skip_while()` tar en referens, och många iteratorer itererar över referenser, leder detta till en möjligen förvirrande situation, där typen av stängningsargument är en dubbel referens:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // behöver två * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stannar efter en första `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // medan detta skulle ha varit falskt, eftersom vi redan har en falsk, används skip_while() inte längre
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Skapar en iterator som ger element baserat på ett predikat.
    ///
    /// `take_while()` tar en avslutning som ett argument.Det kommer att kalla denna stängning för varje element i iteratorn och ge element medan den returnerar `true`.
    ///
    /// Efter att `false` har returnerats är `take_while()`'s-jobbet över och resten av elementen ignoreras.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Eftersom stängningen som överförs till `take_while()` tar en referens, och många iteratorer itererar över referenser, leder detta till en eventuellt förvirrande situation, där typen av stängning är en dubbelreferens:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // behöver två * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stannar efter en första `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Vi har fler element som är mindre än noll, men eftersom vi redan har en falsk används take_while() inte längre
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Eftersom `take_while()` måste titta på värdet för att se om det ska inkluderas eller inte, kommer konsumerande iteratorer att se att det tas bort:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` finns inte längre, eftersom den konsumerades för att se om iterationen skulle sluta, men placerades inte tillbaka i itatorn.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Skapar en iterator som både ger element baserat på ett predikat och kartor.
    ///
    /// `map_while()` tar en avslutning som ett argument.
    /// Det kommer att kalla denna stängning för varje element i iteratorn och ge element medan den returnerar [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Här är samma exempel, men med [`take_while`] och [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stannar efter en första [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Vi har fler element som kan passa in i u32 (4, 5), men `map_while` returnerade `None` för `-3` (när `predicate` returnerade `None`) och `collect` slutade vid den första `None` som påträffades.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Eftersom `map_while()` måste titta på värdet för att se om det ska inkluderas eller inte, kommer konsumerande iteratorer att se att det tas bort:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` finns inte längre, eftersom den konsumerades för att se om iterationen skulle sluta, men placerades inte tillbaka i itatorn.
    ///
    /// Observera att till skillnad från [`take_while`] är denna iterator **inte** smält.
    /// Det anges inte heller vad denna iterator returnerar efter att den första [`None`] returneras.
    /// Om du behöver smält iterator, använd [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Skapar en iterator som hoppar över de första `n`-elementen.
    ///
    /// Efter att de har konsumerats ger resten av elementen.
    /// I stället för att åsidosätta den här metoden direkt, istället åsidosätta `nth`-metoden.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Skapar en iterator som ger sina första `n`-element.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` används ofta med en oändlig iterator för att göra den ändlig:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Om mindre än `n`-element är tillgängliga begränsar `take` sig till storleken på den underliggande iteratorn:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// En iteratoradapter som liknar [`fold`] som håller internt tillstånd och producerar en ny iterator.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` tar två argument: ett initialvärde som fröer det interna tillståndet och en avslutning med två argument, det första är en muterbar referens till det interna tillståndet och det andra ett iteratorelement.
    ///
    /// Avslutningen kan tilldelas det interna tillståndet att dela tillstånd mellan iterationer.
    ///
    /// Vid iteration kommer stängningen att tillämpas på varje element i iteratorn och returvärdet från stängningen, en [`Option`], ges av iteratorn.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // varje iteration multiplicerar vi tillståndet med elementet
    ///     *state = *state * x;
    ///
    ///     // då kommer vi att ge statens negation
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Skapar en iterator som fungerar som karta, men plattar kapslad struktur.
    ///
    /// [`map`]-adaptern är mycket användbar, men bara när stängningsargumentet ger värden.
    /// Om det istället producerar en iterator finns det ett extra lager av indirektion.
    /// `flat_map()` tar bort detta extra lager på egen hand.
    ///
    /// Du kan tänka på `flat_map(f)` som den semantiska ekvivalenten för [`map`] ping, och sedan [`platta`] ing som i `map(f).flatten()`.
    ///
    /// Ett annat sätt att tänka på `flat_map()`: ['map'] s stängning returnerar ett objekt för varje element och `flat_map()`'s stängning returnerar en iterator för varje element.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() returnerar en iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Skapar en iterator som plattar kapslad struktur.
    ///
    /// Detta är användbart när du har en iterator av iteratorer eller en iterator av saker som kan förvandlas till iteratorer och du vill ta bort en nivå av indirektion.
    ///
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Kartläggning och sedan plattning:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() returnerar en iterator
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Du kan också skriva om detta i termer av [`flat_map()`], vilket är att föredra i det här fallet eftersom det förmedlar avsikt tydligare:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() returnerar en iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Plattning tar bara bort en nivå av häckning åt gången:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Här ser vi att `flatten()` inte utför en "deep"-plattning.
    /// Istället tas endast en nivå av häckning bort.Det vill säga om du `flatten()` en tredimensionell matris blir resultatet tvådimensionellt och inte endimensionellt.
    /// För att få en endimensionell struktur måste du `flatten()` igen.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Skapar en iterator som slutar efter den första [`None`].
    ///
    /// Efter att en iterator returnerar [`None`] kan future-samtal ge [`Some(T)`] eller inte igen.
    /// `fuse()` anpassar en iterator och ser till att efter att en [`None`] ges kommer den alltid att returnera [`None`] för alltid.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// // en iterator som växlar mellan Some och None
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // om det är jämnt, Some(i32), annars Ingen
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // vi kan se vår iterator gå fram och tillbaka
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // Men när vi väl har smält det ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // det kommer alltid att returnera `None` efter första gången.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Gör något med varje element i en iterator och förmedlar värdet.
    ///
    /// När du använder iteratorer kommer du ofta att kedja ihop flera av dem.
    /// När du arbetar med en sådan kod kanske du vill kolla vad som händer på olika delar i rörledningen.För att göra det, sätt in ett samtal till `inspect()`.
    ///
    /// Det är vanligare att `inspect()` används som ett felsökningsverktyg än att det finns i din slutkod, men applikationer kan tycka att det är användbart i vissa situationer när fel måste loggas innan de kasseras.
    ///
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // denna iteratorsekvens är komplex.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // låt oss lägga till några inspect()-samtal för att undersöka vad som händer
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Detta kommer att skriva ut:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Loggningsfel innan du kasserar dem:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Detta kommer att skriva ut:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Lånar en iterator snarare än att konsumera den.
    ///
    /// Detta är användbart för att tillåta applicering av iterator-adaptrar samtidigt som äganderätten till den ursprungliga iteratorn behålls.
    ///
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // om vi försöker använda iter igen fungerar det inte.
    /// // Följande rad ger "fel: användning av flyttat värde: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // låt oss försöka igen
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // istället lägger vi till en .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // nu är det bara bra:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Förvandlar en iterator till en samling.
    ///
    /// `collect()` kan ta vad som helst iterabelt och göra det till en relevant samling.
    /// Detta är en av de mer kraftfulla metoderna i standardbiblioteket, som används i en mängd olika sammanhang.
    ///
    /// Det mest grundläggande mönstret i vilket `collect()` används är att förvandla en samling till en annan.
    /// Du tar en samling, ringer [`iter`] på den, gör en massa transformationer och sedan `collect()` i slutet.
    ///
    /// `collect()` kan också skapa förekomster av typer som inte är typiska samlingar.
    /// Till exempel kan en [`String`] byggas från [`char`], och en iterator av [`Result<T, E>`][`Result`]-objekt kan samlas in i `Result<Collection<T>, E>`.
    ///
    /// Se exemplen nedan för mer information.
    ///
    /// Eftersom `collect()` är så allmänt kan det orsaka problem med typavledning.
    /// Som sådan är `collect()` en av de få gånger du ser syntaxen kärleksfullt känd som 'turbofish': `::<>`.
    /// Detta hjälper inferensalgoritmen att förstå specifikt vilken samling du försöker samla in.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Observera att vi behövde `: Vec<i32>` på vänster sida.Detta beror på att vi istället kunde samla in till en [`VecDeque<T>`]:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Använda 'turbofish' istället för att kommentera `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Eftersom `collect()` bara bryr sig om vad du samlar in kan du fortfarande använda en partiell typ av antydan, `_`, med turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Använda `collect()` för att skapa en [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Om du har en lista över [`Resultat<T, E>`][`Resultat`] s, du kan använda `collect()` för att se om någon av dem misslyckades:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ger oss det första felet
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ger oss en lista med svar
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Konsumerar en iterator och skapar två samlingar från den.
    ///
    /// Predikatet som skickas till `partition()` kan returnera `true` eller `false`.
    /// `partition()` returnerar ett par, alla element för vilka det returnerade `true`, och alla element för vilka det returnerade `false`.
    ///
    ///
    /// Se även [`is_partitioned()`] och [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Ordna om elementen i denna iterator *på plats* enligt det givna predikatet, så att alla de som returnerar `true` föregår alla de som returnerar `false`.
    ///
    /// Returnerar antalet `true`-element som hittats.
    ///
    /// Den relativa ordningen på partitionerade objekt bibehålls inte.
    ///
    /// Se även [`is_partitioned()`] och [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Partition på plats mellan kvällar och odds
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: ska vi oroa oss för att antalet rinner överDet enda sättet att ha mer än
        // `usize::MAX` muterbara referenser är med ZST, som inte är användbara för partitionering ...

        // Dessa "factory"-funktioner finns för att undvika genericitet i `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Hitta upprepade gånger den första `false` och byt den med den senaste `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Kontrollerar om elementen i denna iterator är partitionerade enligt det givna predikatet, så att alla de som returnerar `true` föregår alla de som returnerar `false`.
    ///
    ///
    /// Se även [`partition()`] och [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Antingen testar alla artiklar `true`, eller så slutar den första klausulen vid `false` och vi kontrollerar att det inte finns fler `true`-objekt efter det.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// En iteratormetod som tillämpar en funktion så länge den returneras framgångsrikt och ger ett enda slutvärde.
    ///
    /// `try_fold()` tar två argument: ett initialvärde och en avslutning med två argument: en 'accumulator' och ett element.
    /// Avslutningen återgår antingen framgångsrikt, med det värde som ackumulatorn ska ha för nästa iteration, eller så returnerar det fel, med ett felvärde som fortplantas tillbaka till den som ringer omedelbart (short-circuiting).
    ///
    ///
    /// Det initiala värdet är det värde ackumulatorn kommer att ha vid det första samtalet.Om tillämpningen av stängningen lyckades mot alla element i iteratorn, returnerar `try_fold()` den slutliga ackumulatorn som framgång.
    ///
    /// Vikning är användbar när du har en samling av något och vill producera ett enda värde från det.
    ///
    /// # Anmärkning till implementerare
    ///
    /// Flera av de andra (forward)-metoderna har standardimplementeringar när det gäller den här, så försök att implementera detta uttryckligen om det kan göra något bättre än standardimporten `for`-loop.
    ///
    /// Försök särskilt att ha detta samtal `try_fold()` på de interna delarna som denna iterator består av.
    /// Om flera samtal behövs kan `?`-operatören vara bekväm att kedja ackumuleringsvärdet, men akta dig för alla invarianter som behöver upprätthållas innan de återkommer.
    /// Detta är en `&mut self`-metod, så iteration måste kunna återupptas efter att ha träffat ett fel här.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // den kontrollerade summan av alla element i matrisen
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Denna summa flödar över när 100-elementet läggs till
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Eftersom det kortsluts är de återstående elementen fortfarande tillgängliga via iteratorn.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// En iteratormetod som tillämpar en felbar funktion på varje objekt i iteratorn, stoppar vid det första felet och returnerar det felet.
    ///
    ///
    /// Detta kan också ses på som den felbara formen av [`for_each()`] eller som den statslösa versionen av [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Det kortsluts, så de återstående objekten finns fortfarande i iteratorn:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Vikar varje element i en ackumulator genom att genomföra en operation och returnerar slutresultatet.
    ///
    /// `fold()` tar två argument: ett initialvärde och en avslutning med två argument: en 'accumulator' och ett element.
    /// Avslutningen returnerar det värde som ackumulatorn ska ha för nästa iteration.
    ///
    /// Det initiala värdet är det värde ackumulatorn kommer att ha vid det första samtalet.
    ///
    /// Efter att ha stängt denna stängning på alla element i iteratorn returnerar `fold()` ackumulatorn.
    ///
    /// Denna operation kallas ibland 'reduce' eller 'inject'.
    ///
    /// Vikning är användbar när du har en samling av något och vill producera ett enda värde från det.
    ///
    /// Note: `fold()` och liknande metoder som passerar hela iteratorn kanske inte avslutas för oändliga iteratorer, inte ens på traits för vilka ett resultat kan bestämmas på slutlig tid.
    ///
    /// Note: [`reduce()`] kan användas för att använda det första elementet som initialvärde, om ackumulatortypen och artikeln är desamma.
    ///
    /// # Anmärkning till implementerare
    ///
    /// Flera av de andra (forward)-metoderna har standardimplementeringar när det gäller den här, så försök att implementera detta uttryckligen om det kan göra något bättre än standardimporten `for`-loop.
    ///
    ///
    /// Försök särskilt att ha detta samtal `fold()` på de interna delarna som denna iterator består av.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // summan av alla element i matrisen
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Låt oss gå igenom varje steg i iterationen här:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Och så, vårt slutliga resultat, `6`.
    ///
    /// Det är vanligt att människor som inte har använt iteratorer mycket använder en `for`-slinga med en lista över saker för att bygga upp ett resultat.De kan förvandlas till `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // för slinga:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // de är desamma
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Minskar elementen till en enda genom att upprepade gånger använda en reducerande operation.
    ///
    /// Om iteratorn är tom, returnerar [`None`];annars returnerar resultatet av minskningen.
    ///
    /// För iteratorer med minst ett element är det samma som [`fold()`] med det första elementet i iteratorn som det initiala värdet och viks varje efterföljande element i det.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Hitta det maximala värdet:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Testar om varje element i iteratorn matchar ett predikat.
    ///
    /// `all()` tar en stängning som returnerar `true` eller `false`.Det tillämpar denna stängning på varje element i iteratorn, och om de alla returnerar `true`, så gör `all()` det också.
    /// Om någon av dem returnerar `false` returnerar den `false`.
    ///
    /// `all()` är kortslutning;med andra ord kommer den att sluta bearbetas så snart den hittar en `false`, med tanke på att oavsett vad som händer, blir resultatet också `false`.
    ///
    ///
    /// En tom iterator returnerar `true`.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Stannar vid första `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // vi kan fortfarande använda `iter`, eftersom det finns fler element.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Testar om något av iteratorn matchar ett predikat.
    ///
    /// `any()` tar en stängning som returnerar `true` eller `false`.Det tillämpar denna stängning på varje element i iteratorn, och om någon av dem returnerar `true`, så gör `any()` det också.
    /// Om alla returnerar `false` returnerar det `false`.
    ///
    /// `any()` är kortslutning;med andra ord kommer den att sluta bearbetas så snart den hittar en `true`, med tanke på att oavsett vad som händer, blir resultatet också `true`.
    ///
    ///
    /// En tom iterator returnerar `false`.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Stannar vid första `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // vi kan fortfarande använda `iter`, eftersom det finns fler element.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Söker efter ett element i en iterator som uppfyller ett predikat.
    ///
    /// `find()` tar en stängning som returnerar `true` eller `false`.
    /// Den tillämpar denna stängning på varje element i iteratorn, och om någon av dem returnerar `true`, returnerar `find()` [`Some(element)`].
    /// Om alla returnerar `false` returnerar det [`None`].
    ///
    /// `find()` är kortslutning;med andra ord kommer det att sluta bearbetas så snart stängningen returnerar `true`.
    ///
    /// Eftersom `find()` tar en referens, och många iteratorer itererar över referenser, leder detta till en eventuellt förvirrande situation där argumentet är en dubbel referens.
    ///
    /// Du kan se denna effekt i exemplen nedan med `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Stannar vid första `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // vi kan fortfarande använda `iter`, eftersom det finns fler element.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Observera att `iter.find(f)` motsvarar `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Tillämpar funktion på iteratorns element och returnerar det första icke-inget-resultatet.
    ///
    ///
    /// `iter.find_map(f)` motsvarar `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Gäller funktionen för elementen i iterator och returnerar det första sanna resultatet eller det första felet.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Söker efter ett element i en iterator och returnerar dess index.
    ///
    /// `position()` tar en stängning som returnerar `true` eller `false`.
    /// Den tillämpar denna stängning på varje element i iteratorn, och om en av dem returnerar `true`, returnerar `position()` [`Some(index)`].
    /// Om alla returnerar `false` returnerar den [`None`].
    ///
    /// `position()` är kortslutning;med andra ord kommer den att sluta bearbetas så snart den hittar en `true`.
    ///
    /// # Överflödsbeteende
    ///
    /// Metoden skyddar inte mot överflöd, så om det finns mer än [`usize::MAX`]-element som inte matchar, ger det antingen fel resultat eller panics.
    ///
    /// Om felsöknings påståenden är aktiverade garanteras en panic.
    ///
    /// # Panics
    ///
    /// Denna funktion kan panic om iteratorn har mer än `usize::MAX`-element som inte matchar.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Stannar vid första `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // vi kan fortfarande använda `iter`, eftersom det finns fler element.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Det returnerade indexet beror på iteratortillståndet
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Söker efter ett element i en iterator från höger och returnerar dess index.
    ///
    /// `rposition()` tar en stängning som returnerar `true` eller `false`.
    /// Den tillämpar denna stängning på varje element i iteratorn, från början, och om en av dem returnerar `true` returnerar `rposition()` [`Some(index)`].
    ///
    /// Om alla returnerar `false` returnerar den [`None`].
    ///
    /// `rposition()` är kortslutning;med andra ord kommer den att sluta bearbetas så snart den hittar en `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Stannar vid första `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // vi kan fortfarande använda `iter`, eftersom det finns fler element.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Inget behov av en överflödskontroll här, för `ExactSizeIterator` innebär att antalet element passar in i en `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Returnerar det maximala elementet i en iterator.
    ///
    /// Om flera element är lika maximala returneras det sista elementet.
    /// Om iteratorn är tom returneras [`None`].
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Returnerar minimielementet för en iterator.
    ///
    /// Om flera element är lika minsta returneras det första elementet.
    /// Om iteratorn är tom returneras [`None`].
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Returnerar det element som ger det maximala värdet från den angivna funktionen.
    ///
    ///
    /// Om flera element är lika maximala returneras det sista elementet.
    /// Om iteratorn är tom returneras [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Returnerar det element som ger det maximala värdet med avseende på den angivna jämförelsefunktionen.
    ///
    ///
    /// Om flera element är lika maximala returneras det sista elementet.
    /// Om iteratorn är tom returneras [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Returnerar det element som ger minimivärdet från den angivna funktionen.
    ///
    ///
    /// Om flera element är lika minsta returneras det första elementet.
    /// Om iteratorn är tom returneras [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Returnerar det element som ger minimivärdet med avseende på den angivna jämförelsefunktionen.
    ///
    ///
    /// Om flera element är lika minsta returneras det första elementet.
    /// Om iteratorn är tom returneras [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Omvandlar en iterators riktning.
    ///
    /// Vanligtvis itererar det från vänster till höger.
    /// Efter att ha använt `rev()` kommer en iterator istället att itera från höger till vänster.
    ///
    /// Detta är endast möjligt om iteratorn har ett slut, så `rev()` fungerar bara på [`DoubleEndedIterator`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Konverterar en iterator av par till ett par behållare.
    ///
    /// `unzip()` förbrukar en hel iterator av par och producerar två samlingar: en från parternas vänstra element och en från de rätta elementen.
    ///
    ///
    /// Denna funktion är i viss mening motsatsen till [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Skapar en iterator som kopierar alla dess element.
    ///
    /// Detta är användbart när du har en iterator över `&T`, men du behöver en iterator över `T`.
    ///
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // kopieras är samma som .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Skapar en iterator som ["klonar"] alla dess element.
    ///
    /// Detta är användbart när du har en iterator över `&T`, men du behöver en iterator över `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // klonad är samma som .map(|&x| x), för heltal
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Upprepar en iterator oändligt.
    ///
    /// Istället för att stanna vid [`None`] startar iteratorn istället igen, från början.Efter iterering igen kommer den att börja igen från början.Och igen.
    /// Och igen.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Sammanfattar elementen i en iterator.
    ///
    /// Tar varje element, lägger till dem tillsammans och returnerar resultatet.
    ///
    /// En tom iterator returnerar nollvärdet för typen.
    ///
    /// # Panics
    ///
    /// När du ringer till `sum()` och en primitiv heltalstyp returneras kommer denna metod att panic om beräkningen överflödar och felsöknings påståenden är aktiverade.
    ///
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Itererar över hela iteratorn och multiplicerar alla element
    ///
    /// En tom iterator returnerar ett värde av typen.
    ///
    /// # Panics
    ///
    /// När du ringer till `product()` och en primitiv heltalstyp returneras kommer metoden att panic om beräkningen överflödar och felsöknings påståenden är aktiverade.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) jämför elementen i denna [`Iterator`] med de hos en annan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) jämför elementen i denna [`Iterator`] med en annans med avseende på den angivna jämförelsefunktionen.
    ///
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) jämför elementen i denna [`Iterator`] med de hos en annan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) jämför elementen i denna [`Iterator`] med en annans med avseende på den angivna jämförelsefunktionen.
    ///
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Bestämmer om elementen i denna [`Iterator`] är lika med de andra.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Bestämmer om elementen i denna [`Iterator`] är lika med de andra med avseende på den angivna jämställdhetsfunktionen.
    ///
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Avgör om elementen i denna [`Iterator`] är ojämlika med andras.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Avgör om elementen i denna [`Iterator`] är [lexicographically](Ord#lexicographical-comparison) mindre än hos en annan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Bestämmer om elementen i denna [`Iterator`] är [lexicographically](Ord#lexicographical-comparison) mindre eller lika med de hos en annan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Bestämmer om elementen i denna [`Iterator`] är [lexicographically](Ord#lexicographical-comparison) större än hos en annan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Bestämmer om elementen i denna [`Iterator`] är [lexicographically](Ord#lexicographical-comparison) större än eller lika med en annans.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Kontrollerar om elementen i denna iterator är sorterade.
    ///
    /// Det vill säga, för varje element `a` och dess följande element `b` måste `a <= b` innehålla.Om iteratorn ger exakt noll eller ett element returneras `true`.
    ///
    /// Observera att om `Self::Item` bara är `PartialOrd`, men inte `Ord`, innebär definitionen ovan att denna funktion returnerar `false` om två på varandra följande poster inte är jämförbara.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Kontrollerar om elementen i denna iterator sorteras med den givna komparatorfunktionen.
    ///
    /// Istället för att använda `PartialOrd::partial_cmp` använder den här funktionen den givna `compare`-funktionen för att bestämma ordningen för två element.
    /// Bortsett från det motsvarar det [`is_sorted`];se dess dokumentation för mer information.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Kontrollerar om elementen i denna iterator sorteras med den givna nyckelextraktionsfunktionen.
    ///
    /// I stället för att jämföra iteratorns element direkt jämför denna funktion elementens tangenter, som bestäms av `f`.
    /// Bortsett från det motsvarar det [`is_sorted`];se dess dokumentation för mer information.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Se [TrustedRandomAccess]
    // Det ovanliga namnet är att undvika namnkollisioner i metodupplösning se #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}