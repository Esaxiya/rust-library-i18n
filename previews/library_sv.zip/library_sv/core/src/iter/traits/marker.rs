/// En iterator som alltid fortsätter att ge `None` när den är utmattad.
///
/// Att ringa nästa gång på en smält iterator som har returnerat `None` en gång kommer garanterat att returnera [`None`] igen.
/// Denna trait bör implementeras av alla iteratorer som beter sig så eftersom det möjliggör optimering av [`Iterator::fuse()`].
///
///
/// Note: I allmänhet bör du inte använda `FusedIterator` i generiska gränser om du behöver en smält iterator.
/// Istället borde du bara ringa [`Iterator::fuse()`] på iteratorn.
/// Om iteratorn redan är smält, kommer det extra [`Fuse`]-omslaget att vara ett no-op utan prestationsstraff.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// En iterator som rapporterar en exakt längd med hjälp av size_hint.
///
/// Iteratorn rapporterar en storleksanvisning där den antingen är exakt (nedre gräns är lika med övre gräns), eller övre gräns är [`None`].
///
/// Den övre gränsen får endast vara [`None`] om den faktiska iteratorlängden är större än [`usize::MAX`].
/// I så fall måste den nedre gränsen vara [`usize::MAX`], vilket resulterar i en [`Iterator::size_hint()`] på `(usize::MAX, None)`.
///
/// Iteratorn måste producera exakt det antal element som den rapporterat eller avviker innan den når slutet.
///
/// # Safety
///
/// Denna trait får endast genomföras när kontraktet upprätthålls.
/// Konsumenterna av denna trait måste inspektera [`Iterator::size_hint()`]’s övre gräns.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// En iterator som när du ger ett objekt kommer att ha tagit minst ett element från dess underliggande [`SourceIter`].
///
/// Att ringa vilken metod som helst som avancerar iteratorn, t.ex.
/// [`next()`] eller [`try_fold()`], garanterar att åtminstone ett värde av iteratorns underliggande källa för varje steg har flyttats ut och resultatet av iteratorkedjan kan infogas på sin plats, förutsatt att källans strukturella begränsningar möjliggör en sådan insättning.
///
/// Med andra ord indikerar denna trait att en iteratorrörledning kan samlas på plats.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}