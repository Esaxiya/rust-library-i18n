use crate::ops::{ControlFlow, Try};

/// En iterator som kan ge element från båda ändar.
///
/// Något som implementerar `DoubleEndedIterator` har en extra förmåga jämfört med något som implementerar [`Iterator`]: förmågan att också ta 'Objekt från baksidan, liksom framsidan.
///
///
/// Det är viktigt att notera att både fram och tillbaka fungerar på samma område och inte korsar: iteration är över när de möts i mitten.
///
/// På ett liknande sätt som [`Iterator`]-protokollet, när en `DoubleEndedIterator` returnerar [`None`] från en [`next_back()`], kan du ringa den igen eller kanske inte någonsin returnera [`Some`] igen.
/// [`next()`] och [`next_back()`] är utbytbara för detta ändamål.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Grundläggande användning:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Tar bort och returnerar ett element från slutet av iteratorn.
    ///
    /// Returnerar `None` när det inte finns fler element.
    ///
    /// [trait-level]-dokumenten innehåller mer information.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Elementen som ges med "DoubleEndedIterator"-metoderna kan skilja sig från de som ges med ["Iterator"]: s metoder:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Flyttar iteratorn bakifrån med `n`-element.
    ///
    /// `advance_back_by` är den omvända versionen av [`advance_by`].Denna metod hoppar ivrigt över `n`-element som börjar bakifrån genom att ringa [`next_back`] upp till `n` gånger tills [`None`] påträffas.
    ///
    /// `advance_back_by(n)` returnerar [`Ok(())`] om iteratorn framgångsrikt avancerar med `n`-element, eller [`Err(k)`] om [`None`] påträffas, där `k` är antalet element iteratorn avanceras med innan det går tom för element (dvs.
    /// längden på iteratorn).
    /// Observera att `k` alltid är mindre än `n`.
    ///
    /// Att ringa till `advance_back_by(0)` förbrukar inga element och returnerar alltid [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // endast `&3` hoppades över
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Returnerar `n`-elementet från slutet av iteratorn.
    ///
    /// Detta är i huvudsak den omvända versionen av [`Iterator::nth()`].
    /// Även som de flesta indexeringsoperationer börjar räkningen från noll, så `nth_back(0)` returnerar det första värdet från slutet, `nth_back(1)` det andra och så vidare.
    ///
    ///
    /// Observera att alla element mellan slutet och det returnerade elementet kommer att konsumeras, inklusive det returnerade elementet.
    /// Detta innebär också att när du ringer `nth_back(0)` flera gånger på samma iterator kommer olika element att returneras.
    ///
    /// `nth_back()` returnerar [`None`] om `n` är större än eller lika med iteratorns längd.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Att ringa `nth_back()` flera gånger spolar inte iteratorn tillbaka:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Återgår till `None` om det finns mindre än `n + 1`-element:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Detta är den omvända versionen av [`Iterator::try_fold()`]: det tar element som börjar från iteratorns baksida.
    ///
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Eftersom det kortsluts är de återstående elementen fortfarande tillgängliga via iteratorn.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// En iteratormetod som reducerar iteratorns element till ett enda slutvärde, från baksidan.
    ///
    /// Detta är den omvända versionen av [`Iterator::fold()`]: det tar element som börjar från iteratorns baksida.
    ///
    /// `rfold()` tar två argument: ett initialvärde och en avslutning med två argument: en 'accumulator' och ett element.
    /// Avslutningen returnerar det värde som ackumulatorn ska ha för nästa iteration.
    ///
    /// Det initiala värdet är det värde ackumulatorn kommer att ha vid det första samtalet.
    ///
    /// Efter att ha stängt denna stängning på alla element i iteratorn returnerar `rfold()` ackumulatorn.
    ///
    /// Denna operation kallas ibland 'reduce' eller 'inject'.
    ///
    /// Vikning är användbar när du har en samling av något och vill producera ett enda värde från det.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // summan av alla element i a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Det här exemplet bygger en sträng som börjar med ett initialvärde och fortsätter med varje element från baksidan till framsidan:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Söker efter ett element i en iterator bakifrån som uppfyller ett predikat.
    ///
    /// `rfind()` tar en stängning som returnerar `true` eller `false`.
    /// Den tillämpar denna stängning på varje element i iteratorn, med början i slutet, och om någon av dem returnerar `true`, returnerar `rfind()` [`Some(element)`].
    /// Om alla returnerar `false` returnerar det [`None`].
    ///
    /// `rfind()` är kortslutning;med andra ord kommer det att sluta bearbetas så snart stängningen returnerar `true`.
    ///
    /// Eftersom `rfind()` tar en referens, och många iteratorer itererar över referenser, leder detta till en eventuellt förvirrande situation där argumentet är en dubbelreferens.
    ///
    /// Du kan se denna effekt i exemplen nedan med `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Stannar vid första `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // vi kan fortfarande använda `iter`, eftersom det finns fler element.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}