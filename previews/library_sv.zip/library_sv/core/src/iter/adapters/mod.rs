use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Denna trait ger övergående åtkomst till källsteget i en interator-adapterrörledning under de förhållanden som
/// * iteratorkällan `S` själv implementerar `SourceIter<Source = S>`
/// * det finns en delegering av implementeringen av denna trait för varje adapter i rörledningen mellan källan och pipeline-konsumenten.
///
/// När källan är en ägande iteratorstruktur (vanligtvis kallad `IntoIter`) kan detta vara användbart för att specialisera [`FromIterator`]-implementeringar eller återställa de återstående elementen efter att en iterator delvis har uttömts.
///
///
/// Observera att implementeringar inte nödvändigtvis behöver ge tillgång till den innersta källan till en pipeline.En statlig mellanliggande adapter kan ivrigt utvärdera en del av rörledningen och exponera dess interna lagring som källa.
///
/// trait är osäker eftersom implementatorer måste upprätthålla ytterligare säkerhetsegenskaper.
/// Se [`as_inner`] för mer information.
///
/// # Examples
///
/// Hämta en delvis förbrukad källa:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Ett källstadium i en iterator-pipeline.
    type Source: Iterator;

    /// Hämta källan till en iterator-pipeline.
    ///
    /// # Safety
    ///
    /// Implementeringar av måste returnera samma muterbara referens under sin livstid, såvida de inte ersätts av en uppringare.
    /// Uppringare får bara ersätta referensen när de stoppade iterationen och släpper iterator-pipeline efter att källan extraherats.
    ///
    /// Det betyder att iterator-adaptrar kan lita på att källan inte ändras under iteration men de kan inte lita på den i sina Drop-implementeringar.
    ///
    /// Genomförandet av denna metod innebär att adaptrar avstår från privat tillgång till sin källa och kan bara förlita sig på garantier som gjorts baserat på metodmottagartyper.
    /// Bristen på begränsad åtkomst kräver också att adaptrar måste upprätthålla källans offentliga API även när de har tillgång till dess interna.
    ///
    /// Uppringare i sin tur måste förvänta sig att källan befinner sig i alla tillstånd som överensstämmer med dess offentliga API eftersom adaptrar som sitter mellan den och källan har samma åtkomst.
    /// I synnerhet kan en adapter ha förbrukat fler element än strängt nödvändigt.
    ///
    /// Det övergripande målet med dessa krav är att låta konsumenten använda en rörledning
    /// * allt som finns kvar i källan efter att iterationen har upphört
    /// * minnet som har blivit oanvänt genom att flytta fram en konsumerande iterator
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// En iteratoradapter som producerar utdata så länge den underliggande iteratorn producerar `Result::Ok`-värden.
///
///
/// Om ett fel uppstår stannar iteratorn och felet sparas.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Bearbeta den givna iteratorn som om den gav en `T` istället för en `Result<T, _>`.
/// Eventuella fel kommer att stoppa den inre itatorn och det totala resultatet blir ett fel.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}