//! Komponerbar extern iteration.
//!
//! Om du har hittat dig med en samling av något slag och behövt utföra en operation på elementen i nämnda samling kommer du snabbt att stöta på 'iterators'.
//! Iteratorer används starkt i idiomatisk Rust-kod, så det är värt att bli bekant med dem.
//!
//! Innan vi förklarar mer, låt oss prata om hur den här modulen är uppbyggd:
//!
//! # Organization
//!
//! Denna modul är till stor del organiserad efter typ:
//!
//! * [Traits] är kärnan: dessa traits definierar vilken typ av iteratorer som finns och vad du kan göra med dem.Metoderna i dessa traits är värda att lägga lite extra studietid på.
//! * [Functions] ge några användbara sätt att skapa några grundläggande iteratorer.
//! * [Structs] är ofta returtyperna för de olika metoderna på den här modulens traits.Du vill vanligtvis titta på metoden som skapar `struct`, snarare än själva `struct`.
//! För mer information om varför, se '[Implementing Iterator](#implementerings-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Det är allt!Låt oss gräva i iteratorer.
//!
//! # Iterator
//!
//! Hjärtat och själen i denna modul är [`Iterator`] trait.Kärnan i [`Iterator`] ser ut så här:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! En iterator har en metod, [`next`], som när den anropas returnerar ett [`Alternativ`]`<Item>".
//! [`next`] kommer att returnera [`Some(Item)`] så länge det finns element, och när de alla är uttömda, returnerar `None` för att indikera att iterationen är klar.
//! Enskilda iteratorer kan välja att återuppta iteration, och att ringa till [`next`] igen kan eller kanske inte så småningom börja returnera [`Some(Item)`] igen någon gång (se till exempel [`TryIter`]).
//!
//!
//! [Iterator`s fullständiga definition innehåller också ett antal andra metoder, men de är standardmetoder, byggda ovanpå [`next`], så du får dem gratis.
//!
//! Iteratorer är också komponerbara, och det är vanligt att kedja ihop dem för att göra mer komplexa former av bearbetning.Se [Adapters](#adapters)-avsnittet nedan för mer information.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # De tre formerna av iteration
//!
//! Det finns tre vanliga metoder som kan skapa iteratorer från en samling:
//!
//! * `iter()`, som itererar över `&T`.
//! * `iter_mut()`, som itererar över `&mut T`.
//! * `into_iter()`, som itererar över `T`.
//!
//! Olika saker i standardbiblioteket kan implementera en eller flera av de tre, där så är lämpligt.
//!
//! # Implementering av Iterator
//!
//! Att skapa en egen iterator innebär två steg: skapa en `struct` för att hålla iteratorns tillstånd och implementera sedan [`Iterator`] för den `struct`.
//! Det är därför det finns så många `struct`s i den här modulen: det finns en för varje iterator och iteratoradapter.
//!
//! Låt oss göra en iterator med namnet `Counter` som räknas från `1` till `5`:
//!
//! ```
//! // Först strukturen:
//!
//! /// En iterator som räknas från en till fem
//! struct Counter {
//!     count: usize,
//! }
//!
//! // vi vill att vårt antal ska börja med en, så låt oss lägga till en new()-metod för att hjälpa till.
//! // Detta är inte absolut nödvändigt, men är bekvämt.
//! // Observera att vi startar `count` på noll, vi får se varför i `next()`'s-implementeringen nedan.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Sedan implementerar vi `Iterator` för vår `Counter`:
//!
//! impl Iterator for Counter {
//!     // vi kommer att räkna med storleken
//!     type Item = usize;
//!
//!     // next() är den enda metoden som krävs
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Öka vårt antal.Det är därför vi började på noll.
//!         self.count += 1;
//!
//!         // Kontrollera om vi har räknat slut eller inte.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Och nu kan vi använda det!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Att ringa [`next`] på det här sättet blir repetitivt.Rust har en konstruktion som kan ringa [`next`] på din iterator tills den når `None`.Låt oss gå igenom det nästa.
//!
//! Observera också att `Iterator` tillhandahåller en standardimplementering av metoder som `nth` och `fold` som anropar `next` internt.
//! Det är dock också möjligt att skriva en anpassad implementering av metoder som `nth` och `fold` om en iterator kan beräkna dem mer effektivt utan att ringa `next`.
//!
//! # `for` loopar och `IntoIterator`
//!
//! Rust s syntax för `for`-loop är faktiskt socker för iteratorer.Här är ett grundläggande exempel på `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Detta kommer att skriva ut siffrorna en till fem, var och en på sin egen rad.Men du kommer att märka något här: vi ringde aldrig någonting på vår vector för att producera en iterator.Vad ger?
//!
//! Det finns en trait i standardbiblioteket för att konvertera något till en iterator: [`IntoIterator`].
//! Denna trait har en metod, [`into_iter`], som omvandlar det som implementerar [`IntoIterator`] till en iterator.
//! Låt oss ta en titt på den `for`-slingan igen och vad kompilatorn omvandlar den till:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-socker detta till:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Först kallar vi `into_iter()` för värdet.Sedan matchar vi på iteratorn som återvänder och ringer [`next`] om och om igen tills vi ser en `None`.
//! Vid den tidpunkten `break` vi ur slingan, och vi är klara iterating.
//!
//! Det finns ytterligare en subtil bit här: standardbiblioteket innehåller en intressant implementering av [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Med andra ord implementerar alla [`Iterator`] [`IntoIterator`] genom att bara returnera sig själva.Detta betyder två saker:
//!
//! 1. Om du skriver en [`Iterator`] kan du använda den med en `for`-slinga.
//! 2. Om du skapar en samling kan du genom att använda [`IntoIterator`] för den använda din samling med `for`-slingan.
//!
//! # Iterera genom referens
//!
//! Eftersom [`into_iter()`] tar `self` efter värde använder den en `for`-slinga för att iterera över en samling som förbrukar den samlingen.Ofta kanske du vill itera över en samling utan att konsumera den.
//! Många samlingar erbjuder metoder som ger iteratorer över referenser, konventionellt kallade `iter()` respektive `iter_mut()`:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` ägs fortfarande av denna funktion.
//! ```
//!
//! Om en samlingstyp `C` tillhandahåller `iter()` implementerar den vanligtvis också `IntoIterator` för `&C`, med en implementering som bara kallar `iter()`.
//! På samma sätt implementerar en samling `C` som tillhandahåller `iter_mut()` generellt `IntoIterator` för `&mut C` genom att delegera till `iter_mut()`.Detta möjliggör en bekväm förkortning:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // samma som `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // samma som `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Medan många samlingar erbjuder `iter()`, erbjuder inte alla `iter_mut()`.
//! Till exempel kan mutering av nycklarna till en [`HashSet<T>`] eller [`HashMap<K, V>`] sätta samlingen i ett inkonsekvent tillstånd om nyckelhashen ändras, så dessa samlingar erbjuder bara `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Funktioner som tar en [`Iterator`] och returnerar en annan [`Iterator`] kallas ofta 'iteratoradaptrar', eftersom de är en form av 'adapter'
//! pattern'.
//!
//! Vanliga iteratoradaptrar inkluderar [`map`], [`take`] och [`filter`].
//! Mer information finns i deras dokumentation.
//!
//! Om en iteratoradapter panics kommer iteratorn att vara i ett ospecificerat (men minnessäkert) tillstånd.
//! Detta tillstånd garanteras inte heller att vara detsamma över versioner av Rust, så du bör undvika att förlita dig på de exakta värdena som returneras av en iterator som fick panik.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iteratorer (och iterator [adapters](#adapters)) är *lata*. Det betyder att bara att skapa en iterator inte _do_ mycket. Ingenting händer egentligen förrän du ringer till [`next`].
//! Detta är ibland en förvirring när man skapar en iterator enbart för dess biverkningar.
//! Till exempel kallar [`map`]-metoden en förslutning för varje element som den itererar över:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Detta kommer inte att skriva ut några värden, eftersom vi bara skapade en iterator snarare än att använda den.Kompilatorn kommer att varna oss för denna typ av beteende:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Det idiomatiska sättet att skriva en [`map`] för dess biverkningar är att använda en `for`-loop eller ringa [`for_each`]-metoden:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Ett annat vanligt sätt att utvärdera en iterator är att använda [`collect`]-metoden för att producera en ny samling.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iteratorer behöver inte vara ändliga.Som ett exempel är ett öppet intervall en oändlig iterator:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Det är vanligt att använda [`take`] iteratoradaptern för att göra en oändlig iterator till en ändlig:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Detta kommer att skriva ut siffrorna `0` till `4`, var och en på sin egen rad.
//!
//! Tänk på att metoder på oändliga iteratorer, även de för vilka ett resultat kan bestämmas matematiskt på begränsad tid, kanske inte avslutas.
//! Specifikt kommer metoder som [`min`], som i allmänhet kräver att korsa varje element i iteratorn, sannolikt inte att återvända framgångsrikt för oändliga iteratorer.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Å nej!En oändlig slinga!
//! // `ones.min()` orsakar en oändlig slinga, så vi når inte denna punkt!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;