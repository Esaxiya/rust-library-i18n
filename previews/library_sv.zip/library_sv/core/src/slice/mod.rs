// ignore-tidy-filelength

//! Skivhantering och manipulation.
//!
//! För mer information se [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Ren rust memchr-implementering, hämtad från rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Den här funktionen är bara offentlig eftersom det inte finns något annat sätt att testa heapsort.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Returnerar antalet element i segmentet.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // SÄKERHET: const-ljud eftersom vi överför längdfältet som en storlek (som det måste vara)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // SÄKERHET: detta är säkert eftersom `&[T]` och `FatPtr<T>` har samma layout.
            // Endast `std` kan göra denna garanti.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Byt ut med `crate::ptr::metadata(self)` när det är konststabilt.
            // När detta skrivs orsakar detta ett "Const-stable functions can only call other const-stable functions"-fel.
            //

            // SÄKERHET: Åtkomst till värdet från `PtrRepr`-kopplingen är säkert eftersom * konst T
            // och PtrComponents<T>har samma minneslayouter.
            // Endast std kan göra denna garanti.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Returnerar `true` om segmentet har en längd på 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Returnerar det första elementet i segmentet, eller `None` om det är tomt.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Returnerar en muterbar pekare till det första elementet i skivan, eller `None` om den är tom.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Returnerar den första och resten av elementen i skivan, eller `None` om den är tom.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Returnerar den första och resten av elementen i skivan, eller `None` om den är tom.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Returnerar den sista och resten av elementen i skivan, eller `None` om den är tom.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Returnerar den sista och resten av elementen i skivan, eller `None` om den är tom.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Returnerar det sista elementet i segmentet, eller `None` om det är tomt.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Returnerar en muterbar pekare till det sista objektet i segmentet.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Returnerar en referens till ett element eller underdel beroende på typ av index.
    ///
    /// - Om en position ges, returnerar en referens till elementet vid den positionen eller `None` om den är utanför gränserna.
    ///
    /// - Om ett intervall ges, returnerar den underskiva som motsvarar det intervallet, eller `None` om den är utanför gränserna.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Returnerar en muterbar referens till ett element eller underdel beroende på typen av index (se [`get`]) eller `None` om indexet är utanför gränserna.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Returnerar en referens till ett element eller underdel utan att göra gränskontroll.
    ///
    /// För ett säkert alternativ, se [`get`].
    ///
    /// # Safety
    ///
    /// Att kalla den här metoden med ett index utanför gränserna är *[odefinierat beteende]* även om den resulterande referensen inte används.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // SÄKERHET: den som ringer måste upprätthålla de flesta säkerhetskraven för `get_unchecked`;
        // skivan kan avläsas eftersom `self` är en säker referens.
        // Den returnerade pekaren är säker eftersom implantat av `SliceIndex` måste garantera att det är det.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Returnerar en muterbar referens till ett element eller underdel utan att göra gränskontroll.
    ///
    /// För ett säkert alternativ, se [`get_mut`].
    ///
    /// # Safety
    ///
    /// Att kalla den här metoden med ett index utanför gränserna är *[odefinierat beteende]* även om den resulterande referensen inte används.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // SÄKERHET: den som ringer måste upprätthålla säkerhetskraven för `get_unchecked_mut`;
        // skivan kan avläsas eftersom `self` är en säker referens.
        // Den returnerade pekaren är säker eftersom implantat av `SliceIndex` måste garantera att det är det.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Returnerar en rå pekare till skivans buffert.
    ///
    /// Den som ringer måste se till att skivan överlever pekaren som den här funktionen returnerar, annars kommer den att peka på skräp.
    ///
    /// Den som ringer måste också se till att minnet som pekaren (non-transitively) pekar på aldrig skrivs till (utom inuti en `UnsafeCell`) med den här pekaren eller någon pekare som härrör från den.
    /// Om du behöver mutera innehållet i skivan, använd [`as_mut_ptr`].
    ///
    /// Om du ändrar behållaren som det här stycket hänvisar till kan dess buffert omfördelas, vilket också skulle göra eventuella pekare till den ogiltiga.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Returnerar en osäker muterbar pekare till skivans buffert.
    ///
    /// Den som ringer måste se till att skivan överlever pekaren som den här funktionen returnerar, annars kommer den att peka på skräp.
    ///
    /// Om du ändrar behållaren som det här stycket hänvisar till kan dess buffert omfördelas, vilket också skulle göra eventuella pekare till den ogiltiga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Returnerar de två råa pekarna som sträcker sig över skivan.
    ///
    /// Det returnerade intervallet är halvöppet, vilket innebär att slutpekaren pekar *en förbi* det sista elementet i segmentet.
    /// På det här sättet representeras en tom skiva av två lika pekare, och skillnaden mellan de två pekarna representerar storleken på skivan.
    ///
    /// Se [`as_ptr`] för varningar om hur du använder dessa pekare.Slutpekaren kräver extra försiktighet, eftersom den inte pekar på ett giltigt element i segmentet.
    ///
    /// Denna funktion är användbar för interaktion med främmande gränssnitt som använder två pekare för att referera till en rad element i minnet, vilket är vanligt i C++ .
    ///
    ///
    /// Det kan också vara användbart att kontrollera om en pekare till ett element hänvisar till ett element i denna del:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // SÄKERHET: `add` här är säker, för:
        //
        //   - Båda pekarna är en del av samma objekt, eftersom det också räknas att peka direkt förbi objektet.
        //
        //   - Skivans storlek är aldrig större än isize::MAX byte, som nämnts här:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Det finns ingen inslagning inblandad, eftersom skivor inte slingrar sig förbi slutet av adressutrymmet.
        //
        // Se dokumentationen för pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Returnerar de två osäkra muterbara pekarna som spänner över skivan.
    ///
    /// Det returnerade intervallet är halvöppet, vilket innebär att slutpekaren pekar *en förbi* det sista elementet i segmentet.
    /// På det här sättet representeras en tom skiva av två lika pekare, och skillnaden mellan de två pekarna representerar storleken på skivan.
    ///
    /// Se [`as_mut_ptr`] för varningar om hur du använder dessa pekare.
    /// Slutpekaren kräver extra försiktighet, eftersom den inte pekar på ett giltigt element i segmentet.
    ///
    /// Denna funktion är användbar för interaktion med främmande gränssnitt som använder två pekare för att referera till en rad element i minnet, vilket är vanligt i C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // SÄKERHET: Se as_ptr_range() ovan för varför `add` här är säkert.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Byt två element i skivan.
    ///
    /// # Arguments
    ///
    /// * a, index för det första elementet
    /// * b, index för det andra elementet
    ///
    /// # Panics
    ///
    /// Panics om `a` eller `b` är utanför gränserna.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Kan inte ta två muterbara lån från en vector, så använd istället rå pekare.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // SÄKERHET: `pa` och `pb` har skapats från säkra muterbara referenser och hänvisar
        // till element i skivan och är därför garanterade att de är giltiga och inriktade.
        // Observera att åtkomst till elementen bakom `a` och `b` är markerad och kommer att panic när den är utanför gränserna.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Omvandlar ordningen på elementen i skivan på plats.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // För mycket små typer fungerar alla individer som läser i den normala vägen dåligt.
        // Vi kan göra bättre, med tanke på effektiv ojusterad load/store, genom att ladda en större bit och vända ett register.
        //

        // Helst skulle LLVM göra detta åt oss, eftersom det vet bättre än vi om ojämna läsningar är effektiva (eftersom det ändras mellan olika ARM-versioner, till exempel) och vad den bästa bitstorleken skulle vara.
        // Tyvärr, från och med LLVM 4.0 (2017-05) rullar det bara upp slingan, så vi måste göra det själva.
        // (Hypotes: omvänd är besvärligt eftersom sidorna kan justeras annorlunda-kommer att vara när längden är udda-så det finns inget sätt att avge före och efter att använda helt justerad SIMD i mitten.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Använd llvm.bswap inneboende för att vända u8-enheter i en storlek
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // SÄKERHET: Det finns flera saker att kontrollera här:
                //
                // - Observera att `chunk` är antingen 4 eller 8 på grund av cfg-kontrollen ovan.Så `chunk - 1` är positivt.
                // - Indexering med index `i` är bra eftersom loopkontrollen garanterar
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Indexering med index `ln - i - chunk = ln - (i + chunk)` är bra:
                //   - `i + chunk > 0` är trivialt sant.
                //   - Loopcheck garanterar:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, alltså subtraktion inte underflödet.
                // - `read_unaligned`-och `write_unaligned`-samtalen är bra:
                //   - `pa` pekar på index `i` där `i < ln / 2 - (chunk - 1)` (se ovan) och `pb` pekar på index `ln - i - chunk`, så båda är åtminstone `chunk` många byte från slutet av `self`.
                //
                //   - Alla initialiserade minne är giltiga `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Använd Rotate-by-16 för att vända u16s i en u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // SÄKERHET: En ojusterad u32 kan läsas från `i` om `i + 1 < ln`
                // (och uppenbarligen `i < ln`), eftersom varje element är 2 byte och vi läser 4.
                //
                // `i + chunk - 1 < ln / 2` # under skick
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Eftersom den är mindre än längden dividerad med 2 måste den vara i gränser.
                //
                // Detta innebär också att villkoret `0 < i + chunk <= ln` alltid respekteras, vilket säkerställer att `pb`-pekaren kan användas säkert.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // SÄKERHET: `i` är sämre än halva skivans längd så
            // åtkomst till `i` och `ln - i - 1` är säkert (`i` börjar vid 0 och kommer inte längre än `ln / 2 - 1`).
            // De resulterande pekarna `pa` och `pb` är därför giltiga och inriktade och kan läsas från och skrivas till.
            //
            //
            unsafe {
                // Osäker byte för att undvika gränserna i säker byte.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Returnerar en iterator över skivan.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Returnerar en iterator som gör det möjligt att ändra varje värde.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Returnerar en iterator över alla angränsande windows av längden `size`.
    /// windows överlappar varandra.
    /// Om segmentet är kortare än `size` returnerar iteratorn inga värden.
    ///
    /// # Panics
    ///
    /// Panics om `size` är 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Om segmentet är kortare än `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Returnerar en iterator över `chunk_size`-element i skivan åt gången, från början av skivan.
    ///
    /// Bitarna är skivor och överlappar inte varandra.Om `chunk_size` inte delar upp skivans längd kommer den sista biten inte att ha längden `chunk_size`.
    ///
    /// Se [`chunks_exact`] för en variant av denna iterator som returnerar bitar av alltid exakt `chunk_size`-element och [`rchunks`] för samma iterator men börjar i slutet av skivan.
    ///
    ///
    /// # Panics
    ///
    /// Panics om `chunk_size` är 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Returnerar en iterator över `chunk_size`-element i skivan åt gången, från början av skivan.
    ///
    /// Bitarna är mutabla skivor och överlappar inte varandra.Om `chunk_size` inte delar upp skivans längd kommer den sista biten inte att ha längden `chunk_size`.
    ///
    /// Se [`chunks_exact_mut`] för en variant av denna iterator som returnerar bitar av alltid exakt `chunk_size`-element och [`rchunks_mut`] för samma iterator men börjar i slutet av skivan.
    ///
    ///
    /// # Panics
    ///
    /// Panics om `chunk_size` är 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Returnerar en iterator över `chunk_size`-element i skivan åt gången, från början av skivan.
    ///
    /// Bitarna är skivor och överlappar inte varandra.
    /// Om `chunk_size` inte delar upp skivans längd kommer de sista upp till `chunk_size-1`-elementen att utelämnas och kan hämtas från iteratorns `remainder`-funktion.
    ///
    ///
    /// På grund av att varje bit har exakt `chunk_size`-element kan kompilatorn ofta optimera den resulterande koden bättre än i fallet med [`chunks`].
    ///
    /// Se [`chunks`] för en variant av denna iterator som också returnerar resten som en mindre bit, och [`rchunks_exact`] för samma iterator men börjar i slutet av skivan.
    ///
    /// # Panics
    ///
    /// Panics om `chunk_size` är 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Returnerar en iterator över `chunk_size`-element i skivan åt gången, från början av skivan.
    ///
    /// Bitarna är mutabla skivor och överlappar inte varandra.
    /// Om `chunk_size` inte delar upp skivans längd kommer de sista upp till `chunk_size-1`-elementen att utelämnas och kan hämtas från iteratorns `into_remainder`-funktion.
    ///
    ///
    /// På grund av att varje bit har exakt `chunk_size`-element kan kompilatorn ofta optimera den resulterande koden bättre än i fallet med [`chunks_mut`].
    ///
    /// Se [`chunks_mut`] för en variant av denna iterator som också returnerar resten som en mindre bit, och [`rchunks_exact_mut`] för samma iterator men börjar i slutet av skivan.
    ///
    /// # Panics
    ///
    /// Panics om `chunk_size` är 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Delar skivan i en skiva `N`-elementmatriser, förutsatt att det inte finns någon återstod.
    ///
    ///
    /// # Safety
    ///
    /// Detta kan bara kallas när
    /// - Skivan delar sig exakt i bitar av `N`-element (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // SÄKERHET: 1-element bitar har aldrig resten
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // SÄKERHET: Skivlängden (6) är en multipel av 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Dessa skulle vara olämpliga:
    /// // låt bitar: &[[_;5]]= slice.as_chunks_unchecked()//Skivlängden är inte en multipel av 5 låta bitar:&[[_;0]]= slice.as_chunks_unchecked()//Noll längd bitar är aldrig tillåtna
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SÄKERHET: Vår förutsättning är precis vad som behövs för att kalla detta
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SÄKERHET: Vi kastar en bit `new_len * N`-element i
        // en bit `new_len` många `N`-elementbitar.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Delar upp skivan i en skiva `N`-elementmatriser, som börjar i början av skivan, och en återstående skiva med längden strikt mindre än `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics om `N` är 0. Denna kontroll ändras troligen till ett kompileringsfel innan denna metod stabiliseras.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // SÄKERHET: Vi fick redan panik mot noll och garanterade genom konstruktion
        // att längden på underskivan är en multipel av N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Delar upp skivan i en bit `N`-elementmatriser, som börjar i slutet av skivan, och en återstående skiva med längden strikt mindre än `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics om `N` är 0. Denna kontroll ändras troligen till ett kompileringsfel innan denna metod stabiliseras.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // SÄKERHET: Vi fick redan panik mot noll och garanterade genom konstruktion
        // att längden på underskivan är en multipel av N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Returnerar en iterator över `N`-element i skivan åt gången, från början av skivan.
    ///
    /// Bitarna är matrisreferenser och överlappar inte varandra.
    /// Om `N` inte delar upp skivans längd kommer de sista upp till `N-1`-elementen att utelämnas och kan hämtas från iteratorns `remainder`-funktion.
    ///
    ///
    /// Denna metod är den generiska ekvivalenten för [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics om `N` är 0. Denna kontroll ändras troligen till ett kompileringsfel innan denna metod stabiliseras.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Delar skivan i en skiva `N`-elementmatriser, förutsatt att det inte finns någon återstod.
    ///
    ///
    /// # Safety
    ///
    /// Detta kan bara kallas när
    /// - Skivan delar sig exakt i bitar av `N`-element (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // SÄKERHET: 1-element bitar har aldrig resten
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // SÄKERHET: Skivlängden (6) är en multipel av 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Dessa skulle vara olämpliga:
    /// // låt bitar: &[[_;5]]= slice.as_chunks_unchecked_mut()//Skivlängden är inte en multipel av 5 låta bitar:&[[_;0]]= slice.as_chunks_unchecked_mut()//Noll längd bitar är aldrig tillåtna
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SÄKERHET: Vår förutsättning är precis vad som behövs för att kalla detta
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SÄKERHET: Vi kastar en bit `new_len * N`-element i
        // en bit `new_len` många `N`-elementbitar.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Delar upp skivan i en skiva `N`-elementmatriser, som börjar i början av skivan, och en återstående skiva med längden strikt mindre än `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics om `N` är 0. Denna kontroll ändras troligen till ett kompileringsfel innan denna metod stabiliseras.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // SÄKERHET: Vi fick redan panik mot noll och garanterade genom konstruktion
        // att längden på underskivan är en multipel av N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Delar upp skivan i en bit `N`-elementmatriser, som börjar i slutet av skivan, och en återstående skiva med längden strikt mindre än `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics om `N` är 0. Denna kontroll ändras troligen till ett kompileringsfel innan denna metod stabiliseras.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // SÄKERHET: Vi fick redan panik mot noll och garanterade genom konstruktion
        // att längden på underskivan är en multipel av N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Returnerar en iterator över `N`-element i skivan åt gången, från början av skivan.
    ///
    /// Bitarna är mutabla matrisreferenser och överlappar inte varandra.
    /// Om `N` inte delar upp skivans längd kommer de sista upp till `N-1`-elementen att utelämnas och kan hämtas från iteratorns `into_remainder`-funktion.
    ///
    ///
    /// Denna metod är den generiska ekvivalenten för [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics om `N` är 0. Denna kontroll ändras troligen till ett kompileringsfel innan denna metod stabiliseras.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Returnerar en iterator över överlappande windows av `N`-element i en skiva, från början av skivan.
    ///
    ///
    /// Detta är den generiska motsvarigheten till [`windows`].
    ///
    /// Om `N` är större än skivans storlek returnerar den ingen windows.
    ///
    /// # Panics
    ///
    /// Panics om `N` är 0.
    /// Denna kontroll ändras troligen till ett kompileringsfel innan den här metoden stabiliseras.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Returnerar en iterator över `chunk_size`-elementen i skivan åt gången, med början i slutet av skivan.
    ///
    /// Bitarna är skivor och överlappar inte varandra.Om `chunk_size` inte delar upp skivans längd kommer den sista biten inte att ha längden `chunk_size`.
    ///
    /// Se [`rchunks_exact`] för en variant av denna iterator som returnerar bitar av alltid exakt `chunk_size`-element och [`chunks`] för samma iterator men börjar i början av segmentet.
    ///
    ///
    /// # Panics
    ///
    /// Panics om `chunk_size` är 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Returnerar en iterator över `chunk_size`-elementen i skivan åt gången, med början i slutet av skivan.
    ///
    /// Bitarna är mutabla skivor och överlappar inte varandra.Om `chunk_size` inte delar upp skivans längd kommer den sista biten inte att ha längden `chunk_size`.
    ///
    /// Se [`rchunks_exact_mut`] för en variant av denna iterator som returnerar bitar av alltid exakt `chunk_size`-element och [`chunks_mut`] för samma iterator men börjar i början av segmentet.
    ///
    ///
    /// # Panics
    ///
    /// Panics om `chunk_size` är 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Returnerar en iterator över `chunk_size`-elementen i skivan åt gången, med början i slutet av skivan.
    ///
    /// Bitarna är skivor och överlappar inte varandra.
    /// Om `chunk_size` inte delar upp skivans längd kommer de sista upp till `chunk_size-1`-elementen att utelämnas och kan hämtas från iteratorns `remainder`-funktion.
    ///
    /// På grund av att varje bit har exakt `chunk_size`-element kan kompilatorn ofta optimera den resulterande koden bättre än i fallet med [`chunks`].
    ///
    /// Se [`rchunks`] för en variant av denna iterator som också returnerar resten som en mindre bit, och [`chunks_exact`] för samma iterator men börjar i början av skivan.
    ///
    ///
    /// # Panics
    ///
    /// Panics om `chunk_size` är 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Returnerar en iterator över `chunk_size`-elementen i skivan åt gången, med början i slutet av skivan.
    ///
    /// Bitarna är mutabla skivor och överlappar inte varandra.
    /// Om `chunk_size` inte delar upp skivans längd kommer de sista upp till `chunk_size-1`-elementen att utelämnas och kan hämtas från iteratorns `into_remainder`-funktion.
    ///
    /// På grund av att varje bit har exakt `chunk_size`-element kan kompilatorn ofta optimera den resulterande koden bättre än i fallet med [`chunks_mut`].
    ///
    /// Se [`rchunks_mut`] för en variant av denna iterator som också returnerar resten som en mindre bit, och [`chunks_exact_mut`] för samma iterator men börjar i början av skivan.
    ///
    ///
    /// # Panics
    ///
    /// Panics om `chunk_size` är 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Returnerar en iterator över segmentet som producerar icke-överlappande körningar av element som använder predikatet för att separera dem.
    ///
    /// Predikatet kallas på två element som följer sig själva, det betyder att predikatet kallas på `slice[0]` och `slice[1]` sedan på `slice[1]` och `slice[2]` och så vidare.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Denna metod kan användas för att extrahera de sorterade underkategorierna:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Returnerar en iterator över skivan som producerar icke-överlappande muterbara körningar av element som använder predikatet för att separera dem.
    ///
    /// Predikatet kallas på två element som följer sig själva, det betyder att predikatet kallas på `slice[0]` och `slice[1]` sedan på `slice[1]` och `slice[2]` och så vidare.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Denna metod kan användas för att extrahera de sorterade underkategorierna:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Delar en skiva i två i ett index.
    ///
    /// Den första innehåller alla index från `[0, mid)` (exklusive själva indexet `mid`) och det andra innehåller alla index från `[mid, len)` (exklusive själva indexet `len`).
    ///
    ///
    /// # Panics
    ///
    /// Panics om `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // SÄKERHET: `[ptr; mid]` och `[mid; len]` finns i `self`, vilket
        // uppfyller kraven i `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Delar en muterbar skiva i två vid ett index.
    ///
    /// Den första innehåller alla index från `[0, mid)` (exklusive själva indexet `mid`) och det andra innehåller alla index från `[mid, len)` (exklusive själva indexet `len`).
    ///
    ///
    /// # Panics
    ///
    /// Panics om `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // SÄKERHET: `[ptr; mid]` och `[mid; len]` finns i `self`, vilket
        // uppfyller kraven i `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Delar en skiva i två i ett index, utan att göra gränskontroll.
    ///
    /// Den första innehåller alla index från `[0, mid)` (exklusive själva indexet `mid`) och det andra innehåller alla index från `[mid, len)` (exklusive själva indexet `len`).
    ///
    ///
    /// För ett säkert alternativ, se [`split_at`].
    ///
    /// # Safety
    ///
    /// Att kalla den här metoden med ett index utanför gränserna är *[odefinierat beteende]* även om den resulterande referensen inte används.Den som ringer måste se till att `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // SÄKERHET: Uppringaren måste kontrollera att `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Delar en muterbar skiva i två i ett index utan att göra gränskontroll.
    ///
    /// Den första innehåller alla index från `[0, mid)` (exklusive själva indexet `mid`) och det andra innehåller alla index från `[mid, len)` (exklusive själva indexet `len`).
    ///
    ///
    /// För ett säkert alternativ, se [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Att kalla den här metoden med ett index utanför gränserna är *[odefinierat beteende]* även om den resulterande referensen inte används.Den som ringer måste se till att `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // SÄKERHET: Uppringaren måste kontrollera att `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` och `[mid; len]` överlappar inte varför det är bra att returnera en förändrad referens.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Returnerar en iterator över underkategorier åtskilda av element som matchar `pred`.
    /// Det matchade elementet ingår inte i underlicenser.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Om det första elementet matchas blir en tom del det första objektet som returneras av iteratorn.
    /// På samma sätt, om det sista elementet i skivan matchas, kommer en tom skiva att vara det sista objektet som returneras av iteratorn:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Om två matchade element ligger direkt intill kommer en tom skiva att finnas mellan dem:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Returnerar en iterator över muterbara underkategorier åtskilda av element som matchar `pred`.
    /// Det matchade elementet ingår inte i underlicenser.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Returnerar en iterator över underkategorier åtskilda av element som matchar `pred`.
    /// Det matchade elementet finns som en terminator i slutet av den förra underdelen.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Om det sista elementet i skivan matchas kommer detta element att betraktas som avslutaren för den föregående skivan.
    ///
    /// Den delen kommer att vara den sista artikeln som returneras av iteratorn.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Returnerar en iterator över muterbara underkategorier åtskilda av element som matchar `pred`.
    /// Det matchade elementet ingår i den föregående delskivan som en terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Returnerar en iterator över sublices åtskilda av element som matchar `pred`, börjar i slutet av segmentet och arbetar bakåt.
    /// Det matchade elementet ingår inte i underlicenser.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Som med `split()`, om det första eller sista elementet matchas, kommer en tom skiva att vara den första (eller sista) artikeln som returneras av iteratorn.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Returnerar en iterator över muterbara underklister åtskilda av element som matchar `pred`, börjar i slutet av skivan och arbetar bakåt.
    /// Det matchade elementet ingår inte i underlicenser.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Returnerar en iterator över underlicenser åtskilda av element som matchar `pred`, begränsat till att returnera högst `n`-objekt.
    /// Det matchade elementet ingår inte i underlicenser.
    ///
    /// Det sista returnerade elementet, om något, kommer att innehålla resten av segmentet.
    ///
    /// # Examples
    ///
    /// Skriv ut skivan delad en gång med siffror som kan delas med 3 (dvs. `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Returnerar en iterator över underlicenser åtskilda av element som matchar `pred`, begränsat till att returnera högst `n`-objekt.
    /// Det matchade elementet ingår inte i underlicenser.
    ///
    /// Det sista returnerade elementet, om något, kommer att innehålla resten av segmentet.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Returnerar en iterator över underkategorier åtskilda av element som matchar `pred` begränsat till att returnera högst `n`-objekt.
    /// Detta börjar i slutet av skivan och fungerar bakåt.
    /// Det matchade elementet ingår inte i underlicenser.
    ///
    /// Det sista returnerade elementet, om något, kommer att innehålla resten av segmentet.
    ///
    /// # Examples
    ///
    /// Skriv ut skivdelningen en gång, med början från slutet, med siffror som kan delas med 3 (dvs. `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Returnerar en iterator över underkategorier åtskilda av element som matchar `pred` begränsat till att returnera högst `n`-objekt.
    /// Detta börjar i slutet av skivan och fungerar bakåt.
    /// Det matchade elementet ingår inte i underlicenser.
    ///
    /// Det sista returnerade elementet, om något, kommer att innehålla resten av segmentet.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Returnerar `true` om segmentet innehåller ett element med det angivna värdet.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Om du inte har en `&T`, utan bara en `&U` så att `T: Borrow<U>` (t.ex.
    /// `Sträng: Låna<str>`), kan du använda `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // bit `String`
    /// assert!(v.iter().any(|e| e == "hello")); // sök med `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Returnerar `true` om `needle` är ett prefix för segmentet.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Returnerar alltid `true` om `needle` är en tom bit:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Returnerar `true` om `needle` är ett suffix av segmentet.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Returnerar alltid `true` om `needle` är en tom bit:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Returnerar en underdel med prefixet borttaget.
    ///
    /// Om skivan börjar med `prefix`, returnerar underdelen efter prefixet, insvept i `Some`.
    /// Om `prefix` är tom, returnerar du bara originalskivan.
    ///
    /// Om segmentet inte börjar med `prefix`, returneras `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Den här funktionen behöver skrivas om och när SlicePattern blir mer sofistikerad.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Returnerar en delskiva med borttagningen av suffixet.
    ///
    /// Om skivan slutar med `suffix`, returnerar underdelen före suffixet, insvept i `Some`.
    /// Om `suffix` är tom, returnerar du bara originalskivan.
    ///
    /// Om segmentet inte slutar med `suffix`, returneras `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Den här funktionen behöver skrivas om och när SlicePattern blir mer sofistikerad.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Binär söker i den här sorterade skivan efter ett visst element.
    ///
    /// Om värdet hittas returneras [`Result::Ok`] som innehåller indexet för det matchande elementet.
    /// Om det finns flera matchningar kan någon av matcherna returneras.
    /// Om värdet inte hittas returneras [`Result::Err`] med indexet där ett matchande element kan infogas medan den sorterade ordningen bibehålls.
    ///
    ///
    /// Se även [`binary_search_by`], [`binary_search_by_key`] och [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Slår upp en serie med fyra element.
    /// Den första finns, med en unik bestämd position;det andra och det tredje finns inte;den fjärde kan matcha vilken position som helst i `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Om du vill infoga ett objekt i en sorterad vector, med bibehållen sorteringsordning:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Binär söker efter det här sorterade segmentet med en komparatorfunktion.
    ///
    /// Komparatorfunktionen ska implementera en order som överensstämmer med sorteringsordningen för den underliggande skivan, och returnera en orderkod som anger om dess argument är `Less`, `Equal` eller `Greater` det önskade målet.
    ///
    ///
    /// Om värdet hittas returneras [`Result::Ok`] som innehåller indexet för det matchande elementet.Om det finns flera matchningar kan någon av matcherna returneras.
    /// Om värdet inte hittas returneras [`Result::Err`] med indexet där ett matchande element kan infogas medan den sorterade ordningen bibehålls.
    ///
    /// Se även [`binary_search`], [`binary_search_by_key`] och [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Slår upp en serie med fyra element.Den första finns, med en unik bestämd position;det andra och det tredje finns inte;den fjärde kan matcha vilken position som helst i `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // SÄKERHET: samtalet görs säkert av följande invarianter:
            // - `mid >= 0`
            // - `mid < size`: `mid` är begränsad av `[left; right)` bunden.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Anledningen till att vi använder if/else-kontrollflöde snarare än matchning beror på att matchning omorganiserar jämförelseåtgärder, vilket är perfekt känsligt.
            //
            // Det här är x86 asm för u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Binär söker efter den här sorterade skivan med en nyckelextraktionsfunktion.
    ///
    /// Antar att segmentet sorteras efter nyckeln, till exempel med [`sort_by_key`] med samma nyckelextraktionsfunktion.
    ///
    /// Om värdet hittas returneras [`Result::Ok`] som innehåller indexet för det matchande elementet.
    /// Om det finns flera matchningar kan någon av matcherna returneras.
    /// Om värdet inte hittas returneras [`Result::Err`] med indexet där ett matchande element kan infogas medan den sorterade ordningen bibehålls.
    ///
    ///
    /// Se även [`binary_search`], [`binary_search_by`] och [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Slår upp en serie med fyra element i ett par par sorterade efter deras andra element.
    /// Den första finns, med en unik bestämd position;det andra och det tredje finns inte;den fjärde kan matcha vilken position som helst i `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links är tillåten eftersom `slice::sort_by_key` är i crate `alloc`, och som sådan inte finns ännu när man bygger `core`.
    //
    // länkar till nedströms crate: #74481.Eftersom primitiv bara är dokumenterade i libstd (#73423) leder detta aldrig till trasiga länkar i praktiken.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Sorterar skivan men kan inte behålla ordningen på lika element.
    ///
    /// Denna sort är instabil (dvs kan ordna lika element), på plats (dvs tilldelar inte) och *O*(*n*\*log(* n*)) i värsta fall.
    ///
    /// # Aktuellt genomförande
    ///
    /// Den nuvarande algoritmen är baserad på [pattern-defeating quicksort][pdqsort] av Orson Peters, som kombinerar det snabba genomsnittliga fallet av randomiserad kvicksort med det snabbaste värsta fallet med heapsort, samtidigt som man uppnår linjär tid på skivor med vissa mönster.
    /// Den använder viss randomisering för att undvika degenererade fall, men med en fast seed för att alltid ge deterministiskt beteende.
    ///
    /// Det är vanligtvis snabbare än stabil sortering, förutom i några speciella fall, t.ex. när skivan består av flera sammanhängande sorterade sekvenser.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Sorterar skivan med en komparatorfunktion men kan inte behålla ordningen på lika element.
    ///
    /// Denna sort är instabil (dvs kan ordna lika element), på plats (dvs tilldelar inte) och *O*(*n*\*log(* n*)) i värsta fall.
    ///
    /// Komparatorfunktionen måste definiera en total ordning för elementen i segmentet.Om beställningen inte är total är elementens ordning ospecificerad.En order är en total order om den är (för alla `a`, `b` och `c`):
    ///
    /// * total och antisymmetrisk: exakt en av `a < b`, `a == b` eller `a > b` är sant, och
    /// * transitive, `a < b` och `b < c` innebär `a < c`.Detsamma måste gälla för både `==` och `>`.
    ///
    /// Till exempel, medan [`f64`] inte implementerar [`Ord`] eftersom `NaN != NaN`, kan vi använda `partial_cmp` som vår sorteringsfunktion när vi vet att skivan inte innehåller en `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Aktuellt genomförande
    ///
    /// Den nuvarande algoritmen är baserad på [pattern-defeating quicksort][pdqsort] av Orson Peters, som kombinerar det snabba genomsnittliga fallet av randomiserad kvicksort med det snabbaste värsta fallet med heapsort, samtidigt som man uppnår linjär tid på skivor med vissa mönster.
    /// Den använder viss randomisering för att undvika degenererade fall, men med en fast seed för att alltid ge deterministiskt beteende.
    ///
    /// Det är vanligtvis snabbare än stabil sortering, förutom i några speciella fall, t.ex. när skivan består av flera sammanhängande sorterade sekvenser.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // omvänd sortering
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Sorterar segmentet med en nyckelextraktionsfunktion, men kanske inte behåller ordningen på lika element.
    ///
    /// Denna sort är instabil (dvs kan ordna lika element), på plats (dvs tilldelar inte) och *O*(m\* * n *\* log(*n*)) i värsta fall, där nyckelfunktionen är *O*(*m*).
    ///
    /// # Aktuellt genomförande
    ///
    /// Den nuvarande algoritmen är baserad på [pattern-defeating quicksort][pdqsort] av Orson Peters, som kombinerar det snabba genomsnittliga fallet av randomiserad kvicksort med det snabbaste värsta fallet med heapsort, samtidigt som man uppnår linjär tid på skivor med vissa mönster.
    /// Den använder viss randomisering för att undvika degenererade fall, men med en fast seed för att alltid ge deterministiskt beteende.
    ///
    /// På grund av sin nyckelanropsstrategi är [`sort_unstable_by_key`](#method.sort_unstable_by_key) sannolikt långsammare än [`sort_by_cached_key`](#method.sort_by_cached_key) i fall där nyckelfunktionen är dyr.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Ordna om skivan så att elementet på `index` är i sitt slutliga sorterade läge.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Ordna om skivan med en komparatorfunktion så att elementet på `index` är i sitt slutliga sorterade läge.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Ordna om skivan med en nyckelextraktionsfunktion så att elementet på `index` är i sitt slutliga sorterade läge.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Ordna om skivan så att elementet på `index` är i sitt slutliga sorterade läge.
    ///
    /// Denna omordning har den ytterligare egenskapen att något värde vid position `i < index` kommer att vara mindre än eller lika med något värde på en position `j > index`.
    /// Dessutom är denna ordning instabil (dvs.
    /// valfritt antal lika element kan hamna i position `index`), på plats (dvs.
    /// fördelar inte) och *O*(*n*) i värsta fall.
    /// Denna funktion är även känd som "kth element" i andra bibliotek.
    /// Den returnerar en triplett av följande värden: alla element som är mindre än det i det givna indexet, värdet vid det givna indexet och alla element som är större än det i det givna indexet.
    ///
    ///
    /// # Aktuellt genomförande
    ///
    /// Den nuvarande algoritmen är baserad på snabbval-delen av samma quicksort-algoritm som används för [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics när `index >= len()`, vilket betyder att det alltid panics på tomma skivor.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Hitta medianen
    /// v.select_nth_unstable(2);
    ///
    /// // Vi är bara garanterade att skivan kommer att vara en av följande, baserat på hur vi sorterar om det angivna indexet.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Ordna om skivan med en komparatorfunktion så att elementet på `index` är i sitt slutliga sorterade läge.
    ///
    /// Denna omordning har den ytterligare egenskapen att något värde vid position `i < index` kommer att vara mindre än eller lika med något värde vid en position `j > index` med hjälp av komparatorfunktionen.
    /// Dessutom är denna ordning instabil (dvs. valfritt antal lika element kan hamna i position `index`), på plats (dvs. allokerar inte) och *O*(*n*) i värsta fall.
    /// Denna funktion kallas också "kth element" i andra bibliotek.
    /// Den returnerar en triplett av följande värden: alla element som är mindre än den i det angivna indexet, värdet vid det angivna indexet och alla element som är större än det i det angivna indexet, med hjälp av den medföljande komparatorfunktionen.
    ///
    ///
    /// # Aktuellt genomförande
    ///
    /// Den nuvarande algoritmen är baserad på snabbval-delen av samma quicksort-algoritm som används för [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics när `index >= len()`, vilket betyder att det alltid panics på tomma skivor.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Hitta medianen som om skivan sorterades i fallande ordning.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Vi är bara garanterade att skivan kommer att vara en av följande, baserat på hur vi sorterar om det angivna indexet.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Ordna om skivan med en nyckelextraktionsfunktion så att elementet på `index` är i sitt slutliga sorterade läge.
    ///
    /// Denna omordning har den ytterligare egenskapen att vilket värde som helst vid position `i < index` kommer att vara mindre än eller lika med vilket värde som helst vid en position `j > index` med hjälp av nyckelextraktionsfunktionen.
    /// Dessutom är denna ordning instabil (dvs. valfritt antal lika element kan hamna i position `index`), på plats (dvs. allokerar inte) och *O*(*n*) i värsta fall.
    /// Denna funktion kallas också "kth element" i andra bibliotek.
    /// Den returnerar en triplett av följande värden: alla element som är mindre än det vid det givna indexet, värdet vid det givna indexet och alla element som är större än det vid det givna indexet, med hjälp av den medföljande nyckelextraktionsfunktionen.
    ///
    ///
    /// # Aktuellt genomförande
    ///
    /// Den nuvarande algoritmen är baserad på snabbval-delen av samma quicksort-algoritm som används för [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics när `index >= len()`, vilket betyder att det alltid panics på tomma skivor.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Returnera medianen som om matrisen sorterades efter absolut värde.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Vi är bara garanterade att skivan kommer att vara en av följande, baserat på hur vi sorterar om det angivna indexet.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Flyttar alla upprepade element i rad till slutet av segmentet enligt [`PartialEq`] trait-implementeringen.
    ///
    ///
    /// Returnerar två skivor.Den första innehåller inga på varandra följande upprepade element.
    /// Den andra innehåller alla dubbletter i ingen angiven ordning.
    ///
    /// Om skivan sorteras innehåller den första returnerade skivan inga dubbletter.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Flyttar alla utom de första elementen i rad till slutet av skivan som uppfyller en given jämställdhetsrelation.
    ///
    /// Returnerar två skivor.Den första innehåller inga på varandra följande upprepade element.
    /// Den andra innehåller alla dubbletter i ingen angiven ordning.
    ///
    /// `same_bucket`-funktionen skickas referenser till två element från segmentet och måste avgöra om elementen är lika.
    /// Elementen skickas i motsatt ordning från sin ordning i segmentet, så om `same_bucket(a, b)` returnerar `true` flyttas `a` i slutet av segmentet.
    ///
    ///
    /// Om skivan sorteras innehåller den första returnerade skivan inga dubbletter.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Även om vi har en mutbar hänvisning till `self` kan vi inte göra *godtyckliga* ändringar.`same_bucket`-samtalen kan panic, så vi måste se till att skivan alltid är i ett giltigt tillstånd.
        //
        // Sättet vi hanterar detta på är att använda swappar;vi itererar över alla element, vi byter så fort vi går så att i slutet är elementen vi vill behålla framför, och de som vi vill avvisa är på baksidan.
        // Vi kan sedan dela upp skivan.
        // Denna operation är fortfarande `O(n)`.
        //
        // Exempel: Vi börjar i detta tillstånd, där `r` representerar "nästa
        // läs "och `w` representerar" nästa_skriv ".
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Jämförelse av self[r] mot själv [w-1], det här är inte en duplikat, så vi byter self[r] och self[w] (ingen effekt som r==w) och ökar sedan både r och w och lämnar oss med:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Jämförelse av self[r] mot själv [w-1] är detta värde en duplikat, så vi ökar `r` men lämnar allt annat oförändrat:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Jämförelse av self[r] mot själv [w-1], detta är inte en duplikat, så byt self[r] och self[w] och framåt r och w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Inte en duplikat, upprepa:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Duplicera, advance r. End av skivan.Dela vid w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // SÄKERHET: `while`-tillståndet garanterar `next_read` och `next_write`
        // är mindre än `len`, så är de inne i `self`.
        // `prev_ptr_write` pekar på ett element före `ptr_write`, men `next_write` börjar vid 1, så `prev_ptr_write` är aldrig mindre än 0 och är inne i skivan.
        // Detta uppfyller kraven för att hänvisa till `ptr_read`, `prev_ptr_write` och `ptr_write` och för att använda `ptr.add(next_read)`, `ptr.add(next_write - 1)` och `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` ökas också högst en gång per loop högst, vilket innebär att inget element hoppas över när det kan behöva bytas.
        //
        // `ptr_read` och `prev_ptr_write` pekar aldrig på samma element.Detta krävs för att `&mut *ptr_read`, `&mut* prev_ptr_write` ska vara säkra.
        // Förklaringen är helt enkelt att `next_read >= next_write` alltid är sant, så `next_read > next_write - 1` är det också.
        //
        //
        //
        //
        //
        unsafe {
            // Undvik gränskontroller genom att använda råa pekare.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Flyttar alla utom de första på varandra följande elementen till slutet av segmentet som löser sig till samma nyckel.
    ///
    ///
    /// Returnerar två skivor.Den första innehåller inga på varandra följande upprepade element.
    /// Den andra innehåller alla dubbletter i ingen angiven ordning.
    ///
    /// Om skivan sorteras innehåller den första returnerade skivan inga dubbletter.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Roterar skivan på plats så att de första `mid`-elementen i skivan rör sig till slutet medan de sista `self.len() - mid`-elementen rör sig framåt.
    /// Efter att ha ringt `rotate_left` blir elementet tidigare vid index `mid` det första elementet i segmentet.
    ///
    /// # Panics
    ///
    /// Denna funktion kommer att panic om `mid` är större än skivans längd.Observera att `mid == self.len()` gör _not_ panic och är en no-op-rotation.
    ///
    /// # Complexity
    ///
    /// Tar linjärt (i `self.len()`)-tid.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Rotera en delskiva:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // SÄKERHET: Området `[p.add(mid) - mid, p.add(mid) + k)` är trivialt
        // giltigt för läsning och skrivning, som krävs av `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Roterar skivan på plats så att de första `self.len() - k`-elementen i skivan rör sig till slutet medan de sista `k`-elementen rör sig framåt.
    /// Efter att ha ringt `rotate_right` blir elementet tidigare vid index `self.len() - k` det första elementet i segmentet.
    ///
    /// # Panics
    ///
    /// Denna funktion kommer att panic om `k` är större än skivans längd.Observera att `k == self.len()` gör _not_ panic och är en no-op-rotation.
    ///
    /// # Complexity
    ///
    /// Tar linjärt (i `self.len()`)-tid.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Rotera en underdel:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // SÄKERHET: Området `[p.add(mid) - mid, p.add(mid) + k)` är trivialt
        // giltigt för läsning och skrivning, som krävs av `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Fyller `self` med element genom att klona `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Fyller `self` med element som returneras genom att stänga upprepade gånger.
    ///
    /// Denna metod använder en stängning för att skapa nya värden.Om du hellre vill ha [`Clone`] ett visst värde, använd [`fill`].
    /// Om du vill använda [`Default`] trait för att generera värden kan du skicka [`Default::default`] som argument.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Kopierar elementen från `src` till `self`.
    ///
    /// Längden på `src` måste vara densamma som `self`.
    ///
    /// Om `T` implementerar `Copy` kan det vara bättre att använda [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Denna funktion kommer att panic om de två skivorna har olika längder.
    ///
    /// # Examples
    ///
    /// Kloning av två element från en skiva i en annan:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Eftersom skivorna måste ha samma längd skär vi källskivan från fyra element till två.
    /// // Det kommer att panic om vi inte gör det här.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust tvingar att det bara kan finnas en muterbar referens utan oföränderliga referenser till en viss datadel i ett visst omfång.
    /// På grund av detta kommer försök att använda `clone_from_slice` på en enda skiva att resultera i ett kompileringsfel:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// För att kringgå detta kan vi använda [`split_at_mut`] för att skapa två distinkta underskivor från en skiva:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Kopierar alla element från `src` till `self` med en memcpy.
    ///
    /// Längden på `src` måste vara densamma som `self`.
    ///
    /// Om `T` inte implementerar `Copy`, använd [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Denna funktion kommer att panic om de två skivorna har olika längder.
    ///
    /// # Examples
    ///
    /// Kopiera två element från en skiva till en annan:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Eftersom skivorna måste ha samma längd skär vi källskivan från fyra element till två.
    /// // Det kommer att panic om vi inte gör det här.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust tvingar att det bara kan finnas en muterbar referens utan oföränderliga referenser till en viss datadel i ett visst omfång.
    /// På grund av detta kommer försök att använda `copy_from_slice` på en enda skiva att resultera i ett kompileringsfel:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// För att kringgå detta kan vi använda [`split_at_mut`] för att skapa två distinkta underskivor från en skiva:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // panic-kodvägen placerades i en kall funktion för att inte svälja samtalsplatsen.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // SÄKERHET: `self` är per definition giltigt för `self.len()`-element och `src` var
        // kontrollerad för att ha samma längd.
        // Skivorna kan inte överlappa varandra eftersom mutabla referenser är exklusiva.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Kopierar element från en del av skivan till en annan del av sig själv med hjälp av en memmove.
    ///
    /// `src` är intervallet inom `self` att kopiera från.
    /// `dest` är startindex för intervallet inom `self` att kopiera till, som har samma längd som `src`.
    /// De två områdena kan överlappa varandra.
    /// Ändarna på de två områdena måste vara mindre än eller lika med `self.len()`.
    ///
    /// # Panics
    ///
    /// Denna funktion kommer att panic om endera intervallet överstiger slutet av segmentet, eller om slutet på `src` är innan start.
    ///
    ///
    /// # Examples
    ///
    /// Kopiera fyra byte i en bit:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // SÄKERHET: villkoren för `ptr::copy` har alla kontrollerats ovan,
        // liksom de för `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Byt alla element i `self` med dem i `other`.
    ///
    /// Längden på `other` måste vara densamma som `self`.
    ///
    /// # Panics
    ///
    /// Denna funktion kommer att panic om de två skivorna har olika längder.
    ///
    /// # Example
    ///
    /// Byt två element över skivor:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust tvingar fram att det bara kan finnas en muterbar referens till en viss datablad i ett visst omfång.
    ///
    /// På grund av detta kommer försök att använda `swap_with_slice` på en enda skiva att resultera i ett kompileringsfel:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// För att kringgå detta kan vi använda [`split_at_mut`] för att skapa två distinkta muterbara underskivor från en skiva:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // SÄKERHET: `self` är per definition giltigt för `self.len()`-element och `src` var
        // kontrollerad för att ha samma längd.
        // Skivorna kan inte överlappa varandra eftersom mutabla referenser är exklusiva.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Funktion för att beräkna längderna på mitten och efterföljande skiva för `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Vad vi ska göra med `rest` är att ta reda på vilken multipel av U-tal vi kan sätta i det lägsta antalet T-tal.
        //
        // Och hur många `T`s vi behöver för varje sådan "multiple".
        //
        // Tänk till exempel T=u8 U=u16.Sedan kan vi sätta 1 U i 2 Ts.Enkel.
        // Tänk nu till exempel på ett fall där size_of: :<T>=16, storlek_av::<U>=24.</u>
        // Vi kan placera 2 Us i stället för var tredje Ts i `rest`-skivan.
        // Lite mer komplicerat.
        //
        // Formel för att beräkna detta är:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Utökat och förenklat:
        //
        // Us=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Lyckligtvis eftersom allt detta utvärderas konstant ... prestanda här spelar ingen roll!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // iterativ steins algoritm Vi bör ändå göra den här `const fn` (och återgå till rekursiv algoritm om vi gör det) eftersom vi förlitar oss på llvm för att vara konstiga allt detta ... ja, det gör mig obekväm.
            //
            //

            // SÄKERHET: `a` och `b` är markerade som värden som inte är noll.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // ta bort alla faktorer om 2 från b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // SÄKERHET: `b` är kryssat för att vara noll.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Beväpnad med denna kunskap kan vi hitta hur många `U` vi kan passa!
        let us_len = self.len() / ts * us;
        // Och hur många `T` kommer det att finnas i den bakre skivan!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Transmutera skivan till en skiva av annan typ och se till att typens inriktning bibehålls.
    ///
    /// Denna metod delar upp skivan i tre distinkta skivor: prefix, korrekt inriktad mittskiva av en ny typ och suffixskiva.
    /// Metoden kan göra mellersta skivan så lång som möjligt för en viss typ och inmatningsskiva, men bara din algoritms prestanda bör bero på det, inte dess korrekthet.
    ///
    /// Det är tillåtet att alla ingångsdata returneras som prefix eller suffixskiva.
    ///
    /// Den här metoden har inget syfte när antingen ingångselementet `T` eller utgångselementet `U` är nollstorlek och returnerar den ursprungliga delen utan att dela upp någonting.
    ///
    /// # Safety
    ///
    /// Denna metod är i huvudsak en `transmute` med avseende på elementen i den returnerade mittskivan, så alla vanliga försiktighetsåtgärder avseende `transmute::<T, U>` gäller också här.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Observera att det mesta av denna funktion kommer att utvärderas konstant,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // hantera ZST speciellt, vilket är-hantera dem inte alls.
            return (self, &[], &[]);
        }

        // Hitta först vid vilken tidpunkt vi delar mellan första och andra skivan.
        // Enkelt med ptr.align_offset.
        let ptr = self.as_ptr();
        // SÄKERHET: Se `align_to_mut`-metoden för detaljerad säkerhetskommentar.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // SÄKERHET: nu är `rest` definitivt inriktad, så `from_raw_parts` nedan är okej,
            // eftersom den som ringer garanterar att vi kan överföra `T` till `U` säkert.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Transmutera skivan till en skiva av annan typ och se till att typens inriktning bibehålls.
    ///
    /// Denna metod delar upp skivan i tre distinkta skivor: prefix, korrekt inriktad mittskiva av en ny typ och suffixskiva.
    /// Metoden kan göra mellersta skivan så lång som möjligt för en viss typ och inmatningsskiva, men bara din algoritms prestanda bör bero på det, inte dess korrekthet.
    ///
    /// Det är tillåtet att alla ingångsdata returneras som prefix eller suffixskiva.
    ///
    /// Den här metoden har inget syfte när antingen ingångselementet `T` eller utgångselementet `U` är nollstorlek och returnerar den ursprungliga delen utan att dela upp någonting.
    ///
    /// # Safety
    ///
    /// Denna metod är i huvudsak en `transmute` med avseende på elementen i den returnerade mittskivan, så alla vanliga försiktighetsåtgärder avseende `transmute::<T, U>` gäller också här.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Observera att det mesta av denna funktion kommer att utvärderas konstant,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // hantera ZST speciellt, vilket är-hantera dem inte alls.
            return (self, &mut [], &mut []);
        }

        // Hitta först vid vilken tidpunkt vi delar mellan första och andra skivan.
        // Enkelt med ptr.align_offset.
        let ptr = self.as_ptr();
        // SÄKERHET: Här ser vi till att vi kommer att använda justerade pekare för U för
        // resten av metoden.Detta görs genom att skicka en pekare till&[T] med en inriktning riktad mot U.
        // `crate::ptr::align_offset` kallas med en korrekt inriktad och giltig pekare `ptr` (den kommer från en hänvisning till `self`) och med en storlek som är en effekt på två (eftersom den kommer från inriktningen för U), vilket uppfyller dess säkerhetsbegränsningar.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Vi kan inte använda `rest` igen efter detta, det skulle ogiltiga dess alias `mut_ptr`!SÄKERHET: se kommentarer för `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Kontrollerar om delarna i denna skiva är sorterade.
    ///
    /// Det vill säga, för varje element `a` och dess följande element `b` måste `a <= b` innehålla.Om segmentet ger exakt noll eller ett element returneras `true`.
    ///
    /// Observera att om `Self::Item` bara är `PartialOrd`, men inte `Ord`, innebär definitionen ovan att denna funktion returnerar `false` om två på varandra följande poster inte är jämförbara.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Kontrollerar om elementen i denna del sorteras med den givna komparatorfunktionen.
    ///
    /// Istället för att använda `PartialOrd::partial_cmp` använder den här funktionen den givna `compare`-funktionen för att bestämma ordningen för två element.
    /// Bortsett från det motsvarar det [`is_sorted`];se dess dokumentation för mer information.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Kontrollerar om elementen i denna del sorteras med den givna nyckelextraktionsfunktionen.
    ///
    /// Istället för att jämföra segmentets element direkt jämför denna funktion elementens tangenter, som bestäms av `f`.
    /// Bortsett från det motsvarar det [`is_sorted`];se dess dokumentation för mer information.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Returnerar index för partitionspunkten enligt det givna predikatet (indexet för det första elementet i den andra partitionen).
    ///
    /// Skivan antas vara partitionerad enligt det givna predikatet.
    /// Detta innebär att alla element för vilka predikatet returnerar true är i början av segmentet och alla element för vilka predikatet returnerar false är i slutet.
    ///
    /// Till exempel är [7, 15, 3, 5, 4, 12, 6] en partitionerad under predikatet x% 2!=0 (alla udda siffror är i början, alla till och med i slutet).
    ///
    /// Om detta segment inte är partitionerat är det returnerade resultatet ospecificerat och meningslöst, eftersom denna metod utför en slags binär sökning.
    ///
    /// Se även [`binary_search`], [`binary_search_by`] och [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // SÄKERHET: När `left < right`, `left <= mid < right`.
            // Därför ökar alltid `left` och `right` minskar alltid, och någon av dem väljs.I båda fallen är `left <= right` nöjd.Därför om `left < right` i ett steg är `left <= right` nöjd i nästa steg.
            //
            // Därför så länge `left != right` är `0 <= left < right <= len` nöjd och i detta fall `0 <= mid < len` också nöjd.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Vi måste skära dem uttryckligen i samma längd
        // för att göra det enklare för optimeraren att ta bort gränskontroll.
        // Men eftersom det inte kan lita på har vi också en uttrycklig specialisering för T: Copy.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Skapar en tom skiva.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Skapar en muterbar tom skiva.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Mönster i skivor används för närvarande endast av `strip_prefix` och `strip_suffix`.
/// Vid en future-punkt hoppas vi kunna generalisera `core::str::Pattern` (som i skrivande stund är begränsad till `str`) till skivor, och sedan kommer denna trait att ersättas eller avskaffas.
///
pub trait SlicePattern {
    /// Elementtypen för den skiva som matchas.
    type Item;

    /// För närvarande behöver `SlicePattern`-konsumenterna en bit.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}