// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Roterar intervallet `[mid-left, mid+right)` så att elementet vid `mid` blir det första elementet.På motsvarande sätt roterar `left`-elementen till vänster eller `right`-elementen till höger.
///
/// # Safety
///
/// Det angivna intervallet måste vara giltigt för läsning och skrivning.
///
/// # Algorithm
///
/// Algoritm 1 används för små värden på `left + right` eller för stora `T`.
/// Elementen flyttas till sina slutliga positioner en i taget med början vid `mid - left` och framåt genom `right`-steg modulo `left + right`, så att endast en tillfällig behövs.
/// Så småningom kommer vi tillbaka till `mid - left`.
/// Men om `gcd(left + right, right)` inte är 1 hoppades ovanstående steg över element.
/// Till exempel:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Lyckligtvis är antalet överhoppade element mellan slutförda element alltid lika, så vi kan bara kompensera vår startposition och göra fler omgångar (det totala antalet omgångar är `gcd(left + right, right)` value).
///
/// Slutresultatet är att alla element slutförs en gång och bara en gång.
///
/// Algoritm 2 används om `left + right` är stor men `min(left, right)` är tillräckligt liten för att passa in i en stackbuffert.
/// `min(left, right)`-elementen kopieras till bufferten, `memmove` appliceras på de andra och de på bufferten flyttas tillbaka i hålet på motsatt sida av där de har sitt ursprung.
///
/// Algoritmer som kan vektoriseras överträffar ovanstående när `left + right` blir tillräckligt stor.
/// Algoritm 1 kan vektoriseras genom att klumpa ihop och utföra många omgångar samtidigt, men det finns i genomsnitt för få omgångar tills `left + right` är enormt, och det värsta fallet med en enda omgång finns alltid där.
/// I stället använder algoritm 3 upprepad byte av `min(left, right)`-element tills ett mindre roteringsproblem kvarstår.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// när `left < right` byts ut sker från vänster istället.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. nedanstående algoritmer kan misslyckas om dessa fall inte kontrolleras
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algoritm 1 Microbenchmarks indikerar att den genomsnittliga prestandan för slumpmässiga skift är bättre hela vägen fram till ungefär `left + right == 32`, men i värsta fall går prestanda jämnt runt 16.
            // 24 valdes som mellanväg.
            // Om storleken på `T` är större än 4 `` storleken '' överträffar denna algoritm också andra algoritmer.
            //
            //
            let x = unsafe { mid.sub(left) };
            // början av första omgången
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` kan hittas före hand genom att beräkna `gcd(left + right, right)`, men det är snabbare att göra en slinga som beräknar gcd som en bieffekt och sedan gör resten av biten
            //
            //
            let mut gcd = right;
            // riktmärken visar att det är snabbare att byta temporärer hela vägen istället för att läsa en tillfällig en gång, kopiera bakåt och sedan skriva den tillfälliga i slutet.
            // Detta beror möjligen på det faktum att byte eller ersättning av temporärer endast använder en minnesadress i slingan istället för att behöva hantera två.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // istället för att öka `i` och sedan kontrollera om det ligger utanför gränserna, kontrollerar vi om `i` kommer att gå utanför gränserna vid nästa steg.
                // Detta förhindrar att pekare eller `usize` slås in.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // slutet av första omgången
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // detta villkor måste vara här om `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // avsluta biten med fler omgångar
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` är inte en typ av nollstorlek, så det är okej att dela med sin storlek.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algoritm 2 `[T; 0]` här är för att säkerställa att detta är korrekt anpassat för T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algoritm 3 Det finns ett alternativt sätt att byta som innebär att hitta var den sista bytet av denna algoritm skulle vara, och att byta med den sista biten istället för att byta intilliggande bitar som denna algoritm gör, men detta sätt är fortfarande snabbare.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algoritm 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}