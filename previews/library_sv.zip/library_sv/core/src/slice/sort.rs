//! Skivsortering
//!
//! Den här modulen innehåller en sorteringsalgoritm baserad på Orson Peters mönsterbesegrande quicksort, publicerad på: <https://github.com/orlp/pdqsort>
//!
//!
//! Instabil sortering är kompatibel med libcore eftersom den inte tilldelar minne, till skillnad från vår stabila sorteringsimplementering.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// När du tappar kopior från `src` till `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // SÄKERHET: Detta är en hjälpklass.
        //          Se dess användning för korrekthet.
        //          Man måste nämligen vara säker på att `src` och `dst` inte överlappar varandra enligt `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Flyttar det första elementet till höger tills det stöter på ett större eller lika element.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SÄKERHET: De osäkra operationerna nedan innefattar indexering utan bunden kontroll (`get_unchecked` och `get_unchecked_mut`)
    // och kopieringsminne (`ptr::copy_nonoverlapping`).
    //
    // a.Indexering:
    //  1. Vi kontrollerade storleken på matrisen till>=2.
    //  2. All indexering som vi kommer att göra är alltid högst mellan {0 <= index < len}.
    //
    // b.Minneskopiering
    //  1. Vi får tips till referenser som garanterat är giltiga.
    //  2. De kan inte överlappa varandra eftersom vi får pekare till skillnadsindex för skivan.
    //     Nämligen `i` och `i-1`.
    //  3. Om skivan är korrekt inriktad, är elementen ordentligt inriktade.
    //     Det är den som ringer upp att se till att skivan är korrekt inriktad.
    //
    // Se kommentarer nedan för mer information.
    unsafe {
        // Om de två första elementen inte är i ordning ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Läs det första elementet i en stack-allokerad variabel.
            // Om en följande jämförelseoperation panics kommer `hole` att tappas och automatiskt skriva tillbaka elementet i skivan.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Flytta `i`-elementet ett ställe åt vänster och förskjut hålet åt höger.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` tappas och kopierar därmed `tmp` i det återstående hålet i `v`.
        }
    }
}

/// Flyttar det sista elementet åt vänster tills det möter ett mindre eller lika element.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SÄKERHET: De osäkra operationerna nedan innefattar indexering utan bunden kontroll (`get_unchecked` och `get_unchecked_mut`)
    // och kopieringsminne (`ptr::copy_nonoverlapping`).
    //
    // a.Indexering:
    //  1. Vi kontrollerade storleken på matrisen till>=2.
    //  2. All indexering som vi kommer att göra är alltid högst mellan `0 <= index < len-1`.
    //
    // b.Minneskopiering
    //  1. Vi får tips till referenser som garanterat är giltiga.
    //  2. De kan inte överlappa varandra eftersom vi får pekare till skillnadsindex för skivan.
    //     Nämligen `i` och `i+1`.
    //  3. Om skivan är korrekt inriktad, är elementen ordentligt inriktade.
    //     Det är den som ringer upp att se till att skivan är korrekt inriktad.
    //
    // Se kommentarer nedan för mer information.
    unsafe {
        // Om de två sista elementen inte är i ordning ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Läs det sista elementet i en stack-allokerad variabel.
            // Om en följande jämförelseoperation panics kommer `hole` att tappas och automatiskt skriva tillbaka elementet i skivan.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Flytta `i`-elementet en plats åt höger och förskjut därmed hålet åt vänster.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` tappas och kopierar därmed `tmp` i det återstående hålet i `v`.
        }
    }
}

/// Sorterar delvis en bit genom att flytta flera delar som inte är i ordning.
///
/// Returnerar `true` om segmentet sorteras i slutet.Denna funktion är *O*(*n*) i värsta fall.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Maximalt antal intilliggande par som inte är i ordning som flyttas.
    const MAX_STEPS: usize = 5;
    // Om skivan är kortare än så ska du inte flytta några element.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // SÄKERHET: Vi gjorde redan uttryckligen den bundna kontrollen med `i < len`.
        // All vår efterföljande indexering ligger bara i intervallet `0 <= index < len`
        unsafe {
            // Hitta nästa par intilliggande beställningselement.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Är vi klara?
        if i == len {
            return true;
        }

        // Förskjut inte element på korta arrays, det har en prestandakostnad.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Byt det hittade paret av element.Detta sätter dem i rätt ordning.
        v.swap(i - 1, i);

        // Flytta det mindre elementet åt vänster.
        shift_tail(&mut v[..i], is_less);
        // Flytta det större elementet till höger.
        shift_head(&mut v[i..], is_less);
    }

    // Klarade inte att sortera skivan i det begränsade antalet steg.
    false
}

/// Sorterar en skiva med insättningssortering, vilket är *O*(*n*^ 2) i värsta fall.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Sorterar `v` med heapsort, vilket garanterar *O*(*n*\*log(* n*)) i värsta fall.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Denna binära hög respekterar den oföränderliga `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Barn av `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Välj det större barnet.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Stoppa om invarianten håller på `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Byt `node` med det större barnet, flytta ett steg nedåt och fortsätt siktningen.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Bygg högen i linjär tid.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop maximala element från högen.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Partitionerar `v` till element som är mindre än `pivot`, följt av element som är större än eller lika med `pivot`.
///
///
/// Returnerar antalet element som är mindre än `pivot`.
///
/// Partitionering utförs block-för-block för att minimera kostnaden för förgreningar.
/// Denna idé presenteras i [BlockQuicksort][pdf]-uppsatsen.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Antal element i ett typiskt block.
    const BLOCK: usize = 128;

    // Partitioneringsalgoritmen upprepar följande steg tills de är färdiga:
    //
    // 1. Spåra ett block från vänster sida för att identifiera element som är större än eller lika med pivoten.
    // 2. Spåra ett block från höger sida för att identifiera element som är mindre än pivoten.
    // 3. Byt de identifierade elementen mellan vänster och höger sida.
    //
    // Vi har följande variabler för ett block av element:
    //
    // 1. `block` - Antal element i blocket.
    // 2. `start` - Starta pekaren i `offsets`-matrisen.
    // 3. `end` - Avsluta pekaren i `offsets`-arrayen.
    // 4. `förskjutningar, index för element som inte är i ordning inom blocket.

    // Det aktuella blocket på vänster sida (från `l` till `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Det aktuella blocket på höger sida (från `r.sub(block_r)` to `r`).
    // SÄKERHET: Dokumentationen för .add() nämner specifikt att `vec.as_ptr().add(vec.len())` alltid är säker
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: När vi får VLAs, försök skapa en grupp med längden `min(v.len(), 2 * BLOCK) `snarare
    // än två matriser med fast storlek med längden `BLOCK`.VLA: er kan vara mer cacheffektiva.

    // Returnerar antalet element mellan pekare `l` (inclusive) och `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Vi är klara med att partitionera block-för-block när `l` och `r` kommer mycket nära.
        // Sedan gör vi lite lapparbete för att partitionera de återstående elementen däremellan.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Antal återstående element (fortfarande inte jämfört med pivoten).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Justera blockstorlekarna så att det vänstra och högra blocket inte överlappar varandra, men justeras perfekt för att täcka hela kvarvarande mellanrum.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Spåra `block_l`-element från vänster sida.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // SÄKERHET: Osäkerhetsfunktionerna nedan innebär användning av `offset`.
                //         Enligt de villkor som krävs av funktionen uppfyller vi dem eftersom:
                //         1. `offsets_l` är stack-allokerad och anses därför separat tilldelat objekt.
                //         2. Funktionen `is_less` returnerar en `bool`.
                //            Att casta en `bool` kommer aldrig att översvämma `isize`.
                //         3. Vi har garanterat att `block_l` blir `<= BLOCK`.
                //            Dessutom var `end_l` ursprungligen inställd på startpekaren för `offsets_` som deklarerades på stacken.
                //            Således vet vi att även i värsta fall (alla anrop på `is_less` returnerar falskt) kommer vi bara att vara högst 1 byte passera slutet.
                //        En annan osäkerhetsåtgärd här är dereferencing `elem`.
                //        `elem` var dock initialt startpekaren till den del som alltid är giltig.
                unsafe {
                    // Grenfri jämförelse.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Spåra `block_r`-element från höger sida.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // SÄKERHET: Osäkerhetsfunktionerna nedan innebär användning av `offset`.
                //         Enligt de villkor som krävs av funktionen uppfyller vi dem eftersom:
                //         1. `offsets_r` är stack-allokerad och anses därför separat tilldelat objekt.
                //         2. Funktionen `is_less` returnerar en `bool`.
                //            Att casta en `bool` kommer aldrig att översvämma `isize`.
                //         3. Vi har garanterat att `block_r` blir `<= BLOCK`.
                //            Dessutom var `end_r` ursprungligen inställd på startpekaren för `offsets_` som deklarerades på stacken.
                //            Således vet vi att även i värsta fall (alla anrop av `is_less` returnerar sant) kommer vi bara att vara högst 1 byte passera slutet.
                //        En annan osäkerhetsåtgärd här är dereferencing `elem`.
                //        `elem` var dock ursprungligen `1 *sizeof(T)` efter slutet och vi minskar det med `1* sizeof(T)` innan vi öppnar det.
                //        Dessutom hävdades att `block_r` var mindre än `BLOCK` och `elem` pekar därför högst på början av skivan.
                unsafe {
                    // Grenfri jämförelse.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Antal out-of-order-element som ska bytas mellan vänster och höger sida.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Istället för att byta ett par åt gången är det mer effektivt att utföra en cyklisk permutation.
            // Detta motsvarar inte strikt byte, men ger ett liknande resultat med färre minnesoperationer.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Alla beställda element i det vänstra blocket flyttades.Gå till nästa block.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Alla beställda element i det högra blocket flyttades.Gå till föregående block.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Allt som återstår nu är högst ett kvarter (antingen vänster eller höger) med element som inte är i ordning som måste flyttas.
    // Sådana återstående element kan helt enkelt flyttas till slutet inom sitt block.
    //

    if start_l < end_l {
        // Det vänstra blocket kvar.
        // Flytta de återstående beställda elementen längst till höger.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Rätt block kvarstår.
        // Flytta de återstående beställda elementen längst till vänster.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Inget annat att göra, vi är klara.
        width(v.as_mut_ptr(), l)
    }
}

/// Partitionerar `v` till element som är mindre än `v[pivot]`, följt av element som är större än eller lika med `v[pivot]`.
///
///
/// Returnerar en tuple av:
///
/// 1. Antal element mindre än `v[pivot]`.
/// 2. Det är sant om `v` redan var partitionerat.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Placera pivoten i början av skivan.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Läs pivoten i en stack-allokerad variabel för effektivitet.
        // Om en följande jämförelseoperation panics skrivs pivoten automatiskt tillbaka i segmentet.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Hitta det första paret som inte är i ordning.
        let mut l = 0;
        let mut r = v.len();

        // SÄKERHET: Osäkerheten nedan innebär att en array indexeras.
        // För det första: Vi gör redan gränserna här med `l < r`.
        // För den andra: Vi har ursprungligen `l == 0` och `r == v.len()` och vi kontrollerade att `l < r` vid varje indexering.
        //                     Härifrån vet vi att `r` måste vara minst `r == l` vilket visades vara giltigt från den första.
        unsafe {
            // Hitta det första elementet som är större än eller lika med pivoten.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Hitta det sista elementet som är mindre än pivoten.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` går utanför räckvidden och skriver pivoten (som är en stackallokerad variabel) tillbaka i den skiva där den ursprungligen var.
        // Detta steg är avgörande för att säkerställa säkerheten!
        //
    };

    // Placera pivoten mellan de två partitionerna.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Partitioner `v` till element lika med `v[pivot]` följt av element större än `v[pivot]`.
///
/// Returnerar antalet element som är lika med pivoten.
/// Det antas att `v` inte innehåller element som är mindre än pivoten.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Placera pivoten i början av skivan.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Läs pivoten i en stack-allokerad variabel för effektivitet.
    // Om en följande jämförelseoperation panics skrivs pivoten automatiskt tillbaka i segmentet.
    // SÄKERHET: Pekaren här är giltig eftersom den erhålls från en hänvisning till en skiva.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Partitionera nu skivan.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // SÄKERHET: Osäkerheten nedan innebär att en array indexeras.
        // För det första: Vi gör redan gränserna här med `l < r`.
        // För den andra: Vi har ursprungligen `l == 0` och `r == v.len()` och vi kontrollerade att `l < r` vid varje indexering.
        //                     Härifrån vet vi att `r` måste vara minst `r == l` vilket visades vara giltigt från den första.
        unsafe {
            // Hitta det första elementet som är större än pivoten.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Hitta det sista elementet som är lika med pivoten.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Är vi klara?
            if l >= r {
                break;
            }

            // Byt det hittade paret som inte finns i ordningen.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Vi hittade `l`-element lika med pivoten.Lägg till 1 till konto för själva pivoten.
    l + 1

    // `_pivot_guard` går utanför räckvidden och skriver pivoten (som är en stackallokerad variabel) tillbaka i den skiva där den ursprungligen var.
    // Detta steg är avgörande för att säkerställa säkerheten!
}

/// Spridar några element runt i ett försök att bryta mönster som kan orsaka obalanserade partitioner i quicksort.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Pseudorandom nummergenerator från "Xorshift RNGs" papper av George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Ta slumptal modulo detta nummer.
        // Siffran passar in i `usize` eftersom `len` inte är större än `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Vissa pivotkandidater finns i närheten av detta index.Låt oss randomisera dem.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Skapa ett slumptalsmodul `len`.
            // För att undvika dyra operationer tar vi emellertid först modulo en effekt på två och minskar sedan med `len` tills den passar in i intervallet `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` är garanterat mindre än `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Väljer en pivot i `v` och returnerar indexet och `true` om segmentet sannolikt redan är sorterat.
///
/// Element i `v` kan ordnas om under processen.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Minsta längd för att välja metian-median-metoden.
    // Kortare skivor använder den enkla median-av-tre-metoden.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Maximalt antal swappar som kan utföras i denna funktion.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Tre index nära vilka vi ska välja en pivot.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Räknar det totala antalet swappar vi håller på att utföra när vi sorterar index.
    let mut swaps = 0;

    if len >= 8 {
        // Byt index så att `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Byt index så att `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Hitta medianen för `v[a - 1], v[a], v[a + 1]` och lagrar indexet i `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Hitta medianer i stadsdelarna `a`, `b` och `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Hitta medianen bland `a`, `b` och `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Det maximala antalet byten genomfördes.
        // Chansen är stor att skivan är fallande eller oftast fallande, så omvändning kommer troligen att hjälpa till att sortera den snabbare.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Sorterar `v` rekursivt.
///
/// Om segmentet hade en föregångare i den ursprungliga matrisen anges den som `pred`.
///
/// `limit` är antalet tillåtna obalanserade partitioner innan du byter till `heapsort`.
/// Om noll växlar denna funktion omedelbart till heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Skivor upp till denna längd sorteras med insättningssortering.
    const MAX_INSERTION: usize = 20;

    // Det är sant om den sista partitionen var rimligt balanserad.
    let mut was_balanced = true;
    // Det är sant om den sista partitioneringen inte blandade element (skivan var redan partitionerad).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Mycket korta skivor sorteras med insättningssortering.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Om för många dåliga pivotval gjordes, falla helt enkelt tillbaka till heapsort för att garantera `O(n * log(n))` värsta fall.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Om den sista partitionen var obalanserad, försök att bryta mönster i skivan genom att blanda några element runt.
        // Förhoppningsvis väljer vi en bättre pivot den här gången.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Välj en pivot och försök gissa om skivan redan är sorterad.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Om den sista partitionen var anständigt balanserad och inte blandade element, och om pivotval förutspår, är segmentet sannolikt redan sorterat ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Försök att identifiera flera element som inte är i ordning och flytta dem till rätt position.
            // Om skivan slutar vara helt sorterad är vi klara.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Om den valda pivoten är lika med föregångaren är det det minsta elementet i skivan.
        // Partitionera skivan i element som är lika med och element som är större än pivoten.
        // Detta fall träffas vanligtvis när segmentet innehåller många dubbletter.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Fortsätt att sortera element som är större än pivoten.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Partitionera skivan.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Dela upp skivan i `left`, `pivot` och `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Byt bara in på kortsidan för att minimera det totala antalet rekursiva samtal och konsumera mindre stackutrymme.
        // Fortsätt sedan bara med den längre sidan (detta liknar svansrekursion).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Sorterar `v` med hjälp av mönsterbesegrande quicksort, vilket är *O*(*n*\*log(* n*)) i värsta fall.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Sortering har inget meningsfullt beteende på nollstorlekstyper.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Begränsa antalet obalanserade partitioner till `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // För skivor upp till denna längd är det förmodligen snabbare att helt enkelt sortera dem.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Välj en pivot
        let (pivot, _) = choose_pivot(v, is_less);

        // Om den valda pivoten är lika med föregångaren är det det minsta elementet i skivan.
        // Partitionera skivan i element som är lika med och element som är större än pivoten.
        // Detta fall träffas vanligtvis när segmentet innehåller många dubbletter.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Om vi har klarat vårt index är vi bra.
                if mid > index {
                    return;
                }

                // I annat fall fortsätter du att sortera element som är större än pivoten.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Dela upp skivan i `left`, `pivot` och `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Om mitt==index är vi klara, eftersom partition() garanterade att alla element efter mitten är större än eller lika med mitten.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Sortering har inget meningsfullt beteende på nollstorlekstyper.Göra ingenting.
    } else if index == v.len() - 1 {
        // Hitta maxelement och placera det i den sista positionen i matrisen.
        // Vi kan använda `unwrap()` här eftersom vi vet att v inte får vara tomt.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Hitta min-element och placera det i matrisens första position.
        // Vi kan använda `unwrap()` här eftersom vi vet att v inte får vara tomt.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}