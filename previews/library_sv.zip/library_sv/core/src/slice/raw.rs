//! Gratis funktioner för att skapa `&[T]` och `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Bildar en bit från en pekare och en längd.
///
/// `len`-argumentet är antalet **element**, inte antalet byte.
///
/// # Safety
///
/// Beteende är odefinierat om något av följande villkor bryts:
///
/// * `data` måste vara [valid] för läsningar för `len * mem::size_of::<T>()` många byte, och den måste vara korrekt inriktad.Detta innebär särskilt:
///
///     * Hela minnesområdet för denna skiva måste finnas i ett enda tilldelat objekt!
///       Skivor kan aldrig spänna över flera tilldelade objekt.Se [below](#incorrect-usage) för ett exempel som felaktigt inte tar hänsyn till detta.
///     * `data` måste vara icke-noll och justeras även för skivor med noll längd.
///     En anledning till detta är att optimeringar av enumlayout kan vara beroende av att referenser (inklusive skivor av vilken längd som helst) är inriktade och inte är null för att skilja dem från andra data.
///     Du kan få en pekare som kan användas som `data` för nollängdsskivor med [`NonNull::dangling()`].
///
/// * `data` måste peka på `len` på varandra följande korrekt initierade värden av typen `T`.
///
/// * Minnet som den returnerade skivan refererar till får inte muteras under livstidens `'a`, utom i en `UnsafeCell`.
///
/// * Den totala storleken `len * mem::size_of::<T>()` för skivan får inte vara större än `isize::MAX`.
///   Se säkerhetsdokumentationen för [`pointer::offset`].
///
/// # Caveat
///
/// Livslängden för den returnerade skivan härleds från dess användning.
/// För att förhindra oavsiktligt missbruk, föreslås att du kopplar livslängden till vilken källlivstid som är säker i sammanhanget, till exempel genom att tillhandahålla en hjälpfunktion som tar livstiden för ett värdvärde för skivan, eller genom uttrycklig kommentar.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // manifestera en bit för ett enda element
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Felaktig användning
///
/// Följande `join_slices`-funktion är **osund** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Påståendet ovan säkerställer att `fst` och `snd` är angränsande, men de kan fortfarande finnas i _different allocated objects_, i vilket fall att skapa detta segment är odefinierat beteende.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` och `b` är olika tilldelade objekt ...
///     let a = 42;
///     let b = 27;
///     // ... som ändå kan läggas samman i minnet: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Utför samma funktion som [`from_raw_parts`], förutom att en muterbar del returneras.
///
/// # Safety
///
/// Beteende är odefinierat om något av följande villkor bryts:
///
/// * `data` måste vara [valid] för både läsningar och skrivningar för `len * mem::size_of::<T>()` många byte, och den måste vara korrekt inriktad.Detta innebär särskilt:
///
///     * Hela minnesområdet för denna skiva måste finnas i ett enda tilldelat objekt!
///       Skivor kan aldrig spänna över flera tilldelade objekt.
///     * `data` måste vara icke-noll och justeras även för skivor med noll längd.
///     En anledning till detta är att optimeringar av enumlayout kan vara beroende av att referenser (inklusive skivor av vilken längd som helst) är inriktade och inte är null för att skilja dem från andra data.
///
///     Du kan få en pekare som kan användas som `data` för nollängdsskivor med [`NonNull::dangling()`].
///
/// * `data` måste peka på `len` på varandra följande korrekt initierade värden av typen `T`.
///
/// * Minnet som den returnerade skivan refererar till får inte nås via någon annan pekare (inte härledd från returvärdet) under hela livstiden `'a`.
///   Både läs-och skrivåtkomst är förbjudet.
///
/// * Den totala storleken `len * mem::size_of::<T>()` för skivan får inte vara större än `isize::MAX`.
///   Se säkerhetsdokumentationen för [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Konverterar en hänvisning till T till en bit längd 1 (utan kopiering).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Konverterar en hänvisning till T till en bit längd 1 (utan kopiering).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}