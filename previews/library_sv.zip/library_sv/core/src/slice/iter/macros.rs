//! Makron som används av iteratorer av skiva.

// Inlining is_empty och len gör en enorm prestationsskillnad
macro_rules! is_empty {
    // Sättet vi kodar längden på en ZST-iterator, det fungerar både för ZST och icke-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// För att bli av med några begränsningar (se `position`) beräknar vi längden på ett något oväntat sätt.
// (Testad av 'codegen/skiva-position-gränser-check'.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // vi används ibland i ett osäkert block

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Den här _cannot_ använder `unchecked_sub` eftersom vi är beroende av inslagning för att representera längden på långa ZST-skiva iteratorer.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Vi vet att `start <= end`, så kan göra bättre än `offset_from`, som behöver handla in signerad.
            // Genom att ställa in lämpliga flaggor här kan vi berätta för LLVM detta, vilket hjälper det att ta bort gränskontroller.
            // SÄKERHET: Av typen invariant, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Genom att också berätta för LLVM att pekarna är åtskilda med en exakt multipel av typstorleken kan den optimera `len() == 0` ner till `start == end` istället för `(end - start) < size`.
            //
            // SÄKERHET: Efter typen invariant riktas pekarna så att
            //         avståndet mellan dem måste vara en multipel av pointerstorleken
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Den delade definitionen av `Iter` och `IterMut` iteratorer
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Returnerar det första elementet och flyttar iteratorns start framåt med 1.
        // Förbättrar kraftigt prestanda jämfört med en inline-funktion.
        // Iteratorn får inte vara tom.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Returnerar det sista elementet och flyttar iteratorns ände bakåt med 1.
        // Förbättrar kraftigt prestanda jämfört med en inline-funktion.
        // Iteratorn får inte vara tom.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Krymper iteratorn när T är en ZST, genom att flytta änden på iteratorn bakåt med `n`.
        // `n` får inte överstiga `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Hjälparfunktion för att skapa en bit från iteratorn.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // SÄKERHET: iteratorn skapades från en skiva med pekare
                // `self.ptr` och längd `len!(self)`.
                // Detta garanterar att alla förutsättningar för `from_raw_parts` är uppfyllda.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Hjälpfunktion för att flytta iteratorns start framåt med `offset`-element, vilket ger tillbaka den gamla starten.
            //
            // Osäkert eftersom förskjutningen inte får överstiga `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // SÄKERHET: den som ringer garanterar att `offset` inte överstiger `self.len()`,
                    // så den här nya pekaren är inne i `self` och därmed garanterad att den inte är null.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Hjälpfunktion för att flytta iteratorns ände bakåt med `offset`-element, vilket ger den nya änden tillbaka.
            //
            // Osäkert eftersom förskjutningen inte får överstiga `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // SÄKERHET: den som ringer garanterar att `offset` inte överstiger `self.len()`,
                    // vilket garanterat inte överflödar en `isize`.
                    // Den resulterande pekaren ligger också inom gränserna för `slice`, vilket uppfyller de andra kraven för `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // kan implementeras med skivor, men detta undviker gränskontroller

                // SÄKERHET: `assume`-samtal är säkra eftersom en skivas startpekare
                // måste vara icke-noll och skivor över icke-ZST måste också ha en icke-noll slutpekare.
                // Samtalet till `next_unchecked!` är säkert eftersom vi först kontrollerar om iteratorn är tom.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Denna iterator är nu tom.
                    if mem::size_of::<T>() == 0 {
                        // Vi måste göra det på det här sättet eftersom `ptr` kanske aldrig är 0, men `end` kan vara (på grund av inslagning).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // SÄKERHET: slutet kan inte vara 0 om T inte är ZST eftersom ptr inte är 0 och slut>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // SÄKERHET: Vi är inom gränser.`post_inc_start` gör det rätta även för ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Vi åsidosätter standardimplementeringen, som använder `try_fold`, eftersom den här enkla implementeringen genererar mindre LLVM IR och är snabbare att kompilera.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Vi åsidosätter standardimplementeringen, som använder `try_fold`, eftersom den här enkla implementeringen genererar mindre LLVM IR och är snabbare att kompilera.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Vi åsidosätter standardimplementeringen, som använder `try_fold`, eftersom den här enkla implementeringen genererar mindre LLVM IR och är snabbare att kompilera.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Vi åsidosätter standardimplementeringen, som använder `try_fold`, eftersom den här enkla implementeringen genererar mindre LLVM IR och är snabbare att kompilera.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Vi åsidosätter standardimplementeringen, som använder `try_fold`, eftersom den här enkla implementeringen genererar mindre LLVM IR och är snabbare att kompilera.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Vi åsidosätter standardimplementeringen, som använder `try_fold`, eftersom den här enkla implementeringen genererar mindre LLVM IR och är snabbare att kompilera.
            // `assume` undviker också en gränscheck.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // SÄKERHET: vi är garanterat i gränser av loop-invarianten:
                        // när `i >= n` returnerar `self.next()` `None` och slingan bryts.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Vi åsidosätter standardimplementeringen, som använder `try_fold`, eftersom den här enkla implementeringen genererar mindre LLVM IR och är snabbare att kompilera.
            // `assume` undviker också en gränscheck.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // SÄKERHET: `i` måste vara lägre än `n` eftersom den börjar vid `n`
                        // och bara minskar.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // SÄKERHET: den som ringer måste garantera att `i` ligger inom gränserna för
                // den underliggande skivan, så `i` kan inte översvämma en `isize`, och de returnerade referenserna garanterar att de hänvisar till ett element i skivan och därmed garanteras att de är giltiga.
                //
                // Observera också att den som ringer garanterar att vi aldrig blir uppringda med samma index igen, och att inga andra metoder som kommer åt den här underskivan anropas, så det är giltigt att den returnerade referensen kan vara mutbar i fallet med
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // kan implementeras med skivor, men detta undviker gränskontroller

                // SÄKERHET: `assume`-samtal är säkra eftersom en skivas startpekare måste vara icke-null,
                // och skivor över icke-ZST måste också ha en icke-null slutpekare.
                // Samtalet till `next_back_unchecked!` är säkert eftersom vi kontrollerar om iteratorn är tom först.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Denna iterator är nu tom.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // SÄKERHET: Vi är inom gränser.`pre_dec_end` gör det rätta även för ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}