// Originalimplementering hämtad från rust-memchr.
// Copyright 2015 Andrew Gallant, bluss och Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Använd trunkering.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Returnerar `true` om `x` innehåller någon nollbyte.
///
/// Från *Matters Computational*, J. Arndt:
///
/// "Tanken är att subtrahera en från vart och ett av byten och sedan leta efter byte där lånet sprids hela vägen till det mest betydelsefulla
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Returnerar det första indexet som matchar byten `x` i `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Snabb väg för små skivor
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Sök efter ett enda bytevärde genom att läsa två `usize`-ord åt gången.
    //
    // Dela `text` i tre delar
    // - ofördelad initial del, före den första ordjusterade adressen i texten
    // - kropp, skanna med två ord åt gången
    // - den sista återstående delen, <2 ordstorlek

    // sök upp till en inriktad gräns
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // söka i texten
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // SÄKERHET: tidens predikat garanterar ett avstånd på minst 2 * usize_bytes
        // mellan offset och slutet av skivan.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // bryt om det finns en matchande byte
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Hitta byten efter den punkt där kroppsslingan slutade.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Returnerar det sista indexet som matchar byten `x` i `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Sök efter ett enda bytevärde genom att läsa två `usize`-ord åt gången.
    //
    // Dela `text` i tre delar:
    // - ojusterad svans, efter den sista ordinriktade adressen i texten,
    // - kropp, skannad med två ord åt gången,
    // - de första återstående byten, <2 ordstorlek.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Vi kallar detta bara för att få längden på prefixet och suffixet.
        // I mitten bearbetar vi alltid två bitar samtidigt.
        // SÄKERHET: att överföra `[u8]` till `[usize]` är säkert förutom storleksskillnader som hanteras av `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Sök i textens kropp, se till att vi inte korsar min_justerad_offset.
    // offset är alltid inriktad, så det är tillräckligt att bara testa `>` och undviker eventuellt överflöde.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // SÄKERHET: offset börjar vid len, suffix.len(), så länge det är större än
        // min_aligned_offset (prefix.len()) det återstående avståndet är minst 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Bryt om det finns en matchande byte.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Hitta byten före den punkt där kroppsslingan slutade.
    text[..offset].iter().rposition(|elt| *elt == x)
}