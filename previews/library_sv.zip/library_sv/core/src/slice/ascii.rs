//! Verksamhet på ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Kontrollerar om alla byte i denna del ligger inom ASCII-intervallet.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Kontrollerar att två skivor är en ASCII-skiftlägeskänslig matchning.
    ///
    /// Samma som `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, men utan att allokera och kopiera temporärer.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Konverterar denna del till dess ASCII-versaler motsvarande på plats.
    ///
    /// ASCII-bokstäver 'a' till 'z' mappas till 'A' till 'Z', men icke-ASCII-bokstäver är oförändrade.
    ///
    /// Använd [`to_ascii_uppercase`] för att returnera ett nytt uppskattat värde utan att ändra det befintliga.
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Konverterar denna bit till dess ASCII-gemener motsvarande på plats.
    ///
    /// ASCII-bokstäver 'A' till 'Z' mappas till 'a' till 'z', men icke-ASCII-bokstäver är oförändrade.
    ///
    /// Använd [`to_ascii_lowercase`] för att returnera ett nytt lägre värde utan att ändra det befintliga.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Returnerar `true` om någon byte i ordet `v` är nonascii (>=128).
/// Snarfed från `../str/mod.rs`, vilket gör något liknande för utf8-validering.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Optimerat ASCII-test som använder usize-at-a-time-operationer istället för byte-at-a-time-operationer (när det är möjligt).
///
/// Algoritmen vi använder här är ganska enkel.Om `s` är för kort kontrollerar vi bara varje byte och är färdiga med den.Annat:
///
/// - Läs det första ordet med en obalanserad belastning.
/// - Rikta in pekaren, läs efterföljande ord till slutet med inriktade belastningar.
/// - Läs den sista `usize` från `s` med en ojusterad belastning.
///
/// Om någon av dessa belastningar producerar något för vilket `contains_nonascii` (above) returnerar sant, vet vi att svaret är falskt.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Om vi inte skulle få någonting från ord-på-en-gång-implementeringen, fall tillbaka till en skalär slinga.
    //
    // Vi gör det också för arkitekturer där `size_of::<usize>()` inte är tillräcklig anpassning för `usize`, för det är ett konstigt edge-fall.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Vi läser alltid det första ordet ojusterat, vilket betyder att `align_offset` är det
    // 0, vi skulle läsa samma värde igen för den justerade läsningen.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // SÄKERHET: Vi verifierar `len < USIZE_SIZE` ovan.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Vi kollade detta ovan, något implicit.
    // Observera att `offset_to_aligned` är antingen `align_offset` eller `USIZE_SIZE`, båda är uttryckligen markerade ovan.
    //
    debug_assert!(offset_to_aligned <= len);

    // SÄKERHET: word_ptr är den (korrekt inriktade) användningsstorlek som vi använder för att läsa
    // mitten bit av skivan.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` är byteindex för `word_ptr`, som används för loop-end-kontroller.
    let mut byte_pos = offset_to_aligned;

    // Paranoia kontrollerar om inriktning, eftersom vi håller på att göra en massa ojusterade laster.
    // I praktiken bör det dock vara omöjligt att spärra ett fel i `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Läs efterföljande ord tills det sist inriktade ordet, med undantag av det sist inriktade ordet i sig själv som ska göras i svanskontroll senare, för att säkerställa att svansen alltid är högst en `usize` för att extra branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Sanity kontrollera att läsningen är inom gränser
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Och att våra antaganden om `byte_pos` håller.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // SÄKERHET: Vi vet att `word_ptr` är korrekt inriktad (på grund av
        // 'align_offset'), och vi vet att vi har tillräckligt med byte mellan `word_ptr` och slutet
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SÄKERHET: Vi vet att `byte_pos <= len - USIZE_SIZE`, vilket betyder det
        // efter den här `add` kommer `word_ptr` att vara högst en-the-end.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Förnuftskontroll för att säkerställa att det bara finns en `usize` kvar.
    // Detta bör garanteras av vårt slingförhållande.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SÄKERHET: Detta är beroende av `len >= USIZE_SIZE`, som vi kontrollerar i början.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}