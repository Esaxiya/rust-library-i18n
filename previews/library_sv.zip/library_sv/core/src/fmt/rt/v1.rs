//! Detta är en intern modul som används av ifmt!körning.Dessa strukturer emitteras till statiska matriser för att förkompilera formatsträngar i förväg.
//!
//! Dessa definitioner liknar deras `ct`-ekvivalenter, men skiljer sig åt genom att dessa kan fördelas statiskt och är något optimerade för körning
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Möjliga justeringar som kan begäras som en del av ett formateringsdirektiv.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Indikation om att innehållet ska vara vänsterjusterat.
    Left,
    /// Indikation om att innehållet ska vara högerjusterat.
    Right,
    /// Indikation om att innehållet ska centreras.
    Center,
    /// Ingen anpassning begärdes.
    Unknown,
}

/// Används av [width](https://doc.rust-lang.org/std/fmt/#width)-och [precision](https://doc.rust-lang.org/std/fmt/#precision)-specifikationer.
#[derive(Copy, Clone)]
pub enum Count {
    /// Angivet med ett bokstavsnummer, lagrar värdet
    Is(usize),
    /// Specificeras med `$` och `*` syntaxer, lagrar indexet i `args`
    Param(usize),
    /// Ej angivet
    Implied,
}