//! Typer som fäster data till dess plats i minnet.
//!
//! Ibland är det bra att ha objekt som garanterat inte rör sig, i den meningen att deras placering i minnet inte förändras och därmed kan lita på.
//! Ett utmärkt exempel på ett sådant scenario skulle vara att bygga självreferenser, eftersom att flytta ett objekt med pekare till sig själv kommer att ogiltigförklara dem, vilket kan orsaka odefinierat beteende.
//!
//! På en hög nivå säkerställer en [`Pin<P>`] att pekaren av vilken pekartyp som helst `P` har en stabil plats i minnet, vilket innebär att den inte kan flyttas någon annanstans och dess minne inte kan fördelas förrän den tappas.Vi säger att pointee är "pinned".Saker blir mer subtila när man diskuterar typer som kombineras fästa med icke-fästa data;[see below](#projections-and-structural-pinning) för mer information.
//!
//! Som standard är alla typer i Rust rörliga.
//! Rust gör det möjligt att skicka alla typer av värde, och vanliga smartpekartyper som [`Box<T>`] och `&mut T` gör det möjligt att ersätta och flytta de värden de innehåller: du kan flytta ut ur en [`Box<T>`], eller så kan du använda [`mem::swap`].
//! [`Pin<P>`] slår in en pekare typ `P`, så [`Pin`]`<`[`Box`] `<T>>`fungerar ungefär som en vanlig
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Box ']`<T>> `` tappas, så gör dess innehåll, och minnet blir
//!
//! omplacerad.På samma sätt är [`Pin`]`<&mut T>`mycket som `&mut T`.[`Pin<P>`] tillåter dock inte att klienter faktiskt får en [`Box<T>`] eller `&mut T` till fästa data, vilket innebär att du inte kan använda operationer som [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` behöver `&mut T`, men vi kan inte få det.
//!     // Vi har fastnat, vi kan inte byta innehållet i dessa referenser.
//!     // Vi kan använda `Pin::get_unchecked_mut`, men det är osäkert av en anledning:
//!     // vi får inte använda den för att flytta saker ur `Pin`.
//! }
//! ```
//!
//! Det är värt att upprepa att [`Pin<P>`]*inte* förändrar det faktum att en Rust-kompilator anser att alla typer är rörliga.[`mem::swap`] kan fortfarande anropas för alla `T`.Istället förhindrar [`Pin<P>`] att vissa *värden*(pekade på pekare inslagna i [`Pin<P>`]) flyttas genom att göra det omöjligt att anropa metoder som kräver `&mut T` på dem (som [`mem::swap`]).
//!
//! [`Pin<P>`] kan användas för att slå in vilken pekartyp som helst `P`, och som sådan interagerar den med [`Deref`] och [`DerefMut`].En [`Pin<P>`] där `P: Deref` bör betraktas som en "`P`-style pointer" till en fäst `P::Target`-så, en [`Pin`]`<`[`Box`] `<T>>`är en ägd pekare till en fäst `T` och en [`Pin`] `<` [`Rc`]`<T>>`är en referensräknad pekare till en fäst `T`.
//! För att vara korrekt, förlitar sig [`Pin<P>`] på implementeringarna av [`Deref`] och [`DerefMut`] för att inte flytta ur sin `self`-parameter och bara återställa en pekare till fästa data när de kallas på en fäst pekare.
//!
//! # `Unpin`
//!
//! Många typer är alltid fritt rörliga, även när de är fästa, eftersom de inte litar på att ha en stabil adress.Detta inkluderar alla bastyper (som [`bool`], [`i32`] och referenser) samt typer som enbart består av dessa typer.Typer som inte bryr sig om att fästa implementerar [`Unpin`] auto-trait, vilket avbryter effekten av [`Pin<P>`].
//! För `T: Unpin`, [`Pin`]`<`[`Box`] `<T>>`och [`Box<T>`] fungerar identiskt, liksom [`Pin`] `<&mut T>` och `&mut T`.
//!
//! Observera att fästning och [`Unpin`] bara påverkar den pekade typen `P::Target`, inte pekartypen `P` själv som blev insvept i [`Pin<P>`].Till exempel, huruvida [`Box<T>`] är [`Unpin`] eller inte har ingen inverkan på beteendet hos [`Pin`]`<`[`Box`] `<T>>`(här är `T` den pekade typen).
//!
//! # Exempel: självreferens struktur
//!
//! Innan vi går in i mer detaljer för att förklara garantier och val kopplade till `Pin<T>`, diskuterar vi några exempel på hur den kan användas.
//! Känn dig fri att [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Detta är en självreferensstruktur eftersom segmentfältet pekar på datafältet.
//! // Vi kan inte informera kompilatorn om det med en normal referens, eftersom detta mönster inte kan beskrivas med de vanliga lånereglerna.
//! //
//! // Istället använder vi en rå pekare, men en som är känd för att inte vara noll, eftersom vi vet att den pekar på strängen.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // För att säkerställa att data inte rör sig när funktionen återvänder placerar vi den i högen där den kommer att stanna under objektets livstid, och det enda sättet att komma åt den skulle vara genom en pekare till den.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // vi skapar bara pekaren när data är på plats, annars har de redan flyttat innan vi ens började
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // vi vet att detta är säkert eftersom ändring av ett fält inte rör hela strukturen
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Pekaren ska peka på rätt plats så länge strukturen inte har flyttat.
//! //
//! // Under tiden är vi fria att flytta pekaren.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Eftersom vår typ inte implementerar Unpin kommer det inte att kompileras:
//! // låt mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Exempel: påträngande dubbelt länkad lista
//!
//! I en påträngande dubbellänkad lista tilldelar inte samlingen faktiskt minnet för själva elementen.
//! Tilldelningen kontrolleras av klienterna och element kan leva på en stackram som lever kortare än samlingen gör.
//!
//! För att detta ska fungera har varje element pekare till sin föregångare och efterträdare i listan.Element kan bara läggas till när de är fästa, eftersom att flytta elementen skulle göra pekarna ogiltiga.Dessutom kommer [`Drop`]-implementeringen av ett länkat listelement att korrigera pekarna för sin föregångare och efterträdare för att ta bort sig själv från listan.
//!
//! Avgörande är att vi måste kunna lita på att [`drop`] kallas.Om ett element kunde omplaceras eller på annat sätt ogiltigförklaras utan att anropa [`drop`], skulle pekarna i det från dess närliggande element bli ogiltiga, vilket skulle bryta datastrukturen.
//!
//! Därför kommer pinning också med en [`drop`]-relaterad garanti.
//!
//! # `Drop` guarantee
//!
//! Syftet med pinning är att kunna förlita sig på placeringen av vissa data i minnet.
//! För att detta ska fungera är inte bara flyttning av data begränsad;att omplacera, återanvända eller på annat sätt ogiltigförklara minnet som används för att lagra data är också begränsat.
//! Konkret, för fästa data måste du behålla invarianten att *dess minne inte blir ogiltigt eller återuppbyggt från det ögonblick det fästs tills [`drop`] kallas*.Först när [`drop`] återvänder eller panics kan minnet återanvändas.
//!
//! Minne kan vara "invalidated" genom deallocation, men också genom att ersätta en [`Some(v)`] med [`None`], eller ringa [`Vec::set_len`] till "kill" några element från en vector.Det kan återanvändas genom att använda [`ptr::write`] för att skriva över det utan att ringa förstöraren först.Inget av detta är tillåtet för fästa data utan att ringa [`drop`].
//!
//! Detta är exakt den typ av garanti som den påträngande länkade listan från föregående avsnitt behöver fungera korrekt.
//!
//! Observera att denna garanti *inte* betyder att minnet inte läcker!Det är fortfarande helt okej att aldrig ringa [`drop`] på ett fäst element (t.ex., du kan fortfarande ringa [`mem::forget`] på en [`Pin`]`<`[`Box`] `<T>>`).I exemplet med den dubbelt länkade listan skulle det elementet bara stanna i listan.Du får dock inte frigöra eller återanvända lagringen *utan att ringa [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Om din typ använder pinning (till exempel de två exemplen ovan) måste du vara försiktig när du implementerar [`Drop`].[`drop`]-funktionen tar `&mut self`, men detta kallas *även om din typ tidigare var fäst*!Det är som om kompilatorn automatiskt kallas [`Pin::get_unchecked_mut`].
//!
//! Detta kan aldrig orsaka problem i säker kod eftersom implementering av en typ som är beroende av fästning kräver osäker kod, men tänk på att besluta att använda fästning i din typ (till exempel genom att genomföra någon åtgärd på [`Pin`]`<&Själv>`eller [`Pin`] `<&mut Self>`) har också konsekvenser för din [`Drop`]-implementering: om ett element av din typ kunde ha fästs måste du behandla [`Drop`] som implicit att ta [`Pin`]`<&mut Själv>`.
//!
//!
//! Du kan till exempel implementera `Drop` enligt följande:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` är okej eftersom vi vet att detta värde aldrig används igen efter att ha tappats.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Faktisk släppkod går här.
//!         }
//!     }
//! }
//! ```
//!
//! Funktionen `inner_drop` har den typ som [`drop`]*borde* ha, så det ser till att du inte av misstag använder `self`/`this` på ett sätt som är i konflikt med fästning.
//!
//! Dessutom, om din typ är `#[repr(packed)]`, flyttar kompilatorn automatiskt fält för att kunna släppa dem.Det kan till och med göra det för fält som råkar vara tillräckligt inriktade.Som en konsekvens kan du inte använda fästning med en `#[repr(packed)]`-typ.
//!
//! # Prognoser och strukturfästning
//!
//! När man arbetar med fästa strängar uppstår frågan hur man kan komma åt fälten i den strukturen i en metod som bara tar [`Pin`]`<&mut Struct>`.
//! Det vanliga tillvägagångssättet är att skriva hjälpmetoder (så kallade *projektioner*) som förvandlar [`Pin`]`<&mut Struct>`till en referens till fältet, men vilken typ ska referensen ha?Är det [`Pin`]`<&mut Field>`eller `&mut Field`?
//! Samma fråga uppstår med fälten i en `enum`, och även när man överväger container/wrapper-typer som [`Vec<T>`], [`Box<T>`] eller [`RefCell<T>`].
//! (Den här frågan gäller för både muterbara och delade referenser, vi använder bara det vanligaste fallet med muterbara referenser här för illustration.)
//!
//! Det visar sig att det faktiskt är upphovsmannen till datastrukturen att avgöra om den fästa projektionen för ett visst fält förvandlar [`Pin`]`<&mut Struct>`till [`Pin`] `<&mut Field>` eller `&mut Field`.Det finns dock vissa begränsningar, och den viktigaste begränsningen är *konsistens*:
//! varje fält kan *antingen* projiceras till en fäst referens,*eller* har tagits bort som en del av projektionen.
//! Om båda görs för samma fält kommer det sannolikt att vara otrevligt!
//!
//! Som författare till en datastruktur får du bestämma för varje fält om du fäster "propagates" i det här fältet eller inte.
//! Pinning som förökas kallas också "structural", eftersom det följer typens struktur.
//! I följande underavsnitt beskriver vi de överväganden som måste göras för båda valen.
//!
//! ## Att fästa *är inte* strukturellt för `field`
//!
//! Det kan verka kontraintuitivt att fältet i en fäst struktur kanske inte är fäst, men det är faktiskt det enklaste valet: om ett [`Pin`]`<&mut Field>`aldrig skapas kan ingenting gå fel!Så om du bestämmer dig för att något fält inte har strukturell fästning, är allt du behöver se till att du aldrig skapar en fäst referens till det fältet.
//!
//! Fält utan strukturfästning kan ha en projektionsmetod som förvandlar [`Pin`]`<&mut Struct>`till `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Detta är okej eftersom `field` aldrig anses vara fäst.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Du kan också `impl Unpin for Struct`*även om* typen av `field` inte är [`Unpin`].Vad den typen tycker om att fästa är inte relevant när inget [`Pin`]`<&mut Field>`någonsin skapas.
//!
//! ## Pinning *är* strukturell för `field`
//!
//! Det andra alternativet är att bestämma att fästning är "structural" för `field`, vilket innebär att om strukturen är fäst så är fältet det också.
//!
//! Detta gör det möjligt att skriva en projektion som skapar ett [`Pin`]`<&mut-fält>`, och därmed bevittna att fältet är fäst:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Detta är okej eftersom `field` är fäst när `self` är.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Strukturell fästning kommer dock med några extra krav:
//!
//! 1. Strukturen får endast vara [`Unpin`] om alla strukturfält är [`Unpin`].Det här är standard, men [`Unpin`] är en säker trait, så som författare till strukturen är det ditt ansvar *inte* att lägga till något som `impl<T> Unpin for Struct<T>`.
//! (Observera att det krävs en osäker kod för att lägga till en projiceringsoperation, så det faktum att [`Unpin`] är en säker trait bryter inte mot principen att du bara behöver oroa dig för något av detta om du använder `osäker`.)
//! 2. Förstöraren av strukturen får inte flytta strukturella fält ur sitt argument.Detta är den exakta punkten som togs upp i [previous section][drop-impl]: `drop` tar `&mut self`, men strukturen (och därmed dess fält) kan ha fästs tidigare.
//!     Du måste garantera att du inte flyttar ett fält inuti din [`Drop`]-implementering.
//!     I synnerhet, som förklarats tidigare, betyder detta att din struktur får *inte* vara `#[repr(packed)]`.
//!     Se det avsnittet för hur du skriver [`drop`] på ett sätt så att kompilatorn kan hjälpa dig att inte av misstag bryta fästet.
//! 3. Du måste se till att du upprätthåller [`Drop` guarantee][drop-guarantee]:
//!     när din struktur har fästs skrivs inte minnet som innehåller innehållet över eller omplaceras utan att anropa innehållets förstörare.
//!     Detta kan vara knepigt, som bevittnat av [`VecDeque<T>`]: förstöraren av [`VecDeque<T>`] kan misslyckas med att anropa [`drop`] på alla element om en av förstörarna panics.Detta bryter mot [`Drop`]-garantin, eftersom det kan leda till att element omplaceras utan att deras destruktör anropas.([`VecDeque<T>`] har inga fästprojektioner, så detta orsakar inte ojämnhet.)
//! 4. Du får inte erbjuda några andra operationer som kan leda till att data flyttas ut ur strukturfälten när din typ är fäst.Till exempel, om strukturen innehåller en [`Option<T>`] och det finns en "take"-lik operation med typ `fn(Pin<&mut Struct<T>>) -> Option<T>`, kan den operationen användas för att flytta en `T` från en fäst `Struct<T>`-vilket innebär att fästning inte kan vara strukturell för det fält som håller detta data.
//!
//!     För ett mer komplext exempel på att flytta data ur en fäst typ, tänk dig om [`RefCell<T>`] hade en metod `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Då kunde vi göra följande:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Detta är katastrofalt, det betyder att vi först kan fästa innehållet i [`RefCell<T>`] (med hjälp av `RefCell::get_pin_mut`) och sedan flytta det innehållet med hjälp av den muterbara referens vi fick senare.
//!
//! ## Examples
//!
//! För en typ som [`Vec<T>`] är båda möjligheterna (strukturell pinning eller inte) vettiga.
//! En [`Vec<T>`] med strukturell pinning kan ha `get_pin`/`get_pin_mut`-metoder för att få fästa referenser till element.Det kunde dock *inte* tillåta att [`pop`][Vec::pop] anropas på en fäst [`Vec<T>`] eftersom det skulle flytta innehållet (strukturellt fäst)!Det kunde inte heller tillåta [`push`][Vec::push], som kan omfördelas och därmed också flytta innehållet.
//!
//! En [`Vec<T>`] utan strukturfästning kan `impl<T> Unpin for Vec<T>`, eftersom innehållet aldrig fästs och [`Vec<T>`] i sig är bra att flyttas också.
//! Vid den tidpunkten har pinning bara ingen effekt på vector alls.
//!
//! I standardbiblioteket har pekartyper i allmänhet inte strukturell fästning och därför erbjuder de inte fästprojektioner.Det är därför `Box<T>: Unpin` gäller för alla `T`.
//! Det är vettigt att göra detta för pekartyper, för att flytta `Box<T>` faktiskt inte flyttar `T`: [`Box<T>`] kan vara fritt rörlig (aka `Unpin`) även om `T` inte är det.I själva verket till och med [`Pin`]`<`[`Box`] `<T>>`och [`Pin`] `<&mut T>` är alltid [`Unpin`] själva, av samma anledning: deras innehåll (`T`) är fästa, men själva pekarna kan flyttas utan att de fästa data flyttas.
//! För både [`Box<T>`] och [`Pin`]`<`[`Box ']`<T>> `, om innehållet är fästt är helt oberoende av om pekaren är fäst, vilket betyder att fästning är *inte* strukturell.
//!
//! När du implementerar en [`Future`]-kombinator behöver du vanligtvis strukturfästning för de kapslade futures, eftersom du behöver få fästa referenser till dem för att ringa [`poll`].
//! Men om din kombinator innehåller andra data som inte behöver fästas, kan du göra dessa fält inte strukturella och därmed fritt komma åt dem med en muterbar referens även när du bara har [`Pin`]`<&mut Self>`(sådan som i din egen [`poll`]-implementering).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// En fäst pekare.
///
/// Detta är ett omslag kring en slags pekare som gör att pekaren "pin" är på plats, vilket förhindrar att värdet som den pekaren hänvisar till flyttas om den inte implementerar [`Unpin`].
///
///
/// *Se [`pin` module]-dokumentationen för en förklaring av fästning.*
///
/// [`pin` module]: self
///
// Note: `Clone`-härledningen nedan orsakar ohälsa eftersom det är möjligt att implementera
// `Clone` för föränderliga referenser.
// Se <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> för mer information.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Följande implementeringar härleds inte för att undvika sundhetsproblem.
// `&self.pointer` bör inte vara tillgänglig för opålitliga trait-implementeringar.
//
// Se <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> för mer information.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Konstruera en ny `Pin<P>` runt en pekare till vissa data av en typ som implementerar [`Unpin`].
    ///
    /// Till skillnad från `Pin::new_unchecked` är den här metoden säker eftersom pekaren `P` hänvisar till en [`Unpin`]-typ, vilket upphäver fästgarantierna.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SÄKERHET: värdet som pekas på är `Unpin` och har därför inga krav
        // runt fästning.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Packar upp den här `Pin<P>` som returnerar den underliggande pekaren.
    ///
    /// Detta kräver att data inuti denna `Pin` är [`Unpin`] så att vi kan ignorera de fästa invarianterna när vi packar upp den.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Konstruera en ny `Pin<P>` kring en referens till vissa data av en typ som kanske implementerar `Unpin` eller inte.
    ///
    /// Om `pointer` hänvisar till en `Unpin`-typ, bör `Pin::new` användas istället.
    ///
    /// # Safety
    ///
    /// Den här konstruktören är osäker eftersom vi inte kan garantera att de data som `pointer` pekar på är fästa, vilket innebär att data inte kommer att flyttas eller att lagringen blir ogiltig förrän den tappas.
    /// Om den konstruerade `Pin<P>` inte garanterar att data `P` pekar på är fästa, är det ett brott mot API-kontraktet och kan leda till odefinierat beteende i senare (safe)-operationer.
    ///
    /// Genom att använda den här metoden gör du en promise om `P::Deref`-och `P::DerefMut`-implementeringarna, om de finns.
    /// Viktigast av allt, de får inte flytta ur sina `self`-argument: `Pin::as_mut` och `Pin::as_ref` kommer att ringa `DerefMut::deref_mut` och `Deref::deref`*på den fästa pekaren* och förväntar sig att dessa metoder upprätthåller de fästande invarianterna.
    /// Dessutom, genom att anropa den här metoden, promise att referensen `P`-referenser till inte kommer att flyttas ut ur igen;i synnerhet måste det inte vara möjligt att få en `&mut P::Target` och sedan flytta ut från referensen (med exempelvis [`mem::swap`]).
    ///
    ///
    /// Exempelvis är det inte säkert att ringa `Pin::new_unchecked` på en `&'a mut T`, för medan du kan fästa den under den givna livstiden `'a` har du ingen kontroll över om den hålls fäst när `'a` slutar:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Detta borde betyda att pointee `a` aldrig kan röra sig igen.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Adressen till `a` ändrades till `b`s stackplats, så `a` blev flyttad trots att vi tidigare har fäst den!Vi har brutit mot det fasta API-avtalet.
    /////
    /// }
    /// ```
    ///
    /// Ett värde, när det är fäst, måste förbli fästat för alltid (om inte dess typ implementerar `Unpin`).
    ///
    /// På samma sätt är det inte säkert att ringa `Pin::new_unchecked` på en `Rc<T>` eftersom det kan finnas alias för samma data som inte omfattas av fästbegränsningarna:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Detta borde betyda att pointee aldrig kan flytta igen.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Nu, om `x` var den enda referensen, har vi en muterbar referens till data som vi fäst ovan, som vi kunde använda för att flytta den som vi har sett i föregående exempel.
    ///     // Vi har brutit mot det fasta API-avtalet.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Får en fäst delad referens från den här fästa pekaren.
    ///
    /// Detta är en generisk metod för att gå från `&Pin<Pointer<T>>` till `Pin<&T>`.
    /// Det är säkert eftersom pointeraren inte kan röra sig som en del av `Pin::new_unchecked`-kontraktet efter att `Pin<Pointer<T>>` skapats.
    ///
    /// "Malicious" implementeringar av `Pointer::Deref` utesluts också av `Pin::new_unchecked`-avtalet.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SÄKERHET: se dokumentation om denna funktion
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Packar upp den här `Pin<P>` som returnerar den underliggande pekaren.
    ///
    /// # Safety
    ///
    /// Denna funktion är osäker.Du måste garantera att du kommer att fortsätta att behandla pekaren `P` som fästs efter att du har anropat den här funktionen, så att invarianter på `Pin`-typen kan upprätthållas.
    /// Om koden som använder den resulterande `P` inte fortsätter att upprätthålla de fasta invarianterna som bryter mot API-avtalet och kan leda till odefinierat beteende i senare (safe)-operationer.
    ///
    ///
    /// Om underliggande data är [`Unpin`], bör [`Pin::into_inner`] användas istället.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Får en fäst mutabel referens från den fästa pekaren.
    ///
    /// Detta är en generisk metod för att gå från `&mut Pin<Pointer<T>>` till `Pin<&mut T>`.
    /// Det är säkert eftersom pointeraren inte kan röra sig som en del av `Pin::new_unchecked`-kontraktet efter att `Pin<Pointer<T>>` skapats.
    ///
    /// "Malicious" implementeringar av `Pointer::DerefMut` utesluts också av `Pin::new_unchecked`-avtalet.
    ///
    /// Den här metoden är användbar när du gör flera samtal till funktioner som förbrukar den fästa typen.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // göra någonting
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` förbrukar `self`, så återlåna `Pin<&mut Self>` via `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SÄKERHET: se dokumentation om denna funktion
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Tilldelar ett nytt värde till minnet bakom den fästa referensen.
    ///
    /// Detta skriver över fästa data, men det är okej: dess förstörare körs innan den skrivs över, så ingen fästgaranti bryts.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Konstruerar en ny stift genom att kartlägga det inre värdet.
    ///
    /// Om du till exempel vill få en `Pin` av ett fält med något kan du använda det här för att få tillgång till det fältet i en kodrad.
    /// Det finns dock flera gotchas med dessa "pinning projections";
    /// se [`pin` module]-dokumentationen för mer information om det ämnet.
    ///
    /// # Safety
    ///
    /// Denna funktion är osäker.
    /// Du måste garantera att de data du returnerar inte rör sig så länge argumentvärdet inte rör sig (till exempel för att det är ett av fälten i det värdet), och också att du inte flyttar från argumentet du får till inredningsfunktionen.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SÄKERHET: säkerhetskontraktet för `new_unchecked` måste vara
        // upprätthålls av den som ringer.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Får en delad referens ur en nål.
    ///
    /// Detta är säkert eftersom det inte går att flytta ut från en delad referens.
    /// Det kan verka som om det finns ett problem här med inre mutabilitet: det är faktiskt * möjligt att flytta en `T` ur en `&RefCell<T>`.
    /// Detta är dock inte ett problem så länge det inte finns en `Pin<&T>` som pekar på samma data, och `RefCell<T>` låter dig inte skapa en fäst referens till dess innehåll.
    ///
    /// Se diskussionen om ["pinning projections"] för mer information.
    ///
    /// Note: `Pin` implementerar också `Deref` till målet, som kan användas för att komma åt det inre värdet.
    /// `Deref` ger emellertid bara en referens som lever så länge som lånet av `Pin`, inte livslängden för själva `Pin`.
    /// Denna metod gör det möjligt att förvandla `Pin` till en referens med samma livstid som original `Pin`.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Konverterar denna `Pin<&mut T>` till en `Pin<&T>` med samma livstid.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Får en förändrad referens till data inuti denna `Pin`.
    ///
    /// Detta kräver att data i denna `Pin` är `Unpin`.
    ///
    /// Note: `Pin` implementerar också `DerefMut` till data, som kan användas för att komma åt det inre värdet.
    /// `DerefMut` ger dock bara en referens som lever så länge som lånet av `Pin`, inte livslängden för själva `Pin`.
    ///
    /// Denna metod gör det möjligt att förvandla `Pin` till en referens med samma livstid som original `Pin`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Får en förändrad referens till data inuti denna `Pin`.
    ///
    /// # Safety
    ///
    /// Denna funktion är osäker.
    /// Du måste garantera att du aldrig kommer att flytta data från den muterbara referens du får när du ringer till den här funktionen, så att invarianterna på `Pin`-typen kan upprätthållas.
    ///
    ///
    /// Om underliggande data är `Unpin`, bör `Pin::get_mut` användas istället.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Konstruera en ny stift genom att kartlägga det inre värdet.
    ///
    /// Om du till exempel vill få en `Pin` av ett fält med något kan du använda det här för att få tillgång till det fältet i en kodrad.
    /// Det finns dock flera gotchas med dessa "pinning projections";
    /// se [`pin` module]-dokumentationen för mer information om det ämnet.
    ///
    /// # Safety
    ///
    /// Denna funktion är osäker.
    /// Du måste garantera att de data du returnerar inte rör sig så länge argumentvärdet inte rör sig (till exempel för att det är ett av fälten i det värdet), och också att du inte flyttar från argumentet du får till inredningsfunktionen.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // SÄKERHET: den som ringer är ansvarig för att inte flytta
        // värde ur denna referens.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SÄKERHET: eftersom värdet på `this` garanterat inte har
        // har flyttats ut är det här samtalet till `new_unchecked` säkert.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Få en fäst referens från en statisk referens.
    ///
    /// Det här är säkert, eftersom `T` lånas för `'static`-livstiden, som aldrig slutar.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // SÄKERHET: Den 'statiska lånet garanterar att uppgifterna inte kommer att vara det
        // moved/invalidated tills det tappas (vilket aldrig är).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Få en fäst mutabel referens från en statisk mutbar referens.
    ///
    /// Det här är säkert, eftersom `T` lånas för `'static`-livstiden, som aldrig slutar.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // SÄKERHET: Den 'statiska lånet garanterar att uppgifterna inte kommer att vara det
        // moved/invalidated tills det tappas (vilket aldrig är).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: detta innebär att alla impl av `CoerceUnsized` som tillåter tvång från
// en typ som implementerar `Deref<Target=impl !Unpin>` till en typ som impliserar `Deref<Target=Unpin>` är osund.
// Alla sådana impl. Skulle troligen vara osunda av andra skäl, så vi måste bara vara försiktiga så att inte sådana impl. Landar i std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}