#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// En `RawWaker` tillåter implementatören av en uppgiftsutförare att skapa en [`Waker`] som ger anpassat väckningsbeteende.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Den består av en datapekare och en [virtual function pointer table (vtable)][vtable] som anpassar beteendet hos `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// En datapekare som kan användas för att lagra godtyckliga data enligt exekutörens krav.
    /// Detta kan t.ex.
    /// en typraderad pekare till en `Arc` som är associerad med uppgiften.
    /// Värdet för detta fält skickas till alla funktioner som ingår i vtabellen som den första parametern.
    ///
    data: *const (),
    /// Pekertabell för virtuell funktion som anpassar beteendet hos denna waker.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Skapar en ny `RawWaker` från den medföljande `data`-pekaren och `vtable`.
    ///
    /// `data`-pekaren kan användas för att lagra godtyckliga data som krävs av exekutören.Detta kan t.ex.
    /// en typraderad pekare till en `Arc` som är associerad med uppgiften.
    /// Värdet på den här pekaren skickas till alla funktioner som ingår i `vtable` som den första parametern.
    ///
    /// `vtable` anpassar beteendet hos en `Waker` som skapas från en `RawWaker`.
    /// För varje operation på `Waker` kommer den associerade funktionen i `vtable` för den underliggande `RawWaker` att anropas.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// En pekertabell för virtuell funktion (vtable) som anger beteendet hos en [`RawWaker`].
///
/// Pekaren som skickas till alla funktioner inuti vtabellen är `data`-pekaren från det bifogande [`RawWaker`]-objektet.
///
/// Funktionerna i denna struktur är endast avsedda att anropas till `data`-pekaren för ett korrekt konstruerat [`RawWaker`]-objekt inifrån [`RawWaker`]-implementeringen.
/// Att ringa till en av de inneslutna funktionerna med någon annan `data`-pekare orsakar odefinierat beteende.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Denna funktion kommer att anropas när [`RawWaker`] klonas, t.ex. när [`Waker`] där [`RawWaker`] lagras klonas.
    ///
    /// Genomförandet av den här funktionen måste behålla alla resurser som krävs för denna ytterligare instans av en [`RawWaker`] och tillhörande uppgift.
    /// Att ringa till `wake` på den resulterande [`RawWaker`] bör resultera i en väckning av samma uppgift som skulle ha väckts av den ursprungliga [`RawWaker`].
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Denna funktion anropas när `wake` anropas på [`Waker`].
    /// Den måste väcka uppgiften i samband med denna [`RawWaker`].
    ///
    /// Genomförandet av den här funktionen måste se till att frigöra alla resurser som är associerade med den här förekomsten av en [`RawWaker`] och tillhörande uppgift.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Denna funktion anropas när `wake_by_ref` anropas på [`Waker`].
    /// Den måste väcka uppgiften i samband med denna [`RawWaker`].
    ///
    /// Denna funktion liknar `wake`, men får inte använda den angivna datapekaren.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Denna funktion kallas när en [`RawWaker`] tappas.
    ///
    /// Genomförandet av den här funktionen måste se till att frigöra alla resurser som är associerade med den här förekomsten av en [`RawWaker`] och tillhörande uppgift.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Skapar en ny `RawWakerVTable` från de medföljande funktionerna `clone`, `wake`, `wake_by_ref` och `drop`.
    ///
    /// # `clone`
    ///
    /// Denna funktion kommer att anropas när [`RawWaker`] klonas, t.ex. när [`Waker`] där [`RawWaker`] lagras klonas.
    ///
    /// Genomförandet av den här funktionen måste behålla alla resurser som krävs för denna ytterligare instans av en [`RawWaker`] och tillhörande uppgift.
    /// Att ringa till `wake` på den resulterande [`RawWaker`] bör resultera i en väckning av samma uppgift som skulle ha väckts av den ursprungliga [`RawWaker`].
    ///
    /// # `wake`
    ///
    /// Denna funktion anropas när `wake` anropas på [`Waker`].
    /// Den måste väcka uppgiften i samband med denna [`RawWaker`].
    ///
    /// Genomförandet av den här funktionen måste se till att frigöra alla resurser som är associerade med den här förekomsten av en [`RawWaker`] och tillhörande uppgift.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Denna funktion anropas när `wake_by_ref` anropas på [`Waker`].
    /// Den måste väcka uppgiften i samband med denna [`RawWaker`].
    ///
    /// Denna funktion liknar `wake`, men får inte använda den angivna datapekaren.
    ///
    /// # `drop`
    ///
    /// Denna funktion kallas när en [`RawWaker`] tappas.
    ///
    /// Genomförandet av den här funktionen måste se till att frigöra alla resurser som är associerade med den här förekomsten av en [`RawWaker`] och tillhörande uppgift.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// `Context` för en asynkron uppgift.
///
/// För närvarande tjänar `Context` endast för att ge åtkomst till en `&Waker` som kan användas för att väcka den aktuella uppgiften.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Se till att vi är future-säkra mot variansförändringar genom att tvinga livslängden att vara invariant (livslängden för argumentposition är kontravariant medan livslängden för returposition är kovariant).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Skapa en ny `Context` från en `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Returnerar en referens till `Waker` för den aktuella uppgiften.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// En `Waker` är ett handtag för att väcka en uppgift genom att meddela dess exekutor att den är redo att köras.
///
/// Detta handtag inkapslar en [`RawWaker`]-instans, som definierar det exekveringsspecifika väckningsbeteendet.
///
///
/// Implementerar [`Clone`], [`Send`] och [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Vakna upp uppgiften i samband med denna `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Det aktuella väckarklockan delegeras genom ett virtuellt funktionsanrop till implementeringen som definieras av exekutören.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Ring inte `drop`-väckaren kommer att konsumeras av `wake`.
        crate::mem::forget(self);

        // SÄKERHET: Detta är säkert eftersom `Waker::from_raw` är det enda sättet
        // att initialisera `wake` och `data` som kräver att användaren bekräftar att `RawWaker`-avtalet upprätthålls.
        //
        unsafe { (wake)(data) };
    }

    /// Vakna upp uppgiften i samband med denna `Waker` utan att konsumera `Waker`.
    ///
    /// Detta liknar `wake`, men kan vara lite mindre effektivt i fall där en ägd `Waker` är tillgänglig.
    /// Denna metod bör föredras framför `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Det aktuella väckarklockan delegeras genom ett virtuellt funktionsanrop till implementeringen som definieras av exekutören.
        //

        // SÄKERHET: se `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Returnerar `true` om denna `Waker` och en annan `Waker` har väckt samma uppgift.
    ///
    /// Den här funktionen fungerar på bästa möjliga basis och kan returnera falsk även när `Waker`s skulle väcka samma uppgift.
    /// Men om den här funktionen returnerar `true` är det garanterat att Waker kommer att väcka samma uppgift.
    ///
    /// Denna funktion används främst för optimeringsändamål.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Skapar en ny `Waker` från [`RawWaker`].
    ///
    /// Uppförandet av den returnerade `Waker` är odefinierat om kontraktet som definieras i ['RawWaker'] och ['RawWakerVTable'] 's dokumentation inte upprätthålls.
    ///
    /// Därför är denna metod osäker.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // SÄKERHET: Detta är säkert eftersom `Waker::from_raw` är det enda sättet
            // att initialisera `clone` och `data` som kräver att användaren bekräftar att [`RawWaker`]-avtalet upprätthålls.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // SÄKERHET: Detta är säkert eftersom `Waker::from_raw` är det enda sättet
        // att initialisera `drop` och `data` som kräver att användaren bekräftar att `RawWaker`-avtalet upprätthålls.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}