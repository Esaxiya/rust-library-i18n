//! Primitiva traits och typer som representerar typiska grundläggande egenskaper.
//!
//! Rust-typer kan klassificeras på olika användbara sätt beroende på deras inneboende egenskaper.
//! Dessa klassificeringar representeras som traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Typer som kan överföras över trådgränser.
///
/// Denna trait implementeras automatiskt när kompilatorn bestämmer att den är lämplig.
///
/// Ett exempel på en typ som inte är "Skicka" är referensräknarpekaren [`rc::Rc`][`Rc`].
/// Om två trådar försöker klona ['Rc'] som pekar på samma referensräknade värde, kan de försöka uppdatera referensantalet samtidigt, vilket är [undefined behavior][ub] eftersom [`Rc`] inte använder atomoperationer.
///
/// Dess kusin [`sync::Arc`][arc] använder atomoperationer (medför några omkostnader) och är således `Send`.
///
/// Se [the Nomicon](../../nomicon/send-and-sync.html) för mer information.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Typer med en konstant storlek som är känd vid sammanställningstid.
///
/// Alla typsparametrar har en implicit gräns för `Sized`.Den speciella syntaxen `?Sized` kan användas för att ta bort denna bundna om det inte är lämpligt.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//fel: Storleken är inte implementerad för [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Det enda undantaget är den implicita `Self`-typen av en trait.
/// En trait har inte en implicit `Sized`-bunden eftersom det är oförenligt med [trait-objekt] där trait per definition behöver arbeta med alla möjliga implementatorer och därmed kan vara vilken storlek som helst.
///
///
/// Även om Rust låter dig binda `Sized` till en trait, kommer du inte att kunna använda den för att bilda ett trait-objekt senare:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // låt y: &dyn Bar= &Impl;//fel: trait `Bar` kan inte göras till ett objekt
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // för Standard, till exempel, vilket kräver att `[T]: !Default` kan utvärderas
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Typer som kan vara "unsized" till en typ av dynamiskt storlek.
///
/// Till exempel implementerar den stora arraytypen `[i8; 2]` `Unsize<[i8]>` och `Unsize<dyn fmt::Debug>`.
///
/// Alla implementeringar av `Unsize` tillhandahålls automatiskt av kompilatorn.
///
/// `Unsize` implementeras för:
///
/// - `[T; N]` är `Unsize<[T]>`
/// - `T` är `Unsize<dyn Trait>` när `T: Trait`
/// - `Foo<..., T, ...>` är `Unsize<Foo<..., U, ...>>` om:
///   - `T: Unsize<U>`
///   - Foo är en struktur
///   - Endast det sista fältet i `Foo` har en typ som involverar `T`
///   - `T` ingår inte i typen av andra fält
///   - `Bar<T>: Unsize<Bar<U>>`, om det sista fältet i `Foo` har typ `Bar<T>`
///
/// `Unsize` används tillsammans med [`ops::CoerceUnsized`] för att tillåta "user-defined"-behållare som [`Rc`] att innehålla typer av dynamiskt storlek.
/// Se [DST coercion RFC][RFC982] och [the nomicon entry on coercion][nomicon-coerce] för mer information.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Krävs trait för konstanter som används i mönstermatchningar.
///
/// Varje typ som härleder `PartialEq` implementerar automatiskt denna trait,*oavsett* om dess typparametrar implementerar `Eq`.
///
/// Om ett `const`-objekt innehåller någon typ som inte implementerar denna trait, implementerar den typen antingen (1.) inte `PartialEq` (vilket innebär att konstanten inte ger den jämförelsemetoden, vilken kodgenerering förutsätter är tillgänglig) eller (2.) implementerar den *sin egen* version av `PartialEq` (som vi antar inte överensstämmer med en jämförelse mellan struktur och jämlikhet).
///
///
/// I något av de två scenarierna ovan avvisar vi användning av en sådan konstant i en mönstermatchning.
///
/// Se även [structural match RFC][RFC1445] och [issue 63438] som motiverade migrering från attributbaserad design till denna trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Krävs trait för konstanter som används i mönstermatchningar.
///
/// Alla typer som härleder `Eq` implementerar automatiskt denna trait,*oavsett* om dess typparametrar implementerar `Eq`.
///
/// Detta är ett hack för att kringgå en begränsning i vårt typsystem.
///
/// # Background
///
/// Vi vill kräva att typer av konstationer som används i mönstermatchningar har attributet `#[derive(PartialEq, Eq)]`.
///
/// I en mer idealisk värld kan vi kontrollera detta krav genom att bara kontrollera att den givna typen implementerar både `StructuralPartialEq` trait *och*`Eq` trait.
/// Du kan dock ha ADT som *gör*`derive(PartialEq, Eq)`, och vara ett fall som vi vill att kompilatorn ska acceptera, och ändå misslyckas konstantens typ att implementera `Eq`.
///
/// Nämligen ett fall som detta:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Problemet i ovanstående kod är att `Wrap<fn(&())>` inte implementerar `PartialEq` eller `Eq`, eftersom `för <'a> fn(&'a _)` does not implement those traits.)
///
/// Därför kan vi inte förlita oss på naiv kontroll för `StructuralPartialEq` och bara `Eq`.
///
/// Som ett hack för att lösa detta använder vi två separata traits som injiceras av var och en av de två härledda (`#[derive(PartialEq)]` och `#[derive(Eq)]`) och kontrollerar att båda är närvarande som en del av strukturell matchningskontroll.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Typer vars värden kan dupliceras helt enkelt genom att kopiera bitar.
///
/// Som standard har variabla bindningar "flytta semantik."Med andra ord:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` har flyttat till `y` och kan därför inte användas
///
/// // println! ("{: ?}", x);//fel: användning av flyttat värde
/// ```
///
/// Men om en typ implementerar `Copy` har den istället 'kopiera semantik':
///
/// ```
/// // Vi kan härleda en `Copy`-implementering.
/// // `Clone` krävs också, eftersom det är en supertrait av `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` är en kopia av `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Det är viktigt att notera att i dessa två exempel är den enda skillnaden om du får åtkomst till `x` efter uppdraget.
/// Under huven kan både en kopia och ett drag resultera i att bitar kopieras i minnet, även om detta ibland optimeras bort.
///
/// ## Hur kan jag implementera `Copy`?
///
/// Det finns två sätt att implementera `Copy` på din typ.Det enklaste är att använda `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Du kan också implementera `Copy` och `Clone` manuellt:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Det finns en liten skillnad mellan de två: `derive`-strategin placerar också en `Copy` bunden till typparametrar, vilket inte alltid är önskvärt.
///
/// ## Vad är skillnaden mellan `Copy` och `Clone`?
///
/// Kopior sker implicit, till exempel som en del av ett uppdrag `y = x`.Uppförandet av `Copy` är inte överbelastbart.det är alltid en enkel bitvis kopia.
///
/// Kloning är en uttrycklig åtgärd, `x.clone()`.Implementeringen av [`Clone`] kan ge vilket typspecifikt beteende som helst som krävs för att duplicera värden säkert.
/// Till exempel måste implementeringen av [`Clone`] för [`String`] kopiera den pekade strängbufferten i högen.
/// En enkel bitvis kopia av [`String`]-värden skulle bara kopiera pekaren, vilket leder till en dubbel ledig längs linjen.
/// Av denna anledning är [`String`] [`Clone`] men inte `Copy`.
///
/// [`Clone`] är en supertrait av `Copy`, så allt som är `Copy` måste också implementera [`Clone`].
/// Om en typ är `Copy` behöver dess [`Clone`]-implementering bara returnera `*self` (se exemplet ovan).
///
/// ## När kan min typ vara `Copy`?
///
/// En typ kan implementera `Copy` om alla dess komponenter implementerar `Copy`.Till exempel kan denna struktur vara `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// En struktur kan vara `Copy` och [`i32`] är `Copy`, därför kan `Point` vara `Copy`.
/// Däremot överväga
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Struct `PointList` kan inte implementera `Copy`, eftersom [`Vec<T>`] inte är `Copy`.Om vi försöker härleda en `Copy`-implementering får vi ett fel:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Delade referenser (`&T`) är också `Copy`, så en typ kan vara `Copy`, även om den innehåller delade referenser av typ `T` som *inte*`Copy`.
/// Tänk på följande struktur, som kan implementera `Copy`, eftersom den bara innehåller en *delad referens* till vår icke-"kopiera" typ `PointList` ovanifrån:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## När *kan* min typ inte vara `Copy`?
///
/// Vissa typer kan inte kopieras säkert.Till exempel skulle kopiering av `&mut T` skapa en aliasmuterbar referens.
/// Kopiering av [`String`] skulle duplicera ansvaret för att hantera [`` String '' 's buffert, vilket leder till en dubbelfri.
///
/// Genom att generalisera det senare fallet kan alla typer som implementerar [`Drop`] inte vara `Copy`, eftersom det hanterar någon resurs förutom sina egna [`size_of::<T>`]-byte.
///
/// Om du försöker implementera `Copy` på en struktur eller enum som innehåller data som inte är "kopiera" får du felet [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## När *ska* min typ vara `Copy`?
///
/// Generellt sett, om din typ _can_ implementerar `Copy`, borde det.
/// Men kom ihåg att implementering av `Copy` är en del av det offentliga API av din typ.
/// Om typen kanske inte blir 'Kopiera' i future, kan det vara klokt att utelämna `Copy`-implementeringen nu för att undvika en brytande API-förändring.
///
/// ## Ytterligare implementatorer
///
/// Förutom [implementors listed below][impls] implementerar följande typer också `Copy`:
///
/// * Funktionsposttyper (dvs. de olika typerna som definierats för varje funktion)
/// * Funktionspekartyper (t.ex. `fn() -> i32`)
/// * Arraytyper, för alla storlekar, om artikeltypen också implementerar `Copy` (t.ex. `[i32; 123456]`)
/// * Tupeltyper, om varje komponent också implementerar `Copy` (t.ex. `()`, `(i32, bool)`)
/// * Stängningstyper, om de inte fångar något värde från miljön eller om alla sådana fångade värden implementerar `Copy` själva.
///   Observera att variabler som fångas av delad referens alltid implementerar `Copy` (även om referenten inte gör det), medan variabler som fångas av mutabel referens aldrig implementerar `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Detta möjliggör kopiering av en typ som inte implementerar `Copy` på grund av otillfredsställda livstidsgränser (kopiering av `A<'_>` när endast `A<'static>: Copy` och `A<'_>: Clone`).
// Vi har detta attribut här för tillfället bara för att det finns en hel del befintliga specialiseringar på `Copy` som redan finns i standardbiblioteket, och det finns inget sätt att säkert ha detta beteende just nu.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Hämta makro som genererar en impl av trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Typer som det är säkert att dela referenser mellan trådar.
///
/// Denna trait implementeras automatiskt när kompilatorn bestämmer att den är lämplig.
///
/// Den exakta definitionen är: en typ `T` är [`Sync`] om och endast om `&T` är [`Send`].
/// Med andra ord, om det inte finns någon möjlighet för [undefined behavior][ub] (inklusive datalopp) när `&T`-referenser skickas mellan trådarna.
///
/// Som man kan förvänta sig är primitiva typer som [`u8`] och [`f64`] alla [`Sync`], och det är också enkla aggregattyper som innehåller dem, som tuples, structs and enums.
/// Fler exempel på grundläggande [`Sync`]-typer inkluderar "immutable"-typer som `&T`, och de med enkel ärftlig mutabilitet, såsom [`Box<T>`][box], [`Vec<T>`][vec] och de flesta andra samlingstyper.
///
/// (Generiska parametrar måste vara [`Sync`] för att deras behållare ska vara [`Sync`].)
///
/// En något överraskande konsekvens av definitionen är att `&mut T` är `Sync` (om `T` är `Sync`) även om det verkar som att det kan ge osynkroniserad mutation.
/// Tricket är att en muterbar referens bakom en delad referens (det vill säga `& &mut T`) blir skrivskyddad, som om det vore en `& &T`.
/// Därför finns det ingen risk för en datalopp.
///
/// Typer som inte är `Sync` är de som har "interior mutability" i en icke-trådsäker form, till exempel [`Cell`][cell] och [`RefCell`][refcell].
/// Dessa typer möjliggör mutation av deras innehåll även genom en oföränderlig, delad referens.
/// Till exempel tar `set`-metoden på [`Cell<T>`][cell] `&self`, så det kräver bara en delad referens [`&Cell<T>`][cell].
/// Metoden utför ingen synkronisering, så [`Cell`][cell] kan inte vara `Sync`.
///
/// Ett annat exempel på en icke-synk-typ är referensräknarpekaren [`Rc`][rc].
/// Med valfri referens [`&Rc<T>`][rc] kan du klona en ny [`Rc<T>`][rc] genom att ändra referensräkningarna på ett icke-atomärt sätt.
///
/// För fall där man behöver trådsäker inre mutabilitet, tillhandahåller Rust [atomic data types], liksom explicit låsning via [`sync::Mutex`][mutex] och [`sync::RwLock`][rwlock].
/// Dessa typer säkerställer att någon mutation inte kan orsaka dataserier, varför typerna är `Sync`.
/// På samma sätt ger [`sync::Arc`][arc] en trådsäker analog av [`Rc`][rc].
///
/// Alla typer med inre mutabilitet måste också använda [`cell::UnsafeCell`][unsafecell]-omslaget runt value(s) som kan muteras genom en delad referens.
/// Att inte göra detta är [undefined behavior][ub].
/// Till exempel är [`transmute`][transmute]-ing från `&T` till `&mut T` ogiltig.
///
/// Se [the Nomicon][nomicon-send-and-sync] för mer information om `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): när stöd för att lägga till anteckningar i `rustc_on_unimplemented` landar i beta, och det har utökats för att kontrollera om en stängning finns någonstans i kravkedjan, förläng den som sådan (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Nollstorlek används för att markera saker som "act like" de äger en `T`.
///
/// Om du lägger till ett `PhantomData<T>`-fält till din typ berättar kompilatorn att din typ fungerar som om den lagrar ett värde av typen `T`, även om den inte riktigt fungerar.
/// Denna information används vid beräkning av vissa säkerhetsegenskaper.
///
/// För en mer ingående förklaring av hur du använder `PhantomData<T>`, se [the Nomicon](../../nomicon/phantom-data.html).
///
/// # En hemsk anteckning 👻👻👻
///
/// Även om de båda har läskiga namn är `PhantomData` och 'fantomtyper' relaterade, men inte identiska.En fantomtypsparameter är helt enkelt en typparameter som aldrig används.
/// I Rust får detta ofta kompilatorn att klaga, och lösningen är att lägga till en "dummy"-användning via `PhantomData`.
///
/// # Examples
///
/// ## Oanvänd livstidsparametrar
///
/// Det kanske vanligaste användningsfallet för `PhantomData` är en struktur som har en oanvänd livstidsparameter, vanligtvis som en del av någon osäker kod.
/// Här är till exempel en struktur `Slice` som har två pekare av typen `*const T`, som förmodligen pekar in i en matris någonstans:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Avsikten är att de underliggande uppgifterna endast är giltiga under hela `'a`, så `Slice` ska inte överleva `'a`.
/// Denna avsikt uttrycks emellertid inte i koden, eftersom det inte finns någon användning av `'a` livstid och det är därför inte klart vilka data den gäller för.
/// Vi kan korrigera detta genom att berätta för kompilatorn att hantera *som om*`Slice`-strukturen innehöll en referens `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Detta kräver i sin tur också anteckningen `T: 'a`, vilket indikerar att alla referenser i `T` är giltiga under hela `'a`.
///
/// När du initialiserar en `Slice` anger du helt enkelt värdet `PhantomData` för fältet `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Oanvända typparametrar
///
/// Ibland händer det att du har oanvända typparametrar som indikerar vilken typ av data en struct är "tied" till, även om den informationen faktiskt inte finns i själva strukturen.
/// Här är ett exempel där detta uppstår med [FFI].
/// Det främmande gränssnittet använder handtag av typen `*mut ()` för att referera till Rust-värden av olika typer.
/// Vi spårar Rust-typen med en fantomtypsparameter på struct `ExternalResource` som sveper ett handtag.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Ägarskap och droppkontroll
///
/// Lägga till ett fält av typen `PhantomData<T>` indikerar att din typ äger data av typen `T`.Detta i sin tur innebär att när din typ tappas kan den tappa en eller flera instanser av typen `T`.
/// Detta har betydelse för Rust-kompilatorns [drop check]-analys.
///
/// Om din struct faktiskt inte *äger* data av typen `T`, är det bättre att använda en referens typ, som `PhantomData<&'a T>` (ideally) eller `PhantomData<*const T>` (om ingen livslängd gäller), för att inte indikera ägande.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Kompilator-intern trait används för att ange typen av enumdiskriminanter.
///
/// Denna trait implementeras automatiskt för alla typer och ger inga garantier till [`mem::Discriminant`].
/// Det är **odefinierat beteende** att transmutera mellan `DiscriminantKind::Discriminant` och `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Den typ av diskriminant som måste uppfylla trait bounds som krävs av `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Compiler-intern trait används för att avgöra om en typ innehåller någon `UnsafeCell` internt, men inte genom en indirektion.
///
/// Detta påverkar till exempel om en `static` av den typen placeras i skrivskyddat statiskt minne eller skrivbart statiskt minne.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Typer som kan flyttas säkert efter att de har fästs.
///
/// Rust själv har ingen uppfattning om fasta typer och anser att drag (t.ex. genom tilldelning eller [`mem::replace`]) alltid är säkra.
///
/// [`Pin`][Pin]-typen används istället för att förhindra rörelser genom typsystemet.Pekare `P<T>` inslagna i [`Pin<P<T>>`][Pin]-omslaget kan inte flyttas ut.
/// Se [`pin` module]-dokumentationen för mer information om fästning.
///
/// Implementering av `Unpin` trait för `T` lyfter begränsningarna för att fästa av typen, vilket gör det möjligt att flytta `T` ut ur [`Pin<P<T>>`][Pin] med funktioner som [`mem::replace`].
///
///
/// `Unpin` har ingen konsekvens alls för icke-fästa data.
/// I synnerhet flyttar [`mem::replace`] gärna `!Unpin`-data (det fungerar för alla `&mut T`, inte bara när `T: Unpin`).
/// Du kan dock inte använda [`mem::replace`] på data som är insvept i en [`Pin<P<T>>`][Pin] eftersom du inte kan få den `&mut T` du behöver för det, och *det* är det som får systemet att fungera.
///
/// Så detta kan till exempel bara göras på typer som implementerar `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Vi behöver en förändrad referens för att ringa `mem::replace`.
/// // Vi kan få en sådan referens genom att (implicitly) åberopar `Pin::deref_mut`, men det är bara möjligt eftersom `String` implementerar `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Denna trait implementeras automatiskt för nästan alla typer.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// En markörtyp som inte implementerar `Unpin`.
///
/// Om en typ innehåller en `PhantomPinned` implementeras den inte som standard `Unpin`.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implementeringar av `Copy` för primitiva typer.
///
/// Implementeringar som inte kan beskrivas i Rust implementeras i `traits::SelectionContext::copy_clone_conditions()` i `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Delade referenser kan kopieras, men muterbara referenser *kan inte*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}