#![feature(no_core)]
#![no_core]

// Se rustc-std-workspace-core för varför denna crate behövs.

// Byt namn på crate för att undvika konflikt med allokeringsmodulen i liballoc.
extern crate alloc as foo;

pub use foo::*;