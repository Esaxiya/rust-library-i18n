#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Innehållet i det nya minnet är oinitialiserat.
    Uninitialized,
    /// Det nya minnet är garanterat nollställt.
    Zeroed,
}

/// Ett verktyg på låg nivå för mer ergonomisk allokering, omallokering och omlokalisering av en buffert med minne på högen utan att behöva oroa sig för alla inblandade hörnfall.
///
/// Denna typ är utmärkt för att bygga dina egna datastrukturer som Vec och VecDeque.
/// Särskilt:
///
/// * Producerar `Unique::dangling()` på nollstorlekstyper.
/// * Producerar `Unique::dangling()` på nollängdstilldelningar.
/// * Undvik att frigöra `Unique::dangling()`.
/// * Fångar alla överflöden i kapacitetsberäkningar (marknadsför dem till "capacity overflow" panics).
/// * Skydd mot 32-bitars system som tilldelar mer än isize::MAX byte.
/// * Skydd mot överflöd av din längd.
/// * Anropar `handle_alloc_error` för felbara tilldelningar.
/// * Innehåller en `ptr::Unique` och ger användaren därmed alla relaterade fördelar.
/// * Använder det överskott som returneras från fördelaren för att använda den största tillgängliga kapaciteten.
///
/// Den här typen inspekterar ändå inte minnet som den hanterar.När det tappas *kommer det* att frigöra minne, men det *kommer inte* att försöka släppa innehållet.
/// Det är upp till användaren av `RawVec` att hantera de faktiska sakerna *lagrade* inuti en `RawVec`.
///
/// Observera att överskottet av nollstorlekstyper alltid är oändligt, så `capacity()` returnerar alltid `usize::MAX`.
/// Det betyder att du måste vara försiktig när du rundar ut den här typen med en `Box<[T]>`, eftersom `capacity()` inte ger längden.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Detta existerar eftersom `#[unstable]` `const fn`s inte behöver överensstämma med `min_const_fn` och därför kan de inte heller kallas till`min_const_fn`s.
    ///
    /// Om du ändrar `RawVec<T>::new` eller beroenden, var noga med att inte införa något som verkligen skulle bryta mot `min_const_fn`.
    ///
    /// NOTE: Vi kan undvika detta hack och kontrollera överensstämmelse med något `#[rustc_force_min_const_fn]`-attribut som kräver överensstämmelse med `min_const_fn` men inte nödvändigtvis tillåter att det anropas i `stable(...) const fn`/användarkod som inte möjliggör `foo` när `#[rustc_const_unstable(feature = "foo", issue = "01234")]` är närvarande.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Skapar den största möjliga `RawVec` (på systemheapen) utan att allokera.
    /// Om `T` har positiv storlek blir det en `RawVec` med kapacitet `0`.
    /// Om `T` är nollstor, gör det en `RawVec` med kapacitet `usize::MAX`.
    /// Användbar för implementering av försenad tilldelning.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Skapar en `RawVec` (på systemhögen) med exakt kapacitet och justeringskrav för en `[T; capacity]`.
    /// Detta motsvarar att ringa `RawVec::new` när `capacity` är `0` eller `T` är nollstorlek.
    /// Observera att om `T` är nollstorlek betyder det att du *inte* får en `RawVec` med önskad kapacitet.
    ///
    /// # Panics
    ///
    /// Panics om den begärda kapaciteten överstiger `isize::MAX` byte.
    ///
    /// # Aborts
    ///
    /// Avbryter på OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Som `with_capacity`, men garanterar att bufferten nollställs.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Rekonstituerar en `RawVec` från en pekare och kapacitet.
    ///
    /// # Safety
    ///
    /// `ptr` måste tilldelas (på systemheapen) och med den givna `capacity`.
    /// `capacity` kan inte överstiga `isize::MAX` för storlekstyper.(bara ett problem på 32-bitars system).
    /// ZST vektorer kan ha en kapacitet upp till `usize::MAX`.
    /// Om `ptr` och `capacity` kommer från en `RawVec`, är detta garanterat.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Små Vecs är dumma.Hoppa över till:
    // - 8 om elementstorleken är 1, eftersom eventuella högtilldelare sannolikt kommer att runda upp en begäran på mindre än 8 byte till minst 8 byte.
    //
    // - 4 om elementen är måttliga (<=1 KiB).
    // - 1 annars för att undvika att slösa för mycket utrymme för mycket korta Vecs.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Som `new`, men parametrerad över valet av fördelare för den returnerade `RawVec`.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` betyder "unallocated".nollstorlekstyper ignoreras.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Som `with_capacity`, men parametrerad över valet av fördelare för den returnerade `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Som `with_capacity_zeroed`, men parametrerad över valet av fördelare för den returnerade `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Konverterar en `Box<[T]>` till en `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Konverterar hela bufferten till `Box<[MaybeUninit<T>]>` med den angivna `len`.
    ///
    /// Observera att detta kommer att rekonstruera alla `cap`-ändringar som kan ha utförts korrekt.(Se beskrivning av typ för detaljer.)
    ///
    /// # Safety
    ///
    /// * `len` måste vara större än eller lika med den senast begärda kapaciteten, och
    /// * `len` måste vara mindre än eller lika med `self.capacity()`.
    ///
    /// Observera att den begärda kapaciteten och `self.capacity()` kan skilja sig, eftersom en fördelare kan samla in och returnera ett större minnesblock än vad som begärts.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Sanitetskontroll hälften av säkerhetskravet (vi kan inte kontrollera den andra hälften).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Vi undviker `unwrap_or_else` här eftersom det genererar mängden LLVM IR som genereras.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Rekonstituerar en `RawVec` från en pekare, kapacitet och fördelare.
    ///
    /// # Safety
    ///
    /// `ptr` måste tilldelas (via den givna fördelaren `alloc`) och med den givna `capacity`.
    /// `capacity` kan inte överstiga `isize::MAX` för storlekstyper.
    /// (bara ett problem på 32-bitars system).
    /// ZST vektorer kan ha en kapacitet upp till `usize::MAX`.
    /// Om `ptr` och `capacity` kommer från en `RawVec` som skapats via `alloc`, är detta garanterat.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Får en rå pekare till början av tilldelningen.
    /// Observera att detta är `Unique::dangling()` om `capacity == 0` eller `T` är nollstorlek.
    /// I det tidigare fallet måste du vara försiktig.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Hämtar kapaciteten för tilldelningen.
    ///
    /// Detta kommer alltid att vara `usize::MAX` om `T` är nollstor.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Returnerar en delad referens till fördelaren som stöder denna `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Vi har en tilldelad bit minne, så att vi kan kringgå runtime-kontroller för att få vår nuvarande layout.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Säkerställer att bufferten innehåller åtminstone tillräckligt med utrymme för att hålla `len + additional`-element.
    /// Om den inte redan har tillräckligt med kapacitet kommer du att omfördela tillräckligt med utrymme plus bekvämt slackutrymme för att bli amorterad *O*(1).
    ///
    /// Begränsar detta beteende om det onödigt skulle orsaka sig själv till panic.
    ///
    /// Om `len` överstiger `self.capacity()` kan detta misslyckas med att faktiskt allokera det begärda utrymmet.
    /// Detta är inte riktigt osäkert, men den osäkra koden *du* skriver som är beroende av beteendet hos denna funktion kan gå sönder.
    ///
    /// Detta är perfekt för att genomföra en bulk-push-operation som `extend`.
    ///
    /// # Panics
    ///
    /// Panics om den nya kapaciteten överstiger `isize::MAX` byte.
    ///
    /// # Aborts
    ///
    /// Avbryter på OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // reserven skulle ha avbrutits eller fått panik om len översteg `isize::MAX` så det är säkert att göra okontrollerat nu.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Samma som `reserve`, men återkommer vid fel istället för att få panik eller avbryta.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Säkerställer att bufferten innehåller åtminstone tillräckligt med utrymme för att hålla `len + additional`-element.
    /// Om det inte redan gör det kommer omfördelning av minsta möjliga mängd minne som krävs.
    /// I allmänhet kommer detta att vara exakt den mängd minne som krävs, men i princip är allokeraren fri att ge tillbaka mer än vi bad om.
    ///
    ///
    /// Om `len` överstiger `self.capacity()` kan detta misslyckas med att faktiskt allokera det begärda utrymmet.
    /// Detta är inte riktigt osäkert, men den osäkra koden *du* skriver som är beroende av beteendet hos denna funktion kan gå sönder.
    ///
    /// # Panics
    ///
    /// Panics om den nya kapaciteten överstiger `isize::MAX` byte.
    ///
    /// # Aborts
    ///
    /// Avbryter på OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Samma som `reserve_exact`, men återkommer vid fel istället för att få panik eller avbryta.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Krymp tilldelningen ner till det angivna beloppet.
    /// Om det angivna beloppet är 0, delas faktiskt helt ut.
    ///
    /// # Panics
    ///
    /// Panics om det angivna beloppet är *större* än den nuvarande kapaciteten.
    ///
    /// # Aborts
    ///
    /// Avbryter på OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Returnerar om bufferten behöver växa för att uppfylla den extra kapacitet som behövs.
    /// Används främst för att möjliggöra inlining av reservsamtal utan att `grow` läggs in.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Denna metod instanseras vanligtvis många gånger.Så vi vill att den ska vara så liten som möjligt, för att förbättra sammanställningstiderna.
    // Men vi vill också att så mycket av innehållet ska vara statiskt beräknbart som möjligt för att få den genererade koden att gå snabbare.
    // Därför är den här metoden noggrant skriven så att all kod som beror på `T` finns i den, medan så mycket av koden som inte beror på `T` som möjligt finns i funktioner som inte är generiska över `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Detta säkerställs av samtalssammanhanget.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Eftersom vi returnerar en kapacitet på `usize::MAX` när `elem_size` är
            // 0, att komma hit betyder nödvändigtvis att `RawVec` är överfull.
            return Err(CapacityOverflow);
        }

        // Ingenting vi verkligen kan göra åt dessa kontroller, tyvärr.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Detta garanterar exponentiell tillväxt.
        // Fördubblingen kan inte överflödas eftersom `cap <= isize::MAX` och typen av `cap` är `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` är icke-generisk över `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Begränsningarna för denna metod är ungefär desamma som för `grow_amortized`, men den här metoden instanseras vanligtvis mindre ofta så att den är mindre kritisk.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Eftersom vi returnerar en kapacitet på `usize::MAX` när typstorleken är
            // 0, att komma hit betyder nödvändigtvis att `RawVec` är överfull.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` är icke-generisk över `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Denna funktion ligger utanför `RawVec` för att minimera kompileringstider.Se kommentaren ovanför `RawVec::grow_amortized` för mer information.
// (`A`-parametern är inte signifikant, eftersom antalet olika `A`-typer som ses i praktiken är mycket mindre än antalet `T`-typer.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Sök efter felet här för att minimera storleken på `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Tilldelaren kontrollerar om jämställdhet är i linje
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Frigör minnet som ägs av `RawVec`*utan att* försöka släppa innehållet.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Central funktion för hantering av reservfel.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Vi måste garantera följande:
// * Vi tilldelar aldrig `> isize::MAX` byte-storlek objekt.
// * Vi överflödar inte `usize::MAX` och tilldelar faktiskt för lite.
//
// På 64-bitars behöver vi bara kontrollera om det finns överflöde eftersom försök att tilldela `> isize::MAX` byte säkert kommer att misslyckas.
// På 32-bitars och 16-bitars måste vi lägga till ett extra skydd för detta om vi kör på en plattform som kan använda alla 4 GB i användarutrymme, t.ex. PAE eller x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// En central funktion som ansvarar för att rapportera överflöd.
// Detta kommer att säkerställa att kodgenerering relaterad till dessa panics är minimal eftersom det bara finns en plats som panics snarare än en massa i hela modulen.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}