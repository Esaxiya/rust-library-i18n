/// Skapar en [`Vec`] som innehåller argumenten.
///
/// `vec!` tillåter att 'Vec' definieras med samma syntax som arrayuttryck.
/// Det finns två former av detta makro:
///
/// - Skapa en [`Vec`] som innehåller en given lista med element:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Skapa en [`Vec`] från ett visst element och storlek:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Observera att till skillnad från arrayuttryck stöder denna syntax alla element som implementerar [`Clone`] och antalet element behöver inte vara konstant.
///
/// Detta kommer att använda `clone` för att duplicera ett uttryck, så man bör vara försiktig med att använda detta med typer som har en icke-standardiserad `Clone`-implementering.
/// Till exempel `vec![Rc::new(1);5] `kommer att skapa en vector med fem referenser till samma boxade heltal, inte fem referenser som pekar på oberoende boxade heltal.
///
///
/// Observera också att `vec![expr; 0]` är tillåtet och producerar en tom vector.
/// Detta kommer dock fortfarande att utvärdera `expr` och omedelbart släppa det resulterande värdet, så var uppmärksam på biverkningar.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): med cfg(test) är den inneboende `[T]::into_vec`-metoden, som krävs för denna makrodefinition, inte tillgänglig.
// Använd istället `slice::into_vec`-funktionen som endast är tillgänglig med cfg(test) OBS se slice::hack-modulen i slice.rs för mer information
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Skapar en `String` med interpolering av runtime-uttryck.
///
/// Det första argumentet `format!` får är en formatsträng.Detta måste vara en sträng bokstavlig.Formateringssträngens styrka finns i '{}' sna.
///
/// Ytterligare parametrar som skickas till `format!` ersätter '{} i formateringssträngen i den angivna ordningen såvida inte namngivna eller positionsparametrar används;se [`std::fmt`] för mer information.
///
///
/// En vanlig användning för `format!` är sammankoppling och interpolering av strängar.
/// Samma konvention används med [`print!`]-och [`write!`]-makron, beroende på strängens avsedda mål.
///
/// För att konvertera ett enda värde till en sträng, använd [`to_string`]-metoden.Detta använder [`Display`]-formateringen trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics om en formatering av trait-implementering returnerar ett fel.
/// Detta indikerar en felaktig implementering eftersom `fmt::Write for String` aldrig returnerar ett fel själv.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Tvinga AST-noden till ett uttryck för att förbättra diagnostiken i mönsterposition.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}