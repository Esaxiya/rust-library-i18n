use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Tar tillfälligt ut en annan, oföränderlig motsvarighet till samma intervall.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Hitta de distinkta bladkanterna som avgränsar ett angivet intervall i ett träd.
    /// Returnerar antingen ett par olika handtag i samma träd eller ett par tomma alternativ.
    ///
    /// # Safety
    ///
    /// Om inte `BorrowType` är `Immut`, använd inte dubbla handtag för att besöka samma KV två gånger.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Motsvarar `(root1.first_leaf_edge(), root2.last_leaf_edge())` men effektivare.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Hitta paret av bladkanter som avgränsar ett visst område i ett träd.
    ///
    /// Resultatet är endast meningsfullt om trädet ordnas med nyckel, som trädet i en `BTreeMap` är.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // SÄKERHET: vår lånetyp är oföränderlig.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Hitta paret av bladkanter som avgränsar ett helt träd.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Delar en unik referens i ett par bladkanter som avgränsar ett angivet intervall.
    /// Resultatet är icke-unika referenser som tillåter (some)-mutation, som måste användas försiktigt.
    ///
    /// Resultatet är endast meningsfullt om trädet ordnas med nyckel, som trädet i en `BTreeMap` är.
    ///
    ///
    /// # Safety
    /// Använd inte de dubbla handtagen för att besöka samma KV två gånger.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Delar en unik referens i ett par bladkanter som avgränsar trädets hela sortiment.
    /// Resultaten är icke-unika referenser som tillåter mutation (endast av värden), så de måste användas med försiktighet.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Vi duplicerar roten NodeRef här-vi besöker aldrig samma KV två gånger och slutar aldrig med överlappande värdereferenser.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Delar en unik referens i ett par bladkanter som avgränsar trädets hela sortiment.
    /// Resultaten är icke-unika referenser som tillåter massivt destruktiv mutation, så måste användas med största försiktighet.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Vi duplicerar roten NodeRef här-vi kommer aldrig åt den på ett sätt som överlappar referenser som erhållits från roten.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Med ett blad edge-handtag, returneras [`Result::Ok`] med ett handtag till angränsande KV på höger sida, som antingen finns i samma bladnod eller i en förfadernod.
    ///
    /// Om bladet edge är det sista i trädet, returnerar [`Result::Err`] med rotnoden.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Med ett blad edge-handtag returneras [`Result::Ok`] med ett handtag till angränsande KV på vänster sida, som antingen finns i samma bladnod eller i en förfadernod.
    ///
    /// Om bladet edge är det första i trädet, returnerar [`Result::Err`] med rotnoden.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Med ett internt edge-handtag returneras [`Result::Ok`] med ett handtag till angränsande KV på höger sida, som antingen finns i samma interna nod eller i en förfadernod.
    ///
    /// Om den interna edge är den sista i trädet, returneras [`Result::Err`] med rotnoden.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Med ett blad edge-handtag i ett döende träd, returnerar nästa blad edge på höger sida och nyckel-värdeparet däremellan, som antingen finns i samma bladnod, i en förfadernod eller inte finns.
    ///
    ///
    /// Denna metod omplacerar också alla node(s) som den når slutet av.
    /// Detta innebär att om inget fler nyckel-värdepar finns, kommer hela resten av trädet att ha delats ut och det finns inget kvar att återvända.
    ///
    /// # Safety
    /// Den givna edge får inte ha returnerats tidigare av motparten `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Med ett blad edge-handtag i ett döende träd, returnerar nästa blad edge på vänster sida och nyckel-värdeparet däremellan, som antingen finns i samma bladnod, i en förfadernod eller som inte finns.
    ///
    ///
    /// Denna metod omplacerar också alla node(s) som den når slutet av.
    /// Detta innebär att om inget fler nyckel-värdepar finns, kommer hela resten av trädet att ha delats ut och det finns inget kvar att återvända.
    ///
    /// # Safety
    /// Den givna edge får inte ha returnerats tidigare av motparten `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Distribuerar en hög med noder från bladet upp till roten.
    /// Det här är det enda sättet att återplacera resten av ett träd efter att `deallocating_next` och `deallocating_next_back` har knaprat på båda sidor om trädet och träffat samma edge.
    /// Eftersom det endast är avsett att anropas när alla nycklar och värden har returnerats görs ingen rensning på någon av tangenterna eller värdena.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Flyttar bladet edge till nästa blad edge och returnerar referenser till nyckeln och värdet däremellan.
    ///
    ///
    /// # Safety
    /// Det måste finnas ytterligare en KV i den körda riktningen.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Flyttar bladet edge till det tidigare bladet edge och returnerar referenser till nyckeln och värdet däremellan.
    ///
    ///
    /// # Safety
    /// Det måste finnas ytterligare en KV i den körda riktningen.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Flyttar bladet edge till nästa blad edge och returnerar referenser till nyckeln och värdet däremellan.
    ///
    ///
    /// # Safety
    /// Det måste finnas ytterligare en KV i den körda riktningen.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Att göra det här är snabbare enligt riktmärken.
        kv.into_kv_valmut()
    }

    /// Flyttar bladets edge-handtag till föregående blad och returnerar referenser till nyckeln och värdet däremellan.
    ///
    ///
    /// # Safety
    /// Det måste finnas ytterligare en KV i den körda riktningen.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Att göra det här är snabbare enligt riktmärken.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Flyttar bladet edge-handtaget till nästa blad edge och returnerar nyckeln och värdet däremellan, och fördelar all nod som är kvar medan den motsvarande edge lämnas i sin överordnade nod.
    ///
    /// # Safety
    /// - Det måste finnas ytterligare en KV i den körda riktningen.
    /// - Att KV inte tidigare returnerades av motsvarighet `next_back_unchecked` på någon kopia av handtagen som används för att korsa trädet.
    ///
    /// Det enda säkra sättet att gå vidare med det uppdaterade handtaget är att jämföra det, släppa det, anropa denna metod igen under förutsättning av dess säkerhetsförhållanden eller ringa motsvarighet `next_back_unchecked` med förbehåll för dess säkerhetsförhållanden.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Flyttar bladets edge-handtag till det föregående bladet edge och returnerar nyckeln och värdet däremellan, och fördelar all nod som är kvar medan den motsvarande edge lämnas i sin moder nod dinglande.
    ///
    /// # Safety
    /// - Det måste finnas ytterligare en KV i den körda riktningen.
    /// - Det bladet edge returnerades inte tidigare av motsvarigheten `next_unchecked` på någon kopia av handtagen som används för att korsa trädet.
    ///
    /// Det enda säkra sättet att gå vidare med det uppdaterade handtaget är att jämföra det, släppa det, anropa denna metod igen under förutsättning av dess säkerhetsförhållanden eller ringa motsvarighet `next_unchecked` med förbehåll för dess säkerhetsförhållanden.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Returnerar bladet edge längst till vänster i eller under en nod, med andra ord edge du behöver först när du navigerar framåt (eller sist när du navigerar bakåt).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Returnerar bladet edge längst till höger i eller under en nod, med andra ord edge du behöver sist när du navigerar framåt (eller först när du navigerar bakåt).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Besök bladnoder och interna KV: er i ordning efter stigande nycklar och besöker också interna noder som helhet i första ordningens djup, vilket innebär att interna noder föregår deras individuella KV: er och deras barnnoder.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Beräknar antalet element i ett (under) träd.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Returnerar bladet edge närmast en KV för navigering framåt.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Returnerar bladet edge närmast en KV för bakåtnavigering.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}