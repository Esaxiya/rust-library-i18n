// Detta är ett försök till en implementering som följer idealet
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Eftersom Rust faktiskt inte har beroende typer och polymorf rekursion, nöjer vi oss med mycket osäkerhet.
//

// Ett huvudmål med denna modul är att undvika komplexitet genom att behandla trädet som en generisk (om konstigt formad) behållare och undvika att hantera de flesta av B-Tree-invarianterna.
//
// Som sådan bryr sig inte den här modulen om posterna är sorterade, vilka noder som kan vara underfulla eller till och med vad underfull betyder.Vi litar dock på några invarianter:
//
// - Träd måste ha enhetlig depth/height.Detta innebär att varje väg ner till ett blad från en given nod har exakt samma längd.
// - En nod med längden `n` har `n`-nycklar, `n`-värden och `n + 1`-kanter.
//   Detta innebär att även en tom nod har minst en edge.
//   För en bladnod betyder "having an edge" bara att vi kan identifiera en position i noden, eftersom bladkanterna är tomma och inte behöver någon datarepresentation.
// I en intern nod identifierar en edge både en position och innehåller en pekare till en underlig nod.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Den underliggande representationen av bladnoder och en del av representationen av interna noder.
struct LeafNode<K, V> {
    /// Vi vill vara kovarianta i `K` och `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Den här nodens index i föräldernodens `edges`-array.
    /// `*node.parent.edges[node.parent_idx]` borde vara samma sak som `node`.
    /// Detta garanteras bara att initialiseras när `parent` inte är null.
    parent_idx: MaybeUninit<u16>,

    /// Antalet nycklar och värden som denna nod lagrar.
    len: u16,

    /// Arrayer som lagrar den faktiska data för noden.
    /// Endast de första `len`-elementen i varje matris är initialiserade och giltiga.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Initierar en ny `LeafNode` på plats.
    unsafe fn init(this: *mut Self) {
        // Som en allmän policy lämnar vi fält ominitialiserade om de kan vara, eftersom detta borde vara både snabbare och lättare att spåra i Valgrind.
        //
        unsafe {
            // parent_idx, keys och vals är alla MaybeUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Skapar en ny boxad `LeafNode`.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Den underliggande representationen av interna noder.Som med `LeafNode` bör dessa döljas bakom`BoxedNode` för att förhindra att oinitialiserade nycklar och värden släpps.
/// Vilken som helst pekare till en `InternalNode` kan gjutas direkt till en pekare till den underliggande `LeafNode`-delen av noden, så att koden kan agera på blad-och interna noder generiskt utan att ens behöva kontrollera vilken av de två en pekare pekar på.
///
/// Den här egenskapen är aktiverad genom användning av `repr(C)`.
///
#[repr(C)]
// gdb_providers.py använder detta typnamn för introspektion.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Pekaren till barnen i denna nod.
    /// `len + 1` av dessa anses initialiserade och giltiga, förutom att nära slutet, medan trädet hålls genom lån typ `Dying`, hänger några av dessa pekare.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Skapar en ny `InternalNode` i box.
    ///
    /// # Safety
    /// En invariant av interna noder är att de har minst en initialiserad och giltig edge.
    /// Denna funktion ställer inte in en sådan edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Vi behöver bara initialisera data;kanterna är MaybeUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// En hanterad, icke-nollpekare till en nod.Detta är antingen en ägd pekare till `LeafNode<K, V>` eller en ägd pekare till `InternalNode<K, V>`.
///
/// `BoxedNode` innehåller dock ingen information om vilken av de två typerna av noder den faktiskt innehåller, och delvis på grund av denna brist på information, är den inte en separat typ och har ingen förstörare.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Rotnoden till ett ägt träd.
///
/// Observera att detta inte har en förstörare och måste rengöras manuellt.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Returnerar ett nytt ägt träd med sin egen rotnod som ursprungligen är tom.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` får inte vara noll.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Lånar mutabelt den ägda rotnoden.
    /// Till skillnad från `reborrow_mut` är detta säkert eftersom returvärdet inte kan användas för att förstöra roten, och det kan inte finnas andra referenser till trädet.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Lånar den ägda rotnoden något mutabelt.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Övergångsrikt övergår till en referens som tillåter genomgång och erbjuder destruktiva metoder och lite annat.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Lägger till en ny intern nod med en enda edge som pekar på den tidigare rotnoden, gör den nya noden till rotnoden och returnerar den.
    /// Detta ökar höjden med 1 och är motsatsen till `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, förutom att vi bara glömde att vi är interna nu:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Tar bort den interna rotnoden och använder sitt första underordnade som den nya rotnoden.
    /// Eftersom det endast är avsett att anropas när rotnoden bara har ett barn, görs ingen rensning på någon av tangenterna, värdena och andra barn.
    ///
    /// Detta minskar höjden med 1 och är motsatsen till `push_internal_level`.
    ///
    /// Kräver exklusiv åtkomst till `Root`-objektet men inte till rotnoden;
    /// det ogiltigförklarar inte andra handtag eller referenser till rotnoden.
    ///
    /// Panics om det inte finns någon intern nivå, dvs. om rotnoden är ett blad.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // SÄKERHET: vi hävdade att vi var interna.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // SÄKERHET: vi lånade `self` exklusivt och dess lånetyp är exklusiv.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // SÄKERHET: den första edge initialiseras alltid.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` är alltid kovariant i `K` och `V`, även när `BorrowType` är `Mut`.
// Detta är tekniskt fel men kan inte leda till osäkerhet på grund av intern användning av `NodeRef` eftersom vi förblir helt generiska över `K` och `V`.
//
// Men när en offentlig typ slår in `NodeRef`, se till att den har rätt varians.
//
/// En hänvisning till en nod.
///
/// Den här typen har ett antal parametrar som styr hur den fungerar:
/// - `BorrowType`: En dummy-typ som beskriver den typ av lån och bär en livstid.
///    - När detta är `Immut<'a>` fungerar `NodeRef` ungefär som `&'a Node`.
///    - När detta är `ValMut<'a>`, fungerar `NodeRef` ungefär som `&'a Node` med avseende på nycklar och trädstruktur, men tillåter också att många muterbara referenser till värden i hela trädet samexisterar.
///    - När detta är `Mut<'a>`, fungerar `NodeRef` ungefär som `&'a mut Node`, även om infogningsmetoder tillåter en muterbar pekare till ett värde att samexistera.
///    - När detta är `Owned` fungerar `NodeRef` ungefär som `Box<Node>`, men har ingen förstörare och måste rengöras manuellt.
///    - När detta är `Dying` fungerar `NodeRef` fortfarande ungefär som `Box<Node>`, men har metoder för att förstöra trädet bit för bit, och vanliga metoder, även om de inte är markerade som osäkra att ringa, kan åberopa UB om de anropas felaktigt.
///
///   Eftersom alla `NodeRef` tillåter navigering genom trädet gäller `BorrowType` effektivt för hela trädet, inte bara för själva noden.
/// - `K` och `V`: Det här är de typer av nycklar och värden som lagras i noderna.
/// - `Type`: Detta kan vara `Leaf`, `Internal` eller `LeafOrInternal`.
/// När detta är `Leaf` pekar `NodeRef` på en bladnod, när detta är `Internal` pekar `NodeRef` på en intern nod, och när detta är `LeafOrInternal` kan `NodeRef` peka på endera noden.
///   `Type` heter `NodeType` när den används utanför `NodeRef`.
///
/// Både `BorrowType` och `NodeType` begränsar vilka metoder vi implementerar för att utnyttja säkerhet av statisk typ.Det finns begränsningar i hur vi kan tillämpa sådana begränsningar:
/// - För varje typparameter kan vi bara definiera en metod antingen generiskt eller för en viss typ.
/// Vi kan till exempel inte definiera en metod som `into_kv` generiskt för alla `BorrowType`, eller en gång för alla typer som har en livstid, eftersom vi vill att den ska returnera `&'a`-referenser.
///   Därför definierar vi det endast för den minst kraftfulla typen `Immut<'a>`.
/// - Vi kan inte få implicit tvång från säg `Mut<'a>` till `Immut<'a>`.
///   Därför måste vi uttryckligen anropa `reborrow` på en mer kraftfull `NodeRef` för att nå en metod som `into_kv`.
///
/// Alla metoder på `NodeRef` som returnerar någon form av referens, antingen:
/// - Ta `self` efter värde och returnera `BorrowType` livslängd.
///   Ibland, för att åberopa en sådan metod, måste vi ringa `reborrow_mut`.
/// - Ta `self` som referens, och (implicitly) returnerar referensens livstid istället för den livstid som bärs av `BorrowType`.
/// På det sättet garanterar lånekontrollen att `NodeRef` förblir lånad så länge den returnerade referensen används.
///   Metoderna som stöder infoga böjer denna regel genom att returnera en rå pekare, dvs en referens utan någon livstid.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Antalet nivåer som noden och lövnivån är åtskilda, en konstant av noden som inte kan beskrivas helt av `Type` och som noden i sig inte lagrar.
    /// Vi behöver bara lagra rotnodens höjd och härleda alla andra noders höjd från den.
    /// Måste vara noll om `Type` är `Leaf` och inte noll om `Type` är `Internal`.
    ///
    ///
    height: usize,
    /// Pekaren till bladet eller den interna noden.
    /// Definitionen av `InternalNode` säkerställer att pekaren är giltig på något sätt.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Packa upp en nodreferens som var packad som `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Exponerar data för en intern nod.
    ///
    /// Returnerar en rå ptr för att undvika ogiltigförklaring av andra referenser till denna nod.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // SÄKERHET: den statiska nodtypen är `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Lånar exklusiv åtkomst till data för en intern nod.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Hitta längden på noden.Detta är antalet nycklar eller värden.
    /// Antalet kanter är `len() + 1`.
    /// Observera att trots att det är säkert kan anrop till den här funktionen ha den biverkan att ogiltigförklara mutabla referenser som osäker kod har skapat.
    ///
    pub fn len(&self) -> usize {
        // Avgörande är att vi bara kommer åt `len`-fältet här.
        // Om BorrowType är marker::ValMut kan det finnas utestående muterbara referenser till värden som vi inte får ogiltigförklara.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Returnerar antalet nivåer som noden och bladen är åtskilda.
    /// Noll höjd betyder att noden är ett blad i sig.
    /// Om du föreställer dig träd med roten överst, säger siffran vid vilken höjd noden visas.
    /// Om du föreställer dig träd med löv på toppen säger siffran hur högt trädet sträcker sig över noden.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Tar tillfälligt ut en annan, oföränderlig referens till samma nod.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Exponerar bladdelen av vilket blad eller intern nod som helst.
    ///
    /// Returnerar en rå ptr för att undvika ogiltigförklaring av andra referenser till denna nod.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Noden måste vara giltig för minst LeafNode-delen.
        // Det här är inte en referens i NodeRef-typen eftersom vi inte vet om den ska vara unik eller delad.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Hitta föräldern till den aktuella noden.
    /// Returnerar `Ok(handle)` om den aktuella noden faktiskt har en överordnad, där `handle` pekar på edge för den överordnade som pekar på den aktuella noden.
    ///
    /// Returnerar `Err(self)` om den aktuella noden inte har någon förälder, vilket ger tillbaka `NodeRef`-originalet.
    ///
    /// Metodnamnet förutsätter att du bildar träd med rotnoden överst.
    ///
    /// `edge.descend().ascend().unwrap()` och `node.ascend().unwrap().descend()` borde båda, efter framgång, inte göra någonting.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Vi måste använda råa pekare till noder eftersom, om BorrowType är marker::ValMut, kan det finnas enastående muterbara referenser till värden som vi inte får ogiltigförklara.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Observera att `self` måste vara obefintlig.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Observera att `self` måste vara obefintlig.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Exponerar bladdelen av vilket blad eller intern nod som helst i ett oföränderligt träd.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // SÄKERHET: det kan inte finnas några förändringsbara referenser till detta träd som lånas som `Immut`.
        unsafe { &*ptr }
    }

    /// Lånar en vy till nycklarna som är lagrade i noden.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Liknar `ascend`, får en referens till en nods överordnade nod, men också omplacerar den aktuella noden i processen.
    /// Detta är osäkert eftersom den nuvarande noden fortfarande kommer att vara tillgänglig trots att den är omplacerad.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Säkerställer osäker för kompilatorn den statiska informationen att denna nod är en `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Säkerställer osäker för kompilatorn den statiska informationen att denna nod är en `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Tar tillfälligt ut en annan, muterbar referens till samma nod.Observera, eftersom denna metod är mycket farlig, dubbelt så eftersom den kanske inte omedelbart verkar farlig.
    ///
    /// Eftersom föränderliga pekare kan ströva överallt runt trädet, kan den returnerade pekaren enkelt användas för att göra den ursprungliga pekaren dinglande, utanför gränserna eller ogiltig enligt staplade låneregler.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) överväga att lägga till ytterligare en typparameter till `NodeRef` som begränsar användningen av navigeringsmetoder på återlästa pekare, vilket förhindrar denna osäkerhet.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Lånar exklusiv åtkomst till bladdelen i vilket blad eller intern nod som helst.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // SÄKERHET: vi har exklusiv tillgång till hela noden.
        unsafe { &mut *ptr }
    }

    /// Erbjuder exklusiv tillgång till bladdelen i vilket blad eller intern nod som helst.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // SÄKERHET: vi har exklusiv tillgång till hela noden.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Lånar exklusiv åtkomst till ett element i nyckellagringsområdet.
    ///
    /// # Safety
    /// `index` är inom gränserna 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // SÄKERHET: den som ringer kan inte anropa ytterligare metoder på egen hand
        // tills nyckelbitreferensen tappas, eftersom vi har unik tillgång under lånets hela livstid.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Lånar exklusiv åtkomst till ett element eller en del av nodens värdelagringsområde.
    ///
    /// # Safety
    /// `index` är inom gränserna 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // SÄKERHET: den som ringer kan inte anropa ytterligare metoder på egen hand
        // tills värdeskivreferensen tappas, eftersom vi har unik tillgång under lånets hela livstid.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Lånar exklusiv åtkomst till ett element eller en del av nodens lagringsområde för edge-innehåll.
    ///
    /// # Safety
    /// `index` ligger inom gränserna 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // SÄKERHET: den som ringer kan inte anropa ytterligare metoder på egen hand
        // tills edge-skivreferensen tappas, eftersom vi har unik åtkomst under lånets livstid.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Noden har mer än `idx` initialiserade element.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Vi skapar bara en referens till det element som vi är intresserade av, för att undvika alias med enastående referenser till andra element, i synnerhet de som återvände till den som ringer i tidigare iterationer.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Vi måste tvinga osorterade arraypekare på grund av Rust-utgåvan #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Lånar exklusiv åtkomst till nodens längd.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Ställer in nodens länk till dess överordnade edge utan att ogiltigförklara andra referenser till noden.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Rensar rotens länk till dess överordnade edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Lägger till ett nyckel-värdepar i slutet av noden.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Varje artikel som returneras av `range` är ett giltigt edge-index för noden.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Lägger till ett nyckel-värdepar och en edge för att gå till höger om det paret, till slutet av noden.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Kontrollerar om en nod är en `Internal`-nod eller en `Leaf`-nod.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// En referens till ett specifikt nyckel-värdepar eller edge inom en nod.
/// `Node`-parametern måste vara en `NodeRef`, medan `Type` antingen kan vara `KV` (betyder ett handtag på ett nyckel-värdepar) eller `Edge` (betyder ett handtag på en edge).
///
/// Observera att även `Leaf`-noder kan ha `Edge`-handtag.
/// Istället för att representera en pekare till en barnnod representerar dessa de utrymmen där barnpekare skulle gå mellan nyckel-värdeparen.
/// Till exempel, i en nod med längd 2 skulle det finnas 3 möjliga edge-platser, en till vänster om noden, en mellan de två paren och en till höger om noden.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Vi behöver inte `#[derive(Clone)]` fullständiga, eftersom den enda gången `Node` kommer att vara 'Clone' är när det är en oföränderlig referens och därför `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Hämtar noden som innehåller edge eller nyckel-värdeparet som detta handtag pekar på.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Returnerar positionen för detta handtag i noden.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Skapar ett nytt handtag till ett nyckel-värdepar i `node`.
    /// Osäkert eftersom den som ringer måste se till att `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Kan vara en offentlig implementering av PartialEq, men används endast i den här modulen.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Tar tillfälligt ut ett annat, oföränderligt handtag på samma plats.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Vi kan inte använda Handle::new_kv eller Handle::new_edge eftersom vi inte känner till vår typ
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Säkerställer osäker för kompilatorn den statiska informationen att handtagets nod är en `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Tar tillfälligt ut ett annat, föränderligt handtag på samma plats.
    /// Observera, eftersom denna metod är mycket farlig, dubbelt så eftersom den kanske inte omedelbart verkar farlig.
    ///
    ///
    /// Mer information finns i `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Vi kan inte använda Handle::new_kv eller Handle::new_edge eftersom vi inte känner till vår typ
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Skapar ett nytt handtag till en edge i `node`.
    /// Osäkert eftersom den som ringer måste se till att `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Med tanke på ett edge-index där vi vill infoga i en nod fylld till kapacitet, beräknar ett förnuftigt KV-index för en delningspunkt och var man ska utföra insättningen.
///
/// Målet med delningspunkten är att dess nyckel och värde hamnar i en föräldernod;
/// tangenterna, värdena och kanterna till vänster om delningspunkten blir det vänstra barnet;
/// tangenterna, värdena och kanterna till höger om delningspunkten blir rätt barn.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust nummer #74834 försöker förklara dessa symmetriska regler.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Infogar ett nytt nyckel-värdepar mellan nyckel-värdeparen till höger och vänster om denna edge.
    /// Denna metod förutsätter att det finns tillräckligt med utrymme i noden för att det nya paret ska passa.
    ///
    /// Den returnerade pekaren pekar på det infogade värdet.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Infogar ett nytt nyckel-värdepar mellan nyckel-värdeparen till höger och vänster om denna edge.
    /// Den här metoden delar upp noden om det inte finns tillräckligt med utrymme.
    ///
    /// Den returnerade pekaren pekar på det infogade värdet.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Fixar överordnad pekare och index i den underordnade noden som den här edge länkar till.
    /// Detta är användbart när kanternas ordning har ändrats,
    fn correct_parent_link(self) {
        // Skapa backpointer utan att ogiltigförklara andra referenser till noden.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Infogar ett nytt nyckel-värdepar och ett edge som går till höger om det nya paret mellan detta edge och nyckel-värdeparet till höger om detta edge.
    /// Denna metod förutsätter att det finns tillräckligt med utrymme i noden för att det nya paret ska passa.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Infogar ett nytt nyckel-värdepar och ett edge som går till höger om det nya paret mellan detta edge och nyckel-värdeparet till höger om detta edge.
    /// Den här metoden delar upp noden om det inte finns tillräckligt med utrymme.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Infogar ett nytt nyckel-värdepar mellan nyckel-värdeparen till höger och vänster om denna edge.
    /// Den här metoden delar upp noden om det inte finns tillräckligt med utrymme och försöker sätta in den delade delen i modernoden rekursivt tills roten nås.
    ///
    ///
    /// Om det returnerade resultatet är en `Fit` kan handtagsnoden vara den här edge-noden eller en förfader.
    /// Om det returnerade resultatet är ett `Split` kommer fältet `left` att vara rotnoden.
    /// Den returnerade pekaren pekar på det infogade värdet.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Hitta den nod som denna edge pekar på.
    ///
    /// Metodnamnet förutsätter att du bildar träd med rotnoden överst.
    ///
    /// `edge.descend().ascend().unwrap()` och `node.ascend().unwrap().descend()` borde båda, efter framgång, inte göra någonting.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Vi måste använda råa pekare till noder eftersom, om BorrowType är marker::ValMut, kan det finnas enastående muterbara referenser till värden som vi inte får ogiltigförklara.
        // Det finns ingen oro för att komma åt höjdfältet eftersom det värdet kopieras.
        // Var uppmärksam på att när nodpekaren väl har hänvisats till åtkomst till kanterna med en referens (Rust utfärdar #73987) och ogiltigförklarar alla andra referenser till eller inuti matrisen, om det skulle finnas någon.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Vi kan inte anropa separata nyckel-och värdemetoder, för att anropa den andra ogiltigförklarar referensen som returneras av den första.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Byt ut nyckeln och värdet som KV-handtaget hänvisar till.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Hjälper implementeringar av `split` för en viss `NodeType` genom att ta hand om bladdata.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Delar den underliggande noden i tre delar:
    ///
    /// - Noden trunkeras för att endast innehålla nyckel-värdepar till vänster om detta handtag.
    /// - Nyckeln och värdet som detta handtag pekar på extraheras.
    /// - Alla nyckel-värdepar till höger om detta handtag placeras i en ny tilldelad nod.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Tar bort det nyckel-värdepar som detta handtag pekar på och returnerar det tillsammans med edge som nyckel-värdeparet kollapsade in i.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Delar den underliggande noden i tre delar:
    ///
    /// - Noden trunkeras för att endast innehålla kanterna och nyckel-värdepar till vänster om detta handtag.
    /// - Nyckeln och värdet som detta handtag pekar på extraheras.
    /// - Alla kanter och nyckel-värdepar till höger om detta handtag placeras i en ny tilldelad nod.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Representerar en session för att utvärdera och utföra en balanseringsoperation kring ett internt nyckel-värdepar.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Väljer ett balanserande sammanhang som involverar noden som barn, därmed mellan KV direkt till vänster eller till höger i föräldernoden.
    /// Returnerar en `Err` om det inte finns någon förälder.
    /// Panics om föräldern är tom.
    ///
    /// Föredrar vänster sida, för att vara optimal om den givna noden på något sätt är för full, vilket betyder här bara att den har färre element än sitt vänstra syskon och än dess högra syskon, om de finns.
    /// I så fall går det snabbare att slå ihop med vänster syskon, eftersom vi bara behöver flytta nodens N-element istället för att flytta dem åt höger och flytta mer än N-element framåt.
    /// Att stjäla från vänster syskon är också typiskt snabbare, eftersom vi bara behöver flytta nodens N-element till höger, istället för att flytta åtminstone N av syskonens element till vänster.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Returnerar om sammanslagning är möjlig, dvs om det finns tillräckligt med utrymme i en nod för att kombinera den centrala KV med båda intilliggande barnnoder.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Utför en sammanslagning och låter en avslutning avgöra vad som ska returneras.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // SÄKERHET: höjden på noder som slås samman ligger en under höjden
                // av noden på denna edge, alltså över noll, så de är interna.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Sammanfogar förälderns nyckel-värdepar och båda angränsande underordnade noder i den vänstra underordnade noden och returnerar den krympta föräldernoden.
    ///
    ///
    /// Panics om vi inte `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Sammanfogar förälderns nyckel-värdepar och båda angränsande underordnade noder i den vänstra barnnoden och returnerar den underordnade noden.
    ///
    ///
    /// Panics om vi inte `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Slår samman föräldrarnas nyckel-värdepar och båda intilliggande barnnoder i den vänstra barnnoden och returnerar edge-handtaget i den barnnoden där det spårade barnet edge hamnade,
    ///
    ///
    /// Panics om vi inte `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Tar bort ett nyckel-värdepar från det vänstra barnet och placerar det i nyckel-värdet för föräldern, samtidigt som det gamla överordnade nyckel-värde-paret skjuts in i det högra barnet.
    ///
    /// Returnerar ett handtag till edge i rätt barn motsvarande där originalet edge som specificerats av `track_right_edge_idx` hamnade.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Tar bort ett nyckel-värde-par från det högra barnet och placerar det i nyckel-värdet lagring av föräldern, medan du trycker det gamla överordnade nyckel-värde-paret till vänster barnet.
    ///
    /// Returnerar ett handtag till edge i det vänstra barnet som anges av `track_left_edge_idx`, som inte rörde sig.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Detta stjäl liknar `steal_left` men stjäl flera element samtidigt.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Se till att vi kan stjäla säkert.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Flytta bladdata.
            {
                // Gör plats för stulna element i rätt barn.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Flytta element från vänster barn till höger.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Flytta det mest stulna paret till vänster till föräldern.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Flytta föräldrars nyckel-värdepar till rätt barn.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Gör plats för stulna kanter.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Stjäl kanter.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Den symmetriska klonen av `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Se till att vi kan stjäla säkert.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Flytta bladdata.
            {
                // Flytta det mest stulna paret till föräldern.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Flytta föräldrars nyckel-värdepar till vänster barnet.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Flytta element från höger barn till vänster.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Fyll luckan där stulna element brukade vara.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Stjäl kanter.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Fyll luckan där stulna kanter brukade vara.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Tar bort all statisk information som hävdar att denna nod är en `Leaf`-nod.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Tar bort all statisk information som hävdar att denna nod är en `Internal`-nod.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Kontrollerar om den underliggande noden är en `Internal`-nod eller en `Leaf`-nod.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Flytta suffixet efter `self` från en nod till en annan.`right` måste vara tomt.
    /// Den första edge på `right` förblir oförändrad.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Resultat av insättning, när en nod behövde utvidgas utöver dess kapacitet.
pub struct SplitResult<'a, K, V, NodeType> {
    // Ändrad nod i befintligt träd med element och kanter som hör till vänster om `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Någon nyckel och värde delas av för att infogas någon annanstans.
    pub kv: (K, V),
    // Ägd, fristående, ny nod med element och kanter som hör till höger om `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Huruvida nodreferenser av denna låntyp tillåter överföring till andra noder i trädet.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal behövs inte, det händer med resultatet av `borrow_mut`.
        // Genom att inaktivera korsning och bara skapa nya referenser till rötter vet vi att varje referens av typen `Owned` är till en rotnod.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Infogar ett värde i en bit initialiserade element följt av ett oinitialiserat element.
///
/// # Safety
/// Skivan har mer än `idx`-element.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Tar bort och returnerar ett värde från en del av alla initialiserade element och lämnar ett efterföljande oinitialiserat element.
///
///
/// # Safety
/// Skivan har mer än `idx`-element.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Skiftar elementen i en bit `distance`-positioner åt vänster.
///
/// # Safety
/// Skivan har minst `distance`-element.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Förskjuter elementen i en bit `distance`-positioner till höger.
///
/// # Safety
/// Skivan har minst `distance`-element.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Flyttar alla värden från en bit initialiserade element till en bit av oinitialiserade element och lämnar `src` kvar som alla oinitialiserade.
///
/// Fungerar som `dst.copy_from_slice(src)` men kräver inte att `T` är `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;