use core::intrinsics;
use core::mem;
use core::ptr;

/// Detta ersätter värdet bakom `v` unika referens genom att anropa relevant funktion.
///
///
/// Om en panic uppstår i `change`-stängningen avbryts hela processen.
#[allow(dead_code)] // behåll som illustration och för användning future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Detta ersätter värdet bakom `v` unika referens genom att anropa relevant funktion och returnerar ett resultat som erhållits under vägen.
///
///
/// Om en panic uppstår i `change`-stängningen avbryts hela processen.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}