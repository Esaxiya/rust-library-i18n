use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modellerar en återlämning av någon unik referens, när du vet att återlämningen och alla dess ättlingar (dvs. alla pekare och referenser härledda från den) inte kommer att användas längre någon gång, varefter du vill använda den ursprungliga unika referensen igen .
///
///
/// Lånekontrollen hanterar vanligtvis denna stapling av lån för dig, men vissa kontrollflöden som åstadkommer denna stapling är för komplicerade för att kompilatorn ska kunna följa.
/// Med en `DormantMutRef` kan du själv kontrollera upplåning medan du fortfarande uttrycker sin staplade natur och inkapslar den råa pekarkoden som behövs för att göra detta utan odefinierat beteende.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Fånga ett unikt lån och omlåna det omedelbart.
    /// För kompilatorn är den nya referensens livslängd densamma som den ursprungliga referensens livslängd, men du promise för att använda den under en kortare period.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SÄKERHET: vi håller lånet hela 'a via `_marker`, och vi exponerar
        // bara denna referens, så den är unik.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Återgå till det unika lån som ursprungligen fångats.
    ///
    /// # Safety
    ///
    /// Återlämningen måste ha avslutats, dvs den referens som returneras av `new` och alla pekare och referenser härledda från den, får inte användas längre.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // SÄKERHET: våra egna säkerhetsförhållanden innebär att denna referens återigen är unik.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;