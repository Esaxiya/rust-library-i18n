use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Lägger till alla nyckel-värde-par från sammansättningen av två stigande iteratorer och ökar en `length`-variabel längs vägen.Det senare gör det lättare för den som ringer att undvika läckage när en dropphanterare går i panik.
    ///
    /// Om båda iteratorerna producerar samma tangent, tappar den här metoden paret från vänster iterator och lägger till paret från höger iterator.
    ///
    /// Om du vill att trädet ska hamna i en strikt stigande ordning, som för en `BTreeMap`, bör båda iteratorerna producera nycklar i strikt stigande ordning, var och en större än alla nycklar i trädet, inklusive alla nycklar som redan finns i trädet vid inträde.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Vi förbereder oss för att slå samman `left` och `right` till en sorterad sekvens i linjär tid.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Under tiden bygger vi ett träd från den sorterade sekvensen i linjär tid.
        self.bulk_push(iter, length)
    }

    /// Skjuter alla nyckel-värdepar till slutet av trädet och ökar en `length`-variabel längs vägen.
    /// Det senare gör det lättare för den som ringer att undvika läckage när iteratorn går i panik.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Iterera genom alla nyckel-värdepar och tryck in dem i noder på rätt nivå.
        for (key, value) in iter {
            // Försök att trycka på nyckel-värdepar i den aktuella bladnoden.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Inget utrymme kvar, gå upp och tryck dit.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Hittade en nod med utrymme kvar, tryck här.
                                open_node = parent;
                                break;
                            } else {
                                // Gå upp igen.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Vi är högst upp, skapar en ny rotnod och trycker dit.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Tryck på nyckel-värde-paret och det nya högra underträdet.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Gå ner till det högra bladet igen.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Öka längden för varje iteration för att se till att kartan tappar de bifogade elementen, även om iteratorn går vidare.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// En iterator för att slå samman två sorterade sekvenser till en
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Om två nycklar är lika, returnerar nyckel-värdeparet från rätt källa.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}