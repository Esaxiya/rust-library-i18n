//! Enkeltrådiga referensräknarpekare.'Rc' står för 'Reference
//! Counted'.
//!
//! Typen [`Rc<T>`][`Rc`] tillhandahåller delat ägande av ett värde av typen `T`, tilldelat i högen.
//! Att anropa [`clone`][clone] på [`Rc`] producerar en ny pekare till samma tilldelning i högen.
//! När den sista [`Rc`]-pekaren till en given tilldelning förstörs, tappas också värdet som lagras i den allokeringen (ofta kallad "inner value").
//!
//! Delade referenser i Rust tillåter inte mutation som standard, och [`Rc`] är inget undantag: du kan generellt inte få en mutbar referens till något inuti en [`Rc`].
//! Om du behöver ändra, placera en [`Cell`] eller [`RefCell`] inuti [`Rc`];se [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] använder icke-atomreferensräkning.
//! Det betyder att omkostnaderna är mycket låga, men en [`Rc`] kan inte skickas mellan trådarna och [`Rc`] implementerar därför inte [`Send`][send].
//! Som ett resultat kommer Rust-kompilatorn att kontrollera *vid sammanställningstid* att du inte skickar [`Rc`] mellan trådarna.
//! Om du behöver flertrådad, atomreferensräkning, använd [`sync::Arc`][arc].
//!
//! [`downgrade`][downgrade]-metoden kan användas för att skapa en icke-ägande [`Weak`]-pekare.
//! En [`Weak`]-pekare kan [[uppgradera]][uppgradera] d till en [`Rc`], men detta kommer att returnera [`None`] om värdet som lagrats i allokeringen redan har tappats.
//! Med andra ord, `Weak`-pekare håller inte värdet i tilldelningen vid liv.emellertid håller de * levande tilldelningen (stödbutiken för det inre värdet).
//!
//! En cykel mellan [`Rc`]-pekare kommer aldrig att omplaceras.
//! Av denna anledning används [`Weak`] för att bryta cykler.
//! Till exempel kan ett träd ha starka [`Rc`]-pekare från föräldernoder till barn och [`Weak`]-pekare från barn tillbaka till sina föräldrar.
//!
//! `Rc<T>` automatisk hänvisningar till `T` (via [`Deref`] trait), så att du kan anropa 'T' metoder för ett värde av typen [`Rc<T>`][`Rc`].
//! För att undvika namnkollisioner med `T`s metoder är metoderna för [`Rc<T>`][`Rc`] i sig associerade funktioner, kallade med [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>Implementeringar av traits som `Clone` kan också kallas med fullt kvalificerad syntax.
//! Vissa människor föredrar att använda fullt kvalificerad syntax, medan andra föredrar att använda metod-samtalsyntax.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Metod-samtalsyntax
//! let rc2 = rc.clone();
//! // Fullt kvalificerad syntax
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] gör inte autodereferens till `T`, eftersom det inre värdet redan har tappats.
//!
//! # Kloning av referenser
//!
//! Skapa en ny referens till samma allokering som en befintlig referensräknad pekare görs med `Clone` trait implementerad för [`Rc<T>`][`Rc`] och [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // De två syntaxerna nedan är ekvivalenta.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a och b båda pekar på samma minnesplats som foo.
//! ```
//!
//! `Rc::clone(&from)`-syntaxen är den mest idiomatiska eftersom den förmedlar mer tydligt innebörden av koden.
//! I exemplet ovan gör denna syntax det lättare att se att den här koden skapar en ny referens snarare än att kopiera hela innehållet i foo.
//!
//! # Examples
//!
//! Tänk på ett scenario där en uppsättning `Gadget`s ägs av en given `Owner`.
//! Vi vill att vår "Gadget" pekar på deras `Owner`.Vi kan inte göra detta med unikt ägande, eftersom mer än en gadget kan tillhöra samma `Owner`.
//! [`Rc`] tillåter oss att dela en `Owner` mellan flera "Gadget's", och har `Owner` kvar allokerad så länge som alla `Gadget`-poäng på den.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... andra fält
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... andra fält
//! }
//!
//! fn main() {
//!     // Skapa en referensräknad `Owner`.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Skapa "Gadget" som tillhör `gadget_owner`.
//!     // Kloning av `Rc<Owner>` ger oss en ny pekare till samma `Owner`-allokering, vilket ökar referensantalet i processen.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Kassera vår lokala variabel `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Trots att vi tappar `gadget_owner` kan vi fortfarande skriva ut namnet på `Owner` på `Gadget`s.
//!     // Det beror på att vi bara har tappat en enda `Rc<Owner>`, inte `Owner` den pekar på.
//!     // Så länge det finns andra `Rc<Owner>` som pekar på samma `Owner`-tilldelning kommer den att förbli live.
//!     // Fältprojektionen `gadget1.owner.name` fungerar eftersom `Rc<Owner>` automatiskt hänvisar till `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // I slutet av funktionen förstörs `gadget1` och `gadget2` och med dem de senast räknade referenserna till vår `Owner`.
//!     // Gadget Man förstörs nu också.
//!     //
//! }
//! ```
//!
//! Om våra krav ändras och vi också måste kunna korsa från `Owner` till `Gadget`, kommer vi att stöta på problem.
//! En [`Rc`]-pekare från `Owner` till `Gadget` introducerar en cykel.
//! Detta innebär att deras referensräkningar aldrig kan nå 0, och tilldelningen kommer aldrig att förstöras:
//! en minnesläcka.För att komma runt detta kan vi använda [`Weak`]-pekare.
//!
//! Rust gör det faktiskt lite svårt att producera den här slingan i första hand.För att få två värden som pekar på varandra måste ett av dem vara mutabelt.
//! Detta är svårt eftersom [`Rc`] förstärker minnessäkerheten genom att bara ge delade referenser till det värde som den omsluter, och dessa tillåter inte direkt mutation.
//! Vi måste slå in den del av värdet vi vill mutera i en [`RefCell`], som ger *inre mutabilitet*: en metod för att uppnå mutabilitet genom en delad referens.
//! [`RefCell`] verkställer Rust s låneregler vid körning.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... andra fält
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... andra fält
//! }
//!
//! fn main() {
//!     // Skapa en referensräknad `Owner`.
//!     // Observera att vi har placerat `Ägarens vector av` Gadget`s inuti en `RefCell` så att vi kan mutera den genom en delad referens.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Skapa "Gadget" som tillhör `gadget_owner`, som tidigare.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Lägg till "Gadget" till deras `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` dynamiska lån slutar här.
//!     }
//!
//!     // Iterera över våra "Gadget" och skriva ut deras detaljer.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` är en `Weak<Gadget>`.
//!         // Eftersom `Weak`-pekare inte kan garantera att allokeringen fortfarande finns, måste vi ringa `upgrade`, som returnerar en `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // I det här fallet vet vi att allokeringen fortfarande existerar, så vi `unwrap` `Option`.
//!         // I ett mer komplicerat program kan du behöva graciös felhantering för ett `None`-resultat.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // I slutet av funktionen förstörs `gadget_owner`, `gadget1` och `gadget2`.
//!     // Det finns nu inga starka (`Rc`)-pekare till prylarna, så de förstörs.
//!     // Detta nollställer referensräkningen på Gadget Man, så han blir också förstörd.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Detta är repr(C) till future-säkert mot möjlig fältbeställning, vilket skulle störa den annars säkra [into|from]_raw() av transmuterbara inre typer.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// En referensräknarpekare med en gänga.'Rc' står för 'Reference
/// Counted'.
///
/// Se [module-level documentation](./index.html) för mer information.
///
/// De inneboende metoderna för `Rc` är alla associerade funktioner, vilket innebär att du måste anropa dem som t.ex. [`Rc::get_mut(&mut value)`][get_mut] istället för `value.get_mut()`.
/// Detta undviker konflikter med metoder av den inre typen `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Denna osäkerhet är ok, för medan denna Rc lever är vi garanterade att den inre pekaren är giltig.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Konstruerar en ny `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Det finns en implicit svag pekare som ägs av alla starka pekare, vilket säkerställer att den svaga förstöraren aldrig frigör allokeringen medan den starka förstöraren kör, även om den svaga pekaren lagras inuti den starka.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Konstruerar en ny `Rc<T>` med en svag referens till sig själv.
    /// Att försöka uppgradera den svaga referensen innan den här funktionen returnerar kommer att resultera i ett `None`-värde.
    ///
    /// Emellertid kan den svaga referensen klonas fritt och lagras för användning vid ett senare tillfälle.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... fler fält
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Konstruera det inre i "uninitialized"-tillståndet med en enda svag referens.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Det är viktigt att vi inte ger upp äganderätten till den svaga pekaren, annars kan minnet frigöras när `data_fn` återvänder.
        // Om vi verkligen ville passera ägandet kunde vi skapa en ytterligare svag pekare för oss själva, men detta skulle resultera i ytterligare uppdateringar av det svaga referensantalet som annars inte skulle vara nödvändigt.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Starka referenser bör tillsammans äga en delad svag referens, så kör inte förstöraren för vår gamla svaga referens.
        //
        mem::forget(weak);
        strong
    }

    /// Konstruerar en ny `Rc` med oinitialiserat innehåll.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Uppskjuten initialisering:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstruerar en ny `Rc` med oinitialiserat innehåll, där minnet fylls med `0` byte.
    ///
    ///
    /// Se [`MaybeUninit::zeroed`][zeroed] för exempel på korrekt och felaktig användning av denna metod.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstruerar en ny `Rc<T>` och returnerar ett fel om allokeringen misslyckas
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Det finns en implicit svag pekare som ägs av alla starka pekare, vilket säkerställer att den svaga förstöraren aldrig frigör allokeringen medan den starka förstöraren kör, även om den svaga pekaren lagras inuti den starka.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Konstruerar en ny `Rc` med oinitialiserat innehåll och returnerar ett fel om allokeringen misslyckas
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Uppskjuten initialisering:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Konstruerar en ny `Rc` med oinitialiserat innehåll, där minnet fylls med `0`-byte, vilket returnerar ett fel om allokeringen misslyckas
    ///
    ///
    /// Se [`MaybeUninit::zeroed`][zeroed] för exempel på korrekt och felaktig användning av denna metod.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Konstruerar en ny `Pin<Rc<T>>`.
    /// Om `T` inte implementerar `Unpin` kommer `value` att fästas i minnet och kan inte flyttas.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Returnerar det inre värdet om `Rc` har exakt en stark referens.
    ///
    /// Annars returneras en [`Err`] med samma `Rc` som skickades in.
    ///
    ///
    /// Detta kommer att lyckas även om det finns enastående svaga referenser.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // kopiera det innehållna objektet

                // Ange för Weaks att de inte kan marknadsföras genom att minska det starka antalet och ta sedan bort den implicita "strong weak"-pekaren samtidigt som du hanterar dropplogik genom att bara skapa en falsk svag.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Konstruerar en ny referensräknad skiva med oinitialiserat innehåll.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Uppskjuten initialisering:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Konstruerar en ny referensräknad skiva med oinitialiserat innehåll, där minnet fylls med `0` byte.
    ///
    ///
    /// Se [`MaybeUninit::zeroed`][zeroed] för exempel på korrekt och felaktig användning av denna metod.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Konverterar till `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Som med [`MaybeUninit::assume_init`] är det upp till den som ringer att garantera att det inre värdet verkligen är i ett initialiserat tillstånd.
    ///
    /// Att ringa detta när innehållet ännu inte är fullständigt initierat orsakar omedelbart odefinierat beteende.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Uppskjuten initialisering:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Konverterar till `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Som med [`MaybeUninit::assume_init`] är det upp till den som ringer att garantera att det inre värdet verkligen är i ett initialiserat tillstånd.
    ///
    /// Att ringa detta när innehållet ännu inte är fullständigt initierat orsakar omedelbart odefinierat beteende.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Uppskjuten initialisering:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Förbrukar `Rc` och returnerar den inslagna pekaren.
    ///
    /// För att undvika minnesläckage måste pekaren konverteras tillbaka till en `Rc` med [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Ger en rå pekare till data.
    ///
    /// Räkningarna påverkas inte på något sätt och `Rc` förbrukas inte.
    /// Pekaren är giltig så länge det finns starka räkningar i `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // SÄKERHET: Detta kan inte gå igenom Deref::deref eller Rc::inner eftersom
        // detta krävs för att behålla raw/mut härkomst så att t.ex.
        // `get_mut` kan skriva genom pekaren efter att Rc har återställts genom `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Konstruerar en `Rc<T>` från en rå pekare.
    ///
    /// Den råa pekaren måste tidigare ha returnerats av ett samtal till [`Rc<U>::into_raw`][into_raw] där `U` måste ha samma storlek och justering som `T`.
    /// Detta stämmer trivialt om `U` är `T`.
    /// Observera att om `U` inte är `T` men har samma storlek och inriktning, är det i princip som att transmittera referenser av olika slag.
    /// Se [`mem::transmute`][transmute] för mer information om vilka begränsningar som gäller i det här fallet.
    ///
    /// Användaren av `from_raw` måste se till att ett specifikt värde på `T` bara tappas en gång.
    ///
    /// Denna funktion är osäker eftersom felaktig användning kan leda till minnesosäkerhet, även om den returnerade `Rc<T>` aldrig nås.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Konvertera tillbaka till en `Rc` för att förhindra läckage.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Ytterligare samtal till `Rc::from_raw(x_ptr)` skulle vara minnesfarliga.
    /// }
    ///
    /// // Minnet frigjordes när `x` gick utanför ramen ovan, så `x_ptr` dinglar nu!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Omvänd offset för att hitta original RcBox.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Skapar en ny [`Weak`]-pekare till den här allokeringen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Se till att vi inte skapar en dinglande svag
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Hämtar antalet [`Weak`]-pekare till denna fördelning.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Får antalet starka (`Rc`)-pekare till denna fördelning.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Returnerar `true` om det inte finns några andra `Rc`-eller [`Weak`]-pekare till den här allokeringen.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Returnerar en muterbar referens till den angivna `Rc` om det inte finns några andra `Rc`-eller [`Weak`]-pekare till samma allokering.
    ///
    ///
    /// Returnerar [`None`] annars eftersom det inte är säkert att mutera ett delat värde.
    ///
    /// Se även [`make_mut`][make_mut], som kommer att [`clone`][clone] det inre värdet när det finns andra pekare.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Returnerar en muterbar referens till den angivna `Rc` utan någon kontroll.
    ///
    /// Se även [`get_mut`], som är säkert och gör lämpliga kontroller.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Alla andra `Rc`-eller [`Weak`]-pekare till samma fördelning får inte hänvisas till under den återlämnade lånen.
    ///
    /// Detta är triviellt fallet om inga sådana pekare finns, till exempel direkt efter `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Vi är noga med att *inte* skapa en referens som täcker "count"-fälten, eftersom detta skulle strida mot åtkomst till referensräkningarna (t.ex.
        // av `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Returnerar `true` om de två `Rc`erna pekar på samma allokering (i en ven som liknar [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Gör en förändrad referens till den givna `Rc`.
    ///
    /// Om det finns andra `Rc`-pekare till samma allokering kommer `make_mut` att [`clone`] det inre värdet till en ny allokering för att säkerställa unikt ägande.
    /// Detta kallas också klon-på-skriv.
    ///
    /// Om det inte finns några andra `Rc`-pekare till den här allokeringen kommer [`Weak`]-pekare att kopplas bort.
    ///
    /// Se även [`get_mut`], som misslyckas snarare än kloning.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Kommer inte att klona någonting
    /// let mut other_data = Rc::clone(&data);    // Kommer inte att klona inre data
    /// *Rc::make_mut(&mut data) += 1;        // Klonar inre data
    /// *Rc::make_mut(&mut data) += 1;        // Kommer inte att klona någonting
    /// *Rc::make_mut(&mut other_data) *= 2;  // Kommer inte att klona någonting
    ///
    /// // Nu pekar `data` och `other_data` på olika tilldelningar.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] pekare kommer att avskiljas:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Måste klona data, det finns andra RC-enheter.
            // Fördela minne så att du kan skriva det klonade värdet direkt.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Kan bara stjäla data, allt som finns kvar är Svagheter
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Ta bort implicit stark-svag ref (inget behov av att skapa en falsk svag här-vi vet att andra svagheter kan städa upp för oss)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Denna osäkerhet är ok eftersom vi är garanterade att pekaren som returneras är den *enda* pekaren som någonsin kommer att returneras till T.
        // Vårt referensantal är garanterat 1 vid denna tidpunkt, och vi krävde att `Rc<T>` själv var `mut`, så vi returnerar den enda möjliga referensen till tilldelningen.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Försök att nedkasta `Rc<dyn Any>` till en konkret typ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Tilldelar en `RcBox<T>` med tillräckligt med utrymme för ett eventuellt osorterat inre värde där värdet har layouten.
    ///
    /// Funktionen `mem_to_rcbox` anropas med datapekaren och måste returnera en (potentiellt fet)-pekare för `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Beräkna layouten med den angivna värdelayouten.
        // Tidigare beräknades layout på uttrycket `&*(ptr as* const RcBox<T>)`, men detta skapade en felinriktad referens (se #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Tilldelar en `RcBox<T>` med tillräckligt med utrymme för ett eventuellt osorterat inre värde där värdet har den angivna layouten, vilket returnerar ett fel om allokeringen misslyckas.
    ///
    ///
    /// Funktionen `mem_to_rcbox` anropas med datapekaren och måste returnera en (potentiellt fet)-pekare för `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Beräkna layouten med den angivna värdelayouten.
        // Tidigare beräknades layout på uttrycket `&*(ptr as* const RcBox<T>)`, men detta skapade en felinriktad referens (se #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Allokera för layouten.
        let ptr = allocate(layout)?;

        // Initiera RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Tilldelar en `RcBox<T>` med tillräckligt med utrymme för ett osorterat inre värde
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Tilldela `RcBox<T>` med det angivna värdet.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopiera värde som byte
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Frigör tilldelningen utan att tappa innehållet
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Tilldelar en `RcBox<[T]>` med angiven längd.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Kopiera element från skiva till nyligen tilldelad Rc <\[T\]>
    ///
    /// Osäkert eftersom den som ringer måste antingen äga eller binda `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Konstruerar en `Rc<[T]>` från en iterator som är känd för att ha en viss storlek.
    ///
    /// Beteendet är odefinierat om storleken är fel.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic skydd vid kloning av T-element.
        // I händelse av en panic kommer element som har skrivits in i den nya RcBoxen att tappas och sedan frigörs minnet.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Pekare till första elementet
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Allt klart.Glöm vakten så att den inte frigör nya RcBox.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specialisering trait används för `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Tappar `Rc`.
    ///
    /// Detta minskar det starka referensantalet.
    /// Om det starka referensantalet når noll är de enda andra referenser (om några) [`Weak`], så vi `drop` det inre värdet.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Skriver inte ut något
    /// drop(foo2);   // Skriver ut "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // förstöra det inneslutna föremålet
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // ta bort den implicita "strong weak"-pekaren nu när vi har förstört innehållet.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Gör en klon av `Rc`-pekaren.
    ///
    /// Detta skapar en annan pekare till samma fördelning, vilket ökar det starka referensantalet.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Skapar en ny `Rc<T>` med `Default`-värdet för `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hacka för att möjliggöra specialisering på `Eq` även om `Eq` har en metod.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Vi gör denna specialisering här, och inte som en mer allmän optimering på `&T`, eftersom det annars skulle lägga en kostnad för alla jämställdhetskontroller på ref.
/// Vi antar att `Rc`s används för att lagra stora värden, som är långsamma att klona, men också tunga för att kontrollera jämlikhet, vilket gör att denna kostnad lönar sig lättare.
///
/// Det är också mer sannolikt att ha två `Rc`-kloner, som pekar på samma värde, än två `&T`.
///
/// Vi kan bara göra detta när `T: Eq` som `PartialEq` kan vara medvetet irreflexiv.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Jämställdhet för två `Rc`s.
    ///
    /// Två "Rc" är lika om deras inre värden är lika, även om de lagras i olika tilldelningar.
    ///
    /// Om `T` också implementerar `Eq` (antyder reflexivitet av jämlikhet) är två `Rc` som pekar på samma tilldelning alltid lika.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Ojämlikhet för två `Rc`s.
    ///
    /// Två "Rc" är ojämlika om deras inre värden är ojämlika.
    ///
    /// Om `T` också implementerar `Eq` (antyder reflexivitet av jämlikhet) är två `Rc` som pekar på samma tilldelning aldrig ojämlika.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Deljämförelse för två "Rc".
    ///
    /// De två jämförs genom att anropa `partial_cmp()` på sina inre värden.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Mindre än jämförelse för två `Rc`s.
    ///
    /// De två jämförs genom att anropa `<` på sina inre värden.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// "Mindre än eller lika med" jämförelse för två "Rc".
    ///
    /// De två jämförs genom att anropa `<=` på sina inre värden.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Större jämförelse för två "Rc".
    ///
    /// De två jämförs genom att anropa `>` på sina inre värden.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// "Större än eller lika med" jämförelse för två "Rc".
    ///
    /// De två jämförs genom att anropa `>=` på sina inre värden.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Jämförelse för två `Rc`s.
    ///
    /// De två jämförs genom att anropa `cmp()` på sina inre värden.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Tilldela en referensräknad skiva och fyll den genom att klona ``v`s objekt.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Tilldela en referensräknad strängskiva och kopiera `v` till den.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Tilldela en referensräknad strängskiva och kopiera `v` till den.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Flytta ett boxat objekt till en ny, referensräknad, allokering.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Tilldela en referensräknad skiva och flytta 'v'-objekt in i den.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Låt Vec frigöra minne, men förstör inte innehållet
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Tar varje element i `Iterator` och samlar det i en `Rc<[T]>`.
    ///
    /// # Prestandaegenskaper
    ///
    /// ## Det allmänna fallet
    ///
    /// I allmänhet görs insamling i `Rc<[T]>` genom att först samlas in i en `Vec<T>`.Det vill säga när du skriver följande:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// detta beter sig som om vi skrev:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Den första uppsättningen tilldelningar sker här.
    ///     .into(); // En andra tilldelning för `Rc<[T]>` sker här.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Detta tilldelas så många gånger som behövs för att konstruera `Vec<T>` och sedan kommer det att fördelas en gång för att förvandla `Vec<T>` till `Rc<[T]>`.
    ///
    ///
    /// ## Iteratorer med känd längd
    ///
    /// När din `Iterator` implementerar `TrustedLen` och har en exakt storlek kommer en enda tilldelning att göras för `Rc<[T]>`.Till exempel:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Bara en enda tilldelning sker här.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Specialisering trait används för insamling till `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Detta är fallet för en `TrustedLen` iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SÄKERHET: Vi måste se till att iteratorn har en exakt längd och det har vi.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Återgå till normal implementering.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` är en version av [`Rc`] som innehåller en icke-ägande referens till den hanterade tilldelningen.Tilldelningen nås genom att ringa [`upgrade`] på `Weak`-pekaren, som returnerar ett [`Alternativ`]`<`[`Rc`] `<T>>`.
///
/// Eftersom en `Weak`-referens inte räknas till ägande kommer den inte att förhindra att värdet som lagras i allokeringen släpps, och `Weak` i sig själv ger inga garantier för att värdet fortfarande finns.
/// Således kan den returnera [`None`] när [`uppgradera`] d.
/// Observera dock att en `Weak`-referens *förhindrar* att allokeringen i sig (backing store) delas om.
///
/// En `Weak`-pekare är användbar för att hålla en tillfällig referens till allokeringen som hanteras av [`Rc`] utan att förhindra att dess inre värde tappas.
/// Det används också för att förhindra cirkulära referenser mellan [`Rc`]-pekare, eftersom ömsesidiga ägarreferenser aldrig tillåter att någon av [`Rc`] släpps.
/// Till exempel kan ett träd ha starka [`Rc`]-pekare från föräldernoder till barn och `Weak`-pekare från barn tillbaka till sina föräldrar.
///
/// Det typiska sättet att få en `Weak`-pekare är att ringa [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Detta är en `NonNull` för att möjliggöra optimering av storleken på denna typ i enums, men det är inte nödvändigtvis en giltig pekare.
    //
    // `Weak::new` ställer in detta till `usize::MAX` så att det inte behöver fördela utrymme på högen.
    // Det är inte ett värde som en riktig pekare någonsin kommer att ha eftersom RcBox har justering minst 2.
    // Detta är endast möjligt när `T: Sized`;osorterad `T` dinglar aldrig.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Konstruerar en ny `Weak<T>` utan att tilldela något minne.
    /// Att ringa [`upgrade`] på returvärdet ger alltid [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Hjälptyp för att få åtkomst till referensräkningarna utan att göra några påståenden om datafältet.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Returnerar en rå pekare till objektet `T` som pekas på av denna `Weak<T>`.
    ///
    /// Pekaren är endast giltig om det finns några starka referenser.
    /// Pekaren kan vara hängande, ojusterad eller till och med [`null`] annars.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Båda pekar på samma objekt
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Den starka här håller den vid liv så att vi fortfarande kan komma åt objektet.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Men inte längre.
    /// // Vi kan göra weak.as_ptr(), men att komma åt pekaren skulle leda till odefinierat beteende.
    /// // assert_eq! ("hej", osäker {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Om pekaren dinglar, returnerar vi sentinel direkt.
            // Detta kan inte vara en giltig nyttolastadress, eftersom nyttolasten är minst lika justerad som RcBox (usize).
            ptr as *const T
        } else {
            // SÄKERHET: om is_dangling returnerar false, så kan pekaren avläsas.
            // Nyttolasten kan tappas vid denna tidpunkt, och vi måste behålla härkomst, så använd rå pekmanipulation.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Förbrukar `Weak<T>` och gör den till en rå pekare.
    ///
    /// Detta omvandlar den svaga pekaren till en rå pekare, samtidigt som ägandet av en svag referens bevaras (det svaga antalet ändras inte av den här åtgärden).
    /// Den kan förvandlas till `Weak<T>` med [`from_raw`].
    ///
    /// Samma begränsningar för att komma åt pekarens mål som med [`as_ptr`] gäller.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Konverterar en rå pekare som tidigare skapats av [`into_raw`] tillbaka till `Weak<T>`.
    ///
    /// Detta kan användas för att säkert få en stark referens (genom att ringa [`upgrade`] senare) eller för att placera det svaga antalet genom att släppa `Weak<T>`.
    ///
    /// Det tar ägande av en svag referens (med undantag för pekare som skapats av [`new`], eftersom dessa inte äger någonting; metoden fungerar fortfarande på dem).
    ///
    /// # Safety
    ///
    /// Pekaren måste ha sitt ursprung i [`into_raw`] och måste fortfarande äga sin potentiella svaga referens.
    ///
    /// Det är tillåtet att den starka räkningen är 0 vid tiden för att kalla detta.
    /// Ändå tar detta äganderätten till en svag referens som för närvarande representeras som en rå pekare (det svaga antalet ändras inte av denna operation) och därför måste den kopplas ihop med ett tidigare samtal till [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Minska den sista svaga räkningen.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Se Weak::as_ptr för sammanhang om hur ingångspekaren härleds.

        let ptr = if is_dangling(ptr as *mut T) {
            // Detta är en dinglande svag.
            ptr as *mut RcBox<T>
        } else {
            // Annars är vi garanterade att pekaren kom från en orörlig svag.
            // SÄKERHET: data_offset är säkert att ringa, eftersom ptr refererar till en riktig (potentiellt tappad) T.
            let offset = unsafe { data_offset(ptr) };
            // Således vänder vi offset för att få hela RcBox.
            // SÄKERHET: pekaren härstammar från en svag, så denna förskjutning är säker.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SÄKERHET: vi har nu återställt den ursprungliga Svaga pekaren, så kan skapa Svag.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Försöker uppgradera `Weak`-pekaren till en [`Rc`], fördröja att det inre värdet släpps om det lyckas.
    ///
    ///
    /// Returnerar [`None`] om det inre värdet sedan har tappats.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Förstör alla starka pekare.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Får antalet starka (`Rc`)-pekare som pekar på den här tilldelningen.
    ///
    /// Om `self` skapades med [`Weak::new`] returnerar detta 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Hämtar antalet `Weak`-pekare som pekar på den här tilldelningen.
    ///
    /// Om det inte finns några starka pekare återgår detta till noll.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // subtrahera den implicita svaga ptr
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Returnerar `None` när pekaren dinglar och det inte finns någon tilldelad `RcBox` (dvs. när denna `Weak` skapades av `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Vi är försiktiga med att *inte* skapa en referens som täcker "data"-fältet, eftersom fältet kan muteras samtidigt (till exempel, om den sista `Rc` tappas kommer datafältet att tappas på plats).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Returnerar `true` om de två 'Svaga' pekar på samma tilldelning (liknar [`ptr::eq`]), eller om båda inte pekar på någon fördelning (eftersom de skapades med `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Eftersom detta jämför pekare betyder det att `Weak::new()` kommer att vara lika med varandra, även om de inte pekar på någon fördelning.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Jämför `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Tappar `Weak`-pekaren.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Skriver inte ut något
    /// drop(foo);        // Skriver ut "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // det svaga antalet börjar vid 1 och går bara till noll om alla starka pekare har försvunnit.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Gör en klon av `Weak`-pekaren som pekar på samma tilldelning.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Konstruerar en ny `Weak<T>`, fördelar minne för `T` utan att initialisera den.
    /// Att ringa [`upgrade`] på returvärdet ger alltid [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Vi kontrollerade_add här för att hantera mem::forget säkert.Särskilt
// om du mem::forget Rcs (eller Weaks) kan ref-count rinna över, och sedan kan du frigöra allokeringen medan utestående Rcs (eller Weaks) finns.
//
// Vi avbryter eftersom det här är ett så urartat scenario att vi inte bryr oss om vad som händer-inget riktigt program borde någonsin uppleva detta.
//
// Detta borde ha försumbar overhead eftersom du faktiskt inte behöver klona dessa mycket i Rust tack vare ägande och flytt-semantik.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Vi vill avbryta vid överflöde istället för att släppa värdet.
        // Referensantalet blir aldrig noll när detta kallas;
        // ändå infogar vi ett avbrott här för att antyda LLVM till en annars missad optimering.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Vi vill avbryta vid överflöde istället för att släppa värdet.
        // Referensantalet blir aldrig noll när detta kallas;
        // ändå infogar vi ett avbrott här för att antyda LLVM till en annars missad optimering.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Få offset inom en `RcBox` för nyttolasten bakom en pekare.
///
/// # Safety
///
/// Pekaren måste peka på (och ha giltiga metadata för) en tidigare giltig instans av T, men T får släppas.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Justera det osorterade värdet mot slutet av RcBox.
    // Eftersom RcBox är repr(C) kommer det alltid att vara det sista fältet i minnet.
    // SÄKERHET: eftersom de enda möjliga osorterade typerna är skivor, trait-objekt,
    // och externa typer är ingångssäkerhetskravet för närvarande tillräckligt för att uppfylla kraven för align_of_val_raw;Detta är en implementeringsdetalj av språket som kanske inte är beroende av utanför std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}