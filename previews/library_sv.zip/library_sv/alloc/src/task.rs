#![stable(feature = "wake_trait", since = "1.51.0")]
//! Typer och Traits för att arbeta med asynkrona uppgifter.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Implementeringen av att väcka en uppgift på en exekutor.
///
/// Denna trait kan användas för att skapa en [`Waker`].
/// En exekutör kan definiera en implementering av denna trait och använda den för att konstruera en Waker för att överföra de uppgifter som utförs på den exekutören.
///
/// Denna trait är ett minnessäkert och ergonomiskt alternativ till att konstruera en [`RawWaker`].
/// Den stöder den gemensamma utförandedesignen där data som används för att väcka en uppgift lagras i en [`Arc`].
/// Vissa utförare (särskilt de för inbäddade system) kan inte använda detta API, varför [`RawWaker`] finns som ett alternativ för dessa system.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// En grundläggande `block_on`-funktion som tar en future och kör den till slut på den aktuella tråden.
///
/// **Note:** Detta exempel handlar om korrekthet för enkelhet.
/// För att förhindra blockeringar måste implementeringar av produktionskvalitet också hantera mellanliggande samtal till `thread::unpark` såväl som kapslade anrop.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// En vakare som väcker den aktuella tråden när den kallas.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Kör en future till slut på den aktuella tråden.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Fäst future så att den kan pollas.
///     let mut fut = Box::pin(fut);
///
///     // Skapa ett nytt sammanhang som ska skickas till future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Kör future till slut.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Väck den här uppgiften.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Vakna den här uppgiften utan att konsumera väckaren.
    ///
    /// Om en exekutör stöder ett billigare sätt att vakna utan att konsumera waker, bör det åsidosätta denna metod.
    /// Som standard klonar den [`Arc`] och ringer [`wake`] på klonen.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // SÄKERHET: Detta är säkert eftersom raw_waker konstruerar säkert
        // en RawWaker från Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Denna privata funktion för att konstruera en RawWaker används snarare än
// att infoga detta i `From<Arc<W>> for RawWaker`-impl. för att säkerställa att säkerheten för `From<Arc<W>> for Waker` inte beror på rätt trait-sändning, utan istället kallar båda impls denna funktion direkt och uttryckligen.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Öka referensantalet för bågen för att klona den.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Vakna efter värde och flytta bågen till Wake::wake-funktionen
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Vakna med referens, linda upp vakaren i ManuallyDrop för att undvika att tappa den
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Minska referensantalet för bågen vid släpp
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}