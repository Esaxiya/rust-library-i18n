#![stable(feature = "rust1", since = "1.0.0")]

//! Trådsäkra referensräknarpekare.
//!
//! Se [`Arc<T>`][Arc]-dokumentationen för mer information.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// En mjuk gräns för antalet referenser som kan göras till en `Arc`.
///
/// Över denna gräns avbryts ditt program (men inte nödvändigtvis) vid _exactly_ `MAX_REFCOUNT + 1`-referenser.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer stöder inte minnesstaket.
// För att undvika falskt positiva rapporter i Arc/Weak-implementering använder du atombelastningar för synkronisering istället.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// En trådsäker referensräknarpekare.'Arc' står för 'Atomically Reference Counted'.
///
/// Typen `Arc<T>` tillhandahåller delat ägande av ett värde av typen `T`, tilldelat i högen.Att anropa [`clone`][clone] på `Arc` producerar en ny `Arc`-instans, som pekar på samma allokering på högen som källan `Arc`, samtidigt som referensantalet ökar.
/// När den sista `Arc`-pekaren till en given tilldelning förstörs, tappas också värdet som lagras i den allokeringen (ofta kallad "inner value").
///
/// Delade referenser i Rust tillåter inte mutation som standard, och `Arc` är inget undantag: du kan generellt inte få en mutbar referens till något inuti en `Arc`.Om du behöver mutera genom en `Arc`, använd [`Mutex`][mutex], [`RwLock`][rwlock] eller någon av [`Atomic`][atomic]-typerna.
///
/// ## Trådsäkerhet
///
/// Till skillnad från [`Rc<T>`] använder `Arc<T>` atomoperationer för sin referensräkning.Det betyder att den är trådsäker.Nackdelen är att atomoperationer är dyrare än vanlig minnesåtkomst.Om du inte delar referensräknade tilldelningar mellan trådar, överväg att använda [`Rc<T>`] för lägre omkostnader.
/// [`Rc<T>`] är en säker standard, eftersom kompilatorn kommer att fånga alla försök att skicka en [`Rc<T>`] mellan trådarna.
/// Ett bibliotek kan dock välja `Arc<T>` för att ge bibliotekonsumenterna mer flexibilitet.
///
/// `Arc<T>` kommer att implementera [`Send`] och [`Sync`] så länge `T` implementerar [`Send`] och [`Sync`].
/// Varför kan du inte placera en icke-trådsäker typ `T` i en `Arc<T>` för att göra den trådsäker?Det här kan vara lite kontraintuitivt först: trots allt är inte poängen med `Arc<T>` trådsäkerhet?Nyckeln är den här: `Arc<T>` gör det trådsäkert att ha flera äganderätt till samma data, men det ger inte trådsäkerhet till dess data.
///
/// Tänk på `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] är inte [`Sync`], och om `Arc<T>` alltid var [`Send`], `Arc <` [`RefCell<T>`]`>`skulle vara lika bra.
/// Men då skulle vi ha ett problem:
/// [`RefCell<T>`] är inte trådsäker;det håller reda på låneräkningen med icke-atomära operationer.
///
/// I slutändan betyder det att du kan behöva para ihop `Arc<T>` med någon typ av [`std::sync`]-typ, vanligtvis [`Mutex<T>`][mutex].
///
/// ## Brytningscykler med `Weak`
///
/// [`downgrade`][downgrade]-metoden kan användas för att skapa en icke-ägande [`Weak`]-pekare.En [`Weak`]-pekare kan [[uppgradera]][uppgradera] d till en `Arc`, men detta kommer att returnera [`None`] om värdet som lagrats i allokeringen redan har tappats.
/// Med andra ord, `Weak`-pekare håller inte värdet i tilldelningen vid liv.emellertid *håller* de levande tilldelningen (backing-butiken för värdet).
///
/// En cykel mellan `Arc`-pekare kommer aldrig att omplaceras.
/// Av denna anledning används [`Weak`] för att bryta cykler.Till exempel kan ett träd ha starka `Arc`-pekare från föräldernoder till barn och [`Weak`]-pekare från barn tillbaka till sina föräldrar.
///
/// # Kloning av referenser
///
/// Skapa en ny referens från en befintlig referensräknad pekare görs med `Clone` trait implementerad för [`Arc<T>`][Arc] och [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // De två syntaxerna nedan är ekvivalenta.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b och foo är alla bågar som pekar på samma minnesplats
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` automatiskt hänvisar till `T` (via [`Deref`][deref] trait), så att du kan anropa 'T' metoder för ett värde av typen `Arc<T>`.För att undvika namnkollisioner med `T`s metoder är metoderna för `Arc<T>` i sig associerade funktioner, kallade med [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>Implementeringar av traits som `Clone` kan också kallas med fullt kvalificerad syntax.
/// Vissa människor föredrar att använda fullt kvalificerad syntax, medan andra föredrar att använda metod-samtalsyntax.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Metod-samtalsyntax
/// let arc2 = arc.clone();
/// // Fullt kvalificerad syntax
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] gör inte autodereferens till `T`, eftersom det inre värdet redan har tappats.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Dela några oföränderliga data mellan trådar:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Observera att vi **inte** kör dessa tester här.
// windows-byggarna blir supernöjda om en tråd överlever huvudtråden och sedan går ut samtidigt (något spärrar) så vi undviker detta helt genom att inte köra dessa tester.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Dela en muterbar [`AtomicUsize`]:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Se [`rc` documentation][rc_examples] för fler exempel på referensräkning i allmänhet.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` är en version av [`Arc`] som innehåller en icke-ägande referens till den hanterade tilldelningen.
/// Tilldelningen nås genom att ringa [`upgrade`] på `Weak`-pekaren, som returnerar ett [`Alternativ`]`<`[`Arc ']`<T>> `.
///
/// Eftersom en `Weak`-referens inte räknas till ägande kommer den inte att förhindra att värdet som lagras i allokeringen släpps, och `Weak` i sig själv ger inga garantier för att värdet fortfarande finns.
///
/// Således kan den returnera [`None`] när [`uppgradera`] d.
/// Observera dock att en `Weak`-referens *förhindrar* att allokeringen i sig (backing store) delas om.
///
/// En `Weak`-pekare är användbar för att hålla en tillfällig referens till den allokering som hanteras av [`Arc`] utan att förhindra att dess inre värde tappas.
/// Det används också för att förhindra cirkulära referenser mellan [`Arc`]-pekare, eftersom ömsesidiga ägarreferenser aldrig tillåter att någon av [`Arc`] släpps.
/// Till exempel kan ett träd ha starka [`Arc`]-pekare från föräldernoder till barn och `Weak`-pekare från barn tillbaka till sina föräldrar.
///
/// Det typiska sättet att få en `Weak`-pekare är att ringa [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Detta är en `NonNull` för att möjliggöra optimering av storleken på denna typ i enums, men det är inte nödvändigtvis en giltig pekare.
    //
    // `Weak::new` ställer in detta till `usize::MAX` så att det inte behöver fördela utrymme på högen.
    // Det är inte ett värde som en riktig pekare någonsin kommer att ha eftersom RcBox har justering minst 2.
    // Detta är endast möjligt när `T: Sized`;osorterad `T` dinglar aldrig.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Detta är repr(C) till future-säkert mot möjlig fältbeställning, vilket skulle störa den annars säkra [into|from]_raw() av transmuterbara inre typer.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // värdet usize::MAX fungerar som en vaktpost för temporärt "locking" förmågan att uppgradera svaga pekare eller nedgradera starka;detta används för att undvika tävlingar i `make_mut` och `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Konstruerar en ny `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Starta den svaga pekaren som 1, vilket är den svaga pekaren som hålls av alla starka pekare (kinda), se std/rc.rs för mer info
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Konstruerar en ny `Arc<T>` med en svag referens till sig själv.
    /// Att försöka uppgradera den svaga referensen innan den här funktionen returnerar kommer att resultera i ett `None`-värde.
    /// Emellertid kan den svaga referensen klonas fritt och lagras för användning vid ett senare tillfälle.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Konstruera det inre i "uninitialized"-tillståndet med en enda svag referens.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Det är viktigt att vi inte ger upp äganderätten till den svaga pekaren, annars kan minnet frigöras när `data_fn` återvänder.
        // Om vi verkligen ville passera ägandet kunde vi skapa en ytterligare svag pekare för oss själva, men detta skulle resultera i ytterligare uppdateringar av det svaga referensantalet som annars inte skulle vara nödvändigt.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Nu kan vi initialisera det inre värdet ordentligt och göra vår svaga referens till en stark referens.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Ovanstående skriv till datafältet måste vara synlig för alla trådar som observerar ett starkt antal som inte är noll.
            // Därför behöver vi minst "Release"-beställning för att synkronisera med `compare_exchange_weak` i `Weak::upgrade`.
            //
            // "Acquire" beställning krävs inte.
            // När vi överväger det möjliga beteendet hos `data_fn` behöver vi bara titta på vad det kan göra med en hänvisning till en icke-uppgraderbar `Weak`:
            //
            // - Det kan *klona*`Weak`, vilket ökar det svaga referensantalet.
            // - Det kan släppa dessa kloner, vilket minskar det svaga referensantalet (men aldrig till noll).
            //
            // Dessa biverkningar påverkar oss inte på något sätt och inga andra biverkningar är möjliga med enbart säker kod.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Starka referenser bör tillsammans äga en delad svag referens, så kör inte förstöraren för vår gamla svaga referens.
        //
        mem::forget(weak);
        strong
    }

    /// Konstruerar en ny `Arc` med oinitialiserat innehåll.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Uppskjuten initialisering:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstruerar en ny `Arc` med oinitialiserat innehåll, där minnet fylls med `0` byte.
    ///
    ///
    /// Se [`MaybeUninit::zeroed`][zeroed] för exempel på korrekt och felaktig användning av denna metod.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstruerar en ny `Pin<Arc<T>>`.
    /// Om `T` inte implementerar `Unpin` kommer `data` att fästas i minnet och kan inte flyttas.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Konstruerar en ny `Arc<T>` och returnerar ett fel om allokeringen misslyckas.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Starta den svaga pekaren som 1, vilket är den svaga pekaren som hålls av alla starka pekare (kinda), se std/rc.rs för mer info
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Konstruerar en ny `Arc` med oinitialiserat innehåll och returnerar ett fel om allokeringen misslyckas.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Uppskjuten initialisering:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Konstruerar en ny `Arc` med oinitialiserat innehåll, där minnet fylls med `0`-byte, vilket returnerar ett fel om allokeringen misslyckas.
    ///
    ///
    /// Se [`MaybeUninit::zeroed`][zeroed] för exempel på korrekt och felaktig användning av denna metod.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Returnerar det inre värdet om `Arc` har exakt en stark referens.
    ///
    /// Annars returneras en [`Err`] med samma `Arc` som skickades in.
    ///
    ///
    /// Detta kommer att lyckas även om det finns enastående svaga referenser.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Gör en svag pekare för att rensa den implicita stark-svaga referensen
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Konstruerar en ny atomreferensräknad skiva med oinitialiserat innehåll.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Uppskjuten initialisering:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Konstruerar en ny atomreferensräknad skiva med oinitialiserat innehåll, med minnet fyllt med `0` byte.
    ///
    ///
    /// Se [`MaybeUninit::zeroed`][zeroed] för exempel på korrekt och felaktig användning av denna metod.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Konverterar till `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Som med [`MaybeUninit::assume_init`] är det upp till den som ringer att garantera att det inre värdet verkligen är i ett initialiserat tillstånd.
    ///
    /// Att ringa detta när innehållet ännu inte är fullständigt initierat orsakar omedelbart odefinierat beteende.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Uppskjuten initialisering:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Konverterar till `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Som med [`MaybeUninit::assume_init`] är det upp till den som ringer att garantera att det inre värdet verkligen är i ett initialiserat tillstånd.
    ///
    /// Att ringa detta när innehållet ännu inte är fullständigt initierat orsakar omedelbart odefinierat beteende.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Uppskjuten initialisering:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Förbrukar `Arc` och returnerar den inslagna pekaren.
    ///
    /// För att undvika minnesläckage måste pekaren konverteras tillbaka till en `Arc` med [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Ger en rå pekare till data.
    ///
    /// Räkningarna påverkas inte på något sätt och `Arc` förbrukas inte.
    /// Pekaren är giltig så länge det finns starka räkningar i `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // SÄKERHET: Detta kan inte gå igenom Deref::deref eller RcBoxPtr::inner eftersom
        // detta krävs för att behålla raw/mut härkomst så att t.ex.
        // `get_mut` kan skriva genom pekaren efter att Rc har återställts genom `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Konstruerar en `Arc<T>` från en rå pekare.
    ///
    /// Den råa pekaren måste ha returnerats tidigare genom ett samtal till [`Arc<U>::into_raw`][into_raw] där `U` måste ha samma storlek och justering som `T`.
    /// Detta stämmer trivialt om `U` är `T`.
    /// Observera att om `U` inte är `T` men har samma storlek och inriktning, är det i princip som att transmittera referenser av olika slag.
    /// Se [`mem::transmute`][transmute] för mer information om vilka begränsningar som gäller i det här fallet.
    ///
    /// Användaren av `from_raw` måste se till att ett specifikt värde på `T` bara tappas en gång.
    ///
    /// Denna funktion är osäker eftersom felaktig användning kan leda till minnesosäkerhet, även om den returnerade `Arc<T>` aldrig nås.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Konvertera tillbaka till en `Arc` för att förhindra läckage.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Ytterligare samtal till `Arc::from_raw(x_ptr)` skulle vara minnesfarliga.
    /// }
    ///
    /// // Minnet frigjordes när `x` gick utanför ramen ovan, så `x_ptr` dinglar nu!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Omvänd offset för att hitta originalet ArcInner.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Skapar en ny [`Weak`]-pekare till den här allokeringen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Det här är avslappnat eftersom vi kontrollerar värdet i CAS nedan.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // kontrollera om den svaga räknaren för närvarande är "locked";i så fall snurra.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: den här koden ignorerar för närvarande möjligheten till överflöde
            // till usize::MAX;i allmänhet måste både Rc och Arc justeras för att hantera överflöd.
            //

            // Till skillnad från Clone() behöver vi detta för att vara en förvärvsläsning för att synkronisera med den skrivning som kommer från `is_unique`, så att händelserna före skrivningen inträffar innan denna läsning.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Se till att vi inte skapar en dinglande svag
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Hämtar antalet [`Weak`]-pekare till denna fördelning.
    ///
    /// # Safety
    ///
    /// Denna metod är i sig säker, men att använda den korrekt kräver extra försiktighet.
    /// En annan tråd kan när som helst ändra det svaga antalet, inklusive potentiellt mellan att anropa den här metoden och agera på resultatet.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Detta påstående är deterministiskt eftersom vi inte har delat `Arc` eller `Weak` mellan trådarna.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Om den svaga räkningen för närvarande är låst var värdet på räkningen 0 precis innan du tog låset.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Får antalet starka (`Arc`)-pekare till denna fördelning.
    ///
    /// # Safety
    ///
    /// Denna metod är i sig säker, men att använda den korrekt kräver extra försiktighet.
    /// En annan tråd kan när som helst ändra det starka antalet, inklusive potentiellt mellan att anropa den här metoden och att agera på resultatet.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Detta påstående är deterministiskt eftersom vi inte har delat `Arc` mellan trådarna.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Ökar det starka referensantalet på `Arc<T>` associerat med den angivna pekaren med en.
    ///
    /// # Safety
    ///
    /// Pekaren måste ha erhållits via `Arc::into_raw` och tillhörande `Arc`-instans måste vara giltig (dvs.
    /// det starka antalet måste vara minst 1) under hela denna metod.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Detta påstående är deterministiskt eftersom vi inte har delat `Arc` mellan trådarna.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Behåll Arc, men rör inte vid återräkning genom att slå in ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Öka nu omräkningen, men släpp inte heller någon ny omräkning
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Minskar det starka referensantalet på `Arc<T>` som är associerat med den angivna pekaren med en.
    ///
    /// # Safety
    ///
    /// Pekaren måste ha erhållits via `Arc::into_raw` och tillhörande `Arc`-instans måste vara giltig (dvs.
    /// det starka antalet måste vara minst 1) när den här metoden åberopas.
    /// Denna metod kan användas för att släppa den slutliga `Arc` och backinglagring, men **bör inte** anropas efter att den slutliga `Arc` har släppts.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Dessa påståenden är avgörande eftersom vi inte har delat `Arc` mellan trådarna.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Denna osäkerhet är ok, för medan den här bågen lever är vi garanterade att den inre pekaren är giltig.
        // Dessutom vet vi att `ArcInner`-strukturen i sig är `Sync` eftersom den inre informationen också är `Sync`, så det är ok att låna ut en oföränderlig pekare till innehållet.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Icke-inline del av `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Förstör informationen just nu, även om vi kanske inte frigör lådtilldelningen (det kan fortfarande finnas svaga pekare som ligger).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Släpp den svaga ref som hålls av alla starka referenser
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Returnerar `true` om de två `Arc`s pekar på samma allokering (i en ven som liknar [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Tilldelar en `ArcInner<T>` med tillräckligt med utrymme för ett eventuellt osorterat inre värde där värdet har layouten.
    ///
    /// Funktionen `mem_to_arcinner` anropas med datapekaren och måste returnera en (potentiellt fet)-pekare för `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Beräkna layouten med den angivna värdelayouten.
        // Tidigare beräknades layout på uttrycket `&*(ptr as* const ArcInner<T>)`, men detta skapade en felinriktad referens (se #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Tilldelar en `ArcInner<T>` med tillräckligt med utrymme för ett eventuellt osorterat inre värde där värdet har den angivna layouten, vilket returnerar ett fel om allokeringen misslyckas.
    ///
    ///
    /// Funktionen `mem_to_arcinner` anropas med datapekaren och måste returnera en (potentiellt fet)-pekare för `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Beräkna layouten med den angivna värdelayouten.
        // Tidigare beräknades layout på uttrycket `&*(ptr as* const ArcInner<T>)`, men detta skapade en felinriktad referens (se #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Initiera ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Tilldelar en `ArcInner<T>` med tillräckligt med utrymme för ett osorterat inre värde.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Tilldela `ArcInner<T>` med det angivna värdet.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopiera värde som byte
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Frigör tilldelningen utan att tappa innehållet
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Tilldelar en `ArcInner<[T]>` med angiven längd.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Kopiera element från skiva till nyligen tilldelad Arc <\[T\]>
    ///
    /// Osäkert eftersom den som ringer måste antingen äga eller binda `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Konstruerar en `Arc<[T]>` från en iterator som är känd för att ha en viss storlek.
    ///
    /// Beteendet är odefinierat om storleken är fel.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic skydd vid kloning av T-element.
        // I händelse av en panic kommer element som har skrivits in i den nya ArcInner tappas och sedan frigörs minnet.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Pekare till första elementet
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Allt klart.Glöm vakten så att den inte frigör nya ArcInner.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specialisering trait används för `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Gör en klon av `Arc`-pekaren.
    ///
    /// Detta skapar en annan pekare till samma fördelning, vilket ökar det starka referensantalet.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Att använda en avslappnad ordning är okej här, eftersom kunskap om originalreferensen förhindrar att andra trådar felaktigt tar bort objektet.
        //
        // Som förklarats i [Boost documentation][1] kan man alltid göra en ökning av referensräknaren med memory_order_relaxed: Nya referenser till ett objekt kan bara bildas från en befintlig referens, och att skicka en befintlig referens från en tråd till en annan måste redan tillhandahålla synkronisering.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Vi måste dock skydda oss mot massiva återräkningar om någon är 'mem: : glömmer' bågar.
        // Om vi inte gör detta kan antalet rinna över och användarna kommer att använda gratis efter.
        // Vi mättar snabbt till `isize::MAX` under antagandet att det inte finns ~2 miljarder trådar som ökar referensantalet på en gång.
        //
        // Denna branch kommer aldrig att tas i något realistiskt program.
        //
        // Vi avbryter eftersom ett sådant program är oerhört urartat, och vi bryr oss inte om att stödja det.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Gör en förändrad referens till den givna `Arc`.
    ///
    /// Om det finns andra `Arc`-eller [`Weak`]-pekare till samma tilldelning kommer `make_mut` att skapa en ny allokering och åberopa [`clone`][clone] på det inre värdet för att säkerställa unikt ägande.
    /// Detta kallas också klon-på-skriv.
    ///
    /// Observera att detta skiljer sig från beteendet hos [`Rc::make_mut`] som kopplar bort alla återstående `Weak`-pekare.
    ///
    /// Se även [`get_mut`][get_mut], som kommer att misslyckas snarare än kloning.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Kommer inte att klona någonting
    /// let mut other_data = Arc::clone(&data); // Kommer inte att klona inre data
    /// *Arc::make_mut(&mut data) += 1;         // Klonar inre data
    /// *Arc::make_mut(&mut data) += 1;         // Kommer inte att klona någonting
    /// *Arc::make_mut(&mut other_data) *= 2;   // Kommer inte att klona någonting
    ///
    /// // Nu pekar `data` och `other_data` på olika tilldelningar.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Observera att vi har både en stark och en svag referens.
        // Att släppa vår starka referens kommer alltså inte i sig att få minnet att omplaceras.
        //
        // Använd Acquire för att se till att vi ser alla skrivningar till `weak` som händer innan release skriver (dvs. minskningar) till `strong`.
        // Eftersom vi har en svag räkning finns det ingen chans att ArcInner själv skulle kunna omfördelas.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // En annan stark pekare finns, så vi måste klona.
            // Fördela minne så att du kan skriva det klonade värdet direkt.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Avslappnad räcker i ovanstående eftersom detta i grunden är en optimering: vi tävlar alltid med svaga pekare som tappas.
            // I värsta fall tilldelade vi en ny båge i onödan.
            //

            // Vi tog bort den sista starka ref, men det finns ytterligare svaga ref.
            // Vi flyttar innehållet till en ny båge och ogiltigförklarar de andra svaga ref.
            //

            // Observera att det inte är möjligt för avläsningen av `weak` att ge usize::MAX (dvs låst), eftersom det svaga antalet endast kan låsas av en tråd med en stark referens.
            //
            //

            // Materialisera vår egen implicita svaga pekare så att den kan städa upp ArcInner efter behov.
            //
            let _weak = Weak { ptr: this.ptr };

            // Kan bara stjäla data, allt som finns kvar är Svagheter
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Vi var den enda referensen av något slag;stöta tillbaka den starka ref räkningen.
            //
            this.inner().strong.store(1, Release);
        }

        // Som med `get_mut()` är osäkerheten ok eftersom vår referens antingen var unik till att börja med eller blev en efter kloning av innehållet.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Returnerar en muterbar referens till den angivna `Arc`, om det inte finns några andra `Arc`-eller [`Weak`]-pekare till samma tilldelning.
    ///
    ///
    /// Returnerar [`None`] annars eftersom det inte är säkert att mutera ett delat värde.
    ///
    /// Se även [`make_mut`][make_mut], som kommer att [`clone`][clone] det inre värdet när det finns andra pekare.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Denna osäkerhet är ok eftersom vi är garanterade att pekaren som returneras är den *enda* pekaren som någonsin kommer att returneras till T.
            // Vårt referensantal är garanterat 1 vid denna tidpunkt, och vi krävde att själva bågen var `mut`, så vi returnerar den enda möjliga referensen till de inre uppgifterna.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Returnerar en muterbar referens till den givna `Arc`, utan någon kontroll.
    ///
    /// Se även [`get_mut`], som är säkert och gör lämpliga kontroller.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Alla andra `Arc`-eller [`Weak`]-pekare till samma tilldelning får inte hänvisas till under den återlämnade lånet.
    ///
    /// Detta är triviellt fallet om inga sådana pekare finns, till exempel direkt efter `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Vi är noga med att *inte* skapa en referens som täcker "count"-fälten, eftersom detta skulle alias med samtidig åtkomst till referensräkningarna (t.ex.
        // av `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Bestäm om detta är den unika referensen (inklusive svaga refs) till underliggande data.
    ///
    ///
    /// Observera att detta kräver att det svaga ref-antalet låses.
    fn is_unique(&mut self) -> bool {
        // låsa antalet svaga pekare om vi verkar vara den enda svaga pekaren.
        //
        // Förvärvsmärket här säkerställer en händelse före relation med skrivningar till `strong` (särskilt i `Weak::upgrade`) före minskningar av `weak`-räkningen (via `Weak::drop`, som använder release).
        // Om den uppgraderade svaga ref aldrig släpptes kommer CAS här att misslyckas så vi bryr oss inte om att synkronisera.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Detta måste vara en `Acquire` för att synkronisera med minskningen av `strong`-räknaren i `drop`-den enda åtkomst som händer när någon annan än den sista referensen tappas.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Release-skrivningen här synkroniseras med en läsning i `downgrade`, vilket effektivt förhindrar att läsningen av `strong` ovan sker efter skrivningen.
            //
            //
            self.inner().weak.store(1, Release); // lossa låset
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Tappar `Arc`.
    ///
    /// Detta minskar det starka referensantalet.
    /// Om det starka referensantalet når noll är de enda andra referenser (om några) [`Weak`], så vi `drop` det inre värdet.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Skriver inte ut något
    /// drop(foo2);   // Skriver ut "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Eftersom `fetch_sub` redan är atomiskt behöver vi inte synkronisera med andra trådar om vi inte tar bort objektet.
        // Samma logik gäller under `fetch_sub` till `weak`-räkningen.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Detta staket behövs för att förhindra omordning av användningen av data och radering av uppgifterna.
        // Eftersom det är markerat `Release` synkroniseras minskningen av referensantalet med detta `Acquire`-staket.
        // Detta innebär att användningen av data sker innan man minskar referensantalet, vilket händer före detta staket, vilket händer innan data raderas.
        //
        // Som förklaras i [Boost documentation][1],
        //
        // > Det är viktigt att tillämpa eventuell åtkomst till objektet i ett
        // > tråd (genom en befintlig referens) för att *hända innan* raderas
        // > objektet i en annan tråd.Detta uppnås med en "release"
        // > efter att ha tappat en referens (all åtkomst till objektet
        // > genom denna referens måste uppenbarligen hända tidigare), och en
        // > "acquire" innan du tar bort objektet.
        //
        // I synnerhet, även om innehållet i en båge vanligtvis är oföränderligt, är det möjligt att ha interiörskrivningar till något som en Mutex<T>.
        // Eftersom en Mutex inte förvärvas när den raderas kan vi inte lita på dess synkroniseringslogik för att göra skrivningar i tråd A synliga för en destruktör som kör i tråd B.
        //
        //
        // Observera också att Acquire-staketet här troligen kan ersättas med en Acquire-belastning, vilket kan förbättra prestandan i mycket tuffa situationer.Se [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Försök att nedkasta `Arc<dyn Any + Send + Sync>` till en konkret typ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Konstruerar en ny `Weak<T>` utan att tilldela något minne.
    /// Att ringa [`upgrade`] på returvärdet ger alltid [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Hjälptyp för att få åtkomst till referensräkningarna utan att göra några påståenden om datafältet.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Returnerar en rå pekare till objektet `T` som pekas på av denna `Weak<T>`.
    ///
    /// Pekaren är endast giltig om det finns några starka referenser.
    /// Pekaren kan vara hängande, ojusterad eller till och med [`null`] annars.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Båda pekar på samma objekt
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Den starka här håller den vid liv så att vi fortfarande kan komma åt objektet.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Men inte längre.
    /// // Vi kan göra weak.as_ptr(), men att komma åt pekaren skulle leda till odefinierat beteende.
    /// // assert_eq! ("hej", osäker {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Om pekaren dinglar, returnerar vi sentinel direkt.
            // Detta kan inte vara en giltig nyttolastadress, eftersom nyttolasten är minst lika anpassad som ArcInner (usize).
            ptr as *const T
        } else {
            // SÄKERHET: om is_dangling returnerar false, så kan pekaren avläsas.
            // Nyttolasten kan tappas vid denna tidpunkt, och vi måste behålla härkomst, så använd rå pekmanipulation.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Förbrukar `Weak<T>` och gör den till en rå pekare.
    ///
    /// Detta omvandlar den svaga pekaren till en rå pekare, samtidigt som ägandet av en svag referens bevaras (det svaga antalet ändras inte av den här åtgärden).
    /// Den kan förvandlas till `Weak<T>` med [`from_raw`].
    ///
    /// Samma begränsningar för att komma åt pekarens mål som med [`as_ptr`] gäller.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Konverterar en rå pekare som tidigare skapats av [`into_raw`] tillbaka till `Weak<T>`.
    ///
    /// Detta kan användas för att säkert få en stark referens (genom att ringa [`upgrade`] senare) eller för att placera det svaga antalet genom att släppa `Weak<T>`.
    ///
    /// Det tar ägande av en svag referens (med undantag för pekare som skapats av [`new`], eftersom dessa inte äger någonting; metoden fungerar fortfarande på dem).
    ///
    /// # Safety
    ///
    /// Pekaren måste ha sitt ursprung i [`into_raw`] och måste fortfarande äga sin potentiella svaga referens.
    ///
    /// Det är tillåtet att den starka räkningen är 0 vid tiden för att kalla detta.
    /// Ändå tar detta äganderätten till en svag referens som för närvarande representeras som en rå pekare (det svaga antalet ändras inte av denna operation) och därför måste den kopplas ihop med ett tidigare samtal till [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Minska den sista svaga räkningen.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Se Weak::as_ptr för sammanhang om hur ingångspekaren härleds.

        let ptr = if is_dangling(ptr as *mut T) {
            // Detta är en dinglande svag.
            ptr as *mut ArcInner<T>
        } else {
            // Annars är vi garanterade att pekaren kom från en orörlig svag.
            // SÄKERHET: data_offset är säkert att ringa, eftersom ptr refererar till en riktig (potentiellt tappad) T.
            let offset = unsafe { data_offset(ptr) };
            // Således vänder vi offset för att få hela RcBox.
            // SÄKERHET: pekaren härstammar från en svag, så denna förskjutning är säker.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SÄKERHET: vi har nu återställt den ursprungliga Svaga pekaren, så kan skapa Svag.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Försöker uppgradera `Weak`-pekaren till en [`Arc`], fördröja att det inre värdet släpps om det lyckas.
    ///
    ///
    /// Returnerar [`None`] om det inre värdet sedan har tappats.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Förstör alla starka pekare.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Vi använder en CAS-loop för att öka det starka antalet i stället för en fetch_add eftersom den här funktionen aldrig ska ta referensantalet från noll till en.
        //
        //
        let inner = self.inner()?;

        // Avslappnad belastning eftersom någon skrivning av 0 som vi kan observera lämnar fältet i ett permanent nollläge (så en "stale"-läsning av 0 är bra), och alla andra värden bekräftas via CAS nedan.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Se kommentarer i `Arc::clone` för varför vi gör detta (för `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Relaxed är bra för misslyckandet eftersom vi inte har några förväntningar på det nya staten.
            // Förvärv är nödvändigt för att framgångsfallet ska synkroniseras med `Arc::new_cyclic`, när det inre värdet kan initieras efter att `Weak`-referenser redan har skapats.
            // I så fall förväntar vi oss att observera det fullständigt initialiserade värdet.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null markerad ovan
                Err(old) => n = old,
            }
        }
    }

    /// Får antalet starka (`Arc`)-pekare som pekar på den här tilldelningen.
    ///
    /// Om `self` skapades med [`Weak::new`] returnerar detta 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Får en uppskattning av antalet `Weak`-pekare som pekar på denna tilldelning.
    ///
    /// Om `self` skapades med [`Weak::new`], eller om det inte finns några kvarvarande starka pekare, kommer detta att returnera 0.
    ///
    /// # Accuracy
    ///
    /// På grund av implementeringsdetaljer kan det returnerade värdet stängas av med 1 i båda riktningarna när andra trådar manipulerar några ``bågar '' eller`` svaga '' som pekar på samma tilldelning.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Eftersom vi observerade att det fanns åtminstone en stark pekare efter att ha läst den svaga räkningen, vet vi att den implicita svaga referensen (närvarande när några starka referenser lever) fortfarande fanns när vi observerade den svaga räkningen, och kan därför säkert subtrahera den.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Returnerar `None` när pekaren dinglar och det inte finns någon tilldelad `ArcInner` (dvs. när denna `Weak` skapades av `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Vi är försiktiga med att *inte* skapa en referens som täcker "data"-fältet, eftersom fältet kan muteras samtidigt (till exempel, om den sista `Arc` tappas kommer datafältet att tappas på plats).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Returnerar `true` om de två 'Svaga' pekar på samma tilldelning (liknar [`ptr::eq`]), eller om båda inte pekar på någon fördelning (eftersom de skapades med `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Eftersom detta jämför pekare betyder det att `Weak::new()` kommer att vara lika med varandra, även om de inte pekar på någon fördelning.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Jämför `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Gör en klon av `Weak`-pekaren som pekar på samma tilldelning.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Se kommentarer i Arc::clone() för varför detta är avslappnat.
        // Detta kan använda en fetch_add (ignorerar låset) eftersom det svaga antalet bara är låst där *inga andra* svaga pekare finns.
        //
        // (Så vi kan inte köra den här koden i så fall).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Se kommentarer i Arc::clone() för varför vi gör detta (för mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Konstruerar en ny `Weak<T>` utan att allokera minne.
    /// Att ringa [`upgrade`] på returvärdet ger alltid [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Tappar `Weak`-pekaren.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Skriver inte ut något
    /// drop(foo);        // Skriver ut "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Om vi får reda på att vi var den sista svaga pekaren, är det dags att distribuera data helt.Se diskussionen i Arc::drop() om minnesbeställningarna
        //
        // Det är inte nödvändigt att kontrollera om det låsta tillståndet är här, för det svaga antalet kan endast låses om det existerade en svag ref, vilket innebär att fall bara därefter kunde köras PÅ den återstående svaga ref, vilket bara kan hända efter att låset släpps.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Vi gör denna specialisering här, och inte som en mer allmän optimering på `&T`, eftersom det annars skulle lägga en kostnad för alla jämställdhetskontroller på ref.
/// Vi antar att `Arc`s används för att lagra stora värden, som är långsamma att klona, men också tunga för att kontrollera jämlikhet, vilket gör att denna kostnad lönar sig lättare.
///
/// Det är också mer sannolikt att ha två `Arc`-kloner, som pekar på samma värde, än två `&T`.
///
/// Vi kan bara göra detta när `T: Eq` som `PartialEq` kan vara medvetet irreflexiv.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Jämställdhet för två `Arc`s.
    ///
    /// Två bågar är lika om deras inre värden är lika, även om de lagras i olika fördelningar.
    ///
    /// Om `T` också implementerar `Eq` (antyder reflexivitet för jämlikhet) är två `Arc`s som pekar på samma allokering alltid lika.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Ojämlikhet för två `Arc`s.
    ///
    /// Två bågar är ojämlika om deras inre värden är ojämlika.
    ///
    /// Om `T` också implementerar `Eq` (antyder reflexivitet av jämlikhet) är två `Arc`s som pekar på samma värde aldrig ojämlika.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Delvis jämförelse för två `Arc`s.
    ///
    /// De två jämförs genom att anropa `partial_cmp()` på sina inre värden.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Mindre än jämförelse för två `Arc`s.
    ///
    /// De två jämförs genom att anropa `<` på sina inre värden.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// "Mindre än eller lika med" jämförelse för två "bågar".
    ///
    /// De två jämförs genom att anropa `<=` på sina inre värden.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Större jämförelse än för två bågar.
    ///
    /// De två jämförs genom att anropa `>` på sina inre värden.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// "Större än eller lika med" jämförelse för två "bågar".
    ///
    /// De två jämförs genom att anropa `>=` på sina inre värden.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Jämförelse för två `Arc`s.
    ///
    /// De två jämförs genom att anropa `cmp()` på sina inre värden.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Skapar en ny `Arc<T>` med `Default`-värdet för `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Tilldela en referensräknad skiva och fyll den genom att klona ``v`s objekt.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Tilldela en referensräknad `str` och kopiera `v` till den.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Tilldela en referensräknad `str` och kopiera `v` till den.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Flytta ett boxat objekt till en ny, referensräknad allokering.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Tilldela en referensräknad skiva och flytta 'v'-objekt in i den.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Låt Vec frigöra minne, men förstör inte innehållet
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Tar varje element i `Iterator` och samlar det i en `Arc<[T]>`.
    ///
    /// # Prestandaegenskaper
    ///
    /// ## Det allmänna fallet
    ///
    /// I allmänhet görs insamling i `Arc<[T]>` genom att först samlas in i en `Vec<T>`.Det vill säga när du skriver följande:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// detta beter sig som om vi skrev:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Den första uppsättningen tilldelningar sker här.
    ///     .into(); // En andra tilldelning för `Arc<[T]>` sker här.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Detta kommer att fördelas så många gånger som behövs för att konstruera `Vec<T>` och sedan kommer det att fördelas en gång för att förvandla `Vec<T>` till `Arc<[T]>`.
    ///
    ///
    /// ## Iteratorer med känd längd
    ///
    /// När din `Iterator` implementerar `TrustedLen` och har en exakt storlek kommer en enda tilldelning att göras för `Arc<[T]>`.Till exempel:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Bara en enda tilldelning sker här.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Specialisering trait används för insamling till `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Detta är fallet för en `TrustedLen` iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SÄKERHET: Vi måste se till att iteratorn har en exakt längd och det har vi.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Återgå till normal implementering.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Få offset inom en `ArcInner` för nyttolasten bakom en pekare.
///
/// # Safety
///
/// Pekaren måste peka på (och ha giltiga metadata för) en tidigare giltig instans av T, men T får släppas.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Justera det osorterade värdet mot slutet av ArcInner.
    // Eftersom RcBox är repr(C) kommer det alltid att vara det sista fältet i minnet.
    // SÄKERHET: eftersom de enda möjliga osorterade typerna är skivor, trait-objekt,
    // och externa typer är ingångssäkerhetskravet för närvarande tillräckligt för att uppfylla kraven för align_of_val_raw;Detta är en implementeringsdetalj av språket som kanske inte är beroende av utanför std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}