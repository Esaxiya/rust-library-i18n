//! Tilldelningen Prelude
//!
//! Syftet med denna modul är att lindra import av vanligt förekommande artiklar av `alloc` crate genom att lägga till en globimport till toppen av modulerna:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;