//! En UTF-8-kodad, odlingsbar sträng.
//!
//! Den här modulen innehåller [`String`]-typen, [`ToString`] trait för konvertering till strängar och flera feltyper som kan uppstå genom att arbeta med [`String`].
//!
//!
//! # Examples
//!
//! Det finns flera sätt att skapa en ny [`String`] från en strängbokstav:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Du kan skapa en ny [`String`] från en befintlig genom att sammanfoga med
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Om du har en vector med giltiga UTF-8-byte kan du göra en [`String`] av den.Du kan också göra det motsatta.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Vi vet att dessa byte är giltiga, så vi använder `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// En UTF-8-kodad, odlingsbar sträng.
///
/// `String`-typen är den vanligaste strängtypen som äger innehållet i strängen.Den har en nära relation med sin lånade motsvarighet, den primitiva [`str`].
///
/// # Examples
///
/// Du kan skapa en `String` från [a literal string][`str`] med [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Du kan lägga till en [`char`] till en `String` med [`push`]-metoden och lägga till en [`&str`] med [`push_str`]-metoden:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Om du har en vector med UTF-8-byte kan du skapa en `String` från den med [`from_utf8`]-metoden:
///
/// ```
/// // några byte, i en vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Vi vet att dessa byte är giltiga, så vi använder `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// Strängar är alltid giltiga UTF-8.Detta har några konsekvenser, varav den första är att om du behöver en icke-UTF-8-sträng, överväg [`OsString`].Det är liknande, men utan UTF-8-begränsning.Den andra implikationen är att du inte kan indexera till en `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Indexering är tänkt att vara en konstant tidsoperation, men UTF-8-kodning tillåter inte oss att göra detta.Dessutom är det inte klart vilken typ av sak indexet ska returnera: en byte, en kodpunkt eller ett grafekluster.
/// Metoderna [`bytes`] och [`chars`] returnerar iteratorer under de två första.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// "Strängens redskap [" Deref "]"<Target=str>`, och ärva så alla [` str`] metoder.Dessutom innebär det att du kan skicka en `String` till en funktion som tar en [`&str`] med hjälp av ett ampersand (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Detta kommer att skapa en [`&str`] från `String` och skicka den in. Denna omvandling är mycket billig, och så i allmänhet kommer funktioner att acceptera [`&str`s som argument om de inte behöver en `String` av någon specifik anledning.
///
/// I vissa fall har Rust inte tillräckligt med information för att göra denna konvertering, känd som [`Deref`] tvång.I följande exempel implementerar en strängskiva [`&'a str`][`&str`] trait `TraitExample`, och funktionen `example_func` tar allt som implementerar trait.
/// I detta fall skulle Rust behöva göra två implicita konverteringar, vilket Rust inte har möjlighet att göra.
/// Av den anledningen kommer följande exempel inte att kompileras.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Det finns två alternativ som fungerar istället.Den första skulle vara att ändra raden `example_func(&example_string);` till `example_func(example_string.as_str());`, med metoden [`as_str()`] för att uttryckligen extrahera strängskivan som innehåller strängen.
/// Det andra sättet ändrar `example_func(&example_string);` till `example_func(&*example_string);`.
/// I det här fallet hänvisar vi till en `String` till en [`str`][`&str`] och refererar sedan till [`str`][`&str`] till [`&str`].
/// Det andra sättet är mer idiomatiskt, men båda arbetar för att göra omvandlingen uttryckligen snarare än att förlita sig på den implicita omvandlingen.
///
/// # Representation
///
/// En `String` består av tre komponenter: en pekare till vissa byte, en längd och en kapacitet.Pekaren pekar på en intern buffert som `String` använder för att lagra sina data.Längden är antalet byte som för närvarande lagras i bufferten och kapaciteten är storleken på bufferten i byte.
///
/// Som sådan kommer längden alltid att vara mindre än eller lika med kapaciteten.
///
/// Denna buffert lagras alltid på högen.
///
/// Du kan titta på dessa med metoderna [`as_ptr`], [`len`] och [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Uppdatera detta när vec_into_raw_parts är stabiliserat.
/// // Förhindra att automatiskt släppa strängens data
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // historien har nitton byte
/// assert_eq!(19, len);
///
/// // Vi kan bygga om en sträng av ptr, len och kapacitet.
/// // Allt är osäkert eftersom vi är ansvariga för att komponenterna är giltiga:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Om en `String` har tillräckligt med kapacitet kommer det inte att allokeras om du lägger till element i den.Tänk till exempel på det här programmet:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Detta kommer att mata ut följande:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Först har vi inget minne tilldelat alls, men när vi lägger till strängen ökar det kapaciteten på lämpligt sätt.Om vi istället använder [`with_capacity`]-metoden för att tilldela rätt kapacitet från början:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Vi slutar med en annan produktion:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Här behöver du inte allokera mer minne inuti slingan.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Ett möjligt felvärde vid konvertering av en `String` från en UTF-8-byte vector.
///
/// Den här typen är feltyp för [`from_utf8`]-metoden på [`String`].
/// Den är utformad på ett sådant sätt att noggrant undviks omfördelningar: [`into_bytes`]-metoden ger tillbaka byten vector som användes i konverteringsförsöket.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// [`Utf8Error`]-typen som tillhandahålls av [`std::str`] representerar ett fel som kan uppstå vid konvertering av en bit av [`u8`] till en [`&str`].
/// I den meningen är det en analog till `FromUtf8Error`, och du kan få en från en `FromUtf8Error` genom [`utf8_error`]-metoden.
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Grundläggande användning:
///
/// ```
/// // några ogiltiga byte, i en vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Ett möjligt felvärde vid konvertering av en `String` från en UTF-16 byte-skiva.
///
/// Den här typen är feltyp för [`from_utf16`]-metoden på [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Grundläggande användning:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Skapar en ny tom `String`.
    ///
    /// Med tanke på att `String` är tom, kommer detta inte att tilldela någon initial buffert.Även om det betyder att den här inledande åtgärden är mycket billig kan det orsaka överdriven tilldelning senare när du lägger till data.
    ///
    /// Om du har en uppfattning om hur mycket data `String` kommer att innehålla, överväg [`with_capacity`]-metoden för att förhindra överdriven omfördelning.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Skapar en ny tom `String` med en viss kapacitet.
    ///
    /// Strängar har en intern buffert för att hålla deras data.
    /// Kapaciteten är längden på den bufferten och kan ifrågasättas med [`capacity`]-metoden.
    /// Denna metod skapar en tom `String`, men en med en initial buffert som kan innehålla `capacity` byte.
    /// Detta är användbart när du kanske lägger till en massa data till `String`, vilket minskar antalet omfördelningar som behövs.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Om den angivna kapaciteten är `0` kommer ingen allokering att ske, och den här metoden är identisk med [`new`]-metoden.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // Strängen innehåller inga tecken, även om den har kapacitet för mer
    /// assert_eq!(s.len(), 0);
    ///
    /// // Allt görs utan omfördelning ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... men detta kan göra att strängen omfördelas
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): med cfg(test) är den inneboende `[T]::to_vec`-metoden, som krävs för denna metoddefinition, inte tillgänglig.
    // Eftersom vi inte behöver den här metoden för teständamål, stubbar jag bara den. OBS! Se slice::hack-modulen i slice.rs för mer information
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Konverterar en vector av byte till en `String`.
    ///
    /// En sträng ([`String`]) är gjord av byte ([`u8`]) och en vector av byte ([`Vec<u8>`]) är gjord av byte, så den här funktionen omvandlas mellan de två.
    /// Inte alla byte-skivor är giltiga 'Strängar', dock: `String` kräver att det är giltigt UTF-8.
    /// `from_utf8()` kontrollerar att byte är giltiga UTF-8 och gör sedan konverteringen.
    ///
    /// Om du är säker på att bytesskivan är giltig UTF-8 och du inte vill ådra dig giltighetskontrollens omkostnader, finns det en osäker version av den här funktionen, [`from_utf8_unchecked`], som har samma beteende men hoppar över kontrollen.
    ///
    ///
    /// Denna metod tar hand om att inte kopiera vector, för effektivitets skull.
    ///
    /// Om du behöver en [`&str`] istället för en `String`, överväg [`str::from_utf8`].
    ///
    /// Den inversa av denna metod är [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Returnerar [`Err`] om segmentet inte är UTF-8 med en beskrivning av varför de tillhandahållna byten inte är UTF-8.vector du flyttade in ingår också.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// // några byte, i en vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Vi vet att dessa byte är giltiga, så vi använder `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Felaktiga byte:
    ///
    /// ```
    /// // några ogiltiga byte, i en vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Se dokumenten för [`FromUtf8Error`] för mer information om vad du kan göra med det här felet.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Konverterar en bit byte till en sträng, inklusive ogiltiga tecken.
    ///
    /// Strängar är gjorda av byte ([`u8`]) och en bit byte ([`&[u8]`][byteslice]) är gjorda av byte, så den här funktionen omvandlas mellan de två.Inte alla byte-skivor är giltiga strängar, dock: strängar måste vara giltiga UTF-8.
    /// Under denna konvertering ersätter `from_utf8_lossy()` alla ogiltiga UTF-8-sekvenser med [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], som ser ut så här:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Om du är säker på att byte-skivan är giltig UTF-8, och du inte vill ådra dig omkostnaderna för konverteringen, finns det en osäker version av den här funktionen, [`from_utf8_unchecked`], som har samma beteende men hoppar över kontrollerna.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Denna funktion returnerar en [`Cow<'a, str>`].Om vår byte-skiva är ogiltig UTF-8, måste vi infoga ersättningstecken, vilket kommer att ändra storleken på strängen och därmed kräva en `String`.
    /// Men om det redan är giltigt UTF-8 behöver vi inte en ny tilldelning.
    /// Denna returtyp gör att vi kan hantera båda fallen.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// // några byte, i en vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Felaktiga byte:
    ///
    /// ```
    /// // några ogiltiga byte
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Avkoda en UTF-16-kodad vector `v` till en `String`, returnera [`Err`] om `v` innehåller ogiltiga data.
    ///
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Detta görs inte via samla: : <Result<_, _>> () av prestationsskäl.
        // FIXME: funktionen kan förenklas igen när #48994 stängs.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Avkoda en UTF-16-kodad del `v` till en `String`, ersätt ogiltiga data med [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// Till skillnad från [`from_utf8_lossy`] som returnerar en [`Cow<'a, str>`], returnerar `from_utf16_lossy` en `String` eftersom UTF-16 till UTF-8-omvandlingen kräver en minnestilldelning.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Sönderdelar en `String` i dess råa komponenter.
    ///
    /// Returnerar den råa pekaren till underliggande data, längden på strängen (i byte) och den tilldelade kapaciteten för data (i byte).
    /// Dessa är samma argument i samma ordning som argumenten för [`from_raw_parts`].
    ///
    /// Efter att ha ringt denna funktion är den som ringer ansvarig för det minne som tidigare hanterats av `String`.
    /// Det enda sättet att göra detta är att konvertera den råa pekaren, längden och kapaciteten tillbaka till en `String` med [`from_raw_parts`]-funktionen, så att destruktorn kan utföra saneringen.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Skapar en ny `String` från en längd, kapacitet och pekare.
    ///
    /// # Safety
    ///
    /// Detta är mycket osäkert på grund av antalet invarianter som inte kontrolleras:
    ///
    /// * Minnet på `buf` måste ha tilldelats tidigare av samma fördelare som standardbiblioteket använder, med en nödvändig inriktning på exakt 1.
    /// * `length` måste vara mindre än eller lika med `capacity`.
    /// * `capacity` måste vara rätt värde.
    /// * De första `length`-byten på `buf` måste vara giltiga UTF-8.
    ///
    /// Att bryta mot dessa kan orsaka problem som att skada allokerings interna datastrukturer.
    ///
    /// Äganderätten till `buf` överförs effektivt till `String` som sedan kan omplacera, omfördela eller ändra innehållet i minnet som pekaren pekar på.
    /// Se till att inget annat använder pekaren efter att ha anropat den här funktionen.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Uppdatera detta när vec_into_raw_parts är stabiliserat.
    ///     // Förhindra att automatiskt släppa strängens data
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Konverterar en vector av byte till en `String` utan att kontrollera att strängen innehåller giltig UTF-8.
    ///
    /// Se den säkra versionen, [`from_utf8`], för mer information.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Denna funktion är osäker eftersom den inte kontrollerar att de byte som skickas till den är giltiga UTF-8.
    /// Om denna begränsning bryts kan det orsaka minnesosäkerhetsproblem med future-användare av `String`, eftersom resten av standardbiblioteket antar att `Strängar är giltiga UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// // några byte, i en vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Konverterar en `String` till en byte vector.
    ///
    /// Detta förbrukar `String`, så vi behöver inte kopiera innehållet.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Extraherar en strängskiva som innehåller hela `String`.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Konverterar en `String` till en muterbar strängskiva.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Lägger till en viss strängskiva i slutet av denna `String`.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Returnerar den här "strängens" kapacitet i byte.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Säkerställer att den här strängens kapacitet är minst `additional` byte större än dess längd.
    ///
    /// Kapaciteten kan ökas med mer än `additional` byte om den väljer det för att förhindra frekventa omfördelningar.
    ///
    ///
    /// Om du inte vill ha detta "at least"-beteende, se [`reserve_exact`]-metoden.
    ///
    /// # Panics
    ///
    /// Panics om den nya kapaciteten överflödar [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Detta kanske inte faktiskt ökar kapaciteten:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s har nu en längd på 2 och en kapacitet på 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Eftersom vi redan har ytterligare 8 kapacitet, kallar vi det här ...
    /// s.reserve(8);
    ///
    /// // ... ökar faktiskt inte.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Säkerställer att den här "strängens" kapacitet är `additional` byte större än dess längd.
    ///
    /// Överväg att använda [`reserve`]-metoden om du inte vet bättre än fördelaren.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics om den nya kapaciteten överflödar `usize`.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Detta kanske inte faktiskt ökar kapaciteten:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s har nu en längd på 2 och en kapacitet på 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Eftersom vi redan har ytterligare 8 kapacitet, kallar vi det här ...
    /// s.reserve_exact(8);
    ///
    /// // ... ökar faktiskt inte.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Försöker reservera kapacitet för att minst `additional` fler element ska infogas i den angivna `String`.
    /// Samlingen kan reservera mer utrymme för att undvika frekventa omfördelningar.
    /// Efter att ha ringt `reserve` kommer kapaciteten att vara större än eller lika med `self.len() + additional`.
    /// Gör ingenting om kapaciteten redan är tillräcklig.
    ///
    /// # Errors
    ///
    /// Om kapaciteten överflödar eller om allokeraren rapporterar ett fel returneras ett fel.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Förboka minnet och avsluta om vi inte kan
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Nu vet vi att detta inte kan OOM mitt i vårt komplexa arbete
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Försöker reservera minsta kapacitet för exakt `additional` fler element som ska infogas i den angivna `String`.
    ///
    /// Efter att ha ringt `reserve_exact` kommer kapaciteten att vara större än eller lika med `self.len() + additional`.
    /// Gör ingenting om kapaciteten redan är tillräcklig.
    ///
    /// Observera att fördelaren kan ge samlingen mer utrymme än den begär.
    /// Därför kan man inte förlita sig på kapacitet att vara exakt minimal.
    /// Föredrar `reserve` om future-infogningar förväntas.
    ///
    /// # Errors
    ///
    /// Om kapaciteten överflödar eller om allokeraren rapporterar ett fel returneras ett fel.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Förboka minnet och avsluta om vi inte kan
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Nu vet vi att detta inte kan OOM mitt i vårt komplexa arbete
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Krympar kapaciteten hos denna `String` för att matcha dess längd.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Krympar kapaciteten hos denna `String` med en lägre gräns.
    ///
    /// Kapaciteten förblir minst lika stor som både längden och det levererade värdet.
    ///
    ///
    /// Om den nuvarande kapaciteten är mindre än den nedre gränsen är detta ett no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Lägger till den givna [`char`] till slutet av denna `String`.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Returnerar en bytebit av innehållet i denna `sträng`.
    ///
    /// Den inversa av denna metod är [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Förkortar `String` till den angivna längden.
    ///
    /// Om `new_len` är större än strängens nuvarande längd har detta ingen effekt.
    ///
    ///
    /// Observera att den här metoden inte har någon effekt på strängens tilldelade kapacitet
    ///
    /// # Panics
    ///
    /// Panics om `new_len` inte ligger på en [`char`]-gräns.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Tar bort det sista tecknet från strängbufferten och returnerar det.
    ///
    /// Returnerar [`None`] om den här `String` är tom.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Tar bort en [`char`] från denna `String` i en byteposition och returnerar den.
    ///
    /// Detta är en *O*(*n*) operation, eftersom det kräver att varje element i bufferten kopieras.
    ///
    /// # Panics
    ///
    /// Panics om `idx` är större än eller lika med strängens längd, eller om den inte ligger på en [`char`]-gräns.
    ///
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Ta bort alla matchningar av mönster `pat` i `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Matchningar kommer att upptäckas och tas bort iterativt, så i fall där mönster överlappar kommer endast det första mönstret att tas bort:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // SÄKERHET: start och slut är på utf8 bytegränser per
        // Sökaren dokumenterar
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Behåller endast de tecken som anges i predikatet.
    ///
    /// Med andra ord, ta bort alla tecken `c` så att `f(c)` returnerar `false`.
    /// Denna metod fungerar på plats, besöker varje tecken exakt en gång i originalordningen och bevarar ordningen på de kvarhållna karaktärerna.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Den exakta ordningen kan vara användbar för att spåra externt tillstånd, som ett index.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Peka idx till nästa karaktär
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Infogar en karaktär i denna `String` i en byteposition.
    ///
    /// Detta är en *O*(*n*) operation eftersom den kräver att varje element i bufferten kopieras.
    ///
    /// # Panics
    ///
    /// Panics om `idx` är större än strängens längd, eller om den inte ligger på en [`char`]-gräns.
    ///
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Infogar en strängskiva i denna `String` i en byteposition.
    ///
    /// Detta är en *O*(*n*) operation eftersom den kräver att varje element i bufferten kopieras.
    ///
    /// # Panics
    ///
    /// Panics om `idx` är större än strängens längd, eller om den inte ligger på en [`char`]-gräns.
    ///
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Returnerar en förändrad referens till innehållet i denna `String`.
    ///
    /// # Safety
    ///
    /// Denna funktion är osäker eftersom den inte kontrollerar att de byte som skickas till den är giltiga UTF-8.
    /// Om denna begränsning bryts kan det orsaka minnesosäkerhetsproblem med future-användare av `String`, eftersom resten av standardbiblioteket antar att `Strängar är giltiga UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Returnerar längden på denna `String`, i byte, inte [`char`] eller diagram.
    /// Med andra ord kanske det inte är vad en människa anser strängens längd.
    ///
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Returnerar `true` om denna `String` har en längd på noll och `false` annars.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Delar strängen i två vid det angivna byteindexet.
    ///
    /// Returnerar en nyligen tilldelad `String`.
    /// `self` innehåller byte `[0, at)` och den returnerade `String` innehåller byte `[at, len)`.
    /// `at` måste vara på gränsen till en UTF-8-kodpunkt.
    ///
    /// Observera att kapaciteten på `self` inte ändras.
    ///
    /// # Panics
    ///
    /// Panics om `at` inte finns på en `UTF-8`-kodpunktsgräns, eller om den ligger utanför strängens sista kodpunkt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Avkortar denna `String` och tar bort allt innehåll.
    ///
    /// Även om detta betyder att `String` har en längd på noll, berör den inte dess kapacitet.
    ///
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Skapar en tömnings iterator som tar bort det angivna intervallet i `String` och ger bort det borttagna `chars`.
    ///
    ///
    /// Note: Elementintervallet tas bort även om iteratorn inte konsumeras till slutet.
    ///
    /// # Panics
    ///
    /// Panics om startpunkten eller slutpunkten inte ligger på en [`char`]-gräns eller om de är utanför gränserna.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Ta bort intervallet upp till β från strängen
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Ett fullständigt intervall rensar strängen
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Minne säkerhet
        //
        // String-versionen av Drain har inte minnessäkerhetsproblemen för vector-versionen.
        // Uppgifterna är helt enkelt byte.
        // Eftersom avlägsnande av avstånd sker i Drop, kommer Drain-iteratorn att läcka ut, kommer inte borttagningen att ske.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Ta ut två samtidiga lån.
        // &mut-strängen kommer inte åt förrän iterationen är över, i Drop.
        let self_ptr = self as *mut _;
        // SÄKERHET: `slice::range` och `is_char_boundary` gör lämpliga gränskontroller.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Tar bort det angivna intervallet i strängen och ersätter det med den angivna strängen.
    /// Den givna strängen behöver inte ha samma längd som intervallet.
    ///
    /// # Panics
    ///
    /// Panics om startpunkten eller slutpunkten inte ligger på en [`char`]-gräns eller om de är utanför gränserna.
    ///
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Byt ut intervallet upp till β från strängen
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Minne säkerhet
        //
        // Replace_range har inte minnessäkerhetsproblem med en vector Splice.
        // av vector-versionen.Uppgifterna är helt enkelt byte.

        // VARNING: Att infoga denna variabel skulle vara osund (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // VARNING: Att infoga denna variabel skulle vara osund (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Att använda `range` igen skulle vara osunt (#81138) Vi antar att gränserna som rapporterats av `range` förblir desamma, men en kontradiktorisk implementering kan ändras mellan samtal
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Konverterar denna `String` till en [`Box`]`<`[`str`] `>`.
    ///
    /// Detta minskar eventuell överkapacitet.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Returnerar en bit av [`u8`] s byte som försökte konvertera till en `String`.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// // några ogiltiga byte, i en vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Returnerar bytes som försökte konvertera till en `String`.
    ///
    /// Denna metod är noggrant konstruerad för att undvika allokering.
    /// Det kommer att konsumera felet och flytta ut byten så att en kopia av byten inte behöver göras.
    ///
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// // några ogiltiga byte, i en vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Hämta en `Utf8Error` för att få mer information om konverteringsfel.
    ///
    /// [`Utf8Error`]-typen som tillhandahålls av [`std::str`] representerar ett fel som kan uppstå vid konvertering av en bit av [`u8`] till en [`&str`].
    /// I den meningen är det en analog till `FromUtf8Error`.
    /// Se dess dokumentation för mer information om hur du använder den.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// // några ogiltiga byte, i en vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // den första byten är ogiltig här
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Eftersom vi itererar över `String`s, kan vi undvika minst en allokering genom att hämta den första strängen från iteratorn och lägga till alla efterföljande strängar till den.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Eftersom vi itererar över CoWs kan vi (potentially) undvika minst en tilldelning genom att få det första objektet och lägga till det alla efterföljande objekt.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// En bekvämlighetsimpl som delegeras till impl för `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Skapar en tom `String`.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Implementerar `+`-operatören för att sammanfoga två strängar.
///
/// Detta förbrukar `String` på vänster sida och återanvänder bufferten (odlar den vid behov).
/// Detta görs för att undvika att tilldela en ny `String` och kopiera hela innehållet på varje operation, vilket skulle leda till *O*(*n*^ 2) körtid när man bygger en *n*-byte-sträng genom upprepad sammankoppling.
///
///
/// Strängen på höger sida lånas bara;dess innehåll kopieras till den returnerade `String`.
///
/// # Examples
///
/// Att sammanfoga två "strängar" tar den första efter värde och lånar den andra:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` flyttas och kan inte längre användas här.
/// ```
///
/// Om du vill fortsätta använda den första `String` kan du klona den och lägga till klonen istället:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` är fortfarande giltig här.
/// ```
///
/// Sammankoppling av `&str`-skivor kan göras genom att konvertera den första till en `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Implementerar `+=`-operatören för att lägga till en `String`.
///
/// Detta har samma beteende som [`push_str`][String::push_str]-metoden.
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Ett typalias för [`Infallible`].
///
/// Detta alias existerar för bakåtkompatibilitet och kan så småningom utfasas.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// En trait för att konvertera ett värde till en `String`.
///
/// Denna trait implementeras automatiskt för alla typer som implementerar [`Display`] trait.
/// Som sådan bör `ToString` inte implementeras direkt:
/// [`Display`] bör implementeras istället, och du får `ToString`-implementeringen gratis.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Konverterar det angivna värdet till en `String`.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// I denna implementering returnerar `to_string`-metoden panics om `Display`-implementeringen returnerar ett fel.
/// Detta indikerar en felaktig `Display`-implementering eftersom `fmt::Write for String` aldrig själv returnerar ett fel.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // En vanlig riktlinje är att inte integrera generiska funktioner.
    // Att ta bort `#[inline]` från denna metod orsakar dock icke försumbar regressioner.
    // Se <https://github.com/rust-lang/rust/pull/74852>, det sista försöket att försöka ta bort det.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Konverterar en `&mut str` till en `String`.
    ///
    /// Resultatet fördelas på högen.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: test drar in libstd, vilket orsakar fel här
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Konverterar den givna boxade `str`-skivan till en `String`.
    /// Det är anmärkningsvärt att `str`-segmentet ägs.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Konverterar den givna `String` till en boxad `str`-skiva som ägs.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Konverterar en strängskiva till en lånad variant.
    /// Ingen högtilldelning utförs och strängen kopieras inte.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Konverterar en sträng till en ägd variant.
    /// Ingen högtilldelning utförs och strängen kopieras inte.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Konverterar en strängreferens till en lånad variant.
    /// Ingen högtilldelning utförs och strängen kopieras inte.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Konverterar den angivna `String` till en vector `Vec` som innehåller värden av typen `u8`.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// En tömnings iterator för `String`.
///
/// Denna struktur skapas av [`drain`]-metoden på [`String`].
/// Se dess dokumentation för mer information.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Kommer att användas som&'en mutsträng i destruktorn
    string: *mut String,
    /// Börja delen som ska tas bort
    start: usize,
    /// Slut på del som ska tas bort
    end: usize,
    /// Nuvarande återstående intervall att ta bort
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Använd Vec::drain.
            // "Reaffirm" gränskontrollerna för att undvika att panic-koden sätts in igen.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Returnerar återstående (under) sträng av denna iterator som en skiva.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: uncomment AsRef impls nedan när du stabiliserar.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Kommentarer vid stabilisering av `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>för Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> för Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}