use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Specialiseringsmarkör för att samla en iteratorrörledning i en Vec medan källallokering återanvänds, dvs.
/// körning på plats.
///
/// SourceIter-föräldern trait är nödvändig för att specialiseringsfunktionen ska få tillgång till den allokering som ska återanvändas.
/// Men det räcker inte att specialiseringen är giltig.
/// Se ytterligare gränser på impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-interna SourceIter/InPlaceIterable traits implementeras endast av adapterkedjor <Adapter<Adapter<IntoIter>>> (alla ägs av core/std).
// Ytterligare gränser för adapterimplementeringarna (utöver `impl<I: Trait> Trait for Adapter<I>`) beror bara på andra traits som redan är markerade som specialisering traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. markören beror inte på hur länge användartyperna levererar.Modulera kopieringshålet, som flera andra specialiseringar redan är beroende av.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Ytterligare krav som inte kan uttryckas via trait bounds.Vi förlitar oss på konstant i stället:
        // a) inga ZST: er eftersom det inte skulle finnas någon allokering för återanvändning och pekare aritmetik skulle panic b) storlek matchar som krävs av Alloc kontrakt c) inriktningar matchar som krävs av Alloc kontrakt
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // tillbakagång till mer generiska implementeringar
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // använd try-fold sedan
        // - det vektoriserar bättre för vissa iteratoradaptrar
        // - Till skillnad från de flesta interna iterationsmetoder krävs det bara ett &mut-själv
        // - det låter oss gänga skrivpekaren genom dess inre och få tillbaka den till slut
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // iteration lyckades, tappa inte huvudet
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // kontrollera om SourceIter-kontrakten upprätthölls varning: om de inte var det kanske vi inte ens gjorde det till denna punkt
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // kolla InPlaceIterable kontrakt.Detta är endast möjligt om iteratorn alls avancerade källpekaren.
        // Om den använder okontrollerad åtkomst via TrustedRandomAccess förblir källpekaren i sin ursprungliga position och vi kan inte använda den som referens
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // släpp eventuella kvarvarande värden i källans svans men förhindra att allokeringen sjunker när IntoIter går utanför räckvidden om droppen panics läcker också alla element som samlats in i dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // InPlaceIterable-kontraktet kan inte verifieras exakt här eftersom try_fold har en exklusiv referens till källpekaren allt vi kan göra är att kontrollera om det fortfarande är inom räckhåll
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}