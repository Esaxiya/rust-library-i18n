use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Specialisering trait används för Vec::from_iter
///
/// ## Delegationsdiagrammet:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Ett vanligt fall är att ge en vector till en funktion som omedelbart samlas in i en vector.
        // Vi kan kortsluta detta om IntoIter inte har avancerats alls.
        // När det har avancerats kan vi också återanvända minnet och flytta data framåt.
        // Men vi gör det bara när den resulterande Vec inte skulle ha mer oanvänd kapacitet än att skapa den genom den generiska FromIterator-implementeringen.
        //
        // Denna begränsning är inte strikt nödvändig eftersom Vecs allokeringsbeteende är avsiktligt ospecificerat.
        // Men det är ett konservativt val.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // måste delegera till spec_extend() eftersom extend() själv delegerar till spec_from för tomma Vecs
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Detta använder `iterator.as_slice().to_vec()` eftersom spec_extend måste ta fler steg för att resonera om den slutliga kapaciteten + längden och därmed göra mer arbete.
// `to_vec()` fördelar direkt rätt belopp och fyller det exakt.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): med cfg(test) är den inneboende `[T]::to_vec`-metoden, som krävs för denna metoddefinition, inte tillgänglig.
    // Använd istället `slice::to_vec`-funktionen som endast är tillgänglig med cfg(test) OBS se slice::hack-modulen i slice.rs för mer information
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}