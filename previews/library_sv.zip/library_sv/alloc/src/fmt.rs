//! Verktyg för formatering och utskrift av "Strängar".
//!
//! Den här modulen innehåller körtidsstöd för [`format!`]-syntaxförlängningen.
//! Detta makro implementeras i kompilatorn för att sända samtal till den här modulen för att formatera argument vid körning i strängar.
//!
//! # Usage
//!
//! [`format!`]-makrot är avsett att vara bekant för dem som kommer från C: s `printf`/`fprintf`-funktioner eller Python s `str.format`-funktion.
//!
//! Några exempel på [`format!`]-tillägget är:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" med ledande nollor
//! ```
//!
//! Från dessa kan du se att det första argumentet är en formatsträng.Det krävs av kompilatorn för att detta ska vara en strängbokstav;det kan inte vara en variabel som skickas in (för att utföra giltighetskontroll).
//! Kompilatorn analyserar sedan formatsträngen och avgör om listan med angivna argument är lämplig att skicka till den här formatsträngen.
//!
//! För att konvertera ett enda värde till en sträng, använd [`to_string`]-metoden.Detta använder [`Display`]-formateringen trait.
//!
//! ## Positionsparametrar
//!
//! Varje formateringsargument får ange vilket värde-argument det refererar till, och om det utelämnas antas det vara "the next argument".
//! Till exempel skulle formatsträngen `{} {} {}` ta tre parametrar och de skulle formateras i samma ordning som de fick.
//! Formatsträngen `{2} {1} {0}` skulle dock formatera argument i omvänd ordning.
//!
//! Saker kan bli lite knepiga när du börjar blanda ihop de två typerna av positionsspecifikationer."next argument"-specifikatorn kan betraktas som en iterator över argumentet.
//! Varje gång en "next argument"-specifikator visas fortsätter iteratorn.Detta leder till beteenden som detta:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Den interna iteratorn över argumentet har inte flyttats fram när den första `{}` ses, så det skriver ut det första argumentet.Sedan uppnår den andra `{}` har iteratorn gått framåt till det andra argumentet.
//! I huvudsak påverkar inte parametrar som uttryckligen heter deras argument parametrar som inte namnger ett argument i termer av positionsspecifikationer.
//!
//! En formatsträng krävs för att använda alla dess argument, annars är det ett kompileringsfel.Du kan hänvisa till samma argument mer än en gång i formatsträngen.
//!
//! ## Namngivna parametrar
//!
//! Rust i sig har inte en Python-liknande ekvivalent av namngivna parametrar till en funktion, men [`format!`]-makrot är en syntaxförlängning som gör det möjligt att utnyttja namngivna parametrar.
//! Namngivna parametrar listas i slutet av argumentlistan och har syntax:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Följande [`format!`]-uttryck använder till exempel namngivna argument:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Det är inte giltigt att placera positionsparametrar (de utan namn) efter argument som har namn.Som med positionsparametrar är det inte giltigt att ange namngivna parametrar som inte används av formatsträngen.
//!
//! # Formateringsparametrar
//!
//! Varje argument som formateras kan transformeras av ett antal formateringsparametrar (motsvarande `format_spec` i [the syntax](#syntax)). Dessa parametrar påverkar strängrepresentationen för det som formateras.
//!
//! ## Width
//!
//! ```
//! // Alla dessa skriver ut "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Detta är en parameter för "minimum width" som formatet ska ta upp.
//! Om värdets sträng inte fyller så många tecken kommer den stoppning som anges av fill/alignment att användas för att ta upp det utrymme som krävs (se nedan).
//!
//! Värdet för bredden kan också tillhandahållas som en [`usize`] i listan över parametrar genom att lägga till en postfix `$`, vilket indikerar att det andra argumentet är en [`usize`] som anger bredden.
//!
//! Att hänvisa till ett argument med dollarsyntaxen påverkar inte "next argument"-räknaren, så det är vanligtvis en bra idé att hänvisa till argument efter position eller använda namngivna argument.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Valfri fyllningstecken och justering tillhandahålls normalt tillsammans med [`width`](#width)-parametern.Det måste definieras före `width`, direkt efter `:`.
//! Detta indikerar att om värdet som formateras är mindre än `width`, kommer några extra tecken att skrivas ut runt det.
//! Fyllning finns i följande varianter för olika inriktningar:
//!
//! * `[fill]<` - argumentet är vänsterjusterat i `width`-kolumner
//! * `[fill]^` - argumentet är mittjusterat i `width`-kolumner
//! * `[fill]>` - argumentet är högerjusterat i `width`-kolumner
//!
//! Standard [fill/alignment](#fillalignment) för icke-numerik är ett mellanslag och vänsterjusterat.Standard för numeriska formaterare är också ett mellanslagstecken men med högerjustering.
//! Om `0`-flaggan (se nedan) är specificerad för numerik är det implicita fyllningstecknet `0`.
//!
//! Observera att justering kanske inte implementeras av vissa typer.I synnerhet implementeras den generellt inte för `Debug` trait.
//! Ett bra sätt att se till att stoppning tillämpas är att formatera din inmatning och sedan mata in den resulterande strängen för att få din utdata:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Hej Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Dessa är alla flaggor som förändrar formaterarens beteende.
//!
//! * `+` - Detta är avsett för numeriska typer och indikerar att tecknet alltid ska skrivas ut.Positiva tecken skrivs aldrig ut som standard och negativtecknet skrivs endast ut som standard för `Signed` trait.
//! Denna flagga indikerar att rätt tecken (`+` eller `-`) alltid ska skrivas ut.
//! * `-` - För närvarande inte används
//! * `#` - Denna flagga indikerar att "alternate"-utskriftsformen ska användas.De alternativa formerna är:
//!     * `#?` - skriv ut [`Debug`]-formateringen
//!     * `#x` - föregår argumentet med en `0x`
//!     * `#X` - föregår argumentet med en `0x`
//!     * `#b` - föregår argumentet med en `0b`
//!     * `#o` - föregår argumentet med en `0o`
//! * `0` - Detta används för att indikera för heltalsformat att stoppningen till `width` både ska göras med ett `0`-tecken såväl som att vara teckenmedveten.
//! Ett format som `{:08}` skulle ge `00000001` för heltalet `1`, medan samma format skulle ge `-0000001` för heltalet `-1`.
//! Observera att den negativa versionen har en färre noll än den positiva versionen.
//!         Observera att stoppningsnollor alltid placeras efter tecknet (om det finns något) och före siffrorna.När det används tillsammans med `#`-flaggan gäller en liknande regel: utfyllningsnollor infogas efter prefixet men före siffrorna.
//!         Prefixet ingår i den totala bredden.
//!
//! ## Precision
//!
//! För icke-numeriska typer kan detta betraktas som en "maximum width".
//! Om den resulterande strängen är längre än denna bredd, trunkeras den ner till så många tecken och det trunkerade värdet avges med rätt `fill`, `alignment` och `width` om dessa parametrar är inställda.
//!
//! För integrerade typer ignoreras detta.
//!
//! För flytande punkttyper indikerar detta hur många siffror efter decimalpunkten som ska skrivas ut.
//!
//! Det finns tre möjliga sätt att ange önskad `precision`:
//!
//! 1. Ett heltal `.N`:
//!
//!    heltalet `N` i sig är precisionen.
//!
//! 2. Ett heltal eller namn följt av dollartecken `.N$`:
//!
//!    använd format *argument*`N` (som måste vara en `usize`) som precision.
//!
//! 3. En asterisk `.*`:
//!
//!    `.*` betyder att denna `{...}` är associerad med *två* formatingångar snarare än en: den första ingången har `usize`-precision och den andra innehåller värdet som ska skrivas ut.
//!    Observera att i det här fallet, om man använder formatsträngen `{<arg>:<spec>.*}`, hänvisar `<arg>`-delen till*-värdet * för att skriva ut, och `precision` måste komma i ingången före `<arg>`.
//!
//! Till exempel skriver följande samtal alla samma sak `Hello x is 0.01000`:
//!
//! ```
//! // Hej {arg 0 ("x")} är {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Hej {arg 1 ("x")} är {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Hej {arg 0 ("x")} är {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Hej {next arg ("x")} är {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Hej {next arg ("x")} är {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Hej {next arg ("x")} är {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Medan dessa:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! skriva ut tre väsentligt olika saker:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! På vissa programmeringsspråk beror beteendet för strängformateringsfunktioner på operativsystemets inställning för språk.
//! Formatfunktionerna som tillhandahålls av Rust s standardbibliotek har inget språkbegrepp och ger samma resultat på alla system oavsett användarkonfiguration.
//!
//! Till exempel kommer följande kod alltid att skriva ut `1.5` även om systemets språk använder en annan decimalavgränsare än en punkt.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Bokstäverna `{` och `}` kan inkluderas i en sträng genom att föregå dem med samma tecken.`{`-karaktären ryms till exempel med `{{` och `}`-karaktären ryms med `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! För att sammanfatta, här kan du hitta den fullständiga grammatiken för formatsträngar.
//! Syntaxen för det formateringsspråk som används hämtas från andra språk, så det borde inte vara för främmande.Argument är formaterade med Python-liknande syntax, vilket innebär att argument omges av `{}` istället för C-liknande `%`.
//! Den faktiska grammatiken för formateringssyntaxen är:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! I grammatiken ovan får `text` inte innehålla några `'{'`-eller `'}'`-tecken.
//!
//! # Formatera traits
//!
//! När du begär att ett argument ska formateras med en viss typ, ber du faktiskt att ett argument tillskrivs en viss trait.
//! Detta gör att flera faktiska typer kan formateras via `{:x}` (som [`i8`] såväl som [`isize`]).Den aktuella kartläggningen av typer till traits är:
//!
//! * *ingenting* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] med små och små hexadecimala heltal
//! * `X?` ⇒ [`Debug`] med versaler med hexadecimala heltal
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Vad detta betyder är att alla typer av argument som implementerar [`fmt::Binary`][`Binary`] trait sedan kan formateras med `{:b}`.Implementeringar tillhandahålls för dessa traits för ett antal primitiva typer av standardbiblioteket också.
//!
//! Om inget format anges (som i `{}` eller `{:6}`) är formatet trait som används [`Display`] trait.
//!
//! När du implementerar ett format trait för din egen typ måste du implementera en metod för signaturen:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // vår anpassade typ
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Din typ kommer att skickas som `self`-referens, och sedan ska funktionen sända utdata till `f.buf`-strömmen.Det är upp till varje format trait-implementering att korrekt följa de begärda formateringsparametrarna.
//! Värdena för dessa parametrar kommer att listas i fälten i [`Formatter`]-strukturen.För att hjälpa till med detta tillhandahåller [`Formatter`]-strukturen också några hjälpmetoder.
//!
//! Dessutom är returvärdet för denna funktion [`fmt::Result`] vilket är ett typalias för [`Resultat`]`<(),`[`std: : fmt::Error`] `>`.
//! Formatering av implementeringar bör säkerställa att de sprider fel från [`Formatter`] (t.ex. när du ringer till [`write!`]).
//! De bör dock aldrig returnera felaktigt fel.
//! Det vill säga en formateringsimplementering måste och får bara returnera ett fel om den inlämnade [`Formatter`] returnerar ett fel.
//! Detta beror på att, i motsats till vad funktionssignaturen kan föreslå, är strängformatering en ofelbar operation.
//! Den här funktionen returnerar bara ett resultat eftersom skrivning till den underliggande strömmen kan misslyckas och den måste tillhandahålla ett sätt att sprida det faktum att ett fel har inträffat tillbaka upp i stacken.
//!
//! Ett exempel på att implementera formateringen traits skulle se ut:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // `f`-värdet implementerar `Write` trait, vilket är vad man skriver!makro förväntar sig.
//!         // Observera att den här formateringen ignorerar de olika flaggor som tillhandahålls för att formatera strängar.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Olika traits tillåter olika former av utdata av en typ.
//! // Betydelsen av detta format är att skriva ut storleken på en vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Respektera formateringsflaggorna med hjälp av hjälpmetoden `pad_integral` på Formatter-objektet.
//!         // Se metoddokumentationen för detaljer, och funktionen `pad` kan användas för att stoppa strängar.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` mot `fmt::Debug`
//!
//! Dessa två formateringar traits har olika syften:
//!
//! - [`fmt::Display`][`Display`] implementeringar hävdar att typen alltid kan representeras som en UTF-8-sträng.Det förväntas **inte** att alla typer implementerar [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] implementeringar bör implementeras för **alla** offentliga typer.
//!   Output representerar vanligtvis det interna tillståndet så troget som möjligt.
//!   Syftet med [`Debug`] trait är att underlätta felsökning av Rust-kod.I de flesta fall är det tillräckligt och rekommenderat att använda `#[derive(Debug)]`.
//!
//! Några exempel på utdata från båda traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Relaterade makron
//!
//! Det finns ett antal relaterade makron i [`format!`]-familjen.De som för närvarande implementeras är:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Detta och [`writeln!`] är två makron som används för att sända ut formatsträngen till en viss ström.Detta används för att förhindra mellanallokeringar av formatsträngar och istället direkt skriva utdata.
//! Under huven åberopar denna funktion faktiskt [`write_fmt`]-funktionen definierad på [`std::io::Write`] trait.
//! Exempel på användning är:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Detta och [`println!`] släpper ut produktionen till stdout.På samma sätt som [`write!`]-makrot är målet med dessa makron att undvika mellanallokeringar vid utskrift.Exempel på användning är:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! [`eprint!`]-och [`eprintln!`]-makron är identiska med [`print!`] respektive [`println!`], förutom att de sänder ut till stderr.
//!
//! ### `format_args!`
//!
//! Detta är ett märkligt makro som används för att säkert passera ett ogenomskinligt objekt som beskriver formatsträngen.Det här objektet kräver inga högtilldelningar för att skapa, och det refererar bara till information på stacken.
//! Under huven implementeras alla relaterade makron i termer av detta.
//! För det första är några exempel på användning:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Resultatet av [`format_args!`]-makrot är ett värde av typen [`fmt::Arguments`].
//! Denna struktur kan sedan skickas till [`write`]-och [`format`]-funktionerna i denna modul för att bearbeta formatsträngen.
//! Målet med detta makro är att ytterligare förhindra mellanallokeringar när du hanterar formateringssträngar.
//!
//! Till exempel kan ett loggbibliotek använda standardformateringssyntaxen, men det skulle internt passera denna struktur tills det har bestämts var utdata ska gå.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// `format`-funktionen tar en [`Arguments`]-struktur och returnerar den resulterande formaterade strängen.
///
///
/// [`Arguments`]-instansen kan skapas med [`format_args!`]-makrot.
///
/// # Examples
///
/// Grundläggande användning:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Observera att användning av [`format!`] kan vara att föredra.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}