`core::arch` - Rust: s kärnbiblioteksarkitektur-specifika inneboende
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch`-modulen implementerar arkitekturberoende inneboende (t.ex. SIMD).

# Usage 

`core::arch` finns som en del av `libcore` och den exporteras igen av `libstd`.Föredrar att använda den via `core::arch` eller `std::arch` än via denna crate.
Instabila funktioner är ofta tillgängliga i Rust varje natt via `feature(stdsimd)`.

Att använda `core::arch` via denna crate kräver Rust varje natt, och det kan (och gör) gå sönder ofta.De enda fall där du bör överväga att använda den via denna crate är:

* om du behöver kompilera om `core::arch` själv, t.ex. med särskilda målfunktioner aktiverade som inte är aktiverade för `libcore`/`libstd`.
Note: om du behöver kompilera om det för ett icke-standardmål, föredrar du att använda `xargo` och kompilera om `libcore`/`libstd` efter behov istället för att använda denna crate.
  
* använder vissa funktioner som kanske inte är tillgängliga även bakom instabila Rust-funktioner.Vi försöker hålla dessa till ett minimum.
Om du behöver använda några av dessa funktioner, vänligen öppna ett problem så att vi kan exponera dem i Rust varje natt och du kan använda dem därifrån.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` distribueras huvudsakligen under villkoren för både MIT-licensen och Apache-licensen (version 2.0), med delar som omfattas av olika BSD-liknande licenser.

Se LICENSE-APACHE och LICENSE-MIT för mer information.

# Contribution

Om du inte uttryckligen anger något annat, ska alla bidrag som avsiktligt lämnats in i `core_arch` av dig, enligt definitionen i Apache-2.0-licensen, dubbellicensieras enligt ovan, utan några ytterligare villkor.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












