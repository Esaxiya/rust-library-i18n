use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Används för att berätta för våra `#[assert_instr]`-anteckningar att alla simd inneboende är tillgängliga för att testa deras kodegen, eftersom vissa är gated bakom en extra `-Ctarget-feature=+unimplemented-simd128` som inte har någon motsvarighet i `#[target_feature]` just nu.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}