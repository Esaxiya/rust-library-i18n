# Bidrar till stdarch

`stdarch` crate är mer än villig att ta emot bidrag!Först vill du förmodligen kolla in förvaret och se till att testerna passerar dig:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Där `<your-target-arch>` är mål-trippeln som används av `rustup`, t.ex. `x86_x64-unknown-linux-gnu` (utan föregående `nightly-` eller liknande).
Kom också ihåg att detta förvar kräver Rust s nattliga kanal!
Ovanstående tester kräver faktiskt att rust varje natt är standard på ditt system, för att ställa in den som använder `rustup default nightly` (och `rustup default stable` för att återställa).

Om något av ovanstående steg inte fungerar, [please let us know][new]!

Därefter kan du [find an issue][issues] för att hjälpa till, vi har valt några med [`help wanted`][help]-och [`impl-period`][impl]-taggar som särskilt kan använda lite hjälp. 
Du kanske är mest intresserad av [#40][vendor], implementerar alla leverantörsinternik på x86.Den frågan har några bra tips om var du ska komma igång!

Om du har allmänna frågor är du välkommen att [join us on gitter][gitter] och fråga dig!Känn dig fri att pinga antingen@BurntSushi eller@alexcrichton med frågor.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Hur man skriver exempel för stdarch-inneboende

Det finns några funktioner som måste vara aktiverade för att den givna inneboendet ska fungera korrekt och exemplet får endast köras av `cargo test --doc` när funktionen stöds av CPU: n.

Som ett resultat fungerar standard `fn main` som genereras av `rustdoc` inte (i de flesta fall).
Överväg att använda följande som en guide för att se till att ditt exempel fungerar som förväntat.

```rust
/// # // Vi behöver cfg_target_feature för att säkerställa att exemplet bara är
/// # // körs av `cargo test --doc` när processorn stöder funktionen
/// # #![feature(cfg_target_feature)]
/// # // Vi behöver target_feature för att den inneboende ska fungera
/// # #![feature(target_feature)]
/// #
/// # // rustdoc använder som standard `extern crate stdarch`, men vi behöver
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // Den verkliga huvudfunktionen
/// # fn main() {
/// #     // Kör bara detta om `<target feature>` stöds
/// #     om cfg_feature_enabled! ("<target feature>"){
/// #         // Skapa en `worker`-funktion som bara körs om målfunktionen
/// #         // stöds och se till att `target_feature` är aktiverat för din arbetare
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         osäker fn worker() {
/// // Skriv ditt exempel här.Funktionsspecifika inneboende fungerar här!Gå vild!
///
/// #         }
///
/// #         osäker { worker(); }
/// #     }
/// # }
```

Om en del av ovanstående syntax inte ser bekant ut, beskriver [Documentation as tests]-avsnittet i [Rust Book] `rustdoc`-syntaxen ganska bra.
Som alltid är du välkommen att gå till [join us on gitter][gitter] och fråga oss om du stöter på något, och tack för att du hjälper till att förbättra dokumentationen för `stdarch`!

# Alternativa testinstruktioner

Det rekommenderas i allmänhet att du använder `ci/run.sh` för att köra testerna.
Men detta kanske inte fungerar för dig, t.ex. om du använder Windows.

I så fall kan du återgå till att köra `cargo +nightly test` och `cargo +nightly test --release -p core_arch` för att testa kodgenerering.
Observera att dessa kräver att den nattliga verktygskedjan installeras och att `rustc` får veta om din mål-trippel och dess CPU.
I synnerhet måste du ställa in miljövariabeln `TARGET` som för `ci/run.sh`.
Dessutom måste du ställa in `RUSTCFLAGS` (behöver `C`) för att indikera målfunktioner, t.ex. `RUSTCFLAGS="-C -target-features=+avx2"`.
Du kan också ställa in `-C -target-cpu=native` om du "just" utvecklar mot din nuvarande CPU.

Varna att när du använder dessa alternativa instruktioner, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], t.ex.
instruktionsgenereringstest kan misslyckas eftersom demonteraren namngav dem annorlunda, t.ex.
det kan generera `vaesenc` istället för `aesenc`-instruktioner trots att de beter sig på samma sätt.
Dessa instruktioner utför också färre tester än vad som normalt skulle göras, så var inte förvånad över att när du så småningom drar förfrågan kan vissa fel dyka upp för tester som inte täcks här.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






