# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Ett bibliotek för att skaffa backtraces vid körning för Rust.
Detta bibliotek syftar till att förbättra stödet för standardbiblioteket genom att tillhandahålla ett programmatiskt gränssnitt att arbeta med, men det stöder också helt enkelt att enkelt skriva ut den aktuella backtrace som libstds panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

För att helt enkelt fånga en backtrace och skjuta upp hanteringen till en senare tid kan du använda `Backtrace`-typen på toppnivå.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Om du emellertid vill ha mer rå åtkomst till den faktiska spårningsfunktionen kan du använda `trace`-och `resolve`-funktionerna direkt.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Lös den här instruktionspekaren till ett symbolnamn
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // fortsätt till nästa bild
    });
}
```

# License

Detta projekt är licensierat under någon av

 * Apache-licens, version 2.0, ([LICENSE-APACHE](LICENSE-APACHE) eller http://www.apache.org/licenses/LICENSE-2.0)
 * MIT-licens ([LICENSE-MIT](LICENSE-MIT) eller http://opensource.org/licenses/MIT)

efter eget val.

### Contribution

Såvida du inte uttryckligen anger något annat, kommer varje bidrag som avsiktligt lämnats in för att tas med i backtrace-rs, enligt definitionen i Apache-2.0-licensen, dubbellicenserats enligt ovan, utan ytterligare villkor.







