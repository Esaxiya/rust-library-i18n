use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Representation av ett ägt och fristående bakspår.
///
/// Denna struktur kan användas för att fånga en backtrace vid olika punkter i ett program och senare användas för att inspektera vad backtrace var vid den tiden.
///
///
/// `Backtrace` stöder vacker utskrift av backtraces genom dess `Debug`-implementering.
///
/// # Nödvändiga funktioner
///
/// Denna funktion kräver att `std`-funktionen i `backtrace` crate är aktiverad och `std`-funktionen är aktiverad som standard.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Ramar här listas från topp till botten av stacken
    frames: Vec<BacktraceFrame>,
    // Det index vi tror är den faktiska början på backtrace, med utelämnande av ramar som `Backtrace::new` och `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Fångad version av en ram i en backtrace.
///
/// Den här typen returneras som en lista från `Backtrace::frames` och representerar en stackram i ett fångat bakspår.
///
/// # Nödvändiga funktioner
///
/// Denna funktion kräver att `std`-funktionen i `backtrace` crate är aktiverad och `std`-funktionen är aktiverad som standard.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Fångad version av en symbol i en backtrace.
///
/// Denna typ returneras som en lista från `BacktraceFrame::symbols` och representerar metadata för en symbol i en backtrace.
///
/// # Nödvändiga funktioner
///
/// Denna funktion kräver att `std`-funktionen i `backtrace` crate är aktiverad och `std`-funktionen är aktiverad som standard.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Fångar en backtrace på den här funktionens samtalsplats och returnerar en ägt representation.
    ///
    /// Denna funktion är användbar för att representera en backtrace som ett objekt i Rust.Det returnerade värdet kan skickas över trådar och skrivas ut någon annanstans, och syftet med detta värde är att vara helt fristående.
    ///
    /// Observera att det på vissa plattformar kan bli extremt dyrt att få en fullständig backtrace och lösa det.
    /// Om kostnaden är för hög för din applikation rekommenderas det att du istället använder `Backtrace::new_unresolved()` vilket undviker symbolupplösningssteget (som vanligtvis tar längst tid) och gör det möjligt att skjuta upp det till ett senare datum.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Nödvändiga funktioner
    ///
    /// Denna funktion kräver att `std`-funktionen i `backtrace` crate är aktiverad och `std`-funktionen är aktiverad som standard.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // vill se till att det finns en ram här att ta bort
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// På samma sätt som `new`, förutom att detta inte löser några symboler, fångar detta helt enkelt bakspåret som en lista med adresser.
    ///
    /// Vid ett senare tillfälle kan `resolve`-funktionen anropas för att lösa denna backtrace-symboler till läsbara namn.
    /// Denna funktion finns eftersom upplösningsprocessen ibland kan ta betydande tid medan någon backtrace bara sällan kan skrivas ut.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // inga symbolnamn
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // symbolnamn nu närvarande
    /// ```
    ///
    /// # Nödvändiga funktioner
    ///
    /// Denna funktion kräver att `std`-funktionen i `backtrace` crate är aktiverad och `std`-funktionen är aktiverad som standard.
    ///
    ///
    ///
    #[inline(never)] // vill se till att det finns en ram här att ta bort
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Returnerar ramarna från när denna backtrace togs.
    ///
    /// Den första inmatningen av denna del är troligen funktionen `Backtrace::new`, och den sista ramen är troligen något om hur den här tråden eller huvudfunktionen startade.
    ///
    ///
    /// # Nödvändiga funktioner
    ///
    /// Denna funktion kräver att `std`-funktionen i `backtrace` crate är aktiverad och `std`-funktionen är aktiverad som standard.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Om denna backtrace skapades från `new_unresolved` kommer denna funktion att lösa alla adresser i backtrace till deras symboliska namn.
    ///
    ///
    /// Om denna backtrace har tidigare lösts eller skapats genom `new`, gör denna funktion ingenting.
    ///
    /// # Nödvändiga funktioner
    ///
    /// Denna funktion kräver att `std`-funktionen i `backtrace` crate är aktiverad och `std`-funktionen är aktiverad som standard.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Samma som `Frame::ip`
    ///
    /// # Nödvändiga funktioner
    ///
    /// Denna funktion kräver att `std`-funktionen i `backtrace` crate är aktiverad och `std`-funktionen är aktiverad som standard.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Samma som `Frame::symbol_address`
    ///
    /// # Nödvändiga funktioner
    ///
    /// Denna funktion kräver att `std`-funktionen i `backtrace` crate är aktiverad och `std`-funktionen är aktiverad som standard.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Samma som `Frame::module_base_address`
    ///
    /// # Nödvändiga funktioner
    ///
    /// Denna funktion kräver att `std`-funktionen i `backtrace` crate är aktiverad och `std`-funktionen är aktiverad som standard.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Returnerar listan över symboler som denna ram motsvarar.
    ///
    /// Normalt finns det bara en symbol per ram, men ibland om ett antal funktioner läggs in i en ram kommer flera symboler att returneras.
    /// Den första symbolen som listas är "innermost function", medan den sista symbolen är den yttersta (sista uppringaren).
    ///
    /// Observera att om den här ramen kommer från en olöst backtrace kommer detta att returnera en tom lista.
    ///
    /// # Nödvändiga funktioner
    ///
    /// Denna funktion kräver att `std`-funktionen i `backtrace` crate är aktiverad och `std`-funktionen är aktiverad som standard.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Samma som `Symbol::name`
    ///
    /// # Nödvändiga funktioner
    ///
    /// Denna funktion kräver att `std`-funktionen i `backtrace` crate är aktiverad och `std`-funktionen är aktiverad som standard.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Samma som `Symbol::addr`
    ///
    /// # Nödvändiga funktioner
    ///
    /// Denna funktion kräver att `std`-funktionen i `backtrace` crate är aktiverad och `std`-funktionen är aktiverad som standard.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Samma som `Symbol::filename`
    ///
    /// # Nödvändiga funktioner
    ///
    /// Denna funktion kräver att `std`-funktionen i `backtrace` crate är aktiverad och `std`-funktionen är aktiverad som standard.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Samma som `Symbol::lineno`
    ///
    /// # Nödvändiga funktioner
    ///
    /// Denna funktion kräver att `std`-funktionen i `backtrace` crate är aktiverad och `std`-funktionen är aktiverad som standard.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Samma som `Symbol::colno`
    ///
    /// # Nödvändiga funktioner
    ///
    /// Denna funktion kräver att `std`-funktionen i `backtrace` crate är aktiverad och `std`-funktionen är aktiverad som standard.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // När vi skriver ut banor försöker vi ta bort cwd om den finns, annars skriver vi bara ut banan som den är.
        // Observera att vi också bara gör detta för det korta formatet, för om det är fullt vill vi antagligen skriva ut allt.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}