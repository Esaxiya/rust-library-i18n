use core::ffi::c_void;
use core::fmt;

/// Inspekterar den aktuella samtalsstacken och skickar alla aktiva ramar till stängningen som tillhandahålls för att beräkna en stackspårning.
///
/// Den här funktionen är arbetshästen för detta bibliotek vid beräkning av stackspåren för ett program.Den givna stängningen `cb` är givna instanser av en `Frame` som representerar information om den samtalsramen på stacken.
/// Förslutningen ger ramar uppifrån och ner (senast kallade funktioner först).
///
/// Avslutningens returvärde är en indikation på om backtrace ska fortsätta.Ett returvärde på `false` avslutar backtrace och returnerar omedelbart.
///
/// När en `Frame` förvärvats kommer du sannolikt att ringa `backtrace::resolve` för att konvertera `ip` (instruktionspekaren) eller symboladressen till en `Symbol` genom vilken namn och/eller filnamn/radnummer kan läras in.
///
///
/// Observera att detta är en relativt lågnivåfunktion och om du till exempel vill fånga en backtrace som ska inspekteras senare kan `Backtrace`-typen vara mer lämplig.
///
/// # Nödvändiga funktioner
///
/// Denna funktion kräver att `std`-funktionen i `backtrace` crate är aktiverad och `std`-funktionen är aktiverad som standard.
///
/// # Panics
///
/// Denna funktion strävar efter att aldrig panic, men om `cb` tillhandahöll panics kommer vissa plattformar att tvinga en dubbel panic att avbryta processen.
/// Vissa plattformar använder ett C-bibliotek som internt använder återuppringningar som inte kan lindas igenom, så panik från `cb` kan utlösa en processavbrott.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // fortsätt backtrace
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Samma som `trace`, bara osäker eftersom den är osynkroniserad.
///
/// Denna funktion har inte synkroniseringsgarantier men är tillgänglig när `std`-funktionen i denna crate inte kompileras i.
/// Se `trace`-funktionen för mer dokumentation och exempel.
///
/// # Panics
///
/// Se information på `trace` för förbehåll för `cb`-panik.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// En trait som representerar en ram i en backtrace, gav till `trace`-funktionen i denna crate.
///
/// Spårningsfunktionens stängning kommer att ge ramar och ramen skickas praktiskt taget eftersom den underliggande implementeringen inte alltid är känd förrän körning.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Returnerar den aktuella instruktionspekaren för den här ramen.
    ///
    /// Detta är normalt nästa instruktion att utföra i ramen, men inte alla implementeringar listar detta med 100% noggrannhet (men det är i allmänhet ganska nära).
    ///
    ///
    /// Vi rekommenderar att du skickar detta värde till `backtrace::resolve` för att göra det till ett symbolnamn.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Returnerar den aktuella stackpekaren för den här ramen.
    ///
    /// Om en backend inte kan återställa stackpekaren för denna ram returneras en nullpekare.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Returnerar startsymboladressen för ramen för denna funktion.
    ///
    /// Detta kommer att försöka spola tillbaka instruktionspekaren som returneras av `ip` till början av funktionen, och returnera det värdet.
    ///
    /// I vissa fall returnerar dock backender bara `ip` från den här funktionen.
    ///
    /// Det returnerade värdet kan ibland användas om `backtrace::resolve` misslyckades på `ip` ovan.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Returnerar basadressen till den modul som ramen tillhör.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Detta måste komma först, för att säkerställa att Miri prioriteras framför värdplattformen
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // endast används i dbghelp symbolisera
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}