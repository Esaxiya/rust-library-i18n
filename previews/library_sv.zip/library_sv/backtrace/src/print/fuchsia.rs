use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr tar en återuppringning som tar emot en dl_phdr_info-pekare för varje DSO som har länkats till processen.
    // dl_iterate_phdr ser också till att den dynamiska länken är låst från iteration till början till slut.
    // Om återuppringningen returnerar ett värde som inte är noll avslutas iterationen tidigt.
    // 'data' skickas som det tredje argumentet till återuppringningen vid varje samtal.
    // 'size' ger storleken på dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Vi måste analysera build-ID och några grundläggande programhuvuddata vilket innebär att vi också behöver lite grejer från ELF-specifikationen.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Nu måste vi replikera, bit för bit, strukturen för typen dl_phdr_info som används av fuchsias nuvarande dynamiska länkare.
// Chromium har också denna ABI-gräns samt crashpad.
// Så småningom vill vi flytta dessa fall för att använda elfsökning men vi måste ange det i SDK och det har ännu inte gjorts.
//
// Således fastnar vi (och de) med att behöva använda denna metod som åstadkommer en tät koppling med fuchsia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Vi har inget sätt att veta om e_phoff och e_phnum är giltiga.
    // libc bör säkerställa detta för oss dock så det är säkert att bilda en bit här.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr representerar en 64-bitars ELF-programrubrik i målarkitekturens slut.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr representerar en giltig ELF-programrubrik och dess innehåll.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Vi har inget sätt att kontrollera om p_addr eller p_memsz är giltiga.
    // Fuchsias libc tolkar anteckningarna först, men på grund av att de är här måste dessa rubriker vara giltiga.
    //
    // NoteIter kräver inte att de underliggande uppgifterna är giltiga men det kräver att gränserna är giltiga.
    // Vi litar på att libc har säkerställt att detta är fallet för oss här.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Anteckningstypen för bygg-ID: n.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr representerar ett ELF-anteckningshuvud i målets slut.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Not representerar en ELF-anteckning (rubrik + innehåll).
// Namnet lämnas som en u8-skiva eftersom det inte alltid är nollavslutat och rust gör det enkelt att kontrollera att byten matchar hur som helst.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// Med NoteIter kan du trycka itera över ett noteringssegment.
// Det upphör så snart ett fel inträffar eller om det inte finns fler anteckningar.
// Om du itererar över ogiltiga data kommer det att fungera som om inga anteckningar hittades.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Det är en konstant funktion att pekaren och storleken som anges anger ett giltigt byteområde som alla kan läsas.
    // Innehållet i dessa byte kan vara vad som helst men intervallet måste vara giltigt för att detta ska vara säkert.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to justerar 'x' till 'to'-byte-justering förutsatt att 'to' är en effekt på 2.
// Detta följer ett standardmönster i C/C ++ ELF-analyseringskod där (x + till, 1)&-to används.
// Rust låter dig inte förneka användning så jag använder
// 2-komplementkonvertering för att återskapa det.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 förbrukar antal byte från skivan (om sådan finns) och säkerställer dessutom att den slutliga skivan är korrekt justerad.
// Om antingen antalet byte som begärs är för stort eller om skivan inte kan justeras efteråt på grund av att det inte finns tillräckligt med kvarvarande byte, returneras inget och skivan ändras inte.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Denna funktion har inga riktiga invarianter som den som ringer måste upprätthålla annat än att 'bytes' ska vara anpassad för prestanda (och på vissa arkitekturer korrekt).
// Värdena i fälten Elf_Nhdr kan vara nonsens men den här funktionen garanterar inget sådant.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Detta är säkert så länge det finns tillräckligt med utrymme och vi har bara bekräftat att i if-uttalandet ovan så att detta inte borde vara osäkert.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Observera att sice_of: :<Elf_Nhdr>() är alltid 4-byte-inriktad.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Kontrollera om vi har nått slutet.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Vi överför en nhdr men vi överväger noggrant den resulterande strukturen.
        // Vi litar inte på namesz eller descsz och vi fattar inga osäkra beslut baserat på typen.
        //
        // Så även om vi tar ut helt skräp borde vi fortfarande vara säkra.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Indikerar att ett segment är körbart.
const PERM_X: u32 = 0b00000001;
/// Indikerar att ett segment är skrivbart.
const PERM_W: u32 = 0b00000010;
/// Indikerar att ett segment är läsbart.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Representerar ett ELF-segment vid körning.
struct Segment {
    /// Ger den virtuella körningsadressen för detta segments innehåll.
    addr: usize,
    /// Ger minnesstorleken för det här segmentets innehåll.
    size: usize,
    /// Ger modulens virtuella adress för detta segment med ELF-filen.
    mod_rel_addr: usize,
    /// Ger behörigheterna som finns i ELF-filen.
    /// Dessa behörigheter är dock inte nödvändigtvis de behörigheter som finns vid körning.
    flags: Perm,
}

/// Låter en itera över segment från en DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Representerar en ELF DSO (Dynamic Shared Object).
/// Denna typ refererar till de data som lagras i själva DSO snarare än att göra en egen kopia.
struct Dso<'a> {
    /// Den dynamiska länken ger oss alltid ett namn, även om namnet är tomt.
    /// När det gäller den huvudsakliga körbara filen kommer detta namn att vara tomt.
    /// I fallet med ett delat objekt blir det sonamnet (se DT_SONAME).
    name: &'a str,
    /// På Fuchsia har nästan alla binära filer bygg-ID men det är inte en strikt begäran.
    /// Det finns inget sätt att matcha DSO-information med en riktig ELF-fil efteråt om det inte finns någon build_id så vi kräver att varje DSO har en här.
    ///
    /// DSO: er utan build_id ignoreras.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Returnerar en iterator över segment i denna DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Dessa fel kodar för problem som uppstår vid analys av information om varje DSO.
///
enum Error {
    /// NameError betyder att ett fel inträffade när en C-stilsträng konverterades till en rust-sträng.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError betyder att vi inte hittade ett bygg-ID.
    /// Det kan antingen bero på att DSO inte hade något bygg-ID eller att segmentet som innehåller bygg-ID var felaktigt.
    ///
    BuildIDError,
}

/// Anropar antingen 'dso' eller 'error' för varje DSO som är länkad till processen av den dynamiska länken.
///
///
/// # Arguments
///
/// * `visitor` - En DsoPrinter som har en av ätmetoderna kallas för varje DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr ser till att info.name pekar på en giltig plats.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Denna funktion skriver ut Fuchsia-symboliseringsmarkeringen för all information som finns i en DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}