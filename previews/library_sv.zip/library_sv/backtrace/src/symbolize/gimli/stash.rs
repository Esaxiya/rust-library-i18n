// används endast på Linux just nu, så tillåt död kod någon annanstans
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// En enkel arenatilldelare för bytebuffertar.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Tilldelar en buffert av den angivna storleken och returnerar en muterbar referens till den.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SÄKERHET: detta är den enda funktionen som någonsin konstruerar en muterbar
        // hänvisning till `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // SÄKERHET: vi tar aldrig bort element från `self.buffers`, så en referens
        // till data i varje buffert kommer att leva så länge `self` gör.
        &mut buffers[i]
    }
}