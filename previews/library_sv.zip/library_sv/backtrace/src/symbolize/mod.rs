use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Lös en adress till en symbol genom att skicka symbolen till den angivna stängningen.
///
/// Denna funktion kommer att leta upp den givna adressen i områden som den lokala symboltabellen, den dynamiska symboltabellen eller DWARF-felsökningsinformation (beroende på den aktiverade implementeringen) för att hitta symboler att ge.
///
///
/// Avslutningen kanske inte anropas om upplösning inte kunde utföras, och det kan också kallas mer än en gång i fallet med inline-funktioner.
///
/// Symboler som visas representerar körningen vid den angivna `addr`, och returnerar file/line-par för den adressen (om tillgänglig).
///
/// Observera att om du har en `Frame` rekommenderas det att du använder `resolve_frame`-funktionen istället för den här.
///
/// # Nödvändiga funktioner
///
/// Denna funktion kräver att `std`-funktionen i `backtrace` crate är aktiverad och `std`-funktionen är aktiverad som standard.
///
/// # Panics
///
/// Denna funktion strävar efter att aldrig panic, men om `cb` tillhandahöll panics kommer vissa plattformar att tvinga en dubbel panic att avbryta processen.
/// Vissa plattformar använder ett C-bibliotek som internt använder återuppringningar som inte kan lindas igenom, så panik från `cb` kan utlösa en processavbrott.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // titta bara på den övre ramen
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Lös en tidigare fångstram till en symbol och överför symbolen till den angivna stängningen.
///
/// Denna funktion utför samma funktion som `resolve` förutom att den tar en `Frame` som ett argument istället för en adress.
/// Detta kan tillåta vissa plattformsimplementeringar av backtracing för att ge mer exakt symbolinformation eller information om exempelvis inline-ramar.
///
/// Det rekommenderas att använda detta om du kan.
///
/// # Nödvändiga funktioner
///
/// Denna funktion kräver att `std`-funktionen i `backtrace` crate är aktiverad och `std`-funktionen är aktiverad som standard.
///
/// # Panics
///
/// Denna funktion strävar efter att aldrig panic, men om `cb` tillhandahöll panics kommer vissa plattformar att tvinga en dubbel panic att avbryta processen.
/// Vissa plattformar använder ett C-bibliotek som internt använder återuppringningar som inte kan lindas igenom, så panik från `cb` kan utlösa en processavbrott.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // titta bara på den övre ramen
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// IP-värden från stackramar är vanligtvis (always?) instruktionen *efter* samtalet som är det faktiska stackspåret.
// Symbolisering av detta på gör att filename/line-numret ligger ett framåt och kanske i tomrummet om det är nära slutet av funktionen.
//
// Detta verkar i princip alltid vara fallet på alla plattformar, så vi subtraherar alltid en från en löst ip för att lösa den till den tidigare samtalsinstruktionen istället för att instruktionen återgår till.
//
//
// Helst skulle vi inte göra detta.
// Helst skulle vi kräva att uppringare av `resolve` API: er här manuellt gör -1 och redogör för att de vill ha platsinformation för *föregående* instruktion, inte nuvarande.
// Helst skulle vi också exponera på `Frame` om vi verkligen är adressen till nästa instruktion eller nuvarande.
//
// För nu men detta är en ganska nisch oro så vi bara internt alltid subtrahera en.
// Konsumenterna bör fortsätta arbeta och få ganska bra resultat, så vi ska vara tillräckligt bra.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Samma som `resolve`, bara osäker eftersom den är osynkroniserad.
///
/// Denna funktion har inte synkroniseringsgarantier men är tillgänglig när `std`-funktionen i denna crate inte kompileras i.
/// Se `resolve`-funktionen för mer dokumentation och exempel.
///
/// # Panics
///
/// Se information på `resolve` för förbehåll för `cb`-panik.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Samma som `resolve_frame`, bara osäker eftersom den är osynkroniserad.
///
/// Denna funktion har inte synkroniseringsgarantier men är tillgänglig när `std`-funktionen i denna crate inte kompileras i.
/// Se `resolve_frame`-funktionen för mer dokumentation och exempel.
///
/// # Panics
///
/// Se information på `resolve_frame` för förbehåll för `cb`-panik.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// En trait som representerar upplösningen av en symbol i en fil.
///
/// Denna trait ges som ett trait-objekt mot stängningen till `backtrace::resolve`-funktionen, och den skickas praktiskt taget eftersom det är okänt vilken implementering som ligger bakom den.
///
///
/// En symbol kan ge kontextuell information om en funktion, till exempel namn, filnamn, radnummer, exakt adress etc.
/// Inte all information är alltid tillgänglig i en symbol, så alla metoder returnerar en `Option`.
///
///
pub struct Symbol {
    // TODO: denna livstidsbundna måste fortsätta så småningom till `Symbol`,
    // men det är för närvarande en brytande förändring.
    // För närvarande är detta säkert eftersom `Symbol` bara delas ut som referens och inte kan klonas.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Returnerar namnet på den här funktionen.
    ///
    /// Den returnerade strukturen kan användas för att fråga olika egenskaper om symbolnamnet:
    ///
    ///
    /// * `Display`-implementeringen skriver ut den demanglade symbolen.
    /// * Det råa `str`-värdet för symbolen kan nås (om det är giltigt utf-8).
    /// * De råa byten för symbolnamnet kan nås.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Returnerar startfunktionen för denna funktion.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Returnerar det råa filnamnet som ett segment.
    /// Detta är främst användbart för `no_std`-miljöer.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Returnerar kolumnnumret för var den här symbolen för närvarande körs.
    ///
    /// Endast gimli ger för närvarande ett värde här och även då endast om `filename` returnerar `Some`, och så är det följaktligen föremål för liknande förbehåll.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Returnerar radnumret för var den här symbolen för närvarande körs.
    ///
    /// Detta returvärde är vanligtvis `Some` om `filename` returnerar `Some` och är följaktligen föremål för liknande förbehåll.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Returnerar filnamnet där den här funktionen definierades.
    ///
    /// Detta är för närvarande endast tillgängligt när libbacktrace eller gimli används (t.ex.
    /// unix andra plattformar) och när en binär sammanställs med debuginfo.
    /// Om inget av dessa villkor är uppfyllda kommer detta troligen att returnera `None`.
    ///
    /// # Nödvändiga funktioner
    ///
    /// Denna funktion kräver att `std`-funktionen i `backtrace` crate är aktiverad och `std`-funktionen är aktiverad som standard.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Kanske en tolkad C++ -symbol, om tolkning av den manglade symbolen som Rust misslyckades.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Se till att ha den här nollstorleken så att `cpp_demangle`-funktionen inte kostar när den är inaktiverad.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Ett omslag runt ett symbolnamn för att ge ergonomiska accessorer till det demanglade namnet, de råa byten, råsträngen etc.
///
// Tillåt dödkod för när `cpp_demangle`-funktionen inte är aktiverad.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Skapar ett nytt symbolnamn från de råa underliggande byten.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Returnerar det råa (mangled)-symbolnamnet som en `str` om symbolen är giltig utf-8.
    ///
    /// Använd `Display`-implementeringen om du vill ha den demanglade versionen.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Returnerar det råa symbolnamnet som en lista med byte
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Det här kan skrivas ut om den demanglade symbolen inte är giltig, så hantera felet här graciöst genom att inte sprida det utåt.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Försök att återta det cachade minnet som används för att symbolisera adresser.
///
/// Denna metod kommer att försöka släppa alla globala datastrukturer som annars har cachats globalt eller i tråden som vanligtvis representerar analyserad DWARF-information eller liknande.
///
///
/// # Caveats
///
/// Även om den här funktionen alltid är tillgänglig gör den faktiskt ingenting på de flesta implementeringar.
/// Bibliotek som dbghelp eller libbacktrace tillhandahåller inte faciliteter för att omplacera tillstånd och hantera det tilldelade minnet.
/// För närvarande är `gimli-symbolize`-funktionen i denna crate den enda funktionen där denna funktion har någon effekt.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}