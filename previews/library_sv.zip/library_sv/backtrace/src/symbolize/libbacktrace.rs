//! Symboliseringsstrategi med DWARF-analyseringskoden i libbacktrace.
//!
//! Libbacktrace C-biblioteket, som vanligtvis distribueras med gcc, stöder inte bara att skapa en backtrace (som vi faktiskt inte använder) utan också att symbolisera backtrace och hantera dvärgfelsökningsinformation om saker som inline-ramar och vad som helst.
//!
//!
//! Detta är relativt komplicerat på grund av många olika problem här, men grundidén är:
//!
//! * Först kallar vi `backtrace_syminfo`.Detta får symbolinformation från den dynamiska symboltabellen om vi kan.
//! * Därefter kallar vi `backtrace_pcinfo`.Detta analyserar debuginfo-tabeller om de är tillgängliga och låter oss återställa information om inbyggda ramar, filnamn, radnummer etc.
//!
//! Det finns massor av knep för att få dvärgtabellerna till libbacktrace, men förhoppningsvis är det inte världens ände och är tillräckligt tydligt när du läser nedan.
//!
//! Detta är standardiseringsstrategin för plattformar som inte är MSVC och OSX.I libstd är detta dock standardstrategin för OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Om möjligt föredrar `function`-namnet som kommer från debuginfo och kan vanligtvis vara mer exakt för exempelvis inline-ramar.
                // Om det inte finns men fall tillbaka till symboltabellnamnet som anges i `symname`.
                //
                // Observera att `function` ibland kan kännas något mindre exakt, till exempel att vara listad som `try<i32,closure>` inte är `std::panicking::try::do_call`.
                //
                // Det är inte riktigt klart varför, men totalt sett verkar `function`-namnet mer exakt.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // gör ingenting för tillfället
}

/// Typ av `data`-pekaren som överförs till `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // När denna återuppringning anropas från `backtrace_syminfo` när vi börjar lösa går vi längre för att ringa `backtrace_pcinfo`.
    // `backtrace_pcinfo`-funktionen konsulterar felsökningsinformation och försöker göra saker som att återställa file/line-information samt inline-ramar.
    // Observera dock att `backtrace_pcinfo` kan misslyckas eller inte göra mycket om det inte finns felsökningsinformation, så om det händer kommer vi säkert att ringa tillbaka med minst en symbol från `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Typ av `data`-pekaren som överförs till `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Libbacktrace API stöder att skapa ett tillstånd, men det stöder inte att förstöra ett tillstånd.
// Jag personligen anser att detta betyder att en stat är tänkt att skapas och sedan leva för evigt.
//
// Jag skulle gärna registrera en at_exit()-hanterare som rensar upp detta tillstånd, men libbacktrace ger inget sätt att göra det.
//
// Med dessa begränsningar har denna funktion ett statiskt cachat tillstånd som beräknas första gången detta begärs.
//
// Kom ihåg att backtracing allt sker seriellt (ett globalt lås).
//
// Observera att bristen på synkronisering här beror på kravet att `resolve` är externt synkroniserad.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Utöva inte trådsäkra funktioner i libbacktrace eftersom vi alltid kallar det på ett synkroniserat sätt.
        //
        0,
        error_cb,
        ptr::null_mut(), // inga extra data
    );

    return STATE;

    // Observera att för att libbacktrace ska kunna fungera alls måste den hitta DWARF-felsökningsinformationen för den aktuella körbara filen.Det gör det vanligtvis via ett antal mekanismer inklusive, men inte begränsat till:
    //
    // * /proc/self/exe på stödda plattformar
    // * Filnamnet skickades in uttryckligen när du skapade tillstånd
    //
    // Libbacktrace-biblioteket är ett stort antal C-koder.Det betyder naturligtvis att det har minnessäkerhetsproblem, särskilt vid hantering av felformad debuginfo.
    // Libstd har stött på massor av dessa historiskt.
    //
    // Om /proc/self/exe används kan vi vanligtvis ignorera dessa eftersom vi antar att libbacktrace är "mostly correct" och annars inte gör konstiga saker med "attempted to be correct" dvärgfelsökningsinformation.
    //
    //
    // Om vi skickar in ett filnamn är det dock möjligt på vissa plattformar (som BSD) där en skadlig skådespelare kan orsaka att en godtycklig fil placeras på den platsen.
    // Det betyder att om vi berättar libbacktrace om ett filnamn kan det använda en godtycklig fil, vilket möjligen orsakar segfel.
    // Om vi inte säger till libbacktrace någonting kommer det inte att göra någonting på plattformar som inte stöder banor som /proc/self/exe!
    //
    // Med tanke på allt försöker vi så hårt som möjligt att *inte* skicka in ett filnamn, men vi måste på plattformar som inte stöder /proc/self/exe alls.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Observera att vi helst skulle vilja använda `std::env::current_exe`, men vi kan inte kräva `std` här.
            //
            // Använd `_NSGetExecutablePath` för att ladda den aktuella körbara sökvägen till ett statiskt område (som om det är för litet bara ger upp).
            //
            //
            // Observera att vi på allvar litar på libbacktrace här för att inte dö på korrupta körbara filer, men det gör det verkligen ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows har ett läge för att öppna filer där det inte kan raderas efter det att det har öppnats.
            // Det är i allmänhet vad vi vill ha här eftersom vi vill se till att vår körbarhet inte förändras under oss efter att vi lämnat den till libbacktrace, förhoppningsvis minskar möjligheten att skicka godtyckliga data till libbacktrace (som kan misshandlas).
            //
            //
            // Med tanke på att vi gör lite dans här för att försöka få ett slags lås på vår egen bild:
            //
            // * Ta hand om den aktuella processen, ladda filnamnet.
            // * Öppna en fil till det filnamnet med rätt flaggor.
            // * Ladda om den aktuella processens filnamn och se till att den är densamma
            //
            // Om allt går igenom har vi i teorin verkligen öppnat vår processfil och vi är garanterade att det inte kommer att förändras.FWIW en massa av detta kopieras från libstd historiskt, så det här är min bästa tolkning av vad som hände.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Detta lever i statiskt minne så att vi kan returnera det ..
                static mut BUF: [i8; N] = [0; N];
                // ... och detta lever på stacken eftersom det är tillfälligt
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // läcker avsiktligt `handle` här för att ha det öppet borde bevara vårt lås på detta filnamn.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Vi vill returnera en skiva som är nul-avslutad, så om allt var fyllt i och det är lika med den totala längden, likställ det med misslyckande.
                //
                //
                // Annars när du återvänder framgång, se till att nulbyte ingår i segmentet.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // backtrace-fel sopas för närvarande under mattan
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Ring `backtrace_syminfo` API som (från att läsa koden) ska ringa `syminfo_cb` exakt en gång (eller misslyckas med ett förmodligen fel).
    // Vi hanterar sedan mer inom `syminfo_cb`.
    //
    // Observera att vi gör detta eftersom `syminfo` kommer att konsultera symboltabellen och hitta symbolnamn även om det inte finns någon felsökningsinformation i binären.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}