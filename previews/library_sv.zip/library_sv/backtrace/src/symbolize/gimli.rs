//! Stöd för symbolisering med `gimli` crate på crates.io
//!
//! Detta är standardimplementeringen av symbolisering för Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // "statisk livstid är en lögn att hacka kring brist på stöd för självreferensstrukturer.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Konvertera till 'statiska livstider eftersom symbolerna bara ska låna `map` och `stash` och vi bevarar dem nedan.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // För att ladda inbyggda bibliotek på Windows, se en del diskussioner på rust-lang/rust#71060 för de olika strategierna här.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW-bibliotek stöder för närvarande inte ASLR (rust-lang/rust#16514), men DLL-filer kan fortfarande flyttas runt i adressutrymmet.
            // Det verkar som om adresser i felsökningsinformation alla är som om detta bibliotek laddades på "image base", vilket är ett fält i dess COFF-filrubriker.
            // Eftersom detta är vad debuginfo verkar lista, analyserar vi symboltabellen och lagrar adresser som om biblioteket också var laddat på "image base".
            //
            // Biblioteket kanske inte laddas på "image base".
            // (förmodligen kan något annat laddas där?) Det är här `bias`-fältet spelar in och vi måste räkna ut värdet på `bias` här.Tyvärr är det dock inte klart hur man skaffar detta från en laddad modul.
            // Vad vi har är dock den faktiska lastadressen (`modBaseAddr`).
            //
            // Som en bit av en cop-out för nu mmap vi filen, läser filhuvudinformationen och släpper sedan mmap.Det här är slösaktigt eftersom vi antagligen öppnar mmap senare, men det borde fungera tillräckligt bra för nu.
            //
            // När vi väl har `image_base` (önskad lastplats) och `base_addr` (faktisk lastplats) kan vi fylla i `bias` (skillnad mellan den faktiska och önskade) och sedan är den angivna adressen för varje segment `image_base` eftersom det är vad filen säger.
            //
            //
            // För närvarande verkar det som att till skillnad från ELF/MachO kan vi nöja oss med ett segment per bibliotek med `modBaseSize` som hela storleken.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS använder Mach-O-filformatet och använder DYLD-specifika API: er för att ladda en lista över inbyggda bibliotek som ingår i applikationen.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Hämta namnet på det här biblioteket som motsvarar sökvägen till var du ska ladda det också.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Ladda bildhuvudet i detta bibliotek och delegera till `object` för att analysera alla lastkommandon så att vi kan räkna ut alla inblandade segment här.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Iterera över segmenten och registrera kända regioner för segment som vi hittar.
            // Registrera dessutom information om textsegment för bearbetning senare, se kommentarer nedan.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Bestäm "slide" för det här biblioteket, vilket i slutändan blir den förspänning vi använder för att ta reda på var i minnet objekt laddas.
            // Detta är dock lite konstig beräkning och är resultatet av att prova några saker i naturen och se vad som sitter fast.
            //
            // Den allmänna idén är att `bias` plus ett segment `stated_virtual_memory_address` kommer att vara där i det faktiska adressutrymmet segmentet finns.
            // Det andra vi förlitar oss på är dock att en riktig adress minus `bias` är indexet för att slå upp i symboltabellen och debuginfo.
            //
            // Det visar sig dock att dessa beräkningar är felaktiga för systemladdade bibliotek.För inbyggda körbara filer verkar det dock vara korrekt.
            // Att lyfta lite logik från LLDB: s källa och har något specialhölje för den första `__TEXT`-sektionen laddad från filoffset 0 med en icke-nollstorlek.
            // Oavsett anledning när detta är närvarande verkar det innebära att symboltabellen är relativt bara vmaddr-bilden för biblioteket.
            // Om den *inte* är närvarande är symboltabellen relativt vmaddr-bilden plus segmentets angivna adress.
            //
            // För att hantera denna situation om vi *inte* hittar ett textavsnitt vid filförskjutning noll ökar vi förspänningen med de första textavsnitten angivna adress och minskar också alla angivna adresser med det beloppet.
            //
            // På det sättet visas alltid symboltabellen i förhållande till bibliotekets biasbelopp.
            // Detta verkar ha rätt resultat för att symbolisera via symboltabellen.
            //
            // Ärligt talat är jag inte helt säker på om det här är rätt eller om det finns något annat som borde indikera hur man gör det.
            // För nu men det verkar fungera tillräckligt bra (?) och vi borde alltid kunna justera detta över tid om det behövs.
            //
            // För mer information, se #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Andra Unix (t.ex.
        // Linux)-plattformar använder ELF som ett objektfilformat och implementerar vanligtvis ett API som heter `dl_iterate_phdr` för att ladda inbyggda bibliotek.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` bör vara en giltig pekare.
        // `vec` ska vara en giltig pekare till en `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 stödjer inte felsökningsinformation, men byggsystemet kommer att placera felsökningsinformation på sökvägen `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Allt annat ska använda ELF, men vet inte hur man laddar inbyggda bibliotek.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Alla kända delade bibliotek som har laddats.
    libraries: Vec<Library>,

    /// Mappningscache där vi behåller analyserad dvärginformation.
    ///
    /// Denna lista har en fast kapacitet för hela dess lyftid som aldrig ökar.
    /// `usize`-elementet i varje par är ett index i `libraries` ovanför där `usize::max_value()` representerar den nuvarande körbara filen.
    ///
    /// `Mapping` är motsvarande analyserad dvärginformation.
    ///
    /// Observera att detta i princip är en LRU-cache och vi kommer att flytta saker här inne när vi symboliserar adresser.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Segment av detta bibliotek laddas i minnet och var de laddas.
    segments: Vec<LibrarySegment>,
    /// "bias" i detta bibliotek, vanligtvis där den laddas i minnet.
    /// Detta värde läggs till varje segments angivna adress för att få den faktiska virtuella minnesadressen som segmentet laddas in i.
    /// Dessutom subtraheras denna förspänning från riktiga virtuella minnesadresser för att indexeras till debuginfo och symboltabellen.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Den angivna adressen för detta segment i objektfilen.
    /// Det här är faktiskt inte där segmentet laddas, utan snarare är den här adressen plus det innehållande bibliotekets `bias` var du hittar den.
    ///
    stated_virtual_memory_address: usize,
    /// Storleken på detta segment i minnet.
    len: usize,
}

// osäker eftersom detta krävs för att synkroniseras externt
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // osäker eftersom detta krävs för att synkroniseras externt
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // En mycket liten, mycket enkel LRU-cache för felsökningsmappningar.
        //
        // Hitfrekvensen borde vara mycket hög, eftersom den vanliga stacken inte korsar mellan många delade bibliotek.
        //
        // `addr2line::Context`-strukturerna är ganska dyra att skapa.
        // Dess kostnad förväntas skrivas av efterföljande `locate`-frågor, som utnyttjar strukturerna som byggts när man konstruerar `addr2line: : Context`s för att få bra hastigheter.
        //
        // Om vi inte hade den här cachen skulle den amorteringen aldrig hända och symboliserande backtraces skulle vara ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Testa först om den här `lib` har något segment som innehåller `addr` (hantering av omplacering).Om denna kontroll passerar kan vi fortsätta nedan och faktiskt översätta adressen.
                //
                // Observera att vi använder `wrapping_add` här för att undvika överflödskontroller.Det har sett i naturen att SVMA + biasberäkning överflödar.
                // Det verkar lite konstigt att det skulle hända men det finns inte så mycket vi kan göra åt det förutom att förmodligen bara ignorera dessa segment eftersom de sannolikt pekar ut i rymden.
                //
                // Detta kom ursprungligen upp i rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Nu när vi vet att `lib` innehåller `addr` kan vi kompensera med förspänningen för att hitta den angivna virutala minnesadressen.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Invariant: efter att detta villkorliga slutförts utan att återvända tidigt
        // från ett fel är cacheposten för den här sökvägen vid index 0.

        if let Some(idx) = idx {
            // När kartläggningen redan finns i cachen flyttar du den framåt.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // När mappningen inte finns i cachen skapar du en ny mappning, sätter in den i cachens framsida och avlägsnar den äldsta cacheposten om det behövs.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // läck inte `'static`-livstiden, se till att den bara är för oss själva
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Förläng livslängden på `sym` till `'static` eftersom vi tyvärr är skyldiga att komma hit, men det går alltid ut som en referens, så ingen hänvisning till den ska ändå bestå utöver denna ram.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Slutligen få en cachad mappning eller skapa en ny mappning för den här filen och utvärdera DWARF-informationen för att hitta file/line/name för den här adressen.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Vi kunde hitta raminformation för denna symbol, och `addr2line`s ram internt har alla smutsiga detaljer.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Det gick inte att hitta felsökningsinformation, men vi hittade den i symboltabellen för den alf körbara.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}