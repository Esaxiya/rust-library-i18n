//! Plattformberoende typer.

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// En plattformsoberoende representation av en sträng.
/// När du arbetar med `std`-aktiverad rekommenderas det för bekvämlighetsmetoderna för att ge konverteringar till `std`-typer.
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// En bit, som vanligtvis tillhandahålls på Unix-plattformar.
    Bytes(&'a [u8]),
    /// Breda strängar vanligtvis från Windows.
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// Lossy konverterar till en `Cow<str>`, allokeras om `Bytes` inte är giltigt UTF-8 eller om `BytesOrWideString` är `Wide`.
    ///
    /// # Nödvändiga funktioner
    ///
    /// Denna funktion kräver att `std`-funktionen i `backtrace` crate är aktiverad och `std`-funktionen är aktiverad som standard.
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// Ger en `Path`-representation av `BytesOrWideString`.
    ///
    /// # Nödvändiga funktioner
    ///
    /// Denna funktion kräver att `std`-funktionen i `backtrace` crate är aktiverad och `std`-funktionen är aktiverad som standard.
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}