#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// En formaterare för backtraces.
///
/// Denna typ kan användas för att skriva ut en backtrace oavsett var backtrace kommer ifrån.
/// Om du har en `Backtrace`-typ använder `Debug`-implementeringen redan detta utskriftsformat.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// De tryckstilar som vi kan skriva ut
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Skriver ut en terser-backtrace som helst endast innehåller relevant information
    Short,
    /// Skriver ut en backtrace som innehåller all möjlig information
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Skapa en ny `BacktraceFmt` som skriver utdata till den medföljande `fmt`.
    ///
    /// `format`-argumentet styr den stil där bakspåret skrivs ut, och `print_path`-argumentet kommer att användas för att skriva ut `BytesOrWideString`-instanser av filnamn.
    /// Denna typ i sig gör ingen utskrift av filnamn, men denna återuppringning krävs för att göra det.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Skriver ut en inledning för bakspåret som ska skrivas ut.
    ///
    /// Detta krävs på vissa plattformar för att backtraces ska kunna symboliseras helt senare, och annars borde det bara vara den första metoden du ringer efter att du skapat en `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Lägger till en ram i backtrace-utgången.
    ///
    /// Detta åtagande returnerar en RAII-instans av en `BacktraceFrameFmt` som kan användas för att faktiskt skriva ut en ram och vid förstörelse kommer den att öka ramräknaren.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Slutför backtrace-utmatningen.
    ///
    /// Detta är för närvarande ett no-op men läggs till för future-kompatibilitet med backtrace-format.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // För närvarande en no-op-- inklusive denna hook för att möjliggöra future tillägg.
        Ok(())
    }
}

/// En formaterare för bara en ram av en backtrace.
///
/// Denna typ skapas av `BacktraceFmt::frame`-funktionen.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Skriver ut en `BacktraceFrame` med denna ramformatör.
    ///
    /// Detta kommer att rekursivt skriva ut alla `BacktraceSymbol`-instanser inom `BacktraceFrame`.
    ///
    /// # Nödvändiga funktioner
    ///
    /// Denna funktion kräver att `std`-funktionen i `backtrace` crate är aktiverad och `std`-funktionen är aktiverad som standard.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Skriver ut en `BacktraceSymbol` i en `BacktraceFrame`.
    ///
    /// # Nödvändiga funktioner
    ///
    /// Denna funktion kräver att `std`-funktionen i `backtrace` crate är aktiverad och `std`-funktionen är aktiverad som standard.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: det här är inte bra att vi inte slutar skriva ut någonting
            // med icke-utf8-filnamn.
            // Tack och lov är nästan allt utf8 så det här borde inte vara så illa.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Skriver ut en rå spårad `Frame` och `Symbol`, vanligtvis från de råa återuppringningarna av denna crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Lägger till en rå ram till backtrace-utgången.
    ///
    /// Den här metoden tar, till skillnad från den tidigare, de råa argumenten om de kommer från olika platser.
    /// Observera att detta kan anropas flera gånger för en bildruta.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Lägger till en rå ram i backtrace-utdata, inklusive kolumninformation.
    ///
    /// Den här metoden tar, som den föregående, de råa argumenten om de kommer från olika platser.
    /// Observera att detta kan anropas flera gånger för en bildruta.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia kan inte symbolisera inom en process så det har ett speciellt format som kan användas för att symbolisera senare.
        // Skriv ut det istället för att skriva ut adresser i vårt eget format här.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Inget behov av att skriva ut "null"-ramar, det betyder i princip bara att systemets backtrace var lite ivrig att spåra super långt.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // För att minska TCB-storlek i Sgx-enklave vill vi inte implementera symbolupplösningsfunktioner.
        // Snarare kan vi skriva ut offset för adressen här, som senare kan kartläggas för att fungera korrekt.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Skriv ut ramens index såväl som ramens valfria instruktionspekare.
        // Om vi är bortom den första symbolen i den här ramen skriver vi bara ut lämpligt utrymme.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Därefter skriver du ut namnet på symbolen med hjälp av alternativ formatering för mer information om vi är en fullständig backtrace.
        // Här hanterar vi också symboler som inte har något namn,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Och senast, skriv ut filename/line-numret om de finns tillgängliga.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line skrivs ut på rader under symbolnamnet, så skriv ut något lämpligt utrymme för att sortera rätt.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Delegera till vår interna återuppringning för att skriva ut filnamnet och skriva ut radnumret.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Lägg till kolumnnummer, om tillgängligt.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Vi bryr oss bara om den första symbolen för en ram
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}