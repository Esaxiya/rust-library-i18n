//! En modul för att hantera dbghelp-bindningar på Windows
//!
//! Backtraces på Windows (åtminstone för MSVC) drivs till stor del via `dbghelp.dll` och de olika funktionerna som den innehåller.
//! Dessa funktioner laddas för närvarande *dynamiskt* i stället för att länka till `dbghelp.dll` statiskt.
//! Detta görs för närvarande av standardbiblioteket (och krävs i teorin där), men är ett försök att hjälpa till att minska de statiska dll-beroendena i ett bibliotek eftersom bakspår är vanligtvis ganska valfria.
//!
//! Med detta sagt laddar `dbghelp.dll` nästan alltid framgångsrikt på Windows.
//!
//! Observera dock att eftersom vi laddar allt detta stöd dynamiskt kan vi faktiskt inte använda de råa definitionerna i `winapi`, utan snarare måste vi själva definiera funktionspekartyperna och använda det.
//! Vi vill inte vara med att duplicera winapi, så vi har en Cargo-funktion `verify-winapi` som hävdar att alla bindningar matchar de i winapi och den här funktionen är aktiverad på CI.
//!
//! Slutligen noterar du här att dll för `dbghelp.dll` aldrig lossas, och det är för närvarande avsiktligt.
//! Tanken är att vi globalt kan cacha den och använda den mellan samtal till API, och undvika dyra loads/unloads.
//! Om detta är ett problem för läcksökare eller något liknande kan vi korsa bron när vi kommer dit.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Arbeta runt `SymGetOptions` och `SymSetOptions` som inte är närvarande i själva winapi.
// Annars används det bara när vi dubbelkontrollerar typer mot winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Inte definierat i winapi än
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Detta definieras i winapi, men det är felaktigt (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Inte definierat i winapi än
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Detta makro används för att definiera en `Dbghelp`-struktur som internt innehåller alla funktionspekare som vi kan ladda.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// Den laddade DLL-filen för `dbghelp.dll`
            dll: HMODULE,

            // Varje funktionspekare för varje funktion vi kan använda
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Inledningsvis har vi inte laddat DLL-filen
            dll: 0 as *mut _,
            // Initiera alla funktioner är nollställda för att säga att de behöver laddas dynamiskt.
            //
            $($name: 0,)*
        };

        // Bekvämlighet typedef för varje funktionstyp.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Försök att öppna `dbghelp.dll`.
            /// Returnerar framgång om det fungerar eller fel om `LoadLibraryW` misslyckas.
            ///
            /// Panics om biblioteket redan är laddat.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Funktion för varje metod vi vill använda.
            // När den anropas läser den antingen cachad funktionspekare eller laddar den och returnerar det laddade värdet.
            // Belastningar hävdas att lyckas.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Bekväm proxy för att använda rengöringslås för att referera till dbghelp-funktioner.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Initiera allt stöd som krävs för att komma åt `dbghelp` API-funktioner från denna crate.
///
///
/// Observera att denna funktion är **säker**, den har intern synkronisering.
/// Observera också att det är säkert att anropa denna funktion flera gånger rekursivt.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Det första vi behöver göra är att synkronisera den här funktionen.Detta kan kallas samtidigt från andra trådar eller rekursivt inom en tråd.
        // Observera att det är knepigare än det, för det vi använder här, `dbghelp`,*måste också* synkroniseras med alla andra som ringer till `dbghelp` i den här processen.
        //
        // Vanligtvis finns det inte så många samtal till `dbghelp` inom samma process och vi kan antagligen säkert anta att vi är de enda som får åtkomst till den.
        // Det finns dock en primär annan användare som vi måste oroa oss för som ironiskt nog är oss själva, men i standardbiblioteket.
        // Standardbiblioteket Rust beror på detta crate för stöd för backtrace, och detta crate finns också på crates.io.
        // Det betyder att om standardbiblioteket skriver ut en panic-backtrace kan det köra med denna crate som kommer från crates.io, vilket orsakar segfel.
        //
        // För att lösa detta synkroniseringsproblem använder vi ett Windows-specifikt trick här (det är trots allt en Windows-specifik begränsning om synkronisering).
        // Vi skapar en *session-local* med namnet mutex för att skydda detta samtal.
        // Avsikten här är att standardbiblioteket och detta crate inte behöver dela API: er för Rust-nivå för att synkronisera här utan istället kan arbeta bakom kulisserna för att se till att de synkroniseras med varandra.
        //
        // På det sättet när denna funktion anropas via standardbiblioteket eller genom crates.io kan vi vara säkra på att samma mutex förvärvas.
        //
        // Så allt detta är att säga att det första vi gör här är att vi atomiskt skapar en `HANDLE` som är en namngiven mutex på Windows.
        // Vi synkroniserar lite med andra trådar som delar den här funktionen specifikt och ser till att endast ett handtag skapas per instans av den här funktionen.
        // Observera att handtaget aldrig stängs när det har lagrats globalt.
        //
        // Efter att vi faktiskt har gått i låset förvärvar vi det helt enkelt, och vårt `Init`-handtag som vi delar ut kommer att vara ansvarigt för att tappa det så småningom.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Okej!Nu när vi alla är säkert synkroniserade, låt oss faktiskt börja bearbeta allt.
        // Först måste vi se till att `dbghelp.dll` faktiskt laddas i denna process.
        // Vi gör detta dynamiskt för att undvika ett statiskt beroende.
        // Detta har historiskt gjorts för att arbeta kring konstiga länkningsproblem och är avsett att göra binärer lite mer bärbara eftersom detta till stor del bara är ett felsökningsverktyg.
        //
        //
        // När vi väl har öppnat `dbghelp.dll` måste vi kalla några initialiseringsfunktioner i den, och det beskrivs mer nedan.
        // Vi gör det dock bara en gång, så vi har en global boolean som anger om vi är klara ännu eller inte.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Se till att `SYMOPT_DEFERRED_LOADS`-flaggan är inställd, för enligt MSVC: s egna dokument om detta: "This is the fastest, most efficient way to use the symbol handler.", så låt oss göra det!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Initiera faktiskt symboler med MSVC.Observera att detta kan misslyckas, men vi ignorerar det.
        // Det finns inte massor av tidigare känd teknik för detta i sig, men LLVM verkar internt ignorera returvärdet här och ett av desinfektionsbiblioteken i LLVM skriver ut en läskig varning om detta misslyckas men i princip ignorerar det på lång sikt.
        //
        //
        // Ett fall detta kommer upp mycket för Rust är att standardbiblioteket och detta crate på crates.io båda vill tävla om `SymInitializeW`.
        // Standardbiblioteket ville historiskt initialisera sedan städa för det mesta, men nu när det använder denna crate betyder det att någon kommer att initialiseras först och den andra kommer att plocka upp den initialiseringen.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}