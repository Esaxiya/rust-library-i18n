use backtrace::Backtrace;

// Detta test fungerar bara på plattformar som har en fungerande `symbol_address`-funktion för ramar som rapporterar startadressen för en symbol.
// Som ett resultat är det bara aktiverat på några plattformar.
//
const ENABLED: bool = cfg!(all(
    // Windows har inte riktigt testats och OSX stöder inte att hitta en slutande ram, så inaktivera detta
    //
    target_os = "linux",
    // På ARM hittar den bifogande funktionen helt enkelt att returnera ip själv.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}