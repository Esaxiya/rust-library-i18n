// rsbegin.o och rsend.o är den så kallade "compiler runtime startup objects".
// De innehåller kod som behövs för att korrekt initiera kompilatorns körtid.
//
// När en körbar eller dylib-bild är länkad är all användarkod och bibliotek "sandwiched" mellan dessa två objektfiler, så kod eller data från rsbegin.o blir först i respektive avsnitt av bilden, medan kod och data från rsend.o blir de sista.
// Denna effekt kan användas för att placera symboler i början eller i slutet av ett avsnitt, samt för att infoga eventuella sidhuvuden eller sidfötter.
//
// Observera att den faktiska modulens startpunkt är belägen i C-runtime-startobjektet (vanligtvis kallat `crtX.o`), som sedan åberopar initialiseringsåteruppringningar av andra runtime-komponenter (registrerade via ännu en speciell bildsektion).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Markerar början på stapelramens varningsinformation
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Skrapa utrymme för att avveckla intern bokföring.
    // Detta definieras som `struct object` i $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Koppla av info registration/deregistration-rutiner.
    // Se dokumenten för libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // registrera avkopplingsinfo vid start av modulen
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // avregistrera vid avstängning
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-specifik init/uninit rutinregistrering
    pub mod mingw_init {
        // MinGWs startobjekt (crt0.o/dllcrt0.o) kommer att anropa globala konstruktörer i .ctors-och .dtors-sektionerna vid start och utgång.
        // När det gäller DLL-filer görs detta när DLL laddas och lossas.
        //
        // Länkaren sorterar avsnitten, vilket säkerställer att våra återuppringningar finns i slutet av listan.
        // Eftersom konstruktörer körs i omvänd ordning säkerställer detta att våra återuppringningar är de första och sista som utförs.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C-återuppringningar vid initialisering
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C-återuppringningar för avslutning
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}