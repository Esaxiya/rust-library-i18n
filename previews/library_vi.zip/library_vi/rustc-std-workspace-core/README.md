# `rustc-std-workspace-core` crate

crate này là một miếng đệm và crate rỗng, chỉ đơn giản phụ thuộc vào `libcore` và xuất lại tất cả nội dung của nó.
crate là mấu chốt của việc trao quyền cho thư viện tiêu chuẩn để phụ thuộc vào crates từ crates.io

Crates trên crates.io mà thư viện tiêu chuẩn phụ thuộc vào nhu cầu phụ thuộc vào `rustc-std-workspace-core` crate từ crates.io, trống.

Chúng tôi sử dụng `[patch]` để ghi đè nó thành crate này trong kho lưu trữ này.
Do đó, crates trên crates.io sẽ vẽ một edge phụ thuộc vào `libcore`, phiên bản được xác định trong kho lưu trữ này.
Điều đó sẽ vẽ tất cả các cạnh phụ thuộc để đảm bảo Cargo xây dựng crates thành công!

Lưu ý rằng crates trên crates.io cần phụ thuộc vào crate này với tên `core` để mọi thứ hoạt động chính xác.Để làm điều đó, họ có thể sử dụng:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Thông qua việc sử dụng phím `package`, crate được đổi tên thành `core`, có nghĩa là nó sẽ giống như

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

khi Cargo gọi trình biên dịch, thỏa mãn chỉ thị `extern crate core` ngầm được đưa vào bởi trình biên dịch.




