# `rustc-std-workspace-std` crate

Xem tài liệu về `rustc-std-workspace-core` crate.