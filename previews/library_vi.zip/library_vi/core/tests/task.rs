use core::task::Poll;

#[test]
fn poll_const() {
    // kiểm tra xem các phương thức của `Poll` có thể sử dụng được trong ngữ cảnh const không

    const POLL: Poll<usize> = Poll::Pending;

    const IS_READY: bool = POLL.is_ready();
    assert!(!IS_READY);

    const IS_PENDING: bool = POLL.is_pending();
    assert!(IS_PENDING);
}