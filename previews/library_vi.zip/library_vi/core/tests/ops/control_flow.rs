use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Đây không phải là diện tích bề mặt ổn định, nhưng giúp giữ cho `?` rẻ giữa chúng, ngay cả khi LLVM không phải lúc nào cũng có thể tận dụng nó ngay bây giờ.
    //
    // (Đáng tiếc là Kết quả và Tùy chọn không nhất quán, vì vậy ControlFlow không thể khớp với cả hai.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}