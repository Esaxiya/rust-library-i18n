use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri quá chậm
fn exact_sanity_test() {
    // Thử nghiệm này kết thúc chạy những gì tôi chỉ có thể giả định là một số trường hợp góc của hàm thư viện `exp2`, được xác định trong bất kỳ thời gian chạy C nào mà chúng tôi đang sử dụng.
    // Trong VS 2013, chức năng này rõ ràng có một lỗi vì thử nghiệm này không thành công khi được liên kết, nhưng với VS 2015, lỗi xuất hiện đã được sửa vì thử nghiệm chạy tốt.
    //
    // Lỗi này dường như là sự khác biệt trong giá trị trả về của `exp2(-1057)`, trong đó VS 2013 trả về giá trị kép với mẫu bit 0x2 và trong VS 2015, nó trả về 0x20000.
    //
    //
    // Bây giờ chỉ cần bỏ qua thử nghiệm này hoàn toàn trên MSVC vì nó đã được thử nghiệm ở nơi khác và chúng tôi không quan tâm lắm đến việc thử nghiệm triển khai exp2 của mỗi nền tảng.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}