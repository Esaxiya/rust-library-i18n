//! Xác định trình lặp sở hữu `IntoIter` cho các mảng.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Một trình lặp [array] theo giá trị.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Đây là mảng mà chúng tôi đang lặp lại.
    ///
    /// Các phần tử có chỉ mục `i` trong đó `alive.start <= i < alive.end` chưa được tạo ra và là các mục nhập mảng hợp lệ.
    /// Các phần tử có chỉ số `i < alive.start` hoặc `i >= alive.end` đã được tạo ra và không được truy cập nữa!Những phần tử chết đó thậm chí có thể ở trạng thái hoàn toàn chưa được khởi tạo!
    ///
    ///
    /// Vì vậy, các bất biến là:
    /// - `data[alive]` còn sống (tức là chứa các phần tử hợp lệ)
    /// - `data[..alive.start]` và `data[alive.end..]` đã chết (tức là các phần tử đã được đọc và không được chạm vào nữa!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Các phần tử trong `data` chưa được tạo ra.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Tạo một trình lặp mới trên `array` đã cho.
    ///
    /// *Lưu ý*: phương pháp này có thể không được chấp nhận trong future, sau [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Loại `value` ở đây là `i32`, thay vì `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // AN TOÀN: Quá trình chuyển đổi ở đây thực sự an toàn.Tài liệu của `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` được đảm bảo có cùng kích thước và sự liên kết
        // > như `T`.
        //
        // Các tài liệu thậm chí còn hiển thị chuyển đổi từ một mảng `MaybeUninit<T>` sang một mảng `T`.
        //
        //
        // Với điều đó, việc khởi tạo này thỏa mãn các bất biến.

        // FIXME(LukasKalbertodt): thực sự sử dụng `mem::transmute` ở đây, khi nó hoạt động với const generics:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Cho đến lúc đó, chúng ta có thể sử dụng `mem::transmute_copy` để tạo một bản sao bitwise như một kiểu khác, sau đó quên `array` để nó không bị rớt.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Trả về một lát không thay đổi của tất cả các phần tử chưa được tạo ra.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // AN TOÀN: Chúng tôi biết rằng tất cả các phần tử trong `alive` đều được khởi tạo đúng cách.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Trả về một lát cắt có thể thay đổi của tất cả các phần tử chưa được tạo ra.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // AN TOÀN: Chúng tôi biết rằng tất cả các phần tử trong `alive` đều được khởi tạo đúng cách.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Nhận chỉ số tiếp theo từ phía trước.
        //
        // Tăng `alive.start` lên 1 duy trì sự bất biến liên quan đến `alive`.
        // Tuy nhiên, do sự thay đổi này, trong một thời gian ngắn, vùng còn sống không phải là `data[alive]` nữa mà là `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Đọc phần tử từ mảng.
            // AN TOÀN: `idx` là một chỉ mục trong vùng "alive" trước đây của
            // mảng.Đọc phần tử này tức là `data[idx]` coi như chết ngay (tức là không đụng hàng).
            // Vì `idx` là vùng khởi đầu của vùng sống, nên vùng còn sống bây giờ là `data[alive]` một lần nữa, khôi phục tất cả các bất biến.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Nhận chỉ số tiếp theo từ phía sau.
        //
        // Giảm `alive.end` đi 1 duy trì sự bất biến liên quan đến `alive`.
        // Tuy nhiên, do sự thay đổi này, trong một thời gian ngắn, vùng còn sống không phải là `data[alive]` nữa mà là `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Đọc phần tử từ mảng.
            // AN TOÀN: `idx` là một chỉ mục trong vùng "alive" trước đây của
            // mảng.Đọc phần tử này tức là `data[idx]` coi như chết ngay (tức là không đụng hàng).
            // Vì `idx` là phần cuối của vùng sống, nên vùng còn sống bây giờ là `data[alive]` một lần nữa, khôi phục tất cả các bất biến.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // AN TOÀN: Điều này là an toàn: `as_mut_slice` trả về chính xác lát phụ
        // trong số các phần tử chưa được chuyển đi và vẫn bị loại bỏ.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Sẽ không bao giờ bị chảy dưới do bất biến `live.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Trình lặp thực sự báo cáo độ dài chính xác.
// Số phần tử "alive" (sẽ vẫn được tạo ra) là độ dài của phạm vi `alive`.
// Phạm vi này được giảm độ dài trong `next` hoặc `next_back`.
// Nó luôn giảm đi 1 trong các phương thức đó, nhưng chỉ khi `Some(_)` được trả về.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Lưu ý, chúng tôi không thực sự cần phải khớp chính xác cùng một phạm vi còn sống, vì vậy chúng tôi có thể sao chép vào khoảng bù 0 bất kể `self` ở đâu.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Nhân bản tất cả các yếu tố còn sống.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Viết một bản sao vào mảng mới, sau đó cập nhật phạm vi còn sống của nó.
            // Nếu nhân bản panics, chúng tôi sẽ thả các mục trước đó một cách chính xác.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Chỉ in các phần tử chưa được tạo ra: chúng tôi không thể truy cập các phần tử đã được kết xuất nữa.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}