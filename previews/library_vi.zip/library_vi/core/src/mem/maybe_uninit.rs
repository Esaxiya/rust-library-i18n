use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Một loại trình bao bọc để tạo các phiên bản chưa khởi tạo của `T`.
///
/// # Khởi tạo bất biến
///
/// Nói chung, trình biên dịch giả định rằng một biến được khởi tạo đúng theo các yêu cầu về kiểu của biến.Ví dụ, một biến kiểu tham chiếu phải được căn chỉnh và không phải là NULL.
/// Đây là một bất biến phải *luôn* được duy trì, ngay cả trong mã không an toàn.
/// Do đó, không khởi tạo biến kiểu tham chiếu sẽ gây ra [undefined behavior][ub] tức thời, bất kể tham chiếu đó có được sử dụng để truy cập bộ nhớ hay không:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // hành vi không xác định!⚠️
/// // Mã tương đương với `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // hành vi không xác định!⚠️
/// ```
///
/// Điều này được trình biên dịch khai thác cho các tối ưu hóa khác nhau, chẳng hạn như kiểm tra thời gian chạy và tối ưu hóa bố cục `enum`.
///
/// Tương tự, bộ nhớ hoàn toàn chưa khởi tạo có thể có bất kỳ nội dung nào, trong khi `bool` luôn phải là `true` hoặc `false`.Do đó, việc tạo `bool` chưa được khởi tạo là hành vi không xác định:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // hành vi không xác định!⚠️
/// // Mã tương đương với `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // hành vi không xác định!⚠️
/// ```
///
/// Hơn nữa, bộ nhớ chưa khởi tạo đặc biệt ở chỗ nó không có giá trị cố định ("fixed" nghĩa là "it won't change without being written to").Đọc nhiều lần cùng một byte chưa khởi tạo có thể cho các kết quả khác nhau.
/// Điều này làm cho hành vi không được xác định để có dữ liệu chưa được khởi tạo trong một biến ngay cả khi biến đó có kiểu số nguyên, nếu không thì có thể giữ bất kỳ mẫu bit *cố định* nào:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // hành vi không xác định!⚠️
/// // Mã tương đương với `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // hành vi không xác định!⚠️
/// ```
/// (Lưu ý rằng các quy tắc xung quanh số nguyên chưa khởi tạo vẫn chưa được hoàn thiện, nhưng cho đến khi chúng có, bạn nên tránh chúng.)
///
/// Trên hết, hãy nhớ rằng hầu hết các kiểu đều có các biến bổ sung ngoài việc chỉ đơn thuần được coi là khởi tạo ở cấp kiểu.
/// Ví dụ, một [`Vec<T>`] khởi tạo `1` được coi là khởi tạo (trong quá trình triển khai hiện tại; điều này không cấu thành một đảm bảo ổn định) bởi vì yêu cầu duy nhất mà trình biên dịch biết về nó là con trỏ dữ liệu phải khác rỗng.
/// Việc tạo `Vec<T>` như vậy không gây ra hành vi *ngay lập tức* không xác định, nhưng sẽ gây ra hành vi không xác định với hầu hết các hoạt động an toàn (bao gồm cả việc thả nó).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` phục vụ để kích hoạt mã không an toàn để xử lý dữ liệu chưa được khởi tạo.
/// Đó là một tín hiệu cho trình biên dịch cho biết rằng dữ liệu ở đây có thể *không* được khởi tạo:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Tạo một tham chiếu chưa được khởi tạo rõ ràng.
/// // Trình biên dịch biết rằng dữ liệu bên trong `MaybeUninit<T>` có thể không hợp lệ và do đó đây không phải là UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Đặt nó thành một giá trị hợp lệ.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Trích xuất dữ liệu đã khởi tạo-điều này chỉ được phép *sau khi* khởi tạo `x` đúng cách!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Sau đó, trình biên dịch biết để không đưa ra bất kỳ giả định hoặc tối ưu hóa không chính xác nào đối với mã này.
///
/// Bạn có thể nghĩ về `MaybeUninit<T>` giống như `Option<T>` nhưng không có bất kỳ tính năng theo dõi thời gian chạy và không có bất kỳ kiểm tra an toàn nào.
///
/// ## out-pointers
///
/// Bạn có thể sử dụng `MaybeUninit<T>` để triển khai "out-pointers": thay vì trả về dữ liệu từ một hàm, hãy chuyển nó một con trỏ đến một số bộ nhớ (uninitialized) để đưa kết quả vào.
/// Điều này có thể hữu ích khi điều quan trọng là người gọi phải kiểm soát cách bộ nhớ mà kết quả được lưu trữ trong được cấp phát như thế nào và bạn muốn tránh các động thái không cần thiết.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` không bỏ nội dung cũ, đó là điều quan trọng.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Bây giờ chúng ta biết `v` đã được khởi tạo!Điều này cũng đảm bảo vector được thả đúng cách.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Khởi tạo mảng từng phần tử
///
/// `MaybeUninit<T>` có thể được sử dụng để khởi tạo một mảng lớn từng phần tử:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Tạo một mảng `MaybeUninit` chưa khởi tạo.
///     // `assume_init` an toàn vì loại mà chúng tôi tuyên bố đã khởi tạo ở đây là một loạt các ``Có thểUninit` ', không yêu cầu khởi tạo.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Đánh rơi `MaybeUninit` không làm gì cả.
///     // Do đó, việc sử dụng chỉ định con trỏ thô thay vì `ptr::write` sẽ không làm giảm giá trị cũ chưa được khởi tạo.
/////
///     // Ngoài ra, nếu có panic trong vòng lặp này, chúng tôi có một rò rỉ bộ nhớ, nhưng không có vấn đề về an toàn bộ nhớ.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Mọi thứ đều được khởi tạo.
///     // Chuyển mảng sang kiểu đã khởi tạo.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Bạn cũng có thể làm việc với các mảng được khởi tạo một phần, có thể được tìm thấy trong cấu trúc dữ liệu cấp thấp.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Tạo một mảng `MaybeUninit` chưa khởi tạo.
/// // `assume_init` an toàn vì loại mà chúng tôi tuyên bố đã khởi tạo ở đây là một loạt các ``Có thểUninit` ', không yêu cầu khởi tạo.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Đếm số phần tử chúng ta đã gán.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Đối với mỗi mục trong mảng, hãy giảm xuống nếu chúng tôi đã phân bổ nó.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Khởi tạo một trường cấu trúc theo từng trường
///
/// Bạn có thể sử dụng `MaybeUninit<T>` và macro [`std::ptr::addr_of_mut`] để khởi tạo trường cấu trúc theo trường:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Khởi tạo trường `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Khởi tạo trường `list` Nếu có panic ở đây, thì `String` trong trường `name` bị rò rỉ.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Tất cả các trường đều được khởi tạo, vì vậy chúng tôi gọi `assume_init` để lấy Foo được khởi tạo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` được đảm bảo có cùng kích thước, căn chỉnh và ABI như `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Tuy nhiên, hãy nhớ rằng kiểu *chứa* a `MaybeUninit<T>` không nhất thiết phải có cùng một bố cục;Nói chung, Rust không đảm bảo rằng các trường của `Foo<T>` có cùng thứ tự với `Foo<U>` ngay cả khi `T` và `U` có cùng kích thước và căn chỉnh.
///
/// Hơn nữa, vì bất kỳ giá trị bit nào hợp lệ cho `MaybeUninit<T>`, trình biên dịch không thể áp dụng tối ưu hóa non-zero/niche-filling, có khả năng dẫn đến kích thước lớn hơn:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Nếu `T` là FFI an toàn, thì `MaybeUninit<T>` cũng vậy.
///
/// Mặc dù `MaybeUninit` là `#[repr(transparent)]` (cho thấy nó đảm bảo cùng kích thước, căn chỉnh và ABI như `T`), điều này *không* thay đổi bất kỳ cảnh báo nào trước đó.
/// `Option<T>` và `Option<MaybeUninit<T>>` vẫn có thể có các kích thước khác nhau và các kiểu chứa trường kiểu `T` có thể được bố trí (và có kích thước) khác với trường đó là `MaybeUninit<T>`.
/// `MaybeUninit` là một loại liên minh và `#[repr(transparent)]` trên liên kết không ổn định (xem [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Theo thời gian, các đảm bảo chính xác của `#[repr(transparent)]` đối với các công đoàn có thể phát triển và `MaybeUninit` có thể vẫn là `#[repr(transparent)]` hoặc không.
/// Điều đó nói rằng, `MaybeUninit<T>` sẽ *luôn* đảm bảo rằng nó có cùng kích thước, sự liên kết và ABI như `T`;nó chỉ là cách `MaybeUninit` triển khai đảm bảo có thể phát triển.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang mục để chúng ta có thể bọc các loại khác vào đó.Điều này rất hữu ích cho máy phát điện.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Không gọi `T::clone()`, chúng tôi không thể biết liệu chúng tôi đã khởi tạo đủ cho việc đó hay chưa.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Tạo `MaybeUninit<T>` mới được khởi tạo với giá trị đã cho.
    /// Có thể gọi [`assume_init`] trên giá trị trả về của hàm này là an toàn.
    ///
    /// Lưu ý rằng việc thả `MaybeUninit<T>` sẽ không bao giờ gọi mã thả của `T`.
    /// Bạn có trách nhiệm đảm bảo `T` bị rơi nếu nó được khởi chạy.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Tạo `MaybeUninit<T>` mới ở trạng thái chưa khởi tạo.
    ///
    /// Lưu ý rằng việc thả `MaybeUninit<T>` sẽ không bao giờ gọi mã thả của `T`.
    /// Bạn có trách nhiệm đảm bảo `T` bị rơi nếu nó được khởi chạy.
    ///
    /// Xem [type-level documentation][MaybeUninit] để biết một số ví dụ.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Tạo một mảng mới gồm các mục `MaybeUninit<T>`, ở trạng thái chưa khởi tạo.
    ///
    /// Note: trong phiên bản future Rust phương pháp này có thể trở nên không cần thiết khi cú pháp mảng chữ cho phép [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Ví dụ dưới đây có thể sử dụng `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Trả về một phần dữ liệu (có thể nhỏ hơn) đã thực sự được đọc
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // AN TOÀN: `[MaybeUninit<_>; LEN]` chưa khởi tạo là hợp lệ.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Tạo `MaybeUninit<T>` mới ở trạng thái chưa khởi tạo, với bộ nhớ được lấp đầy bởi các byte `0`.Nó phụ thuộc vào `T` liệu điều đó đã thực hiện cho việc khởi tạo thích hợp hay chưa.
    ///
    /// Ví dụ: `MaybeUninit<usize>::zeroed()` được khởi tạo, nhưng `MaybeUninit<&'static i32>::zeroed()` thì không vì các tham chiếu không được rỗng.
    ///
    /// Lưu ý rằng việc thả `MaybeUninit<T>` sẽ không bao giờ gọi mã thả của `T`.
    /// Bạn có trách nhiệm đảm bảo `T` bị rơi nếu nó được khởi chạy.
    ///
    /// # Example
    ///
    /// Cách sử dụng chính xác của hàm này: khởi tạo một cấu trúc bằng 0, trong đó tất cả các trường của cấu trúc có thể giữ mẫu bit 0 như một giá trị hợp lệ.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Cách sử dụng chức năng này không chính xác*: gọi `x.zeroed().assume_init()` khi `0` không phải là mẫu bit hợp lệ cho kiểu:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Bên trong một cặp, chúng tôi tạo ra một `NotZero` không có phân biệt hợp lệ.
    /// // Đây là hành vi không xác định.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // AN TOÀN: `u.as_mut_ptr()` trỏ đến bộ nhớ được cấp phát.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Đặt giá trị của `MaybeUninit<T>`.
    /// Điều này sẽ ghi đè bất kỳ giá trị nào trước đó mà không làm giảm giá trị đó, vì vậy hãy cẩn thận không sử dụng nó hai lần trừ khi bạn muốn bỏ qua việc chạy trình hủy.
    ///
    /// Để thuận tiện cho bạn, điều này cũng trả về một tham chiếu có thể thay đổi đến nội dung (hiện đã được khởi tạo an toàn) của `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // AN TOÀN: Chúng tôi vừa khởi tạo giá trị này.
        unsafe { self.assume_init_mut() }
    }

    /// Nhận một con trỏ đến giá trị được chứa.
    /// Đọc từ con trỏ này hoặc biến nó thành một tham chiếu là hành vi không xác định trừ khi `MaybeUninit<T>` được khởi chạy.
    /// Việc ghi vào bộ nhớ mà con trỏ (non-transitively) này trỏ tới là hành vi không xác định (ngoại trừ bên trong `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Cách sử dụng chính xác của phương pháp này:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Tạo một tham chiếu vào `MaybeUninit<T>`.Điều này không sao vì chúng tôi đã khởi tạo nó.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Cách sử dụng không chính xác* của phương pháp này:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Chúng tôi đã tạo một tham chiếu đến vector chưa được khởi tạo!Đây là hành vi không xác định.⚠️
    /// ```
    ///
    /// (Lưu ý rằng các quy tắc xung quanh các tham chiếu đến dữ liệu chưa được khởi tạo vẫn chưa được hoàn thiện, nhưng cho đến khi chúng có, bạn nên tránh chúng.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` và `ManuallyDrop` đều là `repr(transparent)` nên chúng ta có thể ép kiểu con trỏ.
        self as *const _ as *const T
    }

    /// Nhận một con trỏ có thể thay đổi đến giá trị được chứa.
    /// Đọc từ con trỏ này hoặc biến nó thành một tham chiếu là hành vi không xác định trừ khi `MaybeUninit<T>` được khởi chạy.
    ///
    /// # Examples
    ///
    /// Cách sử dụng chính xác của phương pháp này:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Tạo một tham chiếu vào `MaybeUninit<Vec<u32>>`.
    /// // Điều này không sao vì chúng tôi đã khởi tạo nó.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Cách sử dụng không chính xác* của phương pháp này:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Chúng tôi đã tạo một tham chiếu đến vector chưa được khởi tạo!Đây là hành vi không xác định.⚠️
    /// ```
    ///
    /// (Lưu ý rằng các quy tắc xung quanh các tham chiếu đến dữ liệu chưa được khởi tạo vẫn chưa được hoàn thiện, nhưng cho đến khi chúng có, bạn nên tránh chúng.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` và `ManuallyDrop` đều là `repr(transparent)` nên chúng ta có thể ép kiểu con trỏ.
        self as *mut _ as *mut T
    }

    /// Trích xuất giá trị từ vùng chứa `MaybeUninit<T>`.Đây là một cách tuyệt vời để đảm bảo rằng dữ liệu sẽ bị giảm xuống, vì kết quả `T` phải chịu sự xử lý rơi thông thường.
    ///
    /// # Safety
    ///
    /// Người gọi phải đảm bảo rằng `MaybeUninit<T>` thực sự đang ở trạng thái khởi tạo.Việc gọi này khi nội dung chưa được khởi tạo hoàn toàn sẽ gây ra hành vi không xác định ngay lập tức.
    /// [type-level documentation][inv] chứa nhiều thông tin hơn về bất biến khởi tạo này.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Trên hết, hãy nhớ rằng hầu hết các kiểu đều có các biến bổ sung ngoài việc chỉ đơn thuần được coi là khởi tạo ở cấp kiểu.
    /// Ví dụ, một [`Vec<T>`] khởi tạo `1` được coi là khởi tạo (trong quá trình triển khai hiện tại; điều này không cấu thành một đảm bảo ổn định) bởi vì yêu cầu duy nhất mà trình biên dịch biết về nó là con trỏ dữ liệu phải khác rỗng.
    ///
    /// Việc tạo `Vec<T>` như vậy không gây ra hành vi *ngay lập tức* không xác định, nhưng sẽ gây ra hành vi không xác định với hầu hết các hoạt động an toàn (bao gồm cả việc thả nó).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Cách sử dụng chính xác của phương pháp này:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Cách sử dụng không chính xác* của phương pháp này:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` vẫn chưa được khởi tạo, vì vậy dòng cuối cùng này gây ra hành vi không xác định.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // AN TOÀN: người gọi phải đảm bảo rằng `self` đã được khởi tạo.
        // Điều này cũng có nghĩa là `self` phải là một biến thể `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Đọc giá trị từ vùng chứa `MaybeUninit<T>`.Kết quả `T` có thể xử lý rơi thông thường.
    ///
    /// Bất cứ khi nào có thể, bạn nên sử dụng [`assume_init`] để thay thế, điều này ngăn việc sao chép nội dung của `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Người gọi phải đảm bảo rằng `MaybeUninit<T>` thực sự đang ở trạng thái khởi tạo.Việc gọi này khi nội dung chưa được khởi tạo hoàn toàn gây ra hành vi không xác định.
    /// [type-level documentation][inv] chứa nhiều thông tin hơn về bất biến khởi tạo này.
    ///
    /// Hơn nữa, điều này để lại một bản sao của cùng một dữ liệu trong `MaybeUninit<T>`.
    /// Khi sử dụng nhiều bản sao dữ liệu (bằng cách gọi `assume_init_read` nhiều lần hoặc lần đầu tiên gọi `assume_init_read` rồi đến [`assume_init`]), bạn có trách nhiệm đảm bảo rằng dữ liệu đó thực sự có thể bị trùng lặp.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Cách sử dụng chính xác của phương pháp này:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` là `Copy`, vì vậy chúng tôi có thể đọc nhiều lần.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Việc sao chép giá trị `None` là được, vì vậy chúng tôi có thể đọc nhiều lần.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Cách sử dụng không chính xác* của phương pháp này:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Bây giờ chúng tôi đã tạo ra hai bản sao của cùng một vector, dẫn đến một bản sao ⚠️ miễn phí khi cả hai đều bị rơi!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // AN TOÀN: người gọi phải đảm bảo rằng `self` đã được khởi tạo.
        // Đọc từ `self.as_ptr()` là an toàn vì `self` nên được khởi tạo.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Giảm giá trị chứa tại chỗ.
    ///
    /// Nếu bạn có quyền sở hữu `MaybeUninit`, bạn có thể sử dụng [`assume_init`] để thay thế.
    ///
    /// # Safety
    ///
    /// Người gọi phải đảm bảo rằng `MaybeUninit<T>` thực sự đang ở trạng thái khởi tạo.Việc gọi này khi nội dung chưa được khởi tạo hoàn toàn gây ra hành vi không xác định.
    ///
    /// Trên hết, tất cả các bất biến bổ sung của kiểu `T` phải được thỏa mãn, vì việc triển khai `Drop` của `T` (hoặc các thành viên của nó) có thể dựa vào điều này.
    /// Ví dụ, một [`Vec<T>`] khởi tạo `1` được coi là khởi tạo (trong quá trình triển khai hiện tại; điều này không cấu thành một đảm bảo ổn định) bởi vì yêu cầu duy nhất mà trình biên dịch biết về nó là con trỏ dữ liệu phải khác rỗng.
    ///
    /// Tuy nhiên, việc đánh rơi `Vec<T>` như vậy sẽ gây ra hành vi không xác định.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // AN TOÀN: người gọi phải đảm bảo rằng `self` được khởi tạo và
        // thỏa mãn mọi bất biến của `T`.
        // Giảm giá trị tại chỗ là an toàn nếu trường hợp đó xảy ra.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Nhận tham chiếu được chia sẻ đến giá trị được chứa.
    ///
    /// Điều này có thể hữu ích khi chúng tôi muốn truy cập `MaybeUninit` đã được khởi tạo nhưng không có quyền sở hữu `MaybeUninit` (ngăn cản việc sử dụng `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Việc gọi này khi nội dung chưa được khởi tạo hoàn toàn gây ra hành vi không xác định: người gọi phải đảm bảo rằng `MaybeUninit<T>` thực sự đang ở trạng thái khởi tạo.
    ///
    ///
    /// # Examples
    ///
    /// ### Cách sử dụng chính xác của phương pháp này:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Khởi tạo `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Bây giờ `MaybeUninit<_>` của chúng tôi được biết là đã được khởi tạo, bạn có thể tạo một tham chiếu được chia sẻ tới nó:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // AN TOÀN: `x` đã được khởi tạo.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Cách sử dụng không chính xác* của phương pháp này:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Chúng tôi đã tạo một tham chiếu đến vector chưa được khởi tạo!Đây là hành vi không xác định.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Khởi tạo `MaybeUninit` bằng `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Tham chiếu đến `Cell<bool>` chưa khởi tạo: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // AN TOÀN: người gọi phải đảm bảo rằng `self` đã được khởi tạo.
        // Điều này cũng có nghĩa là `self` phải là một biến thể `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Nhận tham chiếu (unique) có thể thay đổi thành giá trị được chứa.
    ///
    /// Điều này có thể hữu ích khi chúng tôi muốn truy cập `MaybeUninit` đã được khởi tạo nhưng không có quyền sở hữu `MaybeUninit` (ngăn cản việc sử dụng `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Việc gọi này khi nội dung chưa được khởi tạo hoàn toàn gây ra hành vi không xác định: người gọi phải đảm bảo rằng `MaybeUninit<T>` thực sự đang ở trạng thái khởi tạo.
    /// Ví dụ: `.assume_init_mut()` không thể được sử dụng để khởi tạo `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Cách sử dụng chính xác của phương pháp này:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Khởi tạo *tất cả* byte của bộ đệm đầu vào.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Khởi tạo `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Bây giờ chúng tôi biết rằng `buf` đã được khởi tạo, vì vậy chúng tôi có thể `.assume_init()` nó.
    /// // Tuy nhiên, việc sử dụng `.assume_init()` có thể kích hoạt `memcpy` 2048 byte.
    /// // Để khẳng định bộ đệm của chúng tôi đã được khởi tạo mà không cần sao chép nó, chúng tôi nâng cấp `&mut MaybeUninit<[u8; 2048]>` lên `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // AN TOÀN: `buf` đã được khởi tạo.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Bây giờ chúng ta có thể sử dụng `buf` như một lát cắt bình thường:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Cách sử dụng không chính xác* của phương pháp này:
    ///
    /// Bạn không thể sử dụng `.assume_init_mut()` để khởi tạo một giá trị:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Chúng tôi đã tạo một tham chiếu (mutable) cho một `bool` chưa khởi tạo!
    ///     // Đây là hành vi không xác định.⚠️
    /// }
    /// ```
    ///
    /// Ví dụ: bạn không thể [`Read`] vào một bộ đệm chưa được khởi tạo:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) tham chiếu đến bộ nhớ chưa được khởi tạo!
    ///                             // Đây là hành vi không xác định.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Bạn cũng không thể sử dụng quyền truy cập trường trực tiếp để khởi tạo dần dần từng trường:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) tham chiếu đến bộ nhớ chưa được khởi tạo!
    ///                  // Đây là hành vi không xác định.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) tham chiếu đến bộ nhớ chưa được khởi tạo!
    ///                  // Đây là hành vi không xác định.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Hiện tại, chúng tôi cho rằng điều trên là không chính xác, tức là chúng tôi có tham chiếu đến dữ liệu chưa được khởi tạo (ví dụ: trong `libcore/fmt/float.rs`).
    // Chúng ta nên đưa ra quyết định cuối cùng về các quy tắc trước khi ổn định.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // AN TOÀN: người gọi phải đảm bảo rằng `self` đã được khởi tạo.
        // Điều này cũng có nghĩa là `self` phải là một biến thể `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Trích xuất các giá trị từ một mảng các vùng chứa `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Người gọi phải đảm bảo rằng tất cả các phần tử của mảng đều ở trạng thái khởi tạo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // AN TOÀN: Bây giờ an toàn vì chúng tôi đã khởi tạo tất cả các phần tử
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Người gọi đảm bảo rằng tất cả các phần tử của mảng đều được khởi tạo
        // * `MaybeUninit<T>` và T được đảm bảo có cùng một bố cục
        // * Có thểUnint không giảm, vì vậy không có giải phóng kép Và do đó chuyển đổi an toàn
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Giả sử tất cả các phần tử đều được khởi tạo, hãy lấy một lát cắt cho chúng.
    ///
    /// # Safety
    ///
    /// Người gọi phải đảm bảo rằng các phần tử `MaybeUninit<T>` thực sự đang ở trạng thái khởi tạo.
    ///
    /// Việc gọi này khi nội dung chưa được khởi tạo hoàn toàn gây ra hành vi không xác định.
    ///
    /// Xem [`assume_init_ref`] để biết thêm chi tiết và ví dụ.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // AN TOÀN: truyền lát tới `*const [T]` là an toàn vì người gọi đảm bảo rằng
        // `slice` được khởi tạo và`MaybeUninit` được đảm bảo có cùng bố cục như `T`.
        // Con trỏ thu được là hợp lệ vì nó tham chiếu đến bộ nhớ thuộc sở hữu của `slice`, là một tham chiếu và do đó được đảm bảo là hợp lệ cho các lần đọc.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Giả sử tất cả các phần tử được khởi tạo, hãy lấy một lát có thể thay đổi cho chúng.
    ///
    /// # Safety
    ///
    /// Người gọi phải đảm bảo rằng các phần tử `MaybeUninit<T>` thực sự đang ở trạng thái khởi tạo.
    ///
    /// Việc gọi này khi nội dung chưa được khởi tạo hoàn toàn gây ra hành vi không xác định.
    ///
    /// Xem [`assume_init_mut`] để biết thêm chi tiết và ví dụ.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // AN TOÀN: tương tự như ghi chú an toàn cho `slice_get_ref`, nhưng chúng tôi có
        // tham chiếu có thể thay đổi cũng được đảm bảo là hợp lệ để ghi.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Nhận một con trỏ đến phần tử đầu tiên của mảng.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Nhận một con trỏ có thể thay đổi đến phần tử đầu tiên của mảng.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Sao chép các phần tử từ `src` sang `this`, trả về một tham chiếu có thể thay đổi cho các nội dung hiện đã được tạo ra của `this`.
    ///
    /// Nếu `T` không triển khai `Copy`, hãy sử dụng [`write_slice_cloned`]
    ///
    /// Điều này tương tự với [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Hàm này sẽ panic nếu hai lát cắt có độ dài khác nhau.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // AN TOÀN: chúng tôi vừa sao chép tất cả các phần tử của len vào dung lượng dự phòng
    /// // các phần tử src.len() đầu tiên của vec hiện có hiệu lực.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // AN TOÀN: &[T] và&[MaybeUninit<T>] có cùng một bố cục
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // AN TOÀN: Các phần tử hợp lệ vừa được sao chép vào `this` vì vậy nó được phát triển
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Sao chép các phần tử từ `src` sang `this`, trả về một tham chiếu có thể thay đổi cho các nội dung hiện đã được tạo ra của `this`.
    /// Bất kỳ phần tử nào đã được tạo ra sẽ không bị loại bỏ.
    ///
    /// Nếu `T` triển khai `Copy`, hãy sử dụng [`write_slice`]
    ///
    /// Điều này tương tự như [`slice::clone_from_slice`] nhưng không làm rơi các phần tử hiện có.
    ///
    /// # Panics
    ///
    /// Hàm này sẽ panic nếu hai lát cắt có độ dài khác nhau hoặc nếu việc thực hiện `Clone` panics.
    ///
    /// Nếu có panic, các phần tử đã được nhân bản sẽ bị loại bỏ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // AN TOÀN: chúng tôi vừa sao chép tất cả các phần tử của len vào dung lượng dự phòng
    /// // các phần tử src.len() đầu tiên của vec hiện có hiệu lực.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // không giống như copy_from_slice, điều này không gọi clone_from_slice trên lát này là do `MaybeUninit<T: Clone>` không triển khai Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // AN TOÀN: phần thô này sẽ chỉ chứa các đối tượng được khởi tạo
                // đó là lý do tại sao, nó được phép thả nó.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Chúng ta cần phải cắt chúng một cách rõ ràng theo cùng một độ dài
        // để kiểm tra giới hạn được giải quyết và trình tối ưu hóa sẽ tạo bản ghi nhớ cho các trường hợp đơn giản (ví dụ: T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // cần bảo vệ b/c panic có thể xảy ra trong quá trình phân thân
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // AN TOÀN: Các phần tử hợp lệ vừa được viết vào `this` nên nó được phát triển
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}