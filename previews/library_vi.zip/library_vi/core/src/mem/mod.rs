//! Các chức năng cơ bản để xử lý bộ nhớ.
//!
//! Mô-đun này chứa các chức năng để truy vấn kích thước và căn chỉnh của các loại, khởi tạo và thao tác bộ nhớ.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Có quyền sở hữu và "forgets" về giá trị **mà không cần chạy trình hủy**.
///
/// Bất kỳ tài nguyên nào mà giá trị quản lý, chẳng hạn như bộ nhớ heap hoặc xử lý tệp, sẽ tồn tại mãi mãi ở trạng thái không thể truy cập.Tuy nhiên, nó không đảm bảo rằng các con trỏ tới bộ nhớ này sẽ vẫn hợp lệ.
///
/// * Nếu bạn muốn rò rỉ bộ nhớ, hãy xem [`Box::leak`].
/// * Nếu bạn muốn lấy một con trỏ thô vào bộ nhớ, hãy xem [`Box::into_raw`].
/// * Nếu bạn muốn loại bỏ một giá trị đúng cách, chạy trình hủy của nó, hãy xem [`mem::drop`].
///
/// # Safety
///
/// `forget` không được đánh dấu là `unsafe`, vì đảm bảo an toàn của Rust không bao gồm đảm bảo rằng trình hủy sẽ luôn chạy.
/// Ví dụ: một chương trình có thể tạo một chu trình tham chiếu bằng cách sử dụng [`Rc`][rc] hoặc gọi [`process::exit`][exit] để thoát mà không cần chạy hàm hủy.
/// Do đó, việc cho phép `mem::forget` từ mã an toàn về cơ bản không thay đổi các đảm bảo an toàn của Rust.
///
/// Điều đó nói rằng, việc rò rỉ tài nguyên như bộ nhớ hoặc các đối tượng I/O thường là không mong muốn.
/// Sự cần thiết xuất hiện trong một số trường hợp sử dụng chuyên biệt cho FFI hoặc mã không an toàn, nhưng ngay cả khi đó, [`ManuallyDrop`] thường được ưu tiên hơn.
///
/// Bởi vì việc quên giá trị được cho phép, bất kỳ mã `unsafe` nào bạn viết phải cho phép khả năng này.Bạn không thể trả về một giá trị và mong đợi rằng người gọi nhất thiết phải chạy trình hủy của giá trị.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Việc sử dụng an toàn thông thường của `mem::forget` là để phá vỡ bộ hủy của giá trị được thực hiện bởi `Drop` trait.Ví dụ, điều này sẽ làm rò rỉ `File`, tức là
/// lấy lại không gian được chiếm bởi biến nhưng không bao giờ đóng tài nguyên hệ thống cơ bản:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Điều này hữu ích khi quyền sở hữu tài nguyên cơ bản trước đây đã được chuyển sang mã bên ngoài Rust, ví dụ: bằng cách truyền bộ mô tả tệp thô sang mã C.
///
/// # Mối quan hệ với `ManuallyDrop`
///
/// Mặc dù `mem::forget` cũng có thể được sử dụng để chuyển quyền sở hữu *bộ nhớ*, nhưng làm như vậy rất dễ xảy ra lỗi.
/// [`ManuallyDrop`] nên được sử dụng thay thế.Ví dụ, hãy xem xét mã này:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Xây dựng `String` bằng cách sử dụng nội dung của `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // rò rỉ `v` vì bộ nhớ của nó hiện được quản lý bởi `s`
/// mem::forget(v);  // ERROR, v không hợp lệ và không được chuyển cho một hàm
/// assert_eq!(s, "Az");
/// // `s` bị loại bỏ hoàn toàn và bộ nhớ của nó được phân bổ.
/// ```
///
/// Có hai vấn đề với ví dụ trên:
///
/// * Nếu có nhiều mã được thêm vào giữa cấu trúc `String` và lệnh gọi `mem::forget()`, panic bên trong nó sẽ gây ra tình trạng trống kép vì cùng một bộ nhớ được xử lý bởi cả `v` và `s`.
/// * Sau khi gọi `v.as_mut_ptr()` và truyền quyền sở hữu dữ liệu đến `s`, giá trị `v` không hợp lệ.
/// Ngay cả khi một giá trị vừa được chuyển đến `mem::forget` (sẽ không kiểm tra nó), một số loại có yêu cầu nghiêm ngặt về giá trị của chúng khiến chúng không hợp lệ khi bị treo hoặc không còn được sở hữu.
/// Sử dụng các giá trị không hợp lệ theo bất kỳ cách nào, bao gồm cả việc chuyển chúng đến hoặc trả lại chúng từ các hàm, tạo thành hành vi không xác định và có thể phá vỡ các giả định do trình biên dịch đưa ra.
///
/// Chuyển sang `ManuallyDrop` tránh được cả hai vấn đề:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Trước khi chúng tôi tháo rời `v` thành các bộ phận thô của nó, hãy đảm bảo rằng nó không bị rơi!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Bây giờ hãy tháo rời `v`.Các hoạt động này không thể panic, vì vậy không thể có rò rỉ.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Cuối cùng, xây dựng một `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` bị loại bỏ hoàn toàn và bộ nhớ của nó được phân bổ.
/// ```
///
/// `ManuallyDrop` ngăn chặn mạnh mẽ tính năng tự do kép vì chúng tôi vô hiệu hóa trình hủy của `v` trước khi làm bất kỳ điều gì khác.
/// `mem::forget()` không cho phép điều này vì nó tiêu tốn đối số của nó, buộc chúng ta chỉ gọi nó sau khi trích xuất bất cứ thứ gì chúng ta cần từ `v`.
/// Ngay cả khi panic được giới thiệu giữa quá trình xây dựng `ManuallyDrop` và xây dựng chuỗi (điều này không thể xảy ra trong mã như được hiển thị), nó sẽ dẫn đến rò rỉ chứ không phải là miễn phí kép.
/// Nói cách khác, `ManuallyDrop` mắc lỗi ở mặt rò rỉ thay vì lỗi ở mặt (kép) rơi.
///
/// Ngoài ra, `ManuallyDrop` ngăn chúng ta phải "touch" `v` sau khi chuyển quyền sở hữu sang `s`-hoàn toàn tránh được bước cuối cùng của việc tương tác với `v` để xử lý nó mà không chạy trình hủy của nó.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Giống như [`forget`], nhưng cũng chấp nhận các giá trị chưa được kích thước.
///
/// Chức năng này chỉ là một miếng đệm dự định được gỡ bỏ khi tính năng `unsized_locals` được ổn định.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Trả về kích thước của một kiểu tính bằng byte.
///
/// Cụ thể hơn, đây là độ lệch tính bằng byte giữa các phần tử liên tiếp trong một mảng có loại mục đó bao gồm cả phần đệm căn chỉnh.
///
/// Vì vậy, đối với bất kỳ loại `T` và chiều dài `n`, `[T; n]` có kích thước là `n * size_of::<T>()`.
///
/// Nói chung, kích thước của một kiểu không ổn định qua các tập hợp, nhưng các kiểu cụ thể như nguyên thủy thì có.
///
/// Bảng sau đây cung cấp kích thước cho các nguyên thủy.
///
/// Loại |size_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 ký tự |4
///
/// Hơn nữa, `usize` và `isize` có cùng kích thước.
///
/// Các loại `*const T`, `&T`, `Box<T>`, `Option<&T>` và `Option<Box<T>>` đều có cùng kích thước.
/// Nếu `T` có Kích thước, tất cả các loại đó đều có cùng kích thước với `usize`.
///
/// Khả năng thay đổi của một con trỏ không thay đổi kích thước của nó.Như vậy, `&T` và `&mut T` có cùng kích thước.
/// Tương tự như vậy đối với `*const T` và `* mut T`.
///
/// # Kích thước của các mặt hàng `#[repr(C)]`
///
/// Biểu diễn `C` cho các mục có bố cục xác định.
/// Với cách bố trí này, kích thước của các mục cũng ổn định miễn là tất cả các trường có kích thước ổn định.
///
/// ## Kích thước của cấu trúc
///
/// Đối với `structs`, kích thước được xác định bằng thuật toán sau.
///
/// Đối với mỗi trường trong cấu trúc được sắp xếp theo thứ tự khai báo:
///
/// 1. Thêm kích thước của trường.
/// 2. Làm tròn kích thước hiện tại thành bội số gần nhất của [alignment] của trường tiếp theo.
///
/// Cuối cùng, làm tròn kích thước của cấu trúc đến bội số gần nhất với [alignment] của nó.
/// Căn chỉnh của cấu trúc thường là căn chỉnh lớn nhất trong tất cả các trường của nó;điều này có thể được thay đổi với việc sử dụng `repr(align(N))`.
///
/// Không giống như `C`, các cấu trúc có kích thước bằng 0 không được làm tròn đến kích thước một byte.
///
/// ## Kích thước của Enums
///
/// Enums không mang dữ liệu nào khác ngoài dữ liệu phân biệt có cùng kích thước với Enums C trên nền tảng mà chúng được biên dịch.
///
/// ## Quy mô của các công đoàn
///
/// Kích thước của một liên minh là kích thước của trường lớn nhất của nó.
///
/// Không giống như `C`, các liên hiệp có kích thước bằng không không được làm tròn đến kích thước một byte.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Một số nguyên thủy
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Một số mảng
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Bình đẳng kích thước con trỏ
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Sử dụng `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Kích thước của trường đầu tiên là 1, vì vậy hãy thêm 1 vào kích thước.Kích thước là 1.
/// // Căn chỉnh của trường thứ hai là 2, vì vậy hãy thêm 1 vào kích thước cho phần đệm.Kích thước là 2.
/// // Kích thước của trường thứ hai là 2, vì vậy hãy thêm 2 vào kích thước.Kích thước là 4.
/// // Căn chỉnh của trường thứ ba là 1, vì vậy hãy thêm 0 vào kích thước cho phần đệm.Kích thước là 4.
/// // Kích thước của trường thứ ba là 1, vì vậy hãy thêm 1 vào kích thước.Kích thước là 5.
/// // Cuối cùng, căn chỉnh của cấu trúc là 2 (vì căn chỉnh lớn nhất giữa các trường của nó là 2), vì vậy hãy thêm 1 vào kích thước cho phần đệm.
/// // Kích thước là 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Cấu trúc Tuple tuân theo các quy tắc tương tự.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Lưu ý rằng việc sắp xếp lại các trường có thể làm giảm kích thước.
/// // Chúng tôi có thể xóa cả hai byte đệm bằng cách đặt `third` trước `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Kích thước liên minh là kích thước của trường lớn nhất.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Trả về kích thước của giá trị trỏ đến tính bằng byte.
///
/// Điều này thường giống như `size_of::<T>()`.
/// Tuy nhiên, khi `T`*có* không có kích thước được xác định tĩnh, ví dụ: một lát [`[T]`][slice] hoặc [trait object], thì `size_of_val` có thể được sử dụng để lấy kích thước đã biết động.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // AN TOÀN: `val` là một tham chiếu, vì vậy nó là một con trỏ thô hợp lệ
    unsafe { intrinsics::size_of_val(val) }
}

/// Trả về kích thước của giá trị trỏ đến tính bằng byte.
///
/// Điều này thường giống như `size_of::<T>()`.Tuy nhiên, khi `T`*có* không có kích thước đã biết tĩnh, ví dụ: một lát [`[T]`][slice] hoặc [trait object], thì `size_of_val_raw` có thể được sử dụng để lấy kích thước đã biết động.
///
/// # Safety
///
/// Chức năng này chỉ an toàn để gọi nếu các điều kiện sau đây được giữ nguyên:
///
/// - Nếu `T` là `Sized`, chức năng này luôn an toàn để gọi.
/// - Nếu đuôi chưa được kích thước của `T` là:
///     - a [slice], thì độ dài của đuôi lát cắt phải là một số nguyên được khởi tạo và kích thước của *toàn bộ giá trị*(độ dài đuôi động + tiền tố có kích thước tĩnh) phải vừa với `isize`.
///     - [trait object], thì phần vtable của con trỏ phải trỏ đến vtable hợp lệ có được bằng cách ép buộc bỏ kích thước và kích thước của *toàn bộ giá trị*(chiều dài đuôi động + tiền tố có kích thước tĩnh) phải vừa với `isize`.
///
///     - một (unstable) [extern type], thì hàm này luôn an toàn để gọi, nhưng panic có thể trả về giá trị sai, vì không xác định được cách bố trí của kiểu extern.
///     Đây là hành vi tương tự như [`size_of_val`] trên tham chiếu đến kiểu có đuôi kiểu bên ngoài.
///     - nếu không, nó không được phép gọi hàm này một cách thận trọng.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // AN TOÀN: người gọi phải cung cấp một con trỏ thô hợp lệ
    unsafe { intrinsics::size_of_val(val) }
}

/// Trả về căn chỉnh tối thiểu được yêu cầu [ABI] của một loại.
///
/// Mọi tham chiếu đến giá trị của kiểu `T` phải là bội số của số này.
///
/// Đây là căn chỉnh được sử dụng cho các trường cấu trúc.Nó có thể nhỏ hơn căn chỉnh ưa thích.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Trả về căn chỉnh tối thiểu được yêu cầu [ABI] của loại giá trị mà `val` trỏ tới.
///
/// Mọi tham chiếu đến giá trị của kiểu `T` phải là bội số của số này.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // AN TOÀN: val là một tham chiếu, vì vậy nó là một con trỏ thô hợp lệ
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Trả về căn chỉnh tối thiểu được yêu cầu [ABI] của một loại.
///
/// Mọi tham chiếu đến giá trị của kiểu `T` phải là bội số của số này.
///
/// Đây là căn chỉnh được sử dụng cho các trường cấu trúc.Nó có thể nhỏ hơn căn chỉnh ưa thích.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Trả về căn chỉnh tối thiểu được yêu cầu [ABI] của loại giá trị mà `val` trỏ tới.
///
/// Mọi tham chiếu đến giá trị của kiểu `T` phải là bội số của số này.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // AN TOÀN: val là một tham chiếu, vì vậy nó là một con trỏ thô hợp lệ
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Trả về căn chỉnh tối thiểu được yêu cầu [ABI] của loại giá trị mà `val` trỏ tới.
///
/// Mọi tham chiếu đến giá trị của kiểu `T` phải là bội số của số này.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Chức năng này chỉ an toàn để gọi nếu các điều kiện sau đây được giữ nguyên:
///
/// - Nếu `T` là `Sized`, chức năng này luôn an toàn để gọi.
/// - Nếu đuôi chưa được kích thước của `T` là:
///     - a [slice], thì độ dài của đuôi lát cắt phải là một số nguyên được khởi tạo và kích thước của *toàn bộ giá trị*(độ dài đuôi động + tiền tố có kích thước tĩnh) phải vừa với `isize`.
///     - [trait object], thì phần vtable của con trỏ phải trỏ đến vtable hợp lệ có được bằng cách ép buộc bỏ kích thước và kích thước của *toàn bộ giá trị*(chiều dài đuôi động + tiền tố có kích thước tĩnh) phải vừa với `isize`.
///
///     - một (unstable) [extern type], thì hàm này luôn an toàn để gọi, nhưng panic có thể trả về giá trị sai, vì không xác định được cách bố trí của kiểu extern.
///     Đây là hành vi tương tự như [`align_of_val`] trên tham chiếu đến kiểu có đuôi kiểu bên ngoài.
///     - nếu không, nó không được phép gọi hàm này một cách thận trọng.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // AN TOÀN: người gọi phải cung cấp một con trỏ thô hợp lệ
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Trả về `true` nếu vấn đề giảm giá trị của loại `T`.
///
/// Đây hoàn toàn là một gợi ý tối ưu hóa và có thể được thực hiện một cách thận trọng:
/// nó có thể trả về `true` cho các loại không thực sự cần phải bỏ.
/// Như vậy, luôn luôn trả về `true` sẽ là một triển khai hợp lệ của chức năng này.Tuy nhiên, nếu hàm này thực sự trả về `false`, thì bạn có thể chắc chắn rằng việc bỏ `T` không có tác dụng phụ.
///
/// Việc triển khai cấp độ thấp của những thứ như bộ sưu tập, cần loại bỏ dữ liệu của chúng theo cách thủ công, nên sử dụng chức năng này để tránh cố gắng loại bỏ tất cả nội dung của chúng một cách không cần thiết khi chúng bị phá hủy.
///
/// Điều này có thể không tạo ra sự khác biệt trong các bản dựng phát hành (trong đó một vòng lặp không có tác dụng phụ dễ dàng được phát hiện và loại bỏ), nhưng thường là một chiến thắng lớn cho các bản dựng gỡ lỗi.
///
/// Lưu ý rằng [`drop_in_place`] đã thực hiện kiểm tra này, vì vậy nếu khối lượng công việc của bạn có thể giảm xuống một số lượng nhỏ các cuộc gọi [`drop_in_place`], thì việc sử dụng điều này là không cần thiết.
/// Đặc biệt lưu ý rằng bạn có thể [`drop_in_place`] một lát và điều đó sẽ thực hiện một kiểm tra need_drop duy nhất cho tất cả các giá trị.
///
/// Do đó, các loại như Vec chỉ là `drop_in_place(&mut self[..])` mà không sử dụng `needs_drop` một cách rõ ràng.
/// Mặt khác, các loại như [`HashMap`] phải giảm từng giá trị một và nên sử dụng API này.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Dưới đây là một ví dụ về cách một bộ sưu tập có thể sử dụng `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // thả dữ liệu
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Trả về giá trị của kiểu `T` được biểu thị bằng mẫu byte hoàn toàn bằng không.
///
/// Điều này có nghĩa là, ví dụ, byte đệm trong `(u8, u16)` không nhất thiết phải bằng không.
///
/// Không có gì đảm bảo rằng một mẫu byte toàn phần không đại diện cho một giá trị hợp lệ của một số kiểu `T`.
/// Ví dụ: mẫu byte toàn phần không phải là giá trị hợp lệ cho các kiểu tham chiếu (`&T`, `&mut T`) và con trỏ hàm.
/// Sử dụng `zeroed` trên các loại như vậy gây ra [undefined behavior][ub] ngay lập tức vì [the Rust compiler assumes][inv] luôn có giá trị hợp lệ trong một biến mà nó coi là đã khởi tạo.
///
///
/// Điều này có tác dụng tương tự như [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Nó đôi khi hữu ích cho FFI, nhưng nói chung nên tránh.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Cách sử dụng đúng của hàm này: khởi tạo một số nguyên bằng 0.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Cách sử dụng chức năng này không chính xác*: khởi tạo tham chiếu bằng 0.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Hành vi không xác định!
/// let _y: fn() = unsafe { mem::zeroed() }; // Và một lần nữa!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // AN TOÀN: người gọi phải đảm bảo rằng giá trị bằng không là hợp lệ cho `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Bỏ qua các kiểm tra khởi tạo bộ nhớ thông thường của Rust bằng cách giả vờ tạo ra một giá trị kiểu `T`, trong khi không làm gì cả.
///
/// **Chức năng này không được dùng nữa.** Hãy sử dụng [`MaybeUninit<T>`] để thay thế.
///
/// Lý do không dùng nữa là về cơ bản hàm không thể được sử dụng đúng cách: nó có tác dụng tương tự như [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Như [`assume_init` documentation][assume_init] giải thích, [the Rust compiler assumes][inv] mà các giá trị được khởi tạo đúng cách.
/// Như một hệ quả, gọi ví dụ
/// `mem::uninitialized::<bool>()` gây ra hành vi không xác định ngay lập tức để trả về `bool` mà không chắc chắn là `true` hoặc `false`.
/// Tệ hơn nữa, bộ nhớ chưa được khởi tạo thực sự như những gì được trả về ở đây đặc biệt ở chỗ trình biên dịch biết rằng nó không có giá trị cố định.
/// Điều này làm cho hành vi không xác định khi có dữ liệu chưa được khởi tạo trong một biến ngay cả khi biến đó có kiểu số nguyên.
/// (Lưu ý rằng các quy tắc xung quanh số nguyên chưa khởi tạo vẫn chưa được hoàn thiện, nhưng cho đến khi chúng có, bạn nên tránh chúng.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // AN TOÀN: người gọi phải đảm bảo rằng giá trị đơn nguyên hợp lệ cho `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Hoán đổi các giá trị tại hai vị trí có thể thay đổi, mà không làm biến đổi một trong hai vị trí.
///
/// * Nếu bạn muốn hoán đổi với giá trị mặc định hoặc giá trị giả, hãy xem [`take`].
/// * Nếu bạn muốn hoán đổi với một giá trị đã truyền, trả về giá trị cũ, hãy xem [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // AN TOÀN: các con trỏ thô đã được tạo từ các tham chiếu có thể thay đổi an toàn đáp ứng tất cả các
    // ràng buộc trên `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Thay thế `dest` bằng giá trị mặc định là `T`, trả về giá trị `dest` trước đó.
///
/// * Nếu bạn muốn thay thế giá trị của hai biến, hãy xem [`swap`].
/// * Nếu bạn muốn thay thế bằng một giá trị đã truyền thay vì giá trị mặc định, hãy xem [`replace`].
///
/// # Examples
///
/// Một ví dụ đơn giản:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` cho phép chiếm quyền sở hữu trường struct bằng cách thay thế trường đó bằng giá trị "empty".
/// Nếu không có `take`, bạn có thể gặp phải các vấn đề như sau:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Lưu ý rằng `T` không nhất thiết phải triển khai [`Clone`], vì vậy nó thậm chí không thể sao chép và đặt lại `self.buf`.
/// Nhưng `take` có thể được sử dụng để tách giá trị ban đầu của `self.buf` khỏi `self`, cho phép trả lại giá trị đó:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Di chuyển `src` vào `dest` được tham chiếu, trả về giá trị `dest` trước đó.
///
/// Không có giá trị nào bị giảm.
///
/// * Nếu bạn muốn thay thế giá trị của hai biến, hãy xem [`swap`].
/// * Nếu bạn muốn thay thế bằng giá trị mặc định, hãy xem [`take`].
///
/// # Examples
///
/// Một ví dụ đơn giản:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` cho phép sử dụng một trường struct bằng cách thay thế nó bằng một giá trị khác.
/// Nếu không có `replace`, bạn có thể gặp phải các vấn đề như sau:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Lưu ý rằng `T` không nhất thiết phải triển khai [`Clone`], vì vậy chúng tôi thậm chí không thể sao chép `self.buf[i]` để tránh di chuyển.
/// Nhưng `replace` có thể được sử dụng để tách giá trị ban đầu tại chỉ mục đó khỏi `self`, cho phép nó được trả về:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // AN TOÀN: Chúng tôi đọc từ `dest` nhưng ghi trực tiếp `src` vào đó sau đó,
    // sao cho giá trị cũ không bị trùng lặp.
    // Không có gì bị bỏ rơi và không có gì ở đây có thể panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Xử lý một giá trị.
///
/// Điều này làm như vậy bằng cách gọi việc triển khai của đối số là [`Drop`][drop].
///
/// Điều này không hiệu quả đối với các loại triển khai `Copy`, ví dụ:
/// integers.
/// Các giá trị như vậy được sao chép và _then_ được chuyển vào hàm, vì vậy giá trị vẫn tồn tại sau lệnh gọi hàm này.
///
///
/// Chức năng này không phải là ma thuật;nó được định nghĩa theo nghĩa đen là
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Vì `_x` được chuyển vào trong hàm nên nó sẽ tự động bị loại bỏ trước khi hàm trả về.
///
/// [drop]: Drop
///
/// # Examples
///
/// Cách sử dụng cơ bản:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // thả vector một cách rõ ràng
/// ```
///
/// Vì [`RefCell`] thực thi các quy tắc mượn trong thời gian chạy, `drop` có thể phát hành một khoản vay [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // từ bỏ khoản vay có thể thay đổi trên vị trí này
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Số nguyên và các kiểu khác triển khai [`Copy`] không bị ảnh hưởng bởi `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // một bản sao của `x` được di chuyển và thả xuống
/// drop(y); // một bản sao của `y` được di chuyển và thả xuống
///
/// println!("x: {}, y: {}", x, y.0); // vẫn có sẵn
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Diễn giải `src` là có kiểu `&U`, sau đó đọc `src` mà không di chuyển giá trị được chứa.
///
/// Chức năng này sẽ giả định một cách không an toàn con trỏ `src` hợp lệ với các byte [`size_of::<U>`][size_of] bằng cách chuyển đổi `&T` thành `&U` và sau đó đọc `&U` (ngoại trừ việc điều này được thực hiện theo cách chính xác ngay cả khi `&U` đưa ra các yêu cầu căn chỉnh chặt chẽ hơn `&T`).
/// Nó cũng sẽ tạo một bản sao của giá trị được chứa một cách không an toàn thay vì chuyển ra khỏi `src`.
///
/// Đây không phải là lỗi thời gian biên dịch nếu `T` và `U` có kích thước khác nhau, nhưng chúng tôi rất khuyến khích chỉ gọi hàm này khi `T` và `U` có cùng kích thước.Hàm này kích hoạt [undefined behavior][ub] nếu `U` lớn hơn `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Sao chép dữ liệu từ 'foo_array' và coi nó như một 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Sửa đổi dữ liệu đã sao chép
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Nội dung của 'foo_array' không nên thay đổi
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Nếu U có yêu cầu căn chỉnh cao hơn, src có thể không được căn chỉnh phù hợp.
    if align_of::<U>() > align_of::<T>() {
        // AN TOÀN: `src` là một tham chiếu được đảm bảo là hợp lệ để đọc.
        // Người gọi phải đảm bảo rằng quá trình chuyển đổi thực sự diễn ra an toàn.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // AN TOÀN: `src` là một tham chiếu được đảm bảo là hợp lệ để đọc.
        // Chúng tôi vừa kiểm tra xem `src as *const U` đã được căn chỉnh đúng cách chưa.
        // Người gọi phải đảm bảo rằng quá trình chuyển đổi thực sự diễn ra an toàn.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Kiểu mờ đại diện cho sự phân biệt của một enum.
///
/// Xem chức năng [`discriminant`] trong mô-đun này để biết thêm thông tin.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Không thể bắt nguồn các triển khai trait này vì chúng tôi không muốn có bất kỳ giới hạn nào trên T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Trả về một giá trị nhận dạng duy nhất biến thể enum trong `v`.
///
/// Nếu `T` không phải là enum, việc gọi hàm này sẽ không dẫn đến hành vi không xác định, nhưng giá trị trả về là không xác định.
///
///
/// # Stability
///
/// Tính phân biệt của một biến thể enum có thể thay đổi nếu định nghĩa enum thay đổi.
/// Điểm phân biệt của một số biến thể sẽ không thay đổi giữa các lần biên dịch với cùng một trình biên dịch.
///
/// # Examples
///
/// Điều này có thể được sử dụng để so sánh các enums mang dữ liệu, trong khi bỏ qua dữ liệu thực tế:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Trả về số biến thể trong kiểu enum `T`.
///
/// Nếu `T` không phải là enum, việc gọi hàm này sẽ không dẫn đến hành vi không xác định, nhưng giá trị trả về là không xác định.
/// Tương tự, nếu `T` là một enum có nhiều biến thể hơn `usize::MAX` thì giá trị trả về là không xác định.
/// Các biến thể không có người ở sẽ được tính.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}