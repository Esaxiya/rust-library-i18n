use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Một trình bao bọc để ngăn trình biên dịch tự động gọi trình hủy của `T`.
/// Trình bao bọc này là 0 chi phí.
///
/// `ManuallyDrop<T>` được tối ưu hóa bố cục tương tự như `T`.
/// Do đó, nó *không ảnh hưởng* đến các giả định mà trình biên dịch đưa ra về nội dung của nó.
/// Ví dụ: khởi tạo `ManuallyDrop<&mut T>` với [`mem::zeroed`] là hành vi không xác định.
/// Nếu bạn cần xử lý dữ liệu chưa được khởi tạo, hãy sử dụng [`MaybeUninit<T>`] để thay thế.
///
/// Lưu ý rằng việc truy cập giá trị bên trong `ManuallyDrop<T>` là an toàn.
/// Điều này có nghĩa là `ManuallyDrop<T>` có nội dung đã bị loại bỏ không được hiển thị thông qua API an toàn công khai.
/// Tương ứng, `ManuallyDrop::drop` không an toàn.
///
/// # `ManuallyDrop` và thả đơn hàng.
///
/// Rust có giá trị [drop order] được xác định rõ ràng.
/// Để đảm bảo rằng các trường hoặc địa phương được đưa ra theo một thứ tự cụ thể, hãy sắp xếp lại thứ tự khai báo sao cho thứ tự giảm ngầm là đúng.
///
/// Có thể sử dụng `ManuallyDrop` để kiểm soát thứ tự thả, nhưng điều này đòi hỏi mã không an toàn và khó thực hiện chính xác khi có sự cố tháo cuộn.
///
///
/// Ví dụ: nếu bạn muốn đảm bảo rằng một trường cụ thể được bỏ sau các trường khác, hãy đặt trường đó thành trường cuối cùng của một cấu trúc:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` sẽ bị loại bỏ sau `children`.
///     // Rust đảm bảo rằng các trường được loại bỏ theo thứ tự khai báo.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Bao bọc một giá trị để được loại bỏ theo cách thủ công.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Bạn vẫn có thể vận hành an toàn trên giá trị
    /// assert_eq!(*x, "Hello");
    /// // Nhưng `Drop` sẽ không chạy ở đây
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Trích xuất giá trị từ vùng chứa `ManuallyDrop`.
    ///
    /// Điều này cho phép giá trị được giảm xuống một lần nữa.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Điều này làm rơi `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Lấy giá trị từ vùng chứa `ManuallyDrop<T>` ra ngoài.
    ///
    /// Phương pháp này chủ yếu dành cho việc loại bỏ các giá trị.
    /// Thay vì sử dụng [`ManuallyDrop::drop`] để giảm giá trị theo cách thủ công, bạn có thể sử dụng phương pháp này để lấy giá trị và sử dụng theo cách mong muốn.
    ///
    /// Bất cứ khi nào có thể, bạn nên sử dụng [`into_inner`][`ManuallyDrop::into_inner`] để thay thế, điều này ngăn việc sao chép nội dung của `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Hàm này di chuyển về mặt ngữ nghĩa giá trị được chứa mà không ngăn cản việc sử dụng thêm, giữ nguyên trạng thái của vùng chứa này.
    /// Bạn có trách nhiệm đảm bảo rằng `ManuallyDrop` này không được sử dụng lại.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // AN TOÀN: chúng tôi đang đọc từ một tài liệu tham khảo, được đảm bảo
        // để có giá trị cho các lần đọc.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Giảm giá trị được chứa theo cách thủ công.Điều này chính xác tương đương với việc gọi [`ptr::drop_in_place`] bằng một con trỏ đến giá trị được chứa.
    /// Như vậy, trừ khi giá trị được chứa là một cấu trúc được đóng gói, hàm hủy sẽ được gọi tại chỗ mà không cần di chuyển giá trị và do đó có thể được sử dụng để loại bỏ dữ liệu [pinned] một cách an toàn.
    ///
    /// Nếu bạn có quyền sở hữu giá trị, bạn có thể sử dụng [`ManuallyDrop::into_inner`] để thay thế.
    ///
    /// # Safety
    ///
    /// Hàm này chạy hàm hủy của giá trị được chứa.
    /// Ngoài những thay đổi được thực hiện bởi chính bộ hủy, bộ nhớ được giữ nguyên và cho đến nay trình biên dịch vẫn giữ một mẫu bit hợp lệ cho kiểu `T`.
    ///
    ///
    /// Tuy nhiên, giá trị "zombie" này không được hiển thị với mã an toàn và không nên gọi hàm này nhiều hơn một lần.
    /// Để sử dụng một giá trị sau khi nó bị giảm hoặc giảm giá trị nhiều lần, có thể gây ra Hành vi không xác định (tùy thuộc vào những gì `drop` thực hiện).
    /// Điều này thường được ngăn chặn bởi hệ thống loại, nhưng người dùng `ManuallyDrop` phải duy trì những đảm bảo đó mà không cần hỗ trợ từ trình biên dịch.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // AN TOÀN: chúng tôi đang giảm giá trị được trỏ đến bởi một tham chiếu có thể thay đổi
        // được đảm bảo là hợp lệ để viết.
        // Người gọi có thể đảm bảo rằng `slot` không bị rơi lần nữa hay không.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}