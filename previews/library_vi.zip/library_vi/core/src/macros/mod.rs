#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Mở rộng thành `$crate::panic::panic_2015` hoặc `$crate::panic::panic_2021` tùy thuộc vào phiên bản của người gọi.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Khẳng định rằng hai biểu thức bằng nhau (sử dụng [`PartialEq`]).
///
/// Trên panic, macro này sẽ in giá trị của các biểu thức với các biểu thức gỡ lỗi của chúng.
///
///
/// Giống như [`assert!`], macro này có dạng thứ hai, nơi có thể cung cấp thông báo panic tùy chỉnh.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Các khoản vay lại dưới đây là có chủ đích.
                    // Nếu không có chúng, ngăn xếp cho mượn được khởi tạo ngay cả trước khi các giá trị được so sánh, dẫn đến tốc độ chậm đáng kể.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Các khoản vay lại dưới đây là có chủ đích.
                    // Nếu không có chúng, ngăn xếp cho mượn được khởi tạo ngay cả trước khi các giá trị được so sánh, dẫn đến tốc độ chậm đáng kể.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Cảnh báo rằng hai biểu thức không bằng nhau (sử dụng [`PartialEq`]).
///
/// Trên panic, macro này sẽ in giá trị của các biểu thức với các biểu thức gỡ lỗi của chúng.
///
///
/// Giống như [`assert!`], macro này có dạng thứ hai, nơi có thể cung cấp thông báo panic tùy chỉnh.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Các khoản vay lại dưới đây là có chủ đích.
                    // Nếu không có chúng, ngăn xếp cho mượn được khởi tạo ngay cả trước khi các giá trị được so sánh, dẫn đến tốc độ chậm đáng kể.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Các khoản vay lại dưới đây là có chủ đích.
                    // Nếu không có chúng, ngăn xếp cho mượn được khởi tạo ngay cả trước khi các giá trị được so sánh, dẫn đến tốc độ chậm đáng kể.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Cảnh báo rằng một biểu thức boolean là `true` trong thời gian chạy.
///
/// Điều này sẽ gọi macro [`panic!`] nếu biểu thức đã cung cấp không thể được đánh giá thành `true` trong thời gian chạy.
///
/// Giống như [`assert!`], macro này cũng có phiên bản thứ hai, nơi có thể cung cấp thông báo panic tùy chỉnh.
///
/// # Uses
///
/// Không giống như [`assert!`], các câu lệnh `debug_assert!` chỉ được bật trong các bản dựng không được tối ưu hóa theo mặc định.
/// Một bản dựng được tối ưu hóa sẽ không thực thi các câu lệnh `debug_assert!` trừ khi `-C debug-assertions` được chuyển đến trình biên dịch.
/// Điều này làm cho `debug_assert!` hữu ích đối với các kiểm tra quá đắt để có mặt trong bản phát hành nhưng có thể hữu ích trong quá trình phát triển.
/// Kết quả của việc mở rộng `debug_assert!` luôn được kiểm tra.
///
/// Xác nhận không được kiểm tra cho phép một chương trình ở trạng thái không nhất quán tiếp tục chạy, điều này có thể gây ra những hậu quả không mong muốn nhưng không gây mất an toàn miễn là điều này chỉ xảy ra trong mã an toàn.
///
/// Tuy nhiên, chi phí thực hiện của các cơ sở dẫn liệu nói chung không thể đo lường được.
/// Do đó, việc thay thế [`assert!`] bằng `debug_assert!` chỉ được khuyến khích sau khi đã lập hồ sơ kỹ lưỡng và quan trọng hơn, chỉ trong mã an toàn!
///
/// # Examples
///
/// ```
/// // thông báo panic cho các xác nhận này là giá trị được xâu chuỗi của biểu thức đã cho.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // một chức năng rất đơn giản
/// debug_assert!(some_expensive_computation());
///
/// // khẳng định với một thông điệp tùy chỉnh
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Khẳng định rằng hai biểu thức bằng nhau.
///
/// Trên panic, macro này sẽ in giá trị của các biểu thức với các biểu thức gỡ lỗi của chúng.
///
/// Không giống như [`assert_eq!`], các câu lệnh `debug_assert_eq!` chỉ được bật trong các bản dựng không được tối ưu hóa theo mặc định.
/// Một bản dựng được tối ưu hóa sẽ không thực thi các câu lệnh `debug_assert_eq!` trừ khi `-C debug-assertions` được chuyển đến trình biên dịch.
/// Điều này làm cho `debug_assert_eq!` hữu ích đối với các kiểm tra quá đắt để có trong bản phát hành nhưng có thể hữu ích trong quá trình phát triển.
///
/// Kết quả của việc mở rộng `debug_assert_eq!` luôn được kiểm tra.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Khẳng định rằng hai biểu thức không bằng nhau.
///
/// Trên panic, macro này sẽ in giá trị của các biểu thức với các biểu thức gỡ lỗi của chúng.
///
/// Không giống như [`assert_ne!`], các câu lệnh `debug_assert_ne!` chỉ được bật trong các bản dựng không được tối ưu hóa theo mặc định.
/// Một bản dựng được tối ưu hóa sẽ không thực thi các câu lệnh `debug_assert_ne!` trừ khi `-C debug-assertions` được chuyển đến trình biên dịch.
/// Điều này làm cho `debug_assert_ne!` hữu ích đối với các kiểm tra quá đắt để có mặt trong bản phát hành nhưng có thể hữu ích trong quá trình phát triển.
///
/// Kết quả của việc mở rộng `debug_assert_ne!` luôn được kiểm tra.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Trả về liệu biểu thức đã cho có khớp với bất kỳ mẫu nào đã cho hay không.
///
/// Giống như trong biểu thức `match`, mẫu có thể được tùy chọn theo sau bởi `if` và biểu thức bảo vệ có quyền truy cập vào các tên bị ràng buộc bởi mẫu.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Giải nén một kết quả hoặc tuyên truyền lỗi của nó.
///
/// Toán tử `?` đã được thêm vào để thay thế `try!` và sẽ được sử dụng thay thế.
/// Hơn nữa, `try` là một từ dành riêng trong Rust 2018, vì vậy nếu bạn phải sử dụng nó, bạn sẽ cần phải sử dụng [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` khớp với [`Result`] đã cho.Trong trường hợp của biến thể `Ok`, biểu thức có giá trị của giá trị được bao bọc.
///
/// Trong trường hợp của biến thể `Err`, nó truy xuất lỗi bên trong.Sau đó `try!` thực hiện chuyển đổi bằng `From`.
/// Điều này cung cấp khả năng chuyển đổi tự động giữa các lỗi chuyên biệt và các lỗi chung hơn.
/// Lỗi kết quả sau đó được trả về ngay lập tức.
///
/// Do trả về sớm, `try!` chỉ có thể được sử dụng trong các chức năng trả về [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Phương pháp trả về lỗi nhanh chóng được ưa thích
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Phương pháp trả về lỗi nhanh chóng trước đó
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Điều này tương đương với:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Ghi dữ liệu đã định dạng vào bộ đệm.
///
/// Macro này chấp nhận 'writer', một chuỗi định dạng và danh sách các đối số.
/// Các đối số sẽ được định dạng theo chuỗi định dạng đã chỉ định và kết quả sẽ được chuyển cho người viết.
/// Người viết có thể là bất kỳ giá trị nào với phương thức `write_fmt`;nói chung điều này đến từ việc triển khai [`fmt::Write`] hoặc [`io::Write`] trait.
/// Macro trả về bất kỳ thứ gì mà phương thức `write_fmt` trả về;thường là [`fmt::Result`] hoặc [`io::Result`].
///
/// Xem [`std::fmt`] để biết thêm thông tin về cú pháp chuỗi định dạng.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Một mô-đun có thể nhập cả `std::fmt::Write` và `std::io::Write` và gọi `write!` trên các đối tượng đang triển khai, vì các đối tượng thường không triển khai cả hai.
///
/// Tuy nhiên, mô-đun phải nhập traits đủ điều kiện để tên của chúng không xung đột:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // sử dụng fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // sử dụng io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Macro này cũng có thể được sử dụng trong các thiết lập `no_std`.
/// Trong thiết lập `no_std`, bạn chịu trách nhiệm về các chi tiết triển khai của các thành phần.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Ghi dữ liệu đã định dạng vào bộ đệm, với một dòng mới được thêm vào.
///
/// Trên tất cả các nền tảng, dòng mới chỉ có ký tự LINE FEED (`\n`/`U+000A`) (không bổ sung CARRIAGE RETURN (`\r`/`U+000D`).
///
/// Để biết thêm thông tin, hãy xem [`write!`].Để biết thông tin về cú pháp chuỗi định dạng, hãy xem [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Một mô-đun có thể nhập cả `std::fmt::Write` và `std::io::Write` và gọi `write!` trên các đối tượng đang triển khai, vì các đối tượng thường không triển khai cả hai.
/// Tuy nhiên, mô-đun phải nhập traits đủ điều kiện để tên của chúng không xung đột:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // sử dụng fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // sử dụng io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Cho biết mã không thể truy cập.
///
/// Điều này hữu ích bất cứ lúc nào mà trình biên dịch không thể xác định rằng một số mã không thể truy cập được.Ví dụ:
///
/// * Khớp vũ khí với các điều kiện bảo vệ.
/// * Vòng lặp tự động kết thúc.
/// * Trình lặp tự động kết thúc.
///
/// Nếu việc xác định rằng mã không thể truy cập được chứng tỏ không chính xác, chương trình sẽ kết thúc ngay lập tức với [`panic!`].
///
/// Đối tác không an toàn của macro này là hàm [`unreachable_unchecked`], hàm này sẽ gây ra hành vi không xác định nếu đạt đến mã.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Điều này sẽ luôn luôn là [`panic!`].
///
/// # Examples
///
/// Khớp cánh tay:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // biên dịch lỗi nếu nhận xét ra
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // một trong những triển khai kém nhất của x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Cho biết mã chưa hoàn thành bằng cách hoảng sợ với thông báo "not implemented".
///
/// Điều này cho phép mã của bạn kiểm tra kiểu gõ, điều này rất hữu ích nếu bạn đang tạo mẫu hoặc triển khai trait yêu cầu nhiều phương pháp mà bạn không có kế hoạch sử dụng tất cả.
///
/// Sự khác biệt giữa `unimplemented!` và [`todo!`] là trong khi `todo!` truyền đạt ý định triển khai chức năng sau này và thông báo là "not yet implemented", `unimplemented!` không đưa ra tuyên bố nào như vậy.
/// Thông điệp của nó là "not implemented".
/// Ngoài ra, một số IDE sẽ đánh dấu `todo! 'S.
///
/// # Panics
///
/// Điều này sẽ luôn luôn là [`panic!`] vì `unimplemented!` chỉ là cách viết tắt của `panic!` với một thông điệp cụ thể, cố định.
///
/// Giống như `panic!`, macro này có dạng thứ hai để hiển thị các giá trị tùy chỉnh.
///
/// # Examples
///
/// Giả sử chúng ta có trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Chúng tôi muốn triển khai `Foo` cho 'MyStruct', nhưng vì lý do nào đó, việc triển khai chức năng `bar()` chỉ có ý nghĩa.
/// `baz()` và `qux()` sẽ vẫn cần được xác định trong quá trình triển khai `Foo` của chúng tôi, nhưng chúng tôi có thể sử dụng `unimplemented!` trong các định nghĩa của chúng để cho phép mã của chúng tôi biên dịch.
///
/// Chúng tôi vẫn muốn chương trình của mình ngừng chạy nếu đạt được các phương pháp chưa hoàn thành.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // `baz` trở thành `MyStruct` không có ý nghĩa gì, vì vậy chúng tôi không có logic nào ở đây cả.
/////
///         // Điều này sẽ hiển thị "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Chúng tôi có một số logic ở đây, Chúng tôi có thể thêm một thông báo vào chưa hoàn thành!để hiển thị sự thiếu sót của chúng tôi.
///         // Điều này sẽ hiển thị: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Cho biết mã chưa hoàn thành.
///
/// Điều này có thể hữu ích nếu bạn đang tạo mẫu và chỉ muốn đánh máy mã của mình.
///
/// Sự khác biệt giữa [`unimplemented!`] và `todo!` là trong khi `todo!` truyền đạt ý định triển khai chức năng sau này và thông báo là "not yet implemented", `unimplemented!` không đưa ra tuyên bố nào như vậy.
/// Thông điệp của nó là "not implemented".
/// Ngoài ra, một số IDE sẽ đánh dấu `todo! 'S.
///
/// # Panics
///
/// Điều này sẽ luôn luôn là [`panic!`].
///
/// # Examples
///
/// Đây là một ví dụ về một số mã đang xử lý.Chúng tôi có trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Chúng tôi muốn triển khai `Foo` trên một trong các loại của chúng tôi, nhưng chúng tôi cũng muốn chỉ làm việc trên `bar()` trước.Để biên dịch mã của chúng tôi, chúng tôi cần triển khai `baz()`, vì vậy chúng tôi có thể sử dụng `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // thực hiện ở đây
///     }
///
///     fn baz(&self) {
///         // Đừng lo lắng về việc triển khai baz() ngay bây giờ
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // chúng tôi thậm chí không sử dụng baz(), vì vậy điều này là tốt.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Định nghĩa của macro cài sẵn.
///
/// Hầu hết các thuộc tính macro (tính ổn định, khả năng hiển thị, v.v.) được lấy từ mã nguồn ở đây, ngoại trừ các hàm mở rộng chuyển đổi đầu vào macro thành đầu ra, các chức năng đó được cung cấp bởi trình biên dịch.
///
///
pub(crate) mod builtin {

    /// Làm cho quá trình biên dịch không thành công với thông báo lỗi đã cho khi gặp phải.
    ///
    /// Macro này nên được sử dụng khi crate sử dụng chiến lược biên dịch có điều kiện để cung cấp thông báo lỗi tốt hơn cho các điều kiện sai.
    ///
    /// Đây là dạng cấp trình biên dịch của [`panic!`], nhưng phát ra lỗi trong quá trình *biên dịch* chứ không phải trong *thời gian chạy*.
    ///
    /// # Examples
    ///
    /// Hai ví dụ như vậy là macro và môi trường `#[cfg]`.
    ///
    /// Phát ra lỗi trình biên dịch tốt hơn nếu macro được chuyển các giá trị không hợp lệ.
    /// Nếu không có branch cuối cùng, trình biên dịch sẽ vẫn phát ra lỗi, nhưng thông báo lỗi sẽ không đề cập đến hai giá trị hợp lệ.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Phát ra lỗi trình biên dịch nếu một trong số các tính năng không khả dụng.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Tạo tham số cho các macro định dạng chuỗi khác.
    ///
    /// Macro này hoạt động bằng cách lấy một chuỗi định dạng chứa `{}` cho mỗi đối số bổ sung được truyền vào.
    /// `format_args!` chuẩn bị các tham số bổ sung để đảm bảo đầu ra có thể được hiểu là một chuỗi và chuẩn hóa các đối số thành một kiểu duy nhất.
    /// Bất kỳ giá trị nào triển khai [`Display`] trait đều có thể được chuyển cho `format_args!`, cũng như bất kỳ quá trình triển khai [`Debug`] nào cũng có thể được chuyển cho `{:?}` trong chuỗi định dạng.
    ///
    ///
    /// Macro này tạo ra giá trị kiểu [`fmt::Arguments`].Giá trị này có thể được chuyển cho các macro trong [`std::fmt`] để thực hiện chuyển hướng hữu ích.
    /// Tất cả các macro định dạng khác ([`format!`], [`write!`], [`println!`], v.v.) đều được hỗ trợ thông qua macro này.
    /// `format_args!`, không giống như các macro có nguồn gốc của nó, tránh phân bổ đống.
    ///
    /// Bạn có thể sử dụng giá trị [`fmt::Arguments`] mà `format_args!` trả về trong ngữ cảnh `Debug` và `Display` như được thấy bên dưới.
    /// Ví dụ cũng cho thấy định dạng `Debug` và `Display` giống nhau: chuỗi định dạng nội suy trong `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Để biết thêm thông tin, hãy xem tài liệu trong [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Tương tự như `format_args`, nhưng cuối cùng thêm một dòng mới.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Kiểm tra một biến môi trường tại thời điểm biên dịch.
    ///
    /// Macro này sẽ mở rộng đến giá trị của biến môi trường được đặt tên tại thời điểm biên dịch, mang lại biểu thức kiểu `&'static str`.
    ///
    ///
    /// Nếu biến môi trường không được xác định, thì lỗi biên dịch sẽ được phát ra.
    /// Để không phát ra lỗi biên dịch, hãy sử dụng macro [`option_env!`] thay thế.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Bạn có thể tùy chỉnh thông báo lỗi bằng cách chuyển một chuỗi làm tham số thứ hai:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Nếu biến môi trường `documentation` không được xác định, bạn sẽ gặp lỗi sau:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Tùy chọn kiểm tra một biến môi trường tại thời điểm biên dịch.
    ///
    /// Nếu biến môi trường được đặt tên có mặt tại thời điểm biên dịch, biến này sẽ mở rộng thành một biểu thức kiểu `Option<&'static str>` có giá trị là `Some` của giá trị của biến môi trường.
    /// Nếu biến môi trường không có, thì biến này sẽ mở rộng thành `None`.
    /// Xem [`Option<T>`][Option] để biết thêm thông tin về loại này.
    ///
    /// Lỗi thời gian biên dịch không bao giờ được phát ra khi sử dụng macro này bất kể biến môi trường có xuất hiện hay không.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Nối các số nhận dạng thành một số nhận dạng.
    ///
    /// Macro này nhận bất kỳ số lượng số nhận dạng được phân tách bằng dấu phẩy nào và nối tất cả chúng thành một, tạo ra một biểu thức là một số nhận dạng mới.
    /// Lưu ý rằng vệ sinh khiến macro này không thể nắm bắt các biến cục bộ.
    /// Ngoài ra, theo quy tắc chung, macro chỉ được phép ở vị trí mục, câu lệnh hoặc biểu thức.
    /// Điều đó có nghĩa là trong khi bạn có thể sử dụng macro này để tham chiếu đến các biến, hàm hoặc mô-đun hiện có, v.v., bạn không thể xác định một macro mới với nó.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_ident! (new, fun, name) { }//không sử dụng được theo cách này!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Nối các ký tự thành một lát chuỗi tĩnh.
    ///
    /// Macro này nhận bất kỳ số lượng ký tự được phân tách bằng dấu phẩy nào, mang lại biểu thức kiểu `&'static str` đại diện cho tất cả các ký tự được nối từ trái sang phải.
    ///
    ///
    /// Các ký tự số nguyên và dấu phẩy động được xâu chuỗi để được nối với nhau.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Mở rộng đến số dòng mà nó được gọi.
    ///
    /// Với [`column!`] và [`file!`], các macro này cung cấp thông tin gỡ lỗi cho các nhà phát triển về vị trí bên trong nguồn.
    ///
    /// Biểu thức mở rộng có kiểu `u32` và dựa trên 1, vì vậy dòng đầu tiên trong mỗi tệp đánh giá là 1, dòng thứ hai là 2, v.v.
    /// Điều này phù hợp với thông báo lỗi của trình biên dịch thông thường hoặc trình biên tập phổ biến.
    /// Dòng trả về là *không nhất thiết* là dòng của chính lệnh gọi `line!`, mà là dòng của lệnh gọi macro đầu tiên dẫn đến lệnh gọi của macro `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Mở rộng đến số cột mà nó được gọi.
    ///
    /// Với [`line!`] và [`file!`], các macro này cung cấp thông tin gỡ lỗi cho các nhà phát triển về vị trí bên trong nguồn.
    ///
    /// Biểu thức mở rộng có kiểu `u32` và dựa trên 1, vì vậy cột đầu tiên trong mỗi dòng có giá trị 1, cột thứ hai là 2, v.v.
    /// Điều này phù hợp với thông báo lỗi của trình biên dịch thông thường hoặc trình biên tập phổ biến.
    /// Cột trả về là *không nhất thiết* là dòng của chính lệnh gọi `column!`, mà là lệnh gọi macro đầu tiên dẫn đến lệnh gọi macro `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Mở rộng đến tên tệp mà nó đã được gọi.
    ///
    /// Với [`line!`] và [`column!`], các macro này cung cấp thông tin gỡ lỗi cho các nhà phát triển về vị trí bên trong nguồn.
    ///
    /// Biểu thức được mở rộng có kiểu `&'static str` và tệp trả về không phải là lệnh gọi macro `file!` mà là lệnh gọi macro đầu tiên dẫn đến lệnh gọi macro `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Chuỗi các đối số của nó.
    ///
    /// Macro này sẽ mang lại một biểu thức của loại `&'static str`, là chuỗi ký tự của tất cả tokens được chuyển đến macro.
    /// Không có giới hạn nào được đặt ra đối với cú pháp của chính lệnh gọi macro.
    ///
    /// Lưu ý rằng kết quả mở rộng của đầu vào tokens có thể thay đổi trong future.Bạn nên cẩn thận nếu bạn dựa vào kết quả đầu ra.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Bao gồm một tệp được mã hóa UTF-8 dưới dạng một chuỗi.
    ///
    /// Tệp được đặt liên quan đến tệp hiện tại (tương tự như cách tìm thấy các mô-đun).
    /// Đường dẫn đã cung cấp được diễn giải theo cách dành riêng cho nền tảng tại thời điểm biên dịch.
    /// Vì vậy, ví dụ, một lời gọi có đường dẫn Windows chứa dấu gạch chéo ngược `\` sẽ không được biên dịch chính xác trên Unix.
    ///
    ///
    /// Macro này sẽ mang lại một biểu thức kiểu `&'static str` là nội dung của tệp.
    ///
    /// # Examples
    ///
    /// Giả sử có hai tệp trong cùng một thư mục với nội dung sau:
    ///
    /// Tệp 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Tệp 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Biên dịch 'main.rs' và chạy tệp nhị phân kết quả sẽ in ra "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Bao gồm một tệp dưới dạng tham chiếu đến một mảng byte.
    ///
    /// Tệp được đặt liên quan đến tệp hiện tại (tương tự như cách tìm thấy các mô-đun).
    /// Đường dẫn đã cung cấp được diễn giải theo cách dành riêng cho nền tảng tại thời điểm biên dịch.
    /// Vì vậy, ví dụ, một lời gọi có đường dẫn Windows chứa dấu gạch chéo ngược `\` sẽ không được biên dịch chính xác trên Unix.
    ///
    ///
    /// Macro này sẽ mang lại một biểu thức kiểu `&'static [u8; N]` là nội dung của tệp.
    ///
    /// # Examples
    ///
    /// Giả sử có hai tệp trong cùng một thư mục với nội dung sau:
    ///
    /// Tệp 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Tệp 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Biên dịch 'main.rs' và chạy tệp nhị phân kết quả sẽ in ra "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Mở rộng thành một chuỗi đại diện cho đường dẫn mô-đun hiện tại.
    ///
    /// Đường dẫn mô-đun hiện tại có thể được coi là hệ thống phân cấp của các mô-đun dẫn ngược đến crate root.
    /// Thành phần đầu tiên của đường dẫn được trả về là tên của crate hiện đang được biên dịch.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Đánh giá sự kết hợp boolean của cờ cấu hình tại thời điểm biên dịch.
    ///
    /// Ngoài thuộc tính `#[cfg]`, macro này được cung cấp để cho phép đánh giá biểu thức boolean của cờ cấu hình.
    /// Điều này thường xuyên dẫn đến mã ít bị trùng lặp hơn.
    ///
    /// Cú pháp được cung cấp cho macro này có cùng cú pháp với thuộc tính [`cfg`].
    ///
    /// `cfg!`, không giống như `#[cfg]`, không loại bỏ bất kỳ mã nào và chỉ đánh giá đúng hoặc sai.
    /// Ví dụ: tất cả các khối trong biểu thức if/else cần phải hợp lệ khi `cfg!` được sử dụng cho điều kiện, bất kể `cfg!` đang đánh giá điều gì.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Phân tích cú pháp tệp dưới dạng một biểu thức hoặc một mục tùy theo ngữ cảnh.
    ///
    /// Tệp được đặt liên quan đến tệp hiện tại (tương tự như cách tìm thấy các mô-đun).Đường dẫn đã cung cấp được diễn giải theo cách dành riêng cho nền tảng tại thời điểm biên dịch.
    /// Vì vậy, ví dụ, một lời gọi có đường dẫn Windows chứa dấu gạch chéo ngược `\` sẽ không được biên dịch chính xác trên Unix.
    ///
    /// Sử dụng macro này thường là một ý tưởng tồi, bởi vì nếu tệp được phân tích cú pháp như một biểu thức, nó sẽ được đặt trong mã xung quanh một cách không hợp vệ sinh.
    /// Điều này có thể dẫn đến các biến hoặc hàm khác với những gì tệp mong đợi nếu có các biến hoặc hàm có cùng tên trong tệp hiện tại.
    ///
    ///
    /// # Examples
    ///
    /// Giả sử có hai tệp trong cùng một thư mục với nội dung sau:
    ///
    /// Tệp 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Tệp 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Biên dịch 'main.rs' và chạy tệp nhị phân kết quả sẽ in ra "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Cảnh báo rằng một biểu thức boolean là `true` trong thời gian chạy.
    ///
    /// Điều này sẽ gọi macro [`panic!`] nếu biểu thức đã cung cấp không thể được đánh giá thành `true` trong thời gian chạy.
    ///
    /// # Uses
    ///
    /// Các khẳng định luôn được kiểm tra trong cả bản dựng gỡ lỗi và bản phát hành và không thể bị vô hiệu hóa.
    /// Xem [`debug_assert!`] để biết các xác nhận không được bật trong các phiên bản phát hành theo mặc định.
    ///
    /// Mã không an toàn có thể dựa vào `assert!` để thực thi các bất biến trong thời gian chạy mà nếu vi phạm có thể dẫn đến mất an toàn.
    ///
    /// Các trường hợp sử dụng khác của `assert!` bao gồm thử nghiệm và thực thi các bất biến thời gian chạy trong mã an toàn (vi phạm của chúng không thể dẫn đến mất an toàn).
    ///
    ///
    /// # Tin nhắn tùy chỉnh
    ///
    /// Macro này có dạng thứ hai, trong đó thông báo panic tùy chỉnh có thể được cung cấp có hoặc không có đối số để định dạng.
    /// Xem [`std::fmt`] để biết cú pháp cho biểu mẫu này.
    /// Các biểu thức được sử dụng làm đối số định dạng sẽ chỉ được đánh giá nếu xác nhận không thành công.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // thông báo panic cho các xác nhận này là giá trị được xâu chuỗi của biểu thức đã cho.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // một chức năng rất đơn giản
    ///
    /// assert!(some_computation());
    ///
    /// // khẳng định với một thông điệp tùy chỉnh
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Lắp ráp nội tuyến.
    ///
    /// Đọc [unstable book] để biết cách sử dụng.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Lắp ráp nội tuyến kiểu LLVM.
    ///
    /// Đọc [unstable book] để biết cách sử dụng.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Lắp ráp nội tuyến cấp mô-đun.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Các bản in đã chuyển tokens vào đầu ra tiêu chuẩn.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Bật hoặc tắt chức năng theo dõi được sử dụng để gỡ lỗi các macro khác.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Macro thuộc tính được sử dụng để áp dụng macro dẫn xuất.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Macro thuộc tính được áp dụng cho một hàm để biến nó thành một bài kiểm tra đơn vị.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Macro thuộc tính được áp dụng cho một hàm để biến nó thành một bài kiểm tra điểm chuẩn.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Chi tiết triển khai của macro `#[test]` và `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Macro thuộc tính được áp dụng cho một tĩnh để đăng ký nó làm bộ cấp phát toàn cầu.
    ///
    /// Xem thêm [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Giữ mục mà nó được áp dụng nếu đường dẫn đã qua có thể truy cập được và xóa nó theo cách khác.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Mở rộng tất cả các thuộc tính `#[cfg]` và `#[cfg_attr]` trong đoạn mã mà nó được áp dụng.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Chi tiết triển khai không ổn định của trình biên dịch `rustc`, không sử dụng.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Chi tiết triển khai không ổn định của trình biên dịch `rustc`, không sử dụng.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}