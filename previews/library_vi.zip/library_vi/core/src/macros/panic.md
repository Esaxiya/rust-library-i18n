Panics luồng hiện tại.

Điều này cho phép một chương trình kết thúc ngay lập tức và cung cấp phản hồi cho người gọi của chương trình.
`panic!` nên được sử dụng khi một chương trình đạt đến trạng thái không thể khôi phục.

Macro này là cách hoàn hảo để xác nhận các điều kiện trong mã ví dụ và trong các thử nghiệm.
`panic!` được gắn chặt với phương pháp `unwrap` của cả enum [`Option`][ounwrap] và [`Result`][runwrap].
Cả hai triển khai đều gọi `panic!` khi chúng được đặt thành biến thể [`None`] hoặc [`Err`].

Khi sử dụng `panic!()`, bạn có thể chỉ định tải trọng chuỗi, được tạo bằng cú pháp [`format!`].
Trọng tải đó được sử dụng khi tiêm panic vào luồng đang gọi Rust, khiến luồng đó hoàn toàn là panic.

Hành vi của `std` hook mặc định, tức là
mã chạy trực tiếp sau khi panic được gọi, là để in tải trọng tin nhắn tới `stderr` cùng với thông tin file/line/column của cuộc gọi `panic!()`.

Bạn có thể ghi đè panic hook bằng [`std::panic::set_hook()`].
Bên trong hook, panic có thể được truy cập dưới dạng `&dyn Any + Send`, chứa `&str` hoặc `String` cho các lệnh gọi `panic!()` thông thường.
Đối với panic với giá trị của một loại khác, [`panic_any`] có thể được sử dụng.

[`Result`] enum thường là giải pháp tốt hơn để khôi phục lỗi so với sử dụng macro `panic!`.
Macro này nên được sử dụng để tránh tiếp tục sử dụng các giá trị không chính xác, chẳng hạn như từ các nguồn bên ngoài.
Thông tin chi tiết về xử lý lỗi được tìm thấy trong [book].

Xem thêm macro [`compile_error!`], để biết lỗi trong quá trình biên dịch.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Triển khai hiện tại

Nếu luồng chính panics nó sẽ kết thúc tất cả các luồng của bạn và kết thúc chương trình của bạn với mã `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





