#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Chứa các định nghĩa cấu trúc cho bố cục của các loại trình biên dịch tích hợp sẵn.
//!
//! Chúng có thể được sử dụng làm mục tiêu của các chuyển đổi trong mã không an toàn để thao tác trực tiếp các biểu diễn thô.
//!
//!
//! Định nghĩa của chúng phải luôn khớp với ABI được xác định trong `rustc_middle::ty::layout`.
//!

/// Biểu diễn của một đối tượng trait như `&dyn SomeTrait`.
///
/// Cấu trúc này có bố cục giống như các loại như `&dyn SomeTrait` và `Box<dyn AnotherTrait>`.
///
/// `TraitObject` được đảm bảo khớp với bố cục, nhưng nó không phải là loại đối tượng trait (ví dụ: các trường không thể truy cập trực tiếp trên `&dyn SomeTrait`) và nó không kiểm soát bố cục đó (thay đổi định nghĩa sẽ không thay đổi bố cục của `&dyn SomeTrait`).
///
/// Nó chỉ được thiết kế để sử dụng bởi mã không an toàn cần thao tác các chi tiết cấp thấp.
///
/// Không có cách nào để tham chiếu đến tất cả các đối tượng trait một cách chung chung, vì vậy cách duy nhất để tạo các giá trị kiểu này là với các hàm như [`std::mem::transmute`][transmute].
/// Tương tự, cách duy nhất để tạo đối tượng trait thực sự từ giá trị `TraitObject` là với `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Việc tổng hợp một đối tượng trait với các kiểu không khớp - một trong đó vtable không tương ứng với kiểu giá trị mà con trỏ dữ liệu trỏ đến - có khả năng cao dẫn đến hành vi không xác định.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // một ví dụ trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // để trình biên dịch tạo một đối tượng trait
/// let object: &dyn Foo = &value;
///
/// // nhìn vào phần biểu diễn thô
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // con trỏ dữ liệu là địa chỉ của `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // xây dựng một đối tượng mới, trỏ đến một `i32` khác, hãy cẩn thận khi sử dụng vtable `i32` từ `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // nó sẽ hoạt động giống như thể chúng ta đã tạo một đối tượng trait từ `other_value` một cách trực tiếp
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}