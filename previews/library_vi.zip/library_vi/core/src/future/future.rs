#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future đại diện cho một phép tính không đồng bộ.
///
/// future là một giá trị có thể chưa được tính toán xong.
/// Loại "asynchronous value" này giúp một luồng có thể tiếp tục thực hiện công việc hữu ích trong khi chờ giá trị có sẵn.
///
///
/// # Phương pháp `poll`
///
/// Phương pháp cốt lõi của future, `poll`,*cố gắng* phân giải future thành giá trị cuối cùng.
/// Phương thức này không chặn nếu giá trị chưa sẵn sàng.
/// Thay vào đó, nhiệm vụ hiện tại được lên lịch để đánh thức khi có thể đạt được tiến bộ hơn nữa bằng cách `thăm dò 'lại.
/// `context` được chuyển cho phương thức `poll` có thể cung cấp [`Waker`], là một xử lý để đánh thức tác vụ hiện tại.
///
/// Khi sử dụng future, bạn thường sẽ không gọi trực tiếp `poll` mà thay vào đó là giá trị `.await`.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Loại giá trị được tạo ra khi hoàn thành.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Cố gắng giải quyết future thành giá trị cuối cùng, đăng ký tác vụ hiện tại để đánh thức nếu giá trị này chưa có sẵn.
    ///
    /// # Giá trị trả lại
    ///
    /// Hàm này trả về:
    ///
    /// - [`Poll::Pending`] nếu future chưa sẵn sàng
    /// - [`Poll::Ready(val)`] với kết quả `val` của future này nếu nó kết thúc thành công.
    ///
    /// Sau khi future kết thúc, khách hàng không nên `poll` nó một lần nữa.
    ///
    /// Khi future chưa sẵn sàng, `poll` trả về `Poll::Pending` và lưu trữ một bản sao của [`Waker`] được sao chép từ [`Context`] hiện tại.
    /// [`Waker`] này sau đó sẽ được đánh thức khi future có thể đạt được tiến bộ.
    /// Ví dụ: future đang đợi một ổ cắm có thể đọc được sẽ gọi `.clone()` trên [`Waker`] và lưu trữ nó.
    /// Khi một tín hiệu đến nơi khác cho biết rằng ổ cắm có thể đọc được, [`Waker::wake`] được gọi và nhiệm vụ của ổ cắm future được đánh thức.
    /// Khi một tác vụ đã được đánh thức, nó phải cố gắng `poll` future một lần nữa, điều này có thể tạo ra hoặc không tạo ra giá trị cuối cùng.
    ///
    /// Lưu ý rằng trên nhiều cuộc gọi đến `poll`, chỉ có [`Waker`] từ [`Context`] được chuyển đến cuộc gọi gần đây nhất mới được lên lịch để nhận đánh thức.
    ///
    /// # Đặc điểm thời gian chạy
    ///
    /// Riêng Futures thì *trơ*;họ phải được *tích cực*`thăm dò ý kiến` để đạt được tiến bộ, nghĩa là mỗi khi nhiệm vụ hiện tại được đánh thức, nó phải chủ động` `gửi lại '' futures đang chờ xử lý mà nó vẫn quan tâm.
    ///
    /// Hàm `poll` không được gọi lặp đi lặp lại trong một vòng lặp chặt chẽ-thay vào đó, nó chỉ nên được gọi khi future chỉ ra rằng nó đã sẵn sàng để thực hiện (bằng cách gọi `wake()`).
    /// Nếu bạn đã quen với các cuộc gọi tổng hợp `poll(2)` hoặc `select(2)` trên Unix, cần lưu ý rằng futures thường *không* gặp phải các vấn đề tương tự như "all wakeups must poll all events";chúng giống `epoll(4)` hơn.
    ///
    /// Việc triển khai `poll` nên cố gắng quay trở lại nhanh chóng và không bị chặn.Việc quay trở lại nhanh chóng ngăn chặn sự tắc nghẽn không cần thiết của các chuỗi hoặc vòng lặp sự kiện.
    /// Nếu biết trước rằng cuộc gọi đến `poll` có thể kết thúc trong một thời gian, thì công việc nên được giảm tải xuống nhóm luồng (hoặc thứ gì đó tương tự) để đảm bảo rằng `poll` có thể quay trở lại nhanh chóng.
    ///
    /// # Panics
    ///
    /// Khi future đã hoàn thành (trả về `Ready` từ `poll`), việc gọi lại phương thức `poll` của nó có thể là panic, chặn vĩnh viễn hoặc gây ra các loại sự cố khác;`Future` trait không đặt ra yêu cầu nào về ảnh hưởng của cuộc gọi như vậy.
    /// Tuy nhiên, vì phương thức `poll` không được đánh dấu là `unsafe`, các quy tắc thông thường của Rust được áp dụng: các lệnh gọi không bao giờ được gây ra hành vi không xác định (hỏng bộ nhớ, sử dụng sai các hàm `unsafe` hoặc tương tự), bất kể trạng thái của future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}