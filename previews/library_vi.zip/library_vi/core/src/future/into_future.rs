use crate::future::Future;

/// Chuyển đổi thành `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Sản lượng mà future sẽ tạo ra khi hoàn thành.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Chúng ta đang biến nó thành loại future nào?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Tạo future từ một giá trị.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}