#![stable(feature = "futures_api", since = "1.36.0")]

//! Giá trị không đồng bộ.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Loại này là cần thiết vì:
///
/// a) Trình tạo không thể triển khai `for<'a, 'b> Generator<&'a mut Context<'b>>`, vì vậy chúng ta cần chuyển một con trỏ thô (xem <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Con trỏ thô và `NonNull` không phải là `Send` hoặc `Sync`, vì vậy điều đó sẽ tạo nên mọi future non-Send/Sync duy nhất và chúng tôi không muốn điều đó.
///
/// Nó cũng đơn giản hóa việc hạ thấp HIR của `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Quấn máy phát điện trong future.
///
/// Hàm này trả về `GenFuture` bên dưới, nhưng ẩn nó trong `impl Trait` để đưa ra thông báo lỗi tốt hơn (`impl Future` chứ không phải `GenFuture<[closure.....]>`).
///
// Đây là `const` để tránh các lỗi bổ sung sau khi chúng tôi khôi phục từ `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Chúng tôi dựa trên thực tế là async/await futures là bất động để tạo các khoản vay tự tham chiếu trong trình tạo cơ bản.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // AN TOÀN: An toàn vì chúng tôi là !Unpin + !Drop và đây chỉ là phép chiếu trường.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Tiếp tục trình tạo, biến `&mut Context` thành một con trỏ thô `NonNull`.
            // Việc hạ thấp `.await` sẽ chuyển điều đó trở lại `&mut Context` một cách an toàn.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // AN TOÀN: người gọi phải đảm bảo rằng `cx.0` là một con trỏ hợp lệ
    // đáp ứng tất cả các yêu cầu đối với tham chiếu có thể thay đổi.
    unsafe { &mut *cx.0.as_ptr().cast() }
}