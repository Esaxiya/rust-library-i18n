//! Panic hỗ trợ cho libcore
//!
//! Thư viện lõi không thể định nghĩa hoảng loạn, nhưng nó *khai báo* hoảng sợ.
//! Điều này có nghĩa là các chức năng bên trong libcore được phép sử dụng panic, nhưng để trở nên hữu ích, một crate ngược dòng phải xác định hoảng loạn cho libcore để sử dụng.
//! Giao diện hiện tại cho sự hoảng sợ là:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Định nghĩa này cho phép bạn hoảng sợ với bất kỳ thông báo chung nào, nhưng nó không cho phép thất bại với giá trị `Box<Any>`.
//! (`PanicInfo` chỉ chứa một `&(dyn Any + Send)`, mà chúng tôi điền vào một giá trị giả trong `PanicInfo: : internal_constructor`.) Lý do cho điều này là libcore không được phép phân bổ.
//!
//!
//! Mô-đun này chứa một số chức năng gây hoảng sợ khác, nhưng đây chỉ là các mục lang cần thiết cho trình biên dịch.Tất cả panics đều được điều khiển thông qua một chức năng này.
//! Biểu tượng thực tế được khai báo thông qua thuộc tính `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Việc triển khai cơ bản của macro `panic!` của libcore khi không có định dạng nào được sử dụng.
#[cold]
// không bao giờ nội tuyến trừ khi hoảng loạn_im ngay_abort để tránh mã bị phình ra tại các trang web cuộc gọi càng nhiều càng tốt
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // cần thiết bởi codegen cho panic khi tràn và các đầu cuối `Assert` MIR khác
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Sử dụng Arguments::new_v1 thay vì format_args! ("{}", Expr) để có khả năng giảm chi phí kích thước.
    // Định dạng_args!macro sử dụng Display trait của str để viết expr, gọi Formatter::pad, phải đáp ứng việc cắt bớt chuỗi và phần đệm (mặc dù không có gì được sử dụng ở đây).
    //
    // Việc sử dụng Arguments::new_v1 có thể cho phép trình biên dịch bỏ qua Formatter::pad khỏi tệp nhị phân đầu ra, tiết kiệm đến vài kilobyte.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // cần thiết cho panics được đánh giá hằng số
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // cần thiết bởi codegen cho panic khi truy cập OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Việc triển khai cơ bản macro `panic!` của libcore khi định dạng được sử dụng.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // LƯU Ý Chức năng này không bao giờ vượt qua ranh giới FFI;đó là lệnh gọi Rust-to-Rust được giải quyết cho hàm `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // AN TOÀN: `panic_impl` được định nghĩa trong mã Rust an toàn và do đó an toàn khi gọi.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Chức năng bên trong cho macro `assert_eq!` và `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}