//! `Clone` trait dành cho các loại không thể 'sao chép ngầm'.
//!
//! Trong Rust, một số kiểu đơn giản là "implicitly copyable" và khi bạn gán chúng hoặc chuyển chúng làm đối số, bộ nhận sẽ nhận được một bản sao, giữ nguyên giá trị ban đầu.
//! Các loại này không yêu cầu phân bổ để sao chép và không có trình hoàn thiện (tức là chúng không chứa các hộp sở hữu hoặc triển khai [`Drop`]), vì vậy trình biên dịch coi chúng là rẻ và an toàn để sao chép.
//!
//! Đối với các loại khác, bản sao phải được tạo một cách rõ ràng, theo quy ước thực hiện [`Clone`] trait và gọi phương thức [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Ví dụ sử dụng cơ bản:
//!
//! ```
//! let s = String::new(); // Loại chuỗi thực hiện Clone
//! let copy = s.clone(); // vì vậy chúng tôi có thể sao chép nó
//! ```
//!
//! Để dễ dàng thực hiện Clone trait, bạn cũng có thể sử dụng `#[derive(Clone)]`.Thí dụ:
//!
//! ```
//! #[derive(Clone)] // chúng tôi thêm Clone trait vào cấu trúc Morpheus
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // và bây giờ chúng ta có thể sao chép nó!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Một trait phổ biến cho khả năng sao chép rõ ràng một đối tượng.
///
/// Khác với [`Copy`] ở chỗ [`Copy`] là ẩn và cực kỳ rẻ, trong khi `Clone` luôn rõ ràng và có thể đắt hoặc có thể không.
/// Để thực thi các đặc điểm này, Rust không cho phép bạn thực hiện lại [`Copy`], nhưng bạn có thể thực hiện lại `Clone` và chạy mã tùy ý.
///
/// Vì `Clone` tổng quát hơn [`Copy`] nên bạn cũng có thể tự động biến bất kỳ thứ gì [`Copy`] trở thành `Clone`.
///
/// ## Derivable
///
/// trait này có thể được sử dụng với `#[derive]` nếu tất cả các trường đều là `Clone`.Việc triển khai `dẫn xuất`d của [`Clone`] gọi [`clone`] trên mỗi trường.
///
/// [`clone`]: Clone::clone
///
/// Đối với cấu trúc chung, `#[derive]` triển khai `Clone` có điều kiện bằng cách thêm `Clone` liên kết trên các tham số chung.
///
/// ```
/// // `derive` triển khai sao chép để đọc<T>khi T là Clone.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Làm cách nào để triển khai `Clone`?
///
/// Các loại là [`Copy`] nên có một triển khai nhỏ của `Clone`.Chính thức hơn:
/// nếu `T: Copy`, `x: T` và `y: &T`, thì `let x = y.clone();` tương đương với `let x = *y;`.
/// Việc triển khai thủ công nên cẩn thận để duy trì sự bất biến này;tuy nhiên, mã không an toàn không được dựa vào nó để đảm bảo an toàn cho bộ nhớ.
///
/// Một ví dụ là cấu trúc chung chứa một con trỏ hàm.Trong trường hợp này, việc triển khai `Clone` không thể là `dẫn xuất`d, nhưng có thể được thực hiện như:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Người triển khai bổ sung
///
/// Ngoài [implementors listed below][impls], các loại sau cũng triển khai `Clone`:
///
/// * Các loại mục chức năng (nghĩa là các loại riêng biệt được xác định cho từng chức năng)
/// * Các loại con trỏ hàm (ví dụ: `fn() -> i32`)
/// * Các loại mảng, cho tất cả các kích thước, nếu loại mục cũng triển khai `Clone` (ví dụ: `[i32; 123456]`)
/// * Các loại Tuple, nếu mỗi thành phần cũng triển khai `Clone` (ví dụ: `()`, `(i32, bool)`)
/// * Các loại đóng cửa, nếu chúng không nhận được giá trị nào từ môi trường hoặc nếu tất cả các giá trị được bắt đó tự thực hiện `Clone`.
///   Lưu ý rằng các biến được nắm bắt bởi tham chiếu được chia sẻ luôn triển khai `Clone` (ngay cả khi tham chiếu không), trong khi các biến được nắm bắt bởi tham chiếu có thể thay đổi không bao giờ triển khai `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Trả về một bản sao của giá trị.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str thực hiện nhân bản
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Thực hiện sao chép-gán từ `source`.
    ///
    /// `a.clone_from(&b)` tương đương với `a = b.clone()` về chức năng, nhưng có thể được ghi đè để tái sử dụng tài nguyên của `a` để tránh phân bổ không cần thiết.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Derive macro tạo ra một impl của trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): các cấu trúc này chỉ được sử dụng bởi#[obsve] để khẳng định rằng mọi thành phần của một kiểu đều triển khai Bản sao hoặc Bản sao.
//
//
// Những cấu trúc này sẽ không bao giờ xuất hiện trong mã người dùng.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Các triển khai của `Clone` cho các kiểu nguyên thủy.
///
/// Các triển khai không thể được mô tả trong Rust được thực hiện trong `traits::SelectionContext::copy_clone_conditions()` trong `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Các tham chiếu được chia sẻ có thể được sao chép, nhưng các tham chiếu có thể thay đổi *không thể*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Các tham chiếu được chia sẻ có thể được sao chép, nhưng các tham chiếu có thể thay đổi *không thể*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}