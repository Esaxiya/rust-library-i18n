use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` nhưng khác 0 và hiệp phương sai.
///
/// Đây thường là điều chính xác để sử dụng khi xây dựng cấu trúc dữ liệu bằng cách sử dụng con trỏ thô, nhưng cuối cùng nguy hiểm hơn khi sử dụng vì các thuộc tính bổ sung của nó.Nếu bạn không chắc mình có nên sử dụng `NonNull<T>` hay không, chỉ cần sử dụng `*mut T`!
///
/// Không giống như `*mut T`, con trỏ phải luôn không rỗng, ngay cả khi con trỏ không bao giờ được tham chiếu.Điều này để các enums có thể sử dụng giá trị bị cấm này như một giá trị phân biệt-`Option<NonNull<T>>` có cùng kích thước với `* mut T`.
/// Tuy nhiên, con trỏ có thể vẫn treo nếu nó không được tham chiếu.
///
/// Không giống như `*mut T`, `NonNull<T>` được chọn là đồng phương sai so với `T`.Điều này làm cho nó có thể sử dụng `NonNull<T>` khi xây dựng các kiểu hiệp biến, nhưng có nguy cơ gây ra sự không đồng biến nếu được sử dụng trong một kiểu thực sự không nên hiệp biến.
/// (Sự lựa chọn ngược lại đã được đưa ra cho `*mut T` mặc dù về mặt kỹ thuật, sự không chắc chắn chỉ có thể được gây ra bởi việc gọi các chức năng không an toàn.)
///
/// Hiệp phương sai là chính xác cho hầu hết các tóm tắt an toàn, chẳng hạn như `Box`, `Rc`, `Arc`, `Vec` và `LinkedList`.Trường hợp này xảy ra vì họ cung cấp một API công khai tuân theo các quy tắc có thể thay đổi XOR được chia sẻ thông thường của Rust.
///
/// Nếu kiểu của bạn không thể là hiệp phương sai một cách an toàn, bạn phải đảm bảo rằng nó chứa một số trường bổ sung để cung cấp bất biến.Thường thì trường này sẽ là loại [`PhantomData`] như `PhantomData<Cell<T>>` hoặc `PhantomData<&'a mut T>`.
///
/// Lưu ý rằng `NonNull<T>` có một phiên bản `From` cho `&T`.Tuy nhiên, điều này không thay đổi thực tế là đột biến thông qua (con trỏ bắt nguồn từ a) tham chiếu được chia sẻ là hành vi không xác định trừ khi đột biến xảy ra bên trong [`UnsafeCell<T>`].Tương tự với việc tạo một tham chiếu có thể thay đổi từ một tham chiếu được chia sẻ.
///
/// Khi sử dụng phiên bản `From` này mà không có `UnsafeCell<T>`, bạn có trách nhiệm đảm bảo rằng `as_mut` không bao giờ được gọi và `as_ptr` không bao giờ được sử dụng để đột biến.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` con trỏ không phải là `Send` vì dữ liệu mà chúng tham chiếu có thể là bí danh.
// NB, việc cấy ghép này là không cần thiết, nhưng sẽ cung cấp các thông báo lỗi tốt hơn.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` con trỏ không phải là `Sync` vì dữ liệu mà chúng tham chiếu có thể là bí danh.
// NB, việc cấy ghép này là không cần thiết, nhưng sẽ cung cấp các thông báo lỗi tốt hơn.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Tạo ra một `NonNull` mới lơ lửng, nhưng được căn chỉnh tốt.
    ///
    /// Điều này rất hữu ích cho việc khởi tạo các loại phân bổ lười biếng, như `Vec::new`.
    ///
    /// Lưu ý rằng giá trị con trỏ có thể đại diện cho một con trỏ hợp lệ tới `T`, có nghĩa là giá trị này không được sử dụng như một giá trị trạm canh "not yet initialized".
    /// Các kiểu phân bổ lười biếng phải theo dõi quá trình khởi tạo bằng một số phương tiện khác.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // AN TOÀN: mem::align_of() trả về kích thước khác 0, kích thước này sau đó được truyền
        // đến một * đột biến T.
        // Do đó, `ptr` không rỗng và các điều kiện để gọi new_unchecked() được tôn trọng.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Trả về một tham chiếu được chia sẻ cho giá trị.Ngược lại với [`as_ref`], điều này không yêu cầu giá trị phải được khởi tạo.
    ///
    /// Đối với đối tác có thể thay đổi, hãy xem [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Khi gọi phương thức này, bạn phải đảm bảo rằng tất cả những điều sau là đúng:
    ///
    /// * Con trỏ phải được căn chỉnh đúng.
    ///
    /// * Nó phải là "dereferencable" theo nghĩa được định nghĩa trong [the module documentation].
    ///
    /// * Bạn phải thực thi các quy tắc răng cưa của Rust, vì thời gian tồn tại của `'a` được trả về được chọn tùy ý và không nhất thiết phản ánh thời gian tồn tại thực tế của dữ liệu.
    ///
    ///   Đặc biệt, trong suốt thời gian tồn tại này, bộ nhớ mà con trỏ trỏ đến không được thay đổi (ngoại trừ bên trong `UnsafeCell`).
    ///
    /// Điều này áp dụng ngay cả khi kết quả của phương pháp này không được sử dụng!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // AN TOÀN: người gọi phải đảm bảo rằng `self` đáp ứng tất cả các
        // yêu cầu đối với một tài liệu tham khảo.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Trả về một tham chiếu duy nhất cho giá trị.Ngược lại với [`as_mut`], điều này không yêu cầu giá trị phải được khởi tạo.
    ///
    /// Đối với đối tác được chia sẻ, hãy xem [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Khi gọi phương thức này, bạn phải đảm bảo rằng tất cả những điều sau là đúng:
    ///
    /// * Con trỏ phải được căn chỉnh đúng.
    ///
    /// * Nó phải là "dereferencable" theo nghĩa được định nghĩa trong [the module documentation].
    ///
    /// * Bạn phải thực thi các quy tắc răng cưa của Rust, vì thời gian tồn tại của `'a` được trả về được chọn tùy ý và không nhất thiết phản ánh thời gian tồn tại thực tế của dữ liệu.
    ///
    ///   Đặc biệt, trong khoảng thời gian tồn tại này, bộ nhớ mà con trỏ trỏ đến không được truy cập (đọc hoặc ghi) thông qua bất kỳ con trỏ nào khác.
    ///
    /// Điều này áp dụng ngay cả khi kết quả của phương pháp này không được sử dụng!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // AN TOÀN: người gọi phải đảm bảo rằng `self` đáp ứng tất cả các
        // yêu cầu đối với một tài liệu tham khảo.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Tạo `NonNull` mới.
    ///
    /// # Safety
    ///
    /// `ptr` phải khác rỗng.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // AN TOÀN: người gọi phải đảm bảo rằng `ptr` là không rỗng.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Tạo `NonNull` mới nếu `ptr` khác rỗng.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // AN TOÀN: Con trỏ đã được kiểm tra và không rỗng
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Thực hiện chức năng tương tự như [`std::ptr::from_raw_parts`], ngoại trừ việc con trỏ `NonNull` được trả về, trái ngược với con trỏ `*const` thô.
    ///
    ///
    /// Xem tài liệu của [`std::ptr::from_raw_parts`] để biết thêm chi tiết.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // AN TOÀN: Kết quả của `ptr::from::raw_parts_mut` không rỗng vì `data_address` là.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Phân rã một con trỏ (có thể rộng) thành các thành phần địa chỉ và siêu dữ liệu.
    ///
    /// Con trỏ có thể được tạo lại sau đó với [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Nhận con trỏ `*mut` bên dưới.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Trả về một tham chiếu được chia sẻ cho giá trị.Nếu giá trị có thể chưa được khởi tạo, [`as_uninit_ref`] phải được sử dụng để thay thế.
    ///
    /// Đối với đối tác có thể thay đổi, hãy xem [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Khi gọi phương thức này, bạn phải đảm bảo rằng tất cả những điều sau là đúng:
    ///
    /// * Con trỏ phải được căn chỉnh đúng.
    ///
    /// * Nó phải là "dereferencable" theo nghĩa được định nghĩa trong [the module documentation].
    ///
    /// * Con trỏ phải trỏ đến một phiên bản đã khởi tạo của `T`.
    ///
    /// * Bạn phải thực thi các quy tắc răng cưa của Rust, vì thời gian tồn tại của `'a` được trả về được chọn tùy ý và không nhất thiết phản ánh thời gian tồn tại thực tế của dữ liệu.
    ///
    ///   Đặc biệt, trong suốt thời gian tồn tại này, bộ nhớ mà con trỏ trỏ đến không được thay đổi (ngoại trừ bên trong `UnsafeCell`).
    ///
    /// Điều này áp dụng ngay cả khi kết quả của phương pháp này không được sử dụng!
    /// (Phần về việc được khởi tạo vẫn chưa được quyết định đầy đủ, nhưng cho đến khi nó xảy ra, cách tiếp cận an toàn duy nhất là đảm bảo rằng chúng thực sự được khởi tạo.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // AN TOÀN: người gọi phải đảm bảo rằng `self` đáp ứng tất cả các
        // yêu cầu đối với một tài liệu tham khảo.
        unsafe { &*self.as_ptr() }
    }

    /// Trả về một tham chiếu duy nhất cho giá trị.Nếu giá trị có thể chưa được khởi tạo, [`as_uninit_mut`] phải được sử dụng để thay thế.
    ///
    /// Đối với đối tác được chia sẻ, hãy xem [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Khi gọi phương thức này, bạn phải đảm bảo rằng tất cả những điều sau là đúng:
    ///
    /// * Con trỏ phải được căn chỉnh đúng.
    ///
    /// * Nó phải là "dereferencable" theo nghĩa được định nghĩa trong [the module documentation].
    ///
    /// * Con trỏ phải trỏ đến một phiên bản đã khởi tạo của `T`.
    ///
    /// * Bạn phải thực thi các quy tắc răng cưa của Rust, vì thời gian tồn tại của `'a` được trả về được chọn tùy ý và không nhất thiết phản ánh thời gian tồn tại thực tế của dữ liệu.
    ///
    ///   Đặc biệt, trong khoảng thời gian tồn tại này, bộ nhớ mà con trỏ trỏ đến không được truy cập (đọc hoặc ghi) thông qua bất kỳ con trỏ nào khác.
    ///
    /// Điều này áp dụng ngay cả khi kết quả của phương pháp này không được sử dụng!
    /// (Phần về việc được khởi tạo vẫn chưa được quyết định đầy đủ, nhưng cho đến khi nó xảy ra, cách tiếp cận an toàn duy nhất là đảm bảo rằng chúng thực sự được khởi tạo.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // AN TOÀN: người gọi phải đảm bảo rằng `self` đáp ứng tất cả các
        // yêu cầu đối với tham chiếu có thể thay đổi.
        unsafe { &mut *self.as_ptr() }
    }

    /// Truyền tới một con trỏ thuộc loại khác.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // AN TOÀN: `self` là một con trỏ `NonNull` nhất thiết phải không rỗng
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Tạo một lát thô không rỗng từ một con trỏ mỏng và chiều dài.
    ///
    /// Đối số `len` là số **phần tử**, không phải số byte.
    ///
    /// Chức năng này là an toàn, nhưng tham chiếu đến giá trị trả về là không an toàn.
    /// Xem tài liệu của [`slice::from_raw_parts`] để biết các yêu cầu về an toàn lát cắt.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // tạo con trỏ lát cắt khi bắt đầu bằng con trỏ đến phần tử đầu tiên
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Lưu ý rằng ví dụ này thể hiện một cách giả tạo việc sử dụng phương pháp này, nhưng `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // AN TOÀN: `data` là một con trỏ `NonNull` nhất thiết phải không rỗng
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Trả về độ dài của một lát thô không rỗng.
    ///
    /// Giá trị trả về là số **phần tử**, không phải số byte.
    ///
    /// Chức năng này an toàn, ngay cả khi không thể tham chiếu đến lát cắt thô không null tới một lát cắt vì con trỏ không có địa chỉ hợp lệ.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Trả về một con trỏ không null vào bộ đệm của lát cắt.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // AN TOÀN: Chúng tôi biết `self` là không rỗng.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Trả về một con trỏ thô vào bộ đệm của lát cắt.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Trả về một tham chiếu được chia sẻ đến một phần của các giá trị có thể chưa được khởi tạo.Ngược lại với [`as_ref`], điều này không yêu cầu giá trị phải được khởi tạo.
    ///
    /// Đối với đối tác có thể thay đổi, hãy xem [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Khi gọi phương thức này, bạn phải đảm bảo rằng tất cả những điều sau là đúng:
    ///
    /// * Con trỏ phải là [valid] để đọc cho `ptr.len() * mem::size_of::<T>()` nhiều byte và nó phải được căn chỉnh chính xác.Điều này đặc biệt có nghĩa là:
    ///
    ///     * Toàn bộ phạm vi bộ nhớ của lát cắt này phải được chứa trong một đối tượng được cấp phát duy nhất!
    ///       Slices không bao giờ có thể trải dài trên nhiều đối tượng được phân bổ.
    ///
    ///     * Con trỏ phải được căn chỉnh ngay cả đối với các lát cắt có độ dài bằng không.
    ///     Một lý do cho điều này là tối ưu hóa bố cục enum có thể dựa vào các tham chiếu (bao gồm các phần có độ dài bất kỳ) được căn chỉnh và không rỗng để phân biệt chúng với các dữ liệu khác.
    ///
    ///     Bạn có thể lấy một con trỏ có thể sử dụng được dưới dạng `data` cho các lát cắt có độ dài bằng 0 bằng [`NonNull::dangling()`].
    ///
    /// * Tổng kích thước `ptr.len() * mem::size_of::<T>()` của lát cắt không được lớn hơn `isize::MAX`.
    ///   Xem tài liệu an toàn của [`pointer::offset`].
    ///
    /// * Bạn phải thực thi các quy tắc răng cưa của Rust, vì thời gian tồn tại của `'a` được trả về được chọn tùy ý và không nhất thiết phản ánh thời gian tồn tại thực tế của dữ liệu.
    ///   Đặc biệt, trong suốt thời gian tồn tại này, bộ nhớ mà con trỏ trỏ đến không được thay đổi (ngoại trừ bên trong `UnsafeCell`).
    ///
    /// Điều này áp dụng ngay cả khi kết quả của phương pháp này không được sử dụng!
    ///
    /// Xem thêm [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Trả về một tham chiếu duy nhất đến một phần của các giá trị có thể chưa được khởi tạo.Ngược lại với [`as_mut`], điều này không yêu cầu giá trị phải được khởi tạo.
    ///
    /// Đối với đối tác được chia sẻ, hãy xem [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Khi gọi phương thức này, bạn phải đảm bảo rằng tất cả những điều sau là đúng:
    ///
    /// * Con trỏ phải là [valid] để đọc và ghi cho `ptr.len() * mem::size_of::<T>()` nhiều byte và nó phải được căn chỉnh đúng cách.Điều này đặc biệt có nghĩa là:
    ///
    ///     * Toàn bộ phạm vi bộ nhớ của lát cắt này phải được chứa trong một đối tượng được cấp phát duy nhất!
    ///       Slices không bao giờ có thể trải dài trên nhiều đối tượng được phân bổ.
    ///
    ///     * Con trỏ phải được căn chỉnh ngay cả đối với các lát cắt có độ dài bằng không.
    ///     Một lý do cho điều này là tối ưu hóa bố cục enum có thể dựa vào các tham chiếu (bao gồm các phần có độ dài bất kỳ) được căn chỉnh và không rỗng để phân biệt chúng với các dữ liệu khác.
    ///
    ///     Bạn có thể lấy một con trỏ có thể sử dụng được dưới dạng `data` cho các lát cắt có độ dài bằng 0 bằng [`NonNull::dangling()`].
    ///
    /// * Tổng kích thước `ptr.len() * mem::size_of::<T>()` của lát cắt không được lớn hơn `isize::MAX`.
    ///   Xem tài liệu an toàn của [`pointer::offset`].
    ///
    /// * Bạn phải thực thi các quy tắc răng cưa của Rust, vì thời gian tồn tại của `'a` được trả về được chọn tùy ý và không nhất thiết phản ánh thời gian tồn tại thực tế của dữ liệu.
    ///   Đặc biệt, trong khoảng thời gian tồn tại này, bộ nhớ mà con trỏ trỏ đến không được truy cập (đọc hoặc ghi) thông qua bất kỳ con trỏ nào khác.
    ///
    /// Điều này áp dụng ngay cả khi kết quả của phương pháp này không được sử dụng!
    ///
    /// Xem thêm [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Điều này là an toàn vì `memory` hợp lệ để đọc và ghi cho `memory.len()` nhiều byte.
    /// // Lưu ý rằng không được phép gọi `memory.as_mut()` ở đây vì nội dung có thể chưa được khởi tạo.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Trả về một con trỏ thô cho một phần tử hoặc sublice mà không cần thực hiện kiểm tra giới hạn.
    ///
    /// Gọi phương thức này với chỉ mục nằm ngoài giới hạn hoặc khi `self` không có khả năng truy cập là *[hành vi không xác định]* ngay cả khi con trỏ kết quả không được sử dụng.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // AN TOÀN: người gọi đảm bảo rằng `self` là không thể xem xét và `index` trong giới hạn.
        // Do đó, con trỏ kết quả không thể là NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // AN TOÀN: Một con trỏ duy nhất không được rỗng, vì vậy các điều kiện cho
        // new_unchecked() được tôn trọng.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // AN TOÀN: Một tham chiếu có thể thay đổi không được để trống.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // AN TOÀN: Một tham chiếu không được rỗng, vì vậy các điều kiện cho
        // new_unchecked() được tôn trọng.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}