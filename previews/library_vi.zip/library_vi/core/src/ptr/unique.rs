use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Một trình bao bọc xung quanh một `*mut T` thô không null cho biết rằng người sở hữu trình bao bọc này sở hữu tham chiếu.
/// Hữu ích để xây dựng các trừu tượng như `Box<T>`, `Vec<T>`, `String` và `HashMap<K, V>`.
///
/// Không giống như `*mut T`, `Unique<T>` hoạt động "as if", nó là một phiên bản của `T`.
/// Nó thực hiện `Send`/`Sync` nếu `T` là `Send`/`Sync`.
/// Nó cũng ngụ ý loại bảo đảm răng cưa mạnh mẽ mà một phiên bản của `T` có thể mong đợi:
/// tham chiếu của con trỏ không được sửa đổi nếu không có một đường dẫn duy nhất đến Unique của riêng nó.
///
/// Nếu bạn không chắc liệu việc sử dụng `Unique` cho mục đích của mình có đúng hay không, hãy cân nhắc sử dụng `NonNull`, có ngữ nghĩa yếu hơn.
///
///
/// Không giống như `*mut T`, con trỏ phải luôn không rỗng, ngay cả khi con trỏ không bao giờ được tham chiếu.
/// Điều này để các enums có thể sử dụng giá trị bị cấm này như một giá trị phân biệt-`Option<Unique<T>>` có cùng kích thước với `Unique<T>`.
/// Tuy nhiên, con trỏ có thể vẫn treo nếu nó không được tham chiếu.
///
/// Không giống như `*mut T`, `Unique<T>` là hiệp phương sai so với `T`.
/// Điều này phải luôn đúng đối với bất kỳ loại nào đáp ứng các yêu cầu về bí danh của Unique.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: điểm đánh dấu này không có hậu quả đối với phương sai, nhưng cần thiết
    // để dropck hiểu rằng chúng tôi sở hữu một cách hợp lý `T`.
    //
    // Để biết chi tiết, hãy xem:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` con trỏ là `Send` nếu `T` là `Send` vì dữ liệu mà chúng tham chiếu là không phân biệt.
/// Lưu ý rằng bất biến răng cưa này không được hệ thống kiểu bắt buộc;trừu tượng sử dụng `Unique` phải thực thi nó.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` con trỏ là `Sync` nếu `T` là `Sync` vì dữ liệu mà chúng tham chiếu là không phân biệt.
/// Lưu ý rằng bất biến răng cưa này không được hệ thống kiểu bắt buộc;trừu tượng sử dụng `Unique` phải thực thi nó.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Tạo ra một `Unique` mới lơ lửng, nhưng được căn chỉnh tốt.
    ///
    /// Điều này rất hữu ích cho việc khởi tạo các loại phân bổ lười biếng, như `Vec::new`.
    ///
    /// Lưu ý rằng giá trị con trỏ có thể đại diện cho một con trỏ hợp lệ tới `T`, có nghĩa là giá trị này không được sử dụng như một giá trị trạm canh "not yet initialized".
    /// Các kiểu phân bổ lười biếng phải theo dõi quá trình khởi tạo bằng một số phương tiện khác.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // AN TOÀN: mem::align_of() trả về một con trỏ hợp lệ, không rỗng.Các
        // điều kiện để gọi new_unchecked() do đó được tôn trọng.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Tạo `Unique` mới.
    ///
    /// # Safety
    ///
    /// `ptr` phải khác rỗng.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // AN TOÀN: người gọi phải đảm bảo rằng `ptr` là không rỗng.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Tạo `Unique` mới nếu `ptr` khác rỗng.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // AN TOÀN: Con trỏ đã được kiểm tra và không rỗng.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Nhận con trỏ `*mut` bên dưới.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Tham khảo nội dung.
    ///
    /// Thời gian tồn tại kết quả được ràng buộc với chính nó, vì vậy điều này hoạt động "as if" nó thực sự là một phiên bản của T đang được vay mượn.
    /// Nếu cần thời gian sử dụng (unbound) dài hơn, hãy sử dụng `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // AN TOÀN: người gọi phải đảm bảo rằng `self` đáp ứng tất cả các
        // yêu cầu đối với một tài liệu tham khảo.
        unsafe { &*self.as_ptr() }
    }

    /// Tham chiếu lẫn nhau về nội dung.
    ///
    /// Thời gian tồn tại kết quả được ràng buộc với chính nó, vì vậy điều này hoạt động "as if" nó thực sự là một phiên bản của T đang được vay mượn.
    /// Nếu cần thời gian sử dụng (unbound) dài hơn, hãy sử dụng `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // AN TOÀN: người gọi phải đảm bảo rằng `self` đáp ứng tất cả các
        // yêu cầu đối với tham chiếu có thể thay đổi.
        unsafe { &mut *self.as_ptr() }
    }

    /// Truyền tới một con trỏ thuộc loại khác.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // AN TOÀN: Unique::new_unchecked() tạo ra sự độc đáo mới và nhu cầu
        // con trỏ đã cho để không bị null.
        // Vì chúng ta đang vượt qua self dưới dạng một con trỏ, nó không thể là null.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // AN TOÀN: Tham chiếu có thể thay đổi không được để trống
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}