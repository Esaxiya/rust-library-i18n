use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Trả về `true` nếu con trỏ rỗng.
    ///
    /// Lưu ý rằng các kiểu chưa định kích thước có thể có nhiều con trỏ rỗng, vì chỉ con trỏ dữ liệu thô mới được xem xét, không phải chiều dài của chúng, vtable, v.v.
    /// Do đó, hai con trỏ rỗng có thể vẫn không được so sánh bằng nhau.
    ///
    /// ## Hành vi trong quá trình đánh giá const
    ///
    /// Khi hàm này được sử dụng trong quá trình đánh giá const, nó có thể trả về `false` cho các con trỏ trở thành null trong thời gian chạy.
    /// Cụ thể, khi một con trỏ tới một bộ nhớ nào đó bị lệch ra ngoài giới hạn của nó theo cách mà con trỏ kết quả là null, thì hàm sẽ vẫn trả về `false`.
    ///
    /// Không có cách nào để CTFE biết vị trí tuyệt đối của bộ nhớ đó, vì vậy chúng ta không thể biết con trỏ có rỗng hay không.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // So sánh thông qua ép kiểu với một con trỏ mỏng, vì vậy, con trỏ béo chỉ đang xem xét phần "data" của chúng là null-ness.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Truyền tới một con trỏ thuộc loại khác.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Phân rã một con trỏ (có thể rộng) thành các thành phần địa chỉ và siêu dữ liệu.
    ///
    /// Con trỏ có thể được tạo lại sau đó với [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Trả về `None` nếu con trỏ rỗng hoặc trả về một tham chiếu được chia sẻ đến giá trị được bao bọc trong `Some`.Nếu giá trị có thể chưa được khởi tạo, [`as_uninit_ref`] phải được sử dụng thay thế.
    ///
    /// Đối với đối tác có thể thay đổi, hãy xem [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Khi gọi phương thức này, bạn phải đảm bảo rằng *hoặc* con trỏ là NULL *hoặc* tất cả những điều sau là đúng:
    ///
    /// * Con trỏ phải được căn chỉnh đúng.
    ///
    /// * Nó phải là "dereferencable" theo nghĩa được định nghĩa trong [the module documentation].
    ///
    /// * Con trỏ phải trỏ đến một phiên bản đã khởi tạo của `T`.
    ///
    /// * Bạn phải thực thi các quy tắc răng cưa của Rust, vì thời gian tồn tại của `'a` được trả về được chọn tùy ý và không nhất thiết phản ánh thời gian tồn tại thực tế của dữ liệu.
    ///   Đặc biệt, trong suốt thời gian tồn tại này, bộ nhớ mà con trỏ trỏ đến không được thay đổi (ngoại trừ bên trong `UnsafeCell`).
    ///
    /// Điều này áp dụng ngay cả khi kết quả của phương pháp này không được sử dụng!
    /// (Phần về việc được khởi tạo vẫn chưa được quyết định đầy đủ, nhưng cho đến khi nó xảy ra, cách tiếp cận an toàn duy nhất là đảm bảo rằng chúng thực sự được khởi tạo.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Phiên bản không được chọn
    ///
    /// Nếu bạn chắc chắn con trỏ không bao giờ có thể rỗng và đang tìm kiếm một loại `as_ref_unchecked` nào đó trả về `&T` thay vì `Option<&T>`, hãy biết rằng bạn có thể tham khảo trực tiếp con trỏ.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // AN TOÀN: người gọi phải đảm bảo rằng `self` hợp lệ cho một
        // tham chiếu nếu nó không phải là null.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Trả về `None` nếu con trỏ rỗng hoặc trả về một tham chiếu được chia sẻ đến giá trị được bao bọc trong `Some`.
    /// Ngược lại với [`as_ref`], điều này không yêu cầu giá trị phải được khởi tạo.
    ///
    /// Đối với đối tác có thể thay đổi, hãy xem [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Khi gọi phương thức này, bạn phải đảm bảo rằng *hoặc* con trỏ là NULL *hoặc* tất cả những điều sau là đúng:
    ///
    /// * Con trỏ phải được căn chỉnh đúng.
    ///
    /// * Nó phải là "dereferencable" theo nghĩa được định nghĩa trong [the module documentation].
    ///
    /// * Bạn phải thực thi các quy tắc răng cưa của Rust, vì thời gian tồn tại của `'a` được trả về được chọn tùy ý và không nhất thiết phản ánh thời gian tồn tại thực tế của dữ liệu.
    ///
    ///   Đặc biệt, trong suốt thời gian tồn tại này, bộ nhớ mà con trỏ trỏ đến không được thay đổi (ngoại trừ bên trong `UnsafeCell`).
    ///
    /// Điều này áp dụng ngay cả khi kết quả của phương pháp này không được sử dụng!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // AN TOÀN: người gọi phải đảm bảo rằng `self` đáp ứng tất cả các
        // yêu cầu đối với một tài liệu tham khảo.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Tính toán độ lệch từ một con trỏ.
    ///
    /// `count` là đơn vị của T;ví dụ: `count` là 3 đại diện cho độ lệch con trỏ của byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Nếu bất kỳ điều kiện nào sau đây bị vi phạm, kết quả là Hành vi không xác định:
    ///
    /// * Cả con trỏ bắt đầu và con trỏ kết quả phải nằm trong giới hạn hoặc một byte sau phần cuối của cùng một đối tượng được cấp phát.
    /// Lưu ý rằng trong Rust, mọi biến (stack-allocated) được coi là một đối tượng được cấp phát riêng biệt.
    ///
    /// * Phần bù được tính toán,**tính bằng byte**, không thể làm tràn `isize`.
    ///
    /// * Phần bù nằm trong giới hạn không thể dựa vào không gian địa chỉ "wrapping around".Nghĩa là, tổng chính xác vô hạn,**tính bằng byte** phải vừa với một kích thước.
    ///
    /// Trình biên dịch và thư viện tiêu chuẩn thường cố gắng đảm bảo phân bổ không bao giờ đạt đến kích thước mà một phần bù là mối quan tâm.
    /// Ví dụ: `Vec` và `Box` đảm bảo chúng không bao giờ phân bổ nhiều hơn `isize::MAX` byte, vì vậy `vec.as_ptr().add(vec.len())` luôn an toàn.
    ///
    /// Hầu hết các nền tảng về cơ bản thậm chí không thể xây dựng một phân bổ như vậy.
    /// Ví dụ: không có nền tảng 64-bit nào được biết đến có thể phục vụ yêu cầu 2 <sup>63</sup> byte do các giới hạn của bảng trang hoặc phân chia không gian địa chỉ.
    /// Tuy nhiên, một số nền tảng 32 bit và 16 bit có thể phục vụ thành công một yêu cầu nhiều hơn `isize::MAX` byte với những thứ như Mở rộng địa chỉ vật lý.
    ///
    /// Do đó, bộ nhớ được lấy trực tiếp từ trình cấp phát hoặc tệp ánh xạ bộ nhớ *có thể* quá lớn để xử lý với chức năng này.
    ///
    /// Thay vào đó, hãy cân nhắc sử dụng [`wrapping_offset`] nếu những ràng buộc này khó thỏa mãn.
    /// Ưu điểm duy nhất của phương pháp này là nó cho phép tối ưu hóa trình biên dịch tích cực hơn.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `offset`.
        // Con trỏ thu được hợp lệ để ghi vì người gọi phải đảm bảo rằng nó trỏ đến cùng một đối tượng được cấp phát như `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Tính toán độ lệch từ một con trỏ bằng cách sử dụng gói số học.
    /// `count` là đơn vị của T;ví dụ: `count` là 3 đại diện cho độ lệch con trỏ của byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Bản thân hoạt động này luôn an toàn, nhưng sử dụng con trỏ kết quả thì không.
    ///
    /// Con trỏ kết quả vẫn được gắn vào cùng một đối tượng được cấp phát mà `self` trỏ tới.
    /// Nó có thể *không* được sử dụng để truy cập một đối tượng được cấp phát khác.Lưu ý rằng trong Rust, mọi biến (stack-allocated) được coi là một đối tượng được cấp phát riêng biệt.
    ///
    /// Nói cách khác, `let z = x.wrapping_offset((y as isize) - (x as isize))` không *không* làm cho `z` giống với `y` ngay cả khi chúng ta giả sử `T` có kích thước `1` và không có tràn: `z` vẫn được gắn với đối tượng mà `x` được đính kèm và tham chiếu nó là Hành vi không xác định trừ khi `x` `y` trỏ vào cùng một đối tượng được cấp phát.
    ///
    /// So với [`offset`], phương pháp này về cơ bản trì hoãn yêu cầu ở trong cùng một đối tượng được cấp phát: [`offset`] là Hành vi không xác định ngay lập tức khi vượt qua ranh giới đối tượng;`wrapping_offset` tạo ra một con trỏ nhưng vẫn dẫn đến Hành vi không xác định nếu một con trỏ được tham chiếu khi nó nằm ngoài giới hạn của đối tượng mà nó được gắn vào.
    /// [`offset`] có thể được tối ưu hóa tốt hơn và do đó thích hợp hơn trong mã nhạy cảm với hiệu suất.
    ///
    /// Việc kiểm tra trì hoãn chỉ xem xét giá trị của con trỏ đã được tham chiếu, không phải các giá trị trung gian được sử dụng trong quá trình tính toán kết quả cuối cùng.
    /// Ví dụ: `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` luôn giống với `x`.Nói cách khác, việc rời khỏi đối tượng đã cấp phát và sau đó nhập lại nó sau đó được cho phép.
    ///
    /// Nếu bạn cần vượt qua ranh giới đối tượng, hãy truyền con trỏ tới một số nguyên và thực hiện phép tính ở đó.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// // Lặp lại bằng cách sử dụng một con trỏ thô với gia số của hai phần tử
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // AN TOÀN: nội tại của `arith_offset` không có điều kiện tiên quyết để được gọi.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Trả về `None` nếu con trỏ rỗng hoặc trả về một tham chiếu duy nhất đến giá trị được bao bọc trong `Some`.Nếu giá trị có thể chưa được khởi tạo, [`as_uninit_mut`] phải được sử dụng thay thế.
    ///
    /// Đối với đối tác được chia sẻ, hãy xem [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Khi gọi phương thức này, bạn phải đảm bảo rằng *hoặc* con trỏ là NULL *hoặc* tất cả những điều sau là đúng:
    ///
    /// * Con trỏ phải được căn chỉnh đúng.
    ///
    /// * Nó phải là "dereferencable" theo nghĩa được định nghĩa trong [the module documentation].
    ///
    /// * Con trỏ phải trỏ đến một phiên bản đã khởi tạo của `T`.
    ///
    /// * Bạn phải thực thi các quy tắc răng cưa của Rust, vì thời gian tồn tại của `'a` được trả về được chọn tùy ý và không nhất thiết phản ánh thời gian tồn tại thực tế của dữ liệu.
    ///   Đặc biệt, trong khoảng thời gian tồn tại này, bộ nhớ mà con trỏ trỏ đến không được truy cập (đọc hoặc ghi) thông qua bất kỳ con trỏ nào khác.
    ///
    /// Điều này áp dụng ngay cả khi kết quả của phương pháp này không được sử dụng!
    /// (Phần về việc được khởi tạo vẫn chưa được quyết định đầy đủ, nhưng cho đến khi nó xảy ra, cách tiếp cận an toàn duy nhất là đảm bảo rằng chúng thực sự được khởi tạo.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Nó sẽ in: "[4, 2, 3]".
    /// ```
    ///
    /// # Phiên bản không được chọn
    ///
    /// Nếu bạn chắc chắn con trỏ không bao giờ có thể rỗng và đang tìm kiếm một loại `as_mut_unchecked` nào đó trả về `&mut T` thay vì `Option<&mut T>`, hãy biết rằng bạn có thể tham khảo trực tiếp con trỏ.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Nó sẽ in: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // AN TOÀN: người gọi phải đảm bảo rằng `self` hợp lệ cho
        // một tham chiếu có thể thay đổi nếu nó không phải là giá trị rỗng.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Trả về `None` nếu con trỏ rỗng hoặc trả về một tham chiếu duy nhất đến giá trị được bao bọc trong `Some`.
    /// Ngược lại với [`as_mut`], điều này không yêu cầu giá trị phải được khởi tạo.
    ///
    /// Đối với đối tác được chia sẻ, hãy xem [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Khi gọi phương thức này, bạn phải đảm bảo rằng *hoặc* con trỏ là NULL *hoặc* tất cả những điều sau là đúng:
    ///
    /// * Con trỏ phải được căn chỉnh đúng.
    ///
    /// * Nó phải là "dereferencable" theo nghĩa được định nghĩa trong [the module documentation].
    ///
    /// * Bạn phải thực thi các quy tắc răng cưa của Rust, vì thời gian tồn tại của `'a` được trả về được chọn tùy ý và không nhất thiết phản ánh thời gian tồn tại thực tế của dữ liệu.
    ///
    ///   Đặc biệt, trong khoảng thời gian tồn tại này, bộ nhớ mà con trỏ trỏ đến không được truy cập (đọc hoặc ghi) thông qua bất kỳ con trỏ nào khác.
    ///
    /// Điều này áp dụng ngay cả khi kết quả của phương pháp này không được sử dụng!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // AN TOÀN: người gọi phải đảm bảo rằng `self` đáp ứng tất cả các
        // yêu cầu đối với một tài liệu tham khảo.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Trả về liệu hai con trỏ có được đảm bảo bằng nhau hay không.
    ///
    /// Trong thời gian chạy, hàm này hoạt động giống như `self == other`.
    /// Tuy nhiên, trong một số ngữ cảnh (ví dụ: đánh giá thời gian biên dịch), không phải lúc nào cũng có thể xác định được sự bằng nhau của hai con trỏ, vì vậy hàm này có thể trả về `false` một cách ngẫu nhiên cho các con trỏ mà sau này thực sự là bằng nhau.
    ///
    /// Nhưng khi nó trả về `true`, các con trỏ được đảm bảo bằng nhau.
    ///
    /// Hàm này là phản chiếu của [`guaranteed_ne`], nhưng không phải là nghịch đảo của nó.Có các so sánh con trỏ mà cả hai hàm đều trả về `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Giá trị trả về có thể thay đổi tùy thuộc vào phiên bản trình biên dịch và mã không an toàn có thể không dựa vào kết quả của chức năng này cho độ ổn định.
    /// Bạn chỉ nên sử dụng hàm này để tối ưu hóa hiệu suất trong đó các giá trị trả về `false` giả bởi hàm này không ảnh hưởng đến kết quả mà chỉ ảnh hưởng đến hiệu suất.
    /// Hệ quả của việc sử dụng phương pháp này để làm cho thời gian chạy và mã thời gian biên dịch hoạt động khác nhau vẫn chưa được khám phá.
    /// Phương pháp này không nên được sử dụng để đưa ra những khác biệt như vậy, và nó cũng không nên ổn định trước khi chúng ta hiểu rõ hơn về vấn đề này.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Trả về liệu hai con trỏ có được đảm bảo là không bằng nhau hay không.
    ///
    /// Trong thời gian chạy, hàm này hoạt động giống như `self != other`.
    /// Tuy nhiên, trong một số ngữ cảnh (ví dụ: đánh giá thời gian biên dịch), không phải lúc nào cũng có thể xác định được sự bất bình đẳng của hai con trỏ, do đó, hàm này có thể trả về `false` cho các con trỏ mà sau này thực sự trở nên không bằng nhau.
    ///
    /// Nhưng khi nó trả về `true`, các con trỏ được đảm bảo là không bằng nhau.
    ///
    /// Hàm này là phản chiếu của [`guaranteed_eq`], nhưng không phải là nghịch đảo của nó.Có các so sánh con trỏ mà cả hai hàm đều trả về `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Giá trị trả về có thể thay đổi tùy thuộc vào phiên bản trình biên dịch và mã không an toàn có thể không dựa vào kết quả của chức năng này cho độ ổn định.
    /// Bạn chỉ nên sử dụng hàm này để tối ưu hóa hiệu suất trong đó các giá trị trả về `false` giả bởi hàm này không ảnh hưởng đến kết quả mà chỉ ảnh hưởng đến hiệu suất.
    /// Hệ quả của việc sử dụng phương pháp này để làm cho thời gian chạy và mã thời gian biên dịch hoạt động khác nhau vẫn chưa được khám phá.
    /// Phương pháp này không nên được sử dụng để đưa ra những khác biệt như vậy, và nó cũng không nên ổn định trước khi chúng ta hiểu rõ hơn về vấn đề này.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Tính khoảng cách giữa hai con trỏ.Giá trị trả về tính bằng đơn vị T: khoảng cách tính bằng byte chia cho `mem::size_of::<T>()`.
    ///
    /// Hàm này là nghịch đảo của [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Nếu bất kỳ điều kiện nào sau đây bị vi phạm, kết quả là Hành vi không xác định:
    ///
    /// * Cả con trỏ bắt đầu và con trỏ khác phải nằm trong giới hạn hoặc một byte sau phần cuối của cùng một đối tượng được cấp phát.
    /// Lưu ý rằng trong Rust, mọi biến (stack-allocated) được coi là một đối tượng được cấp phát riêng biệt.
    ///
    /// * Cả hai con trỏ phải được *bắt nguồn từ* một con trỏ đến cùng một đối tượng.
    ///   (Xem ví dụ bên dưới.)
    ///
    /// * Khoảng cách giữa các con trỏ, tính bằng byte, phải là bội số chính xác của kích thước `T`.
    ///
    /// * Khoảng cách giữa các con trỏ,**tính bằng byte**, không thể làm tràn `isize`.
    ///
    /// * Khoảng cách nằm trong giới hạn không thể dựa vào không gian địa chỉ "wrapping around".
    ///
    /// Loại Rust không bao giờ lớn hơn `isize::MAX` và phân bổ Rust không bao giờ quấn quanh không gian địa chỉ, vì vậy hai con trỏ trong một số giá trị của bất kỳ loại Rust nào `T` sẽ luôn thỏa mãn hai điều kiện cuối cùng.
    ///
    /// Thư viện tiêu chuẩn cũng thường đảm bảo rằng các phân bổ không bao giờ đạt đến kích thước mà phần bù là mối quan tâm.
    /// Ví dụ: `Vec` và `Box` đảm bảo chúng không bao giờ phân bổ nhiều hơn `isize::MAX` byte, vì vậy `ptr_into_vec.offset_from(vec.as_ptr())` luôn thỏa mãn hai điều kiện cuối cùng.
    ///
    /// Hầu hết các nền tảng về cơ bản thậm chí không thể tạo ra một phân bổ lớn như vậy.
    /// Ví dụ: không có nền tảng 64-bit nào được biết đến có thể phục vụ yêu cầu 2 <sup>63</sup> byte do các giới hạn của bảng trang hoặc phân chia không gian địa chỉ.
    /// Tuy nhiên, một số nền tảng 32 bit và 16 bit có thể phục vụ thành công một yêu cầu nhiều hơn `isize::MAX` byte với những thứ như Mở rộng địa chỉ vật lý.
    /// Do đó, bộ nhớ được lấy trực tiếp từ trình cấp phát hoặc tệp ánh xạ bộ nhớ *có thể* quá lớn để xử lý với chức năng này.
    /// (Lưu ý rằng [`offset`] và [`add`] cũng có một hạn chế tương tự và do đó cũng không thể được sử dụng trên các phân bổ lớn như vậy.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Chức năng này panics nếu `T` là Loại ("ZST") Không kích thước.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Cách sử dụng* không chính xác:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Tạo ptr2_other thành "alias" của ptr2, nhưng bắt nguồn từ ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Vì ptr2_other và ptr2 có nguồn gốc từ các con trỏ đến các đối tượng khác nhau, việc tính toán độ lệch của chúng là hành vi không xác định, mặc dù chúng trỏ đến cùng một địa chỉ!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Hành vi không xác định
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `offset_from`.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Tính toán độ lệch từ một con trỏ (tiện lợi cho `.offset(count as isize)`).
    ///
    /// `count` là đơn vị của T;ví dụ: `count` là 3 đại diện cho độ lệch con trỏ của byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Nếu bất kỳ điều kiện nào sau đây bị vi phạm, kết quả là Hành vi không xác định:
    ///
    /// * Cả con trỏ bắt đầu và con trỏ kết quả phải nằm trong giới hạn hoặc một byte sau phần cuối của cùng một đối tượng được cấp phát.
    /// Lưu ý rằng trong Rust, mọi biến (stack-allocated) được coi là một đối tượng được cấp phát riêng biệt.
    ///
    /// * Phần bù được tính toán,**tính bằng byte**, không thể làm tràn `isize`.
    ///
    /// * Phần bù nằm trong giới hạn không thể dựa vào không gian địa chỉ "wrapping around".Nghĩa là, tổng độ chính xác vô hạn phải vừa với `usize`.
    ///
    /// Trình biên dịch và thư viện tiêu chuẩn thường cố gắng đảm bảo phân bổ không bao giờ đạt đến kích thước mà một phần bù là mối quan tâm.
    /// Ví dụ: `Vec` và `Box` đảm bảo chúng không bao giờ phân bổ nhiều hơn `isize::MAX` byte, vì vậy `vec.as_ptr().add(vec.len())` luôn an toàn.
    ///
    /// Hầu hết các nền tảng về cơ bản thậm chí không thể xây dựng một phân bổ như vậy.
    /// Ví dụ: không có nền tảng 64-bit nào được biết đến có thể phục vụ yêu cầu 2 <sup>63</sup> byte do các giới hạn của bảng trang hoặc phân chia không gian địa chỉ.
    /// Tuy nhiên, một số nền tảng 32 bit và 16 bit có thể phục vụ thành công một yêu cầu nhiều hơn `isize::MAX` byte với những thứ như Mở rộng địa chỉ vật lý.
    ///
    /// Do đó, bộ nhớ được lấy trực tiếp từ trình cấp phát hoặc tệp ánh xạ bộ nhớ *có thể* quá lớn để xử lý với chức năng này.
    ///
    /// Thay vào đó, hãy cân nhắc sử dụng [`wrapping_add`] nếu những ràng buộc này khó thỏa mãn.
    /// Ưu điểm duy nhất của phương pháp này là nó cho phép tối ưu hóa trình biên dịch tích cực hơn.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Tính toán độ lệch từ một con trỏ (thuận tiện cho `.offset ((tính là isize).wrapping_neg())`).
    ///
    /// `count` là đơn vị của T;ví dụ: `count` là 3 đại diện cho độ lệch con trỏ của byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Nếu bất kỳ điều kiện nào sau đây bị vi phạm, kết quả là Hành vi không xác định:
    ///
    /// * Cả con trỏ bắt đầu và con trỏ kết quả phải nằm trong giới hạn hoặc một byte sau phần cuối của cùng một đối tượng được cấp phát.
    /// Lưu ý rằng trong Rust, mọi biến (stack-allocated) được coi là một đối tượng được cấp phát riêng biệt.
    ///
    /// * Phần bù được tính toán không được vượt quá `isize::MAX`**byte**.
    ///
    /// * Phần bù nằm trong giới hạn không thể dựa vào không gian địa chỉ "wrapping around".Nghĩa là, tổng độ chính xác vô hạn phải phù hợp với một kích thước.
    ///
    /// Trình biên dịch và thư viện tiêu chuẩn thường cố gắng đảm bảo phân bổ không bao giờ đạt đến kích thước mà một phần bù là mối quan tâm.
    /// Ví dụ: `Vec` và `Box` đảm bảo chúng không bao giờ phân bổ nhiều hơn `isize::MAX` byte, vì vậy `vec.as_ptr().add(vec.len()).sub(vec.len())` luôn an toàn.
    ///
    /// Hầu hết các nền tảng về cơ bản thậm chí không thể xây dựng một phân bổ như vậy.
    /// Ví dụ: không có nền tảng 64-bit nào được biết đến có thể phục vụ yêu cầu 2 <sup>63</sup> byte do các giới hạn của bảng trang hoặc phân chia không gian địa chỉ.
    /// Tuy nhiên, một số nền tảng 32 bit và 16 bit có thể phục vụ thành công một yêu cầu nhiều hơn `isize::MAX` byte với những thứ như Mở rộng địa chỉ vật lý.
    ///
    /// Do đó, bộ nhớ được lấy trực tiếp từ trình cấp phát hoặc tệp ánh xạ bộ nhớ *có thể* quá lớn để xử lý với chức năng này.
    ///
    /// Thay vào đó, hãy cân nhắc sử dụng [`wrapping_sub`] nếu những ràng buộc này khó thỏa mãn.
    /// Ưu điểm duy nhất của phương pháp này là nó cho phép tối ưu hóa trình biên dịch tích cực hơn.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Tính toán độ lệch từ một con trỏ bằng cách sử dụng gói số học.
    /// (tiện lợi cho `.wrapping_offset(count as isize)`)
    ///
    /// `count` là đơn vị của T;ví dụ: `count` là 3 đại diện cho độ lệch con trỏ của byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Bản thân hoạt động này luôn an toàn, nhưng sử dụng con trỏ kết quả thì không.
    ///
    /// Con trỏ kết quả vẫn được gắn vào cùng một đối tượng được cấp phát mà `self` trỏ tới.
    /// Nó có thể *không* được sử dụng để truy cập một đối tượng được cấp phát khác.Lưu ý rằng trong Rust, mọi biến (stack-allocated) được coi là một đối tượng được cấp phát riêng biệt.
    ///
    /// Nói cách khác, `let z = x.wrapping_add((y as usize) - (x as usize))`*không* làm cho `z` giống với `y` ngay cả khi chúng ta giả sử `T` có kích thước `1` và không có tràn: `z` vẫn được gắn với đối tượng mà `x` được đính kèm và tham chiếu đến nó là Hành vi không xác định trừ khi `x` và `y` trỏ vào cùng một đối tượng được cấp phát.
    ///
    /// So với [`add`], phương pháp này về cơ bản trì hoãn yêu cầu ở trong cùng một đối tượng được cấp phát: [`add`] là Hành vi không xác định ngay lập tức khi vượt qua ranh giới đối tượng;`wrapping_add` tạo ra một con trỏ nhưng vẫn dẫn đến Hành vi không xác định nếu một con trỏ được tham chiếu khi nó nằm ngoài giới hạn của đối tượng mà nó được gắn vào.
    /// [`add`] có thể được tối ưu hóa tốt hơn và do đó thích hợp hơn trong mã nhạy cảm với hiệu suất.
    ///
    /// Việc kiểm tra trì hoãn chỉ xem xét giá trị của con trỏ đã được tham chiếu, không phải các giá trị trung gian được sử dụng trong quá trình tính toán kết quả cuối cùng.
    /// Ví dụ: `x.wrapping_add(o).wrapping_sub(o)` luôn giống với `x`.Nói cách khác, việc rời khỏi đối tượng đã cấp phát và sau đó nhập lại nó sau đó được cho phép.
    ///
    /// Nếu bạn cần vượt qua ranh giới đối tượng, hãy truyền con trỏ tới một số nguyên và thực hiện phép tính ở đó.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// // Lặp lại bằng cách sử dụng một con trỏ thô với gia số của hai phần tử
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Vòng lặp này in ra "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Tính toán độ lệch từ một con trỏ bằng cách sử dụng gói số học.
    /// (thuận tiện cho `.wrapping_offset ((tính là isize).wrapping_neg())`)
    ///
    /// `count` là đơn vị của T;ví dụ: `count` là 3 đại diện cho độ lệch con trỏ của byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Bản thân hoạt động này luôn an toàn, nhưng sử dụng con trỏ kết quả thì không.
    ///
    /// Con trỏ kết quả vẫn được gắn vào cùng một đối tượng được cấp phát mà `self` trỏ tới.
    /// Nó có thể *không* được sử dụng để truy cập một đối tượng được cấp phát khác.Lưu ý rằng trong Rust, mọi biến (stack-allocated) được coi là một đối tượng được cấp phát riêng biệt.
    ///
    /// Nói cách khác, `let z = x.wrapping_sub((x as usize) - (y as usize))` không *không* làm cho `z` giống với `y` ngay cả khi chúng ta giả sử `T` có kích thước `1` và không có tràn: `z` vẫn được gắn với đối tượng mà `x` được đính kèm và tham chiếu nó là Hành vi không xác định trừ khi `x` và `y` trỏ vào cùng một đối tượng được cấp phát.
    ///
    /// So với [`sub`], phương pháp này về cơ bản trì hoãn yêu cầu ở trong cùng một đối tượng được cấp phát: [`sub`] là Hành vi không xác định ngay lập tức khi vượt qua ranh giới đối tượng;`wrapping_sub` tạo ra một con trỏ nhưng vẫn dẫn đến Hành vi không xác định nếu một con trỏ được tham chiếu khi nó nằm ngoài giới hạn của đối tượng mà nó được gắn vào.
    /// [`sub`] có thể được tối ưu hóa tốt hơn và do đó thích hợp hơn trong mã nhạy cảm với hiệu suất.
    ///
    /// Việc kiểm tra trì hoãn chỉ xem xét giá trị của con trỏ đã được tham chiếu, không phải các giá trị trung gian được sử dụng trong quá trình tính toán kết quả cuối cùng.
    /// Ví dụ: `x.wrapping_add(o).wrapping_sub(o)` luôn giống với `x`.Nói cách khác, việc rời khỏi đối tượng đã cấp phát và sau đó nhập lại nó sau đó được cho phép.
    ///
    /// Nếu bạn cần vượt qua ranh giới đối tượng, hãy truyền con trỏ tới một số nguyên và thực hiện phép tính ở đó.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// // Lặp lại bằng cách sử dụng một con trỏ thô theo gia số của hai phần tử (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Vòng lặp này in ra "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Đặt giá trị con trỏ thành `ptr`.
    ///
    /// Trong trường hợp `self` là con trỏ (fat) đến kiểu chưa có kích thước, thao tác này sẽ chỉ ảnh hưởng đến phần con trỏ, trong khi đối với con trỏ (thin) đến kiểu có kích thước, thao tác này có tác dụng tương tự như một phép gán đơn giản.
    ///
    /// Con trỏ kết quả sẽ có xuất xứ là `val`, tức là, đối với con trỏ béo, hoạt động này về mặt ngữ nghĩa giống như tạo một con trỏ béo mới với giá trị con trỏ dữ liệu là `val` nhưng là siêu dữ liệu của `self`.
    ///
    ///
    /// # Examples
    ///
    /// Hàm này chủ yếu hữu ích để cho phép tính toán con trỏ theo byte trên các con trỏ béo tiềm năng:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // sẽ in "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // AN TOÀN: Trong trường hợp con trỏ mỏng, các thao tác này giống hệt nhau
        // đến một nhiệm vụ đơn giản.
        // Trong trường hợp con trỏ béo, với việc triển khai bố cục con trỏ béo hiện tại, trường đầu tiên của con trỏ như vậy luôn là con trỏ dữ liệu, cũng được gán tương tự.
        //
        unsafe { *thin = val };
        self
    }

    /// Đọc giá trị từ `self` mà không cần di chuyển nó.
    /// Điều này làm cho bộ nhớ trong `self` không thay đổi.
    ///
    /// Xem [`ptr::read`] để biết các mối quan tâm và ví dụ về an toàn.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho ``.
        unsafe { read(self) }
    }

    /// Thực hiện đọc giá trị không ổn định từ `self` mà không cần di chuyển nó.Điều này khiến bộ nhớ trong `self` không thay đổi.
    ///
    /// Các hoạt động dễ bay hơi nhằm mục đích hoạt động trên bộ nhớ I/O và được đảm bảo không bị trình biên dịch giải thích hoặc sắp xếp lại thứ tự qua các hoạt động dễ bay hơi khác.
    ///
    ///
    /// Xem [`ptr::read_volatile`] để biết các mối quan tâm và ví dụ về an toàn.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Đọc giá trị từ `self` mà không cần di chuyển nó.
    /// Điều này làm cho bộ nhớ trong `self` không thay đổi.
    ///
    /// Không giống như `read`, con trỏ có thể bị lệch.
    ///
    /// Xem [`ptr::read_unaligned`] để biết các mối quan tâm và ví dụ về an toàn.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Sao chép các byte `count * size_of<T>` từ `self` sang `dest`.
    /// Nguồn và đích có thể trùng nhau.
    ///
    /// NOTE: điều này có thứ tự đối số *giống* như [`ptr::copy`].
    ///
    /// Xem [`ptr::copy`] để biết các mối quan tâm và ví dụ về an toàn.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Sao chép các byte `count * size_of<T>` từ `self` sang `dest`.
    /// Nguồn và đích có thể *không* trùng nhau.
    ///
    /// NOTE: điều này có thứ tự đối số *giống* như [`ptr::copy_nonoverlapping`].
    ///
    /// Xem [`ptr::copy_nonoverlapping`] để biết các mối quan tâm và ví dụ về an toàn.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Sao chép các byte `count * size_of<T>` từ `src` sang `self`.
    /// Nguồn và đích có thể trùng nhau.
    ///
    /// NOTE: điều này có thứ tự đối số *ngược lại* của [`ptr::copy`].
    ///
    /// Xem [`ptr::copy`] để biết các mối quan tâm và ví dụ về an toàn.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `copy`.
        unsafe { copy(src, self, count) }
    }

    /// Sao chép các byte `count * size_of<T>` từ `src` sang `self`.
    /// Nguồn và đích có thể *không* trùng nhau.
    ///
    /// NOTE: điều này có thứ tự đối số *ngược lại* của [`ptr::copy_nonoverlapping`].
    ///
    /// Xem [`ptr::copy_nonoverlapping`] để biết các mối quan tâm và ví dụ về an toàn.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Thực thi hàm hủy (nếu có) của giá trị trỏ đến.
    ///
    /// Xem [`ptr::drop_in_place`] để biết các mối quan tâm và ví dụ về an toàn.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `drop_in_place`.
        unsafe { drop_in_place(self) }
    }

    /// Ghi đè vị trí bộ nhớ với giá trị đã cho mà không đọc hoặc giảm giá trị cũ.
    ///
    ///
    /// Xem [`ptr::write`] để biết các mối quan tâm và ví dụ về an toàn.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `write`.
        unsafe { write(self, val) }
    }

    /// Gọi bộ nhớ trên con trỏ được chỉ định, đặt `count * size_of::<T>()` byte bộ nhớ bắt đầu từ `self` thành `val`.
    ///
    ///
    /// Xem [`ptr::write_bytes`] để biết các mối quan tâm và ví dụ về an toàn.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `write_bytes`.
        unsafe { write_bytes(self, val, count) }
    }

    /// Thực hiện ghi biến động vị trí bộ nhớ với giá trị đã cho mà không đọc hoặc giảm giá trị cũ.
    ///
    /// Các hoạt động dễ bay hơi nhằm mục đích hoạt động trên bộ nhớ I/O và được đảm bảo không bị trình biên dịch giải thích hoặc sắp xếp lại thứ tự qua các hoạt động dễ bay hơi khác.
    ///
    ///
    /// Xem [`ptr::write_volatile`] để biết các mối quan tâm và ví dụ về an toàn.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `write_volatile`.
        unsafe { write_volatile(self, val) }
    }

    /// Ghi đè vị trí bộ nhớ với giá trị đã cho mà không đọc hoặc giảm giá trị cũ.
    ///
    ///
    /// Không giống như `write`, con trỏ có thể bị lệch.
    ///
    /// Xem [`ptr::write_unaligned`] để biết các mối quan tâm và ví dụ về an toàn.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `write_unaligned`.
        unsafe { write_unaligned(self, val) }
    }

    /// Thay thế giá trị tại `self` bằng `src`, trả về giá trị cũ mà không bị giảm.
    ///
    ///
    /// Xem [`ptr::replace`] để biết các mối quan tâm và ví dụ về an toàn.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `replace`.
        unsafe { replace(self, src) }
    }

    /// Hoán đổi các giá trị tại hai vị trí có thể thay đổi của cùng một loại, mà không làm biến dạng.
    /// Chúng có thể chồng chéo lên nhau, không giống như `mem::swap` tương đương.
    ///
    /// Xem [`ptr::swap`] để biết các mối quan tâm và ví dụ về an toàn.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `swap`.
        unsafe { swap(self, with) }
    }

    /// Tính toán độ lệch cần được áp dụng cho con trỏ để làm cho nó được căn chỉnh với `align`.
    ///
    /// Nếu không thể căn chỉnh con trỏ, việc triển khai trả về `usize::MAX`.
    /// Cho phép việc triển khai *luôn* trả về `usize::MAX`.
    /// Chỉ hiệu suất của thuật toán của bạn có thể phụ thuộc vào việc nhận được phần bù có thể sử dụng ở đây, chứ không phải tính đúng đắn của nó.
    ///
    /// Độ lệch được biểu thị bằng số phần tử `T` chứ không phải byte.Giá trị trả về có thể được sử dụng với phương thức `wrapping_add`.
    ///
    /// Không có gì đảm bảo rằng việc bù đắp con trỏ sẽ không bị tràn hoặc vượt quá phân bổ mà con trỏ trỏ vào.
    ///
    /// Người gọi tùy thuộc vào việc đảm bảo rằng giá trị bù được trả về là chính xác trong tất cả các thuật ngữ ngoại trừ việc căn chỉnh.
    ///
    /// # Panics
    ///
    /// Hàm panics nếu `align` không phải là lũy thừa của hai.
    ///
    /// # Examples
    ///
    /// Truy cập `u8` liền kề dưới dạng `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // trong khi con trỏ có thể được căn chỉnh thông qua `offset`, nó sẽ trỏ ra ngoài phân bổ
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // AN TOÀN: `align` đã được kiểm tra để trở thành sức mạnh của 2 mức trên
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Trả về độ dài của một lát thô.
    ///
    /// Giá trị trả về là số **phần tử**, không phải số byte.
    ///
    /// Chức năng này an toàn, ngay cả khi không thể truyền lát thô tới một tham chiếu lát vì con trỏ rỗng hoặc không có dấu.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // AN TOÀN: điều này là an toàn vì `*const [T]` và `FatPtr<T>` có cùng một bố cục.
            // Chỉ có `std` mới có thể đảm bảo điều này.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Trả về một con trỏ thô vào bộ đệm của lát cắt.
    ///
    /// Điều này tương đương với việc đúc `self` thành `*mut T`, nhưng an toàn hơn.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Trả về một con trỏ thô cho một phần tử hoặc sublice mà không cần thực hiện kiểm tra giới hạn.
    ///
    /// Gọi phương thức này với chỉ mục nằm ngoài giới hạn hoặc khi `self` không có khả năng truy cập là *[hành vi không xác định]* ngay cả khi con trỏ kết quả không được sử dụng.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // AN TOÀN: người gọi đảm bảo rằng `self` là không thể xem xét và `index` trong giới hạn.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Trả về `None` nếu con trỏ rỗng hoặc trả về một lát chia sẻ với giá trị được bao bọc trong `Some`.
    /// Ngược lại với [`as_ref`], điều này không yêu cầu giá trị phải được khởi tạo.
    ///
    /// Đối với đối tác có thể thay đổi, hãy xem [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Khi gọi phương thức này, bạn phải đảm bảo rằng *hoặc* con trỏ là NULL *hoặc* tất cả những điều sau là đúng:
    ///
    /// * Con trỏ phải là [valid] để đọc cho `ptr.len() * mem::size_of::<T>()` nhiều byte và nó phải được căn chỉnh chính xác.Điều này đặc biệt có nghĩa là:
    ///
    ///     * Toàn bộ phạm vi bộ nhớ của lát cắt này phải được chứa trong một đối tượng được cấp phát duy nhất!
    ///       Slices không bao giờ có thể trải dài trên nhiều đối tượng được phân bổ.
    ///
    ///     * Con trỏ phải được căn chỉnh ngay cả đối với các lát cắt có độ dài bằng không.
    ///     Một lý do cho điều này là tối ưu hóa bố cục enum có thể dựa vào các tham chiếu (bao gồm các phần có độ dài bất kỳ) được căn chỉnh và không rỗng để phân biệt chúng với các dữ liệu khác.
    ///
    ///     Bạn có thể lấy một con trỏ có thể sử dụng được dưới dạng `data` cho các lát cắt có độ dài bằng 0 bằng [`NonNull::dangling()`].
    ///
    /// * Tổng kích thước `ptr.len() * mem::size_of::<T>()` của lát cắt không được lớn hơn `isize::MAX`.
    ///   Xem tài liệu an toàn của [`pointer::offset`].
    ///
    /// * Bạn phải thực thi các quy tắc răng cưa của Rust, vì thời gian tồn tại của `'a` được trả về được chọn tùy ý và không nhất thiết phản ánh thời gian tồn tại thực tế của dữ liệu.
    ///   Đặc biệt, trong suốt thời gian tồn tại này, bộ nhớ mà con trỏ trỏ đến không được thay đổi (ngoại trừ bên trong `UnsafeCell`).
    ///
    /// Điều này áp dụng ngay cả khi kết quả của phương pháp này không được sử dụng!
    ///
    /// Xem thêm [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Trả về `None` nếu con trỏ rỗng hoặc trả về một lát duy nhất cho giá trị được bao bọc trong `Some`.
    /// Ngược lại với [`as_mut`], điều này không yêu cầu giá trị phải được khởi tạo.
    ///
    /// Đối với đối tác được chia sẻ, hãy xem [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Khi gọi phương thức này, bạn phải đảm bảo rằng *hoặc* con trỏ là NULL *hoặc* tất cả những điều sau là đúng:
    ///
    /// * Con trỏ phải là [valid] để đọc và ghi cho `ptr.len() * mem::size_of::<T>()` nhiều byte và nó phải được căn chỉnh đúng cách.Điều này đặc biệt có nghĩa là:
    ///
    ///     * Toàn bộ phạm vi bộ nhớ của lát cắt này phải được chứa trong một đối tượng được cấp phát duy nhất!
    ///       Slices không bao giờ có thể trải dài trên nhiều đối tượng được phân bổ.
    ///
    ///     * Con trỏ phải được căn chỉnh ngay cả đối với các lát cắt có độ dài bằng không.
    ///     Một lý do cho điều này là tối ưu hóa bố cục enum có thể dựa vào các tham chiếu (bao gồm các phần có độ dài bất kỳ) được căn chỉnh và không rỗng để phân biệt chúng với các dữ liệu khác.
    ///
    ///     Bạn có thể lấy một con trỏ có thể sử dụng được dưới dạng `data` cho các lát cắt có độ dài bằng 0 bằng [`NonNull::dangling()`].
    ///
    /// * Tổng kích thước `ptr.len() * mem::size_of::<T>()` của lát cắt không được lớn hơn `isize::MAX`.
    ///   Xem tài liệu an toàn của [`pointer::offset`].
    ///
    /// * Bạn phải thực thi các quy tắc răng cưa của Rust, vì thời gian tồn tại của `'a` được trả về được chọn tùy ý và không nhất thiết phản ánh thời gian tồn tại thực tế của dữ liệu.
    ///   Đặc biệt, trong khoảng thời gian tồn tại này, bộ nhớ mà con trỏ trỏ đến không được truy cập (đọc hoặc ghi) thông qua bất kỳ con trỏ nào khác.
    ///
    /// Điều này áp dụng ngay cả khi kết quả của phương pháp này không được sử dụng!
    ///
    /// Xem thêm [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `as_uninit_slice_mut`.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Bình đẳng cho con trỏ
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}