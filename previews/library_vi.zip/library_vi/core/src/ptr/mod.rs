//! Quản lý thủ công bộ nhớ thông qua các con trỏ thô.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Nhiều hàm trong mô-đun này lấy con trỏ thô làm đối số và đọc hoặc ghi vào chúng.Để điều này được an toàn, các con trỏ này phải *hợp lệ*.
//! Một con trỏ có hợp lệ hay không phụ thuộc vào hoạt động mà nó được sử dụng (đọc hoặc ghi) và phạm vi bộ nhớ được truy cập (tức là read/written có bao nhiêu byte).
//! Hầu hết các hàm sử dụng `*mut T` và `* const T` chỉ để truy cập một giá trị duy nhất, trong trường hợp này, tài liệu sẽ bỏ qua kích thước và mặc nhiên giả định nó là các byte `size_of::<T>()`.
//!
//! Các quy tắc chính xác về hiệu lực vẫn chưa được xác định.Các đảm bảo được cung cấp tại thời điểm này là rất tối thiểu:
//!
//! * Con trỏ [null] là *không bao giờ* hợp lệ, ngay cả đối với các truy cập của [size zero][zst].
//! * Để một con trỏ hợp lệ, điều cần thiết, nhưng không phải lúc nào cũng đủ, con trỏ phải *có thể tham khảo*: phạm vi bộ nhớ có kích thước đã cho bắt đầu từ con trỏ phải nằm trong giới hạn của một đối tượng được cấp phát duy nhất.
//!
//! Lưu ý rằng trong Rust, mọi biến (stack-allocated) được coi là một đối tượng được cấp phát riêng biệt.
//! * Ngay cả đối với các hoạt động của [size zero][zst], con trỏ không được trỏ đến bộ nhớ được phân bổ, tức là, việc phân bổ thỏa thuận làm cho con trỏ không hợp lệ ngay cả đối với các hoạt động có kích thước bằng không.
//! Tuy nhiên, truyền bất kỳ số nguyên khác 0 *nghĩa đen* tới một con trỏ đều hợp lệ đối với các truy cập có kích thước bằng 0, ngay cả khi một số bộ nhớ tình cờ tồn tại tại địa chỉ đó và được phân bổ.
//! Điều này tương ứng với việc viết trình cấp phát của riêng bạn: cấp phát các đối tượng có kích thước bằng không không khó lắm.
//! Cách chuẩn để lấy con trỏ hợp lệ cho các truy cập có kích thước bằng không là [`NonNull::dangling`].
//! * Tất cả các truy cập được thực hiện bởi các chức năng trong mô-đun này là *phi nguyên tử* theo nghĩa của [atomic operations] được sử dụng để đồng bộ hóa giữa các luồng.
//! Điều này có nghĩa là nó là hành vi không xác định để thực hiện hai truy cập đồng thời đến cùng một vị trí từ các luồng khác nhau trừ khi cả hai truy cập chỉ đọc từ bộ nhớ.
//! Lưu ý rằng điều này bao gồm rõ ràng [`read_volatile`] và [`write_volatile`]: Không thể sử dụng các truy cập linh hoạt để đồng bộ hóa liên luồng.
//! * Kết quả của việc truyền một tham chiếu đến một con trỏ có giá trị miễn là đối tượng bên dưới còn hoạt động và không có tham chiếu nào (chỉ là con trỏ thô) được sử dụng để truy cập cùng một bộ nhớ.
//!
//! Những tiên đề này, cùng với việc sử dụng cẩn thận [`offset`] cho số học con trỏ, đủ để triển khai chính xác nhiều điều hữu ích trong mã không an toàn.
//! Cuối cùng sẽ cung cấp các đảm bảo mạnh mẽ hơn, vì các quy tắc [aliasing] đang được xác định.
//! Để biết thêm thông tin, hãy xem [book] cũng như phần trong tài liệu tham khảo dành cho [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Các con trỏ thô hợp lệ như được định nghĩa ở trên không nhất thiết phải được căn chỉnh chính xác (trong đó căn chỉnh "proper" được xác định bởi loại con trỏ, tức là `*const T` phải được căn chỉnh thành `mem::align_of::<T>()`).
//! Tuy nhiên, hầu hết các hàm đều yêu cầu các đối số của chúng phải được căn chỉnh đúng và sẽ nêu rõ yêu cầu này trong tài liệu của chúng.
//! Các trường hợp ngoại lệ đáng chú ý là [`read_unaligned`] và [`write_unaligned`].
//!
//! Khi một hàm yêu cầu căn chỉnh thích hợp, nó sẽ làm như vậy ngay cả khi quyền truy cập có kích thước 0, tức là, ngay cả khi bộ nhớ không thực sự được chạm vào.Hãy xem xét sử dụng [`NonNull::dangling`] trong những trường hợp như vậy.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Thực thi hàm hủy (nếu có) của giá trị trỏ đến.
///
/// Về mặt ngữ nghĩa, điều này tương đương với việc gọi [`ptr::read`] và loại bỏ kết quả, nhưng có những ưu điểm sau:
///
/// * *Bắt buộc* sử dụng `drop_in_place` để thả các loại không có kích thước như đối tượng trait, vì chúng không thể được đọc ra trên ngăn xếp và được thả bình thường.
///
/// * Sẽ thân thiện hơn với trình tối ưu hóa để thực hiện điều này trên [`ptr::read`] khi giảm bộ nhớ được cấp phát theo cách thủ công (ví dụ: trong các triển khai của `Box`/`Rc`/`Vec`), vì trình biên dịch không cần phải chứng minh rằng việc xử lý bản sao là hợp lý.
///
///
/// * Nó có thể được sử dụng để loại bỏ dữ liệu [pinned] khi `T` không phải là `repr(packed)` (dữ liệu được ghim không được di chuyển trước khi bị loại bỏ).
///
/// Các giá trị không được căn chỉnh không thể được thả tại chỗ, chúng phải được sao chép vào vị trí đã căn chỉnh trước bằng cách sử dụng [`ptr::read_unaligned`].Đối với các cấu trúc được đóng gói, việc di chuyển này được trình biên dịch thực hiện tự động.
/// Điều này có nghĩa là các trường của cấu trúc được đóng gói không được đưa vào đúng vị trí.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Hành vi là không xác định nếu bất kỳ điều kiện nào sau đây bị vi phạm:
///
/// * `to_drop` phải là [valid] cho cả đọc và ghi.
///
/// * `to_drop` phải được căn chỉnh phù hợp.
///
/// * Giá trị `to_drop` trỏ tới phải có giá trị để giảm xuống, có thể có nghĩa là nó phải duy trì các bất biến bổ sung, điều này phụ thuộc vào loại.
///
/// Ngoài ra, nếu `T` không phải là [`Copy`], việc sử dụng giá trị trỏ đến sau khi gọi `drop_in_place` có thể gây ra hành vi không xác định.Lưu ý rằng `*to_drop = foo` được tính là một lần sử dụng vì nó sẽ khiến giá trị bị giảm xuống một lần nữa.
/// [`write()`] có thể được sử dụng để ghi đè dữ liệu mà không làm cho nó bị xóa.
///
/// Lưu ý rằng ngay cả khi `T` có kích thước `0`, con trỏ phải không phải là NULL và được căn chỉnh đúng cách.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Xóa mục cuối cùng khỏi vector theo cách thủ công:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Nhận một con trỏ thô đến phần tử cuối cùng trong `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Rút ngắn `v` để ngăn mục cuối cùng bị rơi.
///     // Chúng tôi làm điều đó trước tiên, để ngăn chặn sự cố nếu `drop_in_place` dưới panics.
///     v.set_len(1);
///     // Nếu không có cuộc gọi `drop_in_place`, mục cuối cùng sẽ không bao giờ bị rơi và bộ nhớ mà nó quản lý sẽ bị rò rỉ.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Đảm bảo rằng mục cuối cùng đã được bỏ.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Lưu ý rằng trình biên dịch thực hiện việc sao chép này tự động khi thả các cấu trúc được đóng gói, tức là, bạn thường không phải lo lắng về các vấn đề như vậy trừ khi bạn gọi `drop_in_place` theo cách thủ công.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Mã ở đây không quan trọng, điều này được thay thế bằng keo thả thực sự bởi trình biên dịch.
    //

    // AN TOÀN: xem bình luận ở trên
    unsafe { drop_in_place(to_drop) }
}

/// Tạo một con trỏ thô rỗng.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Tạo một con trỏ thô có thể thay đổi rỗng.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Cần cấy ghép thủ công để tránh bị ràng buộc `T: Clone`.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Cần cấy ghép thủ công để tránh bị ràng buộc `T: Copy`.
impl<T> Copy for FatPtr<T> {}

/// Tạo thành một lát cắt thô từ một con trỏ và một chiều dài.
///
/// Đối số `len` là số **phần tử**, không phải số byte.
///
/// Hàm này là an toàn, nhưng thực sự sử dụng giá trị trả về là không an toàn.
/// Xem tài liệu của [`slice::from_raw_parts`] để biết các yêu cầu về an toàn lát cắt.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // tạo con trỏ lát cắt khi bắt đầu bằng con trỏ đến phần tử đầu tiên
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // AN TOÀN: Truy cập giá trị từ liên hợp `Repr` là an toàn vì * const [T]
        //
        // và FatPtr có bố cục bộ nhớ giống nhau.Chỉ std mới có thể đảm bảo điều này.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Thực hiện chức năng tương tự như [`slice_from_raw_parts`], ngoại trừ việc một lát có thể thay đổi thô được trả về, trái ngược với một lát không thể thay đổi thô.
///
///
/// Xem tài liệu của [`slice_from_raw_parts`] để biết thêm chi tiết.
///
/// Hàm này là an toàn, nhưng thực sự sử dụng giá trị trả về là không an toàn.
/// Xem tài liệu của [`slice::from_raw_parts_mut`] để biết các yêu cầu về an toàn lát cắt.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // gán một giá trị tại một chỉ mục trong lát
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // AN TOÀN: Truy cập giá trị từ liên hợp `Repr` là an toàn vì * mut [T]
        // và FatPtr có cùng bố cục bộ nhớ
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Hoán đổi các giá trị tại hai vị trí có thể thay đổi của cùng một loại, mà không làm biến dạng.
///
/// Nhưng đối với hai trường hợp ngoại lệ sau, hàm này tương đương về mặt ngữ nghĩa với [`mem::swap`]:
///
///
/// * Nó hoạt động trên con trỏ thô thay vì tham chiếu.
/// Khi có sẵn tài liệu tham khảo, [`mem::swap`] nên được ưu tiên hơn.
///
/// * Hai giá trị trỏ đến có thể trùng nhau.
/// Nếu các giá trị chồng chéo lên nhau thì vùng bộ nhớ chồng chéo từ `x` sẽ được sử dụng.
/// Điều này được chứng minh trong ví dụ thứ hai dưới đây.
///
/// # Safety
///
/// Hành vi là không xác định nếu bất kỳ điều kiện nào sau đây bị vi phạm:
///
/// * Cả `x` và `y` đều phải là [valid] cho cả đọc và ghi.
///
/// * Cả `x` và `y` đều phải được căn chỉnh chính xác.
///
/// Lưu ý rằng ngay cả khi `T` có kích thước `0`, các con trỏ phải không NULL và được căn chỉnh đúng cách.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Hoán đổi hai vùng không chồng chéo:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // đây là `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // đây là `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Hoán đổi hai vùng chồng chéo:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // đây là `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // đây là `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Các chỉ số `1..3` của lát chồng chéo giữa `x` và `y`.
///     // Kết quả hợp lý đối với chúng là `[2, 3]`, do đó các chỉ số `0..3` là `[1, 2, 3]` (khớp với `y` trước `swap`);hoặc để chúng là `[0, 1]` để các chỉ số `1..4` là `[0, 1, 2]` (khớp với `x` trước `swap`).
/////
///     // Việc triển khai này được xác định để đưa ra lựa chọn thứ hai.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Hãy cho chúng tôi một số không gian đầu để làm việc.
    // Chúng tôi không phải lo lắng về việc rơi: `MaybeUninit` không làm gì khi bị rơi.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Thực hiện trao đổi AN TOÀN: người gọi phải đảm bảo rằng `x` và `y` hợp lệ để ghi và căn chỉnh đúng cách.
    // `tmp` không thể chồng chéo `x` hoặc `y` vì `tmp` vừa được cấp phát trên ngăn xếp như một đối tượng được cấp phát riêng biệt.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` và `y` có thể chồng chéo lên nhau
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Hoán đổi các byte `count * size_of::<T>()` giữa hai vùng bộ nhớ bắt đầu từ `x` và `y`.
/// Hai vùng không được * trùng nhau.
///
/// # Safety
///
/// Hành vi là không xác định nếu bất kỳ điều kiện nào sau đây bị vi phạm:
///
/// * Cả `x` và `y` đều phải là [valid] để đọc và ghi `số *
///   size_of: :<T>() `byte.
///
/// * Cả `x` và `y` đều phải được căn chỉnh chính xác.
///
/// * Vùng bộ nhớ bắt đầu từ `x` với kích thước là `số lượng *
///   size_of: :<T>() `byte phải *không* trùng lặp với vùng bộ nhớ bắt đầu từ `y` có cùng kích thước.
///
/// Lưu ý rằng ngay cả khi kích thước được sao chép hiệu quả (`count * size_of: :<T>()`) là `0`, các con trỏ phải không phải là NULL và được căn chỉnh đúng cách.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Cách sử dụng cơ bản:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // AN TOÀN: người gọi phải đảm bảo rằng `x` và `y` là
    // hợp lệ để viết và căn chỉnh đúng cách.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Đối với các loại nhỏ hơn tối ưu hóa khối bên dưới, chỉ cần trao đổi trực tiếp để tránh làm bi quan mã nguồn.
    //
    if mem::size_of::<T>() < 32 {
        // AN TOÀN: người gọi phải đảm bảo rằng `x` và `y` hợp lệ
        // để viết, căn chỉnh đúng và không chồng chéo.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Cách tiếp cận ở đây là sử dụng simd để hoán đổi x&y một cách hiệu quả.
    // Thử nghiệm cho thấy rằng hoán đổi 32 byte hoặc 64 byte cùng một lúc là hiệu quả nhất đối với bộ xử lý Intel Haswell E.
    // LLVM có nhiều khả năng tối ưu hóa hơn nếu chúng tôi cung cấp một cấu trúc là #[repr(simd)], ngay cả khi chúng tôi không thực sự sử dụng cấu trúc này trực tiếp.
    //
    //
    // FIXME repr(simd) bị hỏng trên emscripten và khử oxy hóa
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Lặp qua x&y, sao chép chúng `Block` tại một thời điểm Trình tối ưu hóa sẽ giải nén hoàn toàn vòng lặp đối với hầu hết các loại NB
    // Chúng tôi không thể sử dụng vòng lặp for vì `range` impl gọi `mem::swap` một cách đệ quy
    //
    let mut i = 0;
    while i + block_size <= len {
        // Tạo một số bộ nhớ chưa được khởi tạo làm không gian đầu Khai báo `t` ở đây tránh căn chỉnh ngăn xếp khi vòng lặp này không được sử dụng
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // AN TOÀN: Là `i < len` và với tư cách là người gọi phải đảm bảo rằng `x` và `y` là hợp lệ
        // đối với các byte `len`, `x + i` và `y + i` phải là các địa chỉ hợp lệ đáp ứng hợp đồng an toàn cho `add`.
        //
        // Ngoài ra, người gọi phải đảm bảo rằng `x` và `y` hợp lệ để ghi, căn chỉnh đúng và không chồng chéo, điều này đáp ứng hợp đồng an toàn cho `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Hoán đổi một khối byte x&y, sử dụng t làm bộ đệm tạm thời Điều này sẽ được tối ưu hóa thành các hoạt động SIMD hiệu quả nếu có
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Hoán đổi bất kỳ byte nào còn lại
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // AN TOÀN: xem nhận xét về độ an toàn trước đó.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Di chuyển `src` vào `dst` nhọn, trả về giá trị `dst` trước đó.
///
/// Không có giá trị nào bị giảm.
///
/// Hàm này tương đương về mặt ngữ nghĩa với [`mem::replace`] ngoại trừ việc nó hoạt động trên con trỏ thô thay vì tham chiếu.
/// Khi có sẵn tài liệu tham khảo, [`mem::replace`] nên được ưu tiên hơn.
///
/// # Safety
///
/// Hành vi là không xác định nếu bất kỳ điều kiện nào sau đây bị vi phạm:
///
/// * `dst` phải là [valid] cho cả đọc và ghi.
///
/// * `dst` phải được căn chỉnh phù hợp.
///
/// * `dst` phải trỏ đến một giá trị được khởi tạo đúng kiểu `T`.
///
/// Lưu ý rằng ngay cả khi `T` có kích thước `0`, con trỏ phải không phải là NULL và được căn chỉnh đúng cách.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` sẽ có tác dụng tương tự mà không yêu cầu khối không an toàn.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // AN TOÀN: người gọi phải đảm bảo rằng `dst` hợp lệ để được
    // truyền đến một tham chiếu có thể thay đổi (hợp lệ để ghi, căn chỉnh, khởi tạo) và không thể chồng chéo `src` vì `dst` phải trỏ đến một đối tượng được phân bổ riêng biệt.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // không thể chồng chéo
    }
    src
}

/// Đọc giá trị từ `src` mà không cần di chuyển nó.Điều này khiến bộ nhớ trong `src` không thay đổi.
///
/// # Safety
///
/// Hành vi là không xác định nếu bất kỳ điều kiện nào sau đây bị vi phạm:
///
/// * `src` phải là [valid] cho lần đọc.
///
/// * `src` phải được căn chỉnh phù hợp.Sử dụng [`read_unaligned`] nếu trường hợp này không xảy ra.
///
/// * `src` phải trỏ đến một giá trị được khởi tạo đúng kiểu `T`.
///
/// Lưu ý rằng ngay cả khi `T` có kích thước `0`, con trỏ phải không phải là NULL và được căn chỉnh đúng cách.
///
/// # Examples
///
/// Cách sử dụng cơ bản:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Triển khai thủ công [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Tạo một bản sao bitwise của giá trị tại `a` trong `tmp`.
///         let tmp = ptr::read(a);
///
///         // Việc thoát tại thời điểm này (bằng cách trả về một cách rõ ràng hoặc bằng cách gọi một hàm mà panics) sẽ khiến giá trị trong `tmp` bị giảm xuống trong khi giá trị tương tự vẫn được `a` tham chiếu.
///         // Điều này có thể kích hoạt hành vi không xác định nếu `T` không phải là `Copy`.
/////
/////
///
///         // Tạo một bản sao bitwise của giá trị tại `b` trong `a`.
///         // Điều này là an toàn vì các tham chiếu có thể thay đổi không thể là bí danh.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Như trên, việc thoát ở đây có thể kích hoạt hành vi không xác định vì cùng một giá trị được tham chiếu bởi `a` và `b`.
/////
///
///         // Di chuyển `tmp` thành `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` đã được di chuyển (`write` có quyền sở hữu đối số thứ hai của nó), vì vậy không có gì bị loại bỏ hoàn toàn ở đây.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Quyền sở hữu giá trị trả lại
///
/// `read` tạo một bản sao bitwise của `T`, bất kể `T` có phải là [`Copy`] hay không.
/// Nếu `T` không phải là [`Copy`], việc sử dụng cả giá trị trả về và giá trị tại `*src` có thể vi phạm an toàn bộ nhớ.
/// Lưu ý rằng việc gán cho `*src` được coi là một lần sử dụng vì nó sẽ cố gắng giảm giá trị ở `* src`.
///
/// [`write()`] có thể được sử dụng để ghi đè dữ liệu mà không làm cho nó bị xóa.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` bây giờ trỏ đến cùng một bộ nhớ cơ bản như `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Việc gán cho `s2` sẽ làm giảm giá trị ban đầu của nó.
///     // Sau thời điểm này, `s` không được sử dụng nữa vì bộ nhớ bên dưới đã được giải phóng.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Việc gán cho `s` sẽ khiến giá trị cũ bị giảm xuống một lần nữa, dẫn đến hành vi không xác định.
/////
///     // s= String::from("bar");//LỖI
///
///     // `ptr::write` có thể được sử dụng để ghi đè một giá trị mà không làm giảm giá trị đó.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // AN TOÀN: người gọi phải đảm bảo rằng `src` hợp lệ để đọc.
    // `src` không thể chồng chéo `tmp` vì `tmp` vừa được cấp phát trên ngăn xếp như một đối tượng được cấp phát riêng biệt.
    //
    //
    // Ngoài ra, vì chúng tôi vừa viết một giá trị hợp lệ vào `tmp` nên nó được đảm bảo sẽ được khởi tạo đúng cách.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Đọc giá trị từ `src` mà không cần di chuyển nó.Điều này khiến bộ nhớ trong `src` không thay đổi.
///
/// Không giống như [`read`], `read_unaligned` hoạt động với các con trỏ không liên kết.
///
/// # Safety
///
/// Hành vi là không xác định nếu bất kỳ điều kiện nào sau đây bị vi phạm:
///
/// * `src` phải là [valid] cho lần đọc.
///
/// * `src` phải trỏ đến một giá trị được khởi tạo đúng kiểu `T`.
///
/// Giống như [`read`], `read_unaligned` tạo ra một bản sao bit của `T`, bất kể `T` có phải là [`Copy`] hay không.
/// Nếu `T` không phải là [`Copy`], việc sử dụng cả giá trị trả về và giá trị tại `*src` có thể [violate memory safety][read-ownership].
///
/// Lưu ý rằng ngay cả khi `T` có kích thước `0`, con trỏ phải không phải là NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Trên cấu trúc `packed`
///
/// Hiện tại, không thể tạo các con trỏ thô đến các trường chưa được đánh dấu của một cấu trúc được đóng gói.
///
/// Cố gắng tạo một con trỏ thô cho một trường cấu trúc `unaligned` với một biểu thức chẳng hạn như `&packed.unaligned as *const FieldType` sẽ tạo một tham chiếu không dấu trung gian trước khi chuyển đổi con trỏ đó thành một con trỏ thô.
///
/// Việc tham chiếu này là tạm thời và việc truyền ngay lập tức là không quan trọng vì trình biên dịch luôn mong đợi các tham chiếu được căn chỉnh đúng.
/// Do đó, việc sử dụng `&packed.unaligned as *const FieldType` gây ra ngay lập tức* hành vi không xác định * trong chương trình của bạn.
///
/// Ví dụ về những việc không nên làm và điều này liên quan như thế nào đến `read_unaligned` là:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Ở đây chúng tôi cố gắng lấy địa chỉ của một số nguyên 32 bit không được căn chỉnh.
///     let unaligned =
///         // Tham chiếu tạm thời không được đánh dấu được tạo ở đây dẫn đến hành vi không xác định bất kể tham chiếu đó có được sử dụng hay không.
/////
///         &packed.unaligned
///         // Truyền tới một con trỏ thô không hữu ích;sai lầm đã xảy ra.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Tuy nhiên, việc truy cập trực tiếp vào các trường không được đánh dấu bằng ví dụ `packed.unaligned` là an toàn.
///
///
///
///
///
///
// FIXME: Cập nhật tài liệu dựa trên kết quả của RFC #2582 và bạn bè.
/// # Examples
///
/// Đọc giá trị sử dụng từ bộ đệm byte:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // AN TOÀN: người gọi phải đảm bảo rằng `src` hợp lệ để đọc.
    // `src` không thể chồng chéo `tmp` vì `tmp` vừa được cấp phát trên ngăn xếp như một đối tượng được cấp phát riêng biệt.
    //
    //
    // Ngoài ra, vì chúng tôi vừa viết một giá trị hợp lệ vào `tmp` nên nó được đảm bảo sẽ được khởi tạo đúng cách.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Ghi đè vị trí bộ nhớ với giá trị đã cho mà không đọc hoặc giảm giá trị cũ.
///
/// `write` không làm rơi nội dung của `dst`.
/// Điều này là an toàn, nhưng nó có thể làm rò rỉ các phân bổ hoặc tài nguyên, vì vậy cần cẩn thận để không ghi đè lên một đối tượng sẽ bị loại bỏ.
///
///
/// Ngoài ra, nó không làm rơi `src`.Về mặt ngữ nghĩa, `src` được di chuyển vào vị trí mà `dst` chỉ đến.
///
/// Điều này thích hợp để khởi tạo bộ nhớ chưa khởi tạo hoặc ghi đè bộ nhớ trước đó đã có từ [`read`].
///
/// # Safety
///
/// Hành vi là không xác định nếu bất kỳ điều kiện nào sau đây bị vi phạm:
///
/// * `dst` phải là [valid] để ghi.
///
/// * `dst` phải được căn chỉnh phù hợp.Sử dụng [`write_unaligned`] nếu trường hợp này không xảy ra.
///
/// Lưu ý rằng ngay cả khi `T` có kích thước `0`, con trỏ phải không phải là NULL và được căn chỉnh đúng cách.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Cách sử dụng cơ bản:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Triển khai thủ công [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Tạo một bản sao bitwise của giá trị tại `a` trong `tmp`.
///         let tmp = ptr::read(a);
///
///         // Việc thoát tại thời điểm này (bằng cách trả về một cách rõ ràng hoặc bằng cách gọi một hàm mà panics) sẽ khiến giá trị trong `tmp` bị giảm xuống trong khi giá trị tương tự vẫn được `a` tham chiếu.
///         // Điều này có thể kích hoạt hành vi không xác định nếu `T` không phải là `Copy`.
/////
/////
///
///         // Tạo một bản sao bitwise của giá trị tại `b` trong `a`.
///         // Điều này là an toàn vì các tham chiếu có thể thay đổi không thể là bí danh.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Như trên, việc thoát ở đây có thể kích hoạt hành vi không xác định vì cùng một giá trị được tham chiếu bởi `a` và `b`.
/////
///
///         // Di chuyển `tmp` thành `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` đã được di chuyển (`write` có quyền sở hữu đối số thứ hai của nó), vì vậy không có gì bị loại bỏ hoàn toàn ở đây.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Chúng tôi đang gọi trực tiếp nội hàm để tránh các lệnh gọi hàm trong mã được tạo vì `intrinsics::copy_nonoverlapping` là một hàm trình bao bọc.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // AN TOÀN: người gọi phải đảm bảo rằng `dst` hợp lệ để ghi.
    // `dst` không thể chồng chéo `src` vì người gọi có quyền truy cập có thể thay đổi đến `dst` trong khi `src` thuộc sở hữu của chức năng này.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Ghi đè vị trí bộ nhớ với giá trị đã cho mà không đọc hoặc giảm giá trị cũ.
///
/// Không giống như [`write()`], con trỏ có thể bị lệch.
///
/// `write_unaligned` không làm rơi nội dung của `dst`.Điều này là an toàn, nhưng nó có thể làm rò rỉ các phân bổ hoặc tài nguyên, vì vậy cần cẩn thận để không ghi đè lên một đối tượng sẽ bị loại bỏ.
///
/// Ngoài ra, nó không làm rơi `src`.Về mặt ngữ nghĩa, `src` được di chuyển vào vị trí mà `dst` chỉ đến.
///
/// Điều này thích hợp để khởi tạo bộ nhớ chưa khởi tạo hoặc ghi đè bộ nhớ đã được đọc trước đó với [`read_unaligned`].
///
/// # Safety
///
/// Hành vi là không xác định nếu bất kỳ điều kiện nào sau đây bị vi phạm:
///
/// * `dst` phải là [valid] để ghi.
///
/// Lưu ý rằng ngay cả khi `T` có kích thước `0`, con trỏ phải không phải là NULL.
///
/// [valid]: self#safety
///
/// ## Trên cấu trúc `packed`
///
/// Hiện tại, không thể tạo các con trỏ thô đến các trường chưa được đánh dấu của một cấu trúc được đóng gói.
///
/// Cố gắng tạo một con trỏ thô cho một trường cấu trúc `unaligned` với một biểu thức chẳng hạn như `&packed.unaligned as *const FieldType` sẽ tạo một tham chiếu không dấu trung gian trước khi chuyển đổi con trỏ đó thành một con trỏ thô.
///
/// Việc tham chiếu này là tạm thời và việc truyền ngay lập tức là không quan trọng vì trình biên dịch luôn mong đợi các tham chiếu được căn chỉnh đúng.
/// Do đó, việc sử dụng `&packed.unaligned as *const FieldType` gây ra ngay lập tức* hành vi không xác định * trong chương trình của bạn.
///
/// Ví dụ về những việc không nên làm và điều này liên quan như thế nào đến `write_unaligned` là:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Ở đây chúng tôi cố gắng lấy địa chỉ của một số nguyên 32 bit không được căn chỉnh.
///     let unaligned =
///         // Tham chiếu tạm thời không được đánh dấu được tạo ở đây dẫn đến hành vi không xác định bất kể tham chiếu đó có được sử dụng hay không.
/////
///         &mut packed.unaligned
///         // Truyền tới một con trỏ thô không hữu ích;sai lầm đã xảy ra.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Tuy nhiên, việc truy cập trực tiếp vào các trường không được đánh dấu bằng ví dụ `packed.unaligned` là an toàn.
///
///
///
///
///
///
///
///
///
// FIXME: Cập nhật tài liệu dựa trên kết quả của RFC #2582 và bạn bè.
/// # Examples
///
/// Ghi giá trị sử dụng vào bộ đệm byte:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // AN TOÀN: người gọi phải đảm bảo rằng `dst` hợp lệ để ghi.
    // `dst` không thể chồng chéo `src` vì người gọi có quyền truy cập có thể thay đổi đến `dst` trong khi `src` thuộc sở hữu của chức năng này.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Chúng tôi đang gọi nội tại trực tiếp để tránh các lệnh gọi hàm trong mã được tạo.
        intrinsics::forget(src);
    }
}

/// Thực hiện đọc giá trị không ổn định từ `src` mà không cần di chuyển nó.Điều này khiến bộ nhớ trong `src` không thay đổi.
///
/// Các hoạt động dễ bay hơi nhằm mục đích hoạt động trên bộ nhớ I/O và được đảm bảo không bị trình biên dịch giải thích hoặc sắp xếp lại thứ tự qua các hoạt động dễ bay hơi khác.
///
/// # Notes
///
/// Rust hiện không có mô hình bộ nhớ được xác định chính thức và chặt chẽ, vì vậy ngữ nghĩa chính xác của ý nghĩa "volatile" ở đây có thể thay đổi theo thời gian.
/// Điều đó đang được nói, ngữ nghĩa hầu như sẽ luôn luôn kết thúc khá giống với [C11's definition of volatile][c11].
///
/// Trình biên dịch không nên thay đổi thứ tự tương đối hoặc số lượng các hoạt động bộ nhớ dễ bay hơi.
/// Tuy nhiên, các thao tác trong bộ nhớ dễ bay hơi trên các kiểu có kích thước bằng không (ví dụ: nếu kiểu có kích thước bằng 0 được chuyển cho `read_volatile`) là không có kết quả và có thể bị bỏ qua.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Hành vi là không xác định nếu bất kỳ điều kiện nào sau đây bị vi phạm:
///
/// * `src` phải là [valid] cho lần đọc.
///
/// * `src` phải được căn chỉnh phù hợp.
///
/// * `src` phải trỏ đến một giá trị được khởi tạo đúng kiểu `T`.
///
/// Giống như [`read`], `read_volatile` tạo ra một bản sao bit của `T`, bất kể `T` có phải là [`Copy`] hay không.
/// Nếu `T` không phải là [`Copy`], việc sử dụng cả giá trị trả về và giá trị tại `*src` có thể [violate memory safety][read-ownership].
/// Tuy nhiên, việc lưu trữ các loại không phải [``Copy`] trong bộ nhớ dễ bay hơi gần như chắc chắn là không chính xác.
///
/// Lưu ý rằng ngay cả khi `T` có kích thước `0`, con trỏ phải không phải là NULL và được căn chỉnh đúng cách.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Cũng giống như trong C, liệu một hoạt động có dễ bay hơi hay không không liên quan đến các câu hỏi liên quan đến truy cập đồng thời từ nhiều luồng.Các truy cập bay hơi hoạt động giống hệt như các truy cập phi nguyên tử về mặt đó.
///
/// Đặc biệt, một cuộc chạy đua giữa `read_volatile` và bất kỳ thao tác ghi nào vào cùng một vị trí là hành vi không xác định.
///
/// # Examples
///
/// Cách sử dụng cơ bản:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Không hoảng sợ để giữ cho tác động của codegen nhỏ hơn.
        abort();
    }
    // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Thực hiện ghi biến động vị trí bộ nhớ với giá trị đã cho mà không đọc hoặc giảm giá trị cũ.
///
/// Các hoạt động dễ bay hơi nhằm mục đích hoạt động trên bộ nhớ I/O và được đảm bảo không bị trình biên dịch giải thích hoặc sắp xếp lại thứ tự qua các hoạt động dễ bay hơi khác.
///
/// `write_volatile` không làm rơi nội dung của `dst`.Điều này là an toàn, nhưng nó có thể làm rò rỉ các phân bổ hoặc tài nguyên, vì vậy cần cẩn thận để không ghi đè lên một đối tượng sẽ bị loại bỏ.
///
/// Ngoài ra, nó không làm rơi `src`.Về mặt ngữ nghĩa, `src` được di chuyển vào vị trí mà `dst` chỉ đến.
///
/// # Notes
///
/// Rust hiện không có mô hình bộ nhớ được xác định chính thức và chặt chẽ, vì vậy ngữ nghĩa chính xác của ý nghĩa "volatile" ở đây có thể thay đổi theo thời gian.
/// Điều đó đang được nói, ngữ nghĩa hầu như sẽ luôn luôn kết thúc khá giống với [C11's definition of volatile][c11].
///
/// Trình biên dịch không nên thay đổi thứ tự tương đối hoặc số lượng các hoạt động bộ nhớ dễ bay hơi.
/// Tuy nhiên, các thao tác trong bộ nhớ dễ bay hơi trên các kiểu có kích thước bằng không (ví dụ: nếu kiểu có kích thước bằng 0 được chuyển cho `write_volatile`) là không có kết quả và có thể bị bỏ qua.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Hành vi là không xác định nếu bất kỳ điều kiện nào sau đây bị vi phạm:
///
/// * `dst` phải là [valid] để ghi.
///
/// * `dst` phải được căn chỉnh phù hợp.
///
/// Lưu ý rằng ngay cả khi `T` có kích thước `0`, con trỏ phải không phải là NULL và được căn chỉnh đúng cách.
///
/// [valid]: self#safety
///
/// Cũng giống như trong C, liệu một hoạt động có dễ bay hơi hay không không liên quan đến các câu hỏi liên quan đến truy cập đồng thời từ nhiều luồng.Các truy cập bay hơi hoạt động giống hệt như các truy cập phi nguyên tử về mặt đó.
///
/// Đặc biệt, một cuộc chạy đua giữa `write_volatile` và bất kỳ hoạt động nào khác (đọc hoặc ghi) trên cùng một vị trí là hành vi không xác định.
///
/// # Examples
///
/// Cách sử dụng cơ bản:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Không hoảng sợ để giữ cho tác động của codegen nhỏ hơn.
        abort();
    }
    // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Căn chỉnh con trỏ `p`.
///
/// Tính toán độ lệch (theo các phần tử của sải chân `stride`) phải được áp dụng cho con trỏ `p` để con trỏ `p` sẽ được căn chỉnh với `a`.
///
/// Note: Việc triển khai này đã được điều chỉnh cẩn thận để không phải panic.Nó là UB cho điều này đến panic.
/// Thay đổi thực sự duy nhất có thể được thực hiện ở đây là thay đổi `INV_TABLE_MOD_16` và các hằng số liên quan.
///
/// Nếu chúng ta quyết định có thể gọi nội tại của `a` không phải là sức mạnh của hai, có lẽ sẽ thận trọng hơn nếu chỉ chuyển sang một triển khai ngây thơ hơn là cố gắng điều chỉnh điều này để thích ứng với sự thay đổi đó.
///
///
/// Mọi thắc mắc xin truy cập@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Việc sử dụng trực tiếp các nội dung này cải thiện đáng kể mã nguồn ở cấp độ lựa chọn <=
    // 1, trong đó các phiên bản phương thức của các hoạt động này không được nội tuyến.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Tính nghịch đảo mô-đun nhân của mô-đun `x` `m`.
    ///
    /// Việc triển khai này được thiết kế riêng cho `align_offset` và có các điều kiện tiên quyết sau:
    ///
    /// * `m` là lũy thừa của hai;
    /// * `x < m`; (nếu `x ≥ m`, hãy chuyển vào `x % m` để thay thế)
    ///
    /// Việc thực hiện chức năng này không được panic.Không bao giờ.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Bảng nghịch đảo môđun nhân môđun 2⁴=16.
        ///
        /// Lưu ý rằng bảng này không chứa các giá trị mà nghịch đảo không tồn tại (ví dụ: đối với `0⁻¹ mod 16`, `2⁻¹ mod 16`, v.v.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo dành cho `INV_TABLE_MOD_16`.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // AN TOÀN: `m` được yêu cầu là lũy thừa của hai, do đó khác 0.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Chúng tôi lặp lại "up" bằng công thức sau:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // cho đến khi 2²ⁿ ≥ m.Sau đó, chúng tôi có thể giảm xuống `m` mong muốn của chúng tôi bằng cách lấy kết quả `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Lưu ý rằng chúng tôi sử dụng các phép toán gói ở đây một cách có chủ ý-công thức gốc sử dụng ví dụ: phép trừ `mod n`.
                // Thay vào đó, thực hiện chúng là `mod usize::MAX` là hoàn toàn tốt, vì dù sao chúng ta cũng lấy kết quả `mod n` ở cuối.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // AN TOÀN: `a` là lũy thừa của hai, do đó khác 0.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` case có thể được tính toán đơn giản hơn thông qua `-p (mod a)`, nhưng làm như vậy sẽ hạn chế khả năng chọn lệnh của LLVM như `lea`.Thay vào đó chúng tôi tính toán
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // phân phối các hoạt động xung quanh ổ đỡ tải, nhưng xử lý `and` đủ để LLVM có thể sử dụng các tối ưu hóa khác nhau mà nó biết.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Đã được căn chỉnh.Yay!
        return 0;
    } else if stride == 0 {
        // Nếu con trỏ không được căn chỉnh và phần tử có kích thước bằng 0, thì không có lượng phần tử nào sẽ căn chỉnh con trỏ.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // AN TOÀN: a là lũy thừa của hai do đó khác không.sải bước==0 trường hợp được xử lý ở trên.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // AN TOÀN: gcdpow có giới hạn trên tối đa là số bit trong một kích thước.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // AN TOÀN: gcd luôn lớn hơn hoặc bằng 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // branch này giải cho phương trình đồng dư tuyến tính sau:
        //
        // ` p + so = 0 mod a `
        //
        // `p` đây là giá trị con trỏ, `s`, sải chân của `T`, độ lệch `o` trong `T`s và `a`, căn chỉnh được yêu cầu.
        //
        // Với `g = gcd(a, s)`, và điều kiện trên khẳng định rằng `p` cũng chia hết cho `g`, chúng ta có thể ký hiệu `a' = a/g`, `s' = s/g`, `p' = p/g`, khi đó điều này tương đương với:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Số hạng đầu tiên là "the relative alignment of `p` to `a`" (chia cho `g`), số hạng thứ hai là "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (lại chia cho `g`).
        //
        // Phép chia cho `g` là cần thiết để tạo ra nghịch đảo nếu `a` và `s` không phải là đồng nguyên tố.
        //
        // Hơn nữa, kết quả tạo ra bởi dung dịch này không phải là "minimal", vì vậy cần phải lấy kết quả `o mod lcm(s, a)`.Chúng tôi có thể thay thế `lcm(s, a)` chỉ bằng `a'`.
        //
        //
        //
        //
        //

        // AN TOÀN: `gcdpow` có giới hạn trên không lớn hơn số bit 0 theo sau trong `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // AN TOÀN: `a2` khác 0.Dịch chuyển `a` bởi `gcdpow` không thể thay đổi bất kỳ bit nào trong số các bit đã đặt
        // trong `a` (trong đó nó có chính xác một).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // AN TOÀN: `gcdpow` có giới hạn trên không lớn hơn số bit 0 theo sau trong `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // AN TOÀN: `gcdpow` có giới hạn trên không lớn hơn số bit 0 ở cuối
        // `a`.
        // Hơn nữa, phép trừ không thể tràn, vì `a2 = a >> gcdpow` sẽ luôn lớn hơn `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // AN TOÀN: `a2` là sức mạnh của hai, như đã được chứng minh ở trên.`s2` hoàn toàn nhỏ hơn `a2`
        // bởi vì `(s % a) >> gcdpow` hoàn toàn nhỏ hơn `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Không thể được căn chỉnh ở tất cả.
    usize::MAX
}

/// So sánh các con trỏ thô cho bằng nhau.
///
/// Điều này cũng giống như sử dụng toán tử `==`, nhưng ít chung chung hơn:
/// các đối số phải là con trỏ thô `*const T`, không phải bất kỳ thứ gì triển khai `PartialEq`.
///
/// Điều này có thể được sử dụng để so sánh các tham chiếu `&T` (bắt buộc ngầm định với `*const T`) theo địa chỉ của chúng thay vì so sánh các giá trị mà chúng trỏ tới (đó là những gì triển khai `PartialEq for &T` thực hiện).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Các lát cũng được so sánh theo chiều dài của chúng (con trỏ béo):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits cũng được so sánh bằng cách triển khai của chúng:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Các con trỏ có địa chỉ bằng nhau.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Các đối tượng có địa chỉ bằng nhau, nhưng `Trait` có các cách triển khai khác nhau.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Việc chuyển đổi tham chiếu sang `*const u8` sẽ so sánh theo địa chỉ.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Băm một con trỏ thô.
///
/// Điều này có thể được sử dụng để băm một tham chiếu `&T` (bắt buộc ngầm định với `*const T`) theo địa chỉ của nó thay vì giá trị mà nó trỏ đến (đó là những gì triển khai `Hash for &T` thực hiện).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impls cho con trỏ hàm
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Diễn viên trung gian theo kích thước là bắt buộc đối với AVR
                // để không gian địa chỉ của con trỏ hàm nguồn được bảo toàn trong con trỏ hàm cuối cùng.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Diễn viên trung gian theo kích thước là bắt buộc đối với AVR
                // để không gian địa chỉ của con trỏ hàm nguồn được bảo toàn trong con trỏ hàm cuối cùng.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Không có hàm khác nhau với 0 tham số
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Tạo con trỏ thô `const` đến một địa điểm mà không cần tạo tham chiếu trung gian.
///
/// Việc tạo tham chiếu với `&`/`&mut` chỉ được phép nếu con trỏ được căn chỉnh đúng cách và trỏ đến dữ liệu đã khởi tạo.
/// Đối với những trường hợp không giữ được những yêu cầu đó, thì nên sử dụng con trỏ thô để thay thế.
/// Tuy nhiên, `&expr as *const _` tạo một tham chiếu trước khi truyền nó tới một con trỏ thô và tham chiếu đó phải tuân theo các quy tắc giống như tất cả các tham chiếu khác.
///
/// Macro này có thể tạo một con trỏ thô *mà không cần* tạo tham chiếu trước.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` sẽ tạo ra một tham chiếu không được đánh dấu và do đó là Hành vi không xác định!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Tạo con trỏ thô `mut` đến một địa điểm mà không cần tạo tham chiếu trung gian.
///
/// Việc tạo tham chiếu với `&`/`&mut` chỉ được phép nếu con trỏ được căn chỉnh đúng cách và trỏ đến dữ liệu đã khởi tạo.
/// Đối với những trường hợp không giữ được những yêu cầu đó, thì nên sử dụng con trỏ thô để thay thế.
/// Tuy nhiên, `&mut expr as *mut _` tạo một tham chiếu trước khi truyền nó tới một con trỏ thô và tham chiếu đó phải tuân theo các quy tắc giống như tất cả các tham chiếu khác.
///
/// Macro này có thể tạo một con trỏ thô *mà không cần* tạo tham chiếu trước.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` sẽ tạo ra một tham chiếu không được đánh dấu và do đó là Hành vi không xác định!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` buộc sao chép trường thay vì tạo tham chiếu.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}