#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Cung cấp loại siêu dữ liệu con trỏ của bất kỳ loại trỏ tới nào.
///
/// # Siêu dữ liệu con trỏ
///
/// Các loại con trỏ thô và các loại tham chiếu trong Rust có thể được coi là được làm bằng hai phần:
/// một con trỏ dữ liệu chứa địa chỉ bộ nhớ của giá trị và một số siêu dữ liệu.
///
/// Đối với các loại có kích thước tĩnh (triển khai `Sized` traits) cũng như đối với các loại `extern`, con trỏ được cho là `mỏng`: siêu dữ liệu có kích thước bằng 0 và loại của nó là `()`.
///
///
/// Con trỏ tới [dynamically-sized types][dst] được cho là "rộng" hoặc "béo", chúng có siêu dữ liệu có kích thước khác 0:
///
/// * Đối với cấu trúc có trường cuối cùng là DST, siêu dữ liệu là siêu dữ liệu cho trường cuối cùng
/// * Đối với loại `str`, siêu dữ liệu là độ dài tính bằng byte là `usize`
/// * Đối với các loại lát cắt như `[T]`, siêu dữ liệu là độ dài trong các mục dưới dạng `usize`
/// * Đối với các đối tượng trait như `dyn SomeTrait`, siêu dữ liệu là [`DynMetadata<Self>`][DynMetadata] (ví dụ: `DynMetadata<dyn SomeTrait>`)
///
/// Trong future, ngôn ngữ Rust có thể đạt được các loại kiểu mới có siêu dữ liệu con trỏ khác nhau.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Điểm của trait này là loại liên kết `Metadata` của nó, đó là `()` hoặc `usize` hoặc `DynMetadata<_>` như mô tả ở trên.
/// Nó được thực hiện tự động cho mọi loại.
/// Nó có thể được giả định là được triển khai trong bối cảnh chung, ngay cả khi không có ràng buộc tương ứng.
///
/// # Usage
///
/// Con trỏ thô có thể được phân tách thành địa chỉ dữ liệu và các thành phần siêu dữ liệu bằng phương thức [`to_raw_parts`] của chúng.
///
/// Ngoài ra, một mình siêu dữ liệu có thể được trích xuất bằng chức năng [`metadata`].
/// Một tham chiếu có thể được chuyển tới [`metadata`] và bị ép buộc hoàn toàn.
///
/// Con trỏ (possibly-wide) có thể được đặt lại với nhau từ địa chỉ và siêu dữ liệu của nó với [`from_raw_parts`] hoặc [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Loại cho siêu dữ liệu trong con trỏ và tham chiếu đến `Self`.
    #[lang = "metadata_type"]
    // NOTE: Giữ trait bounds trong `static_assert_expected_bounds_for_metadata`
    //
    // trong `library/core/src/ptr/metadata.rs` đồng bộ với những người ở đây:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Con trỏ đến các loại triển khai bí danh trait này là "mỏng".
///
/// Điều này bao gồm các loại statically-`Size` và các loại `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: không ổn định điều này trước khi bí danh trait ổn định trong ngôn ngữ?
pub trait Thin = Pointee<Metadata = ()>;

/// Trích xuất thành phần siêu dữ liệu của một con trỏ.
///
/// Các giá trị kiểu `*mut T`, `&T` hoặc `&mut T` có thể được chuyển trực tiếp đến hàm này vì chúng bắt buộc ngầm định với `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // AN TOÀN: Truy cập giá trị từ liên hợp `PtrRepr` là an toàn vì * const T
    // và PtrComponents<T>có bố cục bộ nhớ giống nhau.
    // Chỉ std mới có thể đảm bảo điều này.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Tạo con trỏ thô (possibly-wide) từ địa chỉ dữ liệu và siêu dữ liệu.
///
/// Chức năng này an toàn nhưng con trỏ trả về không nhất thiết phải an toàn để bỏ qua.
/// Đối với các lát cắt, hãy xem tài liệu của [`slice::from_raw_parts`] để biết các yêu cầu an toàn.
/// Đối với các đối tượng trait, siêu dữ liệu phải đến từ một con trỏ đến cùng một loại được dựng sẵn bên dưới.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // AN TOÀN: Truy cập giá trị từ liên hợp `PtrRepr` là an toàn vì * const T
    // và PtrComponents<T>có bố cục bộ nhớ giống nhau.
    // Chỉ std mới có thể đảm bảo điều này.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Thực hiện chức năng tương tự như [`from_raw_parts`], ngoại trừ việc con trỏ `*mut` thô được trả về, trái ngược với con trỏ `* const` thô.
///
///
/// Xem tài liệu của [`from_raw_parts`] để biết thêm chi tiết.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // AN TOÀN: Truy cập giá trị từ liên hợp `PtrRepr` là an toàn vì * const T
    // và PtrComponents<T>có bố cục bộ nhớ giống nhau.
    // Chỉ std mới có thể đảm bảo điều này.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Cần cấy ghép thủ công để tránh bị ràng buộc `T: Copy`.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Cần cấy ghép thủ công để tránh bị ràng buộc `T: Clone`.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Siêu dữ liệu cho loại đối tượng `Dyn = dyn SomeTrait` trait.
///
/// Nó là một con trỏ tới một vtable (bảng gọi ảo) đại diện cho tất cả các thông tin cần thiết để thao tác với kiểu cụ thể được lưu trữ bên trong một đối tượng trait.
/// Vtable đáng chú ý là nó chứa:
///
/// * Loại kích thước
/// * loại căn chỉnh
/// * một con trỏ đến mô hình `drop_in_place` của loại (có thể không phù hợp với dữ liệu cũ thuần túy)
/// * con trỏ đến tất cả các phương thức để triển khai kiểu của trait
///
/// Lưu ý rằng ba cái đầu tiên là đặc biệt vì chúng cần thiết để phân bổ, loại bỏ và phân bổ bất kỳ đối tượng trait nào.
///
/// Có thể đặt tên cho cấu trúc này với tham số kiểu không phải là đối tượng `dyn` trait (ví dụ `DynMetadata<u64>`) nhưng không nhận được giá trị có nghĩa của cấu trúc đó.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Tiền tố chung của tất cả các vtables.Tiếp theo là con trỏ hàm cho các phương thức trait.
///
/// Chi tiết triển khai riêng của `DynMetadata::size_of`, v.v.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Trả về kích thước của kiểu được liên kết với vtable này.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Trả về căn chỉnh của kiểu được liên kết với vtable này.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Trả về kích thước và sự liên kết với nhau dưới dạng `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // AN TOÀN: trình biên dịch đã phát ra vtable này cho loại Rust bê tông
        // được biết là có bố cục hợp lệ.Cơ sở lý luận tương tự như trong `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Cần có số lần nhập thủ công để tránh giới hạn `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}