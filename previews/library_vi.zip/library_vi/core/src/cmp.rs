//! Chức năng đặt hàng và so sánh.
//!
//! Mô-đun này chứa các công cụ khác nhau để sắp xếp và so sánh các giá trị.Tóm tắt:
//!
//! * [`Eq`] và [`PartialEq`] là traits cho phép bạn xác định bình đẳng tổng và từng phần giữa các giá trị tương ứng.
//! Việc triển khai chúng sẽ làm quá tải các toán tử `==` và `!=`.
//! * [`Ord`] và [`PartialOrd`] là traits cho phép bạn xác định tổng số và một phần các giá trị tương ứng.
//!
//! Việc triển khai chúng sẽ làm quá tải các toán tử `<`, `<=`, `>` và `>=`.
//! * [`Ordering`] là một enum được trả về bởi các chức năng chính của [`Ord`] và [`PartialOrd`], và mô tả một thứ tự.
//! * [`Reverse`] là một cấu trúc cho phép bạn dễ dàng đảo ngược thứ tự.
//! * [`max`] và [`min`] là các hàm được xây dựng dựa trên [`Ord`] và cho phép bạn tìm giá trị tối đa hoặc tối thiểu của hai giá trị.
//!
//! Để biết thêm chi tiết, hãy xem tài liệu tương ứng của từng mục trong danh sách.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait để so sánh bình đẳng là [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation).
///
/// trait này cho phép bình đẳng từng phần, đối với các loại không có quan hệ tương đương đầy đủ.
/// Ví dụ: trong số dấu phẩy động `NaN != NaN`, do đó, các kiểu dấu phẩy động thực hiện `PartialEq` nhưng không phải [`trait@Eq`].
///
/// Về mặt hình thức, bình đẳng phải là (đối với tất cả `a`, `b`, `c` thuộc loại `A`, `B`, `C`):
///
/// - **Đối xứng**: if `A: PartialEq<B>` và `B: PartialEq<A>`, then **`a==b` ngụ ý`b==a`**;và
///
/// - **Transitive**: if `A: PartialEq<B>` and `B: PartialEq<C>` and `A:
///   PartialEq<C>`, thì **` a==b`và `b == c` ngụ ý`a==c`**.
///
/// Lưu ý rằng các xung `B: PartialEq<A>` (symmetric) và `A: PartialEq<C>` (transitive) không bị buộc phải tồn tại, nhưng các yêu cầu này được áp dụng bất cứ khi nào chúng tồn tại.
///
/// ## Derivable
///
/// trait này có thể được sử dụng với `#[derive]`.Khi `dẫn xuất`d trên các cấu trúc, hai trường hợp bằng nhau nếu tất cả các trường đều bằng nhau và không bằng nhau nếu bất kỳ trường nào không bằng nhau.Khi `dẫn xuất`d trên enums, mỗi biến thể bằng chính nó và không bằng các biến thể khác.
///
/// ## Làm cách nào để triển khai `PartialEq`?
///
/// `PartialEq` chỉ yêu cầu phương thức [`eq`] được thực hiện;[`ne`] được định nghĩa về nó theo mặc định.Bất kỳ quá trình triển khai thủ công nào đối với [`ne`]*phải* tôn trọng quy tắc rằng [`eq`] là một nghịch đảo nghiêm ngặt của [`ne`];nghĩa là `!(a == b)` nếu và chỉ khi `a != b`.
///
/// Việc triển khai `PartialEq`, [`PartialOrd`] và [`Ord`]*phải* đồng ý với nhau.Rất dễ vô tình làm cho họ không đồng ý bằng cách lấy một số traits và thực hiện theo cách thủ công những người khác.
///
/// Triển khai ví dụ cho miền trong đó hai cuốn sách được coi là cùng một cuốn sách nếu ISBN của chúng khớp nhau, ngay cả khi các định dạng khác nhau:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Làm thế nào tôi có thể so sánh hai loại khác nhau?
///
/// Kiểu mà bạn có thể so sánh được kiểm soát bởi tham số kiểu của `PartialEq`.
/// Ví dụ: hãy chỉnh sửa mã trước đó của chúng ta một chút:
///
/// ```
/// // Các triển khai dẫn xuất<BookFormat>==<BookFormat>sự so sánh
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Triển khai thực hiện<Book>==<BookFormat>sự so sánh
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Triển khai thực hiện<BookFormat>==<Book>sự so sánh
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// Bằng cách thay đổi `impl PartialEq for Book` thành `impl PartialEq<BookFormat> for Book`, chúng tôi cho phép so sánh `BookFormat`s với`Book`s.
///
/// So sánh như trên, bỏ qua một số trường của cấu trúc, có thể nguy hiểm.Nó có thể dễ dàng dẫn đến sự vi phạm ngoài ý muốn đối với các yêu cầu đối với quan hệ tương đương một phần.
/// Ví dụ: nếu chúng tôi giữ nguyên triển khai `PartialEq<Book>` cho `BookFormat` ở trên và thêm một triển khai `PartialEq<Book>` cho `Book` (thông qua `#[derive]` hoặc thông qua triển khai thủ công từ ví dụ đầu tiên) thì kết quả sẽ vi phạm độ nhạy:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Phương pháp này kiểm tra các giá trị `self` và `other` bằng nhau và được sử dụng bởi `==`.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Phương pháp này kiểm tra `!=`.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// Derive macro tạo ra một impl của trait `PartialEq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait để so sánh bình đẳng là [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation).
///
/// Điều này có nghĩa là ngoài `a == b` và `a != b` là các nghịch đảo nghiêm ngặt, thì sự bình đẳng phải là (đối với tất cả `a`, `b` và `c`):
///
/// - reflexive: `a == a`;
/// - đối xứng: `a == b` ngụ ý `b == a`;và
/// - bắc cầu: `a == b` và `b == c` ngụ ý `a == c`.
///
/// Thuộc tính này không thể được trình biên dịch kiểm tra và do đó `Eq` ngụ ý [`PartialEq`] và không có phương thức bổ sung nào.
///
/// ## Derivable
///
/// trait này có thể được sử dụng với `#[derive]`.
/// Khi `dẫn xuất`d, vì `Eq` không có các phương thức bổ sung, nó chỉ thông báo cho trình biên dịch rằng đây là một quan hệ tương đương chứ không phải là một quan hệ tương đương một phần.
///
/// Lưu ý rằng chiến lược `derive` yêu cầu tất cả các trường là `Eq`, điều này không phải lúc nào cũng mong muốn.
///
/// ## Làm cách nào để triển khai `Eq`?
///
/// Nếu bạn không thể sử dụng chiến lược `derive`, hãy chỉ định rằng kiểu của bạn triển khai `Eq`, không có phương pháp nào:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // phương pháp này chỉ được sử dụng bởi#[dẫn xuất] để khẳng định rằng mọi thành phần của kiểu thực hiện chính#[dẫn xuất], cơ sở hạ tầng dẫn xuất hiện tại có nghĩa là thực hiện khẳng định này mà không sử dụng phương thức trên trait này là gần như không thể.
    //
    //
    // Điều này không bao giờ nên được thực hiện bằng tay.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Derive macro tạo ra một impl của trait `Eq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: cấu trúc này chỉ được sử dụng bởi#[obsve] để
// khẳng định rằng mọi thành phần của một kiểu thực hiện Eq.
//
// Cấu trúc này không bao giờ được xuất hiện trong mã người dùng.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Ordering` là kết quả của sự so sánh giữa hai giá trị.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// Một thứ tự trong đó một giá trị được so sánh nhỏ hơn một giá trị khác.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// Một thứ tự trong đó một giá trị được so sánh bằng một giá trị khác.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// Một thứ tự trong đó một giá trị được so sánh lớn hơn một giá trị khác.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Trả về `true` nếu đơn đặt hàng là biến thể `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Trả về `true` nếu đơn đặt hàng không phải là biến thể `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Trả về `true` nếu đơn đặt hàng là biến thể `Less`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Trả về `true` nếu đơn đặt hàng là biến thể `Greater`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Trả về `true` nếu thứ tự là biến thể `Less` hoặc `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Trả về `true` nếu thứ tự là biến thể `Greater` hoặc `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// Đảo ngược `Ordering`.
    ///
    /// * `Less` trở thành `Greater`.
    /// * `Greater` trở thành `Less`.
    /// * `Equal` trở thành `Equal`.
    ///
    /// # Examples
    ///
    /// Hành vi cơ bản:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Phương pháp này có thể được sử dụng để đảo ngược so sánh:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // sắp xếp mảng từ lớn nhất đến nhỏ nhất.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Chuỗi hai thử thách.
    ///
    /// Trả về `self` khi nó không phải là `Equal`.Nếu không, trả về `other`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Chuỗi thứ tự với chức năng đã cho.
    ///
    /// Trả về `self` khi nó không phải là `Equal`.
    /// Nếu không, gọi `f` và trả về kết quả.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// Một cấu trúc trợ giúp để sắp xếp ngược lại.
///
/// Cấu trúc này là một trình trợ giúp được sử dụng với các chức năng như [`Vec::sort_by_key`] và có thể được sử dụng để đảo ngược thứ tự một phần của khóa.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait cho các loại tạo thành [total order](https://en.wikipedia.org/wiki/Total_order).
///
/// Một đơn đặt hàng là tổng đơn đặt hàng nếu nó là (cho tất cả `a`, `b` và `c`):
///
/// - tổng và không đối xứng: đúng một trong các `a < b`, `a == b` hoặc `a > b`;và
/// - bắc cầu, `a < b` và `b < c` ngụ ý `a < c`.Điều tương tự phải giữ cho cả `==` và `>`.
///
/// ## Derivable
///
/// trait này có thể được sử dụng với `#[derive]`.
/// Khi `dẫn xuất`d trên struct, nó sẽ tạo ra một thứ tự [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) dựa trên thứ tự khai báo từ trên xuống dưới của các thành viên của struct.
///
/// Khi `dẫn xuất`d trên enums, các biến thể được sắp xếp theo thứ tự phân biệt từ trên xuống dưới của chúng.
///
/// ## So sánh từ vựng
///
/// So sánh từ vựng là một phép toán với các thuộc tính sau:
///  - Hai chuỗi được so sánh từng phần tử.
///  - Phần tử không khớp đầu tiên xác định trình tự nào nhỏ hơn hoặc lớn hơn về mặt từ vựng so với chuỗi kia.
///  - Nếu một trình tự là tiền tố của trình tự khác, thì trình tự ngắn hơn sẽ ít hơn về mặt từ vựng so với trình tự kia.
///  - Nếu hai dãy có các phần tử tương đương và có cùng độ dài, thì các dãy đó bằng nhau về mặt từ vựng.
///  - Một chuỗi trống về mặt từ vựng ít hơn bất kỳ chuỗi không trống nào.
///  - Hai chuỗi trống là bằng nhau về mặt từ vựng.
///
/// ## Làm cách nào để triển khai `Ord`?
///
/// `Ord` yêu cầu loại cũng là [`PartialOrd`] và [`Eq`] (yêu cầu [`PartialEq`]).
///
/// Sau đó, bạn phải xác định một triển khai cho [`cmp`].Bạn có thể thấy hữu ích khi sử dụng [`cmp`] trên các trường thuộc loại của bạn.
///
/// Việc triển khai [`PartialEq`], [`PartialOrd`] và `Ord`*phải* đồng ý với nhau.
/// Đó là, `a.cmp(b) == Ordering::Equal` nếu và chỉ khi `a == b` và `Some(a.cmp(b)) == a.partial_cmp(b)` cho tất cả `a` và `b`.
/// Thật dễ dàng vô tình làm cho họ không đồng ý bằng cách lấy một số traits và thực hiện thủ công những người khác.
///
/// Đây là một ví dụ mà bạn chỉ muốn sắp xếp mọi người theo chiều cao, bỏ qua `id` và `name`:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Phương thức này trả về [`Ordering`] giữa `self` và `other`.
    ///
    /// Theo quy ước, `self.cmp(&other)` trả về thứ tự khớp với biểu thức `self <operator> other` nếu đúng.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// So sánh và trả về giá trị tối đa của hai giá trị.
    ///
    /// Trả về đối số thứ hai nếu phép so sánh xác định chúng bằng nhau.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// So sánh và trả về giá trị nhỏ nhất của hai giá trị.
    ///
    /// Trả về đối số đầu tiên nếu phép so sánh xác định chúng bằng nhau.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Giới hạn một giá trị trong một khoảng thời gian nhất định.
    ///
    /// Trả về `max` nếu `self` lớn hơn `max` và `min` nếu `self` nhỏ hơn `min`.
    /// Nếu không, điều này sẽ trả về `self`.
    ///
    /// # Panics
    ///
    /// Panics nếu `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// Derive macro tạo ra một impl của trait `Ord`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait cho các giá trị có thể được so sánh cho một thứ tự sắp xếp.
///
/// So sánh phải đáp ứng, cho tất cả `a`, `b` và `c`:
///
/// - không đối xứng: nếu `a < b` thì `!(a > b)`, cũng như `a > b` ngụ ý `!(a < b)`;và
/// - độ nhạy: `a < b` và `b < c` ngụ ý `a < c`.Điều tương tự phải giữ cho cả `==` và `>`.
///
/// Lưu ý rằng các yêu cầu này có nghĩa là bản thân trait phải được thực hiện đối xứng và chuyển tiếp: nếu `T: PartialOrd<U>` và `U: PartialOrd<V>` thì `U: PartialOrd<T>` và `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// trait này có thể được sử dụng với `#[derive]`.Khi `dẫn xuất`d trên struct, nó sẽ tạo ra một thứ tự từ vựng dựa trên thứ tự khai báo từ trên xuống dưới của các thành viên trong struct.
/// Khi `dẫn xuất`d trên enums, các biến thể được sắp xếp theo thứ tự phân biệt từ trên xuống dưới của chúng.
///
/// ## Làm cách nào để triển khai `PartialOrd`?
///
/// `PartialOrd` chỉ yêu cầu triển khai phương thức [`partial_cmp`], với các phương thức khác được tạo từ các triển khai mặc định.
///
/// Tuy nhiên, vẫn có thể triển khai những cái khác một cách riêng biệt cho các loại không có thứ tự tổng thể.
/// Ví dụ: đối với số dấu phẩy động, `NaN < 0 == false` và `NaN >= 0 == false` (x.
/// IEEE 754-2008 phần 5.11).
///
/// `PartialOrd` yêu cầu loại của bạn phải là [`PartialEq`].
///
/// Việc triển khai [`PartialEq`], `PartialOrd` và [`Ord`]*phải* đồng ý với nhau.
/// Thật dễ dàng vô tình làm cho họ không đồng ý bằng cách lấy một số traits và thực hiện thủ công những người khác.
///
/// Nếu loại của bạn là [`Ord`], bạn có thể triển khai [`partial_cmp`] bằng cách sử dụng [`cmp`]:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// Bạn cũng có thể thấy hữu ích khi sử dụng [`partial_cmp`] trên các trường thuộc loại của bạn.
/// Dưới đây là ví dụ về các loại `Person` có trường `height` dấu phẩy động là trường duy nhất được sử dụng để sắp xếp:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Phương thức này trả về thứ tự giữa các giá trị `self` và `other` nếu một giá trị tồn tại.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Khi không thể so sánh được:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Phương pháp này kiểm tra nhỏ hơn (đối với `self` và `other`) và được sử dụng bởi toán tử `<`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Phương pháp này kiểm tra nhỏ hơn hoặc bằng (đối với `self` và `other`) và được sử dụng bởi toán tử `<=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Phương pháp này kiểm tra lớn hơn (đối với `self` và `other`) và được sử dụng bởi toán tử `>`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Phương pháp này kiểm tra lớn hơn hoặc bằng (đối với `self` và `other`) và được sử dụng bởi toán tử `>=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// Derive macro tạo ra một impl của trait `PartialOrd`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// So sánh và trả về giá trị nhỏ nhất của hai giá trị.
///
/// Trả về đối số đầu tiên nếu phép so sánh xác định chúng bằng nhau.
///
/// Nội bộ sử dụng bí danh cho [`Ord::min`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Trả về giá trị nhỏ nhất của hai giá trị đối với hàm so sánh được chỉ định.
///
/// Trả về đối số đầu tiên nếu phép so sánh xác định chúng bằng nhau.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Trả về phần tử cho giá trị nhỏ nhất từ hàm được chỉ định.
///
/// Trả về đối số đầu tiên nếu phép so sánh xác định chúng bằng nhau.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// So sánh và trả về giá trị tối đa của hai giá trị.
///
/// Trả về đối số thứ hai nếu phép so sánh xác định chúng bằng nhau.
///
/// Nội bộ sử dụng bí danh cho [`Ord::max`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Trả về giá trị tối đa của hai giá trị đối với hàm so sánh được chỉ định.
///
/// Trả về đối số thứ hai nếu phép so sánh xác định chúng bằng nhau.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Trả về phần tử cho giá trị lớn nhất từ hàm được chỉ định.
///
/// Trả về đối số thứ hai nếu phép so sánh xác định chúng bằng nhau.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// Triển khai PartialEq, Eq, PartialOrd và Ord cho các kiểu nguyên thủy
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // Thứ tự ở đây là quan trọng để tạo ra lắp ráp tối ưu hơn.
                    // Xem <https://github.com/rust-lang/rust/issues/63758> để biết thêm thông tin.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // Đúc theo i8 và chuyển đổi sự khác biệt thành Đặt hàng tạo ra lắp ráp tối ưu hơn.
            //
            // Xem <https://github.com/rust-lang/rust/issues/66780> để biết thêm thông tin.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // AN TOÀN: bool as i8 trả về 0 hoặc 1, vì vậy sự khác biệt không thể là bất kỳ điều gì khác
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &con trỏ

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}