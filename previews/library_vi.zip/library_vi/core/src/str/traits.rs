//! Triển khai Trait cho `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Thực hiện thứ tự các chuỗi.
///
/// Các chuỗi được sắp xếp thứ tự [lexicographically](Ord#lexicographical-comparison) theo giá trị byte của chúng.
/// Điều này sắp xếp các điểm mã Unicode dựa trên vị trí của chúng trong biểu đồ mã.
/// Điều này không nhất thiết phải giống với thứ tự "alphabetical", thay đổi theo ngôn ngữ và khu vực.
/// Việc sắp xếp các chuỗi theo các tiêu chuẩn được văn hóa chấp nhận yêu cầu dữ liệu theo ngôn ngữ cụ thể nằm ngoài phạm vi của loại `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Thực hiện các thao tác so sánh trên chuỗi.
///
/// Các chuỗi được so sánh [lexicographically](Ord#lexicographical-comparison) theo giá trị byte của chúng.
/// Điều này so sánh các điểm mã Unicode dựa trên vị trí của chúng trong biểu đồ mã.
/// Điều này không nhất thiết phải giống với thứ tự "alphabetical", thay đổi theo ngôn ngữ và khu vực.
/// So sánh các chuỗi theo các tiêu chuẩn được văn hóa chấp nhận yêu cầu dữ liệu theo ngôn ngữ cụ thể nằm ngoài phạm vi của loại `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Thực hiện cắt chuỗi con với cú pháp `&self[..]` hoặc `&mut self[..]`.
///
/// Trả về một phần của toàn bộ chuỗi, tức là trả về `&self` hoặc `&mut self`.Tương đương với `&self [0..
/// len] `hoặc`&mut self [0..
/// len]`.
/// Không giống như các hoạt động lập chỉ mục khác, điều này không bao giờ có thể panic.
///
/// Thao tác này là *O*(1).
///
/// Trước 1.20.0, các hoạt động lập chỉ mục này vẫn được hỗ trợ bởi việc triển khai trực tiếp `Index` và `IndexMut`.
///
/// Tương đương với `&self[0 .. len]` hoặc `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Thực hiện cắt chuỗi con với cú pháp `&self[begin .. end]` hoặc `&mut self[begin .. end]`.
///
/// Trả về một phần của chuỗi đã cho từ phạm vi byte [`begin`, `end`).
///
/// Thao tác này là *O*(1).
///
/// Trước 1.20.0, các hoạt động lập chỉ mục này vẫn được hỗ trợ bởi việc triển khai trực tiếp `Index` và `IndexMut`.
///
/// # Panics
///
/// Panics nếu `begin` hoặc `end` không trỏ đến độ lệch byte bắt đầu của một ký tự (như được xác định bởi `is_char_boundary`), nếu `begin > end` hoặc nếu `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // những điều này sẽ panic:
/// // byte 2 nằm trong `ö`:
/// // &s [2 ..3];
///
/// // byte 8 nằm trong `老`&s [1..
/// // 8];
///
/// // byte 100 nằm ngoài chuỗi&s [3..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // AN TOÀN: vừa kiểm tra xem `start` và `end` có nằm trên ranh giới ký tự không,
            // và chúng tôi đang chuyển vào một tham chiếu an toàn, vì vậy giá trị trả về cũng sẽ là một.
            // Chúng tôi cũng đã kiểm tra ranh giới ký tự, vì vậy đây là UTF-8 hợp lệ.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // AN TOÀN: vừa kiểm tra xem `start` và `end` có nằm trên ranh giới ký tự không.
            // Chúng tôi biết con trỏ là duy nhất vì chúng tôi lấy nó từ `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // AN TOÀN: người gọi đảm bảo rằng `self` nằm trong giới hạn của `slice`
        // thỏa mãn tất cả các điều kiện cho `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // AN TOÀN: xem nhận xét cho `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary kiểm tra xem chỉ mục nằm trong [0, .len()] không thể sử dụng lại `get` như trên, vì sự cố NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // AN TOÀN: vừa kiểm tra xem `start` và `end` có nằm trên ranh giới ký tự không,
            // và chúng tôi đang chuyển vào một tham chiếu an toàn, vì vậy giá trị trả về cũng sẽ là một.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Thực hiện cắt chuỗi con với cú pháp `&self[.. end]` hoặc `&mut self[.. end]`.
///
/// Trả về một phần của chuỗi đã cho từ phạm vi byte [`0`, `end`).
/// Tương đương với `&self[0 .. end]` hoặc `&mut self[0 .. end]`.
///
/// Thao tác này là *O*(1).
///
/// Trước 1.20.0, các hoạt động lập chỉ mục này vẫn được hỗ trợ bởi việc triển khai trực tiếp `Index` và `IndexMut`.
///
/// # Panics
///
/// Panics nếu `end` không trỏ đến độ lệch byte bắt đầu của một ký tự (như được xác định bởi `is_char_boundary`) hoặc nếu `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // AN TOÀN: vừa kiểm tra xem `end` có nằm trên ranh giới ký tự không,
            // và chúng tôi đang chuyển vào một tham chiếu an toàn, vì vậy giá trị trả về cũng sẽ là một.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // AN TOÀN: vừa kiểm tra xem `end` có nằm trên ranh giới ký tự không,
            // và chúng tôi đang chuyển vào một tham chiếu an toàn, vì vậy giá trị trả về cũng sẽ là một.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // AN TOÀN: vừa kiểm tra xem `end` có nằm trên ranh giới ký tự không,
            // và chúng tôi đang chuyển vào một tham chiếu an toàn, vì vậy giá trị trả về cũng sẽ là một.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Thực hiện cắt chuỗi con với cú pháp `&self[begin ..]` hoặc `&mut self[begin ..]`.
///
/// Trả về một phần của chuỗi đã cho từ phạm vi byte [`begin`, `len`).Tương đương với `&self [begin ..
/// len] `hoặc`&mut self [begin ..
/// len]`.
///
/// Thao tác này là *O*(1).
///
/// Trước 1.20.0, các hoạt động lập chỉ mục này vẫn được hỗ trợ bởi việc triển khai trực tiếp `Index` và `IndexMut`.
///
/// # Panics
///
/// Panics nếu `begin` không trỏ đến độ lệch byte bắt đầu của một ký tự (như được xác định bởi `is_char_boundary`) hoặc nếu `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // AN TOÀN: vừa kiểm tra xem `start` có nằm trên ranh giới ký tự không,
            // và chúng tôi đang chuyển vào một tham chiếu an toàn, vì vậy giá trị trả về cũng sẽ là một.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // AN TOÀN: vừa kiểm tra xem `start` có nằm trên ranh giới ký tự không,
            // và chúng tôi đang chuyển vào một tham chiếu an toàn, vì vậy giá trị trả về cũng sẽ là một.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // AN TOÀN: người gọi đảm bảo rằng `self` nằm trong giới hạn của `slice`
        // thỏa mãn tất cả các điều kiện cho `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // AN TOÀN: giống với `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // AN TOÀN: vừa kiểm tra xem `start` có nằm trên ranh giới ký tự không,
            // và chúng tôi đang chuyển vào một tham chiếu an toàn, vì vậy giá trị trả về cũng sẽ là một.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Thực hiện cắt chuỗi con với cú pháp `&self[begin ..= end]` hoặc `&mut self[begin ..= end]`.
///
/// Trả về một phần của chuỗi đã cho từ phạm vi byte [`begin`, `end`].Tương đương với `&self [begin .. end + 1]` hoặc `&mut self[begin .. end + 1]`, ngoại trừ trường hợp `end` có giá trị lớn nhất cho `usize`.
///
/// Thao tác này là *O*(1).
///
/// # Panics
///
/// Panics nếu `begin` không trỏ đến phần bù byte bắt đầu của một ký tự (như được xác định bởi `is_char_boundary`), nếu `end` không trỏ đến phần bù byte kết thúc của một ký tự (`end + 1` là phần bù byte bắt đầu hoặc bằng `len`), nếu `begin > end`, hoặc nếu `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Thực hiện cắt chuỗi con với cú pháp `&self[..= end]` hoặc `&mut self[..= end]`.
///
/// Trả về một phần của chuỗi đã cho từ dải byte [0, `end`].
/// Tương đương với `&self [0 .. end + 1]`, ngoại trừ trường hợp `end` có giá trị lớn nhất cho `usize`.
///
/// Thao tác này là *O*(1).
///
/// # Panics
///
/// Panics nếu `end` không trỏ đến phần bù byte kết thúc của một ký tự (`end + 1` hoặc là phần bù byte bắt đầu như được xác định bởi `is_char_boundary`, hoặc bằng `len`) hoặc nếu `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Phân tích cú pháp một giá trị từ một chuỗi
///
/// Phương thức [`from_str`] của `FromStr` thường được sử dụng ngầm, thông qua phương thức [`parse`] của [`str`].
/// Xem tài liệu của [`parse`] để biết các ví dụ.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` không có tham số thời gian tồn tại và vì vậy bạn chỉ có thể phân tích cú pháp các loại không chứa tham số lâu dài.
///
/// Nói cách khác, bạn có thể phân tích cú pháp `i32` với `FromStr`, nhưng không thể phân tích cú pháp `&i32`.
/// Bạn có thể phân tích cú pháp cấu trúc chứa `i32`, nhưng không thể phân tích cấu trúc chứa `&i32`.
///
/// # Examples
///
/// Triển khai cơ bản của `FromStr` trên kiểu `Point` ví dụ:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Lỗi liên quan có thể được trả lại từ quá trình phân tích cú pháp.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Phân tích cú pháp một chuỗi `s` để trả về một giá trị thuộc loại này.
    ///
    /// Nếu quá trình phân tích cú pháp thành công, hãy trả về giá trị bên trong [`Ok`], ngược lại khi chuỗi không được định dạng sẽ trả về một lỗi cụ thể cho bên trong [`Err`].
    /// Loại lỗi dành riêng cho việc triển khai trait.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản với [`i32`], một kiểu triển khai `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Phân tích cú pháp `bool` từ một chuỗi.
    ///
    /// Mang lại `Result<bool, ParseBoolError>`, vì `s` có thể thực sự có thể phân tích cú pháp hoặc không.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Lưu ý, trong nhiều trường hợp, phương thức `.parse()` trên `str` phù hợp hơn.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}