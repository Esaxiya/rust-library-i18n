//! Xác định loại lỗi utf8.

use crate::fmt;

/// Các lỗi có thể xảy ra khi cố gắng diễn giải một chuỗi [`u8`] dưới dạng một chuỗi.
///
/// Do đó, họ hàm và phương thức `from_utf8` cho cả [`String`] và [`&str`] sử dụng lỗi này, chẳng hạn.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Các phương pháp của loại lỗi này có thể được sử dụng để tạo chức năng tương tự như `String::from_utf8_lossy` mà không cần phân bổ bộ nhớ heap:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Trả về chỉ mục trong chuỗi đã cho mà UTF-8 hợp lệ đã được xác minh.
    ///
    /// Đây là chỉ số tối đa mà `from_utf8(&input[..index])` sẽ trả về `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// use std::str;
    ///
    /// // một số byte không hợp lệ, trong vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 trả về một Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // byte thứ hai không hợp lệ ở đây
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Cung cấp thêm thông tin về lỗi:
    ///
    /// * `None`: cuối đầu vào đã đạt đến bất ngờ.
    ///   `self.valid_up_to()` là 1 đến 3 byte tính từ cuối đầu vào.
    ///   Nếu một luồng byte (chẳng hạn như tệp hoặc ổ cắm mạng) đang được giải mã tăng dần, đây có thể là `char` hợp lệ có chuỗi byte UTF-8 trải dài nhiều phần.
    ///
    ///
    /// * `Some(len)`: một byte không mong muốn đã gặp phải.
    ///   Độ dài được cung cấp là độ dài của chuỗi byte không hợp lệ bắt đầu từ chỉ mục do `valid_up_to()` cung cấp.
    ///   Quá trình giải mã sẽ tiếp tục sau chuỗi đó (sau khi chèn [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) trong trường hợp giải mã bị mất.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Lỗi trả về khi phân tích cú pháp `bool` bằng [`from_str`] không thành công
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}