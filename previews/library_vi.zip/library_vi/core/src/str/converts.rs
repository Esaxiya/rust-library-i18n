//! Các cách tạo `str` từ lát byte.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Chuyển đổi một lát byte thành một lát chuỗi.
///
/// Một lát chuỗi ([`&str`]) được tạo bởi các byte ([`u8`]) và một lát byte ([`&[u8]`][byteslice]) được tạo bằng các byte, vì vậy hàm này chuyển đổi giữa hai loại.
/// Tuy nhiên, không phải tất cả các lát byte đều là các lát chuỗi hợp lệ: [`&str`] yêu cầu nó phải là UTF-8 hợp lệ.
/// `from_utf8()` kiểm tra để đảm bảo rằng các byte là UTF-8 hợp lệ, sau đó thực hiện chuyển đổi.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Nếu bạn chắc chắn rằng lát byte là UTF-8 hợp lệ và bạn không muốn phải chịu chi phí kiểm tra tính hợp lệ, thì có một phiên bản không an toàn của hàm này, [`from_utf8_unchecked`], có cùng hành vi nhưng bỏ qua kiểm tra.
///
///
/// Nếu bạn cần `String` thay vì `&str`, hãy xem xét [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Bởi vì bạn có thể phân bổ ngăn xếp một `[u8; N]` và bạn có thể lấy [`&[u8]`][byteslice] của nó, hàm này là một cách để có một chuỗi được phân bổ ngăn xếp.Có một ví dụ về điều này trong phần ví dụ bên dưới.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Trả về `Err` nếu lát cắt không phải là UTF-8 với mô tả lý do tại sao lát được cung cấp không phải là UTF-8.
///
/// # Examples
///
/// Cách sử dụng cơ bản:
///
/// ```
/// use std::str;
///
/// // một số byte, trong vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Chúng tôi biết những byte này là hợp lệ, vì vậy chỉ cần sử dụng `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Các byte không chính xác:
///
/// ```
/// use std::str;
///
/// // một số byte không hợp lệ, trong vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Xem tài liệu dành cho [`Utf8Error`] để biết thêm chi tiết về các loại lỗi có thể được trả lại.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // một số byte, trong một mảng được phân bổ theo ngăn xếp
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Chúng tôi biết những byte này là hợp lệ, vì vậy chỉ cần sử dụng `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // AN TOÀN: Vừa chạy xác thực.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Chuyển đổi một lát byte có thể thay đổi thành một lát chuỗi có thể thay đổi.
///
/// # Examples
///
/// Cách sử dụng cơ bản:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" như một vector có thể thay đổi
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Như chúng ta biết những byte này là hợp lệ, chúng ta có thể sử dụng `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Các byte không chính xác:
///
/// ```
/// use std::str;
///
/// // Một số byte không hợp lệ trong vector có thể thay đổi
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Xem tài liệu dành cho [`Utf8Error`] để biết thêm chi tiết về các loại lỗi có thể được trả lại.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // AN TOÀN: Vừa chạy xác thực.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Chuyển đổi một lát byte thành một lát chuỗi mà không cần kiểm tra xem chuỗi có chứa UTF-8 hợp lệ hay không.
///
/// Xem phiên bản an toàn, [`from_utf8`], để biết thêm thông tin.
///
/// # Safety
///
/// Hàm này không an toàn vì nó không kiểm tra xem các byte được truyền vào nó có phải là UTF-8 hợp lệ hay không.
/// Nếu ràng buộc này bị vi phạm, hành vi không xác định sẽ dẫn đến kết quả, vì phần còn lại của Rust giả định rằng [`&str`] là UTF-8 hợp lệ.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Cách sử dụng cơ bản:
///
/// ```
/// use std::str;
///
/// // một số byte, trong vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // AN TOÀN: người gọi phải đảm bảo rằng các byte `v` là UTF-8 hợp lệ.
    // Cũng dựa vào `&str` và `&[u8]` có cùng một bố cục.
    unsafe { mem::transmute(v) }
}

/// Chuyển đổi một lát byte thành một lát chuỗi mà không cần kiểm tra xem chuỗi có chứa UTF-8 hợp lệ hay không;phiên bản có thể thay đổi.
///
///
/// Xem phiên bản bất biến, [`from_utf8_unchecked()`] để biết thêm thông tin.
///
/// # Examples
///
/// Cách sử dụng cơ bản:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // AN TOÀN: người gọi phải đảm bảo rằng các byte `v`
    // là UTF-8 hợp lệ, do đó việc truyền sang `*mut str` là an toàn.
    // Ngoài ra, tham chiếu con trỏ là an toàn vì con trỏ đó đến từ một tham chiếu được đảm bảo là hợp lệ để ghi.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}