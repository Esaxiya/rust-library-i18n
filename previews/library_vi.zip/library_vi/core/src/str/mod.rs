//! Thao tác với chuỗi.
//!
//! Để biết thêm chi tiết, hãy xem mô-đun [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. ngoài giới hạn
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. bắt đầu <=kết thúc
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. ranh giới ký tự
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // tìm nhân vật
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` phải nhỏ hơn len và một ranh giới char
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Trả về độ dài của `self`.
    ///
    /// Độ dài này tính bằng byte, không phải [`char`] s hoặc grapheme.
    /// Nói cách khác, nó có thể không phải là thứ mà con người coi là độ dài của chuỗi.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // ưa thích f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Trả về `true` nếu `self` có độ dài bằng không byte.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Kiểm tra byte thứ `chỉ mục` là byte đầu tiên trong chuỗi điểm mã UTF-8 hay là phần cuối của chuỗi.
    ///
    ///
    /// Phần đầu và phần cuối của chuỗi (khi `index== self.len()`) được coi là ranh giới.
    ///
    /// Trả về `false` nếu `index` lớn hơn `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // bắt đầu của `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // byte thứ hai của `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // byte thứ ba của `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 và len luôn ok.
        // Kiểm tra 0 một cách rõ ràng để nó có thể tối ưu hóa việc kiểm tra một cách dễ dàng và bỏ qua việc đọc dữ liệu chuỗi cho trường hợp đó.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Đây là phép thuật bit tương đương với: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Chuyển đổi một lát chuỗi thành một lát byte.
    /// Để chuyển đổi lát cắt byte trở lại thành một lát chuỗi, hãy sử dụng hàm [`from_utf8`].
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // AN TOÀN: âm thanh const vì chúng tôi chuyển đổi hai loại có cùng bố cục
        unsafe { mem::transmute(self) }
    }

    /// Chuyển đổi một lát chuỗi có thể thay đổi thành một lát byte có thể thay đổi.
    ///
    /// # Safety
    ///
    /// Người gọi phải đảm bảo rằng nội dung của lát cắt là UTF-8 hợp lệ trước khi việc mượn kết thúc và `str` cơ bản được sử dụng.
    ///
    ///
    /// Sử dụng `str` có nội dung không hợp lệ UTF-8 là hành vi không xác định.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // AN TOÀN: diễn viên từ `&str` đến `&[u8]` an toàn kể từ `str`
        // có bố cục giống như `&[u8]` (chỉ libstd mới có thể đảm bảo điều này).
        // Tham chiếu con trỏ là an toàn vì nó đến từ một tham chiếu có thể thay đổi được, được đảm bảo là hợp lệ để ghi.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Chuyển đổi một lát chuỗi thành một con trỏ thô.
    ///
    /// Vì các lát chuỗi là một lát byte, con trỏ thô trỏ đến [`u8`].
    /// Con trỏ này sẽ trỏ đến byte đầu tiên của lát chuỗi.
    ///
    /// Người gọi phải đảm bảo rằng con trỏ trả về không bao giờ được ghi vào.
    /// Nếu bạn cần thay đổi nội dung của lát chuỗi, hãy sử dụng [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Chuyển đổi một lát chuỗi có thể thay đổi thành một con trỏ thô.
    ///
    /// Vì các lát chuỗi là một lát byte, con trỏ thô trỏ đến [`u8`].
    /// Con trỏ này sẽ trỏ đến byte đầu tiên của lát chuỗi.
    ///
    /// Bạn có trách nhiệm đảm bảo rằng lát chuỗi chỉ được sửa đổi theo cách mà nó vẫn hợp lệ UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Trả về một tập hợp con của `str`.
    ///
    /// Đây là giải pháp thay thế không gây hoảng sợ cho việc lập chỉ mục `str`.
    /// Trả về [`None`] bất cứ khi nào hoạt động lập chỉ mục tương đương sẽ panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // các chỉ số không nằm trên ranh giới trình tự UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // ngoài giới hạn
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Trả về một nhóm con có thể thay đổi của `str`.
    ///
    /// Đây là giải pháp thay thế không gây hoảng sợ cho việc lập chỉ mục `str`.
    /// Trả về [`None`] bất cứ khi nào hoạt động lập chỉ mục tương đương sẽ panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // chiều dài chính xác
    /// assert!(v.get_mut(0..5).is_some());
    /// // ngoài giới hạn
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Trả về một nhóm con chưa được kiểm tra của `str`.
    ///
    /// Đây là giải pháp thay thế không được chọn để lập chỉ mục `str`.
    ///
    /// # Safety
    ///
    /// Người gọi hàm này có trách nhiệm rằng các điều kiện tiên quyết này được thỏa mãn:
    ///
    /// * Chỉ số bắt đầu không được vượt quá chỉ số kết thúc;
    /// * Các chỉ mục phải nằm trong giới hạn của lát gốc;
    /// * Chỉ mục phải nằm trên ranh giới trình tự UTF-8.
    ///
    /// Không làm được điều đó, lát chuỗi được trả về có thể tham chiếu đến bộ nhớ không hợp lệ hoặc vi phạm các bất biến được giao tiếp bởi kiểu `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `get_unchecked`;
        // lát cắt là không thể tham chiếu vì `self` là một tham chiếu an toàn.
        // Con trỏ được trả về là an toàn vì các lần nhập của `SliceIndex` phải đảm bảo rằng nó là đúng.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Trả về một nhóm con có thể thay đổi, chưa được kiểm tra của `str`.
    ///
    /// Đây là giải pháp thay thế không được chọn để lập chỉ mục `str`.
    ///
    /// # Safety
    ///
    /// Người gọi hàm này có trách nhiệm rằng các điều kiện tiên quyết này được thỏa mãn:
    ///
    /// * Chỉ số bắt đầu không được vượt quá chỉ số kết thúc;
    /// * Các chỉ mục phải nằm trong giới hạn của lát gốc;
    /// * Chỉ mục phải nằm trên ranh giới trình tự UTF-8.
    ///
    /// Không làm được điều đó, lát chuỗi được trả về có thể tham chiếu đến bộ nhớ không hợp lệ hoặc vi phạm các bất biến được giao tiếp bởi kiểu `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `get_unchecked_mut`;
        // lát cắt là không thể tham chiếu vì `self` là một tham chiếu an toàn.
        // Con trỏ được trả về là an toàn vì các lần nhập của `SliceIndex` phải đảm bảo rằng nó là đúng.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Tạo một lát chuỗi từ một lát chuỗi khác, bỏ qua các kiểm tra an toàn.
    ///
    /// Điều này thường không được khuyến khích, hãy sử dụng một cách thận trọng!Để biết một giải pháp thay thế an toàn, hãy xem [`str`] và [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Phần mới này đi từ `begin` đến `end`, bao gồm cả `begin` nhưng ngoại trừ `end`.
    ///
    /// Thay vào đó, để nhận một lát chuỗi có thể thay đổi, hãy xem phương pháp [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Người gọi hàm này có trách nhiệm thỏa mãn ba điều kiện tiên quyết:
    ///
    /// * `begin` không được vượt quá `end`.
    /// * `begin` và `end` phải là các vị trí byte trong lát chuỗi.
    /// * `begin` và `end` phải nằm trên ranh giới trình tự UTF-8.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `get_unchecked`;
        // lát cắt là không thể tham chiếu vì `self` là một tham chiếu an toàn.
        // Con trỏ được trả về là an toàn vì các lần nhập của `SliceIndex` phải đảm bảo rằng nó là đúng.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Tạo một lát chuỗi từ một lát chuỗi khác, bỏ qua các kiểm tra an toàn.
    /// Điều này thường không được khuyến khích, hãy sử dụng một cách thận trọng!Để biết một giải pháp thay thế an toàn, hãy xem [`str`] và [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Phần mới này đi từ `begin` đến `end`, bao gồm cả `begin` nhưng ngoại trừ `end`.
    ///
    /// Để có được một lát chuỗi bất biến thay thế, hãy xem phương pháp [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Người gọi hàm này có trách nhiệm thỏa mãn ba điều kiện tiên quyết:
    ///
    /// * `begin` không được vượt quá `end`.
    /// * `begin` và `end` phải là các vị trí byte trong lát chuỗi.
    /// * `begin` và `end` phải nằm trên ranh giới trình tự UTF-8.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `get_unchecked_mut`;
        // lát cắt là không thể tham chiếu vì `self` là một tham chiếu an toàn.
        // Con trỏ được trả về là an toàn vì các lần nhập của `SliceIndex` phải đảm bảo rằng nó là đúng.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Chia một lát chuỗi thành hai tại một chỉ mục.
    ///
    /// Đối số, `mid`, phải là một độ lệch byte tính từ đầu chuỗi.
    /// Nó cũng phải nằm trên ranh giới của một điểm mã UTF-8.
    ///
    /// Hai lát được trả về đi từ đầu của lát chuỗi đến `mid` và từ `mid` đến cuối lát chuỗi.
    ///
    /// Để nhận các lát chuỗi có thể thay đổi thay thế, hãy xem phương pháp [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics nếu `mid` không nằm trên ranh giới điểm mã UTF-8 hoặc nếu nó vượt quá cuối điểm mã cuối cùng của lát chuỗi.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary kiểm tra xem chỉ mục có trong [0, .len()]
        if self.is_char_boundary(mid) {
            // AN TOÀN: vừa kiểm tra xem `mid` có nằm trên ranh giới ký tự không.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Chia một lát chuỗi có thể thay đổi thành hai tại một chỉ mục.
    ///
    /// Đối số, `mid`, phải là một độ lệch byte tính từ đầu chuỗi.
    /// Nó cũng phải nằm trên ranh giới của một điểm mã UTF-8.
    ///
    /// Hai lát được trả về đi từ đầu của lát chuỗi đến `mid` và từ `mid` đến cuối lát chuỗi.
    ///
    /// Thay vào đó, để nhận các lát chuỗi bất biến, hãy xem phương pháp [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics nếu `mid` không nằm trên ranh giới điểm mã UTF-8 hoặc nếu nó vượt quá cuối điểm mã cuối cùng của lát chuỗi.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary kiểm tra xem chỉ mục có trong [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // AN TOÀN: vừa kiểm tra xem `mid` có nằm trên ranh giới ký tự không.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Trả về một trình lặp trên [`char`] của một lát chuỗi.
    ///
    /// Vì một lát chuỗi bao gồm UTF-8 hợp lệ, chúng ta có thể lặp lại một lát chuỗi bằng [`char`].
    /// Phương thức này trả về một trình lặp như vậy.
    ///
    /// Điều quan trọng cần nhớ là [`char`] đại diện cho Giá trị vô hướng Unicode và có thể không khớp với ý tưởng của bạn về 'character' là gì.
    ///
    /// Việc lặp lại trên các cụm grapheme có thể là điều bạn thực sự muốn.
    /// Chức năng này không được cung cấp bởi thư viện tiêu chuẩn của Rust, hãy kiểm tra crates.io để thay thế.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Hãy nhớ rằng, [`char`] có thể không phù hợp với trực giác của bạn về các ký tự:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // không phải 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Trả về một trình lặp trên [`char`] của một lát chuỗi và vị trí của chúng.
    ///
    /// Vì một lát chuỗi bao gồm UTF-8 hợp lệ, chúng ta có thể lặp lại một lát chuỗi bằng [`char`].
    /// Phương thức này trả về một trình lặp của cả hai [`char`] này, cũng như các vị trí byte của chúng.
    ///
    /// Trình lặp tạo ra các bộ giá trị.Vị trí thứ nhất, [`char`] đứng thứ hai.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Hãy nhớ rằng, [`char`] có thể không phù hợp với trực giác của bạn về các ký tự:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // không phải (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // lưu ý 3 ở đây, ký tự cuối cùng chiếm hai byte
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Một trình lặp trên các byte của một lát chuỗi.
    ///
    /// Vì một lát chuỗi bao gồm một chuỗi các byte, chúng ta có thể lặp qua một lát chuỗi theo từng byte.
    /// Phương thức này trả về một trình lặp như vậy.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Tách một lát chuỗi theo khoảng trắng.
    ///
    /// Trình lặp được trả về sẽ trả về các lát chuỗi là các lát con của lát chuỗi ban đầu, được phân tách bằng bất kỳ khoảng trắng nào.
    ///
    ///
    /// 'Whitespace' được định nghĩa theo các điều khoản của Thuộc tính lõi có nguồn gốc Unicode `White_Space`.
    /// Nếu bạn chỉ muốn phân chia trên khoảng trắng ASCII, hãy sử dụng [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Tất cả các loại khoảng trắng được coi là:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Tách một lát chuỗi theo khoảng trắng ASCII.
    ///
    /// Trình lặp được trả về sẽ trả về các lát chuỗi là các lát con của lát chuỗi ban đầu, được phân tách bằng bất kỳ khoảng trắng ASCII nào.
    ///
    ///
    /// Thay vào đó, để phân chia bằng Unicode `Whitespace`, hãy sử dụng [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Tất cả các loại khoảng trắng ASCII được coi là:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Một trình lặp trên các dòng của một chuỗi, dưới dạng các lát cắt của chuỗi.
    ///
    /// Các dòng được kết thúc bằng một dòng mới (`\n`) hoặc một dấu xuống dòng với một nguồn cấp dòng (`\r\n`).
    ///
    /// Kết thúc dòng cuối cùng là tùy chọn.
    /// Một chuỗi kết thúc bằng dòng cuối cùng sẽ trả về các dòng giống như một chuỗi khác giống hệt mà không có dòng cuối cùng.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Kết thúc dòng cuối cùng không bắt buộc:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Một trình lặp trên các dòng của một chuỗi.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Trả về một trình lặp của `u16` trên chuỗi được mã hóa là UTF-16.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Trả về `true` nếu mẫu đã cho khớp với một lát con của lát chuỗi này.
    ///
    /// Trả về `false` nếu không.
    ///
    /// [pattern] có thể là `&str`, [`char`], một phần của [`char`] s, hoặc một hàm hoặc bao đóng xác định xem một ký tự có khớp hay không.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Trả về `true` nếu mẫu đã cho khớp với tiền tố của lát chuỗi này.
    ///
    /// Trả về `false` nếu không.
    ///
    /// [pattern] có thể là `&str`, [`char`], một phần của [`char`] s, hoặc một hàm hoặc bao đóng xác định xem một ký tự có khớp hay không.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Trả về `true` nếu mẫu đã cho khớp với một hậu tố của lát chuỗi này.
    ///
    /// Trả về `false` nếu không.
    ///
    /// [pattern] có thể là `&str`, [`char`], một phần của [`char`] s, hoặc một hàm hoặc bao đóng xác định xem một ký tự có khớp hay không.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Trả về chỉ số byte của ký tự đầu tiên của lát chuỗi phù hợp với mẫu.
    ///
    /// Trả về [`None`] nếu mẫu không khớp.
    ///
    /// [pattern] có thể là `&str`, [`char`], một phần của [`char`] s, hoặc một hàm hoặc bao đóng xác định xem một ký tự có khớp hay không.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Các mẫu đơn giản:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Các mẫu phức tạp hơn sử dụng kiểu đóng và kiểu không điểm:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Không tìm thấy mẫu:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Trả về chỉ số byte cho ký tự đầu tiên của khớp ngoài cùng bên phải của mẫu trong lát chuỗi này.
    ///
    /// Trả về [`None`] nếu mẫu không khớp.
    ///
    /// [pattern] có thể là `&str`, [`char`], một phần của [`char`] s, hoặc một hàm hoặc bao đóng xác định xem một ký tự có khớp hay không.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Các mẫu đơn giản:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Các mẫu phức tạp hơn với các bao đóng:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Không tìm thấy mẫu:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Một trình lặp trên các chuỗi con của lát chuỗi này, được phân tách bằng các ký tự được so khớp bằng một mẫu.
    ///
    /// [pattern] có thể là `&str`, [`char`], một phần của [`char`] s, hoặc một hàm hoặc bao đóng xác định xem một ký tự có khớp hay không.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Hành vi của trình lặp lại
    ///
    /// Trình lặp được trả về sẽ là [`DoubleEndedIterator`] nếu mẫu cho phép tìm kiếm ngược và tìm kiếm forward/reverse mang lại các phần tử giống nhau.
    /// Điều này đúng với, ví dụ: [`char`], nhưng không đúng với `&str`.
    ///
    /// Nếu mẫu cho phép tìm kiếm ngược nhưng kết quả của nó có thể khác với tìm kiếm thuận, phương pháp [`rsplit`] có thể được sử dụng.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Các mẫu đơn giản:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Nếu mẫu là một phần của các ký tự, hãy tách theo mỗi lần xuất hiện của bất kỳ ký tự nào:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Một mẫu phức tạp hơn, sử dụng cách đóng:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Nếu một chuỗi chứa nhiều dấu phân tách liền kề, bạn sẽ kết thúc với các chuỗi trống trong đầu ra:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Các dấu phân cách liền kề được phân tách bằng chuỗi trống.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Các dấu phân tách ở đầu hoặc cuối của một chuỗi được bao quanh bởi các chuỗi trống.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Khi chuỗi trống được sử dụng làm dấu phân tách, nó sẽ phân tách mọi ký tự trong chuỗi, cùng với phần đầu và phần cuối của chuỗi.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Các dấu phân cách liền kề có thể dẫn đến hành vi có thể đáng ngạc nhiên khi khoảng trắng được sử dụng làm dấu phân cách.Mã này đúng:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Nó không _not_ cung cấp cho bạn:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Sử dụng [`split_whitespace`] cho hành vi này.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Một trình lặp trên các chuỗi con của lát chuỗi này, được phân tách bằng các ký tự được so khớp bằng một mẫu.
    /// Khác với trình lặp do `split` tạo ra ở chỗ `split_inclusive` để lại phần đã so khớp là phần cuối của chuỗi con.
    ///
    ///
    /// [pattern] có thể là `&str`, [`char`], một phần của [`char`] s, hoặc một hàm hoặc bao đóng xác định xem một ký tự có khớp hay không.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Nếu phần tử cuối cùng của chuỗi được khớp, phần tử đó sẽ được coi là phần tử kết thúc của chuỗi con trước đó.
    /// Chuỗi con đó sẽ là mục cuối cùng được trả về bởi trình vòng lặp.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Một trình lặp trên các chuỗi con của lát chuỗi đã cho, được phân tách bằng các ký tự được so khớp bởi một mẫu và mang lại kết quả theo thứ tự ngược lại.
    ///
    /// [pattern] có thể là `&str`, [`char`], một phần của [`char`] s, hoặc một hàm hoặc bao đóng xác định xem một ký tự có khớp hay không.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Hành vi của trình lặp lại
    ///
    /// Trình lặp được trả về yêu cầu mẫu hỗ trợ tìm kiếm ngược và nó sẽ là [`DoubleEndedIterator`] nếu tìm kiếm forward/reverse mang lại các phần tử giống nhau.
    ///
    ///
    /// Để lặp lại từ phía trước, phương pháp [`split`] có thể được sử dụng.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Các mẫu đơn giản:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Một mẫu phức tạp hơn, sử dụng cách đóng:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Một trình lặp trên các chuỗi con của lát chuỗi đã cho, được phân tách bằng các ký tự được so khớp bằng một mẫu.
    ///
    /// [pattern] có thể là `&str`, [`char`], một phần của [`char`] s, hoặc một hàm hoặc bao đóng xác định xem một ký tự có khớp hay không.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Tương đương với [`split`], ngoại trừ việc chuỗi con ở cuối bị bỏ qua nếu trống.
    ///
    /// [`split`]: str::split
    ///
    /// Phương pháp này có thể được sử dụng cho dữ liệu chuỗi là _terminated_, thay vì _separated_ theo một mẫu.
    ///
    /// # Hành vi của trình lặp lại
    ///
    /// Trình lặp được trả về sẽ là [`DoubleEndedIterator`] nếu mẫu cho phép tìm kiếm ngược và tìm kiếm forward/reverse mang lại các phần tử giống nhau.
    /// Điều này đúng với, ví dụ: [`char`], nhưng không đúng với `&str`.
    ///
    /// Nếu mẫu cho phép tìm kiếm ngược nhưng kết quả của nó có thể khác với tìm kiếm thuận, phương pháp [`rsplit_terminator`] có thể được sử dụng.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Một trình lặp trên các chuỗi con của `self`, được phân tách bằng các ký tự được so khớp bởi một mẫu và mang lại kết quả theo thứ tự ngược lại.
    ///
    /// [pattern] có thể là `&str`, [`char`], một phần của [`char`] s, hoặc một hàm hoặc bao đóng xác định xem một ký tự có khớp hay không.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Tương đương với [`split`], ngoại trừ việc chuỗi con ở cuối bị bỏ qua nếu trống.
    ///
    /// [`split`]: str::split
    ///
    /// Phương pháp này có thể được sử dụng cho dữ liệu chuỗi là _terminated_, thay vì _separated_ theo một mẫu.
    ///
    /// # Hành vi của trình lặp lại
    ///
    /// Trình lặp được trả về yêu cầu mẫu hỗ trợ tìm kiếm ngược và nó sẽ được kết thúc kép nếu tìm kiếm forward/reverse mang lại các phần tử giống nhau.
    ///
    ///
    /// Để lặp lại từ phía trước, phương pháp [`split_terminator`] có thể được sử dụng.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Một trình lặp trên các chuỗi con của lát chuỗi đã cho, được phân tách bằng một mẫu, bị hạn chế trả về tối đa các mục `n`.
    ///
    /// Nếu các chuỗi con `n` được trả về thì chuỗi con cuối cùng (chuỗi con thứ `n`) sẽ chứa phần còn lại của chuỗi.
    ///
    /// [pattern] có thể là `&str`, [`char`], một phần của [`char`] s, hoặc một hàm hoặc bao đóng xác định xem một ký tự có khớp hay không.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Hành vi của trình lặp lại
    ///
    /// Trình lặp được trả về sẽ không được kết thúc kép, vì nó không hiệu quả để hỗ trợ.
    ///
    /// Nếu mẫu cho phép tìm kiếm ngược, phương pháp [`rsplitn`] có thể được sử dụng.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Các mẫu đơn giản:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Một mẫu phức tạp hơn, sử dụng cách đóng:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Một trình lặp trên các chuỗi con của lát chuỗi này, được phân tách bằng một mẫu, bắt đầu từ cuối chuỗi, bị hạn chế trả về nhiều nhất là các mục `n`.
    ///
    ///
    /// Nếu các chuỗi con `n` được trả về thì chuỗi con cuối cùng (chuỗi con thứ `n`) sẽ chứa phần còn lại của chuỗi.
    ///
    /// [pattern] có thể là `&str`, [`char`], một phần của [`char`] s, hoặc một hàm hoặc bao đóng xác định xem một ký tự có khớp hay không.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Hành vi của trình lặp lại
    ///
    /// Trình lặp được trả về sẽ không được kết thúc kép, vì nó không hiệu quả để hỗ trợ.
    ///
    /// Để tách từ phía trước, phương pháp [`splitn`] có thể được sử dụng.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Các mẫu đơn giản:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Một mẫu phức tạp hơn, sử dụng cách đóng:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Tách chuỗi vào lần xuất hiện đầu tiên của dấu phân cách được chỉ định và trả về tiền tố trước dấu phân tách và hậu tố sau dấu phân cách.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Tách chuỗi vào lần xuất hiện cuối cùng của dấu phân cách được chỉ định và trả về tiền tố trước dấu phân cách và hậu tố sau dấu phân cách.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Một trình lặp trên các kết quả phù hợp rời rạc của một mẫu trong lát chuỗi đã cho.
    ///
    /// [pattern] có thể là `&str`, [`char`], một phần của [`char`] s, hoặc một hàm hoặc bao đóng xác định xem một ký tự có khớp hay không.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Hành vi của trình lặp lại
    ///
    /// Trình lặp được trả về sẽ là [`DoubleEndedIterator`] nếu mẫu cho phép tìm kiếm ngược và tìm kiếm forward/reverse mang lại các phần tử giống nhau.
    /// Điều này đúng với, ví dụ: [`char`], nhưng không đúng với `&str`.
    ///
    /// Nếu mẫu cho phép tìm kiếm ngược nhưng kết quả của nó có thể khác với tìm kiếm thuận, phương pháp [`rmatches`] có thể được sử dụng.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Một trình lặp trên các kết quả phù hợp rời rạc của một mẫu trong lát chuỗi này, được tạo ra theo thứ tự ngược lại.
    ///
    /// [pattern] có thể là `&str`, [`char`], một phần của [`char`] s, hoặc một hàm hoặc bao đóng xác định xem một ký tự có khớp hay không.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Hành vi của trình lặp lại
    ///
    /// Trình lặp được trả về yêu cầu mẫu hỗ trợ tìm kiếm ngược và nó sẽ là [`DoubleEndedIterator`] nếu tìm kiếm forward/reverse mang lại các phần tử giống nhau.
    ///
    ///
    /// Để lặp lại từ phía trước, phương pháp [`matches`] có thể được sử dụng.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Một trình lặp trên các kết quả phù hợp rời rạc của một mẫu trong lát chuỗi này cũng như chỉ mục mà kết hợp bắt đầu ở đó.
    ///
    /// Đối với các trận đấu của `pat` trong `self` trùng lặp, chỉ các chỉ số tương ứng với trận đấu đầu tiên được trả về.
    ///
    /// [pattern] có thể là `&str`, [`char`], một phần của [`char`] s, hoặc một hàm hoặc bao đóng xác định xem một ký tự có khớp hay không.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Hành vi của trình lặp lại
    ///
    /// Trình lặp được trả về sẽ là [`DoubleEndedIterator`] nếu mẫu cho phép tìm kiếm ngược và tìm kiếm forward/reverse mang lại các phần tử giống nhau.
    /// Điều này đúng với, ví dụ: [`char`], nhưng không đúng với `&str`.
    ///
    /// Nếu mẫu cho phép tìm kiếm ngược nhưng kết quả của nó có thể khác với tìm kiếm thuận, phương pháp [`rmatch_indices`] có thể được sử dụng.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // chỉ có `aba` đầu tiên
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Một trình lặp trên các kết quả phù hợp riêng biệt của một mẫu trong `self`, mang lại thứ tự ngược lại cùng với chỉ số của kết quả phù hợp.
    ///
    /// Đối với các trận đấu của `pat` trong `self` trùng lặp, chỉ các chỉ số tương ứng với trận đấu cuối cùng được trả về.
    ///
    /// [pattern] có thể là `&str`, [`char`], một phần của [`char`] s, hoặc một hàm hoặc bao đóng xác định xem một ký tự có khớp hay không.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Hành vi của trình lặp lại
    ///
    /// Trình lặp được trả về yêu cầu mẫu hỗ trợ tìm kiếm ngược và nó sẽ là [`DoubleEndedIterator`] nếu tìm kiếm forward/reverse mang lại các phần tử giống nhau.
    ///
    ///
    /// Để lặp lại từ phía trước, phương pháp [`match_indices`] có thể được sử dụng.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // chỉ có `aba` cuối cùng
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Trả về một lát chuỗi với khoảng trắng ở đầu và cuối bị xóa.
    ///
    /// 'Whitespace' được định nghĩa theo các điều khoản của Thuộc tính lõi có nguồn gốc Unicode `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Trả về một lát chuỗi với khoảng trắng ở đầu đã bị loại bỏ.
    ///
    /// 'Whitespace' được định nghĩa theo các điều khoản của Thuộc tính lõi có nguồn gốc Unicode `White_Space`.
    ///
    /// # Hướng văn bản
    ///
    /// Một chuỗi là một chuỗi các byte.
    /// `start` trong ngữ cảnh này có nghĩa là vị trí đầu tiên của chuỗi byte đó;đối với ngôn ngữ từ trái sang phải như tiếng Anh hoặc tiếng Nga, đây sẽ là phía bên trái và đối với các ngôn ngữ từ phải sang trái như tiếng Ả Rập hoặc tiếng Do Thái, đây sẽ là phía bên phải.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Trả về một lát chuỗi đã loại bỏ khoảng trắng ở cuối.
    ///
    /// 'Whitespace' được định nghĩa theo các điều khoản của Thuộc tính lõi có nguồn gốc Unicode `White_Space`.
    ///
    /// # Hướng văn bản
    ///
    /// Một chuỗi là một chuỗi các byte.
    /// `end` trong ngữ cảnh này có nghĩa là vị trí cuối cùng của chuỗi byte đó;đối với ngôn ngữ từ trái sang phải như tiếng Anh hoặc tiếng Nga, đây sẽ là phía bên phải và đối với các ngôn ngữ từ phải sang trái như tiếng Ả Rập hoặc tiếng Do Thái, đây sẽ là phía bên trái.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Trả về một lát chuỗi với khoảng trắng ở đầu đã bị loại bỏ.
    ///
    /// 'Whitespace' được định nghĩa theo các điều khoản của Thuộc tính lõi có nguồn gốc Unicode `White_Space`.
    ///
    /// # Hướng văn bản
    ///
    /// Một chuỗi là một chuỗi các byte.
    /// 'Left' trong ngữ cảnh này có nghĩa là vị trí đầu tiên của chuỗi byte đó;đối với một ngôn ngữ như tiếng Ả Rập hoặc tiếng Do Thái là 'phải sang trái' chứ không phải 'từ trái sang phải', đây sẽ là bên _right_, không phải bên trái.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Trả về một lát chuỗi đã loại bỏ khoảng trắng ở cuối.
    ///
    /// 'Whitespace' được định nghĩa theo các điều khoản của Thuộc tính lõi có nguồn gốc Unicode `White_Space`.
    ///
    /// # Hướng văn bản
    ///
    /// Một chuỗi là một chuỗi các byte.
    /// 'Right' trong ngữ cảnh này có nghĩa là vị trí cuối cùng của chuỗi byte đó;đối với một ngôn ngữ như tiếng Ả Rập hoặc tiếng Do Thái là 'từ phải sang trái' chứ không phải 'từ trái sang phải', đây sẽ là bên _left_, không phải bên phải.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Trả về một lát chuỗi có tất cả các tiền tố và hậu tố khớp với một mẫu được xóa nhiều lần.
    ///
    /// [pattern] có thể là [`char`], một phần của [`char`] s, hoặc một hàm hoặc bao đóng xác định xem một ký tự có khớp hay không.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Các mẫu đơn giản:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Một mẫu phức tạp hơn, sử dụng cách đóng:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Hãy nhớ trận đấu đã biết sớm nhất, hãy sửa nó bên dưới nếu
            // trận đấu cuối cùng khác
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // AN TOÀN: `Searcher` được biết là trả về các chỉ số hợp lệ.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Trả về một lát chuỗi có tất cả các tiền tố phù hợp với một mẫu bị xóa nhiều lần.
    ///
    /// [pattern] có thể là `&str`, [`char`], một phần của [`char`] s, hoặc một hàm hoặc bao đóng xác định xem một ký tự có khớp hay không.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Hướng văn bản
    ///
    /// Một chuỗi là một chuỗi các byte.
    /// `start` trong ngữ cảnh này có nghĩa là vị trí đầu tiên của chuỗi byte đó;đối với ngôn ngữ từ trái sang phải như tiếng Anh hoặc tiếng Nga, đây sẽ là phía bên trái và đối với các ngôn ngữ từ phải sang trái như tiếng Ả Rập hoặc tiếng Do Thái, đây sẽ là phía bên phải.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // AN TOÀN: `Searcher` được biết là trả về các chỉ số hợp lệ.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Trả về một lát chuỗi đã xóa tiền tố.
    ///
    /// Nếu chuỗi bắt đầu bằng mẫu `prefix`, trả về chuỗi con sau tiền tố, được bao bọc trong `Some`.
    /// Không giống như `trim_start_matches`, phương pháp này loại bỏ tiền tố chính xác một lần.
    ///
    /// Nếu chuỗi không bắt đầu bằng `prefix`, trả về `None`.
    ///
    /// [pattern] có thể là `&str`, [`char`], một phần của [`char`] s, hoặc một hàm hoặc bao đóng xác định xem một ký tự có khớp hay không.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Trả về một lát chuỗi đã xóa hậu tố.
    ///
    /// Nếu chuỗi kết thúc bằng mẫu `suffix`, trả về chuỗi con trước hậu tố, được bao bọc trong `Some`.
    /// Không giống như `trim_end_matches`, phương pháp này loại bỏ hậu tố chính xác một lần.
    ///
    /// Nếu chuỗi không kết thúc bằng `suffix`, trả về `None`.
    ///
    /// [pattern] có thể là `&str`, [`char`], một phần của [`char`] s, hoặc một hàm hoặc bao đóng xác định xem một ký tự có khớp hay không.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Trả về một lát chuỗi có tất cả các hậu tố phù hợp với một mẫu bị xóa nhiều lần.
    ///
    /// [pattern] có thể là `&str`, [`char`], một phần của [`char`] s, hoặc một hàm hoặc bao đóng xác định xem một ký tự có khớp hay không.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Hướng văn bản
    ///
    /// Một chuỗi là một chuỗi các byte.
    /// `end` trong ngữ cảnh này có nghĩa là vị trí cuối cùng của chuỗi byte đó;đối với ngôn ngữ từ trái sang phải như tiếng Anh hoặc tiếng Nga, đây sẽ là phía bên phải và đối với các ngôn ngữ từ phải sang trái như tiếng Ả Rập hoặc tiếng Do Thái, đây sẽ là phía bên trái.
    ///
    ///
    /// # Examples
    ///
    /// Các mẫu đơn giản:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Một mẫu phức tạp hơn, sử dụng cách đóng:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // AN TOÀN: `Searcher` được biết là trả về các chỉ số hợp lệ.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Trả về một lát chuỗi có tất cả các tiền tố phù hợp với một mẫu bị xóa nhiều lần.
    ///
    /// [pattern] có thể là `&str`, [`char`], một phần của [`char`] s, hoặc một hàm hoặc bao đóng xác định xem một ký tự có khớp hay không.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Hướng văn bản
    ///
    /// Một chuỗi là một chuỗi các byte.
    /// 'Left' trong ngữ cảnh này có nghĩa là vị trí đầu tiên của chuỗi byte đó;đối với một ngôn ngữ như tiếng Ả Rập hoặc tiếng Do Thái là 'phải sang trái' chứ không phải 'từ trái sang phải', đây sẽ là bên _right_, không phải bên trái.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Trả về một lát chuỗi có tất cả các hậu tố phù hợp với một mẫu bị xóa nhiều lần.
    ///
    /// [pattern] có thể là `&str`, [`char`], một phần của [`char`] s, hoặc một hàm hoặc bao đóng xác định xem một ký tự có khớp hay không.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Hướng văn bản
    ///
    /// Một chuỗi là một chuỗi các byte.
    /// 'Right' trong ngữ cảnh này có nghĩa là vị trí cuối cùng của chuỗi byte đó;đối với một ngôn ngữ như tiếng Ả Rập hoặc tiếng Do Thái là 'từ phải sang trái' chứ không phải 'từ trái sang phải', đây sẽ là bên _left_, không phải bên phải.
    ///
    ///
    /// # Examples
    ///
    /// Các mẫu đơn giản:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Một mẫu phức tạp hơn, sử dụng cách đóng:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Phân tích đoạn chuỗi này thành một kiểu khác.
    ///
    /// Vì `parse` quá chung chung nên nó có thể gây ra vấn đề với kiểu suy luận.
    /// Do đó, `parse` là một trong số ít lần bạn sẽ thấy cú pháp được gọi một cách trìu mến là 'turbofish': `::<>`.
    ///
    /// Điều này giúp thuật toán suy luận hiểu cụ thể loại mà bạn đang cố gắng phân tích cú pháp.
    ///
    /// `parse` có thể phân tích cú pháp thành bất kỳ kiểu nào triển khai [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// Sẽ trả về [`Err`] nếu không thể phân tích cú pháp chuỗi này thành kiểu mong muốn.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Sử dụng 'turbofish' thay vì chú thích `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Không phân tích được:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Kiểm tra xem tất cả các ký tự trong chuỗi này có nằm trong phạm vi ASCII hay không.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Chúng ta có thể coi mỗi byte là một ký tự ở đây: tất cả các ký tự nhiều byte bắt đầu bằng một byte không nằm trong phạm vi ascii, vì vậy chúng ta sẽ dừng lại ở đó.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Kiểm tra xem hai chuỗi có phải là đối sánh không phân biệt chữ hoa chữ thường ASCII hay không.
    ///
    /// Tương tự như `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, nhưng không phân bổ và sao chép các khoảng thời gian tạm thời.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Chuyển đổi chuỗi này thành dạng chữ hoa ASCII tương đương tại chỗ.
    ///
    /// Các chữ cái ASCII 'a' đến 'z' được ánh xạ thành 'A' đến 'Z', nhưng các chữ cái không phải ASCII thì không thay đổi.
    ///
    /// Để trả về một giá trị viết hoa mới mà không sửa đổi giá trị hiện có, hãy sử dụng [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // AN TOÀN: an toàn vì chúng tôi chuyển đổi hai loại với cùng một bố cục.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Chuyển đổi chuỗi này thành ký tự viết thường ASCII tương đương tại chỗ.
    ///
    /// Các chữ cái ASCII 'A' đến 'Z' được ánh xạ thành 'a' đến 'z', nhưng các chữ cái không phải ASCII thì không thay đổi.
    ///
    /// Để trả về một giá trị chữ thường mới mà không sửa đổi giá trị hiện có, hãy sử dụng [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // AN TOÀN: an toàn vì chúng tôi chuyển đổi hai loại với cùng một bố cục.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Trả lại một trình lặp thoát từng ký tự trong `self` với [`char::escape_debug`].
    ///
    ///
    /// Note: chỉ codepoint grapheme mở rộng bắt đầu chuỗi sẽ bị thoát.
    ///
    /// # Examples
    ///
    /// Là một trình lặp:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Sử dụng `println!` trực tiếp:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Cả hai đều tương đương với:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Sử dụng `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Trả lại một trình lặp thoát từng ký tự trong `self` với [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Là một trình lặp:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Sử dụng `println!` trực tiếp:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Cả hai đều tương đương với:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Sử dụng `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Trả lại một trình lặp thoát từng ký tự trong `self` với [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Là một trình lặp:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Sử dụng `println!` trực tiếp:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Cả hai đều tương đương với:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Sử dụng `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Tạo một str trống
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Tạo một str có thể thay đổi trống
    #[inline]
    fn default() -> Self {
        // AN TOÀN: Chuỗi trống là UTF-8 hợp lệ.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Một loại fn có thể đặt tên, có thể sao chép
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // AN TOÀN: không an toàn
        unsafe { from_utf8_unchecked(bytes) }
    };
}