//! API mẫu chuỗi.
//!
//! API mẫu cung cấp một cơ chế chung để sử dụng các loại mẫu khác nhau khi tìm kiếm thông qua một chuỗi.
//!
//! Để biết thêm chi tiết, hãy xem traits [`Pattern`], [`Searcher`], [`ReverseSearcher`] và [`DoubleEndedSearcher`].
//!
//! Mặc dù API này không ổn định, nhưng nó được hiển thị thông qua các API ổn định trên loại [`str`].
//!
//! # Examples
//!
//! [`Pattern`] là [implemented][pattern-impls] trong API ổn định cho [`&str`][`str`], [`char`], các lát cắt của [`char`] và các hàm và các hàm đóng thực thi `FnMut(char) -> bool`.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // mẫu char
//! assert_eq!(s.find('n'), Some(2));
//! // mô hình lát ký tự
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // mô hình đóng cửa
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Một mẫu chuỗi.
///
/// `Pattern<'a>` thể hiện rằng kiểu triển khai có thể được sử dụng làm mẫu chuỗi để tìm kiếm trong [`&'a str`][str].
///
/// Ví dụ: cả `'a'` và `"aa"` là các mẫu sẽ khớp với chỉ mục `1` trong chuỗi `"baaaab"`.
///
/// Bản thân trait hoạt động như một trình tạo cho kiểu [`Searcher`] được liên kết, thực hiện công việc thực tế là tìm kiếm các lần xuất hiện của mẫu trong một chuỗi.
///
///
/// Tùy thuộc vào loại mẫu, hành vi của các phương thức như [`str::find`] và [`str::contains`] có thể thay đổi.
/// Bảng dưới đây mô tả một số hành vi đó.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Người tìm kiếm được liên kết cho mẫu này
    type Searcher: Searcher<'a>;

    /// Xây dựng trình tìm kiếm được liên kết từ `self` và `haystack` để tìm kiếm.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Kiểm tra xem mẫu có khớp với bất kỳ vị trí nào trong đống cỏ khô hay không
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Kiểm tra xem mẫu có khớp ở mặt trước của đống cỏ khô hay không
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Kiểm tra xem mẫu có khớp ở mặt sau của đống cỏ khô hay không
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Xóa mẫu khỏi mặt trước của đống cỏ khô, nếu nó khớp.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // AN TOÀN: `Searcher` được biết là trả về các chỉ số hợp lệ.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Loại bỏ mẫu khỏi mặt sau của đống cỏ khô, nếu nó khớp.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // AN TOÀN: `Searcher` được biết là trả về các chỉ số hợp lệ.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Kết quả gọi [`Searcher::next()`] hoặc [`ReverseSearcher::next_back()`].
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Biểu thị rằng khớp của mẫu đã được tìm thấy ở `haystack[a..b]`.
    ///
    Match(usize, usize),
    /// Biểu thị rằng `haystack[a..b]` đã bị từ chối khi có thể có một mẫu phù hợp.
    ///
    /// Lưu ý rằng có thể có nhiều hơn một `Reject` giữa hai `trận đấu '', không có yêu cầu nào để chúng được kết hợp thành một.
    ///
    ///
    Reject(usize, usize),
    /// Biểu thị rằng mọi byte của đống cỏ khô đã được truy cập, kết thúc quá trình lặp.
    ///
    Done,
}

/// Người tìm kiếm một mẫu chuỗi.
///
/// trait này cung cấp các phương pháp tìm kiếm các kết quả phù hợp không chồng chéo của một mẫu bắt đầu từ (left) phía trước của một chuỗi.
///
/// Nó sẽ được thực hiện bởi các loại `Searcher` liên quan của [`Pattern`] trait.
///
/// trait được đánh dấu là không an toàn vì các chỉ số được trả về bởi các phương thức [`next()`][Searcher::next] bắt buộc phải nằm trên các ranh giới utf8 hợp lệ trong đống cỏ khô.
/// Điều này cho phép người tiêu dùng trait này cắt đống cỏ khô mà không cần kiểm tra thời gian chạy bổ sung.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter cho chuỗi cơ bản được tìm kiếm trong
    ///
    /// Sẽ luôn trả về cùng một [`&str`][str].
    fn haystack(&self) -> &'a str;

    /// Thực hiện bước tìm kiếm tiếp theo bắt đầu từ phía trước.
    ///
    /// - Trả về [`Match(a, b)`][SearchStep::Match] nếu `haystack[a..b]` khớp với mẫu.
    /// - Trả về [`Reject(a, b)`][SearchStep::Reject] nếu `haystack[a..b]` không thể khớp với mẫu, thậm chí một phần.
    /// - Trả về [`Done`][SearchStep::Done] nếu mọi byte của đống cỏ khô đã được truy cập.
    ///
    /// Luồng các giá trị [`Match`][SearchStep::Match] và [`Reject`][SearchStep::Reject] lên đến [`Done`][SearchStep::Done] sẽ chứa các phạm vi chỉ mục liền kề, không chồng chéo, bao phủ toàn bộ đống cỏ khô và nằm trên ranh giới utf8.
    ///
    ///
    /// Kết quả [`Match`][SearchStep::Match] cần phải chứa toàn bộ mẫu phù hợp, tuy nhiên, kết quả [`Reject`][SearchStep::Reject] có thể được chia thành nhiều đoạn liền kề tùy ý.Cả hai phạm vi có thể có độ dài bằng không.
    ///
    /// Ví dụ: mẫu `"aaa"` và đống cỏ khô `"cbaaaaab"` có thể tạo ra luồng
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Tìm kết quả [`Match`][SearchStep::Match] tiếp theo.Xem [`next()`][Searcher::next].
    ///
    /// Không giống như [`next()`][Searcher::next], không có gì đảm bảo rằng phạm vi trả về của điều này và [`next_reject`][Searcher::next_reject] sẽ trùng nhau.
    /// Điều này sẽ trả về `(start_match, end_match)`, trong đó start_match là chỉ số nơi trận đấu bắt đầu và end_match là chỉ số sau khi kết thúc trận đấu.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Tìm kết quả [`Reject`][SearchStep::Reject] tiếp theo.Xem [`next()`][Searcher::next] và [`next_match()`][Searcher::next_match].
    ///
    /// Không giống như [`next()`][Searcher::next], không có gì đảm bảo rằng phạm vi trả về của điều này và [`next_match`][Searcher::next_match] sẽ trùng nhau.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Trình tìm kiếm ngược lại cho một mẫu chuỗi.
///
/// trait này cung cấp các phương pháp tìm kiếm các kết quả phù hợp không chồng chéo của một mẫu bắt đầu từ (right) trở lại của một chuỗi.
///
/// Nó sẽ được thực hiện bởi các loại [`Searcher`] liên quan của [`Pattern`] trait nếu mẫu hỗ trợ tìm kiếm nó từ phía sau.
///
///
/// Các phạm vi chỉ mục được trả về bởi trait này không bắt buộc phải khớp chính xác với các phạm vi của tìm kiếm thuận ngược lại.
///
/// Để biết lý do tại sao trait này được đánh dấu là không an toàn, hãy xem trait [`Searcher`] chính của chúng.
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Thực hiện bước tìm kiếm tiếp theo bắt đầu từ phía sau.
    ///
    /// - Trả về [`Match(a, b)`][SearchStep::Match] nếu `haystack[a..b]` khớp với mẫu.
    /// - Trả về [`Reject(a, b)`][SearchStep::Reject] nếu `haystack[a..b]` không thể khớp với mẫu, thậm chí một phần.
    /// - Trả về [`Done`][SearchStep::Done] nếu mọi byte của đống cỏ khô đã được truy cập
    ///
    /// Luồng các giá trị [`Match`][SearchStep::Match] và [`Reject`][SearchStep::Reject] lên đến [`Done`][SearchStep::Done] sẽ chứa các phạm vi chỉ mục liền kề, không chồng chéo, bao phủ toàn bộ đống cỏ khô và nằm trên ranh giới utf8.
    ///
    ///
    /// Kết quả [`Match`][SearchStep::Match] cần phải chứa toàn bộ mẫu phù hợp, tuy nhiên, kết quả [`Reject`][SearchStep::Reject] có thể được chia thành nhiều đoạn liền kề tùy ý.Cả hai phạm vi có thể có độ dài bằng không.
    ///
    /// Ví dụ: mẫu `"aaa"` và đống cỏ khô `"cbaaaaab"` có thể tạo ra dòng `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Tìm kết quả [`Match`][SearchStep::Match] tiếp theo.
    /// Xem [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Tìm kết quả [`Reject`][SearchStep::Reject] tiếp theo.
    /// Xem [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Điểm đánh dấu trait để thể hiện rằng [`ReverseSearcher`] có thể được sử dụng để triển khai [`DoubleEndedIterator`].
///
/// Đối với điều này, việc cấy ghép [`Searcher`] và [`ReverseSearcher`] cần tuân theo các điều kiện sau:
///
/// - Tất cả các kết quả của `next()` cần phải giống với kết quả của `next_back()` theo thứ tự ngược lại.
/// - `next()` và `next_back()` cần phải hoạt động như hai đầu của một dải giá trị, tức là chúng không thể "walk past each other".
///
/// # Examples
///
/// `char::Searcher` là `DoubleEndedSearcher` vì việc tìm kiếm [`char`] chỉ yêu cầu xem xét từng thứ một, hoạt động giống nhau từ cả hai đầu.
///
/// `(&str)::Searcher` không phải là `DoubleEndedSearcher` vì mẫu `"aa"` trong đống cỏ khô `"aaa"` khớp với `"[aa]a"` hoặc `"a[aa]"`, tùy thuộc vào phía mà nó được tìm kiếm.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Impl cho char
/////////////////////////////////////////////////////////////////////////////

/// Loại liên kết cho `<char as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // bất biến an toàn: `finger`/`finger_back` phải là chỉ mục byte utf8 hợp lệ của `haystack` Bất biến này có thể bị phá vỡ *trong* next_match và next_match_back, tuy nhiên chúng phải thoát ra bằng ngón tay trên ranh giới điểm mã hợp lệ.
    //
    //
    /// `finger` là chỉ số byte hiện tại của tìm kiếm chuyển tiếp.
    /// Hãy tưởng tượng rằng nó tồn tại trước byte tại chỉ mục của nó, tức là
    /// `haystack[finger]` là byte đầu tiên của lát cắt mà chúng ta phải kiểm tra trong quá trình tìm kiếm chuyển tiếp
    ///
    finger: usize,
    /// `finger_back` là chỉ số byte hiện tại của tìm kiếm ngược.
    /// Hãy tưởng tượng rằng nó tồn tại sau byte tại chỉ mục của nó, tức là
    /// haystack [finger_back, 1] là byte cuối cùng của lát cắt mà chúng ta phải kiểm tra trong quá trình tìm kiếm chuyển tiếp (và do đó là byte đầu tiên được kiểm tra khi gọi next_back()).
    ///
    finger_back: usize,
    /// Nhân vật đang được tìm kiếm
    needle: char,

    // bất biến an toàn: `utf8_size` phải nhỏ hơn 5
    /// Số byte `needle` chiếm khi được mã hóa bằng utf8.
    utf8_size: usize,
    /// Bản sao được mã hóa utf8 của `needle`
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // AN TOÀN: 1-4 đảm bảo an toàn của `get_unchecked`
        // 1. `self.finger` và `self.finger_back` được giữ trên ranh giới unicode (điều này là bất biến)
        // 2. `self.finger >= 0` vì nó bắt đầu từ 0 và chỉ tăng
        // 3. `self.finger < self.finger_back` bởi vì nếu không thì char `iter` sẽ trả về `SearchStep::Done`
        // 4.
        // `self.finger` đến trước khi kết thúc đống cỏ khô vì `self.finger_back` bắt đầu ở cuối và chỉ giảm
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // thêm độ lệch byte của ký tự hiện tại mà không cần mã hóa lại thành utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // lấy đống cỏ khô sau khi ký tự cuối cùng được tìm thấy
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // byte cuối cùng của kim được mã hóa utf8 AN TOÀN: chúng tôi có một bất biến là `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Ngón tay mới là chỉ số của byte mà chúng tôi tìm thấy, cộng với một, vì chúng tôi ghi nhớ byte cuối cùng của ký tự.
                //
                // Lưu ý rằng điều này không phải lúc nào cũng cung cấp cho chúng ta một ngón tay trên ranh giới UTF8.
                // Nếu chúng tôi *không* tìm thấy ký tự của mình, chúng tôi có thể đã lập chỉ mục đến byte không phải cuối cùng của ký tự 3 byte hoặc 4 byte.
                // Chúng ta không thể bỏ qua byte bắt đầu hợp lệ tiếp theo vì một ký tự như ꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` sẽ yêu cầu chúng ta luôn tìm thấy byte thứ hai khi tìm kiếm thứ ba.
                //
                //
                // Tuy nhiên, điều này là hoàn toàn ổn.
                // Mặc dù chúng ta có bất biến mà self.finger nằm trên ranh giới UTF8, nhưng bất biến này không được dựa vào trong phương pháp này (nó được dựa vào trong CharSearcher::next()).
                //
                // Chúng tôi chỉ thoát khỏi phương thức này khi chúng tôi đến cuối chuỗi hoặc nếu chúng tôi tìm thấy thứ gì đó.Khi chúng tôi tìm thấy thứ gì đó, `finger` sẽ được đặt thành ranh giới UTF8.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // không tìm thấy gì, thoát ra
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // hãy để next_reject sử dụng triển khai mặc định từ Searcher trait
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // AN TOÀN: xem nhận xét cho next() ở trên
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // trừ độ lệch byte của ký tự hiện tại mà không cần mã hóa lại thành utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // có được đống cỏ khô nhưng không bao gồm ký tự cuối cùng được tìm kiếm
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // byte cuối cùng của kim được mã hóa utf8 AN TOÀN: chúng tôi có một bất biến là `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // chúng tôi đã tìm kiếm một lát được bù đắp bởi self.finger, thêm self.finger để bù lại chỉ mục ban đầu
                //
                let index = self.finger + index;
                // memrchr sẽ trả về chỉ mục của byte mà chúng ta muốn tìm.
                // Trong trường hợp một ký tự ASCII, điều này thực sự là chúng tôi mong muốn ngón tay mới của chúng tôi là ("after" ký tự được tìm thấy trong mô hình lặp lại ngược).
                //
                // Đối với các ký tự nhiều byte, chúng ta cần bỏ qua số byte mà chúng có nhiều hơn ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // di chuyển ngón tay đến trước khi tìm thấy ký tự (tức là ở chỉ mục bắt đầu của nó)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Chúng tôi không thể sử dụng finger_back=index, size + 1 ở đây.
                // Nếu chúng tôi tìm thấy ký tự cuối cùng của một ký tự có kích thước khác (hoặc byte giữa của một ký tự khác), chúng tôi cần chuyển finger_back xuống `index`.
                // Điều này tương tự làm cho `finger_back` có khả năng không còn ở trên một ranh giới nữa, nhưng điều này là OK vì chúng tôi chỉ thoát khỏi chức năng này trên một ranh giới hoặc khi đống cỏ khô đã được tìm kiếm hoàn toàn.
                //
                //
                // Không giống như next_match, điều này không có vấn đề về các byte lặp lại trong utf-8 vì chúng tôi đang tìm kiếm byte cuối cùng và chúng tôi chỉ có thể tìm thấy byte cuối cùng khi tìm kiếm ngược lại.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // không tìm thấy gì, thoát ra
                return None;
            }
        }
    }

    // hãy để next_reject_back sử dụng triển khai mặc định từ Searcher trait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Tìm kiếm các ký tự bằng [`char`] nhất định.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Impl cho một trình bao bọc MultiCharEq
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // So sánh độ dài của trình lặp lát byte bên trong để tìm độ dài của ký tự hiện tại
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // So sánh độ dài của trình lặp lát byte bên trong để tìm độ dài của ký tự hiện tại
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Impl cho&[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: Thay đổi/Loại bỏ do ý nghĩa không rõ ràng.

/// Loại liên kết cho `<&[char] as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Tìm kiếm các ký tự bằng với bất kỳ [`char`] nào trong lát.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl cho F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Loại liên kết cho `<F as Pattern<'a>>::Searcher`.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Tìm kiếm [`char`] phù hợp với vị từ đã cho.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl cho&&str
/////////////////////////////////////////////////////////////////////////////

/// Đại diện cho cấy ghép `&str`.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Impl cho &str
/////////////////////////////////////////////////////////////////////////////

/// Tìm kiếm chuỗi con không phân bổ.
///
/// Sẽ xử lý mẫu `""` khi trả về các kết quả trống ở mỗi ranh giới ký tự.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Kiểm tra xem mẫu có khớp ở mặt trước của đống cỏ khô hay không.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Xóa mẫu khỏi mặt trước của đống cỏ khô, nếu nó khớp.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // AN TOÀN: tiền tố vừa được xác minh là tồn tại.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Kiểm tra xem mẫu có khớp ở mặt sau của đống cỏ khô hay không.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Loại bỏ mẫu khỏi mặt sau của đống cỏ khô, nếu nó khớp.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // AN TOÀN: hậu tố vừa được xác minh là tồn tại.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Trình tìm kiếm chuỗi con hai chiều
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Loại liên kết cho `<&str as Pattern<'a>>::Searcher`.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // kim rỗng từ chối mọi ký tự và khớp với mọi chuỗi trống giữa chúng
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher tạo ra các chỉ số *Khớp* hợp lệ phân chia theo ranh giới ký tự miễn là nó khớp chính xác và đống cỏ khô và kim là hợp lệ UTF-8 *Từ chối* từ thuật toán có thể rơi vào bất kỳ chỉ số nào, nhưng chúng tôi sẽ đưa chúng theo cách thủ công đến ranh giới ký tự tiếp theo, để chúng được an toàn utf-8.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // bỏ qua ranh giới ký tự tiếp theo
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // viết ra các trường hợp `true` và `false` để khuyến khích trình biên dịch chuyên biệt hóa hai trường hợp này.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // bỏ qua ranh giới ký tự tiếp theo
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // viết ra `true` và `false`, như `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// Trạng thái bên trong của thuật toán tìm kiếm chuỗi con hai chiều.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// chỉ số phân tích nhân tử quan trọng
    crit_pos: usize,
    /// chỉ số phân tích nhân tử quan trọng cho kim quay ngược
    crit_pos_back: usize,
    period: usize,
    /// `byteset` là một phần mở rộng (không phải là một phần của thuật toán hai chiều);
    /// đó là "fingerprint" 64-bit trong đó mỗi bit đặt `j` tương ứng với một (byte&63)==j hiện diện trong kim.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// chỉ mục vào kim mà trước đó chúng tôi đã khớp
    memory: usize,
    /// chỉ mục vào kim mà sau đó chúng tôi đã khớp
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Có thể tìm thấy lời giải thích đặc biệt dễ đọc về những gì đang diễn ra ở đây trong cuốn sách "Text Algorithms", ch 13 của Crochemore và Rytter.
        // Cụ thể, hãy xem mã cho "Algorithm CP" trên p.
        // 323.
        //
        // Điều đang xảy ra là chúng ta có một số phân tích nhân tử quan trọng (u, v) của kim, và chúng ta muốn xác định xem u có phải là hậu tố của&v [.. period] hay không.
        // Nếu có, chúng tôi sử dụng "Algorithm CP1".
        // Nếu không, chúng tôi sử dụng "Algorithm CP2", được tối ưu hóa khi chu kỳ của kim lớn.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // trường hợp chu kỳ ngắn-chu kỳ được tính toán chính xác một thừa số tới hạn riêng biệt cho kim quay ngược x=u 'v' trong đó | v '|<period(x).
            //
            // Điều này được đẩy nhanh bởi khoảng thời gian đã được biết trước.
            // Lưu ý rằng trường hợp như x= "acba" có thể được tính giai đoạn chính xác về phía trước (crit_pos=1, period=3) trong khi được tính giai đoạn gần đúng với chu kỳ ngược lại (crit_pos=2, period=2).
            // Chúng tôi sử dụng thừa số hóa ngược đã cho nhưng giữ khoảng thời gian chính xác.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // trường hợp dài-chúng tôi có giá trị gần đúng với khoảng thời gian thực tế và không sử dụng ghi nhớ.
            //
            //
            // Ước tính khoảng thời gian theo giới hạn dưới max(|u|, |v|) + 1.
            // Việc phân tích nhân tử quan trọng là hiệu quả để sử dụng cho cả tìm kiếm thuận và ngược.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Giá trị giả để biểu thị rằng khoảng thời gian dài
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Một trong những ý tưởng chính của Two-Way là chúng ta phân tích kim thành hai nửa, (u, v), và bắt đầu cố gắng tìm v trong đống cỏ khô bằng cách quét từ trái sang phải.
    // Nếu v khớp, chúng tôi cố gắng so khớp u bằng cách quét từ phải sang trái.
    // Chúng ta có thể nhảy bao xa khi gặp sự không khớp tất cả đều dựa trên thực tế rằng (u, v) là một thừa số hóa quan trọng đối với kim.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` sử dụng `self.position` làm con trỏ của nó
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Kiểm tra để đảm bảo rằng chúng ta có chỗ để tìm kiếm ở vị trí + kim_lương không thể tràn nếu chúng ta giả sử các lát được giới hạn bởi phạm vi của isize.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Nhanh chóng bỏ qua các phần lớn không liên quan đến chuỗi con của chúng tôi
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Xem phần bên phải của kim có khớp không
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Xem phần bên trái của kim có khớp nhau không
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Chúng tôi đã tìm thấy một sự phù hợp!
            let match_pos = self.position;

            // Note: thêm self.period thay vì needle.len() để có các kết quả trùng khớp
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // đặt thành needle.len(), self.period cho các kết quả trùng khớp
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Thực hiện theo các ý tưởng trong `next()`.
    //
    // Các định nghĩa là đối xứng, với period(x) = period(reverse(x)) và local_period(u, v) = local_period(reverse(v), reverse(u)), vì vậy nếu (u, v) là một thừa số quan trọng, thì (reverse(v) cũng vậy, reverse(u)).
    //
    //
    // Đối với trường hợp ngược lại, chúng tôi đã tính toán một thừa số quan trọng x=u 'v' (trường `crit_pos_back`).Chúng tôi cần | u |<period(x) cho trường hợp phía trước và do đó | v '|<period(x) cho chiều ngược lại.
    //
    // Để tìm kiếm ngược qua đống cỏ khô, chúng ta tìm kiếm ngược lại qua đống cỏ khô đã đảo ngược với kim quay ngược, khớp với u 'đầu tiên và sau đó là v'.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` sử dụng `self.end` làm con trỏ của nó-để `next()` và `next_back()` độc lập.
        //
        let old_end = self.end;
        'search: loop {
            // Cuối cùng, hãy kiểm tra để đảm bảo rằng chúng ta có chỗ để tìm kiếm, needle.len() sẽ quấn quanh khi không còn chỗ nữa, nhưng do giới hạn chiều dài lát cắt, nó không bao giờ có thể quấn hết chiều dài của đống cỏ khô.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Nhanh chóng bỏ qua các phần lớn không liên quan đến chuỗi con của chúng tôi
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Xem phần bên trái của kim có khớp nhau không
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Xem phần bên phải của kim có khớp không
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Chúng tôi đã tìm thấy một sự phù hợp!
            let match_pos = self.end - needle.len();
            // Note: phụ self.period thay vì needle.len() để có các kết quả trùng khớp
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Tính hậu tố tối đa của `arr`.
    //
    // Hậu tố tối đa là một thừa số hóa quan trọng có thể có (u, v) của `arr`.
    //
    // Trả về (`i`, `p`) trong đó `i` là chỉ số bắt đầu của v và `p` là khoảng thời gian của v.
    //
    // `order_greater` xác định xem thứ tự từ vựng là `<` hay `>`.
    // Cả hai đơn đặt hàng đều phải được tính toán-đơn đặt hàng với `i` lớn nhất đưa ra một phân tích nhân tử quan trọng.
    //
    //
    // Đối với các trường hợp thời gian dài, khoảng thời gian kết quả không chính xác (nó quá ngắn).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Tương ứng với tôi trong bài báo
        let mut right = 1; // Tương ứng với j trong bài báo
        let mut offset = 0; // Tương ứng với k trong bài báo, nhưng bắt đầu từ 0
        // để phù hợp với lập chỉ mục dựa trên 0.
        let mut period = 1; // Tương ứng với p trong bài báo

        while let Some(&a) = arr.get(right + offset) {
            // `left` sẽ được inbounds khi có `right`.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Hậu tố nhỏ hơn, dấu chấm là toàn bộ tiền tố cho đến nay.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Tiến bộ thông qua sự lặp lại của giai đoạn hiện tại.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Hậu tố lớn hơn, bắt đầu lại từ vị trí hiện tại.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Tính hậu tố lớn nhất của đảo ngược `arr`.
    //
    // Hậu tố cực đại là một thừa số quan trọng có thể có (u ', v') của `arr`.
    //
    // Trả về `i` trong đó `i` là chỉ số bắt đầu của v ', từ phía sau;
    // trả về ngay lập tức khi đạt đến khoảng thời gian `known_period`.
    //
    // `order_greater` xác định xem thứ tự từ vựng là `<` hay `>`.
    // Cả hai đơn đặt hàng đều phải được tính toán-đơn đặt hàng với `i` lớn nhất đưa ra một phân tích nhân tử quan trọng.
    //
    //
    // Đối với các trường hợp thời gian dài, khoảng thời gian kết quả không chính xác (nó quá ngắn).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Tương ứng với tôi trong bài báo
        let mut right = 1; // Tương ứng với j trong bài báo
        let mut offset = 0; // Tương ứng với k trong bài báo, nhưng bắt đầu từ 0
        // để phù hợp với lập chỉ mục dựa trên 0.
        let mut period = 1; // Tương ứng với p trong bài báo
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Hậu tố nhỏ hơn, dấu chấm là toàn bộ tiền tố cho đến nay.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Tiến bộ thông qua sự lặp lại của giai đoạn hiện tại.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Hậu tố lớn hơn, bắt đầu lại từ vị trí hiện tại.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy cho phép thuật toán bỏ qua các nội dung không phù hợp nhanh nhất có thể hoặc hoạt động ở chế độ mà nó phát ra Từ chối tương đối nhanh.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Bỏ qua để khớp các khoảng nhanh nhất có thể
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Gửi từ chối thường xuyên
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}