#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` cho phép người triển khai người thực thi tác vụ tạo [`Waker`] cung cấp hành vi đánh thức tùy chỉnh.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Nó bao gồm một con trỏ dữ liệu và một [virtual function pointer table (vtable)][vtable] tùy chỉnh hành vi của `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Một con trỏ dữ liệu, có thể được sử dụng để lưu trữ dữ liệu tùy ý theo yêu cầu của người thực thi.
    /// Điều này có thể là ví dụ
    /// một con trỏ bị xóa kiểu đến `Arc` được liên kết với nhiệm vụ.
    /// Giá trị của trường này được chuyển cho tất cả các hàm là một phần của vtable dưới dạng tham số đầu tiên.
    ///
    data: *const (),
    /// Bảng con trỏ chức năng ảo tùy chỉnh hành vi của waker này.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Tạo `RawWaker` mới từ con trỏ `data` và `vtable` được cung cấp.
    ///
    /// Con trỏ `data` có thể được sử dụng để lưu trữ dữ liệu tùy ý theo yêu cầu của người thực thi.Điều này có thể là ví dụ
    /// một con trỏ bị xóa kiểu đến `Arc` được liên kết với nhiệm vụ.
    /// Giá trị của con trỏ này sẽ được chuyển cho tất cả các hàm là một phần của `vtable` dưới dạng tham số đầu tiên.
    ///
    /// `vtable` tùy chỉnh hành vi của `Waker` được tạo từ `RawWaker`.
    /// Đối với mỗi thao tác trên `Waker`, hàm liên quan trong `vtable` của `RawWaker` bên dưới sẽ được gọi.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Bảng con trỏ chức năng ảo (vtable) chỉ định hành vi của [`RawWaker`].
///
/// Con trỏ được chuyển đến tất cả các hàm bên trong vtable là con trỏ `data` từ đối tượng [`RawWaker`] bao quanh.
///
/// Các hàm bên trong cấu trúc này chỉ nhằm mục đích được gọi trên con trỏ `data` của một đối tượng [`RawWaker`] được xây dựng đúng cách từ bên trong việc triển khai [`RawWaker`].
/// Việc gọi một trong các hàm chứa bằng bất kỳ con trỏ `data` nào khác sẽ gây ra hành vi không xác định.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Hàm này sẽ được gọi khi [`RawWaker`] được sao chép, ví dụ như khi [`Waker`] mà [`RawWaker`] được lưu trữ bị sao chép.
    ///
    /// Việc triển khai chức năng này phải giữ lại tất cả các tài nguyên cần thiết cho phiên bản bổ sung này của [`RawWaker`] và tác vụ liên quan.
    /// Việc gọi `wake` trên kết quả [`RawWaker`] sẽ dẫn đến việc đánh thức cùng một tác vụ đã được đánh thức bởi [`RawWaker`] ban đầu.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Chức năng này sẽ được gọi khi `wake` được gọi trên [`Waker`].
    /// Nó phải đánh thức tác vụ được liên kết với [`RawWaker`] này.
    ///
    /// Việc triển khai chức năng này phải đảm bảo giải phóng bất kỳ tài nguyên nào được liên kết với phiên bản [`RawWaker`] này và tác vụ liên quan.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Chức năng này sẽ được gọi khi `wake_by_ref` được gọi trên [`Waker`].
    /// Nó phải đánh thức tác vụ được liên kết với [`RawWaker`] này.
    ///
    /// Chức năng này tương tự như `wake`, nhưng không được sử dụng con trỏ dữ liệu được cung cấp.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Hàm này được gọi khi [`RawWaker`] bị rơi.
    ///
    /// Việc triển khai chức năng này phải đảm bảo giải phóng bất kỳ tài nguyên nào được liên kết với phiên bản [`RawWaker`] này và tác vụ liên quan.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Tạo `RawWakerVTable` mới từ các chức năng `clone`, `wake`, `wake_by_ref` và `drop` được cung cấp.
    ///
    /// # `clone`
    ///
    /// Hàm này sẽ được gọi khi [`RawWaker`] được sao chép, ví dụ như khi [`Waker`] mà [`RawWaker`] được lưu trữ bị sao chép.
    ///
    /// Việc triển khai chức năng này phải giữ lại tất cả các tài nguyên cần thiết cho phiên bản bổ sung này của [`RawWaker`] và tác vụ liên quan.
    /// Việc gọi `wake` trên kết quả [`RawWaker`] sẽ dẫn đến việc đánh thức cùng một tác vụ đã được đánh thức bởi [`RawWaker`] ban đầu.
    ///
    /// # `wake`
    ///
    /// Chức năng này sẽ được gọi khi `wake` được gọi trên [`Waker`].
    /// Nó phải đánh thức tác vụ được liên kết với [`RawWaker`] này.
    ///
    /// Việc triển khai chức năng này phải đảm bảo giải phóng bất kỳ tài nguyên nào được liên kết với phiên bản [`RawWaker`] này và tác vụ liên quan.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Chức năng này sẽ được gọi khi `wake_by_ref` được gọi trên [`Waker`].
    /// Nó phải đánh thức tác vụ được liên kết với [`RawWaker`] này.
    ///
    /// Chức năng này tương tự như `wake`, nhưng không được sử dụng con trỏ dữ liệu được cung cấp.
    ///
    /// # `drop`
    ///
    /// Hàm này được gọi khi [`RawWaker`] bị rơi.
    ///
    /// Việc triển khai chức năng này phải đảm bảo giải phóng bất kỳ tài nguyên nào được liên kết với phiên bản [`RawWaker`] này và tác vụ liên quan.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// `Context` của một tác vụ không đồng bộ.
///
/// Hiện tại, `Context` chỉ phục vụ để cung cấp quyền truy cập vào `&Waker` có thể được sử dụng để đánh thức tác vụ hiện tại.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Đảm bảo chúng tôi chống lại sự thay đổi phương sai future bằng cách buộc thời gian tồn tại là bất biến (thời gian tồn tại của đối số-vị trí là nghịch biến trong khi thời gian sống của vị trí trả lại là hiệp biến).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Tạo `Context` mới từ `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Trả về một tham chiếu đến `Waker` cho tác vụ hiện tại.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` là một trình xử lý để đánh thức một tác vụ bằng cách thông báo cho người thực thi nó rằng nó đã sẵn sàng để chạy.
///
/// Xử lý này đóng gói một phiên bản [`RawWaker`], xác định hành vi đánh thức của người thực thi cụ thể.
///
///
/// Triển khai [`Clone`], [`Send`] và [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Đánh thức tác vụ được liên kết với `Waker` này.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Cuộc gọi đánh thức thực tế được ủy quyền thông qua một lệnh gọi hàm ảo đến việc triển khai được xác định bởi người thực thi.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Đừng gọi `drop`-người làm sẽ bị tiêu thụ bởi `wake`.
        crate::mem::forget(self);

        // AN TOÀN: Điều này an toàn vì `Waker::from_raw` là cách duy nhất
        // để khởi tạo `wake` và `data` yêu cầu người dùng xác nhận rằng hợp đồng của `RawWaker` được duy trì.
        //
        unsafe { (wake)(data) };
    }

    /// Đánh thức tác vụ được liên kết với `Waker` này mà không cần sử dụng `Waker`.
    ///
    /// Điều này tương tự như `wake`, nhưng có thể kém hiệu quả hơn một chút trong trường hợp có sẵn `Waker` sở hữu.
    /// Phương thức này nên được ưu tiên để gọi `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Cuộc gọi đánh thức thực tế được ủy quyền thông qua một lệnh gọi hàm ảo đến việc triển khai được xác định bởi người thực thi.
        //

        // AN TOÀN: xem `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Trả về `true` nếu `Waker` này và `Waker` khác đã đánh thức cùng một tác vụ.
    ///
    /// Hàm này hoạt động trên cơ sở nỗ lực cao nhất và có thể trả về false ngay cả khi các `` Thợ làm '' sẽ đánh thức cùng một nhiệm vụ.
    /// Tuy nhiên, nếu hàm này trả về `true`, nó được đảm bảo rằng các `` Thợ làm '' sẽ đánh thức cùng một nhiệm vụ.
    ///
    /// Chức năng này chủ yếu được sử dụng cho mục đích tối ưu hóa.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Tạo `Waker` mới từ [`RawWaker`].
    ///
    /// Hành vi của `Waker` được trả về là không xác định nếu hợp đồng được xác định trong tài liệu của [``RawWaker`] và [``RawWakerVTable`] '] không được duy trì.
    ///
    /// Do đó phương pháp này không an toàn.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // AN TOÀN: Điều này an toàn vì `Waker::from_raw` là cách duy nhất
            // để khởi tạo `clone` và `data` yêu cầu người dùng xác nhận rằng hợp đồng của [`RawWaker`] được duy trì.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // AN TOÀN: Điều này an toàn vì `Waker::from_raw` là cách duy nhất
        // để khởi tạo `drop` và `data` yêu cầu người dùng xác nhận rằng hợp đồng của `RawWaker` được duy trì.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}