//! Mô-đun này triển khai `Any` trait, cho phép nhập động bất kỳ kiểu `'static` nào thông qua phản xạ thời gian chạy.
//!
//! `Any` bản thân nó có thể được sử dụng để lấy `TypeId` và có nhiều tính năng hơn khi được sử dụng như một đối tượng trait.
//! Là `&dyn Any` (một đối tượng trait mượn), nó có các phương thức `is` và `downcast_ref`, để kiểm tra xem giá trị được chứa có thuộc một kiểu nhất định hay không và để nhận tham chiếu đến giá trị bên trong dưới dạng một kiểu.
//! Như `&mut dyn Any`, cũng có phương thức `downcast_mut`, để nhận tham chiếu có thể thay đổi cho giá trị bên trong.
//! `Box<dyn Any>` thêm phương thức `downcast`, phương thức này cố gắng chuyển đổi thành `Box<T>`.
//! Xem tài liệu [`Box`] để biết đầy đủ chi tiết.
//!
//! Lưu ý rằng `&dyn Any` được giới hạn để kiểm tra xem một giá trị có thuộc loại bê tông được chỉ định hay không và không thể được sử dụng để kiểm tra xem một loại có thực hiện trait hay không.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Con trỏ thông minh và `dyn Any`
//!
//! Một phần hành vi cần lưu ý khi sử dụng `Any` làm đối tượng trait, đặc biệt với các loại như `Box<dyn Any>` hoặc `Arc<dyn Any>`, đó là chỉ cần gọi `.type_id()` trên giá trị sẽ tạo ra `TypeId` của *container*, không phải đối tượng trait bên dưới.
//!
//! Điều này có thể tránh được bằng cách chuyển đổi con trỏ thông minh thành `&dyn Any`, con trỏ này sẽ trả về `TypeId` của đối tượng.
//! Ví dụ:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Nhiều khả năng bạn muốn điều này:
//! let actual_id = (&*boxed).type_id();
//! // ... hơn cái này:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Hãy xem xét một tình huống mà chúng ta muốn đăng xuất một giá trị được truyền vào một hàm.
//! Chúng tôi biết giá trị mà chúng tôi đang nghiên cứu khi thực hiện Debug, nhưng chúng tôi không biết loại cụ thể của nó.Chúng tôi muốn xử lý đặc biệt cho một số loại nhất định: trong trường hợp này, in ra độ dài của các giá trị Chuỗi trước giá trị của chúng.
//! Chúng tôi không biết loại cụ thể của giá trị của chúng tôi tại thời điểm biên dịch, vì vậy chúng tôi cần sử dụng phản ánh thời gian chạy thay thế.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Chức năng ghi nhật ký cho bất kỳ kiểu nào triển khai Gỡ lỗi.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Cố gắng chuyển đổi giá trị của chúng tôi thành `String`.
//!     // Nếu thành công, chúng ta muốn xuất ra độ dài của Chuỗi cũng như giá trị của nó.
//!     // Nếu không, đó là một loại khác: chỉ cần in nó ra không trang trí.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Hàm này muốn đăng xuất tham số của nó trước khi thực hiện công việc với nó.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... làm một số công việc khác
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Bất kỳ trait nào
///////////////////////////////////////////////////////////////////////////////

/// Một trait để mô phỏng gõ động.
///
/// Hầu hết các loại triển khai `Any`.Tuy nhiên, bất kỳ loại nào chứa tham chiếu không ``tĩnh` 'thì không.
/// Xem [module-level documentation][mod] để biết thêm chi tiết.
///
/// [mod]: crate::any
// trait này không phải là không an toàn, mặc dù chúng tôi dựa vào các chi tiết cụ thể về chức năng `type_id` của nó duy nhất trong mã không an toàn (ví dụ: `downcast`).Thông thường, đó sẽ là một vấn đề, nhưng bởi vì sự tích hợp duy nhất của `Any` là triển khai hàng loạt, không có mã nào khác có thể triển khai `Any`.
//
// Chúng tôi có thể làm cho trait này không an toàn một cách hợp lý-nó sẽ không gây ra sự cố, vì chúng tôi kiểm soát tất cả các triển khai-nhưng chúng tôi chọn không làm vậy vì điều đó vừa không thực sự cần thiết vừa có thể khiến người dùng nhầm lẫn về sự phân biệt của traits không an toàn và các phương pháp không an toàn (ví dụ: `type_id` sẽ vẫn an toàn để gọi, nhưng chúng tôi có thể muốn chỉ ra như vậy trong tài liệu).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Nhận `TypeId` của `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Các phương thức mở rộng cho mọi đối tượng trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Đảm bảo rằng kết quả của ví dụ: nối một chuỗi có thể được in và do đó được sử dụng với `unwrap`.
// Cuối cùng có thể không còn cần thiết nếu công văn hoạt động với dự báo.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Trả về `true` nếu kiểu đóng hộp giống với `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Nhận `TypeId` thuộc loại mà chức năng này được khởi tạo.
        let t = TypeId::of::<T>();

        // Lấy loại `TypeId` trong đối tượng trait (`self`).
        let concrete = self.type_id();

        // So sánh cả hai `TypeId` về bằng nhau.
        t == concrete
    }

    /// Trả về một số tham chiếu đến giá trị được đóng hộp nếu nó thuộc loại `T` hoặc `None` nếu không phải.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // AN TOÀN: chỉ cần kiểm tra xem chúng tôi có đang trỏ đến đúng loại hay không và chúng tôi có thể dựa vào
            // kiểm tra sự an toàn của bộ nhớ vì chúng tôi đã triển khai Bất kỳ cho tất cả các loại;không có lỗ cấy nào khác có thể tồn tại vì chúng sẽ xung đột với cấy ghép của chúng tôi.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Trả về một số tham chiếu có thể thay đổi cho giá trị được đóng hộp nếu nó thuộc loại `T` hoặc `None` nếu không phải.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // AN TOÀN: chỉ cần kiểm tra xem chúng tôi có đang trỏ đến đúng loại hay không và chúng tôi có thể dựa vào
            // kiểm tra sự an toàn của bộ nhớ vì chúng tôi đã triển khai Bất kỳ cho tất cả các loại;không có lỗ cấy nào khác có thể tồn tại vì chúng sẽ xung đột với cấy ghép của chúng tôi.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Chuyển tiếp đến phương thức được xác định trên kiểu `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Chuyển tiếp đến phương thức được xác định trên kiểu `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Chuyển tiếp đến phương thức được xác định trên kiểu `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Chuyển tiếp đến phương thức được xác định trên kiểu `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Chuyển tiếp đến phương thức được xác định trên kiểu `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Chuyển tiếp đến phương thức được xác định trên kiểu `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID và các phương thức của nó
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` đại diện cho một số nhận dạng duy nhất trên toàn cầu cho một loại.
///
/// Mỗi `TypeId` là một vật thể không trong suốt, không cho phép kiểm tra những gì bên trong nhưng cho phép thực hiện các hoạt động cơ bản như sao chép, so sánh, in và hiển thị.
///
///
/// `TypeId` hiện chỉ khả dụng cho các loại đăng ký `'static`, nhưng giới hạn này có thể bị loại bỏ trong future.
///
/// Trong khi `TypeId` triển khai `Hash`, `PartialOrd` và `Ord`, cần lưu ý rằng các hàm băm và thứ tự sẽ khác nhau giữa các bản phát hành Rust.
/// Cẩn thận với việc dựa vào chúng bên trong mã của bạn!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Trả về `TypeId` của kiểu mà hàm chung này đã được khởi tạo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Trả về tên của một kiểu dưới dạng một lát chuỗi.
///
/// # Note
///
/// Điều này được thiết kế để sử dụng chẩn đoán.
/// Nội dung và định dạng chính xác của chuỗi được trả về không được chỉ định, ngoại trừ việc mô tả kiểu này đã cố gắng hết sức.
/// Ví dụ: trong số các chuỗi mà `type_name::<Option<String>>()` có thể trả về là `"Option<String>"` và `"std::option::Option<std::string::String>"`.
///
///
/// Chuỗi trả về không được coi là số nhận dạng duy nhất của một loại vì nhiều loại có thể ánh xạ đến cùng một tên loại.
/// Tương tự như vậy, không có gì đảm bảo rằng tất cả các phần của một kiểu sẽ xuất hiện trong chuỗi trả về: ví dụ: các chỉ định thời gian tồn tại hiện không được bao gồm.
/// Ngoài ra, đầu ra có thể thay đổi giữa các phiên bản của trình biên dịch.
///
/// Việc triển khai hiện tại sử dụng cơ sở hạ tầng giống như chẩn đoán trình biên dịch và debuginfo, nhưng điều này không được đảm bảo.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Trả về tên của kiểu giá trị trỏ đến dưới dạng một lát chuỗi.
/// Điều này giống như `type_name::<T>()`, nhưng có thể được sử dụng ở những nơi không dễ dàng có được loại biến.
///
/// # Note
///
/// Điều này được thiết kế để sử dụng chẩn đoán.Nội dung và định dạng chính xác của chuỗi không được chỉ định, ngoại trừ việc mô tả kiểu này là nỗ lực cao nhất.
/// Ví dụ: `type_name_of_val::<Option<String>>(None)` có thể trả về `"Option<String>"` hoặc `"std::option::Option<std::string::String>"`, nhưng không phải `"foobar"`.
///
/// Ngoài ra, đầu ra có thể thay đổi giữa các phiên bản của trình biên dịch.
///
/// Chức năng này không giải quyết các đối tượng trait, có nghĩa là `type_name_of_val(&7u32 as &dyn Debug)` có thể trả về `"dyn Debug"`, nhưng không phải `"u32"`.
///
/// Tên kiểu không nên được coi là định danh duy nhất của một kiểu;
/// nhiều loại có thể dùng chung một tên loại.
///
/// Việc triển khai hiện tại sử dụng cơ sở hạ tầng giống như chẩn đoán trình biên dịch và debuginfo, nhưng điều này không được đảm bảo.
///
/// # Examples
///
/// In các kiểu số nguyên và số thực mặc định.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}