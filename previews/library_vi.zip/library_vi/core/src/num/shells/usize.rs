//! Hằng số cho kiểu số nguyên không dấu có kích thước bằng con trỏ.
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! Mã mới nên sử dụng các hằng số liên quan trực tiếp trên kiểu nguyên thủy.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }