//! Hằng số cho kiểu số nguyên có dấu 16 bit.
//!
//! *[See also the `i16` primitive type][i16].*
//!
//! Mã mới nên sử dụng các hằng số liên quan trực tiếp trên kiểu nguyên thủy.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i16`"
)]

int_module! { i16 }