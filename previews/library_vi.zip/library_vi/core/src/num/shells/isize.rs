//! Hằng số cho kiểu số nguyên có dấu có kích thước bằng con trỏ.
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! Mã mới nên sử dụng các hằng số liên quan trực tiếp trên kiểu nguyên thủy.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }