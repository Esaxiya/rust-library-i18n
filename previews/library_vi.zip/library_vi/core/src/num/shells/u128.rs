//! Hằng số cho kiểu số nguyên không dấu 128 bit.
//!
//! *[See also the `u128` primitive type][u128].*
//!
//! Mã mới nên sử dụng các hằng số liên quan trực tiếp trên kiểu nguyên thủy.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u128`"
)]

int_module! { u128, #[stable(feature = "i128", since="1.26.0")] }