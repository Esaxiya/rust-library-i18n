macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Giá trị nhỏ nhất có thể được biểu diễn bằng kiểu số nguyên này.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// Giá trị lớn nhất có thể được biểu diễn bằng kiểu số nguyên này.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// Kích thước của kiểu số nguyên này tính bằng bit.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Chuyển đổi một lát chuỗi trong một cơ sở nhất định thành một số nguyên.
        ///
        /// Chuỗi dự kiến là một ký hiệu `+` tùy chọn theo sau là các chữ số.
        ///
        /// Khoảng trắng đầu và cuối biểu thị một lỗi.
        /// Chữ số là một tập hợp con của các ký tự này, tùy thuộc vào `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Chức năng này panics nếu `radix` không nằm trong phạm vi từ 2 đến 36.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Trả về số đơn vị trong biểu diễn nhị phân của `self`.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Trả về số lượng số không trong biểu diễn nhị phân của `self`.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Trả về số lượng các số 0 ở đầu trong biểu diễn nhị phân của `self`.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Trả về số lượng các số không ở cuối trong biểu diễn nhị phân của `self`.
        ///
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Trả về số lượng giá trị đứng đầu trong biểu diễn nhị phân của `self`.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// Trả về số lượng các ô ở cuối trong biểu diễn nhị phân của `self`.
        ///
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Dịch chuyển các bit sang trái một số lượng được chỉ định, `n`, gói các bit bị cắt ngắn vào cuối số nguyên kết quả.
        ///
        ///
        /// Xin lưu ý rằng đây không phải là hoạt động giống như toán tử chuyển số `<<`!
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Dịch chuyển các bit sang phải theo một số lượng được chỉ định, `n`, gói các bit bị cắt ngắn vào đầu số nguyên kết quả.
        ///
        ///
        /// Xin lưu ý rằng đây không phải là hoạt động giống như toán tử chuyển số `>>`!
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Đảo ngược thứ tự byte của số nguyên.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// cho m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Đảo ngược thứ tự của các bit trong số nguyên.
        /// Bit ít quan trọng nhất trở thành bit quan trọng nhất, bit ít quan trọng thứ hai trở thành bit quan trọng thứ hai, v.v.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// cho m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Chuyển đổi một số nguyên từ giá trị cuối lớn thành giá trị cuối của mục tiêu.
        ///
        /// Trên endian lớn, đây là một điều không cần lựa chọn.
        /// Trên endian nhỏ, các byte được hoán đổi.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// nếu cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } khác {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Chuyển đổi một số nguyên từ giá trị cuối nhỏ thành giá trị cuối cùng của mục tiêu.
        ///
        /// Trên endian nhỏ, đây là một điều không cần thiết.
        /// Trên endian lớn, các byte được hoán đổi.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// nếu cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } khác {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Chuyển đổi `self` thành endian lớn từ endian của mục tiêu.
        ///
        /// Trên endian lớn, đây là một điều không cần lựa chọn.
        /// Trên endian nhỏ, các byte được hoán đổi.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// nếu cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } khác { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // hay không được?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Chuyển đổi `self` thành endian nhỏ so với endian của mục tiêu.
        ///
        /// Trên endian nhỏ, đây là một điều không cần thiết.
        /// Trên endian lớn, các byte được hoán đổi.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// nếu cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } khác { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Đã kiểm tra phép cộng số nguyên.
        /// Tính toán `self + rhs`, trả về `None` nếu xảy ra tràn.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Phép cộng số nguyên không được chọn.Tính toán `self + rhs`, giả sử không thể xảy ra tràn.
        /// Điều này dẫn đến hành vi không xác định khi
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Kiểm tra phép trừ số nguyên.
        /// Tính toán `self - rhs`, trả về `None` nếu xảy ra tràn.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Phép trừ số nguyên không được kiểm tra.Tính toán `self - rhs`, giả sử không thể xảy ra tràn.
        /// Điều này dẫn đến hành vi không xác định khi
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Kiểm tra phép nhân số nguyên.
        /// Tính toán `self * rhs`, trả về `None` nếu xảy ra tràn.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Phép nhân số nguyên không được kiểm tra.Tính toán `self * rhs`, giả sử không thể xảy ra tràn.
        /// Điều này dẫn đến hành vi không xác định khi
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Đã kiểm tra phép chia số nguyên.
        /// Tính toán `self / rhs`, trả về `None` nếu `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // AN TOÀN: div cho zero đã được kiểm tra ở trên và các loại không dấu không có loại nào khác
                // các chế độ phân chia thất bại
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Kiểm tra bộ phận Euclid.
        /// Tính toán `self.div_euclid(rhs)`, trả về `None` nếu `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Phần dư số nguyên đã kiểm tra.
        /// Tính toán `self % rhs`, trả về `None` nếu `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // AN TOÀN: div cho zero đã được kiểm tra ở trên và các loại không dấu không có loại nào khác
                // các chế độ phân chia thất bại
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Đã kiểm tra modulo Euclidean.
        /// Tính toán `self.rem_euclid(rhs)`, trả về `None` nếu `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Phủ định được kiểm tra.Tính toán `-self`, trả về `None` trừ khi `self==
        /// 0`.
        ///
        /// Lưu ý rằng việc phủ định bất kỳ số nguyên dương nào sẽ bị tràn.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Đã kiểm tra ca sang trái.
        /// Tính toán `self << rhs`, trả về `None` nếu `rhs` lớn hơn hoặc bằng số bit trong `self`.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Đã kiểm tra ca phải.
        /// Tính toán `self >> rhs`, trả về `None` nếu `rhs` lớn hơn hoặc bằng số bit trong `self`.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Kiểm tra lũy thừa.
        /// Tính toán `self.pow(exp)`, trả về `None` nếu xảy ra tràn.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // vì exp!=0, cuối cùng exp phải là 1.
            // Xử lý riêng bit cuối cùng của số mũ, vì bình phương cơ số sau đó là không cần thiết và có thể gây tràn không cần thiết.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Điều chỉnh phép cộng số nguyên.
        /// Tính toán `self + rhs`, bão hòa ở giới hạn số thay vì tràn.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Bão hòa phép trừ số nguyên.
        /// Tính toán `self - rhs`, bão hòa ở giới hạn số thay vì tràn.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Bão hòa phép nhân số nguyên.
        /// Tính toán `self * rhs`, bão hòa ở giới hạn số thay vì tràn.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Bão hòa lũy thừa số nguyên.
        /// Tính toán `self.pow(exp)`, bão hòa ở giới hạn số thay vì tràn.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Bao bọc (modular) bổ sung.
        /// Tính toán `self + rhs`, bao quanh ở ranh giới của loại.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Bao bọc phép trừ (modular).
        /// Tính toán `self - rhs`, bao quanh ở ranh giới của loại.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Bao bọc phép nhân (modular).
        /// Tính toán `self * rhs`, bao quanh ở ranh giới của loại.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// Xin lưu ý rằng ví dụ này được chia sẻ giữa các kiểu số nguyên.
        /// Điều này giải thích tại sao `u8` được sử dụng ở đây.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Bao bọc bộ phận (modular).Máy tính `self / rhs`.
        /// Phép chia có dấu trên các kiểu không dấu chỉ là phép chia bình thường.
        /// Không bao giờ có chuyện quấn lấy nhau được.
        /// Chức năng này tồn tại, để tất cả các hoạt động được tính trong các hoạt động gói.
        ///
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Bao bọc bộ phận Ơclit.Máy tính `self.div_euclid(rhs)`.
        /// Phép chia có dấu trên các kiểu không dấu chỉ là phép chia bình thường.
        /// Không bao giờ có chuyện quấn lấy nhau được.
        /// Chức năng này tồn tại, để tất cả các hoạt động được tính trong các hoạt động gói.
        /// Vì đối với các số nguyên dương, tất cả các định nghĩa phổ biến của phép chia đều bằng nhau, điều này chính xác bằng `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Bao bọc phần còn lại (modular).Máy tính `self % rhs`.
        /// Phép tính phần dư được bao bọc trên các loại không có dấu chỉ là phép tính phần dư thông thường.
        ///
        /// Không bao giờ có chuyện quấn lấy nhau được.
        /// Chức năng này tồn tại, để tất cả các hoạt động được tính trong các hoạt động gói.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Bao bọc mô-đun Euclidean.Máy tính `self.rem_euclid(rhs)`.
        /// Tính toán modulo được bao bọc trên các kiểu không dấu chỉ là phép tính phần dư thông thường.
        /// Không bao giờ có chuyện quấn lấy nhau được.
        /// Chức năng này tồn tại, để tất cả các hoạt động được tính trong các hoạt động gói.
        /// Vì đối với các số nguyên dương, tất cả các định nghĩa phổ biến của phép chia đều bằng nhau, điều này chính xác bằng `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Bao bọc phủ định (modular).
        /// Tính toán `-self`, bao quanh ở ranh giới của loại.
        ///
        /// Vì các loại không dấu không có giá trị tương đương âm nên tất cả các ứng dụng của hàm này sẽ bao gồm (ngoại trừ `-0`).
        /// Đối với các giá trị nhỏ hơn giá trị lớn nhất của loại có dấu tương ứng, kết quả giống như việc ép giá trị có dấu tương ứng.
        ///
        /// Mọi giá trị lớn hơn đều tương đương với `MAX + 1 - (val - MAX - 1)` trong đó `MAX` là giá trị tối đa của loại có dấu tương ứng.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// Xin lưu ý rằng ví dụ này được chia sẻ giữa các kiểu số nguyên.
        /// Điều này giải thích tại sao `i8` được sử dụng ở đây.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-không-có-bit dịch chuyển-trái;
        /// tạo ra `self << mask(rhs)`, trong đó `mask` loại bỏ bất kỳ bit bậc cao nào của `rhs` có thể gây ra sự thay đổi vượt quá băng thông bit của kiểu.
        ///
        /// Lưu ý rằng điều này *không* giống như xoay trái;RHS của một gói dịch chuyển sang trái bị hạn chế trong phạm vi của loại, thay vì các bit được dịch chuyển ra khỏi LHS được trả về đầu kia.
        /// Tất cả các kiểu số nguyên nguyên thủy đều triển khai một hàm [`rotate_left`](Self::rotate_left), thay vào đó có thể là hàm mà bạn muốn.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // AN TOÀN: che theo kích thước bit của loại đảm bảo rằng chúng tôi không thay đổi
            // ngoài giới hạn
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-không-có-bit dịch chuyển-phải;
        /// tạo ra `self >> mask(rhs)`, trong đó `mask` loại bỏ bất kỳ bit bậc cao nào của `rhs` có thể gây ra sự thay đổi vượt quá băng thông bit của kiểu.
        ///
        /// Lưu ý rằng điều này *không* giống như xoay-phải;RHS của một dịch chuyển bên phải gói bị hạn chế trong phạm vi của loại, thay vì các bit được dịch chuyển ra khỏi LHS được trả về đầu kia.
        /// Các kiểu số nguyên nguyên thủy đều triển khai một hàm [`rotate_right`](Self::rotate_right), thay vào đó có thể là hàm mà bạn muốn.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // AN TOÀN: che theo kích thước bit của loại đảm bảo rằng chúng tôi không thay đổi
            // ngoài giới hạn
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Bao hàm lũy thừa (modular).
        /// Tính toán `self.pow(exp)`, bao quanh ở ranh giới của loại.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // vì exp!=0, cuối cùng exp phải là 1.
            // Xử lý riêng bit cuối cùng của số mũ, vì bình phương cơ số sau đó là không cần thiết và có thể gây tràn không cần thiết.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Tính `self` + `rhs`
        ///
        /// Trả về một bộ phép cộng cùng với một boolean cho biết liệu có xảy ra tràn số học hay không.
        /// Nếu xảy ra tràn thì giá trị được bao bọc sẽ được trả về.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Tính `self`, `rhs`
        ///
        /// Trả về một bộ số của phép trừ cùng với một boolean cho biết liệu có xảy ra tràn số học hay không.
        /// Nếu xảy ra tràn thì giá trị được bao bọc sẽ được trả về.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Tính phép nhân của `self` và `rhs`.
        ///
        /// Trả về một bộ nhân cùng với một boolean cho biết liệu có xảy ra tràn số học hay không.
        /// Nếu xảy ra tràn thì giá trị được bao bọc sẽ được trả về.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// Xin lưu ý rằng ví dụ này được chia sẻ giữa các kiểu số nguyên.
        /// Điều này giải thích tại sao `u32` được sử dụng ở đây.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Tính số chia khi `self` chia cho `rhs`.
        ///
        /// Trả về một bộ số chia cùng với một boolean cho biết liệu có xảy ra tràn số học hay không.
        /// Lưu ý rằng đối với số nguyên không dấu không bao giờ xảy ra tràn, vì vậy giá trị thứ hai luôn là `false`.
        ///
        /// # Panics
        ///
        /// Hàm này sẽ panic nếu `rhs` là 0.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Tính thương của phép chia Ơclit `self.div_euclid(rhs)`.
        ///
        /// Trả về một bộ số chia cùng với một boolean cho biết liệu có xảy ra tràn số học hay không.
        /// Lưu ý rằng đối với số nguyên không dấu không bao giờ xảy ra tràn, vì vậy giá trị thứ hai luôn là `false`.
        /// Vì đối với các số nguyên dương, tất cả các định nghĩa phổ biến của phép chia đều bằng nhau, điều này chính xác bằng `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Hàm này sẽ panic nếu `rhs` là 0.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Tính phần còn lại khi `self` chia cho `rhs`.
        ///
        /// Trả về một bộ phần còn lại sau khi chia cùng với một boolean cho biết liệu có xảy ra tràn số học hay không.
        /// Lưu ý rằng đối với số nguyên không dấu không bao giờ xảy ra tràn, vì vậy giá trị thứ hai luôn là `false`.
        ///
        /// # Panics
        ///
        /// Hàm này sẽ panic nếu `rhs` là 0.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Tính phần dư `self.rem_euclid(rhs)` như thể bằng phép chia Euclide.
        ///
        /// Trả về một bộ modulo sau khi chia cùng với một boolean cho biết liệu có xảy ra tràn số học hay không.
        /// Lưu ý rằng đối với số nguyên không dấu không bao giờ xảy ra tràn, vì vậy giá trị thứ hai luôn là `false`.
        /// Vì đối với các số nguyên dương, tất cả các định nghĩa phổ biến của phép chia đều bằng nhau, phép toán này chính xác bằng `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Hàm này sẽ panic nếu `rhs` là 0.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Phủ nhận bản thân một cách tràn ngập.
        ///
        /// Trả về `!self + 1` bằng cách sử dụng các thao tác gói để trả về giá trị đại diện cho sự phủ định của giá trị không được đánh dấu này.
        /// Lưu ý rằng đối với các giá trị không dấu dương luôn xảy ra tràn, nhưng việc phủ định 0 không bị tràn.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Tự dịch chuyển sang trái bởi các bit `rhs`.
        ///
        /// Trả về một bộ giá trị của phiên bản đã dịch của chính nó cùng với một boolean cho biết liệu giá trị dịch chuyển có lớn hơn hoặc bằng số bit hay không.
        /// Nếu giá trị shift quá lớn, thì giá trị này sẽ được che đi (N-1) trong đó N là số bit và giá trị này sau đó được sử dụng để thực hiện chuyển đổi.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Tự dịch chuyển sang phải theo bit `rhs`.
        ///
        /// Trả về một bộ giá trị của phiên bản đã dịch của chính nó cùng với một boolean cho biết liệu giá trị dịch chuyển có lớn hơn hoặc bằng số bit hay không.
        /// Nếu giá trị shift quá lớn, thì giá trị này sẽ được che đi (N-1) trong đó N là số bit và giá trị này sau đó được sử dụng để thực hiện chuyển đổi.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Nâng cao sức mạnh của bản thân lên sức mạnh của `exp`, sử dụng lũy thừa bằng cách bình phương.
        ///
        /// Trả về một bộ lũy thừa cùng với bool cho biết liệu có xảy ra tràn hay không.
        ///
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, đúng));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Khoảng trống để lưu trữ các kết quả của overflow_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // vì exp!=0, cuối cùng exp phải là 1.
            // Xử lý riêng bit cuối cùng của số mũ, vì bình phương cơ số sau đó là không cần thiết và có thể gây tràn không cần thiết.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Nâng cao sức mạnh của bản thân lên sức mạnh của `exp`, sử dụng lũy thừa bằng cách bình phương.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // vì exp!=0, cuối cùng exp phải là 1.
            // Xử lý riêng bit cuối cùng của số mũ, vì bình phương cơ số sau đó là không cần thiết và có thể gây tràn không cần thiết.
            //
            //
            acc * base
        }

        /// Thực hiện phép chia Euclide.
        ///
        /// Vì đối với các số nguyên dương, tất cả các định nghĩa phổ biến của phép chia đều bằng nhau, điều này chính xác bằng `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Hàm này sẽ panic nếu `rhs` là 0.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Tính phần dư ít nhất của `self (mod rhs)`.
        ///
        /// Vì đối với các số nguyên dương, tất cả các định nghĩa phổ biến của phép chia đều bằng nhau, điều này chính xác bằng `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Hàm này sẽ panic nếu `rhs` là 0.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Trả về `true` nếu và chỉ khi `self == 2^k` đối với một số `k`.
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Trả về một ít hơn lũy thừa tiếp theo của hai.
        // (Đối với 8u8 sức mạnh tiếp theo của hai là 8u8 và đối với 6u8 là 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Phương thức này không thể làm tràn, vì trong các trường hợp tràn `next_power_of_two`, nó thay vào đó trả về giá trị lớn nhất của kiểu và có thể trả về 0 cho 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // AN TOÀN: Bởi vì `p > 0`, nó không thể bao gồm hoàn toàn các số 0 ở đầu.
            // Điều đó có nghĩa là sự thay đổi luôn ở trong giới hạn và một số bộ xử lý (chẳng hạn như intel pre-haswell) có bản chất ctlz hiệu quả hơn khi đối số là khác 0.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Trả về lũy thừa nhỏ nhất của hai lớn hơn hoặc bằng `self`.
        ///
        /// Khi giá trị trả về tràn (tức là `self > (1 << (N-1))` cho kiểu `uN`), nó panics ở chế độ gỡ lỗi và giá trị trả về được bao bọc thành 0 trong chế độ giải phóng (tình huống duy nhất trong đó phương thức có thể trả về 0).
        ///
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Trả về lũy thừa nhỏ nhất của hai lớn hơn hoặc bằng `n`.
        /// Nếu công suất tiếp theo của hai lớn hơn giá trị lớn nhất của loại, thì `None` sẽ được trả về, nếu không thì công suất của hai được bao bọc trong `Some`.
        ///
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Trả về lũy thừa nhỏ nhất của hai lớn hơn hoặc bằng `n`.
        /// Nếu lũy thừa tiếp theo của hai lớn hơn giá trị lớn nhất của loại, giá trị trả về sẽ được bao bọc thành `0`.
        ///
        ///
        /// # Examples
        ///
        /// Cách sử dụng cơ bản:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Trả về biểu diễn bộ nhớ của số nguyên này dưới dạng một mảng byte theo thứ tự byte big-endian (network).
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Trả về biểu diễn bộ nhớ của số nguyên này dưới dạng một mảng byte theo thứ tự byte cuối con số nhỏ.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Trả về biểu diễn bộ nhớ của số nguyên này dưới dạng một mảng byte theo thứ tự byte nguyên bản.
        ///
        /// Vì tính chất gốc của nền tảng mục tiêu được sử dụng, mã di động nên sử dụng [`to_be_bytes`] hoặc [`to_le_bytes`], nếu thích hợp, thay vào đó.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     byte, nếu cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } khác {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // AN TOÀN: const âm thanh vì các số nguyên là các kiểu dữ liệu cũ đơn giản nên chúng tôi luôn có thể
        // chuyển đổi chúng thành các mảng byte
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // AN TOÀN: các số nguyên là các kiểu dữ liệu cũ đơn giản nên chúng tôi luôn có thể chuyển chúng sang
            // mảng byte
            unsafe { mem::transmute(self) }
        }

        /// Trả về biểu diễn bộ nhớ của số nguyên này dưới dạng một mảng byte theo thứ tự byte nguyên bản.
        ///
        ///
        /// [`to_ne_bytes`] nên được ưu tiên hơn điều này bất cứ khi nào có thể.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// cho byte= num.as_ne_bytes();
        /// assert_eq!(
        ///     byte, nếu cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } khác {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // AN TOÀN: các số nguyên là các kiểu dữ liệu cũ đơn giản nên chúng tôi luôn có thể chuyển chúng sang
            // mảng byte
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Tạo một giá trị số nguyên endian gốc từ biểu diễn của nó dưới dạng một mảng byte trong big endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// sử dụng std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * đầu vào=phần còn lại;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Tạo một giá trị số nguyên endian gốc từ biểu diễn của nó dưới dạng một mảng byte trong endian nhỏ.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// sử dụng std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * đầu vào=phần còn lại;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Tạo một giá trị số nguyên endian gốc từ biểu diễn bộ nhớ của nó dưới dạng một mảng byte trong endianness gốc.
        ///
        /// Vì tính chất gốc của nền tảng mục tiêu được sử dụng, mã di động có thể muốn sử dụng [`from_be_bytes`] hoặc [`from_le_bytes`], nếu thích hợp.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } khác {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// sử dụng std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * đầu vào=phần còn lại;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // AN TOÀN: const âm thanh vì các số nguyên là các kiểu dữ liệu cũ đơn giản nên chúng tôi luôn có thể
        // chuyển đổi cho họ
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // AN TOÀN: các số nguyên là các kiểu dữ liệu cũ thuần túy nên chúng tôi luôn có thể chuyển đổi sang chúng
            unsafe { mem::transmute(bytes) }
        }

        /// Mã mới nên thích sử dụng hơn
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Trả về giá trị nhỏ nhất có thể được biểu diễn bằng kiểu số nguyên này.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// Mã mới nên thích sử dụng hơn
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Trả về giá trị lớn nhất có thể được biểu diễn bằng kiểu số nguyên này.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}