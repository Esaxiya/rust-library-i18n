//! Xác thực và phân tách một chuỗi thập phân có dạng:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Nói cách khác, cú pháp dấu phẩy động tiêu chuẩn, với hai ngoại lệ: Không có dấu và không xử lý "inf" và "NaN".Những điều này được xử lý bởi chức năng trình điều khiển (super::dec2flt).
//!
//! Mặc dù việc nhận dạng các đầu vào hợp lệ là tương đối dễ dàng, nhưng mô-đun này cũng phải từ chối vô số biến thể không hợp lệ, không bao giờ là panic và thực hiện nhiều kiểm tra mà các mô-đun khác dựa vào lần lượt không phải panic (hoặc tràn).
//!
//! Để làm cho vấn đề tồi tệ hơn, tất cả những điều đó xảy ra trong một lần chuyển đầu vào.
//! Vì vậy, hãy cẩn thận khi sửa đổi bất kỳ thứ gì và kiểm tra kỹ với các mô-đun khác.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Các phần thú vị của một chuỗi thập phân.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Số mũ thập phân, được đảm bảo có ít hơn 18 chữ số thập phân.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Kiểm tra xem chuỗi đầu vào có phải là số dấu phẩy động hợp lệ hay không và nếu có, hãy xác định vị trí phần tích phân, phần phân số và số mũ trong đó.
/// Không xử lý các dấu hiệu.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Không có chữ số nào trước 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Chúng tôi yêu cầu ít nhất một chữ số trước hoặc sau điểm.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Theo dõi rác sau phần phân đoạn
            }
        }
        _ => Invalid, // Theo dõi rác sau chuỗi chữ số đầu tiên
    }
}

/// Khắc các chữ số thập phân lên đến ký tự không phải chữ số đầu tiên.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Trích xuất số mũ và kiểm tra lỗi.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Theo dõi rác sau số mũ
    }
    if number.is_empty() {
        return Invalid; // Số mũ rỗng
    }
    // Tại thời điểm này, chúng ta chắc chắn có một chuỗi chữ số hợp lệ.Có thể là quá lâu để đưa vào một `i64`, nhưng nếu nó lớn như vậy, đầu vào chắc chắn là 0 hoặc vô cùng.
    // Vì mỗi số 0 trong các chữ số thập phân chỉ điều chỉnh số mũ bằng +/-1, tại exp=10 ^ 18, đầu vào sẽ phải là 17 exabyte (!) số không để nhận được thậm chí từ xa gần là hữu hạn.
    //
    // Đây không chính xác là một trường hợp sử dụng mà chúng ta cần phục vụ.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}