//! Các thuật toán khác nhau từ bài báo.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Số lượng bit ý nghĩa và trong Fp
const P: u32 = 64;

// Chúng tôi chỉ lưu trữ giá trị gần đúng nhất cho *tất cả* số mũ, do đó, biến "h" và các điều kiện liên quan có thể được bỏ qua.
// Điều này giao dịch hiệu suất cho một vài kilobyte không gian.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Trong hầu hết các kiến trúc, các phép toán dấu phẩy động có kích thước bit rõ ràng, do đó độ chính xác của phép tính được xác định trên cơ sở mỗi phép toán.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Trên x86, FPU x87 được sử dụng cho các hoạt động float nếu phần mở rộng SSE/SSE2 không khả dụng.
// x87 FPU hoạt động với độ chính xác 80 bit theo mặc định, có nghĩa là các hoạt động sẽ làm tròn thành 80 bit khiến cho việc làm tròn đôi xảy ra khi các giá trị cuối cùng được biểu diễn dưới dạng
//
// 32/64 các giá trị số float.Để khắc phục điều này, từ điều khiển FPU có thể được đặt để các phép tính được thực hiện với độ chính xác mong muốn.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Một cấu trúc được sử dụng để bảo toàn giá trị ban đầu của từ điều khiển FPU, để nó có thể được khôi phục khi cấu trúc bị rơi.
    ///
    ///
    /// x87 FPU là một thanh ghi 16 bit có các trường như sau:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Tài liệu cho tất cả các trường có sẵn trong Sổ tay dành cho nhà phát triển phần mềm kiến trúc IA-32 (Tập 1).
    ///
    /// Trường duy nhất có liên quan đến mã sau là PC, Precision Control.
    /// Trường này xác định độ chính xác của các hoạt động do FPU thực hiện.
    /// Nó có thể được đặt thành:
    ///  - 0b00, độ chính xác đơn, tức là 32-bit
    ///  - 0b10, độ chính xác kép tức là 64-bit
    ///  - 0b11, độ chính xác mở rộng gấp đôi tức là, 80-bit (trạng thái mặc định) Giá trị 0b01 được bảo lưu và không nên sử dụng.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // AN TOÀN: hướng dẫn `fldcw` đã được kiểm tra để có thể hoạt động chính xác với
        // bất kỳ `u16` nào
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Chúng tôi đang sử dụng cú pháp ATT để hỗ trợ LLVM 8 và LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Đặt trường chính xác của FPU thành `T` và trả về `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Tính toán giá trị cho trường Điều khiển chính xác phù hợp với `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bit
            8 => 0x0200, // 64 bit
            _ => 0x0300, // mặc định, 80 bit
        };

        // Lấy giá trị ban đầu của từ điều khiển để khôi phục nó sau này, khi cấu trúc `FPUControlWord` bị bỏ AN TOÀN: lệnh `fnstcw` đã được kiểm tra để có thể hoạt động chính xác với bất kỳ `u16` nào
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Chúng tôi đang sử dụng cú pháp ATT để hỗ trợ LLVM 8 và LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Đặt từ điều khiển đến độ chính xác mong muốn.
        // Điều này đạt được bằng cách che đi độ chính xác cũ (bit 8 và 9, 0x300) và thay thế nó bằng cờ độ chính xác đã tính ở trên.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Đường đi nhanh của Bellerophon bằng cách sử dụng số nguyên cỡ máy và số trôi nổi.
///
/// Điều này được trích xuất thành một hàm riêng biệt để nó có thể được thử trước khi xây dựng một bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Chúng tôi so sánh giá trị chính xác với MAX_SIG ở gần cuối, đây chỉ là một sự từ chối nhanh chóng, rẻ tiền (và cũng giải phóng phần còn lại của mã khỏi lo lắng về dòng chảy dưới mức).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Đường dẫn nhanh chủ yếu phụ thuộc vào số học được làm tròn đến đúng số bit mà không cần làm tròn trung gian nào.
    // Trên x86 (không có SSE hoặc SSE2), điều này yêu cầu độ chính xác của ngăn xếp x87 FPU phải được thay đổi để nó trực tiếp làm tròn thành bit 64/32.
    // Chức năng `set_precision` đảm nhận việc thiết lập độ chính xác trên các kiến trúc yêu cầu thiết lập nó bằng cách thay đổi trạng thái chung (như từ điều khiển của FPU x87).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Trường hợp e <0 không thể xếp thành branch kia.
    // Các lũy thừa âm dẫn đến một phần phân số lặp lại trong hệ nhị phân, được làm tròn, gây ra lỗi thực (và đôi khi khá đáng kể!) Trong kết quả cuối cùng.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Thuật toán Bellerophon là mã tầm thường được biện minh bằng phân tích số không tầm thường.
///
/// Nó làm tròn `` f '' thành một phao có ý nghĩa 64 bit và nhân nó với giá trị gần đúng nhất của `10^e` (ở cùng một định dạng dấu phẩy động).Điều này thường đủ để có được kết quả chính xác.
/// Tuy nhiên, khi kết quả gần đến nửa chừng giữa hai lần nổi (ordinary) liền kề, lỗi làm tròn kép do nhân hai giá trị gần đúng có nghĩa là kết quả có thể bị lệch một vài bit.
/// Khi điều này xảy ra, Thuật toán R lặp lại sẽ sửa chữa mọi thứ.
///
/// "close to halfway" gợn sóng bằng tay được thực hiện chính xác nhờ phân tích số trên giấy.
/// Theo lời của Clinger:
///
/// > Độ dốc, được biểu thị bằng đơn vị của bit ít quan trọng nhất, là một ràng buộc bao gồm cho lỗi
/// > tích lũy trong quá trình tính toán dấu phẩy động của giá trị gần đúng với f * 10 ^ e.(Dốc là
/// > không phải là giới hạn cho sai số thực, nhưng giới hạn sự khác biệt giữa giá trị xấp xỉ z và
/// > xấp xỉ tốt nhất có thể sử dụng p bit có ý nghĩa và.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Các trường hợp abs(e) <log5(2^N) nằm trong fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Độ dốc có đủ lớn để tạo ra sự khác biệt khi làm tròn thành n bit không?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Thuật toán lặp lại cải thiện xấp xỉ dấu phẩy động của `f * 10^e`.
///
/// Mỗi lần lặp lại có một đơn vị ở vị trí cuối cùng gần hơn, tất nhiên sẽ mất rất nhiều thời gian để hội tụ nếu `z0` thậm chí bị tắt nhẹ.
/// May mắn thay, khi được sử dụng làm dự phòng cho Bellerophon, giá trị gần đúng bắt đầu bị sai lệch bởi nhiều nhất một ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Tìm các số nguyên dương `x`, `y` sao cho `x / y` chính xác là `(f *10^e) / (m* 2^k)`.
        // Điều này không chỉ tránh đối phó với các dấu hiệu của `e` và `k`, chúng tôi còn loại bỏ sức mạnh của hai dấu hiệu phổ biến của `10^e` và `2^k` để làm cho các số nhỏ hơn.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Điều này được viết hơi khó hiểu vì bignums của chúng tôi không hỗ trợ số âm, vì vậy chúng tôi sử dụng thông tin dấu + giá trị tuyệt đối.
        // Phép nhân với m_digits không được tràn.
        // Nếu `x` hoặc `y` đủ lớn để chúng ta cần lo lắng về việc tràn, thì chúng cũng đủ lớn để `make_ratio` đã giảm phân số đi 2 ^ 64 hoặc hơn.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Không cần x nữa, hãy tiết kiệm clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Vẫn cần y, tạo một bản sao.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Với `x = f` và `y = m` trong đó `f` đại diện cho các chữ số thập phân đầu vào như bình thường và `m` là ý nghĩa của một xấp xỉ dấu phẩy động, làm cho tỷ lệ `x / y` bằng `(f *10^e) / (m* 2^k)`, có thể giảm đi theo lũy thừa của cả hai điểm chung.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, ngoại trừ việc chúng ta giảm phân số đi một số lũy thừa của hai.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Điều này không thể tràn vì nó yêu cầu `e` dương và `k` âm, điều này chỉ có thể xảy ra đối với các giá trị cực kỳ gần bằng 1, có nghĩa là `e` và `k` sẽ tương đối nhỏ.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Điều này cũng không thể tràn, hãy xem ở trên.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), lại giảm đi một lũy thừa chung của hai.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Về mặt khái niệm, Thuật toán M là cách đơn giản nhất để chuyển đổi một số thập phân thành một số thực.
///
/// Chúng tôi tạo ra một tỷ lệ bằng `f * 10^e`, sau đó ném vào lũy thừa của hai cho đến khi nó cho một dấu hiệu float hợp lệ và.
/// Số mũ nhị phân `k` là số lần chúng ta nhân tử số hoặc mẫu số với hai, tức là tại mọi thời điểm `f *10^e` bằng `(u / v)* 2^k`.
/// Khi chúng ta đã tìm ra ý nghĩa và, chúng ta chỉ cần làm tròn bằng cách kiểm tra phần còn lại của phép chia, được thực hiện trong các hàm trợ giúp ở bên dưới.
///
///
/// Thuật toán này siêu chậm, ngay cả với sự tối ưu hóa được mô tả trong `quick_start()`.
/// Tuy nhiên, đây là thuật toán đơn giản nhất trong số các thuật toán để thích ứng với các kết quả tràn, tràn và không bình thường.
/// Việc triển khai này được thực hiện khi Bellerophon và Thuật toán R bị quá tải.
/// Dễ dàng phát hiện dòng chảy dưới và tràn: Tỷ lệ vẫn chưa phải là một ý nghĩa trong phạm vi, nhưng số mũ minimum/maximum đã đạt đến.
/// Trong trường hợp tràn, chúng ta chỉ cần trả về vô cùng.
///
/// Xử lý dòng chảy dưới và kim loại con phức tạp hơn.
/// Một vấn đề lớn là, với số mũ tối thiểu, tỷ lệ có thể vẫn quá lớn đối với một ý nghĩa và.
/// Xem underflow() để biết thêm chi tiết.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // Tối ưu hóa có thể có của FIXME: tổng quát hóa big_to_fp để chúng ta có thể làm tương đương với fp_to_float(big_to_fp(u)) ở đây, chỉ mà không cần làm tròn kép.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Chúng ta phải dừng lại ở số mũ tối thiểu, nếu chúng ta đợi đến `k < T::MIN_EXP_INT`, thì chúng ta sẽ bị lệch bởi hệ số hai.
            // Thật không may, điều này có nghĩa là chúng ta phải phân biệt các số bình thường với số mũ nhỏ nhất.
            // FIXME tìm một công thức thanh lịch hơn, nhưng hãy chạy thử nghiệm `tiny-pow10` để đảm bảo rằng nó thực sự chính xác!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Bỏ qua hầu hết các lần lặp Thuật toán M bằng cách kiểm tra độ dài bit.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Độ dài bit là ước tính của lôgarit cơ số hai và log(u / v) = log(u), log(v).
    // Ước tính bị sai lệch nhiều nhất là 1, nhưng luôn là ước tính thấp hơn, do đó, lỗi trên log(u) và log(v) có cùng dấu hiệu và bị hủy bỏ (nếu cả hai đều lớn).
    // Do đó, lỗi đối với log(u / v) cũng chỉ là một lỗi.
    // Tỷ lệ mục tiêu là một trong đó u/v có ý nghĩa trong phạm vi và.Do đó, điều kiện kết thúc của chúng tôi là log2(u / v) là bit quan trọng và plus/minus là một.
    // FIXME Nhìn vào bit thứ hai có thể cải thiện ước tính và tránh thêm một số phân chia.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Dòng chảy dưới hoặc bất thường.Để nó vào chức năng chính.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Tràn ra.Để nó vào chức năng chính.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Tỷ lệ không phải là một ý nghĩa trong phạm vi và với số mũ tối thiểu, vì vậy chúng ta cần làm tròn các bit thừa và điều chỉnh số mũ cho phù hợp.
    // Giá trị thực bây giờ trông như thế này:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(đại diện bởi rem)
    //
    // Do đó, khi các bit làm tròn là!= 0.5 ULP, chúng sẽ tự quyết định việc làm tròn.
    // Khi chúng bằng nhau và phần dư khác 0, giá trị vẫn cần được làm tròn.
    // Chỉ khi các bit được làm tròn là 1/2 và phần còn lại bằng 0, chúng ta mới có tình huống nửa đến chẵn.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Làm tròn thông thường đến chẵn, bị xáo trộn bằng cách phải làm tròn dựa trên phần còn lại của một phép chia.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}