//! Các hàm tiện ích cho bignums không có quá nhiều ý nghĩa để biến thành các phương thức.

// FIXME Tên của mô-đun này hơi đáng tiếc, vì các mô-đun khác cũng nhập `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Kiểm tra xem việc cắt ngắn tất cả các bit ít quan trọng hơn `ones_place` có gây ra lỗi tương đối nhỏ hơn, bằng hoặc lớn hơn 0.5 ULP hay không.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Nếu tất cả các bit còn lại bằng 0, thì nó là= 0.5 ULP, ngược lại> 0.5 Nếu không còn bit nào nữa (half_bit==0), giá trị bên dưới cũng trả về Equal một cách chính xác.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Chuyển đổi chuỗi ASCII chỉ chứa các chữ số thập phân thành `u64`.
///
/// Không thực hiện kiểm tra các ký tự tràn hoặc không hợp lệ, vì vậy nếu người gọi không cẩn thận, kết quả là không có thật và có thể là panic (mặc dù nó không phải là `unsafe`).
/// Ngoài ra, các chuỗi trống được coi là số không.
/// Chức năng này tồn tại bởi vì
///
/// 1. sử dụng `FromStr` trên `&[u8]` yêu cầu `from_utf8_unchecked`, điều này không tốt và
/// 2. Việc ghép các kết quả của `integral.parse()` và `fractional.parse()` lại phức tạp hơn toàn bộ hàm này.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Chuyển đổi một chuỗi các chữ số ASCII thành một bignum.
///
/// Giống như `from_str_unchecked`, chức năng này dựa vào trình phân tích cú pháp để loại bỏ các chữ số không.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Giải nén bignum thành một số nguyên 64 bit.Panics nếu số lượng quá lớn.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Trích xuất một loạt các bit.

/// Chỉ số 0 là bit ít quan trọng nhất và phạm vi là nửa mở như bình thường.
/// Panics nếu được yêu cầu trích xuất nhiều bit hơn phù hợp với kiểu trả về.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}