//! Chuyển đổi chuỗi thập phân thành số dấu phẩy động nhị phân IEEE 754.
//!
//! # Báo cáo vấn đề
//!
//! Chúng tôi được cung cấp một chuỗi thập phân chẳng hạn như `12.34e56`.
//! Chuỗi này bao gồm các phần (`12`) tích phân, (`34`) phân số và (`56`) lũy thừa.Tất cả các phần là tùy chọn và được hiểu là số không khi thiếu.
//!
//! Chúng tôi tìm kiếm số dấu phẩy động IEEE 754 gần nhất với giá trị chính xác của chuỗi thập phân.
//! Ai cũng biết rằng nhiều chuỗi thập phân không có biểu diễn tận cùng trong cơ số hai, vì vậy chúng tôi làm tròn đến đơn vị 0.5 ở vị trí cuối cùng (nói cách khác, càng tốt).
//! Các mối quan hệ, các giá trị thập phân chính xác bằng một nửa giữa hai số thực liên tiếp, được giải quyết bằng chiến lược nửa thành chẵn, còn được gọi là làm tròn của ngân hàng.
//!
//! Không cần phải nói, điều này là khá khó khăn, cả về độ phức tạp của việc thực hiện và về chu kỳ CPU thực hiện.
//!
//! # Implementation
//!
//! Đầu tiên, chúng tôi bỏ qua các dấu hiệu.Hay đúng hơn, chúng tôi xóa nó ngay từ đầu của quá trình chuyển đổi và áp dụng lại vào cuối.
//! Điều này đúng trong tất cả các trường hợp edge vì các phao IEEE đối xứng xung quanh 0, việc phủ định chỉ đơn giản là lật bit đầu tiên.
//!
//! Sau đó, chúng tôi loại bỏ dấu chấm thập phân bằng cách điều chỉnh số mũ: Về mặt khái niệm, `12.34e56` biến thành `1234e54`, mà chúng tôi mô tả với một số nguyên dương `f = 1234` và một số nguyên `e = 54`.
//! Biểu diễn `(f, e)` được sử dụng bởi hầu hết các mã sau giai đoạn phân tích cú pháp.
//!
//! Sau đó, chúng tôi thử một chuỗi dài các trường hợp đặc biệt tổng quát hơn và đắt tiền hơn bằng cách sử dụng số nguyên cỡ máy và số dấu phẩy động nhỏ, có kích thước cố định (đầu tiên là `f32`/`f64`, sau đó là loại có ý nghĩa 64 bit và `Fp`).
//!
//! Khi tất cả những điều này không thành công, chúng tôi cắn viên đạn và sử dụng một thuật toán đơn giản nhưng rất chậm liên quan đến việc tính toán đầy đủ `f * 10^e` và thực hiện tìm kiếm lặp đi lặp lại để có giá trị gần đúng nhất.
//!
//! Về cơ bản, mô-đun này và các mô-đun con của nó triển khai các thuật toán được mô tả trong:
//! "How to Read Floating Point Numbers Accurately" bởi William D.
//! Clinger, có sẵn trực tuyến: <http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.45.4152>
//!
//! Ngoài ra, có rất nhiều chức năng trợ giúp được sử dụng trong báo cáo nhưng không có sẵn trong Rust (hoặc ít nhất là trong lõi).
//! Phiên bản của chúng tôi cũng phức tạp hơn bởi nhu cầu xử lý tràn và tràn và mong muốn xử lý các số siêu thường.
//! Bellerophon và Algorithm R gặp sự cố với tràn, toán con và dòng chảy dưới.
//! Chúng tôi thận trọng chuyển sang Thuật toán M (với các sửa đổi được mô tả trong phần 8 của bài báo) trước khi các đầu vào đi vào vùng tới hạn.
//!
//! Một khía cạnh khác cần chú ý là trait `` RawFloat '' mà hầu như tất cả các chức năng đều được tham số hóa.Người ta có thể nghĩ rằng nó đủ để phân tích cú pháp thành `f64` và truyền kết quả tới `f32`.
//! Thật không may, đây không phải là thế giới chúng ta đang sống và điều này không liên quan gì đến việc sử dụng cơ số hai hoặc làm tròn nửa đến chẵn.
//!
//! Hãy xem xét ví dụ hai kiểu `d2` và `d4` đại diện cho một kiểu thập phân với hai chữ số thập phân và bốn chữ số thập phân và lấy "0.01499" làm đầu vào.Hãy sử dụng làm tròn một nửa.
//! Chuyển trực tiếp đến hai chữ số thập phân sẽ cho `0.01`, nhưng nếu chúng ta làm tròn đến bốn chữ số trước, chúng ta nhận được `0.0150`, sau đó được làm tròn thành `0.02`.
//! Nguyên tắc tương tự cũng áp dụng cho các hoạt động khác, nếu bạn muốn độ chính xác của 0.5 ULP, bạn cần thực hiện *mọi thứ* với độ chính xác hoàn toàn và làm tròn *chính xác một lần, ở cuối*, bằng cách xem xét tất cả các bit bị cắt ngắn cùng một lúc.
//!
//! FIXME: Mặc dù một số mã trùng lặp là cần thiết, có lẽ các phần của mã có thể được xáo trộn xung quanh để ít mã bị trùng lặp hơn.
//! Các phần lớn của thuật toán không phụ thuộc vào kiểu float để xuất ra, hoặc chỉ cần truy cập vào một vài hằng số, hằng số này có thể được chuyển vào dưới dạng tham số.
//!
//! # Other
//!
//! Việc chuyển đổi không nên *không bao giờ* panic.
//! Có các xác nhận và panics rõ ràng trong mã, nhưng chúng không bao giờ được kích hoạt và chỉ đóng vai trò kiểm tra sự tỉnh táo nội bộ.Bất kỳ panics nào cũng nên được coi là một lỗi.
//!
//! Có những bài kiểm tra đơn vị nhưng chúng không đủ khả năng đảm bảo tính đúng đắn, chúng chỉ bao gồm một tỷ lệ nhỏ các lỗi có thể xảy ra.
//! Các bài kiểm tra mở rộng hơn nằm trong thư mục `src/etc/test-float-parse` dưới dạng tập lệnh Python.
//!
//! Lưu ý về lỗi tràn số nguyên: Nhiều phần của tệp này thực hiện phép tính số học với số mũ thập phân `e`.
//! Về cơ bản, chúng tôi dịch chuyển dấu thập phân xung quanh: Trước chữ số thập phân đầu tiên, sau chữ số thập phân cuối cùng, v.v.Điều này có thể tràn nếu thực hiện bất cẩn.
//! Chúng tôi dựa vào mô-đun con phân tích cú pháp để chỉ đưa ra số mũ đủ nhỏ, trong đó "sufficient" có nghĩa là "such that the exponent +/- the number of decimal digits fits into a 64 bit integer".
//! Các số mũ lớn hơn được chấp nhận, nhưng chúng tôi không tính số học với chúng, chúng ngay lập tức được chuyển thành {positive,negative} {zero,infinity}.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::num::digits_to_big;
use self::parse::{parse_decimal, Decimal, ParseResult, Sign};
use self::rawfp::RawFloat;

mod algorithm;
mod num;
mod table;
// Hai người này có bài kiểm tra riêng của họ.
pub mod parse;
pub mod rawfp;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// Chuyển đổi một chuỗi trong cơ số 10 thành một số float.
            /// Chấp nhận một số mũ thập phân tùy chọn.
            ///
            /// Hàm này chấp nhận các chuỗi như
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', hoặc tương đương, '2.5e10'
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', hoặc, tương đương, '0.5'
            /// * 'inf', '-inf', 'NaN'
            ///
            /// Khoảng trắng đầu và cuối biểu thị một lỗi.
            ///
            /// # Grammar
            ///
            /// Tất cả các chuỗi tuân theo ngữ pháp [EBNF] sau sẽ dẫn đến việc trả về [`Ok`]:
            ///
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'NaN' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= [eE] Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # Các lỗi đã biết
            ///
            /// Trong một số tình huống, một số chuỗi sẽ tạo một số nổi hợp lệ thay vì trả về lỗi.
            /// Xem [issue #31407] để biết thêm chi tiết.
            ///
            /// [issue #31407]: https://github.com/rust-lang/rust/issues/31407
            ///
            /// # Arguments
            ///
            /// * src, Một chuỗi
            ///
            /// # Giá trị trả lại
            ///
            /// `Err(ParseFloatError)` nếu chuỗi không đại diện cho một số hợp lệ.
            /// Nếu không, `Ok(n)` trong đó `n` là số dấu phẩy động được biểu thị bằng `src`.
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// Một lỗi có thể được trả về khi phân tích cú pháp float.
///
/// Lỗi này được sử dụng làm loại lỗi cho việc triển khai [`FromStr`] cho [`f32`] và [`f64`].
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {}", e);
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// Tách một chuỗi thập phân thành dấu và phần còn lại, mà không cần kiểm tra hoặc xác nhận phần còn lại.
fn extract_sign(s: &str) -> (Sign, &str) {
    match s.as_bytes()[0] {
        b'+' => (Sign::Positive, &s[1..]),
        b'-' => (Sign::Negative, &s[1..]),
        // Nếu chuỗi không hợp lệ, chúng tôi không bao giờ sử dụng dấu, vì vậy chúng tôi không cần xác thực ở đây.
        _ => (Sign::Positive, s),
    }
}

/// Chuyển đổi một chuỗi thập phân thành một số dấu phẩy động.
fn dec2flt<T: RawFloat>(s: &str) -> Result<T, ParseFloatError> {
    if s.is_empty() {
        return Err(pfe_empty());
    }
    let (sign, s) = extract_sign(s);
    let flt = match parse_decimal(s) {
        ParseResult::Valid(decimal) => convert(decimal)?,
        ParseResult::ShortcutToInf => T::INFINITY,
        ParseResult::ShortcutToZero => T::ZERO,
        ParseResult::Invalid => match s {
            "inf" => T::INFINITY,
            "NaN" => T::NAN,
            _ => {
                return Err(pfe_invalid());
            }
        },
    };

    match sign {
        Sign::Positive => Ok(flt),
        Sign::Negative => Ok(-flt),
    }
}

/// Workhorse chính cho việc chuyển đổi từ thập phân sang float: Điều phối tất cả quá trình tiền xử lý và tìm ra thuật toán nào sẽ thực hiện chuyển đổi thực tế.
///
fn convert<T: RawFloat>(mut decimal: Decimal<'_>) -> Result<T, ParseFloatError> {
    simplify(&mut decimal);
    if let Some(x) = trivial_cases(&decimal) {
        return Ok(x);
    }
    // Remove/shift ra dấu thập phân.
    let e = decimal.exp - decimal.fractional.len() as i64;
    if let Some(x) = algorithm::fast_path(decimal.integral, decimal.fractional, e) {
        return Ok(x);
    }
    // Big32x40 được giới hạn ở 1280 bit, nghĩa là khoảng 385 chữ số thập phân.
    // Nếu vượt quá mức này, chúng ta sẽ gặp sự cố, vì vậy chúng ta sẽ gặp lỗi trước khi đến quá gần (trong vòng 10 ^ 10).
    let upper_bound = bound_intermediate_digits(&decimal, e);
    if upper_bound > 375 {
        return Err(pfe_invalid());
    }
    let f = digits_to_big(decimal.integral, decimal.fractional);

    // Bây giờ số mũ chắc chắn phù hợp với 16 bit, được sử dụng trong các thuật toán chính.
    let e = e as i16;
    // FIXME Những giới hạn này khá thận trọng.
    // Phân tích cẩn thận hơn về các chế độ lỗi của Bellerophon có thể cho phép sử dụng nó trong nhiều trường hợp hơn để tăng tốc độ lớn.
    let exponent_in_range = table::MIN_E <= e && e <= table::MAX_E;
    let value_in_range = upper_bound <= T::MAX_NORMAL_DIGITS as u64;
    if exponent_in_range && value_in_range {
        Ok(algorithm::bellerophon(&f, e))
    } else {
        Ok(algorithm::algorithm_m(&f, e))
    }
}

// Như đã viết, điều này tối ưu hóa không tốt (xem #27130, mặc dù nó đề cập đến phiên bản cũ của mã).
// `inline(always)` là một giải pháp thay thế cho điều đó.
// Chỉ có hai trang web gọi tổng thể và nó không làm cho kích thước mã tồi tệ hơn.

/// Loại bỏ các số không nếu có thể, ngay cả khi điều này yêu cầu thay đổi số mũ
#[inline(always)]
fn simplify(decimal: &mut Decimal<'_>) {
    let is_zero = &|&&d: &&u8| -> bool { d == b'0' };
    // Việc cắt bớt các số không này không thay đổi bất cứ điều gì nhưng có thể kích hoạt đường dẫn nhanh (<15 chữ số).
    let leading_zeros = decimal.integral.iter().take_while(is_zero).count();
    decimal.integral = &decimal.integral[leading_zeros..];
    let trailing_zeros = decimal.fractional.iter().rev().take_while(is_zero).count();
    let end = decimal.fractional.len() - trailing_zeros;
    decimal.fractional = &decimal.fractional[..end];
    // Đơn giản hóa các số có dạng 0,0 ... x và x ... 0,0, điều chỉnh số mũ cho phù hợp.
    // Điều này có thể không phải lúc nào cũng là chiến thắng (có thể đẩy một số con số ra khỏi đường dẫn nhanh), nhưng nó đơn giản hóa các phần khác một cách đáng kể (đáng chú ý là tính gần đúng độ lớn của giá trị).
    //
    if decimal.integral.is_empty() {
        let leading_zeros = decimal.fractional.iter().take_while(is_zero).count();
        decimal.fractional = &decimal.fractional[leading_zeros..];
        decimal.exp -= leading_zeros as i64;
    } else if decimal.fractional.is_empty() {
        let trailing_zeros = decimal.integral.iter().rev().take_while(is_zero).count();
        let end = decimal.integral.len() - trailing_zeros;
        decimal.integral = &decimal.integral[..end];
        decimal.exp += trailing_zeros as i64;
    }
}

/// Trả về giới hạn trên nhanh chóng trên kích thước (log10) của giá trị lớn nhất mà Thuật toán R và Thuật toán M sẽ tính toán trong khi làm việc với số thập phân đã cho.
///
fn bound_intermediate_digits(decimal: &Decimal<'_>, e: i64) -> u64 {
    // Chúng ta không cần phải lo lắng quá nhiều về việc tràn ở đây nhờ trivial_cases() và trình phân tích cú pháp, lọc ra các đầu vào khắc nghiệt nhất cho chúng ta.
    //
    let f_len: u64 = decimal.integral.len() as u64 + decimal.fractional.len() as u64;
    if e >= 0 {
        // Trong trường hợp e>=0, cả hai thuật toán đều tính toán về `f * 10^e`.
        // Thuật toán R tiến hành thực hiện một số phép tính phức tạp với điều này nhưng chúng ta có thể bỏ qua điều đó đối với giới hạn trên vì nó cũng làm giảm phân số trước đó, vì vậy chúng ta có rất nhiều bộ đệm ở đó.
        //
        f_len + (e as u64)
    } else {
        // Nếu e <0, Thuật toán R thực hiện gần giống như vậy, nhưng Thuật toán M khác:
        // Nó cố gắng tìm một số dương k sao cho `f << k / 10^e` là một ý nghĩa trong phạm vi.
        // Điều này sẽ dẫn đến khoảng `2^53 *f* 10^e` <`10^17 *f* 10^e`.
        // Một đầu vào kích hoạt điều này là 0,33 ... 33 (375 x 3).
        f_len + e.unsigned_abs() + 17
    }
}

/// Phát hiện dòng chảy tràn và dòng chảy thiếu rõ ràng mà không cần nhìn vào các chữ số thập phân.
fn trivial_cases<T: RawFloat>(decimal: &Decimal<'_>) -> Option<T> {
    // Có những số không nhưng chúng đã bị simplify() loại bỏ
    if decimal.integral.is_empty() && decimal.fractional.is_empty() {
        return Some(T::ZERO);
    }
    // Đây là giá trị gần đúng của ceil(log10(the real value)).
    // Chúng ta không cần phải lo lắng quá nhiều về việc tràn ở đây vì độ dài đầu vào là rất nhỏ (ít nhất là so với 2 ^ 64) và trình phân tích cú pháp đã xử lý số mũ có giá trị tuyệt đối lớn hơn 10 ^ 18 (vẫn còn ngắn 10 ^ 19 trong tổng số 2 ^ 64).
    //
    //
    let max_place = decimal.exp + decimal.integral.len() as i64;
    if max_place > T::INF_CUTOFF {
        return Some(T::INFINITY);
    } else if max_place < T::ZERO_CUTOFF {
        return Some(T::ZERO);
    }
    None
}