//! Bit loay hoay trên các phao IEEE 754 tích cực.Số âm không phải và không cần phải xử lý.
//! Các số dấu phẩy động bình thường có biểu diễn chính tắc là (frac, exp) sao cho giá trị là 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) với N là số bit.
//!
//! Subnormals hơi khác và kỳ lạ, nhưng cùng một nguyên tắc áp dụng.
//!
//! Tuy nhiên, ở đây, chúng tôi biểu diễn chúng là (sig, k) với f dương, sao cho giá trị là f *
//! 2 <sup>e</sup> .Bên cạnh việc làm cho "hidden bit" rõ ràng, điều này thay đổi số mũ bằng cái gọi là dịch chuyển định trị.
//!
//! Nói một cách khác, các float thông thường được viết là (1) nhưng ở đây chúng được viết là (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Chúng tôi gọi (1) là **biểu diễn phân số** và (2) là **biểu diễn tích phân**.
//!
//! Nhiều chức năng trong mô-đun này chỉ xử lý các số bình thường.Các quy trình dec2flt thực hiện một cách thận trọng đường đi chậm được phổ biến chính xác (Thuật toán M) cho các số rất nhỏ và rất lớn.
//! Thuật toán đó chỉ cần next_float() xử lý các giá trị con và số không.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Một trình trợ giúp trait để tránh trùng lặp về cơ bản tất cả các mã chuyển đổi cho `f32` và `f64`.
///
/// Xem nhận xét tài liệu của mô-đun mẹ để biết lý do tại sao điều này là cần thiết.
///
/// **Không bao giờ nên** không bao giờ được triển khai cho các loại khác hoặc được sử dụng bên ngoài mô-đun dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Loại được sử dụng bởi `to_bits` và `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Thực hiện chuyển đổi thô thành một số nguyên.
    fn to_bits(self) -> Self::Bits;

    /// Thực hiện chuyển đổi thô từ một số nguyên.
    fn from_bits(v: Self::Bits) -> Self;

    /// Trả về danh mục mà số này thuộc.
    fn classify(self) -> FpCategory;

    /// Trả về phần định trị, số mũ và dấu dưới dạng số nguyên.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Giải mã phao.
    fn unpack(self) -> Unpacked;

    /// Truyền từ một số nguyên nhỏ có thể được biểu diễn chính xác.
    /// Panic nếu số nguyên không thể được biểu diễn, mã khác trong mô-đun này đảm bảo sẽ không bao giờ để điều đó xảy ra.
    fn from_int(x: u64) -> Self;

    /// Nhận giá trị 10 <sup>e</sup> từ một bảng được tính toán trước.
    /// Panics dành cho `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Cái tên nói lên điều gì.
    /// Nó dễ dàng hơn để viết mã khó hơn so với các bản chất phức tạp và hy vọng LLVM không đổi sẽ gấp nó lại.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Một giới hạn thận trọng trên các chữ số thập phân của đầu vào không thể tạo ra tràn hoặc không hoặc
    /// subnormals.Có lẽ là số mũ thập phân của giá trị bình thường lớn nhất, do đó có tên.
    const MAX_NORMAL_DIGITS: usize;

    /// Khi chữ số thập phân quan trọng nhất có giá trị vị trí lớn hơn giá trị này, thì số đó chắc chắn được làm tròn đến vô cùng.
    ///
    const INF_CUTOFF: i64;

    /// Khi chữ số thập phân quan trọng nhất có giá trị vị trí nhỏ hơn giá trị này, thì số đó chắc chắn được làm tròn thành 0.
    ///
    const ZERO_CUTOFF: i64;

    /// Số bit trong số mũ.
    const EXP_BITS: u8;

    /// Số lượng bit trong ý nghĩa và,*bao gồm* bit ẩn.
    const SIG_BITS: u8;

    /// Số lượng bit trong ý nghĩa và,*không bao gồm* bit ẩn.
    const EXPLICIT_SIG_BITS: u8;

    /// Số mũ hợp pháp tối đa trong biểu diễn phân số.
    const MAX_EXP: i16;

    /// Số mũ hợp pháp tối thiểu trong biểu diễn phân số, không bao gồm các đại số con.
    const MIN_EXP: i16;

    /// `MAX_EXP` đối với biểu diễn tích phân, tức là, với sự thay đổi được áp dụng.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` được mã hóa (nghĩa là với độ lệch bù đắp)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` đối với biểu diễn tích phân, tức là, với sự thay đổi được áp dụng.
    const MIN_EXP_INT: i16;

    /// Ý nghĩa chuẩn hóa tối đa và trong biểu diễn tích phân.
    const MAX_SIG: u64;

    /// Ý nghĩa chuẩn hóa tối thiểu và trong biểu diễn tích phân.
    const MIN_SIG: u64;
}

// Chủ yếu là một giải pháp thay thế cho #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Trả về phần định trị, số mũ và dấu dưới dạng số nguyên.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Thiên vị số mũ + dịch chuyển phần định trị
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe không chắc liệu `as` có quay vòng chính xác trên tất cả các nền tảng hay không.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Trả về phần định trị, số mũ và dấu dưới dạng số nguyên.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Thiên vị số mũ + dịch chuyển phần định trị
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe không chắc liệu `as` có quay vòng chính xác trên tất cả các nền tảng hay không.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Chuyển đổi `Fp` thành loại phao máy gần nhất.
/// Không xử lý kết quả bất thường.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f là 64 bit, do đó xe có độ dịch chuyển định trị là 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Làm tròn ý nghĩa 64-bit và đến các bit T::SIG_BITS với nửa đến chẵn.
/// Không xử lý tràn số mũ.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Điều chỉnh dịch chuyển phần định trị
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Nghịch đảo của `RawFloat::unpack()` cho các số chuẩn hóa.
/// Panics nếu ý nghĩa và số mũ không hợp lệ cho các số chuẩn hóa.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Xóa bit ẩn
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Điều chỉnh số mũ để có thiên vị số mũ và dịch chuyển phần định trị
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Để lại bit dấu ở 0 ("+"), các số của chúng tôi đều là số dương
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Xây dựng một công trình phụ.Cho phép một phần định trị 0 và tạo ra số 0.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Số mũ được mã hóa là 0, bit dấu là 0, vì vậy chúng ta chỉ cần giải thích lại các bit.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Gần đúng bignum với Fp.Làm tròn trong 0.5 ULP với giá trị từ nửa đến chẵn.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Chúng tôi cắt tất cả các bit trước chỉ số `start`, tức là chúng tôi dịch sang phải một cách hiệu quả một lượng `start`, vì vậy đây cũng là số mũ mà chúng tôi cần.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Làm tròn (half-to-even) tùy thuộc vào các bit bị cắt ngắn.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Tìm số dấu phẩy động lớn nhất nhỏ hơn đối số.
/// Không xử lý dòng dưới hàm số dưới, số 0 hoặc số mũ.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Tìm số dấu chấm động nhỏ nhất lớn hơn đối số.
// Thao tác này đang bão hòa, tức là next_float(inf) ==inf.
// Không giống như hầu hết các mã trong mô-đun này, hàm này xử lý số 0, số con và số vô hạn.
// Tuy nhiên, giống như tất cả các mã khác ở đây, nó không xử lý NaN và số âm.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Điều này có vẻ quá tốt là đúng, nhưng nó hoạt động.
        // 0.0 được mã hóa dưới dạng từ hoàn toàn không.Các số dưới là 0x000m ... m trong đó m là phần định trị.
        // Trong đó, hàm phụ nhỏ nhất là 0x0 ... 01 và lớn nhất là 0x000F ... F.
        // Số bình thường nhỏ nhất là 0x0010 ... 0, vì vậy trường hợp góc này cũng hoạt động.
        // Nếu số gia làm tràn phần định trị, thì bit mang sẽ tăng số mũ như chúng ta muốn và các bit phần định trị trở thành số không.
        // Bởi vì quy ước bit ẩn, đây cũng chính xác là những gì chúng ta muốn!
        // Cuối cùng, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}