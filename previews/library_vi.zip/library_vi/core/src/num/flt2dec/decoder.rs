//! Giải mã giá trị dấu phẩy động thành các phần riêng lẻ và phạm vi lỗi.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Giá trị hữu hạn chưa được giải mã, sao cho:
///
/// - Giá trị ban đầu bằng `mant * 2^exp`.
///
/// - Bất kỳ số nào từ `(mant - minus)*2^exp` đến `(mant + plus)* 2^exp` sẽ làm tròn thành giá trị ban đầu.
/// Phạm vi chỉ bao gồm khi `inclusive` là `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Phần định trị có tỉ lệ.
    pub mant: u64,
    /// Phạm vi lỗi thấp hơn.
    pub minus: u64,
    /// Phạm vi lỗi trên.
    pub plus: u64,
    /// Số mũ được chia sẻ trong cơ số 2.
    pub exp: i16,
    /// Đúng khi phạm vi lỗi là bao gồm.
    ///
    /// Trong IEEE 754, điều này đúng khi phần định trị ban đầu là số chẵn.
    pub inclusive: bool,
}

/// Giá trị không dấu được giải mã.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Số vô hạn, dương hoặc âm.
    Infinite,
    /// Không, có thể là tích cực hoặc tiêu cực.
    Zero,
    /// Số hữu hạn với các trường được giải mã thêm.
    Finite(Decoded),
}

/// Một loại dấu phẩy động có thể được `giải mã`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Giá trị chuẩn hóa dương tối thiểu.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Trả về một dấu (đúng khi âm) và giá trị `FullDecoded` từ số dấu phẩy động đã cho.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // hàng xóm: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode luôn bảo toàn số mũ, vì vậy phần định trị được chia tỷ lệ cho các cấp số con.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // hàng xóm: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // trong đó maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // hàng xóm: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}