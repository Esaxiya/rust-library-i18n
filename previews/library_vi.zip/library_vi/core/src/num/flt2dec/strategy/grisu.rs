//! Sự thích ứng Rust của thuật toán Grisu3 được mô tả trong "In các số dấu phẩy động một cách nhanh chóng và chính xác với số nguyên" [^ 1].
//! Nó sử dụng khoảng 1KB bảng được tính toán trước và đến lượt nó, nó rất nhanh cho hầu hết các đầu vào.
//!
//! [^1]: Florian Loitsch.2010. In nhanh số dấu phẩy động và
//!   chính xác với số nguyên.SIGPLAN Không.45, 6 (tháng 6 năm 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// xem các nhận xét trong `format_shortest_opt` để biết cơ sở lý luận.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Cho trước `x > 0`, trả về `(k, 10^k)` sao cho `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Thực hiện chế độ ngắn nhất cho Grisu.
///
/// Nó trả về `None` khi ngược lại nó sẽ trả về một biểu diễn không chính xác.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // chúng tôi cần ít nhất ba bit độ chính xác bổ sung

    // bắt đầu với các giá trị chuẩn hóa với số mũ được chia sẻ
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // tìm bất kỳ `cached = 10^minusk` nào sao cho `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // vì `plus` được chuẩn hóa, điều này có nghĩa là `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // với sự lựa chọn của chúng tôi về `ALPHA` và `GAMMA`, điều này đặt `plus * cached` thành `[4, 2^32)`.
    //
    // Rõ ràng là mong muốn tối đa hóa `GAMMA - ALPHA`, để chúng tôi không cần nhiều quyền hạn được lưu trong bộ nhớ cache của 10, nhưng có một số cân nhắc:
    //
    //
    // 1. chúng tôi muốn giữ `floor(plus * cached)` bên trong `u32` vì nó cần một bộ phận tốn kém.
    //    (điều này thực sự không thể tránh được, phần còn lại là cần thiết để ước tính độ chính xác.)
    // 2.
    // phần còn lại của `floor(plus * cached)` liên tục được nhân với 10 và nó sẽ không bị tràn.
    //
    // đầu tiên cho `64 + GAMMA <= 32`, trong khi thứ hai cho `10 * 2^-ALPHA <= 2^64`;
    // -60 và -32 là phạm vi tối đa với giới hạn này và V8 cũng sử dụng chúng.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // tỷ lệ khung hình/giây.điều này tạo ra sai số lớn nhất là 1 ulp (được chứng minh từ Định lý 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-phạm vi thực tế của trừ
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // ở trên `minus`, `v` và `plus` là các xấp xỉ *lượng tử hóa*(sai số <1 ulp).
    // Vì chúng ta không biết sai số là dương hay âm, nên chúng ta sử dụng hai phép gần đúng cách đều nhau và có sai số lớn nhất là 2 ulp.
    //
    // "unsafe region" là khoảng tự do mà chúng tôi tạo ra ban đầu.
    // "safe region" là khoảng thời gian bảo tồn mà chúng tôi chỉ chấp nhận.
    // chúng tôi bắt đầu với đại diện chính xác trong vùng không an toàn và cố gắng tìm đại diện gần nhất với `v` cũng nằm trong vùng an toàn.
    // nếu chúng tôi không thể, chúng tôi từ bỏ.
    //
    let plus1 = plus.f + 1;
    // cho plus0 = plus.f, 1;//chỉ để giải thích let minus0 = minus.f + 1;//chỉ để giải thích
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // số mũ chia sẻ

    // chia `plus1` thành các phần tích phân và phân số.
    // các bộ phận tích hợp được đảm bảo phù hợp với u32, vì năng lượng được lưu trong bộ nhớ đệm đảm bảo `plus < 2^32` và `plus.f` chuẩn hóa luôn nhỏ hơn `2^64 - 2^4` do yêu cầu về độ chính xác.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // tính `10^max_kappa` lớn nhất không quá `plus1` (do đó `plus1 < 10^(max_kappa+1)`).
    // đây là giới hạn trên của `kappa` bên dưới.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Định lý 6.2: nếu `k` là số nguyên lớn nhất st
    // `0 <= y mod 10^k <= y - x`,              thì `V = floor(y / 10^k) * 10^k` nằm trong `[x, y]` và là một trong những đại diện ngắn nhất (với số chữ số có nghĩa tối thiểu) trong phạm vi đó.
    //
    //
    // tìm độ dài chữ số `kappa` giữa `(minus1, plus1)` theo Định lý 6.2.
    // Định lý 6.2 có thể được chấp nhận để loại trừ `x` bằng cách yêu cầu `y mod 10^k < y - x` thay thế.
    // (ví dụ: `x` =32000, `y` =32777; `kappa` =2 vì `y mod 10 ^ 3=777 <y, x=777`.) thuật toán dựa vào giai đoạn xác minh sau để loại trừ `y`.
    //
    let delta1 = plus1 - minus1;
    // let delta1int=(delta1>> e) as usize;//chỉ để giải thích
    let delta1frac = delta1 & ((1 << e) - 1);

    // kết xuất các bộ phận không thể tách rời, đồng thời kiểm tra độ chính xác ở mỗi bước.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // các chữ số chưa được hiển thị
    loop {
        // chúng tôi luôn có ít nhất một chữ số để hiển thị, vì `plus1 >= 10^kappa` bất biến:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (nó theo sau `remainder = plus1int % 10^(kappa+1)` đó)
        //
        //

        // chia `remainder` cho `10^kappa`.cả hai đều được chia tỷ lệ bằng `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; chúng tôi đã tìm thấy đúng `kappa`.
            let ten_kappa = (ten_kappa as u64) << e; // chia tỷ lệ 10 ^ kappa trở lại số mũ được chia sẻ
            return round_and_weed(
                // AN TOÀN: chúng tôi đã khởi tạo bộ nhớ đó ở trên.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // phá vỡ vòng lặp khi chúng tôi đã hiển thị tất cả các chữ số tích phân.
        // số chữ số chính xác là `max_kappa + 1` là `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // khôi phục các bất biến
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // hiển thị các phần phân số, đồng thời kiểm tra độ chính xác ở mỗi bước.
    // lần này chúng ta dựa vào các phép nhân lặp đi lặp lại, vì phép chia sẽ mất độ chính xác.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // chữ số tiếp theo phải có ý nghĩa vì chúng tôi đã kiểm tra điều đó trước khi phát hiện ra các bất biến, trong đó `m = max_kappa + 1` (#chữ số trong phần tích phân):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // sẽ không tràn, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // chia `remainder` cho `10^kappa`.
        // cả hai đều được chia tỷ lệ bằng `2^e / 10^kappa`, vì vậy cái thứ hai là ẩn ở đây.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // ước số ngầm
            return round_and_weed(
                // AN TOÀN: chúng tôi đã khởi tạo bộ nhớ đó ở trên.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // khôi phục các bất biến
        kappa -= 1;
        remainder = r;
    }

    // chúng tôi đã tạo tất cả các chữ số có nghĩa của `plus1`, nhưng không chắc đó có phải là chữ số tối ưu hay không.
    // ví dụ: nếu `minus1` là 3,14153 ... và `plus1` là 3,14158 ..., có 5 đại diện ngắn nhất khác nhau từ 3.14154 đến 3.14158 nhưng chúng tôi chỉ có một đại diện lớn nhất.
    // chúng ta phải giảm liên tiếp chữ số cuối cùng và kiểm tra xem đây có phải là đại diện tối ưu hay không.
    // có nhiều nhất 9 ứng cử viên (. 1 đến ..9), vì vậy điều này khá nhanh chóng.(Pha "rounding")
    //
    // hàm kiểm tra xem đại diện "optimal" này có thực sự nằm trong phạm vi ulp hay không và cũng có thể đại diện "second-to-optimal" thực sự có thể tối ưu do lỗi làm tròn.
    // trong cả hai trường hợp, điều này trả về `None`.
    // (Pha "weeding")
    //
    // tất cả các đối số ở đây được chia tỷ lệ bằng giá trị chung (nhưng ẩn) `k`, do đó:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (và cả `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (và cả `threshold > plus1v` từ các bất biến trước đó)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // tạo ra hai giá trị gần đúng với `v` (thực tế là `plus1 - v`) trong ulps 1.5.
        // biểu diễn kết quả phải là biểu diễn gần nhất với cả hai.
        //
        // ở đây `plus1 - v` được sử dụng vì các phép tính được thực hiện đối với `plus1` để tránh overflow/underflow (do đó các tên dường như đã được hoán đổi).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // giảm chữ số cuối cùng và dừng lại ở điểm biểu diễn gần nhất với `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // chúng tôi làm việc với các chữ số gần đúng `w(n)`, ban đầu bằng `plus1 - plus1 % 10^kappa`.sau khi chạy nội dung vòng lặp `n` lần, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // chúng tôi đặt `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (do đó `remainder= plus1w(0)`) để đơn giản hóa việc kiểm tra.
            // lưu ý rằng `plus1w(n)` luôn tăng.
            //
            // chúng ta có ba điều kiện để chấm dứt.bất kỳ trong số chúng sẽ làm cho vòng lặp không thể tiếp tục, nhưng sau đó chúng tôi có ít nhất một biểu diễn hợp lệ được biết là gần nhất với `v + 1 ulp`.
            // chúng tôi sẽ ký hiệu chúng là TC1 đến TC3 cho ngắn gọn.
            //
            // TC1: `w(n) <= v + 1 ulp`, tức là, đây là lần trả lời cuối cùng có thể là lần gần nhất.
            // điều này tương đương với `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // kết hợp với TC2 (kiểm tra xem `w(n+1)` is valid) hay không, điều này ngăn chặn sự tràn có thể xảy ra khi tính toán `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, tức là lần repr tiếp theo chắc chắn không làm tròn thành `v`.
            // điều này tương đương với `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // phía bên trái có thể bị tràn, nhưng chúng tôi biết `threshold > plus1v`, vì vậy nếu TC1 là false, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` và chúng tôi có thể kiểm tra một cách an toàn nếu `threshold - plus1w(n) < 10^kappa` thay thế.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, tức là repr tiếp theo là
            // không gần với `v + 1 ulp` hơn đại diện hiện tại.
            // đã cho `z(n) = plus1v_up - plus1w(n)`, giá trị này sẽ trở thành `abs(z(n)) <= abs(z(n+1))`.một lần nữa giả sử rằng TC1 là false, chúng ta có `z(n) > 0`.chúng ta có hai trường hợp cần xem xét:
            //
            // - khi `z(n+1) >= 0`: TC3 trở thành `z(n) <= z(n+1)`.
            // vì `plus1w(n)` đang tăng, `z(n)` sẽ giảm và điều này rõ ràng là sai.
            // - khi `z(n+1) < 0`:
            //   - TC3a: điều kiện tiên quyết là `plus1v_up < plus1w(n) + 10^kappa`.giả sử TC2 là false, `threshold >= plus1w(n) + 10^kappa` vì vậy nó không thể tràn.
            //   - TC3b: TC3 trở thành `z(n) <= -z(n+1)`, tức là, `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   TC1 phủ định cho `plus1v_up > plus1w(n)`, vì vậy nó không thể tràn hoặc tràn khi kết hợp với TC3a.
            //
            // do đó, chúng ta nên dừng khi `TC1 || TC2 || (TC3a && TC3b)`.phần sau bằng với nghịch đảo của nó, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // repr ngắn nhất không thể kết thúc bằng `0`
                plus1w += ten_kappa;
            }
        }

        // kiểm tra xem biểu diễn này có phải là biểu diễn gần nhất với `v - 1 ulp` hay không.
        //
        // điều này đơn giản giống với các điều kiện kết thúc cho `v + 1 ulp`, với tất cả `plus1v_up` được thay thế bằng `plus1v_down`.
        // phân tích tràn đều giữ nguyên.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // bây giờ chúng tôi có đại diện gần nhất với `v` giữa `plus1` và `minus1`.
        // Tuy nhiên, điều này là quá tự do, vì vậy chúng tôi từ chối bất kỳ `w(n)` nào không nằm giữa `plus0` và `minus0`, tức là `plus1 - plus1w(n) <= minus0` hoặc `plus1 - plus1w(n) >= plus0`.
        // chúng tôi sử dụng các dữ kiện `threshold = plus1 - minus1` và `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Thực hiện chế độ ngắn nhất cho Grisu với Dragon dự phòng.
///
/// Điều này nên được sử dụng cho hầu hết các trường hợp.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // AN TOÀN: Trình kiểm tra khoản vay không đủ thông minh để cho phép chúng tôi sử dụng `buf`
    // trong branch thứ hai, vì vậy chúng tôi rửa toàn bộ thời gian ở đây.
    // Nhưng chúng tôi chỉ sử dụng lại `buf` nếu `format_shortest_opt` trả về `None` nên điều này không sao cả.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Việc triển khai chế độ chính xác và cố định cho Grisu.
///
/// Nó trả về `None` khi ngược lại nó sẽ trả về một biểu diễn không chính xác.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // chúng tôi cần ít nhất ba bit độ chính xác bổ sung
    assert!(!buf.is_empty());

    // chuẩn hóa và chia tỷ lệ `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // chia `v` thành các phần tích phân và phân số.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // cả `v` cũ và `v` mới (được chia tỷ lệ bằng `10^-k`) đều có sai số <1 ulp (Định lý 5.1).
    // Vì chúng ta không biết sai số là dương hay âm, nên chúng ta sử dụng hai phép gần đúng cách đều nhau và có sai số lớn nhất là 2 ulp (giống trường hợp ngắn nhất).
    //
    //
    // mục tiêu là tìm ra dãy chữ số được làm tròn chính xác chung cho cả `v - 1 ulp` và `v + 1 ulp`, để chúng tôi hoàn toàn tự tin.
    // nếu điều này là không thể, chúng tôi không biết đầu ra nào là đầu ra chính xác cho `v`, vì vậy chúng tôi đã bỏ cuộc và quay trở lại.
    //
    // `err` được định nghĩa là `1 ulp * 2^e` ở đây (giống với ulp trong `vfrac`) và chúng tôi sẽ chia tỷ lệ bất cứ khi nào `v` được mở rộng.
    //
    //
    //
    let mut err = 1;

    // tính `10^max_kappa` lớn nhất không quá `v` (do đó `v < 10^(max_kappa+1)`).
    // đây là giới hạn trên của `kappa` bên dưới.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // nếu chúng tôi đang làm việc với giới hạn chữ số cuối cùng, chúng tôi cần rút ngắn bộ đệm trước khi hiển thị thực tế để tránh làm tròn hai lần.
    //
    // lưu ý rằng chúng ta phải mở rộng bộ đệm một lần nữa khi việc làm tròn xảy ra!
    let len = if exp <= limit {
        // rất tiếc, chúng tôi thậm chí không thể tạo ra *một* chữ số.
        // điều này có thể xảy ra khi chúng ta có một cái gì đó giống như 9.5 và nó được làm tròn thành 10.
        //
        // về nguyên tắc, chúng ta có thể gọi ngay `possibly_round` với một bộ đệm trống, nhưng việc mở rộng `max_ten_kappa << e` bằng 10 có thể dẫn đến tràn.
        //
        // do đó, chúng tôi đang cẩu thả ở đây và mở rộng phạm vi lỗi lên hệ số 10.
        // điều này sẽ làm tăng tỷ lệ âm tính giả, nhưng chỉ rất,*rất* một chút;
        // nó chỉ có thể có vấn đề đáng chú ý khi phần định trị lớn hơn 60 bit.
        //
        // AN TOÀN: `len=0`, vì vậy nghĩa vụ khởi tạo bộ nhớ này là không đáng kể.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // kết xuất các bộ phận tích hợp.
    // lỗi hoàn toàn là phân số, vì vậy chúng ta không cần kiểm tra nó trong phần này.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // các chữ số chưa được hiển thị
    loop {
        // chúng tôi luôn có ít nhất một chữ số để hiển thị các bất biến:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (nó theo sau `remainder = vint % 10^(kappa+1)` đó)
        //
        //

        // chia `remainder` cho `10^kappa`.cả hai đều được chia tỷ lệ bằng `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // bộ đệm có đầy không?chạy vượt qua làm tròn với phần còn lại.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // AN TOÀN: chúng tôi đã khởi tạo `len` nhiều byte.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // phá vỡ vòng lặp khi chúng tôi đã hiển thị tất cả các chữ số tích phân.
        // số chữ số chính xác là `max_kappa + 1` là `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // khôi phục các bất biến
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // kết xuất các phần phân số.
    //
    // về nguyên tắc, chúng tôi có thể tiếp tục đến chữ số cuối cùng có sẵn và kiểm tra độ chính xác.
    // Rất tiếc, chúng tôi đang làm việc với các số nguyên có kích thước hữu hạn, vì vậy chúng tôi cần một số tiêu chí để phát hiện tràn.
    // V8 sử dụng `remainder > err`, điều này sẽ trở thành sai khi các chữ số có nghĩa `i` đầu tiên của `v - 1 ulp` và `v` khác nhau.
    // tuy nhiên điều này từ chối quá nhiều đầu vào hợp lệ.
    //
    // vì giai đoạn sau có phát hiện tràn chính xác, thay vào đó chúng tôi sử dụng tiêu chí chặt chẽ hơn:
    // chúng tôi tiếp tục cho đến khi `err` vượt quá `10^kappa / 2`, để phạm vi giữa `v - 1 ulp` và `v + 1 ulp` chắc chắn chứa hai hoặc nhiều biểu diễn làm tròn.
    //
    // điều này giống với hai so sánh đầu tiên từ `possibly_round`, để tham khảo.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // bất biến, trong đó `m = max_kappa + 1` (#chữ số trong phần tích phân):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // sẽ không tràn, `2^e * 10 < 2^64`
        err *= 10; // sẽ không tràn, `err * 10 < 2^e * 5 < 2^64`

        // chia `remainder` cho `10^kappa`.
        // cả hai đều được chia tỷ lệ bằng `2^e / 10^kappa`, vì vậy cái thứ hai là ẩn ở đây.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // bộ đệm có đầy không?chạy vượt qua làm tròn với phần còn lại.
        if i == len {
            // AN TOÀN: chúng tôi đã khởi tạo `len` nhiều byte.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // khôi phục các bất biến
        remainder = r;
    }

    // tính toán thêm cũng vô ích (`possibly_round` chắc chắn không thành công) nên chúng tôi bỏ cuộc.
    return None;

    // chúng tôi đã tạo tất cả các chữ số được yêu cầu của `v`, các chữ số này cũng phải giống với các chữ số tương ứng của `v - 1 ulp`.
    // bây giờ chúng tôi kiểm tra xem có một đại diện duy nhất được chia sẻ bởi cả `v - 1 ulp` và `v + 1 ulp` hay không;điều này có thể giống với các chữ số được tạo hoặc với phiên bản làm tròn của các chữ số đó.
    //
    // nếu phạm vi chứa nhiều đại diện có cùng độ dài, chúng tôi không thể chắc chắn và thay vào đó nên trả về `None`.
    //
    // tất cả các đối số ở đây được chia tỷ lệ bằng giá trị chung (nhưng ẩn) `k`, do đó:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // AN TOÀN: các byte `len` đầu tiên của `buf` phải được khởi tạo.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (để tham khảo, đường chấm chấm chỉ ra giá trị chính xác cho các biểu diễn có thể có trong một số chữ số nhất định.)
        //
        //
        // lỗi quá lớn nên có thể có ít nhất ba biểu diễn giữa `v - 1 ulp` và `v + 1 ulp`.
        // chúng tôi không thể xác định cái nào là chính xác.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // trên thực tế, 1/2 ulp đủ để giới thiệu hai cách biểu diễn có thể có.
        // (hãy nhớ rằng chúng tôi cần một đại diện duy nhất cho cả `v - 1 ulp` và `v + 1 ulp`.) điều này sẽ không tràn, vì `ulp < ten_kappa` từ lần kiểm tra đầu tiên.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // nếu `v + 1 ulp` gần với biểu diễn làm tròn xuống (đã có trong `buf`), thì chúng ta có thể quay trở lại một cách an toàn.
        // lưu ý rằng `v - 1 ulp`*có thể* nhỏ hơn biểu diễn hiện tại, nhưng với `1 ulp < 10^kappa / 2`, điều kiện này là đủ:
        // khoảng cách giữa `v - 1 ulp` và biểu diễn hiện tại không được vượt quá `10^kappa / 2`.
        //
        // điều kiện tương đương với `remainder + ulp < 10^kappa / 2`.
        // vì điều này có thể dễ dàng bị tràn, trước tiên hãy kiểm tra xem `remainder < 10^kappa / 2`.
        // chúng tôi đã xác minh rằng `ulp < 10^kappa / 2`, vì vậy, miễn là `10^kappa` không bị tràn, kiểm tra thứ hai là tốt.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // AN TOÀN: người gọi của chúng tôi đã khởi tạo bộ nhớ đó.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------phần dư------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // mặt khác, nếu `v - 1 ulp` gần với biểu diễn làm tròn hơn, chúng ta nên làm tròn và quay lại.
        // vì lý do tương tự, chúng tôi không cần kiểm tra `v + 1 ulp`.
        //
        // điều kiện tương đương với `remainder - ulp >= 10^kappa / 2`.
        // một lần nữa, trước tiên chúng tôi kiểm tra xem `remainder > ulp` (lưu ý rằng đây không phải là `remainder >= ulp`, vì `10^kappa` không bao giờ là 0).
        //
        // cũng lưu ý rằng `remainder - ulp <= 10^kappa`, vì vậy lần kiểm tra thứ hai không bị tràn.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // AN TOÀN: người gọi của chúng ta phải khởi tạo bộ nhớ đó.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // chỉ thêm một chữ số bổ sung khi chúng tôi đã được yêu cầu về độ chính xác cố định.
                // chúng ta cũng cần kiểm tra rằng, nếu bộ đệm ban đầu trống, chữ số bổ sung chỉ có thể được thêm vào khi `exp == limit` (trường hợp edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // AN TOÀN: chúng tôi và người gọi của chúng tôi đã khởi tạo bộ nhớ đó.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // nếu không, chúng ta sẽ phải chịu đựng (tức là, một số giá trị giữa `v - 1 ulp` và `v + 1 ulp` đang làm tròn xuống và những giá trị khác đang làm tròn lên) và từ bỏ.
        //
        None
    }
}

/// Việc triển khai chế độ chính xác và cố định cho Grisu với Dragon dự phòng.
///
/// Điều này nên được sử dụng cho hầu hết các trường hợp.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // AN TOÀN: Trình kiểm tra khoản vay không đủ thông minh để cho phép chúng tôi sử dụng `buf`
    // trong branch thứ hai, vì vậy chúng tôi rửa toàn bộ thời gian ở đây.
    // Nhưng chúng tôi chỉ sử dụng lại `buf` nếu `format_exact_opt` trả về `None` nên điều này không sao cả.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}