//! Bản dịch Rust gần như trực tiếp (nhưng được tối ưu hóa một chút) của Hình 3 của "In các số dấu phẩy động một cách nhanh chóng và chính xác" [^ 1].
//!
//!
//! [^1]: Burger, RG và Dybvig, RK 1996. In số dấu phẩy động
//!   nhanh chóng và chính xác.SIGPLAN Không.31, 5 (tháng 5 năm 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// được tính toán trước mảng `Digit`s cho 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// chỉ sử dụng được khi `x < 16 * scale`;`scaleN` phải là `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Thực hiện chế độ ngắn nhất cho Dragon.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // số `v` để định dạng được biết là:
    // - bằng `mant * 2^exp`;
    // - trước `(mant - 2 *minus)* 2^exp` trong kiểu gốc;và
    // - tiếp theo là `(mant + 2 *plus)* 2^exp` ở kiểu gốc.
    //
    // rõ ràng, `minus` và `plus` không thể bằng không.(đối với các số vô hạn, chúng tôi sử dụng các giá trị nằm ngoài phạm vi.) Ngoài ra, chúng tôi giả định rằng ít nhất một chữ số được tạo ra, tức là `mant` cũng không được bằng 0.
    //
    // điều này cũng có nghĩa là bất kỳ số nào giữa `low = (mant - minus)*2^exp` và `high = (mant + plus)* 2^exp` sẽ ánh xạ tới số dấu phẩy động chính xác này, với các giới hạn được bao gồm khi phần định trị ban đầu là chẵn (tức là `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` là `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // ước tính `k_0` từ các đầu vào ban đầu thỏa mãn `10^(k_0-1) < high <= 10^(k_0+1)`.
    // giới hạn chặt chẽ `k` thỏa mãn `10^(k-1) < high <= 10^k` sẽ được tính sau.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // chuyển đổi `{mant, plus, minus} * 2^exp` thành dạng phân số để:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // chia `mant` cho `10^k`.bây giờ là `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // sửa lỗi khi `mant + plus > scale` (hoặc `>=`).
    // chúng tôi không thực sự sửa đổi `scale`, vì chúng tôi có thể bỏ qua phép nhân ban đầu.
    // bây giờ là `scale < mant + plus <= scale * 10` và chúng tôi đã sẵn sàng tạo các chữ số.
    //
    // lưu ý rằng `d[0]`*có thể* bằng 0, khi `scale - plus < mant < scale`.
    // trong trường hợp này, điều kiện làm tròn (`up` bên dưới) sẽ được kích hoạt ngay lập tức.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // tương đương với việc chia tỷ lệ `scale` lên 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // bộ nhớ đệm `(2, 4, 8) * scale` để tạo chữ số.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // bất biến, trong đó `d[0..n-1]` là các chữ số được tạo cho đến nay:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (do đó `mant / scale < 10`) trong đó `d[i..j]` là cách viết tắt của `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // tạo một chữ số: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // đây là một mô tả đơn giản của thuật toán Dragon đã sửa đổi.
        // nhiều dẫn xuất trung gian và đối số tính đầy đủ được bỏ qua để thuận tiện.
        //
        // bắt đầu với các bất biến được sửa đổi, vì chúng tôi đã cập nhật `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // giả sử rằng `d[0..n-1]` là đại diện ngắn nhất giữa `low` và `high`, tức là `d[0..n-1]` thỏa mãn cả hai điều sau nhưng `d[0..n-2]` thì không:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (tính chủ quan: các chữ số làm tròn đến `v`);và
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (chữ số cuối cùng là đúng).
        //
        // điều kiện thứ hai đơn giản hóa thành `2 * mant <= scale`.
        // giải các bất biến theo `mant`, `low` và `high` sẽ tạo ra một phiên bản đơn giản hơn của điều kiện đầu tiên: `-plus < mant < minus`.
        // kể từ `-plus < 0 <= mant`, chúng tôi có biểu diễn ngắn nhất chính xác khi `mant < minus` và `2 * mant <= scale`.
        // (cái trước sẽ trở thành `mant <= minus` khi phần định trị ban đầu là số chẵn.)
        //
        // khi thứ hai không giữ (`2 * mant> scale`), chúng ta cần tăng chữ số cuối cùng.
        // điều này là đủ để khôi phục điều kiện đó: chúng ta đã biết rằng việc tạo chữ số đảm bảo `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // trong trường hợp này, điều kiện đầu tiên trở thành `-plus < mant - scale < minus`.
        // kể từ `mant < scale` sau thế hệ, chúng tôi có `scale < mant + plus`.
        // (một lần nữa, giá trị này trở thành `scale <= mant + plus` khi phần định trị ban đầu là số chẵn.)
        //
        // Nói ngắn gọn:
        // - dừng và làm tròn `down` (giữ nguyên các chữ số) khi `mant < minus` (hoặc `<=`).
        // - dừng và làm tròn `up` (tăng chữ số cuối cùng) khi `scale < mant + plus` (hoặc `<=`).
        // - tiếp tục tạo khác.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // chúng tôi có đại diện ngắn nhất, tiếp tục làm tròn

        // khôi phục các bất biến.
        // điều này làm cho thuật toán luôn kết thúc: `minus` và `plus` luôn tăng, nhưng `mant` được cắt bớt mô-đun `scale` và `scale` được cố định.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // làm tròn số xảy ra khi i) chỉ điều kiện làm tròn số được kích hoạt, hoặc ii) cả hai điều kiện đã được kích hoạt và việc bẻ dây buộc thích làm tròn hơn.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // nếu làm tròn thay đổi độ dài, số mũ cũng sẽ thay đổi.
        // Có vẻ như điều kiện này là rất khó để thỏa mãn (có thể là không thể), nhưng chúng tôi đang an toàn và nhất quán ở đây.
        //
        // AN TOÀN: chúng tôi đã khởi tạo bộ nhớ đó ở trên.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // AN TOÀN: chúng tôi đã khởi tạo bộ nhớ đó ở trên.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Việc thực hiện chế độ chính xác và cố định cho Dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // ước tính `k_0` từ các đầu vào ban đầu thỏa mãn `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // chia `mant` cho `10^k`.bây giờ là `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // sửa chữa khi `mant + plus >= scale`, trong đó `plus / scale = 10^-buf.len() / 2`.
    // để giữ bignum có kích thước cố định, chúng tôi thực sự sử dụng `mant + floor(plus) >= scale`.
    // chúng tôi không thực sự sửa đổi `scale`, vì chúng tôi có thể bỏ qua phép nhân ban đầu.
    // một lần nữa với thuật toán ngắn nhất, `d[0]` có thể bằng 0 nhưng cuối cùng sẽ được làm tròn.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // tương đương với việc chia tỷ lệ `scale` lên 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // nếu chúng tôi đang làm việc với giới hạn chữ số cuối cùng, chúng tôi cần rút ngắn bộ đệm trước khi hiển thị thực tế để tránh làm tròn hai lần.
    //
    // lưu ý rằng chúng ta phải mở rộng bộ đệm một lần nữa khi việc làm tròn xảy ra!
    let mut len = if k < limit {
        // rất tiếc, chúng tôi thậm chí không thể tạo ra *một* chữ số.
        // điều này có thể xảy ra khi chúng ta có một cái gì đó giống như 9.5 và nó được làm tròn thành 10.
        // chúng tôi trả về một bộ đệm trống, ngoại trừ trường hợp làm tròn sau xảy ra khi `k == limit` và phải tạo ra chính xác một chữ số.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // bộ nhớ đệm `(2, 4, 8) * scale` để tạo chữ số.
        // (điều này có thể tốn kém, vì vậy không tính toán chúng khi bộ đệm trống.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // các chữ số sau đều là số 0, chúng ta dừng ở đây để *không* cố gắng thực hiện làm tròn!thay vào đó, hãy điền các chữ số còn lại.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // AN TOÀN: chúng tôi đã khởi tạo bộ nhớ đó ở trên.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // làm tròn lên nếu chúng ta dừng ở giữa các chữ số nếu các chữ số sau chính xác là 5000 ..., hãy kiểm tra chữ số trước và cố gắng làm tròn thành chẵn (nghĩa là tránh làm tròn khi chữ số trước đó là chẵn).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // AN TOÀN: `buf[len-1]` được khởi tạo.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // nếu làm tròn thay đổi độ dài, số mũ cũng sẽ thay đổi.
        // nhưng chúng tôi đã được yêu cầu một số lượng chữ số cố định, vì vậy đừng thay đổi bộ đệm ...
        // AN TOÀN: chúng tôi đã khởi tạo bộ nhớ đó ở trên.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... trừ khi chúng tôi được yêu cầu độ chính xác cố định thay thế.
            // chúng ta cũng cần kiểm tra rằng, nếu bộ đệm ban đầu trống, chữ số bổ sung chỉ có thể được thêm vào khi `k == limit` (trường hợp edge).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // AN TOÀN: chúng tôi đã khởi tạo bộ nhớ đó ở trên.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}