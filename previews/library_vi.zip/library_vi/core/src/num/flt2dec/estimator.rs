//! Công cụ ước lượng lũy thừa.

/// Tìm `k_0` sao cho `10^(k_0-1) < mant * 2^exp <= 10^(k_0+1)`.
///
/// Điều này được sử dụng để ước tính `k = ceil(log_10 (mant * 2^exp))`;
/// `k` thực sự là `k_0` hoặc `k_0+1`.
#[doc(hidden)]
pub fn estimate_scaling_factor(mant: u64, exp: i16) -> i16 {
    // 2 ^ (nbits-1) <manti <=2 ^ nbits nếu mant> 0
    let nbits = 64 - (mant - 1).leading_zeros() as i64;
    // 1292913986= floor(2^32 * log_10 2) do đó điều này luôn đánh giá thấp (hoặc chính xác), nhưng không nhiều.
    //
    (((nbits + exp as i64) * 1292913986) >> 32) as i16
}