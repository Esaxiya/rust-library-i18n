//! Các loại lỗi để chuyển đổi sang loại tích phân.

use crate::convert::Infallible;
use crate::fmt;

/// Loại lỗi được trả về khi chuyển đổi kiểu tích phân đã kiểm tra không thành công.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Khớp thay vì ép buộc để đảm bảo rằng mã như `From<Infallible> for TryFromIntError` ở trên sẽ tiếp tục hoạt động khi `Infallible` trở thành bí danh của `!`.
        //
        //
        match never {}
    }
}

/// Một lỗi có thể được trả về khi phân tích cú pháp một số nguyên.
///
/// Lỗi này được sử dụng làm loại lỗi cho các hàm `from_str_radix()` trên các kiểu số nguyên nguyên thủy, chẳng hạn như [`i8::from_str_radix`].
///
/// # Nguyên nhân tiềm ẩn
///
/// Trong số các nguyên nhân khác, `ParseIntError` có thể bị ném do khoảng trắng ở đầu hoặc cuối trong chuỗi, ví dụ, khi nó được lấy từ đầu vào chuẩn.
///
/// Sử dụng phương pháp [`str::trim()`] đảm bảo rằng không còn khoảng trắng trước khi phân tích cú pháp.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum để lưu trữ các loại lỗi khác nhau có thể khiến phân tích cú pháp một số nguyên không thành công.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Giá trị đang được phân tích cú pháp trống.
    ///
    /// Trong số các nguyên nhân khác, biến thể này sẽ được tạo khi phân tích cú pháp một chuỗi rỗng.
    Empty,
    /// Chứa một chữ số không hợp lệ trong ngữ cảnh của nó.
    ///
    /// Trong số các nguyên nhân khác, biến thể này sẽ được tạo khi phân tích cú pháp một chuỗi có chứa ký tự không phải ASCII.
    ///
    /// Biến thể này cũng được xây dựng khi `+` hoặc `-` bị đặt sai vị trí trong một chuỗi hoặc ở chính nó hoặc ở giữa một số.
    ///
    ///
    InvalidDigit,
    /// Số nguyên quá lớn để lưu trữ ở kiểu số nguyên đích.
    PosOverflow,
    /// Số nguyên quá nhỏ để lưu trữ ở kiểu số nguyên đích.
    NegOverflow,
    /// Giá trị bằng 0
    ///
    /// Biến thể này sẽ được phát ra khi chuỗi phân tích cú pháp có giá trị bằng 0, điều này sẽ là bất hợp pháp đối với các kiểu khác không.
    ///
    Zero,
}

impl ParseIntError {
    /// Đưa ra nguyên nhân chi tiết của việc phân tích cú pháp một số nguyên không thành công.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}