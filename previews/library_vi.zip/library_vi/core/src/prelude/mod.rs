//! Libcore prelude
//!
//! Mô-đun này dành cho người dùng libcore không liên kết với libstd.
//! Mô-đun này được nhập theo mặc định khi `#![no_std]` được sử dụng theo cách tương tự như prelude của thư viện tiêu chuẩn.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Phiên bản 2015 của lõi prelude.
///
/// Xem [module-level documentation](self) để biết thêm.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Phiên bản 2018 của lõi prelude.
///
/// Xem [module-level documentation](self) để biết thêm.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Phiên bản 2021 của prelude lõi.
///
/// Xem [module-level documentation](self) để biết thêm.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Thêm nhiều thứ khác.
}