use crate::fmt;

/// Tạo một trình lặp mới trong đó mỗi lần lặp lại gọi bao đóng đã cung cấp `F: FnMut() -> Option<T>`.
///
/// Điều này cho phép tạo một trình lặp tùy chỉnh với bất kỳ hành vi nào mà không cần sử dụng cú pháp dài dòng hơn để tạo một kiểu chuyên dụng và triển khai [`Iterator`] trait cho nó.
///
/// Lưu ý rằng trình lặp `FromFn` không đưa ra các giả định về hành vi của quá trình đóng và do đó, không triển khai [`FusedIterator`] một cách thận trọng hoặc ghi đè [`Iterator::size_hint()`] từ `(0, None)` mặc định của nó.
///
///
/// Việc đóng có thể sử dụng các ảnh chụp và môi trường của nó để theo dõi trạng thái qua các lần lặp lại.Tùy thuộc vào cách trình lặp được sử dụng, điều này có thể yêu cầu chỉ định từ khóa [`move`] trên bao đóng.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Hãy triển khai lại trình lặp bộ đếm từ [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Tăng số lượng của chúng tôi.Đây là lý do tại sao chúng tôi bắt đầu từ con số không.
///     count += 1;
///
///     // Kiểm tra xem chúng ta đã đếm xong hay chưa.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Một trình vòng lặp trong đó mỗi lần lặp lại gọi bao đóng đã cung cấp `F: FnMut() -> Option<T>`.
///
/// `struct` này được tạo ra bởi hàm [`iter::from_fn()`].
/// Xem tài liệu của nó để biết thêm.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}