use crate::iter::{FusedIterator, TrustedLen};

/// Tạo một trình lặp mới lặp lại liên tục một phần tử.
///
/// Hàm `repeat()` lặp đi lặp lại một giá trị duy nhất.
///
/// Các trình vòng lặp vô hạn như `repeat()` thường được sử dụng với các bộ điều hợp như [`Iterator::take()`], để làm cho chúng trở nên hữu hạn.
///
/// Nếu loại phần tử của trình lặp bạn cần không triển khai `Clone` hoặc nếu bạn không muốn giữ phần tử lặp lại trong bộ nhớ, thay vào đó bạn có thể sử dụng hàm [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Cách sử dụng cơ bản:
///
/// ```
/// use std::iter;
///
/// // số bốn 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // vâng, vẫn còn bốn
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Đi hữu hạn với [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // ví dụ cuối cùng đó là quá nhiều bốn cái.Hãy chỉ có bốn cái bốn chân.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... và bây giờ chúng ta đã hoàn thành
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Một trình lặp lặp lại liên tục một phần tử.
///
/// `struct` này được tạo ra bởi hàm [`repeat()`].Xem tài liệu của nó để biết thêm.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}