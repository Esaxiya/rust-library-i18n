use crate::iter::{FusedIterator, TrustedLen};

/// Tạo một trình lặp mới lặp lại liên tục các phần tử của loại `A` bằng cách áp dụng bao đóng được cung cấp, trình lặp lại, `F: FnMut() -> A`.
///
/// Hàm `repeat_with()` gọi bộ lặp đi lặp lại nhiều lần.
///
/// Các trình vòng lặp vô hạn như `repeat_with()` thường được sử dụng với các bộ điều hợp như [`Iterator::take()`], để làm cho chúng trở nên hữu hạn.
///
/// Nếu loại phần tử của trình lặp bạn cần triển khai [`Clone`] và có thể giữ phần tử nguồn trong bộ nhớ, thay vào đó bạn nên sử dụng hàm [`repeat()`].
///
///
/// Trình lặp do `repeat_with()` tạo ra không phải là [`DoubleEndedIterator`].
/// Nếu bạn cần `repeat_with()` để trả lại [`DoubleEndedIterator`], vui lòng mở sự cố GitHub giải thích trường hợp sử dụng của bạn.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Cách sử dụng cơ bản:
///
/// ```
/// use std::iter;
///
/// // giả sử chúng ta có một số giá trị thuộc loại không phải là `Clone` hoặc không muốn có trong bộ nhớ vì nó đắt:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // một giá trị cụ thể mãi mãi:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Sử dụng đột biến và đi hữu hạn:
///
/// ```rust
/// use std::iter;
///
/// // Từ lũy thừa thứ 0 đến lũy thừa thứ ba của hai:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... và bây giờ chúng ta đã hoàn thành
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Một trình lặp lặp lại liên tục các phần tử của kiểu `A` bằng cách áp dụng bao đóng đã cung cấp `F: FnMut() -> A`.
///
///
/// `struct` này được tạo ra bởi hàm [`repeat_with()`].
/// Xem tài liệu của nó để biết thêm.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}