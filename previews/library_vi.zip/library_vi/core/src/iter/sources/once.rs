use crate::iter::{FusedIterator, TrustedLen};

/// Tạo một trình lặp tạo ra một phần tử chính xác một lần.
///
/// Điều này thường được sử dụng để điều chỉnh một giá trị đơn lẻ thành [`chain()`] của các kiểu lặp khác.
/// Có thể bạn có một trình lặp bao gồm hầu hết mọi thứ, nhưng bạn cần thêm một trường hợp đặc biệt.
/// Có thể bạn có một hàm hoạt động trên trình vòng lặp, nhưng bạn chỉ cần xử lý một giá trị.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Cách sử dụng cơ bản:
///
/// ```
/// use std::iter;
///
/// // một là con số đơn độc nhất
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // chỉ một, đó là tất cả những gì chúng tôi nhận được
/// assert_eq!(None, one.next());
/// ```
///
/// Chuỗi cùng với một trình lặp khác.
/// Giả sử rằng chúng tôi muốn lặp lại từng tệp của thư mục `.foo`, nhưng cũng là tệp cấu hình,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // chúng ta cần chuyển đổi từ một trình lặp của DirEntry-s thành một trình lặp của PathBufs, vì vậy chúng tôi sử dụng bản đồ
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // bây giờ, trình vòng lặp của chúng tôi chỉ dành cho tệp cấu hình của chúng tôi
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // chuỗi hai trình vòng lặp lại với nhau thành một trình vòng lặp lớn
/// let files = dirs.chain(config);
///
/// // điều này sẽ cung cấp cho chúng tôi tất cả các tệp trong .foo cũng như .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Một trình lặp tạo ra một phần tử chính xác một lần.
///
/// `struct` này được tạo ra bởi hàm [`once()`].Xem tài liệu của nó để biết thêm.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}