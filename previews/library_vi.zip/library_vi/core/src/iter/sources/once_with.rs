use crate::iter::{FusedIterator, TrustedLen};

/// Tạo một trình lặp có thể tạo ra một giá trị chính xác một lần một cách lười biếng bằng cách gọi bao đóng được cung cấp.
///
/// Điều này thường được sử dụng để điều chỉnh một trình tạo giá trị đơn lẻ thành [`chain()`] của các kiểu lặp khác.
/// Có thể bạn có một trình lặp bao gồm hầu hết mọi thứ, nhưng bạn cần thêm một trường hợp đặc biệt.
/// Có thể bạn có một hàm hoạt động trên trình vòng lặp, nhưng bạn chỉ cần xử lý một giá trị.
///
/// Không giống như [`once()`], chức năng này sẽ tạo ra giá trị theo yêu cầu một cách lười biếng.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Cách sử dụng cơ bản:
///
/// ```
/// use std::iter;
///
/// // một là con số đơn độc nhất
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // chỉ một, đó là tất cả những gì chúng tôi nhận được
/// assert_eq!(None, one.next());
/// ```
///
/// Chuỗi cùng với một trình lặp khác.
/// Giả sử rằng chúng tôi muốn lặp lại từng tệp của thư mục `.foo`, nhưng cũng là tệp cấu hình,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // chúng ta cần chuyển đổi từ một trình lặp của DirEntry-s thành một trình lặp của PathBufs, vì vậy chúng tôi sử dụng bản đồ
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // bây giờ, trình vòng lặp của chúng tôi chỉ dành cho tệp cấu hình của chúng tôi
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // chuỗi hai trình vòng lặp lại với nhau thành một trình vòng lặp lớn
/// let files = dirs.chain(config);
///
/// // điều này sẽ cung cấp cho chúng tôi tất cả các tệp trong .foo cũng như .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Một trình lặp tạo ra một phần tử duy nhất của kiểu `A` bằng cách áp dụng bao đóng đã cung cấp `F: FnOnce() -> A`.
///
///
/// `struct` này được tạo ra bởi hàm [`once_with()`].
/// Xem tài liệu của nó để biết thêm.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}