//! Lặp lại bên ngoài có thể dùng một lần.
//!
//! Nếu bạn thấy mình có một bộ sưu tập nào đó và cần thực hiện thao tác trên các phần tử của bộ sưu tập nói trên, bạn sẽ nhanh chóng sử dụng 'iterators'.
//! Các trình lặp được sử dụng nhiều trong mã Rust thành ngữ, vì vậy bạn nên làm quen với chúng.
//!
//! Trước khi giải thích thêm, hãy nói về cách mô-đun này được cấu trúc:
//!
//! # Organization
//!
//! Mô-đun này chủ yếu được tổ chức theo loại:
//!
//! * [Traits] là phần cốt lõi: traits này xác định loại trình vòng lặp tồn tại và bạn có thể làm gì với chúng.Các phương pháp của traits này đáng để bạn bỏ thêm thời gian nghiên cứu.
//! * [Functions] cung cấp một số cách hữu ích để tạo một số trình vòng lặp cơ bản.
//! * [Structs] thường là các kiểu trả về của các phương thức khác nhau trên traits của mô-đun này.Thông thường, bạn sẽ muốn xem xét phương pháp tạo ra `struct`, thay vì chính `struct`.
//! Để biết thêm chi tiết về lý do, hãy xem '[Trình lặp thực thi](#trình lặp thực hiện)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Đó là nó!Chúng ta hãy tìm hiểu về các trình vòng lặp.
//!
//! # Iterator
//!
//! Trái tim và linh hồn của mô-đun này là [`Iterator`] trait.Lõi của [`Iterator`] trông như thế này:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Một trình vòng lặp có một phương thức, [`next`], khi được gọi, sẽ trả về một [`Option`]`<Item>`.
//! [`next`] sẽ trả về [`Some(Item)`] miễn là có các phần tử và khi tất cả chúng đã hết, sẽ trả về `None` để cho biết rằng quá trình lặp đã kết thúc.
//! Các trình vòng lặp riêng lẻ có thể chọn tiếp tục lặp lại và do đó, việc gọi lại [`next`] cuối cùng có thể bắt đầu trả lại [`Some(Item)`] một lần nữa vào một thời điểm nào đó (ví dụ: xem [`TryIter`]).
//!
//!
//! Định nghĩa đầy đủ của [`Iterator`] cũng bao gồm một số phương thức khác, nhưng chúng là các phương thức mặc định, được xây dựng trên [`next`] và vì vậy bạn nhận được chúng miễn phí.
//!
//! Các trình lặp cũng có thể kết hợp được và việc xâu chuỗi chúng lại với nhau để thực hiện các hình thức xử lý phức tạp hơn.Xem phần [Adapters](#adapters) bên dưới để biết thêm chi tiết.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Ba hình thức lặp lại
//!
//! Có ba phương pháp phổ biến có thể tạo trình vòng lặp từ một tập hợp:
//!
//! * `iter()`, lặp lại trên `&T`.
//! * `iter_mut()`, lặp lại trên `&mut T`.
//! * `into_iter()`, lặp lại trên `T`.
//!
//! Nhiều thứ khác nhau trong thư viện tiêu chuẩn có thể triển khai một hoặc nhiều hơn ba, nếu thích hợp.
//!
//! # Triển khai lặp lại
//!
//! Tạo một trình lặp của riêng bạn bao gồm hai bước: tạo `struct` để giữ trạng thái của trình lặp, sau đó triển khai [`Iterator`] cho `struct` đó.
//! Đây là lý do tại sao có rất nhiều `cấu trúc` trong mô-đun này: có một cho mỗi trình lặp và bộ điều hợp trình lặp.
//!
//! Hãy tạo một trình lặp có tên là `Counter`, đếm từ `1` đến `5`:
//!
//! ```
//! // Đầu tiên, cấu trúc:
//!
//! /// Một trình lặp đếm từ một đến năm
//! struct Counter {
//!     count: usize,
//! }
//!
//! // chúng tôi muốn số lượng của chúng tôi bắt đầu bằng một, vì vậy hãy thêm một phương thức new() để trợ giúp.
//! // Điều này không hoàn toàn cần thiết, nhưng rất tiện lợi.
//! // Lưu ý rằng chúng tôi bắt đầu `count` ở mức 0, chúng tôi sẽ xem lý do tại sao trong việc triển khai `next()`'s bên dưới.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Sau đó, chúng tôi triển khai `Iterator` cho `Counter` của chúng tôi:
//!
//! impl Iterator for Counter {
//!     // chúng tôi sẽ đếm với kích thước
//!     type Item = usize;
//!
//!     // next() là phương pháp bắt buộc duy nhất
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Tăng số lượng của chúng tôi.Đây là lý do tại sao chúng tôi bắt đầu từ con số không.
//!         self.count += 1;
//!
//!         // Kiểm tra xem chúng ta đã đếm xong hay chưa.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Và bây giờ chúng ta có thể sử dụng nó!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Gọi [`next`] theo cách này sẽ lặp đi lặp lại.Rust có một cấu trúc có thể gọi [`next`] trên trình lặp của bạn, cho đến khi nó đạt đến `None`.Hãy xem xét nó tiếp theo.
//!
//! Cũng lưu ý rằng `Iterator` cung cấp triển khai mặc định của các phương thức như `nth` và `fold` gọi `next` nội bộ.
//! Tuy nhiên, cũng có thể viết một triển khai tùy chỉnh của các phương thức như `nth` và `fold` nếu một trình vòng lặp có thể tính toán chúng hiệu quả hơn mà không cần gọi `next`.
//!
//! # `for` vòng lặp và `IntoIterator`
//!
//! Cú pháp vòng lặp `for` của Rust thực sự là đường cho các trình vòng lặp.Đây là một ví dụ cơ bản về `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Thao tác này sẽ in các số từ một đến năm, mỗi số trên dòng riêng của chúng.Nhưng bạn sẽ nhận thấy điều gì đó ở đây: chúng tôi chưa bao giờ gọi bất kỳ thứ gì trên vector của mình để tạo ra một trình lặp.Đưa cái gì?
//!
//! Có một trait trong thư viện tiêu chuẩn để chuyển đổi một cái gì đó thành một trình vòng lặp: [`IntoIterator`].
//! trait này có một phương thức, [`into_iter`], chuyển đổi thứ đang triển khai [`IntoIterator`] thành một trình vòng lặp.
//! Chúng ta hãy xem xét lại vòng lặp `for` đó và trình biên dịch chuyển đổi nó thành gì:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust khử đường thành:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Đầu tiên, chúng tôi gọi `into_iter()` theo giá trị.Sau đó, chúng tôi so khớp trên trình lặp trả về, gọi đi gọi lại [`next`] cho đến khi chúng tôi thấy `None`.
//! Tại thời điểm đó, chúng tôi `break` ra khỏi vòng lặp và chúng tôi đã hoàn tất việc lặp lại.
//!
//! Có một chút tinh tế hơn ở đây: thư viện tiêu chuẩn chứa một triển khai thú vị của [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Nói cách khác, tất cả [`Iterator`] đều triển khai [`IntoIterator`], bằng cách chỉ trả về chính chúng.Điều này có nghĩa là hai điều:
//!
//! 1. Nếu bạn đang viết [`Iterator`], bạn có thể sử dụng nó với vòng lặp `for`.
//! 2. Nếu bạn đang tạo một bộ sưu tập, việc triển khai [`IntoIterator`] cho bộ sưu tập đó sẽ cho phép bộ sưu tập của bạn được sử dụng với vòng lặp `for`.
//!
//! # Lặp lại bằng cách tham khảo
//!
//! Vì [`into_iter()`] nhận `self` theo giá trị, nên việc sử dụng vòng lặp `for` để lặp qua một bộ sưu tập sẽ sử dụng bộ sưu tập đó.Thông thường, bạn có thể muốn lặp lại một bộ sưu tập mà không cần sử dụng bộ sưu tập đó.
//! Nhiều bộ sưu tập cung cấp các phương thức cung cấp trình vòng lặp qua các tham chiếu, thường được gọi là `iter()` và `iter_mut()` tương ứng:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` vẫn thuộc sở hữu của chức năng này.
//! ```
//!
//! Nếu một loại tập hợp `C` cung cấp `iter()`, nó cũng thường triển khai `IntoIterator` cho `&C`, với một triển khai chỉ gọi `iter()`.
//! Tương tự như vậy, một bộ sưu tập `C` cung cấp `iter_mut()` thường triển khai `IntoIterator` cho `&mut C` bằng cách ủy quyền cho `iter_mut()`.Điều này cho phép viết tắt thuận tiện:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // giống như `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // giống như `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Trong khi nhiều bộ sưu tập cung cấp `iter()`, không phải tất cả đều cung cấp `iter_mut()`.
//! Ví dụ: việc thay đổi các khóa của [`HashSet<T>`] hoặc [`HashMap<K, V>`] có thể đặt bộ sưu tập vào trạng thái không nhất quán nếu hàm băm của khóa thay đổi, vì vậy các bộ sưu tập này chỉ cung cấp `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Các hàm lấy một [`Iterator`] và trả về một [`Iterator`] khác thường được gọi là 'bộ điều hợp trình lặp', vì chúng là một dạng của 'bộ điều hợp
//! pattern'.
//!
//! Các bộ điều hợp trình lặp phổ biến bao gồm [`map`], [`take`] và [`filter`].
//! Để biết thêm, hãy xem tài liệu của họ.
//!
//! Nếu một bộ điều hợp trình vòng lặp panics, trình vòng lặp sẽ ở trạng thái không xác định (nhưng an toàn cho bộ nhớ).
//! Trạng thái này cũng không được đảm bảo sẽ giữ nguyên trên các phiên bản của Rust, vì vậy bạn nên tránh dựa vào các giá trị chính xác được trả về bởi một trình lặp.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Các trình lặp (và trình lặp [adapters](#adapters)) là *lazy*. Điều này có nghĩa là việc chỉ tạo một trình lặp không hoàn toàn _do_. Sẽ không có gì thực sự xảy ra cho đến khi bạn gọi [`next`].
//! Điều này đôi khi gây nhầm lẫn khi tạo một trình lặp chỉ vì các tác dụng phụ của nó.
//! Ví dụ: phương thức [`map`] gọi một bao đóng trên mỗi phần tử mà nó lặp lại:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Thao tác này sẽ không in ra bất kỳ giá trị nào, vì chúng tôi chỉ tạo một trình lặp chứ không phải sử dụng nó.Trình biên dịch sẽ cảnh báo chúng ta về loại hành vi này:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Cách thành ngữ để viết [`map`] cho các tác dụng phụ của nó là sử dụng vòng lặp `for` hoặc gọi phương thức [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Một cách phổ biến khác để đánh giá một trình lặp là sử dụng phương pháp [`collect`] để tạo ra một tập hợp mới.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Các trình lặp không nhất thiết phải là hữu hạn.Ví dụ: một phạm vi kết thúc mở là một trình lặp vô hạn:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Người ta thường sử dụng bộ điều hợp trình vòng lặp [`take`] để biến một trình vòng lặp vô hạn thành một trình vòng lặp hữu hạn:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Thao tác này sẽ in các số từ `0` đến `4`, mỗi số trên dòng riêng của chúng.
//!
//! Hãy nhớ rằng các phương thức trên trình vòng lặp vô hạn, ngay cả những phương thức mà kết quả có thể được xác định bằng toán học trong thời gian hữu hạn, có thể không kết thúc.
//! Cụ thể, các phương thức như [`min`], trong trường hợp chung yêu cầu duyệt qua mọi phần tử trong trình vòng lặp, có khả năng không trả về thành công cho bất kỳ trình vòng lặp vô hạn nào.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Ôi không!Một vòng lặp vô hạn!
//! // `ones.min()` gây ra một vòng lặp vô hạn, vì vậy chúng tôi sẽ không đạt đến điểm này!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;