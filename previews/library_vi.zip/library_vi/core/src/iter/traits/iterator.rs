// Bỏ qua-gọn gàng-filelength Tệp này hầu như chỉ bao gồm định nghĩa của `Iterator`.
// Chúng tôi không thể chia nó thành nhiều tệp.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Một giao diện để xử lý các trình vòng lặp.
///
/// Đây là trình lặp chính trait.
/// Để biết thêm về khái niệm trình vòng lặp nói chung, vui lòng xem [module-level documentation].
/// Đặc biệt, bạn có thể muốn biết cách [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Loại của các phần tử đang được lặp lại.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Nâng cao trình lặp và trả về giá trị tiếp theo.
    ///
    /// Trả về [`None`] khi quá trình lặp kết thúc.
    /// Việc triển khai trình lặp riêng lẻ có thể chọn tiếp tục lặp lại và do đó, việc gọi lại `next()` cuối cùng có thể bắt đầu trả lại [`Some(Item)`] một lần nữa vào một thời điểm nào đó.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Một cuộc gọi đến next() trả về giá trị tiếp theo ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... và sau đó là Không một khi nó kết thúc.
    /// assert_eq!(None, iter.next());
    ///
    /// // Nhiều cuộc gọi hơn có thể trả về `None` hoặc không.Ở đây, họ sẽ luôn như vậy.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Trả về giới hạn trên độ dài còn lại của trình vòng lặp.
    ///
    /// Cụ thể, `size_hint()` trả về một bộ giá trị trong đó phần tử đầu tiên là giới hạn dưới và phần tử thứ hai là giới hạn trên.
    ///
    /// Nửa sau của tuple được trả về là một [`Option`]`<`[`usize`] `>`.
    /// [`None`] ở đây có nghĩa là không có giới hạn trên đã biết hoặc giới hạn trên lớn hơn [`usize`].
    ///
    /// # Ghi chú triển khai
    ///
    /// Việc triển khai trình lặp không được thực thi mang lại số phần tử đã khai báo.Một trình lặp lỗi có thể mang lại ít hơn giới hạn dưới hoặc nhiều hơn giới hạn trên của các phần tử.
    ///
    /// `size_hint()` chủ yếu nhằm mục đích sử dụng để tối ưu hóa chẳng hạn như dành không gian cho các phần tử của trình vòng lặp, nhưng không được tin cậy để ví dụ: bỏ qua kiểm tra giới hạn trong mã không an toàn.
    /// Việc triển khai `size_hint()` không chính xác sẽ không dẫn đến vi phạm an toàn bộ nhớ.
    ///
    /// Điều đó nói rằng, việc triển khai phải cung cấp một ước tính chính xác, bởi vì nếu không nó sẽ vi phạm giao thức của trait.
    ///
    /// Việc triển khai mặc định trả về `(0,` [`None`]`)`đúng cho bất kỳ trình lặp nào.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Một ví dụ phức tạp hơn:
    ///
    /// ```
    /// // Các số chẵn từ 0 đến 10.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Chúng tôi có thể lặp lại từ 0 đến 10 lần.
    /// // Biết rằng đó là năm chính xác sẽ không thể thực hiện được nếu không thực hiện filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Hãy thêm năm số nữa với chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // bây giờ cả hai giới hạn được tăng lên năm
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Trả lại `None` cho giới hạn trên:
    ///
    /// ```
    /// // một trình lặp vô hạn không có giới hạn trên và giới hạn dưới tối đa có thể
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Sử dụng trình lặp, đếm số lần lặp và trả về.
    ///
    /// Phương thức này sẽ gọi [`next`] liên tục cho đến khi gặp [`None`], trả về số lần nó nhìn thấy [`Some`].
    /// Lưu ý rằng [`next`] phải được gọi ít nhất một lần ngay cả khi trình vòng lặp không có bất kỳ phần tử nào.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Hành vi tràn
    ///
    /// Phương thức này không bảo vệ chống tràn, vì vậy việc đếm các phần tử của một trình lặp có nhiều hơn [`usize::MAX`] phần tử hoặc tạo ra kết quả sai hoặc panics.
    ///
    /// Nếu xác nhận gỡ lỗi được bật, panic được đảm bảo.
    ///
    /// # Panics
    ///
    /// Hàm này có thể panic nếu trình lặp có nhiều hơn [`usize::MAX`] phần tử.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Sử dụng trình lặp, trả về phần tử cuối cùng.
    ///
    /// Phương thức này sẽ đánh giá trình lặp cho đến khi nó trả về [`None`].
    /// Trong khi làm như vậy, nó sẽ theo dõi phần tử hiện tại.
    /// Sau khi trả về [`None`], `last()` sẽ trả về phần tử cuối cùng mà nó nhìn thấy.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Nâng cao trình lặp bởi các phần tử `n`.
    ///
    /// Phương thức này sẽ bỏ qua các phần tử `n` một cách háo hức bằng cách gọi [`next`] tối đa `n` lần cho đến khi gặp [`None`].
    ///
    /// `advance_by(n)` sẽ trả về [`Ok(())`][Ok] nếu trình lặp được nâng cấp thành công bởi các phần tử `n` hoặc [`Err(k)`][Err] nếu gặp phải [`None`], trong đó `k` là số phần tử mà trình lặp được nâng cao trước khi hết phần tử (tức là
    /// độ dài của trình lặp).
    /// Lưu ý rằng `k` luôn nhỏ hơn `n`.
    ///
    /// Gọi `advance_by(0)` không sử dụng bất kỳ phần tử nào và luôn trả về [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // chỉ `&4` bị bỏ qua
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Trả về phần tử thứ `n` của trình vòng lặp.
    ///
    /// Giống như hầu hết các hoạt động lập chỉ mục, số đếm bắt đầu từ 0, vì vậy `nth(0)` trả về giá trị đầu tiên, `nth(1)` giá trị thứ hai, v.v.
    ///
    /// Lưu ý rằng tất cả các phần tử trước đó, cũng như phần tử trả về, sẽ được sử dụng từ trình vòng lặp.
    /// Điều đó có nghĩa là các phần tử trước đó sẽ bị loại bỏ và việc gọi `nth(0)` nhiều lần trên cùng một trình lặp sẽ trả về các phần tử khác nhau.
    ///
    ///
    /// `nth()` sẽ trả về [`None`] nếu `n` lớn hơn hoặc bằng độ dài của trình lặp.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Gọi `nth()` nhiều lần không tua lại trình lặp:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Trả về `None` nếu có ít hơn `n + 1` phần tử:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Tạo một trình lặp bắt đầu tại cùng một điểm, nhưng giảm dần theo số lượng đã cho ở mỗi lần lặp.
    ///
    /// Lưu ý 1: Phần tử đầu tiên của trình lặp sẽ luôn được trả về, bất kể bước đã cho.
    ///
    /// Lưu ý 2: Thời gian mà các phần tử bị bỏ qua được kéo không cố định.
    /// `StepBy` hoạt động giống như chuỗi `next(), nth(step-1), nth(step-1),…`, nhưng cũng có thể tự do hoạt động như chuỗi
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Cách nào được sử dụng có thể thay đổi đối với một số trình lặp vì lý do hiệu suất.
    /// Cách thứ hai sẽ tiến trình vòng lặp sớm hơn và có thể tiêu tốn nhiều vật phẩm hơn.
    ///
    /// `advance_n_and_return_first` tương đương với:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Phương thức sẽ panic nếu bước đã cho là `0`.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Sử dụng hai trình vòng lặp và tạo một trình vòng lặp mới cho cả hai trong trình tự.
    ///
    /// `chain()` sẽ trả về một trình vòng lặp mới, trình lặp đầu tiên sẽ lặp lại các giá trị từ trình lặp đầu tiên và sau đó qua các giá trị từ trình lặp thứ hai.
    ///
    /// Nói cách khác, nó liên kết hai trình vòng lặp với nhau, trong một chuỗi.🔗
    ///
    /// [`once`] thường được sử dụng để điều chỉnh một giá trị đơn lẻ thành một chuỗi các kiểu lặp lại khác.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Vì đối số tới `chain()` sử dụng [`IntoIterator`], chúng ta có thể chuyển bất kỳ thứ gì có thể được chuyển đổi thành [`Iterator`], không chỉ là [`Iterator`].
    /// Ví dụ: các lát (`&[T]`) triển khai [`IntoIterator`] và do đó có thể được chuyển trực tiếp đến `chain()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Nếu bạn làm việc với API Windows, bạn có thể muốn chuyển đổi [`OsStr`] thành `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Giải nén' hai trình vòng lặp thành một trình vòng lặp duy nhất của các cặp.
    ///
    /// `zip()` trả về một trình vòng lặp mới sẽ lặp qua hai trình vòng lặp khác, trả về một bộ giá trị trong đó phần tử đầu tiên đến từ trình vòng lặp đầu tiên và phần tử thứ hai đến từ trình vòng lặp thứ hai.
    ///
    ///
    /// Nói cách khác, nó nén hai trình vòng lặp lại với nhau, thành một trình duy nhất.
    ///
    /// Nếu một trong hai trình vòng lặp trả về [`None`], [`next`] từ trình vòng lặp đã nén sẽ trả về [`None`].
    /// Nếu trình lặp đầu tiên trả về [`None`], `zip` sẽ ngắn mạch và `next` sẽ không được gọi trên trình lặp thứ hai.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Vì đối số tới `zip()` sử dụng [`IntoIterator`], chúng ta có thể chuyển bất kỳ thứ gì có thể được chuyển đổi thành [`Iterator`], không chỉ là [`Iterator`].
    /// Ví dụ: các lát (`&[T]`) triển khai [`IntoIterator`] và do đó có thể được chuyển trực tiếp đến `zip()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` thường được sử dụng để nén một trình vòng lặp vô hạn thành một trình vòng lặp hữu hạn.
    /// Điều này hoạt động vì trình lặp hữu hạn cuối cùng sẽ trả về [`None`], kết thúc dây kéo.Nén bằng `(0..)` có thể trông rất giống [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Tạo một trình lặp mới để đặt một bản sao của `separator` giữa các mục liền kề của trình lặp ban đầu.
    ///
    /// Trong trường hợp `separator` không triển khai [`Clone`] hoặc cần phải tính toán mọi lúc, hãy sử dụng [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Phần tử đầu tiên từ `a`.
    /// assert_eq!(a.next(), Some(&100)); // Dấu phân cách.
    /// assert_eq!(a.next(), Some(&1));   // Phần tử tiếp theo từ `a`.
    /// assert_eq!(a.next(), Some(&100)); // Dấu phân cách.
    /// assert_eq!(a.next(), Some(&2));   // Phần tử cuối cùng từ `a`.
    /// assert_eq!(a.next(), None);       // Trình lặp đã kết thúc.
    /// ```
    ///
    /// `intersperse` có thể rất hữu ích khi tham gia các mục của trình vòng lặp bằng cách sử dụng một phần tử chung:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Tạo một trình lặp mới để đặt một mục được tạo bởi `separator` giữa các mục liền kề của trình lặp ban đầu.
    ///
    /// Việc đóng sẽ được gọi chính xác một lần mỗi khi một mục được đặt giữa hai mục liền kề từ trình lặp bên dưới;
    /// cụ thể, bao đóng không được gọi nếu trình lặp bên dưới mang lại ít hơn hai mục và sau khi mục cuối cùng được tạo ra.
    ///
    ///
    /// Nếu mục của trình lặp thực hiện [`Clone`], thì việc sử dụng [`intersperse`] có thể dễ dàng hơn.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Phần tử đầu tiên từ `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Dấu phân cách.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Phần tử tiếp theo từ `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Dấu phân cách.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Phần tử cuối cùng từ `v`.
    /// assert_eq!(it.next(), None);               // Trình lặp đã kết thúc.
    /// ```
    ///
    /// `intersperse_with` có thể được sử dụng trong các tình huống cần tính toán dấu phân tách:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Việc đóng có thể mượn ngữ cảnh của nó để tạo một mục.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Thực hiện một quá trình đóng và tạo một trình vòng lặp gọi hàm đóng trên mỗi phần tử.
    ///
    /// `map()` biến đổi một trình lặp này thành một trình lặp khác, bằng cách đối số của nó:
    /// một cái gì đó triển khai [`FnMut`].Nó tạo ra một trình vòng lặp mới gọi sự đóng này trên mỗi phần tử của trình vòng lặp ban đầu.
    ///
    /// Nếu bạn giỏi suy nghĩ về các loại hình, bạn có thể nghĩ về `map()` như thế này:
    /// Nếu bạn có một trình vòng lặp cung cấp cho bạn các phần tử của một số kiểu `A` và bạn muốn một trình vòng lặp thuộc một số kiểu `B` khác, bạn có thể sử dụng `map()`, truyền một bao đóng nhận `A` và trả về `B`.
    ///
    ///
    /// `map()` về mặt khái niệm tương tự như vòng lặp [`for`].Tuy nhiên, vì `map()` lười, nên nó được sử dụng tốt nhất khi bạn đã làm việc với các trình vòng lặp khác.
    /// Nếu bạn đang thực hiện một số loại lặp lại cho một tác dụng phụ, việc sử dụng [`for`] được coi là khó hiểu hơn là `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Nếu bạn đang thực hiện một số loại tác dụng phụ, hãy thích [`for`] hơn `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // đừng làm điều này:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // nó thậm chí sẽ không thực thi, vì nó lười biếng.Rust sẽ cảnh báo bạn về điều này.
    ///
    /// // Thay vào đó, hãy sử dụng cho:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Gọi một bao đóng trên mỗi phần tử của một trình vòng lặp.
    ///
    /// Điều này tương đương với việc sử dụng vòng lặp [`for`] trên trình vòng lặp, mặc dù `break` và `continue` không thể thực hiện được khi đóng.
    /// Nói chung, sử dụng vòng lặp `for` dễ hiểu hơn, nhưng `for_each` có thể dễ đọc hơn khi xử lý các mục ở cuối chuỗi trình lặp dài hơn.
    ///
    /// Trong một số trường hợp, `for_each` cũng có thể nhanh hơn một vòng lặp, vì nó sẽ sử dụng phép lặp nội bộ trên các bộ điều hợp như `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Đối với một ví dụ nhỏ như vậy, một vòng lặp `for` có thể sạch hơn, nhưng `for_each` có thể thích hợp hơn để giữ một kiểu chức năng với các trình vòng lặp dài hơn:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Tạo một trình lặp sử dụng một bao đóng để xác định xem một phần tử có nên được tạo ra hay không.
    ///
    /// Cho một phần tử, việc đóng phải trả về `true` hoặc `false`.Trình lặp được trả về sẽ chỉ mang lại các phần tử mà bao đóng trả về true.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Bởi vì bao đóng được chuyển đến `filter()` nhận một tham chiếu và nhiều trình vòng lặp lặp qua các tham chiếu, điều này dẫn đến một tình huống có thể khó hiểu, trong đó loại của bao đóng là một tham chiếu kép:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // cần hai * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Thay vào đó, người ta thường sử dụng cấu trúc hủy trên đối số để loại bỏ một:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // cả&và *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// hoặc cả hai:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // hai &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// của các lớp này.
    ///
    /// Lưu ý rằng `iter.filter(f).next()` tương đương với `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Tạo một trình lặp vừa lọc và lập bản đồ.
    ///
    /// Trình lặp được trả về chỉ mang lại giá trị `mà bao đóng được cung cấp trả về `Some(value)`.
    ///
    /// `filter_map` có thể được sử dụng để làm cho chuỗi [`filter`] và [`map`] ngắn gọn hơn.
    /// Ví dụ dưới đây cho thấy cách `map().filter().map()` có thể được rút gọn thành một lệnh gọi đến `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Đây là ví dụ tương tự, nhưng với [`filter`] và [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Tạo một trình lặp cung cấp số lần lặp hiện tại cũng như giá trị tiếp theo.
    ///
    /// Trình vòng lặp được trả về mang lại cặp `(i, val)`, trong đó `i` là chỉ số hiện tại của phép lặp và `val` là giá trị được trả về bởi trình vòng lặp.
    ///
    ///
    /// `enumerate()` giữ nguyên tính là [`usize`].
    /// Nếu bạn muốn đếm bằng một số nguyên có kích thước khác, hàm [`zip`] cung cấp chức năng tương tự.
    ///
    /// # Hành vi tràn
    ///
    /// Phương thức này không bảo vệ chống tràn, vì vậy việc liệt kê nhiều hơn phần tử [`usize::MAX`] hoặc tạo ra kết quả sai hoặc panics.
    /// Nếu xác nhận gỡ lỗi được bật, panic được đảm bảo.
    ///
    /// # Panics
    ///
    /// Trình lặp được trả về có thể panic nếu chỉ mục được trả về sẽ làm tràn [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Tạo một trình vòng lặp có thể sử dụng [`peek`] để xem phần tử tiếp theo của trình vòng lặp mà không sử dụng nó.
    ///
    /// Thêm một phương thức [`peek`] vào một trình vòng lặp.Xem tài liệu của nó để biết thêm thông tin.
    ///
    /// Lưu ý rằng trình lặp bên dưới vẫn được nâng cao khi [`peek`] được gọi lần đầu tiên: Để truy xuất phần tử tiếp theo, [`next`] được gọi trên trình lặp bên dưới, do đó có bất kỳ tác dụng phụ nào (tức là
    ///
    /// bất kỳ điều gì khác ngoài việc tìm nạp giá trị tiếp theo) của phương thức [`next`] sẽ xảy ra.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() hãy để chúng tôi nhìn vào future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // chúng ta có thể peek() nhiều lần, trình lặp sẽ không tiến lên
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // sau khi trình lặp kết thúc, peek() cũng vậy
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Tạo một trình lặp [`bỏ qua`] các phần tử dựa trên một vị từ.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` lấy một đóng cửa làm đối số.Nó sẽ gọi sự đóng này trên mỗi phần tử của trình vòng lặp và bỏ qua các phần tử cho đến khi nó trả về `false`.
    ///
    /// Sau khi `false` được trả lại, công việc `skip_while()`'s kết thúc và các phần tử còn lại được tạo ra.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Bởi vì bao đóng được chuyển đến `skip_while()` nhận một tham chiếu và nhiều trình lặp lặp qua các tham chiếu, điều này dẫn đến một tình huống có thể khó hiểu, trong đó loại của đối số bao đóng là một tham chiếu kép:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // cần hai * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Dừng sau một `false` ban đầu:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // trong khi điều này sẽ là sai, vì chúng tôi đã nhận được sai, skip_while() không được sử dụng nữa
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Tạo một trình lặp tạo ra các phần tử dựa trên một vị từ.
    ///
    /// `take_while()` lấy một đóng cửa làm đối số.Nó sẽ gọi hàm đóng này trên mỗi phần tử của trình vòng lặp và các phần tử mang lại kết quả trong khi trả về `true`.
    ///
    /// Sau khi `false` được trả về, công việc `take_while()`'s kết thúc và các phần tử còn lại bị bỏ qua.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Bởi vì bao đóng được chuyển đến `take_while()` nhận một tham chiếu và nhiều trình vòng lặp lặp qua các tham chiếu, điều này dẫn đến một tình huống có thể khó hiểu, trong đó loại của bao đóng là một tham chiếu kép:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // cần hai * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Dừng sau một `false` ban đầu:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Chúng tôi có nhiều phần tử nhỏ hơn 0, nhưng vì chúng tôi đã có sai, nên take_while() không được sử dụng nữa
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Bởi vì `take_while()` cần xem xét giá trị để xem liệu nó có nên được đưa vào hay không, việc sử dụng các trình vòng lặp sẽ thấy rằng nó bị loại bỏ:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` không còn ở đó nữa, vì nó đã được sử dụng để xem liệu quá trình lặp có nên dừng lại hay không, nhưng không được đặt lại vào trình lặp.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Tạo một trình lặp mà cả hai đều mang lại các phần tử dựa trên một vị từ và các bản đồ.
    ///
    /// `map_while()` lấy một đóng cửa làm đối số.
    /// Nó sẽ gọi hàm đóng này trên mỗi phần tử của trình vòng lặp và các phần tử mang lại kết quả trong khi trả về [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Đây là ví dụ tương tự, nhưng với [`take_while`] và [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Dừng sau một [`None`] ban đầu:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Chúng tôi có nhiều phần tử hơn có thể phù hợp với u32 (4, 5), nhưng `map_while` trả về `None` cho `-3` (vì `predicate` trả về `None`) và `collect` dừng lại ở lần gặp `None` đầu tiên.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Bởi vì `map_while()` cần xem xét giá trị để xem liệu nó có nên được đưa vào hay không, việc sử dụng các trình vòng lặp sẽ thấy rằng nó bị loại bỏ:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` không còn ở đó nữa, vì nó đã được sử dụng để xem liệu quá trình lặp có nên dừng lại hay không, nhưng không được đặt lại vào trình lặp.
    ///
    /// Lưu ý rằng không giống như [`take_while`], trình lặp này **không** hợp nhất.
    /// Nó cũng không được chỉ định những gì trình lặp này trả về sau khi [`None`] đầu tiên được trả về.
    /// Nếu bạn cần trình lặp hợp nhất, hãy sử dụng [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Tạo một trình lặp bỏ qua các phần tử `n` đầu tiên.
    ///
    /// Sau khi chúng đã được tiêu thụ, phần còn lại của các nguyên tố được tạo ra.
    /// Thay vì ghi đè phương thức này trực tiếp, thay vào đó ghi đè phương thức `nth`.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Tạo một trình lặp tạo ra các phần tử `n` đầu tiên của nó.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` thường được sử dụng với một trình lặp vô hạn, để làm cho nó hữu hạn:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Nếu có ít hơn các phần tử `n`, `take` sẽ tự giới hạn kích thước của trình lặp bên dưới:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Một bộ điều hợp trình vòng lặp tương tự như [`fold`] giữ trạng thái bên trong và tạo ra một trình vòng lặp mới.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` nhận hai đối số: một giá trị ban đầu tạo ra trạng thái bên trong và một bao đóng với hai đối số, đối số đầu tiên là một tham chiếu có thể thay đổi đến trạng thái bên trong và giá trị thứ hai là một phần tử trình vòng lặp.
    ///
    /// Việc đóng có thể gán cho trạng thái bên trong để chia sẻ trạng thái giữa các lần lặp.
    ///
    /// Khi lặp lại, việc đóng sẽ được áp dụng cho từng phần tử của trình vòng lặp và giá trị trả về từ bao đóng, một [`Option`], được tạo ra bởi trình vòng lặp.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // mỗi lần lặp, chúng tôi sẽ nhân trạng thái với phần tử
    ///     *state = *state * x;
    ///
    ///     // sau đó, chúng tôi sẽ đưa ra phủ định của trạng thái
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Tạo một trình lặp hoạt động giống như bản đồ, nhưng làm phẳng cấu trúc lồng nhau.
    ///
    /// Bộ điều hợp [`map`] rất hữu ích, nhưng chỉ khi đối số đóng tạo ra giá trị.
    /// Nếu thay vào đó, nó tạo ra một trình lặp, thì sẽ có thêm một lớp hướng dẫn.
    /// `flat_map()` sẽ tự loại bỏ lớp thừa này.
    ///
    /// Bạn có thể coi `flat_map(f)` tương đương với ngữ nghĩa của ping [`map`], và sau đó là [`flatten`] ing như trong `map(f).flatten()`.
    ///
    /// Một cách khác để suy nghĩ về `flat_map()`: Bao đóng của [`map`] trả về một mục cho mỗi phần tử và bao đóng `flat_map()`'s trả về một trình lặp cho mỗi phần tử.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() trả về một trình lặp
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Tạo một trình lặp làm phẳng cấu trúc lồng nhau.
    ///
    /// Điều này hữu ích khi bạn có một trình vòng lặp của các trình vòng lặp hoặc một trình vòng lặp của những thứ có thể được chuyển thành trình vòng lặp và bạn muốn loại bỏ một cấp của hướng dẫn.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Lập bản đồ và sau đó làm phẳng:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() trả về một trình lặp
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Bạn cũng có thể viết lại điều này theo [`flat_map()`], điều này thích hợp hơn trong trường hợp này vì nó truyền đạt ý định rõ ràng hơn:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() trả về một trình lặp
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Làm phẳng chỉ loại bỏ một mức độ lồng vào một thời điểm:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Ở đây chúng ta thấy rằng `flatten()` không thực hiện san phẳng "deep".
    /// Thay vào đó, chỉ một cấp độ lồng được loại bỏ.Tức là, nếu bạn `flatten()` một mảng ba chiều, kết quả sẽ là hai chiều chứ không phải một chiều.
    /// Để có được cấu trúc một chiều, bạn phải `flatten()` một lần nữa.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Tạo một trình lặp kết thúc sau [`None`] đầu tiên.
    ///
    /// Sau khi trình vòng lặp trả về [`None`], các lệnh gọi future có thể mang lại hoặc không mang lại [`Some(T)`] một lần nữa.
    /// `fuse()` điều chỉnh một trình lặp, đảm bảo rằng sau khi [`None`] được cung cấp, nó sẽ luôn trả về [`None`] mãi mãi.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// // một trình lặp thay thế giữa Một số và Không có
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // nếu nó thậm chí, Some(i32), khác Không
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // chúng ta có thể thấy trình lặp của mình quay đi quay lại
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // tuy nhiên, một khi chúng tôi hợp nhất nó ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // nó sẽ luôn trả về `None` sau lần đầu tiên.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Thực hiện điều gì đó với mỗi phần tử của một trình lặp, truyền giá trị vào.
    ///
    /// Khi sử dụng các trình vòng lặp, bạn thường sẽ xâu chuỗi một số chúng lại với nhau.
    /// Trong khi làm việc trên mã như vậy, bạn có thể muốn kiểm tra những gì đang xảy ra ở các phần khác nhau trong đường dẫn.Để làm điều đó, hãy chèn một cuộc gọi tới `inspect()`.
    ///
    /// `inspect()` thường được sử dụng như một công cụ gỡ lỗi hơn là tồn tại trong mã cuối cùng của bạn, nhưng các ứng dụng có thể thấy nó hữu ích trong một số trường hợp nhất định khi các lỗi cần được ghi lại trước khi bị loại bỏ.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // trình tự lặp này phức tạp.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // hãy thêm một số cuộc gọi inspect() để điều tra những gì đang xảy ra
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Điều này sẽ in:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Ghi lại các lỗi trước khi loại bỏ chúng:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Điều này sẽ in:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Mượn một trình lặp, thay vì sử dụng nó.
    ///
    /// Điều này rất hữu ích để cho phép áp dụng bộ điều hợp trình lặp trong khi vẫn giữ quyền sở hữu trình lặp ban đầu.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // nếu chúng tôi cố gắng sử dụng nó một lần nữa, nó sẽ không hoạt động.
    /// // Dòng sau cho "lỗi: sử dụng giá trị đã di chuyển: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // chúng ta hãy thử điều đó một lần nữa
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // thay vào đó, chúng tôi thêm vào một .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // bây giờ điều này là tốt:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Chuyển một trình lặp thành một tập hợp.
    ///
    /// `collect()` có thể lấy bất kỳ thứ gì có thể lặp lại và biến nó thành một bộ sưu tập có liên quan.
    /// Đây là một trong những phương pháp mạnh mẽ hơn trong thư viện chuẩn, được sử dụng trong nhiều ngữ cảnh khác nhau.
    ///
    /// Mô hình cơ bản nhất mà `collect()` được sử dụng là biến một bộ sưu tập này thành một bộ sưu tập khác.
    /// Bạn lấy một bộ sưu tập, gọi [`iter`] trên đó, thực hiện một loạt các phép biến đổi và sau đó là `collect()` ở cuối.
    ///
    /// `collect()` cũng có thể tạo các thể hiện của các loại không phải là bộ sưu tập điển hình.
    /// Ví dụ: [`String`] có thể được tạo từ [`char`] s và một trình lặp của các mục [`Result<T, E>`][`Result`] có thể được thu thập vào `Result<Collection<T>, E>`.
    ///
    /// Xem các ví dụ bên dưới để biết thêm.
    ///
    /// Vì `collect()` quá chung chung nên nó có thể gây ra vấn đề với kiểu suy luận.
    /// Do đó, `collect()` là một trong số ít lần bạn sẽ thấy cú pháp được gọi một cách trìu mến là 'turbofish': `::<>`.
    /// Điều này giúp thuật toán suy luận hiểu cụ thể bộ sưu tập mà bạn đang cố gắng thu thập.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Lưu ý rằng chúng tôi cần `: Vec<i32>` ở phía bên trái.Điều này là do chúng tôi có thể thu thập, chẳng hạn như [`VecDeque<T>`] để thay thế:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Sử dụng 'turbofish' thay vì chú thích `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Bởi vì `collect()` chỉ quan tâm đến những gì bạn đang thu thập, bạn vẫn có thể sử dụng gợi ý loại một phần, `_`, với turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Sử dụng `collect()` để tạo [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Nếu bạn có danh sách [`Kết quả<T, E>`][`Result`] s, bạn có thể sử dụng `collect()` để xem có lỗi nào không:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // cho chúng tôi lỗi đầu tiên
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // cung cấp cho chúng tôi danh sách các câu trả lời
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Sử dụng một trình lặp, tạo hai bộ sưu tập từ nó.
    ///
    /// Vị từ được chuyển đến `partition()` có thể trả về `true` hoặc `false`.
    /// `partition()` trả về một cặp, tất cả các phần tử mà nó trả về `true` và tất cả các phần tử mà nó trả về `false`.
    ///
    ///
    /// Xem thêm [`is_partitioned()`] và [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Sắp xếp lại các phần tử của trình lặp này *tại chỗ* theo vị từ đã cho, sao cho tất cả những phần tử trả về `true` đứng trước tất cả những phần tử trả về `false`.
    ///
    /// Trả về số phần tử `true` được tìm thấy.
    ///
    /// Thứ tự tương đối của các mục được phân vùng không được duy trì.
    ///
    /// Xem thêm [`is_partitioned()`] và [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Phân vùng tại chỗ giữa evens và tỷ lệ cược
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: chúng ta có nên lo lắng về số lượng bị tràn không?Cách duy nhất để có nhiều hơn
        // `usize::MAX` các tham chiếu có thể thay đổi được với ZST, không hữu ích để phân vùng ...

        // Các hàm "factory" đóng này tồn tại để tránh tính chung chung trong `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Liên tục tìm `false` đầu tiên và hoán đổi nó với `true` cuối cùng.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Kiểm tra xem các phần tử của trình lặp này có được phân vùng theo vị từ đã cho hay không, sao cho tất cả những phần tử trả về `true` đứng trước tất cả những phần tử trả về `false`.
    ///
    ///
    /// Xem thêm [`partition()`] và [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Tất cả các mục đều kiểm tra `true` hoặc mệnh đề đầu tiên dừng ở `false` và chúng tôi kiểm tra rằng không có mục `true` nào nữa sau đó.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Phương thức trình lặp áp dụng một hàm miễn là nó trả về thành công, tạo ra một giá trị cuối cùng, duy nhất.
    ///
    /// `try_fold()` nhận hai đối số: một giá trị ban đầu và một bao đóng với hai đối số: một 'accumulator' và một phần tử.
    /// Việc đóng lại trả về thành công, với giá trị mà bộ tích lũy phải có cho lần lặp tiếp theo hoặc trả về lỗi, với giá trị lỗi được truyền trở lại người gọi ngay lập tức (short-circuiting).
    ///
    ///
    /// Giá trị ban đầu là giá trị mà bộ tích lũy sẽ có trong lần gọi đầu tiên.Nếu áp dụng đóng thành công đối với mọi phần tử của trình vòng lặp, `try_fold()` trả về bộ tích lũy cuối cùng là thành công.
    ///
    /// Gấp rất hữu ích bất cứ khi nào bạn có một bộ sưu tập thứ gì đó và muốn tạo ra một giá trị duy nhất từ nó.
    ///
    /// # Lưu ý cho người thực hiện
    ///
    /// Một số phương thức (forward) khác có các triển khai mặc định về phương thức này, vì vậy hãy cố gắng triển khai điều này một cách rõ ràng nếu nó có thể làm điều gì đó tốt hơn việc triển khai vòng lặp `for` mặc định.
    ///
    /// Đặc biệt, hãy cố gắng đặt lệnh gọi `try_fold()` này trên các bộ phận bên trong mà từ đó trình lặp này được tạo thành.
    /// Nếu cần nhiều cuộc gọi, nhà khai thác `?` có thể thuận tiện cho việc xâu chuỗi giá trị của bộ tích lũy, nhưng hãy cẩn thận với bất kỳ biến số nào cần được giữ nguyên trước khi trả về sớm.
    /// Đây là một phương thức `&mut self`, vì vậy cần phải tiếp tục lặp lại sau khi gặp lỗi ở đây.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // tổng đã kiểm tra của tất cả các phần tử của mảng
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Tổng này tràn khi thêm phần tử 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Bởi vì nó ngắn mạch, các phần tử còn lại vẫn có sẵn thông qua bộ lặp.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Phương thức trình vòng lặp áp dụng một hàm fallible cho từng mục trong trình vòng lặp, dừng lại ở lỗi đầu tiên và trả về lỗi đó.
    ///
    ///
    /// Đây cũng có thể được coi là dạng dễ vỡ của [`for_each()`] hoặc là phiên bản không trạng thái của [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Nó bị đoản mạch, vì vậy các mục còn lại vẫn nằm trong trình vòng lặp:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Gấp mọi phần tử vào một bộ tích lũy bằng cách áp dụng một phép toán, trả về kết quả cuối cùng.
    ///
    /// `fold()` nhận hai đối số: một giá trị ban đầu và một bao đóng với hai đối số: một 'accumulator' và một phần tử.
    /// Việc đóng lại trả về giá trị mà bộ tích lũy phải có cho lần lặp tiếp theo.
    ///
    /// Giá trị ban đầu là giá trị mà bộ tích lũy sẽ có trong lần gọi đầu tiên.
    ///
    /// Sau khi áp dụng cách đóng này cho mọi phần tử của trình vòng lặp, `fold()` trả về bộ tích lũy.
    ///
    /// Hoạt động này đôi khi được gọi là 'reduce' hoặc 'inject'.
    ///
    /// Gấp rất hữu ích bất cứ khi nào bạn có một bộ sưu tập thứ gì đó và muốn tạo ra một giá trị duy nhất từ nó.
    ///
    /// Note: `fold()` và các phương thức tương tự đi qua toàn bộ trình vòng lặp, có thể không kết thúc đối với trình vòng lặp vô hạn, ngay cả trên traits mà kết quả có thể xác định được trong thời gian hữu hạn.
    ///
    /// Note: [`reduce()`] có thể được sử dụng để sử dụng phần tử đầu tiên làm giá trị ban đầu, nếu loại bộ tích lũy và loại vật phẩm giống nhau.
    ///
    /// # Lưu ý cho người thực hiện
    ///
    /// Một số phương thức (forward) khác có các triển khai mặc định về phương thức này, vì vậy hãy cố gắng triển khai điều này một cách rõ ràng nếu nó có thể làm điều gì đó tốt hơn việc triển khai vòng lặp `for` mặc định.
    ///
    ///
    /// Đặc biệt, hãy cố gắng đặt lệnh gọi `fold()` này trên các bộ phận bên trong mà từ đó trình lặp này được tạo thành.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // tổng của tất cả các phần tử của mảng
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Hãy xem từng bước của quá trình lặp lại ở đây:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Và như vậy, kết quả cuối cùng của chúng tôi, `6`.
    ///
    /// Những người chưa sử dụng nhiều lần sử dụng vòng lặp thường sử dụng vòng lặp `for` với danh sách những thứ cần xây dựng kết quả.Những thứ đó có thể được chuyển thành `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // vòng lặp for:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // chúng giống nhau
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Giảm các phần tử thành một phần tử duy nhất, bằng cách áp dụng nhiều lần thao tác giảm.
    ///
    /// Nếu trình vòng lặp trống, trả về [`None`];nếu không, trả về kết quả của việc giảm.
    ///
    /// Đối với trình vòng lặp có ít nhất một phần tử, điều này giống như [`fold()`] với phần tử đầu tiên của trình vòng lặp là giá trị ban đầu, gấp mọi phần tử tiếp theo vào nó.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Tìm giá trị lớn nhất:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Kiểm tra xem mọi phần tử của trình lặp có khớp với một vị từ hay không.
    ///
    /// `all()` thực hiện một lần đóng trả về `true` hoặc `false`.Nó áp dụng cách đóng này cho từng phần tử của trình vòng lặp và nếu tất cả chúng đều trả về `true`, thì `all()` cũng vậy.
    /// Nếu bất kỳ trong số chúng trả về `false`, nó sẽ trả về `false`.
    ///
    /// `all()` đang chập mạch;nói cách khác, nó sẽ ngừng xử lý ngay khi tìm thấy `false`, vì cho dù có điều gì khác xảy ra, kết quả cũng sẽ là `false`.
    ///
    ///
    /// Một trình lặp trống trả về `true`.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Dừng lại ở `false` đầu tiên:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // chúng ta vẫn có thể sử dụng `iter`, vì có nhiều phần tử hơn.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Kiểm tra xem bất kỳ phần tử nào của trình lặp khớp với một vị từ.
    ///
    /// `any()` thực hiện một lần đóng trả về `true` hoặc `false`.Nó áp dụng cách đóng này cho từng phần tử của trình vòng lặp và nếu bất kỳ phần tử nào trong số chúng trả về `true`, thì `any()` cũng vậy.
    /// Nếu tất cả chúng đều trả về `false`, nó sẽ trả về `false`.
    ///
    /// `any()` đang chập mạch;nói cách khác, nó sẽ ngừng xử lý ngay khi tìm thấy `true`, vì cho dù có điều gì khác xảy ra, kết quả cũng sẽ là `true`.
    ///
    ///
    /// Một trình lặp trống trả về `false`.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Dừng lại ở `true` đầu tiên:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // chúng ta vẫn có thể sử dụng `iter`, vì có nhiều phần tử hơn.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Tìm kiếm một phần tử của một trình lặp thỏa mãn một vị từ.
    ///
    /// `find()` thực hiện một lần đóng trả về `true` hoặc `false`.
    /// Nó áp dụng cách đóng này cho từng phần tử của trình vòng lặp và nếu bất kỳ phần tử nào trong số chúng trả về `true`, thì `find()` trả về [`Some(element)`].
    /// Nếu tất cả chúng đều trả về `false`, nó sẽ trả về [`None`].
    ///
    /// `find()` đang chập mạch;nói cách khác, nó sẽ ngừng xử lý ngay khi quá trình đóng trả về `true`.
    ///
    /// Bởi vì `find()` có một tham chiếu và nhiều trình lặp lặp qua các tham chiếu, điều này dẫn đến một tình huống có thể gây nhầm lẫn trong đó đối số là một tham chiếu kép.
    ///
    /// Bạn có thể thấy hiệu ứng này trong các ví dụ bên dưới, với `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Dừng lại ở `true` đầu tiên:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // chúng ta vẫn có thể sử dụng `iter`, vì có nhiều phần tử hơn.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Lưu ý rằng `iter.find(f)` tương đương với `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Áp dụng hàm cho các phần tử của trình lặp và trả về kết quả đầu tiên không phải là không có.
    ///
    ///
    /// `iter.find_map(f)` tương đương với `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Áp dụng hàm cho các phần tử của trình lặp và trả về kết quả đúng đầu tiên hoặc lỗi đầu tiên.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Tìm kiếm một phần tử trong một trình lặp, trả về chỉ mục của nó.
    ///
    /// `position()` thực hiện một lần đóng trả về `true` hoặc `false`.
    /// Nó áp dụng cách đóng này cho từng phần tử của trình vòng lặp và nếu một trong số chúng trả về `true`, thì `position()` trả về [`Some(index)`].
    /// Nếu tất cả chúng trả về `false`, nó sẽ trả về [`None`].
    ///
    /// `position()` đang chập mạch;nói cách khác, nó sẽ ngừng xử lý ngay khi tìm thấy `true`.
    ///
    /// # Hành vi tràn
    ///
    /// Phương thức này không bảo vệ chống tràn, vì vậy nếu có nhiều hơn [`usize::MAX`] phần tử không phù hợp, nó sẽ tạo ra kết quả sai hoặc panics.
    ///
    /// Nếu xác nhận gỡ lỗi được bật, panic được đảm bảo.
    ///
    /// # Panics
    ///
    /// Hàm này có thể panic nếu trình lặp có nhiều hơn `usize::MAX` phần tử không phù hợp.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Dừng lại ở `true` đầu tiên:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // chúng ta vẫn có thể sử dụng `iter`, vì có nhiều phần tử hơn.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Chỉ mục trả về phụ thuộc vào trạng thái của trình lặp
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Tìm kiếm một phần tử trong một trình lặp từ bên phải, trả về chỉ mục của nó.
    ///
    /// `rposition()` thực hiện một lần đóng trả về `true` hoặc `false`.
    /// Nó áp dụng cách đóng này cho từng phần tử của trình vòng lặp, bắt đầu từ phần cuối và nếu một trong số chúng trả về `true`, thì `rposition()` trả về [`Some(index)`].
    ///
    /// Nếu tất cả chúng trả về `false`, nó sẽ trả về [`None`].
    ///
    /// `rposition()` đang chập mạch;nói cách khác, nó sẽ ngừng xử lý ngay khi tìm thấy `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Dừng lại ở `true` đầu tiên:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // chúng ta vẫn có thể sử dụng `iter`, vì có nhiều phần tử hơn.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Không cần kiểm tra tràn ở đây, vì `ExactSizeIterator` ngụ ý rằng số phần tử phù hợp với `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Trả về phần tử tối đa của một trình vòng lặp.
    ///
    /// Nếu một số phần tử có giá trị lớn nhất bằng nhau, phần tử cuối cùng được trả về.
    /// Nếu trình vòng lặp trống, [`None`] được trả về.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Trả về phần tử nhỏ nhất của một trình vòng lặp.
    ///
    /// Nếu một số phần tử có giá trị nhỏ nhất bằng nhau, phần tử đầu tiên được trả về.
    /// Nếu trình vòng lặp trống, [`None`] được trả về.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Trả về phần tử cho giá trị lớn nhất từ hàm được chỉ định.
    ///
    ///
    /// Nếu một số phần tử có giá trị lớn nhất bằng nhau, phần tử cuối cùng được trả về.
    /// Nếu trình vòng lặp trống, [`None`] được trả về.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Trả về phần tử mang lại giá trị lớn nhất liên quan đến hàm so sánh được chỉ định.
    ///
    ///
    /// Nếu một số phần tử có giá trị lớn nhất bằng nhau, phần tử cuối cùng được trả về.
    /// Nếu trình vòng lặp trống, [`None`] được trả về.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Trả về phần tử cho giá trị nhỏ nhất từ hàm được chỉ định.
    ///
    ///
    /// Nếu một số phần tử có giá trị nhỏ nhất bằng nhau, phần tử đầu tiên được trả về.
    /// Nếu trình vòng lặp trống, [`None`] được trả về.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Trả về phần tử mang lại giá trị nhỏ nhất liên quan đến hàm so sánh được chỉ định.
    ///
    ///
    /// Nếu một số phần tử có giá trị nhỏ nhất bằng nhau, phần tử đầu tiên được trả về.
    /// Nếu trình vòng lặp trống, [`None`] được trả về.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Đảo ngược hướng của trình lặp.
    ///
    /// Thông thường, các trình lặp sẽ lặp lại từ trái sang phải.
    /// Sau khi sử dụng `rev()`, thay vào đó, một trình lặp sẽ lặp lại từ phải sang trái.
    ///
    /// Điều này chỉ có thể thực hiện được nếu trình lặp có kết thúc, vì vậy `rev()` chỉ hoạt động trên [`DoubleEndedIterator`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Chuyển đổi một trình lặp của các cặp thành một cặp vùng chứa.
    ///
    /// `unzip()` sử dụng toàn bộ trình lặp của các cặp, tạo ra hai tập hợp: một từ các phần tử bên trái của các cặp và một từ các phần tử bên phải.
    ///
    ///
    /// Chức năng này, theo một nghĩa nào đó, ngược lại với [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Tạo một trình lặp sao chép tất cả các phần tử của nó.
    ///
    /// Điều này hữu ích khi bạn có một trình lặp trên `&T`, nhưng bạn cần một trình lặp trên `T`.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // được sao chép giống như .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Tạo một trình lặp [`sao chép`] tất cả các phần tử của nó.
    ///
    /// Điều này hữu ích khi bạn có một trình lặp trên `&T`, nhưng bạn cần một trình lặp trên `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // nhân bản giống như .map(|&x| x), dành cho số nguyên
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Lặp lại liên tục một trình lặp.
    ///
    /// Thay vì dừng lại ở [`None`], trình lặp sẽ bắt đầu lại từ đầu.Sau khi lặp lại, nó sẽ bắt đầu lại từ đầu.Và một lần nữa.
    /// Và một lần nữa.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Tính tổng các phần tử của một trình vòng lặp.
    ///
    /// Lấy từng phần tử, thêm chúng lại với nhau và trả về kết quả.
    ///
    /// Một trình lặp rỗng trả về giá trị 0 của kiểu.
    ///
    /// # Panics
    ///
    /// Khi gọi `sum()` và một kiểu số nguyên nguyên thủy đang được trả về, phương thức này sẽ panic nếu tính toán tràn và các xác nhận gỡ lỗi được bật.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Lặp lại trên toàn bộ trình lặp, nhân tất cả các phần tử
    ///
    /// Một trình lặp rỗng trả về một giá trị của kiểu.
    ///
    /// # Panics
    ///
    /// Khi gọi `product()` và một kiểu số nguyên nguyên thủy đang được trả về, phương thức sẽ panic nếu tính toán tràn và xác nhận gỡ lỗi được bật.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) so sánh các phần tử của [`Iterator`] này với các phần tử khác.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) so sánh các phần tử của [`Iterator`] này với các phần tử khác liên quan đến chức năng so sánh được chỉ định.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) so sánh các phần tử của [`Iterator`] này với các phần tử khác.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) so sánh các phần tử của [`Iterator`] này với các phần tử khác liên quan đến chức năng so sánh được chỉ định.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Xác định xem các phần tử của [`Iterator`] này có bằng các phần tử của [`Iterator`] khác hay không.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Xác định xem các phần tử của [`Iterator`] này có bằng các phần tử của một phần tử khác đối với hàm bình đẳng được chỉ định hay không.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Xác định xem các phần tử của [`Iterator`] này có ngang bằng với các phần tử khác hay không.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Xác định xem các phần tử của [`Iterator`] này có nhỏ hơn [lexicographically](Ord#lexicographical-comparison) hay không.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Xác định xem các phần tử của [`Iterator`] này nhỏ hơn hoặc bằng [lexicographically](Ord#lexicographical-comparison) với các phần tử của một phần tử khác.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Xác định xem các phần tử của [`Iterator`] này có lớn hơn [lexicographically](Ord#lexicographical-comparison) hay không.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Xác định xem các phần tử của [`Iterator`] này là [lexicographically](Ord#lexicographical-comparison) lớn hơn hoặc bằng các phần tử của một phần tử khác.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Kiểm tra xem các phần tử của trình vòng lặp này có được sắp xếp hay không.
    ///
    /// Nghĩa là, đối với mỗi phần tử `a` và phần tử sau `b`, `a <= b` phải giữ.Nếu trình lặp cho kết quả chính xác bằng không hoặc một phần tử, thì `true` sẽ được trả về.
    ///
    /// Lưu ý rằng nếu `Self::Item` chỉ là `PartialOrd`, chứ không phải `Ord`, định nghĩa trên ngụ ý rằng hàm này trả về `false` nếu bất kỳ hai mục liên tiếp nào không so sánh được.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Kiểm tra xem các phần tử của trình lặp này có được sắp xếp bằng cách sử dụng hàm so sánh đã cho hay không.
    ///
    /// Thay vì sử dụng `PartialOrd::partial_cmp`, hàm này sử dụng hàm `compare` đã cho để xác định thứ tự của hai phần tử.
    /// Ngoài ra, nó tương đương với [`is_sorted`];xem tài liệu của nó để biết thêm thông tin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Kiểm tra xem các phần tử của trình vòng lặp này có được sắp xếp bằng cách sử dụng hàm trích xuất khóa đã cho hay không.
    ///
    /// Thay vì so sánh trực tiếp các phần tử của trình lặp, hàm này so sánh các khóa của các phần tử, như được xác định bởi `f`.
    /// Ngoài ra, nó tương đương với [`is_sorted`];xem tài liệu của nó để biết thêm thông tin.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Xem [TrustedRandomAccess]
    // Tên bất thường là để tránh xung đột tên trong độ phân giải phương pháp, xem #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}