/// Một trình lặp biết độ dài chính xác của nó.
///
/// Nhiều [`Iterator`] không biết họ sẽ lặp lại bao nhiêu lần, nhưng một số thì có.
/// Nếu một trình lặp biết nó có thể lặp lại bao nhiêu lần, thì việc cung cấp quyền truy cập vào thông tin đó có thể hữu ích.
/// Ví dụ, nếu bạn muốn lặp đi lặp lại, một khởi đầu tốt là bạn phải biết kết thúc ở đâu.
///
/// Khi triển khai `ExactSizeIterator`, bạn cũng phải triển khai [`Iterator`].
/// Khi làm như vậy, việc triển khai [`Iterator::size_hint`]*phải* trả về kích thước chính xác của trình vòng lặp.
///
/// Phương thức [`len`] có một triển khai mặc định, vì vậy bạn thường không nên triển khai nó.
/// Tuy nhiên, bạn có thể cung cấp một triển khai hiệu quả hơn so với mặc định, vì vậy việc ghi đè nó trong trường hợp này là rất hợp lý.
///
///
/// Lưu ý rằng trait này là trait an toàn và như vậy *không* và *không thể* đảm bảo rằng độ dài trả về là chính xác.
/// Điều này có nghĩa là mã `unsafe`**không được** dựa vào tính chính xác của [`Iterator::size_hint`].
/// [`TrustedLen`](super::marker::TrustedLen) trait không ổn định và không an toàn mang lại sự đảm bảo bổ sung này.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Cách sử dụng cơ bản:
///
/// ```
/// // một phạm vi hữu hạn biết chính xác nó sẽ lặp lại bao nhiêu lần
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Trong [module-level docs], chúng tôi đã triển khai [`Iterator`], `Counter`.
/// Hãy triển khai `ExactSizeIterator` cho nó nữa:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Chúng ta có thể dễ dàng tính toán số lần lặp còn lại.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Và bây giờ chúng ta có thể sử dụng nó!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Trả về độ dài chính xác của trình vòng lặp.
    ///
    /// Việc triển khai đảm bảo rằng trình lặp sẽ trả về chính xác `len()` nhiều lần hơn một giá trị [`Some(T)`], trước khi trả về [`None`].
    ///
    /// Phương pháp này có một triển khai mặc định, vì vậy bạn thường không nên triển khai trực tiếp.
    /// Tuy nhiên, nếu bạn có thể cung cấp một triển khai hiệu quả hơn, bạn có thể làm như vậy.
    /// Xem tài liệu [trait-level] để làm ví dụ.
    ///
    /// Chức năng này có các đảm bảo an toàn tương tự như chức năng [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// // một phạm vi hữu hạn biết chính xác nó sẽ lặp lại bao nhiêu lần
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Khẳng định này là phòng thủ quá mức, nhưng nó kiểm tra sự bất biến
        // được đảm bảo bởi trait.
        // Nếu trait này là rust-internal, chúng ta có thể sử dụng debug_assert !;khẳng định_eq!cũng sẽ kiểm tra tất cả các triển khai của người dùng Rust.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Trả về `true` nếu trình vòng lặp trống.
    ///
    /// Phương pháp này có cài đặt mặc định bằng [`ExactSizeIterator::len()`], vì vậy bạn không cần phải tự triển khai.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}