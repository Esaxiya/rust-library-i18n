/// Một trình lặp luôn tiếp tục mang lại `None` khi cạn kiệt.
///
/// Việc gọi tiếp theo trên một trình lặp hợp nhất đã trả về `None` một lần được đảm bảo sẽ trả về [`None`] một lần nữa.
/// trait này nên được thực hiện bởi tất cả các trình vòng lặp hoạt động theo cách này vì nó cho phép tối ưu hóa [`Iterator::fuse()`].
///
///
/// Note: Nói chung, bạn không nên sử dụng `FusedIterator` trong các giới hạn chung nếu bạn cần một trình lặp hợp nhất.
/// Thay vào đó, bạn chỉ nên gọi [`Iterator::fuse()`] trên trình vòng lặp.
/// Nếu trình lặp đã được hợp nhất, trình bao bọc [`Fuse`] bổ sung sẽ là một lựa chọn không cần sử dụng mà không bị phạt về hiệu suất.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Một trình lặp báo cáo độ dài chính xác bằng cách sử dụng size_hint.
///
/// Trình lặp báo cáo gợi ý kích thước trong đó nó chính xác (giới hạn dưới bằng giới hạn trên) hoặc giới hạn trên là [`None`].
///
/// Giới hạn trên chỉ phải là [`None`] nếu độ dài trình lặp thực tế lớn hơn [`usize::MAX`].
/// Trong trường hợp đó, giới hạn dưới phải là [`usize::MAX`], dẫn đến [`Iterator::size_hint()`] là `(usize::MAX, None)`.
///
/// Trình lặp phải tạo ra chính xác số phần tử mà nó đã báo cáo hoặc phân kỳ trước khi đến cuối.
///
/// # Safety
///
/// trait này chỉ phải được thực hiện khi hợp đồng được duy trì.
/// Người tiêu dùng trait này phải kiểm tra giới hạn trên của [`Iterator::size_hint()`]’s.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Một trình lặp khi tạo ra một mục sẽ lấy ít nhất một phần tử từ [`SourceIter`] cơ bản của nó.
///
/// Gọi bất kỳ phương thức nào cải tiến trình vòng lặp, ví dụ:
/// [`next()`] hoặc [`try_fold()`], đảm bảo rằng đối với mỗi bước, ít nhất một giá trị của nguồn cơ bản của trình vòng lặp đã được chuyển ra ngoài và kết quả của chuỗi trình vòng lặp có thể được chèn vào vị trí của nó, giả sử rằng các ràng buộc cấu trúc của nguồn cho phép chèn như vậy.
///
/// Nói cách khác, trait này chỉ ra rằng một đường ống trình vòng lặp có thể được thu thập tại chỗ.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}