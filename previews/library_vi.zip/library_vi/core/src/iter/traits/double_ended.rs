use crate::ops::{ControlFlow, Try};

/// Một trình lặp có thể mang lại các phần tử từ cả hai đầu.
///
/// Một cái gì đó triển khai `DoubleEndedIterator` có một khả năng bổ sung so với một cái gì đó triển khai [`Iterator`]: khả năng cũng lấy `Item` từ phía sau, cũng như phía trước.
///
///
/// Điều quan trọng cần lưu ý là cả lùi và lùi đều hoạt động trên cùng một phạm vi, và không chéo nhau: quá trình lặp sẽ kết thúc khi chúng gặp nhau ở giữa.
///
/// Tương tự như giao thức [`Iterator`], khi `DoubleEndedIterator` trả về [`None`] từ [`next_back()`], việc gọi lại nó có thể hoặc không bao giờ trả lại [`Some`] nữa.
/// [`next()`] và [`next_back()`] có thể hoán đổi cho nhau cho mục đích này.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Cách sử dụng cơ bản:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Loại bỏ và trả về một phần tử từ cuối trình lặp.
    ///
    /// Trả về `None` khi không còn phần tử nào nữa.
    ///
    /// Tài liệu [trait-level] chứa nhiều thông tin chi tiết hơn.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Các phần tử được tạo bởi các phương thức của `DoubleEndedIterator` có thể khác với các phần tử được tạo bởi các phương thức của [`Iterator`]:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Nâng cao trình lặp từ phía sau bởi các phần tử `n`.
    ///
    /// `advance_back_by` là phiên bản đảo ngược của [`advance_by`].Phương thức này sẽ háo hức bỏ qua các phần tử `n` bắt đầu từ phía sau bằng cách gọi [`next_back`] tối đa `n` lần cho đến khi gặp [`None`].
    ///
    /// `advance_back_by(n)` sẽ trả về [`Ok(())`] nếu trình lặp được nâng cấp thành công bởi các phần tử `n` hoặc [`Err(k)`] nếu gặp phải [`None`], trong đó `k` là số phần tử mà trình lặp được nâng cao trước khi hết phần tử (tức là
    /// độ dài của trình lặp).
    /// Lưu ý rằng `k` luôn nhỏ hơn `n`.
    ///
    /// Gọi `advance_back_by(0)` không sử dụng bất kỳ phần tử nào và luôn trả về [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // chỉ `&3` bị bỏ qua
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Trả về phần tử thứ `n` từ cuối trình lặp.
    ///
    /// Đây thực chất là phiên bản đảo ngược của [`Iterator::nth()`].
    /// Mặc dù giống như hầu hết các hoạt động lập chỉ mục, số đếm bắt đầu từ 0, vì vậy `nth_back(0)` trả về giá trị đầu tiên từ cuối, `nth_back(1)` giá trị thứ hai, v.v.
    ///
    ///
    /// Lưu ý rằng tất cả các phần tử giữa phần tử kết thúc và phần tử trả về sẽ được tiêu thụ, bao gồm cả phần tử được trả về.
    /// Điều này cũng có nghĩa là việc gọi `nth_back(0)` nhiều lần trên cùng một trình lặp sẽ trả về các phần tử khác nhau.
    ///
    /// `nth_back()` sẽ trả về [`None`] nếu `n` lớn hơn hoặc bằng độ dài của trình lặp.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Gọi `nth_back()` nhiều lần không tua lại trình lặp:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Trả về `None` nếu có ít hơn `n + 1` phần tử:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Đây là phiên bản ngược lại của [`Iterator::try_fold()`]: nó lấy các phần tử bắt đầu từ phía sau của trình vòng lặp.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Bởi vì nó ngắn mạch, các phần tử còn lại vẫn có sẵn thông qua bộ lặp.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Phương thức trình vòng lặp làm giảm các phần tử của trình vòng lặp thành một giá trị cuối cùng, duy nhất, bắt đầu từ phía sau.
    ///
    /// Đây là phiên bản ngược lại của [`Iterator::fold()`]: nó lấy các phần tử bắt đầu từ phía sau của trình vòng lặp.
    ///
    /// `rfold()` nhận hai đối số: một giá trị ban đầu và một bao đóng với hai đối số: một 'accumulator' và một phần tử.
    /// Việc đóng lại trả về giá trị mà bộ tích lũy phải có cho lần lặp tiếp theo.
    ///
    /// Giá trị ban đầu là giá trị mà bộ tích lũy sẽ có trong lần gọi đầu tiên.
    ///
    /// Sau khi áp dụng cách đóng này cho mọi phần tử của trình vòng lặp, `rfold()` trả về bộ tích lũy.
    ///
    /// Hoạt động này đôi khi được gọi là 'reduce' hoặc 'inject'.
    ///
    /// Gấp rất hữu ích bất cứ khi nào bạn có một bộ sưu tập thứ gì đó và muốn tạo ra một giá trị duy nhất từ nó.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // tổng của tất cả các phần tử của một
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Ví dụ này xây dựng một chuỗi, bắt đầu với một giá trị ban đầu và tiếp tục với từng phần tử từ phía sau cho đến phía trước:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Tìm kiếm một phần tử của một trình lặp từ phía sau đáp ứng một vị từ.
    ///
    /// `rfind()` thực hiện một lần đóng trả về `true` hoặc `false`.
    /// Nó áp dụng cách đóng này cho từng phần tử của trình vòng lặp, bắt đầu từ cuối và nếu bất kỳ phần tử nào trong số chúng trả về `true`, thì `rfind()` trả về [`Some(element)`].
    /// Nếu tất cả chúng đều trả về `false`, nó sẽ trả về [`None`].
    ///
    /// `rfind()` đang chập mạch;nói cách khác, nó sẽ ngừng xử lý ngay khi quá trình đóng trả về `true`.
    ///
    /// Bởi vì `rfind()` có một tham chiếu và nhiều trình lặp lặp qua các tham chiếu, điều này dẫn đến một tình huống có thể gây nhầm lẫn trong đó đối số là một tham chiếu kép.
    ///
    /// Bạn có thể thấy hiệu ứng này trong các ví dụ bên dưới, với `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Dừng lại ở `true` đầu tiên:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // chúng ta vẫn có thể sử dụng `iter`, vì có nhiều phần tử hơn.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}