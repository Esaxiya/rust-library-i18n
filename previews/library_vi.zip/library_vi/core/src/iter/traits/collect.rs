/// Chuyển đổi từ [`Iterator`].
///
/// Bằng cách triển khai `FromIterator` cho một kiểu, bạn xác định cách nó sẽ được tạo từ một trình vòng lặp.
/// Điều này là phổ biến đối với các loại mô tả một bộ sưu tập của một số loại.
///
/// [`FromIterator::from_iter()`] hiếm khi được gọi một cách rõ ràng, và thay vào đó được sử dụng thông qua phương thức [`Iterator::collect()`].
///
/// Xem tài liệu [`Iterator::collect()`]'s để biết thêm ví dụ.
///
/// Xem thêm: [`IntoIterator`].
///
/// # Examples
///
/// Cách sử dụng cơ bản:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Sử dụng [`Iterator::collect()`] để sử dụng hoàn toàn `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Triển khai `FromIterator` cho loại của bạn:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Một bộ sưu tập mẫu, đó chỉ là một trình bao bọc trên Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Hãy cung cấp cho nó một số phương thức để chúng ta có thể tạo một và thêm những thứ vào nó.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // và chúng tôi sẽ triển khai FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Bây giờ chúng ta có thể tạo một trình lặp mới ...
/// let iter = (0..5).into_iter();
///
/// // ... và tạo MyCollection từ nó
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // sưu tầm các tác phẩm quá!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Tạo một giá trị từ một trình lặp.
    ///
    /// Xem [module-level documentation] để biết thêm.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Chuyển đổi thành [`Iterator`].
///
/// Bằng cách triển khai `IntoIterator` cho một kiểu, bạn xác định cách nó sẽ được chuyển đổi thành một trình lặp.
/// Điều này là phổ biến đối với các loại mô tả một bộ sưu tập của một số loại.
///
/// Một lợi ích của việc triển khai `IntoIterator` là kiểu của bạn sẽ là [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Xem thêm: [`FromIterator`].
///
/// # Examples
///
/// Cách sử dụng cơ bản:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Triển khai `IntoIterator` cho loại của bạn:
///
/// ```
/// // Một bộ sưu tập mẫu, đó chỉ là một trình bao bọc trên Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Hãy cung cấp cho nó một số phương thức để chúng ta có thể tạo một và thêm những thứ vào nó.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // và chúng tôi sẽ triển khai IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Bây giờ chúng ta có thể tạo một bộ sưu tập mới ...
/// let mut c = MyCollection::new();
///
/// // ... thêm một số thứ vào nó ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... và sau đó biến nó thành một Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Người ta thường sử dụng `IntoIterator` như một trait bound.Điều này cho phép kiểu tập hợp đầu vào thay đổi, miễn là nó vẫn là một trình lặp.
/// Giới hạn bổ sung có thể được chỉ định bằng cách hạn chế trên
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Loại của các phần tử đang được lặp lại.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Chúng ta đang biến nó thành loại trình lặp nào?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Tạo một trình lặp từ một giá trị.
    ///
    /// Xem [module-level documentation] để biết thêm.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Mở rộng một bộ sưu tập với nội dung của một trình lặp.
///
/// Các trình lặp tạo ra một loạt các giá trị và các tập hợp cũng có thể được coi là một chuỗi các giá trị.
/// `Extend` trait thu hẹp khoảng cách này, cho phép bạn mở rộng bộ sưu tập bằng cách bao gồm nội dung của trình lặp đó.
/// Khi mở rộng bộ sưu tập với một khóa đã có, mục nhập đó được cập nhật hoặc trong trường hợp bộ sưu tập cho phép nhiều mục nhập có khóa bằng nhau, mục nhập đó sẽ được chèn.
///
///
/// # Examples
///
/// Cách sử dụng cơ bản:
///
/// ```
/// // Bạn có thể mở rộng một Chuỗi với một số ký tự:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Triển khai `Extend`:
///
/// ```
/// // Một bộ sưu tập mẫu, đó chỉ là một trình bao bọc trên Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Hãy cung cấp cho nó một số phương thức để chúng ta có thể tạo một và thêm những thứ vào nó.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // vì MyCollection có danh sách các i32, chúng tôi triển khai Mở rộng cho i32
/// impl Extend<i32> for MyCollection {
///
///     // Điều này đơn giản hơn một chút với chữ ký kiểu cụ thể: chúng ta có thể gọi mở rộng trên bất kỳ thứ gì có thể biến thành một Iterator cung cấp cho chúng ta i32s.
///     // Bởi vì chúng ta cần i32s để đưa vào MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Việc triển khai rất đơn giản: lặp qua trình lặp và add() từng phần tử cho chính chúng ta.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // hãy mở rộng bộ sưu tập của chúng tôi với ba số nữa
/// c.extend(vec![1, 2, 3]);
///
/// // chúng tôi đã thêm các yếu tố này vào cuối
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Mở rộng một bộ sưu tập với nội dung của một trình lặp.
    ///
    /// Vì đây là phương thức bắt buộc duy nhất cho trait này nên tài liệu [trait-level] chứa nhiều thông tin chi tiết hơn.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// // Bạn có thể mở rộng một Chuỗi với một số ký tự:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Mở rộng một bộ sưu tập với chính xác một phần tử.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Dự trữ dung lượng trong một tập hợp cho số phần tử bổ sung đã cho.
    ///
    /// Việc thực hiện mặc định không có gì.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}