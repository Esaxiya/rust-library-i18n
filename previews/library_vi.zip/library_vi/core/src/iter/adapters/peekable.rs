use crate::iter::{adapters::SourceIter, FusedIterator, InPlaceIterable, TrustedLen};
use crate::ops::Try;

/// Một trình vòng lặp với `peek()` trả về một tham chiếu tùy chọn cho phần tử tiếp theo.
///
///
/// `struct` này được tạo bằng phương thức [`peekable`] trên [`Iterator`].
/// Xem tài liệu của nó để biết thêm.
///
/// [`peekable`]: Iterator::peekable
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Peekable<I: Iterator> {
    iter: I,
    /// Hãy nhớ một giá trị được xem trước, ngay cả khi nó là Không có.
    peeked: Option<Option<I::Item>>,
}

impl<I: Iterator> Peekable<I> {
    pub(in crate::iter) fn new(iter: I) -> Peekable<I> {
        Peekable { iter, peeked: None }
    }
}

// Peekable phải ghi nhớ nếu không nhìn thấy Không có trong phương thức `.peek()`.
// Nó đảm bảo rằng `.peek();.peek();` hoặc `.peek();.next();` chỉ nâng cấp trình lặp bên dưới nhiều nhất một lần.
// Bản thân điều này không làm cho trình lặp được hợp nhất.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> Iterator for Peekable<I> {
    type Item = I::Item;

    #[inline]
    fn next(&mut self) -> Option<I::Item> {
        match self.peeked.take() {
            Some(v) => v,
            None => self.iter.next(),
        }
    }

    #[inline]
    #[rustc_inherit_overflow_checks]
    fn count(mut self) -> usize {
        match self.peeked.take() {
            Some(None) => 0,
            Some(Some(_)) => 1 + self.iter.count(),
            None => self.iter.count(),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        match self.peeked.take() {
            Some(None) => None,
            Some(v @ Some(_)) if n == 0 => v,
            Some(Some(_)) => self.iter.nth(n - 1),
            None => self.iter.nth(n),
        }
    }

    #[inline]
    fn last(mut self) -> Option<I::Item> {
        let peek_opt = match self.peeked.take() {
            Some(None) => return None,
            Some(v) => v,
            None => None,
        };
        self.iter.last().or(peek_opt)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let peek_len = match self.peeked {
            Some(None) => return (0, Some(0)),
            Some(Some(_)) => 1,
            None => 0,
        };
        let (lo, hi) = self.iter.size_hint();
        let lo = lo.saturating_add(peek_len);
        let hi = match hi {
            Some(x) => x.checked_add(peek_len),
            None => None,
        };
        (lo, hi)
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let acc = match self.peeked.take() {
            Some(None) => return try { init },
            Some(Some(v)) => f(init, v)?,
            None => init,
        };
        self.iter.try_fold(acc, f)
    }

    #[inline]
    fn fold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let acc = match self.peeked {
            Some(None) => return init,
            Some(Some(v)) => fold(init, v),
            None => init,
        };
        self.iter.fold(acc, fold)
    }
}

#[stable(feature = "double_ended_peek_iterator", since = "1.38.0")]
impl<I> DoubleEndedIterator for Peekable<I>
where
    I: DoubleEndedIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        match self.peeked.as_mut() {
            Some(v @ Some(_)) => self.iter.next_back().or_else(|| v.take()),
            Some(None) => None,
            None => self.iter.next_back(),
        }
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        match self.peeked.take() {
            Some(None) => try { init },
            Some(Some(v)) => match self.iter.try_rfold(init, &mut f).into_result() {
                Ok(acc) => f(acc, v),
                Err(e) => {
                    self.peeked = Some(Some(v));
                    Try::from_error(e)
                }
            },
            None => self.iter.try_rfold(init, f),
        }
    }

    #[inline]
    fn rfold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        match self.peeked {
            Some(None) => init,
            Some(Some(v)) => {
                let acc = self.iter.rfold(init, &mut fold);
                fold(acc, v)
            }
            None => self.iter.rfold(init, fold),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator> ExactSizeIterator for Peekable<I> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator> FusedIterator for Peekable<I> {}

impl<I: Iterator> Peekable<I> {
    /// Trả về một tham chiếu đến giá trị next() mà không cần tiến trình vòng lặp.
    ///
    /// Giống như [`next`], nếu có một giá trị, nó được bao bọc trong một `Some(T)`.
    /// Nhưng nếu quá trình lặp lại kết thúc, `None` sẽ được trả về.
    ///
    /// [`next`]: Iterator::next
    ///
    /// Bởi vì `peek()` trả về một tham chiếu và nhiều trình vòng lặp lặp qua các tham chiếu, có thể có một tình huống khó hiểu trong đó giá trị trả về là một tham chiếu kép.
    /// Bạn có thể thấy hiệu ứng này trong các ví dụ dưới đây.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() hãy để chúng tôi nhìn vào future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // Trình lặp không tiến ngay cả khi chúng ta `peek` nhiều lần
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Sau khi trình lặp kết thúc, `peek()` cũng vậy
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&mut self) -> Option<&I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_ref()
    }

    /// Trả về một tham chiếu có thể thay đổi đến giá trị next() mà không cần tiến trình vòng lặp.
    ///
    /// Giống như [`next`], nếu có một giá trị, nó được bao bọc trong một `Some(T)`.
    /// Nhưng nếu quá trình lặp lại kết thúc, `None` sẽ được trả về.
    ///
    /// Bởi vì `peek_mut()` trả về một tham chiếu và nhiều trình vòng lặp lặp qua các tham chiếu, có thể có một tình huống khó hiểu trong đó giá trị trả về là một tham chiếu kép.
    /// Bạn có thể thấy hiệu ứng này trong các ví dụ dưới đây.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// #![feature(peekable_peek_mut)]
    /// let mut iter = [1, 2, 3].iter().peekable();
    ///
    /// // Giống như với `peek()`, chúng ta có thể nhìn thấy future mà không cần tiến trình lặp.
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // Nhìn vào trình lặp và đặt giá trị đằng sau tham chiếu có thể thay đổi.
    /// if let Some(p) = iter.peek_mut() {
    ///     assert_eq!(*p, &2);
    ///     *p = &5;
    /// }
    ///
    /// // Giá trị chúng tôi đặt vào sẽ xuất hiện lại khi trình lặp tiếp tục.
    /// assert_eq!(iter.collect::<Vec<_>>(), vec![&5, &3]);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "peekable_peek_mut", issue = "78302")]
    pub fn peek_mut(&mut self) -> Option<&mut I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_mut()
    }

    /// Sử dụng và trả về giá trị tiếp theo của trình lặp này nếu một điều kiện là đúng.
    /// Nếu `func` trả về `true` cho giá trị tiếp theo của trình vòng lặp này, hãy tiêu thụ và trả lại giá trị đó.
    /// Nếu không, hãy trả về `None`.
    /// # Examples
    /// Sử dụng một số nếu nó bằng 0.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Mục đầu tiên của trình lặp là 0;tiêu thụ nó.
    /// assert_eq!(iter.next_if(|&x| x == 0), Some(0));
    /// // Mặt hàng tiếp theo được trả lại hiện là 1, vì vậy `consume` sẽ trả về `false`.
    /// assert_eq!(iter.next_if(|&x| x == 0), None);
    /// // `next_if` lưu giá trị của mục tiếp theo nếu nó không bằng `expected`.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    ///
    /// Sử dụng bất kỳ số nào nhỏ hơn 10.
    ///
    /// ```
    /// let mut iter = (1..20).peekable();
    /// // Sử dụng tất cả các số nhỏ hơn 10
    /// while iter.next_if(|&x| x < 10).is_some() {}
    /// // Giá trị tiếp theo được trả về sẽ là 10
    /// assert_eq!(iter.next(), Some(10));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if(&mut self, func: impl FnOnce(&I::Item) -> bool) -> Option<I::Item> {
        match self.next() {
            Some(matched) if func(&matched) => Some(matched),
            other => {
                // Kể từ khi chúng tôi gọi là `self.next()`, chúng tôi đã tiêu thụ `self.peeked`.
                assert!(self.peeked.is_none());
                self.peeked = Some(other);
                None
            }
        }
    }

    /// Tiêu thụ và trả lại mặt hàng tiếp theo nếu nó bằng `expected`.
    /// # Example
    /// Sử dụng một số nếu nó bằng 0.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Mục đầu tiên của trình lặp là 0;tiêu thụ nó.
    /// assert_eq!(iter.next_if_eq(&0), Some(0));
    /// // Mặt hàng tiếp theo được trả lại hiện là 1, vì vậy `consume` sẽ trả về `false`.
    /// assert_eq!(iter.next_if_eq(&0), None);
    /// // `next_if_eq` lưu giá trị của mục tiếp theo nếu nó không bằng `expected`.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if_eq<T>(&mut self, expected: &T) -> Option<I::Item>
    where
        T: ?Sized,
        I::Item: PartialEq<T>,
    {
        self.next_if(|next| next == expected)
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I> TrustedLen for Peekable<I> where I: TrustedLen {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S: Iterator, I: Iterator> SourceIter for Peekable<I>
where
    I: SourceIter<Source = S>,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // AN TOÀN: chuyển tiếp chức năng không an toàn đến chức năng không an toàn với cùng yêu cầu
        unsafe { SourceIter::as_inner(&mut self.iter) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I: InPlaceIterable> InPlaceIterable for Peekable<I> {}