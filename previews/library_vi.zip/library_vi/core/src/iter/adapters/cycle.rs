use crate::{iter::FusedIterator, ops::Try};

/// Một trình lặp lặp lại liên tục.
///
/// `struct` này được tạo bằng phương thức [`cycle`] trên [`Iterator`].
/// Xem tài liệu của nó để biết thêm.
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // trình lặp chu kỳ trống hoặc vô hạn
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // lặp hoàn toàn trình lặp hiện tại.
        // điều này là cần thiết vì `self.iter` có thể trống ngay cả khi `self.orig` không
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // hoàn thành một chu kỳ đầy đủ, theo dõi xem liệu trình lặp đã tuần hoàn có trống hay không.
        // chúng ta cần quay lại sớm trong trường hợp có một trình lặp trống để ngăn một vòng lặp vô hạn
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // Không ghi đè `fold`, vì `fold` không có nhiều ý nghĩa đối với `Cycle` và chúng tôi không thể làm gì tốt hơn mặc định.
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}