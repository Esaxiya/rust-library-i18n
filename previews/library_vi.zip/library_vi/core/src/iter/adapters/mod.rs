use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// trait này cung cấp khả năng truy cập bắc cầu đến giai đoạn nguồn trong một đường ống bộ chuyển đổi tương tác trong các điều kiện
/// * nguồn trình lặp `S` tự triển khai `SourceIter<Source = S>`
/// * có sự triển khai ủy quyền của trait này cho mỗi bộ điều hợp trong đường ống giữa nguồn và người tiêu dùng đường ống.
///
/// Khi nguồn là cấu trúc trình vòng lặp sở hữu (thường được gọi là `IntoIter`) thì điều này có thể hữu ích cho việc triển khai [`FromIterator`] chuyên biệt hoặc khôi phục các phần tử còn lại sau khi trình vòng lặp đã được sử dụng một phần.
///
///
/// Lưu ý rằng việc triển khai không nhất thiết phải cung cấp quyền truy cập vào nguồn bên trong nhất của một đường ống.Bộ điều hợp trung gian trạng thái có thể háo hức đánh giá một phần của đường ống và hiển thị bộ nhớ trong của nó làm nguồn.
///
/// trait không an toàn vì người triển khai phải duy trì các đặc tính an toàn bổ sung.
/// Xem [`as_inner`] để biết thêm chi tiết.
///
/// # Examples
///
/// Truy xuất nguồn đã tiêu thụ một phần:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Một giai đoạn nguồn trong một đường ống trình vòng lặp.
    type Source: Iterator;

    /// Truy xuất nguồn của đường ống trình vòng lặp.
    ///
    /// # Safety
    ///
    /// Việc triển khai của phải trả về cùng một tham chiếu có thể thay đổi cho thời gian tồn tại của chúng, trừ khi được thay thế bởi một trình gọi.
    /// Người gọi chỉ có thể thay thế tham chiếu khi họ ngừng lặp lại và bỏ đường ống trình lặp sau khi trích xuất nguồn.
    ///
    /// Điều này có nghĩa là các bộ điều hợp trình lặp có thể dựa vào nguồn không thay đổi trong quá trình lặp lại nhưng chúng không thể dựa vào nó trong các triển khai Drop của mình.
    ///
    /// Việc triển khai phương pháp này có nghĩa là bộ điều hợp từ bỏ quyền truy cập chỉ dành riêng cho nguồn của chúng và chỉ có thể dựa vào các đảm bảo được thực hiện dựa trên các loại bộ thu phương thức.
    /// Việc thiếu quyền truy cập bị hạn chế cũng yêu cầu bộ điều hợp phải duy trì API công khai của nguồn ngay cả khi họ có quyền truy cập vào nội bộ của nó.
    ///
    /// Đến lượt nó, người gọi phải mong đợi nguồn ở bất kỳ trạng thái nào phù hợp với API công khai của nó vì các bộ điều hợp nằm giữa nó và nguồn có cùng quyền truy cập.
    /// Đặc biệt, một bộ chuyển đổi có thể đã tiêu thụ nhiều phần tử hơn mức cần thiết.
    ///
    /// Mục tiêu chung của các yêu cầu này là để người tiêu dùng sử dụng đường ống
    /// * bất cứ thứ gì vẫn còn trong nguồn sau khi ngừng lặp lại
    /// * bộ nhớ đã trở nên không sử dụng bằng cách nâng cấp một trình lặp tiêu tốn
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Bộ điều hợp trình vòng lặp tạo ra đầu ra miễn là trình vòng lặp bên dưới tạo ra các giá trị `Result::Ok`.
///
///
/// Nếu gặp lỗi, trình lặp sẽ dừng và lỗi được lưu trữ.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Xử lý trình lặp đã cho như thể nó mang lại `T` thay vì `Result<T, _>`.
/// Bất kỳ lỗi nào sẽ dừng trình lặp bên trong và kết quả tổng thể sẽ là một lỗi.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}