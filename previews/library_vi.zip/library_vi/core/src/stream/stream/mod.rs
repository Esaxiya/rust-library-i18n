use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Một giao diện để xử lý các trình vòng lặp không đồng bộ.
///
/// Đây là luồng chính trait.
/// Để biết thêm về khái niệm luồng nói chung, vui lòng xem [module-level documentation].
/// Đặc biệt, bạn có thể muốn biết cách [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Loại mặt hàng do luồng mang lại.
    type Item;

    /// Cố gắng lấy ra giá trị tiếp theo của luồng này, đăng ký tác vụ hiện tại để đánh thức nếu giá trị đó chưa có sẵn và trả về `None` nếu luồng đã hết.
    ///
    /// # Giá trị trả lại
    ///
    /// Có thể có một số giá trị trả về, mỗi giá trị chỉ ra một trạng thái luồng riêng biệt:
    ///
    /// - `Poll::Pending` có nghĩa là giá trị tiếp theo của luồng này chưa sẵn sàng.Việc triển khai sẽ đảm bảo rằng tác vụ hiện tại sẽ được thông báo khi giá trị tiếp theo có thể sẵn sàng.
    ///
    /// - `Poll::Ready(Some(val))` có nghĩa là luồng đã tạo thành công một giá trị, `val` và có thể tạo ra các giá trị khác trong các lần gọi `poll_next` tiếp theo.
    ///
    /// - `Poll::Ready(None)` có nghĩa là luồng đã kết thúc và `poll_next` sẽ không được gọi lại.
    ///
    /// # Panics
    ///
    /// Khi một luồng kết thúc (trả về `Ready(None)` from `poll_next`), việc gọi lại phương thức `poll_next` của nó có thể là panic, chặn vĩnh viễn hoặc gây ra các loại sự cố khác; `Stream` trait không đặt ra yêu cầu nào đối với ảnh hưởng của lệnh gọi như vậy.
    ///
    /// Tuy nhiên, vì phương thức `poll_next` không được đánh dấu là `unsafe`, các quy tắc thông thường của Rust sẽ áp dụng: các lệnh gọi không bao giờ được gây ra hành vi không xác định (hỏng bộ nhớ, sử dụng sai các hàm `unsafe` hoặc tương tự), bất kể trạng thái của luồng.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Trả về giới hạn trên độ dài còn lại của luồng.
    ///
    /// Cụ thể, `size_hint()` trả về một bộ giá trị trong đó phần tử đầu tiên là giới hạn dưới và phần tử thứ hai là giới hạn trên.
    ///
    /// Nửa sau của tuple được trả về là một [`Option`]`<`[`usize`] `>`.
    /// [`None`] ở đây có nghĩa là không có giới hạn trên đã biết hoặc giới hạn trên lớn hơn [`usize`].
    ///
    /// # Ghi chú triển khai
    ///
    /// Việc triển khai luồng mang lại số phần tử đã khai báo không được thực thi.Một luồng lỗi có thể mang lại ít hơn giới hạn dưới hoặc nhiều hơn giới hạn trên của các phần tử.
    ///
    /// `size_hint()` chủ yếu nhằm mục đích sử dụng để tối ưu hóa, chẳng hạn như dành không gian cho các phần tử của luồng, nhưng không được tin cậy để ví dụ, bỏ qua kiểm tra giới hạn trong mã không an toàn.
    /// Việc triển khai `size_hint()` không chính xác sẽ không dẫn đến vi phạm an toàn bộ nhớ.
    ///
    /// Điều đó nói rằng, việc triển khai phải cung cấp một ước tính chính xác, bởi vì nếu không nó sẽ vi phạm giao thức của trait.
    ///
    /// Việc triển khai mặc định trả về `(0,` [`None`]`)`chính xác cho bất kỳ luồng nào.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}