//! Lặp lại không đồng bộ có thể sử dụng một lần.
//!
//! Nếu futures là các giá trị không đồng bộ, thì các luồng là các trình vòng lặp không đồng bộ.
//! Nếu bạn thấy mình có một bộ sưu tập không đồng bộ nào đó và cần thực hiện thao tác trên các phần tử của bộ sưu tập nói trên, bạn sẽ nhanh chóng chạy vào 'streams'.
//! Các luồng được sử dụng nhiều trong mã Rust không đồng bộ thành ngữ, vì vậy bạn nên làm quen với chúng.
//!
//! Trước khi giải thích thêm, hãy nói về cách mô-đun này được cấu trúc:
//!
//! # Organization
//!
//! Mô-đun này chủ yếu được tổ chức theo loại:
//!
//! * [Traits] là phần cốt lõi: traits này xác định loại luồng nào tồn tại và bạn có thể làm gì với chúng.Các phương pháp của traits này đáng để bạn bỏ thêm thời gian nghiên cứu.
//! * Các hàm cung cấp một số cách hữu ích để tạo một số luồng cơ bản.
//! * Các cấu trúc thường là kiểu trả về của các phương thức khác nhau trên traits của mô-đun này.Thông thường, bạn sẽ muốn xem xét phương pháp tạo ra `struct`, thay vì chính `struct`.
//! Để biết thêm chi tiết về lý do, hãy xem '[Luồng triển khai](#luồng thực hiện)'.
//!
//! [Traits]: #traits
//!
//! Đó là nó!Hãy đào sâu vào suối.
//!
//! # Stream
//!
//! Trái tim và linh hồn của mô-đun này là [`Stream`] trait.Lõi của [`Stream`] trông như thế này:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Không giống như `Iterator`, `Stream` phân biệt giữa phương thức [`poll_next`] được sử dụng khi triển khai `Stream` và phương thức (to-be-implemented) `next` được sử dụng khi sử dụng một luồng.
//!
//! Người tiêu dùng `Stream` chỉ cần xem xét `next`, khi được gọi, sẽ trả về future mang lại `Option<Stream::Item>`.
//!
//! future được trả về bởi `next` sẽ mang lại `Some(Item)` miễn là có các phần tử và khi tất cả chúng đã hết, sẽ mang lại `None` để cho biết rằng quá trình lặp đã kết thúc.
//! Nếu chúng ta đang đợi một thứ gì đó không đồng bộ để giải quyết, future sẽ đợi cho đến khi luồng sẵn sàng hoạt động trở lại.
//!
//! Các luồng riêng lẻ có thể chọn tiếp tục lặp lại và do đó, việc gọi lại `next` cuối cùng có thể mang lại `Some(Item)` một lần nữa vào một thời điểm nào đó.
//!
//! Định nghĩa đầy đủ của [`Stream`] cũng bao gồm một số phương thức khác, nhưng chúng là các phương thức mặc định, được xây dựng trên [`poll_next`] và vì vậy bạn nhận được chúng miễn phí.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Luồng triển khai
//!
//! Tạo một luồng của riêng bạn bao gồm hai bước: tạo `struct` để giữ trạng thái của luồng, sau đó triển khai [`Stream`] cho `struct` đó.
//!
//! Hãy tạo một luồng có tên `Counter` được tính từ `1` đến `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Đầu tiên, cấu trúc:
//!
//! /// Luồng đếm từ một đến năm
//! struct Counter {
//!     count: usize,
//! }
//!
//! // chúng tôi muốn số lượng của chúng tôi bắt đầu bằng một, vì vậy hãy thêm một phương thức new() để trợ giúp.
//! // Điều này không hoàn toàn cần thiết, nhưng rất tiện lợi.
//! // Lưu ý rằng chúng tôi bắt đầu `count` ở mức 0, chúng tôi sẽ xem lý do tại sao trong việc triển khai `poll_next()`'s bên dưới.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Sau đó, chúng tôi triển khai `Stream` cho `Counter` của chúng tôi:
//!
//! impl Stream for Counter {
//!     // chúng tôi sẽ đếm với kích thước
//!     type Item = usize;
//!
//!     // poll_next() là phương pháp bắt buộc duy nhất
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Tăng số lượng của chúng tôi.Đây là lý do tại sao chúng tôi bắt đầu từ con số không.
//!         self.count += 1;
//!
//!         // Kiểm tra xem chúng ta đã đếm xong hay chưa.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Luồng là *lười biếng*.Điều này có nghĩa là chỉ tạo một luồng không phải _do_ rất nhiều.Không có gì thực sự xảy ra cho đến khi bạn gọi `next`.
//! Đây đôi khi là một nguồn gây nhầm lẫn khi tạo một luồng chỉ vì các tác dụng phụ của nó.
//! Trình biên dịch sẽ cảnh báo chúng ta về loại hành vi này:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;