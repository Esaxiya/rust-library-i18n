//! Bản chất của trình biên dịch.
//!
//! Các định nghĩa tương ứng có trong `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Các triển khai const tương ứng trong `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Bản chất của chòm sao
//!
//! Note: bất kỳ thay đổi nào đối với tính không đổi của bản chất nên được thảo luận với nhóm ngôn ngữ.
//! Điều này bao gồm những thay đổi về tính ổn định của hằng số.
//!
//! Để làm cho nội tại có thể sử dụng được tại thời điểm biên dịch, người ta cần sao chép quá trình triển khai từ <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> sang `compiler/rustc_mir/src/interpret/intrinsics.rs` và thêm `#[rustc_const_unstable(feature = "foo", issue = "01234")]` vào nội tại.
//!
//!
//! Nếu nội tại được cho là được sử dụng từ `const fn` với thuộc tính `rustc_const_stable`, thì thuộc tính của nội tại cũng phải là `rustc_const_stable`.
//! Thay đổi như vậy không nên được thực hiện mà không có sự tư vấn của T-lang, vì nó đưa một tính năng vào ngôn ngữ không thể sao chép trong mã người dùng mà không có hỗ trợ trình biên dịch.
//!
//! # Volatiles
//!
//! Bản chất dễ bay hơi cung cấp các hoạt động nhằm mục đích hoạt động trên bộ nhớ I/O, được đảm bảo không bị trình biên dịch sắp xếp lại thứ tự qua các bản chất dễ bay hơi khác.Xem tài liệu LLVM trên [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Bản chất nguyên tử cung cấp các hoạt động nguyên tử phổ biến trên các từ máy, với nhiều tổ hợp bộ nhớ có thể có.Chúng tuân theo ngữ nghĩa giống như C++ 11.Xem tài liệu LLVM trên [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Cập nhật nhanh về thứ tự bộ nhớ:
//!
//! * Có được, một rào cản để có được một ổ khóa.Các lần đọc và ghi tiếp theo diễn ra sau hàng rào.
//! * Giải phóng, một rào cản để giải phóng ổ khóa.Việc đọc và ghi trước diễn ra trước hàng rào.
//! * Các hoạt động nhất quán tuần tự, nhất quán tuần tự được đảm bảo diễn ra theo thứ tự.Đây là chế độ tiêu chuẩn để làm việc với các loại nguyên tử và tương đương với `volatile` của Java.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Những lần nhập này được sử dụng để đơn giản hóa các liên kết trong tài liệu
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // AN TOÀN: xem `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, những bản chất này sử dụng các con trỏ thô vì chúng làm thay đổi bộ nhớ bí danh, không hợp lệ cho `&` hoặc `&mut`.
    //

    /// Lưu trữ một giá trị nếu giá trị hiện tại giống với giá trị `old`.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `compare_exchange` bằng cách chuyển [`Ordering::SeqCst`] dưới dạng cả hai tham số `success` và `failure`.
    ///
    /// Ví dụ, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lưu trữ một giá trị nếu giá trị hiện tại giống với giá trị `old`.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `compare_exchange` bằng cách chuyển [`Ordering::Acquire`] dưới dạng cả hai tham số `success` và `failure`.
    ///
    /// Ví dụ, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lưu trữ một giá trị nếu giá trị hiện tại giống với giá trị `old`.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `compare_exchange` bằng cách chuyển [`Ordering::Release`] làm tham số `success` và [`Ordering::Relaxed`] làm tham số `failure`.
    /// Ví dụ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lưu trữ một giá trị nếu giá trị hiện tại giống với giá trị `old`.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `compare_exchange` bằng cách chuyển [`Ordering::AcqRel`] làm tham số `success` và [`Ordering::Acquire`] làm tham số `failure`.
    /// Ví dụ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lưu trữ một giá trị nếu giá trị hiện tại giống với giá trị `old`.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `compare_exchange` bằng cách chuyển [`Ordering::Relaxed`] dưới dạng cả hai tham số `success` và `failure`.
    ///
    /// Ví dụ, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lưu trữ một giá trị nếu giá trị hiện tại giống với giá trị `old`.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `compare_exchange` bằng cách chuyển [`Ordering::SeqCst`] làm tham số `success` và [`Ordering::Relaxed`] làm tham số `failure`.
    /// Ví dụ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lưu trữ một giá trị nếu giá trị hiện tại giống với giá trị `old`.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `compare_exchange` bằng cách chuyển [`Ordering::SeqCst`] làm tham số `success` và [`Ordering::Acquire`] làm tham số `failure`.
    /// Ví dụ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lưu trữ một giá trị nếu giá trị hiện tại giống với giá trị `old`.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `compare_exchange` bằng cách chuyển [`Ordering::Acquire`] làm tham số `success` và [`Ordering::Relaxed`] làm tham số `failure`.
    /// Ví dụ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lưu trữ một giá trị nếu giá trị hiện tại giống với giá trị `old`.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `compare_exchange` bằng cách chuyển [`Ordering::AcqRel`] làm tham số `success` và [`Ordering::Relaxed`] làm tham số `failure`.
    /// Ví dụ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Lưu trữ một giá trị nếu giá trị hiện tại giống với giá trị `old`.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `compare_exchange_weak` bằng cách chuyển [`Ordering::SeqCst`] dưới dạng cả hai tham số `success` và `failure`.
    ///
    /// Ví dụ, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lưu trữ một giá trị nếu giá trị hiện tại giống với giá trị `old`.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `compare_exchange_weak` bằng cách chuyển [`Ordering::Acquire`] dưới dạng cả hai tham số `success` và `failure`.
    ///
    /// Ví dụ, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lưu trữ một giá trị nếu giá trị hiện tại giống với giá trị `old`.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `compare_exchange_weak` bằng cách chuyển [`Ordering::Release`] làm tham số `success` và [`Ordering::Relaxed`] làm tham số `failure`.
    /// Ví dụ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lưu trữ một giá trị nếu giá trị hiện tại giống với giá trị `old`.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `compare_exchange_weak` bằng cách chuyển [`Ordering::AcqRel`] làm tham số `success` và [`Ordering::Acquire`] làm tham số `failure`.
    /// Ví dụ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lưu trữ một giá trị nếu giá trị hiện tại giống với giá trị `old`.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `compare_exchange_weak` bằng cách chuyển [`Ordering::Relaxed`] dưới dạng cả hai tham số `success` và `failure`.
    ///
    /// Ví dụ, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lưu trữ một giá trị nếu giá trị hiện tại giống với giá trị `old`.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `compare_exchange_weak` bằng cách chuyển [`Ordering::SeqCst`] làm tham số `success` và [`Ordering::Relaxed`] làm tham số `failure`.
    /// Ví dụ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lưu trữ một giá trị nếu giá trị hiện tại giống với giá trị `old`.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `compare_exchange_weak` bằng cách chuyển [`Ordering::SeqCst`] làm tham số `success` và [`Ordering::Acquire`] làm tham số `failure`.
    /// Ví dụ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lưu trữ một giá trị nếu giá trị hiện tại giống với giá trị `old`.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `compare_exchange_weak` bằng cách chuyển [`Ordering::Acquire`] làm tham số `success` và [`Ordering::Relaxed`] làm tham số `failure`.
    /// Ví dụ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lưu trữ một giá trị nếu giá trị hiện tại giống với giá trị `old`.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `compare_exchange_weak` bằng cách chuyển [`Ordering::AcqRel`] làm tham số `success` và [`Ordering::Relaxed`] làm tham số `failure`.
    /// Ví dụ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Tải giá trị hiện tại của con trỏ.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `load` bằng cách chuyển [`Ordering::SeqCst`] làm `order`.
    /// Ví dụ, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Tải giá trị hiện tại của con trỏ.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `load` bằng cách chuyển [`Ordering::Acquire`] làm `order`.
    /// Ví dụ, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Tải giá trị hiện tại của con trỏ.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `load` bằng cách chuyển [`Ordering::Relaxed`] làm `order`.
    /// Ví dụ, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Lưu trữ giá trị tại vị trí bộ nhớ được chỉ định.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `store` bằng cách chuyển [`Ordering::SeqCst`] làm `order`.
    /// Ví dụ, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Lưu trữ giá trị tại vị trí bộ nhớ được chỉ định.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `store` bằng cách chuyển [`Ordering::Release`] làm `order`.
    /// Ví dụ, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Lưu trữ giá trị tại vị trí bộ nhớ được chỉ định.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `store` bằng cách chuyển [`Ordering::Relaxed`] làm `order`.
    /// Ví dụ, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Lưu trữ giá trị tại vị trí bộ nhớ được chỉ định, trả về giá trị cũ.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `swap` bằng cách chuyển [`Ordering::SeqCst`] làm `order`.
    /// Ví dụ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lưu trữ giá trị tại vị trí bộ nhớ được chỉ định, trả về giá trị cũ.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `swap` bằng cách chuyển [`Ordering::Acquire`] làm `order`.
    /// Ví dụ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lưu trữ giá trị tại vị trí bộ nhớ được chỉ định, trả về giá trị cũ.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `swap` bằng cách chuyển [`Ordering::Release`] làm `order`.
    /// Ví dụ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lưu trữ giá trị tại vị trí bộ nhớ được chỉ định, trả về giá trị cũ.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `swap` bằng cách chuyển [`Ordering::AcqRel`] làm `order`.
    /// Ví dụ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lưu trữ giá trị tại vị trí bộ nhớ được chỉ định, trả về giá trị cũ.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `swap` bằng cách chuyển [`Ordering::Relaxed`] làm `order`.
    /// Ví dụ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Thêm vào giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `fetch_add` bằng cách chuyển [`Ordering::SeqCst`] làm `order`.
    /// Ví dụ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Thêm vào giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `fetch_add` bằng cách chuyển [`Ordering::Acquire`] làm `order`.
    /// Ví dụ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Thêm vào giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `fetch_add` bằng cách chuyển [`Ordering::Release`] làm `order`.
    /// Ví dụ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Thêm vào giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `fetch_add` bằng cách chuyển [`Ordering::AcqRel`] làm `order`.
    /// Ví dụ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Thêm vào giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `fetch_add` bằng cách chuyển [`Ordering::Relaxed`] làm `order`.
    /// Ví dụ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Trừ giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `fetch_sub` bằng cách chuyển [`Ordering::SeqCst`] làm `order`.
    /// Ví dụ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Trừ giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `fetch_sub` bằng cách chuyển [`Ordering::Acquire`] làm `order`.
    /// Ví dụ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Trừ giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `fetch_sub` bằng cách chuyển [`Ordering::Release`] làm `order`.
    /// Ví dụ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Trừ giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `fetch_sub` bằng cách chuyển [`Ordering::AcqRel`] làm `order`.
    /// Ví dụ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Trừ giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `fetch_sub` bằng cách chuyển [`Ordering::Relaxed`] làm `order`.
    /// Ví dụ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise và với giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `fetch_and` bằng cách chuyển [`Ordering::SeqCst`] làm `order`.
    /// Ví dụ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise và với giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `fetch_and` bằng cách chuyển [`Ordering::Acquire`] làm `order`.
    /// Ví dụ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise và với giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `fetch_and` bằng cách chuyển [`Ordering::Release`] làm `order`.
    /// Ví dụ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise và với giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `fetch_and` bằng cách chuyển [`Ordering::AcqRel`] làm `order`.
    /// Ví dụ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise và với giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `fetch_and` bằng cách chuyển [`Ordering::Relaxed`] làm `order`.
    /// Ví dụ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Điều chỉnh bit với giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên loại [`AtomicBool`] thông qua phương thức `fetch_nand` bằng cách chuyển [`Ordering::SeqCst`] làm `order`.
    /// Ví dụ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Điều chỉnh bit với giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên loại [`AtomicBool`] thông qua phương thức `fetch_nand` bằng cách chuyển [`Ordering::Acquire`] làm `order`.
    /// Ví dụ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Điều chỉnh bit với giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên loại [`AtomicBool`] thông qua phương thức `fetch_nand` bằng cách chuyển [`Ordering::Release`] làm `order`.
    /// Ví dụ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Điều chỉnh bit với giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên loại [`AtomicBool`] thông qua phương thức `fetch_nand` bằng cách chuyển [`Ordering::AcqRel`] làm `order`.
    /// Ví dụ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Điều chỉnh bit với giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên loại [`AtomicBool`] thông qua phương thức `fetch_nand` bằng cách chuyển [`Ordering::Relaxed`] làm `order`.
    /// Ví dụ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise hoặc với giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `fetch_or` bằng cách chuyển [`Ordering::SeqCst`] làm `order`.
    /// Ví dụ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise hoặc với giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `fetch_or` bằng cách chuyển [`Ordering::Acquire`] làm `order`.
    /// Ví dụ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise hoặc với giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `fetch_or` bằng cách chuyển [`Ordering::Release`] làm `order`.
    /// Ví dụ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise hoặc với giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `fetch_or` bằng cách chuyển [`Ordering::AcqRel`] làm `order`.
    /// Ví dụ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise hoặc với giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `fetch_or` bằng cách chuyển [`Ordering::Relaxed`] làm `order`.
    /// Ví dụ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor với giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `fetch_xor` bằng cách chuyển [`Ordering::SeqCst`] làm `order`.
    /// Ví dụ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor với giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `fetch_xor` bằng cách chuyển [`Ordering::Acquire`] làm `order`.
    /// Ví dụ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor với giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `fetch_xor` bằng cách chuyển [`Ordering::Release`] làm `order`.
    /// Ví dụ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor với giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `fetch_xor` bằng cách chuyển [`Ordering::AcqRel`] làm `order`.
    /// Ví dụ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor với giá trị hiện tại, trả về giá trị trước đó.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các loại [`atomic`] thông qua phương thức `fetch_xor` bằng cách chuyển [`Ordering::Relaxed`] làm `order`.
    /// Ví dụ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Tối đa với giá trị hiện tại bằng cách sử dụng so sánh có chữ ký.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các kiểu số nguyên có dấu [`atomic`] thông qua phương thức `fetch_max` bằng cách chuyển [`Ordering::SeqCst`] làm `order`.
    /// Ví dụ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tối đa với giá trị hiện tại bằng cách sử dụng so sánh có chữ ký.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các kiểu số nguyên có dấu [`atomic`] thông qua phương thức `fetch_max` bằng cách chuyển [`Ordering::Acquire`] làm `order`.
    /// Ví dụ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tối đa với giá trị hiện tại bằng cách sử dụng so sánh có chữ ký.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các kiểu số nguyên có dấu [`atomic`] thông qua phương thức `fetch_max` bằng cách chuyển [`Ordering::Release`] làm `order`.
    /// Ví dụ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tối đa với giá trị hiện tại bằng cách sử dụng so sánh có chữ ký.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các kiểu số nguyên có dấu [`atomic`] thông qua phương thức `fetch_max` bằng cách chuyển [`Ordering::AcqRel`] làm `order`.
    /// Ví dụ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tối đa với giá trị hiện tại.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các kiểu số nguyên có dấu [`atomic`] thông qua phương thức `fetch_max` bằng cách chuyển [`Ordering::Relaxed`] làm `order`.
    /// Ví dụ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Tối thiểu với giá trị hiện tại bằng cách sử dụng so sánh có chữ ký.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các kiểu số nguyên có dấu [`atomic`] thông qua phương thức `fetch_min` bằng cách chuyển [`Ordering::SeqCst`] làm `order`.
    /// Ví dụ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tối thiểu với giá trị hiện tại bằng cách sử dụng so sánh có chữ ký.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các kiểu số nguyên có dấu [`atomic`] thông qua phương thức `fetch_min` bằng cách chuyển [`Ordering::Acquire`] làm `order`.
    /// Ví dụ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tối thiểu với giá trị hiện tại bằng cách sử dụng so sánh có chữ ký.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các kiểu số nguyên có dấu [`atomic`] thông qua phương thức `fetch_min` bằng cách chuyển [`Ordering::Release`] làm `order`.
    /// Ví dụ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tối thiểu với giá trị hiện tại bằng cách sử dụng so sánh có chữ ký.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các kiểu số nguyên có dấu [`atomic`] thông qua phương thức `fetch_min` bằng cách chuyển [`Ordering::AcqRel`] làm `order`.
    /// Ví dụ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tối thiểu với giá trị hiện tại bằng cách sử dụng so sánh có chữ ký.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các kiểu số nguyên có dấu [`atomic`] thông qua phương thức `fetch_min` bằng cách chuyển [`Ordering::Relaxed`] làm `order`.
    /// Ví dụ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Tối thiểu với giá trị hiện tại bằng cách sử dụng so sánh không dấu.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các kiểu số nguyên không dấu [`atomic`] thông qua phương thức `fetch_min` bằng cách chuyển [`Ordering::SeqCst`] làm `order`.
    /// Ví dụ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tối thiểu với giá trị hiện tại bằng cách sử dụng so sánh không dấu.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các kiểu số nguyên không dấu [`atomic`] thông qua phương thức `fetch_min` bằng cách chuyển [`Ordering::Acquire`] làm `order`.
    /// Ví dụ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tối thiểu với giá trị hiện tại bằng cách sử dụng so sánh không dấu.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các kiểu số nguyên không dấu [`atomic`] thông qua phương thức `fetch_min` bằng cách chuyển [`Ordering::Release`] làm `order`.
    /// Ví dụ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tối thiểu với giá trị hiện tại bằng cách sử dụng so sánh không dấu.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các kiểu số nguyên không dấu [`atomic`] thông qua phương thức `fetch_min` bằng cách chuyển [`Ordering::AcqRel`] làm `order`.
    /// Ví dụ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tối thiểu với giá trị hiện tại bằng cách sử dụng so sánh không dấu.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các kiểu số nguyên không dấu [`atomic`] thông qua phương thức `fetch_min` bằng cách chuyển [`Ordering::Relaxed`] làm `order`.
    /// Ví dụ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Tối đa với giá trị hiện tại bằng cách sử dụng so sánh không dấu.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các kiểu số nguyên không dấu [`atomic`] thông qua phương thức `fetch_max` bằng cách chuyển [`Ordering::SeqCst`] làm `order`.
    /// Ví dụ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tối đa với giá trị hiện tại bằng cách sử dụng so sánh không dấu.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các kiểu số nguyên không dấu [`atomic`] thông qua phương thức `fetch_max` bằng cách chuyển [`Ordering::Acquire`] làm `order`.
    /// Ví dụ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tối đa với giá trị hiện tại bằng cách sử dụng so sánh không dấu.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các kiểu số nguyên không dấu [`atomic`] thông qua phương thức `fetch_max` bằng cách chuyển [`Ordering::Release`] làm `order`.
    /// Ví dụ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tối đa với giá trị hiện tại bằng cách sử dụng so sánh không dấu.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các kiểu số nguyên không dấu [`atomic`] thông qua phương thức `fetch_max` bằng cách chuyển [`Ordering::AcqRel`] làm `order`.
    /// Ví dụ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tối đa với giá trị hiện tại bằng cách sử dụng so sánh không dấu.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trên các kiểu số nguyên không dấu [`atomic`] thông qua phương thức `fetch_max` bằng cách chuyển [`Ordering::Relaxed`] làm `order`.
    /// Ví dụ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Nội tại của `prefetch` là một gợi ý cho trình tạo mã để chèn một lệnh tìm nạp trước nếu được hỗ trợ;nếu không, nó là một no-op.
    /// Các tìm nạp trước không ảnh hưởng đến hoạt động của chương trình nhưng có thể thay đổi các đặc tính hoạt động của nó.
    ///
    /// Đối số `locality` phải là một số nguyên không đổi và là một mã định vị cục bộ tạm thời khác nhau, từ (0), không có cục bộ, đến (3), cực kỳ cục bộ được lưu trong bộ nhớ cache.
    ///
    ///
    /// Nội tại này không có đối chiếu ổn định.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Nội tại của `prefetch` là một gợi ý cho trình tạo mã để chèn một lệnh tìm nạp trước nếu được hỗ trợ;nếu không, nó là một no-op.
    /// Các tìm nạp trước không ảnh hưởng đến hoạt động của chương trình nhưng có thể thay đổi các đặc tính hoạt động của nó.
    ///
    /// Đối số `locality` phải là một số nguyên không đổi và là một mã định vị cục bộ tạm thời khác nhau, từ (0), không có cục bộ, đến (3), cực kỳ cục bộ được lưu trong bộ nhớ cache.
    ///
    ///
    /// Nội tại này không có đối chiếu ổn định.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Nội tại của `prefetch` là một gợi ý cho trình tạo mã để chèn một lệnh tìm nạp trước nếu được hỗ trợ;nếu không, nó là một no-op.
    /// Các tìm nạp trước không ảnh hưởng đến hoạt động của chương trình nhưng có thể thay đổi các đặc tính hoạt động của nó.
    ///
    /// Đối số `locality` phải là một số nguyên không đổi và là một mã định vị cục bộ tạm thời khác nhau, từ (0), không có cục bộ, đến (3), cực kỳ cục bộ được lưu trong bộ nhớ cache.
    ///
    ///
    /// Nội tại này không có đối chiếu ổn định.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Nội tại của `prefetch` là một gợi ý cho trình tạo mã để chèn một lệnh tìm nạp trước nếu được hỗ trợ;nếu không, nó là một no-op.
    /// Các tìm nạp trước không ảnh hưởng đến hoạt động của chương trình nhưng có thể thay đổi các đặc tính hoạt động của nó.
    ///
    /// Đối số `locality` phải là một số nguyên không đổi và là một mã định vị cục bộ tạm thời khác nhau, từ (0), không có cục bộ, đến (3), cực kỳ cục bộ được lưu trong bộ nhớ cache.
    ///
    ///
    /// Nội tại này không có đối chiếu ổn định.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Một hàng rào nguyên tử.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trong [`atomic::fence`] bằng cách chuyển [`Ordering::SeqCst`] làm `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Một hàng rào nguyên tử.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trong [`atomic::fence`] bằng cách chuyển [`Ordering::Acquire`] làm `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Một hàng rào nguyên tử.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trong [`atomic::fence`] bằng cách chuyển [`Ordering::Release`] làm `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Một hàng rào nguyên tử.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trong [`atomic::fence`] bằng cách chuyển [`Ordering::AcqRel`] làm `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Rào cản bộ nhớ chỉ dành cho trình biên dịch.
    ///
    /// Các truy cập bộ nhớ sẽ không bao giờ được trình biên dịch sắp xếp lại thứ tự vượt qua rào cản này, nhưng sẽ không có hướng dẫn nào được đưa ra cho nó.
    /// Điều này thích hợp cho các hoạt động trên cùng một luồng có thể được ưu tiên trước, chẳng hạn như khi tương tác với bộ xử lý tín hiệu.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trong [`atomic::compiler_fence`] bằng cách chuyển [`Ordering::SeqCst`] làm `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Rào cản bộ nhớ chỉ dành cho trình biên dịch.
    ///
    /// Các truy cập bộ nhớ sẽ không bao giờ được trình biên dịch sắp xếp lại thứ tự vượt qua rào cản này, nhưng sẽ không có hướng dẫn nào được đưa ra cho nó.
    /// Điều này thích hợp cho các hoạt động trên cùng một luồng có thể được ưu tiên trước, chẳng hạn như khi tương tác với bộ xử lý tín hiệu.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trong [`atomic::compiler_fence`] bằng cách chuyển [`Ordering::Acquire`] làm `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Rào cản bộ nhớ chỉ dành cho trình biên dịch.
    ///
    /// Các truy cập bộ nhớ sẽ không bao giờ được trình biên dịch sắp xếp lại thứ tự vượt qua rào cản này, nhưng sẽ không có hướng dẫn nào được đưa ra cho nó.
    /// Điều này thích hợp cho các hoạt động trên cùng một luồng có thể được ưu tiên trước, chẳng hạn như khi tương tác với bộ xử lý tín hiệu.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trong [`atomic::compiler_fence`] bằng cách chuyển [`Ordering::Release`] làm `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Rào cản bộ nhớ chỉ dành cho trình biên dịch.
    ///
    /// Các truy cập bộ nhớ sẽ không bao giờ được trình biên dịch sắp xếp lại thứ tự vượt qua rào cản này, nhưng sẽ không có hướng dẫn nào được đưa ra cho nó.
    /// Điều này thích hợp cho các hoạt động trên cùng một luồng có thể được ưu tiên trước, chẳng hạn như khi tương tác với bộ xử lý tín hiệu.
    ///
    /// Phiên bản ổn định của nội tại này có sẵn trong [`atomic::compiler_fence`] bằng cách chuyển [`Ordering::AcqRel`] làm `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Nội tại ma thuật bắt nguồn từ ý nghĩa của nó từ các thuộc tính gắn với chức năng.
    ///
    /// Ví dụ: luồng dữ liệu sử dụng điều này để đưa các xác nhận tĩnh để `rustc_peek(potentially_uninitialized)` thực sự sẽ kiểm tra lại xem luồng dữ liệu đã thực sự tính toán rằng nó chưa được khởi tạo tại thời điểm đó trong luồng điều khiển hay chưa.
    ///
    ///
    /// Nội tại này không nên được sử dụng bên ngoài trình biên dịch.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Hủy bỏ việc thực hiện quy trình.
    ///
    /// Phiên bản ổn định và thân thiện với người dùng hơn của thao tác này là [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Thông báo cho trình tối ưu hóa rằng điểm này trong mã không thể truy cập được, cho phép tối ưu hóa thêm.
    ///
    /// NB, điều này rất khác với macro `unreachable!()`: Không giống như macro mà panics khi nó được thực thi, nó là *hành vi không xác định* để đạt được mã được đánh dấu bằng hàm này.
    ///
    ///
    /// Phiên bản ổn định của nội tại này là [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Thông báo cho trình tối ưu hóa rằng một điều kiện luôn đúng.
    /// Nếu điều kiện sai, hành vi là không xác định.
    ///
    /// Không có mã nào được tạo cho nội tại này, nhưng trình tối ưu hóa sẽ cố gắng duy trì nó (và tình trạng của nó) giữa các lần vượt qua, điều này có thể cản trở việc tối ưu hóa mã xung quanh và làm giảm hiệu suất.
    /// Nó không nên được sử dụng nếu bất biến có thể được trình tối ưu hóa phát hiện ra, hoặc nếu nó không cho phép bất kỳ tối ưu hóa quan trọng nào.
    ///
    /// Nội tại này không có đối chiếu ổn định.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Gợi ý cho trình biên dịch rằng điều kiện branch có thể là đúng.
    /// Trả về giá trị được truyền cho nó.
    ///
    /// Bất kỳ cách sử dụng nào khác với các câu lệnh `if` có thể sẽ không có hiệu lực.
    ///
    /// Nội tại này không có đối chiếu ổn định.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Gợi ý cho trình biên dịch rằng điều kiện branch có thể là sai.
    /// Trả về giá trị được truyền cho nó.
    ///
    /// Bất kỳ cách sử dụng nào khác với các câu lệnh `if` có thể sẽ không có hiệu lực.
    ///
    /// Nội tại này không có đối chiếu ổn định.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Thực hiện một bẫy điểm ngắt để trình gỡ lỗi kiểm tra.
    ///
    /// Nội tại này không có đối chiếu ổn định.
    pub fn breakpoint();

    /// Kích thước của một loại tính bằng byte.
    ///
    /// Cụ thể hơn, đây là sự chênh lệch tính bằng byte giữa các mục liên tiếp cùng loại, bao gồm cả phần đệm căn chỉnh.
    ///
    ///
    /// Phiên bản ổn định của nội tại này là [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Căn chỉnh tối thiểu của một loại.
    ///
    /// Phiên bản ổn định của nội tại này là [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Căn chỉnh ưu tiên của một loại.
    ///
    /// Nội tại này không có đối chiếu ổn định.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Kích thước của giá trị được tham chiếu tính bằng byte.
    ///
    /// Phiên bản ổn định của nội tại này là [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Căn chỉnh bắt buộc của giá trị được tham chiếu.
    ///
    /// Phiên bản ổn định của nội tại này là [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Nhận một lát chuỗi tĩnh có chứa tên của một kiểu.
    ///
    /// Phiên bản ổn định của nội tại này là [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Nhận số nhận dạng là duy nhất trên toàn cầu cho loại được chỉ định.
    /// Hàm này sẽ trả về cùng một giá trị cho một kiểu bất kể nó được gọi trong crate nào.
    ///
    ///
    /// Phiên bản ổn định của nội tại này là [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Một biện pháp bảo vệ cho các chức năng không an toàn không bao giờ có thể được thực thi nếu `T` không có người ở:
    /// Điều này sẽ tĩnh panic hoặc không làm gì cả.
    ///
    /// Nội tại này không có đối chiếu ổn định.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Một biện pháp bảo vệ cho các chức năng không an toàn không bao giờ được thực thi nếu `T` không cho phép khởi tạo bằng 0: Điều này sẽ tĩnh hoặc panic hoặc không làm gì cả.
    ///
    ///
    /// Nội tại này không có đối chiếu ổn định.
    pub fn assert_zero_valid<T>();

    /// Một biện pháp bảo vệ cho các chức năng không an toàn không bao giờ được thực thi nếu `T` có các mẫu bit không hợp lệ: Điều này sẽ tĩnh hoặc panic hoặc không làm gì cả.
    ///
    ///
    /// Nội tại này không có đối chiếu ổn định.
    pub fn assert_uninit_valid<T>();

    /// Nhận tham chiếu đến `Location` tĩnh cho biết nơi nó được gọi.
    ///
    /// Thay vào đó, hãy cân nhắc sử dụng [`core::panic::Location::caller`](crate::panic::Location::caller).
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Di chuyển một giá trị ra khỏi phạm vi mà không làm rơi keo.
    ///
    /// Điều này chỉ tồn tại cho [`mem::forget_unsized`];`forget` bình thường sử dụng `ManuallyDrop` thay thế.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Diễn giải lại các bit của một giá trị thuộc kiểu này thành kiểu khác.
    ///
    /// Cả hai loại phải có cùng kích thước.
    /// Cả bản gốc hay kết quả đều không thể là [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` về mặt ngữ nghĩa tương đương với sự di chuyển theo chiều bit của một kiểu này sang kiểu khác.Nó sao chép các bit từ giá trị nguồn vào giá trị đích, sau đó quên bản gốc.
    /// Nó tương đương với `memcpy` của C, giống như `transmute_copy`.
    ///
    /// Vì `transmute` là hoạt động theo giá trị, nên việc căn chỉnh bản thân các giá trị *được chuyển đổi* không phải là vấn đề đáng lo ngại.
    /// Như với bất kỳ chức năng nào khác, trình biên dịch đã đảm bảo cả `T` và `U` đều được căn chỉnh chính xác.
    /// Tuy nhiên, khi chuyển đổi các giá trị *trỏ đến nơi khác*(chẳng hạn như con trỏ, tham chiếu, hộp…), người gọi phải đảm bảo căn chỉnh thích hợp của các giá trị trỏ đến.
    ///
    /// `transmute` là **vô cùng** không an toàn.Có rất nhiều cách để gây ra [undefined behavior][ub] với chức năng này.`transmute` nên là giải pháp cuối cùng tuyệt đối.
    ///
    /// [nomicon](../../nomicon/transmutes.html) có tài liệu bổ sung.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Có một số điều mà `transmute` thực sự hữu ích.
    ///
    /// Biến một con trỏ thành một con trỏ hàm.Điều này *không* di động đối với các máy mà con trỏ hàm và con trỏ dữ liệu có kích thước khác nhau.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Kéo dài thời gian tồn tại hoặc rút ngắn thời gian tồn tại bất biến.Đây là Rust tiên tiến, rất không an toàn!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Đừng thất vọng: nhiều công dụng của `transmute` có thể đạt được thông qua các phương tiện khác.
    /// Dưới đây là các ứng dụng phổ biến của `transmute` có thể được thay thế bằng các cấu trúc an toàn hơn.
    ///
    /// Chuyển bytes(`&[u8]`) thô thành `u32`, `f64`, v.v.:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // sử dụng `u32::from_ne_bytes` thay thế
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // hoặc sử dụng `u32::from_le_bytes` hoặc `u32::from_be_bytes` để chỉ định giá trị cuối cùng
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Biến một con trỏ thành `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Sử dụng diễn viên `as` thay thế
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Biến `*mut T` thành `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Sử dụng khoản vay lại thay thế
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Biến `&mut T` thành `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Bây giờ, hãy gộp `as` và vay lại, lưu ý rằng chuỗi `as` `as` không có tính bắc cầu
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Biến `&str` thành `&[u8]`:
    ///
    /// ```
    /// // đây không phải là một cách tốt để làm điều này.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Bạn có thể sử dụng `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Hoặc, chỉ cần sử dụng một chuỗi byte, nếu bạn có quyền kiểm soát chuỗi ký tự
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Biến `Vec<&T>` thành `Vec<Option<&T>>`.
    ///
    /// Để chuyển đổi loại bên trong của nội dung của thùng chứa, bạn phải đảm bảo không vi phạm bất kỳ biến nào của thùng chứa.
    /// Đối với `Vec`, điều này có nghĩa là cả kích thước *và căn chỉnh* của các loại bên trong phải phù hợp.
    /// Các vùng chứa khác có thể phụ thuộc vào kích thước của loại, sự liên kết hoặc thậm chí là `TypeId`, trong trường hợp đó, việc chuyển đổi sẽ không thể thực hiện được nếu không vi phạm các bất biến của vùng chứa.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // sao chép vector vì chúng tôi sẽ sử dụng lại chúng sau này
    /// let v_clone = v_orig.clone();
    ///
    /// // Sử dụng chuyển đổi: điều này dựa vào bố cục dữ liệu không xác định của `Vec`, đây là một ý tưởng tồi và có thể gây ra Hành vi không xác định.
    /////
    /// // Tuy nhiên, nó không phải là bản sao.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Đây là cách được đề xuất, an toàn.
    /// // Tuy nhiên, nó sao chép toàn bộ vector vào một mảng mới.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Đây là cách thích hợp không sao chép, không an toàn của "transmuting" a `Vec` mà không cần dựa vào bố cục dữ liệu.
    /// // Thay vì gọi `transmute` theo nghĩa đen, chúng tôi thực hiện ép kiểu con trỏ, nhưng về mặt chuyển đổi kiểu bên trong ban đầu (`&i32`) thành kiểu mới (`Option<&i32>`), điều này có tất cả các cảnh báo tương tự.
    /////
    /// // Bên cạnh thông tin được cung cấp ở trên, cũng tham khảo tài liệu [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Cập nhật điều này khi vec_into_raw_parts được ổn định.
    ///     // Đảm bảo vector gốc không bị rơi.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Triển khai `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Có nhiều cách để thực hiện việc này và có nhiều vấn đề với cách (transmute) sau đây.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // thứ nhất: transmute không phải là loại an toàn;tất cả những gì nó kiểm tra là T và
    ///         // U có cùng kích thước.
    ///         // Thứ hai, ngay tại đây, bạn có hai tham chiếu có thể thay đổi trỏ đến cùng một bộ nhớ.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Điều này giúp loại bỏ các vấn đề về an toàn kiểu;`&mut *` sẽ* chỉ *cung cấp cho bạn `&mut T` từ `&mut T` hoặc `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // tuy nhiên, bạn vẫn có hai tham chiếu có thể thay đổi trỏ đến cùng một bộ nhớ.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Đây là cách mà thư viện tiêu chuẩn thực hiện.
    /// // Đây là phương pháp tốt nhất, nếu bạn cần làm điều gì đó như thế này
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Điều này hiện có ba tham chiếu có thể thay đổi trỏ đến cùng một bộ nhớ.`slice`, rvalue ret.0 và rvalue ret.1.
    ///         // `slice` không bao giờ được sử dụng sau `let ptr = ...` và vì vậy người ta có thể coi nó là "dead", và do đó, bạn chỉ có hai lát cắt có thể thay đổi thực sự.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Trong khi điều này làm cho const nội tại ổn định, chúng tôi có một số mã tùy chỉnh trong const fn
    // kiểm tra ngăn chặn việc sử dụng nó trong `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Trả về `true` nếu loại thực tế được cung cấp là `T` yêu cầu keo rơi;trả về `false` nếu kiểu thực tế được cung cấp cho `T` triển khai `Copy`.
    ///
    ///
    /// Nếu loại thực tế không yêu cầu giọt keo cũng không thực hiện `Copy`, thì giá trị trả về của hàm này là không xác định.
    ///
    /// Phiên bản ổn định của nội tại này là [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Tính toán độ lệch từ một con trỏ.
    ///
    /// Điều này được thực hiện như một nội tại để tránh chuyển đổi sang và từ một số nguyên, vì quá trình chuyển đổi sẽ loại bỏ thông tin răng cưa.
    ///
    /// # Safety
    ///
    /// Cả con trỏ bắt đầu và con trỏ kết quả phải nằm trong giới hạn hoặc một byte sau phần cuối của một đối tượng được cấp phát.
    /// Nếu một trong hai con trỏ nằm ngoài giới hạn hoặc xảy ra tràn số học thì việc sử dụng thêm giá trị trả về sẽ dẫn đến hành vi không xác định.
    ///
    ///
    /// Phiên bản ổn định của nội tại này là [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Tính toán độ lệch từ một con trỏ, có khả năng bao bọc.
    ///
    /// Điều này được thực hiện như một nội tại để tránh chuyển đổi sang và từ một số nguyên, vì việc chuyển đổi hạn chế các tối ưu hóa nhất định.
    ///
    /// # Safety
    ///
    /// Không giống như nội tại `offset`, nội tại này không hạn chế con trỏ kết quả trỏ vào hoặc một byte qua phần cuối của đối tượng được cấp phát và nó kết thúc bằng số học bổ sung của hai.
    /// Giá trị kết quả không nhất thiết phải hợp lệ để được sử dụng để thực sự truy cập bộ nhớ.
    ///
    /// Phiên bản ổn định của nội tại này là [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Tương đương với nội tại `llvm.memcpy.p0i8.0i8.*` thích hợp, với kích thước `count`*`size_of::<T>()` và căn chỉnh của
    ///
    /// `min_align_of::<T>()`
    ///
    /// Tham số biến động được đặt thành `true`, vì vậy nó sẽ không được tối ưu hóa trừ khi kích thước bằng không.
    ///
    /// Nội tại này không có đối chiếu ổn định.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Tương đương với nội tại `llvm.memmove.p0i8.0i8.*` thích hợp, với kích thước `count* size_of::<T>()` và căn chỉnh của
    ///
    /// `min_align_of::<T>()`
    ///
    /// Tham số biến động được đặt thành `true`, vì vậy nó sẽ không được tối ưu hóa trừ khi kích thước bằng không.
    ///
    /// Nội tại này không có đối chiếu ổn định.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Tương đương với nội tại `llvm.memset.p0i8.*` thích hợp, với kích thước `count* size_of::<T>()` và căn chỉnh `min_align_of::<T>()`.
    ///
    ///
    /// Tham số biến động được đặt thành `true`, vì vậy nó sẽ không được tối ưu hóa trừ khi kích thước bằng không.
    ///
    /// Nội tại này không có đối chiếu ổn định.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Thực hiện tải không ổn định từ con trỏ `src`.
    ///
    /// Phiên bản ổn định của nội tại này là [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Thực hiện lưu trữ biến động cho con trỏ `dst`.
    ///
    /// Phiên bản ổn định của nội tại này là [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Thực hiện tải không ổn định từ con trỏ `src` Con trỏ không bắt buộc phải được căn chỉnh.
    ///
    ///
    /// Nội tại này không có đối chiếu ổn định.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Thực hiện lưu trữ biến động cho con trỏ `dst`.
    /// Con trỏ không bắt buộc phải được căn chỉnh.
    ///
    /// Nội tại này không có đối chiếu ổn định.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Trả về căn bậc hai của `f32`
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Trả về căn bậc hai của `f64`
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Tăng `f32` thành lũy thừa.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Tăng `f64` thành lũy thừa.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Trả về sin của `f32`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Trả về sin của `f64`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Trả về cosin của `f32`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Trả về cosin của `f64`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Tăng sức mạnh `f32` lên `f32`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Tăng sức mạnh `f64` lên `f64`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Trả về cấp số nhân của `f32`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Trả về cấp số nhân của `f64`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Trả về 2 được nâng lên thành sức mạnh của `f32`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Trả về 2 được nâng lên thành sức mạnh của `f64`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Trả về lôgarit tự nhiên của `f32`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Trả về lôgarit tự nhiên của `f64`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Trả về lôgarit cơ số 10 của `f32`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Trả về lôgarit cơ số 10 của `f64`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Trả về logarit cơ số 2 của `f32`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Trả về logarit cơ số 2 của `f64`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Trả về `a * b + c` cho các giá trị `f32`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Trả về `a * b + c` cho các giá trị `f64`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Trả về giá trị tuyệt đối của một `f32`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Trả về giá trị tuyệt đối của một `f64`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Trả về giá trị nhỏ nhất của hai giá trị `f32`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Trả về giá trị nhỏ nhất của hai giá trị `f64`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Trả về tối đa hai giá trị `f32`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Trả về tối đa hai giá trị `f64`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Sao chép ký hiệu từ `y` sang `x` cho các giá trị `f32`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Sao chép ký hiệu từ `y` sang `x` cho các giá trị `f64`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Trả về số nguyên lớn nhất nhỏ hơn hoặc bằng `f32`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Trả về số nguyên lớn nhất nhỏ hơn hoặc bằng `f64`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Trả về số nguyên nhỏ nhất lớn hơn hoặc bằng `f32`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Trả về số nguyên nhỏ nhất lớn hơn hoặc bằng `f64`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Trả về phần nguyên của `f32`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Trả về phần nguyên của `f64`.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Trả về số nguyên gần nhất cho một `f32`.
    /// Có thể đưa ra một ngoại lệ dấu phẩy động không chính xác nếu đối số không phải là số nguyên.
    pub fn rintf32(x: f32) -> f32;
    /// Trả về số nguyên gần nhất cho một `f64`.
    /// Có thể đưa ra một ngoại lệ dấu phẩy động không chính xác nếu đối số không phải là số nguyên.
    pub fn rintf64(x: f64) -> f64;

    /// Trả về số nguyên gần nhất cho một `f32`.
    ///
    /// Nội tại này không có đối chiếu ổn định.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Trả về số nguyên gần nhất cho một `f64`.
    ///
    /// Nội tại này không có đối chiếu ổn định.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Trả về số nguyên gần nhất cho một `f32`.Làm tròn nửa trường hợp đi từ 0.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Trả về số nguyên gần nhất cho một `f64`.Làm tròn nửa trường hợp đi từ 0.
    ///
    /// Phiên bản ổn định của nội tại này là
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Bổ sung phao cho phép tối ưu hóa dựa trên các quy tắc đại số.
    /// Có thể giả sử đầu vào là hữu hạn.
    ///
    /// Nội tại này không có đối chiếu ổn định.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Phép trừ nổi cho phép tối ưu hóa dựa trên các quy tắc đại số.
    /// Có thể giả sử đầu vào là hữu hạn.
    ///
    /// Nội tại này không có đối chiếu ổn định.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Phép nhân nổi cho phép tối ưu hóa dựa trên các quy tắc đại số.
    /// Có thể giả sử đầu vào là hữu hạn.
    ///
    /// Nội tại này không có đối chiếu ổn định.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Phân chia nổi cho phép tối ưu hóa dựa trên các quy tắc đại số.
    /// Có thể giả sử đầu vào là hữu hạn.
    ///
    /// Nội tại này không có đối chiếu ổn định.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Phần dư nổi cho phép tối ưu hóa dựa trên các quy tắc đại số.
    /// Có thể giả sử đầu vào là hữu hạn.
    ///
    /// Nội tại này không có đối chiếu ổn định.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Chuyển đổi với fptoui/fptosi của LLVM, có thể trả về undef cho các giá trị nằm ngoài phạm vi
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Ổn định như [`f32::to_int_unchecked`] và [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Trả về số bit được đặt trong kiểu số nguyên `T`
    ///
    /// Các phiên bản ổn định của nội tại này có sẵn trên các số nguyên gốc thông qua phương pháp `count_ones`.
    /// Ví dụ,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Trả về số bit chưa đặt hàng đầu (zeroes) trong kiểu số nguyên `T`.
    ///
    /// Các phiên bản ổn định của nội tại này có sẵn trên các số nguyên gốc thông qua phương pháp `leading_zeros`.
    /// Ví dụ,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `x` với giá trị `0` sẽ trả về độ rộng bit của `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Giống như `ctlz`, nhưng cực kỳ không an toàn vì nó trả về `undef` khi được cung cấp `x` với giá trị `0`.
    ///
    ///
    /// Nội tại này không có đối chiếu ổn định.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Trả về số bit chưa đặt ở cuối (zeroes) trong kiểu số nguyên `T`.
    ///
    /// Các phiên bản ổn định của nội tại này có sẵn trên các số nguyên gốc thông qua phương pháp `trailing_zeros`.
    /// Ví dụ,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `x` với giá trị `0` sẽ trả về độ rộng bit của `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Giống như `cttz`, nhưng cực kỳ không an toàn vì nó trả về `undef` khi được cung cấp `x` với giá trị `0`.
    ///
    ///
    /// Nội tại này không có đối chiếu ổn định.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Đảo ngược các byte trong một kiểu số nguyên `T`.
    ///
    /// Các phiên bản ổn định của nội tại này có sẵn trên các số nguyên gốc thông qua phương pháp `swap_bytes`.
    /// Ví dụ,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Đảo ngược các bit trong kiểu số nguyên `T`.
    ///
    /// Các phiên bản ổn định của nội tại này có sẵn trên các số nguyên gốc thông qua phương pháp `reverse_bits`.
    /// Ví dụ,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Thực hiện phép cộng số nguyên đã kiểm tra.
    ///
    /// Các phiên bản ổn định của nội tại này có sẵn trên các số nguyên gốc thông qua phương pháp `overflowing_add`.
    /// Ví dụ,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Thực hiện phép trừ số nguyên đã kiểm tra
    ///
    /// Các phiên bản ổn định của nội tại này có sẵn trên các số nguyên gốc thông qua phương pháp `overflowing_sub`.
    /// Ví dụ,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Thực hiện phép nhân số nguyên đã kiểm tra
    ///
    /// Các phiên bản ổn định của nội tại này có sẵn trên các số nguyên gốc thông qua phương pháp `overflowing_mul`.
    /// Ví dụ,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Thực hiện phân chia chính xác, dẫn đến hành vi không xác định trong đó `x % y != 0` hoặc `y == 0` hoặc `x == T::MIN && y == -1`
    ///
    ///
    /// Nội tại này không có đối chiếu ổn định.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Thực hiện phân chia không được kiểm tra, dẫn đến hành vi không xác định trong đó `y == 0` hoặc `x == T::MIN && y == -1`
    ///
    ///
    /// Các trình bao bọc an toàn cho nội tại này có sẵn trên các nguyên thủy số nguyên thông qua phương thức `checked_div`.
    /// Ví dụ,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Trả về phần còn lại của phép chia chưa được kiểm tra, dẫn đến hành vi không xác định khi `y == 0` hoặc `x == T::MIN && y == -1`
    ///
    ///
    /// Các trình bao bọc an toàn cho nội tại này có sẵn trên các nguyên thủy số nguyên thông qua phương thức `checked_rem`.
    /// Ví dụ,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Thực hiện dịch chuyển trái không được kiểm tra, dẫn đến hành vi không xác định khi `y < 0` hoặc `y >= N`, trong đó N là độ rộng của T tính bằng bit.
    ///
    ///
    /// Các trình bao bọc an toàn cho nội tại này có sẵn trên các nguyên thủy số nguyên thông qua phương thức `checked_shl`.
    /// Ví dụ,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Thực hiện dịch chuyển sang phải không được kiểm tra, dẫn đến hành vi không xác định khi `y < 0` hoặc `y >= N`, trong đó N là độ rộng của T tính bằng bit.
    ///
    ///
    /// Các trình bao bọc an toàn cho nội tại này có sẵn trên các nguyên thủy số nguyên thông qua phương thức `checked_shr`.
    /// Ví dụ,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Trả về kết quả của một phép cộng chưa được kiểm tra, dẫn đến hành vi không xác định khi `x + y > T::MAX` hoặc `x + y < T::MIN`.
    ///
    ///
    /// Nội tại này không có đối chiếu ổn định.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Trả về kết quả của một phép trừ chưa được kiểm tra, dẫn đến hành vi không xác định khi `x - y > T::MAX` hoặc `x - y < T::MIN`.
    ///
    ///
    /// Nội tại này không có đối chiếu ổn định.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Trả về kết quả của một phép nhân chưa được kiểm tra, dẫn đến hành vi không xác định khi `x *y > T::MAX` hoặc `x* y < T::MIN`.
    ///
    ///
    /// Nội tại này không có đối chiếu ổn định.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Thực hiện xoay sang trái.
    ///
    /// Các phiên bản ổn định của nội tại này có sẵn trên các số nguyên gốc thông qua phương pháp `rotate_left`.
    /// Ví dụ,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Thực hiện xoay sang phải.
    ///
    /// Các phiên bản ổn định của nội tại này có sẵn trên các số nguyên gốc thông qua phương pháp `rotate_right`.
    /// Ví dụ,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Trả về (a + b) mod 2 <sup>N</sup>, trong đó N là độ rộng của T tính bằng bit.
    ///
    /// Các phiên bản ổn định của nội tại này có sẵn trên các số nguyên gốc thông qua phương pháp `wrapping_add`.
    /// Ví dụ,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Trả về (a, b) mod 2 <sup>N</sup>, trong đó N là độ rộng của T tính bằng bit.
    ///
    /// Các phiên bản ổn định của nội tại này có sẵn trên các số nguyên gốc thông qua phương pháp `wrapping_sub`.
    /// Ví dụ,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Trả về (a * b) mod 2 <sup>N</sup>, trong đó N là độ rộng của T tính bằng bit.
    ///
    /// Các phiên bản ổn định của nội tại này có sẵn trên các số nguyên gốc thông qua phương pháp `wrapping_mul`.
    /// Ví dụ,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Tính toán `a + b`, bão hòa ở giới hạn số.
    ///
    /// Các phiên bản ổn định của nội tại này có sẵn trên các số nguyên gốc thông qua phương pháp `saturating_add`.
    /// Ví dụ,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Tính toán `a - b`, bão hòa ở giới hạn số.
    ///
    /// Các phiên bản ổn định của nội tại này có sẵn trên các số nguyên gốc thông qua phương pháp `saturating_sub`.
    /// Ví dụ,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Trả về giá trị của giá trị phân biệt cho biến thể trong 'v';
    /// nếu `T` không có phân biệt, trả về `0`.
    ///
    /// Phiên bản ổn định của nội tại này là [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Trả về số biến thể của kiểu `T` được truyền thành `usize`;
    /// nếu `T` không có biến thể, trả về `0`.Các biến thể không có người ở sẽ được tính.
    ///
    /// Phiên bản ổn định của nội tại này là [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Cấu trúc "try catch" của Rust gọi con trỏ hàm `try_fn` với con trỏ dữ liệu `data`.
    ///
    /// Đối số thứ ba là một hàm được gọi nếu panic xảy ra.
    /// Hàm này nhận con trỏ dữ liệu và một con trỏ đến đối tượng ngoại lệ dành riêng cho mục tiêu cụ thể đã bị bắt.
    ///
    /// Để biết thêm thông tin, hãy xem nguồn của trình biên dịch cũng như cách triển khai bắt của std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Phát ra một cửa hàng `!nontemporal` theo LLVM (xem tài liệu của họ).
    /// Có lẽ sẽ không bao giờ trở nên ổn định.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Xem tài liệu của `<*const T>::offset_from` để biết thêm chi tiết.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Xem tài liệu của `<*const T>::guaranteed_eq` để biết thêm chi tiết.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Xem tài liệu của `<*const T>::guaranteed_ne` để biết thêm chi tiết.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Phân bổ tại thời điểm biên dịch.Không nên được gọi trong thời gian chạy.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Một số chức năng được định nghĩa ở đây bởi vì chúng vô tình được cung cấp trong mô-đun này ở trạng thái ổn định.
// Xem <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` cũng thuộc loại này, nhưng nó không thể được bọc do kiểm tra rằng `T` và `U` có cùng kích thước.)
//

/// Kiểm tra xem `ptr` có được căn chỉnh chính xác so với `align_of::<T>()` hay không.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Sao chép các byte `count *size_of::<T>()` từ `src` sang `dst`.Nguồn và đích phải* không * trùng nhau.
///
/// Đối với các vùng bộ nhớ có thể chồng chéo lên nhau, hãy sử dụng [`copy`] để thay thế.
///
/// `copy_nonoverlapping` tương đương về mặt ngữ nghĩa với [`memcpy`] của C, nhưng với thứ tự đối số được hoán đổi.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Hành vi là không xác định nếu bất kỳ điều kiện nào sau đây bị vi phạm:
///
/// * `src` phải là [valid] cho các lần đọc `count * size_of::<T>()` byte.
///
/// * `dst` phải là [valid] để ghi các byte `count * size_of::<T>()`.
///
/// * Cả `src` và `dst` đều phải được căn chỉnh chính xác.
///
/// * Vùng bộ nhớ bắt đầu từ `src` với kích thước là `số lượng *
///   size_of: :<T>() `byte phải *không* trùng lặp với vùng bộ nhớ bắt đầu từ `dst` có cùng kích thước.
///
/// Giống như [`read`], `copy_nonoverlapping` tạo ra một bản sao bit của `T`, bất kể `T` có phải là [`Copy`] hay không.
/// Nếu `T` không phải là [`Copy`], việc sử dụng *cả hai* các giá trị trong vùng bắt đầu từ `*src` và vùng bắt đầu từ `* dst` có thể [violate memory safety][read-ownership].
///
///
/// Lưu ý rằng ngay cả khi kích thước được sao chép hiệu quả (`count * size_of: :<T>()`) là `0`, các con trỏ phải không phải là NULL và được căn chỉnh đúng cách.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Triển khai thủ công [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Di chuyển tất cả các phần tử của `src` vào `dst`, để trống `src`.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Đảm bảo rằng `dst` có đủ dung lượng để chứa tất cả `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Lời gọi bù đắp luôn an toàn vì `Vec` sẽ không bao giờ phân bổ nhiều hơn `isize::MAX` byte.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Cắt `src` mà không làm rơi nội dung của nó.
///         // Chúng tôi thực hiện việc này trước tiên, để tránh các vấn đề trong trường hợp có điều gì đó tiếp tục xảy ra với panics.
///         src.set_len(0);
///
///         // Hai vùng không thể trùng lặp vì các tham chiếu có thể thay đổi không phải là bí danh và hai vectors khác nhau không thể sở hữu cùng một bộ nhớ.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Thông báo cho `dst` rằng nó hiện giữ nội dung của `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Chỉ thực hiện các kiểm tra này tại thời gian chạy
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Không hoảng sợ để giữ cho tác động của codegen nhỏ hơn.
        abort();
    }*/

    // AN TOÀN: hợp đồng an toàn cho `copy_nonoverlapping` phải
    // được người gọi ủng hộ.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Sao chép các byte `count * size_of::<T>()` từ `src` sang `dst`.Nguồn và đích có thể trùng nhau.
///
/// Nếu nguồn và đích *không bao giờ* trùng nhau, thì [`copy_nonoverlapping`] có thể được sử dụng để thay thế.
///
/// `copy` tương đương về mặt ngữ nghĩa với [`memmove`] của C, nhưng với thứ tự đối số được hoán đổi.
/// Việc sao chép diễn ra như thể các byte được sao chép từ `src` sang một mảng tạm thời và sau đó được sao chép từ mảng sang `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Hành vi là không xác định nếu bất kỳ điều kiện nào sau đây bị vi phạm:
///
/// * `src` phải là [valid] cho các lần đọc `count * size_of::<T>()` byte.
///
/// * `dst` phải là [valid] để ghi các byte `count * size_of::<T>()`.
///
/// * Cả `src` và `dst` đều phải được căn chỉnh chính xác.
///
/// Giống như [`read`], `copy` tạo ra một bản sao bit của `T`, bất kể `T` có phải là [`Copy`] hay không.
/// Nếu `T` không phải là [`Copy`], việc sử dụng cả hai giá trị trong vùng bắt đầu từ `*src` và vùng bắt đầu từ `* dst` có thể [violate memory safety][read-ownership].
///
///
/// Lưu ý rằng ngay cả khi kích thước được sao chép hiệu quả (`count * size_of: :<T>()`) là `0`, các con trỏ phải không phải là NULL và được căn chỉnh đúng cách.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Tạo hiệu quả Rust vector từ bộ đệm không an toàn:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` phải được căn chỉnh chính xác cho loại của nó và khác không.
/// /// * `ptr` phải hợp lệ để đọc các phần tử liền kề `elts` của kiểu `T`.
/// /// * Các phần tử đó không được sử dụng sau khi gọi hàm này trừ khi `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // AN TOÀN: Điều kiện tiên quyết của chúng tôi đảm bảo nguồn được căn chỉnh và hợp lệ,
///     // và `Vec::with_capacity` đảm bảo rằng chúng ta có không gian sử dụng được để viết chúng.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // AN TOÀN: Chúng tôi đã tạo ra nó với dung lượng lớn như vậy trước đó,
///     // và `copy` trước đó đã khởi tạo các phần tử này.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Chỉ thực hiện các kiểm tra này tại thời gian chạy
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Không hoảng sợ để giữ cho tác động của codegen nhỏ hơn.
        abort();
    }*/

    // AN TOÀN: hợp đồng an toàn cho `copy` phải được người gọi tuân thủ.
    unsafe { copy(src, dst, count) }
}

/// Đặt `count * size_of::<T>()` byte bộ nhớ bắt đầu từ `dst` thành `val`.
///
/// `write_bytes` tương tự như [`memset`] của C, nhưng đặt các byte `count * size_of::<T>()` thành `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Hành vi là không xác định nếu bất kỳ điều kiện nào sau đây bị vi phạm:
///
/// * `dst` phải là [valid] để ghi các byte `count * size_of::<T>()`.
///
/// * `dst` phải được căn chỉnh phù hợp.
///
/// Ngoài ra, người gọi phải đảm bảo rằng việc ghi các byte `count * size_of::<T>()` vào vùng bộ nhớ đã cho dẫn đến giá trị hợp lệ là `T`.
/// Sử dụng vùng bộ nhớ được nhập là `T` có chứa giá trị không hợp lệ của `T` là hành vi không xác định.
///
/// Lưu ý rằng ngay cả khi kích thước được sao chép hiệu quả (`count * size_of: :<T>()`) là `0`, con trỏ phải không NULL và được căn chỉnh đúng cách.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Cách sử dụng cơ bản:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Tạo giá trị không hợp lệ:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Làm rò rỉ giá trị đã giữ trước đó bằng cách ghi đè lên `Box<T>` bằng con trỏ null.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Tại thời điểm này, việc sử dụng hoặc thả `v` dẫn đến hành vi không xác định.
/// // drop(v); // ERROR
///
/// // Thậm chí làm rò rỉ `v` "uses" nó, và do đó là hành vi không xác định.
/// // mem::forget(v); // ERROR
///
/// // Trên thực tế, `v` không hợp lệ theo bất biến bố cục kiểu cơ bản, vì vậy *bất kỳ* thao tác nào chạm vào nó là hành vi không xác định.
/////
/// // cho v2 =v;//LỖI
///
/// unsafe {
///     // Thay vào đó, hãy để chúng tôi đưa vào một giá trị hợp lệ
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Bây giờ hộp là tốt
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // AN TOÀN: hợp đồng an toàn cho `write_bytes` phải được người gọi tuân thủ.
    unsafe { write_bytes(dst, val, count) }
}