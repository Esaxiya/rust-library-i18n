//! Hỗ trợ Panic trong thư viện tiêu chuẩn.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// Một cấu trúc cung cấp thông tin về panic.
///
/// `PanicInfo` cấu trúc được chuyển tới panic hook được thiết lập bởi hàm [`set_hook`].
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// Trả về tải trọng được liên kết với panic.
    ///
    /// Điều này thường, nhưng không phải luôn luôn, là `&'static str` hoặc [`String`].
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// Nếu macro `panic!` từ `core` crate (không phải từ `std`) được sử dụng với một chuỗi định dạng và một số đối số bổ sung, trả về thông báo đó sẵn sàng được sử dụng, chẳng hạn như với [`fmt::write`]
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// Trả về thông tin về vị trí mà panic xuất phát, nếu có.
    ///
    /// Phương thức này hiện sẽ luôn trả về [`Some`], nhưng điều này có thể thay đổi trong các phiên bản future.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: Nếu điều này được thay đổi thành đôi khi trả về Không có,
        // giải quyết trường hợp đó trong std::panicking::default_hook và std::panicking::begin_panic_fmt.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: chúng tôi không thể sử dụng downcast_ref: :<String>() đây
        // vì Chuỗi không có sẵn trong libcore!
        // Tải trọng là một Chuỗi khi `std::panic!` được gọi với nhiều đối số, nhưng trong trường hợp đó, thông báo cũng có sẵn.
        //

        self.location.fmt(formatter)
    }
}

/// Một cấu trúc chứa thông tin về vị trí của panic.
///
/// Cấu trúc này được tạo ra bởi [`PanicInfo::location()`].
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// Các so sánh về sự bình đẳng và thứ tự được thực hiện trong mức độ ưu tiên của tệp, dòng, sau đó là cột.
/// Các tệp được so sánh dưới dạng chuỗi, không phải `Path`, điều này có thể gây bất ngờ.
/// Xem tài liệu của [`Location: : file`] để thảo luận thêm.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// Trả về vị trí nguồn của trình gọi hàm này.
    /// Nếu trình gọi của hàm đó được chú thích thì vị trí cuộc gọi của nó sẽ được trả lại, và cứ thế tiếp tục chồng lên lệnh gọi đầu tiên trong thân hàm không được theo dõi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// Trả về [`Location`] mà nó được gọi.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// Trả về [`Location`] từ bên trong định nghĩa của hàm này.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // chạy cùng một chức năng không được theo dõi ở một vị trí khác cho chúng ta cùng một kết quả
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // chạy chức năng được theo dõi ở một vị trí khác sẽ tạo ra một giá trị khác
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// Trả về tên của tệp nguồn mà panic bắt nguồn từ đó.
    ///
    /// # `&str`, không phải `&Path`
    ///
    /// Tên được trả về đề cập đến một đường dẫn nguồn trên hệ thống biên dịch, nhưng nó không hợp lệ để biểu thị điều này trực tiếp dưới dạng `&Path`.
    /// Mã đã biên dịch có thể chạy trên một hệ thống khác với cách triển khai `Path` khác với hệ thống cung cấp nội dung và thư viện này hiện không có kiểu "host path" khác.
    ///
    /// Hành vi đáng ngạc nhiên nhất xảy ra khi tệp "the same" có thể truy cập được thông qua nhiều đường dẫn trong hệ thống mô-đun (thường sử dụng thuộc tính `#[path = "..."]` hoặc tương tự), điều này có thể khiến những gì có vẻ là mã giống hệt nhau trả về các giá trị khác với chức năng này.
    ///
    ///
    /// # Cross-compilation
    ///
    /// Giá trị này không phù hợp để chuyển tới `Path::new` hoặc các trình tạo tương tự khi nền tảng máy chủ và nền tảng đích khác nhau.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// Trả về số dòng mà panic bắt nguồn từ đó.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// Trả về cột mà panic bắt nguồn từ đó.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// Một trait nội bộ được libstd sử dụng để truyền dữ liệu từ libstd sang `panic_unwind` và các thời gian chạy panic khác.
/// Không có ý định được ổn định sớm, không sử dụng.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// Có toàn quyền sở hữu các nội dung.
    /// Kiểu trả về thực sự là `Box<dyn Any + Send>`, nhưng chúng ta không thể sử dụng `Box` trong libcore.
    ///
    /// Sau khi phương thức này được gọi, chỉ còn lại một số giá trị mặc định giả trong `self`.
    /// Việc gọi phương thức này hai lần hoặc gọi `get` sau khi gọi phương thức này là một lỗi.
    ///
    /// Đối số được mượn vì panic thời gian chạy (`__rust_start_panic`) chỉ nhận được một `dyn BoxMeUp` mượn.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// Chỉ cần mượn nội dung.
    fn get(&mut self) -> &(dyn Any + Send);
}