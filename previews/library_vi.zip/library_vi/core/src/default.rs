//! `Default` trait dành cho các loại có thể có giá trị mặc định có ý nghĩa.

#![stable(feature = "rust1", since = "1.0.0")]

/// trait để cung cấp cho một loại giá trị mặc định hữu ích.
///
/// Đôi khi, bạn muốn quay trở lại một số loại giá trị mặc định và không đặc biệt quan tâm nó là gì.
/// Điều này thường xuất hiện với các `cấu trúc` xác định một tập hợp các tùy chọn:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// Làm thế nào chúng ta có thể xác định một số giá trị mặc định?Bạn có thể sử dụng `Default`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// Bây giờ, bạn nhận được tất cả các giá trị mặc định.Rust triển khai `Default` cho các kiểu nguyên thủy khác nhau.
///
/// Nếu bạn muốn ghi đè một tùy chọn cụ thể, nhưng vẫn giữ nguyên các giá trị mặc định khác:
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// trait này có thể được sử dụng với `#[derive]` nếu tất cả các trường của loại đều triển khai `Default`.
/// Khi `dẫn xuất`d, nó sẽ sử dụng giá trị mặc định cho từng loại trường.
///
/// ## Làm cách nào để triển khai `Default`?
///
/// Cung cấp triển khai cho phương thức `default()` trả về giá trị của loại của bạn, giá trị này phải là giá trị mặc định:
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// Trả về "default value" cho một kiểu.
    ///
    /// Giá trị mặc định thường là một số loại giá trị ban đầu, giá trị nhận dạng hoặc bất kỳ thứ gì khác có thể có ý nghĩa như một giá trị mặc định.
    ///
    ///
    /// # Examples
    ///
    /// Sử dụng các giá trị mặc định được tích hợp sẵn:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// Làm của riêng bạn:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// Trả về giá trị mặc định của một loại theo `Default` trait.
///
/// Kiểu trả về được suy ra từ ngữ cảnh;điều này tương đương với `Default::default()` nhưng ngắn hơn để nhập.
///
/// Ví dụ:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// Derive macro tạo ra một impl của trait `Default`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }