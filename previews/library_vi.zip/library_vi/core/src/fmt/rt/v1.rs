//! Đây là một mô-đun nội bộ được sử dụng bởi ifmt!thời gian chạy.Các cấu trúc này được phát ra các mảng tĩnh để biên dịch trước các chuỗi định dạng trước thời hạn.
//!
//! Các định nghĩa này tương tự như các định nghĩa tương đương `ct` của chúng, nhưng khác ở chỗ chúng có thể được phân bổ tĩnh và được tối ưu hóa một chút cho thời gian chạy
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Các căn chỉnh có thể có có thể được yêu cầu như một phần của chỉ thị định dạng.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Chỉ ra rằng nội dung nên được căn trái.
    Left,
    /// Chỉ ra rằng nội dung phải được căn phải.
    Right,
    /// Chỉ ra rằng nội dung phải được căn giữa.
    Center,
    /// Không có căn chỉnh nào được yêu cầu.
    Unknown,
}

/// Được sử dụng bởi các thông số kỹ thuật [width](https://doc.rust-lang.org/std/fmt/#width) và [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Được chỉ định bằng một số theo nghĩa đen, lưu trữ giá trị
    Is(usize),
    /// Được chỉ định bằng cách sử dụng cú pháp `$` và `*`, lưu trữ chỉ mục vào `args`
    Param(usize),
    /// Không được chỉ định
    Implied,
}