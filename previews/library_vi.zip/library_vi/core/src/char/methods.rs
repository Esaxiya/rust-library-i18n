//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Điểm mã hợp lệ cao nhất mà `char` có thể có.
    ///
    /// `char` là [Unicode Scalar Value], có nghĩa là nó là [Code Point], nhưng chỉ là những cái trong một phạm vi nhất định.
    /// `MAX` là điểm mã hợp lệ cao nhất là [Unicode Scalar Value] hợp lệ.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () được sử dụng trong Unicode để biểu thị một lỗi giải mã.
    ///
    /// Nó có thể xảy ra, ví dụ, khi cung cấp các byte UTF-8 sai cho [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Phiên bản của [Unicode](http://www.unicode.org/) dựa trên các phần Unicode của phương thức `char` và `str`.
    ///
    /// Các phiên bản mới của Unicode được phát hành thường xuyên và sau đó tất cả các phương thức trong thư viện chuẩn tùy thuộc vào Unicode đều được cập nhật.
    /// Do đó hành vi của một số phương pháp `char` và `str` và giá trị của hằng số này thay đổi theo thời gian.
    /// Đây *không* được coi là một thay đổi đột phá.
    ///
    /// Sơ đồ đánh số phiên bản được giải thích trong [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Tạo một trình lặp trên các điểm mã được mã hóa UTF-16 trong `iter`, trả về các đại diện chưa được ghép nối dưới dạng `Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Có thể thu được bộ giải mã mất dữ liệu bằng cách thay thế kết quả `Err` bằng ký tự thay thế:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Chuyển đổi `u32` thành `char`.
    ///
    /// Lưu ý rằng tất cả các `char` đều hợp lệ [`u32`] và có thể được chuyển thành một với
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Tuy nhiên, điều ngược lại là không đúng: không phải tất cả các [`u32`] hợp lệ đều là`char` hợp lệ.
    /// `from_u32()` sẽ trả về `None` nếu đầu vào không phải là giá trị hợp lệ cho `char`.
    ///
    /// Đối với phiên bản không an toàn của hàm này bỏ qua các kiểm tra này, hãy xem [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Trả lại `None` khi đầu vào không phải là `char` hợp lệ:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Chuyển đổi `u32` thành `char`, bỏ qua tính hợp lệ.
    ///
    /// Lưu ý rằng tất cả các `char` đều hợp lệ [`u32`] và có thể được chuyển thành một với
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Tuy nhiên, điều ngược lại là không đúng: không phải tất cả các [`u32`] hợp lệ đều là`char` hợp lệ.
    /// `from_u32_unchecked()` sẽ bỏ qua điều này và truyền đến `char` một cách mù quáng, có thể tạo ra một tệp không hợp lệ.
    ///
    ///
    /// # Safety
    ///
    /// Hàm này không an toàn, vì nó có thể tạo ra các giá trị `char` không hợp lệ.
    ///
    /// Để biết phiên bản an toàn của chức năng này, hãy xem chức năng [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // AN TOÀN: hợp đồng an toàn phải được người gọi tuân thủ.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Chuyển đổi một chữ số trong cơ số đã cho thành `char`.
    ///
    /// 'radix' ở đây đôi khi còn được gọi là 'base'.
    /// Cơ số hai cho biết một số nhị phân, cơ số mười, số thập phân và cơ số mười sáu, hệ thập lục phân, để cung cấp một số giá trị chung.
    ///
    /// Các hình chiếu xạ tùy ý được hỗ trợ.
    ///
    /// `from_digit()` sẽ trả về `None` nếu đầu vào không phải là một chữ số trong cơ số đã cho.
    ///
    /// # Panics
    ///
    /// Panics nếu cho cơ số lớn hơn 36.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Số thập phân 11 là một chữ số duy nhất trong cơ số 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Trả về `None` khi đầu vào không phải là chữ số:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Vượt qua một cơ số lớn, gây ra panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Kiểm tra xem `char` có phải là một chữ số trong cơ số đã cho hay không.
    ///
    /// 'radix' ở đây đôi khi còn được gọi là 'base'.
    /// Cơ số hai cho biết một số nhị phân, cơ số mười, số thập phân và cơ số mười sáu, hệ thập lục phân, để cung cấp một số giá trị chung.
    ///
    /// Các hình chiếu xạ tùy ý được hỗ trợ.
    ///
    /// So với [`is_numeric()`], chức năng này chỉ nhận dạng các ký tự `0-9`, `a-z` và `A-Z`.
    ///
    /// 'Digit' được định nghĩa là chỉ các ký tự sau:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Để hiểu toàn diện hơn về 'digit', hãy xem [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics nếu cho cơ số lớn hơn 36.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Vượt qua một cơ số lớn, gây ra panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Chuyển đổi `char` thành một chữ số trong cơ số đã cho.
    ///
    /// 'radix' ở đây đôi khi còn được gọi là 'base'.
    /// Cơ số hai cho biết một số nhị phân, cơ số mười, số thập phân và cơ số mười sáu, hệ thập lục phân, để cung cấp một số giá trị chung.
    ///
    /// Các hình chiếu xạ tùy ý được hỗ trợ.
    ///
    /// 'Digit' được định nghĩa là chỉ các ký tự sau:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Trả về `None` nếu `char` không tham chiếu đến một chữ số trong cơ số đã cho.
    ///
    /// # Panics
    ///
    /// Panics nếu cho cơ số lớn hơn 36.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Việc vượt qua một kết quả không phải là chữ số sẽ không thành công:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Vượt qua một cơ số lớn, gây ra panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // mã được tách ra ở đây để cải thiện tốc độ thực thi cho các trường hợp `radix` không đổi và 10 hoặc nhỏ hơn
        //
        let val = if likely(radix <= 10) {
            // Nếu không phải là một chữ số, một số lớn hơn cơ số sẽ được tạo ra.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Trả về một trình lặp mang lại lối thoát Unicode thập lục phân của một ký tự dưới dạng `char`s.
    ///
    /// Thao tác này sẽ thoát các ký tự với cú pháp Rust của dạng `\u{NNNNNN}` trong đó `NNNNNN` là biểu diễn thập lục phân.
    ///
    ///
    /// # Examples
    ///
    /// Là một trình lặp:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Sử dụng `println!` trực tiếp:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Cả hai đều tương đương với:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Sử dụng `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // or-ing 1 đảm bảo rằng đối với c==0, mã tính toán rằng một chữ số sẽ được in và (giống nhau) tránh dòng dưới (31, 32)
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // chỉ số của chữ số hex có ý nghĩa nhất
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Phiên bản mở rộng của `escape_debug` cho phép tùy chọn thoát mã điểm đồ họa mở rộng.
    /// Điều này cho phép chúng tôi định dạng các ký tự như dấu không có khoảng cách tốt hơn khi chúng ở đầu chuỗi.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Trả về một trình lặp mang lại mã thoát theo nghĩa đen của một ký tự dưới dạng `char`s.
    ///
    /// Điều này sẽ thoát khỏi các ký tự tương tự như triển khai `Debug` của `str` hoặc `char`.
    ///
    ///
    /// # Examples
    ///
    /// Là một trình lặp:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Sử dụng `println!` trực tiếp:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Cả hai đều tương đương với:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Sử dụng `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Trả về một trình lặp mang lại mã thoát theo nghĩa đen của một ký tự dưới dạng `char`s.
    ///
    /// Mặc định được chọn với xu hướng tạo ra các ký tự hợp pháp trong nhiều ngôn ngữ khác nhau, bao gồm C++ 11 và các ngôn ngữ họ C tương tự.
    /// Các quy tắc chính xác là:
    ///
    /// * Tab được thoát dưới dạng `\t`.
    /// * Vận chuyển trở lại được thoát dưới dạng `\r`.
    /// * Nguồn cấp dữ liệu dòng được thoát dưới dạng `\n`.
    /// * Trích dẫn duy nhất được thoát dưới dạng `\'`.
    /// * Dấu ngoặc kép được thoát là `\"`.
    /// * Dấu gạch chéo ngược được thoát ra dưới dạng `\\`.
    /// * Bất kỳ ký tự nào trong phạm vi 'ASCII có thể in' `0x20` .. bao gồm `0x7e` không được thoát.
    /// * Tất cả các ký tự khác được cung cấp các thoát Unicode thập lục phân;xem [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Là một trình lặp:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Sử dụng `println!` trực tiếp:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Cả hai đều tương đương với:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Sử dụng `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Trả về số byte mà `char` này sẽ cần nếu được mã hóa bằng UTF-8.
    ///
    /// Số byte đó luôn nằm trong khoảng từ 1 đến 4, bao gồm cả.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Kiểu `&str` đảm bảo rằng nội dung của nó là UTF-8 và do đó, chúng tôi có thể so sánh độ dài sẽ mất nếu mỗi điểm mã được biểu diễn dưới dạng `char` so với trong chính `&str`:
    ///
    ///
    /// ```
    /// // dưới dạng ký tự
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // cả hai đều có thể được biểu diễn dưới dạng ba byte
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // dưới dạng &str, hai cái này được mã hóa bằng UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // chúng ta có thể thấy rằng chúng chiếm tổng cộng sáu byte ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... giống như &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Trả về số lượng đơn vị mã 16 bit mà `char` này sẽ cần nếu được mã hóa bằng UTF-16.
    ///
    ///
    /// Xem tài liệu về [`len_utf8()`] để biết thêm giải thích về khái niệm này.
    /// Chức năng này là một nhân bản, nhưng dành cho UTF-16 thay vì UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Mã hóa ký tự này dưới dạng UTF-8 vào bộ đệm byte được cung cấp, rồi trả về tập hợp con của bộ đệm có chứa ký tự được mã hóa.
    ///
    ///
    /// # Panics
    ///
    /// Panics nếu bộ đệm không đủ lớn.
    /// Bộ đệm có độ dài bốn là đủ lớn để mã hóa bất kỳ `char` nào.
    ///
    /// # Examples
    ///
    /// Trong cả hai ví dụ này, 'ß' cần hai byte để mã hóa.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Bộ đệm quá nhỏ:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // AN TOÀN: `char` không phải là vật thay thế, vì vậy đây là UTF-8 hợp lệ.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Mã hóa ký tự này dưới dạng UTF-16 vào bộ đệm `u16` được cung cấp, sau đó trả về tập hợp con của bộ đệm có chứa ký tự được mã hóa.
    ///
    ///
    /// # Panics
    ///
    /// Panics nếu bộ đệm không đủ lớn.
    /// Bộ đệm có độ dài 2 đủ lớn để mã hóa bất kỳ `char` nào.
    ///
    /// # Examples
    ///
    /// Trong cả hai ví dụ này, '𝕊' cần hai `u16`s để mã hóa.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Bộ đệm quá nhỏ:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Trả về `true` nếu `char` này có thuộc tính `Alphabetic`.
    ///
    /// `Alphabetic` được mô tả trong Chương 4 (Thuộc tính ký tự) của [Unicode Standard] và được chỉ định trong [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // tình yêu là nhiều thứ, nhưng nó không phải là bảng chữ cái
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Trả về `true` nếu `char` này có thuộc tính `Lowercase`.
    ///
    /// `Lowercase` được mô tả trong Chương 4 (Thuộc tính ký tự) của [Unicode Standard] và được chỉ định trong [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Các chữ viết và dấu câu khác nhau của Trung Quốc không có chữ hoa và chữ thường:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Trả về `true` nếu `char` này có thuộc tính `Uppercase`.
    ///
    /// `Uppercase` được mô tả trong Chương 4 (Thuộc tính ký tự) của [Unicode Standard] và được chỉ định trong [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Các chữ viết và dấu câu khác nhau của Trung Quốc không có chữ hoa và chữ thường:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Trả về `true` nếu `char` này có thuộc tính `White_Space`.
    ///
    /// `White_Space` được chỉ định trong [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // một không gian không phá vỡ
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Trả về `true` nếu `char` này thỏa mãn [`is_alphabetic()`] hoặc [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Trả về `true` nếu `char` này có danh mục chung cho mã điều khiển.
    ///
    /// Mã điều khiển (các điểm mã có danh mục chung là `Cc`) được mô tả trong Chương 4 (Thuộc tính ký tự) của [Unicode Standard] và được chỉ định trong [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// // U + 009C, STRING TERMINATOR
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Trả về `true` nếu `char` này có thuộc tính `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` được mô tả trong [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] và được chỉ định trong [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Trả về `true` nếu `char` này có một trong các danh mục chung cho số.
    ///
    /// Các danh mục chung cho số (`Nd` cho các chữ số thập phân, `Nl` cho các ký tự số giống như chữ cái và `No` cho các ký tự số khác) được chỉ định trong [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Trả về một trình lặp mang lại ánh xạ chữ thường của `char` này dưới dạng một hoặc nhiều
    /// `char`s.
    ///
    /// Nếu `char` này không có ánh xạ chữ thường, thì trình lặp cho kết quả giống `char`.
    ///
    /// Nếu `char` này có ánh xạ chữ thường 1-1 được cung cấp bởi [Unicode Character Database][ucd] [`UnicodeData.txt`], thì trình lặp cho ra `char` đó.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Nếu `char` này yêu cầu xem xét đặc biệt (ví dụ: nhiều `char`), trình lặp sẽ thu được (các)`char` do [`SpecialCasing.txt`] đưa ra.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Thao tác này thực hiện một ánh xạ vô điều kiện mà không cần chỉnh sửa.Nghĩa là, việc chuyển đổi không phụ thuộc vào ngữ cảnh và ngôn ngữ.
    ///
    /// Trong [Unicode Standard], Chương 4 (Thuộc tính Ký tự) thảo luận về ánh xạ trường hợp nói chung và Chương 3 (Conformance) thảo luận về thuật toán mặc định để chuyển đổi trường hợp.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Là một trình lặp:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Sử dụng `println!` trực tiếp:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Cả hai đều tương đương với:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Sử dụng `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Đôi khi kết quả có nhiều hơn một ký tự:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Các ký tự không có cả chữ hoa và chữ thường chuyển đổi thành chính chúng.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Trả về một trình lặp mang lại ánh xạ chữ hoa của `char` này dưới dạng một hoặc nhiều
    /// `char`s.
    ///
    /// Nếu `char` này không có ánh xạ chữ hoa, thì trình lặp cho kết quả giống `char`.
    ///
    /// Nếu `char` này có ánh xạ chữ hoa một-một được cung cấp bởi [Unicode Character Database][ucd] [`UnicodeData.txt`], thì trình lặp cho ra `char` đó.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Nếu `char` này yêu cầu xem xét đặc biệt (ví dụ: nhiều `char`), trình lặp sẽ thu được (các)`char` do [`SpecialCasing.txt`] đưa ra.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Thao tác này thực hiện một ánh xạ vô điều kiện mà không cần chỉnh sửa.Nghĩa là, việc chuyển đổi không phụ thuộc vào ngữ cảnh và ngôn ngữ.
    ///
    /// Trong [Unicode Standard], Chương 4 (Thuộc tính Ký tự) thảo luận về ánh xạ trường hợp nói chung và Chương 3 (Conformance) thảo luận về thuật toán mặc định để chuyển đổi trường hợp.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Là một trình lặp:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Sử dụng `println!` trực tiếp:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Cả hai đều tương đương với:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Sử dụng `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Đôi khi kết quả có nhiều hơn một ký tự:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Các ký tự không có cả chữ hoa và chữ thường chuyển đổi thành chính chúng.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Ghi chú về ngôn ngữ
    ///
    /// Trong tiếng Thổ Nhĩ Kỳ, tương đương với 'i' trong tiếng Latinh có năm dạng thay vì hai dạng:
    ///
    /// * 'Dotless': I/ı, đôi khi được viết ï
    /// * 'Dotted': İ/tôi
    ///
    /// Lưu ý rằng chữ 'i' chấm chấm chữ thường giống với chữ Latinh.Vì thế:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Giá trị của `upper_i` ở đây phụ thuộc vào ngôn ngữ của văn bản: nếu chúng ta đang ở `en-US`, nó phải là `"I"`, nhưng nếu chúng ta ở `tr_TR`, nó phải là `"İ"`.
    /// `to_uppercase()` không tính đến điều này, và do đó:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// giữ trên các ngôn ngữ.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Kiểm tra xem giá trị có nằm trong phạm vi ASCII không.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Tạo một bản sao của giá trị bằng chữ hoa và chữ thường ASCII của nó.
    ///
    /// Các chữ cái ASCII 'a' đến 'z' được ánh xạ thành 'A' đến 'Z', nhưng các chữ cái không phải ASCII thì không thay đổi.
    ///
    /// Để viết hoa giá trị tại chỗ, hãy sử dụng [`make_ascii_uppercase()`].
    ///
    /// Để viết hoa các ký tự ASCII ngoài các ký tự không phải ASCII, hãy sử dụng [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Tạo một bản sao của giá trị bằng chữ thường ASCII tương đương của nó.
    ///
    /// Các chữ cái ASCII 'A' đến 'Z' được ánh xạ thành 'a' đến 'z', nhưng các chữ cái không phải ASCII thì không thay đổi.
    ///
    /// Để viết thường giá trị tại chỗ, hãy sử dụng [`make_ascii_lowercase()`].
    ///
    /// Để ký tự ASCII viết thường ngoài các ký tự không phải ASCII, hãy sử dụng [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Kiểm tra xem hai giá trị có trùng khớp không phân biệt chữ hoa chữ thường ASCII hay không.
    ///
    /// Tương đương với `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Chuyển đổi kiểu này thành dạng chữ hoa ASCII tương đương tại chỗ.
    ///
    /// Các chữ cái ASCII 'a' đến 'z' được ánh xạ thành 'A' đến 'Z', nhưng các chữ cái không phải ASCII thì không thay đổi.
    ///
    /// Để trả về một giá trị viết hoa mới mà không sửa đổi giá trị hiện có, hãy sử dụng [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Chuyển đổi loại này thành chữ thường ASCII tương đương tại chỗ.
    ///
    /// Các chữ cái ASCII 'A' đến 'Z' được ánh xạ thành 'a' đến 'z', nhưng các chữ cái không phải ASCII thì không thay đổi.
    ///
    /// Để trả về một giá trị chữ thường mới mà không sửa đổi giá trị hiện có, hãy sử dụng [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Kiểm tra xem giá trị có phải là ký tự chữ cái ASCII hay không:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', hoặc
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Kiểm tra xem giá trị có phải là ký tự viết hoa ASCII hay không:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Kiểm tra xem giá trị có phải là ký tự viết thường ASCII hay không:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Kiểm tra xem giá trị có phải là ký tự chữ và số ASCII hay không:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', hoặc
    /// - U + 0061 'a' ..=U + 007A 'z', hoặc
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Kiểm tra xem giá trị có phải là chữ số thập phân ASCII hay không:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Kiểm tra xem giá trị có phải là chữ số thập lục phân ASCII hay không:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', hoặc
    /// - U + 0041 'A' ..=U + 0046 'F', hoặc
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Kiểm tra xem giá trị có phải là ký tự dấu câu ASCII hay không:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, hoặc
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, hoặc
    /// - U + 005B ..=U + 0060 ``[\] ^ _`` hoặc
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Kiểm tra xem giá trị có phải là ký tự đồ họa ASCII hay không:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Kiểm tra xem giá trị có phải là ký tự khoảng trắng ASCII hay không:
    /// KHÔNG GIAN U + 0020, TAB NGANG U + 0009, THỨC ĂN DÒNG U + 000A, THỨC ĂN MẪU U + 000C, hoặc QUAY LẠI VẬN CHUYỂN U + 000D.
    ///
    /// Rust sử dụng [definition of ASCII whitespace][infra-aw] của Chuẩn hồng ngoại WhatWG.Có một số định nghĩa khác được sử dụng rộng rãi.
    /// Ví dụ: [the POSIX locale][pct] bao gồm U + 000B VERTICAL TAB cũng như tất cả các ký tự ở trên, nhưng - từ cùng một thông số kỹ thuật- [quy tắc mặc định cho "field splitting" trong Bourne shell][bfs] xem xét *chỉ* KHÔNG GIAN, BẢNG NGANG, và LINE FEED dưới dạng khoảng trắng.
    ///
    ///
    /// Nếu bạn đang viết một chương trình sẽ xử lý một định dạng tệp hiện có, hãy kiểm tra định nghĩa khoảng trắng của định dạng đó là gì trước khi sử dụng chức năng này.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Kiểm tra xem giá trị có phải là ký tự điều khiển ASCII hay không:
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR, hoặc U + 007F DELETE.
    /// Lưu ý rằng hầu hết các ký tự khoảng trắng ASCII là ký tự điều khiển, nhưng SPACE thì không.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Mã hóa một giá trị u32 thô dưới dạng UTF-8 vào bộ đệm byte được cung cấp, rồi trả về tập hợp con của bộ đệm có chứa ký tự được mã hóa.
///
///
/// Không giống như `char::encode_utf8`, phương pháp này cũng xử lý các điểm mã trong phạm vi thay thế.
/// (Tạo `char` trong phạm vi thay thế là UB.) Kết quả là [generalized UTF-8] hợp lệ nhưng không hợp lệ UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics nếu bộ đệm không đủ lớn.
/// Bộ đệm có độ dài bốn là đủ lớn để mã hóa bất kỳ `char` nào.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Mã hóa một giá trị u32 thô dưới dạng UTF-16 vào bộ đệm `u16` được cung cấp, rồi trả về tập hợp con của bộ đệm có chứa ký tự được mã hóa.
///
///
/// Không giống như `char::encode_utf16`, phương pháp này cũng xử lý các điểm mã trong phạm vi thay thế.
/// (Tạo `char` trong phạm vi thay thế là UB.)
///
/// # Panics
///
/// Panics nếu bộ đệm không đủ lớn.
/// Bộ đệm có độ dài 2 đủ lớn để mã hóa bất kỳ `char` nào.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // AN TOÀN: mỗi nhánh kiểm tra xem có đủ bit để ghi vào không
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP giảm
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Máy bay bổ sung đột nhập vào máy bay thay thế.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}