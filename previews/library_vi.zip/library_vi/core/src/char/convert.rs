//! Chuyển đổi ký tự.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Chuyển đổi `u32` thành `char`.
///
/// Lưu ý rằng tất cả [`char`] đều hợp lệ [`u32`] và có thể được truyền thành một với
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Tuy nhiên, điều ngược lại là không đúng: không phải tất cả các [`u32`] hợp lệ đều hợp lệ [`char`] s.
/// `from_u32()` sẽ trả về `None` nếu đầu vào không phải là giá trị hợp lệ cho [`char`].
///
/// Đối với phiên bản không an toàn của hàm này bỏ qua các kiểm tra này, hãy xem [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Cách sử dụng cơ bản:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Trả lại `None` khi đầu vào không phải là [`char`] hợp lệ:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Chuyển đổi `u32` thành `char`, bỏ qua tính hợp lệ.
///
/// Lưu ý rằng tất cả [`char`] đều hợp lệ [`u32`] và có thể được truyền thành một với
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Tuy nhiên, điều ngược lại là không đúng: không phải tất cả các [`u32`] hợp lệ đều hợp lệ [`char`] s.
/// `from_u32_unchecked()` sẽ bỏ qua điều này và chuyển sang [`char`] một cách mù quáng, có thể tạo ra một tệp không hợp lệ.
///
///
/// # Safety
///
/// Hàm này không an toàn, vì nó có thể tạo ra các giá trị `char` không hợp lệ.
///
/// Để biết phiên bản an toàn của chức năng này, hãy xem chức năng [`from_u32`].
///
/// # Examples
///
/// Cách sử dụng cơ bản:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // AN TOÀN: người gọi phải đảm bảo rằng `i` là một giá trị char hợp lệ.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Chuyển đổi [`char`] thành [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Chuyển đổi [`char`] thành [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Char được truyền đến giá trị của điểm mã, sau đó được mở rộng bằng 0 đến 64 bit.
        // Xem [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Chuyển đổi [`char`] thành [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Char được truyền đến giá trị của điểm mã, sau đó được mở rộng bằng 0 đến 128 bit.
        // Xem [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Ánh xạ một byte ở 0x00 ..=0xFF tới `char` có điểm mã có cùng giá trị, tính bằng U + 0000 ..=U + 00FF.
///
/// Unicode được thiết kế để giải mã byte một cách hiệu quả với mã hóa ký tự mà IANA gọi là ISO-8859-1.
/// Bảng mã này tương thích với ASCII.
///
/// Lưu ý rằng điều này khác với ISO/IEC 8859-1 aka
/// ISO 8859-1 (với một dấu gạch ngang ít hơn), để lại một số "blanks", giá trị byte không được gán cho bất kỳ ký tự nào.
/// ISO-8859-1 (IANA) chỉ định chúng cho mã điều khiển C0 và C1.
///
/// Lưu ý rằng điều này *cũng* khác với Windows-1252 aka
/// mã trang 1252, là bộ superset ISO/IEC 8859-1 gán một số khoảng trống (không phải tất cả!) cho dấu câu và các ký tự Latinh khác nhau.
///
/// Để làm cho mọi thứ thêm nhầm lẫn, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` và `windows-1252` đều là bí danh của một bộ siêu Windows-1252 có chức năng lấp đầy các khoảng trống còn lại bằng mã điều khiển C0 và C1 tương ứng.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Chuyển đổi [`u8`] thành [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Một lỗi có thể được trả lại khi phân tích cú pháp một ký tự.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // AN TOÀN: đã kiểm tra xem đó có phải là giá trị unicode hợp pháp không
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Loại lỗi được trả về khi chuyển đổi từ u32 sang char không thành công.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Chuyển đổi một chữ số trong cơ số đã cho thành `char`.
///
/// 'radix' ở đây đôi khi còn được gọi là 'base'.
/// Cơ số hai cho biết một số nhị phân, cơ số mười, số thập phân và cơ số mười sáu, hệ thập lục phân, để cung cấp một số giá trị chung.
///
/// Các hình chiếu xạ tùy ý được hỗ trợ.
///
/// `from_digit()` sẽ trả về `None` nếu đầu vào không phải là một chữ số trong cơ số đã cho.
///
/// # Panics
///
/// Panics nếu cho cơ số lớn hơn 36.
///
/// # Examples
///
/// Cách sử dụng cơ bản:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Số thập phân 11 là một chữ số duy nhất trong cơ số 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Trả về `None` khi đầu vào không phải là chữ số:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Vượt qua một cơ số lớn, gây ra panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}