/// Được sử dụng cho các hoạt động hội nghị bất biến, như `*v`.
///
/// Ngoài việc được sử dụng cho các hoạt động hội nghị rõ ràng với toán tử (unary) `*` trong các ngữ cảnh bất biến, `Deref` cũng được trình biên dịch sử dụng ngầm trong nhiều trường hợp.
/// Cơ chế này được gọi là ['`Deref` coercion'][more].
/// Trong các ngữ cảnh có thể thay đổi, [`DerefMut`] được sử dụng.
///
/// Việc triển khai `Deref` cho các con trỏ thông minh giúp việc truy cập dữ liệu đằng sau chúng trở nên thuận tiện, đó là lý do tại sao họ triển khai `Deref`.
/// Mặt khác, các quy tắc liên quan đến `Deref` và [`DerefMut`] được thiết kế đặc biệt để phù hợp với các con trỏ thông minh.
/// Do đó,**`Deref` chỉ nên được triển khai cho các con trỏ thông minh** để tránh nhầm lẫn.
///
/// Vì những lý do tương tự,**trait này sẽ không bao giờ bị lỗi**.Lỗi trong quá trình hội nghị có thể cực kỳ khó hiểu khi `Deref` được gọi ngầm.
///
/// # Thêm thông tin về cưỡng chế `Deref`
///
/// Nếu `T` triển khai `Deref<Target = U>` và `x` là một giá trị của kiểu `T`, thì:
///
/// * Trong các ngữ cảnh bất biến, `*x` (trong đó `T` không phải là tham chiếu cũng như con trỏ thô) tương đương với `* Deref::deref(&x)`.
/// * Các giá trị của kiểu `&T` bị ép buộc với các giá trị của kiểu `&U`
/// * `T` triển khai ngầm tất cả các phương thức (immutable) của kiểu `U`.
///
/// Để biết thêm chi tiết, hãy truy cập [the chapter in *The Rust Programming Language*][book] cũng như các phần tham khảo trên [the dereference operator][ref-deref-op], [method resolution] và [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Một cấu trúc có một trường duy nhất có thể truy cập được bằng cách tham chiếu cấu trúc.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Loại kết quả sau khi tham khảo.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Bỏ qua giá trị.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Được sử dụng cho các hoạt động hội nghị có thể thay đổi, như trong `*v = 1;`.
///
/// Ngoài việc được sử dụng cho các hoạt động hội nghị rõ ràng với toán tử (unary) `*` trong các ngữ cảnh có thể thay đổi, `DerefMut` cũng được trình biên dịch sử dụng ngầm trong nhiều trường hợp.
/// Cơ chế này được gọi là ['`Deref` coercion'][more].
/// Trong các ngữ cảnh bất biến, [`Deref`] được sử dụng.
///
/// Việc triển khai `DerefMut` cho các con trỏ thông minh làm cho việc thay đổi dữ liệu đằng sau chúng trở nên thuận tiện, đó là lý do tại sao họ triển khai `DerefMut`.
/// Mặt khác, các quy tắc liên quan đến [`Deref`] và `DerefMut` được thiết kế đặc biệt để phù hợp với các con trỏ thông minh.
/// Do đó,**`DerefMut` chỉ nên được triển khai cho các con trỏ thông minh** để tránh nhầm lẫn.
///
/// Vì những lý do tương tự,**trait này sẽ không bao giờ bị lỗi**.Lỗi trong quá trình hội nghị có thể cực kỳ khó hiểu khi `DerefMut` được gọi ngầm.
///
/// # Thêm thông tin về cưỡng chế `Deref`
///
/// Nếu `T` triển khai `DerefMut<Target = U>` và `x` là một giá trị của kiểu `T`, thì:
///
/// * Trong các ngữ cảnh có thể thay đổi, `*x` (trong đó `T` không phải là tham chiếu hoặc con trỏ thô) tương đương với `* DerefMut::deref_mut(&mut x)`.
/// * Các giá trị của kiểu `&mut T` bị ép buộc với các giá trị của kiểu `&mut U`
/// * `T` triển khai ngầm tất cả các phương thức (mutable) của kiểu `U`.
///
/// Để biết thêm chi tiết, hãy truy cập [the chapter in *The Rust Programming Language*][book] cũng như các phần tham khảo trên [the dereference operator][ref-deref-op], [method resolution] và [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Một cấu trúc có một trường duy nhất có thể sửa đổi được bằng cách tham khảo cấu trúc.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Bỏ qua lẫn nhau giá trị.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Cho biết rằng một cấu trúc có thể được sử dụng như một bộ thu phương thức mà không cần tính năng `arbitrary_self_types`.
///
/// Điều này được thực hiện bởi các loại con trỏ stdlib như `Box<T>`, `Rc<T>`, `&T` và `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}