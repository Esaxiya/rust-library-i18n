use crate::marker::Unsize;

/// Trait chỉ ra rằng đây là một con trỏ hoặc một trình bao bọc cho một, nơi có thể thực hiện việc hủy kích thước trên con trỏ.
///
/// Xem [DST coercion RFC][dst-coerce] và [the nomicon entry on coercion][nomicon-coerce] để biết thêm chi tiết.
///
/// Đối với các loại con trỏ nội trang, con trỏ tới `T` sẽ ép buộc con trỏ tới `U` nếu `T: Unsize<U>` bằng cách chuyển đổi từ con trỏ mỏng thành con trỏ béo.
///
/// Đối với các loại tùy chỉnh, việc ép buộc ở đây hoạt động bằng cách ép buộc `Foo<T>` thành `Foo<U>` với điều kiện tồn tại một lượng `CoerceUnsized<Foo<U>> for Foo<T>`.
/// Việc cấy ghép như vậy chỉ có thể được viết nếu `Foo<T>` chỉ có một trường không phải dữ liệu ảo liên quan đến `T`.
/// Nếu loại trường đó là `Bar<T>`, thì việc triển khai `CoerceUnsized<Bar<U>> for Bar<T>` phải tồn tại.
/// Việc ép buộc sẽ hoạt động bằng cách ép trường `Bar<T>` thành `Bar<U>` và điền vào các trường còn lại từ `Foo<T>` để tạo `Foo<U>`.
/// Điều này có hiệu quả sẽ đi sâu vào một trường con trỏ và ép buộc nó.
///
/// Nói chung, đối với con trỏ thông minh, bạn sẽ triển khai `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, với một `?Sized` tùy chọn được ràng buộc trên chính `T`.
/// Đối với các loại trình bao bọc nhúng trực tiếp `T` như `Cell<T>` và `RefCell<T>`, bạn có thể triển khai trực tiếp `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Điều này sẽ cho phép các loại cưỡng chế như `Cell<Box<T>>` hoạt động.
///
/// [`Unsize`][unsize] được sử dụng để đánh dấu các loại có thể bị ép buộc đối với DST nếu đứng sau con trỏ.Nó được thực hiện tự động bởi trình biên dịch.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * đột biến U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *đột biến T->* đột biến U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Điều này được sử dụng để đảm bảo an toàn cho đối tượng, để kiểm tra xem loại bộ thu của phương thức có thể được gửi đi hay không.
///
/// Một ví dụ về triển khai trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *đột biến T->* đột biến U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}