/// Phiên bản của nhà điều hành cuộc gọi có người nhận không thay đổi.
///
/// Các phiên bản của `Fn` có thể được gọi nhiều lần mà không có trạng thái đột biến.
///
/// *Không nên nhầm lẫn trait (`Fn`) này với [function pointers] (`fn`).*
///
/// `Fn` được thực hiện tự động bằng cách đóng, chỉ lấy các tham chiếu không thay đổi đến các biến đã bắt hoặc không nắm bắt bất cứ thứ gì, cũng như (safe) [function pointers] (với một số lưu ý, hãy xem tài liệu của chúng để biết thêm chi tiết).
///
/// Ngoài ra, đối với bất kỳ loại `F` nào triển khai `Fn`, `&F` cũng triển khai `Fn`.
///
/// Vì cả [`FnMut`] và [`FnOnce`] đều là supertraits của `Fn` nên bất kỳ phiên bản nào của `Fn` đều có thể được sử dụng làm tham số mà [`FnMut`] hoặc [`FnOnce`] được mong đợi.
///
/// Sử dụng `Fn` như một ràng buộc khi bạn muốn chấp nhận một tham số có kiểu giống như hàm và cần gọi nó nhiều lần và không có trạng thái đột biến (ví dụ: khi gọi nó đồng thời).
/// Nếu bạn không cần những yêu cầu khắt khe như vậy, hãy sử dụng [`FnMut`] hoặc [`FnOnce`] làm giới hạn.
///
/// Xem [chapter on closures in *The Rust Programming Language*][book] để biết thêm thông tin về chủ đề này.
///
/// Cũng cần lưu ý là cú pháp đặc biệt cho `Fn` traits (ví dụ:
/// `Fn(usize, bool) -> sử dụng`).Những người quan tâm đến các chi tiết kỹ thuật của điều này có thể tham khảo [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Kêu gọi đóng cửa
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Sử dụng tham số `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // để regex có thể dựa vào `&str: !FnMut` đó
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Thực hiện thao tác cuộc gọi.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Phiên bản của nhà điều hành cuộc gọi có bộ thu có thể thay đổi.
///
/// Các phiên bản của `FnMut` có thể được gọi nhiều lần và có thể thay đổi trạng thái.
///
/// `FnMut` được thực hiện tự động bằng các bao đóng lấy các tham chiếu có thể thay đổi đến các biến được bắt, cũng như tất cả các kiểu triển khai [`Fn`], ví dụ: (safe) [function pointers] (vì `FnMut` là một siêu trang của [`Fn`]).
/// Ngoài ra, đối với bất kỳ loại `F` nào triển khai `FnMut`, `&mut F` cũng triển khai `FnMut`.
///
/// Vì [`FnOnce`] là một supertrait của `FnMut`, bất kỳ phiên bản nào của `FnMut` đều có thể được sử dụng khi [`FnOnce`] được mong đợi và vì [`Fn`] là một subtrait của `FnMut` nên bất kỳ phiên bản nào của [`Fn`] đều có thể được sử dụng khi `FnMut` được mong đợi.
///
/// Sử dụng `FnMut` làm giới hạn khi bạn muốn chấp nhận một tham số kiểu hàm giống như hàm và cần gọi nó nhiều lần, đồng thời cho phép nó thay đổi trạng thái.
/// Nếu bạn không muốn tham số thay đổi trạng thái, hãy sử dụng [`Fn`] làm giới hạn;nếu bạn không cần gọi nó nhiều lần, hãy sử dụng [`FnOnce`].
///
/// Xem [chapter on closures in *The Rust Programming Language*][book] để biết thêm thông tin về chủ đề này.
///
/// Cũng cần lưu ý là cú pháp đặc biệt cho `Fn` traits (ví dụ:
/// `Fn(usize, bool) -> sử dụng`).Những người quan tâm đến các chi tiết kỹ thuật của điều này có thể tham khảo [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Kêu gọi sự đóng cửa có thể thay đổi được
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Sử dụng tham số `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // để regex có thể dựa vào `&str: !FnMut` đó
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Thực hiện thao tác cuộc gọi.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Phiên bản của nhà điều hành cuộc gọi có người nhận theo giá trị.
///
/// Các phiên bản của `FnOnce` có thể được gọi, nhưng có thể không được gọi nhiều lần.Do đó, nếu điều duy nhất được biết về một kiểu là nó thực hiện `FnOnce`, thì nó chỉ có thể được gọi một lần.
///
/// `FnOnce` được thực hiện tự động bằng các bao đóng có thể sử dụng các biến đã được nắm bắt, cũng như tất cả các kiểu triển khai [`FnMut`], ví dụ: (safe) [function pointers] (vì `FnOnce` là một supertrait của [`FnMut`]).
///
///
/// Vì cả [`Fn`] và [`FnMut`] đều là các phiên bản con của `FnOnce`, bất kỳ phiên bản nào của [`Fn`] hoặc [`FnMut`] đều có thể được sử dụng khi `FnOnce` được mong đợi.
///
/// Sử dụng `FnOnce` làm giới hạn khi bạn muốn chấp nhận một tham số kiểu hàm giống như hàm và chỉ cần gọi nó một lần.
/// Nếu bạn cần gọi tham số nhiều lần, hãy sử dụng [`FnMut`] làm giới hạn;nếu bạn cũng cần nó để không thay đổi trạng thái, hãy sử dụng [`Fn`].
///
/// Xem [chapter on closures in *The Rust Programming Language*][book] để biết thêm thông tin về chủ đề này.
///
/// Cũng cần lưu ý là cú pháp đặc biệt cho `Fn` traits (ví dụ:
/// `Fn(usize, bool) -> sử dụng`).Những người quan tâm đến các chi tiết kỹ thuật của điều này có thể tham khảo [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Sử dụng tham số `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` sử dụng các biến đã bắt của nó, vì vậy nó không thể được chạy nhiều hơn một lần.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Cố gắng gọi lại `func()` sẽ gây ra lỗi `use of moved value` cho `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` không còn có thể được gọi vào thời điểm này
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // để regex có thể dựa vào `&str: !FnMut` đó
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Kiểu trả về sau khi người điều hành cuộc gọi được sử dụng.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Thực hiện thao tác cuộc gọi.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}