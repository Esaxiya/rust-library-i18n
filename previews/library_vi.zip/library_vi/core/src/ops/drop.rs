/// Mã tùy chỉnh trong trình hủy.
///
/// Khi một giá trị không còn cần thiết nữa, Rust sẽ chạy "destructor" trên giá trị đó.
/// Cách phổ biến nhất mà một giá trị không còn cần thiết nữa là khi nó vượt ra khỏi phạm vi.Các trình hủy có thể vẫn chạy trong các trường hợp khác, nhưng chúng tôi sẽ tập trung vào phạm vi cho các ví dụ ở đây.
/// Để tìm hiểu về một số trường hợp khác, vui lòng xem phần [the reference] về trình hủy.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Bộ hủy này bao gồm hai thành phần:
/// - Một lệnh gọi đến `Drop::drop` cho giá trị đó, nếu `Drop` trait đặc biệt này được triển khai cho loại của nó.
/// - "drop glue" được tạo tự động gọi đệ quy các hàm hủy của tất cả các trường có giá trị này.
///
/// Vì Rust tự động gọi hàm hủy của tất cả các trường được chứa, bạn không cần phải triển khai `Drop` trong hầu hết các trường hợp.
/// Nhưng có một số trường hợp nó hữu ích, ví dụ như đối với các loại quản lý trực tiếp tài nguyên.
/// Tài nguyên đó có thể là bộ nhớ, có thể là bộ mô tả tệp, có thể là ổ cắm mạng.
/// Khi một giá trị của kiểu đó không còn được sử dụng nữa, nó sẽ "clean up" tài nguyên của nó bằng cách giải phóng bộ nhớ hoặc đóng tệp hoặc ổ cắm.
/// Đây là công việc của một bộ hủy, và do đó là công việc của `Drop::drop`.
///
/// ## Examples
///
/// Để xem các hàm hủy đang hoạt động, chúng ta hãy xem chương trình sau:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust trước tiên sẽ gọi `Drop::drop` cho `_x` và sau đó cho cả `_x.one` và `_x.two`, có nghĩa là chạy điều này sẽ in
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Ngay cả khi chúng ta loại bỏ việc triển khai `Drop` cho `HasTwoDrop`, các hàm hủy của các trường của nó vẫn được gọi.
/// Điều này sẽ dẫn đến
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Bạn không thể tự gọi `Drop::drop`
///
/// Vì `Drop::drop` được sử dụng để xóa một giá trị, có thể nguy hiểm nếu sử dụng giá trị này sau khi phương thức đã được gọi.
/// Vì `Drop::drop` không có quyền sở hữu đầu vào của nó, Rust ngăn chặn việc lạm dụng bằng cách không cho phép bạn gọi `Drop::drop` trực tiếp.
///
/// Nói cách khác, nếu bạn cố gắng gọi `Drop::drop` một cách rõ ràng trong ví dụ trên, bạn sẽ gặp lỗi trình biên dịch.
///
/// Nếu bạn muốn gọi hàm hủy của một giá trị một cách rõ ràng, [`mem::drop`] có thể được sử dụng để thay thế.
///
/// [`mem::drop`]: drop
///
/// ## Bỏ đơn hàng
///
/// Tuy nhiên, cái nào trong hai chiếc `HasDrop` của chúng ta rơi xuống đầu tiên?Đối với các cấu trúc, đó là thứ tự mà chúng được khai báo: đầu tiên là `one`, sau đó là `two`.
/// Nếu bạn muốn tự mình thử điều này, bạn có thể sửa đổi `HasDrop` ở trên để chứa một số dữ liệu, chẳng hạn như số nguyên, sau đó sử dụng nó trong `println!` bên trong `Drop`.
/// Hành vi này được đảm bảo bởi ngôn ngữ.
///
/// Không giống như đối với cấu trúc, các biến cục bộ được loại bỏ theo thứ tự ngược lại:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Điều này sẽ in
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Vui lòng xem [the reference] để biết các quy tắc đầy đủ.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` và `Drop` là độc quyền
///
/// Bạn không thể triển khai cả [`Copy`] và `Drop` trên cùng một loại.Các loại `Copy` được trình biên dịch sao chép ngầm, khiến rất khó dự đoán khi nào và tần suất các hàm hủy sẽ được thực thi.
///
/// Như vậy, các loại này không thể có hàm hủy.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Thực thi trình hủy cho kiểu này.
    ///
    /// Phương thức này được gọi ngầm định khi giá trị nằm ngoài phạm vi và không thể được gọi một cách rõ ràng (đây là lỗi trình biên dịch [E0040]).
    /// Tuy nhiên, hàm [`mem::drop`] trong prelude có thể được sử dụng để gọi việc triển khai `Drop` của đối số.
    ///
    /// Khi phương thức này được gọi, `self` vẫn chưa được phân bổ.
    /// Điều đó chỉ xảy ra sau khi phương pháp kết thúc.
    /// Nếu không phải như vậy, `self` sẽ là một tài liệu tham khảo lơ lửng.
    ///
    /// # Panics
    ///
    /// Giả sử rằng [`panic!`] sẽ gọi `drop` khi nó mở ra, bất kỳ [`panic!`] nào trong quá trình triển khai `drop` đều có khả năng bị hủy bỏ.
    ///
    /// Lưu ý rằng ngay cả khi panics này, giá trị được coi là bị loại bỏ;
    /// bạn không được gọi lại `drop`.
    /// Điều này thường được trình biên dịch tự động xử lý, nhưng khi sử dụng mã không an toàn, đôi khi có thể xảy ra ngoài ý muốn, đặc biệt là khi sử dụng [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}