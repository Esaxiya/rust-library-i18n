use crate::marker::Unpin;
use crate::pin::Pin;

/// Kết quả của việc khôi phục lại máy phát điện.
///
/// Enum này được trả về từ phương thức `Generator::resume` và chỉ ra các giá trị trả về có thể có của một trình tạo.
/// Hiện tại, điều này tương ứng với điểm tạm dừng (`Yielded`) hoặc điểm kết thúc (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Máy phát điện bị treo với một giá trị.
    ///
    /// Trạng thái này chỉ ra rằng một trình tạo đã bị treo và thường tương ứng với một câu lệnh `yield`.
    /// Giá trị được cung cấp trong biến thể này tương ứng với biểu thức được chuyển đến `yield` và cho phép trình tạo cung cấp giá trị mỗi khi chúng mang lại.
    ///
    ///
    Yielded(Y),

    /// Trình tạo đã hoàn thành với một giá trị trả về.
    ///
    /// Trạng thái này chỉ ra rằng một trình tạo đã hoàn thành việc thực thi với giá trị được cung cấp.
    /// Khi trình tạo đã trả về `Complete`, việc gọi lại `resume` được coi là lỗi của lập trình viên.
    ///
    Complete(R),
}

/// trait được triển khai bởi các loại trình tạo nội dung.
///
/// Trình tạo, còn thường được gọi là coroutines, hiện là một tính năng ngôn ngữ thử nghiệm trong Rust.
/// Các trình tạo [RFC 2033] được thêm vào hiện tại nhằm mục đích chủ yếu cung cấp một khối xây dựng cho cú pháp async/await nhưng có khả năng sẽ mở rộng để cung cấp định nghĩa công thái học cho các trình vòng lặp và các nguyên thủy khác.
///
///
/// Cú pháp và ngữ nghĩa của trình tạo không ổn định và sẽ cần thêm RFC để ổn định.Tuy nhiên, tại thời điểm này, cú pháp giống như hàm đóng:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Có thể tìm thêm tài liệu về máy phát điện trong cuốn sách không ổn định.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Loại giá trị mà trình tạo này mang lại.
    ///
    /// Loại được liên kết này tương ứng với biểu thức `yield` và các giá trị được phép trả về mỗi khi trình tạo kết quả.
    ///
    /// Ví dụ: một trình tạo lặp dưới dạng trình tạo có thể sẽ có kiểu này là `T`, kiểu đang được lặp lại.
    ///
    type Yield;

    /// Loại giá trị mà trình tạo này trả về.
    ///
    /// Điều này tương ứng với kiểu được trả về từ trình tạo bằng câu lệnh `return` hoặc ngầm hiểu là biểu thức cuối cùng của ký tự trình tạo.
    /// Ví dụ: futures sẽ sử dụng nó là `Result<T, E>` vì nó đại diện cho một future đã hoàn thành.
    ///
    ///
    type Return;

    /// Tiếp tục thực thi trình tạo này.
    ///
    /// Hàm này sẽ tiếp tục thực thi trình tạo hoặc bắt đầu thực thi nếu chưa thực thi.
    /// Lệnh gọi này sẽ quay trở lại điểm tạm dừng cuối cùng của trình tạo, tiếp tục thực thi từ `yield` mới nhất.
    /// Trình tạo sẽ tiếp tục thực thi cho đến khi nó sinh ra hoặc trả về, lúc này hàm này sẽ trả về.
    ///
    /// # Giá trị trả lại
    ///
    /// Enum `GeneratorState` được trả về từ hàm này cho biết trạng thái của trình tạo khi trả về.
    /// Nếu biến thể `Yielded` được trả lại thì trình tạo đã đạt đến điểm tạm dừng và một giá trị đã được tạo ra.
    /// Máy phát điện ở trạng thái này có thể hoạt động lại sau đó.
    ///
    /// Nếu `Complete` được trả về thì trình tạo đã hoàn thành hoàn toàn với giá trị được cung cấp.Việc tiếp tục lại trình tạo là không hợp lệ.
    ///
    /// # Panics
    ///
    /// Hàm này có thể panic nếu nó được gọi sau khi biến thể `Complete` đã được trả về trước đó.
    /// Trong khi các ký tự của trình tạo trong ngôn ngữ được đảm bảo với panic khi tiếp tục lại sau `Complete`, điều này không được đảm bảo cho tất cả các triển khai của `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}