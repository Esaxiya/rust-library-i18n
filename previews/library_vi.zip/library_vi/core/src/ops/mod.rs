//! Các toán tử quá tải.
//!
//! Việc triển khai các traits này cho phép bạn quá tải các toán tử nhất định.
//!
//! Một số traits này được nhập bởi prelude, vì vậy chúng có sẵn trong mọi chương trình Rust.Chỉ các toán tử được hỗ trợ bởi traits mới có thể bị quá tải.
//! Ví dụ: toán tử bổ sung (`+`) có thể được nạp chồng thông qua [`Add`] trait, nhưng vì toán tử gán (`=`) không có trait hỗ trợ, không có cách nào để nạp chồng ngữ nghĩa của nó.
//! Ngoài ra, mô-đun này không cung cấp bất kỳ cơ chế nào để tạo toán tử mới.
//! Nếu yêu cầu quá tải không có đặc điểm hoặc toán tử tùy chỉnh, bạn nên xem xét macro hoặc plugin trình biên dịch để mở rộng cú pháp của Rust.
//!
//! Việc triển khai của toán tử traits sẽ không có gì đáng ngạc nhiên trong các ngữ cảnh tương ứng của chúng, hãy ghi nhớ ý nghĩa thông thường của chúng và [operator precedence].
//! Ví dụ: khi triển khai [`Mul`], hoạt động phải có một số điểm tương đồng với phép nhân (và chia sẻ các thuộc tính mong đợi như tính kết hợp).
//!
//! Lưu ý rằng các toán tử `&&` và `||` ngắn mạch, tức là chúng chỉ đánh giá toán hạng thứ hai nếu nó góp phần vào kết quả.Vì hành vi này không được thực thi bởi traits, `&&` và `||` không được hỗ trợ như các toán tử có thể quá tải.
//!
//! Nhiều toán tử lấy toán hạng của họ theo giá trị.Trong các ngữ cảnh không chung chung liên quan đến các kiểu dựng sẵn, đây thường không phải là vấn đề.
//! Tuy nhiên, việc sử dụng các toán tử này trong mã chung, đòi hỏi một số chú ý nếu các giá trị phải được sử dụng lại thay vì để các toán tử sử dụng chúng.Một lựa chọn là thỉnh thoảng sử dụng [`clone`].
//! Một tùy chọn khác là dựa vào các kiểu liên quan để cung cấp các triển khai toán tử bổ sung cho các tài liệu tham khảo.
//! Ví dụ: đối với loại `T` do người dùng xác định được cho là hỗ trợ việc bổ sung, có lẽ nên để cả `T` và `&T` triển khai traits [`Add<T>`][`Add`] và [`Add<&T>`][`Add`] để mã chung có thể được viết mà không cần sao chép.
//!
//!
//! # Examples
//!
//! Ví dụ này tạo một cấu trúc `Point` triển khai [`Add`] và [`Sub`], sau đó thể hiện phép cộng và trừ hai `Điểm`.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Xem tài liệu cho từng trait để biết cách triển khai ví dụ.
//!
//! [`Fn`], [`FnMut`] và [`FnOnce`] traits được thực hiện bởi các kiểu có thể được gọi như các hàm.Lưu ý rằng [`Fn`] lấy `&self`, [`FnMut`] lấy `&mut self` và [`FnOnce`] lấy `self`.
//! Chúng tương ứng với ba loại phương thức có thể được gọi trên một cá thể: gọi theo tham chiếu, gọi theo-có thể thay đổi-tham chiếu và gọi theo giá trị.
//! Việc sử dụng phổ biến nhất của các traits này là hoạt động như các giới hạn đối với các hàm cấp cao hơn lấy các hàm hoặc các bao đóng làm đối số.
//!
//! Lấy [`Fn`] làm tham số:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Lấy [`FnMut`] làm tham số:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Lấy [`FnOnce`] làm tham số:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` sử dụng các biến đã bắt của nó, vì vậy nó không thể được chạy nhiều hơn một lần
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Cố gắng gọi lại `func()` sẽ gây ra lỗi `use of moved value` cho `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` không còn có thể được gọi vào thời điểm này
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;