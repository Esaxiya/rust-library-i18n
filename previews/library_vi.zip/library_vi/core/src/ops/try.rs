/// Một trait để tùy chỉnh hành vi của toán tử `?`.
///
/// Kiểu triển khai `Try` là kiểu có cách chuẩn để xem nó theo phân tách success/failure.
/// trait này cho phép cả hai trích xuất các giá trị thành công hoặc thất bại từ một phiên bản hiện có và tạo một phiên bản mới từ một giá trị thành công hoặc thất bại.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Loại giá trị này khi được xem là thành công.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Loại giá trị này khi được xem là không thành công.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Áp dụng toán tử "?".Trả về `Ok(t)` có nghĩa là quá trình thực thi sẽ tiếp tục bình thường và kết quả của `?` là giá trị `t`.
    /// Việc trả về `Err(e)` có nghĩa là quá trình thực thi phải branch đến phần trong cùng bao bọc `catch` hoặc trả về từ hàm.
    ///
    /// Nếu kết quả `Err(e)` được trả về, giá trị `e` sẽ là "wrapped" trong kiểu trả về của phạm vi bao quanh (chính nó phải triển khai `Try`).
    ///
    /// Cụ thể, giá trị `X::from_error(From::from(e))` được trả về, trong đó `X` là kiểu trả về của hàm bao quanh.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Bao bọc một giá trị lỗi để xây dựng kết quả tổng hợp.
    /// Ví dụ: `Result::Err(x)` và `Result::from_error(x)` là tương đương.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Bao bọc một giá trị OK để xây dựng kết quả tổng hợp.
    /// Ví dụ: `Result::Ok(x)` và `Result::from_ok(x)` là tương đương.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}