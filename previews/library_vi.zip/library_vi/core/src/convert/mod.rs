//! Traits để chuyển đổi giữa các loại.
//!
//! traits trong mô-đun này cung cấp một cách để chuyển đổi từ loại này sang loại khác.
//! Mỗi trait phục vụ một mục đích khác nhau:
//!
//! - Triển khai [`AsRef`] trait để chuyển đổi từ tham chiếu sang tham chiếu giá rẻ
//! - Triển khai [`AsMut`] trait cho các chuyển đổi có thể thay đổi thành có thể thay đổi giá rẻ
//! - Triển khai [`From`] trait để sử dụng các chuyển đổi giá trị thành giá trị
//! - Triển khai [`Into`] trait để sử dụng chuyển đổi giá trị thành giá trị sang các loại bên ngoài crate hiện tại
//! - [`TryFrom`] và [`TryInto`] traits hoạt động giống như [`From`] và [`Into`], nhưng sẽ được triển khai khi quá trình chuyển đổi có thể không thành công.
//!
//! traits trong mô-đun này thường được sử dụng như trait bounds cho các chức năng chung như hỗ trợ các đối số của nhiều loại.Xem tài liệu của từng trait để biết ví dụ.
//!
//! Là một tác giả thư viện, bạn nên luôn thích triển khai [`From<T>`][`From`] hoặc [`TryFrom<T>`][`TryFrom`] hơn là [`Into<U>`][`Into`] hoặc [`TryInto<U>`][`TryInto`], vì [`From`] và [`TryFrom`] cung cấp tính linh hoạt cao hơn và cung cấp các triển khai [`Into`] hoặc [`TryInto`] tương đương miễn phí, nhờ triển khai hàng loạt trong thư viện tiêu chuẩn.
//! Khi nhắm mục tiêu phiên bản trước Rust 1.41, có thể cần phải triển khai [`Into`] hoặc [`TryInto`] trực tiếp khi chuyển đổi sang loại bên ngoài crate hiện tại.
//!
//! # Triển khai chung
//!
//! - [`AsRef`] và [`AsMut`] tự động bỏ qua nếu loại bên trong là tham chiếu
//! - [`From`]`<U>cho T` ngụ ý [`Into`]`</u><T><U>cho U`</u>
//! - [`TryFrom`]`<U>cho T` ngụ ý [`TryInto`]`</u><T><U>cho U`</u>
//! - [`From`] và [`Into`] là phản xạ, có nghĩa là tất cả các loại có thể tự `into` và `from` tự
//!
//! Xem từng trait để biết các ví dụ sử dụng.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Các chức năng nhận dạng.
///
/// Hai điều quan trọng cần lưu ý về chức năng này:
///
/// - Nó không phải lúc nào cũng tương đương với kiểu đóng như `|x| x`, vì kiểu đóng có thể ép `x` thành một kiểu khác.
///
/// - Nó di chuyển đầu vào `x` được chuyển đến hàm.
///
/// Mặc dù có vẻ lạ khi có một hàm chỉ trả về đầu vào, nhưng có một số cách sử dụng thú vị.
///
///
/// # Examples
///
/// Sử dụng `identity` để không làm gì trong một chuỗi các chức năng thú vị khác:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Hãy giả sử rằng việc thêm một cái là một chức năng thú vị.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Sử dụng `identity` làm vỏ cơ sở "do nothing" trong điều kiện:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Làm những điều thú vị hơn ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Sử dụng `identity` để giữ các biến thể `Some` của một trình lặp của `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Được sử dụng để thực hiện chuyển đổi từ tham chiếu sang tham chiếu giá rẻ.
///
/// trait này tương tự như [`AsMut`] được sử dụng để chuyển đổi giữa các tham chiếu có thể thay đổi.
/// Nếu bạn cần thực hiện một chuyển đổi tốn kém, tốt hơn là nên triển khai [`From`] với kiểu `&T` hoặc viết một hàm tùy chỉnh.
///
/// `AsRef` có cùng chữ ký với [`Borrow`], nhưng [`Borrow`] khác ở một số khía cạnh:
///
/// - Không giống như `AsRef`, [`Borrow`] có một lớp phủ cho bất kỳ `T` nào và có thể được sử dụng để chấp nhận một tham chiếu hoặc một giá trị.
/// - [`Borrow`] cũng yêu cầu [`Hash`], [`Eq`] và [`Ord`] đối với giá trị vay phải tương đương với giá trị sở hữu.
/// Vì lý do này, nếu bạn chỉ muốn mượn một trường duy nhất của cấu trúc, bạn có thể triển khai `AsRef`, nhưng không phải [`Borrow`].
///
/// **Note: trait này không được lỗi **.Nếu quá trình chuyển đổi có thể không thành công, hãy sử dụng một phương pháp chuyên dụng trả về [`Option<T>`] hoặc [`Result<T, E>`].
///
/// # Triển khai chung
///
/// - `AsRef` tự động bỏ tham chiếu nếu loại bên trong là tham chiếu hoặc tham chiếu có thể thay đổi (ví dụ: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Bằng cách sử dụng trait bounds, chúng ta có thể chấp nhận các đối số thuộc các kiểu khác nhau miễn là chúng có thể được chuyển đổi thành kiểu `T` được chỉ định.
///
/// Ví dụ: Bằng cách tạo một hàm chung sử dụng `AsRef<str>`, chúng tôi thể hiện rằng chúng tôi muốn chấp nhận tất cả các tham chiếu có thể được chuyển đổi thành [`&str`] như một đối số.
/// Vì cả [`String`] và [`&str`] đều triển khai `AsRef<str>` nên chúng ta có thể chấp nhận cả hai làm đối số đầu vào.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Thực hiện chuyển đổi.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Được sử dụng để thực hiện chuyển đổi tham chiếu có thể thay đổi thành có thể thay đổi giá rẻ.
///
/// trait này tương tự như [`AsRef`] nhưng được sử dụng để chuyển đổi giữa các tham chiếu có thể thay đổi.
/// Nếu bạn cần thực hiện một chuyển đổi tốn kém, tốt hơn là nên triển khai [`From`] với kiểu `&mut T` hoặc viết một hàm tùy chỉnh.
///
/// **Note: trait này không được lỗi **.Nếu quá trình chuyển đổi có thể không thành công, hãy sử dụng một phương pháp chuyên dụng trả về [`Option<T>`] hoặc [`Result<T, E>`].
///
/// # Triển khai chung
///
/// - `AsMut` tự động bỏ tham chiếu nếu kiểu bên trong là tham chiếu có thể thay đổi (ví dụ: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Sử dụng `AsMut` làm trait bound cho một hàm chung, chúng ta có thể chấp nhận tất cả các tham chiếu có thể thay đổi có thể được chuyển đổi thành kiểu `&mut T`.
/// Vì [`Box<T>`] triển khai `AsMut<T>` nên chúng ta có thể viết một hàm `add_one` nhận tất cả các đối số có thể được chuyển đổi thành `&mut u64`.
/// Vì [`Box<T>`] triển khai `AsMut<T>` nên `add_one` cũng chấp nhận các đối số kiểu `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Thực hiện chuyển đổi.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Một chuyển đổi giá trị thành giá trị sử dụng giá trị đầu vào.Ngược lại với [`From`].
///
/// Người ta nên tránh triển khai [`Into`] và thay vào đó thực hiện [`From`].
/// Việc triển khai [`From`] tự động cung cấp một bản triển khai [`Into`] nhờ vào việc triển khai hàng loạt trong thư viện tiêu chuẩn.
///
/// Ưu tiên sử dụng [`Into`] hơn [`From`] khi chỉ định trait bounds trên một hàm chung để đảm bảo rằng các loại chỉ triển khai [`Into`] cũng có thể được sử dụng.
///
/// **Note: trait này không được lỗi **.Nếu quá trình chuyển đổi không thành công, hãy sử dụng [`TryInto`].
///
/// # Triển khai chung
///
/// - [`Từ`]`<T>cho U` ngụ ý `Into<U> for T`
/// - [`Into`] là phản xạ, có nghĩa là `Into<T> for T` được triển khai
///
/// # Triển khai [`Into`] cho các chuyển đổi sang loại bên ngoài trong các phiên bản cũ của Rust
///
/// Trước Rust 1.41, nếu kiểu đích không phải là một phần của crate hiện tại thì bạn không thể triển khai [`From`] trực tiếp.
/// Ví dụ: lấy mã này:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Điều này sẽ không thể biên dịch trong các phiên bản cũ hơn của ngôn ngữ vì các quy tắc mồ côi của Rust từng nghiêm ngặt hơn một chút.
/// Để vượt qua điều này, bạn có thể triển khai [`Into`] trực tiếp:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Điều quan trọng là phải hiểu rằng [`Into`] không cung cấp triển khai [`From`] (như [`From`] thực hiện với [`Into`]).
/// Do đó, bạn nên luôn cố gắng triển khai [`From`] và sau đó quay lại [`Into`] nếu không thể triển khai [`From`].
///
/// # Examples
///
/// [`String`] thực hiện [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Để thể hiện rằng chúng ta muốn một hàm chung nhận tất cả các đối số có thể được chuyển đổi thành một loại `T` được chỉ định, chúng ta có thể sử dụng trait bound của [`Into`]`<T>`.
///
/// Ví dụ: Hàm `is_hello` nhận tất cả các đối số có thể chuyển đổi thành [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Thực hiện chuyển đổi.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Được sử dụng để thực hiện chuyển đổi giá trị thành giá trị trong khi sử dụng giá trị đầu vào.Nó là nghịch đảo của [`Into`].
///
/// Một người nên luôn thích triển khai `From` hơn [`Into`] vì việc triển khai `From` tự động cung cấp cho một người triển khai [`Into`] nhờ triển khai hàng loạt trong thư viện tiêu chuẩn.
///
///
/// Chỉ triển khai [`Into`] khi nhắm mục tiêu phiên bản trước Rust 1.41 và chuyển đổi sang loại bên ngoài crate hiện tại.
/// `From` không thể thực hiện các loại chuyển đổi này trong các phiên bản trước vì các quy tắc mồ côi của Rust.
/// Xem [`Into`] để biết thêm chi tiết.
///
/// Thích sử dụng [`Into`] hơn sử dụng `From` khi chỉ định trait bounds trên một hàm chung.
/// Bằng cách này, các kiểu triển khai trực tiếp [`Into`] cũng có thể được sử dụng làm đối số.
///
/// `From` cũng rất hữu ích khi thực hiện xử lý lỗi.Khi xây dựng một hàm có khả năng bị lỗi, kiểu trả về thường sẽ có dạng `Result<T, E>`.
/// `From` trait đơn giản hóa việc xử lý lỗi bằng cách cho phép một hàm trả về một loại lỗi duy nhất đóng gói nhiều loại lỗi.Xem phần "Examples" và [the book][book] để biết thêm chi tiết.
///
/// **Note: trait này không được lỗi **.Nếu quá trình chuyển đổi không thành công, hãy sử dụng [`TryFrom`].
///
/// # Triển khai chung
///
/// - `From<T> for U` ngụ ý [`Into`]`<U>cho T`</u>
/// - `From` là phản xạ, có nghĩa là `From<T> for T` được triển khai
///
/// # Examples
///
/// [`String`] triển khai `From<&str>`:
///
/// Việc chuyển đổi rõ ràng từ `&str` sang Chuỗi được thực hiện như sau:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Trong khi thực hiện xử lý lỗi, việc triển khai `From` cho loại lỗi của riêng bạn thường rất hữu ích.
/// Bằng cách chuyển đổi các loại lỗi cơ bản thành loại lỗi tùy chỉnh của riêng chúng tôi bao gồm loại lỗi cơ bản, chúng tôi có thể trả về một loại lỗi duy nhất mà không làm mất thông tin về nguyên nhân cơ bản.
/// Toán tử '?' tự động chuyển đổi loại lỗi cơ bản thành loại lỗi tùy chỉnh của chúng tôi bằng cách gọi `Into<CliError>::into` được cung cấp tự động khi triển khai `From`.
/// Sau đó, trình biên dịch sẽ suy ra việc triển khai `Into` nào nên được sử dụng.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Thực hiện chuyển đổi.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Một chuyển đổi đã cố gắng sử dụng `self`, có thể đắt hoặc có thể không.
///
/// Các tác giả thư viện thường không nên trực tiếp triển khai trait này, nhưng nên triển khai [`TryFrom`] trait, mang lại tính linh hoạt cao hơn và cung cấp miễn phí triển khai `TryInto` tương đương, nhờ triển khai hàng loạt trong thư viện tiêu chuẩn.
/// Để biết thêm thông tin về điều này, hãy xem tài liệu dành cho [`Into`].
///
/// # Triển khai `TryInto`
///
/// Điều này gặp phải những hạn chế và lý do tương tự như việc triển khai [`Into`], hãy xem ở đó để biết chi tiết.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Loại được trả về trong trường hợp có lỗi chuyển đổi.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Thực hiện chuyển đổi.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Chuyển đổi loại đơn giản và an toàn có thể không thành công theo cách có kiểm soát trong một số trường hợp.Nó là nghịch đảo của [`TryInto`].
///
/// Điều này rất hữu ích khi bạn đang thực hiện một chuyển đổi kiểu có thể thành công nhỏ nhưng cũng có thể cần xử lý đặc biệt.
/// Ví dụ: không có cách nào để chuyển đổi [`i64`] thành [`i32`] bằng [`From`] trait, bởi vì [`i64`] có thể chứa giá trị mà [`i32`] không thể đại diện và do đó việc chuyển đổi sẽ mất dữ liệu.
///
/// Điều này có thể được xử lý bằng cách cắt bớt [`i64`] thành [`i32`] (về cơ bản là cung cấp mô-đun giá trị của [``i64`]] [`i32::MAX`]) hoặc đơn giản là trả về [`i32::MAX`] hoặc bằng một số phương pháp khác.
/// [`From`] trait được thiết kế để chuyển đổi hoàn hảo, vì vậy `TryFrom` trait thông báo cho lập trình viên khi một chuyển đổi kiểu có thể gặp trục trặc và cho phép họ quyết định cách xử lý.
///
/// # Triển khai chung
///
/// - `TryFrom<T> for U` ngụ ý [`TryInto`]`<U>cho T`</u>
/// - [`try_from`] là phản xạ, có nghĩa là `TryFrom<T> for T` được triển khai và không thể thất bại-kiểu `Error` được liên kết để gọi `T::try_from()` trên giá trị của kiểu `T` là [`Infallible`].
/// Khi loại [`!`] được ổn định [`Infallible`] và [`!`] sẽ tương đương.
///
/// `TryFrom<T>` có thể được thực hiện như sau:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Như được mô tả, [`i32`] triển khai `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Âm thầm cắt ngắn `big_number`, yêu cầu phát hiện và xử lý phần cắt sau thực tế.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Trả về lỗi vì `big_number` quá lớn để vừa với `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Trả về `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Loại được trả về trong trường hợp có lỗi chuyển đổi.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Thực hiện chuyển đổi.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS GENERIC
////////////////////////////////////////////////////////////////////////////////

// Khi nâng lên&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Khi nâng hơn &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): thay thế các lần hiển thị ở trên cho&/&mut bằng một điểm tổng quát hơn sau:
// // Như nâng lên trên Deref
// cấy ghép <D: ?Sized + Deref<Target: AsRef<U>>, U:? Sized> AsRef <U>cho D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut nâng hơn &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): thay thế mô hình ở trên cho &mut bằng mô hình tổng quát hơn sau:
// // AsMut nâng lên trên DerefMut
// cấy ghép <D: ?Sized + Deref<Target: AsMut<U>>, U:? Sized> AsMut <U>cho D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Từ ngụ ý vào
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Từ (và do đó Thành) là phản xạ
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Lưu ý về độ ổn định:** Bộ phận cấy ghép này chưa tồn tại, nhưng chúng tôi là "reserving space" để thêm nó vào future.
/// Xem [rust-lang/rust#64715][#64715] để biết thêm chi tiết.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): thay vào đó thực hiện một bản sửa lỗi có nguyên tắc.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom ngụ ý TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Các chuyển đổi không thể sai về mặt ngữ nghĩa tương đương với các chuyển đổi không thể sai với một loại lỗi không có người ở.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS BÊ TÔNG
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// LOẠI LỖI KHÔNG CÓ LỖI
////////////////////////////////////////////////////////////////////////////////

/// Loại lỗi cho những lỗi không bao giờ có thể xảy ra.
///
/// Vì enum này không có biến thể, một giá trị của loại này không bao giờ có thể thực sự tồn tại.
/// Điều này có thể hữu ích cho các API chung sử dụng [`Result`] và tham số hóa loại lỗi, để chỉ ra rằng kết quả luôn là [`Ok`].
///
/// Ví dụ: [`TryFrom`] trait (chuyển đổi trả về [`Result`]) có triển khai chung cho tất cả các loại có triển khai [`Into`] ngược.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Khả năng tương thích Future
///
/// Enum này có vai trò giống như [the `!`“never”type][never], điều này không ổn định trong phiên bản Rust này.
/// Khi `!` được ổn định, chúng tôi dự định đặt `Infallible` thành một loại bí danh cho nó:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Và cuối cùng không dùng `Infallible` nữa.
///
/// Tuy nhiên, có một trường hợp mà cú pháp `!` có thể được sử dụng trước khi `!` được ổn định như một kiểu chính thức: ở vị trí kiểu trả về của một hàm.
/// Cụ thể, có thể triển khai cho hai loại con trỏ chức năng khác nhau:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Với `Infallible` là một enum, mã này hợp lệ.
/// Tuy nhiên, khi `Infallible` trở thành bí danh cho ctures type, hai ``impl`s sẽ bắt đầu chồng chéo và do đó sẽ không được phép bởi các quy tắc kết hợp trait của ngôn ngữ.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}