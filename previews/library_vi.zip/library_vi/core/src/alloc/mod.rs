//! API cấp phát bộ nhớ

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Lỗi `AllocError` cho biết lỗi phân bổ có thể do cạn kiệt tài nguyên hoặc do điều gì đó sai khi kết hợp các đối số đầu vào đã cho với trình cấp phát này.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (chúng tôi cần điều này cho việc nhập hạ lưu của Lỗi trait)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Việc triển khai `Allocator` có thể phân bổ, phát triển, thu nhỏ và phân bổ các khối dữ liệu tùy ý được mô tả qua [`Layout`][].
///
/// `Allocator` được thiết kế để triển khai trên ZST, tham chiếu hoặc con trỏ thông minh vì không thể di chuyển bộ cấp phát như `MyAlloc([u8; N])` mà không cập nhật con trỏ vào bộ nhớ được cấp phát.
///
/// Không giống như [`GlobalAlloc`][], phân bổ có kích thước bằng 0 được phép trong `Allocator`.
/// Nếu một trình cấp phát cơ bản không hỗ trợ điều này (như jemalloc) hoặc trả về một con trỏ null (chẳng hạn như `libc::malloc`), điều này phải được triển khai.
///
/// ### Bộ nhớ được cấp phát hiện tại
///
/// Một số phương pháp yêu cầu khối bộ nhớ *hiện được cấp phát* thông qua bộ cấp phát.Điều này có nghĩa rằng:
///
/// * địa chỉ bắt đầu cho khối bộ nhớ đó trước đó đã được trả về bởi [`allocate`], [`grow`] hoặc [`shrink`] và
///
/// * khối bộ nhớ sau đó đã không được phân bổ theo thỏa thuận, trong đó các khối hoặc được phân bổ trực tiếp bằng cách chuyển cho [`deallocate`] hoặc được thay đổi bằng cách chuyển cho [`grow`] hoặc [`shrink`] trả về `Ok`.
///
/// Nếu `grow` hoặc `shrink` trả về `Err`, thì con trỏ đã qua vẫn hợp lệ.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Bộ nhớ phù hợp
///
/// Một số phương thức yêu cầu bố cục *vừa với* một khối bộ nhớ.
/// Ý nghĩa của một bố cục đối với "fit" một khối bộ nhớ (hoặc tương đương, đối với một khối bộ nhớ đối với một bố cục "fit") là các điều kiện sau phải có:
///
/// * Khối phải được phân bổ với cùng một căn chỉnh như [`layout.align()`] và
///
/// * [`layout.size()`] được cung cấp phải nằm trong phạm vi `min ..= max`, trong đó:
///   - `min` là kích thước của bố cục được sử dụng gần đây nhất để phân bổ khối và
///   - `max` là kích thước thực tế mới nhất được trả về từ [`allocate`], [`grow`] hoặc [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Các khối bộ nhớ được trả về từ bộ cấp phát phải trỏ đến bộ nhớ hợp lệ và giữ nguyên giá trị của chúng cho đến khi phiên bản và tất cả các bản sao của nó bị loại bỏ,
///
/// * sao chép hoặc di chuyển bộ cấp phát không được làm mất hiệu lực các khối bộ nhớ được trả về từ bộ cấp phát này.Trình phân bổ nhân bản phải hoạt động giống như cùng một trình phân bổ và
///
/// * bất kỳ con trỏ nào đến khối bộ nhớ là [*currently allocated*] có thể được chuyển tới bất kỳ phương thức nào khác của bộ cấp phát.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Cố gắng cấp phát một khối bộ nhớ.
    ///
    /// Khi thành công, trả về [`NonNull<[u8]>`][NonNull] đáp ứng các đảm bảo về kích thước và sự liên kết của `layout`.
    ///
    /// Khối được trả về có thể có kích thước lớn hơn kích thước được chỉ định bởi `layout.size()` và có thể có hoặc không khởi tạo nội dung của nó.
    ///
    /// # Errors
    ///
    /// Việc trả về `Err` chỉ ra rằng bộ nhớ đã hết hoặc `layout` không đáp ứng các ràng buộc về kích thước hoặc căn chỉnh của bộ cấp phát.
    ///
    /// Việc triển khai được khuyến khích trả lại `Err` khi cạn kiệt bộ nhớ thay vì hoảng sợ hoặc hủy bỏ, nhưng đây không phải là một yêu cầu nghiêm ngặt.
    /// (Cụ thể: là *hợp pháp* để triển khai trait này trên đỉnh một thư viện cấp phát gốc cơ bản bị hủy bỏ do cạn kiệt bộ nhớ.)
    ///
    /// Khách hàng muốn hủy bỏ việc tính toán để giải quyết lỗi phân bổ được khuyến khích gọi hàm [`handle_alloc_error`], thay vì gọi trực tiếp `panic!` hoặc tương tự.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Hoạt động giống như `allocate`, nhưng cũng đảm bảo rằng bộ nhớ trả về không được khởi tạo.
    ///
    /// # Errors
    ///
    /// Việc trả về `Err` chỉ ra rằng bộ nhớ đã hết hoặc `layout` không đáp ứng các ràng buộc về kích thước hoặc căn chỉnh của bộ cấp phát.
    ///
    /// Việc triển khai được khuyến khích trả lại `Err` khi cạn kiệt bộ nhớ thay vì hoảng sợ hoặc hủy bỏ, nhưng đây không phải là một yêu cầu nghiêm ngặt.
    /// (Cụ thể: là *hợp pháp* để triển khai trait này trên đỉnh một thư viện cấp phát gốc cơ bản bị hủy bỏ do cạn kiệt bộ nhớ.)
    ///
    /// Khách hàng muốn hủy bỏ việc tính toán để giải quyết lỗi phân bổ được khuyến khích gọi hàm [`handle_alloc_error`], thay vì gọi trực tiếp `panic!` hoặc tương tự.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // AN TOÀN: `alloc` trả về khối bộ nhớ hợp lệ
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Phân bổ bộ nhớ được tham chiếu bởi `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` phải biểu thị một khối bộ nhớ [*currently allocated*] thông qua bộ cấp phát này, và
    /// * `layout` phải [*fit*] khối bộ nhớ đó.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Cố gắng mở rộng khối bộ nhớ.
    ///
    /// Trả về [`NonNull<[u8]>`][NonNull] mới chứa một con trỏ và kích thước thực của bộ nhớ được cấp phát.Con trỏ thích hợp để giữ dữ liệu được mô tả bởi `new_layout`.
    /// Để thực hiện điều này, trình phân bổ có thể mở rộng phân bổ được tham chiếu bởi `ptr` để phù hợp với bố cục mới.
    ///
    /// Nếu điều này trả về `Ok`, thì quyền sở hữu khối bộ nhớ được tham chiếu bởi `ptr` đã được chuyển cho bộ cấp phát này.
    /// Bộ nhớ có thể đã được giải phóng hoặc chưa được giải phóng, và nên được coi là không sử dụng được trừ khi nó được chuyển trở lại người gọi một lần nữa thông qua giá trị trả về của phương thức này.
    ///
    /// Nếu phương thức này trả về `Err`, thì quyền sở hữu khối bộ nhớ đã không được chuyển cho bộ cấp phát này và nội dung của khối bộ nhớ không bị thay đổi.
    ///
    /// # Safety
    ///
    /// * `ptr` phải biểu thị một khối bộ nhớ [*currently allocated*] thông qua bộ cấp phát này.
    /// * `old_layout` phải [*fit*] khối bộ nhớ đó (Đối số `new_layout` không cần phù hợp với nó.).
    /// * `new_layout.size()` phải lớn hơn hoặc bằng `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Trả về `Err` nếu bố cục mới không đáp ứng các ràng buộc về kích thước của trình phân bổ và căn chỉnh của trình phân bổ hoặc nếu việc phát triển không thành công.
    ///
    /// Việc triển khai được khuyến khích trả lại `Err` khi cạn kiệt bộ nhớ thay vì hoảng sợ hoặc hủy bỏ, nhưng đây không phải là một yêu cầu nghiêm ngặt.
    /// (Cụ thể: là *hợp pháp* để triển khai trait này trên đỉnh một thư viện cấp phát gốc cơ bản bị hủy bỏ do cạn kiệt bộ nhớ.)
    ///
    /// Khách hàng muốn hủy bỏ việc tính toán để giải quyết lỗi phân bổ được khuyến khích gọi hàm [`handle_alloc_error`], thay vì gọi trực tiếp `panic!` hoặc tương tự.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // AN TOÀN: vì `new_layout.size()` phải lớn hơn hoặc bằng
        // `old_layout.size()`, cả cấp phát bộ nhớ cũ và mới đều hợp lệ để đọc và ghi đối với các byte `old_layout.size()`.
        // Ngoài ra, vì phân bổ cũ chưa được phân bổ, nó không thể chồng chéo `new_ptr`.
        // Do đó, cuộc gọi đến `copy_nonoverlapping` là an toàn.
        // Người gọi phải tuân theo hợp đồng an toàn cho `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Hoạt động giống như `grow`, nhưng cũng đảm bảo rằng nội dung mới được đặt thành 0 trước khi được trả lại.
    ///
    /// Khối bộ nhớ sẽ chứa các nội dung sau sau khi gọi thành công tới
    /// `grow_zeroed`:
    ///   * Các byte `0..old_layout.size()` được giữ nguyên từ phân bổ ban đầu.
    ///   * Các byte `old_layout.size()..old_size` sẽ được giữ nguyên hoặc bằng không, tùy thuộc vào việc triển khai trình cấp phát.
    ///   `old_size` đề cập đến kích thước của khối bộ nhớ trước cuộc gọi `grow_zeroed`, có thể lớn hơn kích thước được yêu cầu ban đầu khi nó được cấp phát.
    ///   * Các byte `old_size..new_size` được làm bằng 0.`new_size` đề cập đến kích thước của khối bộ nhớ được trả về bởi lệnh gọi `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` phải biểu thị một khối bộ nhớ [*currently allocated*] thông qua bộ cấp phát này.
    /// * `old_layout` phải [*fit*] khối bộ nhớ đó (Đối số `new_layout` không cần phù hợp với nó.).
    /// * `new_layout.size()` phải lớn hơn hoặc bằng `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Trả về `Err` nếu bố cục mới không đáp ứng các ràng buộc về kích thước của trình phân bổ và căn chỉnh của trình phân bổ hoặc nếu việc phát triển không thành công.
    ///
    /// Việc triển khai được khuyến khích trả lại `Err` khi cạn kiệt bộ nhớ thay vì hoảng sợ hoặc hủy bỏ, nhưng đây không phải là một yêu cầu nghiêm ngặt.
    /// (Cụ thể: là *hợp pháp* để triển khai trait này trên đỉnh một thư viện cấp phát gốc cơ bản bị hủy bỏ do cạn kiệt bộ nhớ.)
    ///
    /// Khách hàng muốn hủy bỏ việc tính toán để giải quyết lỗi phân bổ được khuyến khích gọi hàm [`handle_alloc_error`], thay vì gọi trực tiếp `panic!` hoặc tương tự.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // AN TOÀN: vì `new_layout.size()` phải lớn hơn hoặc bằng
        // `old_layout.size()`, cả cấp phát bộ nhớ cũ và mới đều hợp lệ để đọc và ghi đối với các byte `old_layout.size()`.
        // Ngoài ra, vì phân bổ cũ chưa được phân bổ, nó không thể chồng chéo `new_ptr`.
        // Do đó, cuộc gọi đến `copy_nonoverlapping` là an toàn.
        // Người gọi phải tuân theo hợp đồng an toàn cho `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Cố gắng thu nhỏ khối bộ nhớ.
    ///
    /// Trả về [`NonNull<[u8]>`][NonNull] mới chứa một con trỏ và kích thước thực của bộ nhớ được cấp phát.Con trỏ thích hợp để giữ dữ liệu được mô tả bởi `new_layout`.
    /// Để thực hiện điều này, trình phân bổ có thể thu nhỏ phân bổ được tham chiếu bởi `ptr` để phù hợp với bố cục mới.
    ///
    /// Nếu điều này trả về `Ok`, thì quyền sở hữu khối bộ nhớ được tham chiếu bởi `ptr` đã được chuyển cho bộ cấp phát này.
    /// Bộ nhớ có thể đã được giải phóng hoặc chưa được giải phóng, và nên được coi là không sử dụng được trừ khi nó được chuyển trở lại người gọi một lần nữa thông qua giá trị trả về của phương thức này.
    ///
    /// Nếu phương thức này trả về `Err`, thì quyền sở hữu khối bộ nhớ đã không được chuyển cho bộ cấp phát này và nội dung của khối bộ nhớ không bị thay đổi.
    ///
    /// # Safety
    ///
    /// * `ptr` phải biểu thị một khối bộ nhớ [*currently allocated*] thông qua bộ cấp phát này.
    /// * `old_layout` phải [*fit*] khối bộ nhớ đó (Đối số `new_layout` không cần phù hợp với nó.).
    /// * `new_layout.size()` phải nhỏ hơn hoặc bằng `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Trả về `Err` nếu bố cục mới không đáp ứng các ràng buộc về kích thước của bộ cấp phát và căn chỉnh của bộ cấp phát hoặc nếu việc thu nhỏ không thành công.
    ///
    /// Việc triển khai được khuyến khích trả lại `Err` khi cạn kiệt bộ nhớ thay vì hoảng sợ hoặc hủy bỏ, nhưng đây không phải là một yêu cầu nghiêm ngặt.
    /// (Cụ thể: là *hợp pháp* để triển khai trait này trên đỉnh một thư viện cấp phát gốc cơ bản bị hủy bỏ do cạn kiệt bộ nhớ.)
    ///
    /// Khách hàng muốn hủy bỏ việc tính toán để giải quyết lỗi phân bổ được khuyến khích gọi hàm [`handle_alloc_error`], thay vì gọi trực tiếp `panic!` hoặc tương tự.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // AN TOÀN: vì `new_layout.size()` phải thấp hơn hoặc bằng
        // `old_layout.size()`, cả cấp phát bộ nhớ cũ và mới đều hợp lệ để đọc và ghi cho các byte `new_layout.size()`.
        // Ngoài ra, vì phân bổ cũ chưa được phân bổ, nó không thể chồng chéo `new_ptr`.
        // Do đó, cuộc gọi đến `copy_nonoverlapping` là an toàn.
        // Người gọi phải tuân theo hợp đồng an toàn cho `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Tạo bộ điều hợp "by reference" cho phiên bản `Allocator` này.
    ///
    /// Bộ điều hợp được trả lại cũng triển khai `Allocator` và sẽ chỉ đơn giản là mượn cái này.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // AN TOÀN: hợp đồng an toàn phải được người gọi tuân thủ
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // AN TOÀN: hợp đồng an toàn phải được người gọi tuân thủ
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // AN TOÀN: hợp đồng an toàn phải được người gọi tuân thủ
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // AN TOÀN: hợp đồng an toàn phải được người gọi tuân thủ
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}