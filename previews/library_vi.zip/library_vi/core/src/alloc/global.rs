use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Một trình cấp phát bộ nhớ có thể được đăng ký làm mặc định của thư viện tiêu chuẩn thông qua thuộc tính `#[global_allocator]`.
///
/// Một số phương pháp yêu cầu khối bộ nhớ *hiện được cấp phát* thông qua bộ cấp phát.Điều này có nghĩa rằng:
///
/// * địa chỉ bắt đầu cho khối bộ nhớ đó trước đó đã được trả về bởi một lệnh gọi trước đó tới một phương thức cấp phát chẳng hạn như `alloc`, và
///
/// * khối bộ nhớ sau đó đã không được phân bổ lại, trong đó các khối được phân bổ bằng cách được chuyển cho một phương thức phân bổ như `dealloc` hoặc bằng cách được chuyển cho một phương thức phân bổ lại trả về một con trỏ không null.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// `GlobalAlloc` trait là `unsafe` trait vì một số lý do và người triển khai phải đảm bảo rằng họ tuân thủ các hợp đồng sau:
///
/// * Đó là hành vi không xác định nếu các nhà phân bổ toàn cầu thả lỏng.Hạn chế này có thể được dỡ bỏ trong future, nhưng hiện tại panic từ bất kỳ chức năng nào trong số này có thể dẫn đến mất an toàn bộ nhớ.
///
/// * `Layout` các truy vấn và tính toán nói chung phải đúng.Người gọi trait này được phép dựa vào các hợp đồng được xác định theo từng phương pháp và người thực hiện phải đảm bảo các hợp đồng đó vẫn đúng.
///
/// * Bạn có thể không dựa vào phân bổ thực sự đang xảy ra, ngay cả khi có phân bổ heap rõ ràng trong nguồn.
/// Trình tối ưu hóa có thể phát hiện các phân bổ không sử dụng mà nó có thể loại bỏ hoàn toàn hoặc di chuyển vào ngăn xếp và do đó không bao giờ gọi trình phân bổ.
/// Trình tối ưu hóa có thể giả định thêm rằng phân bổ là không thể sai, vì vậy mã đã từng bị lỗi do trình phân bổ không thành công giờ đây có thể đột nhiên hoạt động vì trình tối ưu hóa hoạt động xung quanh nhu cầu phân bổ.
/// Cụ thể hơn, ví dụ mã sau đây là không rõ ràng, bất kể liệu trình phân bổ tùy chỉnh của bạn có cho phép đếm bao nhiêu phân bổ đã xảy ra hay không.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Lưu ý rằng các tối ưu hóa được đề cập ở trên không phải là tối ưu hóa duy nhất có thể được áp dụng.Nói chung, bạn có thể không dựa vào việc phân bổ đống xảy ra nếu chúng có thể được loại bỏ mà không thay đổi hành vi của chương trình.
///   Việc phân bổ có xảy ra hay không không phải là một phần của hành vi chương trình, ngay cả khi nó có thể được phát hiện thông qua một trình cấp phát theo dõi phân bổ bằng cách in hoặc có các tác dụng phụ.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Phân bổ bộ nhớ như được mô tả bởi `layout` đã cho.
    ///
    /// Trả về một con trỏ đến bộ nhớ mới được cấp phát hoặc null để chỉ ra lỗi cấp phát.
    ///
    /// # Safety
    ///
    /// Chức năng này không an toàn vì hành vi không xác định có thể dẫn đến nếu người gọi không đảm bảo rằng `layout` có kích thước khác 0.
    ///
    /// (Các đường dẫn con của tiện ích mở rộng có thể cung cấp các giới hạn cụ thể hơn về hành vi, ví dụ: đảm bảo địa chỉ trạm gác hoặc con trỏ rỗng để phản hồi yêu cầu phân bổ kích thước bằng không.)
    ///
    /// Khối bộ nhớ được cấp phát có thể được khởi tạo hoặc không.
    ///
    /// # Errors
    ///
    /// Trả về một con trỏ null chỉ ra rằng bộ nhớ đã hết hoặc `layout` không đáp ứng các ràng buộc về kích thước hoặc căn chỉnh của bộ cấp phát này.
    ///
    /// Việc triển khai được khuyến khích trả về null khi cạn kiệt bộ nhớ hơn là hủy bỏ, nhưng đây không phải là một yêu cầu nghiêm ngặt.
    /// (Cụ thể: là *hợp pháp* để triển khai trait này trên đỉnh một thư viện cấp phát gốc cơ bản bị hủy bỏ do cạn kiệt bộ nhớ.)
    ///
    /// Khách hàng muốn hủy bỏ việc tính toán để giải quyết lỗi phân bổ được khuyến khích gọi hàm [`handle_alloc_error`], thay vì gọi trực tiếp `panic!` hoặc tương tự.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Phân bổ khối bộ nhớ tại con trỏ `ptr` đã cho với `layout` đã cho.
    ///
    /// # Safety
    ///
    /// Chức năng này không an toàn vì hành vi không xác định có thể dẫn đến nếu người gọi không đảm bảo tất cả những điều sau:
    ///
    ///
    /// * `ptr` phải biểu thị một khối bộ nhớ hiện được cấp phát qua bộ cấp phát này,
    ///
    /// * `layout` phải là cùng một bố cục đã được sử dụng để cấp phát khối bộ nhớ đó.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Hoạt động giống như `alloc`, nhưng cũng đảm bảo rằng nội dung được đặt thành 0 trước khi được trả lại.
    ///
    /// # Safety
    ///
    /// Chức năng này không an toàn vì những lý do tương tự như `alloc`.
    /// Tuy nhiên, khối bộ nhớ được cấp phát được đảm bảo sẽ được khởi tạo.
    ///
    /// # Errors
    ///
    /// Trả về một con trỏ null chỉ ra rằng bộ nhớ đã hết hoặc `layout` không đáp ứng các ràng buộc về kích thước hoặc căn chỉnh của bộ cấp phát, giống như trong `alloc`.
    ///
    /// Khách hàng muốn hủy bỏ việc tính toán để giải quyết lỗi phân bổ được khuyến khích gọi hàm [`handle_alloc_error`], thay vì gọi trực tiếp `panic!` hoặc tương tự.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // AN TOÀN: hợp đồng an toàn cho `alloc` phải được người gọi tuân thủ.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // AN TOÀN: khi phân bổ thành công, khu vực từ `ptr`
            // có kích thước `size` được đảm bảo là hợp lệ để ghi.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Thu hẹp hoặc tăng một khối bộ nhớ cho `new_size` nhất định.
    /// Khối được mô tả bởi con trỏ `ptr` và `layout` đã cho.
    ///
    /// Nếu điều này trả về một con trỏ không null, thì quyền sở hữu khối bộ nhớ được tham chiếu bởi `ptr` đã được chuyển cho bộ cấp phát này.
    /// Bộ nhớ có thể đã được phân bổ hoặc chưa được phân bổ và nên được coi là không sử dụng được (tất nhiên là trừ khi nó được chuyển trở lại người gọi một lần nữa thông qua giá trị trả về của phương thức này).
    /// Khối bộ nhớ mới được cấp phát với `layout`, nhưng với `size` được cập nhật lên `new_size`.
    /// Bố cục mới này sẽ được sử dụng khi phân bổ khối bộ nhớ mới với `dealloc`.
    /// Phạm vi `0..min(layout.size(), new_size) `của khối bộ nhớ mới được đảm bảo có cùng giá trị với khối ban đầu.
    ///
    /// Nếu phương thức này trả về null, thì quyền sở hữu của khối bộ nhớ đã không được chuyển cho bộ cấp phát này và nội dung của khối bộ nhớ không bị thay đổi.
    ///
    /// # Safety
    ///
    /// Chức năng này không an toàn vì hành vi không xác định có thể dẫn đến nếu người gọi không đảm bảo tất cả những điều sau:
    ///
    /// * `ptr` hiện phải được phân bổ thông qua trình phân bổ này,
    ///
    /// * `layout` phải là cùng một bố cục đã được sử dụng để cấp phát khối bộ nhớ đó,
    ///
    /// * `new_size` phải lớn hơn 0.
    ///
    /// * `new_size`, khi làm tròn lên bội số gần nhất của `layout.align()`, không được tràn (nghĩa là giá trị làm tròn phải nhỏ hơn `usize::MAX`).
    ///
    /// (Các đường dẫn con của tiện ích mở rộng có thể cung cấp các giới hạn cụ thể hơn về hành vi, ví dụ: đảm bảo địa chỉ trạm gác hoặc con trỏ rỗng để phản hồi yêu cầu phân bổ kích thước bằng không.)
    ///
    /// # Errors
    ///
    /// Trả về null nếu bố cục mới không đáp ứng các ràng buộc về kích thước và căn chỉnh của trình cấp phát hoặc nếu việc phân bổ lại không thành công.
    ///
    /// Việc triển khai được khuyến khích trả về giá trị rỗng khi cạn kiệt bộ nhớ thay vì hoảng sợ hoặc hủy bỏ, nhưng đây không phải là một yêu cầu nghiêm ngặt.
    /// (Cụ thể: là *hợp pháp* để triển khai trait này trên đỉnh một thư viện cấp phát gốc cơ bản bị hủy bỏ do cạn kiệt bộ nhớ.)
    ///
    /// Khách hàng muốn hủy bỏ tính toán để giải quyết lỗi phân bổ lại được khuyến khích gọi hàm [`handle_alloc_error`], thay vì gọi trực tiếp `panic!` hoặc tương tự.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // AN TOÀN: người gọi phải đảm bảo rằng `new_size` không bị tràn.
        // `layout.align()` đến từ `Layout` và do đó được đảm bảo là hợp lệ.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // AN TOÀN: người gọi phải đảm bảo rằng `new_layout` lớn hơn 0.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // AN TOÀN: khối được cấp phát trước đó không được chồng lên khối mới được cấp phát.
            // Người gọi phải tuân theo hợp đồng an toàn cho `dealloc`.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}