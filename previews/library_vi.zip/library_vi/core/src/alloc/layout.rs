use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Mặc dù chức năng này được sử dụng ở một nơi và việc triển khai nó có thể được nội tuyến, nhưng những nỗ lực trước đây để làm như vậy đã khiến rustc chậm hơn:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Bố cục của một khối bộ nhớ.
///
/// Một phiên bản của `Layout` mô tả một bố cục bộ nhớ cụ thể.
/// Bạn xây dựng một `Layout` làm đầu vào để cung cấp cho người cấp phát.
///
/// Tất cả các bố cục đều có kích thước được liên kết và căn chỉnh theo sức mạnh của hai.
///
/// (Lưu ý rằng bố cục *không* bắt buộc phải có kích thước khác 0, mặc dù `GlobalAlloc` yêu cầu tất cả các yêu cầu bộ nhớ có kích thước khác 0.
/// Người gọi phải đảm bảo đáp ứng các điều kiện như thế này, sử dụng các trình phân bổ cụ thể với các yêu cầu lỏng hơn hoặc sử dụng giao diện `Allocator` khoan dung hơn.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // kích thước của khối bộ nhớ được yêu cầu, được đo bằng byte.
    size_: usize,

    // căn chỉnh của khối bộ nhớ được yêu cầu, được đo bằng byte.
    // chúng tôi đảm bảo rằng đây luôn là sức mạnh của hai vì API như `posix_memalign` yêu cầu nó và đó là một ràng buộc hợp lý để áp đặt lên các trình tạo Bố cục.
    //
    //
    // (Tuy nhiên, chúng tôi không yêu cầu tương tự như `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Tạo `Layout` từ `size` và `align` đã cho hoặc trả về `LayoutError` nếu bất kỳ điều kiện nào sau đây không được đáp ứng:
    ///
    /// * `align` không được bằng 0,
    ///
    /// * `align` phải là một lũy thừa của hai,
    ///
    /// * `size`, khi làm tròn lên bội số gần nhất của `align`, không được tràn (nghĩa là giá trị làm tròn phải nhỏ hơn hoặc bằng `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (lũy thừa của hai ngụ ý căn chỉnh!=0)

        // Kích thước làm tròn lên là:
        //   size_rounded_up=(size + align, 1)&! (align, 1);
        //
        // Từ phía trên, chúng tôi biết rằng căn chỉnh!=0.
        // Nếu việc thêm (căn chỉnh, 1) không bị tràn thì làm tròn số là được.
        //
        // Ngược lại,&-masking with! (Align, 1) sẽ chỉ trừ đi các bit bậc thấp.
        // Vì vậy, nếu xảy ra tràn với tổng,&-mask không thể trừ đủ để hoàn tác tràn đó.
        //
        //
        // Ở trên ngụ ý rằng việc kiểm tra tràn tổng là cần thiết và đủ.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // AN TOÀN: các điều kiện cho `from_size_align_unchecked` đã được
        // đã kiểm tra ở trên.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Tạo một bố cục, bỏ qua tất cả các bước kiểm tra.
    ///
    /// # Safety
    ///
    /// Chức năng này không an toàn vì nó không xác minh các điều kiện tiên quyết từ [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // AN TOÀN: người gọi phải đảm bảo rằng `align` lớn hơn 0.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Kích thước tối thiểu tính bằng byte cho khối bộ nhớ của bố cục này.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Căn chỉnh byte tối thiểu cho một khối bộ nhớ của bố cục này.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Tạo `Layout` phù hợp để giữ giá trị của loại `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // AN TOÀN: căn chỉnh được đảm bảo bởi Rust là lũy thừa của hai và
        // kết hợp kích thước + căn chỉnh được đảm bảo phù hợp với không gian địa chỉ của chúng tôi.
        // Do đó, hãy sử dụng hàm tạo không được chọn ở đây để tránh chèn mã panics nếu nó không được tối ưu hóa đủ tốt.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Tạo bố cục mô tả một bản ghi có thể được sử dụng để phân bổ cấu trúc hỗ trợ cho `T` (có thể là trait hoặc kiểu không có kích thước khác như một lát cắt).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // AN TOÀN: xem lý do trong `new` để biết lý do tại sao điều này đang sử dụng biến thể không an toàn
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Tạo bố cục mô tả một bản ghi có thể được sử dụng để phân bổ cấu trúc hỗ trợ cho `T` (có thể là trait hoặc kiểu không có kích thước khác như một lát cắt).
    ///
    /// # Safety
    ///
    /// Chức năng này chỉ an toàn để gọi nếu các điều kiện sau đây được giữ nguyên:
    ///
    /// - Nếu `T` là `Sized`, chức năng này luôn an toàn để gọi.
    /// - Nếu đuôi chưa được kích thước của `T` là:
    ///     - a [slice], thì độ dài của đuôi lát cắt phải là một số nguyên phức tạp và kích thước của *toàn bộ giá trị*(độ dài đuôi động + tiền tố có kích thước tĩnh) phải vừa với `isize`.
    ///     - [trait object], thì phần vtable của con trỏ phải trỏ đến vtable hợp lệ cho loại `T` có được bằng cách giải mã kích thước và kích thước của *toàn bộ giá trị*(chiều dài đuôi động + tiền tố có kích thước tĩnh) phải vừa với `isize`.
    ///
    ///     - một (unstable) [extern type], thì hàm này luôn an toàn để gọi, nhưng panic có thể trả về giá trị sai, vì không xác định được cách bố trí của kiểu extern.
    ///     Đây là hành vi tương tự như [`Layout::for_value`] trên tham chiếu đến đuôi kiểu extern.
    ///     - nếu không, nó không được phép gọi hàm này một cách thận trọng.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // AN TOÀN: chúng tôi chuyển các điều kiện tiên quyết của các chức năng này cho người gọi
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // AN TOÀN: xem lý do trong `new` để biết lý do tại sao điều này đang sử dụng biến thể không an toàn
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Tạo một `NonNull` lơ lửng, nhưng được căn chỉnh tốt cho Bố cục này.
    ///
    /// Lưu ý rằng giá trị con trỏ có thể đại diện cho một con trỏ hợp lệ, có nghĩa là giá trị này không được sử dụng như một giá trị sentinel "not yet initialized".
    /// Các kiểu phân bổ lười biếng phải theo dõi quá trình khởi tạo bằng một số phương tiện khác.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // AN TOÀN: căn chỉnh được đảm bảo là khác 0
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Tạo bố cục mô tả bản ghi có thể giữ một giá trị của cùng một bố cục như `self`, nhưng giá trị đó cũng được căn chỉnh để căn chỉnh `align` (tính bằng byte).
    ///
    ///
    /// Nếu `self` đã đáp ứng căn chỉnh theo quy định, thì trả về `self`.
    ///
    /// Lưu ý rằng phương pháp này không thêm bất kỳ khoảng đệm nào vào kích thước tổng thể, bất kể bố cục được trả về có căn chỉnh khác hay không.
    /// Nói cách khác, nếu `K` có kích thước 16, thì `K.align_to(32)` sẽ *vẫn* có kích thước 16.
    ///
    /// Trả về lỗi nếu kết hợp `self.size()` và `align` đã cho vi phạm các điều kiện được liệt kê trong [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Trả về số lượng vùng đệm mà chúng ta phải chèn sau `self` để đảm bảo rằng địa chỉ sau sẽ thỏa mãn `align` (tính bằng byte).
    ///
    /// ví dụ: nếu `self.size()` là 9, thì `self.padding_needed_for(4)` trả về 3, vì đó là số byte đệm tối thiểu cần thiết để có được địa chỉ 4 căn (giả sử rằng khối bộ nhớ tương ứng bắt đầu ở địa chỉ 4 căn).
    ///
    ///
    /// Giá trị trả về của hàm này không có ý nghĩa nếu `align` không phải là lũy thừa của hai.
    ///
    /// Lưu ý rằng tiện ích của giá trị trả về yêu cầu `align` nhỏ hơn hoặc bằng sự liên kết của địa chỉ bắt đầu cho toàn bộ khối bộ nhớ được cấp phát.Một cách để đáp ứng ràng buộc này là đảm bảo `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Giá trị làm tròn lên là:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // và sau đó chúng tôi trả lại sự khác biệt về phần đệm: `len_rounded_up - len`.
        //
        // Chúng tôi sử dụng số học mô-đun trong suốt:
        //
        // 1. align được đảm bảo là> 0, vì vậy align, 1 luôn hợp lệ.
        //
        // 2.
        // `len + align - 1` có thể tràn nhiều nhất là `align - 1`, vì vậy&-mask với `!(align - 1)` sẽ đảm bảo rằng trong trường hợp tràn, bản thân `len_rounded_up` sẽ bằng 0.
        //
        //    Do đó, phần đệm được trả về, khi được thêm vào `len`, mang lại giá trị 0, thỏa mãn đáng kể sự liên kết `align`.
        //
        // (Tất nhiên, việc cố gắng cấp phát các khối bộ nhớ có kích thước và phần đệm tràn theo cách trên sẽ khiến trình cấp phát phát sinh lỗi.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Tạo bố cục bằng cách làm tròn kích thước của bố cục này lên đến bội số căn chỉnh của bố cục.
    ///
    ///
    /// Điều này tương đương với việc thêm kết quả của `padding_needed_for` vào kích thước hiện tại của bố cục.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Điều này không thể tràn.Trích dẫn từ bất biến của Bố cục:
        // > `size`, khi làm tròn đến bội số gần nhất của `align`,
        // > không được tràn (nghĩa là giá trị làm tròn phải nhỏ hơn
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Tạo bố cục mô tả bản ghi cho các phiên bản `n` của `self`, với một lượng đệm phù hợp giữa mỗi phiên bản để đảm bảo rằng mỗi phiên bản được cung cấp kích thước và căn chỉnh được yêu cầu.
    /// Khi thành công, trả về `(k, offs)` trong đó `k` là bố cục của mảng và `offs` là khoảng cách giữa điểm bắt đầu của mỗi phần tử trong mảng.
    ///
    /// Khi tràn số học, trả về `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Điều này không thể tràn.Trích dẫn từ bất biến của Bố cục:
        // > `size`, khi làm tròn đến bội số gần nhất của `align`,
        // > không được tràn (nghĩa là giá trị làm tròn phải nhỏ hơn
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // AN TOÀN: self.align đã được biết là hợp lệ và phân bổ_size đã được
        // đã độn rồi.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Tạo bố cục mô tả bản ghi cho `self` theo sau là `next`, bao gồm bất kỳ phần đệm cần thiết nào để đảm bảo rằng `next` sẽ được căn chỉnh chính xác, nhưng *không có phần đệm ở cuối*.
    ///
    /// Để khớp với bố cục biểu diễn C `repr(C)`, bạn nên gọi `pad_to_align` sau khi mở rộng bố cục với tất cả các trường.
    /// (Không có cách nào để khớp với bố cục biểu diễn Rust mặc định `repr(Rust)`, as it is unspecified.)
    ///
    /// Lưu ý rằng sự liên kết của bố cục kết quả sẽ là mức tối đa của bố cục `self` và `next`, để đảm bảo sự liên kết của cả hai phần.
    ///
    /// Trả về `Ok((k, offset))`, trong đó `k` là bố cục của bản ghi được nối và `offset` là vị trí tương đối, tính bằng byte, của điểm bắt đầu `next` được nhúng trong bản ghi được nối (giả sử rằng bản ghi tự bắt đầu ở độ lệch 0).
    ///
    ///
    /// Khi tràn số học, trả về `LayoutError`.
    ///
    /// # Examples
    ///
    /// Để tính toán bố cục của cấu trúc `#[repr(C)]` và hiệu số của các trường từ bố cục các trường của nó:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Hãy nhớ hoàn thiện với `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // kiểm tra xem nó hoạt động
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Tạo bố cục mô tả bản ghi cho các phiên bản `n` của `self`, không có phần đệm giữa mỗi phiên bản.
    ///
    /// Lưu ý rằng, không giống như `repeat`, `repeat_packed` không đảm bảo rằng các phiên bản lặp lại của `self` sẽ được căn chỉnh chính xác, ngay cả khi một phiên bản nhất định của `self` được căn chỉnh chính xác.
    /// Nói cách khác, nếu bố cục được trả về bởi `repeat_packed` được sử dụng để phân bổ một mảng, thì không đảm bảo rằng tất cả các phần tử trong mảng sẽ được căn chỉnh đúng.
    ///
    /// Khi tràn số học, trả về `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Tạo bố cục mô tả bản ghi cho `self`, tiếp theo là `next` mà không có thêm phần đệm giữa hai bản ghi.
    /// Vì không có phần đệm nào được chèn nên việc căn chỉnh của `next` không liên quan và không được kết hợp *chút nào* vào bố cục kết quả.
    ///
    ///
    /// Khi tràn số học, trả về `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Tạo bố cục mô tả bản ghi cho `[T; n]`.
    ///
    /// Khi tràn số học, trả về `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Các tham số được cung cấp cho `Layout::from_size_align` hoặc một số phương thức khởi tạo `Layout` khác không thỏa mãn các ràng buộc được lập thành văn bản của nó.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (chúng tôi cần điều này cho việc nhập hạ lưu của Lỗi trait)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}