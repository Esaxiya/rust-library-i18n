//! Loại ghim dữ liệu vào vị trí của nó trong bộ nhớ.
//!
//! Đôi khi hữu ích khi có các đối tượng được đảm bảo không di chuyển, theo nghĩa là vị trí của chúng trong bộ nhớ không thay đổi, và do đó có thể được tin cậy.
//! Một ví dụ điển hình của trường hợp như vậy sẽ là xây dựng các cấu trúc tự tham chiếu, vì việc di chuyển một đối tượng có con trỏ đến chính nó sẽ làm mất hiệu lực của chúng, có thể gây ra hành vi không xác định.
//!
//! Ở cấp độ cao, [`Pin<P>`] đảm bảo rằng con trỏ của bất kỳ loại con trỏ nào `P` đều có vị trí ổn định trong bộ nhớ, có nghĩa là nó không thể được di chuyển đi nơi khác và bộ nhớ của nó không thể được định vị cho đến khi nó bị rơi.Chúng tôi nói rằng pointee là "pinned".Mọi thứ trở nên tinh tế hơn khi thảo luận về các loại kết hợp dữ liệu được ghim với dữ liệu không được ghim;[see below](#projections-and-structural-pinning) để biết thêm chi tiết.
//!
//! Theo mặc định, tất cả các loại trong Rust đều có thể di chuyển được.
//! Rust cho phép chuyển tất cả các loại theo giá trị và các loại con trỏ thông minh phổ biến như [`Box<T>`] và `&mut T` cho phép thay thế và di chuyển các giá trị mà chúng chứa: bạn có thể chuyển ra khỏi [`Box<T>`] hoặc bạn có thể sử dụng [`mem::swap`].
//! [`Pin<P>`] bao bọc một loại con trỏ `P`, vì vậy [`Pin`]`<`[`Hộp`] `<T>>`hoạt động giống như một
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Hộp`] `<T>>`bị rơi, nội dung của nó cũng vậy, và bộ nhớ sẽ
//!
//! đã phân bổ.Tương tự, [`Pin`]`<&mut T>`rất giống `&mut T`.Tuy nhiên, [`Pin<P>`] không cho phép khách hàng thực sự lấy [`Box<T>`] hoặc `&mut T` để ghim dữ liệu, điều này ngụ ý rằng bạn không thể sử dụng các hoạt động như [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` cần `&mut T`, nhưng chúng tôi không thể lấy được.
//!     // Chúng tôi bị kẹt, chúng tôi không thể hoán đổi nội dung của các tài liệu tham khảo này.
//!     // Chúng tôi có thể sử dụng `Pin::get_unchecked_mut`, nhưng điều đó không an toàn vì một lý do:
//!     // chúng tôi không được phép sử dụng nó để di chuyển mọi thứ ra khỏi `Pin`.
//! }
//! ```
//!
//! Cần nhắc lại rằng [`Pin<P>`]*không* thay đổi thực tế là trình biên dịch Rust coi tất cả các kiểu đều có thể di chuyển được.[`mem::swap`] vẫn có thể gọi được cho bất kỳ `T` nào.Thay vào đó, [`Pin<P>`] ngăn các giá trị * * nhất định (được trỏ tới bởi các con trỏ được bọc trong [`Pin<P>`]) bằng cách không thể gọi các phương thức yêu cầu `&mut T` trên chúng (như [`mem::swap`]).
//!
//! [`Pin<P>`] có thể được sử dụng để bọc bất kỳ loại con trỏ nào `P`, và như vậy, nó tương tác với [`Deref`] và [`DerefMut`].[`Pin<P>`] trong đó `P: Deref` nên được coi là "`P`-style pointer" thành `P::Target` được ghim-vì vậy, một [`Pin`]`<`[`Hộp`] `<T>>`là một con trỏ được sở hữu tới `T` được ghim và [`Pin`] `<` [`Rc`]`<T>>`là một con trỏ được đếm tham chiếu đến `T` được ghim.
//! Để đảm bảo tính chính xác, [`Pin<P>`] dựa vào việc triển khai [`Deref`] và [`DerefMut`] không di chuyển ra khỏi tham số `self` của chúng và chỉ trả về một con trỏ đến dữ liệu được ghim khi chúng được gọi trên một con trỏ được ghim.
//!
//! # `Unpin`
//!
//! Nhiều loại luôn có thể di chuyển tự do, ngay cả khi được ghim, vì chúng không dựa vào việc có một địa chỉ ổn định.Điều này bao gồm tất cả các loại cơ bản (như [`bool`], [`i32`] và các tham chiếu) cũng như các loại chỉ bao gồm các loại này.Các loại không quan tâm đến việc ghim sẽ thực hiện [`Unpin`] auto-trait, thao tác này sẽ hủy bỏ tác dụng của [`Pin<P>`].
//! Đối với `T: Unpin`, [`Pin`]`<`[`Hộp`] `<T>>`và [`Box<T>`] hoạt động giống nhau, cũng như [`Pin`] `<&mut T>` và `&mut T`.
//!
//! Lưu ý rằng ghim và [`Unpin`] chỉ ảnh hưởng đến loại trỏ tới `P::Target`, không ảnh hưởng đến chính loại con trỏ `P` được bao bọc trong [`Pin<P>`].Ví dụ: việc [`Box<T>`] có phải là [`Unpin`] hay không không ảnh hưởng đến hoạt động của [`Pin`]`<`[`Hộp`] `<T>>`(ở đây, `T` là kiểu trỏ đến).
//!
//! # Ví dụ: cấu trúc tự tham chiếu
//!
//! Trước khi đi vào chi tiết hơn để giải thích các đảm bảo và lựa chọn liên quan đến `Pin<T>`, chúng ta sẽ thảo luận một số ví dụ về cách nó có thể được sử dụng.
//! Hãy thoải mái với [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Đây là một cấu trúc tự tham chiếu vì trường lát cắt trỏ đến trường dữ liệu.
//! // Chúng tôi không thể thông báo cho trình biên dịch về điều đó bằng một tham chiếu thông thường, vì mẫu này không thể được mô tả bằng các quy tắc mượn thông thường.
//! //
//! // Thay vào đó, chúng ta sử dụng một con trỏ thô, mặc dù một con trỏ được biết là không có giá trị rỗng, vì chúng ta biết nó đang trỏ vào chuỗi.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Để đảm bảo dữ liệu không di chuyển khi hàm trả về, chúng tôi đặt nó vào heap nơi nó sẽ ở lại trong suốt thời gian tồn tại của đối tượng và cách duy nhất để truy cập nó là thông qua một con trỏ tới nó.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // chúng tôi chỉ tạo con trỏ khi dữ liệu đã ở đúng vị trí, nếu không, nó sẽ di chuyển trước khi chúng tôi bắt đầu
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // chúng tôi biết điều này là an toàn vì việc sửa đổi một trường không di chuyển toàn bộ cấu trúc
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Con trỏ phải trỏ đến vị trí chính xác, miễn là cấu trúc chưa di chuyển.
//! //
//! // Trong khi đó, chúng tôi có thể tự do di chuyển con trỏ xung quanh.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Vì kiểu của chúng tôi không triển khai Bỏ ghim, điều này sẽ không biên dịch được:
//! // để mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Ví dụ: danh sách liên kết đôi xâm nhập
//!
//! Trong danh sách được liên kết đôi xâm nhập, tập hợp không thực sự cấp phát bộ nhớ cho chính các phần tử.
//! Việc phân bổ được kiểm soát bởi các máy khách và các phần tử có thể sống trên một khung ngăn xếp có tuổi thọ ngắn hơn so với bộ sưu tập.
//!
//! Để làm cho điều này hoạt động, mọi phần tử đều có con trỏ đến người tiền nhiệm và người kế nhiệm của nó trong danh sách.Chỉ có thể thêm các phần tử khi chúng được ghim, vì việc di chuyển các phần tử xung quanh sẽ làm mất hiệu lực của các con trỏ.Hơn nữa, việc triển khai [`Drop`] của một phần tử danh sách liên kết sẽ vá các con trỏ của người tiền nhiệm và người kế nhiệm của nó để xóa chính nó khỏi danh sách.
//!
//! Điều quan trọng, chúng ta phải có thể dựa vào [`drop`] được gọi.Nếu một phần tử có thể bị phân bổ hoặc làm mất hiệu lực theo cách khác mà không gọi [`drop`], các con trỏ vào nó từ các phần tử lân cận của nó sẽ trở nên không hợp lệ, điều này sẽ phá vỡ cấu trúc dữ liệu.
//!
//! Do đó, ghim cũng đi kèm với đảm bảo liên quan đến [`drop`].
//!
//! # `Drop` guarantee
//!
//! Mục đích của ghim là có thể dựa vào vị trí của một số dữ liệu trong bộ nhớ.
//! Để làm cho việc này hoạt động, không chỉ hạn chế việc di chuyển dữ liệu;việc phân bổ, định vị lại hoặc làm mất hiệu lực của bộ nhớ được sử dụng để lưu trữ dữ liệu cũng bị hạn chế.
//! Cụ thể, đối với dữ liệu được ghim, bạn phải duy trì sự bất biến rằng *bộ nhớ của nó sẽ không bị mất hiệu lực hoặc được tái sử dụng kể từ thời điểm nó được ghim cho đến khi [`drop`] được gọi*.Chỉ khi [`drop`] trở lại hoặc panics, bộ nhớ có thể được sử dụng lại.
//!
//! Bộ nhớ có thể là "invalidated" theo vị trí thỏa thuận, nhưng cũng có thể bằng cách thay thế [`Some(v)`] bằng [`None`] hoặc gọi [`Vec::set_len`] thành "kill" một số phần tử của vector.Nó có thể được định vị lại bằng cách sử dụng [`ptr::write`] để ghi đè lên nó mà không cần gọi hàm hủy trước.Không điều nào trong số này được phép đối với dữ liệu được ghim mà không gọi [`drop`].
//!
//! Đây chính xác là loại đảm bảo rằng danh sách liên kết xâm nhập từ phần trước cần hoạt động chính xác.
//!
//! Lưu ý rằng đảm bảo này không *không* có nghĩa là bộ nhớ không bị rò rỉ!Vẫn hoàn toàn không sao khi không bao giờ gọi [`drop`] trên một phần tử được ghim (ví dụ: bạn vẫn có thể gọi [`mem::forget`] trên [`Pin`]`<`[`Hộp`] `<T>>`).Trong ví dụ về danh sách được liên kết kép, phần tử đó sẽ chỉ ở trong danh sách.Tuy nhiên, bạn không thể giải phóng hoặc sử dụng lại bộ nhớ *mà không gọi [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Nếu kiểu của bạn sử dụng ghim (chẳng hạn như hai ví dụ ở trên), bạn phải cẩn thận khi triển khai [`Drop`].Hàm [`drop`] sử dụng `&mut self`, nhưng nó được gọi là *ngay cả khi loại của bạn đã được ghim trước đó*!Nó giống như thể trình biên dịch tự động được gọi là [`Pin::get_unchecked_mut`].
//!
//! Điều này không bao giờ có thể gây ra sự cố trong mã an toàn vì việc triển khai một loại dựa vào ghim yêu cầu mã không an toàn, nhưng hãy lưu ý rằng quyết định sử dụng ghim trong loại của bạn (ví dụ: bằng cách triển khai một số thao tác trên [`Pin`]`<&Self>`hoặc [`Pin`] `<&mut Self>`) cũng có hậu quả đối với việc triển khai [`Drop`] của bạn: nếu một phần tử thuộc loại của bạn có thể đã được ghim, bạn phải coi [`Drop`] là hoàn toàn nhận [`Pin`]`<&mut Bản thân>`.
//!
//!
//! Ví dụ: bạn có thể triển khai `Drop` như sau:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` không sao vì chúng tôi biết giá trị này không bao giờ được sử dụng lại sau khi bị bỏ.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Mã giảm thực tế ở đây.
//!         }
//!     }
//! }
//! ```
//!
//! Hàm `inner_drop` có kiểu mà [`drop`]*nên* có, vì vậy điều này đảm bảo rằng bạn không vô tình sử dụng `self`/`this` theo cách xung đột với ghim.
//!
//! Hơn nữa, nếu loại của bạn là `#[repr(packed)]`, trình biên dịch sẽ tự động di chuyển các trường xung quanh để có thể loại bỏ chúng.Nó thậm chí có thể làm điều đó cho các trường tình cờ được căn chỉnh đầy đủ.Do đó, bạn không thể sử dụng ghim với loại `#[repr(packed)]`.
//!
//! # Phép chiếu và ghim cấu trúc
//!
//! Khi làm việc với các cấu trúc được ghim, câu hỏi đặt ra là làm thế nào người ta có thể truy cập các trường của cấu trúc đó trong một phương thức chỉ cần [`Pin`]`<&mut Struct>`.
//! Cách tiếp cận thông thường là viết các phương thức trợ giúp (được gọi là *các phép chiếu*) biến [`Pin`]`<&mut Struct>`thành một tham chiếu đến trường, nhưng tham chiếu đó phải có kiểu gì?Đó là [`Pin`]`<&mut Field>`hay `&mut Field`?
//! Câu hỏi tương tự cũng đặt ra với các trường của `enum` và cả khi xem xét các loại container/wrapper như [`Vec<T>`], [`Box<T>`] hoặc [`RefCell<T>`].
//! (Câu hỏi này áp dụng cho cả tham chiếu có thể thay đổi và tham chiếu được chia sẻ, chúng tôi chỉ sử dụng trường hợp phổ biến hơn của tham chiếu có thể thay đổi ở đây để minh họa.)
//!
//! Hóa ra là thực sự tùy thuộc vào tác giả của cấu trúc dữ liệu để quyết định liệu phép chiếu được ghim cho một trường cụ thể có biến [`Pin`]`<&mut Struct>`thành [`Pin`] `<&mut Field>` hay không `&mut Field`.Tuy nhiên, có một số ràng buộc và hạn chế quan trọng nhất là *nhất quán*:
//! mọi trường đều có thể *hoặc* được chiếu tới một tham chiếu được ghim,*hoặc* đã loại bỏ ghim như một phần của phép chiếu.
//! Nếu cả hai đều được thực hiện cho cùng một lĩnh vực, điều đó có thể sẽ không được đảm bảo!
//!
//! Là tác giả của cấu trúc dữ liệu, bạn có thể quyết định cho từng trường xem có ghim "propagates" vào trường này hay không.
//! Ghim lan truyền còn được gọi là "structural", vì nó tuân theo cấu trúc của kiểu.
//! Trong phần phụ sau đây, chúng tôi mô tả những cân nhắc phải thực hiện cho một trong hai lựa chọn.
//!
//! ## Ghim *không phải là* cấu trúc cho `field`
//!
//! Có vẻ hơi phản trực giác rằng trường của một cấu trúc được ghim có thể không được ghim, nhưng đó thực sự là lựa chọn dễ dàng nhất: nếu một [`Pin`]`<&mut Field>`không bao giờ được tạo, không có gì có thể xảy ra sai sót!Vì vậy, nếu bạn quyết định rằng một số trường không có ghim cấu trúc, tất cả những gì bạn phải đảm bảo là bạn không bao giờ tạo tham chiếu được ghim cho trường đó.
//!
//! Các trường không có ghim cấu trúc có thể có phương thức chiếu biến [`Pin`]`<&mut Struct>`thành `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Điều này không sao cả vì `field` không bao giờ được coi là đã được ghim.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Bạn cũng có thể `impl Unpin for Struct`*ngay cả khi* loại `field` không phải là [`Unpin`].Loại đó nghĩ gì về việc ghim không liên quan khi không có [`Pin`]`<&mut Field>`nào được tạo.
//!
//! ## Ghim *là* cấu trúc cho `field`
//!
//! Tùy chọn khác là quyết định rằng ghim là "structural" cho `field`, có nghĩa là nếu cấu trúc được ghim thì trường cũng vậy.
//!
//! Điều này cho phép viết một phép chiếu tạo ra [`Pin`]`<&mut Field>`, do đó chứng kiến rằng trường được ghim:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Điều này không sao vì `field` được ghim khi `self`.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Tuy nhiên, ghim cấu trúc đi kèm với một số yêu cầu bổ sung:
//!
//! 1. Cấu trúc chỉ phải là [`Unpin`] nếu tất cả các trường cấu trúc là [`Unpin`].Đây là mặc định, nhưng [`Unpin`] là một trait an toàn, vì vậy với tư cách là tác giả của cấu trúc, bạn có trách nhiệm *không* thêm một cái gì đó như `impl<T> Unpin for Struct<T>`.
//! (Lưu ý rằng việc thêm thao tác chiếu yêu cầu mã không an toàn, vì vậy việc [`Unpin`] là một trait an toàn không phá vỡ nguyên tắc mà bạn chỉ phải lo lắng về bất kỳ điều nào trong số này nếu bạn sử dụng `` không an toàn ''.)
//! 2. Hàm hủy của cấu trúc không được di chuyển các trường cấu trúc ra khỏi đối số của nó.Đây là điểm chính xác đã được nêu ra trong [previous section][drop-impl]: `drop` lấy `&mut self`, nhưng cấu trúc (và do đó là các trường của nó) có thể đã được ghim trước đó.
//!     Bạn phải đảm bảo rằng bạn không di chuyển một trường bên trong quá trình triển khai [`Drop`] của mình.
//!     Đặc biệt, như đã giải thích trước đây, điều này có nghĩa là cấu trúc của bạn phải *không phải* là `#[repr(packed)]`.
//!     Xem phần đó để biết cách viết [`drop`] theo cách mà trình biên dịch có thể giúp bạn không vô tình làm hỏng ghim.
//! 3. Bạn phải đảm bảo rằng bạn duy trì [`Drop` guarantee][drop-guarantee]:
//!     khi cấu trúc của bạn được ghim, bộ nhớ chứa nội dung sẽ không bị ghi đè hoặc được phân bổ mà không gọi hàm hủy của nội dung.
//!     Điều này có thể phức tạp, như đã chứng kiến bởi [`VecDeque<T>`]: trình hủy của [`VecDeque<T>`] có thể không gọi [`drop`] trên tất cả các phần tử nếu một trong các trình hủy panics.Điều này vi phạm đảm bảo [`Drop`], vì nó có thể dẫn đến việc các phần tử được phân bổ mà không có trình hủy của chúng được gọi.([`VecDeque<T>`] không có hình chiếu ghim, vì vậy điều này không gây ra tình trạng không chắc chắn.)
//! 4. Bạn không được cung cấp bất kỳ thao tác nào khác có thể dẫn đến việc dữ liệu bị di chuyển ra khỏi các trường cấu trúc khi loại của bạn được ghim.Ví dụ: nếu cấu trúc chứa [`Option<T>`] và có một hoạt động giống như ``lấy` với loại `fn(Pin<&mut Struct<T>>) -> Option<T>`, thì hoạt động đó có thể được sử dụng để di chuyển `T` ra khỏi `Struct<T>` đã được ghim-có nghĩa là không thể có cấu trúc ghim cho trường nắm giữ này dữ liệu.
//!
//!     Đối với một ví dụ phức tạp hơn về việc di chuyển dữ liệu ra khỏi kiểu được ghim, hãy tưởng tượng nếu [`RefCell<T>`] có một phương thức `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Sau đó, chúng tôi có thể làm như sau:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Điều này thật thảm khốc, nó có nghĩa là trước tiên chúng tôi có thể ghim nội dung của [`RefCell<T>`] (sử dụng `RefCell::get_pin_mut`) và sau đó di chuyển nội dung đó bằng cách sử dụng tham chiếu có thể thay đổi mà chúng tôi nhận được sau đó.
//!
//! ## Examples
//!
//! Đối với một loại như [`Vec<T>`], cả hai khả năng (ghim cấu trúc hoặc không) đều có ý nghĩa.
//! [`Vec<T>`] có ghim cấu trúc có thể có các phương thức `get_pin`/`get_pin_mut` để nhận các tham chiếu được ghim đến các phần tử.Tuy nhiên, nó không thể *không* cho phép gọi [`pop`][Vec::pop] trên [`Vec<T>`] được ghim vì điều đó sẽ di chuyển nội dung (được ghim theo cấu trúc)!Nó cũng không thể cho phép [`push`][Vec::push], có thể phân bổ lại và do đó cũng di chuyển nội dung.
//!
//! [`Vec<T>`] không có ghim cấu trúc có thể `impl<T> Unpin for Vec<T>`, vì nội dung không bao giờ được ghim và bản thân [`Vec<T>`] cũng ổn khi di chuyển.
//! Tại thời điểm đó, việc ghim không ảnh hưởng gì đến vector cả.
//!
//! Trong thư viện tiêu chuẩn, các loại con trỏ thường không có cấu trúc ghim và do đó chúng không cung cấp các phép chiếu ghim.Đây là lý do tại sao `Box<T>: Unpin` giữ cho tất cả `T`.
//! Làm điều này rất hợp lý đối với các loại con trỏ, vì việc di chuyển `Box<T>` không thực sự di chuyển `T`: [`Box<T>`] có thể di chuyển tự do (hay còn gọi là `Unpin`) ngay cả khi `T` không di chuyển.Trên thực tế, ngay cả [`Pin`]`<`[`Hộp`] `<T>>`và [`Pin`] `<&mut T>` luôn tự là [`Unpin`], vì lý do tương tự: nội dung của chúng (`T`) được ghim, nhưng bản thân các con trỏ có thể được di chuyển mà không cần di chuyển dữ liệu được ghim.
//! Đối với cả [`Box<T>`] và [`Pin`]`<`[`Hộp`] `<T>>`, nội dung có được ghim hay không là hoàn toàn độc lập với việc con trỏ có được ghim hay không, nghĩa là việc ghim có cấu trúc *không*.
//!
//! Khi triển khai bộ tổ hợp [`Future`], bạn thường sẽ cần ghim cấu trúc cho futures lồng nhau, vì bạn cần lấy các tham chiếu được ghim đến chúng để gọi [`poll`].
//! Nhưng nếu bộ tổ hợp của bạn chứa bất kỳ dữ liệu nào khác không cần được ghim, bạn có thể làm cho các trường đó không có cấu trúc và do đó tự do truy cập chúng với một tham chiếu có thể thay đổi ngay cả khi bạn chỉ có [`Pin`]`<&mut Self>`(chẳng hạn như trong quá trình triển khai [`poll`] của riêng bạn).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Một con trỏ được ghim.
///
/// Đây là một trình bao bọc xung quanh một loại con trỏ làm cho con trỏ đó "pin" có giá trị tại chỗ, ngăn không cho giá trị được tham chiếu bởi con trỏ đó được di chuyển trừ khi nó triển khai [`Unpin`].
///
///
/// *Xem tài liệu [`pin` module] để biết giải thích về ghim.*
///
/// [`pin` module]: self
///
// Note: `Clone` dẫn xuất bên dưới gây ra sự không chắc chắn vì nó có thể triển khai
// `Clone` cho các tham chiếu có thể thay đổi.
// Xem <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> để biết thêm chi tiết.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Các triển khai sau đây không bắt nguồn để tránh các vấn đề về âm thanh.
// `&self.pointer` không thể truy cập vào các triển khai trait không đáng tin cậy.
//
// Xem <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> để biết thêm chi tiết.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Xây dựng một `Pin<P>` mới xung quanh một con trỏ tới một số dữ liệu thuộc kiểu triển khai [`Unpin`].
    ///
    /// Không giống như `Pin::new_unchecked`, phương pháp này an toàn vì con trỏ `P` tham chiếu đến kiểu [`Unpin`], loại bỏ các bảo đảm ghim.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // AN TOÀN: giá trị được trỏ đến là `Unpin` và do đó không có yêu cầu
        // xung quanh ghim.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Giải nén `Pin<P>` này trả về con trỏ cơ bản.
    ///
    /// Điều này yêu cầu dữ liệu bên trong `Pin` này là [`Unpin`] để chúng tôi có thể bỏ qua các bất biến ghim khi mở gói.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Xây dựng một `Pin<P>` mới xung quanh một tham chiếu đến một số dữ liệu thuộc loại có thể hoặc có thể không triển khai `Unpin`.
    ///
    /// Nếu `pointer` tham chiếu đến kiểu `Unpin`, thì `Pin::new` nên được sử dụng thay thế.
    ///
    /// # Safety
    ///
    /// Hàm tạo này không an toàn vì chúng tôi không thể đảm bảo rằng dữ liệu được trỏ đến bởi `pointer` đã được ghim, có nghĩa là dữ liệu sẽ không được di chuyển hoặc bộ nhớ của nó bị vô hiệu cho đến khi nó bị xóa.
    /// Nếu `Pin<P>` được xây dựng không đảm bảo rằng dữ liệu mà `P` trỏ đến được ghim, điều đó vi phạm hợp đồng API và có thể dẫn đến hành vi không xác định trong các hoạt động (safe) sau này.
    ///
    /// Bằng cách sử dụng phương pháp này, bạn đang tạo promise về việc triển khai `P::Deref` và `P::DerefMut`, nếu chúng tồn tại.
    /// Quan trọng nhất, chúng không được di chuyển ra khỏi các đối số `self` của chúng: `Pin::as_mut` và `Pin::as_ref` sẽ gọi `DerefMut::deref_mut` và `Deref::deref`*trên con trỏ được ghim* và mong đợi các phương pháp này duy trì các bất biến ghim.
    /// Hơn nữa, bằng cách gọi phương thức này là bạn promise mà tham chiếu `P` tham chiếu đến sẽ không bị chuyển ra ngoài nữa;đặc biệt, không thể lấy `&mut P::Target` và sau đó chuyển ra khỏi tham chiếu đó (sử dụng, ví dụ: [`mem::swap`]).
    ///
    ///
    /// Ví dụ: gọi `Pin::new_unchecked` trên `&'a mut T` là không an toàn vì mặc dù bạn có thể ghim nó cho `'a` đời nhất định, nhưng bạn không kiểm soát được việc nó có được ghim sau khi `'a` kết thúc hay không:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Điều này có nghĩa là pointee `a` không bao giờ có thể di chuyển được nữa.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Địa chỉ của `a` đã thay đổi thành khe ngăn xếp của `b`, vì vậy `a` đã được di chuyển mặc dù chúng tôi đã ghim nó trước đó!Chúng tôi đã vi phạm hợp đồng API ghim.
    /////
    /// }
    /// ```
    ///
    /// Một giá trị, sau khi được ghim, phải được ghim mãi mãi (trừ khi kiểu của nó triển khai `Unpin`).
    ///
    /// Tương tự, việc gọi `Pin::new_unchecked` trên `Rc<T>` là không an toàn vì có thể có bí danh cho cùng một dữ liệu không tuân theo các hạn chế ghim:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Điều này có nghĩa là con trỏ không bao giờ có thể di chuyển nữa.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Bây giờ, nếu `x` là tham chiếu duy nhất, chúng ta có một tham chiếu có thể thay đổi đến dữ liệu mà chúng ta đã ghim ở trên, mà chúng ta có thể sử dụng để di chuyển nó như chúng ta đã thấy trong ví dụ trước.
    ///     // Chúng tôi đã vi phạm hợp đồng API ghim.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Nhận tham chiếu chia sẻ được ghim từ con trỏ được ghim này.
    ///
    /// Đây là một phương pháp chung để đi từ `&Pin<Pointer<T>>` đến `Pin<&T>`.
    /// Nó an toàn bởi vì, là một phần của hợp đồng `Pin::new_unchecked`, con trỏ không thể di chuyển sau khi `Pin<Pointer<T>>` được tạo.
    ///
    /// "Malicious" việc triển khai `Pointer::Deref` cũng bị loại trừ bởi hợp đồng của `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // AN TOÀN: xem tài liệu về chức năng này
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Giải nén `Pin<P>` này trả về con trỏ cơ bản.
    ///
    /// # Safety
    ///
    /// Chức năng này không an toàn.Bạn phải đảm bảo rằng bạn sẽ tiếp tục coi con trỏ `P` là đã được ghim sau khi bạn gọi hàm này, để các biến bất biến trên kiểu `Pin` có thể được duy trì.
    /// Nếu mã sử dụng kết quả `P` không tiếp tục duy trì các bất biến ghim là vi phạm hợp đồng API và có thể dẫn đến hành vi không xác định trong các hoạt động (safe) sau này.
    ///
    ///
    /// Nếu dữ liệu cơ bản là [`Unpin`], thì [`Pin::into_inner`] nên được sử dụng thay thế.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Nhận tham chiếu có thể thay đổi được ghim từ con trỏ được ghim này.
    ///
    /// Đây là một phương pháp chung để đi từ `&mut Pin<Pointer<T>>` đến `Pin<&mut T>`.
    /// Nó an toàn bởi vì, là một phần của hợp đồng `Pin::new_unchecked`, con trỏ không thể di chuyển sau khi `Pin<Pointer<T>>` được tạo.
    ///
    /// "Malicious" việc triển khai `Pointer::DerefMut` cũng bị loại trừ bởi hợp đồng của `Pin::new_unchecked`.
    ///
    /// Phương pháp này hữu ích khi thực hiện nhiều lệnh gọi đến các hàm sử dụng kiểu được ghim.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // làm việc gì đó
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` tiêu thụ `self`, vì vậy hãy mượn lại `Pin<&mut Self>` qua `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // AN TOÀN: xem tài liệu về chức năng này
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Gán một giá trị mới cho bộ nhớ đằng sau tham chiếu được ghim.
    ///
    /// Điều này sẽ ghi đè lên dữ liệu được ghim, nhưng điều đó không sao cả: trình hủy của nó sẽ được chạy trước khi bị ghi đè, vì vậy không có đảm bảo ghim nào bị vi phạm.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Tạo một ghim mới bằng cách ánh xạ giá trị bên trong.
    ///
    /// Ví dụ: nếu bạn muốn nhận `Pin` của một trường nào đó, bạn có thể sử dụng điều này để truy cập vào trường đó trong một dòng mã.
    /// Tuy nhiên, có một số lỗi với những "pinning projections" này;
    /// xem tài liệu [`pin` module] để biết thêm chi tiết về chủ đề đó.
    ///
    /// # Safety
    ///
    /// Chức năng này không an toàn.
    /// Bạn phải đảm bảo rằng dữ liệu bạn trả về sẽ không di chuyển miễn là giá trị đối số không di chuyển (ví dụ: vì nó là một trong các trường của giá trị đó) và bạn cũng không di chuyển ra khỏi đối số mà bạn nhận được chức năng nội thất.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // AN TOÀN: hợp đồng an toàn cho `new_unchecked` phải
        // được người gọi ủng hộ.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Nhận tham chiếu được chia sẻ ra khỏi ghim.
    ///
    /// Điều này là an toàn vì không thể chuyển ra khỏi tham chiếu được chia sẻ.
    /// Có vẻ như có một vấn đề ở đây với khả năng thay đổi nội thất: trên thực tế, có thể * di chuyển `T` ra khỏi `&RefCell<T>`.
    /// Tuy nhiên, đây không phải là vấn đề miễn là không tồn tại `Pin<&T>` trỏ đến cùng một dữ liệu và `RefCell<T>` không cho phép bạn tạo tham chiếu được ghim cho nội dung của nó.
    ///
    /// Xem thảo luận về ["pinning projections"] để biết thêm chi tiết.
    ///
    /// Note: `Pin` cũng triển khai `Deref` tới đích, có thể được sử dụng để truy cập giá trị bên trong.
    /// Tuy nhiên, `Deref` chỉ cung cấp một tài liệu tham khảo tồn tại lâu dài với thời gian vay mượn của `Pin`, không phải thời gian tồn tại của chính `Pin`.
    /// Phương pháp này cho phép biến `Pin` thành một tham chiếu có cùng tuổi thọ với `Pin` ban đầu.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Chuyển đổi `Pin<&mut T>` này thành `Pin<&T>` với cùng tuổi thọ.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Nhận tham chiếu có thể thay đổi đến dữ liệu bên trong `Pin` này.
    ///
    /// Điều này yêu cầu dữ liệu bên trong `Pin` này là `Unpin`.
    ///
    /// Note: `Pin` cũng triển khai `DerefMut` vào dữ liệu, dữ liệu này có thể được sử dụng để truy cập giá trị bên trong.
    /// Tuy nhiên, `DerefMut` chỉ cung cấp một tài liệu tham khảo tồn tại lâu dài với thời gian vay mượn của `Pin`, không phải thời gian tồn tại của chính `Pin`.
    ///
    /// Phương pháp này cho phép biến `Pin` thành một tham chiếu có cùng tuổi thọ với `Pin` ban đầu.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Nhận tham chiếu có thể thay đổi đến dữ liệu bên trong `Pin` này.
    ///
    /// # Safety
    ///
    /// Chức năng này không an toàn.
    /// Bạn phải đảm bảo rằng bạn sẽ không bao giờ di chuyển dữ liệu ra khỏi tham chiếu có thể thay đổi mà bạn nhận được khi gọi hàm này, để các biến bất biến trên kiểu `Pin` có thể được giữ nguyên.
    ///
    ///
    /// Nếu dữ liệu cơ bản là `Unpin`, thì `Pin::get_mut` nên được sử dụng thay thế.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Tạo một ghim mới bằng cách ánh xạ giá trị bên trong.
    ///
    /// Ví dụ: nếu bạn muốn nhận `Pin` của một trường nào đó, bạn có thể sử dụng điều này để truy cập vào trường đó trong một dòng mã.
    /// Tuy nhiên, có một số lỗi với những "pinning projections" này;
    /// xem tài liệu [`pin` module] để biết thêm chi tiết về chủ đề đó.
    ///
    /// # Safety
    ///
    /// Chức năng này không an toàn.
    /// Bạn phải đảm bảo rằng dữ liệu bạn trả về sẽ không di chuyển miễn là giá trị đối số không di chuyển (ví dụ: vì nó là một trong các trường của giá trị đó) và bạn cũng không di chuyển ra khỏi đối số mà bạn nhận được chức năng nội thất.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // AN TOÀN: người gọi có trách nhiệm không di chuyển
        // giá trị của tài liệu tham khảo này.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // AN TOÀN: vì giá trị của `this` được đảm bảo không có
        // đã được chuyển ra ngoài, cuộc gọi tới `new_unchecked` này an toàn.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Nhận một tham chiếu được ghim từ một tham chiếu tĩnh.
    ///
    /// Điều này là an toàn, vì `T` được mượn cho vòng đời của `'static`, không bao giờ kết thúc.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // AN TOÀN: 'Vay tĩnh đảm bảo dữ liệu sẽ không
        // moved/invalidated cho đến khi nó bị rơi (mà không bao giờ).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Nhận một tham chiếu có thể thay đổi được ghim từ một tham chiếu có thể thay đổi tĩnh.
    ///
    /// Điều này là an toàn, vì `T` được mượn cho vòng đời của `'static`, không bao giờ kết thúc.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // AN TOÀN: 'Vay tĩnh đảm bảo dữ liệu sẽ không
        // moved/invalidated cho đến khi nó bị rơi (mà không bao giờ).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: điều này có nghĩa là bất kỳ sự xâm nhập nào của `CoerceUnsized` cho phép ép buộc từ
// một loại nhập `Deref<Target=impl !Unpin>` với một loại nhập `Deref<Target=Unpin>` là không liên quan.
// Mặc dù vậy, bất kỳ điểm tích lũy nào như vậy có thể không được xác nhận vì các lý do khác, vì vậy chúng ta chỉ cần lưu ý không cho phép các lần cấy ghép đó hạ cánh trong std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}