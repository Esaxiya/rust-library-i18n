//! # Thư viện lõi Rust
//!
//! Thư viện lõi Rust là nền tảng [^ miễn phí] không phụ thuộc của [The Rust Standard Library](../std/index.html).
//! Nó là chất kết dính di động giữa ngôn ngữ và các thư viện của nó, xác định các khối xây dựng nội tại và nguyên thủy của tất cả mã Rust.
//!
//! Nó liên kết đến không có thư viện ngược dòng, không có thư viện hệ thống và không có libc.
//!
//! [^free]: Strictly nói, có một số ký hiệu cần thiết nhưng
//!          chúng không phải lúc nào cũng cần thiết.
//!
//! Thư viện lõi là *tối thiểu*: nó thậm chí không biết về phân bổ heap, cũng như không cung cấp đồng thời hoặc I/O.
//! Những thứ này yêu cầu tích hợp nền tảng và thư viện này là nền tảng bất khả tri.
//!
//! # Cách sử dụng thư viện lõi
//!
//! Xin lưu ý rằng tất cả các chi tiết này hiện không được coi là ổn định.
//!
//!
//!
// FIXME: Điền cho tôi thông tin chi tiết hơn khi giao diện ổn định
//! Thư viện này được xây dựng dựa trên giả định về một số ký hiệu hiện có:
//!
//! * `memcpy`, `memcmp`, `memset`, Đây là các quy trình bộ nhớ cốt lõi thường được tạo ra bởi LLVM.
//! Ngoài ra, thư viện này có thể thực hiện các lệnh gọi rõ ràng đến các hàm này.
//! Chữ ký của họ giống như được tìm thấy trong C.
//!   Các chức năng này thường được cung cấp bởi hệ thống libc, nhưng cũng có thể được cung cấp bởi [compiler-builtins crate](https://crates.io/crates/compiler_builtins).
//!
//!
//! * `rust_begin_panic` - Hàm này nhận bốn đối số, một `fmt::Arguments`, một `&'static str` và hai 'u32`.
//! Bốn đối số này ra lệnh cho thông báo panic, tệp mà panic được gọi, và dòng và cột bên trong tệp.
//! Người sử dụng thư viện lõi này tùy thuộc vào việc xác định chức năng panic này;nó chỉ được yêu cầu để không bao giờ quay trở lại.
//! Điều này yêu cầu một thuộc tính `lang` có tên là `panic_impl`.
//!
//! * `rust_eh_personality` - được sử dụng bởi các cơ chế lỗi của trình biên dịch.
//! Điều này thường được ánh xạ đến hàm tính cách của GCC, nhưng crates không kích hoạt panic có thể yên tâm rằng hàm này không bao giờ được gọi.
//! Thuộc tính `lang` được gọi là `eh_personality`.
//!
//!
//!

// Vì libcore xác định nhiều mục lang cơ bản, nên tất cả các bài kiểm tra đều nằm trong một crate riêng biệt, libcoretest, để tránh các vấn đề kỳ lạ.
//
// Ở đây chúng tôi rõ ràng#[cfg]-out toàn bộ crate này khi thử nghiệm.
// Nếu chúng tôi không thực hiện việc này, cả cấu phần thử nghiệm đã tạo và libtest được liên kết (tạm dịch bao gồm libcore) sẽ xác định cùng một tập hợp các mục lang và điều này sẽ gây ra lỗi E0152 "found duplicate lang item".
//
// Xem thảo luận trong #50466 để biết chi tiết.
//
// Cfg này sẽ không ảnh hưởng đến các bài kiểm tra doc.
//
//
#![cfg(not(test))]
#![stable(feature = "core", since = "1.6.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![no_core]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(asm)]
#![feature(cfg_target_has_atomic)]
#![feature(const_heap)]
#![feature(const_alloc_layout)]
#![feature(const_assert_type)]
#![feature(const_discriminant)]
#![feature(const_cell_into_inner)]
#![feature(const_intrinsic_copy)]
#![feature(const_intrinsic_forget)]
#![feature(const_float_classify)]
#![feature(const_float_bits_conv)]
#![feature(const_int_unchecked_arith)]
#![feature(const_mut_refs)]
#![feature(const_refs_to_cell)]
#![feature(const_cttz)]
#![feature(const_panic)]
#![feature(const_pin)]
#![feature(const_fn)]
#![feature(const_fn_union)]
#![feature(const_impl_trait)]
#![feature(const_fn_floating_point_arithmetic)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(const_option)]
#![feature(const_precise_live_drops)]
#![feature(const_ptr_offset)]
#![feature(const_ptr_offset_from)]
#![feature(const_ptr_read)]
#![feature(const_ptr_write)]
#![feature(const_raw_ptr_comparison)]
#![feature(const_raw_ptr_deref)]
#![feature(const_slice_from_raw_parts)]
#![feature(const_slice_ptr_len)]
#![feature(const_size_of_val)]
#![feature(const_swap)]
#![feature(const_align_of_val)]
#![feature(const_type_id)]
#![feature(const_type_name)]
#![feature(const_likely)]
#![feature(const_unreachable_unchecked)]
#![feature(const_maybe_uninit_assume_init)]
#![feature(const_maybe_uninit_as_ptr)]
#![feature(custom_inner_attributes)]
#![feature(decl_macro)]
#![feature(doc_cfg)]
#![feature(doc_spotlight)]
#![feature(duration_consts_2)]
#![feature(duration_saturating_ops)]
#![feature(extended_key_value_attributes)]
#![feature(extern_types)]
#![feature(fundamental)]
#![feature(intra_doc_pointers)]
#![feature(intrinsics)]
#![feature(lang_items)]
#![feature(link_llvm_intrinsics)]
#![feature(llvm_asm)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(exhaustive_patterns)]
#![feature(no_core)]
#![feature(auto_traits)]
#![feature(or_patterns)]
#![feature(prelude_import)]
#![cfg_attr(not(bootstrap), feature(ptr_metadata))]
#![feature(repr_simd, platform_intrinsics)]
#![feature(rustc_attrs)]
#![feature(simd_ffi)]
#![feature(min_specialization)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(stmt_expr_attributes)]
#![feature(str_split_as_str)]
#![feature(str_split_inclusive_as_str)]
#![feature(trait_alias)]
#![feature(transparent_unions)]
#![feature(try_blocks)]
#![feature(unboxed_closures)]
#![feature(unsized_fn_params)]
#![feature(unwind_attributes)]
#![feature(variant_count)]
#![feature(tbm_target_feature)]
#![feature(sse4a_target_feature)]
#![feature(arm_target_feature)]
#![feature(powerpc_target_feature)]
#![feature(mips_target_feature)]
#![feature(aarch64_target_feature)]
#![feature(wasm_target_feature)]
#![feature(avx512_target_feature)]
#![feature(cmpxchg16b_target_feature)]
#![feature(rtm_target_feature)]
#![feature(f16c_target_feature)]
#![feature(hexagon_target_feature)]
#![feature(const_fn_transmute)]
#![feature(abi_unadjusted)]
#![feature(adx_target_feature)]
#![feature(external_doc)]
#![feature(associated_type_bounds)]
#![feature(const_caller_location)]
#![feature(slice_ptr_get)]
#![feature(no_niche)] // rust-lang/rust#68303
#![feature(int_error_matching)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![deny(unsafe_op_in_unsafe_fn)]

#[prelude_import]
#[allow(unused)]
use prelude::v1::*;

#[cfg(not(test))] // Xem #65860
#[macro_use]
mod macros;

#[macro_use]
mod internal_macros;

#[path = "num/shells/int_macros.rs"]
#[macro_use]
mod int_macros;

#[path = "num/shells/i128.rs"]
pub mod i128;
#[path = "num/shells/i16.rs"]
pub mod i16;
#[path = "num/shells/i32.rs"]
pub mod i32;
#[path = "num/shells/i64.rs"]
pub mod i64;
#[path = "num/shells/i8.rs"]
pub mod i8;
#[path = "num/shells/isize.rs"]
pub mod isize;

#[path = "num/shells/u128.rs"]
pub mod u128;
#[path = "num/shells/u16.rs"]
pub mod u16;
#[path = "num/shells/u32.rs"]
pub mod u32;
#[path = "num/shells/u64.rs"]
pub mod u64;
#[path = "num/shells/u8.rs"]
pub mod u8;
#[path = "num/shells/usize.rs"]
pub mod usize;

#[path = "num/f32.rs"]
pub mod f32;
#[path = "num/f64.rs"]
pub mod f64;

#[macro_use]
pub mod num;

/* The libcore prelude, not as all-encompassing as the libstd prelude */

pub mod prelude;

/* Core modules for ownership management */

pub mod hint;
pub mod intrinsics;
pub mod mem;
pub mod ptr;

/* Core language traits */

pub mod borrow;
pub mod clone;
pub mod cmp;
pub mod convert;
pub mod default;
pub mod marker;
pub mod ops;

/* Core types and methods on primitives */

pub mod any;
pub mod array;
pub mod ascii;
pub mod cell;
pub mod char;
pub mod ffi;
pub mod iter;
#[unstable(feature = "once_cell", issue = "74465")]
pub mod lazy;
pub mod option;
pub mod panic;
pub mod panicking;
pub mod pin;
pub mod raw;
pub mod result;
#[unstable(feature = "async_stream", issue = "79024")]
pub mod stream;
pub mod sync;

pub mod fmt;
pub mod hash;
pub mod slice;
pub mod str;
pub mod time;

pub mod unicode;

/* Async */
pub mod future;
pub mod task;

/* Heap memory allocator trait */
#[allow(missing_docs)]
pub mod alloc;

// note: không cần phải công khai
mod bool;
mod tuple;
mod unit;

#[stable(feature = "core_primitive", since = "1.43.0")]
pub mod primitive;

// Kéo `core_arch` crate trực tiếp vào libcore.Nội dung của `core_arch` nằm trong một kho lưu trữ khác: rust-lang/stdarch.
//
// `core_arch` phụ thuộc vào libcore, nhưng nội dung của mô-đun này được thiết lập theo cách trực tiếp kéo nó đến đây hoạt động sao cho crate sử dụng crate này làm libcore của nó.
//
//
//
#[path = "../../stdarch/crates/core_arch/src/mod.rs"]
#[allow(
    missing_docs,
    missing_debug_implementations,
    dead_code,
    unused_imports,
    unsafe_op_in_unsafe_fn
)]
#[cfg_attr(bootstrap, allow(non_autolinks))]
#[cfg_attr(not(bootstrap), allow(rustdoc::non_autolinks))]
// FIXME: Chú thích này sẽ được chuyển vào rust-lang/stdarch sau khi clashing_extern_decl Tuyên
// đã hợp nhất.Nó hiện không thể vì bootstrap không thành công vì lint chưa được xác định.
#[allow(clashing_extern_declarations)]
#[unstable(feature = "stdsimd", issue = "48556")]
mod core_arch;

#[stable(feature = "simd_arch", since = "1.27.0")]
pub use core_arch::arch;