//! traits nguyên thủy và các kiểu đại diện cho các thuộc tính cơ bản của các kiểu.
//!
//! Các loại Rust có thể được phân loại theo nhiều cách hữu ích khác nhau tùy theo đặc tính nội tại của chúng.
//! Các phân loại này được biểu diễn dưới dạng traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Các loại có thể được chuyển qua các ranh giới luồng.
///
/// trait này được thực hiện tự động khi trình biên dịch xác định nó phù hợp.
///
/// Một ví dụ về kiểu không phải `Send` là con trỏ đếm tham chiếu [`rc::Rc`][`Rc`].
/// Nếu hai luồng cố gắng sao chép [`Rc`] trỏ đến cùng một giá trị được đếm tham chiếu, chúng có thể cố gắng cập nhật số lượng tham chiếu cùng một lúc, đó là [undefined behavior][ub] vì [`Rc`] không sử dụng các phép toán nguyên tử.
///
/// Người anh em họ của nó là [`sync::Arc`][arc] sử dụng các hoạt động nguyên tử (phát sinh một số chi phí) và do đó là `Send`.
///
/// Xem [the Nomicon](../../nomicon/send-and-sync.html) để biết thêm chi tiết.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Các loại có kích thước không đổi đã biết tại thời điểm biên dịch.
///
/// Tất cả các tham số kiểu đều có một giới hạn ngầm định là `Sized`.Cú pháp đặc biệt `?Sized` có thể được sử dụng để loại bỏ ràng buộc này nếu nó không phù hợp.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//error: Size không được triển khai cho [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Một ngoại lệ là kiểu `Self` ngầm định của trait.
/// trait không có ràng buộc `Sized` ngầm định vì điều này không tương thích với [đối tượng trait] trong đó, theo định nghĩa, trait cần hoạt động với tất cả các trình triển khai có thể và do đó có thể có kích thước bất kỳ.
///
///
/// Mặc dù Rust sẽ cho phép bạn liên kết `Sized` với trait, bạn sẽ không thể sử dụng nó để tạo đối tượng trait sau này:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // cho y: &dyn Bar= &Impl;//lỗi: không thể tạo trait `Bar` thành một đối tượng
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // đối với Mặc định, ví dụ, yêu cầu `[T]: !Default` có thể đánh giá được
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Các loại có thể là "unsized" thành loại có kích thước động.
///
/// Ví dụ, kiểu mảng có kích thước `[i8; 2]` triển khai `Unsize<[i8]>` và `Unsize<dyn fmt::Debug>`.
///
/// Tất cả các triển khai của `Unsize` được cung cấp tự động bởi trình biên dịch.
///
/// `Unsize` được triển khai cho:
///
/// - `[T; N]` là `Unsize<[T]>`
/// - `T` là `Unsize<dyn Trait>` khi `T: Trait`
/// - `Foo<..., T, ...>` là `Unsize<Foo<..., U, ...>>` nếu:
///   - `T: Unsize<U>`
///   - Foo là một cấu trúc
///   - Chỉ trường cuối cùng của `Foo` có kiểu liên quan đến `T`
///   - `T` không thuộc loại của bất kỳ trường nào khác
///   - `Bar<T>: Unsize<Bar<U>>`, nếu trường cuối cùng của `Foo` có kiểu `Bar<T>`
///
/// `Unsize` được sử dụng cùng với [`ops::CoerceUnsized`] để cho phép các thùng chứa "user-defined" như [`Rc`] chứa các loại có kích thước động.
/// Xem [DST coercion RFC][RFC982] và [the nomicon entry on coercion][nomicon-coerce] để biết thêm chi tiết.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// trait bắt buộc đối với các hằng số được sử dụng trong các đối sánh mẫu.
///
/// Bất kỳ kiểu nào dẫn xuất từ `PartialEq` sẽ tự động triển khai trait này,*bất chấp* bất kể kiểu tham số của nó có triển khai `Eq` hay không.
///
/// Nếu một mục `const` chứa một số kiểu không triển khai trait này, thì kiểu đó hoặc (1.) không triển khai `PartialEq` (có nghĩa là hằng số sẽ không cung cấp phương pháp so sánh đó, giả định rằng việc tạo mã có sẵn) hoặc (2.) nó thực hiện * * phiên bản của `PartialEq` (mà chúng tôi cho rằng không tuân theo phép so sánh bình đẳng về cấu trúc).
///
///
/// Trong một trong hai trường hợp trên, chúng tôi từ chối việc sử dụng một hằng số như vậy trong một đối sánh mẫu.
///
/// Xem thêm [structural match RFC][RFC1445] và [issue 63438] đã thúc đẩy chuyển từ thiết kế dựa trên thuộc tính sang trait này.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// trait bắt buộc đối với các hằng số được sử dụng trong các đối sánh mẫu.
///
/// Bất kỳ kiểu nào dẫn xuất từ `Eq` sẽ tự động triển khai trait này,*bất chấp* bất kể các tham số kiểu của nó có triển khai `Eq` hay không.
///
/// Đây là một cuộc tấn công để giải quyết một hạn chế trong hệ thống loại của chúng tôi.
///
/// # Background
///
/// Chúng tôi muốn yêu cầu rằng các loại khuyết điểm được sử dụng trong các đối sánh mẫu phải có thuộc tính `#[derive(PartialEq, Eq)]`.
///
/// Trong một thế giới lý tưởng hơn, chúng ta có thể kiểm tra yêu cầu đó bằng cách chỉ cần kiểm tra xem loại đã cho có triển khai cả `StructuralPartialEq` trait *và*`Eq` trait hay không.
/// Tuy nhiên, bạn có thể có các ADT *do*`derive(PartialEq, Eq)` và là một trường hợp mà chúng tôi muốn trình biên dịch chấp nhận, nhưng kiểu của hằng số không thực hiện được `Eq`.
///
/// Cụ thể là một trường hợp như thế này:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Vấn đề trong đoạn mã trên là `Wrap<fn(&())>` không triển khai `PartialEq` hoặc `Eq`, vì `for <'a> fn(&'a _)` does not implement those traits.)
///
/// Do đó, chúng tôi không thể dựa vào kiểm tra ngây thơ cho `StructuralPartialEq` và `Eq` đơn thuần.
///
/// Để giải quyết vấn đề này, chúng tôi sử dụng hai traits riêng biệt được đưa vào bởi mỗi trong số hai dẫn xuất (`#[derive(PartialEq)]` và `#[derive(Eq)]`) và kiểm tra xem cả hai đều có mặt như một phần của kiểm tra đối sánh cấu trúc.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Các loại có giá trị có thể được sao chép đơn giản bằng cách sao chép các bit.
///
/// Theo mặc định, các liên kết biến có 'ngữ nghĩa di chuyển.'Nói cách khác:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` đã chuyển sang `y` và do đó không thể sử dụng
///
/// // println! ("{: ?}", x);//error: sử dụng giá trị đã di chuyển
/// ```
///
/// Tuy nhiên, nếu một kiểu triển khai `Copy`, thay vào đó nó có 'ngữ nghĩa sao chép':
///
/// ```
/// // Chúng ta có thể tạo ra một bản triển khai `Copy`.
/// // `Clone` cũng là bắt buộc, vì nó là một supertrait của `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` là một bản sao của `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Điều quan trọng cần lưu ý là trong hai ví dụ này, sự khác biệt duy nhất là bạn có được phép truy cập `x` sau khi được chỉ định hay không.
/// Bên dưới, cả một bản sao và một lần di chuyển có thể dẫn đến việc các bit được sao chép trong bộ nhớ, mặc dù điều này đôi khi được tối ưu hóa đi.
///
/// ## Làm cách nào để triển khai `Copy`?
///
/// Có hai cách để triển khai `Copy` trên loại của bạn.Đơn giản nhất là sử dụng `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Bạn cũng có thể triển khai `Copy` và `Clone` theo cách thủ công:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Có một sự khác biệt nhỏ giữa hai loại: chiến lược `derive` cũng sẽ đặt `Copy` bị ràng buộc trên các tham số kiểu, điều này không phải lúc nào cũng mong muốn.
///
/// ## Sự khác biệt giữa `Copy` và `Clone` là gì?
///
/// Các bản sao diễn ra ngầm, ví dụ như một phần của nhiệm vụ `y = x`.Hành vi của `Copy` là không thể quá tải;nó luôn là một bản sao đơn giản khôn ngoan.
///
/// Nhân bản là một hành động rõ ràng, `x.clone()`.Việc triển khai [`Clone`] có thể cung cấp bất kỳ hành vi cụ thể nào cần thiết để sao chép các giá trị một cách an toàn.
/// Ví dụ: việc triển khai [`Clone`] cho [`String`] cần sao chép bộ đệm chuỗi trỏ đến trong heap.
/// Một bản sao bitwise đơn giản của các giá trị [`String`] sẽ chỉ sao chép con trỏ, dẫn đến dòng tự do gấp đôi.
/// Vì lý do này, [`String`] là [`Clone`] nhưng không phải `Copy`.
///
/// [`Clone`] là một supertrait của `Copy`, vì vậy mọi thứ là `Copy` cũng phải triển khai [`Clone`].
/// Nếu một kiểu là `Copy` thì việc triển khai [`Clone`] của nó chỉ cần trả về `*self` (xem ví dụ ở trên).
///
/// ## Khi nào loại của tôi có thể là `Copy`?
///
/// Một kiểu có thể triển khai `Copy` nếu tất cả các thành phần của nó triển khai `Copy`.Ví dụ, cấu trúc này có thể là `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Một cấu trúc có thể là `Copy` và [`i32`] là `Copy`, do đó `Point` đủ điều kiện để trở thành `Copy`.
/// Ngược lại, hãy xem xét
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Struct `PointList` không thể triển khai `Copy`, vì [`Vec<T>`] không phải là `Copy`.Nếu chúng tôi cố gắng lấy một triển khai `Copy`, chúng tôi sẽ gặp lỗi:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Các tham chiếu được chia sẻ (`&T`) cũng là `Copy`, vì vậy một loại có thể là `Copy`, ngay cả khi nó chứa các tham chiếu được chia sẻ thuộc các loại `T`*không phải*`Copy`.
/// Hãy xem xét cấu trúc sau, cấu trúc này có thể triển khai `Copy`, vì nó chỉ giữ một *tham chiếu được chia sẻ* cho loại `PointList` không phải `Copy` của chúng tôi từ phía trên:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Khi *không thể* loại của tôi là `Copy`?
///
/// Một số loại không thể được sao chép một cách an toàn.Ví dụ: sao chép `&mut T` sẽ tạo ra một tham chiếu có thể thay đổi được bí danh.
/// Việc sao chép [`String`] sẽ trùng lặp trách nhiệm quản lý bộ đệm của [``String`], dẫn đến việc miễn phí gấp đôi.
///
/// Tổng quát hóa trường hợp thứ hai, bất kỳ kiểu nào triển khai [`Drop`] không thể là `Copy`, vì nó đang quản lý một số tài nguyên bên cạnh các byte [`size_of::<T>`] của chính nó.
///
/// Nếu bạn cố gắng triển khai `Copy` trên một cấu trúc hoặc enum chứa dữ liệu không phải là `Sao chép`, bạn sẽ gặp lỗi [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Khi nào *nên* loại của tôi là `Copy`?
///
/// Nói chung, nếu loại _can_ của bạn triển khai `Copy`, thì điều đó sẽ xảy ra.
/// Tuy nhiên, hãy nhớ rằng việc triển khai `Copy` là một phần của API công khai thuộc loại của bạn.
/// Nếu loại có thể trở thành không phải là `` Sao chép '' trong future, thì có thể thận trọng bỏ qua việc triển khai `Copy` ngay bây giờ, để tránh thay đổi API vi phạm.
///
/// ## Người triển khai bổ sung
///
/// Ngoài [implementors listed below][impls], các loại sau cũng triển khai `Copy`:
///
/// * Các loại mục chức năng (nghĩa là các loại riêng biệt được xác định cho từng chức năng)
/// * Các loại con trỏ hàm (ví dụ: `fn() -> i32`)
/// * Các loại mảng, cho tất cả các kích thước, nếu loại mục cũng triển khai `Copy` (ví dụ: `[i32; 123456]`)
/// * Các loại Tuple, nếu mỗi thành phần cũng triển khai `Copy` (ví dụ: `()`, `(i32, bool)`)
/// * Các loại đóng cửa, nếu chúng không nhận được giá trị nào từ môi trường hoặc nếu tất cả các giá trị được bắt đó tự thực hiện `Copy`.
///   Lưu ý rằng các biến được nắm bắt bởi tham chiếu được chia sẻ luôn triển khai `Copy` (ngay cả khi tham chiếu không), trong khi các biến được nắm bắt bởi tham chiếu có thể thay đổi không bao giờ triển khai `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Điều này cho phép sao chép kiểu không triển khai `Copy` vì giới hạn thời gian tồn tại không thỏa mãn (sao chép `A<'_>` khi chỉ `A<'static>: Copy` và `A<'_>: Clone`).
// Chúng tôi có thuộc tính này ở đây bây giờ chỉ vì có khá nhiều chuyên môn hiện có trên `Copy` đã tồn tại trong thư viện tiêu chuẩn và không có cách nào để có hành vi này một cách an toàn ngay bây giờ.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Derive macro tạo ra một impl của trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Các loại an toàn để chia sẻ tham chiếu giữa các luồng.
///
/// trait này được thực hiện tự động khi trình biên dịch xác định nó phù hợp.
///
/// Định nghĩa chính xác là: loại `T` là [`Sync`] nếu và chỉ khi `&T` là [`Send`].
/// Nói cách khác, nếu không có khả năng xảy ra [undefined behavior][ub] (bao gồm các chủng tộc dữ liệu) khi chuyển các tham chiếu `&T` giữa các luồng.
///
/// Như người ta mong đợi, các kiểu nguyên thủy như [`u8`] và [`f64`] đều là [`Sync`] và các kiểu tổng hợp đơn giản chứa chúng cũng vậy, như bộ giá trị, cấu trúc và enum.
/// Các ví dụ khác về các loại [`Sync`] cơ bản bao gồm các loại "immutable" như `&T` và những loại có khả năng đột biến kế thừa đơn giản, chẳng hạn như [`Box<T>`][box], [`Vec<T>`][vec] và hầu hết các loại tập hợp khác.
///
/// (Các tham số chung cần phải là [`Sync`] để vùng chứa của chúng là [`Sync`].)
///
/// Một hệ quả hơi đáng ngạc nhiên của định nghĩa là `&mut T` là `Sync` (nếu `T` là `Sync`) mặc dù có vẻ như điều đó có thể cung cấp đột biến không đồng bộ.
/// Bí quyết là một tham chiếu có thể thay đổi đằng sau một tham chiếu được chia sẻ (nghĩa là, `& &mut T`) trở thành chỉ đọc, như thể nó là một `& &T`.
/// Do đó, không có rủi ro về một cuộc chạy đua dữ liệu.
///
/// Các loại không phải `Sync` là những loại có "interior mutability" ở dạng không an toàn theo luồng, chẳng hạn như [`Cell`][cell] và [`RefCell`][refcell].
/// Những loại này cho phép thay đổi nội dung của chúng ngay cả thông qua một tham chiếu được chia sẻ, bất biến.
/// Ví dụ: phương thức `set` trên [`Cell<T>`][cell] lấy `&self`, vì vậy nó chỉ yêu cầu một tham chiếu được chia sẻ [`&Cell<T>`][cell].
/// Phương thức không thực hiện đồng bộ hóa, do đó [`Cell`][cell] không thể là `Sync`.
///
/// Một ví dụ khác về kiểu không phải `Sync` là con trỏ đếm tham chiếu [`Rc`][rc].
/// Với bất kỳ tham chiếu [`&Rc<T>`][rc] nào, bạn có thể sao chép [`Rc<T>`][rc] mới, sửa đổi số lượng tham chiếu theo cách phi nguyên tử.
///
/// Đối với những trường hợp cần khả năng thay đổi nội thất an toàn theo luồng, Rust cung cấp [atomic data types], cũng như khóa rõ ràng qua [`sync::Mutex`][mutex] và [`sync::RwLock`][rwlock].
/// Các loại này đảm bảo rằng bất kỳ đột biến nào không thể gây ra các cuộc đua dữ liệu, do đó các loại là `Sync`.
/// Tương tự như vậy, [`sync::Arc`][arc] cung cấp một chất tương tự an toàn theo luồng của [`Rc`][rc].
///
/// Bất kỳ loại nào có khả năng thay đổi nội thất cũng phải sử dụng trình bao bọc [`cell::UnsafeCell`][unsafecell] xung quanh value(s) có thể được thay đổi thông qua tham chiếu được chia sẻ.
/// Không làm được điều này là [undefined behavior][ub].
/// Ví dụ: [`transmute`][transmute]-ing từ `&T` đến `&mut T` không hợp lệ.
///
/// Xem [the Nomicon][nomicon-send-and-sync] để biết thêm chi tiết về `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): khi hỗ trợ thêm ghi chú trong `rustc_on_unimplemented` đến trong phiên bản beta và nó đã được mở rộng để kiểm tra xem việc đóng có ở bất kỳ đâu trong chuỗi yêu cầu hay không, hãy mở rộng nó như (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Loại có kích thước bằng không dùng để đánh dấu những thứ "act like" mà họ sở hữu `T`.
///
/// Việc thêm trường `PhantomData<T>` vào kiểu của bạn sẽ cho trình biên dịch biết rằng kiểu của bạn hoạt động như thể nó lưu trữ giá trị kiểu `T`, mặc dù nó không thực sự như vậy.
/// Thông tin này được sử dụng khi tính toán các đặc tính an toàn nhất định.
///
/// Để được giải thích sâu hơn về cách sử dụng `PhantomData<T>`, vui lòng xem [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Một ghi chú ghê rợn 👻👻👻
///
/// Mặc dù cả hai đều có những cái tên đáng sợ, `PhantomData` và 'loại ma' có liên quan với nhau, nhưng không giống hệt nhau.Tham số kiểu ảo chỉ đơn giản là một tham số kiểu không bao giờ được sử dụng.
/// Trong Rust, điều này thường khiến trình biên dịch phàn nàn và giải pháp là thêm một "dummy" sử dụng theo cách của `PhantomData`.
///
/// # Examples
///
/// ## Các thông số lâu dài không được sử dụng
///
/// Có lẽ trường hợp sử dụng phổ biến nhất cho `PhantomData` là một cấu trúc có tham số thời gian tồn tại không được sử dụng, thường là một phần của một số mã không an toàn.
/// Ví dụ, đây là một cấu trúc `Slice` có hai con trỏ kiểu `*const T`, có lẽ trỏ vào một mảng ở đâu đó:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Mục đích là dữ liệu cơ bản chỉ có giá trị trong vòng đời của `'a`, vì vậy `Slice` sẽ không tồn tại lâu hơn `'a`.
/// Tuy nhiên, ý định này không được thể hiện trong mã, vì không có công dụng nào của đời `'a` và do đó không rõ nó áp dụng cho dữ liệu nào.
/// Chúng tôi có thể sửa lỗi này bằng cách yêu cầu trình biên dịch hoạt động *như thể* cấu trúc `Slice` chứa tham chiếu `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Điều này cũng yêu cầu chú thích `T: 'a`, cho biết rằng bất kỳ tham chiếu nào trong `T` đều có giá trị trong suốt thời gian tồn tại của `'a`.
///
/// Khi khởi tạo `Slice`, bạn chỉ cần cung cấp giá trị `PhantomData` cho trường `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Tham số loại không được sử dụng
///
/// Đôi khi xảy ra trường hợp bạn có các tham số kiểu không được sử dụng cho biết kiểu dữ liệu mà cấu trúc là "tied", mặc dù dữ liệu đó không thực sự được tìm thấy trong chính cấu trúc.
/// Đây là một ví dụ nơi điều này phát sinh với [FFI].
/// Giao diện bên ngoài sử dụng các chốt kiểu `*mut ()` để tham chiếu đến các giá trị Rust thuộc các kiểu khác nhau.
/// Chúng tôi theo dõi kiểu Rust bằng cách sử dụng tham số kiểu ảo trên struct `ExternalResource` bao bọc một tay cầm.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Quyền sở hữu và kiểm tra thả
///
/// Thêm trường kiểu `PhantomData<T>` cho biết rằng kiểu của bạn sở hữu dữ liệu kiểu `T`.Đến lượt nó, điều này ngụ ý rằng khi loại của bạn bị loại bỏ, nó có thể rơi ra một hoặc nhiều trường hợp của loại `T`.
/// Điều này liên quan đến phân tích [drop check] của trình biên dịch Rust.
///
/// Nếu cấu trúc của bạn trên thực tế không *sở hữu* dữ liệu thuộc loại `T`, tốt hơn nên sử dụng loại tham chiếu, như `PhantomData<&'a T>` (ideally) hoặc `PhantomData<*const T>` (nếu không áp dụng thời gian tồn tại), để không chỉ ra quyền sở hữu.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Trình biên dịch-nội bộ trait được sử dụng để chỉ ra loại phân biệt enum.
///
/// trait này được triển khai tự động cho mọi loại và không thêm bất kỳ đảm bảo nào cho [`mem::Discriminant`].
/// Đó là **hành vi không xác định** để chuyển đổi giữa `DiscriminantKind::Discriminant` và `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Loại phân biệt, phải thỏa mãn trait bounds theo yêu cầu của `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Trình biên dịch-nội bộ trait được sử dụng để xác định xem một loại có chứa bất kỳ `UnsafeCell` nào bên trong không, nhưng không thông qua một hướng.
///
/// Ví dụ, điều này ảnh hưởng đến việc một `static` thuộc loại đó được đặt trong bộ nhớ tĩnh chỉ đọc hay bộ nhớ tĩnh có thể ghi.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Các loại có thể được di chuyển an toàn sau khi được ghim.
///
/// Bản thân Rust không có khái niệm về các loại bất động và coi việc di chuyển (ví dụ: thông qua nhiệm vụ hoặc [`mem::replace`]) là luôn an toàn.
///
/// Loại [`Pin`][Pin] được sử dụng thay thế để ngăn chặn việc di chuyển qua hệ thống loại.Không thể di chuyển con trỏ `P<T>` được bọc trong trình bao bọc [`Pin<P<T>>`][Pin].
/// Xem tài liệu [`pin` module] để biết thêm thông tin về cách ghim.
///
/// Việc triển khai `Unpin` trait cho `T` loại bỏ các hạn chế của việc ghim loại, sau đó cho phép di chuyển `T` ra khỏi [`Pin<P<T>>`][Pin] với các chức năng như [`mem::replace`].
///
///
/// `Unpin` không có hậu quả gì đối với dữ liệu không được ghim.
/// Đặc biệt, [`mem::replace`] vui vẻ di chuyển dữ liệu `!Unpin` (nó hoạt động với bất kỳ `&mut T` nào, không chỉ khi `T: Unpin`).
/// Tuy nhiên, bạn không thể sử dụng [`mem::replace`] trên dữ liệu được bao bọc bên trong [`Pin<P<T>>`][Pin] vì bạn không thể nhận được `&mut T` bạn cần cho điều đó và *đó* là điều khiến hệ thống này hoạt động.
///
/// Vì vậy, điều này, chẳng hạn, chỉ có thể được thực hiện trên các loại triển khai `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Chúng tôi cần một tham chiếu có thể thay đổi để gọi `mem::replace`.
/// // Chúng ta có thể có được một tham chiếu như vậy bằng cách (implicitly) gọi `Pin::deref_mut`, nhưng điều đó chỉ có thể thực hiện được vì `String` triển khai `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// trait này được thực hiện tự động cho hầu hết mọi loại.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Loại điểm đánh dấu không triển khai `Unpin`.
///
/// Nếu một loại chứa `PhantomPinned`, nó sẽ không triển khai `Unpin` theo mặc định.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Các triển khai của `Copy` cho các kiểu nguyên thủy.
///
/// Các triển khai không thể được mô tả trong Rust được thực hiện trong `traits::SelectionContext::copy_clone_conditions()` trong `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Các tham chiếu được chia sẻ có thể được sao chép, nhưng các tham chiếu có thể thay đổi *không thể*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}