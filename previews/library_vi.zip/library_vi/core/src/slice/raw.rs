//! Chức năng miễn phí để tạo `&[T]` và `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Tạo thành một lát cắt từ một con trỏ và một chiều dài.
///
/// Đối số `len` là số **phần tử**, không phải số byte.
///
/// # Safety
///
/// Hành vi là không xác định nếu bất kỳ điều kiện nào sau đây bị vi phạm:
///
/// * `data` phải là [valid] để đọc cho `len * mem::size_of::<T>()` nhiều byte và nó phải được căn chỉnh chính xác.Điều này đặc biệt có nghĩa là:
///
///     * Toàn bộ phạm vi bộ nhớ của lát cắt này phải được chứa trong một đối tượng được cấp phát duy nhất!
///       Slices không bao giờ có thể trải dài trên nhiều đối tượng được phân bổ.Xem [below](#incorrect-usage) để biết ví dụ không chính xác khi không tính đến điều này.
///     * `data` phải không rỗng và được căn chỉnh ngay cả đối với các lát cắt có độ dài bằng không.
///     Một lý do cho điều này là tối ưu hóa bố cục enum có thể dựa vào các tham chiếu (bao gồm các phần có độ dài bất kỳ) được căn chỉnh và không rỗng để phân biệt chúng với các dữ liệu khác.
///     Bạn có thể lấy một con trỏ có thể sử dụng được dưới dạng `data` cho các lát cắt có độ dài bằng 0 bằng [`NonNull::dangling()`].
///
/// * `data` phải trỏ đến `len` các giá trị được khởi tạo đúng cách liên tiếp của kiểu `T`.
///
/// * Bộ nhớ được tham chiếu bởi lát trả về không được thay đổi trong suốt thời gian tồn tại của `'a`, ngoại trừ bên trong `UnsafeCell`.
///
/// * Tổng kích thước `len * mem::size_of::<T>()` của lát cắt không được lớn hơn `isize::MAX`.
///   Xem tài liệu an toàn của [`pointer::offset`].
///
/// # Caveat
///
/// Thời gian tồn tại của lát được trả về được suy ra từ cách sử dụng của nó.
/// Để tránh việc vô tình lạm dụng, bạn nên gắn thời gian tồn tại với bất kỳ thời gian tồn tại nguồn nào là an toàn trong ngữ cảnh, chẳng hạn như bằng cách cung cấp hàm trợ giúp lấy toàn bộ thời gian của giá trị máy chủ cho phần hoặc bằng chú thích rõ ràng.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // hiển thị một lát cho một phần tử duy nhất
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Sử dụng không chính xác
///
/// Hàm `join_slices` sau đây là **không xác định** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Khẳng định ở trên đảm bảo `fst` và `snd` liền kề, nhưng chúng vẫn có thể được chứa bên trong _different allocated objects_, trong trường hợp đó, việc tạo lát cắt này là hành vi không xác định.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` và `b` là các đối tượng được phân bổ khác nhau ...
///     let a = 42;
///     let b = 27;
///     // ... tuy nhiên có thể được trình bày liền kề trong bộ nhớ: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Thực hiện chức năng tương tự như [`from_raw_parts`], ngoại trừ việc trả về một lát có thể thay đổi.
///
/// # Safety
///
/// Hành vi là không xác định nếu bất kỳ điều kiện nào sau đây bị vi phạm:
///
/// * `data` phải là [valid] cho cả lần đọc và ghi đối với `len * mem::size_of::<T>()` nhiều byte và nó phải được căn chỉnh đúng cách.Điều này đặc biệt có nghĩa là:
///
///     * Toàn bộ phạm vi bộ nhớ của lát cắt này phải được chứa trong một đối tượng được cấp phát duy nhất!
///       Slices không bao giờ có thể trải dài trên nhiều đối tượng được phân bổ.
///     * `data` phải không rỗng và được căn chỉnh ngay cả đối với các lát cắt có độ dài bằng không.
///     Một lý do cho điều này là tối ưu hóa bố cục enum có thể dựa vào các tham chiếu (bao gồm các phần có độ dài bất kỳ) được căn chỉnh và không rỗng để phân biệt chúng với các dữ liệu khác.
///
///     Bạn có thể lấy một con trỏ có thể sử dụng được dưới dạng `data` cho các lát cắt có độ dài bằng 0 bằng [`NonNull::dangling()`].
///
/// * `data` phải trỏ đến `len` các giá trị được khởi tạo đúng cách liên tiếp của kiểu `T`.
///
/// * Bộ nhớ được tham chiếu bởi lát trả về không được truy cập thông qua bất kỳ con trỏ nào khác (không bắt nguồn từ giá trị trả về) trong suốt thời gian tồn tại của `'a`.
///   Cả hai quyền truy cập đọc và ghi đều bị cấm.
///
/// * Tổng kích thước `len * mem::size_of::<T>()` của lát cắt không được lớn hơn `isize::MAX`.
///   Xem tài liệu an toàn của [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // AN TOÀN: người gọi phải duy trì hợp đồng an toàn cho `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Chuyển một tham chiếu đến T thành một lát cắt có độ dài 1 (không sao chép).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Chuyển một tham chiếu đến T thành một lát cắt có độ dài 1 (không sao chép).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}