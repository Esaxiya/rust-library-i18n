//! Macro được sử dụng bởi các trình vòng lặp của lát cắt.

// Inline is_empty và len tạo ra sự khác biệt lớn về hiệu suất
macro_rules! is_empty {
    // Cách chúng tôi mã hóa độ dài của trình vòng lặp ZST, điều này hoạt động cho cả ZST và không phải ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Để loại bỏ một số kiểm tra giới hạn (xem `position`), chúng tôi tính độ dài theo một cách hơi bất ngờ.
// (Được kiểm tra bởi `codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // đôi khi chúng tôi được sử dụng trong một khối không an toàn

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // _cannot_ này sử dụng `unchecked_sub` vì chúng tôi phụ thuộc vào việc bao bọc để biểu thị độ dài của các trình vòng lặp lát cắt ZST dài.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Chúng tôi biết rằng `start <= end`, vì vậy có thể làm tốt hơn `offset_from`, vốn cần phải xử lý khi đã đăng nhập.
            // Bằng cách đặt các cờ thích hợp ở đây, chúng ta có thể cho LLVM biết điều này, giúp nó loại bỏ các kiểm tra giới hạn.
            // AN TOÀN: Theo kiểu bất biến, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Bằng cách nói với LLVM rằng các con trỏ cách nhau một bội số chính xác của kích thước kiểu, nó có thể tối ưu hóa `len() == 0` xuống `start == end` thay vì `(end - start) < size`.
            //
            // AN TOÀN: Theo kiểu bất biến, các con trỏ được căn chỉnh để
            //         khoảng cách giữa chúng phải là bội số của kích thước con trỏ
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Định nghĩa được chia sẻ của các trình vòng lặp `Iter` và `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Trả về phần tử đầu tiên và di chuyển phần bắt đầu của trình vòng lặp chuyển tiếp 1.
        // Cải thiện đáng kể hiệu suất so với một hàm nội tuyến.
        // Trình lặp không được để trống.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Trả về phần tử cuối cùng và di chuyển phần cuối của trình lặp về phía sau 1.
        // Cải thiện đáng kể hiệu suất so với một hàm nội tuyến.
        // Trình lặp không được để trống.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Thu hẹp trình lặp khi T là ZST, bằng cách di chuyển phần cuối của trình lặp về phía sau `n`.
        // `n` không được vượt quá `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Chức năng trợ giúp để tạo một lát từ trình lặp.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // AN TOÀN: trình lặp được tạo từ một lát với con trỏ
                // `self.ptr` và chiều dài `len!(self)`.
                // Điều này đảm bảo rằng tất cả các điều kiện tiên quyết cho `from_raw_parts` đều được đáp ứng.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Chức năng trợ giúp để di chuyển phần bắt đầu của trình vòng lặp chuyển tiếp theo các phần tử `offset`, trả về phần bắt đầu cũ.
            //
            // Không an toàn vì độ lệch không được vượt quá `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // AN TOÀN: người gọi đảm bảo rằng `offset` không vượt quá `self.len()`,
                    // vì vậy con trỏ mới này nằm bên trong `self` và do đó được đảm bảo là không rỗng.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Chức năng trợ giúp để di chuyển phần cuối của trình lặp về phía sau bởi các phần tử `offset`, trả về phần cuối mới.
            //
            // Không an toàn vì độ lệch không được vượt quá `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // AN TOÀN: người gọi đảm bảo rằng `offset` không vượt quá `self.len()`,
                    // được đảm bảo không làm tràn `isize`.
                    // Ngoài ra, con trỏ kết quả nằm trong giới hạn của `slice`, đáp ứng các yêu cầu khác cho `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // có thể được triển khai với các lát, nhưng điều này tránh kiểm tra giới hạn

                // AN TOÀN: Các cuộc gọi `assume` an toàn vì con trỏ bắt đầu của lát cắt
                // phải khác rỗng và các lát cắt trên không phải ZST cũng phải có con trỏ kết thúc không null.
                // Lệnh gọi tới `next_unchecked!` là an toàn vì trước tiên chúng tôi kiểm tra xem trình vòng lặp có trống không.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Trình lặp này hiện đang trống.
                    if mem::size_of::<T>() == 0 {
                        // Chúng ta phải làm theo cách này vì `ptr` có thể không bao giờ là 0, nhưng `end` có thể là (do gói).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // AN TOÀN: kết thúc không được bằng 0 nếu T không phải là ZST vì ptr không phải là 0 và kết thúc>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // AN TOÀN: Chúng tôi đang ở trong giới hạn.`post_inc_start` làm điều đúng đắn ngay cả đối với ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Chúng tôi ghi đè triển khai mặc định, sử dụng `try_fold`, vì triển khai đơn giản này tạo ra ít IR LLVM hơn và biên dịch nhanh hơn.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Chúng tôi ghi đè triển khai mặc định, sử dụng `try_fold`, vì triển khai đơn giản này tạo ra ít IR LLVM hơn và biên dịch nhanh hơn.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Chúng tôi ghi đè triển khai mặc định, sử dụng `try_fold`, vì triển khai đơn giản này tạo ra ít IR LLVM hơn và biên dịch nhanh hơn.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Chúng tôi ghi đè triển khai mặc định, sử dụng `try_fold`, vì triển khai đơn giản này tạo ra ít IR LLVM hơn và biên dịch nhanh hơn.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Chúng tôi ghi đè triển khai mặc định, sử dụng `try_fold`, vì triển khai đơn giản này tạo ra ít IR LLVM hơn và biên dịch nhanh hơn.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Chúng tôi ghi đè triển khai mặc định, sử dụng `try_fold`, vì triển khai đơn giản này tạo ra ít IR LLVM hơn và biên dịch nhanh hơn.
            // Ngoài ra, `assume` tránh bị kiểm tra giới hạn.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // AN TOÀN: chúng tôi được đảm bảo ở trong giới hạn bởi sự bất biến của vòng lặp:
                        // khi `i >= n`, `self.next()` trả về `None` và vòng lặp bị ngắt.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Chúng tôi ghi đè triển khai mặc định, sử dụng `try_fold`, vì triển khai đơn giản này tạo ra ít IR LLVM hơn và biên dịch nhanh hơn.
            // Ngoài ra, `assume` tránh bị kiểm tra giới hạn.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // AN TOÀN: `i` phải thấp hơn `n` vì nó bắt đầu ở `n`
                        // và đang giảm dần.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // AN TOÀN: người gọi phải đảm bảo rằng `i` nằm trong giới hạn
                // lát bên dưới, vì vậy `i` không thể làm tràn `isize` và các tham chiếu trả về được đảm bảo tham chiếu đến một phần tử của lát và do đó được đảm bảo là hợp lệ.
                //
                // Cũng lưu ý rằng trình gọi cũng đảm bảo rằng chúng tôi sẽ không bao giờ được gọi với cùng một chỉ mục và không có phương thức nào khác sẽ truy cập vào mạng con này được gọi, vì vậy tham chiếu trả về có thể thay đổi được trong trường hợp
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // có thể được triển khai với các lát, nhưng điều này tránh kiểm tra giới hạn

                // AN TOÀN: Các lệnh gọi `assume` là an toàn vì con trỏ bắt đầu của lát cắt phải không rỗng,
                // và các lát trên không phải ZST cũng phải có con trỏ kết thúc không null.
                // Lệnh gọi tới `next_back_unchecked!` là an toàn vì trước tiên chúng tôi kiểm tra xem trình vòng lặp có trống không.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Trình lặp này hiện đang trống.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // AN TOÀN: Chúng tôi đang ở trong giới hạn.`pre_dec_end` làm điều đúng đắn ngay cả đối với ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}