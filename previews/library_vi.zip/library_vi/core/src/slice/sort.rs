//! Phân loại lát
//!
//! Mô-đun này chứa một thuật toán sắp xếp dựa trên sự nhanh chóng đánh bại mẫu của Orson Peters, được xuất bản tại: <https://github.com/orlp/pdqsort>
//!
//!
//! Sắp xếp không ổn định tương thích với libcore vì nó không phân bổ bộ nhớ, không giống như cách triển khai sắp xếp ổn định của chúng tôi.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Khi bị rơi, các bản sao từ `src` thành `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // AN TOÀN: Đây là một lớp trợ giúp.
        //          Vui lòng tham khảo cách sử dụng của nó để biết tính đúng đắn.
        //          Cụ thể, người ta phải chắc chắn rằng `src` và `dst` không trùng lặp theo yêu cầu của `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Dịch chuyển phần tử đầu tiên sang phải cho đến khi nó gặp phần tử lớn hơn hoặc bằng.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // AN TOÀN: Các hoạt động không an toàn bên dưới liên quan đến việc lập chỉ mục mà không có kiểm tra ràng buộc (`get_unchecked` và `get_unchecked_mut`)
    // và sao chép bộ nhớ (`ptr::copy_nonoverlapping`).
    //
    // a.Lập chỉ mục:
    //  1. Chúng tôi đã kiểm tra kích thước của mảng là>=2.
    //  2. Tất cả việc lập chỉ mục mà chúng tôi sẽ làm luôn luôn ở giữa {0 <= index < len}.
    //
    // b.Sao chép bộ nhớ
    //  1. Chúng tôi đang thu thập các con trỏ đến các tham chiếu được đảm bảo là hợp lệ.
    //  2. Chúng không thể chồng chéo lên nhau bởi vì chúng tôi có được các con trỏ đến các chỉ số khác nhau của lát cắt.
    //     Cụ thể là `i` và `i-1`.
    //  3. Nếu lát được căn chỉnh đúng cách, các phần tử sẽ được căn chỉnh đúng.
    //     Người gọi có trách nhiệm đảm bảo rằng lát cắt được căn chỉnh chính xác.
    //
    // Xem bình luận bên dưới để biết thêm chi tiết.
    unsafe {
        // Nếu hai phần tử đầu tiên không theo thứ tự ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Đọc phần tử đầu tiên vào một biến được cấp phát ngăn xếp.
            // Nếu thao tác so sánh sau panics, `hole` sẽ bị loại bỏ và tự động ghi phần tử trở lại lát cắt.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Di chuyển phần tử thứ `i` sang trái một chỗ, do đó dịch chuyển lỗ sang phải.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` bị rơi và do đó sao chép `tmp` vào lỗ còn lại trong `v`.
        }
    }
}

/// Di chuyển phần tử cuối cùng sang trái cho đến khi nó gặp phần tử nhỏ hơn hoặc bằng.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // AN TOÀN: Các hoạt động không an toàn bên dưới liên quan đến việc lập chỉ mục mà không có kiểm tra ràng buộc (`get_unchecked` và `get_unchecked_mut`)
    // và sao chép bộ nhớ (`ptr::copy_nonoverlapping`).
    //
    // a.Lập chỉ mục:
    //  1. Chúng tôi đã kiểm tra kích thước của mảng là>=2.
    //  2. Tất cả việc lập chỉ mục mà chúng tôi sẽ làm luôn luôn ở giữa `0 <= index < len-1`.
    //
    // b.Sao chép bộ nhớ
    //  1. Chúng tôi đang thu thập các con trỏ đến các tham chiếu được đảm bảo là hợp lệ.
    //  2. Chúng không thể chồng chéo lên nhau bởi vì chúng tôi có được các con trỏ đến các chỉ số khác nhau của lát cắt.
    //     Cụ thể là `i` và `i+1`.
    //  3. Nếu lát được căn chỉnh đúng cách, các phần tử sẽ được căn chỉnh đúng.
    //     Người gọi có trách nhiệm đảm bảo rằng lát cắt được căn chỉnh chính xác.
    //
    // Xem bình luận bên dưới để biết thêm chi tiết.
    unsafe {
        // Nếu hai phần tử cuối cùng không theo thứ tự ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Đọc phần tử cuối cùng vào một biến được cấp phát ngăn xếp.
            // Nếu thao tác so sánh sau panics, `hole` sẽ bị loại bỏ và tự động ghi phần tử trở lại lát cắt.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Di chuyển phần tử thứ `i` sang phải một chỗ, do đó dịch chuyển lỗ sang trái.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` bị rơi và do đó sao chép `tmp` vào lỗ còn lại trong `v`.
        }
    }
}

/// Sắp xếp từng phần một lát cắt bằng cách dịch chuyển một số phần tử không có thứ tự xung quanh.
///
/// Trả về `true` nếu lát cắt được sắp xếp ở cuối.Hàm này là *O*(*n*) trường hợp xấu nhất.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Số lượng tối đa các cặp không có thứ tự liền kề sẽ được dịch chuyển.
    const MAX_STEPS: usize = 5;
    // Nếu lát cắt ngắn hơn mức này, không thay đổi bất kỳ phần tử nào.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // AN TOÀN: Chúng tôi đã thực hiện kiểm tra ràng buộc một cách rõ ràng với `i < len`.
        // Tất cả lập chỉ mục tiếp theo của chúng tôi chỉ nằm trong phạm vi `0 <= index < len`
        unsafe {
            // Tìm cặp phần tử không có thứ tự liền kề tiếp theo.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Chúng ta làm xong chưa?
        if i == len {
            return true;
        }

        // Không thay đổi các phần tử trên các mảng ngắn, điều đó có chi phí hiệu suất.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Hoán đổi cặp phần tử tìm được.Điều này đặt chúng theo đúng thứ tự.
        v.swap(i - 1, i);

        // Di chuyển phần tử nhỏ hơn sang trái.
        shift_tail(&mut v[..i], is_less);
        // Di chuyển phần tử lớn hơn sang bên phải.
        shift_head(&mut v[i..], is_less);
    }

    // Không quản lý để sắp xếp lát trong một số bước giới hạn.
    false
}

/// Sắp xếp một lát bằng cách sử dụng sắp xếp chèn, đây là trường hợp xấu nhất *O*(*n*^ 2).
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Sắp xếp `v` bằng cách sử dụng heapsort, đảm bảo *O*(*n*\*log(* n*)) trong trường hợp xấu nhất.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Heap nhị phân này tôn trọng `parent >= child` bất biến.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Những đứa con của `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Chọn đứa trẻ lớn hơn.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Dừng lại nếu bất biến giữ ở `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Trao đổi `node` với con lớn hơn, di chuyển xuống một bậc và tiếp tục sàng lọc.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Xây dựng đống theo thời gian tuyến tính.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Hiển thị các phần tử tối đa từ đống.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Chia `v` thành các phần tử nhỏ hơn `pivot`, tiếp theo là các phần tử lớn hơn hoặc bằng `pivot`.
///
///
/// Trả về số phần tử nhỏ hơn `pivot`.
///
/// Việc phân vùng được thực hiện theo từng khối để giảm thiểu chi phí của các hoạt động phân nhánh.
/// Ý tưởng này được trình bày trong bài báo [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Số phần tử trong một khối điển hình.
    const BLOCK: usize = 128;

    // Thuật toán phân vùng lặp lại các bước sau cho đến khi hoàn thành:
    //
    // 1. Theo dõi một khối từ phía bên trái để xác định các phần tử lớn hơn hoặc bằng trục xoay.
    // 2. Theo dõi một khối từ phía bên phải để xác định các phần tử nhỏ hơn trục.
    // 3. Trao đổi các yếu tố đã xác định giữa bên trái và bên phải.
    //
    // Chúng tôi giữ các biến sau cho một khối phần tử:
    //
    // 1. `block` - Số phần tử trong khối.
    // 2. `start` - Bắt đầu con trỏ vào mảng `offsets`.
    // 3. `end` - Con trỏ cuối vào mảng `offsets`.
    // 4. `hiệu số, Chỉ số của các phần tử không theo thứ tự trong khối.

    // Khối hiện tại ở phía bên trái (từ `l` đến `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Khối hiện tại ở phía bên phải (từ `r.sub(block_r)` to `r`).
    // AN TOÀN: Tài liệu cho .add() đề cập cụ thể rằng `vec.as_ptr().add(vec.len())` luôn an toàn`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Khi chúng tôi nhận được VLA, hãy thử tạo một mảng có độ dài `min(v.len(), 2 * BLOCK) `thay vì
    // hơn hai mảng kích thước cố định có độ dài `BLOCK`.VLA có thể tiết kiệm bộ nhớ cache hơn.

    // Trả về số phần tử giữa con trỏ `l` (inclusive) và `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Chúng tôi đã hoàn thành việc phân vùng theo từng khối khi `l` và `r` đến rất gần.
        // Sau đó, chúng tôi thực hiện một số công việc vá lỗi để phân vùng các phần tử còn lại ở giữa.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Số phần tử còn lại (vẫn chưa được so sánh với trục).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Điều chỉnh kích thước khối để khối bên trái và bên phải không chồng lên nhau, nhưng được căn chỉnh hoàn hảo để che toàn bộ khoảng trống còn lại.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Theo dõi các phần tử `block_l` từ phía bên trái.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // AN TOÀN: Các hoạt động không an toàn dưới đây liên quan đến việc sử dụng `offset`.
                //         Theo các điều kiện yêu cầu của hàm, chúng tôi thỏa mãn chúng vì:
                //         1. `offsets_l` được cấp phát ngăn xếp, và do đó được coi là đối tượng được cấp phát riêng biệt.
                //         2. Hàm `is_less` trả về `bool`.
                //            Truyền `bool` sẽ không bao giờ làm tràn `isize`.
                //         3. Chúng tôi đã đảm bảo rằng `block_l` sẽ là `<= BLOCK`.
                //            Ngoài ra, `end_l` ban đầu được đặt thành con trỏ bắt đầu của `offsets_` được khai báo trên ngăn xếp.
                //            Do đó, chúng ta biết rằng ngay cả trong trường hợp xấu nhất (tất cả các lệnh gọi của `is_less` đều trả về false), chúng ta sẽ chỉ có tối đa 1 byte được chuyển vào cuối.
                //        Một hoạt động không an toàn khác ở đây là bỏ tham chiếu `elem`.
                //        Tuy nhiên, `elem` ban đầu là con trỏ bắt đầu đến lát cắt luôn hợp lệ.
                unsafe {
                    // So sánh không nhánh.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Theo dõi các phần tử `block_r` từ phía bên phải.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // AN TOÀN: Các hoạt động không an toàn dưới đây liên quan đến việc sử dụng `offset`.
                //         Theo các điều kiện yêu cầu của hàm, chúng tôi thỏa mãn chúng vì:
                //         1. `offsets_r` được cấp phát ngăn xếp, và do đó được coi là đối tượng được cấp phát riêng biệt.
                //         2. Hàm `is_less` trả về `bool`.
                //            Truyền `bool` sẽ không bao giờ làm tràn `isize`.
                //         3. Chúng tôi đã đảm bảo rằng `block_r` sẽ là `<= BLOCK`.
                //            Ngoài ra, `end_r` ban đầu được đặt thành con trỏ bắt đầu của `offsets_` được khai báo trên ngăn xếp.
                //            Do đó, chúng ta biết rằng ngay cả trong trường hợp xấu nhất (tất cả các lệnh gọi của `is_less` đều trả về true), chúng ta sẽ chỉ có nhiều nhất 1 byte được chuyển vào cuối.
                //        Một hoạt động không an toàn khác ở đây là bỏ tham chiếu `elem`.
                //        Tuy nhiên, `elem` ban đầu là `1 *sizeof(T)` quá cuối và chúng tôi giảm nó xuống `1* sizeof(T)` trước khi truy cập nó.
                //        Thêm vào đó, `block_r` được khẳng định là nhỏ hơn `BLOCK` và do đó, `elem` sẽ ít nhất là trỏ đến phần đầu của lát cắt.
                unsafe {
                    // So sánh không nhánh.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Số phần tử không theo thứ tự để hoán đổi giữa bên trái và bên phải.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Thay vì hoán đổi một cặp tại thời điểm đó, sẽ hiệu quả hơn nếu thực hiện hoán vị tuần hoàn.
            // Điều này không hoàn toàn tương đương với hoán đổi, nhưng tạo ra một kết quả tương tự bằng cách sử dụng ít hoạt động bộ nhớ hơn.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Tất cả các phần tử không có thứ tự trong khối bên trái đã được di chuyển.Di chuyển đến khối tiếp theo.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Tất cả các phần tử không có thứ tự trong khối bên phải đã được di chuyển.Di chuyển đến khối trước đó.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Tất cả những gì còn lại bây giờ nhiều nhất là một khối (bên trái hoặc bên phải) với các phần tử không theo thứ tự cần được di chuyển.
    // Các phần tử còn lại như vậy có thể được chuyển đơn giản đến cuối trong khối của chúng.
    //

    if start_l < end_l {
        // Khối bên trái vẫn còn.
        // Di chuyển các phần tử không theo thứ tự còn lại của nó sang ngoài cùng bên phải.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Khối bên phải vẫn còn.
        // Di chuyển các phần tử không theo thứ tự còn lại của nó sang ngoài cùng bên trái.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Không có gì khác để làm, chúng tôi đã hoàn thành.
        width(v.as_mut_ptr(), l)
    }
}

/// Chia `v` thành các phần tử nhỏ hơn `v[pivot]`, tiếp theo là các phần tử lớn hơn hoặc bằng `v[pivot]`.
///
///
/// Trả về một bộ:
///
/// 1. Số phần tử nhỏ hơn `v[pivot]`.
/// 2. Đúng nếu `v` đã được phân vùng.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Đặt trục ở đầu lát.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Đọc pivot vào một biến được phân bổ theo ngăn xếp để có hiệu quả.
        // Nếu thao tác so sánh sau panics, trục xoay sẽ được tự động ghi lại vào lát cắt.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Tìm cặp phần tử không có thứ tự đầu tiên.
        let mut l = 0;
        let mut r = v.len();

        // AN TOÀN: Không an toàn bên dưới liên quan đến việc lập chỉ mục một mảng.
        // Đối với cái đầu tiên: Chúng tôi đã thực hiện kiểm tra giới hạn ở đây với `l < r`.
        // Đối với cái thứ hai: Ban đầu chúng tôi có `l == 0` và `r == v.len()` và chúng tôi đã kiểm tra `l < r` đó ở mọi thao tác lập chỉ mục.
        //                     Từ đây, chúng ta biết rằng `r` ít nhất phải là `r == l` đã được chứng minh là hợp lệ từ lần đầu tiên.
        unsafe {
            // Tìm phần tử đầu tiên lớn hơn hoặc bằng trục.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Tìm phần tử cuối cùng nhỏ hơn mà trục quay.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` vượt ra khỏi phạm vi và ghi pivot (là một biến do ngăn xếp cấp phát) trở lại lát cắt ở vị trí ban đầu.
        // Bước này rất quan trọng trong việc đảm bảo an toàn!
        //
    };

    // Đặt trục giữa hai phân vùng.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Chia `v` thành các phần tử bằng `v[pivot]`, tiếp theo là các phần tử lớn hơn `v[pivot]`.
///
/// Trả về số phần tử bằng trục xoay.
/// Giả định rằng `v` không chứa các phần tử nhỏ hơn trục.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Đặt trục ở đầu lát.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Đọc pivot vào một biến được phân bổ theo ngăn xếp để có hiệu quả.
    // Nếu thao tác so sánh sau panics, trục xoay sẽ được tự động ghi lại vào lát cắt.
    // AN TOÀN: Con trỏ ở đây là hợp lệ vì nó được lấy từ một tham chiếu đến một lát cắt.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Bây giờ phân vùng slice.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // AN TOÀN: Không an toàn bên dưới liên quan đến việc lập chỉ mục một mảng.
        // Đối với cái đầu tiên: Chúng tôi đã thực hiện kiểm tra giới hạn ở đây với `l < r`.
        // Đối với cái thứ hai: Ban đầu chúng tôi có `l == 0` và `r == v.len()` và chúng tôi đã kiểm tra `l < r` đó ở mọi thao tác lập chỉ mục.
        //                     Từ đây, chúng ta biết rằng `r` ít nhất phải là `r == l` đã được chứng minh là hợp lệ từ lần đầu tiên.
        unsafe {
            // Tìm phần tử đầu tiên lớn hơn pivot.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Tìm phần tử cuối cùng bằng trục.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Chúng ta làm xong chưa?
            if l >= r {
                break;
            }

            // Hoán đổi cặp phần tử không theo thứ tự đã tìm thấy.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Chúng tôi tìm thấy các phần tử `l` bằng trục.Thêm 1 vào tài khoản cho trục chính.
    l + 1

    // `_pivot_guard` vượt ra khỏi phạm vi và ghi pivot (là một biến do ngăn xếp cấp phát) trở lại lát cắt ở vị trí ban đầu.
    // Bước này rất quan trọng trong việc đảm bảo an toàn!
}

/// Phân tán một số yếu tố xung quanh để cố gắng phá vỡ các mẫu có thể gây ra các phân vùng mất cân bằng trong nhanh chóng.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Bộ tạo số giả từ giấy "Xorshift RNGs" của George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Lấy số ngẫu nhiên modulo số này.
        // Con số phù hợp với `usize` vì `len` không lớn hơn `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Một số ứng cử viên xoay sẽ ở gần chỉ số này.Hãy ngẫu nhiên hóa chúng.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Tạo mô-đun số ngẫu nhiên `len`.
            // Tuy nhiên, để tránh các hoạt động tốn kém, trước tiên, chúng tôi lấy nó theo mô-đun công suất hai, sau đó giảm `len` cho đến khi nó phù hợp với phạm vi `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` được đảm bảo nhỏ hơn `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Chọn một trục trong `v` và trả về chỉ mục và `true` nếu phần có thể đã được sắp xếp.
///
/// Các phần tử trong `v` có thể được sắp xếp lại trong quá trình này.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Độ dài tối thiểu để chọn phương pháp trung vị của trung vị.
    // Các lát cắt ngắn hơn sử dụng phương pháp trung vị của ba đơn giản.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Số lượng hoán đổi tối đa có thể được thực hiện trong chức năng này.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Ba chỉ số gần đó chúng tôi sẽ chọn một trục.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Đếm tổng số lần hoán đổi mà chúng tôi sắp thực hiện trong khi sắp xếp các chỉ số.
    let mut swaps = 0;

    if len >= 8 {
        // Hoán đổi các chỉ số để `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Hoán đổi các chỉ số để `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Tìm giá trị trung bình của `v[a - 1], v[a], v[a + 1]` và lưu chỉ mục vào `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Tìm trung bình trong vùng lân cận của `a`, `b` và `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Tìm giá trị trung bình giữa `a`, `b` và `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Số lần hoán đổi tối đa đã được thực hiện.
        // Rất có thể lát cắt đang giảm dần hoặc chủ yếu là giảm dần, vì vậy việc đảo ngược có thể sẽ giúp sắp xếp nó nhanh hơn.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Sắp xếp `v` một cách đệ quy.
///
/// Nếu lát cắt có một phần trước trong mảng ban đầu, nó được chỉ định là `pred`.
///
/// `limit` là số lượng phân vùng không cân bằng được phép trước khi chuyển sang `heapsort`.
/// Nếu không, chức năng này sẽ ngay lập tức chuyển sang heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Các lát có độ dài tối đa này được sắp xếp bằng cách sử dụng sắp xếp chèn.
    const MAX_INSERTION: usize = 20;

    // Đúng nếu phân vùng cuối cùng được cân bằng hợp lý.
    let mut was_balanced = true;
    // Đúng nếu lần phân vùng cuối cùng không xáo trộn các phần tử (phần đã được phân vùng).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Các lát rất ngắn được sắp xếp bằng cách sử dụng sắp xếp chèn.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Nếu có quá nhiều lựa chọn trục không tốt được thực hiện, chỉ cần quay trở lại đống để đảm bảo `O(n * log(n))` trong trường hợp xấu nhất.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Nếu phân vùng cuối cùng không cân bằng, hãy thử phá vỡ các mẫu trong lát bằng cách xáo trộn một số yếu tố xung quanh.
        // Hy vọng rằng chúng tôi sẽ chọn một trục tốt hơn lần này.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Chọn một trục và thử đoán xem lát cắt đã được sắp xếp hay chưa.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Nếu phân vùng cuối cùng được cân bằng và không xáo trộn các phần tử và nếu lựa chọn xoay vòng dự đoán lát cắt có thể đã được sắp xếp ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Hãy thử xác định một số yếu tố không theo thứ tự và chuyển chúng sang vị trí chính xác.
            // Nếu lát cắt được sắp xếp hoàn toàn, chúng ta đã hoàn tất.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Nếu trục được chọn bằng với trục trước, thì đó là phần tử nhỏ nhất trong lát.
        // Phân chia lát cắt thành các phần tử bằng và các phần tử lớn hơn trục.
        // Trường hợp này thường xảy ra khi lát chứa nhiều phần tử trùng lặp.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Tiếp tục sắp xếp các phần tử lớn hơn trục.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Phân vùng lát cắt.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Chia lát thành `left`, `pivot` và `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Chỉ đệ quy vào cạnh ngắn hơn để giảm thiểu tổng số lệnh gọi đệ quy và tiêu tốn ít không gian ngăn xếp hơn.
        // Sau đó, chỉ cần tiếp tục với cạnh dài hơn (điều này giống với đệ quy đuôi).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Sắp xếp `v` bằng cách sử dụng nhanh kiểu đánh bại mẫu, đây là trường hợp xấu nhất *O*(*n*\*log(* n*)).
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Sắp xếp không có hành vi có ý nghĩa trên các loại có kích thước bằng không.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Giới hạn số lượng phân vùng không cân bằng cho `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Đối với các lát cắt có độ dài như vậy, có lẽ chỉ cần sắp xếp chúng sẽ nhanh hơn.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Chọn một trục
        let (pivot, _) = choose_pivot(v, is_less);

        // Nếu trục được chọn bằng với trục trước, thì đó là phần tử nhỏ nhất trong lát.
        // Phân chia lát cắt thành các phần tử bằng và các phần tử lớn hơn trục.
        // Trường hợp này thường xảy ra khi lát chứa nhiều phần tử trùng lặp.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Nếu chúng tôi đã vượt qua chỉ số của mình, thì chúng tôi tốt.
                if mid > index {
                    return;
                }

                // Nếu không, hãy tiếp tục sắp xếp các phần tử lớn hơn trục.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Chia lát thành `left`, `pivot` và `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Nếu chỉ số giữa==thì chúng ta đã hoàn tất, vì partition() đảm bảo rằng tất cả các phần tử sau giữa đều lớn hơn hoặc bằng giữa.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Sắp xếp không có hành vi có ý nghĩa trên các loại có kích thước bằng không.Không làm gì cả.
    } else if index == v.len() - 1 {
        // Tìm phần tử max và đặt nó ở vị trí cuối cùng của mảng.
        // Chúng tôi miễn phí sử dụng `unwrap()` ở đây vì chúng tôi biết v không được để trống.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Tìm phần tử min và đặt nó vào vị trí đầu tiên của mảng.
        // Chúng tôi miễn phí sử dụng `unwrap()` ở đây vì chúng tôi biết v không được để trống.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}