//! Các thao tác trên ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Kiểm tra xem tất cả các byte trong phần này có nằm trong phạm vi ASCII hay không.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Kiểm tra xem hai lát có phải là đối sánh không phân biệt chữ hoa chữ thường ASCII hay không.
    ///
    /// Tương tự như `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, nhưng không phân bổ và sao chép các khoảng thời gian tạm thời.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Chuyển đổi lát cắt này thành dạng chữ hoa ASCII tương đương tại chỗ.
    ///
    /// Các chữ cái ASCII 'a' đến 'z' được ánh xạ thành 'A' đến 'Z', nhưng các chữ cái không phải ASCII thì không thay đổi.
    ///
    /// Để trả về một giá trị viết hoa mới mà không sửa đổi giá trị hiện có, hãy sử dụng [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Chuyển đổi lát cắt này thành chữ thường ASCII tương đương tại chỗ.
    ///
    /// Các chữ cái ASCII 'A' đến 'Z' được ánh xạ thành 'a' đến 'z', nhưng các chữ cái không phải ASCII thì không thay đổi.
    ///
    /// Để trả về một giá trị chữ thường mới mà không sửa đổi giá trị hiện có, hãy sử dụng [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Trả về `true` nếu bất kỳ byte nào trong từ `v` là nonascii (>=128).
/// Snarfed từ `../str/mod.rs`, thực hiện điều gì đó tương tự đối với xác thực utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Kiểm tra ASCII được tối ưu hóa sẽ sử dụng các hoạt động tận dụng tại một thời điểm thay vì các hoạt động byte tại một thời điểm (khi có thể).
///
/// Thuật toán chúng tôi sử dụng ở đây khá đơn giản.Nếu `s` quá ngắn, chúng ta chỉ cần kiểm tra từng byte là xong.Nếu không thì:
///
/// - Đọc từ đầu tiên với một tải không dấu.
/// - Căn chỉnh con trỏ, đọc các từ tiếp theo cho đến khi kết thúc với các tải được căn chỉnh.
/// - Đọc `usize` cuối cùng từ `s` với tải không đổi.
///
/// Nếu bất kỳ tải nào trong số này tạo ra thứ gì đó mà `contains_nonascii` (above) trả về true, thì chúng tôi biết câu trả lời là sai.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Nếu chúng ta không thu được gì từ việc triển khai từng từ một, hãy quay trở lại vòng lặp vô hướng.
    //
    // Chúng tôi cũng làm điều này cho các kiến trúc mà `size_of::<usize>()` không đủ căn chỉnh cho `usize`, vì đó là một trường hợp edge kỳ lạ.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Chúng tôi luôn đọc từ đầu tiên không dấu, có nghĩa là `align_offset` là
    // 0, chúng tôi sẽ đọc lại cùng một giá trị cho lần đọc được căn chỉnh.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // AN TOÀN: Chúng tôi xác minh `len < USIZE_SIZE` ở trên.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Chúng tôi đã kiểm tra điều này ở trên, hơi ngầm.
    // Lưu ý rằng `offset_to_aligned` là `align_offset` hoặc `USIZE_SIZE`, cả hai đều được kiểm tra rõ ràng ở trên.
    //
    debug_assert!(offset_to_aligned <= len);

    // AN TOÀN: word_ptr là ptr sử dụng (căn chỉnh đúng) mà chúng tôi sử dụng để đọc
    // phần giữa của lát.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` là chỉ số byte của `word_ptr`, được sử dụng để kiểm tra kết thúc vòng lặp.
    let mut byte_pos = offset_to_aligned;

    // Kiểm tra hoang tưởng về sự liên kết, vì chúng tôi sắp thực hiện một loạt các tải không được căn chỉnh.
    // Trong thực tế, điều này là không thể trừ một lỗi trong `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Đọc các từ tiếp theo cho đến từ được căn cuối cùng, không bao gồm từ được căn cuối cùng sẽ được thực hiện trong kiểm tra đuôi sau này, để đảm bảo rằng đuôi luôn là một `usize` nhiều nhất đến branch `byte_pos == len` bổ sung.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Sanity kiểm tra xem đã đọc có giới hạn không
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Và những giả định của chúng tôi về `byte_pos` vẫn giữ nguyên.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // AN TOÀN: Chúng tôi biết `word_ptr` được căn chỉnh đúng cách (vì
        // `align_offset`) và chúng tôi biết rằng chúng tôi có đủ byte giữa `word_ptr` và cuối
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // AN TOÀN: Chúng tôi biết rằng `byte_pos <= len - USIZE_SIZE`, có nghĩa là
        // sau `add` này, `word_ptr` sẽ chỉ là một quá khứ.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Kiểm tra tình trạng để đảm bảo thực sự chỉ còn một chiếc `usize`.
    // Điều này phải được đảm bảo bởi điều kiện vòng lặp của chúng tôi.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // AN TOÀN: Điều này dựa trên `len >= USIZE_SIZE`, mà chúng tôi kiểm tra ngay từ đầu.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}