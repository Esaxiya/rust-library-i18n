// Bản triển khai gốc được lấy từ rust-memchr.
// Bản quyền 2015 Andrew Gallant, bluss và Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Sử dụng sự cắt ngắn.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Trả về `true` nếu `x` chứa bất kỳ byte 0 nào.
///
/// Từ *Matters Computational*, J. Arndt:
///
/// "Ý tưởng là trừ đi một trong mỗi byte và sau đó tìm các byte trong đó khoản vay được truyền đến mức quan trọng nhất
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Trả về chỉ mục đầu tiên khớp với byte `x` trong `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Đường dẫn nhanh cho các lát nhỏ
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Quét một giá trị byte đơn bằng cách đọc hai từ `usize` cùng một lúc.
    //
    // Chia `text` thành ba phần
    // - phần đầu không căn, trước địa chỉ căn từ đầu tiên trong văn bản
    // - nội dung, quét 2 từ cùng một lúc
    // - phần cuối cùng còn lại, kích thước <2 từ

    // tìm kiếm đến một ranh giới được căn chỉnh
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // tìm kiếm nội dung của văn bản
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // AN TOÀN: vị từ của while đảm bảo khoảng cách ít nhất là 2 * usize_byte
        // giữa phần bù và phần cuối của lát cắt.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // ngắt nếu có một byte phù hợp
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Tìm byte sau điểm mà vòng lặp nội dung dừng lại.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Trả về chỉ mục cuối cùng khớp với byte `x` trong `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Quét một giá trị byte đơn bằng cách đọc hai từ `usize` cùng một lúc.
    //
    // Chia `text` thành ba phần:
    // - đuôi không dấu, sau địa chỉ căn từ cuối cùng trong văn bản,
    // - nội dung, được quét 2 từ cùng một lúc,
    // - byte đầu tiên còn lại, kích thước <2 từ.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Chúng tôi gọi điều này chỉ để lấy độ dài của tiền tố và hậu tố.
        // Ở giữa, chúng tôi luôn xử lý hai khối cùng một lúc.
        // AN TOÀN: chuyển đổi `[u8]` sang `[usize]` là an toàn ngoại trừ sự khác biệt về kích thước được xử lý bởi `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Tìm kiếm nội dung của văn bản, đảm bảo rằng chúng tôi không vượt qua min_aligned_offset.
    // offset luôn được căn chỉnh, vì vậy chỉ cần kiểm tra `>` là đủ và tránh có thể bị tràn.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // AN TOÀN: offset bắt đầu từ len, suffix.len(), miễn là nó lớn hơn
        // min_aligned_offset (prefix.len()) khoảng cách còn lại ít nhất là 2 * chunk_byte.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Ngắt nếu có một byte phù hợp.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Tìm byte trước điểm mà vòng lặp nội dung dừng lại.
    text[..offset].iter().rposition(|elt| *elt == x)
}