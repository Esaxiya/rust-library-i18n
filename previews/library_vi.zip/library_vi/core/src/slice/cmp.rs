//! So sánh traits cho `[T]`.

use crate::cmp;
use crate::cmp::Ordering::{self, Greater, Less};
use crate::mem;

use super::from_raw_parts;
use super::memchr;

extern "C" {
    /// Thực hiện cuộc gọi đã cung cấp memcmp.
    ///
    /// Phiên dịch dữ liệu dưới dạng u8.
    ///
    /// Trả về 0 cho bằng, <0 cho nhỏ hơn và> 0 cho lớn hơn.
    ///
    // FIXME(#32610): Loại trả lại phải là c_int
    fn memcmp(s1: *const u8, s2: *const u8, n: usize) -> i32;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> PartialEq<[B]> for [A]
where
    A: PartialEq<B>,
{
    fn eq(&self, other: &[B]) -> bool {
        SlicePartialEq::equal(self, other)
    }

    fn ne(&self, other: &[B]) -> bool {
        SlicePartialEq::not_equal(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for [T] {}

/// So sánh triển khai của vectors [lexicographically](Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for [T] {
    fn cmp(&self, other: &[T]) -> Ordering {
        SliceOrd::compare(self, other)
    }
}

/// So sánh triển khai của vectors [lexicographically](Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for [T] {
    fn partial_cmp(&self, other: &[T]) -> Option<Ordering> {
        SlicePartialOrd::partial_compare(self, other)
    }
}

#[doc(hidden)]
// trait trung gian để chuyên môn hóa PartialEq của lát cắt
trait SlicePartialEq<B> {
    fn equal(&self, other: &[B]) -> bool;

    fn not_equal(&self, other: &[B]) -> bool {
        !self.equal(other)
    }
}

// Bình đẳng lát chung
impl<A, B> SlicePartialEq<B> for [A]
where
    A: PartialEq<B>,
{
    default fn equal(&self, other: &[B]) -> bool {
        if self.len() != other.len() {
            return false;
        }

        self.iter().zip(other.iter()).all(|(x, y)| x == y)
    }
}

// Sử dụng memcmp để bình đẳng theo từng byte khi các loại cho phép
impl<A, B> SlicePartialEq<B> for [A]
where
    A: BytewiseEquality<B>,
{
    fn equal(&self, other: &[B]) -> bool {
        if self.len() != other.len() {
            return false;
        }

        // AN TOÀN: `self` và `other` là tài liệu tham khảo và do đó được đảm bảo là hợp lệ.
        // Hai lát cắt đã được kiểm tra để có cùng kích thước ở trên.
        unsafe {
            let size = mem::size_of_val(self);
            memcmp(self.as_ptr() as *const u8, other.as_ptr() as *const u8, size) == 0
        }
    }
}

#[doc(hidden)]
// trait trung gian để chuyên môn hóa PartialOrd của lát cắt
trait SlicePartialOrd: Sized {
    fn partial_compare(left: &[Self], right: &[Self]) -> Option<Ordering>;
}

impl<A: PartialOrd> SlicePartialOrd for A {
    default fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        let l = cmp::min(left.len(), right.len());

        // Cắt giảm phạm vi lặp lại vòng lặp để cho phép loại bỏ kiểm tra giới hạn trong trình biên dịch
        //
        let lhs = &left[..l];
        let rhs = &right[..l];

        for i in 0..l {
            match lhs[i].partial_cmp(&rhs[i]) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }

        left.len().partial_cmp(&right.len())
    }
}

// Đây là cấy ghép mà chúng tôi muốn có.Thật không may, nó không phải là âm thanh.
// Xem `partial_ord_slice.rs`.
/*
impl<A> SlicePartialOrd for A
where
    A: Ord,
{
    default fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        Some(SliceOrd::compare(left, right))
    }
}
*/

impl<A: AlwaysApplicableOrd> SlicePartialOrd for A {
    fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        Some(SliceOrd::compare(left, right))
    }
}

#[rustc_specialization_trait]
trait AlwaysApplicableOrd: SliceOrd + Ord {}

macro_rules! always_applicable_ord {
    ($([$($p:tt)*] $t:ty,)*) => {
        $(impl<$($p)*> AlwaysApplicableOrd for $t {})*
    }
}

always_applicable_ord! {
    [] u8, [] u16, [] u32, [] u64, [] u128, [] usize,
    [] i8, [] i16, [] i32, [] i64, [] i128, [] isize,
    [] bool, [] char,
    [T: ?Sized] *const T, [T: ?Sized] *mut T,
    [T: AlwaysApplicableOrd] &T,
    [T: AlwaysApplicableOrd] &mut T,
    [T: AlwaysApplicableOrd] Option<T>,
}

#[doc(hidden)]
// trait trung gian để chuyên môn hóa Ord của lát cắt
trait SliceOrd: Sized {
    fn compare(left: &[Self], right: &[Self]) -> Ordering;
}

impl<A: Ord> SliceOrd for A {
    default fn compare(left: &[Self], right: &[Self]) -> Ordering {
        let l = cmp::min(left.len(), right.len());

        // Cắt giảm phạm vi lặp lại vòng lặp để cho phép loại bỏ kiểm tra giới hạn trong trình biên dịch
        //
        let lhs = &left[..l];
        let rhs = &right[..l];

        for i in 0..l {
            match lhs[i].cmp(&rhs[i]) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }

        left.len().cmp(&right.len())
    }
}

// memcmp so sánh một chuỗi các byte không dấu về mặt từ vựng.
// điều này khớp với thứ tự chúng tôi muốn cho [u8], nhưng không khớp với thứ tự khác (thậm chí không phải [i8]).
impl SliceOrd for u8 {
    #[inline]
    fn compare(left: &[Self], right: &[Self]) -> Ordering {
        let order =
            // AN TOÀN: `left` và `right` là tài liệu tham khảo và do đó được đảm bảo là hợp lệ.
            // Chúng tôi sử dụng độ dài tối thiểu của cả hai vùng để đảm bảo rằng cả hai vùng đều hợp lệ để đọc trong khoảng thời gian đó.
            //
            unsafe { memcmp(left.as_ptr(), right.as_ptr(), cmp::min(left.len(), right.len())) };
        if order == 0 {
            left.len().cmp(&right.len())
        } else if order < 0 {
            Less
        } else {
            Greater
        }
    }
}

// Hack để cho phép chuyên về `Eq` mặc dù `Eq` có một phương pháp.
#[rustc_unsafe_specialization_marker]
trait MarkerEq<T>: PartialEq<T> {}

impl<T: Eq> MarkerEq<T> for T {}

#[doc(hidden)]
/// Trait được triển khai cho các loại có thể được so sánh để bình đẳng bằng cách sử dụng biểu diễn theo byte của chúng
///
#[rustc_specialization_trait]
trait BytewiseEquality<T>: MarkerEq<T> + Copy {}

macro_rules! impl_marker_for {
    ($traitname:ident, $($ty:ty)*) => {
        $(
            impl $traitname<$ty> for $ty { }
        )*
    }
}

impl_marker_for!(BytewiseEquality,
                 u8 i8 u16 i16 u32 i32 u64 i64 u128 i128 usize isize char bool);

pub(super) trait SliceContains: Sized {
    fn slice_contains(&self, x: &[Self]) -> bool;
}

impl<T> SliceContains for T
where
    T: PartialEq,
{
    default fn slice_contains(&self, x: &[Self]) -> bool {
        x.iter().any(|y| *y == *self)
    }
}

impl SliceContains for u8 {
    #[inline]
    fn slice_contains(&self, x: &[Self]) -> bool {
        memchr::memchr(*self, x).is_some()
    }
}

impl SliceContains for i8 {
    #[inline]
    fn slice_contains(&self, x: &[Self]) -> bool {
        let byte = *self as u8;
        // AN TOÀN: `i8` và `u8` có cùng bố cục bộ nhớ, do đó truyền `x.as_ptr()`
        // vì `*const u8` là an toàn.
        // `x.as_ptr()` đến từ một tham chiếu và do đó được đảm bảo là hợp lệ để đọc cho chiều dài của lát `x.len()`, không thể lớn hơn `isize::MAX`.
        // Slice trả về không bao giờ bị đột biến.
        let bytes: &[u8] = unsafe { from_raw_parts(x.as_ptr() as *const u8, x.len()) };
        memchr::memchr(byte, bytes).is_some()
    }
}