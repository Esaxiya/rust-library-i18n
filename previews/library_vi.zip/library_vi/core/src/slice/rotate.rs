// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Xoay phạm vi `[mid-left, mid+right)` sao cho phần tử tại `mid` trở thành phần tử đầu tiên.Tương tự, xoay phạm vi các phần tử `left` sang trái hoặc các phần tử `right` sang phải.
///
/// # Safety
///
/// Phạm vi được chỉ định phải có giá trị để đọc và ghi.
///
/// # Algorithm
///
/// Thuật toán 1 được sử dụng cho các giá trị nhỏ của `left + right` hoặc cho `T` lớn.
/// Các phần tử được di chuyển vào vị trí cuối cùng của chúng lần lượt bắt đầu từ `mid - left` và tiến lên theo các bước `right` theo modulo `left + right`, sao cho chỉ cần một bước tạm thời.
/// Cuối cùng, chúng tôi quay trở lại `mid - left`.
/// Tuy nhiên, nếu `gcd(left + right, right)` không phải là 1, các bước trên đã bỏ qua các phần tử.
/// Ví dụ:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// May mắn thay, số lượng phần tử bị bỏ qua giữa các phần tử đã hoàn thiện luôn bằng nhau, vì vậy chúng tôi có thể chỉ cần bù lại vị trí bắt đầu của mình và thực hiện nhiều vòng hơn (tổng số vòng là `gcd(left + right, right)` value).
///
/// Kết quả cuối cùng là tất cả các phần tử được hoàn thiện một lần và chỉ một lần.
///
/// Thuật toán 2 được sử dụng nếu `left + right` lớn nhưng `min(left, right)` đủ nhỏ để vừa với bộ đệm ngăn xếp.
/// Các phần tử `min(left, right)` được sao chép vào bộ đệm, `memmove` được áp dụng cho các phần tử khác và các phần tử trên bộ đệm được chuyển trở lại lỗ ở phía đối diện với nơi chúng xuất phát.
///
/// Các thuật toán có thể được vectơ hóa hoạt động tốt hơn các thuật toán trên khi `left + right` trở nên đủ lớn.
/// Thuật toán 1 có thể được vectơ hóa bằng cách chia nhỏ và thực hiện nhiều vòng cùng một lúc, nhưng trung bình có quá ít vòng cho đến khi `left + right` là rất lớn, và trường hợp xấu nhất là một vòng duy nhất luôn có.
/// Thay vào đó, thuật toán 3 sử dụng việc hoán đổi lặp đi lặp lại các phần tử `min(left, right)` cho đến khi vấn đề xoay nhỏ hơn không còn.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// khi `left < right`, việc hoán đổi xảy ra từ bên trái.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. các thuật toán dưới đây có thể không thành công nếu những trường hợp này không được kiểm tra
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Thuật toán 1 Microbenchmarks chỉ ra rằng hiệu suất trung bình cho các thay đổi ngẫu nhiên là tốt hơn cho đến khoảng `left + right == 32`, nhưng hiệu suất trong trường hợp xấu nhất thậm chí là khoảng 16.
            // 24 được chọn làm trung gian.
            // Nếu kích thước của `T` lớn hơn 4 'usize`, thuật toán này cũng hoạt động tốt hơn các thuật toán khác.
            //
            //
            let x = unsafe { mid.sub(left) };
            // bắt đầu của vòng đầu tiên
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` có thể được tìm thấy trước bằng cách tính toán `gcd(left + right, right)`, nhưng sẽ nhanh hơn nếu thực hiện một vòng lặp tính toán gcd như một hiệu ứng phụ, sau đó thực hiện phần còn lại của đoạn
            //
            //
            let mut gcd = right;
            // điểm chuẩn tiết lộ rằng việc hoán đổi các thời gian tạm thời sẽ nhanh hơn thay vì đọc một đoạn tạm thời một lần, sao chép ngược và sau đó viết tạm thời đó vào cuối cùng.
            // Điều này có thể là do việc hoán đổi hoặc thay thế các địa chỉ tạm thời chỉ sử dụng một địa chỉ bộ nhớ trong vòng lặp thay vì cần quản lý hai địa chỉ.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // thay vì tăng `i` và sau đó kiểm tra xem nó có nằm ngoài giới hạn hay không, chúng tôi kiểm tra xem `i` có đi ra ngoài giới hạn trong lần tăng tiếp theo hay không.
                // Điều này ngăn cản mọi gói con trỏ hoặc `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // kết thúc vòng đầu tiên
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // điều kiện này phải ở đây nếu `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // hoàn thành đoạn với nhiều vòng hơn
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` không phải là loại có kích thước bằng 0, vì vậy bạn có thể chia theo kích thước của nó.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Thuật toán 2 `[T; 0]` ở đây là để đảm bảo điều này được căn chỉnh thích hợp cho T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Thuật toán 3 Có một cách hoán đổi thay thế liên quan đến việc tìm vị trí hoán đổi cuối cùng của thuật toán này và hoán đổi bằng cách sử dụng đoạn cuối cùng đó thay vì hoán đổi các đoạn liền kề như thuật toán này đang làm, nhưng cách này vẫn nhanh hơn.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Thuật toán 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}