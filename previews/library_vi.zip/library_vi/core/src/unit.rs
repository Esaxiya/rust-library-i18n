use crate::iter::FromIterator;

/// Thu gọn tất cả các mục đơn vị từ một trình lặp thành một.
///
/// Điều này hữu ích hơn khi được kết hợp với các phần tóm tắt cấp cao hơn, như thu thập vào `Result<(), E>` nơi bạn chỉ quan tâm đến các lỗi:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}