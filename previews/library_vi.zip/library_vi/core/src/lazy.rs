//! Giá trị lười biếng và khởi tạo một lần dữ liệu tĩnh.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// Một ô chỉ có thể được ghi vào một lần.
///
/// Không giống như `RefCell`, `OnceCell` chỉ cung cấp các tham chiếu `&T` được chia sẻ với giá trị của nó.
/// Không giống như `Cell`, `OnceCell` không yêu cầu sao chép hoặc thay thế giá trị để truy cập nó.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // Bất biến: được viết cho nhiều nhất một lần.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// Tạo một ô trống mới.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// Nhận tham chiếu đến giá trị cơ bản.
    ///
    /// Trả về `None` nếu ô trống.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // AN TOÀN: An toàn do tính bất biến của `bên trong`
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// Nhận tham chiếu có thể thay đổi thành giá trị cơ bản.
    ///
    /// Trả về `None` nếu ô trống.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // AN TOÀN: An toàn vì chúng tôi có quyền truy cập duy nhất
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// Đặt nội dung của ô thành `value`.
    ///
    /// # Errors
    ///
    /// Phương thức này trả về `Ok(())` nếu ô trống và `Err(value)` nếu ô đã đầy.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // AN TOÀN: An toàn vì chúng tôi không thể có các khoản vay có thể thay đổi chồng chéo
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // AN TOÀN: Đây là nơi duy nhất mà chúng tôi đặt vị trí, không có cuộc đua
        // do reentrancy/concurrency là có thể, và chúng tôi đã kiểm tra vị trí đó hiện là `None`, vì vậy, ghi này duy trì sự bất biến của `bên trong`.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// Lấy nội dung của ô, khởi tạo nó bằng `f` nếu ô trống.
    ///
    /// # Panics
    ///
    /// Nếu `f` panics, panic được truyền tới người gọi và ô vẫn chưa được khởi tạo.
    ///
    ///
    /// Lỗi khi khởi tạo lại ô từ `f`.Làm như vậy dẫn đến một panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// Lấy nội dung của ô, khởi tạo nó bằng `f` nếu ô trống.
    /// Nếu ô trống và `f` không thành công, lỗi sẽ được trả về.
    ///
    /// # Panics
    ///
    /// Nếu `f` panics, panic được truyền tới người gọi và ô vẫn chưa được khởi tạo.
    ///
    ///
    /// Lỗi khi khởi tạo lại ô từ `f`.Làm như vậy dẫn đến một panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // Lưu ý rằng *một số* dạng khởi chạy lại có thể dẫn đến UB (xem thử nghiệm `reentrant_init`).
        // Tôi tin rằng chỉ cần loại bỏ `assert` này, trong khi giữ lại `set/get` sẽ rất tốt, nhưng nó có vẻ tốt hơn với panic, hơn là âm thầm sử dụng một giá trị cũ.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// Sử dụng ô, trả về giá trị được bao bọc.
    ///
    /// Trả về `None` nếu ô trống.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // Vì `into_inner` nhận `self` theo giá trị, trình biên dịch xác minh tĩnh rằng nó hiện không được mượn.
        // Vì vậy, nó là an toàn để chuyển ra khỏi `Option<T>`.
        self.inner.into_inner()
    }

    /// Lấy giá trị ra khỏi `OnceCell` này, chuyển nó trở lại trạng thái chưa khởi tạo.
    ///
    /// Không có tác dụng và trả về `None` nếu `OnceCell` chưa được khởi chạy.
    ///
    /// An toàn được đảm bảo bằng cách yêu cầu tham chiếu có thể thay đổi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// Một giá trị được khởi tạo trong lần truy cập đầu tiên.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   sẵn sàng khởi tạo
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// Tạo một giá trị lười biếng mới với chức năng khởi tạo đã cho.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// Buộc đánh giá giá trị lười biếng này và trả về một tham chiếu đến kết quả.
    ///
    ///
    /// Điều này tương đương với `Deref` impl, nhưng rõ ràng.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// Tạo một giá trị lười biếng mới bằng cách sử dụng `Default` làm hàm khởi tạo.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}