//! Một mô-đun để làm việc với dữ liệu mượn.

#![stable(feature = "rust1", since = "1.0.0")]

/// Một trait để mượn dữ liệu.
///
/// Trong Rust, thông thường cung cấp các đại diện khác nhau của một loại cho các trường hợp sử dụng khác nhau.
/// Ví dụ: vị trí lưu trữ và quản lý cho một giá trị có thể được chọn cụ thể sao cho thích hợp cho một mục đích sử dụng cụ thể thông qua các loại con trỏ như [`Box<T>`] hoặc [`Rc<T>`].
/// Ngoài các trình bao bọc chung này có thể được sử dụng với bất kỳ loại nào, một số loại cung cấp các khía cạnh tùy chọn cung cấp chức năng có thể tốn kém.
/// Một ví dụ cho kiểu như vậy là [`String`] bổ sung khả năng mở rộng chuỗi cho [`str`] cơ bản.
/// Điều này yêu cầu giữ thông tin bổ sung không cần thiết cho một chuỗi đơn giản, bất biến.
///
/// Các loại này cung cấp quyền truy cập vào dữ liệu cơ bản thông qua các tham chiếu đến loại dữ liệu đó.Chúng được cho là 'mượn như' kiểu đó.
/// Ví dụ: [`Box<T>`] có thể được mượn dưới dạng `T` trong khi [`String`] có thể được mượn dưới dạng `str`.
///
/// Các kiểu thể hiện rằng chúng có thể được mượn dưới dạng một số kiểu `T` bằng cách triển khai `Borrow<T>`, cung cấp tham chiếu đến `T` trong phương thức [`borrow`] của trait.Một loại được cho mượn miễn phí như một số loại khác nhau.
/// Nếu nó muốn mượn lẫn nhau làm kiểu-cho phép dữ liệu cơ bản được sửa đổi, nó có thể triển khai thêm [`BorrowMut<T>`].
///
/// Hơn nữa, khi cung cấp các triển khai cho traits bổ sung, cần phải xem xét liệu chúng có nên hoạt động giống với các hoạt động của kiểu cơ bản như một hệ quả của việc hoạt động như một đại diện của kiểu cơ bản đó hay không.
/// Mã chung thường sử dụng `Borrow<T>` khi nó dựa trên hành vi giống hệt nhau của các triển khai trait bổ sung này.
/// Các traits này có thể sẽ xuất hiện dưới dạng trait bounds bổ sung.
///
/// Cụ thể `Eq`, `Ord` và `Hash` phải tương đương với các giá trị mượn và sở hữu: `x.borrow() == y.borrow()` phải cho kết quả tương tự như `x == y`.
///
/// Nếu mã chung chỉ cần hoạt động cho tất cả các loại có thể cung cấp tham chiếu đến loại liên quan `T`, thì tốt hơn nên sử dụng [`AsRef<T>`] vì nhiều loại có thể triển khai nó một cách an toàn.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Là một bộ sưu tập dữ liệu, [`HashMap<K, V>`] sở hữu cả khóa và giá trị.Tuy nhiên, nếu dữ liệu thực tế của khóa được bao bọc trong một kiểu quản lý nào đó, tuy nhiên, vẫn có thể tìm kiếm giá trị bằng cách sử dụng tham chiếu đến dữ liệu của khóa.
/// Ví dụ: nếu khóa là một chuỗi, thì nó có khả năng được lưu trữ với bản đồ băm dưới dạng [`String`], trong khi có thể tìm kiếm bằng [`&str`][`str`].
/// Do đó, `insert` cần hoạt động trên `String` trong khi `get` cần có thể sử dụng `&str`.
///
/// Được đơn giản hóa một chút, các bộ phận liên quan của `HashMap<K, V>` trông như thế này:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // các trường bị bỏ qua
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Toàn bộ bản đồ băm là chung cho một loại khóa `K`.Vì các khóa này được lưu trữ với bản đồ băm, nên loại này phải sở hữu dữ liệu của khóa.
/// Khi chèn một cặp khóa-giá trị, bản đồ được cung cấp một `K` như vậy và cần phải tìm nhóm băm chính xác và kiểm tra xem khóa đã có sẵn dựa trên `K` đó hay chưa.Do đó, nó yêu cầu `K: Hash + Eq`.
///
/// Tuy nhiên, khi tìm kiếm một giá trị trong bản đồ, việc phải cung cấp một tham chiếu đến `K` làm khóa để tìm kiếm sẽ yêu cầu luôn tạo một giá trị được sở hữu như vậy.
/// Đối với các khóa chuỗi, điều này có nghĩa là giá trị `String` cần được tạo chỉ để tìm kiếm các trường hợp chỉ có `str`.
///
/// Thay vào đó, phương thức `get` là chung so với loại dữ liệu khóa cơ bản, được gọi là `Q` trong chữ ký phương thức ở trên.Nó nói rằng `K` mượn như một `Q` bằng cách yêu cầu `K: Borrow<Q>` đó.
/// Bằng cách yêu cầu thêm `Q: Hash + Eq`, nó báo hiệu yêu cầu rằng `K` và `Q` phải triển khai `Hash` và `Eq` traits tạo ra kết quả giống hệt nhau.
///
/// Việc triển khai `get` đặc biệt dựa vào các triển khai giống hệt nhau của `Hash` bằng cách xác định nhóm băm của khóa bằng cách gọi `Hash::hash` trên giá trị `Q` ngay cả khi nó đã chèn khóa dựa trên giá trị băm được tính từ giá trị `K`.
///
///
/// Do đó, bản đồ băm bị hỏng nếu `K` bao bọc một giá trị `Q` tạo ra một hàm băm khác với `Q`.Ví dụ: hãy tưởng tượng bạn có một kiểu bao bọc một chuỗi nhưng so sánh các chữ cái ASCII bỏ qua trường hợp của chúng:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Bởi vì hai giá trị bằng nhau cần tạo ra cùng một giá trị băm, việc triển khai `Hash` cũng cần phải bỏ qua trường hợp ASCII:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// `CaseInsensitiveString` có thể triển khai `Borrow<str>` không?Nó chắc chắn có thể cung cấp một tham chiếu đến một lát chuỗi thông qua chuỗi sở hữu của nó.
/// Nhưng vì cách triển khai `Hash` của nó khác, nó hoạt động khác với `str` và do đó, trên thực tế, không được triển khai `Borrow<str>`.
/// Nếu nó muốn cho phép người khác truy cập vào `str` bên dưới, nó có thể làm điều đó thông qua `AsRef<str>` mà không mang bất kỳ yêu cầu bổ sung nào.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Các khoản vay liên tục từ một giá trị sở hữu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// Một trait để mượn dữ liệu lẫn nhau.
///
/// Là bạn đồng hành với [`Borrow<T>`], trait này cho phép một kiểu mượn làm kiểu cơ bản bằng cách cung cấp một tham chiếu có thể thay đổi.
/// Xem [`Borrow<T>`] để biết thêm thông tin về việc vay mượn như một loại khác.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Các khoản vay lẫn nhau từ một giá trị sở hữu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}