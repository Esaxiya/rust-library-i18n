#![stable(feature = "core_hint", since = "1.27.0")]

//! Gợi ý trình biên dịch ảnh hưởng đến cách mã được phát ra hoặc tối ưu hóa.
//! Gợi ý có thể là thời gian biên dịch hoặc thời gian chạy.

use crate::intrinsics;

/// Thông báo cho trình biên dịch rằng điểm này trong mã không thể truy cập được, cho phép tối ưu hóa hơn nữa.
///
/// # Safety
///
/// Tiếp cận chức năng này là hoàn toàn *hành vi không xác định*(UB).Đặc biệt, trình biên dịch giả định rằng tất cả UB không bao giờ xảy ra, và do đó sẽ loại bỏ tất cả các nhánh tiếp cận với lệnh gọi đến `unreachable_unchecked()`.
///
/// Giống như tất cả các trường hợp của UB, nếu giả định này là sai, tức là, lệnh gọi `unreachable_unchecked()` thực sự có thể truy cập được trong số tất cả các luồng điều khiển có thể có, trình biên dịch sẽ áp dụng chiến lược tối ưu hóa sai và đôi khi có thể làm hỏng mã dường như không liên quan, gây khó khăn-để gỡ lỗi vấn đề.
///
///
/// Chỉ sử dụng chức năng này khi bạn có thể chứng minh rằng mã sẽ không bao giờ gọi nó.
/// Nếu không, hãy xem xét sử dụng macro [`unreachable!`], macro này không cho phép tối ưu hóa nhưng sẽ panic khi được thực thi.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` luôn luôn dương (không phải 0), do đó `checked_div` sẽ không bao giờ trả về `None`.
/////
///     // Do đó, branch khác không thể truy cập được.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // AN TOÀN: hợp đồng an toàn cho `intrinsics::unreachable` phải
    // được người gọi ủng hộ.
    unsafe { intrinsics::unreachable() }
}

/// Phát ra lệnh máy để báo hiệu cho bộ xử lý rằng nó đang chạy trong vòng quay chờ bận ("khóa quay").
///
/// Khi nhận được tín hiệu vòng quay, bộ xử lý có thể tối ưu hóa hành vi của nó, chẳng hạn như tiết kiệm năng lượng hoặc chuyển đổi luồng hyper.
///
/// Chức năng này khác với [`thread::yield_now`], chức năng này trực tiếp cung cấp cho bộ lập lịch của hệ thống, trong khi `spin_loop` không tương tác với hệ điều hành.
///
/// Một trường hợp sử dụng phổ biến cho `spin_loop` là thực hiện quay lạc quan có giới hạn trong một vòng lặp CAS trong nguyên thủy đồng bộ hóa.
/// Để tránh các vấn đề như đảo ngược mức độ ưu tiên, chúng tôi khuyên bạn nên kết thúc vòng quay vòng quay sau một số lần lặp lại hữu hạn và một cuộc gọi tổng hợp chặn thích hợp được thực hiện.
///
///
/// **Lưu ý**: Trên các nền tảng không hỗ trợ nhận gợi ý spin-loop, chức năng này không thực hiện bất cứ điều gì.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Một giá trị nguyên tử được chia sẻ mà các chủ đề sẽ sử dụng để điều phối
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Trong một chuỗi nền cuối cùng, chúng tôi sẽ đặt giá trị
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Làm một số công việc, sau đó làm cho giá trị sống
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Quay lại chuỗi hiện tại của chúng tôi, chúng tôi đợi giá trị được đặt
/// while !live.load(Ordering::Acquire) {
///     // Vòng quay là một gợi ý cho CPU mà chúng tôi đang chờ đợi, nhưng có lẽ không lâu lắm
/////
///     hint::spin_loop();
/// }
///
/// // Giá trị hiện đã được đặt
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // AN TOÀN: trình đính kèm `cfg` đảm bảo rằng chúng tôi chỉ thực hiện điều này trên các mục tiêu x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // AN TOÀN: trình đính kèm `cfg` đảm bảo rằng chúng tôi chỉ thực hiện điều này trên các mục tiêu x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // AN TOÀN: trình đính kèm `cfg` đảm bảo rằng chúng tôi chỉ thực hiện điều này trên các mục tiêu aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // AN TOÀN: bộ điều chỉnh `cfg` đảm bảo rằng chúng tôi chỉ thực hiện điều này trên các mục tiêu nhánh
            // với sự hỗ trợ cho tính năng v6.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Một hàm nhận dạng *__ gợi ý __* cho trình biên dịch để tối đa hóa sự bi quan về những gì `black_box` có thể làm.
///
/// Không giống như [`std::convert::identity`], trình biên dịch Rust được khuyến khích để giả định rằng `black_box` có thể sử dụng `dummy` theo bất kỳ cách hợp lệ nào có thể có mà mã Rust được phép mà không đưa ra hành vi không xác định trong mã gọi.
///
/// Thuộc tính này làm cho `black_box` hữu ích để viết mã trong đó một số tối ưu hóa không được mong muốn, chẳng hạn như điểm chuẩn.
///
/// Tuy nhiên, lưu ý rằng `black_box` chỉ (và chỉ có thể được) cung cấp trên cơ sở "best-effort".Mức độ mà nó có thể chặn tối ưu hóa có thể khác nhau tùy thuộc vào nền tảng và chương trình phụ trợ thế hệ mã được sử dụng.
/// Các chương trình không thể dựa vào `black_box` cho *độ đúng* theo bất kỳ cách nào.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Chúng ta cần "use" đối số theo một cách nào đó mà LLVM không thể xem xét bên trong và đối với các mục tiêu hỗ trợ nó, chúng ta thường có thể tận dụng lắp ráp nội tuyến để thực hiện điều này.
    // Giải thích của LLVM về lắp ráp nội tuyến là nó, tốt, là một hộp đen.
    // Đây không phải là cách triển khai tuyệt vời nhất vì nó có thể giảm lượng điện năng nhiều hơn chúng ta muốn, nhưng cho đến nay nó đủ tốt.
    //
    //

    #[cfg(not(miri))] // Đây chỉ là gợi ý nên bỏ qua ở Miri cũng được.
    // AN TOÀN: lắp ráp nội tuyến là một lựa chọn không cần thiết.
    unsafe {
        // FIXME: Không thể sử dụng `asm!` vì nó không hỗ trợ MIPS và các kiến trúc khác.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}