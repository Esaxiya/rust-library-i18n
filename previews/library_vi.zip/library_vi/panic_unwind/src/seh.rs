//! Windows SEH
//!
//! Trên Windows (hiện chỉ có trên MSVC), cơ chế xử lý ngoại lệ mặc định là Xử lý ngoại lệ có cấu trúc (SEH).
//! Điều này hoàn toàn khác với việc xử lý ngoại lệ dựa trên Dwarf (ví dụ: những gì nền tảng unix khác sử dụng) về nội bộ trình biên dịch, vì vậy LLVM được yêu cầu phải có nhiều hỗ trợ bổ sung cho SEH.
//!
//! Tóm lại, những gì xảy ra ở đây là:
//!
//! 1. Hàm `panic` gọi hàm Windows tiêu chuẩn `_CxxThrowException` để ném một ngoại lệ giống C++ , kích hoạt quá trình giải nén.
//! 2.
//! Tất cả các đệm đích do trình biên dịch tạo ra đều sử dụng hàm cá tính `__CxxFrameHandler3`, một hàm trong CRT và mã tháo cuộn trong Windows sẽ sử dụng hàm cá tính này để thực thi tất cả mã dọn dẹp trên ngăn xếp.
//!
//! 3. Tất cả các lệnh gọi do trình biên dịch tạo tới `invoke` đều có bảng đệm được đặt làm lệnh `cleanuppad` LLVM, cho biết thời điểm bắt đầu quy trình dọn dẹp.
//! Nhân cách (trong bước 2, được định nghĩa trong CRT) chịu trách nhiệm điều hành các quy trình dọn dẹp.
//! 4. Cuối cùng mã "catch" trong nội tại `try` (do trình biên dịch tạo ra) được thực thi và chỉ ra rằng điều khiển sẽ quay trở lại Rust.
//! Điều này được thực hiện thông qua `catchswitch` cộng với lệnh `catchpad` trong điều kiện LLVM IR, cuối cùng trả lại điều khiển bình thường cho chương trình bằng lệnh `catchret`.
//!
//! Một số khác biệt cụ thể so với xử lý ngoại lệ dựa trên gcc là:
//!
//! * Rust không có chức năng tính cách tùy chỉnh, thay vào đó là *luôn luôn*`__CxxFrameHandler3`.Ngoài ra, không có bộ lọc bổ sung nào được thực hiện, vì vậy chúng tôi sẽ bắt được bất kỳ ngoại lệ C++ nào xảy ra giống như loại chúng tôi đang ném.
//! Lưu ý rằng việc ném một ngoại lệ vào Rust dù sao cũng là hành vi không xác định, vì vậy điều này sẽ ổn.
//! * Chúng tôi có một số dữ liệu để truyền qua ranh giới không tua, cụ thể là `Box<dyn Any + Send>`.Giống như với các ngoại lệ Dwarf, hai con trỏ này được lưu trữ như một trọng tải trong chính ngoại lệ.
//! Tuy nhiên, trên MSVC, không cần phân bổ thêm heap vì ngăn xếp cuộc gọi được giữ nguyên trong khi các chức năng lọc đang được thực thi.
//! Điều này có nghĩa là các con trỏ được chuyển trực tiếp đến `_CxxThrowException`, sau đó được khôi phục trong chức năng lọc để ghi vào khung ngăn xếp của nội tại `try`.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Đây cần phải là một Tùy chọn vì chúng tôi bắt ngoại lệ bằng tham chiếu và trình hủy của nó được thực thi bởi thời gian chạy C++ .
    // Khi chúng ta lấy Hộp ra khỏi ngoại lệ, chúng ta cần để ngoại lệ ở trạng thái hợp lệ để trình hủy của nó chạy mà không làm rơi Hộp hai lần.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Đầu tiên, một loạt các định nghĩa về kiểu.Có một vài điểm kỳ lạ dành riêng cho nền tảng ở đây và rất nhiều thứ chỉ được sao chép trắng trợn từ LLVM.Mục đích của tất cả điều này là thực hiện chức năng `panic` bên dưới thông qua một cuộc gọi tới `_CxxThrowException`.
//
// Hàm này có hai đối số.Đầu tiên là một con trỏ đến dữ liệu mà chúng ta đang truyền vào, trong trường hợp này là đối tượng trait của chúng ta.Khá dễ tìm!Tiếp theo, tuy nhiên, phức tạp hơn.
// Đây là một con trỏ đến một cấu trúc `_ThrowInfo` và nó thường chỉ nhằm mục đích mô tả ngoại lệ đang được ném ra.
//
// Hiện tại, định nghĩa của loại [1] này hơi khó hiểu và điều kỳ lạ chính (và sự khác biệt so với bài viết trực tuyến) là trên 32 bit, con trỏ là con trỏ nhưng trên 64 bit, con trỏ được biểu thị dưới dạng hiệu số 32 bit từ Ký hiệu `__ImageBase`.
//
// Macro `ptr_t` và `ptr!` trong các mô-đun bên dưới được sử dụng để thể hiện điều này.
//
// Mê cung của các định nghĩa loại cũng theo sát những gì LLVM phát ra cho loại hoạt động này.Ví dụ: nếu bạn biên dịch mã C++ này trên MSVC và phát ra LLVM IR:
//
//      #include <stdint.h>
//
//      struct gỉ_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];}
//
//      void foo() { rust_panic a = {0, 1};
//          ném một;}
//
// Về cơ bản đó là những gì chúng tôi đang cố gắng mô phỏng.Hầu hết các giá trị không đổi bên dưới chỉ được sao chép từ LLVM,
//
// Trong mọi trường hợp, những cấu trúc này đều được xây dựng theo cách tương tự, và nó chỉ hơi dài dòng đối với chúng ta.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Lưu ý rằng chúng tôi cố tình bỏ qua các quy tắc xáo trộn tên ở đây: chúng tôi không muốn C++ có thể bắt được Rust panics chỉ bằng cách khai báo một `struct rust_panic`.
//
//
// Khi sửa đổi, hãy đảm bảo rằng chuỗi tên loại khớp chính xác với chuỗi tên được sử dụng trong `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Byte `\x01` hàng đầu ở đây thực sự là một tín hiệu kỳ diệu cho LLVM để *không* áp dụng bất kỳ sự xáo trộn nào khác như tiền tố với ký tự `_`.
    //
    //
    // Biểu tượng này là vtable được sử dụng bởi C++ 's `std::type_info`.
    // Các đối tượng kiểu `std::type_info`, bộ mô tả kiểu, có một con trỏ đến bảng này.
    // Các bộ mô tả kiểu được tham chiếu bởi cấu trúc C++ EH được định nghĩa ở trên và chúng tôi xây dựng bên dưới.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Bộ mô tả kiểu này chỉ được sử dụng khi ném một ngoại lệ.
// Phần bắt được xử lý bởi nội tại thử, tạo ra TypeDescriptor của riêng nó.
//
// Điều này là tốt vì thời gian chạy MSVC sử dụng so sánh chuỗi trên tên kiểu để khớp với TypeDescriptors hơn là bình đẳng con trỏ.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Bộ hủy được sử dụng nếu mã C++ quyết định nắm bắt ngoại lệ và loại bỏ nó mà không truyền nó.
// Phần bắt của nội tại try sẽ đặt từ đầu tiên của đối tượng ngoại lệ thành 0 để nó bị trình hủy bỏ qua.
//
// Lưu ý rằng x86 Windows sử dụng quy ước gọi "thiscall" cho các hàm thành viên C++ thay vì quy ước gọi "C" mặc định.
//
// Hàm exception_copy có một chút đặc biệt ở đây: nó được gọi bởi thời gian chạy MSVC dưới khối try/catch và panic mà chúng ta tạo ở đây sẽ được sử dụng như là kết quả của bản sao ngoại lệ.
//
// Điều này được sử dụng bởi thời gian chạy C++ để hỗ trợ bắt các ngoại lệ với std::exception_ptr, điều này chúng tôi không thể hỗ trợ vì Box<dyn Any>không thể nhân bản.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException thực thi hoàn toàn trên khung ngăn xếp này, vì vậy không cần phải chuyển `data` sang heap.
    // Chúng tôi chỉ chuyển một con trỏ ngăn xếp đến hàm này.
    //
    // Ở đây cần có ManentlyDrop vì chúng tôi không muốn Exception bị loại bỏ khi giải nén.
    // Thay vào đó, nó sẽ bị loại bỏ bởi exception_cleanup được gọi bởi thời gian chạy C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Điều này ... có vẻ đáng ngạc nhiên, và chính đáng là như vậy.Trên MSVC 32-bit, con trỏ giữa các cấu trúc này chỉ là con trỏ.
    // Tuy nhiên, trên MSVC 64-bit, các con trỏ giữa các cấu trúc được thể hiện dưới dạng hiệu số 32-bit từ `__ImageBase`.
    //
    // Do đó, trên MSVC 32-bit, chúng ta có thể khai báo tất cả các con trỏ này trong phần `static` ở trên.
    // Trên MSVC 64-bit, chúng tôi sẽ phải thể hiện phép trừ con trỏ trong tĩnh, điều mà Rust hiện không cho phép, vì vậy chúng tôi thực sự không thể làm điều đó.
    //
    // Điều tốt nhất tiếp theo là điền vào các cấu trúc này trong thời gian chạy (dù sao cũng đã là "slow path" rồi).
    // Vì vậy, ở đây chúng tôi giải thích lại tất cả các trường con trỏ này dưới dạng số nguyên 32-bit và sau đó lưu trữ giá trị có liên quan vào nó (về mặt nguyên tử, vì panics đồng thời có thể đang xảy ra).
    //
    // Về mặt kỹ thuật, thời gian chạy có thể sẽ thực hiện việc đọc giải phẫu các trường này, nhưng về lý thuyết, chúng không bao giờ đọc giá trị *sai* nên nó không quá tệ ...
    //
    // Trong mọi trường hợp, về cơ bản chúng ta cần phải làm điều gì đó như thế này cho đến khi chúng ta có thể thể hiện nhiều hoạt động hơn trong tĩnh (và chúng ta có thể không bao giờ làm được).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Trọng tải NULL ở đây có nghĩa là chúng tôi đến đây từ lần bắt (...) của __rust_try.
    // Điều này xảy ra khi một ngoại lệ không phải Rust bị bắt.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Điều này được yêu cầu bởi trình biên dịch để tồn tại (ví dụ: đó là một mục lang), nhưng nó không bao giờ thực sự được trình biên dịch gọi vì __C_specific_handler hoặc_except_handler3 là hàm tính cách luôn được sử dụng.
//
// Do đó, đây chỉ là một sơ khai hủy bỏ.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}