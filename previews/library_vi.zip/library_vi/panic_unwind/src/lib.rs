//! Thực hiện panics thông qua cuộn mở ngăn xếp
//!
//! crate này là một triển khai của panics trong Rust sử dụng cơ chế giải nén ngăn xếp "most native" của nền tảng này đang được biên dịch.
//! Điều này về cơ bản được phân loại thành ba nhóm hiện tại:
//!
//! 1. Mục tiêu MSVC sử dụng SEH trong tệp `seh.rs`.
//! 2. Emscripten sử dụng các ngoại lệ C++ trong tệp `emcc.rs`.
//! 3. Tất cả các mục tiêu khác sử dụng libunwind/libgcc trong tệp `gcc.rs`.
//!
//! Có thể tìm thấy thêm tài liệu về mỗi cách triển khai trong mô-đun tương ứng.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` không được sử dụng với Miri, vì vậy hãy im lặng cảnh báo.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Các đối tượng khởi động của thời gian chạy Rust phụ thuộc vào các ký hiệu này, vì vậy hãy đặt chúng ở chế độ công khai.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Các mục tiêu không hỗ trợ bỏ tua.
        // - arch=wasm32
        // - os=none (mục tiêu "bare metal")
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Sử dụng thời gian chạy Miri.
        // Chúng tôi vẫn cần tải thời gian chạy bình thường ở trên, vì rustc mong đợi một số mục lang nhất định từ đó được xác định.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Sử dụng thời gian chạy thực.
        use real_imp as imp;
    }
}

extern "C" {
    /// Xử lý trong libstd được gọi khi một đối tượng panic được thả ra bên ngoài `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Xử lý trong libstd được gọi khi bắt được một ngoại lệ.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Điểm đầu vào để nâng cao một ngoại lệ, chỉ ủy quyền cho việc triển khai nền tảng cụ thể.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}