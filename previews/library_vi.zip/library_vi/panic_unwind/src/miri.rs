//! Mở panics cho Miri.
use alloc::boxed::Box;
use core::any::Any;

// Loại trọng tải mà động cơ Miri truyền thông qua việc tháo cuộn cho chúng ta.
// Phải có kích thước bằng con trỏ.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Chức năng bên ngoài do Miri cung cấp để bắt đầu tháo cuộn.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Trọng tải mà chúng tôi chuyển cho `miri_start_panic` sẽ chính xác là đối số mà chúng tôi nhận được trong `cleanup` bên dưới.
    // Vì vậy, chúng tôi chỉ đóng hộp nó một lần, để có được thứ gì đó có kích thước bằng con trỏ.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Khôi phục `Box` bên dưới.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}