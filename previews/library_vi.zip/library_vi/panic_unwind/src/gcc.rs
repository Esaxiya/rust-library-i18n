//! Triển khai panics được hỗ trợ bởi libgcc/libunwind (ở một số hình thức).
//!
//! Để biết thông tin cơ bản về xử lý ngoại lệ và giải nén ngăn xếp, vui lòng xem "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) và các tài liệu được liên kết từ nó.
//! Đây cũng là những bài đọc hay:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## Một bản tóm tắt ngắn gọn
//!
//! Xử lý ngoại lệ xảy ra trong hai giai đoạn: giai đoạn tìm kiếm và giai đoạn dọn dẹp.
//!
//! Trong cả hai giai đoạn, trình giải nén sẽ đi các khung ngăn xếp từ trên xuống dưới bằng cách sử dụng thông tin từ khung xếp chồng, giải phóng các phần của mô-đun của quy trình hiện tại ("module" ở đây đề cập đến một mô-đun OS, tức là một tệp thực thi hoặc một thư viện động).
//!
//!
//! Đối với mỗi khung ngăn xếp, nó gọi "personality routine" được liên kết, có địa chỉ cũng được lưu trữ trong phần thông tin thư giãn.
//!
//! Trong giai đoạn tìm kiếm, công việc của một thói quen tính cách là kiểm tra đối tượng ngoại lệ đang được ném và quyết định xem nó có được bắt tại khung ngăn xếp đó hay không.Khi khung xử lý đã được xác định, giai đoạn dọn dẹp bắt đầu.
//!
//! Trong giai đoạn dọn dẹp, trình gỡ rối sẽ gọi lại từng thói quen tính cách.
//! Lần này nó quyết định mã dọn dẹp (nếu có) nào cần được chạy cho khung ngăn xếp hiện tại.Nếu vậy, điều khiển được chuyển đến một branch đặc biệt trong thân hàm, "landing pad", gọi hàm hủy, giải phóng bộ nhớ, v.v.
//! Ở phần cuối của bệ hạ cánh, điều khiển được chuyển trở lại bộ tiếp tục tháo và gỡ.
//!
//! Khi ngăn xếp đã được mở xuống cấp khung trình xử lý, các điểm dừng cuộn và quy trình tính cách cuối cùng sẽ chuyển quyền điều khiển đến khối bắt.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Định danh lớp ngoại lệ của Rust.
// Điều này được sử dụng bởi các thói quen tính cách để xác định xem liệu ngoại lệ có bị ném ra bởi thời gian chạy của chính chúng hay không.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-nhà cung cấp, ngôn ngữ
    0x4d4f5a_00_52555354
}

// Id thanh ghi đã được nâng lên từ TargetLowering::getExceptionPointerRegister() và TargetLowering::getExceptionSelectorRegister() của LLVM cho mỗi kiến trúc, sau đó được ánh xạ tới số thanh ghi DWARF thông qua bảng định nghĩa thanh ghi (thông thường<arch>RegisterInfo.td, tìm kiếm "DwarfRegNum").
//
// Xem thêm http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// Đoạn mã sau đây dựa trên thói quen tính cách C và C++ của GCC.Để tham khảo, hãy xem:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM Thói quen nhân cách EHABI.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS thay vào đó sử dụng quy trình mặc định vì nó sử dụng tính năng giải nén SjLj.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // Backtraces trên ARM sẽ gọi thói quen tính cách với trạng thái==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // Trong những trường hợp đó, chúng tôi muốn tiếp tục giải nén ngăn xếp, nếu không, tất cả các dấu vết của chúng tôi sẽ kết thúc tại __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // Trình giải nén DWARF giả định rằng_Unwind_Context giữ những thứ như hàm và con trỏ LSDA, tuy nhiên ARM EHABI đặt chúng vào đối tượng ngoại lệ.
            // Để duy trì chữ ký của các chức năng như _Unwind_GetLanguageSpecificData(), chỉ lấy con trỏ ngữ cảnh, các quy trình tính cách GCC lưu trữ một con trỏ tới exception_object trong ngữ cảnh, sử dụng vị trí dành riêng cho "scratch register" (r12) của ARM.
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... Một cách tiếp cận nguyên tắc hơn sẽ là cung cấp định nghĩa đầy đủ về _Unwind_Context của ARM trong liên kết libunwind của chúng tôi và tìm nạp dữ liệu cần thiết trực tiếp từ đó, bỏ qua các chức năng tương thích DWARF.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI yêu cầu quy trình tính cách cập nhật giá trị SP trong bộ đệm hàng rào của đối tượng ngoại lệ.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // Trên ARM EHABI, thói quen tính cách chịu trách nhiệm thực sự giải nén một khung ngăn xếp trước khi quay trở lại (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // được định nghĩa trong libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // Thói quen tính cách mặc định, được sử dụng trực tiếp trên hầu hết các mục tiêu và gián tiếp trên Windows x86_64 thông qua SEH.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // Trên các mục tiêu x86_64 MinGW, cơ chế giải nén là SEH tuy nhiên dữ liệu của trình xử lý thư giãn (hay còn gọi là LSDA) sử dụng mã hóa tương thích GCC.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // Các thói quen tính cách cho hầu hết các mục tiêu của chúng tôi.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // Địa chỉ trả về trỏ 1 byte qua lệnh gọi, có thể nằm trong dải IP tiếp theo trong bảng dải LSDA.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Khung đăng ký thông tin thư giãn
//
// Mỗi hình ảnh của mô-đun có chứa phần thông tin mở rộng khung hình (thường là ".eh_frame").Khi một mô-đun là loaded/unloaded vào quy trình, trình giải nén phải được thông báo về vị trí của phần này trong bộ nhớ.Các phương pháp đạt được điều đó khác nhau tùy theo nền tảng.
// Trên một số (ví dụ: Linux), trình giải nén có thể tự khám phá các phần thông tin thư giãn (bằng cách liệt kê động các mô-đun hiện đang tải qua dl_iterate_phdr() API and finding their ".eh_frame" sections); những mô-đun khác, như Windows, yêu cầu mô-đun chủ động đăng ký các phần thông tin thư giãn của họ thông qua API giải nén.
//
//
// Mô-đun này xác định hai ký hiệu được tham chiếu và gọi từ rsbegin.rs để đăng ký thông tin của chúng tôi với thời gian chạy GCC.
// Việc triển khai giải nén ngăn xếp (hiện tại) được hoãn lại cho libgcc_eh, tuy nhiên Rust crates sử dụng các điểm vào dành riêng cho Rust này để tránh xung đột tiềm ẩn với bất kỳ thời gian chạy GCC nào.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}