//! Thực hiện Rust panics thông qua hủy bỏ quy trình
//!
//! Khi so sánh với việc thực hiện thông qua giải nén, crate này *đơn giản* hơn nhiều!Điều đó đang được nói, nó không hoàn toàn linh hoạt, nhưng ở đây là!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" trọng tải và miếng dán để hủy bỏ có liên quan trên nền tảng được đề cập.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // gọi std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Trên Windows, hãy sử dụng cơ chế __fastfail dành riêng cho bộ xử lý.Trong Windows 8 trở lên, điều này sẽ kết thúc quá trình ngay lập tức mà không cần chạy bất kỳ trình xử lý ngoại lệ trong quá trình nào.
            // Trong các phiên bản trước đó của Windows, chuỗi hướng dẫn này sẽ bị coi là vi phạm quyền truy cập, chấm dứt quá trình nhưng không nhất thiết phải bỏ qua tất cả các trình xử lý ngoại lệ.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: đây là cách triển khai tương tự như trong `abort_internal` của libstd
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Điều này ... hơi kỳ quặc.Các tl; dr;là điều này được yêu cầu để liên kết chính xác, giải thích dài hơn là bên dưới.
//
// Hiện tại, các mã nhị phân của libcore/libstd mà chúng tôi giao hàng đều được biên dịch bằng `-C panic=unwind`.Điều này được thực hiện để đảm bảo rằng các tệp nhị phân tương thích tối đa với nhiều tình huống nhất có thể.
// Tuy nhiên, trình biên dịch yêu cầu "personality function" cho tất cả các chức năng được biên dịch với `-C panic=unwind`.Hàm tính cách này được mã hóa cứng thành ký hiệu `rust_eh_personality` và được xác định bởi mục lang `eh_personality`.
//
// So...
// Tại sao không chỉ định nghĩa mục lang ở đây?Câu hỏi hay!Cách mà các thời gian chạy panic được liên kết thực sự hơi tinh tế ở chỗ chúng là "sort of" trong cửa hàng crate của trình biên dịch, nhưng chỉ thực sự được liên kết nếu một tệp khác không thực sự được liên kết.
//
// Điều này kết thúc có nghĩa là cả crate này và crazy_unwind crate đều có thể xuất hiện trong cửa hàng crate của trình biên dịch và nếu cả hai đều xác định mục `eh_personality` lang thì sẽ gặp lỗi.
//
// Để xử lý điều này, trình biên dịch chỉ yêu cầu xác định `eh_personality` nếu thời gian chạy panic được liên kết là thời gian chạy giải nén, và nếu không thì không cần phải xác định (đúng như vậy).
// Tuy nhiên, trong trường hợp này, thư viện này chỉ định nghĩa biểu tượng này nên ít nhất có một số tính cách ở đâu đó.
//
// Về cơ bản, biểu tượng này chỉ được định nghĩa để có dây tới các tệp nhị phân libcore/libstd, nhưng nó không bao giờ được gọi vì chúng tôi không liên kết trong thời gian chạy không chạy chút nào.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // Trên x86_64-pc-windows-gnu, chúng tôi sử dụng chức năng cá tính của riêng chúng tôi cần trả về `ExceptionContinueSearch` khi chúng tôi chuyển tất cả các khung của mình.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Tương tự như trên, điều này tương ứng với mục lang `eh_catch_typeinfo` hiện chỉ được sử dụng trên Emscripten.
    //
    // Vì panics không tạo ra các ngoại lệ và các ngoại lệ nước ngoài hiện là UB với -C panic=abort (mặc dù điều này có thể thay đổi), mọi lệnh gọi catch_unwind sẽ không bao giờ sử dụng typeinfo này.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Hai đối tượng này được gọi bởi các đối tượng khởi động của chúng tôi trên i686-pc-windows-gnu, nhưng chúng không cần phải làm bất cứ điều gì để các cơ quan là nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}