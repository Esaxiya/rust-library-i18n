use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Được sử dụng để nói với các chú thích `#[assert_instr]` của chúng tôi rằng tất cả các bản chất của simd đều có sẵn để kiểm tra mã của chúng, vì một số được cài đặt sau một `-Ctarget-feature=+unimplemented-simd128` bổ sung không có bất kỳ tương đương nào trong `#[target_feature]` ngay bây giờ.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}