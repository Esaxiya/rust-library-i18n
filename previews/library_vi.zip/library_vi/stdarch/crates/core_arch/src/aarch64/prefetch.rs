#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// Xem [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_READ: i32 = 0;

/// Xem [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_WRITE: i32 = 1;

/// Xem [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// Xem [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// Xem [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// Xem [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// Tìm nạp dòng bộ đệm chứa địa chỉ `p` bằng cách sử dụng `rw` và `locality` đã cho.
///
/// `rw` phải là một trong số:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): tìm nạp trước đang chuẩn bị đọc.
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): tìm nạp trước đang chuẩn bị viết.
///
/// `locality` phải là một trong số:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): Truyền trực tuyến hoặc tìm nạp trước không theo thời gian, đối với dữ liệu chỉ được sử dụng một lần.
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): Tìm nạp vào bộ nhớ cache cấp 3.
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): Tìm nạp vào bộ nhớ cache cấp 2.
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): Tìm nạp vào bộ nhớ cache cấp 1.
///
/// Các lệnh bộ nhớ tìm nạp trước báo hiệu cho hệ thống bộ nhớ rằng bộ nhớ truy cập từ một địa chỉ xác định có thể xảy ra trong future gần.
/// Hệ thống bộ nhớ có thể phản hồi bằng cách thực hiện các hành động được mong đợi để tăng tốc độ truy cập bộ nhớ khi chúng xảy ra, chẳng hạn như tải trước địa chỉ đã chỉ định vào một hoặc nhiều bộ nhớ đệm.
///
/// Bởi vì những tín hiệu này chỉ là gợi ý, nó hợp lệ đối với một CPU cụ thể để coi bất kỳ hoặc tất cả các lệnh tìm nạp trước như một NOP.
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // Chúng tôi sử dụng nội tại `llvm.prefetch` với `cache type` =1 (bộ nhớ cache dữ liệu).
    // `rw` và `strategy` dựa trên các tham số chức năng.
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}