`core::arch` - Bản chất cụ thể về kiến trúc thư viện cốt lõi của Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Mô-đun `core::arch` thực hiện bản chất phụ thuộc vào kiến trúc (ví dụ: SIMD).

# Usage 

`core::arch` có sẵn như một phần của `libcore` và nó được tái xuất bởi `libstd`.Thích sử dụng nó qua `core::arch` hoặc `std::arch` hơn là qua crate này.
Các tính năng không ổn định thường có trong Rust hàng đêm thông qua `feature(stdsimd)`.

Sử dụng `core::arch` thông qua crate này yêu cầu Rust hàng đêm và nó có thể (và thường xuyên) bị hỏng.Các trường hợp duy nhất mà bạn nên xem xét sử dụng nó qua crate này là:

* nếu bạn cần tự biên dịch lại `core::arch`, ví dụ: với các tính năng mục tiêu cụ thể được bật chưa được bật cho `libcore`/`libstd`.
Note: nếu bạn cần biên dịch lại nó cho mục tiêu không chuẩn, vui lòng sử dụng `xargo` và biên dịch lại `libcore`/`libstd` nếu thích hợp thay vì sử dụng crate này.
  
* sử dụng một số tính năng có thể không có sẵn ngay cả sau các tính năng không ổn định của Rust.Chúng tôi cố gắng giữ những điều này ở mức tối thiểu.
Nếu bạn cần sử dụng một số tính năng này, vui lòng mở sự cố để chúng tôi có thể hiển thị chúng trong Rust hàng đêm và bạn có thể sử dụng chúng từ đó.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` chủ yếu được phân phối theo các điều khoản của cả giấy phép MIT và Giấy phép Apache (Phiên bản 2.0), với các phần được bao phủ bởi các giấy phép giống BSD khác nhau.

Xem LICENSE-APACHE và LICENSE-MIT để biết thêm chi tiết.

# Contribution

Trừ khi bạn tuyên bố rõ ràng bằng cách khác, bất kỳ đóng góp nào do bạn cố tình gửi để đưa vào `core_arch`, như được định nghĩa trong giấy phép Apache-2.0, sẽ được cấp phép kép như trên, mà không có bất kỳ điều khoản hoặc điều kiện bổ sung nào.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












