# Đóng góp vào tinh bột

`stdarch` crate sẵn sàng chấp nhận đóng góp!Trước tiên, có thể bạn sẽ muốn kiểm tra kho lưu trữ và đảm bảo rằng các bài kiểm tra sẽ vượt qua cho bạn:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Trong đó `<your-target-arch>` là bộ ba mục tiêu được sử dụng bởi `rustup`, ví dụ: `x86_x64-unknown-linux-gnu` (không có bất kỳ `nightly-` nào trước đó hoặc tương tự).
Cũng nên nhớ rằng kho lưu trữ này yêu cầu kênh hàng đêm của Rust!
Các bài kiểm tra trên thực tế yêu cầu rust hàng đêm phải là mặc định trên hệ thống của bạn, để đặt sử dụng `rustup default nightly` (và `rustup default stable` để hoàn nguyên).

Nếu bất kỳ bước nào ở trên không hiệu quả, [please let us know][new]!

Tiếp theo, bạn có thể [find an issue][issues] để trợ giúp, chúng tôi đã chọn một số thẻ có thẻ [`help wanted`][help] và [`impl-period`][impl], đặc biệt có thể sử dụng một số trợ giúp. 
Bạn có thể quan tâm nhất đến [#40][vendor], triển khai tất cả bản chất của nhà cung cấp trên x86.Vấn đề đó có một số gợi ý tốt về nơi bắt đầu!

Nếu bạn có các câu hỏi chung, vui lòng liên hệ với [join us on gitter][gitter] và hỏi xung quanh!Vui lòng ping@BurntSushi hoặc@alexcrichton nếu có câu hỏi.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Cách viết ví dụ cho bản chất của stdarch

Có một số tính năng phải được kích hoạt để nội tại đã cho hoạt động bình thường và ví dụ này chỉ được chạy bởi `cargo test --doc` khi tính năng này được CPU hỗ trợ.

Do đó, `fn main` mặc định được tạo bởi `rustdoc` sẽ không hoạt động (trong hầu hết các trường hợp).
Hãy xem xét sử dụng phần sau làm hướng dẫn để đảm bảo ví dụ của bạn hoạt động như mong đợi.

```rust
/// # // Chúng tôi cần cfg_target_feature để đảm bảo rằng ví dụ này chỉ là
/// # // chạy bởi `cargo test --doc` khi CPU hỗ trợ tính năng
/// # #![feature(cfg_target_feature)]
/// # // Chúng ta cần target_feature để nội tại hoạt động
/// # #![feature(target_feature)]
/// #
/// # // gỉdoc theo mặc định sử dụng `extern crate stdarch`, nhưng chúng tôi cần
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // Chức năng chính thực sự
/// # fn main() {
/// #     // Chỉ chạy điều này nếu `<target feature>` được hỗ trợ
/// #     nếu cfg_feature_enabled! ("<target feature>"){
/// #         // Tạo một hàm `worker` sẽ chỉ được chạy nếu tính năng đích
/// #         // được hỗ trợ và đảm bảo rằng `target_feature` được bật cho nhân viên của bạn
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         fn worker() không an toàn {
/// // Viết ví dụ của bạn ở đây.Bản chất cụ thể của tính năng sẽ hoạt động ở đây!Đi hoang dã!
///
/// #         }
///
/// #         { worker(); } không an toàn
/// #     }
/// # }
```

Nếu một số cú pháp ở trên trông không quen thuộc, thì phần [Documentation as tests] của [Rust Book] mô tả cú pháp `rustdoc` khá tốt.
Như mọi khi, hãy thoải mái đến với [join us on gitter][gitter] và hỏi chúng tôi xem bạn có gặp bất kỳ khó khăn nào không và cảm ơn bạn đã giúp cải thiện tài liệu về `stdarch`!

# Hướng dẫn Kiểm tra Thay thế

Thông thường, bạn nên sử dụng `ci/run.sh` để chạy thử nghiệm.
Tuy nhiên, điều này có thể không hiệu quả với bạn, ví dụ: nếu bạn đang sử dụng Windows.

Trong trường hợp đó, bạn có thể quay lại chạy `cargo +nightly test` và `cargo +nightly test --release -p core_arch` để kiểm tra việc tạo mã.
Lưu ý rằng những điều này yêu cầu phải cài đặt chuỗi công cụ hàng đêm và để `rustc` biết về bộ ba mục tiêu của bạn và CPU của nó.
Đặc biệt, bạn cần đặt biến môi trường `TARGET` như bạn làm cho `ci/run.sh`.
Ngoài ra, bạn cần đặt `RUSTCFLAGS` (cần `C`) để chỉ ra các tính năng mục tiêu, ví dụ: `RUSTCFLAGS="-C -target-features=+avx2"`.
Bạn cũng có thể đặt `-C -target-cpu=native` nếu "just" đang phát triển dựa trên CPU hiện tại của bạn.

Hãy cảnh báo rằng khi bạn sử dụng các hướng dẫn thay thế này, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], ví dụ:
các bài kiểm tra tạo lệnh có thể không thành công vì trình tháo gỡ đặt tên cho chúng khác nhau, ví dụ:
nó có thể tạo ra các lệnh `vaesenc` thay vì `aesenc` mặc dù chúng hoạt động giống nhau.
Ngoài ra, các hướng dẫn này thực hiện ít thử nghiệm hơn bình thường, vì vậy đừng ngạc nhiên khi cuối cùng bạn kéo-request, một số lỗi có thể hiển thị cho các thử nghiệm không được đề cập ở đây.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






