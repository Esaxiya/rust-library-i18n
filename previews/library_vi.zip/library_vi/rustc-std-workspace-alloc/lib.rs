#![feature(no_core)]
#![no_core]

// Xem rustc-std-workspace-core để biết lý do tại sao crate này là cần thiết.

// Đổi tên crate để tránh xung đột với mô-đun cấp phát trong liballoc.
extern crate alloc as foo;

pub use foo::*;