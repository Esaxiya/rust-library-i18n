use backtrace::Backtrace;

// Tên mô-đun 50 ký tự
mod _234567890_234567890_234567890_234567890_234567890 {
    // Tên cấu trúc 50 ký tự
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// Tên hàm dài phải được cắt bớt thành (MAX_SYM_NAME, 1) ký tự.
// Chỉ chạy thử nghiệm này cho msvc, vì gnu in "<no info>" cho tất cả các khung.
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // 10 lần lặp lại của tên struct, do đó, tên hàm đủ điều kiện có độ dài ít nhất là 10 *(50 + 50)* 2=2000 ký tự.
    //
    // Nó thực sự dài hơn vì nó cũng bao gồm `::`, `<>` và tên của mô-đun hiện tại
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}