# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Một thư viện để lấy các dấu vết ngược trong thời gian chạy cho Rust.
Thư viện này nhằm mục đích nâng cao sự hỗ trợ của thư viện tiêu chuẩn bằng cách cung cấp một giao diện lập trình để làm việc, nhưng nó cũng hỗ trợ dễ dàng in backtrace hiện tại như panics của libstd.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Để chỉ cần nắm bắt được một tồn đọng và trì hoãn xử lý nó cho đến một thời gian sau, bạn có thể sử dụng loại `Backtrace` cấp cao nhất.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Tuy nhiên, nếu bạn muốn có thêm quyền truy cập thô vào chức năng theo dõi thực tế, bạn có thể sử dụng trực tiếp các chức năng `trace` và `resolve`.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Giải quyết con trỏ hướng dẫn này thành một tên ký hiệu
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // tiếp tục chuyển sang khung tiếp theo
    });
}
```

# License

Dự án này được cấp phép theo một trong hai

 * Giấy phép Apache, Phiên bản 2.0, ([LICENSE-APACHE](LICENSE-APACHE) hoặc http://www.apache.org/licenses/LICENSE-2.0)
 * Giấy phép MIT ([LICENSE-MIT](LICENSE-MIT) hoặc http://opensource.org/licenses/MIT)

tùy theo lựa chọn của bạn.

### Contribution

Trừ khi bạn tuyên bố rõ ràng khác, bất kỳ đóng góp nào do bạn cố ý gửi để đưa vào backtrace-rs, như được định nghĩa trong giấy phép Apache-2.0, sẽ được cấp phép kép như trên, mà không có bất kỳ điều khoản hoặc điều kiện bổ sung nào.







