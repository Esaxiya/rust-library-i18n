use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr thực hiện một cuộc gọi lại sẽ nhận được một con trỏ dl_phdr_info cho mọi DSO đã được liên kết vào quy trình.
    // dl_iterate_phdr cũng đảm bảo rằng trình liên kết động bị khóa từ đầu đến cuối của quá trình lặp.
    // Nếu lệnh gọi lại trả về một giá trị khác 0 thì quá trình lặp sẽ kết thúc sớm.
    // 'data' sẽ được chuyển làm đối số thứ ba cho lệnh gọi lại trên mỗi lần gọi.
    // 'size' cung cấp kích thước của dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Chúng ta cần phân tích cú pháp ID bản dựng và một số dữ liệu tiêu đề chương trình cơ bản, có nghĩa là chúng ta cũng cần một chút nội dung từ thông số ELF.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Bây giờ chúng ta phải sao chép, từng chút một, cấu trúc của kiểu dl_phdr_info được sử dụng bởi trình liên kết động hiện tại của fuchsia.
// Chromium cũng có ranh giới ABI này cũng như bàn di chuột.
// Cuối cùng, chúng tôi muốn chuyển những trường hợp này sang sử dụng elf-search nhưng chúng tôi cần cung cấp điều đó trong SDK và điều đó vẫn chưa được thực hiện.
//
// Vì vậy, chúng tôi (và họ) bị mắc kẹt khi phải sử dụng phương pháp này, dẫn đến một khớp nối chặt chẽ với libc fuchsia.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Chúng tôi không có cách nào để biết kiểm tra xem e_phoff và e_phnum có hợp lệ hay không.
    // Tuy nhiên, libc nên đảm bảo điều này cho chúng ta, vì vậy, có thể an toàn khi tạo một lát cắt ở đây.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr đại diện cho một tiêu đề chương trình ELF 64-bit trong độ bền của kiến trúc đích.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr đại diện cho tiêu đề chương trình ELF hợp lệ và nội dung của nó.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Chúng tôi không có cách nào để kiểm tra xem p_addr hoặc p_memsz có hợp lệ hay không.
    // Tuy nhiên, libc của Fuchsia phân tích cú pháp các ghi chú trước tiên, do đó, do ở đây, các tiêu đề này phải hợp lệ.
    //
    // NoteIter không yêu cầu dữ liệu cơ bản phải hợp lệ nhưng nó yêu cầu các giới hạn phải hợp lệ.
    // Chúng tôi tin tưởng rằng libc đã đảm bảo rằng đây là trường hợp của chúng tôi ở đây.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Loại ghi chú cho ID bản dựng.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr đại diện cho một tiêu đề ghi chú ELF trong khả năng cuối cùng của mục tiêu.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Ghi chú đại diện cho một ghi chú ELF (tiêu đề + nội dung).
// Tên được để lại là một lát u8 vì nó không phải lúc nào cũng kết thúc bằng rỗng và rust giúp bạn dễ dàng kiểm tra xem các byte có khớp hay không.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter cho phép bạn lặp lại một cách an toàn trên một đoạn ghi chú.
// Nó chấm dứt ngay khi có lỗi xảy ra hoặc không có ghi chú nào nữa.
// Nếu bạn lặp lại dữ liệu không hợp lệ, nó sẽ hoạt động như thể không tìm thấy ghi chú nào.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Nó là một hàm bất biến mà con trỏ và kích thước đã cho biểu thị một phạm vi byte hợp lệ mà tất cả đều có thể đọc được.
    // Nội dung của các byte này có thể là bất kỳ thứ gì nhưng phạm vi phải hợp lệ để điều này được an toàn.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to căn chỉnh 'x' thành căn lề 'to'-byte giả sử 'to' là lũy thừa của 2.
// Điều này tuân theo một mẫu tiêu chuẩn trong mã phân tích cú pháp C/C ++ ELF trong đó (x + to, 1)&-to được sử dụng.
// Rust không cho phép bạn phủ nhận kích thước nên tôi sử dụng
// 2's-bổ sung chuyển đổi để tạo lại điều đó.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 sử dụng num byte từ lát (nếu có) và cũng đảm bảo rằng lát cuối cùng được căn chỉnh thích hợp.
// Nếu số lượng byte được yêu cầu quá lớn hoặc không thể sắp xếp lại lát cắt sau đó do không còn đủ số byte còn lại hiện có, thì Không trả về và lát cắt không được sửa đổi.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Hàm này không có bất biến thực sự mà người gọi phải đề cao ngoài việc có lẽ 'bytes' nên được căn chỉnh để đạt hiệu suất (và về độ chính xác của một số kiến trúc).
// Các giá trị trong trường Elf_Nhdr có thể vô nghĩa nhưng hàm này đảm bảo không có điều đó.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Điều này là an toàn miễn là có đủ không gian và chúng tôi chỉ xác nhận rằng trong câu lệnh if ở trên, vì vậy điều này không phải là không an toàn.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Lưu ý rằng sice_of: :<Elf_Nhdr>() luôn được căn chỉnh 4 byte.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Kiểm tra xem chúng ta đã đến cuối chưa.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Chúng tôi chuyển đổi ra một nhdr nhưng chúng tôi xem xét cẩn thận cấu trúc kết quả.
        // Chúng tôi không tin tưởng tênz hoặc descsz và chúng tôi không đưa ra quyết định không an toàn dựa trên loại.
        //
        // Vì vậy, ngay cả khi chúng ta dọn sạch rác, chúng ta vẫn nên an toàn.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Cho biết một phân đoạn có thể thực thi được.
const PERM_X: u32 = 0b00000001;
/// Cho biết rằng một phân đoạn có thể ghi được.
const PERM_W: u32 = 0b00000010;
/// Cho biết rằng một phân đoạn có thể đọc được.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Đại diện cho một phân đoạn ELF trong thời gian chạy.
struct Segment {
    /// Cung cấp địa chỉ ảo thời gian chạy của nội dung phân đoạn này.
    addr: usize,
    /// Cung cấp kích thước bộ nhớ cho nội dung của phân đoạn này.
    size: usize,
    /// Cung cấp địa chỉ ảo mô-đun của phân đoạn này với tệp ELF.
    mod_rel_addr: usize,
    /// Cung cấp các quyền được tìm thấy trong tệp ELF.
    /// Tuy nhiên, những quyền này không nhất thiết phải là những quyền có trong thời gian chạy.
    flags: Perm,
}

/// Cho phép một lần lặp lại các Phân đoạn từ DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Đại diện cho ELF DSO (Đối tượng được chia sẻ động).
/// Loại này tham chiếu đến dữ liệu được lưu trữ trong DSO thực tế hơn là tạo bản sao của chính nó.
struct Dso<'a> {
    /// Trình liên kết động luôn cung cấp cho chúng ta một tên, ngay cả khi tên đó trống.
    /// Trong trường hợp tệp thực thi chính, tên này sẽ trống.
    /// Trong trường hợp một đối tượng được chia sẻ, nó sẽ là soname (xem DT_SONAME).
    name: &'a str,
    /// Trên Fuchsia hầu như tất cả các tệp nhị phân đều có ID xây dựng nhưng đây không phải là một yêu cầu nghiêm ngặt.
    /// Không có cách nào để đối chiếu thông tin DSO với tệp ELF thực sau đó nếu không có build_id, vì vậy chúng tôi yêu cầu mọi DSO phải có một tệp ở đây.
    ///
    /// DSO không có build_id bị bỏ qua.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Trả về một trình lặp qua Phân đoạn trong DSO này.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Những lỗi này mã hóa các vấn đề phát sinh trong khi phân tích cú pháp thông tin về từng DSO.
///
enum Error {
    /// NameError có nghĩa là đã xảy ra lỗi khi chuyển đổi chuỗi kiểu C thành chuỗi rust.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError có nghĩa là chúng tôi không tìm thấy ID bản dựng.
    /// Điều này có thể là do DSO không có ID bản dựng hoặc do phân đoạn chứa ID bản dựng không đúng định dạng.
    ///
    BuildIDError,
}

/// Gọi 'dso' hoặc 'error' cho mỗi DSO được liên kết động liên kết với quy trình.
///
///
/// # Arguments
///
/// * `visitor` - Một DsoPrinter sẽ có một trong các phương thức ăn được gọi là foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr đảm bảo rằng info.name sẽ trỏ đến một vị trí hợp lệ.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Chức năng này in đánh dấu ký hiệu Fuchsia cho tất cả thông tin có trong DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}