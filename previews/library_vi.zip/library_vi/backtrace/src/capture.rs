use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Đại diện cho một nền tảng sở hữu và độc lập.
///
/// Cấu trúc này có thể được sử dụng để ghi lại dấu vết tại các điểm khác nhau trong một chương trình và sau đó được sử dụng để kiểm tra dấu vết tồn đọng tại thời điểm đó.
///
///
/// `Backtrace` hỗ trợ in khá nhiều dấu vết thông qua việc triển khai `Debug` của nó.
///
/// # Các tính năng bắt buộc
///
/// Chức năng này yêu cầu bật tính năng `std` của `backtrace` crate và tính năng `std` được bật theo mặc định.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Các khung ở đây được liệt kê từ trên xuống dưới của ngăn xếp
    frames: Vec<BacktraceFrame>,
    // Chỉ số mà chúng tôi tin rằng là thời điểm bắt đầu thực tế của backtrace, bỏ qua các khung như `Backtrace::new` và `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Đã chụp phiên bản của một khung trong một dấu vết.
///
/// Loại này được trả về dưới dạng danh sách từ `Backtrace::frames` và đại diện cho một khung ngăn xếp trong một dấu vết đã được chụp lại.
///
/// # Các tính năng bắt buộc
///
/// Chức năng này yêu cầu bật tính năng `std` của `backtrace` crate và tính năng `std` được bật theo mặc định.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Đã chụp phiên bản của một biểu tượng trong một dấu vết.
///
/// Loại này được trả về dưới dạng danh sách từ `BacktraceFrame::symbols` và đại diện cho siêu dữ liệu cho một biểu tượng trong dấu vết.
///
/// # Các tính năng bắt buộc
///
/// Chức năng này yêu cầu bật tính năng `std` của `backtrace` crate và tính năng `std` được bật theo mặc định.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Nắm bắt một backtrace tại callite của hàm này, trả về một đại diện được sở hữu.
    ///
    /// Hàm này hữu ích để biểu diễn backtrace dưới dạng một đối tượng trong Rust.Giá trị trả về này có thể được gửi qua các chuỗi và được in ở nơi khác, và mục đích của giá trị này là hoàn toàn độc lập.
    ///
    /// Lưu ý rằng trên một số nền tảng, việc mua lại đầy đủ và giải quyết nó có thể cực kỳ tốn kém.
    /// Nếu chi phí quá nhiều cho ứng dụng của bạn, thay vào đó, bạn nên sử dụng `Backtrace::new_unresolved()` để tránh bước phân giải biểu tượng (thường mất nhiều thời gian nhất) và cho phép trì hoãn bước đó đến một ngày sau đó.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Các tính năng bắt buộc
    ///
    /// Chức năng này yêu cầu bật tính năng `std` của `backtrace` crate và tính năng `std` được bật theo mặc định.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // muốn đảm bảo rằng có một khung ở đây để loại bỏ
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Tương tự như `new` ngoại trừ việc điều này không giải quyết bất kỳ ký hiệu nào, điều này chỉ đơn giản là ghi lại dấu vết dưới dạng danh sách địa chỉ.
    ///
    /// Sau đó, hàm `resolve` có thể được gọi để giải quyết các ký hiệu của backtrace này thành các tên có thể đọc được.
    /// Chức năng này tồn tại bởi vì quá trình giải quyết đôi khi có thể mất một khoảng thời gian đáng kể trong khi bất kỳ dấu vết tồn đọng nào có thể hiếm khi được in ra.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // không có tên ký hiệu
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // tên biểu tượng bây giờ có mặt
    /// ```
    ///
    /// # Các tính năng bắt buộc
    ///
    /// Chức năng này yêu cầu bật tính năng `std` của `backtrace` crate và tính năng `std` được bật theo mặc định.
    ///
    ///
    ///
    #[inline(never)] // muốn đảm bảo rằng có một khung ở đây để loại bỏ
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Trả về các khung hình từ khi dấu vết này được chụp lại.
    ///
    /// Mục nhập đầu tiên của phần này có thể là hàm `Backtrace::new` và khung cuối cùng có thể là một cái gì đó về cách luồng này hoặc chức năng chính bắt đầu.
    ///
    ///
    /// # Các tính năng bắt buộc
    ///
    /// Chức năng này yêu cầu bật tính năng `std` của `backtrace` crate và tính năng `std` được bật theo mặc định.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Nếu backtrace này được tạo từ `new_unresolved` thì hàm này sẽ phân giải tất cả các địa chỉ trong backtrace thành tên tượng trưng của chúng.
    ///
    ///
    /// Nếu tồn đọng này đã được giải quyết trước đó hoặc được tạo thông qua `new`, thì chức năng này không có tác dụng gì.
    ///
    /// # Các tính năng bắt buộc
    ///
    /// Chức năng này yêu cầu bật tính năng `std` của `backtrace` crate và tính năng `std` được bật theo mặc định.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Giống như `Frame::ip`
    ///
    /// # Các tính năng bắt buộc
    ///
    /// Chức năng này yêu cầu bật tính năng `std` của `backtrace` crate và tính năng `std` được bật theo mặc định.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Giống như `Frame::symbol_address`
    ///
    /// # Các tính năng bắt buộc
    ///
    /// Chức năng này yêu cầu bật tính năng `std` của `backtrace` crate và tính năng `std` được bật theo mặc định.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Giống như `Frame::module_base_address`
    ///
    /// # Các tính năng bắt buộc
    ///
    /// Chức năng này yêu cầu bật tính năng `std` của `backtrace` crate và tính năng `std` được bật theo mặc định.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Trả về danh sách các ký hiệu mà khung này tương ứng với.
    ///
    /// Thông thường chỉ có một ký hiệu cho mỗi khung, nhưng đôi khi nếu một số hàm được nội tuyến vào một khung thì nhiều ký hiệu sẽ được trả về.
    /// Biểu tượng đầu tiên được liệt kê là "innermost function", trong khi biểu tượng cuối cùng là ngoài cùng (người gọi cuối cùng).
    ///
    /// Lưu ý rằng nếu khung này đến từ một tồn đọng chưa được giải quyết thì điều này sẽ trả về một danh sách trống.
    ///
    /// # Các tính năng bắt buộc
    ///
    /// Chức năng này yêu cầu bật tính năng `std` của `backtrace` crate và tính năng `std` được bật theo mặc định.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Giống như `Symbol::name`
    ///
    /// # Các tính năng bắt buộc
    ///
    /// Chức năng này yêu cầu bật tính năng `std` của `backtrace` crate và tính năng `std` được bật theo mặc định.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Giống như `Symbol::addr`
    ///
    /// # Các tính năng bắt buộc
    ///
    /// Chức năng này yêu cầu bật tính năng `std` của `backtrace` crate và tính năng `std` được bật theo mặc định.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Giống như `Symbol::filename`
    ///
    /// # Các tính năng bắt buộc
    ///
    /// Chức năng này yêu cầu bật tính năng `std` của `backtrace` crate và tính năng `std` được bật theo mặc định.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Giống như `Symbol::lineno`
    ///
    /// # Các tính năng bắt buộc
    ///
    /// Chức năng này yêu cầu bật tính năng `std` của `backtrace` crate và tính năng `std` được bật theo mặc định.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Giống như `Symbol::colno`
    ///
    /// # Các tính năng bắt buộc
    ///
    /// Chức năng này yêu cầu bật tính năng `std` của `backtrace` crate và tính năng `std` được bật theo mặc định.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Khi in đường dẫn, chúng tôi cố gắng loại bỏ cwd nếu nó tồn tại, nếu không, chúng tôi chỉ in đường dẫn như hiện tại.
        // Lưu ý rằng chúng tôi cũng chỉ làm điều này cho định dạng ngắn, vì nếu nó đầy, chúng tôi có thể muốn in mọi thứ.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}