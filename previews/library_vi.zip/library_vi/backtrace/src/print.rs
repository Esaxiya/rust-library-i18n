#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Một định dạng cho các dấu lùi.
///
/// Loại này có thể được sử dụng để in backtrace bất kể backtrace xuất phát từ đâu.
/// Nếu bạn có kiểu `Backtrace` thì việc triển khai `Debug` của nó đã sử dụng định dạng in này.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Các kiểu in mà chúng tôi có thể in
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// In dấu nền ngắn hơn mà lý tưởng là chỉ chứa thông tin có liên quan
    Short,
    /// In dấu nền chứa tất cả thông tin có thể có
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Tạo một `BacktraceFmt` mới sẽ ghi đầu ra vào `fmt` được cung cấp.
    ///
    /// Đối số `format` sẽ kiểm soát kiểu in backtrace và đối số `print_path` sẽ được sử dụng để in các phiên bản `BytesOrWideString` của tên tệp.
    /// Bản thân loại này không thực hiện bất kỳ thao tác in tên tệp nào, nhưng lệnh gọi lại này là bắt buộc để thực hiện.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// In lời mở đầu cho bản nhạc nền sắp được in.
    ///
    /// Điều này là bắt buộc trên một số nền tảng để các dấu lùi sau được biểu tượng hóa đầy đủ sau này, và nếu không thì đây chỉ nên là phương thức đầu tiên bạn gọi sau khi tạo `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Thêm một khung vào đầu ra backtrace.
    ///
    /// Cam kết này trả về một thể hiện RAII của `BacktraceFrameFmt` có thể được sử dụng để thực sự in một khung và khi hủy nó sẽ làm tăng bộ đếm khung.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Hoàn thành đầu ra backtrace.
    ///
    /// Tính năng này hiện không được phép sử dụng nhưng được thêm vào để future tương thích với các định dạng backtrace.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Hiện tại là cấm-bao gồm hook này để cho phép bổ sung future.
        Ok(())
    }
}

/// Một định dạng chỉ cho một khung của backtrace.
///
/// Loại này được tạo bởi hàm `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// In `BacktraceFrame` với bộ định dạng khung này.
    ///
    /// Thao tác này sẽ in đệ quy tất cả các phiên bản `BacktraceSymbol` trong `BacktraceFrame`.
    ///
    /// # Các tính năng bắt buộc
    ///
    /// Chức năng này yêu cầu bật tính năng `std` của `backtrace` crate và tính năng `std` được bật theo mặc định.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// In `BacktraceSymbol` trong `BacktraceFrame`.
    ///
    /// # Các tính năng bắt buộc
    ///
    /// Chức năng này yêu cầu bật tính năng `std` của `backtrace` crate và tính năng `std` được bật theo mặc định.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: điều này thật tuyệt khi chúng tôi không in bất cứ thứ gì
            // với tên tệp không phải utf8.
            // Rất may, hầu hết mọi thứ đều là utf8 nên điều này không quá tệ.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// In `Frame` và `Symbol` được theo dõi thô, thường từ bên trong các lệnh gọi lại thô của crate này.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Thêm một khung thô vào đầu ra backtrace.
    ///
    /// Không giống như phương pháp trước, phương pháp này lấy các đối số thô trong trường hợp chúng được lấy nguồn từ các vị trí khác nhau.
    /// Lưu ý rằng điều này có thể được gọi nhiều lần cho một khung.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Thêm một khung thô vào đầu ra backtrace, bao gồm cả thông tin cột.
    ///
    /// Phương pháp này, giống như phương pháp trước, lấy các đối số thô trong trường hợp chúng được lấy từ các vị trí khác nhau.
    /// Lưu ý rằng điều này có thể được gọi nhiều lần cho một khung.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia không thể ký hiệu trong một quá trình nên nó có một định dạng đặc biệt có thể được sử dụng để ký hiệu sau này.
        // In địa chỉ đó thay vì in địa chỉ ở định dạng riêng của chúng tôi tại đây.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Không cần in các khung "null", về cơ bản điều đó chỉ có nghĩa là hệ thống đã có một chút háo hức để theo dõi quá xa.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Để giảm kích thước TCB trong Sgx enclave, chúng tôi không muốn triển khai chức năng phân giải biểu tượng.
        // Thay vào đó, chúng ta có thể in offset của địa chỉ ở đây, sau này có thể được ánh xạ để chỉnh sửa chức năng.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // In chỉ mục của khung cũng như con trỏ lệnh tùy chọn của khung.
        // Nếu chúng ta vượt ra ngoài biểu tượng đầu tiên của khung này, mặc dù chúng ta chỉ in khoảng trắng thích hợp.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Tiếp theo, hãy viết ra tên biểu tượng, sử dụng định dạng thay thế để biết thêm thông tin nếu chúng ta là một người có hoàn cảnh khó khăn.
        // Ở đây chúng tôi cũng xử lý các ký hiệu không có tên,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Và cuối cùng, hãy in ra số filename/line nếu chúng có sẵn.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line được in trên các dòng dưới tên biểu tượng, vì vậy hãy in một số khoảng trắng thích hợp để sắp xếp căn lề phải.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Ủy quyền cho cuộc gọi lại nội bộ của chúng tôi để in tên tệp và sau đó in ra số dòng.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Thêm số cột, nếu có.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Chúng tôi chỉ quan tâm đến biểu tượng đầu tiên của khung
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}