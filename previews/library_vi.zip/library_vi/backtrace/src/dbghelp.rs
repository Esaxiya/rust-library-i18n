//! Một mô-đun để hỗ trợ quản lý các ràng buộc dbghelp trên Windows
//!
//! Backtraces trên Windows (ít nhất là đối với MSVC) phần lớn được cung cấp thông qua `dbghelp.dll` và các chức năng khác nhau mà nó có.
//! Các hàm này hiện được tải *động* thay vì liên kết tĩnh với `dbghelp.dll`.
//! Điều này hiện đang được thực hiện bởi thư viện tiêu chuẩn (và về lý thuyết là bắt buộc ở đó), nhưng là một nỗ lực để giúp giảm bớt sự phụ thuộc của dll tĩnh của một thư viện vì các dấu nền thường khá tùy chọn.
//!
//! Điều đó đang được nói, `dbghelp.dll` hầu như luôn luôn tải thành công trên Windows.
//!
//! Xin lưu ý rằng vì chúng tôi đang tải động tất cả hỗ trợ này, chúng tôi thực sự không thể sử dụng các định nghĩa thô trong `winapi`, mà thay vào đó, chúng tôi cần tự xác định các loại con trỏ hàm và sử dụng nó.
//! Chúng tôi không thực sự muốn kinh doanh sao chép winapi, vì vậy chúng tôi có tính năng Cargo `verify-winapi` khẳng định rằng tất cả các liên kết khớp với những liên kết trong winapi và tính năng này được bật trên CI.
//!
//! Cuối cùng, bạn sẽ lưu ý ở đây rằng dll cho `dbghelp.dll` không bao giờ được tải xuống và điều đó hiện có chủ ý.
//! Suy nghĩ là chúng ta có thể lưu trữ nó trên toàn cầu và sử dụng nó giữa các lần gọi tới API, tránh loads/unloads đắt tiền.
//! Nếu đây là vấn đề đối với máy dò rò rỉ hoặc những thứ tương tự như vậy, chúng ta có thể băng qua cầu khi đến đó.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Làm việc xung quanh `SymGetOptions` và `SymSetOptions` không có trong chính winapi.
// Nếu không, điều này chỉ được sử dụng khi chúng tôi kiểm tra kỹ các loại dựa trên winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Chưa được xác định trong winapi
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Điều này được định nghĩa trong winapi, nhưng nó không chính xác (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Chưa được xác định trong winapi
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Macro này được sử dụng để xác định cấu trúc `Dbghelp` chứa bên trong tất cả các con trỏ hàm mà chúng tôi có thể tải.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// DLL đã tải cho `dbghelp.dll`
            dll: HMODULE,

            // Mỗi con trỏ hàm cho mỗi hàm chúng ta có thể sử dụng
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Ban đầu, chúng tôi chưa tải DLL
            dll: 0 as *mut _,
            // Khởi đầu tất cả các chức năng được đặt thành 0 để nói rằng chúng cần được tải động.
            //
            $($name: 0,)*
        };

        // Typedef thuận tiện cho từng loại chức năng.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Cố gắng mở `dbghelp.dll`.
            /// Trả về thành công nếu nó hoạt động hoặc lỗi nếu `LoadLibraryW` không thành công.
            ///
            /// Panics nếu thư viện đã được tải.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Chức năng cho mỗi phương pháp chúng tôi muốn sử dụng.
            // Khi được gọi, nó sẽ đọc con trỏ hàm được lưu trong bộ nhớ cache hoặc tải nó và trả về giá trị đã tải.
            // Tải được khẳng định sẽ thành công.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Proxy thuận tiện để sử dụng khóa dọn dẹp để tham chiếu các chức năng dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Khởi tạo tất cả các hỗ trợ cần thiết để truy cập các hàm API `dbghelp` từ crate này.
///
///
/// Lưu ý rằng chức năng này là **an toàn**, bên trong nó có đồng bộ hóa riêng.
/// Cũng lưu ý rằng an toàn khi gọi hàm này nhiều lần một cách đệ quy.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Điều đầu tiên chúng ta cần làm là đồng bộ hóa chức năng này.Điều này có thể được gọi đồng thời từ các luồng khác hoặc đệ quy trong một luồng.
        // Lưu ý rằng nó phức tạp hơn thế vì những gì chúng tôi đang sử dụng ở đây, `dbghelp`,*cũng* cần được đồng bộ hóa với tất cả những người gọi khác tới `dbghelp` trong quá trình này.
        //
        // Thông thường, không thực sự có nhiều cuộc gọi đến `dbghelp` trong cùng một quá trình và chúng ta có thể yên tâm cho rằng chúng ta là người duy nhất truy cập nó.
        // Tuy nhiên, có một người dùng chính khác mà chúng tôi phải lo lắng về điều trớ trêu thay lại chính là bản thân họ, nhưng lại nằm trong thư viện tiêu chuẩn.
        // Thư viện chuẩn Rust phụ thuộc vào crate này để hỗ trợ backtrace và crate này cũng tồn tại trên crates.io.
        // Điều này có nghĩa là nếu thư viện tiêu chuẩn đang in ngược panic thì nó có thể chạy đua với crate này đến từ crates.io, gây ra các giá trị mặc định.
        //
        // Để giúp giải quyết vấn đề đồng bộ hóa này, chúng tôi sử dụng một thủ thuật dành riêng cho Windows ở đây (xét cho cùng, đó là một hạn chế dành riêng cho Windows về đồng bộ hóa).
        // Chúng tôi tạo một *session-local* có tên mutex để bảo vệ cuộc gọi này.
        // Mục đích ở đây là thư viện tiêu chuẩn và crate này không phải chia sẻ các API cấp Rust để đồng bộ hóa ở đây mà thay vào đó có thể hoạt động đằng sau hậu trường để đảm bảo chúng đang đồng bộ hóa với nhau.
        //
        // Bằng cách đó, khi hàm này được gọi thông qua thư viện chuẩn hoặc thông qua crates.io, chúng ta có thể chắc chắn rằng cùng một mutex đang được mua.
        //
        // Vì vậy, tất cả những điều đó muốn nói rằng điều đầu tiên chúng ta làm ở đây là chúng ta tạo ra một `HANDLE` về mặt nguyên tử, là một mutex được đặt tên trên Windows.
        // Chúng tôi đồng bộ hóa một chút với các luồng khác chia sẻ cụ thể chức năng này và đảm bảo rằng chỉ một xử lý được tạo cho mỗi phiên bản của chức năng này.
        // Lưu ý rằng xử lý không bao giờ bị đóng khi nó được lưu trữ trên toàn cầu.
        //
        // Sau khi chúng tôi thực sự mở khóa, chúng tôi chỉ cần lấy nó và tay cầm `Init` của chúng tôi mà chúng tôi cung cấp sẽ chịu trách nhiệm đánh rơi nó cuối cùng.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Được rồi!Bây giờ tất cả chúng ta đã được đồng bộ hóa một cách an toàn, hãy thực sự bắt đầu xử lý mọi thứ.
        // Đầu tiên, chúng ta cần đảm bảo rằng `dbghelp.dll` thực sự được tải trong quá trình này.
        // Chúng tôi thực hiện điều này một cách động để tránh sự phụ thuộc tĩnh.
        // Điều này trong lịch sử đã được thực hiện để giải quyết các vấn đề liên kết kỳ lạ và nhằm mục đích làm cho các tệp nhị phân trở nên linh hoạt hơn một chút vì đây phần lớn chỉ là một tiện ích gỡ lỗi.
        //
        //
        // Khi chúng ta đã mở `dbghelp.dll`, chúng ta cần gọi một số hàm khởi tạo trong đó và điều đó sẽ được trình bày chi tiết bên dưới.
        // Tuy nhiên, chúng tôi chỉ làm điều này một lần, vì vậy chúng tôi có boolean toàn cục cho biết chúng tôi đã hoàn thành hay chưa.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Đảm bảo rằng cờ `SYMOPT_DEFERRED_LOADS` được đặt, vì theo tài liệu riêng của MSVC về điều này: "This is the fastest, most efficient way to use the symbol handler.", vì vậy hãy làm điều đó!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Trên thực tế khởi tạo các ký hiệu bằng MSVC.Lưu ý rằng điều này có thể không thành công, nhưng chúng tôi bỏ qua nó.
        // Không có nhiều tác phẩm trước cho điều này, nhưng nội bộ LLVM dường như bỏ qua giá trị trả về ở đây và một trong những thư viện trình vệ sinh trong LLVM sẽ in một cảnh báo đáng sợ nếu điều này không thành công nhưng về cơ bản sẽ bỏ qua nó về lâu dài.
        //
        //
        // Một trường hợp điều này xuất hiện rất nhiều đối với Rust là thư viện tiêu chuẩn và crate này trên crates.io đều muốn cạnh tranh cho `SymInitializeW`.
        // Thư viện tiêu chuẩn trước đây thường muốn khởi tạo sau đó dọn dẹp hầu hết thời gian, nhưng bây giờ nó đang sử dụng crate này, điều đó có nghĩa là ai đó sẽ bắt đầu khởi tạo trước và người kia sẽ nhận khởi tạo đó.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}