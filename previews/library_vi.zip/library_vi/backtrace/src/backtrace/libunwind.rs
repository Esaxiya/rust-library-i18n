//! Hỗ trợ backtrace bằng cách sử dụng các API libunwind/gcc_s/etc.
//!
//! Mô-đun này có khả năng giải phóng ngăn xếp bằng cách sử dụng các API kiểu libunwind.
//! Lưu ý rằng có rất nhiều cách triển khai API giống như libunwind và điều này chỉ đang cố gắng tương thích với hầu hết chúng cùng một lúc thay vì kén chọn.
//!
//!
//! API libunwind được cung cấp bởi `_Unwind_Backtrace` và trên thực tế rất đáng tin cậy trong việc tạo ra một backtrace.
//! Nó không hoàn toàn rõ ràng nó hoạt động như thế nào (con trỏ khung? Eh_frame thông tin? Cả hai?) Nhưng nó có vẻ hoạt động!
//!
//! Hầu hết sự phức tạp của mô-đun này là xử lý các khác biệt nền tảng khác nhau giữa các triển khai libunwind.
//! Nếu không thì đây là một ràng buộc Rust khá đơn giản với các API libunwind.
//!
//! Đây là API giải nén mặc định cho tất cả các nền tảng không phải Windows hiện tại.
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// Với một con trỏ libunwind thô, nó chỉ có thể được truy cập theo kiểu luồng an toàn chỉ đọc, vì vậy đó là `Sync`.
// Khi gửi đến các chủ đề khác qua `Clone`, chúng tôi luôn chuyển sang một phiên bản không giữ lại các con trỏ bên trong, vì vậy chúng tôi cũng nên là `Send`.
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // Có vẻ như trên OSX `_Unwind_FindEnclosingFunction` trả về một con trỏ đến ... một cái gì đó không rõ ràng.
        // Nó chắc chắn không phải lúc nào cũng là chức năng bao quanh vì bất kỳ lý do gì.
        // Tôi không hoàn toàn rõ ràng những gì đang xảy ra ở đây, vì vậy hãy bi quan điều này ngay bây giờ và chỉ cần trả lại ip.
        //
        // Lưu ý rằng bài kiểm tra `skip_inner_frames.rs` bị bỏ qua trên OSX do điều khoản này và nếu điều này được khắc phục thì bài kiểm tra trên lý thuyết có thể chạy trên OSX!
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// Mở rộng giao diện thư viện được sử dụng cho các dấu vết
///
/// Lưu ý rằng mã chết được cho phép vì ở đây chỉ là ràng buộc iOS không sử dụng tất cả chúng nhưng việc thêm nhiều cấu hình nền tảng cụ thể hơn sẽ làm ô nhiễm mã quá nhiều
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // chỉ được sử dụng bởi ARM EABI
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        // Không có _Unwind_Backtrace gốc trên iOS
        #[cfg(not(all(target_os = "ios", target_arch = "arm")))]
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;

        // có sẵn kể từ GCC 4.2.0, nên phù hợp với mục đích của chúng tôi
        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "s390x"))
        ))]
        // Hàm này là một sự nhầm lẫn: thay vì lấy Địa chỉ Khung Canonical của khung này (hay còn gọi là SP của khung người gọi), nó sẽ trả về SP của khung này.
        //
        //
        // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
        //
        #[link_name = "_Unwind_GetCFA"]
        pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
    }

    // s390x sử dụng giá trị CFA thiên vị, do đó chúng ta cần sử dụng_Unwind_GetGR để lấy thanh ghi con trỏ ngăn xếp (%r15) thay vì dựa vào_Unwind_GetCFA.
    //
    //
    #[cfg(all(target_os = "linux", target_arch = "s390x"))]
    pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
        extern "C" {
            pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
        }
        _Unwind_GetGR(ctx, 15)
    }

    // Trên android và arm, hàm `_Unwind_GetIP` và một loạt các hàm khác là macro, vì vậy chúng tôi xác định các hàm chứa sự mở rộng của macro.
    //
    //
    // TODO: liên kết đến tệp tiêu đề xác định các macro này, nếu bạn có thể tìm thấy nó.
    // (Tôi, fitzgen, không thể tìm thấy tệp tiêu đề mà một số bản mở rộng macro này ban đầu được mượn từ đó.)
    //
    //
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    pub use self::arm::*;
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    mod arm {
        pub use super::*;
        #[repr(C)]
        enum _Unwind_VRS_Result {
            _UVRSR_OK = 0,
            _UVRSR_NOT_IMPLEMENTED = 1,
            _UVRSR_FAILED = 2,
        }
        #[repr(C)]
        enum _Unwind_VRS_RegClass {
            _UVRSC_CORE = 0,
            _UVRSC_VFP = 1,
            _UVRSC_FPA = 2,
            _UVRSC_WMMXD = 3,
            _UVRSC_WMMXC = 4,
        }
        #[repr(C)]
        enum _Unwind_VRS_DataRepresentation {
            _UVRSD_UINT32 = 0,
            _UVRSD_VFPX = 1,
            _UVRSD_FPAX = 2,
            _UVRSD_UINT64 = 3,
            _UVRSD_FLOAT = 4,
            _UVRSD_DOUBLE = 5,
        }

        type _Unwind_Word = libc::c_uint;
        extern "C" {
            fn _Unwind_VRS_Get(
                ctx: *mut _Unwind_Context,
                klass: _Unwind_VRS_RegClass,
                word: _Unwind_Word,
                repr: _Unwind_VRS_DataRepresentation,
                data: *mut c_void,
            ) -> _Unwind_VRS_Result;
        }

        pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                15,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            (val & !1) as libc::uintptr_t
        }

        // R13 là con trỏ ngăn xếp trên cánh tay.
        const SP: _Unwind_Word = 13;

        pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                SP,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            val as libc::uintptr_t
        }

        // Chức năng này cũng không tồn tại trên Android hoặc ARM/Linux, do đó, hãy chọn nó.
        //
        pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
            pc
        }
    }
}