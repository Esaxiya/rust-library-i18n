use core::ffi::c_void;
use core::fmt;

/// Kiểm tra ngăn xếp cuộc gọi hiện tại, chuyển tất cả các khung hoạt động vào bao đóng được cung cấp để tính toán dấu vết ngăn xếp.
///
/// Hàm này là workhorse của thư viện này trong việc tính toán các dấu vết ngăn xếp cho một chương trình.Bao đóng đã cho `cb` là các thể hiện của `Frame` đại diện cho thông tin về khung cuộc gọi đó trên ngăn xếp.
/// Việc đóng lại được tạo ra các khung theo kiểu từ trên xuống (gần đây nhất được gọi là các hàm trước tiên).
///
/// Giá trị trả về của lệnh đóng là một dấu hiệu cho biết liệu quá trình lùi lại có nên tiếp tục hay không.Giá trị trả về của `false` sẽ chấm dứt backtrace và trả về ngay lập tức.
///
/// Sau khi có được `Frame`, bạn có thể sẽ muốn gọi `backtrace::resolve` để chuyển đổi `ip` (con trỏ lệnh) hoặc địa chỉ biểu tượng thành `Symbol` mà thông qua đó, tên và/hoặc tên tệp/số dòng có thể được học.
///
///
/// Lưu ý rằng đây là một chức năng cấp tương đối thấp và nếu bạn muốn, chẳng hạn như ghi lại dấu vết để kiểm tra sau này, thì loại `Backtrace` có thể thích hợp hơn.
///
/// # Các tính năng bắt buộc
///
/// Chức năng này yêu cầu bật tính năng `std` của `backtrace` crate và tính năng `std` được bật theo mặc định.
///
/// # Panics
///
/// Chức năng này cố gắng không bao giờ panic, nhưng nếu `cb` cung cấp panics thì một số nền tảng sẽ buộc panic kép phải hủy bỏ quá trình.
/// Một số nền tảng sử dụng thư viện C sử dụng nội bộ các lệnh gọi lại mà không thể bỏ qua, vì vậy việc hoảng sợ từ `cb` có thể kích hoạt quá trình hủy bỏ.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // tiếp tục con đường lùi
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Tương tự như `trace`, chỉ không an toàn vì nó không được đồng bộ hóa.
///
/// Chức năng này không có guarentees đồng bộ hóa nhưng khả dụng khi tính năng `std` của crate này không được biên dịch.
/// Xem chức năng `trace` để biết thêm tài liệu và ví dụ.
///
/// # Panics
///
/// Xem thông tin về `trace` để biết cảnh báo về việc `cb` đang hoảng loạn.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// trait đại diện cho một khung của backtrace, nhường cho hàm `trace` của crate này.
///
/// Việc đóng của chức năng theo dõi sẽ được tạo ra các khung và khung hầu như được gửi đi vì việc triển khai bên dưới không phải lúc nào cũng được biết đến cho đến thời gian chạy.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Trả về con trỏ hướng dẫn hiện tại của khung này.
    ///
    /// Đây thường là lệnh tiếp theo để thực thi trong khung, nhưng không phải tất cả các triển khai đều liệt kê điều này với độ chính xác 100% (nhưng nói chung là khá gần).
    ///
    ///
    /// Bạn nên chuyển giá trị này cho `backtrace::resolve` để biến nó thành tên ký hiệu.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Trả về con trỏ ngăn xếp hiện tại của khung này.
    ///
    /// Trong trường hợp chương trình phụ trợ không thể khôi phục con trỏ ngăn xếp cho khung này, con trỏ null sẽ được trả về.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Trả về địa chỉ ký hiệu bắt đầu của khung của hàm này.
    ///
    /// Thao tác này sẽ cố gắng tua lại con trỏ lệnh được trả về bởi `ip` về đầu hàm, trả về giá trị đó.
    ///
    /// Tuy nhiên, trong một số trường hợp, phụ trợ sẽ chỉ trả về `ip` từ chức năng này.
    ///
    /// Giá trị trả về đôi khi có thể được sử dụng nếu `backtrace::resolve` không thành công trên `ip` đã cho ở trên.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Trả về địa chỉ cơ sở của mô-đun mà khung thuộc về.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Điều này cần phải đến trước để đảm bảo rằng Miri được ưu tiên hơn so với nền tảng máy chủ
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // chỉ được sử dụng trong biểu tượng dbghelp
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}