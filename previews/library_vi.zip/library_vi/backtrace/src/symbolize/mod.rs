use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Phân giải một địa chỉ thành một biểu tượng, chuyển biểu tượng đến một bao đóng được chỉ định.
///
/// Chức năng này sẽ tra cứu địa chỉ đã cho trong các khu vực như bảng ký hiệu cục bộ, bảng ký hiệu động hoặc thông tin gỡ lỗi DWARF (tùy thuộc vào việc triển khai được kích hoạt) để tìm các ký hiệu cần mang lại.
///
///
/// Việc đóng có thể không được gọi nếu không thể thực hiện phân giải, và nó cũng có thể được gọi nhiều lần trong trường hợp các hàm nội tuyến.
///
/// Các ký hiệu mang lại đại diện cho việc thực thi tại `addr` được chỉ định, trả về các cặp file/line cho địa chỉ đó (nếu có).
///
/// Lưu ý rằng nếu bạn có `Frame` thì bạn nên sử dụng chức năng `resolve_frame` thay vì chức năng này.
///
/// # Các tính năng bắt buộc
///
/// Chức năng này yêu cầu bật tính năng `std` của `backtrace` crate và tính năng `std` được bật theo mặc định.
///
/// # Panics
///
/// Chức năng này cố gắng không bao giờ panic, nhưng nếu `cb` cung cấp panics thì một số nền tảng sẽ buộc panic kép phải hủy bỏ quá trình.
/// Một số nền tảng sử dụng thư viện C sử dụng nội bộ các lệnh gọi lại mà không thể bỏ qua, vì vậy việc hoảng sợ từ `cb` có thể kích hoạt quá trình hủy bỏ.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // chỉ nhìn vào khung trên cùng
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Phân giải một khung đã chụp trước đó thành một biểu tượng, chuyển biểu tượng đó đến vùng đóng được chỉ định.
///
/// Functin này thực hiện chức năng tương tự như `resolve` ngoại trừ việc nó lấy `Frame` làm đối số thay vì địa chỉ.
/// Điều này có thể cho phép một số triển khai nền tảng của backtracing để cung cấp thông tin ký hiệu chính xác hơn hoặc thông tin về khung nội tuyến chẳng hạn.
///
/// Bạn nên sử dụng cái này nếu bạn có thể.
///
/// # Các tính năng bắt buộc
///
/// Chức năng này yêu cầu bật tính năng `std` của `backtrace` crate và tính năng `std` được bật theo mặc định.
///
/// # Panics
///
/// Chức năng này cố gắng không bao giờ panic, nhưng nếu `cb` cung cấp panics thì một số nền tảng sẽ buộc panic kép phải hủy bỏ quá trình.
/// Một số nền tảng sử dụng thư viện C sử dụng nội bộ các lệnh gọi lại mà không thể bỏ qua, vì vậy việc hoảng sợ từ `cb` có thể kích hoạt quá trình hủy bỏ.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // chỉ nhìn vào khung trên cùng
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Giá trị IP từ các khung ngăn xếp thường là (always?) lệnh *sau* lệnh gọi đó là dấu vết ngăn xếp thực tế.
// Việc ký hiệu điều này làm cho số filename/line đi trước một số và có thể trở thành khoảng trống nếu nó ở gần cuối hàm.
//
// Điều này dường như luôn luôn xảy ra trên tất cả các nền tảng, vì vậy chúng tôi luôn trừ đi một từ ip đã phân giải để giải quyết nó thành lệnh gọi trước đó thay vì lệnh được trả về.
//
//
// Tốt nhất là chúng tôi sẽ không làm điều này.
// Lý tưởng nhất là chúng tôi yêu cầu người gọi các API `resolve` ở đây thực hiện thủ công -1 và tài khoản rằng họ muốn thông tin vị trí cho hướng dẫn *trước đó*, không phải hiện tại.
// Lý tưởng nhất là chúng tôi cũng sẽ hiển thị trên `Frame` nếu chúng tôi thực sự là địa chỉ của lệnh tiếp theo hoặc hiện tại.
//
// Hiện tại, mặc dù đây là một mối quan tâm khá thích hợp, vì vậy chúng tôi chỉ luôn trừ một trong nội bộ.
// Người tiêu dùng nên tiếp tục làm việc và nhận được kết quả khá tốt, vì vậy chúng ta nên đủ tốt.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Tương tự như `resolve`, chỉ không an toàn vì nó không được đồng bộ hóa.
///
/// Chức năng này không có guarentees đồng bộ hóa nhưng khả dụng khi tính năng `std` của crate này không được biên dịch.
/// Xem chức năng `resolve` để biết thêm tài liệu và ví dụ.
///
/// # Panics
///
/// Xem thông tin về `resolve` để biết cảnh báo về việc `cb` đang hoảng loạn.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Tương tự như `resolve_frame`, chỉ không an toàn vì nó không được đồng bộ hóa.
///
/// Chức năng này không có guarentees đồng bộ hóa nhưng khả dụng khi tính năng `std` của crate này không được biên dịch.
/// Xem chức năng `resolve_frame` để biết thêm tài liệu và ví dụ.
///
/// # Panics
///
/// Xem thông tin về `resolve_frame` để biết cảnh báo về việc `cb` đang hoảng loạn.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// Một trait đại diện cho độ phân giải của một ký hiệu trong một tệp.
///
/// trait này được tạo ra dưới dạng một đối tượng trait cho bao đóng được cung cấp cho hàm `backtrace::resolve` và nó hầu như được gửi đi vì không biết triển khai nào đằng sau nó.
///
///
/// Một biểu tượng có thể cung cấp thông tin theo ngữ cảnh về một hàm, ví dụ như tên, tên tệp, số dòng, địa chỉ chính xác, v.v.
/// Tuy nhiên, không phải tất cả thông tin luôn có sẵn trong một biểu tượng, vì vậy tất cả các phương thức đều trả về `Option`.
///
///
pub struct Symbol {
    // TODO: giới hạn trọn đời này cần phải được duy trì cuối cùng đến `Symbol`,
    // nhưng đó hiện là một thay đổi đột phá.
    // Hiện tại, điều này là an toàn vì `Symbol` chỉ được cung cấp bằng cách tham khảo và không thể sao chép.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Trả về tên của hàm này.
    ///
    /// Cấu trúc trả về có thể được sử dụng để truy vấn các thuộc tính khác nhau về tên biểu tượng:
    ///
    ///
    /// * Việc triển khai `Display` sẽ in ra biểu tượng được tách lớp.
    /// * Giá trị `str` thô của biểu tượng có thể được truy cập (nếu nó là utf-8 hợp lệ).
    /// * Các byte thô cho tên biểu tượng có thể được truy cập.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Trả về địa chỉ bắt đầu của hàm này.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Trả về tên tệp thô dưới dạng một lát cắt.
    /// Điều này chủ yếu hữu ích cho môi trường `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Trả về số cột mà biểu tượng này hiện đang thực thi.
    ///
    /// Chỉ gimli hiện cung cấp một giá trị ở đây và thậm chí sau đó chỉ khi `filename` trả về `Some` và do đó, nó phải tuân theo các cảnh báo tương tự.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Trả về số dòng cho vị trí biểu tượng này hiện đang thực thi.
    ///
    /// Giá trị trả về này thường là `Some` nếu `filename` trả về `Some` và do đó phải tuân theo các cảnh báo tương tự.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Trả về tên tệp nơi hàm này được xác định.
    ///
    /// Điều này hiện chỉ khả dụng khi libbacktrace hoặc gimli đang được sử dụng (ví dụ:
    /// unix nền tảng khác) và khi một tệp nhị phân được biên dịch với debuginfo.
    /// Nếu cả hai điều kiện này đều không được đáp ứng thì điều này có thể sẽ trả về `None`.
    ///
    /// # Các tính năng bắt buộc
    ///
    /// Chức năng này yêu cầu bật tính năng `std` của `backtrace` crate và tính năng `std` được bật theo mặc định.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Có thể là một ký hiệu C++ được phân tích cú pháp, nếu phân tích cú pháp ký hiệu bị xáo trộn là Rust không thành công.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Đảm bảo giữ nguyên kích thước bằng 0 này để tính năng `cpp_demangle` không bị mất phí khi bị vô hiệu hóa.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Một trình bao bọc xung quanh một tên biểu tượng để cung cấp các trình truy cập tiện lợi cho tên đã được tách, các byte thô, chuỗi thô, v.v.
///
// Cho phép mã chết khi tính năng `cpp_demangle` không được bật.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Tạo tên biểu tượng mới từ các byte thô bên dưới.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Trả về tên biểu tượng (mangled) thô dưới dạng `str` nếu biểu tượng là utf-8 hợp lệ.
    ///
    /// Sử dụng triển khai `Display` nếu bạn muốn phiên bản đã được tách.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Trả về tên biểu tượng thô dưới dạng danh sách các byte
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Điều này có thể được in ra nếu biểu tượng được tách lớp không thực sự hợp lệ, vì vậy hãy xử lý lỗi ở đây một cách khéo léo bằng cách không truyền nó ra ngoài.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Cố gắng lấy lại bộ nhớ đã lưu trong bộ nhớ cache được sử dụng để biểu thị địa chỉ.
///
/// Phương pháp này sẽ cố gắng giải phóng bất kỳ cấu trúc dữ liệu toàn cục nào đã được lưu vào bộ nhớ cache trên toàn cầu hoặc trong chuỗi thường đại diện cho thông tin DWARF được phân tích cú pháp hoặc tương tự.
///
///
/// # Caveats
///
/// Mặc dù chức năng này luôn có sẵn nhưng nó không thực sự làm bất cứ điều gì trên hầu hết các triển khai.
/// Các thư viện như dbghelp hoặc libbacktrace không cung cấp các phương tiện để phân bổ trạng thái và quản lý bộ nhớ được cấp phát.
/// Hiện tại, tính năng `gimli-symbolize` của crate này là tính năng duy nhất mà chức năng này có tác dụng.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}