//! Hỗ trợ ký hiệu bằng `gimli` crate trên crates.io
//!
//! Đây là triển khai ký hiệu mặc định cho Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'static life là một sự lừa dối để hack xung quanh việc thiếu hỗ trợ cho các cấu trúc tự tham chiếu.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Chuyển đổi thành 'vòng đời tĩnh vì các biểu tượng chỉ nên mượn `map` và `stash` và chúng tôi đang bảo quản chúng bên dưới.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Để tải các thư viện gốc trên Windows, hãy xem một số thảo luận về rust-lang/rust#71060 để biết các chiến lược khác nhau tại đây.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // Các thư viện MinGW hiện không hỗ trợ ASLR (rust-lang/rust#16514), nhưng các tệp DLL vẫn có thể được di dời trong không gian địa chỉ.
            // Có vẻ như các địa chỉ trong thông tin gỡ lỗi đều giống như thư viện này được tải tại "image base", đây là một trường trong tiêu đề tệp COFF của nó.
            // Vì đây là những gì mà debuginfo liệt kê, chúng tôi phân tích cú pháp bảng biểu tượng và lưu trữ các địa chỉ như thể thư viện cũng được tải ở "image base".
            //
            // Tuy nhiên, thư viện có thể không được tải ở "image base".
            // (có lẽ là thứ gì đó khác có thể được tải ở đó?) Đây là nơi trường `bias` phát huy tác dụng và chúng ta cần tìm ra giá trị của `bias` tại đây.Thật không may, mặc dù không rõ ràng làm thế nào để có được điều này từ một mô-đun đã tải.
            // Tuy nhiên, những gì chúng tôi có là địa chỉ tải thực tế (`modBaseAddr`).
            //
            // Bây giờ, chúng ta chuẩn bị cho tệp mmap một chút, đọc thông tin tiêu đề tệp, sau đó thả mmap xuống.Điều này thật lãng phí vì có thể chúng tôi sẽ mở lại mmap sau, nhưng điều này sẽ hoạt động đủ tốt cho đến lúc này.
            //
            // Khi chúng ta có `image_base` (vị trí tải mong muốn) và `base_addr` (vị trí tải thực tế), chúng tôi có thể điền vào `bias` (sự khác biệt giữa thực tế và mong muốn) và sau đó địa chỉ đã nêu của mỗi phân đoạn là `image_base` vì đó là những gì tệp cho biết.
            //
            //
            // Hiện tại, có vẻ như không giống như ELF/MachO, chúng ta có thể thực hiện với một phân đoạn cho mỗi thư viện, sử dụng `modBaseSize` làm kích thước toàn bộ.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS sử dụng định dạng tệp Mach-O và sử dụng các API dành riêng cho DYLD để tải danh sách các thư viện gốc là một phần của ứng dụng.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Tìm nạp tên của thư viện này tương ứng với đường dẫn của nơi tải nó.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Tải tiêu đề hình ảnh của thư viện này và ủy quyền cho `object` để phân tích cú pháp tất cả các lệnh tải để chúng ta có thể tìm ra tất cả các phân đoạn liên quan ở đây.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Lặp lại các phân đoạn và đăng ký các vùng đã biết cho các phân đoạn mà chúng tôi tìm thấy.
            // Ngoài ra, ghi lại thông tin từng đoạn văn bản để xử lý sau này, xem nhận xét bên dưới.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Xác định "slide" cho thư viện này mà cuối cùng là độ lệch mà chúng tôi sử dụng để tìm ra vị trí các đối tượng trong bộ nhớ được tải.
            // Tuy nhiên, đây là một phép tính hơi kỳ lạ và là kết quả của việc thử một vài thứ trong tự nhiên và xem những gì phù hợp.
            //
            // Ý tưởng chung là `bias` cộng với `stated_virtual_memory_address` của một phân khúc sẽ là nơi trong không gian địa chỉ thực tế mà phân khúc đó cư trú.
            // Tuy nhiên, điều khác mà chúng tôi dựa vào là địa chỉ thực trừ đi `bias` là chỉ số cần tra cứu trong bảng biểu tượng và debuginfo.
            //
            // Tuy nhiên, hóa ra đối với các thư viện được tải hệ thống, các phép tính này không chính xác.Tuy nhiên, đối với các tệp thực thi gốc, nó có vẻ đúng.
            // Nâng một số logic từ nguồn của LLDB, nó có một số cách viết hoa đặc biệt cho phần `__TEXT` đầu tiên được tải từ tệp offset 0 với kích thước khác không.
            // Vì bất kỳ lý do gì khi điều này xuất hiện, nó dường như có nghĩa là bảng biểu tượng chỉ tương đối với trang trình bày vmaddr cho thư viện.
            // Nếu nó *không* hiện diện thì bảng ký hiệu có liên quan đến trang chiếu vmaddr cộng với địa chỉ đã nêu của phân đoạn.
            //
            // Để xử lý tình huống này nếu chúng tôi *không* tìm thấy một phần văn bản ở độ lệch tệp bằng không thì chúng tôi tăng độ lệch theo địa chỉ đã nêu của phần văn bản đầu tiên và giảm tất cả các địa chỉ đã nêu theo số lượng đó.
            //
            // Bằng cách đó, bảng ký hiệu luôn xuất hiện liên quan đến số lượng thiên vị của thư viện.
            // Điều này dường như có kết quả phù hợp cho việc ký hiệu thông qua bảng ký hiệu.
            //
            // Thành thật mà nói, tôi không hoàn toàn chắc chắn liệu điều này có đúng hay không hay có điều gì khác sẽ chỉ ra cách thực hiện điều này.
            // Hiện tại, mặc dù điều này dường như hoạt động đủ tốt với (?) và chúng tôi sẽ luôn có thể tinh chỉnh điều này theo thời gian nếu cần thiết.
            //
            // Để biết thêm thông tin, hãy xem #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Unix khác (ví dụ:
        // Nền tảng Linux) sử dụng ELF làm định dạng tệp đối tượng và thường triển khai một API có tên là `dl_iterate_phdr` để tải các thư viện gốc.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` phải là một con trỏ hợp lệ.
        // `vec` phải là một con trỏ hợp lệ tới `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 nguyên bản không hỗ trợ thông tin gỡ lỗi, nhưng hệ thống xây dựng sẽ đặt thông tin gỡ lỗi tại đường dẫn `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Mọi thứ khác nên sử dụng ELF, nhưng không biết cách tải các thư viện gốc.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Tất cả các thư viện chia sẻ đã biết đã được tải.
    libraries: Vec<Library>,

    /// Ánh xạ bộ nhớ cache nơi chúng tôi giữ lại thông tin ngắn đã được phân tích cú pháp.
    ///
    /// Danh sách này có dung lượng cố định trong toàn bộ thời gian tồn tại của nó mà không bao giờ tăng.
    /// Phần tử `usize` của mỗi cặp là một chỉ mục trong `libraries` ở trên trong đó `usize::max_value()` đại diện cho tệp thực thi hiện tại.
    ///
    /// `Mapping` là thông tin lùn được phân tích cú pháp tương ứng.
    ///
    /// Lưu ý rằng đây về cơ bản là một bộ nhớ cache LRU và chúng tôi sẽ chuyển mọi thứ xung quanh đây khi chúng tôi ký hiệu các địa chỉ.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Các phân đoạn của thư viện này được tải vào bộ nhớ và chúng được tải ở đâu.
    segments: Vec<LibrarySegment>,
    /// "bias" của thư viện này, thường là nơi nó được tải vào bộ nhớ.
    /// Giá trị này được thêm vào địa chỉ đã nêu của mỗi phân đoạn để lấy địa chỉ bộ nhớ ảo thực mà phân đoạn đó được tải vào.
    /// Ngoài ra, độ lệch này được trừ khỏi các địa chỉ bộ nhớ ảo thực để lập chỉ mục vào debuginfo và bảng biểu tượng.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Địa chỉ đã nêu của phân đoạn này trong tệp đối tượng.
    /// Đây thực sự không phải là nơi phân đoạn được tải, mà là địa chỉ này cộng với `bias` của thư viện chứa nó là nơi để tìm nó.
    ///
    stated_virtual_memory_address: usize,
    /// Kích thước của phân đoạn ths trong bộ nhớ.
    len: usize,
}

// không an toàn vì điều này bắt buộc phải được đồng bộ hóa bên ngoài
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // không an toàn vì điều này bắt buộc phải được đồng bộ hóa bên ngoài
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Một bộ đệm LRU rất nhỏ, rất đơn giản để gỡ lỗi ánh xạ thông tin.
        //
        // Tỷ lệ truy cập phải rất cao, vì ngăn xếp điển hình không giao nhau giữa nhiều thư viện được chia sẻ.
        //
        // Cấu trúc `addr2line::Context` khá tốn kém để tạo ra.
        // Chi phí của nó dự kiến sẽ được khấu hao bởi các truy vấn `locate` tiếp theo, giúp tận dụng các cấu trúc được xây dựng khi xây dựng `addr2line: : Context`s để có được tốc độ tốt.
        //
        // Nếu chúng tôi không có bộ nhớ cache này, sự khấu hao đó sẽ không bao giờ xảy ra và các dấu hiệu tồn đọng tượng trưng sẽ là ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Đầu tiên, hãy kiểm tra xem `lib` này có bất kỳ phân đoạn nào chứa `addr` (xử lý việc di dời) hay không.Nếu kiểm tra này vượt qua thì chúng tôi có thể tiếp tục bên dưới và thực sự dịch địa chỉ.
                //
                // Lưu ý rằng chúng tôi đang sử dụng `wrapping_add` ở đây để tránh kiểm tra tràn.Nó đã được thấy trong tự nhiên rằng tính toán thiên vị SVMA + tràn.
                // Điều đó có vẻ hơi kỳ lạ nhưng chúng ta không thể làm gì nhiều ngoài việc bỏ qua những phân đoạn đó vì chúng có khả năng hướng vào không gian.
                //
                // Điều này ban đầu xuất hiện trong rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Bây giờ chúng ta biết `lib` chứa `addr`, chúng ta có thể bù trừ với độ lệch để tìm địa chỉ bộ nhớ virutal đã nêu.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Bất biến: sau khi điều kiện này hoàn thành mà không trở lại sớm
        // từ một lỗi, mục nhập bộ nhớ cache cho đường dẫn này ở chỉ mục 0.

        if let Some(idx) = idx {
            // Khi ánh xạ đã có trong bộ nhớ cache, hãy chuyển nó lên phía trước.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Khi ánh xạ không có trong bộ đệm, hãy tạo một ánh xạ mới, chèn nó vào mặt trước của bộ đệm và loại bỏ mục nhập bộ đệm cũ nhất nếu cần.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // không rò rỉ thời gian tồn tại của `'static`, hãy đảm bảo rằng nó chỉ dành cho chính chúng ta
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Kéo dài thời gian tồn tại của `sym` thành `'static` vì chúng tôi rất tiếc phải ở đây, nhưng nó sẽ không bao giờ được sử dụng như một tài liệu tham khảo, do đó, không có tham chiếu nào đến nó nên được duy trì ngoài khung này.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Cuối cùng, nhận ánh xạ đã lưu trong bộ nhớ cache hoặc tạo ánh xạ mới cho tệp này và đánh giá thông tin DWARF để tìm file/line/name cho địa chỉ này.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Chúng tôi có thể xác định vị trí thông tin khung cho biểu tượng này và khung của `addr2line` bên trong có tất cả các chi tiết phức tạp.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Không thể tìm thấy thông tin gỡ lỗi, nhưng chúng tôi đã tìm thấy thông tin đó trong bảng ký hiệu của tệp thực thi elf.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}