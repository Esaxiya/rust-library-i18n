//! Chiến lược biểu tượng bằng cách sử dụng mã phân tích cú pháp DWARF trong libbacktrace.
//!
//! Thư viện libbacktrace C, thường được phân phối với gcc, không chỉ hỗ trợ tạo backtrace (mà chúng tôi không thực sự sử dụng) mà còn tượng trưng cho backtrace và xử lý thông tin gỡ lỗi ngắn về những thứ như khung nội tuyến và những thứ khác.
//!
//!
//! Điều này tương đối phức tạp do có nhiều mối quan tâm khác nhau ở đây, nhưng ý tưởng cơ bản là:
//!
//! * Đầu tiên chúng tôi gọi là `backtrace_syminfo`.Điều này lấy thông tin ký hiệu từ bảng ký hiệu động nếu chúng ta có thể.
//! * Tiếp theo chúng tôi gọi là `backtrace_pcinfo`.Điều này sẽ phân tích cú pháp các bảng debuginfo nếu chúng có sẵn và cho phép chúng tôi khôi phục thông tin về khung nội tuyến, tên tệp, số dòng, v.v.
//!
//! Có rất nhiều thủ thuật về việc đưa các bảng lùn vào libbacktrace, nhưng hy vọng rằng đó không phải là ngày tận thế và đủ rõ ràng khi đọc phần dưới đây.
//!
//! Đây là chiến lược biểu tượng mặc định cho các nền tảng không phải MSVC và không phải OSX.Trong libstd mặc dù đây là chiến lược mặc định cho OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Nếu có thể, hãy thích tên `function` đến từ debuginfo và thường có thể chính xác hơn cho các khung nội tuyến chẳng hạn.
                // Nếu điều đó không có mặt, hãy quay lại tên bảng ký hiệu được chỉ định trong `symname`.
                //
                // Lưu ý rằng đôi khi `function` có thể hơi kém chính xác, ví dụ như được liệt kê là `try<i32,closure>` thay vì `std::panicking::try::do_call`.
                //
                // Không thực sự rõ ràng tại sao, nhưng nhìn chung tên `function` có vẻ chính xác hơn.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // không làm gì cho bây giờ
}

/// Loại con trỏ `data` được chuyển vào `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Sau khi gọi lại này được gọi từ `backtrace_syminfo` khi chúng tôi bắt đầu giải quyết, chúng tôi sẽ tiếp tục gọi `backtrace_pcinfo`.
    // Chức năng `backtrace_pcinfo` sẽ tham khảo thông tin gỡ lỗi và cố gắng thực hiện những việc như khôi phục thông tin file/line cũng như các khung nội tuyến.
    // Xin lưu ý rằng `backtrace_pcinfo` có thể bị lỗi hoặc không thực hiện được nhiều nếu không có thông tin gỡ lỗi, vì vậy nếu điều đó xảy ra, chúng tôi chắc chắn sẽ gọi lệnh gọi lại với ít nhất một biểu tượng từ `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Loại con trỏ `data` được chuyển vào `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// API libbacktrace hỗ trợ tạo trạng thái, nhưng không hỗ trợ hủy trạng thái.
// Cá nhân tôi coi điều này có nghĩa là một trạng thái được tạo ra và sau đó tồn tại mãi mãi.
//
// Tôi rất thích đăng ký trình xử lý at_exit() để xóa trạng thái này, nhưng libbacktrace không cung cấp cách nào để làm như vậy.
//
// Với những ràng buộc này, hàm này có một trạng thái được lưu trong bộ đệm tĩnh được tính vào lần đầu tiên nó được yêu cầu.
//
// Hãy nhớ rằng backtracing tất cả diễn ra tuần tự (một khóa toàn cầu).
//
// Lưu ý rằng việc thiếu đồng bộ hóa ở đây là do yêu cầu `resolve` phải được đồng bộ hóa bên ngoài.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Đừng sử dụng khả năng an toàn luồng của libbacktrace vì chúng tôi luôn gọi nó theo kiểu đồng bộ.
        //
        0,
        error_cb,
        ptr::null_mut(), // không có thêm dữ liệu
    );

    return STATE;

    // Lưu ý rằng để libbacktrace hoạt động, nó cần tìm thông tin gỡ lỗi DWARF cho tệp thực thi hiện tại.Nó thường thực hiện điều đó thông qua một số cơ chế bao gồm, nhưng không giới hạn ở:
    //
    // * /proc/self/exe trên các nền tảng được hỗ trợ
    // * Tên tệp được chuyển rõ ràng khi tạo trạng thái
    //
    // Thư viện libbacktrace là một bộ mã C lớn.Điều này đương nhiên có nghĩa là nó có lỗ hổng an toàn bộ nhớ, đặc biệt là khi xử lý debuginfo không đúng định dạng.
    // Libstd đã gặp phải rất nhiều điều này trong lịch sử.
    //
    // Nếu /proc/self/exe được sử dụng thì chúng tôi thường có thể bỏ qua những điều này vì chúng tôi giả định rằng libbacktrace là "mostly correct" và nếu không thì không làm những điều kỳ lạ với thông tin gỡ lỗi lùn "attempted to be correct".
    //
    //
    // Tuy nhiên, nếu chúng tôi chuyển vào một tên tệp, thì có thể trên một số nền tảng (như BSD) nơi mà một tác nhân độc hại có thể gây ra một tệp tùy ý được đặt tại vị trí đó.
    // Điều này có nghĩa là nếu chúng tôi nói với libbacktrace về một tên tệp, nó có thể đang sử dụng một tệp tùy ý, có thể gây ra giá trị mặc định.
    // Nếu chúng tôi không nói với libbacktrace bất cứ điều gì thì nó sẽ không làm được gì trên các nền tảng không hỗ trợ đường dẫn như /proc/self/exe!
    //
    // Với tất cả những gì chúng tôi cố gắng hết sức có thể để *không* chuyển vào tên tệp, nhưng chúng tôi phải sử dụng các nền tảng không hỗ trợ /proc/self/exe.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Lưu ý rằng lý tưởng nhất là chúng tôi nên sử dụng `std::env::current_exe`, nhưng chúng tôi không thể yêu cầu `std` ở đây.
            //
            // Sử dụng `_NSGetExecutablePath` để tải đường dẫn thực thi hiện tại vào một vùng tĩnh (nếu nó quá nhỏ thì chỉ cần bỏ).
            //
            //
            // Lưu ý rằng chúng tôi thực sự tin tưởng libbacktrace ở đây sẽ không chết trên các tệp thực thi bị hỏng, nhưng nó chắc chắn có ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows có chế độ mở tệp mà sau khi mở tệp, tệp đó không thể bị xóa.
            // Nói chung, đó là những gì chúng tôi muốn ở đây vì chúng tôi muốn đảm bảo rằng tệp thực thi của chúng tôi không thay đổi so với chúng tôi sau khi chúng tôi chuyển nó cho libbacktrace, hy vọng giảm thiểu khả năng truyền dữ liệu tùy ý vào libbacktrace (có thể bị xử lý sai).
            //
            //
            // Cho rằng chúng tôi thực hiện một chút nhảy múa ở đây để cố gắng có được một loại khóa hình ảnh của chính chúng tôi:
            //
            // * Nhận một xử lý cho quy trình hiện tại, tải tên tệp của nó.
            // * Mở tệp với tên tệp đó bằng các cờ phù hợp.
            // * Tải lại tên tệp của quy trình hiện tại, đảm bảo rằng nó giống nhau
            //
            // Nếu tất cả vượt qua, về lý thuyết, chúng tôi đã thực sự mở tệp quy trình của mình và chúng tôi đảm bảo rằng nó sẽ không thay đổi.FWIW rất nhiều điều này được sao chép từ libstd trong lịch sử, vì vậy đây là cách giải thích tốt nhất của tôi về những gì đang xảy ra.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Nó nằm trong bộ nhớ tĩnh nên chúng tôi có thể trả lại nó ..
                static mut BUF: [i8; N] = [0; N];
                // ... và điều này tồn tại trên ngăn xếp vì nó tạm thời
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // cố ý làm rò rỉ `handle` ở đây vì việc mở đó sẽ bảo toàn khóa của chúng tôi trên tên tệp này.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Chúng tôi muốn trả về một lát cắt được kết thúc bằng nul, vì vậy nếu mọi thứ đã được điền vào và nó bằng tổng độ dài thì tương đương với thất bại.
                //
                //
                // Nếu không, khi trả về thành công, hãy chắc chắn rằng byte nul được bao gồm trong lát.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // lỗi backtrace hiện được quét dưới tấm thảm
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Gọi API `backtrace_syminfo` mà (từ việc đọc mã) sẽ gọi `syminfo_cb` chính xác một lần (hoặc có thể không thành công với lỗi).
    // Sau đó, chúng tôi xử lý nhiều hơn trong `syminfo_cb`.
    //
    // Lưu ý rằng chúng tôi làm điều này vì `syminfo` sẽ tham khảo bảng ký hiệu, tìm tên ký hiệu ngay cả khi không có thông tin gỡ lỗi trong tệp nhị phân.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}