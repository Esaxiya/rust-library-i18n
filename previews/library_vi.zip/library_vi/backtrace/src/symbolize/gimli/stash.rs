// chỉ được sử dụng trên Linux ngay bây giờ, vì vậy hãy cho phép mã chết ở nơi khác
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Một trình phân bổ đấu trường đơn giản cho bộ đệm byte.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Phân bổ một bộ đệm có kích thước được chỉ định và trả về một tham chiếu có thể thay đổi cho nó.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // AN TOÀN: đây là hàm duy nhất từng tạo một hàm có thể thay đổi
        // tham chiếu đến `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // AN TOÀN: chúng tôi không bao giờ xóa các phần tử khỏi `self.buffers`, vì vậy một tài liệu tham khảo
        // dữ liệu bên trong bất kỳ bộ đệm nào sẽ tồn tại miễn là `self`.
        &mut buffers[i]
    }
}