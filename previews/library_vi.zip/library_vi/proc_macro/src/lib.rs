//! Thư viện hỗ trợ cho các tác giả macro khi xác định macro mới.
//!
//! Thư viện này, được cung cấp bởi phân phối chuẩn, cung cấp các loại được sử dụng trong giao diện của các định nghĩa macro được xác định theo thủ tục, chẳng hạn như macro giống hàm `#[proc_macro]`, thuộc tính macro `#[proc_macro_attribute]` và thuộc tính dẫn xuất tùy chỉnh '#[proc_macro_derive] `.
//!
//!
//! Xem [the book] để biết thêm.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Xác định xem proc_macro có được truy cập vào chương trình hiện đang chạy hay không.
///
/// Proc_macro crate chỉ được thiết kế để sử dụng bên trong việc triển khai các macro thủ tục.Tất cả các hàm trong crate panic này nếu được gọi từ bên ngoài macro thủ tục, chẳng hạn như từ tập lệnh xây dựng hoặc kiểm tra đơn vị hoặc mã nhị phân Rust thông thường.
///
/// Với việc xem xét các thư viện Rust được thiết kế để hỗ trợ cả trường hợp sử dụng macro và không macro, `proc_macro::is_available()` cung cấp một cách không gây hoảng sợ để phát hiện xem cơ sở hạ tầng cần thiết để sử dụng API của proc_macro hiện có sẵn hay không.
/// Trả về true nếu được gọi từ bên trong macro thủ tục, false nếu được gọi từ bất kỳ tệp nhị phân nào khác.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Kiểu chính được cung cấp bởi crate này, đại diện cho một dòng trừu tượng của tokens, hoặc cụ thể hơn, một chuỗi các cây token.
/// Kiểu này cung cấp các giao diện để lặp qua các cây token đó và ngược lại, thu thập một số cây token vào một luồng.
///
///
/// Đây là cả đầu vào và đầu ra của các định nghĩa `#[proc_macro]`, `#[proc_macro_attribute]` và `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Lỗi trả về từ `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Trả về `TokenStream` trống không chứa cây token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Kiểm tra xem `TokenStream` này có trống không.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Cố gắng ngắt chuỗi thành tokens và phân tích cú pháp tokens đó thành luồng token.
/// Có thể không thành công vì một số lý do, ví dụ, nếu chuỗi chứa các dấu phân cách không cân bằng hoặc các ký tự không tồn tại trong ngôn ngữ.
///
/// Tất cả tokens trong luồng đã phân tích cú pháp đều nhận được khoảng cách `Span::call_site()`.
///
/// NOTE: một số lỗi có thể gây ra panics thay vì trả về `LexError`.Chúng tôi có quyền thay đổi các lỗi này thành `LexError` sau này.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, cầu nối chỉ cung cấp `to_string`, thực hiện `fmt::Display` dựa trên nó (mặt trái của mối quan hệ thông thường giữa hai).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// In luồng token dưới dạng một chuỗi được cho là có thể chuyển đổi dễ dàng trở lại cùng một luồng token (các nhịp modulo), ngoại trừ có thể là `TokenTree: : Group` có dấu phân cách `Delimiter::None` và ký tự số âm.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// In token ở dạng thuận tiện cho việc gỡ lỗi.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Tạo luồng token chứa một cây token.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Thu thập một số cây token vào một luồng duy nhất.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Hoạt động "flattening" trên các luồng token, thu thập các cây token từ nhiều luồng token thành một luồng duy nhất.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Sử dụng if/when triển khai được tối ưu hóa có thể.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Chi tiết triển khai công khai cho kiểu `TokenStream`, chẳng hạn như trình vòng lặp.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Một trình lặp trên `TokenTree` của`TokenStream`.
    /// Phép lặp là "shallow", ví dụ: trình lặp không đệ quy thành các nhóm được phân cách và trả về toàn bộ nhóm dưới dạng cây token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` chấp nhận tokens tùy ý và mở rộng thành `TokenStream` mô tả đầu vào.
/// Ví dụ: `quote!(a + b)` sẽ tạo ra một biểu thức, khi được đánh giá, sẽ xây dựng `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Việc giải mã được thực hiện với `$` và hoạt động bằng cách lấy một danh tính tiếp theo duy nhất làm thuật ngữ chưa được trích dẫn.
/// Để báo giá chính `$`, hãy sử dụng `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Một vùng mã nguồn, cùng với thông tin mở rộng macro.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Tạo `Diagnostic` mới với `message` đã cho ở khoảng `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Một khoảng giải quyết tại trang web định nghĩa macro.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Khoảng thời gian gọi macro thủ tục hiện tại.
    /// Các số nhận dạng được tạo với khoảng thời gian này sẽ được phân giải như thể chúng được viết trực tiếp tại vị trí cuộc gọi macro (vệ sinh trang web cuộc gọi) và mã khác tại địa điểm gọi macro cũng sẽ có thể tham chiếu đến chúng.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Một nhịp đại diện cho vệ sinh `macro_rules` và đôi khi giải quyết tại trang web định nghĩa macro (biến cục bộ, nhãn, `$crate`) và đôi khi tại trang web gọi macro (mọi thứ khác).
    ///
    /// Vị trí nhịp được lấy từ trang web cuộc gọi.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Tệp nguồn ban đầu mà span này trỏ đến.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` cho tokens trong bản mở rộng macro trước đó mà từ đó `self` được tạo ra, nếu có.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Khoảng cho mã nguồn gốc mà `self` được tạo từ đó.
    /// Nếu `Span` này không được tạo từ các mở rộng macro khác thì giá trị trả về giống như `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Lấy line/column bắt đầu trong tệp nguồn cho khoảng thời gian này.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Nhận kết thúc line/column trong tệp nguồn cho khoảng thời gian này.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Tạo một khoảng mới bao gồm `self` và `other`.
    ///
    /// Trả về `None` nếu `self` và `other` từ các tệp khác nhau.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Tạo một khoảng mới với thông tin line/column giống như `self` nhưng giải quyết các ký hiệu như thể ở `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Tạo một khoảng mới với hành vi phân giải cùng tên như `self` nhưng với thông tin line/column của `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// So sánh với các nhịp để xem chúng có bằng nhau không.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Trả về văn bản nguồn sau một khoảng.
    /// Điều này bảo tồn mã nguồn ban đầu, bao gồm cả khoảng trắng và nhận xét.
    /// Nó chỉ trả về một kết quả nếu khoảng thời gian tương ứng với mã nguồn thực.
    ///
    /// Note: Kết quả quan sát được của một macro chỉ nên dựa vào tokens chứ không dựa vào văn bản nguồn này.
    ///
    /// Kết quả của chức năng này là nỗ lực tốt nhất chỉ được sử dụng cho chẩn đoán.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// In một khoảng thời gian trong một biểu mẫu thuận tiện cho việc gỡ lỗi.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Một cặp cột dòng đại diện cho phần đầu hoặc phần cuối của `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Dòng 1 được lập chỉ mục trong tệp nguồn mà khoảng thời gian bắt đầu hoặc kết thúc (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Cột được lập chỉ mục 0 (trong các ký tự UTF-8) trong tệp nguồn có khoảng bắt đầu hoặc kết thúc (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Tệp nguồn của `Span` nhất định.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Lấy đường dẫn đến tệp nguồn này.
    ///
    /// ### Note
    /// Nếu khoảng mã được liên kết với `SourceFile` này được tạo bởi một macro bên ngoài, thì macro này, đây có thể không phải là một đường dẫn thực tế trên hệ thống tệp.
    /// Sử dụng [`is_real`] để kiểm tra.
    ///
    /// Cũng lưu ý rằng ngay cả khi `is_real` trả về `true`, nếu `--remap-path-prefix` được chuyển trên dòng lệnh, đường dẫn như đã cho có thể không thực sự hợp lệ.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Trả về `true` nếu tệp nguồn này là tệp nguồn thực và không được tạo bởi sự mở rộng của macro bên ngoài.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Đây là một cuộc tấn công cho đến khi các nhịp xen kẽ được triển khai và chúng tôi có thể có các tệp nguồn thực cho các nhịp được tạo trong macro bên ngoài.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Một token đơn lẻ hoặc một chuỗi phân cách của cây token (ví dụ: `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Luồng token được bao quanh bởi dấu phân cách trong ngoặc.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Một mã định danh.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Một ký tự dấu câu (`+`, `,`, `$`, v.v.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Một ký tự chữ (`'a'`), chuỗi (`"hello"`), số (`2.3`), v.v.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Trả về khoảng của cây này, ủy quyền cho phương thức `span` của token được chứa hoặc một luồng được phân tách.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Định cấu hình khoảng cách cho *chỉ token* này.
    ///
    /// Lưu ý rằng nếu token này là `Group` thì phương pháp này sẽ không định cấu hình khoảng của từng tokens bên trong, điều này sẽ chỉ ủy quyền cho phương thức `set_span` của từng biến thể.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// In cây token ở dạng thuận tiện cho việc gỡ lỗi.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Mỗi trong số này có tên trong kiểu cấu trúc trong gỡ lỗi dẫn xuất, vì vậy đừng bận tâm với một lớp bổ sung của hướng dẫn
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, cầu nối chỉ cung cấp `to_string`, thực hiện `fmt::Display` dựa trên nó (mặt trái của mối quan hệ thông thường giữa hai).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// In cây token dưới dạng một chuỗi được cho là có thể chuyển đổi dễ dàng trở lại cùng một cây token (các nhịp modulo), ngoại trừ có thể là `TokenTree: : Group` có dấu phân cách `Delimiter::None` và ký tự số âm.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Luồng token được phân tách.
///
/// Bên trong một `Group` chứa một `TokenStream` được bao quanh bởi các dấu phân cách.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Mô tả cách phân cách một chuỗi các cây token.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Một dấu phân cách ngầm, chẳng hạn, có thể xuất hiện xung quanh tokens đến từ "macro variable" `$var`.
    /// Điều quan trọng là giữ nguyên các ưu tiên của toán tử trong các trường hợp như `$var * 3` trong đó `$var` là `1 + 2`.
    /// Các dấu phân cách ngầm định có thể không tồn tại trong vòng một luồng token thông qua một chuỗi.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Tạo `Group` mới với dấu phân cách đã cho và luồng token.
    ///
    /// Hàm tạo này sẽ đặt khoảng cách cho nhóm này thành `Span::call_site()`.
    /// Để thay đổi nhịp, bạn có thể sử dụng phương pháp `set_span` bên dưới.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Trả về dấu phân cách của `Group` này
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Trả về `TokenStream` của tokens được phân tách trong `Group` này.
    ///
    /// Lưu ý rằng luồng token được trả về không bao gồm dấu phân cách được trả về ở trên.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Trả về khoảng cho các dấu phân cách của luồng token này, kéo dài toàn bộ `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Trả về khoảng cách trỏ đến dấu phân cách mở của nhóm này.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Trả về khoảng cách trỏ đến dấu phân cách đóng của nhóm này.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Định cấu hình khoảng cách cho dấu phân cách của `Nhóm` này, nhưng không phải tokens nội bộ của nó.
    ///
    /// Phương thức này sẽ **không** đặt khoảng của tất cả tokens bên trong được bao quanh bởi nhóm này, mà đúng hơn nó sẽ chỉ đặt khoảng của dấu phân tách tokens ở cấp của `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, cầu nối chỉ cung cấp `to_string`, thực hiện `fmt::Display` dựa trên nó (mặt trái của mối quan hệ thông thường giữa hai).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// In nhóm dưới dạng chuỗi có thể chuyển đổi dễ dàng trở lại cùng một nhóm (các nhịp modulo), ngoại trừ có thể là `TokenTree: : Group` có dấu phân cách `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` là một ký tự dấu câu đơn như `+`, `-` hoặc `#`.
///
/// Các toán tử nhiều ký tự như `+=` được biểu diễn dưới dạng hai trường hợp của `Punct` với các dạng khác nhau của `Spacing` được trả về.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Cho dù một `Punct` được theo sau ngay bởi một `Punct` khác hoặc theo sau bởi một token khác hoặc khoảng trắng.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// ví dụ: `+` là `Alone` trong `+ =`, `+ident` hoặc `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// ví dụ: `+` là `Joint` trong `+=` hoặc `'#`.
    /// Ngoài ra, trích dẫn đơn `'` có thể kết hợp với các số nhận dạng để tạo thành các vòng đời `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Tạo `Punct` mới từ ký tự và khoảng cách đã cho.
    /// Đối số `ch` phải là một ký tự dấu câu hợp lệ được ngôn ngữ cho phép, nếu không hàm sẽ panic.
    ///
    /// `Punct` trả về sẽ có khoảng thời gian mặc định là `Span::call_site()` có thể được định cấu hình thêm bằng phương pháp `set_span` bên dưới.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Trả về giá trị của ký tự dấu câu này là `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Trả về khoảng cách của ký tự dấu câu này, cho biết liệu nó có ngay sau đó bởi một `Punct` khác trong luồng token hay không, vì vậy chúng có thể được kết hợp thành một toán tử nhiều ký tự (`Joint`) hoặc theo sau bởi một số token khác hoặc khoảng trắng (`Alone`) để toán tử chắc chắn có đã kết thúc.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Trả về khoảng cho ký tự dấu câu này.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Định cấu hình khoảng cách cho ký tự dấu câu này.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, cầu nối chỉ cung cấp `to_string`, thực hiện `fmt::Display` dựa trên nó (mặt trái của mối quan hệ thông thường giữa hai).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// In ký tự dấu câu dưới dạng một chuỗi có thể chuyển đổi hoàn toàn trở lại thành cùng một ký tự.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Số nhận dạng (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Tạo `Ident` mới với `string` đã cho cũng như `span` được chỉ định.
    /// Đối số `string` phải là số nhận dạng hợp lệ được ngôn ngữ cho phép (bao gồm từ khóa, ví dụ: `self` hoặc `fn`).Nếu không, hàm sẽ panic.
    ///
    /// Lưu ý rằng `span`, hiện đang ở rustc, định cấu hình thông tin vệ sinh cho số nhận dạng này.
    ///
    /// Kể từ thời điểm này, `Span::call_site()` chọn tham gia vệ sinh "call-site" một cách rõ ràng có nghĩa là các số nhận dạng được tạo với khoảng thời gian này sẽ được giải quyết như thể chúng được viết trực tiếp tại vị trí của lệnh gọi macro và mã khác tại trang web gọi macro sẽ có thể tham chiếu đến họ cũng vậy.
    ///
    ///
    /// Các nhịp sau đó như `Span::def_site()` sẽ cho phép chọn tham gia vệ sinh "definition-site" nghĩa là các số nhận dạng được tạo bằng khoảng này sẽ được giải quyết tại vị trí của định nghĩa macro và mã khác tại trang web gọi macro sẽ không thể tham chiếu đến chúng.
    ///
    /// Do tầm quan trọng hiện tại của việc vệ sinh, trình tạo này, không giống như các tokens khác, yêu cầu `Span` phải được chỉ định khi xây dựng.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Tương tự như `Ident::new`, nhưng tạo một số nhận dạng thô (`r#ident`).
    /// Đối số `string` là số nhận dạng hợp lệ được ngôn ngữ cho phép (bao gồm từ khóa, ví dụ: `fn`).
    /// Các từ khóa có thể sử dụng được trong các phân đoạn đường dẫn (ví dụ:
    /// `self`, `super`) không được hỗ trợ và sẽ gây ra panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Trả về khoảng của `Ident` này, bao gồm toàn bộ chuỗi được trả về bởi [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Định cấu hình khoảng thời gian của `Ident` này, có thể thay đổi bối cảnh vệ sinh của nó.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, cầu nối chỉ cung cấp `to_string`, thực hiện `fmt::Display` dựa trên nó (mặt trái của mối quan hệ thông thường giữa hai).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// In số nhận dạng dưới dạng một chuỗi có thể chuyển đổi dễ dàng trở lại thành cùng một số nhận dạng.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Một chuỗi chữ (`"hello"`), chuỗi byte (`b"hello"`), ký tự (`'a'`), ký tự byte (`b'a'`), một số nguyên hoặc dấu phẩy động có hoặc không có hậu tố (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Các ký tự Boolean như `true` và `false` không thuộc về đây, chúng là `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Tạo một số nguyên có hậu tố mới theo giá trị được chỉ định.
        ///
        /// Hàm này sẽ tạo ra một số nguyên như `1u32` trong đó giá trị số nguyên được chỉ định là phần đầu tiên của token và tích phân cũng có hậu tố ở cuối.
        /// Chữ viết được tạo từ số âm có thể không tồn tại trong các chuyến đi vòng qua `TokenStream` hoặc chuỗi và có thể bị chia thành hai tokens (`-` và chữ dương).
        ///
        ///
        /// Các chữ được tạo thông qua phương pháp này có khoảng `Span::call_site()` theo mặc định, có thể được định cấu hình bằng phương pháp `set_span` bên dưới.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Tạo một số nguyên mới theo nghĩa đen với giá trị được chỉ định.
        ///
        /// Hàm này sẽ tạo một số nguyên như `1` trong đó giá trị số nguyên được chỉ định là phần đầu tiên của token.
        /// Không có hậu tố nào được chỉ định trên token này, có nghĩa là các lệnh gọi như `Literal::i8_unsuffixed(1)` tương đương với `Literal::u32_unsuffixed(1)`.
        /// Chữ viết được tạo từ các số âm có thể không tồn tại khi chạy qua `TokenStream` hoặc chuỗi và có thể bị chia thành hai tokens (`-` và chữ dương).
        ///
        ///
        /// Các chữ được tạo thông qua phương pháp này có khoảng `Span::call_site()` theo mặc định, có thể được định cấu hình bằng phương pháp `set_span` bên dưới.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Tạo một ký tự dấu phẩy động không cố định mới.
    ///
    /// Hàm tạo này tương tự như những hàm như `Literal::i8_unsuffixed` trong đó giá trị của float được phát trực tiếp vào token nhưng không có hậu tố nào được sử dụng, vì vậy nó có thể được suy ra là `f64` sau này trong trình biên dịch.
    ///
    /// Chữ viết được tạo từ các số âm có thể không tồn tại khi chạy qua `TokenStream` hoặc chuỗi và có thể bị chia thành hai tokens (`-` và chữ dương).
    ///
    /// # Panics
    ///
    /// Hàm này yêu cầu float được chỉ định là hữu hạn, ví dụ nếu nó là vô cùng hoặc NaN thì hàm này sẽ panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Tạo một ký tự dấu phẩy động có hậu tố mới.
    ///
    /// Hàm tạo này sẽ tạo ra một ký tự giống như `1.0f32` trong đó giá trị được chỉ định là phần trước của token và `f32` là hậu tố của token.
    /// token này sẽ luôn được suy ra là một `f32` trong trình biên dịch.
    /// Chữ viết được tạo từ các số âm có thể không tồn tại khi chạy qua `TokenStream` hoặc chuỗi và có thể bị chia thành hai tokens (`-` và chữ dương).
    ///
    ///
    /// # Panics
    ///
    /// Hàm này yêu cầu float được chỉ định là hữu hạn, ví dụ nếu nó là vô cùng hoặc NaN thì hàm này sẽ panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Tạo một ký tự dấu phẩy động không cố định mới.
    ///
    /// Hàm tạo này tương tự như những hàm như `Literal::i8_unsuffixed` trong đó giá trị của float được phát trực tiếp vào token nhưng không có hậu tố nào được sử dụng, vì vậy nó có thể được suy ra là `f64` sau này trong trình biên dịch.
    ///
    /// Chữ viết được tạo từ các số âm có thể không tồn tại khi chạy qua `TokenStream` hoặc chuỗi và có thể bị chia thành hai tokens (`-` và chữ dương).
    ///
    /// # Panics
    ///
    /// Hàm này yêu cầu float được chỉ định là hữu hạn, ví dụ nếu nó là vô cùng hoặc NaN thì hàm này sẽ panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Tạo một ký tự dấu phẩy động có hậu tố mới.
    ///
    /// Hàm tạo này sẽ tạo ra một ký tự giống như `1.0f64` trong đó giá trị được chỉ định là phần trước của token và `f64` là hậu tố của token.
    /// token này sẽ luôn được suy ra là một `f64` trong trình biên dịch.
    /// Chữ viết được tạo từ các số âm có thể không tồn tại khi chạy qua `TokenStream` hoặc chuỗi và có thể bị chia thành hai tokens (`-` và chữ dương).
    ///
    ///
    /// # Panics
    ///
    /// Hàm này yêu cầu float được chỉ định là hữu hạn, ví dụ nếu nó là vô cùng hoặc NaN thì hàm này sẽ panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Chuỗi chữ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Chữ ký tự.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Chuỗi byte theo nghĩa đen.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Trả về khoảng bao gồm chữ này.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Định cấu hình khoảng được liên kết cho nghĩa đen này.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Trả về `Span` là tập con của `self.span()` chỉ chứa các byte nguồn trong phạm vi `range`.
    /// Trả về `None` nếu khoảng thời gian sẽ được cắt bớt nằm ngoài giới hạn của `self`.
    ///
    // FIXME(SergioBenitez): kiểm tra xem phạm vi byte bắt đầu và kết thúc ở ranh giới UTF-8 của nguồn.
    // nếu không, có khả năng panic sẽ xảy ra ở nơi khác khi văn bản nguồn được in.
    // FIXME(SergioBenitez): không có cách nào để người dùng biết `self.span()` thực sự ánh xạ tới cái gì, vì vậy phương pháp này hiện chỉ có thể được gọi là mù quáng.
    // Ví dụ, `to_string()` cho ký tự 'c' trả về "'\u{63}'";không có cách nào để người dùng biết văn bản nguồn là 'c' hay là '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) một cái gì đó tương tự như `Option::cloned`, nhưng đối với `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, cầu nối chỉ cung cấp `to_string`, thực hiện `fmt::Display` dựa trên nó (mặt trái của mối quan hệ thông thường giữa hai).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// In ký tự dưới dạng một chuỗi có thể chuyển đổi dễ dàng trở lại thành cùng một ký tự (ngoại trừ khả năng làm tròn đối với các ký tự dấu phẩy động).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Theo dõi quyền truy cập vào các biến môi trường.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Truy xuất một biến môi trường và thêm nó để xây dựng thông tin phụ thuộc.
    /// Hệ thống xây dựng thực thi trình biên dịch sẽ biết rằng biến đã được truy cập trong quá trình biên dịch và sẽ có thể chạy lại quá trình xây dựng khi giá trị của biến đó thay đổi.
    ///
    /// Bên cạnh việc theo dõi phụ thuộc, hàm này phải tương đương với `env::var` từ thư viện chuẩn, ngoại trừ đối số phải là UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}