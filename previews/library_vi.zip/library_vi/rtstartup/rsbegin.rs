// rsbegin.o và rsend.o được gọi là "compiler runtime startup objects".
// Chúng chứa mã cần thiết để khởi tạo chính xác thời gian chạy trình biên dịch.
//
// Khi một hình ảnh thực thi hoặc dylib được liên kết, tất cả mã người dùng và thư viện đều là "sandwiched" giữa hai tệp đối tượng này, vì vậy mã hoặc dữ liệu từ rsbegin.o trở thành phần đầu tiên trong các phần tương ứng của hình ảnh, trong khi mã và dữ liệu từ rsend.o trở thành phần cuối cùng.
// Hiệu ứng này có thể được sử dụng để đặt các biểu tượng ở đầu hoặc cuối phần, cũng như để chèn bất kỳ đầu trang hoặc chân trang bắt buộc nào.
//
// Lưu ý rằng điểm vào mô-đun thực tế nằm trong đối tượng khởi động thời gian chạy C (thường được gọi là `crtX.o`), đối tượng này sau đó gọi ra lệnh gọi lại khởi tạo của các thành phần thời gian chạy khác (được đăng ký qua một phần hình ảnh đặc biệt khác).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Đánh dấu phần bắt đầu của phần thông tin thư giãn khung ngăn xếp
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Cào không gian để lưu trữ sách bên trong của người mở.
    // Điều này được định nghĩa là `struct object` trong $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Mở thông tin về các thói quen registration/deregistration.
    // Xem tài liệu của libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // đăng ký thông tin thư giãn khi khởi động mô-đun
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // hủy đăng ký khi tắt máy
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Đăng ký định kỳ init/uninit dành riêng cho MinGW
    pub mod mingw_init {
        // Các đối tượng khởi động của MinGW (crt0.o/dllcrt0.o) sẽ gọi các hàm tạo toàn cục trong phần .ctors và .dtors khi khởi động và thoát.
        // Trong trường hợp DLL, điều này được thực hiện khi DLL được tải và dỡ tải.
        //
        // Trình liên kết sẽ sắp xếp các phần, điều này đảm bảo rằng các lệnh gọi lại của chúng tôi nằm ở cuối danh sách.
        // Vì các hàm tạo được chạy theo thứ tự ngược lại, điều này đảm bảo rằng các lệnh gọi lại của chúng ta là các lệnh gọi đầu tiên và cuối cùng được thực thi.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: Lệnh gọi khởi tạo C
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: Các lệnh gọi lại kết thúc C
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}