//! Các tiện ích để định dạng và in `Chuỗi`.
//!
//! Mô-đun này chứa hỗ trợ thời gian chạy cho phần mở rộng cú pháp [`format!`].
//! Macro này được thực hiện trong trình biên dịch để phát ra các lệnh gọi đến mô-đun này nhằm định dạng các đối số trong thời gian chạy thành chuỗi.
//!
//! # Usage
//!
//! Macro [`format!`] được thiết kế để quen thuộc với những người đến từ các chức năng `printf`/`fprintf` của C hoặc chức năng `str.format` của Python.
//!
//! Một số ví dụ về phần mở rộng [`format!`] là:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" với các số không ở đầu
//! ```
//!
//! Từ những điều này, bạn có thể thấy rằng đối số đầu tiên là một chuỗi định dạng.Nó được yêu cầu bởi trình biên dịch đối với điều này là một chuỗi ký tự;nó không thể là một biến được chuyển vào (để thực hiện kiểm tra tính hợp lệ).
//! Sau đó, trình biên dịch sẽ phân tích cú pháp chuỗi định dạng và xác định xem danh sách các đối số được cung cấp có phù hợp để chuyển đến chuỗi định dạng này hay không.
//!
//! Để chuyển đổi một giá trị thành một chuỗi, hãy sử dụng phương thức [`to_string`].Điều này sẽ sử dụng định dạng [`Display`] trait.
//!
//! ## Tham số vị trí
//!
//! Mỗi đối số định dạng được phép chỉ định đối số giá trị nào mà đối số đó đang tham chiếu và nếu bị bỏ qua, nó được giả định là "the next argument".
//! Ví dụ: chuỗi định dạng `{} {} {}` sẽ có ba tham số và chúng sẽ được định dạng theo thứ tự như đã cho.
//! Tuy nhiên, chuỗi định dạng `{2} {1} {0}` sẽ định dạng các đối số theo thứ tự ngược lại.
//!
//! Mọi thứ có thể trở nên phức tạp một chút khi bạn bắt đầu trộn lẫn hai loại chỉ định vị trí.Thông số "next argument" có thể được coi như một trình lặp trên đối số.
//! Mỗi khi nhìn thấy thông số "next argument", trình vòng lặp sẽ tăng lên.Điều này dẫn đến hành vi như thế này:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Trình lặp nội bộ trên đối số chưa được nâng cao vào thời điểm `{}` đầu tiên được nhìn thấy, vì vậy nó sẽ in đối số đầu tiên.Sau đó, khi đạt đến `{}` thứ hai, trình lặp đã chuyển tiếp sang đối số thứ hai.
//! Về cơ bản, các tham số đặt tên rõ ràng cho đối số của chúng không ảnh hưởng đến các tham số không đặt tên cho một đối số dưới dạng các chỉ định vị trí.
//!
//! Một chuỗi định dạng được yêu cầu để sử dụng tất cả các đối số của nó, nếu không thì đó là lỗi thời gian biên dịch.Bạn có thể tham chiếu đến cùng một đối số nhiều lần trong chuỗi định dạng.
//!
//! ## Các thông số được đặt tên
//!
//! Bản thân Rust không có các tham số được đặt tên giống như Python cho một hàm, nhưng macro [`format!`] là một phần mở rộng cú pháp cho phép nó sử dụng các tham số được đặt tên.
//! Các tham số đã đặt tên được liệt kê ở cuối danh sách đối số và có cú pháp:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Ví dụ: tất cả các biểu thức [`format!`] sau đây đều sử dụng đối số được đặt tên:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Không hợp lệ để đặt các tham số vị trí (những tham số không có tên) sau các đối số có tên.Giống như với các tham số vị trí, không hợp lệ để cung cấp các tham số đã đặt tên mà chuỗi định dạng không sử dụng.
//!
//! # Các thông số định dạng
//!
//! Mỗi đối số đang được định dạng có thể được chuyển đổi bằng một số tham số định dạng (tương ứng với `format_spec` trong [the syntax](#syntax)). Các tham số này ảnh hưởng đến biểu diễn chuỗi của những gì đang được định dạng.
//!
//! ## Width
//!
//! ```
//! // Tất cả những bản in này "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Đây là một tham số cho "minimum width" mà định dạng sẽ sử dụng.
//! Nếu chuỗi của giá trị không lấp đầy nhiều ký tự này, thì phần đệm được chỉ định bởi fill/alignment sẽ được sử dụng để chiếm không gian cần thiết (xem bên dưới).
//!
//! Giá trị cho chiều rộng cũng có thể được cung cấp dưới dạng [`usize`] trong danh sách các tham số bằng cách thêm hậu tố `$`, cho biết rằng đối số thứ hai là [`usize`] chỉ định chiều rộng.
//!
//! Việc tham chiếu đến một đối số bằng cú pháp đô la không ảnh hưởng đến bộ đếm "next argument", vì vậy, bạn nên tham khảo các đối số theo vị trí hoặc sử dụng các đối số được đặt tên.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Ký tự điền tùy chọn và căn chỉnh được cung cấp bình thường cùng với tham số [`width`](#width).Nó phải được xác định trước `width`, ngay sau `:`.
//! Điều này chỉ ra rằng nếu giá trị được định dạng nhỏ hơn `width`, một số ký tự phụ sẽ được in xung quanh nó.
//! Điền có các biến thể sau cho các căn chỉnh khác nhau:
//!
//! * `[fill]<` - đối số được căn trái trong các cột `width`
//! * `[fill]^` - đối số được căn giữa trong các cột `width`
//! * `[fill]>` - đối số được căn phải trong các cột `width`
//!
//! [fill/alignment](#fillalignment) mặc định cho không phải số là khoảng trắng và được căn trái.Mặc định cho các định dạng số cũng là một ký tự khoảng trắng nhưng có căn chỉnh bên phải.
//! Nếu cờ `0` (xem bên dưới) được chỉ định cho các số, thì ký tự điền ngầm định là `0`.
//!
//! Lưu ý rằng một số loại có thể không triển khai căn chỉnh.Đặc biệt, nó thường không được triển khai cho `Debug` trait.
//! Một cách tốt để đảm bảo đệm được áp dụng là định dạng đầu vào của bạn, sau đó đệm chuỗi kết quả này để có được đầu ra của bạn:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Xin chào Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Đây là tất cả các cờ thay đổi hành vi của trình định dạng.
//!
//! * `+` - Điều này dành cho các loại số và chỉ ra rằng dấu hiệu phải luôn được in.Các dấu tích cực không bao giờ được in theo mặc định và dấu âm chỉ được in theo mặc định cho `Signed` trait.
//! Cờ này chỉ ra rằng phải luôn in đúng dấu (`+` hoặc `-`).
//! * `-` - Hiện tại không được sử dụng
//! * `#` - Cờ này chỉ ra rằng nên sử dụng hình thức in "alternate".Các hình thức thay thế là:
//!     * `#?` - in đẹp định dạng [`Debug`]
//!     * `#x` - đứng trước đối số bằng `0x`
//!     * `#X` - đứng trước đối số bằng `0x`
//!     * `#b` - đứng trước đối số bằng `0b`
//!     * `#o` - đứng trước đối số bằng `0o`
//! * `0` - Điều này được sử dụng để chỉ ra cho các định dạng số nguyên rằng phần đệm tới `width` phải được thực hiện bằng ký tự `0` cũng như nhận biết dấu hiệu.
//! Định dạng như `{:08}` sẽ mang lại `00000001` cho số nguyên `1`, trong khi định dạng tương tự sẽ mang lại `-0000001` cho số nguyên `-1`.
//! Lưu ý rằng phiên bản âm có ít hơn một số 0 so với phiên bản dương.
//!         Lưu ý rằng các số không đệm luôn được đặt sau dấu (nếu có) và trước các chữ số.Khi được sử dụng cùng với cờ `#`, một quy tắc tương tự sẽ được áp dụng: các số không đệm được chèn sau tiền tố nhưng trước các chữ số.
//!         Tiền tố được bao gồm trong tổng chiều rộng.
//!
//! ## Precision
//!
//! Đối với các loại không phải số, đây có thể được coi là một "maximum width".
//! Nếu chuỗi kết quả dài hơn chiều rộng này, thì nó sẽ bị cắt ngắn xuống còn nhiều ký tự này và giá trị bị cắt ngắn đó được phát ra với `fill`, `alignment` và `width` thích hợp nếu các tham số đó được đặt.
//!
//! Đối với các loại tích phân, điều này được bỏ qua.
//!
//! Đối với các loại dấu phẩy động, điều này cho biết có bao nhiêu chữ số sau dấu thập phân sẽ được in.
//!
//! Có ba cách có thể để chỉ định `precision` mong muốn:
//!
//! 1. Một số nguyên `.N`:
//!
//!    số nguyên `N` chính nó là độ chính xác.
//!
//! 2. Một số nguyên hoặc tên theo sau là ký hiệu đô la `.N$`:
//!
//!    sử dụng định dạng *đối số*`N` (phải là `usize`) làm độ chính xác.
//!
//! 3. Dấu hoa thị `.*`:
//!
//!    `.*` có nghĩa là `{...}` này được liên kết với đầu vào định dạng *hai* thay vì một đầu vào: đầu vào đầu tiên giữ độ chính xác `usize` và đầu vào thứ hai giữ giá trị để in.
//!    Lưu ý rằng trong trường hợp này, nếu người ta sử dụng chuỗi định dạng `{<arg>:<spec>.*}`, thì phần `<arg>` tham chiếu đến* giá trị * để in và `precision` phải ở đầu vào trước `<arg>`.
//!
//! Ví dụ: tất cả các lệnh gọi sau đều in cùng một thứ `Hello x is 0.01000`:
//!
//! ```
//! // Xin chào {arg 0 ("x")} là {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Xin chào {arg 1 ("x")} là {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Xin chào {arg 0 ("x")} là {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Xin chào {next arg ("x")} là {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Xin chào {next arg ("x")} là {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Xin chào {next arg ("x")} là {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Trong khi những điều này:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! in ba thứ khác nhau đáng kể:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Trong một số ngôn ngữ lập trình, hoạt động của các hàm định dạng chuỗi phụ thuộc vào cài đặt ngôn ngữ của hệ điều hành.
//! Các hàm định dạng được cung cấp bởi thư viện tiêu chuẩn của Rust không có bất kỳ khái niệm ngôn ngữ nào và sẽ tạo ra kết quả giống nhau trên tất cả các hệ thống bất kể cấu hình của người dùng.
//!
//! Ví dụ: mã sau sẽ luôn in `1.5` ngay cả khi ngôn ngữ hệ thống sử dụng dấu phân tách thập phân không phải là dấu chấm.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Các ký tự chữ `{` và `}` có thể được bao gồm trong một chuỗi bằng cách đặt trước chúng bằng cùng một ký tự.Ví dụ: ký tự `{` được thoát bằng `{{` và ký tự `}` được thoát bằng `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Tóm lại, ở đây bạn có thể tìm thấy toàn bộ ngữ pháp của chuỗi định dạng.
//! Cú pháp cho ngôn ngữ định dạng được sử dụng được lấy từ các ngôn ngữ khác, vì vậy nó không được quá xa lạ.Các đối số được định dạng với cú pháp giống Python, có nghĩa là các đối số được bao quanh bởi `{}` thay vì `%` giống C.
//! Ngữ pháp thực tế cho cú pháp định dạng là:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Theo ngữ pháp trên, `text` không được chứa bất kỳ ký tự `'{'` hoặc `'}'` nào.
//!
//! # Định dạng traits
//!
//! Khi yêu cầu đối số được định dạng bằng một kiểu cụ thể, bạn thực sự đang yêu cầu đối số đó chỉ định cho một trait cụ thể.
//! Điều này cho phép nhiều kiểu thực tế được định dạng thông qua `{:x}` (như [`i8`] cũng như [`isize`]).Ánh xạ hiện tại của các loại tới traits là:
//!
//! * *không có gì* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] với số nguyên thập lục phân viết thường
//! * `X?` ⇒ [`Debug`] với số nguyên thập lục phân viết hoa
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Điều này có nghĩa là bất kỳ loại đối số nào triển khai [`fmt::Binary`][`Binary`] trait sau đó đều có thể được định dạng bằng `{:b}`.Các triển khai cũng được cung cấp cho các traits này cho một số kiểu nguyên thủy bởi thư viện chuẩn.
//!
//! Nếu không có định dạng nào được chỉ định (như trong `{}` hoặc `{:6}`), thì định dạng trait được sử dụng là [`Display`] trait.
//!
//! Khi triển khai định dạng trait cho kiểu của riêng bạn, bạn sẽ phải triển khai một phương thức của chữ ký:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // loại tùy chỉnh của chúng tôi
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Kiểu của bạn sẽ được chuyển là `self` theo tham chiếu và sau đó hàm sẽ phát ra đầu ra vào luồng `f.buf`.Việc triển khai trait tùy thuộc vào từng định dạng để tuân thủ chính xác các thông số định dạng được yêu cầu.
//! Giá trị của các tham số này sẽ được liệt kê trong các trường của cấu trúc [`Formatter`].Để trợ giúp việc này, cấu trúc [`Formatter`] cũng cung cấp một số phương pháp trợ giúp.
//!
//! Ngoài ra, giá trị trả về của hàm này là [`fmt::Result`], là bí danh kiểu của [`Result`]`<(),`[`std: : fmt::Error`] `>`.
//! Việc triển khai định dạng phải đảm bảo rằng chúng truyền lỗi từ [`Formatter`] (ví dụ: khi gọi [`write!`]).
//! Tuy nhiên, họ không bao giờ nên trả lại lỗi một cách cay đắng.
//! Nghĩa là, việc triển khai định dạng phải và chỉ có thể trả về lỗi nếu [`Formatter`] được truyền vào trả về lỗi.
//! Điều này là do, trái với những gì mà chữ ký hàm có thể đề xuất, định dạng chuỗi là một thao tác không thể sai lầm.
//! Hàm này chỉ trả về một kết quả vì việc ghi vào luồng bên dưới có thể không thành công và nó phải cung cấp một cách để tuyên truyền sự thật rằng đã xảy ra lỗi sao lưu ngăn xếp.
//!
//! Ví dụ về việc triển khai định dạng traits sẽ giống như sau:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Giá trị `f` thực hiện `Write` trait, đó là những gì được ghi!macro đang mong đợi.
//!         // Lưu ý rằng định dạng này bỏ qua các cờ khác nhau được cung cấp cho các chuỗi định dạng.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // traits khác nhau cho phép các dạng đầu ra khác nhau của một loại.
//! // Ý nghĩa của định dạng này là in độ lớn của vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Tôn trọng các cờ định dạng bằng cách sử dụng phương thức trợ giúp `pad_integral` trên đối tượng Định dạng.
//!         // Xem tài liệu phương pháp để biết chi tiết và hàm `pad` có thể được sử dụng để đệm các chuỗi.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` so với `fmt::Debug`
//!
//! Hai định dạng traits này có các mục đích riêng biệt:
//!
//! - [`fmt::Display`][`Display`] triển khai khẳng định rằng kiểu có thể được biểu diễn trung thực dưới dạng chuỗi UTF-8 tại mọi thời điểm.**Không** mong đợi rằng tất cả các loại đều triển khai [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] triển khai nên được triển khai cho **tất cả** loại công khai.
//!   Đầu ra thường sẽ đại diện cho trạng thái bên trong một cách trung thực nhất có thể.
//!   Mục đích của [`Debug`] trait là để tạo điều kiện gỡ lỗi mã Rust.Trong hầu hết các trường hợp, sử dụng `#[derive(Debug)]` là đủ và được khuyến khích.
//!
//! Một số ví dụ về đầu ra từ cả hai traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Macro có liên quan
//!
//! Có một số macro liên quan trong họ [`format!`].Những cái hiện đang được triển khai là:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Đây và [`writeln!`] là hai macro được sử dụng để phát chuỗi định dạng tới một luồng được chỉ định.Điều này được sử dụng để ngăn phân bổ trung gian các chuỗi định dạng và thay vào đó ghi trực tiếp đầu ra.
//! Dưới mui xe, chức năng này thực sự đang gọi chức năng [`write_fmt`] được xác định trên [`std::io::Write`] trait.
//! Cách sử dụng ví dụ là:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Điều này và [`println!`] phát ra đầu ra của chúng tới stdout.Tương tự như macro [`write!`], mục tiêu của các macro này là tránh phân bổ trung gian khi in đầu ra.Cách sử dụng ví dụ là:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Các macro [`eprint!`] và [`eprintln!`] tương ứng giống với [`print!`] và [`println!`], ngoại trừ chúng phát ra đầu ra của chúng tới stderr.
//!
//! ### `format_args!`
//!
//! Đây là một macro tò mò được sử dụng để truyền một cách an toàn xung quanh một đối tượng không trong suốt mô tả chuỗi định dạng.Đối tượng này không yêu cầu bất kỳ phân bổ heap nào để tạo và nó chỉ tham chiếu thông tin trên ngăn xếp.
//! Dưới mui xe, tất cả các macro có liên quan đều được thực hiện theo điều này.
//! Trước hết, một số ví dụ sử dụng là:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Kết quả của macro [`format_args!`] là một giá trị kiểu [`fmt::Arguments`].
//! Cấu trúc này sau đó có thể được chuyển cho các hàm [`write`] và [`format`] bên trong mô-đun này để xử lý chuỗi định dạng.
//! Mục tiêu của macro này là ngăn chặn hơn nữa việc phân bổ trung gian khi xử lý các chuỗi định dạng.
//!
//! Ví dụ, một thư viện ghi nhật ký có thể sử dụng cú pháp định dạng tiêu chuẩn, nhưng nó sẽ truyền nội bộ xung quanh cấu trúc này cho đến khi nó được xác định nơi đầu ra sẽ chuyển đến.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Hàm `format` nhận cấu trúc [`Arguments`] và trả về chuỗi được định dạng kết quả.
///
///
/// Phiên bản [`Arguments`] có thể được tạo bằng macro [`format_args!`].
///
/// # Examples
///
/// Cách sử dụng cơ bản:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Xin lưu ý rằng sử dụng [`format!`] có thể thích hợp hơn.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}