//! Các lát cắt chuỗi Unicode.
//!
//! *[See also the `str` primitive type](str).*
//!
//! Loại `&str` là một trong hai loại chuỗi chính, loại còn lại là `String`.
//! Không giống như đối tác `String` của nó, nội dung của nó được vay mượn.
//!
//! # Cách sử dụng cơ bản
//!
//! Khai báo chuỗi cơ bản của kiểu `&str`:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Ở đây chúng ta đã khai báo một chuỗi ký tự, còn được gọi là một lát chuỗi.
//! Chuỗi ký tự có thời gian tồn tại tĩnh, có nghĩa là chuỗi `hello_world` được đảm bảo có giá trị trong suốt thời gian của toàn bộ chương trình.
//!
//! Chúng tôi cũng có thể chỉ định rõ ràng thời gian tồn tại của `hello_world`:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Nhiều ứng dụng trong mô-đun này chỉ được sử dụng trong cấu hình thử nghiệm.
// Sẽ tốt hơn nếu bạn chỉ tắt cảnh báo used_imports hơn là sửa chúng.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `str` trong `Concat<str>` không có ý nghĩa ở đây.
/// Tham số kiểu này của trait chỉ tồn tại để cho phép cấy ghép khác.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // các vòng lặp có kích thước mã cứng chạy nhanh hơn nhiều, chuyên về các trường hợp có độ dài dấu phân cách nhỏ
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // dự phòng kích thước khác 0 tùy ý
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Triển khai tham gia được tối ưu hóa hoạt động cho cả Vec<T>(T: Copy) và vec bên trong của String Hiện tại (2018-05-13) có một lỗi với kiểu suy luận và chuyên môn hóa (xem vấn đề #36262) Vì lý do này SliceConcat<T>không chuyên cho T: Copy và SliceConcat<str>là người dùng duy nhất của chức năng này.
// Nó được giữ nguyên trong thời gian khi điều đó được cố định.
//
// giới hạn cho String-join là S: Borrow<str>và đối với Vec-join Borrow <[T]> [T] và str đều tích hợp AsRef <[T]> cho một số T
// => s.borrow().as_ref() và chúng tôi luôn có những lát cắt
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // lát đầu tiên là lát duy nhất không có dấu phân cách trước nó
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // tính toán tổng độ dài chính xác của Vec đã tham gia nếu phép tính `len` bị tràn, chúng ta sẽ panic dù sao chúng ta cũng sẽ hết bộ nhớ và phần còn lại của hàm yêu cầu toàn bộ Vec được cấp phát trước để đảm bảo an toàn
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // chuẩn bị một bộ đệm chưa khởi tạo
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // sao chép phân tách và các lát cắt qua kiểm tra không giới hạn tạo ra các vòng lặp với hiệu số mã cứng cho các dấu phân tách nhỏ, có thể cải thiện lớn (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // Một triển khai mượn kỳ lạ có thể trả về các lát cắt khác nhau cho phép tính độ dài và bản sao thực.
        //
        // Đảm bảo rằng chúng tôi không để lộ các byte chưa được khởi tạo cho người gọi.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Các phương thức cho các lát chuỗi.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// Chuyển đổi `Box<str>` thành `Box<[u8]>` mà không cần sao chép hoặc phân bổ.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// Thay thế tất cả các kết quả phù hợp của một mẫu bằng một chuỗi khác.
    ///
    /// `replace` tạo một [`String`] mới và sao chép dữ liệu từ phần chuỗi này vào nó.
    /// Trong khi làm như vậy, nó cố gắng tìm các kết quả phù hợp của một mẫu.
    /// Nếu nó tìm thấy bất kỳ, nó sẽ thay thế chúng bằng lát chuỗi thay thế.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Khi mẫu không khớp:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Thay thế N kết quả đầu tiên của một mẫu bằng một chuỗi khác.
    ///
    /// `replacen` tạo một [`String`] mới và sao chép dữ liệu từ phần chuỗi này vào nó.
    /// Trong khi làm như vậy, nó cố gắng tìm các kết quả phù hợp của một mẫu.
    /// Nếu nó tìm thấy bất kỳ, nó sẽ thay thế chúng bằng lát chuỗi thay thế nhiều nhất là `count` lần.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Khi mẫu không khớp:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Hy vọng sẽ giảm số lần phân bổ lại
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Trả về chữ thường tương đương của lát chuỗi này, dưới dạng [`String`] mới.
    ///
    /// 'Lowercase' được định nghĩa theo các điều khoản của Thuộc tính lõi có nguồn gốc Unicode `Lowercase`.
    ///
    /// Vì một số ký tự có thể mở rộng thành nhiều ký tự khi thay đổi trường hợp, hàm này trả về [`String`] thay vì sửa đổi tham số tại chỗ.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Một ví dụ khó, với sigma:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // nhưng ở cuối một từ, nó là ς, không phải σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// Các ngôn ngữ không có chữ hoa thường không được thay đổi:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ ánh xạ tới σ, ngoại trừ ở cuối một từ mà nó ánh xạ tới ς.
                // Đây là ánh xạ (contextual) có điều kiện duy nhất nhưng không phụ thuộc vào ngôn ngữ trong `SpecialCasing.txt`, vì vậy hãy mã hóa nó thay vì có một cơ chế "condition" chung chung.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // đối với định nghĩa của `Final_Sigma`.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Trả về chữ hoa tương đương của lát chuỗi này, dưới dạng [`String`] mới.
    ///
    /// 'Uppercase' được định nghĩa theo các điều khoản của Thuộc tính lõi có nguồn gốc Unicode `Uppercase`.
    ///
    /// Vì một số ký tự có thể mở rộng thành nhiều ký tự khi thay đổi trường hợp, hàm này trả về [`String`] thay vì sửa đổi tham số tại chỗ.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// Các tập lệnh không có chữ hoa thường không được thay đổi:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Một ký tự có thể trở thành nhiều:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// Chuyển đổi [`Box<str>`] thành [`String`] mà không cần sao chép hoặc phân bổ.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// Tạo [`String`] mới bằng cách lặp lại chuỗi `n` lần.
    ///
    /// # Panics
    ///
    /// Hàm này sẽ panic nếu dung lượng tràn.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// A panic khi tràn:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Trả về một bản sao của chuỗi này trong đó mỗi ký tự được ánh xạ tới chữ hoa chữ thường ASCII tương đương của nó.
    ///
    ///
    /// Các chữ cái ASCII 'a' đến 'z' được ánh xạ thành 'A' đến 'Z', nhưng các chữ cái không phải ASCII thì không thay đổi.
    ///
    /// Để viết hoa giá trị tại chỗ, hãy sử dụng [`make_ascii_uppercase`].
    ///
    /// Để viết hoa các ký tự ASCII ngoài các ký tự không phải ASCII, hãy sử dụng [`to_uppercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() bảo toàn UTF-8 bất biến.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Trả về một bản sao của chuỗi này trong đó mỗi ký tự được ánh xạ tới chữ thường ASCII tương đương của nó.
    ///
    ///
    /// Các chữ cái ASCII 'A' đến 'Z' được ánh xạ thành 'a' đến 'z', nhưng các chữ cái không phải ASCII thì không thay đổi.
    ///
    /// Để viết thường giá trị tại chỗ, hãy sử dụng [`make_ascii_lowercase`].
    ///
    /// Để ký tự ASCII viết thường ngoài các ký tự không phải ASCII, hãy sử dụng [`to_lowercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() bảo toàn UTF-8 bất biến.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Chuyển đổi một lát byte được đóng hộp thành một lát chuỗi được đóng hộp mà không cần kiểm tra xem chuỗi có chứa UTF-8 hợp lệ hay không.
///
///
/// # Examples
///
/// Cách sử dụng cơ bản:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}