//! Prelude được cấp phát
//!
//! Mục đích của mô-đun này là để giảm bớt việc nhập khẩu các mặt hàng thường được sử dụng của `alloc` crate bằng cách thêm nhập toàn cầu vào đầu mô-đun:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;