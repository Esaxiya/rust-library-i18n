use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Viết thử nghiệm tích hợp giữa trình cấp phát của bên thứ ba và `RawVec` hơi phức tạp vì API `RawVec` không hiển thị các phương pháp cấp phát sai lệch, vì vậy chúng tôi không thể kiểm tra điều gì xảy ra khi trình cấp phát hết (ngoài việc phát hiện panic).
    //
    //
    // Thay vào đó, điều này chỉ kiểm tra xem các phương thức `RawVec` có ít nhất đi qua API phân bổ khi nó dự trữ bộ nhớ hay không.
    //
    //
    //
    //
    //

    // Một bộ phân bổ ngu ngốc tiêu thụ một lượng nhiên liệu cố định trước khi các nỗ lực phân bổ bắt đầu không thành công.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (gây ra phân bổ lại, do đó sử dụng 50 + 150=200 đơn vị nhiên liệu)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Đầu tiên, `reserve` phân bổ giống như `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 cao hơn gấp đôi của 7, vì vậy `reserve` sẽ hoạt động giống như `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 nhỏ hơn một nửa của 12, vì vậy `reserve` phải phát triển theo cấp số nhân.
        // Tại thời điểm viết bài kiểm tra này, hệ số tăng trưởng là 2, vì vậy công suất mới là 24, tuy nhiên, hệ số tăng trưởng của 1.5 cũng ổn.
        //
        // Do đó `>= 18` khẳng định.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}