#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Nội dung của bộ nhớ mới chưa được khởi tạo.
    Uninitialized,
    /// Bộ nhớ mới được đảm bảo là không.
    Zeroed,
}

/// Một tiện ích cấp thấp để phân bổ, phân bổ lại và phân bổ lại bộ nhớ đệm trên heap một cách công thái học hơn mà không phải lo lắng về tất cả các trường hợp góc liên quan.
///
/// Loại này tuyệt vời để xây dựng cấu trúc dữ liệu của riêng bạn như Vec và VecDeque.
/// Đặc biệt:
///
/// * Sản xuất `Unique::dangling()` trên các loại có kích thước bằng không.
/// * Sản xuất `Unique::dangling()` trên phân bổ độ dài bằng không.
/// * Tránh giải phóng `Unique::dangling()`.
/// * Bắt tất cả các lỗi tràn trong tính toán dung lượng (quảng bá chúng thành "capacity overflow" panics).
/// * Bảo vệ chống lại các hệ thống 32-bit phân bổ nhiều hơn isize::MAX byte.
/// * Bảo vệ chống tràn chiều dài của bạn.
/// * Gọi `handle_alloc_error` để biết phân bổ sai.
/// * Chứa `ptr::Unique` và do đó mang lại cho người dùng tất cả các lợi ích liên quan.
/// * Sử dụng phần vượt quá được trả lại từ bộ phân bổ để sử dụng dung lượng lớn nhất hiện có.
///
/// Loại này dù sao cũng không kiểm tra bộ nhớ mà nó quản lý.Khi bị rơi, nó *sẽ* giải phóng bộ nhớ của nó, nhưng nó *sẽ không* cố gắng làm rơi nội dung của nó.
/// Người dùng `RawVec` có quyền xử lý những thứ thực tế *được lưu trữ* bên trong `RawVec`.
///
/// Lưu ý rằng phần dư của các loại có kích thước bằng 0 luôn là vô hạn, vì vậy `capacity()` luôn trả về `usize::MAX`.
/// Điều này có nghĩa là bạn cần phải cẩn thận khi quay vòng kiểu này với `Box<[T]>`, vì `capacity()` sẽ không mang lại độ dài.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Điều này tồn tại vì `#[unstable]` `const fn`s không cần tuân theo `min_const_fn` và vì vậy chúng cũng không thể được gọi trong`min_const_fn`s.
    ///
    /// Nếu bạn thay đổi `RawVec<T>::new` hoặc các phần phụ thuộc, vui lòng lưu ý không giới thiệu bất kỳ thứ gì thực sự vi phạm `min_const_fn`.
    ///
    /// NOTE: Chúng tôi có thể tránh bị hack này và kiểm tra sự phù hợp với một số thuộc tính `#[rustc_force_min_const_fn]` yêu cầu sự phù hợp với `min_const_fn` nhưng không nhất thiết cho phép gọi nó trong `stable(...) const fn`/mã người dùng không kích hoạt `foo` khi `#[rustc_const_unstable(feature = "foo", issue = "01234")]` có mặt.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Tạo `RawVec` lớn nhất có thể (trên heap hệ thống) mà không cần phân bổ.
    /// Nếu `T` có kích thước dương, thì điều này làm cho `RawVec` có dung lượng `0`.
    /// Nếu `T` có kích thước bằng 0, thì nó tạo thành `RawVec` có dung lượng `usize::MAX`.
    /// Hữu ích cho việc thực hiện phân bổ bị trì hoãn.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Tạo `RawVec` (trên heap hệ thống) với chính xác các yêu cầu về dung lượng và căn chỉnh cho `[T; capacity]`.
    /// Điều này tương đương với việc gọi `RawVec::new` khi `capacity` là `0` hoặc `T` có kích thước bằng không.
    /// Lưu ý rằng nếu `T` có kích thước bằng 0, điều này có nghĩa là bạn sẽ *không* nhận được `RawVec` với dung lượng được yêu cầu.
    ///
    /// # Panics
    ///
    /// Panics nếu dung lượng yêu cầu vượt quá `isize::MAX` byte.
    ///
    /// # Aborts
    ///
    /// Bỏ qua OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Giống như `with_capacity`, nhưng đảm bảo bộ đệm bằng không.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Tái tạo `RawVec` từ một con trỏ và dung lượng.
    ///
    /// # Safety
    ///
    /// `ptr` phải được cấp phát (trên heap hệ thống) và với `capacity` đã cho.
    /// `capacity` không thể vượt quá `isize::MAX` đối với các loại có kích thước.(chỉ là mối quan tâm trên hệ thống 32-bit).
    /// ZST vectors có thể có dung lượng lên đến `usize::MAX`.
    /// Nếu `ptr` và `capacity` đến từ `RawVec`, thì điều này được đảm bảo.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Vecs tí hon bị câm.Bỏ qua:
    // - 8 nếu kích thước phần tử là 1, vì bất kỳ trình phân bổ heap nào cũng có khả năng làm tròn một yêu cầu nhỏ hơn 8 byte thành ít nhất 8 byte.
    //
    // - 4 nếu các phần tử có kích thước vừa phải (<=1 KiB).
    // - 1 nếu không, để tránh lãng phí quá nhiều dung lượng cho các Vec rất ngắn.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Giống như `new`, nhưng được tham số hóa qua sự lựa chọn của bộ cấp phát cho `RawVec` được trả về.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` nghĩa là "unallocated".loại có kích thước bằng không bị bỏ qua.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Giống như `with_capacity`, nhưng được tham số hóa qua sự lựa chọn của bộ cấp phát cho `RawVec` được trả về.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Giống như `with_capacity_zeroed`, nhưng được tham số hóa qua sự lựa chọn của bộ cấp phát cho `RawVec` được trả về.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Chuyển đổi `Box<[T]>` thành `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Chuyển đổi toàn bộ bộ đệm thành `Box<[MaybeUninit<T>]>` với `len` được chỉ định.
    ///
    /// Lưu ý rằng điều này sẽ hoàn nguyên chính xác mọi thay đổi `cap` có thể đã được thực hiện.(Xem mô tả loại để biết thêm chi tiết.)
    ///
    /// # Safety
    ///
    /// * `len` phải lớn hơn hoặc bằng dung lượng được yêu cầu gần đây nhất và
    /// * `len` phải nhỏ hơn hoặc bằng `self.capacity()`.
    ///
    /// Lưu ý rằng dung lượng được yêu cầu và `self.capacity()` có thể khác nhau, vì bộ phân bổ có thể phân bổ tổng thể và trả về khối bộ nhớ lớn hơn yêu cầu.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Sanity-kiểm tra một nửa yêu cầu an toàn (chúng tôi không thể kiểm tra nửa còn lại).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Chúng tôi tránh `unwrap_or_else` ở đây vì nó làm tăng lượng LLVM IR được tạo ra.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Tái tạo `RawVec` từ một con trỏ, dung lượng và bộ phân bổ.
    ///
    /// # Safety
    ///
    /// `ptr` phải được cấp phát (thông qua trình cấp phát `alloc` đã cho) và với `capacity` đã cho.
    /// `capacity` không được vượt quá `isize::MAX` đối với các loại có kích thước.
    /// (chỉ là mối quan tâm trên hệ thống 32-bit).
    /// ZST vectors có thể có dung lượng lên đến `usize::MAX`.
    /// Nếu `ptr` và `capacity` đến từ `RawVec` được tạo thông qua `alloc`, thì điều này được đảm bảo.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Nhận một con trỏ thô để bắt đầu phân bổ.
    /// Lưu ý rằng đây là `Unique::dangling()` nếu `capacity == 0` hoặc `T` có kích thước bằng không.
    /// Trong trường hợp trước đây, bạn phải cẩn thận.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Nhận dung lượng của phân bổ.
    ///
    /// Đây sẽ luôn là `usize::MAX` nếu `T` có kích thước bằng không.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Trả về một tham chiếu được chia sẻ tới trình cấp phát hỗ trợ `RawVec` này.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Chúng tôi có một phần bộ nhớ được phân bổ, vì vậy chúng tôi có thể bỏ qua kiểm tra thời gian chạy để có được bố cục hiện tại của chúng tôi.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Đảm bảo rằng bộ đệm chứa ít nhất đủ không gian để chứa các phần tử `len + additional`.
    /// Nếu nó không có đủ công suất, sẽ phân bổ lại đủ không gian cộng với không gian thoải mái để có được hành vi *O*(1) được khấu hao.
    ///
    /// Sẽ hạn chế hành vi này nếu nó tự gây ra panic một cách không cần thiết.
    ///
    /// Nếu `len` vượt quá `self.capacity()`, điều này có thể không thực sự phân bổ không gian được yêu cầu.
    /// Điều này không thực sự không an toàn, nhưng mã không an toàn *bạn* viết dựa trên hoạt động của hàm này có thể bị hỏng.
    ///
    /// Điều này lý tưởng để triển khai hoạt động đẩy hàng loạt như `extend`.
    ///
    /// # Panics
    ///
    /// Panics nếu dung lượng mới vượt quá `isize::MAX` byte.
    ///
    /// # Aborts
    ///
    /// Bỏ qua OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // dự trữ sẽ bị hủy bỏ hoặc bị hoảng sợ nếu len vượt quá `isize::MAX` vì vậy điều này có thể an toàn để bỏ chọn bây giờ.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Giống như `reserve`, nhưng trả về lỗi thay vì hoảng sợ hoặc bỏ dở.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Đảm bảo rằng bộ đệm chứa ít nhất đủ không gian để chứa các phần tử `len + additional`.
    /// Nếu nó chưa có, sẽ phân bổ lại lượng bộ nhớ tối thiểu có thể cần thiết.
    /// Nói chung, đây chính xác là dung lượng bộ nhớ cần thiết, nhưng về nguyên tắc, bộ cấp phát có thể tự do cung cấp lại nhiều hơn những gì chúng tôi yêu cầu.
    ///
    ///
    /// Nếu `len` vượt quá `self.capacity()`, điều này có thể không thực sự phân bổ không gian được yêu cầu.
    /// Điều này không thực sự không an toàn, nhưng mã không an toàn *bạn* viết dựa trên hoạt động của hàm này có thể bị hỏng.
    ///
    /// # Panics
    ///
    /// Panics nếu dung lượng mới vượt quá `isize::MAX` byte.
    ///
    /// # Aborts
    ///
    /// Bỏ qua OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Giống như `reserve_exact`, nhưng trả về lỗi thay vì hoảng sợ hoặc bỏ dở.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Thu hẹp phân bổ xuống mức được chỉ định.
    /// Nếu số tiền đã cho là 0, thực sự hoàn toàn được phân bổ.
    ///
    /// # Panics
    ///
    /// Panics nếu số lượng đã cho *lớn hơn* so với dung lượng hiện tại.
    ///
    /// # Aborts
    ///
    /// Bỏ qua OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Trả về nếu bộ đệm cần phát triển để đáp ứng dung lượng bổ sung cần thiết.
    /// Chủ yếu được sử dụng để thực hiện các cuộc gọi dự phòng nội tuyến mà không cần nội tuyến `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Phương pháp này thường được khởi tạo nhiều lần.Vì vậy, chúng tôi muốn nó càng nhỏ càng tốt để cải thiện thời gian biên dịch.
    // Nhưng chúng tôi cũng muốn càng nhiều nội dung của nó có thể tính toán tĩnh càng tốt, để làm cho mã được tạo chạy nhanh hơn.
    // Do đó, phương pháp này được viết cẩn thận để tất cả mã phụ thuộc vào `T` đều nằm trong nó, trong khi càng nhiều mã không phụ thuộc vào `T` càng tốt nằm trong các hàm không chung chung so với `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Điều này được đảm bảo bởi các ngữ cảnh gọi.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Vì chúng tôi trả về dung lượng `usize::MAX` khi `elem_size` là
            // 0, đến đây nhất thiết có nghĩa là `RawVec` đã quá đầy.
            return Err(CapacityOverflow);
        }

        // Thật đáng buồn là chúng tôi không thể làm gì về những kiểm tra này.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Điều này đảm bảo sự tăng trưởng theo cấp số nhân.
        // Việc nhân đôi không thể tràn vì `cap <= isize::MAX` và loại `cap` là `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` không chung chung so với `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Các ràng buộc trên phương pháp này cũng giống như trên `grow_amortized`, nhưng phương pháp này thường được khởi tạo ít thường xuyên hơn nên nó ít quan trọng hơn.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Vì chúng tôi trả về dung lượng `usize::MAX` khi kích thước loại là
            // 0, đến đây nhất thiết có nghĩa là `RawVec` đã quá đầy.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` không chung chung so với `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Chức năng này nằm ngoài `RawVec` để giảm thiểu thời gian biên dịch.Xem bình luận ở trên `RawVec::grow_amortized` để biết chi tiết.
// (Tham số `A` không đáng kể, bởi vì số lượng các loại `A` khác nhau được nhìn thấy trong thực tế nhỏ hơn nhiều so với số lượng các loại `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Kiểm tra lỗi tại đây để giảm thiểu kích thước của `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Trình phân bổ kiểm tra sự bình đẳng về căn chỉnh
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Giải phóng bộ nhớ thuộc sở hữu của `RawVec`*mà không* cố gắng xóa nội dung của nó.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Chức năng trung tâm để xử lý lỗi dự trữ.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Chúng tôi cần đảm bảo những điều sau:
// * Chúng tôi không bao giờ phân bổ các đối tượng kích thước byte `> isize::MAX`.
// * Chúng tôi không làm tràn `usize::MAX` và thực sự phân bổ quá ít.
//
// Trên 64-bit, chúng tôi chỉ cần kiểm tra xem có tràn vì cố gắng cấp phát byte `> isize::MAX` chắc chắn sẽ không thành công.
// Trên 32-bit và 16-bit, chúng tôi cần thêm một bảo vệ bổ sung cho điều này trong trường hợp chúng tôi đang chạy trên một nền tảng có thể sử dụng tất cả 4GB trong không gian người dùng, ví dụ: PAE hoặc x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Một chức năng trung tâm chịu trách nhiệm báo cáo tràn dung lượng.
// Điều này sẽ đảm bảo rằng việc tạo mã liên quan đến các panics này là tối thiểu vì chỉ có một vị trí mà panics thay vì một nhóm trong toàn mô-đun.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}