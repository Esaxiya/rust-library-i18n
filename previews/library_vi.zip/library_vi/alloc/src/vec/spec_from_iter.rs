use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Chuyên môn trait được sử dụng cho Vec::from_iter
///
/// ## Biểu đồ ủy quyền:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Một trường hợp phổ biến là chuyển vector vào một hàm ngay lập tức thu thập lại thành vector.
        // Chúng ta có thể đoản mạch điều này nếu IntoIter không được cải tiến chút nào.
        // Khi nó đã được nâng cao Chúng tôi cũng có thể sử dụng lại bộ nhớ và di chuyển dữ liệu lên phía trước.
        // Nhưng chúng tôi chỉ làm như vậy khi Vec kết quả sẽ không có nhiều dung lượng không sử dụng hơn so với việc tạo nó thông qua triển khai FromIterator chung chung.
        //
        // Hạn chế đó là không cần thiết vì hành vi phân bổ của Vec là cố ý không xác định.
        // Nhưng đó là một lựa chọn bảo thủ.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // phải ủy quyền cho spec_extend() vì chính extend() ủy quyền cho spec_from cho các Vec trống
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Điều này sử dụng `iterator.as_slice().to_vec()` vì spec_extend phải thực hiện nhiều bước hơn để suy luận về dung lượng + độ dài cuối cùng và do đó thực hiện nhiều công việc hơn.
// `to_vec()` phân bổ trực tiếp số tiền chính xác và điền chính xác.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): với cfg(test), phương thức `[T]::to_vec` vốn có, được yêu cầu cho định nghĩa phương pháp này, không khả dụng.
    // Thay vào đó, hãy sử dụng chức năng `slice::to_vec` chỉ khả dụng với cfg(test) NB, hãy xem mô-đun slice::hack trong slice.rs để biết thêm thông tin
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}