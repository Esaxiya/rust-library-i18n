use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// Một chuyên môn khác trait dành cho Vec::from_iter cần thiết để ưu tiên thủ công các chuyên môn chồng chéo, hãy xem [`SpecFromIter`](super::SpecFromIter) để biết chi tiết.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Bỏ cuộn lần lặp đầu tiên, vì vector sẽ được mở rộng trên lần lặp này trong mọi trường hợp khi có thể lặp không trống, nhưng vòng lặp trong extend_desugared() sẽ không thấy vector đầy trong một vài lần lặp vòng tiếp theo.
        //
        // Vì vậy, chúng tôi nhận được dự đoán branch tốt hơn.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // phải ủy quyền cho spec_extend() vì chính extend() ủy quyền cho spec_from cho các Vec trống
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // phải ủy quyền cho spec_extend() vì chính extend() ủy quyền cho spec_from cho các Vec trống
        //
        vector.spec_extend(iterator);
        vector
    }
}