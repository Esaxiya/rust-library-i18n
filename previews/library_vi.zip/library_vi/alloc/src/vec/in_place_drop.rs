use core::ptr::{self};
use core::slice::{self};

// Một cấu trúc trình trợ giúp cho phép lặp tại chỗ làm giảm phần lặp đích, tức là phần đầu.
// Phần nguồn (phần đuôi) bị bỏ bởi IntoIter.
pub(super) struct InPlaceDrop<T> {
    pub(super) inner: *mut T,
    pub(super) dst: *mut T,
}

impl<T> InPlaceDrop<T> {
    fn len(&self) -> usize {
        unsafe { self.dst.offset_from(self.inner) as usize }
    }
}

impl<T> Drop for InPlaceDrop<T> {
    #[inline]
    fn drop(&mut self) {
        unsafe {
            ptr::drop_in_place(slice::from_raw_parts_mut(self.inner, self.len()));
        }
    }
}