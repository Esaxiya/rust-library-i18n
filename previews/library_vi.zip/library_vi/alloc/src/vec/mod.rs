//! Kiểu mảng có thể phát triển liền kề với nội dung được phân bổ theo đống, được viết `Vec<T>`.
//!
//! Vectors có lập chỉ mục `O(1)`, đẩy `O(1)` phân bổ (đến cuối) và cửa sổ bật `O(1)` (từ cuối).
//!
//!
//! Vectors đảm bảo chúng không bao giờ phân bổ nhiều hơn `isize::MAX` byte.
//!
//! # Examples
//!
//! Bạn có thể tạo [`Vec`] một cách rõ ràng với [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... hoặc bằng cách sử dụng macro [`vec!`]:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // mười số 0
//! ```
//!
//! Bạn có thể đặt các giá trị [`push`] vào cuối vector (sẽ phát triển vector khi cần):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Các giá trị bật lên hoạt động theo cùng một cách:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors cũng hỗ trợ lập chỉ mục (thông qua [`Index`] và [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Một kiểu mảng có thể phát triển liền kề, được viết là `Vec<T>` và phát âm là 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Macro [`vec!`] được cung cấp để giúp việc khởi tạo thuận tiện hơn:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Nó cũng có thể khởi tạo từng phần tử của `Vec<T>` với một giá trị nhất định.
/// Điều này có thể hiệu quả hơn việc thực hiện phân bổ và khởi tạo theo các bước riêng biệt, đặc biệt khi khởi tạo vector gồm các số không:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Điều sau là tương đương, nhưng có thể chậm hơn:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Để biết thêm thông tin, hãy xem [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Sử dụng `Vec<T>` như một ngăn xếp hiệu quả:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Bản in 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Kiểu `Vec` cho phép truy cập các giá trị theo chỉ mục, vì nó thực hiện [`Index`] trait.Một ví dụ sẽ rõ ràng hơn:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // nó sẽ hiển thị '2'
/// ```
///
/// Tuy nhiên, hãy cẩn thận: nếu bạn cố gắng truy cập một chỉ mục không có trong `Vec`, phần mềm của bạn sẽ panic!Bạn không thể làm điều này:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Sử dụng [`get`] và [`get_mut`] nếu bạn muốn kiểm tra xem chỉ mục có trong `Vec` hay không.
///
/// # Slicing
///
/// `Vec` có thể thay đổi được.Mặt khác, các lát cắt là các đối tượng chỉ đọc.
/// Để có được [slice][prim@slice], hãy sử dụng [`&`].Thí dụ:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... và đó là tất cả!
/// // bạn cũng có thể làm như thế này:
/// let u: &[usize] = &v;
/// // hoặc như thế này:
/// let u: &[_] = &v;
/// ```
///
/// Trong Rust, việc chuyển các lát cắt làm đối số hơn là vectors khi bạn chỉ muốn cung cấp quyền truy cập đọc.Tương tự với [`String`] và [`&str`].
///
/// # Năng lực và phân bổ lại
///
/// Dung lượng của vector là lượng không gian được phân bổ cho bất kỳ phần tử future nào sẽ được thêm vào vector.Điều này không được nhầm lẫn với *length* của vector, chỉ định số lượng phần tử thực tế trong vector.
/// Nếu chiều dài của vector vượt quá công suất của nó, công suất của nó sẽ tự động được tăng lên, nhưng các phần tử của nó sẽ phải được phân bổ lại.
///
/// Ví dụ: vector có dung lượng 10 và độ dài 0 sẽ là vector trống với không gian cho 10 phần tử nữa.Việc đẩy 10 phần tử trở xuống vào vector sẽ không làm thay đổi công suất của nó hoặc khiến cho việc phân bổ lại xảy ra.
/// Tuy nhiên, nếu chiều dài của vector được tăng lên 11, nó sẽ phải phân bổ lại, điều này có thể chậm.Vì lý do này, bạn nên sử dụng [`Vec::with_capacity`] bất cứ khi nào có thể để chỉ định mức độ lớn mà vector dự kiến sẽ nhận được.
///
/// # Guarantees
///
/// Do bản chất cực kỳ cơ bản của nó, `Vec` đảm bảo rất nhiều về thiết kế của nó.Điều này đảm bảo rằng nó có chi phí thấp nhất có thể trong trường hợp chung và có thể được thao tác chính xác theo những cách nguyên thủy bằng mã không an toàn.Lưu ý rằng những đảm bảo này đề cập đến một `Vec<T>` không đủ tiêu chuẩn.
/// Nếu các tham số kiểu bổ sung được thêm vào (ví dụ: để hỗ trợ trình phân bổ tùy chỉnh), việc ghi đè giá trị mặc định của chúng có thể thay đổi hành vi.
///
/// Về cơ bản, `Vec` luôn và sẽ là một bộ ba (con trỏ, dung lượng, chiều dài).Không nhiều không ít.Thứ tự của các trường này hoàn toàn không xác định, và bạn nên sử dụng các phương pháp thích hợp để sửa đổi chúng.
/// Con trỏ sẽ không bao giờ là null, vì vậy kiểu này được tối ưu hóa cho con trỏ bằng null.
///
/// Tuy nhiên, con trỏ có thể không thực sự trỏ đến bộ nhớ được cấp phát.
/// Đặc biệt, nếu bạn tạo `Vec` với dung lượng 0 thông qua [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`] hoặc bằng cách gọi [`shrink_to_fit`] trên Vec trống, nó sẽ không cấp phát bộ nhớ.Tương tự, nếu bạn lưu trữ các loại có kích thước bằng không bên trong `Vec`, nó sẽ không phân bổ không gian cho chúng.
/// *Lưu ý rằng trong trường hợp này, `Vec` có thể không báo cáo [`capacity`] là 0*.
/// `Vec` sẽ cấp phát nếu và chỉ khi [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Nói chung, chi tiết phân bổ của `Vec` rất tinh tế-nếu bạn định cấp phát bộ nhớ bằng `Vec` và sử dụng nó cho việc khác (để chuyển đến mã không an toàn hoặc để xây dựng bộ sưu tập được hỗ trợ bộ nhớ của riêng bạn), hãy chắc chắn để phân bổ bộ nhớ này bằng cách sử dụng `from_raw_parts` để khôi phục `Vec` và sau đó loại bỏ nó.
///
/// Nếu `Vec`*có* bộ nhớ được cấp phát, thì bộ nhớ mà nó trỏ đến sẽ nằm trên heap (như được định nghĩa bởi trình cấp phát Rust được định cấu hình để sử dụng theo mặc định) và con trỏ của nó trỏ đến [`len`], các phần tử liền kề theo thứ tự (bạn sẽ xem bạn có ép buộc nó thành một lát hay không), theo sau là [`dung lượng`]`,`[`len`] một cách hợp lý chưa khởi tạo, các phần tử liền kề.
///
///
/// Một vector chứa các phần tử `'a'` và `'b'` với dung lượng 4 có thể được hình dung như dưới đây.Phần trên cùng là cấu trúc `Vec`, nó chứa một con trỏ đến phần đầu của phân bổ trong heap, độ dài và dung lượng.
/// Phần dưới cùng là phân bổ trên heap, một khối bộ nhớ liền kề.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** đại diện cho bộ nhớ không được khởi tạo, xem [`MaybeUninit`].
/// - Note: ABI không ổn định và `Vec` không đảm bảo về bố cục bộ nhớ của nó (bao gồm thứ tự các trường).
///
/// `Vec` sẽ không bao giờ thực hiện một "small optimization" nơi các phần tử thực sự được lưu trữ trên ngăn xếp vì hai lý do:
///
/// * Nó sẽ khiến mã không an toàn khó thao tác chính xác hơn với `Vec`.Nội dung của `Vec` sẽ không có địa chỉ ổn định nếu nó chỉ được di chuyển và sẽ khó khăn hơn để xác định xem `Vec` có thực sự được cấp phát bộ nhớ hay không.
///
/// * Nó sẽ phạt trường hợp chung, phát sinh thêm branch trên mỗi lần truy cập.
///
/// `Vec` sẽ không bao giờ tự động thu nhỏ lại, ngay cả khi hoàn toàn trống rỗng.Điều này đảm bảo không xảy ra phân bổ hoặc phân bổ giao dịch không cần thiết.Làm trống một `Vec` và sau đó lấp đầy nó trở lại vào cùng một [`len`] sẽ không có lệnh gọi nào đến trình cấp phát.Nếu bạn muốn giải phóng bộ nhớ không sử dụng, hãy sử dụng [`shrink_to_fit`] hoặc [`shrink_to`].
///
/// [`push`] và [`insert`] sẽ không bao giờ (lại) phân bổ nếu dung lượng được báo cáo là đủ.[`push`] và [`insert`]*sẽ*(lại) cấp phát nếu [`len`]`==`[`dung lượng`].Tức là dung lượng được báo cáo là hoàn toàn chính xác, có thể tin cậy được.Nó thậm chí có thể được sử dụng để giải phóng thủ công bộ nhớ được cấp phát bởi `Vec` nếu muốn.
/// Các phương thức chèn hàng loạt *có thể* phân bổ lại, ngay cả khi không cần thiết.
///
/// `Vec` không đảm bảo bất kỳ chiến lược tăng trưởng cụ thể nào khi phân bổ lại khi đầy, cũng như khi [`reserve`] được gọi.Chiến lược hiện tại là cơ bản và nó có thể chứng tỏ mong muốn sử dụng hệ số tăng trưởng không đổi.Dù sử dụng chiến lược nào, tất nhiên sẽ đảm bảo *O*(1) [`push`] được phân bổ.
///
/// `vec![x; n]`, `vec![a, b, c, d]` và [`Vec::with_capacity(n)`][`Vec::with_capacity`], tất cả sẽ tạo ra `Vec` với công suất chính xác được yêu cầu.
/// Nếu [`len`]`==`[`dung lượng`], (như trường hợp của macro [`vec!`]), thì `Vec<T>` có thể được chuyển đổi thành và từ [`Box<[T]>`][owned slice] mà không cần phân bổ lại hoặc di chuyển các phần tử.
///
/// `Vec` sẽ không ghi đè cụ thể bất kỳ dữ liệu nào bị xóa khỏi dữ liệu đó, nhưng cũng sẽ không lưu giữ cụ thể dữ liệu đó.Bộ nhớ chưa được khởi tạo của nó là khoảng trống mà nó có thể sử dụng theo cách nào nó muốn.Nói chung, nó sẽ chỉ làm bất cứ điều gì hiệu quả nhất hoặc dễ thực hiện.Không dựa vào dữ liệu đã xóa để xóa vì mục đích bảo mật.
/// Ngay cả khi bạn đánh rơi `Vec`, bộ đệm của nó có thể được sử dụng lại bởi một `Vec` khác.
/// Ngay cả khi bạn không có bộ nhớ của `Vec` trước, điều đó có thể không thực sự xảy ra vì trình tối ưu hóa không coi đây là một tác dụng phụ cần được bảo tồn.
/// Tuy nhiên, có một trường hợp mà chúng tôi sẽ không phá vỡ: sử dụng mã `unsafe` để ghi vào dung lượng vượt quá, và sau đó tăng độ dài để phù hợp, luôn luôn hợp lệ.
///
/// Hiện tại, `Vec` không đảm bảo thứ tự loại bỏ các phần tử.
/// Thứ tự đã thay đổi trong quá khứ và có thể thay đổi lại.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Phương pháp kế thừa
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Tạo một `Vec<T>` mới, trống.
    ///
    /// vector sẽ không phân bổ cho đến khi các phần tử được đẩy lên nó.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Tạo một `Vec<T>` mới, trống với dung lượng được chỉ định.
    ///
    /// vector sẽ có thể giữ chính xác các phần tử `capacity` mà không cần phân bổ lại.
    /// Nếu `capacity` là 0, vector sẽ không phân bổ.
    ///
    /// Điều quan trọng cần lưu ý là mặc dù vector trả về có *dung lượng* được chỉ định, vector sẽ có không *chiều dài*.
    ///
    /// Để biết giải thích về sự khác biệt giữa độ dài và dung lượng, hãy xem *[Dung lượng và phân bổ lại]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector không chứa mục nào, mặc dù nó có khả năng chứa nhiều hơn
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Tất cả đều được thực hiện mà không cần phân bổ lại ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... nhưng điều này có thể làm cho vector phân bổ lại
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Tạo `Vec<T>` trực tiếp từ các thành phần thô của vector khác.
    ///
    /// # Safety
    ///
    /// Điều này rất không an toàn, do số lượng bất biến không được kiểm tra:
    ///
    /// * `ptr` cần phải được cấp phát trước đó qua [`String`]/`Vec<T>`(ít nhất, nó rất có khả năng không chính xác nếu không).
    /// * `T` cần phải có cùng kích thước và sự liên kết như những gì `ptr` đã được phân bổ.
    ///   (`T` có một căn chỉnh ít chặt chẽ hơn là không đủ, căn chỉnh thực sự cần phải bằng nhau để đáp ứng yêu cầu của [`dealloc`] rằng bộ nhớ phải được cấp phát và giải quyết với cùng một bố cục.)
    ///
    /// * `length` cần nhỏ hơn hoặc bằng `capacity`.
    /// * `capacity` cần phải là dung lượng mà con trỏ đã được cấp phát.
    ///
    /// Vi phạm những điều này có thể gây ra các vấn đề như làm hỏng cấu trúc dữ liệu nội bộ của trình cấp phát.Ví dụ:**không** an toàn khi xây dựng `Vec<u8>` từ một con trỏ đến một mảng C `char` với độ dài `size_t`.
    /// Cũng không an toàn khi xây dựng một cái từ `Vec<u16>` và độ dài của nó, bởi vì trình phân bổ quan tâm đến sự liên kết và hai loại này có những căn chỉnh khác nhau.
    /// Bộ đệm đã được phân bổ với căn chỉnh 2 (cho `u16`), nhưng sau khi biến nó thành `Vec<u8>`, nó sẽ được phân bổ với căn chỉnh 1.
    ///
    /// Quyền sở hữu của `ptr` được chuyển một cách hiệu quả sang `Vec<T>`, sau đó có thể phân bổ, phân bổ lại hoặc thay đổi nội dung của bộ nhớ được con trỏ trỏ đến theo ý muốn.
    /// Đảm bảo rằng không có gì khác sử dụng con trỏ sau khi gọi hàm này.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Cập nhật điều này khi vec_into_raw_parts được ổn định.
    ///     // Ngăn chặn chạy trình hủy của `v` để chúng tôi hoàn toàn kiểm soát việc cấp phát.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Lấy ra các phần thông tin quan trọng khác nhau về `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Ghi đè bộ nhớ với 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Kết hợp mọi thứ lại với nhau thành một Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Tạo một `Vec<T, A>` mới, trống.
    ///
    /// vector sẽ không phân bổ cho đến khi các phần tử được đẩy lên nó.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Tạo một `Vec<T, A>` mới, trống với dung lượng được chỉ định với bộ cấp phát được cung cấp.
    ///
    /// vector sẽ có thể giữ chính xác các phần tử `capacity` mà không cần phân bổ lại.
    /// Nếu `capacity` là 0, vector sẽ không phân bổ.
    ///
    /// Điều quan trọng cần lưu ý là mặc dù vector trả về có *dung lượng* được chỉ định, vector sẽ có không *chiều dài*.
    ///
    /// Để biết giải thích về sự khác biệt giữa độ dài và dung lượng, hãy xem *[Dung lượng và phân bổ lại]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector không chứa mục nào, mặc dù nó có khả năng chứa nhiều hơn
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Tất cả đều được thực hiện mà không cần phân bổ lại ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... nhưng điều này có thể làm cho vector phân bổ lại
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Tạo `Vec<T, A>` trực tiếp từ các thành phần thô của vector khác.
    ///
    /// # Safety
    ///
    /// Điều này rất không an toàn, do số lượng bất biến không được kiểm tra:
    ///
    /// * `ptr` cần phải được cấp phát trước đó qua [`String`]/`Vec<T>`(ít nhất, nó rất có khả năng không chính xác nếu không).
    /// * `T` cần phải có cùng kích thước và sự liên kết như những gì `ptr` đã được phân bổ.
    ///   (`T` có một căn chỉnh ít chặt chẽ hơn là không đủ, căn chỉnh thực sự cần phải bằng nhau để đáp ứng yêu cầu của [`dealloc`] rằng bộ nhớ phải được cấp phát và giải quyết với cùng một bố cục.)
    ///
    /// * `length` cần nhỏ hơn hoặc bằng `capacity`.
    /// * `capacity` cần phải là dung lượng mà con trỏ đã được cấp phát.
    ///
    /// Vi phạm những điều này có thể gây ra các vấn đề như làm hỏng cấu trúc dữ liệu nội bộ của trình cấp phát.Ví dụ:**không** an toàn khi xây dựng `Vec<u8>` từ một con trỏ đến một mảng C `char` với độ dài `size_t`.
    /// Cũng không an toàn khi xây dựng một cái từ `Vec<u16>` và độ dài của nó, bởi vì trình phân bổ quan tâm đến sự liên kết và hai loại này có những căn chỉnh khác nhau.
    /// Bộ đệm đã được phân bổ với căn chỉnh 2 (cho `u16`), nhưng sau khi biến nó thành `Vec<u8>`, nó sẽ được phân bổ với căn chỉnh 1.
    ///
    /// Quyền sở hữu của `ptr` được chuyển một cách hiệu quả sang `Vec<T>`, sau đó có thể phân bổ, phân bổ lại hoặc thay đổi nội dung của bộ nhớ được con trỏ trỏ đến theo ý muốn.
    /// Đảm bảo rằng không có gì khác sử dụng con trỏ sau khi gọi hàm này.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Cập nhật điều này khi vec_into_raw_parts được ổn định.
    ///     // Ngăn chặn chạy trình hủy của `v` để chúng tôi hoàn toàn kiểm soát việc cấp phát.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Lấy ra các phần thông tin quan trọng khác nhau về `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Ghi đè bộ nhớ với 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Kết hợp mọi thứ lại với nhau thành một Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Phân hủy `Vec<T>` thành các thành phần thô của nó.
    ///
    /// Trả về con trỏ thô cho dữ liệu cơ bản, độ dài của vector (trong phần tử) và dung lượng được phân bổ của dữ liệu (trong phần tử).
    /// Đây là các đối số giống nhau theo cùng thứ tự với các đối số đối với [`from_raw_parts`].
    ///
    /// Sau khi gọi hàm này, người gọi phải chịu trách nhiệm về bộ nhớ mà `Vec` quản lý trước đó.
    /// Cách duy nhất để làm điều này là chuyển đổi con trỏ thô, độ dài và dung lượng trở lại thành `Vec` với chức năng [`from_raw_parts`], cho phép trình hủy thực hiện dọn dẹp.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Bây giờ chúng tôi có thể thực hiện các thay đổi đối với các thành phần, chẳng hạn như chuyển con trỏ thô sang một loại tương thích.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Phân hủy `Vec<T>` thành các thành phần thô của nó.
    ///
    /// Trả về con trỏ thô cho dữ liệu cơ bản, độ dài của vector (trong phần tử), dung lượng được phân bổ của dữ liệu (trong phần tử) và trình cấp phát.
    /// Đây là các đối số giống nhau theo cùng thứ tự với các đối số đối với [`from_raw_parts_in`].
    ///
    /// Sau khi gọi hàm này, người gọi phải chịu trách nhiệm về bộ nhớ mà `Vec` quản lý trước đó.
    /// Cách duy nhất để làm điều này là chuyển đổi con trỏ thô, độ dài và dung lượng trở lại thành `Vec` với chức năng [`from_raw_parts_in`], cho phép trình hủy thực hiện dọn dẹp.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Bây giờ chúng tôi có thể thực hiện các thay đổi đối với các thành phần, chẳng hạn như chuyển con trỏ thô sang một loại tương thích.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Trả về số phần tử mà vector có thể giữ mà không cần phân bổ lại.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Dự trữ dung lượng cho ít nhất `additional` nhiều phần tử hơn sẽ được chèn vào `Vec<T>` đã cho.
    /// Bộ sưu tập có thể dành thêm không gian để tránh tái phân bổ thường xuyên.
    /// Sau khi gọi `reserve`, dung lượng sẽ lớn hơn hoặc bằng `self.len() + additional`.
    /// Không có gì nếu năng lực đã đủ.
    ///
    /// # Panics
    ///
    /// Panics nếu dung lượng mới vượt quá `isize::MAX` byte.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Dành riêng dung lượng tối thiểu cho chính xác `additional` nhiều phần tử hơn sẽ được chèn vào `Vec<T>` đã cho.
    ///
    /// Sau khi gọi `reserve_exact`, dung lượng sẽ lớn hơn hoặc bằng `self.len() + additional`.
    /// Không có gì nếu dung lượng đã đủ.
    ///
    /// Lưu ý rằng bộ phân bổ có thể cung cấp cho bộ sưu tập nhiều không gian hơn nó yêu cầu.
    /// Do đó, không thể dựa vào dung lượng để được chính xác là tối thiểu.
    /// Ưu tiên `reserve` nếu mong đợi chèn future.
    ///
    /// # Panics
    ///
    /// Panics nếu dung lượng mới tràn `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Cố gắng dự trữ dung lượng cho ít nhất `additional` nhiều phần tử hơn sẽ được chèn vào `Vec<T>` đã cho.
    /// Bộ sưu tập có thể dành thêm không gian để tránh tái phân bổ thường xuyên.
    /// Sau khi gọi `try_reserve`, dung lượng sẽ lớn hơn hoặc bằng `self.len() + additional`.
    /// Không có gì nếu năng lực đã đủ.
    ///
    /// # Errors
    ///
    /// Nếu dung lượng bị tràn hoặc trình cấp phát báo lỗi, thì lỗi sẽ được trả về.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Đặt trước bộ nhớ, thoát ra nếu chúng ta không thể
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Bây giờ chúng tôi biết điều này không thể OOM giữa công việc phức tạp của chúng tôi
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // rất phức tạp
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Cố gắng dự trữ dung lượng tối thiểu cho chính xác các phần tử `additional` sẽ được chèn vào `Vec<T>` đã cho.
    /// Sau khi gọi `try_reserve_exact`, dung lượng sẽ lớn hơn hoặc bằng `self.len() + additional` nếu nó trả về `Ok(())`.
    ///
    /// Không có gì nếu dung lượng đã đủ.
    ///
    /// Lưu ý rằng bộ phân bổ có thể cung cấp cho bộ sưu tập nhiều không gian hơn nó yêu cầu.
    /// Do đó, không thể dựa vào dung lượng để được chính xác là tối thiểu.
    /// Ưu tiên `reserve` nếu mong đợi chèn future.
    ///
    /// # Errors
    ///
    /// Nếu dung lượng bị tràn hoặc trình cấp phát báo lỗi, thì lỗi sẽ được trả về.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Đặt trước bộ nhớ, thoát ra nếu chúng ta không thể
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Bây giờ chúng tôi biết điều này không thể OOM giữa công việc phức tạp của chúng tôi
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // rất phức tạp
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Thu hẹp công suất của vector càng nhiều càng tốt.
    ///
    /// Nó sẽ thả xuống gần với độ dài nhất có thể nhưng bộ cấp phát vẫn có thể thông báo cho vector rằng có không gian cho một vài phần tử nữa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Dung lượng không bao giờ nhỏ hơn chiều dài và không có gì phải làm khi chúng bằng nhau, vì vậy chúng ta có thể tránh trường hợp panic trong `RawVec::shrink_to_fit` bằng cách chỉ gọi nó với công suất lớn hơn.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Thu hẹp dung lượng của vector với giới hạn thấp hơn.
    ///
    /// Dung lượng ít nhất sẽ vẫn lớn bằng cả chiều dài và giá trị được cung cấp.
    ///
    ///
    /// Nếu dung lượng hiện tại nhỏ hơn giới hạn dưới, đây là điều không nên.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Chuyển đổi vector thành [`Box<[T]>`][owned slice].
    ///
    /// Lưu ý rằng điều này sẽ làm giảm bất kỳ dung lượng dư thừa nào.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Mọi dung lượng dư thừa đều bị loại bỏ:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Rút ngắn vector, giữ lại các phần tử `len` đầu tiên và loại bỏ phần còn lại.
    ///
    /// Nếu `len` lớn hơn độ dài hiện tại của vector, điều này không có tác dụng.
    ///
    /// Phương thức [`drain`] có thể mô phỏng `truncate`, nhưng khiến các phần tử thừa được trả về thay vì bị loại bỏ.
    ///
    ///
    /// Lưu ý rằng phương pháp này không ảnh hưởng đến dung lượng được phân bổ của vector.
    ///
    /// # Examples
    ///
    /// Cắt ngắn năm phần tử vector thành hai phần tử:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Không có sự cắt ngắn nào xảy ra khi `len` lớn hơn độ dài hiện tại của vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Việc cắt bớt khi `len == 0` tương đương với việc gọi phương thức [`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Điều này là an toàn vì:
        //
        // * Slice được chuyển đến `drop_in_place` là hợp lệ;trường hợp `len > self.len` tránh tạo một lát cắt không hợp lệ và
        // * `len` của vector được thu nhỏ trước khi gọi `drop_in_place`, sao cho không có giá trị nào bị giảm hai lần trong trường hợp `drop_in_place` đến panic một lần (nếu panics hai lần, chương trình sẽ hủy bỏ).
        //
        //
        //
        unsafe {
            // Note: Có chủ ý rằng đây là `>` chứ không phải `>=`.
            //       Thay đổi nó thành `>=` có tác động tiêu cực đến hiệu suất trong một số trường hợp.
            //       Xem #78884 để biết thêm.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Trích xuất một lát chứa toàn bộ vector.
    ///
    /// Tương đương với `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Trích xuất một lát có thể thay đổi của toàn bộ vector.
    ///
    /// Tương đương với `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Trả về một con trỏ thô vào bộ đệm của vector.
    ///
    /// Người gọi phải đảm bảo rằng vector tồn tại lâu hơn con trỏ mà hàm này trả về, nếu không, nó sẽ kết thúc trỏ đến rác.
    /// Việc sửa đổi vector có thể khiến bộ đệm của nó bị phân bổ lại, điều này cũng sẽ làm cho bất kỳ con trỏ nào đến nó không hợp lệ.
    ///
    /// Người gọi cũng phải đảm bảo rằng bộ nhớ mà con trỏ (non-transitively) trỏ tới không bao giờ được ghi vào (ngoại trừ bên trong `UnsafeCell`) bằng cách sử dụng con trỏ này hoặc bất kỳ con trỏ nào xuất phát từ nó.
    /// Nếu bạn cần thay đổi nội dung của lát cắt, hãy sử dụng [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Chúng tôi phủ bóng phương thức lát cắt cùng tên để tránh đi qua `deref`, phương thức này tạo ra một tham chiếu trung gian.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Trả về một con trỏ có thể thay đổi không an toàn vào bộ đệm của vector.
    ///
    /// Người gọi phải đảm bảo rằng vector tồn tại lâu hơn con trỏ mà hàm này trả về, nếu không, nó sẽ kết thúc trỏ đến rác.
    ///
    /// Việc sửa đổi vector có thể khiến bộ đệm của nó bị phân bổ lại, điều này cũng sẽ làm cho bất kỳ con trỏ nào đến nó không hợp lệ.
    ///
    /// # Examples
    ///
    /// ```
    /// // Phân bổ vector đủ lớn cho 4 phần tử.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Khởi tạo các phần tử thông qua ghi con trỏ thô, sau đó đặt độ dài.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Chúng tôi phủ bóng phương thức lát cắt cùng tên để tránh đi qua `deref_mut`, phương thức này tạo ra một tham chiếu trung gian.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Trả về một tham chiếu đến trình phân bổ cơ bản.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Buộc chiều dài của vector thành `new_len`.
    ///
    /// Đây là một hoạt động cấp thấp duy trì không có bất biến bình thường nào của kiểu này.
    /// Thông thường, việc thay đổi độ dài của vector được thực hiện bằng cách sử dụng một trong các thao tác an toàn, chẳng hạn như [`truncate`], [`resize`], [`extend`] hoặc [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` phải nhỏ hơn hoặc bằng [`capacity()`].
    /// - Các phần tử tại `old_len..new_len` phải được khởi tạo.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Phương pháp này có thể hữu ích cho các tình huống trong đó vector đang phục vụ như một bộ đệm cho mã khác, đặc biệt là trên FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Đây chỉ là một khung tối thiểu cho ví dụ doc;
    /// # // không sử dụng điều này như một điểm khởi đầu cho một thư viện thực.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Theo tài liệu của phương pháp FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // AN TOÀN: Khi `deflateGetDictionary` trả về `Z_OK`, nó lưu ý rằng:
    ///     // 1. `dict_length` các phần tử đã được khởi tạo.
    ///     // 2.
    ///     // `dict_length` <=dung lượng (32_768) làm cho `set_len` an toàn để gọi.
    ///     unsafe {
    ///         // Thực hiện cuộc gọi FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... và cập nhật độ dài thành những gì đã được khởi tạo.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Trong khi ví dụ sau là âm thanh, có một rò rỉ bộ nhớ vì vectors bên trong không được giải phóng trước cuộc gọi `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` rỗng nên không cần khởi tạo phần tử.
    /// // 2. `0 <= capacity` luôn giữ bất cứ điều gì `capacity`.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Thông thường, ở đây, người ta sẽ sử dụng [`clear`] để thay thế chính xác nội dung và do đó không làm rò rỉ bộ nhớ.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Xóa một phần tử khỏi vector và trả về nó.
    ///
    /// Phần tử bị loại bỏ được thay thế bằng phần tử cuối cùng của vector.
    ///
    /// Điều này không bảo toàn thứ tự, nhưng là O(1).
    ///
    /// # Panics
    ///
    /// Panics nếu `index` nằm ngoài giới hạn.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Chúng tôi thay thế self [index] bằng phần tử cuối cùng.
            // Lưu ý rằng nếu việc kiểm tra giới hạn ở trên thành công thì phải có một phần tử cuối cùng (có thể là bản thân [chỉ mục]).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Chèn một phần tử ở vị trí `index` trong vector, dịch chuyển tất cả các phần tử sau nó sang bên phải.
    ///
    ///
    /// # Panics
    ///
    /// Panics nếu `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // không gian cho phần tử mới
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // không thể sai lầm Vị trí để đặt giá trị mới
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Thay đổi mọi thứ để tạo khoảng trống.
                // (Sao chép phần tử thứ `chỉ mục` thành hai vị trí liên tiếp.)
                ptr::copy(p, p.offset(1), len - index);
                // Viết nó vào, ghi đè lên bản sao đầu tiên của phần tử `chỉ mục`.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Loại bỏ và trả về phần tử ở vị trí `index` trong vector, dịch chuyển tất cả các phần tử sau nó sang trái.
    ///
    ///
    /// # Panics
    ///
    /// Panics nếu `index` nằm ngoài giới hạn.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // nơi chúng tôi đang đi từ.
                let ptr = self.as_mut_ptr().add(index);
                // sao chép nó ra ngoài, một cách an toàn khi có một bản sao của giá trị trên ngăn xếp và trong vector cùng một lúc.
                //
                ret = ptr::read(ptr);

                // Chuyển mọi thứ xuống để điền vào chỗ đó.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Chỉ giữ lại các phần tử được chỉ định bởi vị từ.
    ///
    /// Nói cách khác, loại bỏ tất cả các phần tử `e` để `f(&e)` trả về `false`.
    /// Phương thức này hoạt động tại chỗ, truy cập chính xác từng phần tử một lần theo thứ tự ban đầu và bảo toàn thứ tự của các phần tử được giữ lại.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Bởi vì các phần tử được truy cập chính xác một lần theo thứ tự ban đầu, trạng thái bên ngoài có thể được sử dụng để quyết định phần tử nào cần giữ lại.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Tránh thả hai lần nếu bộ bảo vệ thả không được thực hiện, vì chúng tôi có thể tạo ra một số lỗ hổng trong quá trình này.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-đã xử lý len-> |^-tiếp theo để kiểm tra
        //                  | <-đã xóa cnt-> |
        //      | <-original_len-> |Kept: Các phần tử mà vị từ trả về true trên.
        //
        // Lỗ: Đã di chuyển hoặc thả khe phần tử.
        // Bỏ chọn: Bỏ chọn các phần tử hợp lệ.
        //
        // Bảo vệ thả này sẽ được gọi khi vị từ hoặc `drop` của phần tử bị hoảng loạn.
        // Nó dịch chuyển các phần tử không được kiểm tra để che các lỗ và `set_len` theo chiều dài chính xác.
        // Trong trường hợp khi vị từ và `drop` không bao giờ hoảng loạn, nó sẽ được tối ưu hóa.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // AN TOÀN: Các mục không được chọn theo dõi phải hợp lệ vì chúng tôi không bao giờ chạm vào chúng.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // AN TOÀN: Sau khi lấp đầy các lỗ, tất cả các mục đều nằm trong bộ nhớ liền kề.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // AN TOÀN: Phần tử không được chọn phải hợp lệ.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Tiến hành sớm để tránh giảm gấp đôi nếu `drop_in_place` hoảng loạn.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // AN TOÀN: Chúng tôi không bao giờ chạm vào phần tử này nữa sau khi bị rơi.
                unsafe { ptr::drop_in_place(cur) };
                // Chúng tôi đã nâng cao bộ đếm.
                continue;
            }
            if g.deleted_cnt > 0 {
                // AN TOÀN: `deleted_cnt`> 0, do đó rãnh lỗ không được chồng lên phần tử hiện tại.
                // Chúng tôi sử dụng bản sao để di chuyển và không bao giờ chạm vào phần tử này nữa.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Tất cả các mục đã được xử lý.Điều này có thể được tối ưu hóa thành `set_len` bằng LLVM.
        drop(g);
    }

    /// Loại bỏ tất cả trừ phần tử đầu tiên của các phần tử liên tiếp trong vector phân giải thành cùng một khóa.
    ///
    ///
    /// Nếu vector được sắp xếp, điều này sẽ loại bỏ tất cả các bản sao.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Loại bỏ tất cả trừ phần tử đầu tiên của các phần tử liên tiếp trong vector thỏa mãn một quan hệ bình đẳng nhất định.
    ///
    /// Hàm `same_bucket` được chuyển tham chiếu đến hai phần tử từ vector và phải xác định xem các phần tử so sánh có bằng nhau hay không.
    /// Các phần tử được chuyển theo thứ tự ngược lại với thứ tự của chúng trong lát, vì vậy nếu `same_bucket(a, b)` trả về `true`, `a` sẽ bị loại bỏ.
    ///
    ///
    /// Nếu vector được sắp xếp, điều này sẽ loại bỏ tất cả các bản sao.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Thêm một phần tử vào mặt sau của một tập hợp.
    ///
    /// # Panics
    ///
    /// Panics nếu dung lượng mới vượt quá `isize::MAX` byte.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Điều này sẽ panic hoặc hủy bỏ nếu chúng ta phân bổ> isize::MAX byte hoặc nếu độ dài tăng dần cho các loại có kích thước bằng không.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Loại bỏ phần tử cuối cùng khỏi vector và trả về nó, hoặc [`None`] nếu nó trống.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Di chuyển tất cả các phần tử của `other` vào `Self`, để trống `other`.
    ///
    /// # Panics
    ///
    /// Panics nếu số phần tử trong vector vượt quá một `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Thêm các phần tử vào `Self` từ bộ đệm khác.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Tạo một trình lặp thoát nước loại bỏ phạm vi được chỉ định trong vector và mang lại các mục đã loại bỏ.
    ///
    /// Khi trình vòng lặp **bị xóa**, tất cả các phần tử trong phạm vi sẽ bị xóa khỏi vector, ngay cả khi trình vòng lặp không được sử dụng hoàn toàn.
    /// Nếu trình lặp **không** bị loại bỏ (với [`mem::forget`] chẳng hạn), thì không xác định được có bao nhiêu phần tử bị loại bỏ.
    ///
    /// # Panics
    ///
    /// Panics nếu điểm đầu lớn hơn điểm cuối hoặc nếu điểm cuối lớn hơn độ dài của vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Một dải đầy đủ xóa vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // An toàn bộ nhớ
        //
        // Khi Drain lần đầu tiên được tạo, nó sẽ rút ngắn độ dài của nguồn vector để đảm bảo rằng không có phần tử nào chưa được khởi tạo hoặc chuyển từ có thể truy cập được nếu trình hủy của Drain không bao giờ chạy.
        //
        //
        // Drain sẽ ptr::read các giá trị cần xóa.
        // Khi hoàn thành, phần đuôi còn lại của vec được sao chép lại để che lỗ và chiều dài vector được khôi phục thành chiều dài mới.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // đặt độ dài self.vec để bắt đầu, để an toàn trong trường hợp Drain bị rò rỉ
            self.set_len(start);
            // Sử dụng sự vay mượn trong IterMut để chỉ ra hành vi vay mượn của toàn bộ trình lặp Drain (như &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Xóa vector, xóa tất cả các giá trị.
    ///
    /// Lưu ý rằng phương pháp này không ảnh hưởng đến dung lượng được phân bổ của vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Trả về số phần tử trong vector, còn được gọi là 'length' của nó.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Trả về `true` nếu vector không chứa phần tử nào.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Tách tập hợp thành hai tại chỉ mục đã cho.
    ///
    /// Trả về vector mới được cấp phát có chứa các phần tử trong phạm vi `[at, len)`.
    /// Sau cuộc gọi, vector ban đầu sẽ được để lại chứa các phần tử `[0, at)` với dung lượng trước đó không thay đổi.
    ///
    ///
    /// # Panics
    ///
    /// Panics nếu `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // vector mới có thể tiếp quản bộ đệm gốc và tránh sao chép
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // `set_len` không an toàn và sao chép các mục sang `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Thay đổi kích thước của `Vec` tại chỗ để `len` bằng `new_len`.
    ///
    /// Nếu `new_len` lớn hơn `len`, `Vec` được mở rộng bởi sự khác biệt, với mỗi vị trí bổ sung được lấp đầy với kết quả của việc gọi đóng `f`.
    ///
    /// Các giá trị trả về từ `f` sẽ kết thúc trong `Vec` theo thứ tự chúng đã được tạo.
    ///
    /// Nếu `new_len` nhỏ hơn `len`, thì `Vec` chỉ đơn giản là bị cắt bớt.
    ///
    /// Phương pháp này sử dụng một bao đóng để tạo các giá trị mới trên mỗi lần đẩy.Nếu bạn muốn [`Clone`] một giá trị nhất định, hãy sử dụng [`Vec::resize`].
    /// Nếu bạn muốn sử dụng [`Default`] trait để tạo giá trị, bạn có thể chuyển [`Default::default`] làm đối số thứ hai.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Tiêu thụ và làm rò rỉ `Vec`, trả về một tham chiếu có thể thay đổi cho nội dung, `&'a mut [T]`.
    /// Lưu ý rằng loại `T` phải tồn tại lâu hơn `'a` thời gian tồn tại đã chọn.
    /// Nếu kiểu chỉ có tham chiếu tĩnh hoặc không có tham chiếu nào, thì kiểu này có thể được chọn là `'static`.
    ///
    /// Chức năng này tương tự như chức năng [`leak`][Box::leak] trên [`Box`] ngoại trừ việc không có cách nào để khôi phục bộ nhớ bị rò rỉ.
    ///
    ///
    /// Chức năng này chủ yếu hữu ích cho dữ liệu tồn tại trong thời gian còn lại của chương trình.
    /// Bỏ tham chiếu trả về sẽ gây ra rò rỉ bộ nhớ.
    ///
    /// # Examples
    ///
    /// Cách sử dụng đơn giản:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Trả về dung lượng dự phòng còn lại của vector dưới dạng một phần của `MaybeUninit<T>`.
    ///
    /// Slice trả về có thể được sử dụng để lấp đầy dữ liệu vector (ví dụ:
    /// bằng cách đọc từ một tệp) trước khi đánh dấu dữ liệu là đã khởi tạo bằng phương pháp [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Phân bổ vector đủ lớn cho 10 phần tử.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Điền vào 3 yếu tố đầu tiên.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Đánh dấu 3 phần tử đầu tiên của vector là đã được khởi tạo.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Phương pháp này không được thực hiện đối với `split_at_spare_mut`, để ngăn chặn sự vô hiệu của các con trỏ tới bộ đệm.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Trả về nội dung vector dưới dạng một phần của `T`, cùng với dung lượng dự phòng còn lại của vector dưới dạng một phần của `MaybeUninit<T>`.
    ///
    /// Phần dung lượng dự phòng trả về có thể được sử dụng để lấp đầy vector với dữ liệu (ví dụ bằng cách đọc từ một tệp) trước khi đánh dấu dữ liệu là đã khởi tạo bằng phương pháp [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Lưu ý rằng đây là một API cấp thấp, cần được sử dụng cẩn thận cho các mục đích tối ưu hóa.
    /// Nếu bạn cần nối dữ liệu vào `Vec`, bạn có thể sử dụng [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] hoặc [`resize_with`], tùy thuộc vào nhu cầu chính xác của bạn.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Dành thêm không gian đủ lớn cho 10 phần tử.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Điền vào 4 yếu tố tiếp theo.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Đánh dấu 4 phần tử của vector là đã được khởi tạo.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len bị bỏ qua và vì vậy không bao giờ thay đổi
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// An toàn: thay đổi trả về .2 (kích thước &mut) được coi là giống như gọi `.set_len(_)`.
    ///
    /// Phương thức này được sử dụng để có quyền truy cập duy nhất vào tất cả các phần vec cùng một lúc trong `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` được đảm bảo hợp lệ cho các phần tử `len`
        // - `spare_ptr` đang trỏ một phần tử qua bộ đệm, vì vậy nó không trùng lặp với `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Thay đổi kích thước của `Vec` tại chỗ để `len` bằng `new_len`.
    ///
    /// Nếu `new_len` lớn hơn `len`, thì `Vec` được mở rộng bởi sự khác biệt, với mỗi vị trí bổ sung được lấp đầy bằng `value`.
    ///
    /// Nếu `new_len` nhỏ hơn `len`, thì `Vec` chỉ đơn giản là bị cắt bớt.
    ///
    /// Phương thức này yêu cầu `T` triển khai [`Clone`] để có thể sao chép giá trị đã truyền.
    /// Nếu bạn cần linh hoạt hơn (hoặc muốn dựa vào [`Default`] thay vì [`Clone`]), hãy sử dụng [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Sao chép và nối tất cả các phần tử trong một lát vào `Vec`.
    ///
    /// Lặp lại lát cắt `other`, sao chép từng phần tử, sau đó gắn nó vào `Vec` này.
    /// `other` vector được duyệt theo thứ tự.
    ///
    /// Lưu ý rằng chức năng này giống như [`extend`] ngoại trừ việc nó được chuyên dụng để làm việc với các lát cắt thay thế.
    ///
    /// Nếu và khi Rust được chuyên môn hóa, chức năng này có thể sẽ không được dùng nữa (nhưng vẫn khả dụng).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Sao chép các phần tử từ phạm vi `src` đến cuối vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` đảm bảo rằng phạm vi đã cho hợp lệ để tự lập chỉ mục
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Mã này tổng quát hóa `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Mở rộng giá trị vector thêm `n`, sử dụng trình tạo đã cho.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Sử dụng SetLenOnDrop để khắc phục lỗi trong đó trình biên dịch có thể không nhận ra cửa hàng thông qua `ptr` thông qua self.set_len() không có bí danh.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Viết tất cả các phần tử ngoại trừ phần tử cuối cùng
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Tăng chiều dài trong mỗi bước trong trường hợp next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Chúng ta có thể viết trực tiếp phần tử cuối cùng mà không cần sao chép
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len được thiết lập bởi bảo vệ phạm vi
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Loại bỏ các phần tử lặp lại liên tiếp trong vector theo triển khai [`PartialEq`] trait.
    ///
    ///
    /// Nếu vector được sắp xếp, điều này sẽ loại bỏ tất cả các bản sao.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Các phương pháp và chức năng nội bộ
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` cần phải là chỉ mục hợp lệ
    /// - `self.capacity() - self.len()` phải là `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len chỉ được tăng lên sau khi khởi tạo các phần tử
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - người gọi tin tưởng rằng src là một chỉ mục hợp lệ
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Phần tử vừa được khởi tạo với `MaybeUninit::write`, vì vậy bạn có thể tăng tốc độ len
            // - len được tăng lên sau mỗi phần tử để ngăn rò rỉ (xem vấn đề #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - người gọi tin tưởng rằng `src` là một chỉ mục hợp lệ
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Cả hai con trỏ đều được tạo từ các tham chiếu lát cắt duy nhất (`&mut [_]`) nên chúng hợp lệ và không trùng lặp.
            //
            // - Các yếu tố là: Sao chép để có thể sao chép chúng mà không cần làm gì với các giá trị gốc
            // - `count` bằng với len của `source`, vì vậy nguồn hợp lệ cho các lần đọc `count`
            // - `.reserve(count)` đảm bảo rằng `spare.len() >= count` để dự phòng là hợp lệ để ghi `count`
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Các phần tử vừa được khởi tạo bởi `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Triển khai trait phổ biến cho Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): với cfg(test), phương thức `[T]::to_vec` vốn có, được yêu cầu cho định nghĩa phương pháp này, không khả dụng.
    // Thay vào đó, hãy sử dụng chức năng `slice::to_vec` chỉ khả dụng với cfg(test) NB, hãy xem mô-đun slice::hack trong slice.rs để biết thêm thông tin
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // thả bất cứ thứ gì sẽ không bị ghi đè
        self.truncate(other.len());

        // self.len <= other.len do cắt ngắn ở trên, vì vậy các lát cắt ở đây luôn nằm trong giới hạn.
        //
        let (init, tail) = other.split_at(self.len());

        // sử dụng lại các giá trị chứa allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Tạo một trình lặp tiêu thụ, nghĩa là một trình lặp di chuyển từng giá trị ra khỏi vector (từ đầu đến cuối).
    /// vector không thể được sử dụng sau khi gọi nó.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s có loại Chuỗi, không phải &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // phương pháp lá mà các triển khai SpecFrom/SpecExtend khác nhau ủy quyền khi chúng không còn tối ưu hóa để áp dụng
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Đây là trường hợp của một trình lặp tổng quát.
        //
        // Chức năng này phải tương đương với đạo đức của:
        //
        //      cho mục trong trình lặp {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB không thể tràn vì chúng tôi sẽ phải phân bổ không gian địa chỉ
                self.set_len(len + 1);
            }
        }
    }

    /// Tạo một trình lặp nối thay thế phạm vi được chỉ định trong vector bằng trình lặp `replace_with` đã cho và mang lại các mục đã loại bỏ.
    ///
    /// `replace_with` không cần có cùng độ dài với `range`.
    ///
    /// `range` bị loại bỏ ngay cả khi trình lặp không được sử dụng cho đến khi kết thúc.
    ///
    /// Không xác định có bao nhiêu phần tử bị xóa khỏi vector nếu giá trị `Splice` bị rò rỉ.
    ///
    /// Trình lặp đầu vào `replace_with` chỉ được sử dụng khi giá trị `Splice` bị giảm xuống.
    ///
    /// Điều này là tối ưu nếu:
    ///
    /// * Phần đuôi (các phần tử trong vector sau `range`) trống,
    /// * hoặc `replace_with` mang lại ít phần tử hơn hoặc bằng chiều dài của `phạm vi`
    /// * hoặc giới hạn dưới của `size_hint()` là chính xác.
    ///
    /// Nếu không, một vector tạm thời được cấp phát và phần đuôi được di chuyển hai lần.
    ///
    /// # Panics
    ///
    /// Panics nếu điểm đầu lớn hơn điểm cuối hoặc nếu điểm cuối lớn hơn độ dài của vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Tạo một trình lặp sử dụng bao đóng để xác định xem có nên xóa một phần tử hay không.
    ///
    /// Nếu bao đóng trả về true, thì phần tử sẽ bị loại bỏ và mang lại kết quả.
    /// Nếu bao đóng trả về false, phần tử sẽ vẫn nằm trong vector và sẽ không được cấp bởi trình vòng lặp.
    ///
    /// Sử dụng phương pháp này tương đương với mã sau:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // mã của bạn ở đây
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Nhưng `drain_filter` dễ sử dụng hơn.
    /// `drain_filter` cũng hiệu quả hơn, vì nó có thể dịch ngược hàng loạt các phần tử của mảng.
    ///
    /// Lưu ý rằng `drain_filter` cũng cho phép bạn thay đổi mọi phần tử trong phần đóng bộ lọc, bất kể bạn chọn giữ hay loại bỏ nó.
    ///
    ///
    /// # Examples
    ///
    /// Chia một mảng thành các tỷ lệ và tỷ lệ cược, sử dụng lại phân bổ ban đầu:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Bảo vệ chống lại chúng tôi bị rò rỉ (khuếch đại rò rỉ)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Mở rộng triển khai sao chép các phần tử ra khỏi các tham chiếu trước khi đẩy chúng vào Vec.
///
/// Việc triển khai này chuyên dụng cho các trình vòng lặp lát cắt, nơi nó sử dụng [`copy_from_slice`] để nối toàn bộ lát cắt cùng một lúc.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// So sánh triển khai của vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Triển khai đặt hàng vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // sử dụng drop cho [T] sử dụng một lát thô để chỉ các phần tử của vector là loại cần thiết yếu nhất;
            //
            // có thể tránh các câu hỏi về tính hợp lệ trong một số trường hợp nhất định
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec xử lý phân bổ giao dịch
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Tạo một `Vec<T>` trống.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: kiểm tra kéo trong libstd, gây ra lỗi ở đây
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: kiểm tra kéo trong libstd, gây ra lỗi ở đây
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Nhận toàn bộ nội dung của `Vec<T>` dưới dạng một mảng, nếu kích thước của nó khớp chính xác với kích thước của mảng được yêu cầu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Nếu độ dài không khớp, đầu vào sẽ trở lại trong `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Nếu bạn ổn với việc chỉ lấy tiền tố của `Vec<T>`, bạn có thể gọi [`.truncate(N)`](Vec::truncate) trước.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // AN TOÀN: `.set_len(0)` luôn âm thanh.
        unsafe { vec.set_len(0) };

        // AN TOÀN: Con trỏ của `Vec` luôn được căn chỉnh đúng cách, và
        // sự liên kết mà mảng cần giống như các mục.
        // Chúng tôi đã kiểm tra trước đó rằng chúng tôi có đủ mặt hàng.
        // Các vật phẩm sẽ không bị rơi ra hai lần vì `set_len` yêu cầu `Vec` cũng không thả chúng xuống.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}