use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Một trình lặp sử dụng một bao đóng để xác định xem một phần tử có nên bị loại bỏ hay không.
///
/// Cấu trúc này được tạo bởi [`Vec::drain_filter`].
/// Xem tài liệu của nó để biết thêm.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// Chỉ mục của mặt hàng sẽ được kiểm tra trong lần gọi tiếp theo tới `next`.
    pub(super) idx: usize,
    /// Số lượng mục đã được rút hết (removed) cho đến nay.
    pub(super) del: usize,
    /// Chiều dài ban đầu của `vec` trước khi rút nước.
    pub(super) old_len: usize,
    /// Vị từ kiểm tra bộ lọc.
    pub(super) pred: F,
    /// Cờ cho biết panic đã xảy ra trong vị từ kiểm tra bộ lọc.
    /// Điều này được sử dụng như một gợi ý trong việc triển khai drop để ngăn chặn việc tiêu thụ phần còn lại của `DrainFilter`.
    /// Bất kỳ mục nào chưa được xử lý sẽ được dịch ngược lại trong `vec`, nhưng không có mục nào khác sẽ bị loại bỏ hoặc kiểm tra bởi vị từ bộ lọc.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Trả về một tham chiếu đến trình phân bổ cơ bản.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Cập nhật chỉ mục *sau khi* vị từ được gọi.
                // Nếu chỉ mục được cập nhật trước và vị từ panics, phần tử tại chỉ mục này sẽ bị rò rỉ.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // Đây là một trạng thái khá lộn xộn và không thực sự có một điều rõ ràng là đúng đắn để làm.
                        // Chúng tôi không muốn tiếp tục cố gắng thực thi `pred`, vì vậy chúng tôi chỉ cần dịch chuyển ngược lại tất cả các phần tử chưa được xử lý và nói với vec rằng chúng vẫn tồn tại.
                        //
                        // Cần phải có dịch chuyển ngược để ngăn chặn việc thả hai lần mục cuối cùng được rút cạn thành công trước panic trong vị từ.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Cố gắng sử dụng bất kỳ phần tử còn lại nào nếu vị từ bộ lọc vẫn chưa hoạt động.
        // Chúng tôi sẽ chuyển ngược lại bất kỳ yếu tố nào còn lại cho dù chúng tôi đã hoảng sợ hoặc nếu tiêu thụ ở đây panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}