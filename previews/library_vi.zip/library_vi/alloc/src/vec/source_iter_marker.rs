use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Điểm đánh dấu chuyên môn để thu thập một đường ống trình vòng lặp vào Vec trong khi sử dụng lại phân bổ nguồn, tức là
/// thi công đường ống tại chỗ.
///
/// Nguồn trait cha của SourceIter là cần thiết cho chức năng chuyên biệt để truy cập phân bổ sẽ được sử dụng lại.
/// Nhưng nó không đủ để chuyên ngành có giá trị.
/// Xem các giới hạn bổ sung về cấy ghép.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-nội bộ SourceIter/InPlaceIterable traits chỉ được thực hiện bởi chuỗi Bộ điều hợp <Adapter<Adapter<IntoIter>>> (tất cả đều thuộc sở hữu của core/std).
// Các giới hạn bổ sung đối với việc triển khai bộ điều hợp (ngoài `impl<I: Trait> Trait for Adapter<I>`) chỉ phụ thuộc vào traits khác đã được đánh dấu là chuyên môn hóa traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. điểm đánh dấu không phụ thuộc vào thời gian tồn tại của các loại do người dùng cung cấp.Modulo lỗ Sao chép, mà một số chuyên môn khác đã phụ thuộc vào.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Các yêu cầu bổ sung không thể thể hiện qua trait bounds.Thay vào đó, chúng tôi dựa vào const eval:
        // a) không có ZST vì sẽ không có phân bổ để sử dụng lại và số học con trỏ sẽ panic b) kích thước khớp theo yêu cầu của hợp đồng Alloc c) căn chỉnh khớp theo yêu cầu của hợp đồng Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // dự phòng cho các triển khai chung chung hơn
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // sử dụng try-fold kể từ
        // - nó vectơ hóa tốt hơn cho một số bộ điều hợp trình lặp
        // - không giống như hầu hết các phương pháp lặp lại nội bộ, nó chỉ mất một &mut tự
        // - nó cho phép chúng tôi xâu chuỗi con trỏ ghi qua các thứ tự bên trong của nó và cuối cùng lấy lại nó
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // lặp lại thành công, đừng bỏ qua
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // kiểm tra xem hợp đồng SourceIter có được duy trì hay không: nếu không, chúng tôi thậm chí có thể không thực hiện được đến thời điểm này
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // kiểm tra hợp đồng InPlaceIterable.Điều này chỉ có thể thực hiện được nếu trình lặp nâng cao con trỏ nguồn.
        // Nếu nó sử dụng quyền truy cập không được kiểm tra thông qua TrustedRandomAccess thì con trỏ nguồn sẽ ở lại vị trí ban đầu và chúng tôi không thể sử dụng nó làm tài liệu tham khảo
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // thả bất kỳ giá trị còn lại nào ở đuôi nguồn nhưng ngăn chặn việc giảm phân bổ chính nó khi IntoIter vượt ra khỏi phạm vi nếu thả panics thì chúng tôi cũng rò rỉ bất kỳ phần tử nào được thu thập vào dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // Hợp đồng InPlaceIterable không thể được xác minh chính xác tại đây vì try_fold có một tham chiếu độc quyền đến con trỏ nguồn, tất cả những gì chúng tôi có thể làm là kiểm tra xem nó có còn trong phạm vi không
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}