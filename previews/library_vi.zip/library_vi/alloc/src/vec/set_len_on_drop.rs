// Đặt độ dài của vec khi giá trị `SetLenOnDrop` vượt ra ngoài phạm vi.
//
// Ý tưởng là: Trường độ dài trong SetLenOnDrop là một biến cục bộ mà trình tối ưu hóa sẽ thấy không có bí danh với bất kỳ cửa hàng nào thông qua con trỏ dữ liệu của Vec.
// Đây là một giải pháp cho vấn đề phân tích bí danh #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}