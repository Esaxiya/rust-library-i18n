//! API cấp phát bộ nhớ

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Đây là những ký hiệu ma thuật để gọi trình phân bổ toàn cầu.rustc tạo ra chúng để gọi `__rg_alloc`, v.v.
    // nếu có thuộc tính `#[global_allocator]` (mã mở rộng macro thuộc tính đó sẽ tạo ra các hàm đó) hoặc để gọi các triển khai mặc định trong libstd (`__rdl_alloc`, v.v.
    //
    // trong `library/std/src/alloc.rs`) ngược lại.
    // rustc fork của LLVM cũng có các trường hợp đặc biệt là các tên hàm này để có thể tối ưu hóa chúng như `malloc`, `realloc` và `free`, tương ứng.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Bộ cấp phát bộ nhớ chung.
///
/// Kiểu này thực hiện [`Allocator`] trait bằng cách chuyển tiếp các cuộc gọi đến bộ cấp phát được đăng ký với thuộc tính `#[global_allocator]` nếu có hoặc thuộc tính mặc định của `std` crate.
///
///
/// Note: trong khi loại này không ổn định, chức năng mà nó cung cấp có thể được truy cập thông qua [free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Cấp phát bộ nhớ với trình cấp phát toàn cục.
///
/// Hàm này chuyển tiếp các cuộc gọi đến phương thức [`GlobalAlloc::alloc`] của bộ cấp phát được đăng ký với thuộc tính `#[global_allocator]` nếu có hoặc thuộc tính mặc định của `std` crate.
///
///
/// Chức năng này dự kiến sẽ không được dùng nữa để thay thế cho phương pháp `alloc` của loại [`Global`] khi nó và [`Allocator`] trait trở nên ổn định.
///
/// # Safety
///
/// Xem [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Phân bổ bộ nhớ với trình phân bổ toàn cục.
///
/// Hàm này chuyển tiếp các cuộc gọi đến phương thức [`GlobalAlloc::dealloc`] của bộ cấp phát được đăng ký với thuộc tính `#[global_allocator]` nếu có hoặc thuộc tính mặc định của `std` crate.
///
///
/// Chức năng này dự kiến sẽ không được dùng nữa để thay thế cho phương pháp `dealloc` của loại [`Global`] khi nó và [`Allocator`] trait trở nên ổn định.
///
/// # Safety
///
/// Xem [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Phân bổ lại bộ nhớ với trình cấp phát toàn cục.
///
/// Hàm này chuyển tiếp các cuộc gọi đến phương thức [`GlobalAlloc::realloc`] của bộ cấp phát được đăng ký với thuộc tính `#[global_allocator]` nếu có hoặc thuộc tính mặc định của `std` crate.
///
///
/// Chức năng này dự kiến sẽ không được dùng nữa để thay thế cho phương pháp `realloc` của loại [`Global`] khi nó và [`Allocator`] trait trở nên ổn định.
///
/// # Safety
///
/// Xem [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Phân bổ bộ nhớ không khởi tạo với trình cấp phát toàn cục.
///
/// Hàm này chuyển tiếp các cuộc gọi đến phương thức [`GlobalAlloc::alloc_zeroed`] của bộ cấp phát được đăng ký với thuộc tính `#[global_allocator]` nếu có hoặc thuộc tính mặc định của `std` crate.
///
///
/// Chức năng này dự kiến sẽ không được dùng nữa để thay thế cho phương pháp `alloc_zeroed` của loại [`Global`] khi nó và [`Allocator`] trait trở nên ổn định.
///
/// # Safety
///
/// Xem [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // AN TOÀN: `layout` có kích thước khác 0,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // AN TOÀN: Giống như `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // AN TOÀN: `new_size` khác 0 vì `old_size` lớn hơn hoặc bằng `new_size`
            // theo yêu cầu của các điều kiện an toàn.Các điều kiện khác phải được người gọi tuân thủ
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` có thể kiểm tra `new_size >= old_layout.size()` hoặc một cái gì đó tương tự.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // AN TOÀN: vì `new_layout.size()` phải lớn hơn hoặc bằng `old_size`,
            // cả cấp phát bộ nhớ cũ và mới đều hợp lệ để đọc và ghi cho các byte `old_size`.
            // Ngoài ra, vì phân bổ cũ chưa được phân bổ, nó không thể chồng chéo `new_ptr`.
            // Do đó, cuộc gọi đến `copy_nonoverlapping` là an toàn.
            // Người gọi phải tuân theo hợp đồng an toàn cho `dealloc`.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // AN TOÀN: `layout` có kích thước khác 0,
            // các điều kiện khác phải được người gọi tuân thủ
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // AN TOÀN: tất cả các điều kiện phải được người gọi tuân thủ
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // AN TOÀN: tất cả các điều kiện phải được người gọi tuân thủ
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // AN TOÀN: người gọi phải tuân thủ các điều kiện
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // AN TOÀN: `new_size` khác 0.Các điều kiện khác phải được người gọi tuân thủ
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` có thể kiểm tra `new_size <= old_layout.size()` hoặc một cái gì đó tương tự.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // AN TOÀN: vì `new_size` phải nhỏ hơn hoặc bằng `old_layout.size()`,
            // cả cấp phát bộ nhớ cũ và mới đều hợp lệ để đọc và ghi cho các byte `new_size`.
            // Ngoài ra, vì phân bổ cũ chưa được phân bổ, nó không thể chồng chéo `new_ptr`.
            // Do đó, cuộc gọi đến `copy_nonoverlapping` là an toàn.
            // Người gọi phải tuân theo hợp đồng an toàn cho `dealloc`.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Bộ phân bổ cho các con trỏ duy nhất.
// Chức năng này không được rút lui.Nếu đúng như vậy, MIR codegen sẽ không thành công.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Chữ ký này phải giống với `Box`, nếu không ICE sẽ xảy ra.
// Khi một tham số bổ sung cho `Box` được thêm vào (như `A: Allocator`), điều này cũng phải được thêm vào đây.
// Ví dụ: nếu `Box` được thay đổi thành `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, chức năng này cũng phải được thay đổi thành `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)`.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Trình xử lý lỗi phân bổ

extern "Rust" {
    // Đây là biểu tượng ma thuật để gọi trình xử lý lỗi phân bổ toàn cục.
    // rustc tạo ra nó để gọi `__rg_oom` nếu có `#[alloc_error_handler]` hoặc để gọi các triển khai mặc định bên dưới (`__rdl_oom`) nếu không.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Bỏ qua lỗi cấp phát bộ nhớ hoặc không thành công.
///
/// Những người gọi API cấp phát bộ nhớ muốn hủy bỏ tính toán để đáp ứng với lỗi cấp phát được khuyến khích gọi hàm này, thay vì gọi trực tiếp `panic!` hoặc tương tự.
///
///
/// Hành vi mặc định của chức năng này là in thông báo lỗi chuẩn và hủy bỏ quá trình.
/// Nó có thể được thay thế bằng [`set_alloc_error_hook`] và [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Để phân bổ thử nghiệm `std::alloc::handle_alloc_error` có thể được sử dụng trực tiếp.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // được gọi qua `__rust_alloc_error_handler` được tạo

    // nếu không có `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // nếu có một `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Đặc biệt hóa các bản sao vào bộ nhớ chưa được khởi tạo, được cấp phát trước.
/// Được sử dụng bởi `Box::clone` và `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Việc phân bổ *đầu tiên* có thể cho phép trình tối ưu hóa tạo giá trị nhân bản tại chỗ, bỏ qua cục bộ và di chuyển.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Chúng tôi luôn có thể sao chép tại chỗ mà không liên quan đến giá trị cục bộ.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}