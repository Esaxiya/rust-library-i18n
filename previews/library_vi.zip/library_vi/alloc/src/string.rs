//! Chuỗi có thể phát triển, được mã hóa UTF-8.
//!
//! Mô-đun này chứa loại [`String`], [`ToString`] trait để chuyển đổi thành chuỗi và một số loại lỗi có thể do làm việc với [`String`] s.
//!
//!
//! # Examples
//!
//! Có nhiều cách để tạo [`String`] mới từ một chuỗi ký tự:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Bạn có thể tạo một [`String`] mới từ một [`String`] hiện có bằng cách nối với
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Nếu bạn có vector gồm các byte UTF-8 hợp lệ, bạn có thể tạo [`String`] từ nó.Bạn cũng có thể làm ngược lại.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Chúng tôi biết những byte này là hợp lệ, vì vậy chúng tôi sẽ sử dụng `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// Chuỗi có thể phát triển, được mã hóa UTF-8.
///
/// Kiểu `String` là kiểu chuỗi phổ biến nhất có quyền sở hữu đối với nội dung của chuỗi.Nó có mối quan hệ chặt chẽ với đối tác vay mượn của nó, [`str`] nguyên thủy.
///
/// # Examples
///
/// Bạn có thể tạo `String` từ [a literal string][`str`] với [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Bạn có thể nối [`char`] vào `String` bằng phương thức [`push`] và nối [`&str`] với phương thức [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Nếu bạn có vector UTF-8 byte, bạn có thể tạo `String` từ nó bằng phương pháp [`from_utf8`]:
///
/// ```
/// // một số byte, trong vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Chúng tôi biết những byte này là hợp lệ, vì vậy chúng tôi sẽ sử dụng `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `Chuỗi` luôn hợp lệ UTF-8.Điều này có một vài ý nghĩa, điều đầu tiên là nếu bạn cần một chuỗi không phải UTF-8, hãy xem xét [`OsString`].Nó tương tự, nhưng không có ràng buộc UTF-8.Ý thứ hai là bạn không thể lập chỉ mục vào `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Lập chỉ mục nhằm mục đích là một hoạt động liên tục trong thời gian, nhưng mã hóa UTF-8 không cho phép chúng tôi thực hiện điều này.Hơn nữa, không rõ loại thứ mà chỉ mục sẽ trả về: một byte, một điểm mã hoặc một cụm grapheme.
/// Phương thức [`bytes`] và [`chars`] trả về các trình vòng lặp tương ứng trên hai phương thức đầu tiên.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String`s hiện thực [`Deref`] `<Target=str>`, và do đó kế thừa tất cả các phương thức của [`str`].Ngoài ra, điều này có nghĩa là bạn có thể chuyển `String` cho một hàm lấy [`&str`] bằng cách sử dụng ký hiệu và (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Thao tác này sẽ tạo [`&str`] từ `String` và chuyển nó vào. Việc chuyển đổi này rất rẻ và do đó, nói chung, các hàm sẽ chấp nhận [`&str`] làm đối số trừ khi chúng cần `String` vì một số lý do cụ thể.
///
/// Trong một số trường hợp nhất định, Rust không có đủ thông tin để thực hiện chuyển đổi này, được gọi là cưỡng chế [`Deref`].Trong ví dụ sau, một lát chuỗi [`&'a str`][`&str`] triển khai trait `TraitExample` và hàm `example_func` nhận bất kỳ thứ gì triển khai trait.
/// Trong trường hợp này, Rust sẽ cần thực hiện hai chuyển đổi ngầm định, điều mà Rust không có phương tiện để thực hiện.
/// Vì lý do đó, ví dụ sau sẽ không biên dịch.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Có hai tùy chọn sẽ hoạt động thay thế.Đầu tiên là thay đổi dòng `example_func(&example_string);` thành `example_func(example_string.as_str());`, sử dụng phương thức [`as_str()`] để trích xuất rõ ràng lát chuỗi chứa chuỗi.
/// Cách thứ hai thay đổi `example_func(&example_string);` thành `example_func(&*example_string);`.
/// Trong trường hợp này, chúng tôi đang tham chiếu `String` đến [`str`][`&str`], sau đó tham chiếu [`str`][`&str`] trở lại [`&str`].
/// Cách thứ hai mang tính thành ngữ hơn, tuy nhiên cả hai đều hoạt động để thực hiện chuyển đổi một cách rõ ràng thay vì dựa vào chuyển đổi ngầm định.
///
/// # Representation
///
/// `String` được tạo thành từ ba thành phần: con trỏ tới một số byte, độ dài và dung lượng.Con trỏ trỏ đến một bộ đệm bên trong mà `String` sử dụng để lưu trữ dữ liệu của nó.Chiều dài là số byte hiện được lưu trong bộ đệm và dung lượng là kích thước của bộ đệm tính bằng byte.
///
/// Như vậy, chiều dài sẽ luôn nhỏ hơn hoặc bằng dung lượng.
///
/// Bộ đệm này luôn được lưu trữ trên heap.
///
/// Bạn có thể xem những điều này bằng các phương pháp [`as_ptr`], [`len`] và [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Cập nhật điều này khi vec_into_raw_parts được ổn định.
/// // Ngăn tự động giảm dữ liệu của Chuỗi
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // câu chuyện có mười chín byte
/// assert_eq!(19, len);
///
/// // Chúng ta có thể xây dựng lại một Chuỗi từ ptr, len và dung lượng.
/// // Điều này hoàn toàn không an toàn vì chúng tôi chịu trách nhiệm đảm bảo các thành phần hợp lệ:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Nếu `String` có đủ dung lượng, việc thêm các phần tử vào nó sẽ không phân bổ lại.Ví dụ, hãy xem xét chương trình này:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Điều này sẽ xuất ra như sau:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Lúc đầu, chúng ta không có bộ nhớ nào được cấp phát, nhưng khi chúng ta nối vào chuỗi, nó sẽ tăng dung lượng của nó một cách thích hợp.Nếu thay vào đó, chúng tôi sử dụng phương pháp [`with_capacity`] để phân bổ công suất chính xác ban đầu:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Chúng tôi kết thúc với một đầu ra khác:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Ở đây, không cần cấp phát thêm bộ nhớ bên trong vòng lặp.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Giá trị lỗi có thể xảy ra khi chuyển đổi `String` từ byte UTF-8 vector.
///
/// Loại này là loại lỗi cho phương pháp [`from_utf8`] trên [`String`].
/// Nó được thiết kế theo cách để tránh phân bổ lại một cách cẩn thận: phương thức [`into_bytes`] sẽ trả lại byte vector đã được sử dụng trong nỗ lực chuyển đổi.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Loại [`Utf8Error`] được cung cấp bởi [`std::str`] đại diện cho một lỗi có thể xảy ra khi chuyển đổi một phần của [`u8`] s thành [`&str`].
/// Theo nghĩa này, nó tương tự như `FromUtf8Error` và bạn có thể lấy một từ `FromUtf8Error` thông qua phương thức [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Cách sử dụng cơ bản:
///
/// ```
/// // một số byte không hợp lệ, trong vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Giá trị lỗi có thể xảy ra khi chuyển đổi `String` từ lát byte UTF-16.
///
/// Loại này là loại lỗi cho phương pháp [`from_utf16`] trên [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Cách sử dụng cơ bản:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Tạo một `String` trống mới.
    ///
    /// Cho rằng `String` trống, điều này sẽ không cấp phát bất kỳ bộ đệm ban đầu nào.Mặc dù điều đó có nghĩa là thao tác ban đầu này rất rẻ, nhưng nó có thể gây ra phân bổ quá mức sau này khi bạn thêm dữ liệu.
    ///
    /// Nếu bạn có ý tưởng về lượng dữ liệu `String` sẽ giữ, hãy xem xét phương pháp [`with_capacity`] để ngăn phân bổ lại quá nhiều.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Tạo một `String` trống mới với một dung lượng cụ thể.
    ///
    /// `Chuỗi` có một bộ đệm bên trong để giữ dữ liệu của chúng.
    /// Dung lượng là độ dài của bộ đệm đó và có thể được truy vấn bằng phương thức [`capacity`].
    /// Phương pháp này tạo ra một `String` trống, nhưng một với bộ đệm ban đầu có thể chứa các byte `capacity`.
    /// Điều này rất hữu ích khi bạn có thể thêm một loạt dữ liệu vào `String`, giảm số lượng phân bổ lại mà nó cần phải thực hiện.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Nếu dung lượng đã cho là `0`, sẽ không có phân bổ nào xảy ra và phương pháp này giống với phương pháp [`new`].
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // Chuỗi không chứa ký tự, mặc dù nó có khả năng chứa nhiều ký tự hơn
    /// assert_eq!(s.len(), 0);
    ///
    /// // Tất cả đều được thực hiện mà không cần phân bổ lại ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... nhưng điều này có thể làm cho chuỗi phân bổ lại
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): với cfg(test), phương thức `[T]::to_vec` vốn có, được yêu cầu cho định nghĩa phương pháp này, không khả dụng.
    // Vì chúng tôi không yêu cầu phương pháp này cho mục đích thử nghiệm, tôi sẽ chỉ cần khai báo NB xem mô-đun slice::hack trong slice.rs để biết thêm thông tin
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Chuyển đổi vector byte thành `String`.
    ///
    /// Chuỗi ([`String`]) được tạo bởi byte ([`u8`]) và vector của byte ([`Vec<u8>`]) được tạo bởi byte, vì vậy hàm này chuyển đổi giữa hai chuỗi.
    /// Tuy nhiên, không phải tất cả các lát byte đều là `String` hợp lệ: `String` yêu cầu nó phải là UTF-8 hợp lệ.
    /// `from_utf8()` kiểm tra để đảm bảo rằng các byte là UTF-8 hợp lệ, sau đó thực hiện chuyển đổi.
    ///
    /// Nếu bạn chắc chắn rằng lát byte là UTF-8 hợp lệ và bạn không muốn phải chịu chi phí kiểm tra tính hợp lệ, thì có một phiên bản không an toàn của hàm này, [`from_utf8_unchecked`], có cùng hành vi nhưng bỏ qua kiểm tra.
    ///
    ///
    /// Phương pháp này sẽ cẩn thận để không sao chép vector, vì lợi ích của hiệu quả.
    ///
    /// Nếu bạn cần [`&str`] thay vì `String`, hãy xem xét [`str::from_utf8`].
    ///
    /// Nghịch đảo của phương pháp này là [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Trả về [`Err`] nếu lát cắt không phải là UTF-8 với mô tả lý do tại sao các byte đã cung cấp không phải là UTF-8.vector bạn đã chuyển đến cũng được bao gồm.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// // một số byte, trong vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Chúng tôi biết những byte này là hợp lệ, vì vậy chúng tôi sẽ sử dụng `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Các byte không chính xác:
    ///
    /// ```
    /// // một số byte không hợp lệ, trong vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Xem tài liệu dành cho [`FromUtf8Error`] để biết thêm chi tiết về những gì bạn có thể làm với lỗi này.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Chuyển đổi một phần byte thành một chuỗi, bao gồm các ký tự không hợp lệ.
    ///
    /// Các chuỗi được tạo bằng byte ([`u8`]) và một phần của byte ([`&[u8]`][byteslice]) được tạo bằng byte, vì vậy hàm này chuyển đổi giữa hai loại.Tuy nhiên, không phải tất cả các lát byte đều là chuỗi hợp lệ: các chuỗi bắt buộc phải là UTF-8 hợp lệ.
    /// Trong quá trình chuyển đổi này, `from_utf8_lossy()` sẽ thay thế mọi chuỗi UTF-8 không hợp lệ bằng [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], trông giống như sau:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Nếu bạn chắc chắn rằng lát byte là UTF-8 hợp lệ và bạn không muốn chịu phí chuyển đổi, thì có một phiên bản không an toàn của hàm này, [`from_utf8_unchecked`], có cùng hành vi nhưng bỏ qua các bước kiểm tra.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Hàm này trả về [`Cow<'a, str>`].Nếu lát byte của chúng ta là UTF-8 không hợp lệ, thì chúng ta cần chèn các ký tự thay thế, điều này sẽ thay đổi kích thước của chuỗi và do đó, yêu cầu `String`.
    /// Nhưng nếu nó đã là UTF-8 hợp lệ, chúng tôi không cần phân bổ mới.
    /// Kiểu trả về này cho phép chúng tôi xử lý cả hai trường hợp.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// // một số byte, trong vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Các byte không chính xác:
    ///
    /// ```
    /// // một số byte không hợp lệ
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Giải mã vector `v` được mã hóa UTF-16 thành `String`, trả về [`Err`] nếu `v` chứa bất kỳ dữ liệu không hợp lệ nào.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Điều này không được thực hiện thông qua thu thập: : <Result<_, _>> () vì lý do hiệu suất.
        // FIXME: chức năng có thể được đơn giản hóa trở lại khi #48994 đóng.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Giải mã lát được mã hóa UTF-16 `v` thành `String`, thay thế dữ liệu không hợp lệ bằng [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// Không giống như [`from_utf8_lossy`] trả về [`Cow<'a, str>`], `from_utf16_lossy` trả về `String` vì quá trình chuyển đổi UTF-16 sang UTF-8 yêu cầu cấp phát bộ nhớ.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Phân hủy `String` thành các thành phần thô của nó.
    ///
    /// Trả về con trỏ thô cho dữ liệu cơ bản, độ dài của chuỗi (tính bằng byte) và dung lượng được phân bổ của dữ liệu (tính bằng byte).
    /// Đây là các đối số giống nhau theo cùng thứ tự với các đối số đối với [`from_raw_parts`].
    ///
    /// Sau khi gọi hàm này, người gọi phải chịu trách nhiệm về bộ nhớ mà `String` quản lý trước đó.
    /// Cách duy nhất để làm điều này là chuyển đổi con trỏ thô, độ dài và dung lượng trở lại thành `String` với chức năng [`from_raw_parts`], cho phép trình hủy thực hiện dọn dẹp.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Tạo `String` mới từ độ dài, dung lượng và con trỏ.
    ///
    /// # Safety
    ///
    /// Điều này rất không an toàn, do số lượng bất biến không được kiểm tra:
    ///
    /// * Bộ nhớ ở `buf` cần phải được cấp phát trước đó bởi cùng một bộ cấp phát mà thư viện tiêu chuẩn sử dụng, với sự căn chỉnh bắt buộc chính xác là 1.
    /// * `length` cần nhỏ hơn hoặc bằng `capacity`.
    /// * `capacity` cần phải là giá trị chính xác.
    /// * Các byte `length` đầu tiên tại `buf` cần phải là UTF-8 hợp lệ.
    ///
    /// Vi phạm những điều này có thể gây ra các vấn đề như làm hỏng cấu trúc dữ liệu nội bộ của trình cấp phát.
    ///
    /// Quyền sở hữu của `buf` được chuyển một cách hiệu quả sang `String`, sau đó có thể phân bổ, phân bổ lại hoặc thay đổi nội dung của bộ nhớ được con trỏ trỏ đến theo ý muốn.
    /// Đảm bảo rằng không có gì khác sử dụng con trỏ sau khi gọi hàm này.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Cập nhật điều này khi vec_into_raw_parts được ổn định.
    ///     // Ngăn tự động giảm dữ liệu của Chuỗi
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Chuyển đổi vector byte thành `String` mà không cần kiểm tra xem chuỗi có chứa UTF-8 hợp lệ hay không.
    ///
    /// Xem phiên bản an toàn, [`from_utf8`], để biết thêm chi tiết.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Hàm này không an toàn vì nó không kiểm tra xem các byte được truyền vào nó có phải là UTF-8 hợp lệ hay không.
    /// Nếu giới hạn này bị vi phạm, nó có thể gây ra sự cố mất an toàn bộ nhớ với người dùng future của `String`, vì phần còn lại của thư viện tiêu chuẩn giả định rằng chuỗi `chuỗi là UTF-8 hợp lệ.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// // một số byte, trong vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Chuyển đổi `String` thành byte vector.
    ///
    /// Điều này tiêu tốn `String`, vì vậy chúng tôi không cần phải sao chép nội dung của nó.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Trích xuất một lát chuỗi chứa toàn bộ `String`.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Chuyển đổi `String` thành một lát chuỗi có thể thay đổi.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Thêm một lát chuỗi nhất định vào phần cuối của `String` này.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Trả về dung lượng của `Chuỗi` này, tính bằng byte.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Đảm bảo rằng dung lượng của `Chuỗi` này lớn hơn ít nhất `additional` byte so với chiều dài của nó.
    ///
    /// Dung lượng có thể tăng hơn `additional` byte nếu nó chọn, để ngăn việc phân bổ lại thường xuyên.
    ///
    ///
    /// Nếu bạn không muốn hành vi "at least" này, hãy xem phương pháp [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics nếu dung lượng mới tràn [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Điều này có thể không thực sự làm tăng dung lượng:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s bây giờ có chiều dài là 2 và công suất là 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Vì chúng tôi đã có thêm 8 dung lượng, nên gọi đây là ...
    /// s.reserve(8);
    ///
    /// // ... không thực sự tăng.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Đảm bảo rằng dung lượng của `Chuỗi` này lớn hơn `additional` byte so với chiều dài của nó.
    ///
    /// Cân nhắc sử dụng phương pháp [`reserve`] trừ khi bạn hoàn toàn hiểu rõ hơn người cấp phát.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics nếu dung lượng mới tràn `usize`.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Điều này có thể không thực sự làm tăng dung lượng:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s bây giờ có chiều dài là 2 và công suất là 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Vì chúng tôi đã có thêm 8 dung lượng, nên gọi đây là ...
    /// s.reserve_exact(8);
    ///
    /// // ... không thực sự tăng.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Cố gắng dự trữ dung lượng cho ít nhất `additional` nhiều phần tử hơn sẽ được chèn vào `String` đã cho.
    /// Bộ sưu tập có thể dành thêm không gian để tránh tái phân bổ thường xuyên.
    /// Sau khi gọi `reserve`, dung lượng sẽ lớn hơn hoặc bằng `self.len() + additional`.
    /// Không có gì nếu năng lực đã đủ.
    ///
    /// # Errors
    ///
    /// Nếu dung lượng bị tràn hoặc trình cấp phát báo lỗi, thì lỗi sẽ được trả về.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Đặt trước bộ nhớ, thoát ra nếu chúng ta không thể
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Bây giờ chúng tôi biết điều này không thể OOM giữa công việc phức tạp của chúng tôi
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Cố gắng dự trữ dung lượng tối thiểu cho chính xác `additional` nhiều phần tử hơn sẽ được chèn vào `String` đã cho.
    ///
    /// Sau khi gọi `reserve_exact`, dung lượng sẽ lớn hơn hoặc bằng `self.len() + additional`.
    /// Không có gì nếu dung lượng đã đủ.
    ///
    /// Lưu ý rằng bộ phân bổ có thể cung cấp cho bộ sưu tập nhiều không gian hơn nó yêu cầu.
    /// Do đó, không thể dựa vào dung lượng để được chính xác là tối thiểu.
    /// Ưu tiên `reserve` nếu mong đợi chèn future.
    ///
    /// # Errors
    ///
    /// Nếu dung lượng bị tràn hoặc trình cấp phát báo lỗi, thì lỗi sẽ được trả về.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Đặt trước bộ nhớ, thoát ra nếu chúng ta không thể
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Bây giờ chúng tôi biết điều này không thể OOM giữa công việc phức tạp của chúng tôi
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Thu nhỏ công suất của `String` này để phù hợp với chiều dài của nó.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Thu hẹp dung lượng của `String` này với giới hạn thấp hơn.
    ///
    /// Dung lượng ít nhất sẽ vẫn lớn bằng cả chiều dài và giá trị được cung cấp.
    ///
    ///
    /// Nếu dung lượng hiện tại nhỏ hơn giới hạn dưới, đây là điều không nên.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Thêm [`char`] đã cho vào cuối `String` này.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Trả về một lát byte của nội dung của `Chuỗi` này.
    ///
    /// Nghịch đảo của phương pháp này là [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Rút ngắn `String` này đến độ dài được chỉ định.
    ///
    /// Nếu `new_len` lớn hơn độ dài hiện tại của chuỗi, điều này không có tác dụng.
    ///
    ///
    /// Lưu ý rằng phương pháp này không ảnh hưởng đến dung lượng được phân bổ của chuỗi
    ///
    /// # Panics
    ///
    /// Panics nếu `new_len` không nằm trên ranh giới [`char`].
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Xóa ký tự cuối cùng khỏi bộ đệm chuỗi và trả về ký tự đó.
    ///
    /// Trả về [`None`] nếu `String` này trống.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Loại bỏ [`char`] khỏi `String` này ở một vị trí byte và trả lại nó.
    ///
    /// Đây là một phép toán *O*(*n*), vì nó yêu cầu sao chép mọi phần tử trong bộ đệm.
    ///
    /// # Panics
    ///
    /// Panics nếu `idx` lớn hơn hoặc bằng độ dài của `Chuỗi` hoặc nếu nó không nằm trên ranh giới [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Xóa tất cả các kết quả trùng khớp của mẫu `pat` trong `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Các kết quả phù hợp sẽ được phát hiện và loại bỏ lặp đi lặp lại, vì vậy trong trường hợp các mẫu trùng lặp, chỉ mẫu đầu tiên sẽ bị xóa:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // AN TOÀN: bắt đầu và kết thúc sẽ nằm trên ranh giới byte utf8 mỗi
        // tài liệu của Người tìm kiếm
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Chỉ giữ lại các ký tự được chỉ định bởi vị từ.
    ///
    /// Nói cách khác, loại bỏ tất cả các ký tự `c` để `f(c)` trả về `false`.
    /// Phương thức này hoạt động tại chỗ, truy cập từng ký tự chính xác một lần theo thứ tự ban đầu và bảo toàn thứ tự của các ký tự được giữ lại.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Thứ tự chính xác có thể hữu ích để theo dõi trạng thái bên ngoài, như một chỉ mục.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Trỏ idx vào ký tự tiếp theo
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Chèn một ký tự vào `String` này ở một vị trí byte.
    ///
    /// Đây là một phép toán *O*(*n*) vì nó yêu cầu sao chép mọi phần tử trong bộ đệm.
    ///
    /// # Panics
    ///
    /// Panics nếu `idx` lớn hơn độ dài của `Chuỗi` hoặc nếu nó không nằm trên ranh giới [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Chèn một lát chuỗi vào `String` này ở một vị trí byte.
    ///
    /// Đây là một phép toán *O*(*n*) vì nó yêu cầu sao chép mọi phần tử trong bộ đệm.
    ///
    /// # Panics
    ///
    /// Panics nếu `idx` lớn hơn độ dài của `Chuỗi` hoặc nếu nó không nằm trên ranh giới [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Trả về một tham chiếu có thể thay đổi cho nội dung của `String` này.
    ///
    /// # Safety
    ///
    /// Hàm này không an toàn vì nó không kiểm tra xem các byte được truyền vào nó có phải là UTF-8 hợp lệ hay không.
    /// Nếu giới hạn này bị vi phạm, nó có thể gây ra sự cố mất an toàn bộ nhớ với người dùng future của `String`, vì phần còn lại của thư viện tiêu chuẩn giả định rằng chuỗi `chuỗi là UTF-8 hợp lệ.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Trả về độ dài của `String` này, tính bằng byte, không phải [`char`] hoặc grapheme.
    /// Nói cách khác, nó có thể không phải là thứ mà con người coi là độ dài của chuỗi.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Trả về `true` nếu `String` này có độ dài bằng 0 và `false` nếu không.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Tách chuỗi thành hai tại chỉ mục byte đã cho.
    ///
    /// Trả về `String` mới được cấp phát.
    /// `self` chứa byte `[0, at)` và `String` trả về chứa byte `[at, len)`.
    /// `at` phải nằm trên ranh giới của một điểm mã UTF-8.
    ///
    /// Lưu ý rằng dung lượng của `self` không thay đổi.
    ///
    /// # Panics
    ///
    /// Panics nếu `at` không nằm trên ranh giới điểm mã `UTF-8` hoặc nếu nó nằm ngoài điểm mã cuối cùng của chuỗi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Cắt bớt `String` này, xóa tất cả nội dung.
    ///
    /// Mặc dù điều này có nghĩa là `String` sẽ có chiều dài bằng 0, nhưng nó không ảnh hưởng đến dung lượng của nó.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Tạo một trình lặp thoát nước loại bỏ phạm vi được chỉ định trong `String` và mang lại `chars` đã bị loại bỏ.
    ///
    ///
    /// Note: Phạm vi phần tử bị loại bỏ ngay cả khi trình lặp không được sử dụng cho đến khi kết thúc.
    ///
    /// # Panics
    ///
    /// Panics nếu điểm bắt đầu hoặc điểm kết thúc không nằm trên ranh giới [`char`] hoặc nếu chúng nằm ngoài giới hạn.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Loại bỏ phạm vi cho đến khi β khỏi chuỗi
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Một phạm vi đầy đủ sẽ xóa chuỗi
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // An toàn bộ nhớ
        //
        // Phiên bản chuỗi của Drain không có các vấn đề về an toàn bộ nhớ của phiên bản vector.
        // Dữ liệu chỉ là các byte đơn giản.
        // Bởi vì việc loại bỏ phạm vi xảy ra trong Drop, nếu trình lặp Drain bị rò rỉ, việc loại bỏ sẽ không xảy ra.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Lấy hai khoản vay đồng thời.
        // Chuỗi &mut sẽ không được truy cập cho đến khi quá trình lặp kết thúc, trong Drop.
        let self_ptr = self as *mut _;
        // AN TOÀN: `slice::range` và `is_char_boundary` thực hiện kiểm tra giới hạn thích hợp.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Loại bỏ phạm vi được chỉ định trong chuỗi và thay thế nó bằng chuỗi đã cho.
    /// Chuỗi đã cho không cần có cùng độ dài với dải ô.
    ///
    /// # Panics
    ///
    /// Panics nếu điểm bắt đầu hoặc điểm kết thúc không nằm trên ranh giới [`char`] hoặc nếu chúng nằm ngoài giới hạn.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Thay thế dải ô cho đến khi chuỗi β từ chuỗi
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // An toàn bộ nhớ
        //
        // Replace_range không có vấn đề về an toàn bộ nhớ của Mối nối vector.
        // của phiên bản vector.Dữ liệu chỉ là byte đơn giản.

        // CẢNH BÁO: Nội dòng biến này sẽ không được gắn với (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // CẢNH BÁO: Nội dòng biến này sẽ không được gắn với (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Sử dụng lại `range` sẽ không bị ràng buộc (#81138) Chúng tôi giả định các giới hạn được báo cáo bởi `range` vẫn giữ nguyên, nhưng việc triển khai đối thủ có thể thay đổi giữa các cuộc gọi
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Chuyển đổi `String` này thành [`Box`]`<`[`str`] `>`.
    ///
    /// Điều này sẽ làm giảm bất kỳ dung lượng dư thừa nào.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Trả về một phần của [`u8`] s byte đã được cố gắng chuyển đổi thành `String`.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// // một số byte không hợp lệ, trong vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Trả về các byte đã được cố gắng chuyển đổi thành `String`.
    ///
    /// Phương pháp này được xây dựng cẩn thận để tránh phân bổ.
    /// Nó sẽ xử lý lỗi, loại bỏ các byte, do đó không cần tạo bản sao của các byte.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// // một số byte không hợp lệ, trong vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Tìm nạp `Utf8Error` để biết thêm chi tiết về lỗi chuyển đổi.
    ///
    /// Loại [`Utf8Error`] được cung cấp bởi [`std::str`] đại diện cho một lỗi có thể xảy ra khi chuyển đổi một phần của [`u8`] s thành [`&str`].
    /// Theo nghĩa này, nó tương tự như `FromUtf8Error`.
    /// Xem tài liệu của nó để biết thêm chi tiết về cách sử dụng nó.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// // một số byte không hợp lệ, trong vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // byte đầu tiên không hợp lệ ở đây
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Bởi vì chúng tôi đang lặp lại các chuỗi `String`, chúng tôi có thể tránh ít nhất một phân bổ bằng cách lấy chuỗi đầu tiên từ trình lặp và thêm vào đó tất cả các chuỗi tiếp theo.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Bởi vì chúng tôi đang lặp lại CoWs, chúng tôi có thể (potentially) tránh ít nhất một lần phân bổ bằng cách lấy mục đầu tiên và thêm vào đó tất cả các mục tiếp theo.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Một mô hình tiện lợi ủy quyền cho mô hình cấy ghép cho `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Tạo một `String` trống.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Triển khai toán tử `+` để nối hai chuỗi.
///
/// Điều này tiêu thụ `String` ở phía bên trái và sử dụng lại bộ đệm của nó (phát triển nó nếu cần).
/// Điều này được thực hiện để tránh phân bổ `String` mới và sao chép toàn bộ nội dung trên mọi thao tác, điều này sẽ dẫn đến thời gian chạy *O*(*n*^ 2) khi xây dựng chuỗi *n*-byte bằng cách nối lặp lại.
///
///
/// Chuỗi ở phía bên tay phải chỉ được mượn;nội dung của nó được sao chép vào `String` trả về.
///
/// # Examples
///
/// Ghép hai chuỗi `chuỗi` lấy giá trị đầu tiên và mượn chuỗi thứ hai:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` đã được chuyển đi và không thể sử dụng ở đây nữa.
/// ```
///
/// Nếu bạn muốn tiếp tục sử dụng `String` đầu tiên, bạn có thể sao chép nó và nối vào bản sao để thay thế:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` vẫn còn giá trị ở đây.
/// ```
///
/// Việc nối các lát `&str` có thể được thực hiện bằng cách chuyển đổi đầu tiên thành `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Triển khai toán tử `+=` để thêm vào `String`.
///
/// Điều này có hành vi tương tự như phương thức [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Một loại bí danh cho [`Infallible`].
///
/// Bí danh này tồn tại để tương thích ngược và cuối cùng có thể không được dùng nữa.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// trait để chuyển đổi giá trị thành `String`.
///
/// trait này được triển khai tự động cho bất kỳ loại nào triển khai [`Display`] trait.
/// Do đó, `ToString` không nên được triển khai trực tiếp:
/// [`Display`] sẽ được triển khai thay thế và bạn nhận được bản triển khai `ToString` miễn phí.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Chuyển đổi giá trị đã cho thành `String`.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// Trong triển khai này, phương pháp `to_string` panics nếu việc triển khai `Display` trả về lỗi.
/// Điều này cho thấy việc triển khai `Display` không chính xác vì `fmt::Write for String` không bao giờ tự trả về lỗi.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Một nguyên tắc chung là không nội dòng các hàm chung chung.
    // Tuy nhiên, việc loại bỏ `#[inline]` khỏi phương pháp này gây ra các hồi quy không đáng kể.
    // Xem <https://github.com/rust-lang/rust/pull/74852>, nỗ lực cuối cùng để cố gắng loại bỏ nó.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Chuyển đổi `&mut str` thành `String`.
    ///
    /// Kết quả được phân bổ trên heap.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: kiểm tra kéo trong libstd, gây ra lỗi ở đây
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Chuyển đổi lát `str` đóng hộp đã cho thành `String`.
    /// Đáng chú ý là sở hữu lát cắt `str`.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Chuyển đổi `String` đã cho thành một lát `str` đóng hộp được sở hữu.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Chuyển đổi một lát chuỗi thành một biến thể Mượn.
    /// Không có phân bổ heap nào được thực hiện và chuỗi không được sao chép.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Chuyển đổi một Chuỗi thành một biến thể Được sở hữu.
    /// Không có phân bổ heap nào được thực hiện và chuỗi không được sao chép.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Chuyển đổi một tham chiếu Chuỗi thành một biến thể Mượn.
    /// Không có phân bổ heap nào được thực hiện và chuỗi không được sao chép.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Chuyển đổi `String` đã cho thành vector `Vec` chứa các giá trị kiểu `u8`.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Một trình lặp thoát cho `String`.
///
/// Cấu trúc này được tạo bởi phương thức [`drain`] trên [`String`].
/// Xem tài liệu của nó để biết thêm.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Sẽ được sử dụng như&'một Chuỗi đột biến trong trình hủy
    string: *mut String,
    /// Bắt đầu một phần để loại bỏ
    start: usize,
    /// Kết thúc phần để loại bỏ
    end: usize,
    /// Phạm vi còn lại hiện tại để loại bỏ
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Sử dụng Vec::drain.
            // "Reaffirm" kiểm tra giới hạn để tránh mã panic được chèn lại.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Trả về chuỗi (con) còn lại của trình vòng lặp này dưới dạng một lát cắt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: bỏ ghi chú AsRef hiển thị bên dưới khi ổn định.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Ghi chú khi ổn định `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>cho Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> cho Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}