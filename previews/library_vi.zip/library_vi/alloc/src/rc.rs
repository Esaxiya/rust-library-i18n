//! Con trỏ đếm tham chiếu đơn luồng.'Rc' là viết tắt của 'Reference
//! Counted'.
//!
//! Kiểu [`Rc<T>`][`Rc`] cung cấp quyền sở hữu chung của một giá trị kiểu `T`, được phân bổ trong heap.
//! Gọi [`clone`][clone] trên [`Rc`] tạo ra một con trỏ mới đến cùng một phân bổ trong heap.
//! Khi con trỏ [`Rc`] cuối cùng đến một phân bổ nhất định bị hủy, giá trị được lưu trữ trong phân bổ đó (thường được gọi là "inner value") cũng bị loại bỏ.
//!
//! Các tham chiếu được chia sẻ trong Rust không cho phép đột biến theo mặc định và [`Rc`] không phải là ngoại lệ: nói chung bạn không thể có được một tham chiếu có thể thay đổi cho một cái gì đó bên trong [`Rc`].
//! Nếu bạn cần khả năng thay đổi, hãy đặt [`Cell`] hoặc [`RefCell`] bên trong [`Rc`];xem [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] sử dụng phép đếm tham chiếu phi nguyên tử.
//! Điều này có nghĩa là chi phí rất thấp, nhưng [`Rc`] không thể được gửi giữa các luồng và do đó [`Rc`] không triển khai [`Send`][send].
//! Do đó, trình biên dịch Rust sẽ kiểm tra *tại thời điểm biên dịch* rằng bạn không gửi [`Rc`] giữa các luồng.
//! Nếu bạn cần đếm tham chiếu nguyên tử, đa luồng, hãy sử dụng [`sync::Arc`][arc].
//!
//! Phương thức [`downgrade`][downgrade] có thể được sử dụng để tạo một con trỏ [`Weak`] không sở hữu.
//! Con trỏ [`Weak`] có thể được [`nâng cấp`][nâng cấp] d thành [`Rc`], nhưng điều này sẽ trả về [`None`] nếu giá trị được lưu trữ trong phân bổ đã bị loại bỏ.
//! Nói cách khác, con trỏ `Weak` không giữ giá trị bên trong phân bổ tồn tại;tuy nhiên, chúng *làm* giữ cho phân bổ (kho dự trữ cho giá trị bên trong) tồn tại.
//!
//! Một chu kỳ giữa các con trỏ [`Rc`] sẽ không bao giờ được phân bổ.
//! Vì lý do này, [`Weak`] được sử dụng để phá vỡ các chu kỳ.
//! Ví dụ: một cây có thể có con trỏ [`Rc`] mạnh từ các nút cha đến nút con và con trỏ [`Weak`] từ con quay lại cha mẹ của chúng.
//!
//! `Rc<T>` tự động tham chiếu đến `T` (thông qua [`Deref`] trait), vì vậy bạn có thể gọi các phương thức của `T` trên giá trị kiểu [`Rc<T>`][`Rc`].
//! Để tránh xung đột tên với các phương thức của `T`, bản thân các phương thức của [`Rc<T>`][`Rc`] là các hàm liên kết, được gọi bằng cách sử dụng [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>Các triển khai của traits như `Clone` cũng có thể được gọi bằng cách sử dụng cú pháp đủ điều kiện.
//! Một số người thích sử dụng cú pháp đủ điều kiện, trong khi những người khác thích sử dụng cú pháp gọi phương thức.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Cú pháp gọi phương thức
//! let rc2 = rc.clone();
//! // Cú pháp hoàn toàn đủ điều kiện
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] không tự động tham chiếu đến `T`, vì giá trị bên trong có thể đã bị loại bỏ.
//!
//! # Nhân bản tài liệu tham khảo
//!
//! Tạo một tham chiếu mới cho cùng một phân bổ như một con trỏ được đếm tham chiếu hiện có được thực hiện bằng cách sử dụng `Clone` trait được triển khai cho [`Rc<T>`][`Rc`] và [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Hai cú pháp dưới đây là tương đương.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a và b đều trỏ đến cùng một vị trí bộ nhớ như foo.
//! ```
//!
//! Cú pháp `Rc::clone(&from)` là câu thành ngữ nhất vì nó truyền đạt ý nghĩa của mã một cách rõ ràng hơn.
//! Trong ví dụ trên, cú pháp này giúp bạn dễ dàng thấy rằng mã này đang tạo một tham chiếu mới chứ không phải sao chép toàn bộ nội dung của foo.
//!
//! # Examples
//!
//! Hãy xem xét một tình huống trong đó một tập hợp các `Tiện ích 'được sở hữu bởi một `Owner` nhất định.
//! Chúng tôi muốn `` Tiện ích '' của chúng tôi trỏ đến `Owner` của chúng.Chúng tôi không thể làm điều này với quyền sở hữu duy nhất, vì nhiều tiện ích có thể thuộc cùng một `Owner`.
//! [`Rc`] cho phép chúng tôi chia sẻ `Owner` giữa nhiều `Tiện ích` và để `Owner` vẫn được phân bổ miễn là có bất kỳ `Gadget` nào ở đó.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ...các lĩnh vực khác
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ...các lĩnh vực khác
//! }
//!
//! fn main() {
//!     // Tạo `Owner` được tính tham chiếu.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Tạo `Tiện ích` thuộc về `gadget_owner`.
//!     // Nhân bản `Rc<Owner>` cung cấp cho chúng tôi một con trỏ mới đến cùng một phân bổ `Owner`, tăng số lượng tham chiếu trong quá trình này.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Loại bỏ biến cục bộ `gadget_owner` của chúng tôi.
//!     drop(gadget_owner);
//!
//!     // Mặc dù bỏ `gadget_owner`, chúng tôi vẫn có thể in ra tên của `Owner` trong phần `Tiện ích '.
//!     // Điều này là do chúng tôi chỉ bỏ một `Rc<Owner>` duy nhất, không phải `Owner` mà nó trỏ tới.
//!     // Miễn là có những `Rc<Owner>` khác chỉ vào cùng một phân bổ `Owner`, nó sẽ vẫn hoạt động.
//!     // Phép chiếu trường `gadget1.owner.name` hoạt động vì `Rc<Owner>` tự động bỏ tham chiếu đến `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Khi kết thúc chức năng, `gadget1` và `gadget2` bị hủy và cùng với chúng là các tham chiếu được đếm cuối cùng đến `Owner` của chúng tôi.
//!     // Gadget Man bây giờ cũng bị phá hủy.
//!     //
//! }
//! ```
//!
//! Nếu yêu cầu của chúng tôi thay đổi và chúng tôi cũng cần có thể chuyển từ `Owner` sang `Gadget`, chúng tôi sẽ gặp sự cố.
//! Một con trỏ [`Rc`] từ `Owner` đến `Gadget` giới thiệu một chu trình.
//! Điều này có nghĩa là số lượng tham chiếu của chúng không bao giờ có thể đạt đến 0 và phân bổ sẽ không bao giờ bị hủy:
//! một bộ nhớ bị rò rỉ.Để giải quyết vấn đề này, chúng ta có thể sử dụng con trỏ [`Weak`].
//!
//! Rust thực sự gây khó khăn cho việc tạo vòng lặp này ngay từ đầu.Để kết thúc bằng hai giá trị trỏ vào nhau, một trong hai giá trị đó cần phải có thể thay đổi được.
//! Điều này rất khó vì [`Rc`] thực thi an toàn bộ nhớ bằng cách chỉ đưa ra các tham chiếu được chia sẻ đến giá trị mà nó bao bọc và những tham chiếu này không cho phép đột biến trực tiếp.
//! Chúng ta cần bao bọc một phần giá trị mà chúng ta muốn biến đổi trong [`RefCell`], cung cấp *khả năng thay đổi bên trong*: một phương pháp để đạt được khả năng thay đổi thông qua tham chiếu được chia sẻ.
//! [`RefCell`] thực thi các quy tắc mượn của Rust trong thời gian chạy.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ...các lĩnh vực khác
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ...các lĩnh vực khác
//! }
//!
//! fn main() {
//!     // Tạo `Owner` được tính tham chiếu.
//!     // Lưu ý rằng chúng tôi đã đặt vector của `Owner`'s của`Gadget`s bên trong `RefCell` để chúng tôi có thể thay đổi nó thông qua một tài liệu tham khảo được chia sẻ.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Tạo `Tiện ích` thuộc về `gadget_owner`, như trước đây.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Thêm `Gadget`s vào `Owner` của họ.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` động vay kết thúc ở đây.
//!     }
//!
//!     // Lặp lại các `Tiện ích 'của chúng tôi, in chi tiết của chúng ra.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` là một `Weak<Gadget>`.
//!         // Vì con trỏ `Weak` không thể đảm bảo phân bổ vẫn tồn tại, chúng ta cần gọi `upgrade`, trả về `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // Trong trường hợp này, chúng tôi biết phân bổ vẫn tồn tại, vì vậy chúng tôi chỉ cần `unwrap` `Option`.
//!         // Trong một chương trình phức tạp hơn, bạn có thể cần xử lý lỗi duyên dáng để có kết quả `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Khi kết thúc chức năng, `gadget_owner`, `gadget1` và `gadget2` bị hủy.
//!     // Hiện không có con trỏ (`Rc`) mạnh mẽ nào đến các tiện ích, vì vậy chúng bị phá hủy.
//!     // Con số này bằng không số tham chiếu trên Gadget Man, vì vậy anh ta cũng bị phá hủy.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Đây là loại repr(C) đến future chống lại khả năng sắp xếp lại trường, điều này sẽ cản trở [into|from]_raw() an toàn của các loại bên trong có thể chuyển đổi.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Một con trỏ đếm tham chiếu đơn luồng.'Rc' là viết tắt của 'Reference
/// Counted'.
///
/// Xem [module-level documentation](./index.html) để biết thêm chi tiết.
///
/// Các phương thức vốn có của `Rc` là tất cả các hàm liên quan, có nghĩa là bạn phải gọi chúng như là [`Rc::get_mut(&mut value)`][get_mut] thay vì `value.get_mut()`.
/// Điều này tránh xung đột với các phương thức của kiểu bên trong `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Sự không an toàn này là ổn vì trong khi Rc này còn sống, chúng tôi đảm bảo rằng con trỏ bên trong là hợp lệ.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Xây dựng một `Rc<T>` mới.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Có một con trỏ yếu tiềm ẩn thuộc sở hữu của tất cả các con trỏ mạnh, điều này đảm bảo rằng bộ hủy yếu không bao giờ giải phóng phân bổ trong khi bộ hủy mạnh đang chạy, ngay cả khi con trỏ yếu được lưu trữ bên trong con trỏ mạnh.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Tạo một `Rc<T>` mới bằng cách sử dụng một tham chiếu yếu cho chính nó.
    /// Cố gắng nâng cấp tham chiếu yếu trước khi hàm này trả về sẽ dẫn đến giá trị `None`.
    ///
    /// Tuy nhiên, tham chiếu yếu có thể được sao chép tự do và được lưu trữ để sử dụng sau này.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... các lĩnh vực khác
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Xây dựng bên trong ở trạng thái "uninitialized" với một tham chiếu yếu duy nhất.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Điều quan trọng là chúng ta không từ bỏ quyền sở hữu con trỏ yếu, nếu không bộ nhớ có thể được giải phóng vào thời điểm `data_fn` quay trở lại.
        // Nếu chúng tôi thực sự muốn chuyển quyền sở hữu, chúng tôi có thể tạo một con trỏ yếu bổ sung cho chính mình, nhưng điều này sẽ dẫn đến cập nhật bổ sung cho số lượng tham chiếu yếu mà có thể không cần thiết.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Các tham chiếu mạnh phải sở hữu chung một tham chiếu yếu được chia sẻ, vì vậy đừng chạy trình hủy cho tham chiếu yếu cũ của chúng tôi.
        //
        mem::forget(weak);
        strong
    }

    /// Tạo một `Rc` mới với nội dung chưa được khởi tạo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Khởi tạo hoãn lại:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Xây dựng một `Rc` mới với nội dung chưa được khởi tạo, với bộ nhớ được lấp đầy bởi các byte `0`.
    ///
    ///
    /// Xem [`MaybeUninit::zeroed`][zeroed] để biết các ví dụ về cách sử dụng đúng và sai của phương pháp này.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Tạo `Rc<T>` mới, trả về lỗi nếu phân bổ không thành công
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Có một con trỏ yếu tiềm ẩn thuộc sở hữu của tất cả các con trỏ mạnh, điều này đảm bảo rằng bộ hủy yếu không bao giờ giải phóng phân bổ trong khi bộ hủy mạnh đang chạy, ngay cả khi con trỏ yếu được lưu trữ bên trong con trỏ mạnh.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Tạo `Rc` mới với nội dung chưa được khởi tạo, trả về lỗi nếu phân bổ không thành công
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Khởi tạo hoãn lại:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Tạo một `Rc` mới với nội dung chưa được khởi tạo, với bộ nhớ được lấp đầy bởi các byte `0`, trả về lỗi nếu phân bổ không thành công
    ///
    ///
    /// Xem [`MaybeUninit::zeroed`][zeroed] để biết các ví dụ về cách sử dụng đúng và sai của phương pháp này.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Xây dựng một `Pin<Rc<T>>` mới.
    /// Nếu `T` không triển khai `Unpin`, thì `value` sẽ được ghim trong bộ nhớ và không thể di chuyển được.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Trả về giá trị bên trong, nếu `Rc` có chính xác một tham chiếu mạnh.
    ///
    /// Nếu không, [`Err`] được trả về cùng với `Rc` đã được chuyển vào.
    ///
    ///
    /// Điều này sẽ thành công ngay cả khi có những tài liệu tham khảo yếu kém nổi bật.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // sao chép đối tượng được chứa

                // Cho Weak biết rằng chúng không thể được thăng hạng bằng cách giảm số lượng mạnh, sau đó loại bỏ con trỏ "strong weak" ngầm trong khi cũng xử lý logic drop bằng cách chỉ tạo một Weak giả.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Tạo một lát mới được tính là tham chiếu với nội dung chưa được khởi tạo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Khởi tạo hoãn lại:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Tạo một lát cắt được đếm tham chiếu mới với nội dung chưa được khởi tạo, với bộ nhớ được lấp đầy bởi các byte `0`.
    ///
    ///
    /// Xem [`MaybeUninit::zeroed`][zeroed] để biết các ví dụ về cách sử dụng đúng và sai của phương pháp này.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Chuyển đổi sang `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Như với [`MaybeUninit::assume_init`], người gọi phải đảm bảo rằng giá trị bên trong thực sự ở trạng thái khởi tạo.
    ///
    /// Việc gọi này khi nội dung chưa được khởi tạo hoàn toàn sẽ gây ra hành vi không xác định ngay lập tức.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Khởi tạo hoãn lại:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Chuyển đổi sang `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Như với [`MaybeUninit::assume_init`], người gọi phải đảm bảo rằng giá trị bên trong thực sự ở trạng thái khởi tạo.
    ///
    /// Việc gọi này khi nội dung chưa được khởi tạo hoàn toàn sẽ gây ra hành vi không xác định ngay lập tức.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Khởi tạo hoãn lại:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Sử dụng `Rc`, trả về con trỏ được bọc.
    ///
    /// Để tránh rò rỉ bộ nhớ, con trỏ phải được chuyển đổi trở lại `Rc` bằng [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Cung cấp một con trỏ thô tới dữ liệu.
    ///
    /// Số lượng không bị ảnh hưởng theo bất kỳ cách nào và `Rc` không bị tiêu thụ.
    /// Con trỏ có giá trị miễn là có số lượng mạnh trong `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // AN TOÀN: Điều này không thể đi qua Deref::deref hoặc Rc::inner vì
        // điều này được yêu cầu để giữ lại xuất xứ của raw/mut, ví dụ:
        // `get_mut` có thể ghi thông qua con trỏ sau khi Rc được khôi phục thông qua `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Tạo `Rc<T>` từ một con trỏ thô.
    ///
    /// Con trỏ thô phải được trả về trước đó bằng một lệnh gọi tới [`Rc<U>::into_raw`][into_raw] trong đó `U` phải có cùng kích thước và căn chỉnh như `T`.
    /// Điều này hoàn toàn đúng nếu `U` là `T`.
    /// Lưu ý rằng nếu `U` không phải là `T` nhưng có cùng kích thước và căn chỉnh, thì về cơ bản điều này giống như việc chuyển đổi các tham chiếu của các loại khác nhau.
    /// Xem [`mem::transmute`][transmute] để biết thêm thông tin về những hạn chế nào áp dụng trong trường hợp này.
    ///
    /// Người dùng `from_raw` phải đảm bảo rằng một giá trị cụ thể của `T` chỉ bị giảm một lần.
    ///
    /// Chức năng này không an toàn vì sử dụng không đúng cách có thể dẫn đến mất an toàn bộ nhớ, ngay cả khi `Rc<T>` trả về không bao giờ được truy cập.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Chuyển đổi trở lại `Rc` để ngăn rò rỉ.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Các cuộc gọi tiếp theo tới `Rc::from_raw(x_ptr)` sẽ không an toàn về bộ nhớ.
    /// }
    ///
    /// // Bộ nhớ đã được giải phóng khi `x` vượt ra khỏi phạm vi ở trên, vì vậy `x_ptr` hiện đang treo lơ lửng!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Đảo ngược phần bù để tìm RcBox ban đầu.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Tạo một con trỏ [`Weak`] mới cho phân bổ này.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Đảm bảo rằng chúng tôi không tạo ra một Điểm yếu lủng lẳng
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Nhận số lượng con trỏ [`Weak`] đến phân bổ này.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Nhận số lượng con trỏ (`Rc`) mạnh đến phân bổ này.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Trả về `true` nếu không có con trỏ `Rc` hoặc [`Weak`] nào khác tới phân bổ này.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Trả về một tham chiếu có thể thay đổi vào `Rc` đã cho, nếu không có con trỏ `Rc` hoặc [`Weak`] nào khác đến cùng một phân bổ.
    ///
    ///
    /// Trả về [`None`] nếu không, vì không an toàn khi thay đổi giá trị được chia sẻ.
    ///
    /// Xem thêm [`make_mut`][make_mut], [`clone`][clone] sẽ là giá trị bên trong khi có các con trỏ khác.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Trả về một tham chiếu có thể thay đổi vào `Rc` đã cho mà không cần kiểm tra.
    ///
    /// Xem thêm [`get_mut`], an toàn và kiểm tra thích hợp.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Bất kỳ con trỏ `Rc` hoặc [`Weak`] nào khác đến cùng một phân bổ không được tham chiếu đến trong suốt thời gian của khoản vay đã trả lại.
    ///
    /// Đây là trường hợp nhỏ nếu không có con trỏ nào như vậy tồn tại, ví dụ ngay sau `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Chúng tôi cẩn thận *không* tạo một tham chiếu bao gồm các trường "count", vì điều này sẽ xung đột với quyền truy cập vào số lượng tham chiếu (ví dụ:
        // bởi `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Trả về `true` nếu hai `Rc` trỏ đến cùng một phân bổ (trong mạch tương tự như [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Tạo một tham chiếu có thể thay đổi vào `Rc` đã cho.
    ///
    /// Nếu có các con trỏ `Rc` khác đến cùng một phân bổ, thì `make_mut` sẽ [`clone`] giá trị bên trong cho một phân bổ mới để đảm bảo quyền sở hữu duy nhất.
    /// Điều này cũng được gọi là sao chép trên ghi.
    ///
    /// Nếu không có con trỏ `Rc` nào khác tới phân bổ này, thì con trỏ [`Weak`] tới phân bổ này sẽ bị tách ra.
    ///
    /// Xem thêm [`get_mut`], sẽ không thành công hơn là nhân bản.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Sẽ không sao chép bất cứ thứ gì
    /// let mut other_data = Rc::clone(&data);    // Sẽ không sao chép dữ liệu bên trong
    /// *Rc::make_mut(&mut data) += 1;        // Sao chép dữ liệu bên trong
    /// *Rc::make_mut(&mut data) += 1;        // Sẽ không sao chép bất cứ thứ gì
    /// *Rc::make_mut(&mut other_data) *= 2;  // Sẽ không sao chép bất cứ thứ gì
    ///
    /// // Bây giờ `data` và `other_data` trỏ đến các phân bổ khác nhau.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] các con trỏ sẽ bị tách ra:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Gotta sao chép dữ liệu, có những Rcs khác.
            // Cấp phát trước bộ nhớ để cho phép ghi trực tiếp giá trị được nhân bản.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Chỉ có thể đánh cắp dữ liệu, tất cả những gì còn lại là Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Xóa giới thiệu mạnh-yếu tiềm ẩn (không cần tạo yếu tố giả mạo ở đây-chúng tôi biết các Weak khác có thể dọn dẹp cho chúng tôi)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Sự không an toàn này là ổn vì chúng tôi đảm bảo rằng con trỏ được trả về là con trỏ *duy nhất* sẽ được trả về T.
        // Số tham chiếu của chúng tôi được đảm bảo là 1 tại thời điểm này và chúng tôi yêu cầu bản thân `Rc<T>` phải là `mut`, vì vậy chúng tôi đang trả lại tham chiếu duy nhất có thể có cho phân bổ.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Cố gắng hạ thấp `Rc<dyn Any>` xuống loại bê tông.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Phân bổ `RcBox<T>` với đủ không gian cho giá trị bên trong có thể chưa được kích thước, nơi giá trị có bố cục được cung cấp.
    ///
    /// Hàm `mem_to_rcbox` được gọi với con trỏ dữ liệu và phải trả về một con trỏ (có khả năng béo) cho `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Tính toán bố cục bằng cách sử dụng bố cục giá trị đã cho.
        // Trước đây, bố cục được tính toán trên biểu thức `&*(ptr as* const RcBox<T>)`, nhưng điều này đã tạo ra một tham chiếu bị lệch (xem #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Phân bổ `RcBox<T>` với đủ không gian cho giá trị bên trong có thể chưa được kích thước trong đó giá trị có bố cục được cung cấp, trả về lỗi nếu phân bổ không thành công.
    ///
    ///
    /// Hàm `mem_to_rcbox` được gọi với con trỏ dữ liệu và phải trả về một con trỏ (có khả năng béo) cho `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Tính toán bố cục bằng cách sử dụng bố cục giá trị đã cho.
        // Trước đây, bố cục được tính toán trên biểu thức `&*(ptr as* const RcBox<T>)`, nhưng điều này đã tạo ra một tham chiếu bị lệch (xem #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Phân bổ cho bố cục.
        let ptr = allocate(layout)?;

        // Khởi tạo RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Phân bổ `RcBox<T>` với đủ không gian cho giá trị bên trong chưa được kích thước
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Phân bổ cho `RcBox<T>` bằng cách sử dụng giá trị đã cho.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Sao chép giá trị dưới dạng byte
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Giải phóng phân bổ mà không làm rơi nội dung của nó
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Phân bổ một `RcBox<[T]>` với độ dài đã cho.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Sao chép các phần tử từ lát vào Rc mới được cấp phát <\[T\]>
    ///
    /// Không an toàn vì người gọi phải có quyền sở hữu hoặc ràng buộc `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Tạo `Rc<[T]>` từ một trình lặp được biết là có kích thước nhất định.
    ///
    /// Hành vi không được xác định nên kích thước sai.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic bảo vệ trong khi nhân bản các phần tử T.
        // Trong trường hợp có panic, các phần tử đã được ghi vào RcBox mới sẽ bị loại bỏ, sau đó bộ nhớ được giải phóng.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Con trỏ đến phần tử đầu tiên
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Tất cả rõ ràng.Quên bảo vệ để nó không giải phóng RcBox mới.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Chuyên trait dùng cho `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Bỏ `Rc`.
    ///
    /// Điều này sẽ làm giảm số lượng tham chiếu mạnh mẽ.
    /// Nếu số lượng tham chiếu mạnh bằng không thì các tham chiếu khác (nếu có) duy nhất là [`Weak`], vì vậy chúng tôi `drop` giá trị bên trong.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Không in bất cứ thứ gì
    /// drop(foo2);   // In "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // phá hủy đối tượng được chứa
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // loại bỏ con trỏ "strong weak" tiềm ẩn ngay bây giờ mà chúng tôi đã phá hủy nội dung.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Tạo bản sao của con trỏ `Rc`.
    ///
    /// Điều này tạo ra một con trỏ khác đến cùng một phân bổ, làm tăng số lượng tham chiếu mạnh mẽ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Tạo `Rc<T>` mới, với giá trị `Default` cho `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack để cho phép chuyên về `Eq` mặc dù `Eq` có một phương pháp.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Chúng tôi đang thực hiện chuyên môn hóa này ở đây, không phải là tối ưu hóa chung chung hơn trên `&T`, bởi vì nếu không, nó sẽ thêm chi phí cho tất cả các lần kiểm tra bình đẳng trên refs.
/// Chúng tôi giả định rằng `Rc` được sử dụng để lưu trữ các giá trị lớn, chậm được sao chép, nhưng cũng nặng để kiểm tra sự bình đẳng, khiến chi phí này dễ dàng thanh toán hơn.
///
/// Nó cũng có nhiều khả năng có hai bản sao `Rc`, chỉ đến cùng một giá trị, hơn hai chữ `&T`.
///
/// Chúng tôi chỉ có thể làm điều này khi `T: Eq` dưới dạng `PartialEq` có thể cố tình không linh hoạt.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Bằng nhau cho hai `Rc`.
    ///
    /// Hai `Rc` bằng nhau nếu giá trị bên trong của chúng bằng nhau, ngay cả khi chúng được lưu trữ trong phân bổ khác nhau.
    ///
    /// Nếu `T` cũng triển khai `Eq` (ngụ ý tính phản xạ của bình đẳng), hai `Rc` trỏ đến cùng một phân bổ luôn bằng nhau.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Bất đẳng thức cho hai `Rc`.
    ///
    /// Hai `Rc` không bằng nhau nếu giá trị bên trong của chúng không bằng nhau.
    ///
    /// Nếu `T` cũng triển khai `Eq` (ngụ ý tính phản xạ của sự bình đẳng), hai `Rc` trỏ đến cùng một phân bổ không bao giờ là không bằng nhau.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// So sánh một phần cho hai `Rc`.
    ///
    /// Cả hai được so sánh bằng cách gọi `partial_cmp()` trên các giá trị bên trong của chúng.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// So sánh nhỏ hơn cho hai `Rc`.
    ///
    /// Cả hai được so sánh bằng cách gọi `<` trên các giá trị bên trong của chúng.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// So sánh 'nhỏ hơn hoặc bằng' cho hai 'Rc`.
    ///
    /// Cả hai được so sánh bằng cách gọi `<=` trên các giá trị bên trong của chúng.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// So sánh lớn hơn cho hai `Rc`.
    ///
    /// Cả hai được so sánh bằng cách gọi `>` trên các giá trị bên trong của chúng.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// So sánh 'Lớn hơn hoặc bằng' cho hai 'Rc`.
    ///
    /// Cả hai được so sánh bằng cách gọi `>=` trên các giá trị bên trong của chúng.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// So sánh hai `Rc`.
    ///
    /// Cả hai được so sánh bằng cách gọi `cmp()` trên các giá trị bên trong của chúng.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Phân bổ một lát được tính tham chiếu và lấp đầy nó bằng cách sao chép các mục của `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Phân bổ một lát chuỗi được tính tham chiếu và sao chép `v` vào đó.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Phân bổ một lát chuỗi được tính tham chiếu và sao chép `v` vào đó.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Di chuyển một đối tượng được đóng hộp sang một phân bổ mới, được tính tham chiếu.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Phân bổ một lát được tính tham chiếu và di chuyển các mục của `v` vào đó.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Cho phép Vec giải phóng bộ nhớ của nó, nhưng không phá hủy nội dung của nó
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Lấy từng phần tử trong `Iterator` và thu thập nó thành `Rc<[T]>`.
    ///
    /// # Đặc điểm hiệu suất
    ///
    /// ## Trường hợp chung
    ///
    /// Trong trường hợp chung, việc thu thập vào `Rc<[T]>` được thực hiện bằng cách thu thập vào `Vec<T>` trước.Đó là, khi viết như sau:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// điều này hoạt động như thể chúng tôi đã viết:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Tập hợp phân bổ đầu tiên xảy ra ở đây.
    ///     .into(); // Phân bổ thứ hai cho `Rc<[T]>` xảy ra ở đây.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Điều này sẽ phân bổ nhiều lần nếu cần để xây dựng `Vec<T>` và sau đó nó sẽ phân bổ một lần để biến `Vec<T>` thành `Rc<[T]>`.
    ///
    ///
    /// ## Trình lặp có độ dài đã biết
    ///
    /// Khi `Iterator` của bạn triển khai `TrustedLen` và có kích thước chính xác, một phân bổ duy nhất sẽ được thực hiện cho `Rc<[T]>`.Ví dụ:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Chỉ một phân bổ duy nhất xảy ra ở đây.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Chuyên trait dùng để thu vào `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Đây là trường hợp của một trình lặp `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // AN TOÀN: Chúng tôi cần đảm bảo rằng trình vòng lặp có độ dài chính xác và chúng tôi có.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Trở lại thực hiện bình thường.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` là phiên bản của [`Rc`] có tham chiếu không sở hữu đến phân bổ được quản lý.Việc phân bổ được truy cập bằng cách gọi [`upgrade`] trên con trỏ `Weak`, trả về [`Option`]`<`[`Rc`] `<T>>`.
///
/// Vì tham chiếu `Weak` không được tính vào quyền sở hữu, nên nó sẽ không ngăn giá trị được lưu trữ trong phân bổ bị giảm và bản thân `Weak` không đảm bảo về giá trị vẫn hiện diện.
/// Do đó, nó có thể trả về [`None`] khi [`nâng cấp`] d.
/// Tuy nhiên, lưu ý rằng tham chiếu `Weak`*không* ngăn chính phân bổ (kho dự phòng) được phân bổ theo thỏa thuận.
///
/// Con trỏ `Weak` hữu ích để giữ một tham chiếu tạm thời đến phân bổ được quản lý bởi [`Rc`] mà không ngăn giá trị bên trong của nó bị giảm.
/// Nó cũng được sử dụng để ngăn chặn các tham chiếu vòng giữa các con trỏ [`Rc`], vì các tham chiếu sở hữu lẫn nhau sẽ không bao giờ cho phép bỏ [`Rc`].
/// Ví dụ: một cây có thể có con trỏ [`Rc`] mạnh từ các nút cha đến nút con và con trỏ `Weak` từ con quay lại cha mẹ của chúng.
///
/// Cách điển hình để lấy con trỏ `Weak` là gọi [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Đây là `NonNull` cho phép tối ưu hóa kích thước của loại này trong enums, nhưng nó không nhất thiết phải là một con trỏ hợp lệ.
    //
    // `Weak::new` đặt giá trị này thành `usize::MAX` để nó không cần phân bổ không gian trên heap.
    // Đó không phải là một giá trị mà một con trỏ thực sẽ có bởi vì RcBox có ít nhất là 2 căn chỉnh.
    // Điều này chỉ có thể thực hiện được khi `T: Sized`;`T` không kích thước không bao giờ treo.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Xây dựng một `Weak<T>` mới mà không cần cấp phát bất kỳ bộ nhớ nào.
    /// Gọi [`upgrade`] trên giá trị trả về luôn cho [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Loại trình trợ giúp để cho phép truy cập số lượng tham chiếu mà không cần đưa ra bất kỳ xác nhận nào về trường dữ liệu.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Trả về một con trỏ thô cho đối tượng `T` được trỏ tới bởi `Weak<T>` này.
    ///
    /// Con trỏ chỉ hợp lệ nếu có một số tham chiếu mạnh.
    /// Con trỏ có thể treo lơ lửng, không liên kết hoặc thậm chí là [`null`] nếu không.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Cả hai đều trỏ đến cùng một đối tượng
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Strong ở đây giữ cho nó tồn tại, vì vậy chúng ta vẫn có thể tiếp cận đối tượng.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Nhưng không còn nữa.
    /// // Chúng ta có thể làm weak.as_ptr(), nhưng việc truy cập con trỏ sẽ dẫn đến hành vi không xác định.
    /// // khẳng định_eq! ("xin chào", không an toàn {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Nếu con trỏ treo lơ lửng, chúng tôi sẽ trả lại trực tiếp cho trạm gác.
            // Đây không thể là địa chỉ trọng tải hợp lệ, vì tải trọng ít nhất cũng được căn chỉnh như RcBox (usize).
            ptr as *const T
        } else {
            // AN TOÀN: nếu is_dangling trả về false, thì con trỏ là không thể chọn được.
            // Tải trọng có thể bị giảm vào thời điểm này và chúng tôi phải duy trì xuất xứ, vì vậy hãy sử dụng thao tác con trỏ thô.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Sử dụng `Weak<T>` và biến nó thành một con trỏ thô.
    ///
    /// Điều này chuyển đổi con trỏ yếu thành một con trỏ thô, trong khi vẫn bảo toàn quyền sở hữu của một tham chiếu yếu (số lượng yếu không được sửa đổi bởi thao tác này).
    /// Nó có thể được quay trở lại `Weak<T>` với [`from_raw`].
    ///
    /// Các hạn chế truy cập mục tiêu của con trỏ tương tự như với [`as_ptr`] cũng được áp dụng.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Chuyển đổi một con trỏ thô do [`into_raw`] tạo trước đó trở lại thành `Weak<T>`.
    ///
    /// Điều này có thể được sử dụng để có được một tham chiếu mạnh một cách an toàn (bằng cách gọi [`upgrade`] sau này) hoặc để phân bổ số lượng yếu bằng cách thả `Weak<T>`.
    ///
    /// Nó có quyền sở hữu một tham chiếu yếu (ngoại trừ các con trỏ được tạo bởi [`new`], vì chúng không sở hữu bất cứ thứ gì; phương pháp vẫn hoạt động trên chúng).
    ///
    /// # Safety
    ///
    /// Con trỏ phải có nguồn gốc từ [`into_raw`] và vẫn phải sở hữu tham chiếu yếu tiềm ẩn của nó.
    ///
    /// Cho phép số mạnh là 0 tại thời điểm gọi giá trị này.
    /// Tuy nhiên, điều này có quyền sở hữu một tham chiếu yếu hiện được biểu diễn dưới dạng con trỏ thô (số yếu không được sửa đổi bởi thao tác này) và do đó nó phải được ghép nối với một lệnh gọi trước đó tới [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Giảm số lượng yếu cuối cùng.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Xem Weak::as_ptr để biết ngữ cảnh về cách con trỏ đầu vào được tạo ra.

        let ptr = if is_dangling(ptr as *mut T) {
            // Đây là một điểm yếu treo lơ lửng.
            ptr as *mut RcBox<T>
        } else {
            // Nếu không, chúng tôi đảm bảo rằng con trỏ đến từ Điểm yếu không liên quan.
            // AN TOÀN: data_offset an toàn để gọi, vì ptr tham chiếu đến một T thực (có khả năng bị loại bỏ).
            let offset = unsafe { data_offset(ptr) };
            // Do đó, chúng tôi đảo ngược phần bù để có được toàn bộ RcBox.
            // AN TOÀN: con trỏ bắt nguồn từ Điểm yếu, vì vậy điểm bù này là an toàn.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // AN TOÀN: bây giờ chúng tôi đã khôi phục con trỏ Điểm yếu ban đầu, vì vậy có thể tạo Điểm yếu.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Cố gắng nâng cấp con trỏ `Weak` lên [`Rc`], trì hoãn việc giảm giá trị bên trong nếu thành công.
    ///
    ///
    /// Trả về [`None`] nếu giá trị bên trong đã bị loại bỏ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Tiêu diệt tất cả các điểm mạnh.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Nhận số lượng con trỏ (`Rc`) mạnh trỏ đến phân bổ này.
    ///
    /// Nếu `self` được tạo bằng [`Weak::new`], giá trị này sẽ trả về 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Nhận số lượng con trỏ `Weak` trỏ đến phân bổ này.
    ///
    /// Nếu không còn con trỏ mạnh nào, giá trị này sẽ trả về 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // trừ ptr yếu tiềm ẩn
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Trả về `None` khi con trỏ treo và không có `RcBox` được cấp phát, (tức là khi `Weak` này được tạo bởi `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Chúng tôi cẩn thận *không* tạo một tham chiếu bao gồm trường "data", vì trường có thể bị thay đổi đồng thời (ví dụ: nếu `Rc` cuối cùng bị xóa, trường dữ liệu sẽ bị xóa tại chỗ).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Trả về `true` nếu hai điểm yếu 'trỏ đến cùng một phân bổ (tương tự như [`ptr::eq`]) hoặc nếu cả hai không trỏ đến bất kỳ phân bổ nào (vì chúng được tạo bằng `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Vì điều này so sánh các con trỏ nên có nghĩa là `Weak::new()` sẽ bằng nhau, mặc dù chúng không trỏ đến bất kỳ phân bổ nào.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// So sánh `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Làm rơi con trỏ `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Không in bất cứ thứ gì
    /// drop(foo);        // In "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // số điểm yếu bắt đầu từ 1 và sẽ chỉ về 0 nếu tất cả các con trỏ mạnh đã biến mất.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Tạo bản sao của con trỏ `Weak` trỏ đến cùng một phân bổ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Xây dựng `Weak<T>` mới, cấp phát bộ nhớ cho `T` mà không cần khởi tạo nó.
    /// Gọi [`upgrade`] trên giá trị trả về luôn cho [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Chúng tôi đã check_add ở đây để xử lý mem::forget một cách an toàn.Đặc biệt
// nếu bạn mem::forget Rcs (hoặc Weak), số lần tham chiếu có thể bị tràn và sau đó bạn có thể giải phóng phân bổ trong khi tồn tại các Rcs (hoặc Weak) chưa xuất hiện.
//
// Chúng tôi hủy bỏ bởi vì đây là một kịch bản thoái hóa đến mức chúng tôi không quan tâm đến những gì sẽ xảy ra-không một chương trình thực tế nào phải trải nghiệm điều này.
//
// Điều này sẽ có chi phí không đáng kể vì bạn không thực sự cần sao chép những thứ này nhiều trong Rust nhờ quyền sở hữu và ngữ nghĩa chuyển động.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Chúng tôi muốn hủy bỏ khi tràn thay vì giảm giá trị.
        // Số tham chiếu sẽ không bao giờ bằng 0 khi điều này được gọi;
        // tuy nhiên, chúng tôi chèn một lược bỏ ở đây để gợi ý LLVM về một cách tối ưu hóa bị bỏ lỡ.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Chúng tôi muốn hủy bỏ khi tràn thay vì giảm giá trị.
        // Số tham chiếu sẽ không bao giờ bằng 0 khi điều này được gọi;
        // tuy nhiên, chúng tôi chèn một lược bỏ ở đây để gợi ý LLVM về một cách tối ưu hóa bị bỏ lỡ.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Nhận phần bù trong `RcBox` cho tải trọng đằng sau một con trỏ.
///
/// # Safety
///
/// Con trỏ phải trỏ đến (và có siêu dữ liệu hợp lệ cho) một phiên bản hợp lệ trước đó của T, nhưng T được phép bỏ đi.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Căn chỉnh giá trị chưa được kích thước vào cuối RcBox.
    // Vì RcBox là repr(C) nên nó sẽ luôn là trường cuối cùng trong bộ nhớ.
    // AN TOÀN: vì các loại không kích thước duy nhất có thể là các lát cắt, các đối tượng trait,
    // và các loại extern, yêu cầu an toàn đầu vào hiện đủ để thỏa mãn các yêu cầu của align_of_val_raw;đây là chi tiết triển khai của ngôn ngữ có thể không được dựa vào bên ngoài std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}