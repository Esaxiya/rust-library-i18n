#![stable(feature = "wake_trait", since = "1.51.0")]
//! Các loại và Traits để làm việc với các tác vụ không đồng bộ.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Việc thực hiện đánh thức một nhiệm vụ trên một người thực thi.
///
/// trait này có thể được sử dụng để tạo [`Waker`].
/// Một người thực thi có thể xác định một triển khai của trait này và sử dụng nó để xây dựng một Waker để chuyển cho các tác vụ được thực thi trên trình thực thi đó.
///
/// trait này là một giải pháp thay thế an toàn cho bộ nhớ và công thái học để xây dựng một [`RawWaker`].
/// Nó hỗ trợ thiết kế trình thực thi phổ biến trong đó dữ liệu được sử dụng để đánh thức một tác vụ được lưu trữ trong [`Arc`].
/// Một số người thực thi (đặc biệt là những người dùng cho hệ thống nhúng) không thể sử dụng API này, đó là lý do tại sao [`RawWaker`] tồn tại như một sự thay thế cho các hệ thống đó.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Một hàm `block_on` cơ bản sử dụng future và chạy nó đến khi hoàn thành trên luồng hiện tại.
///
/// **Note:** Ví dụ này giao dịch tính đúng đắn cho đơn giản.
/// Để ngăn chặn deadlock, các triển khai cấp sản xuất cũng sẽ cần xử lý các lệnh gọi trung gian tới `thread::unpark` cũng như các lệnh gọi lồng nhau.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Một waker đánh thức luồng hiện tại khi được gọi.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Chạy future để hoàn thành trên luồng hiện tại.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Ghim future để nó có thể được thăm dò ý kiến.
///     let mut fut = Box::pin(fut);
///
///     // Tạo một bối cảnh mới để được chuyển đến future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Chạy future để hoàn thành.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Đánh thức nhiệm vụ này.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Đánh thức nhiệm vụ này mà không cần tiêu thụ waker.
    ///
    /// Nếu một người thực thi hỗ trợ một cách rẻ hơn để đánh thức mà không tiêu thụ waker, thì nó sẽ ghi đè phương thức này.
    /// Theo mặc định, nó sao chép [`Arc`] và gọi [`wake`] trên bản sao.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // AN TOÀN: Điều này là an toàn vì raw_waker xây dựng một cách an toàn
        // một RawWaker từ Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Chức năng riêng tư này để xây dựng một RawWaker được sử dụng, thay vì
// nội tuyến điều này vào hàm `From<Arc<W>> for RawWaker`, để đảm bảo rằng sự an toàn của `From<Arc<W>> for Waker` không phụ thuộc vào công văn trait chính xác, thay vào đó, cả hai hàm này đều gọi hàm này một cách trực tiếp và rõ ràng.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Tăng số lượng tham chiếu của cung để sao chép nó.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Đánh thức theo giá trị, di chuyển Arc vào chức năng Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Đánh thức bằng cách tham khảo, bọc waker trong ManentlyDrop để tránh làm rơi nó
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Giảm số lượng tham chiếu của Arc khi giảm
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}