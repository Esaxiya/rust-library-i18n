//! Chế độ xem có kích thước động thành một chuỗi liền kề, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Slices là một khung nhìn vào một khối bộ nhớ được biểu diễn dưới dạng con trỏ và chiều dài.
//!
//! ```
//! // cắt một Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // ép buộc một mảng thành một lát
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Các lát cắt có thể thay đổi hoặc chia sẻ.
//! Loại lát chia sẻ là `&[T]`, trong khi loại lát cắt có thể thay đổi là `&mut [T]`, trong đó `T` đại diện cho loại phần tử.
//! Ví dụ: bạn có thể thay đổi khối bộ nhớ mà một lát có thể thay đổi trỏ đến:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Dưới đây là một số điều mà mô-đun này chứa:
//!
//! ## Structs
//!
//! Có một số cấu trúc hữu ích cho các lát, chẳng hạn như [`Iter`], biểu thị sự lặp lại trên một lát.
//!
//! ## Triển khai Trait
//!
//! Có một số triển khai của traits phổ biến cho các lát.Một số ví dụ bao gồm:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], dành cho các lát có kiểu phần tử là [`Eq`] hoặc [`Ord`].
//! * [`Hash`] - cho các lát có kiểu phần tử là [`Hash`].
//!
//! ## Iteration
//!
//! Các lát thực hiện `IntoIterator`.Trình lặp mang lại các tham chiếu đến các phần tử của lát cắt.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Slice có thể thay đổi mang lại các tham chiếu có thể thay đổi đến các phần tử:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Trình vòng lặp này mang lại các tham chiếu có thể thay đổi đến các phần tử của lát cắt, vì vậy trong khi loại phần tử của lát cắt là `i32`, thì kiểu phần tử của trình lặp là `&mut i32`.
//!
//!
//! * [`.iter`] và [`.iter_mut`] là các phương thức rõ ràng để trả về các trình vòng lặp mặc định.
//! * Các phương pháp khác trả về trình vòng lặp là [`.split`], [`.splitn`], [`.chunks`], [`.windows`] và hơn thế nữa.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Nhiều ứng dụng trong mô-đun này chỉ được sử dụng trong cấu hình thử nghiệm.
// Sẽ tốt hơn nếu bạn chỉ tắt cảnh báo used_imports hơn là sửa chúng.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Các phương pháp mở rộng lát cơ bản
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) cần thiết cho việc triển khai macro `vec!` trong quá trình thử nghiệm NB, hãy xem mô-đun `hack` trong tệp này để biết thêm chi tiết.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) cần thiết cho việc triển khai `Vec::clone` trong quá trình thử nghiệm NB, hãy xem mô-đun `hack` trong tệp này để biết thêm chi tiết.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Với cfg(test) thì không có `impl [T]`, ba chức năng này thực chất là các phương thức có trong `impl [T]` nhưng không có trong `core::slice::SliceExt`, chúng tôi cần cung cấp các chức năng này cho bài kiểm tra `test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Chúng ta không nên thêm thuộc tính nội tuyến vào thuộc tính này vì nó được sử dụng chủ yếu trong macro `vec!` và gây ra hồi quy hoàn chỉnh.
    // Xem #71204 để biết kết quả thảo luận và hiệu suất.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // các mục đã được đánh dấu là khởi tạo trong vòng lặp bên dưới
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) là cần thiết cho LLVM để loại bỏ kiểm tra giới hạn và có codegen tốt hơn zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec đã được cấp phát và khởi tạo ở trên với độ dài ít nhất là này.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // được phân bổ ở trên với dung lượng `s` và khởi tạo thành `s.len()` trong ptr::copy_to_non_overlapping bên dưới.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Sắp xếp lát cắt.
    ///
    /// Cách sắp xếp này ổn định (tức là không sắp xếp lại các phần tử bằng nhau) và *O*(*n*\*log(* n*)) trường hợp xấu nhất.
    ///
    /// Khi có thể, sắp xếp không ổn định được ưu tiên hơn vì nó thường nhanh hơn sắp xếp ổn định và nó không cấp phát bộ nhớ phụ.
    /// Xem [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Triển khai hiện tại
    ///
    /// Thuật toán hiện tại là một loại hợp nhất lặp đi lặp lại, thích ứng được lấy cảm hứng từ [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Nó được thiết kế để rất nhanh trong trường hợp lát cắt gần như được sắp xếp, hoặc bao gồm hai hoặc nhiều chuỗi được sắp xếp nối tiếp nhau.
    ///
    ///
    /// Ngoài ra, nó phân bổ lưu trữ tạm thời bằng một nửa kích thước của `self`, nhưng đối với các lát cắt ngắn, loại chèn không phân bổ được sử dụng để thay thế.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Sắp xếp lát cắt bằng hàm so sánh.
    ///
    /// Cách sắp xếp này ổn định (tức là không sắp xếp lại các phần tử bằng nhau) và *O*(*n*\*log(* n*)) trường hợp xấu nhất.
    ///
    /// Hàm so sánh phải xác định thứ tự tổng số cho các phần tử trong lát cắt.Nếu thứ tự không phải là tổng số, thứ tự của các phần tử là không xác định.
    /// Một đơn đặt hàng là tổng đơn đặt hàng nếu nó là (cho tất cả `a`, `b` và `c`):
    ///
    /// * tổng và phản đối xứng: chính xác một trong các `a < b`, `a == b` hoặc `a > b` là đúng, và
    /// * bắc cầu, `a < b` và `b < c` ngụ ý `a < c`.Điều tương tự phải giữ cho cả `==` và `>`.
    ///
    /// Ví dụ: trong khi [`f64`] không triển khai [`Ord`] vì `NaN != NaN`, chúng ta có thể sử dụng `partial_cmp` làm hàm sắp xếp khi chúng ta biết lát cắt không chứa `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Khi có thể, sắp xếp không ổn định được ưu tiên hơn vì nó thường nhanh hơn sắp xếp ổn định và nó không cấp phát bộ nhớ phụ.
    /// Xem [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Triển khai hiện tại
    ///
    /// Thuật toán hiện tại là một loại hợp nhất lặp đi lặp lại, thích ứng được lấy cảm hứng từ [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Nó được thiết kế để rất nhanh trong trường hợp lát cắt gần như được sắp xếp, hoặc bao gồm hai hoặc nhiều chuỗi được sắp xếp nối tiếp nhau.
    ///
    /// Ngoài ra, nó phân bổ lưu trữ tạm thời bằng một nửa kích thước của `self`, nhưng đối với các lát cắt ngắn, loại chèn không phân bổ được sử dụng để thay thế.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // sắp xếp ngược lại
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Sắp xếp lát cắt bằng chức năng trích xuất khóa.
    ///
    /// Cách sắp xếp này ổn định (tức là không sắp xếp lại các phần tử bằng nhau) và *O*(*m*\* * n *\* log(*n*)) trường hợp xấu nhất, trong đó hàm chính là *O*(*m*).
    ///
    /// Đối với các chức năng chính đắt tiền (ví dụ:
    /// các chức năng không phải là truy cập thuộc tính đơn giản hoặc các hoạt động cơ bản), [`sort_by_cached_key`](slice::sort_by_cached_key) có thể nhanh hơn đáng kể, vì nó không tính toán lại các khóa phần tử.
    ///
    ///
    /// Khi có thể, sắp xếp không ổn định được ưu tiên hơn vì nó thường nhanh hơn sắp xếp ổn định và nó không cấp phát bộ nhớ phụ.
    /// Xem [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Triển khai hiện tại
    ///
    /// Thuật toán hiện tại là một loại hợp nhất lặp đi lặp lại, thích ứng được lấy cảm hứng từ [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Nó được thiết kế để rất nhanh trong trường hợp lát cắt gần như được sắp xếp, hoặc bao gồm hai hoặc nhiều chuỗi được sắp xếp nối tiếp nhau.
    ///
    /// Ngoài ra, nó phân bổ lưu trữ tạm thời bằng một nửa kích thước của `self`, nhưng đối với các lát cắt ngắn, loại chèn không phân bổ được sử dụng để thay thế.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Sắp xếp lát cắt bằng chức năng trích xuất khóa.
    ///
    /// Trong quá trình sắp xếp, hàm phím chỉ được gọi một lần cho mỗi phần tử.
    ///
    /// Cách sắp xếp này ổn định (tức là không sắp xếp lại các phần tử bằng nhau) và *O*(*m*\* * n *+* n *\* Trường hợp xấu nhất log(*n*)), trong đó hàm chính là *O*(*m*) .
    ///
    /// Đối với các chức năng chính đơn giản (ví dụ: các chức năng là quyền truy cập thuộc tính hoặc hoạt động cơ bản), [`sort_by_key`](slice::sort_by_key) có thể nhanh hơn.
    ///
    /// # Triển khai hiện tại
    ///
    /// Thuật toán hiện tại dựa trên [pattern-defeating quicksort][pdqsort] của Orson Peters, kết hợp trường hợp trung bình nhanh của nhanh ngẫu nhiên ngẫu nhiên với trường hợp xấu nhất nhanh nhất của heapsort, đồng thời đạt được thời gian tuyến tính trên các lát có các mẫu nhất định.
    /// Nó sử dụng một số ngẫu nhiên để tránh các trường hợp suy biến, nhưng với seed cố định để luôn cung cấp hành vi xác định.
    ///
    /// Trong trường hợp xấu nhất, thuật toán phân bổ lưu trữ tạm thời theo độ dài của lát cắt là `Vec<(K, usize)>`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Macro trình trợ giúp lập chỉ mục vector của chúng tôi theo loại nhỏ nhất có thể, để giảm phân bổ.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Các phần tử của `indices` là duy nhất, vì chúng được lập chỉ mục, vì vậy bất kỳ cách sắp xếp nào cũng sẽ ổn định đối với phần gốc.
                // Chúng tôi sử dụng `sort_unstable` ở đây vì nó yêu cầu cấp phát bộ nhớ ít hơn.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Sao chép `self` thành `Vec` mới.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Ở đây, `s` và `x` có thể được sửa đổi độc lập.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Sao chép `self` thành `Vec` mới với bộ cấp phát.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Ở đây, `s` và `x` có thể được sửa đổi độc lập.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, hãy xem mô-đun `hack` trong tệp này để biết thêm chi tiết.
        hack::to_vec(self, alloc)
    }

    /// Chuyển đổi `self` thành vector mà không cần sao chép hoặc phân bổ.
    ///
    /// vector kết quả có thể được chuyển đổi trở lại thành một hộp thông qua `Vec<T>Phương thức `into_boxed_slice` của`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` không thể sử dụng được nữa vì nó đã được chuyển đổi thành `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, hãy xem mô-đun `hack` trong tệp này để biết thêm chi tiết.
        hack::into_vec(self)
    }

    /// Tạo vector bằng cách lặp lại một lát `n` lần.
    ///
    /// # Panics
    ///
    /// Hàm này sẽ panic nếu dung lượng tràn.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// A panic khi tràn:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Nếu `n` lớn hơn 0, nó có thể được chia thành `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` là số được biểu thị bằng bit '1' ngoài cùng bên trái của `n` và `rem` là phần còn lại của `n`.
        //
        //

        // Sử dụng `Vec` để truy cập `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` lặp lại được thực hiện bằng cách nhân đôi `buf` `expn`-lần.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Nếu `m > 0`, có các bit còn lại tính đến '1' ngoài cùng bên trái.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` có dung lượng `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` Việc lặp lại (`=n, 2 ^ expn`) được thực hiện bằng cách sao chép các lần lặp lại `rem` đầu tiên từ chính `buf`.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Điều này là không chồng chéo kể từ `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` bằng `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Làm phẳng một lát `T` thành một giá trị `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Làm phẳng một lát `T` thành một giá trị `Self::Output`, đặt một dấu phân cách nhất định giữa mỗi phần.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Làm phẳng một lát `T` thành một giá trị `Self::Output`, đặt một dấu phân cách nhất định giữa mỗi phần.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Trả về vector có chứa một bản sao của lát cắt này trong đó mỗi byte được ánh xạ tới tương đương chữ hoa ASCII của nó.
    ///
    ///
    /// Các chữ cái ASCII 'a' đến 'z' được ánh xạ thành 'A' đến 'Z', nhưng các chữ cái không phải ASCII thì không thay đổi.
    ///
    /// Để viết hoa giá trị tại chỗ, hãy sử dụng [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Trả về một vector chứa một bản sao của lát này trong đó mỗi byte được ánh xạ tới tương đương chữ thường ASCII của nó.
    ///
    ///
    /// Các chữ cái ASCII 'A' đến 'Z' được ánh xạ thành 'a' đến 'z', nhưng các chữ cái không phải ASCII thì không thay đổi.
    ///
    /// Để viết thường giá trị tại chỗ, hãy sử dụng [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Phần mở rộng traits dành cho các lát cắt trên các loại dữ liệu cụ thể
////////////////////////////////////////////////////////////////////////////////

/// Trình trợ giúp trait cho [`[T]: : concat`](slice::concat).
///
/// Note: tham số loại `Item` không được sử dụng trong trait này, nhưng nó cho phép hiển thị chung chung hơn.
/// Nếu không có nó, chúng tôi gặp lỗi này:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Điều này là do có thể tồn tại các loại `V` với nhiều lần cấy `Borrow<[_]>`, như vậy sẽ áp dụng nhiều loại `T`:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Kiểu kết quả sau khi nối
    type Output;

    /// Triển khai [`[T]: : concat`](slice::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Người trợ giúp trait cho [`[T]: : tham gia`](lát::tham gia)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Kiểu kết quả sau khi nối
    type Output;

    /// Triển khai [`[T]: : join`](slice::join)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Triển khai trait tiêu chuẩn cho các lát cắt
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // thả bất cứ thứ gì vào mục tiêu sẽ không bị ghi đè
        target.truncate(self.len());

        // target.len <= self.len do phần cắt ngắn ở trên, vì vậy các lát cắt ở đây luôn nằm trong giới hạn.
        //
        let (init, tail) = self.split_at(target.len());

        // sử dụng lại các giá trị chứa allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Chèn `v[0]` vào trình tự được sắp xếp trước `v[1..]` để toàn bộ `v[..]` được sắp xếp.
///
/// Đây là chương trình con tích phân của sắp xếp chèn.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Có ba cách để triển khai chèn ở đây:
            //
            // 1. Hoán đổi các phần tử liền kề cho đến khi phần tử đầu tiên đến đích cuối cùng.
            //    Tuy nhiên, bằng cách này chúng tôi sao chép dữ liệu xung quanh nhiều hơn mức cần thiết.
            //    Nếu các phần tử là cấu trúc lớn (tốn kém để sao chép), phương pháp này sẽ chậm.
            //
            // 2. Lặp lại cho đến khi tìm thấy đúng vị trí cho phần tử đầu tiên.
            // Sau đó chuyển các phần tử tiếp theo để nhường chỗ cho nó và cuối cùng đặt nó vào lỗ còn lại.
            // Đây là một phương pháp tốt.
            //
            // 3. Sao chép phần tử đầu tiên vào một biến tạm thời.Lặp lại cho đến khi tìm thấy vị trí thích hợp cho nó.
            // Khi chúng ta tiếp tục, hãy sao chép mọi phần tử được duyệt vào vị trí trước nó.
            // Cuối cùng, sao chép dữ liệu từ biến tạm thời vào lỗ còn lại.
            // Phương pháp này rất tốt.
            // Điểm chuẩn cho thấy hiệu suất tốt hơn một chút so với phương pháp thứ hai.
            //
            // Tất cả các phương pháp đều được đánh giá chuẩn và phương pháp thứ 3 cho kết quả tốt nhất.Vì vậy, chúng tôi đã chọn cái đó.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Trạng thái trung gian của quá trình chèn luôn được `hole` theo dõi, phục vụ hai mục đích:
            // 1. Bảo vệ tính toàn vẹn của `v` khỏi panics trong `is_less`.
            // 2. Cuối cùng, lấp đầy lỗ còn lại trong `v`.
            //
            // Panic an toàn:
            //
            // Nếu `is_less` panics tại bất kỳ thời điểm nào trong quá trình, `hole` sẽ bị rơi và lấp đầy lỗ hổng trong `v` bằng `tmp`, do đó đảm bảo rằng `v` vẫn giữ mọi đối tượng mà nó giữ ban đầu chính xác một lần.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` bị rơi và do đó sao chép `tmp` vào lỗ còn lại trong `v`.
        }
    }

    // Khi bị rơi, các bản sao từ `src` thành `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Hợp nhất chạy không giảm `v[..mid]` và `v[mid..]` bằng cách sử dụng `buf` làm bộ nhớ tạm thời và lưu trữ kết quả vào `v[..]`.
///
/// # Safety
///
/// Hai lát cắt không được trống và `mid` phải nằm trong giới hạn.
/// Bộ đệm `buf` phải đủ dài để chứa một bản sao của lát cắt ngắn hơn.
/// Ngoài ra, `T` không được là loại có kích thước bằng không.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Trước tiên, quá trình hợp nhất sao chép thời gian chạy ngắn hơn vào `buf`.
    // Sau đó, nó theo dõi lần chạy mới được sao chép và lần chạy dài hơn về phía trước (hoặc ngược), so sánh các phần tử chưa được tích lũy tiếp theo của chúng và sao chép phần tử nhỏ hơn (hoặc lớn hơn) vào `v`.
    //
    // Ngay sau khi thời gian chạy ngắn hơn được tiêu thụ hết, quá trình sẽ được thực hiện.Nếu lần chạy dài hơn bị tiêu hao trước, thì chúng ta phải sao chép bất cứ thứ gì còn lại của lần chạy ngắn hơn vào lỗ còn lại trong `v`.
    //
    // Trạng thái trung gian của quá trình luôn được theo dõi bởi `hole`, phục vụ hai mục đích:
    // 1. Bảo vệ tính toàn vẹn của `v` khỏi panics trong `is_less`.
    // 2. Điền vào lỗ còn lại trong `v` nếu thời gian chạy dài hơn được tiêu thụ trước.
    //
    // Panic an toàn:
    //
    // Nếu `is_less` panics tại bất kỳ thời điểm nào trong quá trình, `hole` sẽ bị rơi và lấp đầy lỗ hổng trong `v` với phạm vi chưa tích lũy trong `buf`, do đó đảm bảo rằng `v` vẫn giữ mọi đối tượng mà nó giữ ban đầu chính xác một lần.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Đường chạy bên trái ngắn hơn.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Ban đầu, các con trỏ này trỏ đến đầu các mảng của chúng.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Tiêu thụ bên ít hơn.
            // Nếu bằng nhau, ưu tiên chạy bên trái để duy trì sự ổn định.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Đường chạy bên phải ngắn hơn.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Ban đầu, các con trỏ này trỏ qua các đầu của mảng của chúng.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Tiêu thụ mặt lớn hơn.
            // Nếu bằng nhau, thích chạy đúng hơn để duy trì sự ổn định.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Cuối cùng, `hole` bị loại bỏ.
    // Nếu thời gian chạy ngắn hơn không được tiêu thụ hết, mọi thứ còn lại của nó bây giờ sẽ được sao chép vào lỗ hổng trong `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Khi bị rơi, hãy sao chép phạm vi `start..end` thành `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` không phải là loại có kích thước bằng 0, vì vậy bạn có thể chia theo kích thước của nó.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Loại hợp nhất này vay mượn một số (nhưng không phải tất cả) ý tưởng từ TimSort, được mô tả chi tiết [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Thuật toán xác định các dãy con giảm dần và không giảm dần, được gọi là các lần chạy tự nhiên.Có một chồng các lần chạy đang chờ xử lý chưa được hợp nhất.
/// Mỗi lần chạy mới được tìm thấy được đẩy lên ngăn xếp, và sau đó một số cặp lần chạy liền kề được hợp nhất cho đến khi thỏa mãn hai bất biến này:
///
/// 1. cho mọi `i` trong `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. cho mọi `i` trong `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Các bất biến đảm bảo rằng tổng thời gian chạy là *O*(*n*\*log(* n*)) trong trường hợp xấu nhất.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Các lát có độ dài tối đa này được sắp xếp bằng cách sử dụng sắp xếp chèn.
    const MAX_INSERTION: usize = 20;
    // Các lần chạy rất ngắn được kéo dài bằng cách sử dụng sắp xếp chèn để kéo dài ít nhất nhiều phần tử này.
    const MIN_RUN: usize = 10;

    // Sắp xếp không có hành vi có ý nghĩa trên các loại có kích thước bằng không.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Các mảng ngắn được sắp xếp tại chỗ thông qua sắp xếp chèn để tránh phân bổ.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Phân bổ một bộ đệm để sử dụng làm bộ nhớ đầu.Chúng tôi giữ độ dài 0 để chúng tôi có thể giữ trong đó các bản sao nông của nội dung của `v` mà không gây rủi ro cho các dtors chạy trên các bản sao nếu `is_less` panics.
    //
    // Khi hợp nhất hai lần chạy đã được sắp xếp, bộ đệm này giữ một bản sao của lần chạy ngắn hơn, sẽ luôn có độ dài tối đa là `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Để xác định các lần chạy tự nhiên trong `v`, chúng tôi duyệt ngược nó.
    // Đó có vẻ là một quyết định kỳ lạ, nhưng hãy xem xét thực tế rằng việc hợp nhất thường đi theo hướng ngược lại (forwards).
    // Theo điểm chuẩn, hợp nhất chuyển tiếp nhanh hơn một chút so với hợp nhất ngược.
    // Để kết luận, việc xác định các lần chạy bằng cách đi ngang sẽ cải thiện hiệu suất.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Tìm lần chạy tự nhiên tiếp theo và đảo ngược nó nếu nó giảm dần.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Chèn thêm một số phần tử vào chạy nếu nó quá ngắn.
        // Sắp xếp chèn nhanh hơn sắp xếp hợp nhất trên các chuỗi ngắn, vì vậy điều này cải thiện đáng kể hiệu suất.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Đẩy lần chạy này vào ngăn xếp.
        runs.push(Run { start, len: end - start });
        end = start;

        // Hợp nhất một số cặp chạy liền kề để thỏa mãn các bất biến.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Cuối cùng, chính xác một lần chạy phải vẫn còn trong ngăn xếp.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Kiểm tra chồng lần chạy và xác định cặp lần chạy tiếp theo để hợp nhất.
    // Cụ thể hơn, nếu `Some(r)` được trả về, điều đó có nghĩa là `runs[r]` và `runs[r + 1]` phải được hợp nhất tiếp theo.
    // Nếu thuật toán tiếp tục xây dựng một lần chạy mới thay vào đó, `None` sẽ được trả về.
    //
    // TimSort nổi tiếng với việc triển khai nhiều lỗi, như được mô tả ở đây:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Ý chính của câu chuyện là: chúng ta phải thực thi các bất biến ở bốn lần chạy trên cùng trên ngăn xếp.
    // Chỉ ép buộc chúng ở ba trên cùng là không đủ để đảm bảo rằng các bất biến vẫn sẽ giữ cho *tất cả* chạy trong ngăn xếp.
    //
    // Hàm này kiểm tra chính xác các bất biến cho bốn lần chạy hàng đầu.
    // Ngoài ra, nếu lần chạy trên cùng bắt đầu từ chỉ mục 0, nó sẽ luôn yêu cầu hoạt động hợp nhất cho đến khi ngăn xếp được thu gọn hoàn toàn, để hoàn thành việc sắp xếp.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}