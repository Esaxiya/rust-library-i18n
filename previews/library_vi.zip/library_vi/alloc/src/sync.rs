#![stable(feature = "rust1", since = "1.0.0")]

//! Con trỏ đếm tham chiếu an toàn luồng.
//!
//! Xem tài liệu [`Arc<T>`][Arc] để biết thêm chi tiết.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Một giới hạn mềm về số lượng tham chiếu có thể được tạo cho `Arc`.
///
/// Vượt quá giới hạn này sẽ hủy bỏ chương trình của bạn (mặc dù không nhất thiết) tại các tham chiếu _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer không hỗ trợ hàng rào bộ nhớ.
// Để tránh các báo cáo dương tính giả trong quá trình triển khai Arc/Yếu, hãy sử dụng tải nguyên tử để đồng bộ hóa thay thế.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Con trỏ đếm tham chiếu an toàn luồng.'Arc' là viết tắt của 'Atomally Reference Counted'.
///
/// Kiểu `Arc<T>` cung cấp quyền sở hữu chung của một giá trị kiểu `T`, được phân bổ trong heap.Việc gọi [`clone`][clone] trên `Arc` tạo ra một phiên bản `Arc` mới, nó trỏ đến cùng một phân bổ trên heap với nguồn `Arc`, đồng thời tăng số lượng tham chiếu.
/// Khi con trỏ `Arc` cuối cùng đến một phân bổ nhất định bị hủy, giá trị được lưu trữ trong phân bổ đó (thường được gọi là "inner value") cũng bị loại bỏ.
///
/// Các tham chiếu được chia sẻ trong Rust không cho phép đột biến theo mặc định và `Arc` cũng không phải là ngoại lệ: nói chung bạn không thể có được tham chiếu có thể thay đổi cho thứ gì đó bên trong `Arc`.Nếu bạn cần đột biến thông qua `Arc`, hãy sử dụng [`Mutex`][mutex], [`RwLock`][rwlock] hoặc một trong các loại [`Atomic`][atomic].
///
/// ## An toàn chủ đề
///
/// Không giống như [`Rc<T>`], `Arc<T>` sử dụng các phép toán nguyên tử để đếm tham chiếu của nó.Điều này có nghĩa là nó an toàn theo chủ đề.Điểm bất lợi là các hoạt động nguyên tử đắt hơn các truy cập bộ nhớ thông thường.Nếu bạn không chia sẻ phân bổ được tính tham chiếu giữa các chuỗi, hãy xem xét sử dụng [`Rc<T>`] để có chi phí thấp hơn.
/// [`Rc<T>`] là một mặc định an toàn, vì trình biên dịch sẽ bắt bất kỳ nỗ lực nào để gửi một [`Rc<T>`] giữa các luồng.
/// Tuy nhiên, thư viện có thể chọn `Arc<T>` để cung cấp cho người sử dụng thư viện sự linh hoạt hơn.
///
/// `Arc<T>` sẽ triển khai [`Send`] và [`Sync`] miễn là `T` triển khai [`Send`] và [`Sync`].
/// Tại sao bạn không thể đưa loại `T` không an toàn vào `Arc<T>` để làm cho nó an toàn?Thoạt đầu, điều này có thể hơi phản trực quan: xét cho cùng, không phải điểm an toàn của luồng `Arc<T>`?Mấu chốt ở đây là: `Arc<T>` làm cho chuỗi an toàn khi có nhiều quyền sở hữu cùng một dữ liệu, nhưng nó không thêm an toàn cho chuỗi vào dữ liệu của nó.
///
/// Hãy xem xét `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] không phải là [`Sync`] và nếu `Arc<T>` luôn là [`Send`] thì `Arc <` [`RefCell<T>`]`>`cũng sẽ như vậy.
/// Nhưng sau đó chúng tôi gặp vấn đề:
/// [`RefCell<T>`] không phải là chủ đề an toàn;nó theo dõi số lần mượn bằng các phép toán phi nguyên tử.
///
/// Cuối cùng, điều này có nghĩa là bạn có thể cần phải ghép nối `Arc<T>` với một số loại [`std::sync`], thường là [`Mutex<T>`][mutex].
///
/// ## Phá vỡ chu kỳ với `Weak`
///
/// Phương thức [`downgrade`][downgrade] có thể được sử dụng để tạo một con trỏ [`Weak`] không sở hữu.Con trỏ [`Weak`] có thể được [`nâng cấp`][nâng cấp] d thành `Arc`, nhưng điều này sẽ trả về [`None`] nếu giá trị được lưu trữ trong phân bổ đã bị loại bỏ.
/// Nói cách khác, con trỏ `Weak` không giữ giá trị bên trong phân bổ tồn tại;tuy nhiên, chúng *làm* giữ cho phân bổ (kho dự trữ cho giá trị) tồn tại.
///
/// Một chu kỳ giữa các con trỏ `Arc` sẽ không bao giờ được phân bổ.
/// Vì lý do này, [`Weak`] được sử dụng để phá vỡ các chu kỳ.Ví dụ: một cây có thể có con trỏ `Arc` mạnh từ các nút cha đến nút con và con trỏ [`Weak`] từ con quay lại cha mẹ của chúng.
///
/// # Nhân bản tài liệu tham khảo
///
/// Tạo một tham chiếu mới từ một con trỏ đếm tham chiếu hiện có được thực hiện bằng cách sử dụng `Clone` trait được triển khai cho [`Arc<T>`][Arc] và [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Hai cú pháp dưới đây là tương đương.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b và foo là tất cả các Cung trỏ đến cùng một vị trí bộ nhớ
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` tự động tham chiếu đến `T` (thông qua [`Deref`][deref] trait), vì vậy bạn có thể gọi các phương thức của `T` trên giá trị kiểu `Arc<T>`.Để tránh xung đột tên với các phương thức của `T`, bản thân các phương thức của `Arc<T>` là các hàm liên kết, được gọi bằng cách sử dụng [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>Các triển khai của traits như `Clone` cũng có thể được gọi bằng cách sử dụng cú pháp đủ điều kiện.
/// Một số người thích sử dụng cú pháp đủ điều kiện, trong khi những người khác thích sử dụng cú pháp gọi phương thức.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Cú pháp gọi phương thức
/// let arc2 = arc.clone();
/// // Cú pháp hoàn toàn đủ điều kiện
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] không tự động tham chiếu đến `T`, vì giá trị bên trong có thể đã bị loại bỏ.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Chia sẻ một số dữ liệu bất biến giữa các chuỗi:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Lưu ý rằng chúng tôi **không** chạy các thử nghiệm này tại đây.
// Các nhà xây dựng windows sẽ cực kỳ không hài lòng nếu một luồng sống lâu hơn luồng chính và sau đó thoát ra cùng lúc (một cái gì đó bế tắc) vì vậy chúng tôi chỉ cần tránh điều này hoàn toàn bằng cách không chạy các thử nghiệm này.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Chia sẻ [`AtomicUsize`] có thể thay đổi:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Xem [`rc` documentation][rc_examples] để biết thêm các ví dụ về đếm tham chiếu nói chung.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` là phiên bản của [`Arc`] có tham chiếu không sở hữu đến phân bổ được quản lý.
/// Việc phân bổ được truy cập bằng cách gọi [`upgrade`] trên con trỏ `Weak`, trả về [`Option`]`<`[`Arc`] `<T>>`.
///
/// Vì tham chiếu `Weak` không được tính vào quyền sở hữu, nên nó sẽ không ngăn giá trị được lưu trữ trong phân bổ bị giảm và bản thân `Weak` không đảm bảo về giá trị vẫn hiện diện.
///
/// Do đó, nó có thể trả về [`None`] khi [`nâng cấp`] d.
/// Tuy nhiên, lưu ý rằng tham chiếu `Weak`*không* ngăn chính phân bổ (kho dự phòng) được phân bổ theo thỏa thuận.
///
/// Con trỏ `Weak` hữu ích để giữ một tham chiếu tạm thời đến phân bổ được quản lý bởi [`Arc`] mà không ngăn giá trị bên trong của nó bị giảm.
/// Nó cũng được sử dụng để ngăn chặn các tham chiếu vòng giữa các con trỏ [`Arc`], vì các tham chiếu sở hữu lẫn nhau sẽ không bao giờ cho phép bỏ [`Arc`].
/// Ví dụ: một cây có thể có con trỏ [`Arc`] mạnh từ các nút cha đến nút con và con trỏ `Weak` từ con quay lại cha mẹ của chúng.
///
/// Cách điển hình để lấy con trỏ `Weak` là gọi [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Đây là `NonNull` cho phép tối ưu hóa kích thước của loại này trong enums, nhưng nó không nhất thiết phải là một con trỏ hợp lệ.
    //
    // `Weak::new` đặt giá trị này thành `usize::MAX` để nó không cần phân bổ không gian trên heap.
    // Đó không phải là một giá trị mà một con trỏ thực sẽ có bởi vì RcBox có ít nhất là 2 căn chỉnh.
    // Điều này chỉ có thể thực hiện được khi `T: Sized`;`T` không kích thước không bao giờ treo.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Đây là loại repr(C) đến future chống lại khả năng sắp xếp lại trường, điều này sẽ cản trở [into|from]_raw() an toàn của các loại bên trong có thể chuyển đổi.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // giá trị usize::MAX hoạt động như một trạm canh gác tạm thời cho "locking" khả năng nâng cấp con trỏ yếu hoặc hạ cấp con trỏ mạnh;điều này được sử dụng để tránh các cuộc đua trong `make_mut` và `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Xây dựng một `Arc<T>` mới.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Bắt đầu đếm con trỏ yếu là 1 là con trỏ yếu được giữ bởi tất cả các con trỏ mạnh (kinda), xem std/rc.rs để biết thêm thông tin
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Tạo một `Arc<T>` mới bằng cách sử dụng một tham chiếu yếu cho chính nó.
    /// Cố gắng nâng cấp tham chiếu yếu trước khi hàm này trả về sẽ dẫn đến giá trị `None`.
    /// Tuy nhiên, tham chiếu yếu có thể được sao chép tự do và được lưu trữ để sử dụng sau này.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Xây dựng bên trong ở trạng thái "uninitialized" với một tham chiếu yếu duy nhất.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Điều quan trọng là chúng ta không từ bỏ quyền sở hữu con trỏ yếu, nếu không bộ nhớ có thể được giải phóng vào thời điểm `data_fn` quay trở lại.
        // Nếu chúng tôi thực sự muốn chuyển quyền sở hữu, chúng tôi có thể tạo một con trỏ yếu bổ sung cho chính mình, nhưng điều này sẽ dẫn đến cập nhật bổ sung cho số lượng tham chiếu yếu mà có thể không cần thiết.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Bây giờ chúng ta có thể khởi tạo đúng giá trị bên trong và biến tham chiếu yếu của chúng ta thành tham chiếu mạnh.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Việc ghi ở trên vào trường dữ liệu phải được hiển thị cho bất kỳ luồng nào quan sát số lượng mạnh khác 0.
            // Do đó, chúng tôi cần đặt hàng ít nhất "Release" để đồng bộ hóa với `compare_exchange_weak` trong `Weak::upgrade`.
            //
            // "Acquire" đặt hàng là không cần thiết.
            // Khi xem xét các hành vi có thể xảy ra của `data_fn`, chúng ta chỉ cần xem xét những gì nó có thể làm với tham chiếu đến `Weak` không thể nâng cấp:
            //
            // - Nó có thể *sao chép*`Weak`, làm tăng số lượng tham chiếu yếu.
            // - Nó có thể loại bỏ các bản sao đó, làm giảm số lượng tham chiếu yếu (nhưng không bao giờ về không).
            //
            // Những tác dụng phụ này không ảnh hưởng đến chúng ta theo bất kỳ cách nào, và không có tác dụng phụ nào khác có thể xảy ra chỉ với mã an toàn.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Các tham chiếu mạnh phải sở hữu chung một tham chiếu yếu được chia sẻ, vì vậy đừng chạy trình hủy cho tham chiếu yếu cũ của chúng tôi.
        //
        mem::forget(weak);
        strong
    }

    /// Tạo một `Arc` mới với nội dung chưa được khởi tạo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Khởi tạo hoãn lại:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Xây dựng một `Arc` mới với nội dung chưa được khởi tạo, với bộ nhớ được lấp đầy bởi các byte `0`.
    ///
    ///
    /// Xem [`MaybeUninit::zeroed`][zeroed] để biết các ví dụ về cách sử dụng đúng và sai của phương pháp này.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Xây dựng một `Pin<Arc<T>>` mới.
    /// Nếu `T` không triển khai `Unpin`, thì `data` sẽ được ghim trong bộ nhớ và không thể di chuyển được.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Tạo `Arc<T>` mới, trả về lỗi nếu phân bổ không thành công.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Bắt đầu đếm con trỏ yếu là 1 là con trỏ yếu được giữ bởi tất cả các con trỏ mạnh (kinda), xem std/rc.rs để biết thêm thông tin
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Tạo `Arc` mới với nội dung chưa được khởi tạo, trả về lỗi nếu phân bổ không thành công.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Khởi tạo hoãn lại:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Tạo một `Arc` mới với nội dung chưa được khởi tạo, với bộ nhớ được lấp đầy bởi các byte `0`, trả về lỗi nếu phân bổ không thành công.
    ///
    ///
    /// Xem [`MaybeUninit::zeroed`][zeroed] để biết các ví dụ về cách sử dụng đúng và sai của phương pháp này.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Trả về giá trị bên trong, nếu `Arc` có chính xác một tham chiếu mạnh.
    ///
    /// Nếu không, [`Err`] được trả về cùng với `Arc` đã được chuyển vào.
    ///
    ///
    /// Điều này sẽ thành công ngay cả khi có những tài liệu tham khảo yếu kém nổi bật.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Tạo một con trỏ yếu để xóa tham chiếu mạnh-yếu tiềm ẩn
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Tạo một lát mới được đếm tham chiếu nguyên tử với nội dung chưa được khởi tạo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Khởi tạo hoãn lại:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Tạo một lát mới được đếm tham chiếu nguyên tử với nội dung chưa được khởi tạo, với bộ nhớ được lấp đầy bởi các byte `0`.
    ///
    ///
    /// Xem [`MaybeUninit::zeroed`][zeroed] để biết các ví dụ về cách sử dụng đúng và sai của phương pháp này.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Chuyển đổi sang `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Như với [`MaybeUninit::assume_init`], người gọi phải đảm bảo rằng giá trị bên trong thực sự ở trạng thái khởi tạo.
    ///
    /// Việc gọi này khi nội dung chưa được khởi tạo hoàn toàn sẽ gây ra hành vi không xác định ngay lập tức.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Khởi tạo hoãn lại:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Chuyển đổi sang `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Như với [`MaybeUninit::assume_init`], người gọi phải đảm bảo rằng giá trị bên trong thực sự ở trạng thái khởi tạo.
    ///
    /// Việc gọi này khi nội dung chưa được khởi tạo hoàn toàn sẽ gây ra hành vi không xác định ngay lập tức.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Khởi tạo hoãn lại:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Sử dụng `Arc`, trả về con trỏ được bọc.
    ///
    /// Để tránh rò rỉ bộ nhớ, con trỏ phải được chuyển đổi trở lại `Arc` bằng [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Cung cấp một con trỏ thô tới dữ liệu.
    ///
    /// Số lượng không bị ảnh hưởng theo bất kỳ cách nào và `Arc` không bị tiêu thụ.
    /// Con trỏ có giá trị miễn là có số lượng mạnh trong `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // AN TOÀN: Điều này không thể đi qua Deref::deref hoặc RcBoxPtr::inner vì
        // điều này được yêu cầu để giữ lại xuất xứ của raw/mut, ví dụ:
        // `get_mut` có thể ghi thông qua con trỏ sau khi Rc được khôi phục thông qua `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Tạo `Arc<T>` từ một con trỏ thô.
    ///
    /// Con trỏ thô phải được trả về trước đó bằng một lệnh gọi tới [`Arc<U>::into_raw`][into_raw] trong đó `U` phải có cùng kích thước và căn chỉnh như `T`.
    /// Điều này hoàn toàn đúng nếu `U` là `T`.
    /// Lưu ý rằng nếu `U` không phải là `T` nhưng có cùng kích thước và căn chỉnh, thì về cơ bản điều này giống như việc chuyển đổi các tham chiếu của các loại khác nhau.
    /// Xem [`mem::transmute`][transmute] để biết thêm thông tin về những hạn chế nào áp dụng trong trường hợp này.
    ///
    /// Người dùng `from_raw` phải đảm bảo rằng một giá trị cụ thể của `T` chỉ bị giảm một lần.
    ///
    /// Chức năng này không an toàn vì sử dụng không đúng cách có thể dẫn đến mất an toàn bộ nhớ, ngay cả khi `Arc<T>` trả về không bao giờ được truy cập.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Chuyển đổi trở lại `Arc` để ngăn rò rỉ.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Các cuộc gọi tiếp theo tới `Arc::from_raw(x_ptr)` sẽ không an toàn về bộ nhớ.
    /// }
    ///
    /// // Bộ nhớ đã được giải phóng khi `x` vượt ra khỏi phạm vi ở trên, vì vậy `x_ptr` hiện đang treo lơ lửng!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Đảo ngược phần bù để tìm ArcInner ban đầu.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Tạo một con trỏ [`Weak`] mới cho phân bổ này.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Điều này thoải mái là OK vì chúng tôi đang kiểm tra giá trị trong CAS bên dưới.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // kiểm tra xem bộ đếm yếu hiện tại là "locked";nếu vậy, hãy quay.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: mã này hiện đang bỏ qua khả năng tràn
            // thành usize::MAX;nói chung cả Rc và Arc đều cần được điều chỉnh để đối phó với hiện tượng tràn.
            //

            // Không giống như với Clone(), chúng ta cần đây là một Acquire read để đồng bộ hóa với việc ghi đến từ `is_unique`, để các sự kiện trước khi ghi đó xảy ra trước khi đọc này.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Đảm bảo rằng chúng tôi không tạo ra một Điểm yếu lủng lẳng
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Nhận số lượng con trỏ [`Weak`] đến phân bổ này.
    ///
    /// # Safety
    ///
    /// Phương pháp này tự nó là an toàn, nhưng sử dụng nó một cách chính xác cần phải cẩn thận hơn.
    /// Một luồng khác có thể thay đổi số lượng yếu bất kỳ lúc nào, bao gồm cả khả năng giữa việc gọi phương thức này và hành động trên kết quả.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Khẳng định này là xác định vì chúng tôi chưa chia sẻ `Arc` hoặc `Weak` giữa các luồng.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Nếu số đếm yếu hiện đang bị khóa, giá trị của số đếm là 0 ngay trước khi thực hiện khóa.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Nhận số lượng con trỏ (`Arc`) mạnh đến phân bổ này.
    ///
    /// # Safety
    ///
    /// Phương pháp này tự nó là an toàn, nhưng sử dụng nó một cách chính xác cần phải cẩn thận hơn.
    /// Một luồng khác có thể thay đổi số lượng mạnh bất kỳ lúc nào, bao gồm cả khả năng giữa việc gọi phương thức này và hành động trên kết quả.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Khẳng định này là xác định vì chúng tôi chưa chia sẻ `Arc` giữa các luồng.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Tăng số lượng tham chiếu mạnh mẽ trên `Arc<T>` được liên kết với con trỏ được cung cấp lên từng con một.
    ///
    /// # Safety
    ///
    /// Con trỏ phải được lấy thông qua `Arc::into_raw` và phiên bản `Arc` được liên kết phải hợp lệ (tức là
    /// số lượng mạnh phải ít nhất là 1) trong suốt thời gian của phương pháp này.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Khẳng định này là xác định vì chúng tôi chưa chia sẻ `Arc` giữa các luồng.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Giữ lại Arc, nhưng không chạm vào số tiền hoàn lại bằng cách gói trong ManentlyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Bây giờ, hãy tăng số tiền hoàn lại, nhưng cũng không được giảm số tiền hoàn lại mới
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Giảm số lượng tham chiếu mạnh mẽ trên `Arc<T>` được liên kết với con trỏ được cung cấp từng cái một.
    ///
    /// # Safety
    ///
    /// Con trỏ phải được lấy thông qua `Arc::into_raw` và phiên bản `Arc` được liên kết phải hợp lệ (tức là
    /// số lượng mạnh phải ít nhất là 1) khi gọi phương thức này.
    /// Phương thức này có thể được sử dụng để phát hành `Arc` cuối cùng và lưu trữ sao lưu, nhưng **không nên** được gọi sau khi `Arc` cuối cùng đã được phát hành.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Những khẳng định đó là xác định vì chúng tôi chưa chia sẻ `Arc` giữa các luồng.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Sự không an toàn này là ổn vì trong khi vòng cung này vẫn còn tồn tại, chúng tôi đảm bảo rằng con trỏ bên trong là hợp lệ.
        // Hơn nữa, chúng ta biết rằng bản thân cấu trúc `ArcInner` là `Sync` vì dữ liệu bên trong cũng là `Sync`, vì vậy chúng ta có thể cho mượn một con trỏ bất biến tới các nội dung này.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Phần không nội dòng của `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Hủy dữ liệu tại thời điểm này, mặc dù chúng tôi có thể không tự giải phóng phân bổ hộp (vẫn có thể có các con trỏ yếu nằm xung quanh).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Bỏ tham chiếu yếu được tổng hợp bởi tất cả các tham chiếu mạnh
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Trả về `true` nếu hai `Arc` chỉ đến cùng một phân bổ (trong một mạch tương tự như [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Phân bổ `ArcInner<T>` với đủ không gian cho giá trị bên trong có thể chưa được kích thước, nơi giá trị có bố cục được cung cấp.
    ///
    /// Hàm `mem_to_arcinner` được gọi với con trỏ dữ liệu và phải trả về một con trỏ (có khả năng béo) cho `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Tính toán bố cục bằng cách sử dụng bố cục giá trị đã cho.
        // Trước đây, bố cục được tính toán trên biểu thức `&*(ptr as* const ArcInner<T>)`, nhưng điều này đã tạo ra một tham chiếu bị lệch (xem #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Phân bổ `ArcInner<T>` với đủ không gian cho giá trị bên trong có thể chưa được kích thước trong đó giá trị có bố cục được cung cấp, trả về lỗi nếu phân bổ không thành công.
    ///
    ///
    /// Hàm `mem_to_arcinner` được gọi với con trỏ dữ liệu và phải trả về một con trỏ (có khả năng béo) cho `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Tính toán bố cục bằng cách sử dụng bố cục giá trị đã cho.
        // Trước đây, bố cục được tính toán trên biểu thức `&*(ptr as* const ArcInner<T>)`, nhưng điều này đã tạo ra một tham chiếu bị lệch (xem #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Khởi tạo ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Phân bổ `ArcInner<T>` với đủ không gian cho giá trị bên trong chưa được kích thước.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Phân bổ cho `ArcInner<T>` bằng cách sử dụng giá trị đã cho.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Sao chép giá trị dưới dạng byte
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Giải phóng phân bổ mà không làm rơi nội dung của nó
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Phân bổ một `ArcInner<[T]>` với độ dài đã cho.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Sao chép các phần tử từ lát vào Arc mới được cấp phát <\[T\]>
    ///
    /// Không an toàn vì người gọi phải có quyền sở hữu hoặc ràng buộc `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Tạo `Arc<[T]>` từ một trình lặp được biết là có kích thước nhất định.
    ///
    /// Hành vi không được xác định nên kích thước sai.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic bảo vệ trong khi nhân bản các phần tử T.
        // Trong trường hợp có panic, các phần tử đã được ghi vào ArcInner mới sẽ bị loại bỏ, sau đó bộ nhớ được giải phóng.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Con trỏ đến phần tử đầu tiên
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Tất cả rõ ràng.Quên bảo vệ để nó không giải phóng ArcInner mới.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Chuyên trait dùng cho `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Tạo bản sao của con trỏ `Arc`.
    ///
    /// Điều này tạo ra một con trỏ khác đến cùng một phân bổ, làm tăng số lượng tham chiếu mạnh mẽ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Ở đây, sử dụng một thứ tự thoải mái là được, vì kiến thức về tham chiếu ban đầu ngăn chặn các luồng khác xóa nhầm đối tượng.
        //
        // Như đã giải thích trong [Boost documentation][1], Việc tăng bộ đếm tham chiếu luôn có thể được thực hiện với memory_order_relaxed: Các tham chiếu mới đến một đối tượng chỉ có thể được hình thành từ một tham chiếu hiện có và việc chuyển một tham chiếu hiện có từ luồng này sang luồng khác đã phải cung cấp bất kỳ đồng bộ hóa bắt buộc nào.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Tuy nhiên, chúng ta cần đề phòng các khoản hoàn lại lớn trong trường hợp ai đó đang `mem: : quên`ing Arcs.
        // Nếu chúng tôi không làm điều này, số lượng có thể bị tràn và người dùng sẽ sử dụng sau khi miễn phí.
        // Chúng tôi thực sự bão hòa với `isize::MAX` với giả định rằng không có tỷ luồng ~2 nào làm tăng số lượng tham chiếu cùng một lúc.
        //
        // branch này sẽ không bao giờ được đưa vào bất kỳ chương trình thực tế nào.
        //
        // Chúng tôi hủy bỏ bởi vì một chương trình như vậy là vô cùng thoái hóa và chúng tôi không quan tâm đến việc hỗ trợ nó.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Tạo một tham chiếu có thể thay đổi vào `Arc` đã cho.
    ///
    /// Nếu có các con trỏ `Arc` hoặc [`Weak`] khác đến cùng một phân bổ, thì `make_mut` sẽ tạo một phân bổ mới và gọi [`clone`][clone] trên giá trị bên trong để đảm bảo quyền sở hữu duy nhất.
    /// Điều này cũng được gọi là sao chép trên ghi.
    ///
    /// Lưu ý rằng điều này khác với hành vi của [`Rc::make_mut`], nó sẽ ngắt liên kết bất kỳ con trỏ `Weak` nào còn lại.
    ///
    /// Xem thêm [`get_mut`][get_mut], sẽ không thành công hơn là nhân bản.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Sẽ không sao chép bất cứ thứ gì
    /// let mut other_data = Arc::clone(&data); // Sẽ không sao chép dữ liệu bên trong
    /// *Arc::make_mut(&mut data) += 1;         // Sao chép dữ liệu bên trong
    /// *Arc::make_mut(&mut data) += 1;         // Sẽ không sao chép bất cứ thứ gì
    /// *Arc::make_mut(&mut other_data) *= 2;   // Sẽ không sao chép bất cứ thứ gì
    ///
    /// // Bây giờ `data` và `other_data` trỏ đến các phân bổ khác nhau.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Lưu ý rằng chúng tôi giữ cả một tham chiếu mạnh và một tham chiếu yếu.
        // Do đó, việc chỉ giải phóng tham chiếu mạnh của chúng ta sẽ không khiến bộ nhớ bị phân bổ.
        //
        // Sử dụng Acquire để đảm bảo rằng chúng tôi thấy bất kỳ lần ghi nào vào `weak` xảy ra trước khi bản phát hành ghi (tức là giảm) vào `strong`.
        // Vì chúng tôi nắm giữ một số lượng yếu, không có khả năng bản thân ArcInner có thể bị phân bổ.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Một điểm mạnh khác tồn tại, vì vậy chúng ta phải nhân bản.
            // Cấp phát trước bộ nhớ để cho phép ghi trực tiếp giá trị được nhân bản.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Thoải mái ở trên là đủ vì đây về cơ bản là một sự tối ưu hóa: chúng tôi luôn chạy đua với những điểm yếu bị loại bỏ.
            // Trường hợp xấu nhất, chúng tôi cuối cùng đã phân bổ một Arc mới một cách không cần thiết.
            //

            // Chúng tôi đã loại bỏ các ref mạnh cuối cùng, nhưng vẫn còn lại các ref yếu bổ sung.
            // Chúng tôi sẽ chuyển nội dung sang Arc mới và làm mất hiệu lực của các ref yếu khác.
            //

            // Lưu ý rằng việc đọc `weak` không thể mang lại usize::MAX (tức là bị khóa), vì số đếm yếu chỉ có thể bị khóa bởi một luồng có tham chiếu mạnh.
            //
            //

            // Vật chất hóa con trỏ yếu tiềm ẩn của riêng chúng ta, để nó có thể dọn dẹp ArcInner khi cần thiết.
            //
            let _weak = Weak { ptr: this.ptr };

            // Chỉ có thể đánh cắp dữ liệu, tất cả những gì còn lại là Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Chúng tôi là tài liệu tham khảo duy nhất của một trong hai loại;tăng trở lại số lượng giới thiệu mạnh mẽ.
            //
            this.inner().strong.store(1, Release);
        }

        // Như với `get_mut()`, sự không an toàn vẫn ổn vì tham chiếu của chúng tôi hoặc là duy nhất khi bắt đầu, hoặc trở thành một khi sao chép nội dung.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Trả về một tham chiếu có thể thay đổi vào `Arc` đã cho, nếu không có con trỏ `Arc` hoặc [`Weak`] nào khác đến cùng một phân bổ.
    ///
    ///
    /// Trả về [`None`] nếu không, vì không an toàn khi thay đổi giá trị được chia sẻ.
    ///
    /// Xem thêm [`make_mut`][make_mut], [`clone`][clone] sẽ là giá trị bên trong khi có các con trỏ khác.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Sự không an toàn này là ổn vì chúng tôi đảm bảo rằng con trỏ được trả về là con trỏ *duy nhất* sẽ được trả về T.
            // Số lượng tham chiếu của chúng tôi được đảm bảo là 1 tại thời điểm này và chúng tôi yêu cầu bản thân Arc phải là `mut`, vì vậy chúng tôi đang trả lại tham chiếu duy nhất có thể có cho dữ liệu bên trong.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Trả về một tham chiếu có thể thay đổi vào `Arc` đã cho mà không cần kiểm tra.
    ///
    /// Xem thêm [`get_mut`], an toàn và kiểm tra thích hợp.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Bất kỳ con trỏ `Arc` hoặc [`Weak`] nào khác đến cùng một phân bổ không được tham chiếu đến trong suốt thời gian của khoản vay đã trả lại.
    ///
    /// Đây là trường hợp nhỏ nếu không có con trỏ nào như vậy tồn tại, ví dụ ngay sau `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Chúng tôi cẩn thận *không* tạo một tham chiếu bao gồm các trường "count", vì điều này sẽ là bí danh với quyền truy cập đồng thời vào số lượng tham chiếu (ví dụ:
        // bởi `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Xác định xem đây có phải là tham chiếu duy nhất (bao gồm cả các tham chiếu yếu) đến dữ liệu cơ bản hay không.
    ///
    ///
    /// Lưu ý rằng điều này yêu cầu khóa số lượng tham chiếu yếu.
    fn is_unique(&mut self) -> bool {
        // khóa số lượng con trỏ yếu nếu chúng tôi có vẻ là người giữ con trỏ yếu duy nhất.
        //
        // Nhãn thu được ở đây đảm bảo mối quan hệ xảy ra trước với bất kỳ lần ghi nào vào `strong` (cụ thể là trong `Weak::upgrade`) trước khi số lượng `weak` giảm (thông qua `Weak::drop`, sử dụng bản phát hành).
        // Nếu ref nâng cấp yếu không bao giờ bị rớt, CAS ở đây sẽ bị lỗi vì vậy chúng tôi không quan tâm đến việc đồng bộ hóa.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Điều này cần phải là `Acquire` để đồng bộ hóa với sự giảm xuống của bộ đếm `strong` trong `drop`-quyền truy cập duy nhất xảy ra khi bất kỳ tham chiếu nào trừ tham chiếu cuối cùng bị loại bỏ.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Bản phát hành ghi ở đây đồng bộ hóa với lần đọc trong `downgrade`, ngăn chặn hiệu quả việc đọc `strong` ở trên xảy ra sau khi ghi.
            //
            //
            self.inner().weak.store(1, Release); // mở khóa
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Bỏ `Arc`.
    ///
    /// Điều này sẽ làm giảm số lượng tham chiếu mạnh mẽ.
    /// Nếu số lượng tham chiếu mạnh bằng không thì các tham chiếu khác (nếu có) duy nhất là [`Weak`], vì vậy chúng tôi `drop` giá trị bên trong.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Không in bất cứ thứ gì
    /// drop(foo2);   // In "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Bởi vì `fetch_sub` đã là nguyên tử, chúng tôi không cần phải đồng bộ hóa với các luồng khác trừ khi chúng tôi định xóa đối tượng.
        // Logic tương tự này áp dụng cho `fetch_sub` dưới đây cho số `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Hàng rào này là cần thiết để ngăn việc sắp xếp lại việc sử dụng dữ liệu và xóa dữ liệu.
        // Bởi vì nó được đánh dấu `Release`, việc giảm số lượng tham chiếu sẽ đồng bộ hóa với hàng rào `Acquire` này.
        // Điều này có nghĩa là việc sử dụng dữ liệu xảy ra trước khi giảm số lượng tham chiếu, xảy ra trước hàng rào này, xảy ra trước khi xóa dữ liệu.
        //
        // Như đã giải thích trong [Boost documentation][1],
        //
        // > Điều quan trọng là phải thực thi mọi quyền truy cập có thể vào đối tượng trong một
        // > chủ đề (thông qua một tham chiếu hiện có) để *xảy ra trước khi* xóa
        // > đối tượng trong một chủ đề khác.Điều này đạt được nhờ "release"
        // > hoạt động sau khi bỏ tham chiếu (bất kỳ quyền truy cập nào vào đối tượng
        // > thông qua tham chiếu này rõ ràng phải xảy ra trước đó), và một
        // > "acquire" hoạt động trước khi xóa đối tượng.
        //
        // Đặc biệt, trong khi nội dung của Arc thường là bất biến, có thể có nội dung ghi vào thứ gì đó giống như Mutex<T>.
        // Vì Mutex không được nhận khi nó bị xóa, chúng tôi không thể dựa vào logic đồng bộ hóa của nó để thực hiện ghi trong luồng A hiển thị cho một trình hủy đang chạy trong luồng B.
        //
        //
        // Cũng lưu ý rằng hàng rào Tiếp nhận ở đây có thể được thay thế bằng tải Có được, có thể cải thiện hiệu suất trong các tình huống có tính cạnh tranh cao.Xem [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Cố gắng hạ thấp `Arc<dyn Any + Send + Sync>` xuống loại bê tông.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Xây dựng một `Weak<T>` mới mà không cần cấp phát bất kỳ bộ nhớ nào.
    /// Gọi [`upgrade`] trên giá trị trả về luôn cho [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Loại trình trợ giúp để cho phép truy cập số lượng tham chiếu mà không cần đưa ra bất kỳ xác nhận nào về trường dữ liệu.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Trả về một con trỏ thô cho đối tượng `T` được trỏ tới bởi `Weak<T>` này.
    ///
    /// Con trỏ chỉ hợp lệ nếu có một số tham chiếu mạnh.
    /// Con trỏ có thể treo lơ lửng, không liên kết hoặc thậm chí là [`null`] nếu không.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Cả hai đều trỏ đến cùng một đối tượng
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Strong ở đây giữ cho nó tồn tại, vì vậy chúng ta vẫn có thể tiếp cận đối tượng.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Nhưng không còn nữa.
    /// // Chúng ta có thể làm weak.as_ptr(), nhưng việc truy cập con trỏ sẽ dẫn đến hành vi không xác định.
    /// // khẳng định_eq! ("xin chào", không an toàn {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Nếu con trỏ treo lơ lửng, chúng tôi sẽ trả lại trực tiếp cho trạm gác.
            // Đây không thể là địa chỉ trọng tải hợp lệ, vì tải trọng ít nhất cũng được căn chỉnh như ArcInner (usize).
            ptr as *const T
        } else {
            // AN TOÀN: nếu is_dangling trả về false, thì con trỏ là không thể chọn được.
            // Tải trọng có thể bị giảm vào thời điểm này và chúng tôi phải duy trì xuất xứ, vì vậy hãy sử dụng thao tác con trỏ thô.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Sử dụng `Weak<T>` và biến nó thành một con trỏ thô.
    ///
    /// Điều này chuyển đổi con trỏ yếu thành một con trỏ thô, trong khi vẫn bảo toàn quyền sở hữu của một tham chiếu yếu (số lượng yếu không được sửa đổi bởi thao tác này).
    /// Nó có thể được quay trở lại `Weak<T>` với [`from_raw`].
    ///
    /// Các hạn chế truy cập mục tiêu của con trỏ tương tự như với [`as_ptr`] cũng được áp dụng.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Chuyển đổi một con trỏ thô do [`into_raw`] tạo trước đó trở lại thành `Weak<T>`.
    ///
    /// Điều này có thể được sử dụng để có được một tham chiếu mạnh một cách an toàn (bằng cách gọi [`upgrade`] sau này) hoặc để phân bổ số lượng yếu bằng cách thả `Weak<T>`.
    ///
    /// Nó có quyền sở hữu một tham chiếu yếu (ngoại trừ các con trỏ được tạo bởi [`new`], vì chúng không sở hữu bất cứ thứ gì; phương pháp vẫn hoạt động trên chúng).
    ///
    /// # Safety
    ///
    /// Con trỏ phải có nguồn gốc từ [`into_raw`] và vẫn phải sở hữu tham chiếu yếu tiềm ẩn của nó.
    ///
    /// Cho phép số mạnh là 0 tại thời điểm gọi giá trị này.
    /// Tuy nhiên, điều này có quyền sở hữu một tham chiếu yếu hiện được biểu diễn dưới dạng con trỏ thô (số yếu không được sửa đổi bởi thao tác này) và do đó nó phải được ghép nối với một lệnh gọi trước đó tới [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Giảm số lượng yếu cuối cùng.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Xem Weak::as_ptr để biết ngữ cảnh về cách con trỏ đầu vào được tạo ra.

        let ptr = if is_dangling(ptr as *mut T) {
            // Đây là một điểm yếu treo lơ lửng.
            ptr as *mut ArcInner<T>
        } else {
            // Nếu không, chúng tôi đảm bảo rằng con trỏ đến từ Điểm yếu không liên quan.
            // AN TOÀN: data_offset an toàn để gọi, vì ptr tham chiếu đến một T thực (có khả năng bị loại bỏ).
            let offset = unsafe { data_offset(ptr) };
            // Do đó, chúng tôi đảo ngược phần bù để có được toàn bộ RcBox.
            // AN TOÀN: con trỏ bắt nguồn từ Điểm yếu, vì vậy điểm bù này là an toàn.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // AN TOÀN: bây giờ chúng tôi đã khôi phục con trỏ Điểm yếu ban đầu, vì vậy có thể tạo Điểm yếu.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Cố gắng nâng cấp con trỏ `Weak` lên [`Arc`], trì hoãn việc giảm giá trị bên trong nếu thành công.
    ///
    ///
    /// Trả về [`None`] nếu giá trị bên trong đã bị loại bỏ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Tiêu diệt tất cả các điểm mạnh.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Chúng tôi sử dụng một vòng lặp CAS để tăng số lượng mạnh thay vì một fetch_add vì hàm này sẽ không bao giờ lấy số lượng tham chiếu từ 0 đến một.
        //
        //
        let inner = self.inner()?;

        // Tải nhẹ vì bất kỳ ghi nào về 0 mà chúng ta có thể quan sát đều để trường ở trạng thái 0 vĩnh viễn (do đó, "stale" đọc 0 là ổn) và mọi giá trị khác được xác nhận thông qua CAS bên dưới.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Xem nhận xét trong `Arc::clone` để biết lý do tại sao chúng tôi làm điều này (đối với `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Thư giãn là tốt cho trường hợp thất bại vì chúng tôi không có bất kỳ kỳ vọng nào về trạng thái mới.
            // Acquire là cần thiết cho trường hợp thành công để đồng bộ hóa với `Arc::new_cyclic`, khi giá trị bên trong có thể được khởi tạo sau khi các tham chiếu `Weak` đã được tạo.
            // Trong trường hợp đó, chúng tôi mong đợi quan sát giá trị được khởi tạo đầy đủ.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // vô hiệu được kiểm tra ở trên
                Err(old) => n = old,
            }
        }
    }

    /// Nhận số lượng con trỏ (`Arc`) mạnh trỏ đến phân bổ này.
    ///
    /// Nếu `self` được tạo bằng [`Weak::new`], giá trị này sẽ trả về 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Lấy số lượng con trỏ `Weak` gần đúng trỏ đến phân bổ này.
    ///
    /// Nếu `self` được tạo bằng [`Weak::new`] hoặc nếu không còn con trỏ mạnh nào, giá trị này sẽ trả về 0.
    ///
    /// # Accuracy
    ///
    /// Do chi tiết triển khai, giá trị trả về có thể bị lệch 1 theo một trong hai hướng khi các luồng khác đang thao tác bất kỳ `Arc`s hoặc`Weak` nào trỏ đến cùng một phân bổ.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Vì chúng tôi quan sát thấy rằng có ít nhất một con trỏ mạnh sau khi đọc số lượng yếu, chúng tôi biết rằng tham chiếu yếu tiềm ẩn (hiện diện bất cứ khi nào bất kỳ tham chiếu mạnh nào còn sống) vẫn ở xung quanh khi chúng tôi quan sát số lượng yếu và do đó có thể trừ nó một cách an toàn.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Trả về `None` khi con trỏ treo và không có `ArcInner` được cấp phát, (tức là khi `Weak` này được tạo bởi `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Chúng tôi cẩn thận *không* tạo một tham chiếu bao gồm trường "data", vì trường có thể bị thay đổi đồng thời (ví dụ: nếu `Arc` cuối cùng bị xóa, trường dữ liệu sẽ bị xóa tại chỗ).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Trả về `true` nếu hai điểm yếu 'trỏ đến cùng một phân bổ (tương tự như [`ptr::eq`]) hoặc nếu cả hai không trỏ đến bất kỳ phân bổ nào (vì chúng được tạo bằng `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Vì điều này so sánh các con trỏ nên có nghĩa là `Weak::new()` sẽ bằng nhau, mặc dù chúng không trỏ đến bất kỳ phân bổ nào.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// So sánh `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Tạo bản sao của con trỏ `Weak` trỏ đến cùng một phân bổ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Xem nhận xét trong Arc::clone() để biết lý do tại sao điều này được thoải mái.
        // Điều này có thể sử dụng một fetch_add (bỏ qua khóa) vì số lượng yếu chỉ bị khóa khi *không có con trỏ yếu* nào khác tồn tại.
        //
        // (Vì vậy, chúng tôi không thể chạy mã này trong trường hợp đó).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Xem nhận xét trong Arc::clone() để biết lý do tại sao chúng tôi làm điều này (đối với mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Xây dựng một `Weak<T>` mới mà không cần phân bổ bộ nhớ.
    /// Gọi [`upgrade`] trên giá trị trả về luôn cho [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Làm rơi con trỏ `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Không in bất cứ thứ gì
    /// drop(foo);        // In "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Nếu chúng tôi phát hiện ra rằng chúng tôi là điểm yếu cuối cùng, thì đã đến lúc phải phân bổ dữ liệu hoàn toàn.Xem thảo luận trong Arc::drop() về các thử thách bộ nhớ
        //
        // Không cần thiết phải kiểm tra trạng thái bị khóa ở đây, bởi vì số lượng yếu chỉ có thể bị khóa nếu có chính xác một ref yếu, có nghĩa là lần giảm đó chỉ có thể chạy ON sau đó ref yếu còn lại, điều này chỉ có thể xảy ra sau khi khóa được giải phóng.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Chúng tôi đang thực hiện chuyên môn hóa này ở đây, không phải là tối ưu hóa chung chung hơn trên `&T`, bởi vì nếu không, nó sẽ thêm chi phí cho tất cả các lần kiểm tra bình đẳng trên refs.
/// Chúng tôi giả định rằng các `Arc` được sử dụng để lưu trữ các giá trị lớn, có tốc độ sao chép chậm, nhưng cũng rất nặng để kiểm tra tính bình đẳng, khiến chi phí này dễ dàng trả hơn.
///
/// Nó cũng có nhiều khả năng có hai bản sao `Arc`, chỉ đến cùng một giá trị, hơn hai chữ `&T`.
///
/// Chúng tôi chỉ có thể làm điều này khi `T: Eq` dưới dạng `PartialEq` có thể cố tình không linh hoạt.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Bình đẳng cho hai `Arc`.
    ///
    /// Hai `Arc` bằng nhau nếu giá trị bên trong của chúng bằng nhau, ngay cả khi chúng được lưu trữ trong phân bổ khác nhau.
    ///
    /// Nếu `T` cũng triển khai `Eq` (ngụ ý tính phản xạ của sự bình đẳng), hai `Arc`s trỏ đến cùng một phân bổ luôn bằng nhau.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Bất đẳng thức cho hai `Arc`.
    ///
    /// Hai `Arc` không bằng nhau nếu giá trị bên trong của chúng không bằng nhau.
    ///
    /// Nếu `T` cũng triển khai `Eq` (ngụ ý tính phản xạ của sự bình đẳng), hai `Arc` trỏ đến cùng một giá trị không bao giờ là không bằng nhau.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// So sánh một phần cho hai `Arc`.
    ///
    /// Cả hai được so sánh bằng cách gọi `partial_cmp()` trên các giá trị bên trong của chúng.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// So sánh ít hơn cho hai `Arc`.
    ///
    /// Cả hai được so sánh bằng cách gọi `<` trên các giá trị bên trong của chúng.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// So sánh 'nhỏ hơn hoặc bằng' cho hai 'Arc`.
    ///
    /// Cả hai được so sánh bằng cách gọi `<=` trên các giá trị bên trong của chúng.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// So sánh lớn hơn cho hai `Arc`.
    ///
    /// Cả hai được so sánh bằng cách gọi `>` trên các giá trị bên trong của chúng.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// So sánh 'Lớn hơn hoặc bằng' cho hai 'Arc`.
    ///
    /// Cả hai được so sánh bằng cách gọi `>=` trên các giá trị bên trong của chúng.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// So sánh hai `Arc`.
    ///
    /// Cả hai được so sánh bằng cách gọi `cmp()` trên các giá trị bên trong của chúng.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Tạo `Arc<T>` mới, với giá trị `Default` cho `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Phân bổ một lát được tính tham chiếu và lấp đầy nó bằng cách sao chép các mục của `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Phân bổ `str` được tính tham chiếu và sao chép `v` vào đó.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Phân bổ `str` được tính tham chiếu và sao chép `v` vào đó.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Di chuyển một đối tượng được đóng hộp sang một phân bổ mới, được tính là tham chiếu.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Phân bổ một lát được tính tham chiếu và di chuyển các mục của `v` vào đó.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Cho phép Vec giải phóng bộ nhớ của nó, nhưng không phá hủy nội dung của nó
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Lấy từng phần tử trong `Iterator` và thu thập nó thành `Arc<[T]>`.
    ///
    /// # Đặc điểm hiệu suất
    ///
    /// ## Trường hợp chung
    ///
    /// Trong trường hợp chung, việc thu thập vào `Arc<[T]>` được thực hiện bằng cách thu thập vào `Vec<T>` trước.Đó là, khi viết như sau:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// điều này hoạt động như thể chúng tôi đã viết:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Tập hợp phân bổ đầu tiên xảy ra ở đây.
    ///     .into(); // Phân bổ thứ hai cho `Arc<[T]>` xảy ra ở đây.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Điều này sẽ phân bổ nhiều lần nếu cần để xây dựng `Vec<T>` và sau đó nó sẽ phân bổ một lần để biến `Vec<T>` thành `Arc<[T]>`.
    ///
    ///
    /// ## Trình lặp có độ dài đã biết
    ///
    /// Khi `Iterator` của bạn triển khai `TrustedLen` và có kích thước chính xác, một phân bổ duy nhất sẽ được thực hiện cho `Arc<[T]>`.Ví dụ:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Chỉ một phân bổ duy nhất xảy ra ở đây.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Chuyên trait dùng để thu vào `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Đây là trường hợp của một trình lặp `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // AN TOÀN: Chúng tôi cần đảm bảo rằng trình vòng lặp có độ dài chính xác và chúng tôi có.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Trở lại thực hiện bình thường.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Nhận phần bù trong `ArcInner` cho tải trọng đằng sau một con trỏ.
///
/// # Safety
///
/// Con trỏ phải trỏ đến (và có siêu dữ liệu hợp lệ cho) một phiên bản hợp lệ trước đó của T, nhưng T được phép bỏ đi.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Căn chỉnh giá trị chưa được kích thước vào cuối ArcInner.
    // Vì RcBox là repr(C) nên nó sẽ luôn là trường cuối cùng trong bộ nhớ.
    // AN TOÀN: vì các loại không kích thước duy nhất có thể là các lát cắt, các đối tượng trait,
    // và các loại extern, yêu cầu an toàn đầu vào hiện đủ để thỏa mãn các yêu cầu của align_of_val_raw;đây là chi tiết triển khai của ngôn ngữ có thể không được dựa vào bên ngoài std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}