//! Hàng đợi ưu tiên được triển khai với một đống nhị phân.
//!
//! Chèn và bật phần tử lớn nhất có độ phức tạp về thời gian *O*(log(*n*)).
//! Kiểm tra phần tử lớn nhất là *O*(1).Việc chuyển đổi vector thành một heap nhị phân có thể được thực hiện tại chỗ và có độ phức tạp *O*(*n*).
//! Một đống nhị phân cũng có thể được chuyển đổi thành một vector được sắp xếp tại chỗ, cho phép nó được sử dụng cho một *O*(*n*\*log(* n*)) tại chỗ.
//!
//! # Examples
//!
//! Đây là một ví dụ lớn hơn triển khai [Dijkstra's algorithm][dijkstra] để giải quyết [shortest path problem][sssp] trên [directed graph][dir_graph].
//!
//! Nó chỉ ra cách sử dụng [`BinaryHeap`] với các loại tùy chỉnh.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // Hàng đợi ưu tiên phụ thuộc vào `Ord`.
//! // Triển khai trait một cách rõ ràng để hàng đợi trở thành min-heap thay vì max-heap.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Lưu ý rằng chúng tôi lật thứ tự về chi phí.
//!         // Trong trường hợp có sự ràng buộc, chúng tôi so sánh các vị trí, bước này là cần thiết để làm cho việc triển khai `PartialEq` và `Ord` nhất quán.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` cũng cần được thực hiện.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Mỗi nút được biểu diễn dưới dạng `usize`, để triển khai ngắn hơn.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Thuật toán đường đi ngắn nhất Dijkstra.
//!
//! // Bắt đầu ở `start` và sử dụng `dist` để theo dõi khoảng cách ngắn nhất hiện tại đến mỗi nút.Việc triển khai này không hiệu quả về bộ nhớ vì nó có thể để lại các nút trùng lặp trong hàng đợi.
//! //
//! // Nó cũng sử dụng `usize::MAX` như một giá trị sentinel, để triển khai đơn giản hơn.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [node]=khoảng cách ngắn nhất hiện tại từ `start` đến `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Chúng tôi đang ở `start`, với chi phí bằng không
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Kiểm tra biên giới với các nút chi phí thấp hơn (min-heap) đầu tiên
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Ngoài ra, chúng tôi có thể tiếp tục tìm tất cả các con đường ngắn nhất
//!         if position == goal { return Some(cost); }
//!
//!         // Quan trọng vì chúng tôi có thể đã tìm ra cách tốt hơn
//!         if cost > dist[position] { continue; }
//!
//!         // Đối với mỗi nút mà chúng tôi có thể tiếp cận, hãy xem liệu chúng tôi có thể tìm ra cách với chi phí thấp hơn đi qua nút này không
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Nếu vậy, hãy thêm nó vào biên giới và tiếp tục
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Thư giãn, chúng tôi đã tìm thấy một cách tốt hơn
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Không thể đạt được mục tiêu
//!     None
//! }
//!
//! fn main() {
//!     // Đây là biểu đồ có hướng mà chúng tôi sẽ sử dụng.
//!     // Số nút tương ứng với các trạng thái khác nhau và trọng số edge tượng trưng cho chi phí di chuyển từ nút này sang nút khác.
//!     //
//!     // Lưu ý rằng các cạnh là một chiều.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // Biểu đồ được biểu diễn dưới dạng danh sách kề trong đó mỗi chỉ mục, tương ứng với một giá trị nút, có một danh sách các cạnh đi ra.
//!     // Được lựa chọn vì hiệu quả của nó.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Nút 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Nút 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Nút 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Nút 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Nút 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Hàng đợi ưu tiên được triển khai với một đống nhị phân.
///
/// Đây sẽ là một đống tối đa.
///
/// Đó là một lỗi logic đối với một mặt hàng được sửa đổi theo cách khiến thứ tự của mặt hàng đó so với bất kỳ mặt hàng nào khác, như được xác định bởi `Ord` trait, thay đổi khi nó ở trong đống.
///
/// Điều này thường chỉ có thể thực hiện được thông qua `Cell`, `RefCell`, trạng thái toàn cầu, I/O hoặc mã không an toàn.
/// Hành vi do lỗi logic như vậy không được chỉ định, nhưng sẽ không dẫn đến hành vi không xác định.
/// Điều này có thể bao gồm panics, kết quả không chính xác, hủy bỏ, rò rỉ bộ nhớ và không kết thúc.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Suy luận kiểu cho phép chúng ta bỏ qua một chữ ký kiểu rõ ràng (trong ví dụ này sẽ là `BinaryHeap<i32>`).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Chúng ta có thể sử dụng tính năng nhìn trộm để xem mục tiếp theo trong đống.
/// // Trong trường hợp này, chưa có mục nào trong đó nên chúng tôi nhận được Không có.
/// assert_eq!(heap.peek(), None);
///
/// // Hãy thêm một số điểm số ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Bây giờ xem trước cho thấy mục quan trọng nhất trong đống.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Chúng tôi có thể kiểm tra độ dài của một đống.
/// assert_eq!(heap.len(), 3);
///
/// // Chúng ta có thể lặp lại các mục trong đống, mặc dù chúng được trả về theo thứ tự ngẫu nhiên.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Thay vào đó, nếu chúng tôi bật những điểm số này, chúng sẽ trở lại theo thứ tự.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Chúng tôi có thể xóa đống của bất kỳ mục nào còn lại.
/// heap.clear();
///
/// // Heap bây giờ sẽ trống.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Có thể sử dụng `std::cmp::Reverse` hoặc triển khai `Ord` tùy chỉnh để biến `BinaryHeap` trở thành min-heap.
/// Điều này làm cho `heap.pop()` trả về giá trị nhỏ nhất thay vì giá trị lớn nhất.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Bọc các giá trị trong `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Nếu chúng ta bật những điểm số này ngay bây giờ, chúng sẽ trở lại theo thứ tự ngược lại.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Thời gian phức tạp
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// Giá trị cho `push` là chi phí dự kiến;tài liệu phương pháp cung cấp một phân tích chi tiết hơn.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Cấu trúc bao bọc một tham chiếu có thể thay đổi đến mục lớn nhất trên `BinaryHeap`.
///
///
/// `struct` này được tạo bằng phương thức [`peek_mut`] trên [`BinaryHeap`].
/// Xem tài liệu của nó để biết thêm.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // AN TOÀN: PeekMut chỉ được khởi tạo cho các heap không trống.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // AN TOÀN: PeekMut chỉ được khởi tạo cho các heap không trống
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // AN TOÀN: PeekMut chỉ được khởi tạo cho các heap không trống
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Loại bỏ giá trị đã xem trước khỏi heap và trả lại giá trị đó.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Tạo một `BinaryHeap<T>` trống.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Tạo `BinaryHeap` trống dưới dạng khối tối đa.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Tạo một `BinaryHeap` trống với một dung lượng cụ thể.
    /// Điều này phân bổ trước đủ bộ nhớ cho các phần tử `capacity`, để `BinaryHeap` không phải được phân bổ lại cho đến khi nó chứa ít nhất nhiều giá trị đó.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Trả về một tham chiếu có thể thay đổi cho mục lớn nhất trong đống nhị phân hoặc `None` nếu nó trống.
    ///
    /// Note: Nếu giá trị `PeekMut` bị rò rỉ, heap có thể ở trạng thái không nhất quán.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Thời gian phức tạp
    ///
    /// Nếu mục được sửa đổi thì độ phức tạp thời gian trong trường hợp xấu nhất là *O*(log(*n*)), ngược lại là *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Loại bỏ mục lớn nhất khỏi đống nhị phân và trả lại hoặc `None` nếu nó trống.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Thời gian phức tạp
    ///
    /// Chi phí trong trường hợp xấu nhất của `pop` trên một đống chứa *n* phần tử là *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // AN TOÀN: !self.is_empty() có nghĩa là self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Đẩy một mục lên đống nhị phân.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Thời gian phức tạp
    ///
    /// Chi phí dự kiến của `push`, được tính trung bình trên mọi thứ tự có thể có của các phần tử được đẩy và trên một số lượng đẩy đủ lớn, là *O*(1).
    ///
    /// Đây là chỉ số chi phí có ý nghĩa nhất khi đẩy các phần tử *không* đã có trong bất kỳ mẫu được sắp xếp nào.
    ///
    /// Độ phức tạp về thời gian giảm đi nếu các phần tử được đẩy chủ yếu theo thứ tự tăng dần.
    /// Trong trường hợp xấu nhất, các phần tử được đẩy theo thứ tự sắp xếp tăng dần và chi phí phân bổ cho mỗi lần đẩy là *O*(log(*n*)) so với một đống chứa *n* phần tử.
    ///
    /// Chi phí trong trường hợp xấu nhất của một cuộc gọi *đơn* tới `push` là *O*(*n*).Trường hợp xấu nhất xảy ra khi dung lượng đã hết và cần thay đổi kích thước.
    /// Chi phí thay đổi kích thước đã được phân bổ trong các số liệu trước đó.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // AN TOÀN: Vì chúng tôi đã đẩy một mặt hàng mới, điều đó có nghĩa là
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Sử dụng `BinaryHeap` và trả về vector theo thứ tự (ascending) được sắp xếp.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // AN TOÀN: `end` chuyển từ `self.len() - 1` thành 1 (bao gồm cả hai),
            //  vì vậy nó luôn là một chỉ mục hợp lệ để truy cập.
            //  Việc truy cập chỉ mục 0 (tức là `ptr`) là an toàn, bởi vì
            //  1 <=end <self.len(), nghĩa là self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // AN TOÀN: `end` chuyển từ `self.len() - 1` thành 1 (bao gồm cả hai) vì vậy:
            //  0 <1 <=end <= self.len(), 1 <self.len() Có nghĩa là 0 <end và end <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Việc triển khai sift_up và sift_down sử dụng các khối không an toàn để di chuyển một phần tử ra khỏi vector (để lại một lỗ), dịch chuyển dọc theo các phần tử khác và di chuyển phần tử đã loại bỏ trở lại vector tại vị trí cuối cùng của lỗ.
    //
    // Loại `Hole` được sử dụng để thể hiện điều này và đảm bảo lỗ được lấp đầy trở lại ở cuối phạm vi của nó, ngay cả trên panic.
    // Sử dụng một lỗ làm giảm hệ số không đổi so với sử dụng hoán đổi, bao gồm hai lần di chuyển.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Người gọi phải đảm bảo rằng `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Lấy ra giá trị tại `pos` và tạo một lỗ.
        // AN TOÀN: Người gọi đảm bảo rằng pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // AN TOÀN: hole.pos()> start>=0, có nghĩa là hole.pos()> 0
            //  và vì vậy hole.pos(), 1 không thể tràn.
            //  Điều này đảm bảo rằng cha mẹ <hole.pos() vì vậy nó là một chỉ mục hợp lệ và cũng có thể!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // AN TOÀN: Tương tự như trên
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Lấy một phần tử ở `pos` và di chuyển phần tử đó xuống đống, trong khi phần tử con của nó lớn hơn.
    ///
    ///
    /// # Safety
    ///
    /// Người gọi phải đảm bảo rằng `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // AN TOÀN: Người gọi đảm bảo rằng pos <end <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Bất biến vòng lặp: con==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // so sánh với con lớn hơn của hai con SAFETY: con <end, 1 <self.len() và con + 1 <end <= self.len(), vì vậy chúng là các chỉ mục hợp lệ.
            //
            //  con==2 *hole.pos() + 1!= hole.pos() và con + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 hoặc 2* hole.pos() + 2 có thể tràn nếu T là ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // nếu chúng ta đã có thứ tự, hãy dừng lại.
            // AN TOÀN: đứa trẻ bây giờ là đứa trẻ cũ hoặc đứa trẻ cũ + 1
            //  Chúng tôi đã chứng minh rằng cả hai đều <self.len() và!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // AN TOÀN: giống như trên.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // AN TOÀN: &&ngắn mạch, có nghĩa là trong
        //  điều kiện thứ hai là con==end, 1 <self.len() đã đúng.
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // AN TOÀN: trẻ đã được chứng minh là một chỉ mục hợp lệ và
            //  con==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Người gọi phải đảm bảo rằng `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // AN TOÀN: pos <len được đảm bảo bởi người gọi và
        //  rõ ràng len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Lấy một phần tử tại `pos` và di chuyển phần tử đó xuống hết đống, sau đó sàng lọc phần tử đó đến vị trí của nó.
    ///
    ///
    /// Note: Điều này nhanh hơn khi phần tử được biết là lớn/phải gần đáy hơn.
    ///
    /// # Safety
    ///
    /// Người gọi phải đảm bảo rằng `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // AN TOÀN: Người gọi đảm bảo rằng pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Bất biến vòng lặp: con==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // AN TOÀN: con <end, 1 <self.len() và
            //  con + 1 <end <= self.len(), vì vậy chúng là các chỉ mục hợp lệ.
            //  con==2 *hole.pos() + 1!= hole.pos() và con + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 hoặc 2* hole.pos() + 2 có thể tràn nếu T là ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // AN TOÀN: Tương tự như trên
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // AN TOÀN: con==end, 1 <self.len(), vì vậy nó là một chỉ mục hợp lệ
            //  và con==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // AN TOÀN: pos là vị trí trong lỗ và đã được chứng minh
        //  là một chỉ mục hợp lệ.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // AN TOÀN: n bắt đầu từ self.len()/2 và đi xuống 0.
            //  Trường hợp duy nhất khi! (N <self.len()) là nếu self.len() ==0, nhưng nó bị loại trừ bởi điều kiện vòng lặp.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Di chuyển tất cả các phần tử của `other` vào `self`, để trống `other`.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` thực hiện các phép toán O(len1 + len2) và khoảng 2 *(len1 + len2) trong trường hợp xấu nhất trong khi `extend` thực hiện phép toán O(len2* log(len1)) và khoảng 1 *len2* log_2(len1) so sánh trong trường hợp xấu nhất, giả sử len1>= len2.
        // Đối với các đống lớn hơn, điểm giao nhau không còn tuân theo lý do này nữa và được xác định theo kinh nghiệm.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Trả về một trình lặp truy xuất các phần tử theo thứ tự đống.
    /// Các phần tử được truy xuất sẽ bị xóa khỏi đống ban đầu.
    /// Các phần tử còn lại sẽ bị xóa theo thứ tự đống.
    ///
    /// Note:
    /// * `.drain_sorted()` là *O*(*n*\*log(* n*)); chậm hơn nhiều so với `.drain()`.
    ///   Bạn nên sử dụng cái sau cho hầu hết các trường hợp.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // loại bỏ tất cả các phần tử theo thứ tự đống
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Chỉ giữ lại các phần tử được chỉ định bởi vị từ.
    ///
    /// Nói cách khác, loại bỏ tất cả các phần tử `e` để `f(&e)` trả về `false`.
    /// Các phần tử được truy cập theo thứ tự không được sắp xếp (và không xác định).
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // chỉ giữ số chẵn
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Trả về một trình lặp truy cập tất cả các giá trị trong vector bên dưới, theo thứ tự tùy ý.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // In 1, 2, 3, 4 theo thứ tự tùy ý
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Trả về một trình lặp truy xuất các phần tử theo thứ tự đống.
    /// Phương thức này sử dụng heap ban đầu.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Trả về mục lớn nhất trong đống nhị phân hoặc `None` nếu nó trống.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Thời gian phức tạp
    ///
    /// Chi phí là *O*(1) trong trường hợp xấu nhất.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Trả về số phần tử mà đống nhị phân có thể giữ mà không cần phân bổ lại.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Dành riêng dung lượng tối thiểu cho chính xác `additional` nhiều phần tử hơn sẽ được chèn vào `BinaryHeap` đã cho.
    /// Không có gì nếu dung lượng đã đủ.
    ///
    /// Lưu ý rằng bộ phân bổ có thể cung cấp cho bộ sưu tập nhiều không gian hơn nó yêu cầu.
    /// Do đó, không thể dựa vào dung lượng để được chính xác là tối thiểu.
    /// Ưu tiên [`reserve`] nếu mong đợi chèn future.
    ///
    /// # Panics
    ///
    /// Panics nếu dung lượng mới tràn `usize`.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Dự trữ dung lượng cho ít nhất `additional` nhiều phần tử hơn sẽ được chèn vào `BinaryHeap`.
    /// Bộ sưu tập có thể dành thêm không gian để tránh tái phân bổ thường xuyên.
    ///
    /// # Panics
    ///
    /// Panics nếu dung lượng mới tràn `usize`.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Loại bỏ càng nhiều dung lượng bổ sung càng tốt.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Loại bỏ dung lượng có giới hạn thấp hơn.
    ///
    /// Dung lượng ít nhất sẽ vẫn lớn bằng cả chiều dài và giá trị được cung cấp.
    ///
    ///
    /// Nếu dung lượng hiện tại nhỏ hơn giới hạn dưới, đây là điều không nên.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Sử dụng `BinaryHeap` và trả về vector bên dưới theo thứ tự tùy ý.
    ///
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Sẽ in theo thứ tự nào đó
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Trả về độ dài của đống nhị phân.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Kiểm tra xem đống nhị phân có trống không.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Xóa đống nhị phân, trả về một trình lặp trên các phần tử đã bị loại bỏ.
    ///
    /// Các phần tử được loại bỏ theo thứ tự tùy ý.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Bỏ tất cả các mục khỏi đống nhị phân.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Hole đại diện cho một lỗ trong một lát cắt, tức là một chỉ mục không có giá trị hợp lệ (vì nó đã được di chuyển từ hoặc sao chép).
///
/// Khi thả, `Hole` sẽ khôi phục lát cắt bằng cách lấp đầy vị trí lỗ với giá trị đã được loại bỏ ban đầu.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Tạo một `Hole` mới tại chỉ mục `pos`.
    ///
    /// Không an toàn vì pos phải nằm trong lát dữ liệu.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // AN TOÀN: pos phải ở bên trong lát
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Trả về một tham chiếu đến phần tử bị xóa.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Trả về một tham chiếu đến phần tử tại `index`.
    ///
    /// Không an toàn vì chỉ mục phải nằm trong lát dữ liệu và không bằng vị trí.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Di chuyển lỗ đến vị trí mới
    ///
    /// Không an toàn vì chỉ mục phải nằm trong lát dữ liệu và không bằng vị trí.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // lấp đầy lỗ một lần nữa
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Một trình lặp trên các phần tử của `BinaryHeap`.
///
/// `struct` này được tạo ra bởi [`BinaryHeap::iter()`].
/// Xem tài liệu của nó để biết thêm.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Loại bỏ có lợi cho `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Một trình lặp sở hữu trên các phần tử của `BinaryHeap`.
///
/// `struct` này được tạo ra bởi [`BinaryHeap::into_iter()`] (được cung cấp bởi `IntoIterator` trait).
/// Xem tài liệu của nó để biết thêm.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Một trình lặp rút cạn trên các phần tử của `BinaryHeap`.
///
/// `struct` này được tạo ra bởi [`BinaryHeap::drain()`].
/// Xem tài liệu của nó để biết thêm.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Một trình lặp rút cạn trên các phần tử của `BinaryHeap`.
///
/// `struct` này được tạo ra bởi [`BinaryHeap::drain_sorted()`].
/// Xem tài liệu của nó để biết thêm.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Loại bỏ các phần tử đống theo thứ tự đống.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Chuyển đổi `Vec<T>` thành `BinaryHeap<T>`.
    ///
    /// Việc chuyển đổi này diễn ra tại chỗ và có độ phức tạp về thời gian *O*(*n*).
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Chuyển đổi `BinaryHeap<T>` thành `Vec<T>`.
    ///
    /// Việc chuyển đổi này không yêu cầu di chuyển hoặc phân bổ dữ liệu và có độ phức tạp về thời gian không đổi.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Tạo một trình lặp tiêu thụ, nghĩa là một trình lặp di chuyển từng giá trị ra khỏi đống nhị phân theo thứ tự tùy ý.
    /// Không thể sử dụng đống nhị phân sau khi gọi nó.
    ///
    /// # Examples
    ///
    /// Cách sử dụng cơ bản:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // In 1, 2, 3, 4 theo thứ tự tùy ý
    /// for x in heap.into_iter() {
    ///     // x có loại i32, không phải &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}