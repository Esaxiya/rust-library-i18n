use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Thêm tất cả các cặp khóa-giá trị từ sự kết hợp của hai trình vòng lặp tăng dần, tăng một biến `length` trong quá trình thực hiện.Cái thứ hai giúp người gọi dễ dàng tránh bị rò rỉ khi người đánh rơi hoảng sợ.
    ///
    /// Nếu cả hai trình vòng lặp tạo ra cùng một khóa, phương thức này loại bỏ cặp từ trình vòng lặp bên trái và nối cặp từ trình vòng lặp bên phải.
    ///
    /// Nếu bạn muốn cây kết thúc theo thứ tự tăng dần, như đối với `BTreeMap`, cả hai trình vòng lặp phải tạo ra các khóa theo thứ tự tăng dần, mỗi khóa lớn hơn tất cả các khóa trong cây, bao gồm bất kỳ khóa nào đã có trong cây khi nhập.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Chúng tôi chuẩn bị hợp nhất `left` và `right` thành một chuỗi được sắp xếp theo thời gian tuyến tính.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Trong khi đó, chúng tôi xây dựng một cây từ trình tự được sắp xếp theo thời gian tuyến tính.
        self.bulk_push(iter, length)
    }

    /// Đẩy tất cả các cặp khóa-giá trị về cuối cây, tăng một biến `length` trong quá trình thực hiện.
    /// Cái thứ hai giúp người gọi dễ dàng tránh bị rò rỉ khi người lặp hoảng sợ.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Lặp lại tất cả các cặp khóa-giá trị, đẩy chúng vào các nút ở cấp độ phù hợp.
        for (key, value) in iter {
            // Cố gắng đẩy cặp khóa-giá trị vào nút lá hiện tại.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Không còn chỗ trống, đi lên và đẩy tới đó.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Tìm thấy một nút còn trống, nhấn vào đây.
                                open_node = parent;
                                break;
                            } else {
                                // Đi lên một lần nữa.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Chúng tôi đang ở trên cùng, tạo một nút gốc mới và đẩy đến đó.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Đẩy cặp khóa-giá trị và cây con bên phải mới.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Đi xuống lá ngoài cùng bên phải một lần nữa.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Độ dài tăng lên mỗi lần lặp lại, để đảm bảo bản đồ loại bỏ các phần tử được thêm vào ngay cả khi tiến trình của trình lặp có hoảng sợ.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Một trình lặp để hợp nhất hai chuỗi đã sắp xếp thành một
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Nếu hai khóa bằng nhau, trả về cặp khóa-giá trị từ nguồn bên phải.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}