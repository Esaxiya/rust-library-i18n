// Đây là một nỗ lực thực hiện theo lý tưởng
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Vì Rust không thực sự có các kiểu phụ thuộc và đệ quy đa hình, chúng tôi thực hiện với rất nhiều điều không an toàn.
//

// Mục tiêu chính của mô-đun này là tránh sự phức tạp bằng cách coi cây như một thùng chứa chung (nếu có hình dạng kỳ lạ) và tránh xử lý hầu hết các bất biến của B-Tree.
//
// Do đó, mô-đun này không quan tâm đến việc các mục nhập có được sắp xếp hay không, các nút nào có thể bị đầy hoặc thậm chí là dưới mức có nghĩa là gì.Tuy nhiên, chúng tôi dựa trên một số bất biến:
//
// - Cây phải có depth/height đồng đều.Điều này có nghĩa là mọi đường dẫn xuống lá từ một nút nhất định đều có cùng độ dài.
// - Một nút có độ dài `n` có các khóa `n`, giá trị `n` và các cạnh `n + 1`.
//   Điều này ngụ ý rằng ngay cả một nút trống cũng có ít nhất một edge.
//   Đối với một nút lá, "having an edge" chỉ có nghĩa là chúng ta có thể xác định một vị trí trong nút, vì các cạnh lá trống và không cần biểu diễn dữ liệu.
// Trong một nút bên trong, một edge vừa xác định một vị trí vừa chứa một con trỏ đến một nút con.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Biểu diễn bên dưới của các nút lá và một phần của biểu diễn các nút bên trong.
struct LeafNode<K, V> {
    /// Chúng tôi muốn đồng biến trong `K` và `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Chỉ mục của nút này vào mảng `edges` của nút mẹ.
    /// `*node.parent.edges[node.parent_idx]` sẽ giống như `node`.
    /// Điều này chỉ được đảm bảo được khởi tạo khi `parent` không phải là null.
    parent_idx: MaybeUninit<u16>,

    /// Số lượng khóa và giá trị mà nút này lưu trữ.
    len: u16,

    /// Các mảng lưu trữ dữ liệu thực của nút.
    /// Chỉ các phần tử `len` đầu tiên của mỗi mảng được khởi tạo và hợp lệ.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Khởi tạo `LeafNode` mới tại chỗ.
    unsafe fn init(this: *mut Self) {
        // Theo chính sách chung, chúng tôi không khởi tạo các trường nếu có thể, vì điều này sẽ nhanh hơn một chút và dễ theo dõi hơn trong Valgrind.
        //
        unsafe {
            // parent_idx, key và vals đều là MaybeUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Tạo một `LeafNode` mới đóng hộp.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Biểu diễn cơ bản của các nút bên trong.Như với `LeafNode`s, chúng nên được ẩn sau`BoxedNode`s để ngăn chặn việc làm rơi các khóa và giá trị chưa được khởi tạo.
/// Bất kỳ con trỏ nào đến `InternalNode` đều có thể được truyền trực tiếp tới một con trỏ tới phần `LeafNode` bên dưới của nút, cho phép mã hoạt động trên các nút lá và nút bên trong một cách chung chung mà không cần phải kiểm tra xem con trỏ đang trỏ đến cái nào trong hai nút.
///
/// Thuộc tính này được kích hoạt bằng cách sử dụng `repr(C)`.
///
#[repr(C)]
// gdb_providers.py sử dụng tên loại này để xem xét nội tâm.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Các con trỏ đến con của nút này.
    /// `len + 1` trong số này được coi là đã khởi tạo và hợp lệ, ngoại trừ việc ở gần cuối, trong khi cây được giữ thông qua kiểu vay `Dying`, một số con trỏ này bị treo lơ lửng.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Tạo một `InternalNode` mới đóng hộp.
    ///
    /// # Safety
    /// Một bất biến của các nút bên trong là chúng có ít nhất một edge được khởi tạo và hợp lệ.
    /// Chức năng này không thiết lập edge như vậy.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Chúng ta chỉ cần khởi tạo dữ liệu;các cạnh là Có thểUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Một con trỏ được quản lý, không rỗng tới một nút.Đây là con trỏ được sở hữu tới `LeafNode<K, V>` hoặc con trỏ được sở hữu tới `InternalNode<K, V>`.
///
/// Tuy nhiên, `BoxedNode` không chứa thông tin về loại nút nào trong số hai loại nút mà nó thực sự chứa, và một phần do thiếu thông tin này, nó không phải là một loại riêng biệt và không có trình hủy.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Nút gốc của cây sở hữu.
///
/// Lưu ý rằng điều này không có trình hủy và phải được dọn dẹp theo cách thủ công.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Trả về một cây được sở hữu mới, với nút gốc của chính nó ban đầu trống.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` không được bằng 0.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Mượn lẫn nhau của nút gốc được sở hữu.
    /// Không giống như `reborrow_mut`, điều này là an toàn vì giá trị trả về không thể được sử dụng để phá hủy gốc và không thể có các tham chiếu khác đến cây.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Hơi vay mượn nút gốc được sở hữu.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Chuyển đổi không thể đảo ngược sang một tham chiếu cho phép duyệt và cung cấp các phương pháp phá hủy và một số phương pháp khác.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Thêm một nút bên trong mới với một edge duy nhất trỏ đến nút gốc trước đó, đặt nút mới đó thành nút gốc và trả về.
    /// Điều này làm tăng chiều cao lên 1 và ngược lại với `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, ngoại trừ việc chúng tôi chỉ quên rằng chúng tôi đang ở bên trong:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Loại bỏ nút gốc bên trong, sử dụng nút con đầu tiên của nó làm nút gốc mới.
    /// Vì nó chỉ được gọi khi nút gốc chỉ có một nút con, không có thao tác dọn dẹp nào được thực hiện trên bất kỳ khóa, giá trị và các nút con khác.
    ///
    /// Điều này làm giảm chiều cao đi 1 và ngược lại với `push_internal_level`.
    ///
    /// Yêu cầu quyền truy cập độc quyền vào đối tượng `Root` nhưng không yêu cầu nút gốc;
    /// nó sẽ không làm mất hiệu lực của các xử lý hoặc tham chiếu khác đến nút gốc.
    ///
    /// Panics nếu không có mức bên trong, tức là nếu nút gốc là một lá.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // AN TOÀN: chúng tôi khẳng định là nội bộ.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // AN TOÀN: chúng tôi mượn riêng `self` và kiểu mượn của nó là độc quyền.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // AN TOÀN: edge đầu tiên luôn được khởi tạo.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` luôn đồng biến trong `K` và `V`, ngay cả khi `BorrowType` là `Mut`.
// Điều này là sai về mặt kỹ thuật, nhưng không thể dẫn đến bất kỳ sự mất an toàn nào do việc sử dụng nội bộ của `NodeRef` vì chúng tôi hoàn toàn chung chung so với `K` và `V`.
//
// Tuy nhiên, bất cứ khi nào một loại công khai kết thúc `NodeRef`, hãy đảm bảo rằng nó có phương sai chính xác.
//
/// Tham chiếu đến một nút.
///
/// Loại này có một số tham số kiểm soát cách nó hoạt động:
/// - `BorrowType`: Một kiểu giả mô tả kiểu đi vay và mang theo suốt đời.
///    - Khi đây là `Immut<'a>`, `NodeRef` hoạt động gần giống như `&'a Node`.
///    - Khi đây là `ValMut<'a>`, `NodeRef` hoạt động gần giống như `&'a Node` đối với các khóa và cấu trúc cây, nhưng cũng cho phép nhiều tham chiếu có thể thay đổi đến các giá trị trong toàn bộ cây cùng tồn tại.
///    - Khi đây là `Mut<'a>`, `NodeRef` hoạt động gần giống như `&'a mut Node`, mặc dù các phương thức chèn cho phép một con trỏ có thể thay đổi thành một giá trị cùng tồn tại.
///    - Khi đây là `Owned`, `NodeRef` hoạt động gần giống như `Box<Node>`, nhưng không có bộ hủy và phải được dọn dẹp theo cách thủ công.
///    - Khi đây là `Dying`, `NodeRef` vẫn hoạt động gần giống như `Box<Node>`, nhưng có các phương thức để phá hủy cây từng chút một và các phương thức thông thường, mặc dù không được đánh dấu là không an toàn để gọi, có thể gọi UB nếu được gọi sai.
///
///   Vì bất kỳ `NodeRef` nào đều cho phép điều hướng qua cây, nên `BorrowType` áp dụng hiệu quả cho toàn bộ cây, không chỉ cho chính nút.
/// - `K` và `V`: Đây là các loại khóa và giá trị được lưu trữ trong các nút.
/// - `Type`: Đây có thể là `Leaf`, `Internal` hoặc `LeafOrInternal`.
/// Khi đây là `Leaf`, `NodeRef` trỏ đến một nút lá, khi đây là `Internal` thì `NodeRef` trỏ đến một nút bên trong và khi đây là `LeafOrInternal` thì `NodeRef` có thể trỏ đến một trong hai loại nút.
///   `Type` được đặt tên là `NodeType` khi sử dụng bên ngoài `NodeRef`.
///
/// Cả `BorrowType` và `NodeType` đều hạn chế những phương pháp chúng tôi triển khai để khai thác sự an toàn kiểu tĩnh.Có những hạn chế trong cách chúng tôi có thể áp dụng những hạn chế như vậy:
/// - Đối với mỗi tham số kiểu, chúng ta chỉ có thể xác định một phương thức chung chung hoặc cho một kiểu cụ thể.
/// Ví dụ: chúng tôi không thể định nghĩa chung một phương thức như `into_kv` cho tất cả `BorrowType` hoặc một lần cho tất cả các loại có thời gian tồn tại, bởi vì chúng tôi muốn nó trả về các tham chiếu `&'a`.
///   Do đó, chúng tôi chỉ định nghĩa nó cho loại `Immut<'a>` kém mạnh nhất.
/// - Chúng tôi không thể nhận được sự ép buộc ngầm từ `Mut<'a>` đến `Immut<'a>`.
///   Do đó, chúng ta phải gọi `reborrow` một cách rõ ràng trên một `NodeRef` mạnh mẽ hơn để đạt được một phương thức như `into_kv`.
///
/// Tất cả các phương thức trên `NodeRef` trả về một số loại tham chiếu:
/// - Lấy `self` theo giá trị và trả về thời gian tồn tại của `BorrowType`.
///   Đôi khi, để gọi một phương thức như vậy, chúng ta cần gọi `reborrow_mut`.
/// - Lấy `self` theo tham chiếu và (implicitly) trả về thời gian tồn tại của tham chiếu đó, thay vì thời gian tồn tại của `BorrowType`.
/// Bằng cách đó, công cụ kiểm tra khoản vay đảm bảo rằng `NodeRef` vẫn được mượn miễn là tham chiếu trả về được sử dụng.
///   Các phương thức hỗ trợ chèn sẽ bẻ cong quy tắc này bằng cách trả về một con trỏ thô, tức là một tham chiếu không có thời gian tồn tại.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Số mức mà nút và mức lá cách nhau, một hằng số của nút mà `Type` không thể mô tả hoàn toàn và bản thân nút đó không lưu trữ.
    /// Chúng ta chỉ cần lưu trữ chiều cao của nút gốc và lấy ra mọi chiều cao của nút khác từ nó.
    /// Phải bằng 0 nếu `Type` là `Leaf` và khác 0 nếu `Type` là `Internal`.
    ///
    ///
    height: usize,
    /// Con trỏ tới lá hoặc nút bên trong.
    /// Định nghĩa của `InternalNode` đảm bảo rằng con trỏ hợp lệ theo cả hai cách.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Giải nén tham chiếu nút được đóng gói dưới dạng `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Hiển thị dữ liệu của một nút bên trong.
    ///
    /// Trả về một ptr thô để tránh làm mất hiệu lực của các tham chiếu khác đến nút này.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // AN TOÀN: loại nút tĩnh là `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Mượn quyền truy cập độc quyền vào dữ liệu của một nút nội bộ.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Tìm chiều dài của nút.Đây là số lượng khóa hoặc giá trị.
    /// Số cạnh là `len() + 1`.
    /// Lưu ý rằng, mặc dù an toàn, nhưng việc gọi hàm này có thể có tác dụng phụ là làm mất hiệu lực của các tham chiếu có thể thay đổi mà mã không an toàn đã tạo.
    ///
    pub fn len(&self) -> usize {
        // Điều quan trọng, chúng tôi chỉ truy cập trường `len` tại đây.
        // Nếu BorrowType là marker::ValMut, có thể có các tham chiếu có thể thay đổi nổi bật đến các giá trị mà chúng tôi không được làm mất hiệu lực.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Trả về số cấp mà nút và các lá khác nhau.
    /// Chiều cao bằng không có nghĩa là bản thân nút là một lá.
    /// Nếu bạn hình dung cây có gốc ở trên cùng, con số cho biết nút sẽ xuất hiện ở độ cao nào.
    /// Nếu bạn hình dung những cái cây có lá ở trên cùng, con số cho biết cây vươn cao bao nhiêu phía trên nút.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Tạm thời lấy ra một tham chiếu khác, bất biến cho cùng một nút.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Để lộ phần lá của bất kỳ lá nào hoặc nút bên trong.
    ///
    /// Trả về một ptr thô để tránh làm mất hiệu lực của các tham chiếu khác đến nút này.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Nút phải hợp lệ cho ít nhất phần LeafNode.
        // Đây không phải là một tham chiếu trong kiểu NodeRef vì chúng tôi không biết liệu nó nên là duy nhất hay được chia sẻ.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Tìm nút cha của nút hiện tại.
    /// Trả về `Ok(handle)` nếu nút hiện tại thực sự có nút cha, trong đó `handle` trỏ đến edge của nút mẹ trỏ đến nút hiện tại.
    ///
    /// Trả về `Err(self)` nếu nút hiện tại không có nút cha, trả về `NodeRef` ban đầu.
    ///
    /// Tên phương thức giả sử bạn hình ảnh cây với nút gốc ở trên cùng.
    ///
    /// `edge.descend().ascend().unwrap()` và `node.ascend().unwrap().descend()` nên cả hai, khi thành công, không làm gì cả.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Chúng ta cần sử dụng con trỏ thô đến các nút vì nếu BorrowType là marker::ValMut, có thể có các tham chiếu có thể thay đổi nổi bật đến các giá trị mà chúng ta không được làm mất hiệu lực.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Lưu ý rằng `self` không phải là aimpty.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Lưu ý rằng `self` không phải là aimpty.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Để lộ phần lá của bất kỳ lá nào hoặc nút bên trong cây bất biến.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // AN TOÀN: không thể có tham chiếu có thể thay đổi vào cây này được mượn là `Immut`.
        unsafe { &*ptr }
    }

    /// Mượn một khung nhìn vào các khóa được lưu trữ trong nút.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Tương tự như `ascend`, nhận một tham chiếu đến nút cha của một nút, nhưng cũng định vị nút hiện tại trong quá trình này.
    /// Điều này không an toàn vì nút hiện tại vẫn có thể truy cập được mặc dù đã được phân bổ.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Xác nhận một cách không an toàn với trình biên dịch thông tin tĩnh rằng nút này là `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Xác nhận một cách không an toàn với trình biên dịch thông tin tĩnh rằng nút này là `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Tạm thời lấy ra một tham chiếu khác, có thể thay đổi cho cùng một nút.Hãy cẩn thận, vì phương pháp này rất nguy hiểm, gấp đôi vì nó có thể không nguy hiểm ngay lập tức.
    ///
    /// Bởi vì con trỏ có thể thay đổi có thể di chuyển đến bất kỳ đâu xung quanh cây, con trỏ trả về có thể dễ dàng được sử dụng để làm cho con trỏ ban đầu bị treo lơ lửng, nằm ngoài giới hạn hoặc không hợp lệ theo quy tắc mượn xếp chồng lên nhau.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) hãy xem xét thêm một tham số kiểu khác vào `NodeRef` để hạn chế việc sử dụng các phương pháp điều hướng trên các con trỏ được mượn lại, ngăn chặn sự mất an toàn này.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Mượn quyền truy cập độc quyền vào phần lá của bất kỳ lá nào hoặc nút bên trong nào.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // AN TOÀN: chúng tôi có quyền truy cập độc quyền vào toàn bộ nút.
        unsafe { &mut *ptr }
    }

    /// Cung cấp quyền truy cập độc quyền vào phần lá của bất kỳ lá nào hoặc nút bên trong nào.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // AN TOÀN: chúng tôi có quyền truy cập độc quyền vào toàn bộ nút.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Mượn quyền truy cập độc quyền vào một phần tử của vùng lưu trữ khóa.
    ///
    /// # Safety
    /// `index` nằm trong giới hạn 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // AN TOÀN: người gọi sẽ không thể tự gọi các phương thức khác
        // cho đến khi tham chiếu lát khóa bị loại bỏ, vì chúng tôi có quyền truy cập duy nhất trong suốt thời gian của khoản vay.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Mượn quyền truy cập độc quyền vào một phần tử hoặc phần của vùng lưu trữ giá trị của nút.
    ///
    /// # Safety
    /// `index` nằm trong giới hạn 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // AN TOÀN: người gọi sẽ không thể tự gọi các phương thức khác
        // cho đến khi tham chiếu phần giá trị bị loại bỏ, vì chúng tôi có quyền truy cập duy nhất trong suốt thời gian của khoản vay.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Mượn quyền truy cập độc quyền vào một phần tử hoặc phần của vùng lưu trữ của nút cho nội dung edge.
    ///
    /// # Safety
    /// `index` nằm trong giới hạn 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // AN TOÀN: người gọi sẽ không thể tự gọi các phương thức khác
        // cho đến khi tham chiếu lát cắt edge bị loại bỏ, vì chúng tôi có quyền truy cập duy nhất trong suốt thời gian vay.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Nút có hơn `idx` phần tử được khởi tạo.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Chúng tôi chỉ tạo tham chiếu đến một phần tử mà chúng tôi quan tâm, để tránh hiện tượng răng cưa với các tham chiếu nổi bật đến các phần tử khác, đặc biệt là các tham chiếu được trả lại cho người gọi trong các lần lặp trước đó.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Chúng tôi phải cưỡng chế các con trỏ mảng không có kích thước vì vấn đề Rust #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Mượn quyền truy cập độc quyền vào chiều dài của nút.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Đặt liên kết của nút thành edge cha của nó, mà không làm mất hiệu lực các tham chiếu khác đến nút.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Xóa liên kết của gốc tới edge mẹ của nó.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Thêm cặp khóa-giá trị vào cuối nút.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Mỗi mục được trả về bởi `range` là một chỉ số edge hợp lệ cho nút.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Thêm một cặp khóa-giá trị và một edge ở bên phải của cặp đó, vào cuối nút.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Kiểm tra xem một nút là nút `Internal` hay nút `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Tham chiếu đến một cặp khóa-giá trị cụ thể hoặc edge trong một nút.
/// Tham số `Node` phải là `NodeRef`, trong khi `Type` có thể là `KV` (biểu thị một xử lý trên cặp khóa-giá trị) hoặc `Edge` (biểu thị một xử lý trên edge).
///
/// Lưu ý rằng ngay cả các nút `Leaf` cũng có thể có tay cầm `Edge`.
/// Thay vì đại diện cho một con trỏ tới một nút con, chúng đại diện cho các khoảng trống mà con trỏ con sẽ đi giữa các cặp khóa-giá trị.
/// Ví dụ, trong một nút có độ dài 2, sẽ có 3 vị trí edge có thể có, một ở bên trái của nút, một ở giữa hai cặp và một ở bên phải của nút.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Chúng tôi không cần tính tổng quát đầy đủ của `#[derive(Clone)]`, vì lần duy nhất `Node` sẽ được `` Sao chép '' là khi nó là một tham chiếu bất biến và do đó là `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Truy xuất nút có chứa edge hoặc cặp khóa-giá trị mà tay cầm này trỏ đến.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Trả về vị trí của chốt điều khiển này trong nút.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Tạo một chốt điều khiển mới cho cặp khóa-giá trị trong `node`.
    /// Không an toàn vì người gọi phải đảm bảo rằng `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Có thể là một triển khai công khai của PartialEq, nhưng chỉ được sử dụng trong mô-đun này.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Tạm thời lấy ra một tay cầm bất biến khác trên cùng một vị trí.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Chúng tôi không thể sử dụng Handle::new_kv hoặc Handle::new_edge vì chúng tôi không biết loại của mình
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Xác nhận một cách không an toàn với trình biên dịch thông tin tĩnh rằng nút của xử lý là `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Tạm thời lấy ra một tay cầm khác, có thể thay đổi trên cùng một vị trí.
    /// Hãy cẩn thận, vì phương pháp này rất nguy hiểm, gấp đôi vì nó có thể không nguy hiểm ngay lập tức.
    ///
    ///
    /// Để biết chi tiết, hãy xem `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Chúng tôi không thể sử dụng Handle::new_kv hoặc Handle::new_edge vì chúng tôi không biết loại của mình
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Tạo một tay cầm mới cho edge trong `node`.
    /// Không an toàn vì người gọi phải đảm bảo rằng `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Đưa ra chỉ số edge mà chúng ta muốn chèn vào một nút đã được lấp đầy dung lượng, tính chỉ số KV hợp lý của một điểm tách và nơi thực hiện chèn.
///
/// Mục tiêu của điểm phân tách là để khóa và giá trị của nó kết thúc trong một nút cha;
/// các khóa, giá trị và cạnh bên trái của điểm phân tách trở thành phần tử con bên trái;
/// các khóa, giá trị và các cạnh ở bên phải của điểm phân tách trở thành phần tử con bên phải.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Vấn đề Rust #74834 cố gắng giải thích các quy tắc đối xứng này.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Chèn một cặp khóa-giá trị mới giữa các cặp khóa-giá trị ở bên phải và bên trái của edge này.
    /// Phương pháp này giả định rằng có đủ không gian trong nút cho cặp mới phù hợp.
    ///
    /// Con trỏ trả về trỏ đến giá trị đã chèn.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Chèn một cặp khóa-giá trị mới giữa các cặp khóa-giá trị ở bên phải và bên trái của edge này.
    /// Phương pháp này sẽ chia nút nếu không có đủ chỗ.
    ///
    /// Con trỏ trả về trỏ đến giá trị đã chèn.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Sửa con trỏ cha và chỉ mục trong nút con mà edge này liên kết đến.
    /// Điều này hữu ích khi thứ tự của các cạnh đã được thay đổi,
    fn correct_parent_link(self) {
        // Tạo backpointer mà không làm mất hiệu lực các tham chiếu khác đến nút.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Chèn một cặp khóa-giá trị mới và một edge sẽ đi vào bên phải của cặp mới đó giữa edge này và cặp khóa-giá trị ở bên phải edge này.
    /// Phương pháp này giả định rằng có đủ không gian trong nút cho cặp mới phù hợp.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Chèn một cặp khóa-giá trị mới và một edge sẽ đi vào bên phải của cặp mới đó giữa edge này và cặp khóa-giá trị ở bên phải edge này.
    /// Phương pháp này sẽ chia nút nếu không có đủ chỗ.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Chèn một cặp khóa-giá trị mới giữa các cặp khóa-giá trị ở bên phải và bên trái của edge này.
    /// Phương thức này sẽ chia tách nút nếu không có đủ chỗ và cố gắng chèn phần đã tách vào nút cha một cách đệ quy, cho đến khi đạt đến phần gốc.
    ///
    ///
    /// Nếu kết quả trả về là `Fit`, thì nút của tay cầm của nó có thể là nút của edge này hoặc là tổ tiên.
    /// Nếu kết quả trả về là `Split`, trường `left` sẽ là nút gốc.
    /// Con trỏ trả về trỏ đến giá trị đã chèn.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Tìm nút được trỏ tới bởi edge này.
    ///
    /// Tên phương thức giả sử bạn hình ảnh cây với nút gốc ở trên cùng.
    ///
    /// `edge.descend().ascend().unwrap()` và `node.ascend().unwrap().descend()` nên cả hai, khi thành công, không làm gì cả.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Chúng ta cần sử dụng con trỏ thô đến các nút vì nếu BorrowType là marker::ValMut, có thể có các tham chiếu có thể thay đổi nổi bật đến các giá trị mà chúng ta không được làm mất hiệu lực.
        // Không phải lo lắng khi truy cập trường chiều cao vì giá trị đó đã được sao chép.
        // Hãy lưu ý rằng, một khi con trỏ nút bị bỏ tham chiếu, chúng tôi truy cập vào mảng cạnh với một tham chiếu (Rust sự cố #73987) và làm mất hiệu lực bất kỳ tham chiếu nào khác đến hoặc bên trong mảng, nếu bất kỳ tham chiếu nào xung quanh.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Chúng ta không thể gọi các phương thức khóa và giá trị riêng biệt, bởi vì việc gọi phương thức thứ hai sẽ làm mất hiệu lực tham chiếu được trả về bởi phương thức thứ nhất.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Thay thế khóa và giá trị mà tay cầm KV đề cập đến.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Giúp triển khai `split` cho một `NodeType` cụ thể, bằng cách quan tâm đến dữ liệu lá.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Chia nút bên dưới thành ba phần:
    ///
    /// - Nút bị cắt bớt để chỉ chứa các cặp khóa-giá trị ở bên trái của nút điều khiển này.
    /// - Khóa và giá trị được trỏ đến bởi chốt này được trích xuất.
    /// - Tất cả các cặp khóa-giá trị ở bên phải của chốt này được đưa vào một nút mới được cấp phát.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Xóa cặp khóa-giá trị được trỏ đến bởi chốt này và trả về nó, cùng với edge mà cặp khóa-giá trị đã thu gọn vào.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Chia nút bên dưới thành ba phần:
    ///
    /// - Nút bị cắt bớt để chỉ chứa các cạnh và cặp khóa-giá trị ở bên trái của chốt điều khiển này.
    /// - Khóa và giá trị được trỏ đến bởi chốt này được trích xuất.
    /// - Tất cả các cạnh và cặp khóa-giá trị ở bên phải của chốt này được đưa vào một nút mới được cấp phát.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Đại diện cho một phiên để đánh giá và thực hiện thao tác cân bằng xung quanh cặp khóa-giá trị nội bộ.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Chọn bối cảnh cân bằng liên quan đến nút khi còn nhỏ, do đó giữa KV ngay lập tức sang trái hoặc sang phải trong nút cha.
    /// Trả về `Err` nếu không có cha mẹ.
    /// Panics nếu cha mẹ trống.
    ///
    /// Ưu tiên phía bên trái, là tối ưu nếu nút đã cho bằng cách nào đó bị thiếu, có nghĩa là ở đây chỉ có nghĩa là nó có ít phần tử hơn người anh em bên trái và hơn người anh em bên phải của nó, nếu chúng tồn tại.
    /// Trong trường hợp đó, việc hợp nhất với anh em bên trái sẽ nhanh hơn, vì chúng ta chỉ cần di chuyển N phần tử của nút, thay vì chuyển chúng sang bên phải và di chuyển nhiều hơn N phần tử ở phía trước.
    /// Việc ăn cắp từ nút anh em bên trái cũng thường nhanh hơn, vì chúng ta chỉ cần dịch chuyển N phần tử của nút sang bên phải, thay vì dịch chuyển ít nhất N phần tử của nút anh em sang bên trái.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Trả về liệu có thể hợp nhất hay không, tức là có đủ chỗ trong một nút để kết hợp KV trung tâm với cả hai nút con liền kề hay không.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Thực hiện hợp nhất và cho phép đóng cửa quyết định những gì sẽ trả lại.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // AN TOÀN: chiều cao của các nút được hợp nhất thấp hơn chiều cao
                // của nút của edge này, do đó trên 0, vì vậy chúng là bên trong.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Hợp nhất cặp khóa-giá trị của cha và cả hai nút con liền kề vào nút con bên trái và trả về nút cha đã thu nhỏ.
    ///
    ///
    /// Panics trừ khi chúng tôi `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Hợp nhất cặp khóa-giá trị của cha và cả hai nút con liền kề vào nút con bên trái và trả về nút con đó.
    ///
    ///
    /// Panics trừ khi chúng tôi `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Hợp nhất cặp khóa-giá trị của cha và cả hai nút con liền kề vào nút con bên trái và trả về xử lý edge trong nút con đó nơi kết thúc của nút con edge được theo dõi,
    ///
    ///
    /// Panics trừ khi chúng tôi `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Xóa một cặp khóa-giá trị khỏi phần con bên trái và đặt nó vào kho lưu trữ khóa-giá trị của phần cha, đồng thời đẩy cặp khóa-giá trị cha cũ vào phần con bên phải.
    ///
    /// Trả về một chốt cho edge ở con bên phải tương ứng với nơi edge ban đầu được chỉ định bởi `track_right_edge_idx` đã kết thúc.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Loại bỏ một cặp khóa-giá trị khỏi phần con bên phải và đặt nó vào bộ lưu trữ khóa-giá trị của phần tử chính, đồng thời đẩy cặp khóa-giá trị gốc cũ sang phần bên trái.
    ///
    /// Trả về một chốt cho edge trong con bên trái được chỉ định bởi `track_left_edge_idx`, không di chuyển.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Điều này thực hiện ăn cắp tương tự như `steal_left` nhưng ăn cắp nhiều phần tử cùng một lúc.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Đảm bảo rằng chúng tôi có thể ăn cắp một cách an toàn.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Di chuyển dữ liệu lá.
            {
                // Dành chỗ cho những phần tử bị đánh cắp ở đúng đứa trẻ.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Di chuyển các phần tử từ con bên trái sang con bên phải.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Chuyển cặp bị đánh cắp nhiều nhất bên trái cho cặp cha mẹ.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Di chuyển cặp khóa-giá trị của cha mẹ sang con bên phải.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Dành chỗ cho các cạnh bị đánh cắp.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Ăn cắp các cạnh.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Bản sao đối xứng của `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Đảm bảo rằng chúng tôi có thể ăn cắp một cách an toàn.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Di chuyển dữ liệu lá.
            {
                // Chuyển cặp bị đánh cắp bên phải nhất cho phụ huynh.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Di chuyển cặp khóa-giá trị của cha mẹ sang con bên trái.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Di chuyển các phần tử từ phần tử bên phải sang phần tử bên trái.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Lấp đầy khoảng trống nơi các yếu tố bị đánh cắp từng có
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Ăn cắp các cạnh.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Lấp đầy khoảng trống nơi các cạnh bị đánh cắp trước đây.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Loại bỏ mọi thông tin tĩnh xác nhận rằng nút này là nút `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Loại bỏ mọi thông tin tĩnh xác nhận rằng nút này là một nút `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Kiểm tra xem nút bên dưới là nút `Internal` hay nút `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Di chuyển hậu tố sau `self` từ nút này sang nút khác.`right` phải trống.
    /// edge đầu tiên của `right` không đổi.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Kết quả của việc chèn, khi một nút cần mở rộng vượt quá khả năng của nó.
pub struct SplitResult<'a, K, V, NodeType> {
    // Đã thay đổi nút trong cây hiện có với các phần tử và cạnh thuộc bên trái của `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Một số khóa và giá trị tách ra, để được chèn vào nơi khác.
    pub kv: (K, V),
    // Có sở hữu, chưa được đính kèm, nút mới với các phần tử và cạnh thuộc quyền của `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Liệu các tham chiếu nút của kiểu mượn này có cho phép truyền đến các nút khác trong cây hay không.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Truyền tải không cần thiếte, nó xảy ra bằng cách sử dụng kết quả của `borrow_mut`.
        // Bằng cách tắt tính năng truyền tải và chỉ tạo các tham chiếu mới đến các gốc, chúng ta biết rằng mọi tham chiếu của kiểu `Owned` là đến một nút gốc.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Chèn một giá trị vào một phần của các phần tử đã khởi tạo, theo sau là một phần tử chưa được khởi tạo.
///
/// # Safety
/// Slice có nhiều phần tử `idx`.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Loại bỏ và trả về một giá trị từ một phần của tất cả các phần tử đã khởi tạo, để lại một phần tử chưa được khởi tạo ở cuối.
///
///
/// # Safety
/// Slice có nhiều phần tử `idx`.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Di chuyển các phần tử trong một lát cắt `distance` sang trái.
///
/// # Safety
/// Slice có ít nhất phần tử `distance`.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Di chuyển các phần tử trong một lát cắt `distance` sang phải.
///
/// # Safety
/// Slice có ít nhất phần tử `distance`.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Di chuyển tất cả các giá trị từ một phần của các phần tử đã khởi tạo sang một phần của các phần tử chưa được khởi tạo, để lại `src` là tất cả các phần tử chưa được khởi tạo.
///
/// Hoạt động giống như `dst.copy_from_slice(src)` nhưng không yêu cầu `T` phải là `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;