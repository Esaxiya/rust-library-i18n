use core::marker::PhantomData;
use core::ptr::NonNull;

/// Lập mô hình từ vay lại của một số tham chiếu duy nhất, khi bạn biết rằng từ vay lại và tất cả con cháu của nó (tức là tất cả các con trỏ và tham chiếu bắt nguồn từ nó) sẽ không được sử dụng nữa vào một thời điểm nào đó, sau đó bạn muốn sử dụng lại tham chiếu duy nhất ban đầu .
///
///
/// Trình kiểm tra khoản vay thường xử lý việc xếp chồng các khoản vay này cho bạn, nhưng một số luồng điều khiển thực hiện việc xếp chồng này quá phức tạp để trình biên dịch làm theo.
/// `DormantMutRef` cho phép bạn tự kiểm tra việc vay mượn, trong khi vẫn thể hiện bản chất xếp chồng lên nhau của nó và đóng gói mã con trỏ thô cần thiết để thực hiện việc này mà không có hành vi không xác định.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Nắm bắt một khoản vay duy nhất và ngay lập tức vay lại.
    /// Đối với trình biên dịch, thời gian tồn tại của tham chiếu mới giống với thời gian tồn tại của tham chiếu ban đầu, nhưng bạn promise để sử dụng nó trong một khoảng thời gian ngắn hơn.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // AN TOÀN: chúng tôi giữ khoản vay trong suốt 'a qua `_marker` và chúng tôi tiết lộ
        // chỉ tham chiếu này, vì vậy nó là duy nhất.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Hoàn nguyên về khoản vay duy nhất đã thu được ban đầu.
    ///
    /// # Safety
    ///
    /// Việc vay lại phải kết thúc, tức là, tham chiếu được trả về bởi `new` và tất cả các con trỏ và tham chiếu bắt nguồn từ nó, không được sử dụng nữa.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // AN TOÀN: các điều kiện an toàn của riêng chúng tôi ngụ ý rằng tài liệu tham khảo này lại là duy nhất.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;