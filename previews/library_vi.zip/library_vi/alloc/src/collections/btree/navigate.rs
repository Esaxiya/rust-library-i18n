use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Tạm thời lấy ra một giá trị tương đương khác, bất biến trong cùng một phạm vi.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Tìm các mép lá riêng biệt để phân định một phạm vi xác định trên cây.
    /// Trả về một cặp chốt điều khiển khác nhau vào cùng một cây hoặc một cặp tùy chọn trống.
    ///
    /// # Safety
    ///
    /// Trừ khi `BorrowType` là `Immut`, không sử dụng các chốt điều khiển trùng lặp để truy cập cùng một KV hai lần.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Tương đương với `(root1.first_leaf_edge(), root2.last_leaf_edge())` nhưng hiệu quả hơn.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Tìm các cặp mép lá phân định một phạm vi cụ thể trên cây.
    ///
    /// Kết quả chỉ có ý nghĩa nếu cây được sắp xếp theo khóa, giống như cây trong `BTreeMap`.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // AN TOÀN: kiểu vay của chúng tôi là bất biến.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Tìm các cặp mép lá phân định toàn bộ cây.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Tách một tham chiếu duy nhất thành một cặp cạnh lá phân định một phạm vi được chỉ định.
    /// Kết quả là các tham chiếu không duy nhất cho phép đột biến (some), phải được sử dụng cẩn thận.
    ///
    /// Kết quả chỉ có ý nghĩa nếu cây được sắp xếp theo khóa, giống như cây trong `BTreeMap`.
    ///
    ///
    /// # Safety
    /// Không sử dụng các chốt điều khiển trùng lặp để truy cập cùng một KV hai lần.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Tách một tham chiếu duy nhất thành một cặp mép lá phân định toàn bộ phạm vi của cây.
    /// Các kết quả là các tham chiếu không phải là duy nhất cho phép đột biến (chỉ trong số các giá trị), vì vậy phải được sử dụng cẩn thận.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Chúng tôi sao chép NodeRef gốc ở đây-chúng tôi sẽ không bao giờ truy cập cùng một KV hai lần và không bao giờ kết thúc với các tham chiếu giá trị chồng chéo.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Tách một tham chiếu duy nhất thành một cặp mép lá phân định toàn bộ phạm vi của cây.
    /// Các kết quả là các tham chiếu không duy nhất cho phép đột biến phá hủy hàng loạt, vì vậy phải được sử dụng hết sức cẩn thận.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Chúng tôi sao chép NodeRef gốc ở đây-chúng tôi sẽ không bao giờ truy cập nó theo cách chồng chéo các tham chiếu thu được từ gốc.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Cho một xử lý edge lá, trả về [`Result::Ok`] có một xử lý cho KV lân cận ở phía bên phải, nằm trong cùng một nút lá hoặc trong một nút tổ tiên.
    ///
    /// Nếu lá edge là lá cuối cùng trong cây, trả về [`Result::Err`] với nút gốc.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Đưa ra một ô điều khiển edge lá, trả về [`Result::Ok`] có một ô điều khiển cho KV lân cận ở phía bên trái, nằm trong cùng một nút lá hoặc trong một nút tổ tiên.
    ///
    /// Nếu lá edge là lá đầu tiên trong cây, trả về [`Result::Err`] với nút gốc.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Đưa ra một bộ xử lý edge bên trong, trả về [`Result::Ok`] có một bộ xử lý cho KV lân cận ở phía bên phải, nằm trong cùng một nút nội bộ hoặc trong một nút tổ tiên.
    ///
    /// Nếu edge bên trong là nút cuối cùng trong cây, trả về [`Result::Err`] với nút gốc.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Cho một tay cầm edge lá vào một cây sắp chết, trả về lá edge tiếp theo ở phía bên phải và cặp khóa-giá trị ở giữa, nằm trong cùng một nút lá, trong một nút tổ tiên hoặc không tồn tại.
    ///
    ///
    /// Phương pháp này cũng phân bổ bất kỳ node(s) nào mà nó đạt đến cuối.
    /// Điều này ngụ ý rằng nếu không còn cặp khóa-giá trị nào nữa tồn tại, toàn bộ phần còn lại của cây sẽ được phân bổ và không còn gì để trả lại.
    ///
    /// # Safety
    /// edge đã cho trước đó không được trả lại bởi đối tác `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Đưa một tay cầm edge lá vào một cây sắp chết, trả về lá edge tiếp theo ở phía bên trái và cặp khóa-giá trị ở giữa, nằm trong cùng một nút lá, trong một nút tổ tiên hoặc không tồn tại.
    ///
    ///
    /// Phương pháp này cũng phân bổ bất kỳ node(s) nào mà nó đạt đến cuối.
    /// Điều này ngụ ý rằng nếu không còn cặp khóa-giá trị nào nữa tồn tại, toàn bộ phần còn lại của cây sẽ được phân bổ và không còn gì để trả lại.
    ///
    /// # Safety
    /// edge đã cho trước đó không được trả lại bởi đối tác `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Phân bổ một đống nút từ lá lên đến gốc.
    /// Đây là cách duy nhất để phân bổ phần còn lại của cây sau khi `deallocating_next` và `deallocating_next_back` đã gặm nhấm ở cả hai phía của cây và đã đạt được cùng một edge.
    /// Vì nó chỉ được gọi khi tất cả các khóa và giá trị đã được trả về, nên không có thao tác dọn dẹp nào được thực hiện trên bất kỳ khóa hoặc giá trị nào.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Di chuyển lá edge xử lý đến lá tiếp theo edge và trả về các tham chiếu đến khóa và giá trị ở giữa.
    ///
    ///
    /// # Safety
    /// Phải có một KV khác theo hướng di chuyển.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Di chuyển lá edge xử lý đến lá edge trước đó và trả về các tham chiếu đến khóa và giá trị ở giữa.
    ///
    ///
    /// # Safety
    /// Phải có một KV khác theo hướng di chuyển.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Di chuyển lá edge xử lý đến lá tiếp theo edge và trả về các tham chiếu đến khóa và giá trị ở giữa.
    ///
    ///
    /// # Safety
    /// Phải có một KV khác theo hướng di chuyển.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Thực hiện điều này cuối cùng sẽ nhanh hơn, theo điểm chuẩn.
        kv.into_kv_valmut()
    }

    /// Di chuyển tay cầm edge của lá tới lá trước đó và trả về các tham chiếu đến khóa và giá trị ở giữa.
    ///
    ///
    /// # Safety
    /// Phải có một KV khác theo hướng di chuyển.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Thực hiện điều này cuối cùng sẽ nhanh hơn, theo điểm chuẩn.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Di chuyển lá edge xử lý sang lá tiếp theo edge và trả về khóa và giá trị ở giữa, định vị bất kỳ nút nào bị bỏ lại trong khi vẫn để edge tương ứng trong nút cha của nó.
    ///
    /// # Safety
    /// - Phải có một KV khác theo hướng di chuyển.
    /// - KV đó trước đây không được trả lại bởi đối tác `next_back_unchecked` trên bất kỳ bản sao nào của các tay cầm đang được sử dụng để đi ngang qua cây.
    ///
    /// Cách an toàn duy nhất để tiếp tục với tay cầm cập nhật là so sánh nó, thả nó xuống, gọi lại phương pháp này tùy theo điều kiện an toàn của nó hoặc gọi đối tác `next_back_unchecked` tùy theo điều kiện an toàn của nó.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Di chuyển lá edge xử lý đến lá edge trước đó và trả về khóa và giá trị ở giữa, định vị bất kỳ nút nào bị bỏ lại trong khi vẫn để edge tương ứng trong nút cha của nó lơ lửng.
    ///
    /// # Safety
    /// - Phải có một KV khác theo hướng di chuyển.
    /// - Lá edge đó trước đó không được đối tác `next_unchecked` trả lại trên bất kỳ bản sao nào của các chốt được sử dụng để đi ngang qua cây.
    ///
    /// Cách an toàn duy nhất để tiếp tục với tay cầm cập nhật là so sánh nó, thả nó xuống, gọi lại phương pháp này tùy theo điều kiện an toàn của nó hoặc gọi đối tác `next_unchecked` tùy theo điều kiện an toàn của nó.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Trả về lá edge ngoài cùng bên trái trong hoặc bên dưới một nút, nói cách khác, edge bạn cần đầu tiên khi điều hướng về phía trước (hoặc cuối cùng khi điều hướng lùi lại).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Trả về lá edge ngoài cùng bên phải trong hoặc bên dưới một nút, nói cách khác, edge bạn cần cuối cùng khi điều hướng về phía trước (hoặc đầu tiên khi điều hướng lùi lại).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Truy cập các nút lá và KV nội bộ theo thứ tự các khóa tăng dần và cũng truy cập tổng thể các nút nội bộ theo thứ tự độ sâu đầu tiên, nghĩa là các nút nội bộ đứng trước KV riêng lẻ và các nút con của chúng.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Tính số phần tử trong cây (con).
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Trả về lá edge gần nhất với KV để điều hướng phía trước.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Trả về lá edge gần nhất với KV để điều hướng lùi.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}