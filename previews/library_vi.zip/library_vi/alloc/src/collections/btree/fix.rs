use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Tích trữ một nút có thể chưa đầy đủ bằng cách hợp nhất hoặc ăn cắp từ một anh chị em.
    /// Nếu thành công nhưng với chi phí thu nhỏ nút cha, trả về nút cha đã thu nhỏ đó.
    /// Trả về `Err` nếu nút là gốc trống.
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Tích trữ một nút có thể thiếu và nếu điều đó làm cho nút cha của nó bị thu hẹp, hãy tích trữ một cách đệ quy nút cha.
    /// Trả về `true` nếu nó đã sửa cây, `false` nếu nó không thể vì nút gốc trở nên trống.
    ///
    /// Phương thức này không mong đợi tổ tiên đã bị thiếu khi nhập và panics nếu nó gặp tổ tiên trống.
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// Loại bỏ các mức trống trên đầu, nhưng giữ một lá trống nếu toàn bộ cây trống.
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// Tích trữ hoặc hợp nhất bất kỳ nút nào chưa đầy đủ trên đường viền bên phải của cây.
    /// Các nút khác, những nút không phải gốc hoặc không phải là edge ngoài cùng bên phải, phải có ít nhất MIN_LEN phần tử.
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// Bản sao đối xứng của `fix_right_border`.
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// Tích trữ bất kỳ nút nào chưa đầy đủ trên đường viền bên phải của cây.
    /// Các nút khác, những nút không phải gốc hoặc không phải là edge ngoài cùng bên phải, phải được chuẩn bị để có tối đa MIN_LEN phần tử bị đánh cắp.
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // Kiểm tra xem con ngoài cùng bên phải có bị đầy đủ không.
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // Chúng ta cần phải ăn cắp.
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // Đi xuống xa hơn.
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Tích trữ phần tử bên trái, giả sử phần tử bên phải không bị thiếu và cung cấp thêm một phần tử để cho phép lần lượt hợp nhất các phần tử con của nó mà không bị thiếu.
    ///
    /// Trả về con bên trái.
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` để tránh điều chỉnh lại nếu hợp nhất xảy ra ở cấp độ tiếp theo.
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// Tích trữ phần tử bên phải, giả sử phần tử bên trái không bị thiếu và cung cấp một phần tử bổ sung để cho phép lần lượt hợp nhất các phần tử con của nó mà không bị thiếu.
    ///
    /// Trả về bất cứ nơi nào con phù hợp đã kết thúc.
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` để tránh điều chỉnh lại nếu hợp nhất xảy ra ở cấp độ tiếp theo.
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}