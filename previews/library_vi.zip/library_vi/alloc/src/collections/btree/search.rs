use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// Một ràng buộc bao gồm để tìm kiếm, giống như `Bound::Included(T)`.
    Included(T),
    /// Một ràng buộc độc quyền để tìm kiếm, giống như `Bound::Excluded(T)`.
    Excluded(T),
    /// Một ràng buộc bao gồm vô điều kiện, giống như `Bound::Unbounded`.
    AllIncluded,
    /// Một ràng buộc độc quyền vô điều kiện.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Tìm kiếm một khóa đã cho trong cây (con) do nút đứng đầu, một cách đệ quy.
    /// Trả về `Found` với tay cầm của KV phù hợp, nếu có.
    /// Nếu không, trả về `GoDown` với tay cầm của lá edge nơi khóa thuộc về.
    ///
    /// Kết quả chỉ có ý nghĩa nếu cây được sắp xếp theo khóa, giống như cây trong `BTreeMap`.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// Giảm dần đến nút gần nhất nơi edge khớp với giới hạn dưới của dải khác với edge khớp với giới hạn trên, tức là, nút gần nhất có ít nhất một khóa chứa trong dải.
    ///
    ///
    /// Nếu được tìm thấy, trả về một `Ok` với nút đó, cặp chỉ số edge trong đó phân định phạm vi và cặp giới hạn tương ứng để tiếp tục tìm kiếm trong các nút con, trong trường hợp nút là nội bộ.
    ///
    /// Nếu không tìm thấy, trả về `Err` với lá edge khớp với toàn bộ phạm vi.
    ///
    /// Kết quả chỉ có ý nghĩa nếu cây được sắp xếp theo khóa.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Nên tránh nội tuyến các biến này.
        // Chúng tôi giả định các giới hạn được báo cáo bởi `range` vẫn giữ nguyên, nhưng việc triển khai đối thủ có thể thay đổi giữa các lệnh gọi (#81138).
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// Tìm một edge trong nút phân định giới hạn dưới của một dải ô.
    /// Đồng thời trả về giới hạn dưới được sử dụng để tiếp tục tìm kiếm trong nút con phù hợp, nếu `self` là một nút bên trong.
    ///
    ///
    /// Kết quả chỉ có ý nghĩa nếu cây được sắp xếp theo khóa.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// Bản sao của `find_lower_bound_edge` cho giới hạn trên.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Tìm kiếm một khóa nhất định trong nút mà không cần đệ quy.
    /// Trả về `Found` với tay cầm của KV phù hợp, nếu có.
    /// Nếu không, trả về `GoDown` với tay cầm của edge nơi khóa có thể được tìm thấy (nếu nút bên trong) hoặc nơi khóa có thể được chèn.
    ///
    ///
    /// Kết quả chỉ có ý nghĩa nếu cây được sắp xếp theo khóa, giống như cây trong `BTreeMap`.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// Trả về chỉ số KV trong nút mà khóa (hoặc một khóa tương đương) tồn tại hoặc chỉ số edge nơi khóa thuộc về.
    ///
    ///
    /// Kết quả chỉ có ý nghĩa nếu cây được sắp xếp theo khóa, giống như cây trong `BTreeMap`.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// Tìm chỉ số edge trong nút phân định giới hạn dưới của một dải ô.
    /// Đồng thời trả về giới hạn dưới được sử dụng để tiếp tục tìm kiếm trong nút con phù hợp, nếu `self` là một nút bên trong.
    ///
    ///
    /// Kết quả chỉ có ý nghĩa nếu cây được sắp xếp theo khóa.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// Bản sao của `find_lower_bound_index` cho giới hạn trên.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}