/// Tạo một [`Vec`] chứa các đối số.
///
/// `vec!` cho phép `Vec`s được định nghĩa với cú pháp giống như biểu thức mảng.
/// Có hai dạng macro này:
///
/// - Tạo một [`Vec`] chứa một danh sách các phần tử đã cho:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Tạo [`Vec`] từ một phần tử và kích thước nhất định:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Lưu ý rằng không giống như các biểu thức mảng, cú pháp này hỗ trợ tất cả các phần tử triển khai [`Clone`] và số phần tử không nhất thiết phải là một hằng số.
///
/// Điều này sẽ sử dụng `clone` để sao chép một biểu thức, vì vậy người ta nên cẩn thận khi sử dụng điều này với các loại có triển khai `Clone` không chuẩn.
/// Ví dụ, `vec![Rc::new(1);5] `sẽ tạo một vector gồm năm tham chiếu đến cùng một giá trị số nguyên được đóng hộp, không phải năm tham chiếu trỏ đến các số nguyên được đóng hộp độc lập.
///
///
/// Ngoài ra, lưu ý rằng `vec![expr; 0]` được cho phép và tạo ra vector trống.
/// Tuy nhiên, điều này sẽ vẫn đánh giá `expr` và ngay lập tức giảm giá trị kết quả, vì vậy hãy lưu ý đến các tác dụng phụ.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): với cfg(test), phương thức `[T]::into_vec` vốn có, được yêu cầu cho định nghĩa macro này, không khả dụng.
// Thay vào đó, hãy sử dụng chức năng `slice::into_vec` chỉ khả dụng với cfg(test) NB, hãy xem mô-đun slice::hack trong slice.rs để biết thêm thông tin
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Tạo `String` bằng cách sử dụng nội suy các biểu thức thời gian chạy.
///
/// Đối số đầu tiên mà `format!` nhận được là một chuỗi định dạng.Đây phải là một chuỗi ký tự.Sức mạnh của chuỗi định dạng nằm trong phần chứa `{}`.
///
/// Các tham số bổ sung được truyền cho `format!` thay thế các ký tự `{}` trong chuỗi định dạng theo thứ tự đã cho trừ khi các tham số có tên hoặc vị trí được sử dụng;xem [`std::fmt`] để biết thêm thông tin.
///
///
/// Một cách sử dụng phổ biến cho `format!` là nối và nội suy các chuỗi.
/// Quy ước tương tự được sử dụng với macro [`print!`] và [`write!`], tùy thuộc vào đích dự kiến của chuỗi.
///
/// Để chuyển đổi một giá trị thành một chuỗi, hãy sử dụng phương thức [`to_string`].Điều này sẽ sử dụng định dạng [`Display`] trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics nếu triển khai định dạng trait trả về lỗi.
/// Điều này cho thấy việc triển khai không chính xác vì `fmt::Write for String` không bao giờ tự trả về lỗi.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Buộc nút AST vào một biểu thức để cải thiện chẩn đoán ở vị trí mẫu.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}