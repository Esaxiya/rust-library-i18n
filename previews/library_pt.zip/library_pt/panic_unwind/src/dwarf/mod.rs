//! Utilitários para analisar fluxos de dados codificados por DWARF.
//! Consulte o padrão <http://www.dwarfstd.org>, DWARF-4, Seção 7, "Data Representation"
//!

// Este módulo é usado apenas por x86_64-pc-windows-gnu por enquanto, mas estamos compilando-o em todos os lugares para evitar regressões.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // Os fluxos DWARF são compactados, portanto, por exemplo, um u32 não seria necessariamente alinhado em um limite de 4 bytes.
    // Isso pode causar problemas em plataformas com requisitos de alinhamento estritos.
    // Ao agrupar os dados em uma estrutura "packed", estamos informando o back-end para gerar o código "misalignment-safe".
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // As codificações ULEB128 e SLEB128 são definidas na Seção 7.6, "Variable Length Data".
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}