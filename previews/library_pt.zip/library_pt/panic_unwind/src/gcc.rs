//! Implementação do panics apoiado pelo libgcc/libunwind (de alguma forma).
//!
//! Para obter informações sobre tratamento de exceções e desenrolamento de pilha, consulte "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) e os documentos vinculados a ele.
//! Estas também são boas leituras:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## Um breve resumo
//!
//! O tratamento de exceções ocorre em duas fases: uma fase de pesquisa e uma fase de limpeza.
//!
//! Em ambas as fases, o desenrolador percorre os quadros de pilha de cima para baixo usando informações das seções de desenrolamento de quadros de pilha dos módulos do processo atual ("module" aqui se refere a um módulo de SO, ou seja, um executável ou uma biblioteca dinâmica).
//!
//!
//! Para cada frame de pilha, ele invoca o "personality routine" associado, cujo endereço também é armazenado na seção de informações de desenrolamento.
//!
//! Na fase de pesquisa, o trabalho de uma rotina de personalidade é examinar o objeto de exceção que está sendo lançado e decidir se ele deve ser capturado naquele quadro de pilha.Assim que o quadro do manipulador for identificado, a fase de limpeza começa.
//!
//! Na fase de limpeza, o desenrolador invoca a rotina de cada personalidade novamente.
//! Desta vez, ele decide qual (se houver) código de limpeza precisa ser executado para o quadro de pilha atual.Nesse caso, o controle é transferido para um branch especial no corpo da função, o "landing pad", que invoca destruidores, libera memória, etc.
//! No final da plataforma de pouso, o controle é transferido de volta para o desenrolador e o desenrolamento é reiniciado.
//!
//! Uma vez que a pilha foi desenrolada até o nível do quadro do manipulador, o desenrolamento para e a última rotina de personalidade transfere o controle para o bloco de captura.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Identificador de classe de exceção de Rust.
// Isso é usado por rotinas de personalidade para determinar se a exceção foi lançada por seu próprio tempo de execução.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-fornecedor, idioma
    0x4d4f5a_00_52555354
}

// Os ids de registro foram retirados do LLVM's TargetLowering::getExceptionPointerRegister() e TargetLowering::getExceptionSelectorRegister() para cada arquitetura e, em seguida, mapeados para números de registro DWARF através de tabelas de definição de registro (normalmente<arch>RegisterInfo.td, procure "DwarfRegNum").
//
// Consulte também http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// O código a seguir é baseado nas rotinas de personalidade C e C++ de GCC.Para referência, consulte:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM Rotina de personalidade EHABI.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS usa a rotina padrão, uma vez que usa o desenrolamento SjLj.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // Backtraces no ARM chamará a rotina de personalidade com estado==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // Nesses casos, queremos continuar desenrolando a pilha, caso contrário, todos os nossos backtraces terminariam em __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // O desenrolador DWARF assume que_Unwind_Context contém coisas como a função e os ponteiros LSDA, no entanto, ARM EHABI os coloca no objeto de exceção.
            // Para preservar assinaturas de funções como _Unwind_GetLanguageSpecificData(), que usam apenas o ponteiro de contexto, as rotinas de personalidade GCC escondem um ponteiro para exception_object no contexto, usando o local reservado para o "scratch register" (r12) da ARM.
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... Uma abordagem mais baseada em princípios seria fornecer a definição completa do_Unwind_Context do ARM em nossas ligações libunwind e buscar os dados necessários diretamente, ignorando as funções de compatibilidade DWARF.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // O EHABI requer que a rotina de personalidade atualize o valor SP no cache de barreira do objeto de exceção.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // No ARM EHABI, a rotina de personalidade é responsável por realmente desenrolar um único quadro de pilha antes de retornar (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // definido em libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // Rotina de personalidade padrão, que é usada diretamente na maioria dos alvos e indiretamente no Windows x86_64 via SEH.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // Em destinos x86_64 MinGW, o mecanismo de desenrolamento é SEH, no entanto, os dados do manipulador de desenrolamento (também conhecido como LSDA) usam codificação compatível com GCC.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // A rotina de personalidade para a maioria de nossos alvos.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // O endereço de retorno aponta 1 byte após a instrução de chamada, que pode estar no próximo intervalo de IP na tabela de intervalo LSDA.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Registro de informações de desenrolamento do quadro
//
// A imagem de cada módulo contém uma seção de informações de desenrolamento de quadros (geralmente ".eh_frame").Quando um módulo é loaded/unloaded no processo, o desenrolador deve ser informado sobre a localização desta seção na memória.Os métodos para conseguir isso variam de acordo com a plataforma.
// Em alguns (por exemplo, Linux), o desenrolador pode descobrir seções de informações de desenrolamento por conta própria (enumerando dinamicamente os módulos carregados atualmente por meio do dl_iterate_phdr() API and finding their ".eh_frame" sections); Outros, como o Windows, exigem que os módulos registrem ativamente suas seções de informações de desenrolamento por meio da API do desenrolador.
//
//
// Este módulo define dois símbolos que são referenciados e chamados a partir do rsbegin.rs para registrar nossas informações com o tempo de execução GCC.
// A implementação do desenrolamento da pilha é (por enquanto) adiada para libgcc_eh, no entanto Rust crates usa esses pontos de entrada específicos de Rust para evitar conflitos potenciais com qualquer tempo de execução GCC.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}