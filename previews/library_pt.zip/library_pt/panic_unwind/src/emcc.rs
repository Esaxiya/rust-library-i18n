//! Desenrolando para o alvo *emscripten*.
//!
//! Enquanto a implementação usual de desenrolamento do Rust para plataformas Unix chama as APIs libunwind diretamente, no Emscripten, em vez disso, chamamos as APIs de desenrolamento do C++ .
//! Este é apenas um expediente, pois o tempo de execução do Emscripten sempre implementa essas APIs e não implementa o libunwind.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// Isso corresponde ao layout do std::type_info em C++
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // O byte `\x01` principal aqui é na verdade um sinal mágico para o LLVM para *não* aplicar qualquer outra alteração como prefixar com um caractere `_`.
    //
    //
    // Este símbolo é a vtable usada pelo `std::type_info` do C++ .
    // Objetos do tipo `std::type_info`, descritores de tipo, possuem um ponteiro para esta tabela.
    // Os descritores de tipo são referenciados pelas estruturas C++ EH definidas acima e que construímos abaixo.
    //
    // Observe que o tamanho real é maior que 3 usize, mas só precisamos de nossa vtable para apontar para o terceiro elemento.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info para uma aula rust_panic
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // Normalmente usaríamos o .as_ptr().add(2), mas isso não funciona em um contexto const.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // Isso intencionalmente não usa o esquema normal de mutilação de nome porque não queremos que C++ seja capaz de produzir ou capturar Rust panics.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // Isso é necessário porque o código C++ pode capturar nossa execução com o std::exception_ptr e relançá-la várias vezes, possivelmente até mesmo em outro thread.
    //
    //
    caught: AtomicBool,

    // Isso precisa ser uma opção porque o tempo de vida do objeto segue a semântica C++ : quando catch_unwind move a caixa para fora da exceção, ele ainda deve deixar o objeto de exceção em um estado válido porque seu destruidor ainda será chamado por __cxa_end_catch.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try na verdade, nos dá um ponteiro para essa estrutura.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // Como o cleanup() não tem permissão para panic, nós apenas abortamos.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}