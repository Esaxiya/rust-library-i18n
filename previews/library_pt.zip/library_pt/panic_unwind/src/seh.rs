//! Windows SEH
//!
//! No Windows (atualmente apenas no MSVC), o mecanismo padrão de tratamento de exceções é o Structured Exception Handling (SEH).
//! Isso é bem diferente do tratamento de exceção baseado em Dwarf (por exemplo, o que outras plataformas unix usam) em termos de componentes internos do compilador, portanto, o LLVM deve ter um bom suporte extra para SEH.
//!
//! Em suma, o que acontece aqui é:
//!
//! 1. A função `panic` chama a função Windows padrão `_CxxThrowException` para lançar uma exceção semelhante ao C++ , disparando o processo de desenrolamento.
//! 2.
//! Todos os campos de aterrissagem gerados pelo compilador usam a função de personalidade `__CxxFrameHandler3`, uma função no CRT, e o código de desenrolamento no Windows usará essa função de personalidade para executar todo o código de limpeza na pilha.
//!
//! 3. Todas as chamadas geradas pelo compilador para o `invoke` têm um campo de aterrissagem definido como uma instrução LLVM `cleanuppad`, que indica o início da rotina de limpeza.
//! A personalidade (na etapa 2, definida no CRT) é responsável por executar as rotinas de limpeza.
//! 4. Eventualmente, o código "catch" no intrínseco `try` (gerado pelo compilador) é executado e indica que o controle deve voltar para Rust.
//! Isso é feito por meio de um `catchswitch` mais uma instrução `catchpad` em termos de LLVM IR, finalmente retornando o controle normal para o programa com uma instrução `catchret`.
//!
//! Algumas diferenças específicas do tratamento de exceção baseado em gcc são:
//!
//! * Rust não tem função de personalidade personalizada, em vez disso é *sempre*`__CxxFrameHandler3`.Além disso, nenhuma filtragem extra é realizada, portanto, acabamos capturando quaisquer exceções C++ que pareçam do tipo que estamos lançando.
//! Observe que lançar uma exceção em Rust é um comportamento indefinido de qualquer maneira, então isso deve ser bom.
//! * Temos alguns dados para transmitir através da fronteira de desenrolamento, especificamente um `Box<dyn Any + Send>`.Como com as exceções Dwarf, esses dois ponteiros são armazenados como uma carga útil na própria exceção.
//! No MSVC, entretanto, não há necessidade de uma alocação de heap extra porque a pilha de chamadas é preservada enquanto as funções de filtro estão sendo executadas.
//! Isso significa que os ponteiros são passados diretamente para o `_CxxThrowException`, que são recuperados na função de filtro para serem gravados no stack frame do `try` intrínseco.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Isso precisa ser uma opção porque capturamos a exceção por referência e seu destruidor é executado pelo tempo de execução C++ .
    // Quando retiramos o Box da exceção, precisamos deixar a exceção em um estado válido para que seu destruidor seja executado sem derrubar o Box duas vezes.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Primeiro, um monte de definições de tipo.Existem algumas peculiaridades específicas da plataforma aqui, e muitas que são copiadas descaradamente do LLVM.O objetivo de tudo isso é implementar a função `panic` abaixo por meio de uma chamada para `_CxxThrowException`.
//
// Esta função leva dois argumentos.O primeiro é um ponteiro para os dados que estamos transmitindo, que neste caso é nosso objeto trait.Muito fácil de encontrar!O próximo, entretanto, é mais complicado.
// Este é um ponteiro para uma estrutura `_ThrowInfo` e, geralmente, destina-se apenas a descrever a exceção que está sendo lançada.
//
// Atualmente, a definição deste tipo [1] é um pouco complicada, e a principal estranheza (e diferença do artigo online) é que em 32 bits os ponteiros são ponteiros, mas em 64 bits os ponteiros são expressos como deslocamentos de 32 bits do Símbolo `__ImageBase`.
//
// As macros `ptr_t` e `ptr!` nos módulos abaixo são usadas para expressar isso.
//
// O labirinto de definições de tipo também segue de perto o que o LLVM emite para este tipo de operação.Por exemplo, se você compilar este código C++ no MSVC e emitir o IR LLVM:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      void foo() { rust_panic a = {0, 1};
//          lançar um;}
//
// Isso é essencialmente o que estamos tentando emular.A maioria dos valores constantes abaixo foram apenas copiados do LLVM,
//
// Em qualquer caso, essas estruturas são todas construídas de maneira semelhante, e é um pouco prolixo para nós.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Observe que intencionalmente ignoramos as regras de mutilação de nomes aqui: não queremos que C++ seja capaz de capturar Rust panics simplesmente declarando um `struct rust_panic`.
//
//
// Ao modificar, certifique-se de que a string do nome do tipo corresponda exatamente àquela usada no `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // O byte `\x01` principal aqui é na verdade um sinal mágico para o LLVM para *não* aplicar qualquer outra alteração como prefixar com um caractere `_`.
    //
    //
    // Este símbolo é a vtable usada pelo `std::type_info` do C++ .
    // Objetos do tipo `std::type_info`, descritores de tipo, possuem um ponteiro para esta tabela.
    // Os descritores de tipo são referenciados pelas estruturas C++ EH definidas acima e que construímos abaixo.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Este descritor de tipo é usado apenas ao lançar uma exceção.
// A parte catch é tratada pelo intrínseco try, que gera seu próprio TypeDescriptor.
//
// Isso é bom, pois o tempo de execução MSVC usa comparação de string no nome do tipo para corresponder a TypeDescriptors em vez de igualdade de ponteiro.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destruidor usado se o código C++ decidir capturar a exceção e descartá-la sem propagá-la.
// A parte catch do try intrínseco definirá a primeira palavra do objeto de exceção como 0 para que seja ignorada pelo destruidor.
//
// Observe que o x86 Windows usa a convenção de chamada "thiscall" para funções de membro C++ em vez da convenção de chamada "C" padrão.
//
// A função exception_copy é um pouco especial aqui: ela é chamada pelo tempo de execução MSVC em um bloco try/catch e o panic que geramos aqui será usado como resultado da cópia de exceção.
//
// Isso é usado pelo tempo de execução C++ para suportar a captura de exceções com o std::exception_ptr, que não podemos suportar porque o Box<dyn Any>não é clonável.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException é executado inteiramente neste frame de pilha, portanto, não há necessidade de transferir `data` para o heap.
    // Apenas passamos um ponteiro de pilha para esta função.
    //
    // O ManualmenteDrop é necessário aqui, pois não queremos que a Exceção seja descartada ao desenrolar.
    // Em vez disso, ele será eliminado por exception_cleanup, que é invocado pelo tempo de execução C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Isso ... pode parecer surpreendente, e com razão.No MSVC de 32 bits, os ponteiros entre essas estruturas são apenas isso, ponteiros.
    // No MSVC de 64 bits, no entanto, os ponteiros entre as estruturas são expressos como deslocamentos de 32 bits do `__ImageBase`.
    //
    // Consequentemente, no MSVC de 32 bits podemos declarar todos esses ponteiros nos `estáticos` acima.
    // No MSVC de 64 bits, teríamos que expressar a subtração de ponteiros em estática, o que Rust não permite atualmente, portanto, não podemos realmente fazer isso.
    //
    // A próxima melhor coisa, então, é preencher essas estruturas em tempo de execução (entrar em pânico já é o "slow path" de qualquer maneira).
    // Portanto, aqui reinterpretamos todos esses campos de ponteiro como inteiros de 32 bits e, em seguida, armazenamos o valor relevante nele (atomicamente, já que panics simultâneo pode estar acontecendo).
    //
    // Tecnicamente, o tempo de execução provavelmente fará uma leitura não atômica desses campos, mas, em teoria, eles nunca lêem o valor *errado*, então não deve ser tão ruim ...
    //
    // Em qualquer caso, basicamente precisamos fazer algo assim até que possamos expressar mais operações em estática (e talvez nunca seja possível).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Uma carga útil NULL aqui significa que obtivemos aqui do catch (...) de __rust_try.
    // Isso acontece quando uma exceção externa não Rust é capturada.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Isso é exigido pelo compilador para existir (por exemplo, é um item de idioma), mas nunca é realmente chamado pelo compilador porque __C_specific_handler ou_except_handler3 é a função de personalidade que sempre é usada.
//
// Portanto, este é apenas um esboço de abortamento.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}