//! Desenrolando panics para Miri.
use alloc::boxed::Box;
use core::any::Any;

// O tipo de carga útil que o motor Miri propaga por meio do desenrolamento para nós.
// Deve ter o tamanho de um ponteiro.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Função externa fornecida pela Miri para começar a desenrolar.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // A carga útil que passaremos para o `miri_start_panic` será exatamente o argumento que obteremos no `cleanup` abaixo.
    // Então, apenas encaixotamos uma vez, para obter algo do tamanho de um ponteiro.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Recupere o `Box` subjacente.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}