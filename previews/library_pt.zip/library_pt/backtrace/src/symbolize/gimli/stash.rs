// usado apenas no Linux agora, então permita código morto em outro lugar
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Um alocador de arena simples para buffers de bytes.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Aloca um buffer do tamanho especificado e retorna uma referência mutável a ele.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SEGURANÇA: esta é a única função que sempre constrói um mutável
        // referência ao `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // SEGURANÇA: nunca removemos elementos do `self.buffers`, portanto, uma referência
        // para os dados dentro de qualquer buffer viverá enquanto o `self` viver.
        &mut buffers[i]
    }
}