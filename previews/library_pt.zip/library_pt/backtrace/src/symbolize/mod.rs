use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Resolve um endereço para um símbolo, passando o símbolo para o fechamento especificado.
///
/// Esta função irá procurar o endereço fornecido em áreas como a tabela de símbolos local, tabela de símbolos dinâmicos ou informações de depuração DWARF (dependendo da implementação ativada) para encontrar os símbolos a serem produzidos.
///
///
/// O encerramento não pode ser chamado se a resolução não puder ser executada, e também pode ser chamado mais de uma vez no caso de funções embutidas.
///
/// Os símbolos gerados representam a execução no `addr` especificado, retornando pares file/line para esse endereço (se disponível).
///
/// Observe que, se você tiver um `Frame`, é recomendável usar a função `resolve_frame` em vez desta.
///
/// # Recursos necessários
///
/// Esta função requer que o recurso `std` do `backtrace` crate seja habilitado, e o recurso `std` está habilitado por padrão.
///
/// # Panics
///
/// Esta função se esforça para nunca panic, mas se o `cb` forneceu panics, então algumas plataformas forçarão um panic duplo a abortar o processo.
/// Algumas plataformas usam uma biblioteca C que usa internamente retornos de chamada que não podem ser desenrolados, portanto, entrar em pânico com o `cb` pode acionar o aborto do processo.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // olhe apenas para a moldura superior
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Resolve um quadro previamente capturado para um símbolo, passando o símbolo para o fechamento especificado.
///
/// Esta função desempenha a mesma função que o `resolve`, exceto que leva um `Frame` como um argumento em vez de um endereço.
/// Isso pode permitir algumas implementações de plataforma de backtracing para fornecer informações de símbolo mais precisas ou informações sobre quadros em linha, por exemplo.
///
/// É recomendado usar isso se você puder.
///
/// # Recursos necessários
///
/// Esta função requer que o recurso `std` do `backtrace` crate seja habilitado, e o recurso `std` está habilitado por padrão.
///
/// # Panics
///
/// Esta função se esforça para nunca panic, mas se o `cb` forneceu panics, então algumas plataformas forçarão um panic duplo a abortar o processo.
/// Algumas plataformas usam uma biblioteca C que usa internamente retornos de chamada que não podem ser desenrolados, portanto, entrar em pânico com o `cb` pode acionar o aborto do processo.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // olhe apenas para a moldura superior
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Os valores IP dos quadros de pilha são normalmente (always?) a instrução *após* a chamada que é o rastreamento de pilha real.
// Simbolizar isso faz com que o número filename/line esteja um à frente e talvez no vazio se estiver perto do final da função.
//
// Isso parece ser basicamente sempre o caso em todas as plataformas, portanto, sempre subtraímos um de um ip resolvido para resolvê-lo para a instrução de chamada anterior, em vez de para a instrução retornada.
//
//
// Idealmente, não faríamos isso.
// Idealmente, exigiríamos que os chamadores das APIs do `resolve` aqui fizessem o -1 manualmente e informassem que desejam informações de localização para a instrução *anterior*, não a atual.
// Idealmente, também exporíamos no `Frame` se realmente somos o endereço da próxima instrução ou da corrente.
//
// Por enquanto, esta é uma preocupação de nicho muito bonita, então internamente sempre subtraímos um.
// Os consumidores devem continuar trabalhando e obtendo resultados muito bons, então devemos ser bons o suficiente.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Igual ao `resolve`, apenas inseguro, pois não está sincronizado.
///
/// Esta função não tem garantias de sincronização, mas está disponível quando o recurso `std` deste crate não está compilado.
/// Consulte a função `resolve` para obter mais documentação e exemplos.
///
/// # Panics
///
/// Consulte as informações sobre o `resolve` para advertências sobre o pânico do `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Igual ao `resolve_frame`, apenas inseguro, pois não está sincronizado.
///
/// Esta função não tem garantias de sincronização, mas está disponível quando o recurso `std` deste crate não está compilado.
/// Consulte a função `resolve_frame` para obter mais documentação e exemplos.
///
/// # Panics
///
/// Consulte as informações sobre o `resolve_frame` para advertências sobre o pânico do `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// Um trait representando a resolução de um símbolo em um arquivo.
///
/// Este trait é gerado como um objeto trait para o fechamento dado à função `backtrace::resolve`, e é virtualmente despachado porque não se sabe qual implementação está por trás dele.
///
///
/// Um símbolo pode fornecer informações contextuais sobre uma função, por exemplo, o nome, nome do arquivo, número da linha, endereço preciso, etc.
/// Nem todas as informações estão sempre disponíveis em um símbolo, portanto, todos os métodos retornam um `Option`.
///
///
pub struct Symbol {
    // TODO: este limite de vida deve ser persistido eventualmente para `Symbol`,
    // mas isso é atualmente uma mudança significativa.
    // Por enquanto, isso é seguro, pois o `Symbol` é entregue apenas por referência e não pode ser clonado.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Retorna o nome desta função.
    ///
    /// A estrutura retornada pode ser usada para consultar várias propriedades sobre o nome do símbolo:
    ///
    ///
    /// * A implementação do `Display` imprimirá o símbolo demangled.
    /// * O valor `str` bruto do símbolo pode ser acessado (se for utf-8 válido).
    /// * Os bytes brutos para o nome do símbolo podem ser acessados.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Retorna o endereço inicial desta função.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Retorna o nome do arquivo bruto como uma fatia.
    /// Isso é útil principalmente para ambientes `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Retorna o número da coluna para onde este símbolo está sendo executado no momento.
    ///
    /// Atualmente, apenas o gimli fornece um valor aqui e, mesmo assim, apenas se o `filename` retornar `Some` e, portanto, estará sujeito a advertências semelhantes.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Retorna o número da linha para onde este símbolo está sendo executado no momento.
    ///
    /// Esse valor de retorno é normalmente `Some` se `filename` retornar `Some` e, conseqüentemente, está sujeito a advertências semelhantes.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Retorna o nome do arquivo onde esta função foi definida.
    ///
    /// No momento, isso está disponível apenas quando libbacktrace ou gimli está sendo usado (por exemplo
    /// unix outras plataformas) e quando um binário é compilado com debuginfo.
    /// Se nenhuma dessas condições for atendida, isso provavelmente retornará `None`.
    ///
    /// # Recursos necessários
    ///
    /// Esta função requer que o recurso `std` do `backtrace` crate seja habilitado, e o recurso `std` está habilitado por padrão.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Talvez um símbolo C++ analisado, se a análise do símbolo mutilado como Rust falhou.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Certifique-se de mantê-lo com tamanho zero, para que o recurso `cpp_demangle` não tenha nenhum custo quando desativado.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Um wrapper em torno de um nome de símbolo para fornecer acessores ergonômicos para o nome demangled, os bytes brutos, a string bruta, etc.
///
// Permitir código morto para quando o recurso `cpp_demangle` não estiver habilitado.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Cria um novo nome de símbolo a partir dos bytes básicos brutos.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Retorna o nome do símbolo (mangled) bruto como um `str` se o símbolo for utf-8 válido.
    ///
    /// Use a implementação do `Display` se quiser a versão degrau.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Retorna o nome do símbolo bruto como uma lista de bytes
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Isso pode ser impresso se o símbolo demangled não for realmente válido, então trate o erro aqui normalmente, não propagando-o para fora.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Tente recuperar a memória em cache usada para simbolizar endereços.
///
/// Este método tentará liberar quaisquer estruturas de dados globais que, de outra forma, tenham sido armazenadas em cache globalmente ou no encadeamento que normalmente representam informações DWARF analisadas ou semelhantes.
///
///
/// # Caveats
///
/// Embora essa função esteja sempre disponível, ela não faz nada na maioria das implementações.
/// Bibliotecas como dbghelp ou libbacktrace não fornecem recursos para desalocar o estado e gerenciar a memória alocada.
/// Por enquanto, o recurso `gimli-symbolize` deste crate é o único recurso onde esta função tem algum efeito.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}