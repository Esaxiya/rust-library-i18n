//! Estratégia de simbolização usando o código de análise DWARF em libbacktrace.
//!
//! A biblioteca libbacktrace C, normalmente distribuída com gcc, oferece suporte não apenas à geração de um backtrace (que não usamos), mas também simboliza o backtrace e manipula informações de depuração anã sobre coisas como quadros embutidos e outros enfeites.
//!
//!
//! Isso é relativamente complicado devido a várias preocupações aqui, mas a ideia básica é:
//!
//! * Primeiro chamamos `backtrace_syminfo`.Isso obtém informações de símbolo da tabela de símbolos dinâmicos, se possível.
//! * Em seguida, chamamos `backtrace_pcinfo`.Isso analisará as tabelas de debuginfo, se estiverem disponíveis, e nos permitirá recuperar informações sobre frames inline, nomes de arquivos, números de linha, etc.
//!
//! Há muitos truques para colocar as tabelas anãs no libbacktrace, mas espero que não seja o fim do mundo e seja claro o suficiente na leitura abaixo.
//!
//! Esta é a estratégia de simbolização padrão para plataformas não MSVC e não OSX.No libstd, embora esta seja a estratégia padrão para OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Se possível, prefira o nome `function` que vem de debuginfo e pode normalmente ser mais preciso para frames inline, por exemplo.
                // Se não estiver presente, volte para o nome da tabela de símbolos especificada no `symname`.
                //
                // Observe que às vezes o `function` pode parecer um pouco menos preciso, por exemplo, sendo listado como `try<i32,closure>` em vez de `std::panicking::try::do_call`.
                //
                // Não está muito claro o porquê, mas no geral o nome `function` parece mais preciso.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // não faça nada por agora
}

/// Tipo de ponteiro `data` passado para `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Assim que esse retorno de chamada for invocado do `backtrace_syminfo`, quando começarmos a resolver, prosseguiremos para chamar o `backtrace_pcinfo`.
    // A função `backtrace_pcinfo` consultará informações de depuração e tentará fazer coisas como recuperar informações file/line, bem como quadros embutidos.
    // Observe que o `backtrace_pcinfo` pode falhar ou não fazer muito se não houver informações de depuração, então, se isso acontecer, teremos certeza de chamar o retorno de chamada com pelo menos um símbolo do `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Tipo de ponteiro `data` passado para `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// A API libbacktrace oferece suporte à criação de um estado, mas não à destruição de um estado.
// Eu pessoalmente entendo que isso significa que um estado deve ser criado e então viver para sempre.
//
// Eu adoraria registrar um manipulador at_exit() que limpe esse estado, mas libbacktrace não fornece nenhuma maneira de fazer isso.
//
// Com essas restrições, essa função tem um estado armazenado em cache estaticamente que é calculado na primeira vez que é solicitado.
//
// Lembre-se de que o backtracing tudo acontece em série (um bloqueio global).
//
// Observe que a falta de sincronização aqui se deve ao requisito de que o `resolve` seja sincronizado externamente.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Não exercite os recursos threadsafe do libbacktrace, pois sempre o chamamos de maneira sincronizada.
        //
        0,
        error_cb,
        ptr::null_mut(), // sem dados extras
    );

    return STATE;

    // Observe que para que o libbacktrace opere, ele precisa encontrar as informações de depuração DWARF para o executável atual.Normalmente faz isso por meio de vários mecanismos, incluindo, mas não se limitando a:
    //
    // * /proc/self/exe em plataformas suportadas
    // * O nome do arquivo é passado explicitamente ao criar o estado
    //
    // A biblioteca libbacktrace é um grande maço de código C.Isso naturalmente significa que ele tem vulnerabilidades de segurança de memória, especialmente ao lidar com informações de depuração malformadas.
    // Libstd já se deparou com muitos deles historicamente.
    //
    // Se o /proc/self/exe for usado, podemos geralmente ignorá-los, pois presumimos que o libbacktrace é o "mostly correct" e não faz coisas estranhas com as informações de depuração do anão do "attempted to be correct".
    //
    //
    // Se passarmos um nome de arquivo, entretanto, é possível em algumas plataformas (como BSDs) onde um agente malicioso pode fazer com que um arquivo arbitrário seja colocado naquele local.
    // Isso significa que se informarmos ao libbacktrace sobre um nome de arquivo, ele pode estar usando um arquivo arbitrário, possivelmente causando segfaults.
    // Se não dissermos nada ao libbacktrace, ele não fará nada em plataformas que não suportam caminhos como o /proc/self/exe!
    //
    // Considerando tudo isso, tentamos o máximo possível *não* passar um nome de arquivo, mas devemos fazer isso em plataformas que não suportam /proc/self/exe.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Observe que o ideal seria usar o `std::env::current_exe`, mas não podemos exigir o `std` aqui.
            //
            // Use o `_NSGetExecutablePath` para carregar o caminho do executável atual em uma área estática (que se for muito pequena, desista).
            //
            //
            // Observe que estamos confiando seriamente no libbacktrace aqui para não morrer em executáveis corrompidos, mas com certeza ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows tem um modo de abrir arquivos onde, depois de aberto, não pode ser excluído.
            // Em geral, é isso que queremos aqui porque queremos garantir que nosso executável não seja alterado depois de transferi-lo para libbacktrace, mitigando a capacidade de passar dados arbitrários para libbacktrace (o que pode ser maltratado).
            //
            //
            // Dado que damos um pouco aqui para tentar obter uma espécie de bloqueio em nossa própria imagem:
            //
            // * Obtenha um identificador para o processo atual, carregue seu nome de arquivo.
            // * Abra um arquivo com esse nome de arquivo com os sinalizadores corretos.
            // * Recarregue o nome do arquivo do processo atual, certificando-se de que é o mesmo
            //
            // Se tudo passar, nós, em teoria, de fato abrimos o arquivo do nosso processo e temos a garantia de que não vai mudar.FWIW, muito disso é copiado do libstd historicamente, então esta é minha melhor interpretação do que estava acontecendo.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Ele vive na memória estática para que possamos devolvê-lo.
                static mut BUF: [i8; N] = [0; N];
                // ... e isso permanece na pilha, pois é temporário
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // vazar intencionalmente `handle` aqui porque ter isso aberto deve preservar nosso bloqueio neste nome de arquivo.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Queremos retornar uma fatia com terminação nula, então se tudo foi preenchido e é igual ao comprimento total, então iguale isso a falha.
                //
                //
                // Caso contrário, ao retornar com sucesso, certifique-se de que o byte nul esteja incluído na fatia.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // erros de rastreamento são atualmente varridos para debaixo do tapete
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Chame a API `backtrace_syminfo` que (pela leitura do código) deve chamar `syminfo_cb` exatamente uma vez (ou falhará com um erro, presumivelmente).
    // Em seguida, lidamos com mais no `syminfo_cb`.
    //
    // Observe que fazemos isso porque o `syminfo` consultará a tabela de símbolos, encontrando os nomes dos símbolos mesmo se não houver informações de depuração no binário.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}