//! Suporte para simbolização usando o `gimli` crate no crates.io
//!
//! Esta é a implementação de simbolização padrão para Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'O tempo de vida estático é uma mentira para contornar a falta de suporte para estruturas autorreferenciais.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Converta para 'tempos de vida estáticos, pois os símbolos devem usar apenas `map` e `stash` e os estamos preservando a seguir.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Para carregar bibliotecas nativas no Windows, consulte algumas discussões sobre o rust-lang/rust#71060 para as várias estratégias aqui.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // Bibliotecas MinGW atualmente não suportam ASLR (rust-lang/rust#16514), mas DLLs ainda podem ser realocadas no espaço de endereço.
            // Parece que os endereços nas informações de depuração são todos como se essa biblioteca tivesse sido carregada em seu "image base", que é um campo em seus cabeçalhos de arquivo COFF.
            // Como é isso que o debuginfo parece listar, analisamos a tabela de símbolos e armazenamos os endereços como se a biblioteca também tivesse sido carregada no "image base".
            //
            // A biblioteca não pode ser carregada no "image base", entretanto.
            // (presumivelmente, algo mais pode estar carregado lá?) É aqui que o campo `bias` entra em jogo e precisamos descobrir o valor de `bias` aqui.Infelizmente, porém, não está claro como adquiri-lo de um módulo carregado.
            // O que temos, entretanto, é o endereço de carregamento real (`modBaseAddr`).
            //
            // Por ora, como uma espécie de desculpa, nós fazemos o mmap do arquivo, lemos as informações do cabeçalho do arquivo e, em seguida, eliminamos o mmap.Isso é um desperdício porque provavelmente iremos reabrir o mmap mais tarde, mas isso deve funcionar bem o suficiente por agora.
            //
            // Assim que tivermos o `image_base` (local de carregamento desejado) e o `base_addr` (local de carregamento real), podemos preencher o `bias` (diferença entre o real e o desejado) e o endereço declarado de cada segmento é o `image_base`, pois é isso que o arquivo diz.
            //
            //
            // Por enquanto, parece que, ao contrário do ELF/MachO, podemos nos contentar com um segmento por biblioteca, usando o `modBaseSize` como tamanho total.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS usa o formato de arquivo Mach-O e usa APIs específicas de DYLD para carregar uma lista de bibliotecas nativas que fazem parte do aplicativo.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Busque o nome desta biblioteca que corresponde ao caminho de onde carregá-la também.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Carregue o cabeçalho da imagem desta biblioteca e delegue ao `object` para analisar todos os comandos de carregamento para que possamos descobrir todos os segmentos envolvidos aqui.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Repita os segmentos e registre regiões conhecidas para os segmentos que encontrarmos.
            // Além disso, registre informações sobre os segmentos de texto para processamento posterior; consulte os comentários abaixo.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Determine o "slide" para esta biblioteca que acaba sendo o viés que usamos para descobrir onde os objetos da memória são carregados.
            // Este é um cálculo um pouco estranho e é o resultado de tentar algumas coisas na selva e ver o que pega.
            //
            // A ideia geral é que o `bias` mais o `stated_virtual_memory_address` de um segmento estarão onde no espaço de endereço real o segmento reside.
            // A outra coisa em que confiamos é que um endereço real sem o `bias` é o índice a ser pesquisado na tabela de símbolos e informações de depuração.
            //
            // Acontece, porém, que para as bibliotecas carregadas pelo sistema, esses cálculos estão incorretos.Para executáveis nativos, no entanto, parece correto.
            // Tirando um pouco da lógica da fonte do LLDB, ele tem um invólucro especial para a primeira seção `__TEXT` carregada do deslocamento de arquivo 0 com um tamanho diferente de zero.
            // Por alguma razão, quando isso está presente, parece significar que a tabela de símbolos é relativa apenas ao slide vmaddr da biblioteca.
            // Se *não* estiver presente, a tabela de símbolos é relativa ao slide vmaddr mais o endereço declarado do segmento.
            //
            // Para lidar com essa situação, se *não* encontrarmos uma seção de texto no deslocamento de arquivo zero, aumentamos a tendência pelo endereço declarado das primeiras seções de texto e também diminuímos todos os endereços declarados nessa quantidade.
            //
            // Dessa forma, a tabela de símbolos sempre aparece em relação à quantidade de polarização da biblioteca.
            // Isso parece ter os resultados corretos para simbolizar por meio da tabela de símbolos.
            //
            // Honestamente, não tenho certeza se isso está certo ou se há algo mais que deva indicar como fazer isso.
            // Por enquanto, o (?) parece funcionar bem o suficiente e devemos sempre ser capazes de ajustá-lo ao longo do tempo, se necessário.
            //
            // Para obter mais informações, consulte #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Outro Unix (por exemplo
        // As plataformas Linux) usam ELF como um formato de arquivo de objeto e geralmente implementam uma API chamada `dl_iterate_phdr` para carregar bibliotecas nativas.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` deve ser um indicador válido.
        // `vec` deve ser um ponteiro válido para um `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 não oferece suporte nativo às informações de depuração, mas o sistema de compilação colocará as informações de depuração no caminho `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Todo o resto deve usar ELF, mas não sabe como carregar bibliotecas nativas.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Todas as bibliotecas compartilhadas conhecidas que foram carregadas.
    libraries: Vec<Library>,

    /// Cache de mapeamentos onde retemos as informações analisadas sobre anões.
    ///
    /// Esta lista tem uma capacidade fixa para todo o seu tempo de levantamento que nunca aumenta.
    /// O elemento `usize` de cada par é um índice em `libraries` acima, onde `usize::max_value()` representa o executável atual.
    ///
    /// O `Mapping` é uma informação anã analisada correspondente.
    ///
    /// Observe que este é basicamente um cache LRU e estaremos mudando as coisas aqui conforme simbolizamos endereços.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Segmentos desta biblioteca carregados na memória e onde são carregados.
    segments: Vec<LibrarySegment>,
    /// O "bias" desta biblioteca, normalmente onde é carregado na memória.
    /// Este valor é adicionado ao endereço declarado de cada segmento para obter o endereço real da memória virtual em que o segmento é carregado.
    /// Além disso, essa tendência é subtraída dos endereços de memória virtual real para indexar no debuginfo e na tabela de símbolos.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// O endereço declarado deste segmento no arquivo de objeto.
    /// Não é realmente onde o segmento é carregado, mas sim este endereço mais o `bias` da biblioteca que o contém é onde encontrá-lo.
    ///
    stated_virtual_memory_address: usize,
    /// O tamanho deste segmento na memória.
    len: usize,
}

// inseguro porque é necessário sincronizar externamente
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // inseguro porque é necessário sincronizar externamente
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Um cache LRU muito pequeno e muito simples para mapeamentos de informações de depuração.
        //
        // A taxa de acerto deve ser muito alta, já que a pilha típica não cruza entre muitas bibliotecas compartilhadas.
        //
        // As estruturas `addr2line::Context` são muito caras para criar.
        // Espera-se que seu custo seja amortizado por consultas `locate` subsequentes, que alavancam as estruturas construídas ao construir `addr2line: : Context`s para obter ótimos acelerações.
        //
        // Se não tivéssemos esse cache, essa amortização nunca aconteceria, e os backtraces simbólicos seriam ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Primeiro, teste se este `lib` tem algum segmento contendo o `addr` (manipulação de realocação).Se a verificação for aprovada, podemos continuar abaixo e traduzir o endereço.
                //
                // Observe que estamos usando o `wrapping_add` aqui para evitar verificações de estouro.Foi visto à solta que o overflows de computação de polarização de SVMA +.
                // Parece um pouco estranho que isso aconteceria, mas não há muito que possamos fazer a respeito, a não ser, provavelmente, apenas ignorar esses segmentos, já que eles provavelmente estão apontando para o espaço.
                //
                // Isso veio originalmente no rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Agora que sabemos que o `lib` contém o `addr`, podemos compensar com a polarização para encontrar o endereço de memória viral declarado.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Invariante: após a conclusão desta condicional sem retornar antecipadamente
        // de um erro, a entrada de cache para este caminho está no índice 0.

        if let Some(idx) = idx {
            // Quando o mapeamento já estiver no cache, mova-o para a frente.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Quando o mapeamento não estiver no cache, crie um novo mapeamento, insira-o na frente do cache e remova a entrada de cache mais antiga, se necessário.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // não deixe vazar a vida útil do `'static`, certifique-se de que o escopo é apenas para nós
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Prolongue a vida útil do `sym` para o `'static`, uma vez que infelizmente somos obrigados a fazê-lo aqui, mas ele só sai como uma referência, então nenhuma referência a ele deve ser persistida além deste quadro de qualquer maneira.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Finalmente, obtenha um mapeamento em cache ou crie um novo mapeamento para este arquivo e avalie as informações DWARF para encontrar o file/line/name para este endereço.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Conseguimos localizar as informações do frame para este símbolo, e o frame de `addr2line` possui internamente todos os detalhes essenciais.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Não foi possível encontrar informações de depuração, mas as encontramos na tabela de símbolos do executável elf.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}