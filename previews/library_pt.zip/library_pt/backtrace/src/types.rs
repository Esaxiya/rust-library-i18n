//! Tipos dependentes de plataforma.

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// Uma representação independente de plataforma de uma string.
/// Ao trabalhar com o `std` habilitado, é recomendável usar os métodos de conveniência para fornecer conversões para os tipos `std`.
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// Uma fatia, normalmente fornecida em plataformas Unix.
    Bytes(&'a [u8]),
    /// Strings largas normalmente do Windows.
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// Com perdas é convertido em `Cow<str>`, será alocado se `Bytes` não for UTF-8 válido ou se `BytesOrWideString` for `Wide`.
    ///
    /// # Recursos necessários
    ///
    /// Esta função requer que o recurso `std` do `backtrace` crate seja habilitado, e o recurso `std` está habilitado por padrão.
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// Fornece uma representação `Path` de `BytesOrWideString`.
    ///
    /// # Recursos necessários
    ///
    /// Esta função requer que o recurso `std` do `backtrace` crate seja habilitado, e o recurso `std` está habilitado por padrão.
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}