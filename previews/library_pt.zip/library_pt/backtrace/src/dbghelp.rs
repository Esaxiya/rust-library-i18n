//! Um módulo para auxiliar no gerenciamento de ligações dbghelp no Windows
//!
//! Backtraces no Windows (pelo menos para MSVC) são amplamente alimentados pelo `dbghelp.dll` e pelas várias funções que ele contém.
//! Essas funções são carregadas *dinamicamente* em vez de vincular ao `dbghelp.dll` estaticamente.
//! Isso é feito atualmente pela biblioteca padrão (e é teoricamente necessário lá), mas é um esforço para ajudar a reduzir as dependências dll estáticas de uma biblioteca, uma vez que os backtraces são normalmente bastante opcionais.
//!
//! Dito isso, o `dbghelp.dll` quase sempre carrega com sucesso no Windows.
//!
//! Observe que, como estamos carregando todo esse suporte dinamicamente, não podemos realmente usar as definições brutas no `winapi`, mas precisamos definir os tipos de ponteiro de função nós mesmos e usá-los.
//! Não queremos realmente duplicar o winapi, então temos um recurso Cargo `verify-winapi` que afirma que todas as ligações correspondem às do winapi e esse recurso está habilitado no CI.
//!
//! Finalmente, você notará aqui que a dll para o `dbghelp.dll` nunca é descarregada e isso é intencional no momento.
//! O pensamento é que podemos armazená-lo em cache globalmente e usá-lo entre as chamadas para a API, evitando o caro loads/unloads.
//! Se isso for um problema para detectores de vazamento ou algo parecido, podemos cruzar a ponte quando chegarmos lá.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Trabalhe em torno do `SymGetOptions` e do `SymSetOptions`, não estando presente no Winapi.
// Caso contrário, isso só é usado quando estamos verificando os tipos contra o winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Ainda não definido no winapi
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Isso é definido no winapi, mas está incorreto (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Ainda não definido no winapi
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Esta macro é usada para definir uma estrutura `Dbghelp` que contém internamente todos os ponteiros de função que podemos carregar.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// A DLL carregada para `dbghelp.dll`
            dll: HMODULE,

            // Cada ponteiro de função para cada função que podemos usar
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Inicialmente não carregamos a DLL
            dll: 0 as *mut _,
            // Inicialmente, todas as funções são definidas como zero para dizer que precisam ser carregadas dinamicamente.
            //
            $($name: 0,)*
        };

        // Typedef de conveniência para cada tipo de função.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Tenta abrir o `dbghelp.dll`.
            /// Retorna sucesso se funcionar ou erro se `LoadLibraryW` falhar.
            ///
            /// Panics se a biblioteca já estiver carregada.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Função para cada método que gostaríamos de usar.
            // Quando chamado, ele lerá o ponteiro de função em cache ou o carregará e retornará o valor carregado.
            // As cargas são declaradas com êxito.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Proxy de conveniência para usar os bloqueios de limpeza para fazer referência a funções dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Inicialize todo o suporte necessário para acessar as funções da API `dbghelp` a partir deste crate.
///
///
/// Observe que esta função é **segura**, ela possui internamente sua própria sincronização.
/// Observe também que é seguro chamar essa função várias vezes recursivamente.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // A primeira coisa que precisamos fazer é sincronizar essa função.Isso pode ser chamado simultaneamente a partir de outros threads ou recursivamente em um thread.
        // Observe que é mais complicado do que porque o que estamos usando aqui, `dbghelp`,*também* precisa ser sincronizado com todos os outros chamadores para `dbghelp` neste processo.
        //
        // Normalmente, não há muitas chamadas para o `dbghelp` dentro do mesmo processo e provavelmente podemos assumir com segurança que somos os únicos a acessá-lo.
        // Há, no entanto, um outro usuário principal com o qual devemos nos preocupar, que ironicamente é nós mesmos, mas na biblioteca padrão.
        // A biblioteca padrão Rust depende deste crate para suporte de backtrace, e este crate também existe no crates.io.
        // Isso significa que se a biblioteca padrão estiver imprimindo um backtrace panic, ela pode competir com esse crate vindo do crates.io, causando falhas de segurança.
        //
        // Para ajudar a resolver esse problema de sincronização, empregamos um truque específico do Windows aqui (é, afinal, uma restrição específica do Windows sobre a sincronização).
        // Criamos um mutex *local da sessão* chamado para proteger essa chamada.
        // A intenção aqui é que a biblioteca padrão e este crate não tenham que compartilhar APIs de nível Rust para sincronizar aqui, mas podem trabalhar nos bastidores para ter certeza de que estão sincronizando um com o outro.
        //
        // Dessa forma, quando esta função é chamada através da biblioteca padrão ou através do crates.io, podemos ter certeza de que o mesmo mutex está sendo adquirido.
        //
        // Então, tudo isso é para dizer que a primeira coisa que fazemos aqui é criar atomicamente um `HANDLE` que é um mutex nomeado no Windows.
        // Sincronizamos um pouco com outros threads que compartilham esta função especificamente e garantimos que apenas um identificador seja criado por instância desta função.
        // Observe que o identificador nunca é fechado, uma vez que é armazenado no global.
        //
        // Depois de realmente abrirmos o bloqueio, simplesmente o adquirimos, e nosso identificador `Init` que distribuímos será responsável por descartá-lo eventualmente.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, ufa!Agora que estamos todos sincronizados com segurança, vamos começar a processar tudo.
        // Primeiro, precisamos garantir que o `dbghelp.dll` seja realmente carregado neste processo.
        // Fazemos isso dinamicamente para evitar uma dependência estática.
        // Isso tem sido feito historicamente para contornar problemas estranhos de links e tem como objetivo tornar os binários um pouco mais portáveis, uma vez que se trata basicamente de um utilitário de depuração.
        //
        //
        // Depois de abrir o `dbghelp.dll`, precisamos chamar algumas funções de inicialização nele, e isso é mais detalhado abaixo.
        // No entanto, só fazemos isso uma vez, então temos um booleano global indicando se terminamos ainda ou não.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Certifique-se de que o sinalizador `SYMOPT_DEFERRED_LOADS` esteja definido, porque de acordo com os próprios documentos do MSVC sobre isso: "This is the fastest, most efficient way to use the symbol handler.", então vamos fazer isso!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Na verdade, inicialize os símbolos com MSVC.Observe que isso pode falhar, mas nós o ignoramos.
        // Não há uma tonelada de técnica anterior para isso em si, mas o LLVM internamente parece ignorar o valor de retorno aqui e uma das bibliotecas do sanitizer no LLVM imprime um aviso assustador se isso falhar, mas basicamente o ignora no longo prazo.
        //
        //
        // Um caso que surge muito para Rust é que a biblioteca padrão e este crate no crates.io desejam competir pelo `SymInitializeW`.
        // A biblioteca padrão historicamente queria inicializar e depois limpar na maioria das vezes, mas agora que está usando este crate, significa que alguém fará a inicialização primeiro e o outro pegará essa inicialização.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}