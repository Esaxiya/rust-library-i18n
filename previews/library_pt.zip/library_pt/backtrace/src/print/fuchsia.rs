use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr recebe um retorno de chamada que receberá um ponteiro dl_phdr_info para cada DSO que foi vinculado ao processo.
    // dl_iterate_phdr também garante que o vinculador dinâmico seja bloqueado do início ao fim da iteração.
    // Se o retorno de chamada retornar um valor diferente de zero, a iteração será encerrada antecipadamente.
    // 'data' será passado como o terceiro argumento para o retorno de chamada em cada chamada.
    // 'size' dá o tamanho de dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Precisamos analisar o ID de construção e alguns dados básicos do cabeçalho do programa, o que significa que também precisamos de um pouco de material da especificação ELF.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Agora temos que replicar, bit a bit, a estrutura do tipo dl_phdr_info usado pelo vinculador dinâmico atual do fuchsia.
// O Chromium também tem esse limite ABI, bem como crashpad.
// Eventualmente, gostaríamos de mover esses casos para usar o elf-search, mas precisaríamos fornecer isso no SDK e isso ainda não foi feito.
//
// Portanto, nós (e eles) estamos presos tendo que usar este método que incorre em um acoplamento forte com a libc fúcsia.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Não temos como saber se e_phoff e e_phnum são válidos.
    // A libc deve garantir isso para nós, portanto, é seguro formar uma fatia aqui.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr representa um cabeçalho de programa ELF de 64 bits no endianness da arquitetura de destino.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr representa um cabeçalho de programa ELF válido e seu conteúdo.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Não temos como verificar se p_addr ou p_memsz são válidos.
    // A libc de Fuchsia analisa as notas primeiro, entretanto, por estar aqui, esses cabeçalhos devem ser válidos.
    //
    // NoteIter não requer que os dados subjacentes sejam válidos, mas requer que os limites sejam válidos.
    // Esperamos que a libc tenha garantido que este seja o nosso caso aqui.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// O tipo de nota para IDs de compilação.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr representa um cabeçalho de nota ELF no endianness do alvo.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Nota representa uma nota ELF (cabeçalho + conteúdo).
// O nome é deixado como uma fatia u8 porque nem sempre é terminado em nulo e rust torna mais fácil verificar se os bytes correspondem de qualquer maneira.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter permite iterar com segurança sobre um segmento de nota.
// Ele termina assim que ocorre um erro ou não há mais notas.
// Se você iterar sobre dados inválidos, funcionará como se nenhuma nota tivesse sido encontrada.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // É uma invariante da função que o ponteiro e o tamanho dados denotem um intervalo válido de bytes que podem ser lidos.
    // O conteúdo desses bytes pode ser qualquer coisa, mas o intervalo deve ser válido para que isso seja seguro.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to alinha 'x' com o alinhamento de 'to'-byte, assumindo que 'to' é uma potência de 2.
// Isso segue um padrão padrão no código de análise C/C ++ ELF em que (x + a, 1)&-to é usado.
// Rust não permite que você negue o uso, então eu uso
// Conversão de complemento de 2 para recriar isso.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 consome núm bytes da fatia (se presente) e, adicionalmente, garante que a fatia final esteja devidamente alinhada.
// Se o número de bytes solicitados for muito grande ou a fatia não puder ser realinhada posteriormente devido à existência de bytes insuficientes, None é retornado e a fatia não é modificada.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Esta função não possui invariantes reais que o chamador deve defender, exceto talvez que o 'bytes' deva ser alinhado para desempenho (e em algumas arquiteturas correção).
// Os valores nos campos Elf_Nhdr podem ser absurdos, mas esta função não garante isso.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Isso é seguro desde que haja espaço suficiente e nós apenas confirmamos isso na instrução if acima, portanto, não deve ser inseguro.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Observe que sice_of: :<Elf_Nhdr>() está sempre alinhado com 4 bytes.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Verifique se chegamos ao fim.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Transmutamos um nhdr, mas consideramos cuidadosamente a estrutura resultante.
        // Não confiamos no namesz ou descsz e não tomamos decisões inseguras com base no tipo.
        //
        // Portanto, mesmo que retiremos o lixo completo, ainda estaremos seguros.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Indica que um segmento é executável.
const PERM_X: u32 = 0b00000001;
/// Indica que um segmento é gravável.
const PERM_W: u32 = 0b00000010;
/// Indica que um segmento é legível.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Representa um segmento ELF em tempo de execução.
struct Segment {
    /// Fornece o endereço virtual de tempo de execução do conteúdo deste segmento.
    addr: usize,
    /// Fornece o tamanho da memória do conteúdo deste segmento.
    size: usize,
    /// Fornece o endereço virtual do módulo deste segmento com o arquivo ELF.
    mod_rel_addr: usize,
    /// Fornece as permissões encontradas no arquivo ELF.
    /// No entanto, essas permissões não são necessariamente as permissões presentes no tempo de execução.
    flags: Perm,
}

/// Permite iterar sobre segmentos de um DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Representa um ELF DSO (Dynamic Shared Object).
/// Esse tipo faz referência aos dados armazenados no DSO real, em vez de fazer sua própria cópia.
struct Dso<'a> {
    /// O vinculador dinâmico sempre nos dá um nome, mesmo se o nome estiver vazio.
    /// No caso do executável principal, este nome estará vazio.
    /// No caso de um objeto compartilhado, será o soname (ver DT_SONAME).
    name: &'a str,
    /// No Fuchsia, virtualmente todos os binários têm IDs de construção, mas isso não é um requisito estrito.
    /// Não há como combinar as informações do DSO com um arquivo ELF real depois, se não houver build_id, então exigimos que cada DSO tenha um aqui.
    ///
    /// DSOs sem um build_id são ignorados.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Retorna um iterador sobre segmentos neste DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Esses erros codificam problemas que surgem durante a análise de informações sobre cada DSO.
///
enum Error {
    /// NameError significa que ocorreu um erro ao converter uma string de estilo C em uma string rust.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError significa que não encontramos um ID de compilação.
    /// Isso pode ser porque o DSO não tinha ID de compilação ou porque o segmento que contém a ID de compilação estava malformado.
    ///
    BuildIDError,
}

/// Chama o 'dso' ou o 'error' para cada DSO vinculado ao processo pelo vinculador dinâmico.
///
///
/// # Arguments
///
/// * `visitor` - Uma DsoPrinter que terá um dos métodos eats chamados foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr garante que o info.name apontará para um local válido.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Esta função imprime a marcação do simbolizador fúcsia para todas as informações contidas em um DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}