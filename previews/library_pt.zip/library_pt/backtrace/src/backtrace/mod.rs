use core::ffi::c_void;
use core::fmt;

/// Inspeciona a pilha de chamadas atual, passando todos os quadros ativos para o fechamento fornecido para calcular um rastreamento de pilha.
///
/// Esta função é o carro-chefe desta biblioteca no cálculo dos rastreamentos de pilha de um programa.O `cb` de fechamento fornecido são instâncias produzidas de um `Frame` que representam informações sobre aquele quadro de chamada na pilha.
/// O fechamento é gerado em quadros de cima para baixo (mais recentemente chamado de funções primeiro).
///
/// O valor de retorno do fechamento é uma indicação se o backtrace deve continuar.Um valor de retorno de `false` encerrará o backtrace e retornará imediatamente.
///
/// Depois que um `Frame` for adquirido, você provavelmente desejará chamar o `backtrace::resolve` para converter o `ip` (ponteiro de instrução) ou endereço de símbolo em um `Symbol` por meio do qual o nome e/ou nome do arquivo/número da linha podem ser aprendidos.
///
///
/// Observe que esta é uma função de nível relativamente baixo e se você quiser, por exemplo, capturar um backtrace para ser inspecionado posteriormente, o tipo `Backtrace` pode ser mais apropriado.
///
/// # Recursos necessários
///
/// Esta função requer que o recurso `std` do `backtrace` crate seja habilitado, e o recurso `std` está habilitado por padrão.
///
/// # Panics
///
/// Esta função se esforça para nunca panic, mas se o `cb` forneceu panics, então algumas plataformas forçarão um panic duplo a abortar o processo.
/// Algumas plataformas usam uma biblioteca C que usa internamente retornos de chamada que não podem ser desenrolados, portanto, entrar em pânico com o `cb` pode acionar o aborto do processo.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // continue o backtrace
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Igual ao `trace`, apenas inseguro, pois não está sincronizado.
///
/// Esta função não tem garantias de sincronização, mas está disponível quando o recurso `std` deste crate não está compilado.
/// Consulte a função `trace` para obter mais documentação e exemplos.
///
/// # Panics
///
/// Consulte as informações sobre o `trace` para advertências sobre o pânico do `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// Um trait representando um quadro de um backtrace, rendido à função `trace` deste crate.
///
/// O fechamento da função de rastreamento produzirá quadros, e o quadro é virtualmente despachado, pois a implementação subjacente nem sempre é conhecida até o tempo de execução.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Retorna o ponteiro de instrução atual deste quadro.
    ///
    /// Normalmente, essa é a próxima instrução a ser executada no quadro, mas nem todas as implementações listam isso com 100% de precisão (mas geralmente é bem parecido).
    ///
    ///
    /// Recomenda-se passar este valor para o `backtrace::resolve` para transformá-lo em um nome de símbolo.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Retorna o ponteiro da pilha atual deste quadro.
    ///
    /// No caso de um back-end não poder recuperar o ponteiro da pilha para este quadro, um ponteiro nulo é retornado.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Retorna o endereço do símbolo inicial do quadro desta função.
    ///
    /// Isso tentará retroceder o ponteiro de instrução retornado pelo `ip` para o início da função, retornando esse valor.
    ///
    /// Em alguns casos, no entanto, os back-ends retornarão apenas o `ip` a partir desta função.
    ///
    /// O valor retornado às vezes pode ser usado se o `backtrace::resolve` falhou no `ip` fornecido acima.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Retorna o endereço básico do módulo ao qual o quadro pertence.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Isso precisa vir primeiro, para garantir que Miri tenha prioridade sobre a plataforma host
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // usado apenas em dbghelp.
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}