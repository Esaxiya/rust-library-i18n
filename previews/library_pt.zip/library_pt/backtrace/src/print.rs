#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Um formatador para backtraces.
///
/// Este tipo pode ser usado para imprimir um backtrace, independentemente de onde o próprio backtrace vem.
/// Se você tiver um tipo `Backtrace`, sua implementação `Debug` já usa este formato de impressão.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Os estilos de impressão que podemos imprimir
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Imprime um backtrace curto que, idealmente, contém apenas informações relevantes
    Short,
    /// Imprime um backtrace que contém todas as informações possíveis
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Crie um novo `BacktraceFmt` que gravará a saída no `fmt` fornecido.
    ///
    /// O argumento `format` controlará o estilo no qual o backtrace é impresso e o argumento `print_path` será usado para imprimir as instâncias `BytesOrWideString` de nomes de arquivos.
    /// Este tipo em si não imprime nomes de arquivo, mas esse retorno de chamada é necessário para isso.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Imprime um preâmbulo para o backtrace prestes a ser impresso.
    ///
    /// Isso é necessário em algumas plataformas para que os backtraces sejam totalmente simbolizados posteriormente; caso contrário, este deve ser apenas o primeiro método a ser chamado após a criação de um `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Adiciona um quadro à saída do backtrace.
    ///
    /// Este commit retorna uma instância RAII de um `BacktraceFrameFmt` que pode ser usado para realmente imprimir um quadro e, na destruição, irá incrementar o contador de quadros.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Conclui a saída de backtrace.
    ///
    /// Este é atualmente um ambiente autônomo, mas foi adicionado para compatibilidade do future com formatos de backtrace.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Atualmente sem operação-incluindo este hook para permitir adições ao future.
        Ok(())
    }
}

/// Um formatador para apenas um quadro de um backtrace.
///
/// Este tipo é criado pela função `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Imprime uma `BacktraceFrame` com este formatador de quadros.
    ///
    /// Isso imprimirá recursivamente todas as instâncias do `BacktraceSymbol` no `BacktraceFrame`.
    ///
    /// # Recursos necessários
    ///
    /// Esta função requer que o recurso `std` do `backtrace` crate seja habilitado, e o recurso `std` está habilitado por padrão.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Imprime um `BacktraceSymbol` dentro de um `BacktraceFrame`.
    ///
    /// # Recursos necessários
    ///
    /// Esta função requer que o recurso `std` do `backtrace` crate seja habilitado, e o recurso `std` está habilitado por padrão.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: isso não é bom que acabamos não imprimindo nada
            // com nomes de arquivo não utf8.
            // Felizmente, quase tudo é utf8, então isso não deve ser tão ruim.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Imprime um `Frame` e `Symbol` rastreado bruto, normalmente de dentro dos callbacks brutos deste crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Adiciona um quadro bruto à saída do backtrace.
    ///
    /// Este método, ao contrário do anterior, pega os argumentos brutos no caso de serem fonte de locais diferentes.
    /// Observe que isso pode ser chamado várias vezes para um quadro.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Adiciona um quadro bruto à saída do backtrace, incluindo informações da coluna.
    ///
    /// Este método, como o anterior, pega os argumentos brutos no caso de serem fonte de locais diferentes.
    /// Observe que isso pode ser chamado várias vezes para um quadro.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // O fúcsia não é capaz de simbolizar dentro de um processo, por isso tem um formato especial que pode ser usado para simbolizar mais tarde.
        // Imprima isso em vez de imprimir endereços em nosso próprio formato aqui.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Não há necessidade de imprimir quadros "null", basicamente significa apenas que o backtrace do sistema estava um pouco ansioso para rastrear muito longe.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Para reduzir o tamanho do TCB no enclave Sgx, não queremos implementar a funcionalidade de resolução de símbolo.
        // Em vez disso, podemos imprimir o deslocamento do endereço aqui, que pode ser mapeado posteriormente para a função correta.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Imprime o índice do quadro, bem como o ponteiro de instrução opcional do quadro.
        // Se estivermos além do primeiro símbolo deste quadro, apenas imprimiremos os espaços em branco apropriados.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Em seguida, escreva o nome do símbolo, usando a formatação alternativa para obter mais informações se formos um backtrace completo.
        // Aqui também lidamos com símbolos que não têm um nome,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // E por último, imprima o número do filename/line, se estiver disponível.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line são impressos em linhas abaixo do nome do símbolo, então imprima alguns espaços em branco apropriados para nos alinharmos à direita.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Delegue ao nosso callback interno para imprimir o nome do arquivo e, em seguida, imprimir o número da linha.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Adicione o número da coluna, se disponível.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Nós só nos importamos com o primeiro símbolo de uma moldura
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}