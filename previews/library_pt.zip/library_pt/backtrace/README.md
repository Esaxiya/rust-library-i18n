# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Uma biblioteca para adquirir backtraces em tempo de execução para Rust.
Esta biblioteca visa aprimorar o suporte da biblioteca padrão, fornecendo uma interface programática para trabalhar, mas também suporta a impressão simples e fácil do backtrace atual como o panics da libstd.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Para simplesmente capturar um backtrace e adiar lidar com ele para um momento posterior, você pode usar o tipo `Backtrace` de nível superior.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Se, no entanto, você quiser um acesso mais bruto à funcionalidade de rastreamento real, poderá usar as funções `trace` e `resolve` diretamente.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Resolve este ponteiro de instrução para um nome de símbolo
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // continue indo para o próximo quadro
    });
}
```

# License

Este projeto está licenciado sob qualquer um dos

 * Licença Apache, Versão 2.0, ([LICENSE-APACHE](LICENSE-APACHE) ou http://www.apache.org/licenses/LICENSE-2.0)
 * Licença MIT ([LICENSE-MIT](LICENSE-MIT) ou http://opensource.org/licenses/MIT)

à sua escolha.

### Contribution

A menos que você declare explicitamente o contrário, qualquer contribuição enviada intencionalmente para inclusão no backtrace-rs por você, conforme definido na licença Apache-2.0, será licenciada dupla conforme acima, sem quaisquer termos ou condições adicionais.







