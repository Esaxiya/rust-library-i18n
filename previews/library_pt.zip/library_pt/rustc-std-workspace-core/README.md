# O `rustc-std-workspace-core` crate

Este crate é um calço e crate vazio que simplesmente depende do `libcore` e reexporta todo o seu conteúdo.
O crate é o ponto crucial para capacitar a biblioteca padrão a depender do crates do crates.io

Crates no crates.io do qual a biblioteca padrão depende precisa depender do `rustc-std-workspace-core` crate do crates.io, que está vazio.

Usamos `[patch]` para substituí-lo por este crate neste repositório.
Como resultado, crates no crates.io desenhará uma dependência edge para `libcore`, a versão definida neste repositório.
Isso deve desenhar todas as bordas de dependência para garantir que Cargo construa crates com sucesso!

Observe que crates no crates.io precisa depender deste crate com o nome `core` para que tudo funcione corretamente.Para fazer isso, eles podem usar:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Através do uso da chave `package`, o crate é renomeado para `core`, o que significa que se parecerá com

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

quando Cargo invoca o compilador, satisfazendo a diretiva `extern crate core` implícita injetada pelo compilador.




