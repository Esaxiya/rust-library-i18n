// rsbegin.o e rsend.o são os chamados "compiler runtime startup objects".
// Eles contêm o código necessário para inicializar corretamente o tempo de execução do compilador.
//
// Quando uma imagem executável ou dylib é vinculada, todos os códigos e bibliotecas do usuário são "sandwiched" entre esses dois arquivos de objeto, portanto, o código ou os dados do rsbegin.o se tornam os primeiros nas respectivas seções da imagem, enquanto o código e os dados do rsend.o se tornam os últimos.
// Este efeito pode ser usado para colocar símbolos no início ou no final de uma seção, bem como para inserir quaisquer cabeçalhos ou rodapés necessários.
//
// Observe que o ponto de entrada do módulo real está localizado no objeto de inicialização do tempo de execução C (geralmente chamado de `crtX.o`), que então invoca retornos de chamada de inicialização de outros componentes de tempo de execução (registrados por meio de outra seção de imagem especial).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Marca o início da seção de informações de desenrolamento da estrutura da pilha
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Espaço livre para a contabilidade interna do desenrolador.
    // Isso é definido como `struct object` em $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Desenrole informações sobre rotinas registration/deregistration.
    // Veja a documentação de libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // registrar informações de desenrolamento na inicialização do módulo
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // cancelar o registro no desligamento
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Registro de rotina init/uninit específico para MinGW
    pub mod mingw_init {
        // Os objetos de inicialização do MinGW (crt0.o/dllcrt0.o) invocarão construtores globais nas seções .ctors e .dtors na inicialização e saída.
        // No caso de DLLs, isso é feito quando a DLL é carregada e descarregada.
        //
        // O vinculador classificará as seções, o que garante que nossos retornos de chamada estejam localizados no final da lista.
        // Como os construtores são executados em ordem reversa, isso garante que nossos retornos de chamada sejam os primeiros e os últimos executados.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: retornos de chamada de inicialização C
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: callbacks de terminação C
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}