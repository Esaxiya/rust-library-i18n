# O `rustc-std-workspace-std` crate

Consulte a documentação do `rustc-std-workspace-core` crate.