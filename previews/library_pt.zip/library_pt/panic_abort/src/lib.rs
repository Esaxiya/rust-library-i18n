//! Implementação de Rust panics via abortos de processo
//!
//! Quando comparado com a implementação via desenrolamento, este crate é *muito* mais simples!Dito isso, não é tão versátil, mas aqui vai!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" a carga útil e o shim para o aborto relevante na plataforma em questão.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // ligue para std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // No Windows, use o mecanismo __fastfail específico do processador.No Windows 8 e posterior, isso encerrará o processo imediatamente sem executar qualquer manipulador de exceção em processo.
            // Em versões anteriores do Windows, esta sequência de instruções será tratada como uma violação de acesso, encerrando o processo, mas sem necessariamente ignorar todos os manipuladores de exceção.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: esta é a mesma implementação que no `abort_internal` da libstd
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Isso ... é um pouco estranho.O tl; dr;é que isso é necessário para vincular corretamente, a explicação mais longa está abaixo.
//
// No momento, os binários do libcore/libstd que enviamos são todos compilados com o `-C panic=unwind`.Isso é feito para garantir que os binários sejam compatíveis ao máximo com o maior número possível de situações.
// O compilador, entretanto, requer um "personality function" para todas as funções compiladas com o `-C panic=unwind`.Esta função de personalidade é codificada para o símbolo `rust_eh_personality` e é definida pelo item lang `eh_personality`.
//
// So...
// por que não definir esse item de idioma aqui?Boa pergunta!A maneira como os tempos de execução panic são vinculados é, na verdade, um pouco sutil, pois eles são "sort of" no armazenamento crate do compilador, mas apenas vinculados de fato se outro não estiver vinculado.
//
// Isso acaba significando que tanto este crate quanto o panic_unwind crate podem aparecer no armazenamento crate do compilador e, se ambos definirem o item de idioma `eh_personality`, ocorrerá um erro.
//
// Para lidar com isso, o compilador só requer que o `eh_personality` seja definido se o tempo de execução panic sendo vinculado for o tempo de execução de desenrolamento e, caso contrário, não é necessário definir (com razão).
// Neste caso, entretanto, esta biblioteca apenas define este símbolo, então há pelo menos alguma personalidade em algum lugar.
//
// Essencialmente, esse símbolo é apenas definido para ser conectado aos binários do libcore/libstd, mas nunca deve ser chamado, pois não nos vinculamos em um tempo de execução de desenrolamento.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // No x86_64-pc-windows-gnu, usamos nossa própria função de personalidade que precisa retornar o `ExceptionContinueSearch` conforme estamos passando todos os nossos quadros.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Semelhante ao anterior, isso corresponde ao item `eh_catch_typeinfo` lang que é usado apenas no Emscripten atualmente.
    //
    // Uma vez que panics não gera exceções e exceções estrangeiras são atualmente UB com -C panic=abort (embora isso possa estar sujeito a alterações), quaisquer chamadas catch_unwind nunca usarão este typeinfo.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Esses dois são chamados por nossos objetos de inicialização em i686-pc-windows-gnu, mas eles não precisam fazer nada, então os corpos são nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}