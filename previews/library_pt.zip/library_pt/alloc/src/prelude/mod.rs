//! A alocação Prelude
//!
//! O objetivo deste módulo é aliviar as importações de itens comumente usados do `alloc` crate adicionando uma importação global ao topo dos módulos:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;