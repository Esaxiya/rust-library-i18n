#![stable(feature = "wake_trait", since = "1.51.0")]
//! Tipos e Traits para trabalhar com tarefas assíncronas.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// A implementação de despertar uma tarefa em um executor.
///
/// Este trait pode ser usado para criar um [`Waker`].
/// Um executor pode definir uma implementação deste trait e usá-lo para construir um Waker para passar para as tarefas que são executadas naquele executor.
///
/// Este trait é uma alternativa ergonômica e segura para a memória para construir um [`RawWaker`].
/// Ele oferece suporte ao design de executor comum, no qual os dados usados para ativar uma tarefa são armazenados em um [`Arc`].
/// Alguns executores (especialmente aqueles para sistemas embarcados) não podem usar esta API, e é por isso que o [`RawWaker`] existe como uma alternativa para esses sistemas.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Uma função `block_on` básica que pega um future e o executa até a conclusão no thread atual.
///
/// **Note:** Este exemplo negocia correção por simplicidade.
/// Para evitar bloqueios, as implementações de nível de produção também precisarão lidar com chamadas intermediárias para o `thread::unpark`, bem como invocações aninhadas.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Um waker que desperta o encadeamento atual quando chamado.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Execute um future até a conclusão no segmento atual.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Fixe o future para que possa ser pesquisado.
///     let mut fut = Box::pin(fut);
///
///     // Crie um novo contexto a ser passado para o future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Execute o future até a conclusão.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Desperte esta tarefa.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Desperte esta tarefa sem consumir o waker.
    ///
    /// Se um executor oferecer suporte a uma maneira mais barata de despertar sem consumir o waker, ele deve substituir esse método.
    /// Por padrão, ele clona o [`Arc`] e chama o [`wake`] no clone.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // SEGURANÇA: Isso é seguro porque raw_waker constrói com segurança
        // um RawWaker do Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Esta função privada para construir um RawWaker é usada, ao invés de
// embutir isso no implemento `From<Arc<W>> for RawWaker`, para garantir que a segurança do `From<Arc<W>> for Waker` não dependa do despacho trait correto, em vez disso, ambos os impls chamam essa função direta e explicitamente.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Aumente a contagem de referência do arco para cloná-lo.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Desperte pelo valor, movendo o Arc para a função Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Wake by reference, envolva o waker em ManualmenteDrop para evitar deixá-lo cair
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Diminuir a contagem de referência do arco em queda
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}