/// Cria um [`Vec`] contendo os argumentos.
///
/// `vec!` permite que `Vec`s seja definido com a mesma sintaxe das expressões de array.
/// Existem duas formas dessa macro:
///
/// - Crie um [`Vec`] contendo uma determinada lista de elementos:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Crie um [`Vec`] a partir de um determinado elemento e tamanho:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Observe que, ao contrário das expressões de matriz, essa sintaxe oferece suporte a todos os elementos que implementam [`Clone`] e o número de elementos não precisa ser uma constante.
///
/// Isso usará o `clone` para duplicar uma expressão, portanto, deve-se ter cuidado ao usá-lo com tipos que possuem uma implementação `Clone` não padrão.
/// Por exemplo, `vec![Rc::new(1);5] `criará um vector de cinco referências para o mesmo valor inteiro em caixa, não cinco referências apontando para inteiros em caixa independentemente.
///
///
/// Além disso, observe que `vec![expr; 0]` é permitido e produz um vector vazio.
/// No entanto, isso ainda avaliará o `expr` e reduzirá imediatamente o valor resultante, portanto, esteja ciente dos efeitos colaterais.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): com o cfg(test), o método `[T]::into_vec` inerente, que é necessário para esta definição de macro, não está disponível.
// Em vez disso, use a função `slice::into_vec` que está disponível apenas com cfg(test) NB, consulte o módulo slice::hack em slice.rs para obter mais informações
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Cria um `String` usando interpolação de expressões de tempo de execução.
///
/// O primeiro argumento que o `format!` recebe é uma string de formato.Deve ser um literal de string.O poder da string de formatação está nos `{}` s contidos.
///
/// Parâmetros adicionais passados para o `format!` substituem os `{}` s dentro da string de formatação na ordem fornecida, a menos que parâmetros nomeados ou posicionais sejam usados;consulte [`std::fmt`] para obter mais informações.
///
///
/// Um uso comum do `format!` é a concatenação e interpolação de strings.
/// A mesma convenção é usada com macros [`print!`] e [`write!`], dependendo do destino pretendido da string.
///
/// Para converter um único valor em uma string, use o método [`to_string`].Isso usará a formatação [`Display`] trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics se uma implementação de formatação de trait retornar um erro.
/// Isso indica uma implementação incorreta, pois o `fmt::Write for String` nunca retorna um erro.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Força o nó AST para uma expressão para melhorar os diagnósticos na posição padrão.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}