//! Uma visualização de tamanho dinâmico em uma sequência contígua, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Fatias são uma vista em um bloco de memória representado como um ponteiro e um comprimento.
//!
//! ```
//! // fatiar um Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // coagir uma matriz a uma fatia
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! As fatias são mutáveis ou compartilhadas.
//! O tipo de fatia compartilhada é `&[T]`, enquanto o tipo de fatia mutável é `&mut [T]`, onde `T` representa o tipo de elemento.
//! Por exemplo, você pode transformar o bloco de memória para o qual uma fatia mutável aponta:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Aqui estão algumas das coisas que este módulo contém:
//!
//! ## Structs
//!
//! Existem várias estruturas que são úteis para fatias, como [`Iter`], que representa a iteração sobre uma fatia.
//!
//! ## Implementações Trait
//!
//! Existem várias implementações de traits comuns para fatias.Alguns exemplos incluem:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], para fatias cujo tipo de elemento é [`Eq`] ou [`Ord`].
//! * [`Hash`] - para fatias cujo tipo de elemento é [`Hash`].
//!
//! ## Iteration
//!
//! As fatias implementam `IntoIterator`.O iterador produz referências aos elementos de fatia.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! A fatia mutável produz referências mutáveis aos elementos:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Esse iterador produz referências mutáveis aos elementos da fatia, portanto, embora o tipo de elemento da fatia seja `i32`, o tipo de elemento do iterador é `&mut i32`.
//!
//!
//! * [`.iter`] e [`.iter_mut`] são os métodos explícitos para retornar os iteradores padrão.
//! * Outros métodos que retornam iteradores são [`.split`], [`.splitn`], [`.chunks`], [`.windows`] e mais.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Muitos dos usos neste módulo são usados apenas na configuração de teste.
// É mais limpo apenas desligar o aviso unused_imports do que corrigi-los.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Métodos básicos de extensão de fatia
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) necessário para a implementação da macro `vec!` durante o teste NB, consulte o módulo `hack` neste arquivo para obter mais detalhes.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) necessário para a implementação do `Vec::clone` durante o teste NB, consulte o módulo `hack` neste arquivo para obter mais detalhes.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Com o cfg(test), o `impl [T]` não está disponível, essas três funções são, na verdade, métodos que estão no `impl [T]`, mas não no `core::slice::SliceExt`, precisamos fornecer essas funções para o teste do `test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Não devemos adicionar atributo embutido a isso, pois isso é usado principalmente na macro `vec!` e causa regressão de desempenho.
    // Consulte #71204 para discussão e resultados de desempenho.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // itens foram marcados como inicializados no loop abaixo
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) é necessário para o LLVM remover as verificações de limites e tem um codegen melhor do que o zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // o vec foi alocado e inicializado acima com pelo menos este comprimento.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // alocado acima com a capacidade de `s` e inicializar para `s.len()` em ptr::copy_to_non_overlapping abaixo.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Classifica a fatia.
    ///
    /// Essa classificação é estável (ou seja, não reordena elementos iguais) e *O*(*n*\*pior caso log(* n*)).
    ///
    /// Quando aplicável, a classificação instável é preferida porque geralmente é mais rápida do que a classificação estável e não aloca memória auxiliar.
    /// Consulte [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Implementação atual
    ///
    /// O algoritmo atual é uma classificação de mesclagem iterativa e adaptativa inspirada no [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Ele é projetado para ser muito rápido nos casos em que a fatia está quase classificada ou consiste em duas ou mais sequências classificadas concatenadas uma após a outra.
    ///
    ///
    /// Além disso, ele aloca armazenamento temporário com metade do tamanho do `self`, mas para fatias curtas, uma classificação de inserção sem alocação é usada.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Classifica a fatia com uma função de comparador.
    ///
    /// Essa classificação é estável (ou seja, não reordena elementos iguais) e *O*(*n*\*pior caso log(* n*)).
    ///
    /// A função de comparador deve definir uma ordem total para os elementos na fatia.Se a ordem não for total, a ordem dos elementos não é especificada.
    /// Um pedido é um pedido total se for (para todos os `a`, `b` e `c`):
    ///
    /// * total e antissimétrico: exatamente um dos `a < b`, `a == b` ou `a > b` é verdadeiro, e
    /// * transitivo, `a < b` e `b < c` implicam em `a < c`.O mesmo deve ser válido para o `==` e o `>`.
    ///
    /// Por exemplo, embora o [`f64`] não implemente o [`Ord`] porque o `NaN != NaN`, podemos usar o `partial_cmp` como nossa função de classificação quando sabemos que a fatia não contém um `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Quando aplicável, a classificação instável é preferida porque geralmente é mais rápida do que a classificação estável e não aloca memória auxiliar.
    /// Consulte [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Implementação atual
    ///
    /// O algoritmo atual é uma classificação de mesclagem iterativa e adaptativa inspirada no [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Ele é projetado para ser muito rápido nos casos em que a fatia está quase classificada ou consiste em duas ou mais sequências classificadas concatenadas uma após a outra.
    ///
    /// Além disso, ele aloca armazenamento temporário com metade do tamanho do `self`, mas para fatias curtas, uma classificação de inserção sem alocação é usada.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // classificação reversa
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Classifica a fatia com uma função de extração de chave.
    ///
    /// Essa classificação é estável (ou seja, não reordena elementos iguais) e *O*(*m*\* * n *\* pior caso log(*n*)), onde a função-chave é *O*(*m*).
    ///
    /// Para funções-chave caras (por exemplo
    /// funções que não são simples acessos de propriedade ou operações básicas), o [`sort_by_cached_key`](slice::sort_by_cached_key) provavelmente será significativamente mais rápido, pois não recalcula as chaves de elemento.
    ///
    ///
    /// Quando aplicável, a classificação instável é preferida porque geralmente é mais rápida do que a classificação estável e não aloca memória auxiliar.
    /// Consulte [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Implementação atual
    ///
    /// O algoritmo atual é uma classificação de mesclagem iterativa e adaptativa inspirada no [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Ele é projetado para ser muito rápido nos casos em que a fatia está quase classificada ou consiste em duas ou mais sequências classificadas concatenadas uma após a outra.
    ///
    /// Além disso, ele aloca armazenamento temporário com metade do tamanho do `self`, mas para fatias curtas, uma classificação de inserção sem alocação é usada.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Classifica a fatia com uma função de extração de chave.
    ///
    /// Durante a classificação, a função-chave é chamada apenas uma vez por elemento.
    ///
    /// Esta classificação é estável (ou seja, não reordena elementos iguais) e *O*(*m*\* * n *+* n *\* pior caso log(*n*)), em que a função principal é *O*(*m*) .
    ///
    /// Para funções de tecla simples (por exemplo, funções que são acessos de propriedade ou operações básicas), o [`sort_by_key`](slice::sort_by_key) provavelmente será mais rápido.
    ///
    /// # Implementação atual
    ///
    /// O algoritmo atual é baseado no [pattern-defeating quicksort][pdqsort] de Orson Peters, que combina o caso médio rápido do quicksort aleatório com o pior caso rápido do heapsort, enquanto obtém o tempo linear em fatias com certos padrões.
    /// Ele usa alguma randomização para evitar casos degenerados, mas com um seed fixo para sempre fornecer um comportamento determinístico.
    ///
    /// No pior caso, o algoritmo aloca armazenamento temporário em um `Vec<(K, usize)>` o comprimento da fatia.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Macro auxiliar para indexar nosso vector pelo menor tipo possível, para reduzir a alocação.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Os elementos do `indices` são exclusivos, pois são indexados, portanto, qualquer tipo será estável em relação à fatia original.
                // Usamos o `sort_unstable` aqui porque requer menos alocação de memória.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Copia o `self` em um novo `Vec`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Aqui, `s` e `x` podem ser modificados independentemente.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Copia o `self` em um novo `Vec` com um alocador.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Aqui, `s` e `x` podem ser modificados independentemente.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, veja o módulo `hack` neste arquivo para mais detalhes.
        hack::to_vec(self, alloc)
    }

    /// Converte `self` em um vector sem clones ou alocação.
    ///
    /// O vector resultante pode ser convertido de volta em uma caixa via `Vec<T>método `into_boxed_slice` do`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` não pode mais ser usado porque foi convertido para `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, veja o módulo `hack` neste arquivo para mais detalhes.
        hack::into_vec(self)
    }

    /// Cria um vector repetindo uma fatia `n` vezes.
    ///
    /// # Panics
    ///
    /// Esta função será panic se a capacidade estourar.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// Um panic após transbordamento:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Se `n` for maior que zero, ele pode ser dividido como `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` é o número representado pelo bit '1' mais à esquerda de `n` e `rem` é a parte restante de `n`.
        //
        //

        // Usando o `Vec` para acessar o `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` a repetição é feita dobrando os tempos `expn` `buf`.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Se for `m > 0`, há bits restantes até o '1' mais à esquerda.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` tem capacidade de `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) a repetição é feita copiando as primeiras repetições `rem` do próprio `buf`.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Isso não se sobrepõe desde o `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` é igual a `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Nivela uma fatia de `T` em um único valor `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Nivela uma fatia de `T` em um único valor `Self::Output`, colocando um determinado separador entre cada um.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Nivela uma fatia de `T` em um único valor `Self::Output`, colocando um determinado separador entre cada um.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Retorna um vector contendo uma cópia desta fatia onde cada byte é mapeado para seu equivalente em maiúsculas ASCII.
    ///
    ///
    /// As letras ASCII 'a' a 'z' são mapeadas para 'A' a 'Z', mas as letras não ASCII permanecem inalteradas.
    ///
    /// Para maiúsculas o valor in-loco, use [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Retorna um vector contendo uma cópia desta fatia onde cada byte é mapeado para seu equivalente ASCII em minúsculas.
    ///
    ///
    /// As letras ASCII 'A' a 'Z' são mapeadas para 'a' a 'z', mas as letras não ASCII permanecem inalteradas.
    ///
    /// Para colocar o valor no local em minúsculas, use [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Extensão traits para fatias sobre tipos específicos de dados
////////////////////////////////////////////////////////////////////////////////

/// Helper trait para [`[T]: : concat`](slice::concat).
///
/// Note: o parâmetro de tipo `Item` não é usado neste trait, mas permite que impls seja mais genérico.
/// Sem ele, obtemos este erro:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Isso ocorre porque pode haver tipos de `V` com vários impls `Borrow<[_]>`, de modo que vários tipos de `T` se apliquem:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// O tipo resultante após a concatenação
    type Output;

    /// Implementação de [`[T]: : concat`](slice::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Helper trait para [`[T]: : join`](slice::join)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// O tipo resultante após a concatenação
    type Output;

    /// Implementação de [`[T]: : join`](slice::join)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Implementações trait padrão para fatias
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // elimine qualquer coisa no destino que não seja sobrescrita
        target.truncate(self.len());

        // target.len <= self.len devido ao truncamento acima, portanto, as fatias aqui estão sempre dentro dos limites.
        //
        let (init, tail) = self.split_at(target.len());

        // reutilize os valores contidos allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Insere `v[0]` na sequência pré-classificada `v[1..]` para que todo o `v[..]` seja classificado.
///
/// Esta é a sub-rotina integral da classificação por inserção.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Existem três maneiras de implementar a inserção aqui:
            //
            // 1. Troque os elementos adjacentes até que o primeiro chegue ao destino final.
            //    No entanto, dessa forma copiamos os dados mais do que o necessário.
            //    Se os elementos forem estruturas grandes (caro para copiar), este método será lento.
            //
            // 2. Repita até que o lugar certo para o primeiro elemento seja encontrado.
            // Em seguida, desloque os elementos que o sucedem para abrir espaço para ele e, finalmente, coloque-o no buraco restante.
            // Este é um bom método.
            //
            // 3. Copie o primeiro elemento em uma variável temporária.Repita até que o lugar certo seja encontrado.
            // À medida que avançamos, copie cada elemento percorrido no slot que o precede.
            // Finalmente, copie os dados da variável temporária para o orifício restante.
            // Este método é muito bom.
            // Os benchmarks demonstraram desempenho ligeiramente melhor do que com o segundo método.
            //
            // Todos os métodos foram avaliados e o terceiro apresentou os melhores resultados.Então escolhemos esse.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // O estado intermediário do processo de inserção é sempre rastreado pelo `hole`, que tem duas finalidades:
            // 1. Protege a integridade do `v` de panics no `is_less`.
            // 2. Preenche o orifício restante no `v` no final.
            //
            // Segurança Panic:
            //
            // Se o `is_less` panics em qualquer ponto durante o processo, o `hole` será descartado e preencherá o buraco no `v` com o `tmp`, garantindo assim que o `v` ainda segure todos os objetos que inicialmente segurava exatamente uma vez.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` é descartado e, portanto, copia o `tmp` no orifício restante do `v`.
        }
    }

    // Quando descartado, copia do `src` para o `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Mescla execuções não decrescentes `v[..mid]` e `v[mid..]` usando `buf` como armazenamento temporário e armazena o resultado no `v[..]`.
///
/// # Safety
///
/// As duas fatias não devem estar vazias e o `mid` deve estar dentro dos limites.
/// O buffer `buf` deve ser longo o suficiente para conter uma cópia da fatia mais curta.
/// Além disso, o `T` não deve ser do tipo tamanho zero.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // O processo de mesclagem primeiro copia a execução mais curta para o `buf`.
    // Em seguida, ele rastreia a execução recém-copiada e a execução mais longa para a frente (ou para trás), comparando seus próximos elementos não consumidos e copiando o menor (ou maior) para o `v`.
    //
    // Assim que a execução mais curta for totalmente consumida, o processo estará concluído.Se a execução mais longa for consumida primeiro, devemos copiar o que sobrou da execução mais curta para o orifício restante no `v`.
    //
    // O estado intermediário do processo é sempre rastreado pelo `hole`, que serve a dois propósitos:
    // 1. Protege a integridade do `v` de panics no `is_less`.
    // 2. Preenche o orifício restante no `v` se a execução mais longa for consumida primeiro.
    //
    // Segurança Panic:
    //
    // Se o `is_less` panics em qualquer ponto durante o processo, o `hole` será descartado e preencherá o buraco no `v` com o intervalo não consumido no `buf`, garantindo assim que o `v` ainda segure todos os objetos que inicialmente segurava exatamente uma vez.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // A corrida à esquerda é mais curta.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Inicialmente, esses ponteiros apontam para o início de seus arrays.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Consumir o lado inferior.
            // Se igual, prefira a corrida para a esquerda para manter a estabilidade.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // A corrida certa é mais curta.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Inicialmente, esses ponteiros apontam para além das extremidades de suas matrizes.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Consuma o lado maior.
            // Se igual, prefira a corrida certa para manter a estabilidade.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Finalmente, o `hole` foi descartado.
    // Se a execução mais curta não foi totalmente consumida, o que restar dele agora será copiado para o furo do `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Quando descartado, copia o intervalo `start..end` para `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` não é um tipo de tamanho zero, portanto, não há problema em dividir por seu tamanho.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Essa classificação de mesclagem pega emprestado algumas (mas não todas) idéias do TimSort, que é descrito em detalhes [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// O algoritmo identifica subseqüências estritamente descendentes e não descendentes, que são chamadas de execuções naturais.Há uma pilha de execuções pendentes a serem mescladas.
/// Cada execução recém-encontrada é colocada na pilha e, em seguida, alguns pares de execuções adjacentes são mesclados até que essas duas invariáveis sejam satisfeitas:
///
/// 1. para cada `i` em `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. para cada `i` em `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// As invariáveis garantem que o tempo total de execução seja *O*(*n*\*pior caso log(* n*)).
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Fatias de até esse comprimento são classificadas usando a classificação por inserção.
    const MAX_INSERTION: usize = 20;
    // Execuções muito curtas são estendidas usando a classificação por inserção para abranger pelo menos esses vários elementos.
    const MIN_RUN: usize = 10;

    // A classificação não tem comportamento significativo em tipos de tamanho zero.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Arrays curtos são classificados no local por meio de classificação por inserção para evitar alocações.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Aloque um buffer para usar como memória temporária.Mantemos o comprimento 0 para que possamos manter nele cópias superficiais do conteúdo do `v` sem arriscar os dtors rodando nas cópias do `is_less` panics.
    //
    // Ao mesclar duas execuções classificadas, esse buffer mantém uma cópia da execução mais curta, que sempre terá comprimento máximo de `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Para identificar execuções naturais no `v`, nós o percorremos de trás para frente.
    // Isso pode parecer uma decisão estranha, mas considere o fato de que as mesclagens costumam ir na direção oposta (forwards).
    // De acordo com os benchmarks, a fusão para a frente é ligeiramente mais rápida do que a fusão para trás.
    // Para concluir, a identificação de execuções percorrendo para trás melhora o desempenho.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Encontre a próxima corrida natural e inverta-a se for estritamente descendente.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Insira mais alguns elementos na execução se for muito curta.
        // A classificação por inserção é mais rápida do que a classificação por mesclagem em sequências curtas, portanto, melhora significativamente o desempenho.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Empurre esta corrida para a pilha.
        runs.push(Run { start, len: end - start });
        end = start;

        // Mescle alguns pares de execuções adjacentes para satisfazer os invariantes.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Finalmente, exatamente uma corrida deve permanecer na pilha.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Examina a pilha de corridas e identifica o próximo par de corridas a ser mesclado.
    // Mais especificamente, se `Some(r)` for retornado, isso significa que `runs[r]` e `runs[r + 1]` devem ser mesclados em seguida.
    // Se o algoritmo continuar criando uma nova execução, `None` será retornado.
    //
    // TimSort é famoso por suas implementações com bugs, conforme descrito aqui:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // A essência da história é: devemos aplicar as invariantes nas quatro primeiras execuções da pilha.
    // Impingi-los apenas nos três primeiros não é suficiente para garantir que os invariantes ainda serão válidos para *todas* as execuções na pilha.
    //
    // Esta função verifica corretamente as invariantes das quatro primeiras execuções.
    // Além disso, se a execução superior começar no índice 0, sempre exigirá uma operação de mesclagem até que a pilha esteja totalmente recolhida, a fim de concluir a classificação.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}