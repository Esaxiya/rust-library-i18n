use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Especialização trait usada para Vec::from_iter
///
/// ## O gráfico de delegação:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Um caso comum é passar um vector para uma função que imediatamente recolhe para um vector.
        // Podemos curto-circuitar isso se o IntoIter não tiver sido avançado.
        // Quando estiver avançado, também podemos reutilizar a memória e mover os dados para a frente.
        // Mas só fazemos isso quando o Vec resultante não teria mais capacidade não utilizada do que criá-lo por meio da implementação genérica de FromIterator teria.
        //
        // Essa limitação não é estritamente necessária, pois o comportamento de alocação de Vec é intencionalmente não especificado.
        // Mas é uma escolha conservadora.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // deve delegar ao spec_extend(), já que o próprio extend() delega a spec_from para Vecs vazios
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Isso utiliza o `iterator.as_slice().to_vec()`, pois spec_extend deve realizar mais etapas para raciocinar sobre a capacidade + comprimento final e, portanto, trabalhar mais.
// `to_vec()` aloca diretamente a quantidade correta e a preenche com exatidão.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): com cfg(test), o método `[T]::to_vec` inerente, que é necessário para esta definição de método, não está disponível.
    // Em vez disso, use a função `slice::to_vec` que está disponível apenas com cfg(test) NB, consulte o módulo slice::hack em slice.rs para obter mais informações
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}