//! Um tipo de array expansível contíguo com conteúdo alocado em heap, escrito em `Vec<T>`.
//!
//! Vectors tem indexação `O(1)`, push `O(1)` amortizado (até o fim) e pop `O(1)` (desde o fim).
//!
//!
//! Vectors garante que eles nunca alocem mais de `isize::MAX` bytes.
//!
//! # Examples
//!
//! Você pode criar explicitamente um [`Vec`] com [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... ou usando a macro [`vec!`]:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // dez zeros
//! ```
//!
//! Você pode [`push`] valores no final de um vector (que aumentará o vector conforme necessário):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Popping valores funcionam da mesma maneira:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors também suporta indexação (através do traits [`Index`] e [`IndexMut`]):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Um tipo de array expansível contíguo, escrito como `Vec<T>` e pronunciado 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// A macro [`vec!`] é fornecida para tornar a inicialização mais conveniente:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Ele também pode inicializar cada elemento de um `Vec<T>` com um determinado valor.
/// Isso pode ser mais eficiente do que realizar a alocação e inicialização em etapas separadas, especialmente ao inicializar um vector de zeros:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // O seguinte é equivalente, mas potencialmente mais lento:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Para obter mais informações, consulte [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Use um `Vec<T>` como uma pilha eficiente:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Imprime 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// O tipo `Vec` permite acessar valores por índice, pois implementa o [`Index`] trait.Um exemplo será mais explícito:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // irá exibir '2'
/// ```
///
/// No entanto, tenha cuidado: se você tentar acessar um índice que não está no `Vec`, seu software será panic!Você não pode fazer isso:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Use [`get`] e [`get_mut`] se quiser verificar se o índice está no `Vec`.
///
/// # Slicing
///
/// Um `Vec` pode ser mutável.Por outro lado, as fatias são objetos somente leitura.
/// Para obter um [slice][prim@slice], use o [`&`].Exemplo:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... e isso é tudo!
/// // você também pode fazer assim:
/// let u: &[usize] = &v;
/// // ou assim:
/// let u: &[_] = &v;
/// ```
///
/// Em Rust, é mais comum passar fatias como argumentos em vez de vectors quando você deseja apenas fornecer acesso de leitura.O mesmo vale para [`String`] e [`&str`].
///
/// # Capacidade e realocação
///
/// A capacidade de um vector é a quantidade de espaço alocado para quaisquer elementos future que serão adicionados ao vector.Isso não deve ser confundido com o *comprimento* de um vector, que especifica o número de elementos reais dentro do vector.
/// Se o comprimento de um vector exceder sua capacidade, sua capacidade será automaticamente aumentada, mas seus elementos terão que ser realocados.
///
/// Por exemplo, um vector com capacidade 10 e comprimento 0 seria um vector vazio com espaço para mais 10 elementos.Empurrar 10 ou menos elementos para o vector não mudará sua capacidade nem fará com que ocorra a realocação.
/// No entanto, se o comprimento do vector for aumentado para 11, ele terá que realocar, o que pode ser lento.Por esse motivo, é recomendado usar o [`Vec::with_capacity`] sempre que possível para especificar o tamanho que se espera que o vector alcance.
///
/// # Guarantees
///
/// Devido à sua natureza incrivelmente fundamental, o `Vec` oferece muitas garantias sobre seu design.Isso garante que seja o mais baixo overhead possível no caso geral e possa ser manipulado corretamente de maneiras primitivas por código inseguro.Observe que essas garantias se referem a um `Vec<T>` não qualificado.
/// Se parâmetros de tipo adicionais forem adicionados (por exemplo, para oferecer suporte a alocadores personalizados), a substituição de seus padrões pode alterar o comportamento.
///
/// Mais fundamentalmente, o `Vec` é e sempre será um trio (ponteiro, capacidade, comprimento).Nem mais nem menos.A ordem desses campos não é especificada e você deve usar os métodos apropriados para modificá-los.
/// O ponteiro nunca será nulo, portanto, este tipo é otimizado para ponteiro nulo.
///
/// No entanto, o ponteiro pode não apontar realmente para a memória alocada.
/// Em particular, se você construir um `Vec` com capacidade 0 por meio de [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], ou chamando [`shrink_to_fit`] em um Vec vazio, ele não alocará memória.Da mesma forma, se você armazenar tipos de tamanho zero dentro de um `Vec`, ele não alocará espaço para eles.
/// *Observe que, neste caso, o `Vec` pode não relatar um [`capacity`] de 0*.
/// `Vec` irá alocar se e somente se [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Em geral, os detalhes de alocação de `Vec` são muito sutis-se você pretende alocar memória usando um `Vec` e usá-lo para outra coisa (para passar para um código inseguro ou para construir sua própria coleção baseada em memória), certifique-se para desalocar essa memória usando o `from_raw_parts` para recuperar o `Vec` e, em seguida, descartá-lo.
///
/// Se um `Vec`*tiver* memória alocada, então a memória para a qual ele aponta está no heap (conforme definido pelo alocador Rust é configurado para usar por padrão), e seu ponteiro aponta para [`len`] inicializado, elementos contíguos em ordem (o que você faria veja se você o coagiu para um slice), seguido por [`capacity`]`,`[`len`] logicamente não inicializado, elementos contíguos.
///
///
/// Um vector contendo os elementos `'a'` e `'b'` com capacidade 4 pode ser visualizado conforme abaixo.A parte superior é a estrutura `Vec`, que contém um ponteiro para o cabeçalho da alocação no heap, comprimento e capacidade.
/// A parte inferior é a alocação no heap, um bloco de memória contíguo.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** representa a memória que não foi inicializada, consulte [`MaybeUninit`].
/// - Note: a ABI não é estável e o `Vec` não oferece garantias sobre o layout da memória (incluindo a ordem dos campos).
///
/// `Vec` nunca executará um "small optimization" onde os elementos são realmente armazenados na pilha por dois motivos:
///
/// * Isso tornaria mais difícil para um código não seguro manipular corretamente um `Vec`.O conteúdo de um `Vec` não teria um endereço estável se apenas fosse movido, e seria mais difícil determinar se um `Vec` realmente alocou memória.
///
/// * Isso penalizaria o caso geral, incorrendo em um branch adicional em cada acesso.
///
/// `Vec` nunca encolherá automaticamente, mesmo se estiver completamente vazio.Isso garante que não ocorram alocações ou desalocações desnecessárias.Esvaziar um `Vec` e, em seguida, enchê-lo de volta com o mesmo [`len`] não deve gerar chamadas para o alocador.Se você deseja liberar memória não utilizada, use [`shrink_to_fit`] ou [`shrink_to`].
///
/// [`push`] e o [`insert`] nunca (re) alocará se a capacidade relatada for suficiente.[`push`] e [`insert`]*irão*(re) alocar se [`len`]`==`[`capacidade`].Ou seja, a capacidade relatada é totalmente precisa e confiável.Ele pode até ser usado para liberar manualmente a memória alocada por um `Vec`, se desejado.
/// Os métodos de inserção em massa *podem* ser realocados, mesmo quando não são necessários.
///
/// `Vec` não garante nenhuma estratégia de crescimento particular ao realocar quando cheio, nem quando [`reserve`] é chamado.A estratégia atual é básica e pode ser desejável usar um fator de crescimento não constante.Qualquer estratégia usada irá certamente garantir *O*(1) [`push`] amortizado.
///
/// `vec![x; n]`, O `vec![a, b, c, d]` e o [`Vec::with_capacity(n)`][`Vec::with_capacity`] produzirão um `Vec` com exatamente a capacidade solicitada.
/// Se [`len`]`==`[`capacity`], (como é o caso da macro [`vec!`]), um `Vec<T>` pode ser convertido de e para um [`Box<[T]>`][owned slice] sem realocar ou mover os elementos.
///
/// `Vec` não sobrescreverá especificamente nenhum dado removido dele, mas também não os preservará especificamente.Sua memória não inicializada é um espaço de rascunho que pode usar como quiser.Geralmente, ele fará apenas o que for mais eficiente ou fácil de implementar.Não confie em dados removidos para serem apagados para fins de segurança.
/// Mesmo se você descartar um `Vec`, seu buffer pode simplesmente ser reutilizado por outro `Vec`.
/// Mesmo se você zerar a memória de um `Vec` primeiro, isso pode não acontecer porque o otimizador não considera isso um efeito colateral que deve ser preservado.
/// No entanto, há um caso que não resolveremos: usar o código `unsafe` para gravar na capacidade excedente e, em seguida, aumentar o comprimento para corresponder, é sempre válido.
///
/// Atualmente, o `Vec` não garante a ordem em que os elementos são eliminados.
/// A ordem mudou no passado e pode mudar novamente.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Métodos inerentes
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Constrói um novo `Vec<T>` vazio.
    ///
    /// O vector não será alocado até que os elementos sejam inseridos nele.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Constrói um novo `Vec<T>` vazio com a capacidade especificada.
    ///
    /// O vector será capaz de conter exatamente elementos `capacity` sem realocação.
    /// Se `capacity` for 0, o vector não fará a alocação.
    ///
    /// É importante notar que embora o vector retornado tenha a *capacidade* especificada, o vector terá um comprimento *zero*.
    ///
    /// Para obter uma explicação da diferença entre comprimento e capacidade, consulte *[Capacidade e realocação]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // O vector não contém itens, embora tenha capacidade para mais
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Tudo isso é feito sem realocar ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... mas isso pode fazer o vector realocar
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Cria um `Vec<T>` diretamente dos componentes brutos de outro vector.
    ///
    /// # Safety
    ///
    /// Isso é altamente inseguro, devido ao número de invariantes que não são verificados:
    ///
    /// * `ptr` precisa ter sido alocado anteriormente via [`String`]/`Vec<T>`(pelo menos, é altamente provável que esteja incorreto se não estiver).
    /// * `T` precisa ter o mesmo tamanho e alinhamento com os quais o `ptr` foi alocado.
    ///   (`T` com um alinhamento menos estrito não é suficiente, o alinhamento realmente precisa ser igual para satisfazer o requisito do [`dealloc`] de que a memória deve ser alocada e desalocada com o mesmo layout.)
    ///
    /// * `length` precisa ser menor ou igual a `capacity`.
    /// * `capacity` precisa ser a capacidade com a qual o ponteiro foi alocado.
    ///
    /// Violá-los pode causar problemas como corromper as estruturas de dados internas do alocador.Por exemplo,**não** é seguro construir um `Vec<u8>` a partir de um ponteiro para um array C `char` com comprimento `size_t`.
    /// Também não é seguro construir um a partir de um `Vec<u16>` e seu comprimento, porque o alocador se preocupa com o alinhamento e esses dois tipos têm alinhamentos diferentes.
    /// O buffer foi alocado com o alinhamento 2 (para `u16`), mas após transformá-lo em um `Vec<u8>` ele será desalocado com o alinhamento 1.
    ///
    /// A propriedade do `ptr` é efetivamente transferida para o `Vec<T>`, que pode então desalocar, realocar ou alterar o conteúdo da memória apontado pelo ponteiro à vontade.
    /// Certifique-se de que nada mais use o ponteiro após chamar esta função.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Atualize quando vec_into_raw_parts estiver estabilizado.
    ///     // Impedir a execução do destruidor de `v` para que tenhamos controle total da alocação.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Retire as várias informações importantes sobre o `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Substituir memória com 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Coloque tudo de volta em um Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Constrói um novo `Vec<T, A>` vazio.
    ///
    /// O vector não será alocado até que os elementos sejam inseridos nele.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Constrói um novo `Vec<T, A>` vazio com a capacidade especificada com o alocador fornecido.
    ///
    /// O vector será capaz de conter exatamente elementos `capacity` sem realocação.
    /// Se `capacity` for 0, o vector não fará a alocação.
    ///
    /// É importante notar que embora o vector retornado tenha a *capacidade* especificada, o vector terá um comprimento *zero*.
    ///
    /// Para obter uma explicação da diferença entre comprimento e capacidade, consulte *[Capacidade e realocação]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // O vector não contém itens, embora tenha capacidade para mais
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Tudo isso é feito sem realocar ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... mas isso pode fazer o vector realocar
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Cria um `Vec<T, A>` diretamente dos componentes brutos de outro vector.
    ///
    /// # Safety
    ///
    /// Isso é altamente inseguro, devido ao número de invariantes que não são verificados:
    ///
    /// * `ptr` precisa ter sido alocado anteriormente via [`String`]/`Vec<T>`(pelo menos, é altamente provável que esteja incorreto se não estiver).
    /// * `T` precisa ter o mesmo tamanho e alinhamento com os quais o `ptr` foi alocado.
    ///   (`T` com um alinhamento menos estrito não é suficiente, o alinhamento realmente precisa ser igual para satisfazer o requisito do [`dealloc`] de que a memória deve ser alocada e desalocada com o mesmo layout.)
    ///
    /// * `length` precisa ser menor ou igual a `capacity`.
    /// * `capacity` precisa ser a capacidade com a qual o ponteiro foi alocado.
    ///
    /// Violá-los pode causar problemas como corromper as estruturas de dados internas do alocador.Por exemplo,**não** é seguro construir um `Vec<u8>` a partir de um ponteiro para um array C `char` com comprimento `size_t`.
    /// Também não é seguro construir um a partir de um `Vec<u16>` e seu comprimento, porque o alocador se preocupa com o alinhamento e esses dois tipos têm alinhamentos diferentes.
    /// O buffer foi alocado com o alinhamento 2 (para `u16`), mas após transformá-lo em um `Vec<u8>` ele será desalocado com o alinhamento 1.
    ///
    /// A propriedade do `ptr` é efetivamente transferida para o `Vec<T>`, que pode então desalocar, realocar ou alterar o conteúdo da memória apontado pelo ponteiro à vontade.
    /// Certifique-se de que nada mais use o ponteiro após chamar esta função.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Atualize quando vec_into_raw_parts estiver estabilizado.
    ///     // Impedir a execução do destruidor de `v` para que tenhamos controle total da alocação.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Retire as várias informações importantes sobre o `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Substituir memória com 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Coloque tudo de volta em um Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Decompõe um `Vec<T>` em seus componentes brutos.
    ///
    /// Retorna o ponteiro bruto para os dados subjacentes, o comprimento do vector (em elementos) e a capacidade alocada dos dados (em elementos).
    /// Esses são os mesmos argumentos na mesma ordem que os argumentos para [`from_raw_parts`].
    ///
    /// Depois de chamar esta função, o chamador é responsável pela memória anteriormente gerenciada pelo `Vec`.
    /// A única maneira de fazer isso é converter o ponteiro bruto, o comprimento e a capacidade de volta em um `Vec` com a função [`from_raw_parts`], permitindo que o destruidor execute a limpeza.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Agora podemos fazer alterações nos componentes, como transmutar o ponteiro bruto para um tipo compatível.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Decompõe um `Vec<T>` em seus componentes brutos.
    ///
    /// Retorna o ponteiro bruto para os dados subjacentes, o comprimento do vector (em elementos), a capacidade alocada dos dados (em elementos) e o alocador.
    /// Esses são os mesmos argumentos na mesma ordem que os argumentos para [`from_raw_parts_in`].
    ///
    /// Depois de chamar esta função, o chamador é responsável pela memória anteriormente gerenciada pelo `Vec`.
    /// A única maneira de fazer isso é converter o ponteiro bruto, o comprimento e a capacidade de volta em um `Vec` com a função [`from_raw_parts_in`], permitindo que o destruidor execute a limpeza.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Agora podemos fazer alterações nos componentes, como transmutar o ponteiro bruto para um tipo compatível.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Retorna o número de elementos que vector pode conter sem realocar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Reserva capacidade para pelo menos `additional` mais elementos a serem inseridos no `Vec<T>` fornecido.
    /// A coleção pode reservar mais espaço para evitar realocações frequentes.
    /// Depois de chamar `reserve`, a capacidade será maior ou igual a `self.len() + additional`.
    /// Não faz nada se a capacidade já for suficiente.
    ///
    /// # Panics
    ///
    /// Panics se a nova capacidade exceder `isize::MAX` bytes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Reserva a capacidade mínima para exatamente `additional` mais elementos a serem inseridos no `Vec<T>` fornecido.
    ///
    /// Depois de chamar `reserve_exact`, a capacidade será maior ou igual a `self.len() + additional`.
    /// Não faz nada se a capacidade já for suficiente.
    ///
    /// Observe que o alocador pode fornecer à coleção mais espaço do que ele solicita.
    /// Portanto, a capacidade não pode ser considerada precisamente mínima.
    /// Prefira `reserve` se inserções future são esperadas.
    ///
    /// # Panics
    ///
    /// Panics se a nova capacidade ultrapassar `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Tenta reservar capacidade para pelo menos `additional` mais elementos a serem inseridos no `Vec<T>` fornecido.
    /// A coleção pode reservar mais espaço para evitar realocações frequentes.
    /// Depois de chamar `try_reserve`, a capacidade será maior ou igual a `self.len() + additional`.
    /// Não faz nada se a capacidade já for suficiente.
    ///
    /// # Errors
    ///
    /// Se a capacidade estourar ou o alocador relatar uma falha, um erro será retornado.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Pré-reserve a memória, saindo se não pudermos
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Agora sabemos que isso não OOM no meio de nosso trabalho complexo
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // muito complicado
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Tenta reservar a capacidade mínima para exatamente os elementos `additional` a serem inseridos no `Vec<T>` fornecido.
    /// Depois de chamar `try_reserve_exact`, a capacidade será maior ou igual a `self.len() + additional` se ele retornar `Ok(())`.
    ///
    /// Não faz nada se a capacidade já for suficiente.
    ///
    /// Observe que o alocador pode fornecer à coleção mais espaço do que ele solicita.
    /// Portanto, a capacidade não pode ser considerada precisamente mínima.
    /// Prefira `reserve` se inserções future são esperadas.
    ///
    /// # Errors
    ///
    /// Se a capacidade estourar ou o alocador relatar uma falha, um erro será retornado.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Pré-reserve a memória, saindo se não pudermos
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Agora sabemos que isso não OOM no meio de nosso trabalho complexo
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // muito complicado
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Reduz a capacidade do vector tanto quanto possível.
    ///
    /// Ele cairá o mais próximo possível do comprimento, mas o alocador ainda pode informar ao vector que há espaço para mais alguns elementos.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // A capacidade nunca é menor que o comprimento, e não há nada a fazer quando eles são iguais, então podemos evitar o case panic no `RawVec::shrink_to_fit` apenas chamando-o com uma capacidade maior.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Reduz a capacidade do vector com um limite inferior.
    ///
    /// A capacidade permanecerá pelo menos tão grande quanto o comprimento e o valor fornecido.
    ///
    ///
    /// Se a capacidade atual for menor que o limite inferior, este é um ambiente autônomo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Converte o vector em [`Box<[T]>`][owned slice].
    ///
    /// Observe que isso eliminará qualquer excesso de capacidade.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Qualquer excesso de capacidade é removido:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Encurta o vector, mantendo os primeiros elementos `len` e eliminando o resto.
    ///
    /// Se `len` for maior que o comprimento atual do vector, isso não terá efeito.
    ///
    /// O método [`drain`] pode emular o `truncate`, mas faz com que os elementos em excesso sejam retornados em vez de descartados.
    ///
    ///
    /// Observe que este método não tem efeito na capacidade alocada do vector.
    ///
    /// # Examples
    ///
    /// Truncando um vector de cinco elementos em dois elementos:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Nenhum truncamento ocorre quando `len` é maior que o comprimento atual do vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Truncando quando `len == 0` é equivalente a chamar o método [`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Isso é seguro porque:
        //
        // * a fatia passada para o `drop_in_place` é válida;o caso `len > self.len` evita a criação de uma fatia inválida e
        // * o `len` do vector é reduzido antes de chamar o `drop_in_place`, de forma que nenhum valor seja descartado duas vezes no caso de `drop_in_place` ser para panic uma vez (se for panics duas vezes, o programa é abortado).
        //
        //
        //
        unsafe {
            // Note: É intencional que este seja o `>` e não o `>=`.
            //       Mudá-lo para `>=` tem implicações negativas no desempenho em alguns casos.
            //       Consulte #78884 para obter mais informações.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Extrai uma fatia contendo todo o vector.
    ///
    /// Equivalente a `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Extrai uma fatia mutável de todo o vector.
    ///
    /// Equivalente a `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Retorna um ponteiro bruto para o buffer do vector.
    ///
    /// O chamador deve garantir que o vector sobreviva ao ponteiro que esta função retorna, ou então ele acabará apontando para o lixo.
    /// Modificar o vector pode fazer com que seu buffer seja realocado, o que também tornaria quaisquer ponteiros para ele inválidos.
    ///
    /// O chamador também deve garantir que a memória para a qual o ponteiro (non-transitively) aponta nunca seja gravada (exceto dentro de um `UnsafeCell`) usando esse ponteiro ou qualquer ponteiro derivado dele.
    /// Se você precisar alterar o conteúdo da fatia, use o [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Sombreamos o método slice de mesmo nome para evitar passar pelo `deref`, que cria uma referência intermediária.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Retorna um ponteiro mutável inseguro para o buffer do vector.
    ///
    /// O chamador deve garantir que o vector sobreviva ao ponteiro que esta função retorna, ou então ele acabará apontando para o lixo.
    ///
    /// Modificar o vector pode fazer com que seu buffer seja realocado, o que também tornaria quaisquer ponteiros para ele inválidos.
    ///
    /// # Examples
    ///
    /// ```
    /// // Aloque vector grande o suficiente para 4 elementos.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Inicialize os elementos por meio de gravações de ponteiro brutas e defina o comprimento
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Sombreamos o método slice de mesmo nome para evitar passar pelo `deref_mut`, que cria uma referência intermediária.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Retorna uma referência ao alocador subjacente.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Força o comprimento do vector a `new_len`.
    ///
    /// Esta é uma operação de baixo nível que não mantém nenhum dos invariantes normais do tipo.
    /// Normalmente, a alteração do comprimento de um vector é feita usando uma das operações seguras, como [`truncate`], [`resize`], [`extend`] ou [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` deve ser menor ou igual a [`capacity()`].
    /// - Os elementos em `old_len..new_len` devem ser inicializados.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Este método pode ser útil para situações em que o vector está servindo como um buffer para outro código, particularmente sobre FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Este é apenas um esqueleto mínimo para o exemplo de doc;
    /// # // não use isso como um ponto de partida para uma biblioteca real.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // De acordo com os documentos do método FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // SEGURANÇA: Quando `deflateGetDictionary` retorna `Z_OK`, ele garante que:
    ///     // 1. `dict_length` elementos foram inicializados.
    ///     // 2.
    ///     // `dict_length` <=a capacidade do (32_768) que torna o `set_len` seguro para chamadas.
    ///     unsafe {
    ///         // Faça a chamada FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... e atualize o comprimento para o que foi inicializado.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Embora o exemplo a seguir seja válido, há um vazamento de memória, pois os vectors internos não foram liberados antes da chamada do `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` está vazio, portanto, nenhum elemento precisa ser inicializado.
    /// // 2. `0 <= capacity` sempre contém tudo o que o `capacity` é.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Normalmente, aqui, seria usado o [`clear`] para descartar corretamente o conteúdo e, portanto, não vazar memória.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Remove um elemento do vector e o retorna.
    ///
    /// O elemento removido é substituído pelo último elemento do vector.
    ///
    /// Isso não preserva o pedido, mas é O(1).
    ///
    /// # Panics
    ///
    /// Panics se `index` estiver fora dos limites.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Substituímos self [index] pelo último elemento.
            // Observe que se a verificação de limites acima for bem-sucedida, deve haver um último elemento (que pode ser o próprio [índice]).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Insere um elemento na posição `index` dentro do vector, deslocando todos os elementos depois dele para a direita.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // espaço para o novo elemento
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // infalível O local para colocar o novo valor
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Mude tudo para abrir espaço.
                // (Duplicando o elemento `índice` em duas casas consecutivas.)
                ptr::copy(p, p.offset(1), len - index);
                // Escreva, sobrescrevendo a primeira cópia do elemento `index`.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Remove e retorna o elemento na posição `index` dentro do vector, deslocando todos os elementos após ele para a esquerda.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `index` estiver fora dos limites.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // o lugar de onde estamos tirando.
                let ptr = self.as_mut_ptr().add(index);
                // copie-o, sem segurança ter uma cópia do valor na pilha e no vector ao mesmo tempo.
                //
                ret = ptr::read(ptr);

                // Mude tudo para baixo para preencher esse ponto.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Retém apenas os elementos especificados pelo predicado.
    ///
    /// Em outras palavras, remova todos os elementos `e` de forma que `f(&e)` retorne `false`.
    /// Esse método opera no local, visitando cada elemento exatamente uma vez na ordem original e preserva a ordem dos elementos retidos.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Como os elementos são visitados exatamente uma vez na ordem original, o estado externo pode ser usado para decidir quais elementos manter.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Evite a queda dupla se a proteção contra queda não for executada, pois podemos fazer alguns furos durante o processo.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-len processado-> |^-próximo a verificar
        //                  | <-cnt excluído-> |
        //      | <-original_len-> |Kept: Elementos cujo predicado retorna verdadeiro.
        //
        // Furo: Slot do elemento movido ou eliminado.
        // Desmarcado: Elementos válidos não verificados.
        //
        // Este protetor contra queda será invocado quando o predicado ou `drop` do elemento entrar em pânico.
        // Ele muda os elementos não verificados para cobrir os orifícios e o `set_len` para o comprimento correto.
        // Nos casos em que o predicado e o `drop` nunca entram em pânico, ele será otimizado.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // SEGURANÇA: Itens finais não verificados devem ser válidos, pois nunca tocamos neles.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // SEGURANÇA: Após preencher os orifícios, todos os itens ficam na memória contígua.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // SEGURANÇA: O elemento não verificado deve ser válido.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Avance cedo para evitar a queda dupla se o `drop_in_place` entrar em pânico.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // SEGURANÇA: Nós nunca tocamos neste elemento novamente depois de cair.
                unsafe { ptr::drop_in_place(cur) };
                // Já avançamos o contador.
                continue;
            }
            if g.deleted_cnt > 0 {
                // SEGURANÇA: `deleted_cnt`> 0, então o slot do orifício não deve se sobrepor ao elemento atual.
                // Usamos cópia para mover e nunca mais tocamos neste elemento.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Todos os itens são processados.Isso pode ser otimizado para `set_len` pelo LLVM.
        drop(g);
    }

    /// Remove todos, exceto o primeiro dos elementos consecutivos no vector que resolvem para a mesma chave.
    ///
    ///
    /// Se o vector for classificado, isso remove todas as duplicatas.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Remove todos, exceto o primeiro dos elementos consecutivos no vector que satisfazem uma dada relação de igualdade.
    ///
    /// A função `same_bucket` recebe referências a dois elementos do vector e deve determinar se os elementos são iguais.
    /// Os elementos são passados na ordem oposta de sua ordem na fatia, portanto, se `same_bucket(a, b)` retornar `true`, `a` será removido.
    ///
    ///
    /// Se o vector for classificado, isso remove todas as duplicatas.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Acrescenta um elemento ao final de uma coleção.
    ///
    /// # Panics
    ///
    /// Panics se a nova capacidade exceder `isize::MAX` bytes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Isso irá panic ou abortará se alocarmos> isize::MAX bytes ou se o incremento de comprimento estourar para tipos de tamanho zero.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Remove o último elemento de um vector e o retorna, ou [`None`] se estiver vazio.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Move todos os elementos do `other` para o `Self`, deixando o `other` vazio.
    ///
    /// # Panics
    ///
    /// Panics se o número de elementos no vector estourar um `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Acrescenta elementos ao `Self` de outro buffer.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Cria um iterador de drenagem que remove o intervalo especificado no vector e produz os itens removidos.
    ///
    /// Quando o iterador **é** eliminado, todos os elementos no intervalo são removidos do vector, mesmo se o iterador não foi totalmente consumido.
    /// Se o iterador **não** for descartado (com o [`mem::forget`], por exemplo), não é especificado quantos elementos são removidos.
    ///
    /// # Panics
    ///
    /// Panics se o ponto inicial for maior que o ponto final ou se o ponto final for maior que o comprimento do vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Uma faixa completa limpa o vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Segurança de memória
        //
        // Quando o Drain é criado pela primeira vez, ele encurta o comprimento do vector de origem para garantir que nenhum elemento não inicializado ou movido esteja acessível se o destruidor do Drain nunca for executado.
        //
        //
        // Drain eliminará em ptr::read os valores a serem removidos.
        // Quando terminar, a cauda restante do vec é copiada de volta para cobrir o buraco, e o comprimento vector é restaurado para o novo comprimento.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // defina o comprimento self.vec para iniciar, para ser seguro no caso de vazamento de Drain
            self.set_len(start);
            // Use o empréstimo no IterMut para indicar o comportamento de empréstimo de todo o iterador Drain (como &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Limpa o vector, removendo todos os valores.
    ///
    /// Observe que este método não tem efeito na capacidade alocada do vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Retorna o número de elementos no vector, também conhecido como 'length'.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Retorna `true` se o vector não contiver elementos.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Divide a coleção em duas no índice fornecido.
    ///
    /// Retorna um vector recém-alocado contendo os elementos no intervalo `[at, len)`.
    /// Após a chamada, o vector original ficará contendo os elementos `[0, at)` com sua capacidade anterior inalterada.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // o novo vector pode assumir o controle do buffer original e evitar a cópia
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Não seguro `set_len` e copie itens para `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Redimensiona o `Vec` no local para que `len` seja igual a `new_len`.
    ///
    /// Se `new_len` for maior que `len`, o `Vec` é estendido pela diferença, com cada slot adicional preenchido com o resultado de chamar o `f` de fechamento.
    ///
    /// Os valores de retorno do `f` terminarão no `Vec` na ordem em que foram gerados.
    ///
    /// Se `new_len` for menor que `len`, o `Vec` será simplesmente truncado.
    ///
    /// Este método usa um fechamento para criar novos valores em cada push.Se você preferir [`Clone`] um determinado valor, use [`Vec::resize`].
    /// Se quiser usar o [`Default`] trait para gerar valores, você pode passar [`Default::default`] como o segundo argumento.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Consome e vaza o `Vec`, retornando uma referência mutável ao conteúdo, `&'a mut [T]`.
    /// Observe que o tipo `T` deve durar mais que a vida útil `'a` escolhida.
    /// Se o tipo tiver apenas referências estáticas ou nenhuma, então isso pode ser escolhido como `'static`.
    ///
    /// Esta função é semelhante à função do [`leak`][Box::leak] no [`Box`], exceto que não há como recuperar a memória perdida.
    ///
    ///
    /// Esta função é útil principalmente para dados que duram o resto da vida do programa.
    /// Eliminar a referência retornada causará um vazamento de memória.
    ///
    /// # Examples
    ///
    /// Uso simples:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Retorna a capacidade sobressalente restante do vector como uma fatia do `MaybeUninit<T>`.
    ///
    /// A fatia retornada pode ser usada para preencher o vector com dados (por exemplo
    /// lendo de um arquivo) antes de marcar os dados como inicializados usando o método [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Aloque vector grande o suficiente para 10 elementos.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Preencha os 3 primeiros elementos.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Marque os primeiros 3 elementos do vector como sendo inicializados.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Este método não é implementado em termos de `split_at_spare_mut`, para evitar a invalidação de ponteiros para o buffer.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Retorna o conteúdo vector como uma fatia de `T`, junto com a capacidade sobressalente restante do vector como uma fatia de `MaybeUninit<T>`.
    ///
    /// A fatia de capacidade sobressalente retornada pode ser usada para preencher o vector com dados (por exemplo, lendo de um arquivo) antes de marcar os dados como inicializados usando o método [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Observe que esta é uma API de baixo nível, que deve ser usada com cuidado para fins de otimização.
    /// Se precisar anexar dados a um `Vec`, você pode usar [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] ou [`resize_with`], dependendo de suas necessidades exatas.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Reserve espaço adicional grande o suficiente para 10 elementos.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Preencha os próximos 4 elementos.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Marque os 4 elementos do vector como sendo inicializados.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len é ignorado e nunca alterado
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Segurança: alterar retornado .2 (&mut usize) é considerado o mesmo que chamar `.set_len(_)`.
    ///
    /// Este método é usado para ter acesso exclusivo a todas as peças vec de uma vez no `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` tem garantia de ser válido para elementos `len`
        // - `spare_ptr` está apontando um elemento além do buffer, para que não se sobreponha ao `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Redimensiona o `Vec` no local para que `len` seja igual a `new_len`.
    ///
    /// Se `new_len` for maior que `len`, o `Vec` será estendido pela diferença, com cada slot adicional preenchido com `value`.
    ///
    /// Se `new_len` for menor que `len`, o `Vec` será simplesmente truncado.
    ///
    /// Este método requer que o `T` implemente o [`Clone`], para poder clonar o valor passado.
    /// Se você precisar de mais flexibilidade (ou quiser contar com o [`Default`] em vez do [`Clone`]), use o [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Clona e anexa todos os elementos em uma fatia ao `Vec`.
    ///
    /// Itera sobre a fatia `other`, clona cada elemento e, em seguida, anexa-o a este `Vec`.
    /// O `other` vector é percorrido em ordem.
    ///
    /// Observe que esta função é a mesma do [`extend`], exceto que é especializada para trabalhar com fatias.
    ///
    /// Se e quando Rust obtiver a especialização, essa função provavelmente ficará obsoleta (mas ainda estará disponível).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Copia elementos do intervalo `src` até o final do vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` garante que o intervalo fornecido é válido para a auto-indexação
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Este código generaliza o `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Estenda o vector em valores `n`, usando o gerador fornecido.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Use SetLenOnDrop para contornar o bug em que o compilador pode não perceber que o armazenamento por meio de `ptr` a self.set_len() não faz alias.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Escreva todos os elementos exceto o último
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Aumente o comprimento em cada etapa no caso next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Podemos escrever o último elemento diretamente sem clonar desnecessariamente
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len definido pelo protetor de escopo
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Remove elementos repetidos consecutivos no vector de acordo com a implementação do [`PartialEq`] trait.
    ///
    ///
    /// Se o vector for classificado, isso remove todas as duplicatas.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Métodos e funções internos
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` precisa ser um índice válido
    /// - `self.capacity() - self.len()` deve ser `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len é aumentado apenas após a inicialização de elementos
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - o chamador garante que src é um índice válido
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - O elemento foi inicializado apenas com o `MaybeUninit::write`, então está tudo bem para aumentar o len
            // - len é aumentado após cada elemento para evitar vazamentos (consulte o problema #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - chamador garante que `src` é um índice válido
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Ambos os ponteiros são criados a partir de referências de fatia exclusivas (`&mut [_]`) para que sejam válidos e não se sobreponham.
            //
            // - Os elementos são: Copiar, portanto, não há problema em copiá-los, sem fazer nada com os valores originais
            // - `count` é igual ao comprimento de `source`, então a fonte é válida para leituras `count`
            // - `.reserve(count)` garante que `spare.len() >= count` tão sobressalente é válido para gravações `count`
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Os elementos foram inicializados apenas pelo `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Implementações trait comuns para Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): com cfg(test), o método `[T]::to_vec` inerente, que é necessário para esta definição de método, não está disponível.
    // Em vez disso, use a função `slice::to_vec` que está disponível apenas com cfg(test) NB, consulte o módulo slice::hack em slice.rs para obter mais informações
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // elimine tudo o que não será sobrescrito
        self.truncate(other.len());

        // self.len <= other.len devido ao truncamento acima, portanto, as fatias aqui estão sempre dentro dos limites.
        //
        let (init, tail) = other.split_at(self.len());

        // reutilize os valores contidos allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Cria um iterador de consumo, ou seja, aquele que move cada valor para fora do vector (do início ao fim).
    /// O vector não pode ser usado depois de chamar isso.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s tem tipo String, não &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // método folha ao qual várias implementações SpecFrom/SpecExtend delegam quando não têm mais otimizações para aplicar
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Esse é o caso de um iterador geral.
        //
        // Esta função deve ser moralmente equivalente a:
        //
        //      para o item no iterador {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB não pode estourar, pois teríamos que alocar o espaço de endereço
                self.set_len(len + 1);
            }
        }
    }

    /// Cria um iterador de splicing que substitui o intervalo especificado no vector pelo iterador `replace_with` fornecido e produz os itens removidos.
    ///
    /// `replace_with` não precisa ter o mesmo comprimento que `range`.
    ///
    /// `range` é removido mesmo se o iterador não for consumido até o final.
    ///
    /// Não é especificado quantos elementos são removidos do vector se o valor `Splice` vazar.
    ///
    /// O iterador de entrada `replace_with` é consumido apenas quando o valor de `Splice` é descartado.
    ///
    /// Isso é ideal se:
    ///
    /// * A cauda (elementos no vector após `range`) está vazia,
    /// * ou `replace_with` produz menos elementos ou iguais do que o comprimento de `intervalo`
    /// * ou o limite inferior de seu `size_hint()` é exato.
    ///
    /// Caso contrário, um vector temporário é alocado e a cauda é movida duas vezes.
    ///
    /// # Panics
    ///
    /// Panics se o ponto inicial for maior que o ponto final ou se o ponto final for maior que o comprimento do vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Cria um iterador que usa um encerramento para determinar se um elemento deve ser removido.
    ///
    /// Se o encerramento retornar verdadeiro, o elemento será removido e gerado.
    /// Se o fechamento retornar falso, o elemento permanecerá no vector e não será gerado pelo iterador.
    ///
    /// Usar este método é equivalente ao seguinte código:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // seu código aqui
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Mas o `drain_filter` é mais fácil de usar.
    /// `drain_filter` também é mais eficiente, porque pode retroceder os elementos da matriz em massa.
    ///
    /// Observe que o `drain_filter` também permite que você modifique cada elemento no fechamento do filtro, independentemente de você optar por mantê-lo ou removê-lo.
    ///
    ///
    /// # Examples
    ///
    /// Dividindo uma matriz em pares e probabilidades, reutilizando a alocação original:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Proteja-se contra vazamentos (amplificação de vazamento)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Estenda a implementação que copia elementos de referências antes de colocá-los no Vec.
///
/// Essa implementação é especializada para iteradores de fatia, onde usa o [`copy_from_slice`] para anexar a fatia inteira de uma vez.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Comparação de implementos de vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Implementa ordenação de vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // use drop para [T] use uma fatia bruta para se referir aos elementos do vector como o tipo mais fraco necessário;
            //
            // poderia evitar questões de validade em certos casos
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec lida com desalocação
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Cria um `Vec<T>` vazio.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: test puxa em libstd, o que causa erros aqui
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: test puxa em libstd, o que causa erros aqui
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Obtém todo o conteúdo do `Vec<T>` como uma matriz, se seu tamanho corresponder exatamente ao da matriz solicitada.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Se o comprimento não corresponder, a entrada volta em `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Se você quiser apenas obter um prefixo do `Vec<T>`, pode primeiro ligar para o [`.truncate(N)`](Vec::truncate).
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // SEGURANÇA: o `.set_len(0)` está sempre correto.
        unsafe { vec.set_len(0) };

        // SEGURANÇA: O ponteiro de um `Vec` está sempre alinhado corretamente, e
        // o alinhamento que a matriz precisa é o mesmo dos itens.
        // Verificamos anteriormente se temos itens suficientes.
        // Os itens não cairão duas vezes, pois o `set_len` diz ao `Vec` para não soltá-los também.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}