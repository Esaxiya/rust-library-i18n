use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Marcador de especialização para coletar um pipeline de iterador em um Vec enquanto reutiliza a alocação de origem, ou seja,
/// executando o pipeline no local.
///
/// O SourceIter pai trait é necessário para a função de especialização para acessar a alocação que deve ser reutilizada.
/// Mas não basta que a especialização seja válida.
/// Veja limites adicionais no impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// O std interno SourceIter/InPlaceIterable traits são implementados apenas por cadeias de adaptador <Adapter<Adapter<IntoIter>>> (todos propriedade de core/std).
// Limites adicionais nas implementações do adaptador (além de `impl<I: Trait> Trait for Adapter<I>`) dependem apenas de outro traits já marcado como especialização traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. o marcador não depende da vida útil dos tipos fornecidos pelo usuário.Modulo the Copy hole, do qual várias outras especializações já dependem.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Requisitos adicionais que não podem ser expressos via trait bounds.Em vez disso, contamos com const eval:
        // a) sem ZSTs, pois não haveria alocação para reutilizar e a aritmética de ponteiro panic b) correspondência de tamanho conforme exigido pelo contrato de Alocação c) correspondência de alinhamentos conforme exigido pelo contrato de Alocação
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // fallback para implementações mais genéricas
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // use try-fold desde
        // - ele vetoriza melhor para alguns adaptadores iteradores
        // - ao contrário da maioria dos métodos de iteração internos, leva apenas um &mut self
        // - nos permite enfiar o ponteiro de gravação por suas entranhas e recuperá-lo no final
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // iteração bem-sucedida, não abaixe a cabeça
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // verifique se o contrato da SourceIter foi mantido. Advertência: se não foram, podemos nem mesmo chegar a este ponto
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // verifique o contrato InPlaceIterable.Isso só é possível se o iterador avançou o ponteiro de origem.
        // Se ele usar acesso não verificado via TrustedRandomAccess então o ponteiro de origem permanecerá em sua posição inicial e não podemos usá-lo como referência
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // elimine quaisquer valores restantes no final da fonte, mas evite a queda da própria alocação quando o IntoIter sair do escopo se a queda panics, então também vazamos quaisquer elementos coletados em dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // o contrato InPlaceIterable não pode ser verificado precisamente aqui, pois try_fold tem uma referência exclusiva para o ponteiro de origem, tudo o que podemos fazer é verificar se ele ainda está dentro do alcance
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}