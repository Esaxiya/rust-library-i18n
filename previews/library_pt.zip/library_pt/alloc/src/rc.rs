//! Ponteiros de contagem de referência de thread único.'Rc' significa 'Referência
//! Counted'.
//!
//! O tipo [`Rc<T>`][`Rc`] fornece propriedade compartilhada de um valor do tipo `T`, alocado no heap.
//! Invocar o [`clone`][clone] no [`Rc`] produz um novo ponteiro para a mesma alocação no heap.
//! Quando o último ponteiro [`Rc`] para uma determinada alocação é destruído, o valor armazenado nessa alocação (freqüentemente referido como "inner value") também é descartado.
//!
//! As referências compartilhadas em Rust não permitem a mutação por padrão, e o [`Rc`] não é exceção: geralmente você não pode obter uma referência mutável para algo dentro de um [`Rc`].
//! Se você precisar de mutabilidade, coloque um [`Cell`] ou [`RefCell`] dentro do [`Rc`];consulte [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] usa contagem de referência não atômica.
//! Isso significa que a sobrecarga é muito baixa, mas um [`Rc`] não pode ser enviado entre threads e, conseqüentemente, o [`Rc`] não implementa o [`Send`][send].
//! Como resultado, o compilador Rust verificará *no momento da compilação* se você não está enviando [`Rc`] s entre threads.
//! Se você precisar de contagem de referência atômica multithread, use o [`sync::Arc`][arc].
//!
//! O método [`downgrade`][downgrade] pode ser usado para criar um ponteiro [`Weak`] não proprietário.
//! Um ponteiro [`Weak`] pode ser [`upgrade`][upgrade] d para um [`Rc`], mas ele retornará [`None`] se o valor armazenado na alocação já tiver sido descartado.
//! Em outras palavras, os ponteiros `Weak` não mantêm o valor dentro da alocação ativo;no entanto, eles *mantêm* a alocação (o armazenamento de apoio para o valor interno) ativa.
//!
//! Um ciclo entre ponteiros [`Rc`] nunca será desalocado.
//! Por esse motivo, o [`Weak`] é usado para interromper ciclos.
//! Por exemplo, uma árvore pode ter ponteiros [`Rc`] fortes dos nós pais para os filhos e ponteiros [`Weak`] dos filhos de volta aos pais.
//!
//! `Rc<T>` desreferencia automaticamente para `T` (via [`Deref`] trait), então você pode chamar os métodos de `T` em um valor do tipo [`Rc<T>`][`Rc`].
//! Para evitar conflitos de nome com os métodos de `T`, os métodos do próprio [`Rc<T>`][`Rc`] são funções associadas, chamadas usando o [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>As implementações de traits como `Clone` também podem ser chamadas usando uma sintaxe totalmente qualificada.
//! Algumas pessoas preferem usar sintaxe totalmente qualificada, enquanto outras preferem usar sintaxe de chamada de método.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Sintaxe de chamada de método
//! let rc2 = rc.clone();
//! // Sintaxe totalmente qualificada
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] não desreferencia automaticamente para `T`, porque o valor interno pode já ter sido descartado.
//!
//! # Referências de clonagem
//!
//! A criação de uma nova referência para a mesma alocação de um ponteiro contado de referência existente é feita usando o `Clone` trait implementado para [`Rc<T>`][`Rc`] e [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // As duas sintaxes abaixo são equivalentes.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // aeb apontam para o mesmo local de memória que foo.
//! ```
//!
//! A sintaxe `Rc::clone(&from)` é a mais idiomática porque transmite mais explicitamente o significado do código.
//! No exemplo acima, essa sintaxe torna mais fácil ver que esse código está criando uma nova referência em vez de copiar todo o conteúdo de foo.
//!
//! # Examples
//!
//! Considere um cenário em que um conjunto de `Gadget`s pertence a um determinado `Owner`.
//! Queremos que nosso `Gadget` aponte para seu `Owner`.Não podemos fazer isso com propriedade exclusiva, porque mais de um gadget pode pertencer ao mesmo `Owner`.
//! [`Rc`] nos permite compartilhar um `Owner` entre vários `Gadget`s, e ter o `Owner` alocado enquanto qualquer `Gadget` apontar para ele.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... outros campos
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... outros campos
//! }
//!
//! fn main() {
//!     // Crie um `Owner` com contagem de referência.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Crie `Gadget`s pertencentes ao `gadget_owner`.
//!     // A clonagem do `Rc<Owner>` nos dá um novo ponteiro para a mesma alocação do `Owner`, incrementando a contagem de referência no processo.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Descarte nossa variável local `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Apesar de descartar o `gadget_owner`, ainda podemos imprimir o nome do `Owner` do `Gadget`s.
//!     // Isso ocorre porque descartamos apenas um único `Rc<Owner>`, não o `Owner` para o qual ele aponta.
//!     // Enquanto houver outro `Rc<Owner>` apontando para a mesma alocação `Owner`, ele permanecerá ativo.
//!     // A projeção de campo `gadget1.owner.name` funciona porque `Rc<Owner>` desreferencia automaticamente para `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // No final da função, `gadget1` e `gadget2` são destruídos, e com eles as últimas referências contadas para nosso `Owner`.
//!     // Gadget Man agora é destruído também.
//!     //
//! }
//! ```
//!
//! Se nossos requisitos mudarem e também precisarmos ser capazes de atravessar do `Owner` para o `Gadget`, teremos problemas.
//! Um ponteiro [`Rc`] de `Owner` para `Gadget` apresenta um ciclo.
//! Isso significa que suas contagens de referência nunca podem chegar a 0 e a alocação nunca será destruída:
//! um vazamento de memória.Para contornar isso, podemos usar ponteiros [`Weak`].
//!
//! Rust na verdade torna um pouco difícil produzir este loop em primeiro lugar.Para terminar com dois valores que apontam um para o outro, um deles precisa ser mutável.
//! Isso é difícil porque o [`Rc`] reforça a segurança da memória fornecendo apenas referências compartilhadas para o valor que ele envolve, e isso não permite mutação direta.
//! Precisamos envolver a parte do valor que desejamos transformar em um [`RefCell`], que fornece *mutabilidade interior*: um método para atingir mutabilidade por meio de uma referência compartilhada.
//! [`RefCell`] aplica as regras de empréstimo de Rust em tempo de execução.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... outros campos
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... outros campos
//! }
//!
//! fn main() {
//!     // Crie um `Owner` com contagem de referência.
//!     // Observe que colocamos o vector do `Owner`'s do`Gadget`s dentro de um `RefCell` para que possamos alterá-lo por meio de uma referência compartilhada.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Crie `Gadget`s pertencentes ao `gadget_owner`, como antes.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Adicione o `Gadget`s ao seu `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` o empréstimo dinâmico termina aqui.
//!     }
//!
//!     // Itere sobre nosso `Gadget`s, imprimindo seus detalhes.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` é um `Weak<Gadget>`.
//!         // Como os ponteiros `Weak` não podem garantir que a alocação ainda exista, precisamos chamar `upgrade`, que retorna um `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // Neste caso, sabemos que a alocação ainda existe, então simplesmente `unwrap` o `Option`.
//!         // Em um programa mais complicado, você pode precisar de um tratamento de erros adequado para um resultado `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // No final da função, `gadget_owner`, `gadget1` e `gadget2` são destruídos.
//!     // Agora não há ponteiros (`Rc`) fortes para os gadgets, então eles são destruídos.
//!     // Isso zera a contagem de referência em Gadget Man, então ele é destruído também.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Isso é à prova de repr(C) a future contra possível reordenamento de campo, o que interferiria com o [into|from]_raw() seguro de tipos internos transmutáveis de outra forma.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Um ponteiro de contagem de referência de thread único.'Rc' significa 'Referência
/// Counted'.
///
/// Consulte o [module-level documentation](./index.html) para obter mais detalhes.
///
/// Os métodos inerentes de `Rc` são todas funções associadas, o que significa que você deve chamá-los como, por exemplo, [`Rc::get_mut(&mut value)`][get_mut] em vez de `value.get_mut()`.
/// Isso evita conflitos com métodos do tipo interno `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Esta insegurança está ok porque enquanto este Rc estiver ativo, temos a garantia de que o ponteiro interno é válido.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Constrói um novo `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Existe um ponteiro fraco implícito pertencente a todos os ponteiros fortes, o que garante que o destruidor fraco nunca libere a alocação enquanto o destruidor forte estiver em execução, mesmo se o ponteiro fraco estiver armazenado dentro do destruidor forte.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Constrói um novo `Rc<T>` usando uma referência fraca para si mesmo.
    /// A tentativa de atualizar a referência fraca antes que esta função retorne resultará em um valor `None`.
    ///
    /// No entanto, a referência fraca pode ser clonada livremente e armazenada para uso posterior.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... mais campos
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Construa o interior no estado "uninitialized" com uma única referência fraca.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // É importante não abrirmos mão do ponteiro fraco, caso contrário, a memória pode ser liberada quando o `data_fn` retornar.
        // Se realmente quiséssemos passar a propriedade, poderíamos criar um ponteiro fraco adicional para nós mesmos, mas isso resultaria em atualizações adicionais para a contagem de referência fraca que poderia não ser necessária de outra forma.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Referências fortes devem possuir coletivamente uma referência fraca compartilhada, portanto, não execute o destruidor para nossa referência fraca antiga.
        //
        mem::forget(weak);
        strong
    }

    /// Constrói um novo `Rc` com conteúdo não inicializado.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inicialização adiada:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Constrói um novo `Rc` com conteúdo não inicializado, com a memória sendo preenchida com bytes `0`.
    ///
    ///
    /// Consulte [`MaybeUninit::zeroed`][zeroed] para obter exemplos de uso correto e incorreto desse método.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Constrói um novo `Rc<T>`, retornando um erro se a alocação falhar
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Existe um ponteiro fraco implícito pertencente a todos os ponteiros fortes, o que garante que o destruidor fraco nunca libere a alocação enquanto o destruidor forte estiver em execução, mesmo se o ponteiro fraco estiver armazenado dentro do destruidor forte.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Constrói um novo `Rc` com conteúdo não inicializado, retornando um erro se a alocação falhar
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Inicialização adiada:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Constrói um novo `Rc` com conteúdo não inicializado, com a memória sendo preenchida com bytes `0`, retornando um erro se a alocação falhar
    ///
    ///
    /// Consulte [`MaybeUninit::zeroed`][zeroed] para obter exemplos de uso correto e incorreto desse método.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Constrói um novo `Pin<Rc<T>>`.
    /// Se o `T` não implementar o `Unpin`, o `value` ficará preso na memória e não poderá ser movido.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Retorna o valor interno, se o `Rc` tiver exatamente uma referência forte.
    ///
    /// Caso contrário, um [`Err`] é retornado com o mesmo `Rc` que foi passado.
    ///
    ///
    /// Isso terá sucesso mesmo se houver referências fracas pendentes.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // copie o objeto contido

                // Indique a Weaks que eles não podem ser promovidos diminuindo a contagem forte e, em seguida, remova o ponteiro "strong weak" implícito enquanto também lida com a lógica de eliminação apenas criando um Fraco falso.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Constrói uma nova fatia contada por referência com conteúdo não inicializado.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inicialização adiada:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Constrói uma nova fatia contada por referência com conteúdo não inicializado, com a memória sendo preenchida com bytes `0`.
    ///
    ///
    /// Consulte [`MaybeUninit::zeroed`][zeroed] para obter exemplos de uso correto e incorreto desse método.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Converte para `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Assim como no [`MaybeUninit::assume_init`], cabe ao chamador garantir que o valor interno realmente esteja em um estado inicializado.
    ///
    /// Chamar isso quando o conteúdo ainda não foi totalmente inicializado causa um comportamento indefinido imediato.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inicialização adiada:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Converte para `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Assim como no [`MaybeUninit::assume_init`], cabe ao chamador garantir que o valor interno realmente esteja em um estado inicializado.
    ///
    /// Chamar isso quando o conteúdo ainda não foi totalmente inicializado causa um comportamento indefinido imediato.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inicialização adiada:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Consome o `Rc`, retornando o ponteiro empacotado.
    ///
    /// Para evitar um vazamento de memória, o ponteiro deve ser convertido de volta para um `Rc` usando o [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Fornece um ponteiro bruto para os dados.
    ///
    /// As contagens não são afetadas de forma alguma e o `Rc` não é consumido.
    /// O ponteiro é válido enquanto houver contagens fortes no `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // SEGURANÇA: Não pode passar por Deref::deref ou Rc::inner porque
        // isso é necessário para manter a proveniência do raw/mut de forma que, por exemplo,
        // `get_mut` pode escrever por meio do ponteiro após o Rc ser recuperado por meio do `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Constrói um `Rc<T>` a partir de um ponteiro bruto.
    ///
    /// O ponteiro bruto deve ter sido retornado anteriormente por uma chamada para [`Rc<U>::into_raw`][into_raw], onde `U` deve ter o mesmo tamanho e alinhamento que `T`.
    /// Isso é trivialmente verdadeiro se `U` for `T`.
    /// Observe que, se o `U` não for o `T`, mas tiver o mesmo tamanho e alinhamento, será basicamente como transmutar referências de tipos diferentes.
    /// Consulte [`mem::transmute`][transmute] para obter mais informações sobre quais restrições se aplicam neste caso.
    ///
    /// O usuário do `from_raw` deve certificar-se de que um valor específico de `T` seja descartado apenas uma vez.
    ///
    /// Esta função não é segura porque o uso impróprio pode levar à insegurança da memória, mesmo se o `Rc<T>` retornado nunca for acessado.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Converta novamente para um `Rc` para evitar vazamentos.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Outras chamadas para o `Rc::from_raw(x_ptr)` não seriam seguras para a memória.
    /// }
    ///
    /// // A memória foi liberada quando o `x` saiu do escopo acima, então o `x_ptr` agora está pendurado!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Inverta o deslocamento para encontrar o RcBox original.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Cria um novo ponteiro [`Weak`] para esta alocação.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Certifique-se de não criar um Weak pendente
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Obtém o número de ponteiros [`Weak`] para esta alocação.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Obtém o número de ponteiros (`Rc`) fortes para essa alocação.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Retorna `true` se não houver outros ponteiros `Rc` ou [`Weak`] para esta alocação.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Retorna uma referência mutável no `Rc` fornecido, se não houver outros ponteiros `Rc` ou [`Weak`] para a mesma alocação.
    ///
    ///
    /// Caso contrário, retorna [`None`], porque não é seguro alterar um valor compartilhado.
    ///
    /// Consulte também [`make_mut`][make_mut], que [`clone`][clone] será o valor interno quando houver outros ponteiros.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Retorna uma referência mutável no `Rc` fornecido, sem qualquer verificação.
    ///
    /// Consulte também [`get_mut`], que é seguro e faz as verificações apropriadas.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Quaisquer outros ponteiros `Rc` ou [`Weak`] para a mesma alocação não devem ser referenciados durante o empréstimo retornado.
    ///
    /// Este é o caso trivial se não existirem tais ponteiros, por exemplo, imediatamente após o `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Temos o cuidado de *não* criar uma referência cobrindo os campos "count", pois isso entraria em conflito com os acessos às contagens de referência (por exemplo
        // por `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Retorna `true` se os dois `Rc`s apontam para a mesma alocação (em uma veia semelhante a [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Faz uma referência mutável no `Rc` fornecido.
    ///
    /// Se houver outros ponteiros `Rc` para a mesma alocação, o `make_mut` [`clone`] o valor interno para uma nova alocação para garantir a propriedade exclusiva.
    /// Isso também é conhecido como clone na gravação.
    ///
    /// Se não houver outros ponteiros `Rc` para essa alocação, os ponteiros [`Weak`] para essa alocação serão desassociados.
    ///
    /// Consulte também [`get_mut`], que falhará em vez de clonar.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Não vai clonar nada
    /// let mut other_data = Rc::clone(&data);    // Não clonará dados internos
    /// *Rc::make_mut(&mut data) += 1;        // Clona dados internos
    /// *Rc::make_mut(&mut data) += 1;        // Não vai clonar nada
    /// *Rc::make_mut(&mut other_data) *= 2;  // Não vai clonar nada
    ///
    /// // Agora, o `data` e o `other_data` apontam para diferentes alocações.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] os ponteiros serão desassociados:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Tenho que clonar os dados, existem outros Rcs.
            // Pré-aloque a memória para permitir a gravação direta do valor clonado.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Pode simplesmente roubar os dados, tudo o que resta é o Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Remova o ref forte-fraco implícito (não há necessidade de criar um Fraco falso aqui-sabemos que outros Weaks podem limpar para nós)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Esta insegurança está ok porque temos a garantia de que o ponteiro retornado é o *único* ponteiro que sempre será retornado para T.
        // Nossa contagem de referência é garantidamente 1 neste ponto, e exigimos que o próprio `Rc<T>` fosse `mut`, portanto, estamos retornando a única referência possível para a alocação.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Tente fazer o downcast do `Rc<dyn Any>` para um tipo concreto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Aloca um `RcBox<T>` com espaço suficiente para um valor interno possivelmente não dimensionado, onde o valor tem o layout fornecido.
    ///
    /// A função `mem_to_rcbox` é chamada com o ponteiro de dados e deve retornar um ponteiro (potencialmente gordo) para o `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Calcule o layout usando o layout de valor dado.
        // Anteriormente, o layout era calculado na expressão `&*(ptr as* const RcBox<T>)`, mas isso criava uma referência desalinhada (consulte #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Aloca um `RcBox<T>` com espaço suficiente para um valor interno possivelmente não dimensionado onde o valor tem o layout fornecido, retornando um erro se a alocação falhar.
    ///
    ///
    /// A função `mem_to_rcbox` é chamada com o ponteiro de dados e deve retornar um ponteiro (potencialmente gordo) para o `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Calcule o layout usando o layout de valor dado.
        // Anteriormente, o layout era calculado na expressão `&*(ptr as* const RcBox<T>)`, mas isso criava uma referência desalinhada (consulte #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Alocar para o layout.
        let ptr = allocate(layout)?;

        // Inicialize o RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Aloca um `RcBox<T>` com espaço suficiente para um valor interno não dimensionado
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Aloque para o `RcBox<T>` usando o valor fornecido.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Copiar valor como bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Libere a alocação sem descartar seu conteúdo
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Aloca um `RcBox<[T]>` com o comprimento fornecido.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Copie os elementos da fatia para o Rc recém-alocado <\[T\]>
    ///
    /// Inseguro porque o chamador deve assumir a propriedade ou vincular o `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Constrói um `Rc<[T]>` a partir de um iterador conhecido por ter um determinado tamanho.
    ///
    /// O comportamento é indefinido caso o tamanho esteja incorreto.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic guarda ao clonar elementos T.
        // No caso de um panic, os elementos que foram gravados no novo RcBox serão descartados e a memória será liberada.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Ponteiro para o primeiro elemento
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Tudo limpo.Esqueça a proteção para não liberar o novo RcBox.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Especialização trait usada para `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Descarta o `Rc`.
    ///
    /// Isso diminuirá a contagem de referência forte.
    /// Se a contagem de referência forte chegar a zero, as únicas outras referências (se houver) serão [`Weak`], portanto, `drop` será o valor interno.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Não imprime nada
    /// drop(foo2);   // Imprime "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // destruir o objeto contido
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // remova o ponteiro "strong weak" implícito agora que destruímos o conteúdo.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Faz um clone do ponteiro `Rc`.
    ///
    /// Isso cria outro ponteiro para a mesma alocação, aumentando a contagem de referência forte.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Cria um novo `Rc<T>`, com o valor `Default` para `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Faça um hack para permitir a especialização no `Eq`, embora o `Eq` tenha um método.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Estamos fazendo essa especialização aqui, e não como uma otimização mais geral no `&T`, porque, de outra forma, acrescentaria um custo a todas as verificações de igualdade nos refs.
/// Assumimos que `Rc`s são usados para armazenar grandes valores, que são lentos para clonar, mas também pesados para verificar a igualdade, fazendo com que esse custo seja compensado mais facilmente.
///
/// Também é mais provável que haja dois clones `Rc`, que apontam para o mesmo valor, do que dois `&T`s.
///
/// Só podemos fazer isso quando o `T: Eq`, como `PartialEq`, pode ser deliberadamente irreflexivo.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Igualdade para dois `Rc`s.
    ///
    /// Dois `Rc`s são iguais se seus valores internos forem iguais, mesmo se eles estiverem armazenados em alocações diferentes.
    ///
    /// Se `T` também implementa `Eq` (implicando reflexividade de igualdade), dois `Rc`s que apontam para a mesma alocação são sempre iguais.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Desigualdade para dois `Rc`s.
    ///
    /// Dois `Rc`s são desiguais se seus valores internos forem desiguais.
    ///
    /// Se `T` também implementa `Eq` (implicando reflexividade de igualdade), dois `Rc`s que apontam para a mesma alocação nunca são desiguais.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Comparação parcial para dois `Rc`s.
    ///
    /// Os dois são comparados chamando `partial_cmp()` em seus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Comparação inferior para dois `Rc`s.
    ///
    /// Os dois são comparados chamando `<` em seus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Comparação 'menor ou igual a' para dois 'Rc`s.
    ///
    /// Os dois são comparados chamando `<=` em seus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Comparação maior que para dois `Rc`s.
    ///
    /// Os dois são comparados chamando `>` em seus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Comparação 'maior ou igual a' para dois 'Rc`s.
    ///
    /// Os dois são comparados chamando `>=` em seus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Comparação para dois `Rc`s.
    ///
    /// Os dois são comparados chamando `cmp()` em seus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Aloque uma fatia contada por referência e preencha-a clonando os itens de `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Aloque uma fatia de string contada por referência e copie `v` nela.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Aloque uma fatia de string contada por referência e copie `v` nela.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Mova um objeto em caixa para uma nova alocação contada por referência.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Aloque uma fatia contada por referência e mova os itens de `v` para ela.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Permita que o Vec libere sua memória, mas não destrua seu conteúdo
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Pega cada elemento no `Iterator` e os coleta em um `Rc<[T]>`.
    ///
    /// # Características de desempenho
    ///
    /// ## O caso geral
    ///
    /// No caso geral, a coleta no `Rc<[T]>` é feita primeiro na coleta em um `Vec<T>`.Ou seja, ao escrever o seguinte:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// isso se comporta como se escrevêssemos:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // O primeiro conjunto de alocações acontece aqui.
    ///     .into(); // Uma segunda alocação para `Rc<[T]>` acontece aqui.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Isso alocará quantas vezes forem necessárias para construir o `Vec<T>` e, em seguida, alocará uma vez para transformar o `Vec<T>` no `Rc<[T]>`.
    ///
    ///
    /// ## Iteradores de comprimento conhecido
    ///
    /// Quando o seu `Iterator` implementa o `TrustedLen` e tem um tamanho exato, uma única alocação é feita para o `Rc<[T]>`.Por exemplo:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Apenas uma única alocação acontece aqui.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Especialização trait usada para coleta em `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Esse é o caso de um iterador `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SEGURANÇA: Precisamos garantir que o iterador tenha um comprimento exato e nós temos.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Retorne à implementação normal.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` é uma versão do [`Rc`] que contém uma referência não proprietária para a alocação gerenciada.A alocação é acessada chamando [`upgrade`] no ponteiro `Weak`, que retorna um [`Option`]`<`[`Rc`] `<T>>`.
///
/// Como uma referência `Weak` não conta para propriedade, ela não impedirá que o valor armazenado na alocação seja descartado, e o próprio `Weak` não oferece garantias sobre o valor ainda presente.
/// Portanto, ele pode retornar [`None`] quando [`atualizar`] d.
/// Observe, entretanto, que uma referência `Weak`*impede* que a própria alocação (o armazenamento de apoio) seja desalocada.
///
/// Um ponteiro `Weak` é útil para manter uma referência temporária à alocação gerenciada pelo [`Rc`] sem evitar que seu valor interno seja descartado.
/// Também é usado para evitar referências circulares entre ponteiros [`Rc`], uma vez que as referências de propriedade mútua nunca permitiriam que o [`Rc`] fosse descartado.
/// Por exemplo, uma árvore pode ter ponteiros [`Rc`] fortes dos nós pais para os filhos e ponteiros `Weak` dos filhos de volta aos pais.
///
/// A maneira típica de obter um ponteiro `Weak` é chamar [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Este é um `NonNull` para permitir a otimização do tamanho desse tipo em enums, mas não é necessariamente um ponteiro válido.
    //
    // `Weak::new` define isso como `usize::MAX` para que não precise alocar espaço no heap.
    // Esse não é um valor que um ponteiro real jamais terá porque RcBox tem alinhamento de pelo menos 2.
    // Isso só é possível quando `T: Sized`;`T` não dimensionado nunca balança.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Constrói um novo `Weak<T>`, sem alocar memória.
    /// Chamar [`upgrade`] no valor de retorno sempre dá [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Tipo auxiliar para permitir o acesso às contagens de referência sem fazer nenhuma afirmação sobre o campo de dados.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Retorna um ponteiro bruto para o objeto `T` apontado por este `Weak<T>`.
    ///
    /// O ponteiro é válido apenas se houver algumas referências fortes.
    /// O ponteiro pode estar pendente, desalinhado ou até mesmo [`null`] de outra forma.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Ambos apontam para o mesmo objeto
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // O forte aqui o mantém vivo, então ainda podemos acessar o objeto.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Mas não mais.
    /// // Podemos fazer weak.as_ptr(), mas acessar o ponteiro levaria a um comportamento indefinido.
    /// // assert_eq! ("olá", inseguro {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Se o ponteiro estiver pendurado, retornamos a sentinela diretamente.
            // Este não pode ser um endereço de carga útil válido, pois a carga útil é pelo menos tão alinhada quanto RcBox (usize).
            ptr as *const T
        } else {
            // SEGURANÇA: se is_dangling retornar falso, então o ponteiro é desreferenciável.
            // A carga útil pode ser descartada neste ponto, e temos que manter a procedência, então use a manipulação bruta do ponteiro.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Consome o `Weak<T>` e o transforma em um ponteiro bruto.
    ///
    /// Isso converte o ponteiro fraco em um ponteiro bruto, enquanto ainda preserva a propriedade de uma referência fraca (a contagem fraca não é modificada por esta operação).
    /// Ele pode ser transformado novamente no `Weak<T>` com o [`from_raw`].
    ///
    /// As mesmas restrições de acesso ao destino do ponteiro do [`as_ptr`] se aplicam.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Converte um ponteiro bruto criado anteriormente pelo [`into_raw`] de volta para o `Weak<T>`.
    ///
    /// Isso pode ser usado para obter uma referência forte com segurança (chamando o [`upgrade`] posteriormente) ou para desalocar a contagem fraca descartando o `Weak<T>`.
    ///
    /// Ele se apropria de uma referência fraca (com exceção dos ponteiros criados pelo [`new`], já que eles não possuem nada; o método ainda funciona neles).
    ///
    /// # Safety
    ///
    /// O ponteiro deve ter se originado do [`into_raw`] e ainda deve possuir sua referência fraca potencial.
    ///
    /// É permitido que a contagem forte seja 0 no momento da chamada.
    /// No entanto, isso assume a propriedade de uma referência fraca atualmente representada como um ponteiro bruto (a contagem fraca não é modificada por esta operação) e, portanto, deve ser emparelhada com uma chamada anterior para o [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Diminua a última contagem fraca.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Consulte Weak::as_ptr para obter o contexto de como o ponteiro de entrada é derivado.

        let ptr = if is_dangling(ptr as *mut T) {
            // Este é um fraco oscilante.
            ptr as *mut RcBox<T>
        } else {
            // Caso contrário, temos a garantia de que o ponteiro veio de um Fraco não emaranhado.
            // SEGURANÇA: data_offset é seguro para chamar, já que ptr faz referência a um T. real (potencialmente descartado).
            let offset = unsafe { data_offset(ptr) };
            // Assim, invertemos o deslocamento para obter todo o RcBox.
            // SEGURANÇA: o ponteiro se originou de um Fraco, então este deslocamento é seguro.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SEGURANÇA: agora recuperamos o ponteiro Fraco original, então podemos criar o Fraco.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Tenta atualizar o ponteiro `Weak` para um [`Rc`], atrasando a eliminação do valor interno se for bem-sucedido.
    ///
    ///
    /// Retorna [`None`] se o valor interno já foi descartado.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Destrua todos os ponteiros fortes.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Obtém o número de ponteiros (`Rc`) fortes que apontam para esta alocação.
    ///
    /// Se o `self` foi criado usando o [`Weak::new`], retornará 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Obtém o número de ponteiros `Weak` apontando para esta alocação.
    ///
    /// Se nenhum ponteiro forte permanecer, ele retornará zero.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // subtrair o ptr fraco implícito
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Retorna `None` quando o ponteiro está pendurado e não há nenhum `RcBox` alocado (ou seja, quando este `Weak` foi criado por `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Temos o cuidado de *não* criar uma referência cobrindo o campo "data", pois o campo pode sofrer mutação simultaneamente (por exemplo, se o último `Rc` for descartado, o campo de dados será descartado no local).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Retorna `true` se os dois `Weak`s apontam para a mesma alocação (semelhante a [`ptr::eq`]), ou se ambos não apontam para nenhuma alocação (porque foram criados com `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Como isso compara ponteiros, significa que o `Weak::new()` será igual um ao outro, embora eles não apontem para nenhuma alocação.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Comparando `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Deixa cair o ponteiro `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Não imprime nada
    /// drop(foo);        // Imprime "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // a contagem fraca começa em 1 e só vai para zero se todos os indicadores fortes tiverem desaparecido.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Faz um clone do ponteiro `Weak` que aponta para a mesma alocação.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Constrói um novo `Weak<T>`, alocando memória para o `T` sem inicializá-lo.
    /// Chamar [`upgrade`] no valor de retorno sempre dá [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Check_add aqui para lidar com o mem::forget com segurança.Em particular
// se você mem::forget Rcs (ou Weaks), o ref-count pode estourar, e então você pode liberar a alocação enquanto houver Rcs (ou Weaks) pendentes.
//
// Abortamos porque este é um cenário tão degenerado que não nos importamos com o que acontece-nenhum programa real deveria experimentar isso.
//
// Isso deve ter uma sobrecarga desprezível, já que você não precisa realmente cloná-los no Rust graças à propriedade e à semântica de movimentação.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Queremos abortar no estouro em vez de descartar o valor.
        // A contagem de referência nunca será zero quando for chamada;
        // no entanto, inserimos um aborto aqui para sugerir ao LLVM uma otimização perdida de outra forma.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Queremos abortar no estouro em vez de descartar o valor.
        // A contagem de referência nunca será zero quando for chamada;
        // no entanto, inserimos um aborto aqui para sugerir ao LLVM uma otimização perdida de outra forma.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Obtenha o deslocamento em um `RcBox` para a carga atrás de um ponteiro.
///
/// # Safety
///
/// O ponteiro deve apontar para (e ter metadados válidos para) uma instância anteriormente válida de T, mas o T pode ser descartado.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Alinhe o valor não dimensionado ao final do RcBox.
    // Como RcBox é repr(C), ele sempre será o último campo na memória.
    // SEGURANÇA: uma vez que os únicos tipos não dimensionados possíveis são fatias, objetos trait,
    // e tipos externos, o requisito de segurança de entrada é atualmente suficiente para satisfazer os requisitos de align_of_val_raw;este é um detalhe de implementação da linguagem que não pode ser confiado fora de std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}