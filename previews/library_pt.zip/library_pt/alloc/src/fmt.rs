//! Utilitários para formatar e imprimir `String`s.
//!
//! Este módulo contém o suporte de tempo de execução para a extensão da sintaxe [`format!`].
//! Esta macro é implementada no compilador para emitir chamadas para este módulo a fim de formatar argumentos em tempo de execução em strings.
//!
//! # Usage
//!
//! A macro [`format!`] se destina a ser familiar para aqueles que vêm das funções `printf`/`fprintf` do C ou da função `str.format` do Python.
//!
//! Alguns exemplos da extensão [`format!`] são:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" com zeros à esquerda
//! ```
//!
//! Destes, você pode ver que o primeiro argumento é uma string de formato.É exigido pelo compilador para que seja uma string literal;não pode ser uma variável passada (para realizar a verificação de validade).
//! O compilador irá então analisar a string de formato e determinar se a lista de argumentos fornecida é adequada para passar para esta string de formato.
//!
//! Para converter um único valor em uma string, use o método [`to_string`].Isso usará a formatação [`Display`] trait.
//!
//! ## Parâmetros posicionais
//!
//! Cada argumento de formatação tem permissão para especificar qual argumento de valor está referenciando e, se omitido, é considerado "the next argument".
//! Por exemplo, a string de formato `{} {} {}` teria três parâmetros e eles seriam formatados na mesma ordem em que foram dados.
//! A string de formato `{2} {1} {0}`, no entanto, formata os argumentos na ordem inversa.
//!
//! As coisas podem ficar um pouco complicadas quando você começa a misturar os dois tipos de especificadores de posição.O especificador "next argument" pode ser considerado um iterador sobre o argumento.
//! Cada vez que um especificador "next argument" é visto, o iterador avança.Isso leva a um comportamento como este:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! O iterador interno sobre o argumento não foi avançado no momento em que o primeiro `{}` é visto, portanto, ele imprime o primeiro argumento.Então, ao alcançar o segundo `{}`, o iterador avançou para o segundo argumento.
//! Essencialmente, os parâmetros que nomeiam explicitamente seu argumento não afetam os parâmetros que não nomeiam um argumento em termos de especificadores posicionais.
//!
//! Uma string de formato é necessária para usar todos os seus argumentos, caso contrário, é um erro em tempo de compilação.Você pode se referir ao mesmo argumento mais de uma vez na string de formato.
//!
//! ## Parâmetros nomeados
//!
//! Rust em si não tem um equivalente Python de parâmetros nomeados para uma função, mas a macro [`format!`] é uma extensão de sintaxe que permite alavancar parâmetros nomeados.
//! Os parâmetros nomeados são listados no final da lista de argumentos e têm a sintaxe:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Por exemplo, todas as seguintes expressões [`format!`] usam um argumento nomeado:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Não é válido colocar parâmetros posicionais (aqueles sem nomes) após os argumentos que possuem nomes.Como acontece com os parâmetros posicionais, não é válido fornecer parâmetros nomeados que não sejam usados pela string de formato.
//!
//! # Parâmetros de formatação
//!
//! Cada argumento sendo formatado pode ser transformado por vários parâmetros de formatação (correspondendo a `format_spec` em [the syntax](#syntax)). Esses parâmetros afetam a representação de string do que está sendo formatado.
//!
//! ## Width
//!
//! ```
//! // Todos estes imprimem "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Este é um parâmetro para o "minimum width" que o formato deve assumir.
//! Se a string do valor não preencher essa quantidade de caracteres, o preenchimento especificado pelo fill/alignment será usado para ocupar o espaço necessário (veja abaixo).
//!
//! O valor para a largura também pode ser fornecido como um [`usize`] na lista de parâmetros adicionando um postfix `$`, indicando que o segundo argumento é um [`usize`] especificando a largura.
//!
//! Referir-se a um argumento com a sintaxe de dólar não afeta o contador "next argument", portanto, geralmente é uma boa ideia referir-se a argumentos por posição ou usar argumentos nomeados.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! O caractere de preenchimento opcional e o alinhamento são fornecidos normalmente em conjunto com o parâmetro [`width`](#width).Deve ser definido antes do `width`, logo após o `:`.
//! Isso indica que se o valor que está sendo formatado for menor que `width`, alguns caracteres extras serão impressos ao redor dele.
//! O preenchimento vem nas seguintes variantes para diferentes alinhamentos:
//!
//! * `[fill]<` - o argumento é alinhado à esquerda nas colunas `width`
//! * `[fill]^` - o argumento é alinhado ao centro nas colunas `width`
//! * `[fill]>` - o argumento é alinhado à direita nas colunas `width`
//!
//! O padrão [fill/alignment](#fillalignment) para não numéricos é um espaço e alinhado à esquerda.O padrão para formatadores numéricos também é um caractere de espaço, mas com alinhamento à direita.
//! Se o sinalizador `0` (veja abaixo) for especificado para números, o caractere de preenchimento implícito é `0`.
//!
//! Observe que o alinhamento pode não ser implementado por alguns tipos.Em particular, geralmente não é implementado para o `Debug` trait.
//! Uma boa maneira de garantir que o preenchimento seja aplicado é formatar sua entrada e, em seguida, preencher esta string resultante para obter sua saída:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Olá Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Todos esses são sinalizadores que alteram o comportamento do formatador.
//!
//! * `+` - Destina-se a tipos numéricos e indica que o sinal deve ser sempre impresso.Os sinais positivos nunca são impressos por padrão, e o sinal negativo só é impresso por padrão para o `Signed` trait.
//! Este sinalizador indica que o sinal correto (`+` ou `-`) deve sempre ser impresso.
//! * `-` - Atualmente não usado
//! * `#` - Este sinalizador indica que a forma de impressão "alternate" deve ser usada.As formas alternativas são:
//!     * `#?` - imprima bem a formatação do [`Debug`]
//!     * `#x` - precede o argumento com um `0x`
//!     * `#X` - precede o argumento com um `0x`
//!     * `#b` - precede o argumento com um `0b`
//!     * `#o` - precede o argumento com um `0o`
//! * `0` - Isso é usado para indicar para formatos inteiros que o preenchimento para `width` deve ser feito com um caractere `0` e também com reconhecimento de sinal.
//! Um formato como `{:08}` geraria `00000001` para o inteiro `1`, enquanto o mesmo formato geraria `-0000001` para o inteiro `-1`.
//! Observe que a versão negativa tem um zero a menos que a versão positiva.
//!         Observe que os zeros de preenchimento são sempre colocados após o sinal (se houver) e antes dos dígitos.Quando usado junto com o sinalizador `#`, uma regra semelhante se aplica: zeros de preenchimento são inseridos após o prefixo, mas antes dos dígitos.
//!         O prefixo está incluído na largura total.
//!
//! ## Precision
//!
//! Para tipos não numéricos, isso pode ser considerado um "maximum width".
//! Se a string resultante for maior do que essa largura, ela será truncada até esse número de caracteres e esse valor truncado será emitido com `fill`, `alignment` e `width` adequados se esses parâmetros forem definidos.
//!
//! Para tipos integrais, isso é ignorado.
//!
//! Para tipos de ponto flutuante, isso indica quantos dígitos após o ponto decimal devem ser impressos.
//!
//! Existem três maneiras possíveis de especificar o `precision` desejado:
//!
//! 1. Um inteiro `.N`:
//!
//!    o próprio inteiro `N` é a precisão.
//!
//! 2. Um número inteiro ou nome seguido do cifrão `.N$`:
//!
//!    use o formato *argumento*`N` (que deve ser um `usize`) como a precisão.
//!
//! 3. Um asterisco `.*`:
//!
//!    `.*` significa que este `{...}` está associado a *duas* entradas de formato em vez de uma: a primeira entrada contém a precisão do `usize` e a segunda contém o valor a ser impresso.
//!    Observe que, neste caso, se usarmos a string de formato `{<arg>:<spec>.*}`, a parte `<arg>` se refere ao* valor * a ser impresso e o `precision` deve vir na entrada anterior ao `<arg>`.
//!
//! Por exemplo, todas as chamadas a seguir imprimem a mesma coisa `Hello x is 0.01000`:
//!
//! ```
//! // Hello {arg 0 ("x")} é {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Hello {arg 1 ("x")} é {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Hello {arg 0 ("x")} é {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Hello {next arg ("x")} é {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Hello {next arg ("x")} é {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Hello {next arg ("x")} é {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Enquanto estes:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! imprimir três coisas significativamente diferentes:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Em algumas linguagens de programação, o comportamento das funções de formatação de string depende da configuração local do sistema operacional.
//! As funções de formato fornecidas pela biblioteca padrão do Rust não têm nenhum conceito de localidade e produzirão os mesmos resultados em todos os sistemas, independentemente da configuração do usuário.
//!
//! Por exemplo, o código a seguir sempre imprimirá `1.5`, mesmo se a localidade do sistema usar um separador decimal diferente de um ponto.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Os caracteres literais `{` e `}` podem ser incluídos em uma string precedendo-os com o mesmo caractere.Por exemplo, o caractere `{` tem escape com `{{` e o caractere `}` tem escape com `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Para resumir, aqui você pode encontrar a gramática completa das strings de formato.
//! A sintaxe da linguagem de formatação usada é extraída de outras linguagens, portanto, não deve ser muito estranha.Os argumentos são formatados com sintaxe semelhante a Python, o que significa que os argumentos são cercados por `{}` em vez de `%` semelhante a C.
//! A gramática real para a sintaxe de formatação é:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Na gramática acima, `text` não pode conter nenhum caractere `'{'` ou `'}'`.
//!
//! # Formatando traits
//!
//! Ao solicitar que um argumento seja formatado com um tipo específico, você está, na verdade, solicitando que um argumento seja atribuído a um trait específico.
//! Isso permite que vários tipos reais sejam formatados via `{:x}` (como [`i8`] e também [`isize`]).O mapeamento atual de tipos para traits é:
//!
//! * *nada* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] com inteiros hexadecimais em minúsculas
//! * `X?` ⇒ [`Debug`] com inteiros hexadecimais em maiúsculas
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! O que isso significa é que qualquer tipo de argumento que implemente o [`fmt::Binary`][`Binary`] trait pode então ser formatado com o `{:b}`.Implementações são fornecidas para esses traits para vários tipos primitivos pela biblioteca padrão também.
//!
//! Se nenhum formato for especificado (como em `{}` ou `{:6}`), o formato trait usado é o [`Display`] trait.
//!
//! Ao implementar um formato trait para seu próprio tipo, você terá que implementar um método de assinatura:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // nosso tipo personalizado
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Seu tipo será passado como `self` por referência e, em seguida, a função deve emitir saída para o fluxo `f.buf`.Cabe a cada implementação do formato trait aderir corretamente aos parâmetros de formatação solicitados.
//! Os valores desses parâmetros serão listados nos campos da estrutura [`Formatter`].Para ajudar nisso, a estrutura [`Formatter`] também fornece alguns métodos auxiliares.
//!
//! Além disso, o valor de retorno desta função é [`fmt::Result`], que é um alias de tipo de [`Result`]`<(),`[`std: : fmt::Error`] `>`.
//! As implementações de formatação devem garantir que propaguem erros do [`Formatter`] (por exemplo, ao chamar o [`write!`]).
//! No entanto, eles nunca devem retornar erros espúrios.
//! Ou seja, uma implementação de formatação deve e só pode retornar um erro se o [`Formatter`] passado retornar um erro.
//! Isso ocorre porque, ao contrário do que a assinatura da função pode sugerir, a formatação de strings é uma operação infalível.
//! Essa função retorna apenas um resultado porque a gravação no fluxo subjacente pode falhar e deve fornecer uma maneira de propagar o fato de que ocorreu um erro de volta à pilha.
//!
//! Um exemplo de implementação da formatação traits seria assim:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // O valor `f` implementa o `Write` trait, que é o que a escrita!macro está esperando.
//!         // Observe que essa formatação ignora os vários sinalizadores fornecidos para formatar strings.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // traits diferentes permitem diferentes formas de saída de um tipo.
//! // O significado deste formato é imprimir a magnitude de um vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Respeite os sinalizadores de formatação usando o método auxiliar `pad_integral` no objeto Formatter.
//!         // Consulte a documentação do método para obter detalhes e a função `pad` pode ser usada para preencher strings.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Esses dois traits de formatação têm finalidades distintas:
//!
//! - [`fmt::Display`][`Display`] as implementações afirmam que o tipo pode ser fielmente representado como uma string UTF-8 em todos os momentos.**Não** é esperado que todos os tipos implementem o [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] as implementações devem ser implementadas para **todos** os tipos públicos.
//!   A saída normalmente representará o estado interno da forma mais fiel possível.
//!   O objetivo do [`Debug`] trait é facilitar a depuração do código Rust.Na maioria dos casos, usar o `#[derive(Debug)]` é suficiente e recomendado.
//!
//! Alguns exemplos da saída de ambos traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Macros relacionadas
//!
//! Existem várias macros relacionadas na família [`format!`].Os que estão implementados atualmente são:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Este e o [`writeln!`] são duas macros usadas para emitir a string de formato para um fluxo especificado.Isso é usado para evitar alocações intermediárias de strings de formato e, em vez disso, escrever diretamente a saída.
//! Por baixo do capô, esta função está, na verdade, invocando a função [`write_fmt`] definida no [`std::io::Write`] trait.
//! O uso de exemplo é:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Este e o [`println!`] emitem sua saída para stdout.Da mesma forma que a macro [`write!`], o objetivo dessas macros é evitar alocações intermediárias ao imprimir a saída.O uso de exemplo é:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! As macros [`eprint!`] e [`eprintln!`] são idênticas a [`print!`] e [`println!`], respectivamente, exceto que emitem sua saída para stderr.
//!
//! ### `format_args!`
//!
//! Esta é uma macro curiosa usada para passar com segurança um objeto opaco que descreve a string de formato.Este objeto não requer nenhuma alocação de heap para criar e apenas faz referência a informações na pilha.
//! Sob o capô, todas as macros relacionadas são implementadas em termos disso.
//! Em primeiro lugar, alguns exemplos de uso são:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! O resultado da macro [`format_args!`] é um valor do tipo [`fmt::Arguments`].
//! Essa estrutura pode então ser passada para as funções [`write`] e [`format`] dentro deste módulo para processar a string de formato.
//! O objetivo dessa macro é evitar ainda mais as alocações intermediárias ao lidar com strings de formatação.
//!
//! Por exemplo, uma biblioteca de registro poderia usar a sintaxe de formatação padrão, mas passaria internamente esta estrutura até que fosse determinado para onde a saída deve ir.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// A função `format` usa uma estrutura [`Arguments`] e retorna a string formatada resultante.
///
///
/// A instância [`Arguments`] pode ser criada com a macro [`format_args!`].
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Observe que usar o [`format!`] pode ser preferível.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}