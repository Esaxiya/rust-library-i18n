#![stable(feature = "rust1", since = "1.0.0")]

//! Ponteiros de contagem de referência seguros para thread.
//!
//! Consulte a documentação do [`Arc<T>`][Arc] para obter mais detalhes.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Um limite flexível na quantidade de referências que podem ser feitas a um `Arc`.
///
/// Ir acima desse limite abortará seu programa (embora não necessariamente) nas referências _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer não oferece suporte a cercas de memória.
// Para evitar relatórios de falsos positivos na implementação Arco/Fraco, use cargas atômicas para sincronização.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Um ponteiro de contagem de referência seguro para thread.'Arc' significa 'Contagem de referência atômica'.
///
/// O tipo `Arc<T>` fornece propriedade compartilhada de um valor do tipo `T`, alocado no heap.Invocar [`clone`][clone] no `Arc` produz uma nova instância `Arc`, que aponta para a mesma alocação no heap que o `Arc` de origem, enquanto aumenta uma contagem de referência.
/// Quando o último ponteiro `Arc` para uma determinada alocação é destruído, o valor armazenado nessa alocação (freqüentemente referido como "inner value") também é descartado.
///
/// As referências compartilhadas em Rust não permitem a mutação por padrão, e o `Arc` não é exceção: geralmente você não pode obter uma referência mutável para algo dentro de um `Arc`.Se você precisar fazer mutação por meio de um `Arc`, use [`Mutex`][mutex], [`RwLock`][rwlock] ou um dos tipos [`Atomic`][atomic].
///
/// ## Segurança da linha
///
/// Ao contrário do [`Rc<T>`], o `Arc<T>` usa operações atômicas para sua contagem de referência.Isso significa que é seguro para thread.A desvantagem é que as operações atômicas são mais caras do que os acessos comuns à memória.Se você não estiver compartilhando alocações contadas por referência entre threads, considere usar o [`Rc<T>`] para reduzir a sobrecarga.
/// [`Rc<T>`] é um padrão seguro, porque o compilador detectará qualquer tentativa de enviar um [`Rc<T>`] entre threads.
/// No entanto, uma biblioteca pode escolher o `Arc<T>` para dar aos consumidores da biblioteca mais flexibilidade.
///
/// `Arc<T>` implementará [`Send`] e [`Sync`], desde que o `T` implemente [`Send`] e [`Sync`].
/// Por que você não pode colocar um tipo `T` sem thread-safe em um `Arc<T>` para torná-lo thread-safe?Isso pode ser um pouco contra-intuitivo no início: afinal, não é o ponto de segurança de thread do `Arc<T>`?A chave é esta: o `Arc<T>` torna seguro para thread ter várias propriedades dos mesmos dados, mas não adiciona segurança de thread para seus dados.
///
/// Considere `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] não é [`Sync`], e se `Arc<T>` sempre foi [`Send`], `Arc <` [`RefCell<T>`]`>`seria também.
/// Mas então teríamos um problema:
/// [`RefCell<T>`] não é seguro para threads;ele mantém o controle da contagem de empréstimos usando operações não atômicas.
///
/// No final, isso significa que você pode precisar emparelhar o `Arc<T>` com algum tipo de [`std::sync`], geralmente o [`Mutex<T>`][mutex].
///
/// ## Quebrando ciclos com `Weak`
///
/// O método [`downgrade`][downgrade] pode ser usado para criar um ponteiro [`Weak`] não proprietário.Um ponteiro [`Weak`] pode ser [`upgrade`][upgrade] d para um `Arc`, mas ele retornará [`None`] se o valor armazenado na alocação já tiver sido descartado.
/// Em outras palavras, os ponteiros `Weak` não mantêm o valor dentro da alocação ativo;no entanto, eles *mantêm* a alocação (o armazenamento de apoio para o valor) ativa.
///
/// Um ciclo entre ponteiros `Arc` nunca será desalocado.
/// Por esse motivo, o [`Weak`] é usado para interromper ciclos.Por exemplo, uma árvore pode ter ponteiros `Arc` fortes dos nós pais para os filhos e ponteiros [`Weak`] dos filhos de volta aos pais.
///
/// # Referências de clonagem
///
/// A criação de uma nova referência a partir de um ponteiro contado por referência existente é feita usando o `Clone` trait implementado para [`Arc<T>`][Arc] e [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // As duas sintaxes abaixo são equivalentes.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b e foo são todos arcos que apontam para o mesmo local de memória
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` desreferencia automaticamente para `T` (via [`Deref`][deref] trait), então você pode chamar os métodos de `T` em um valor do tipo `Arc<T>`.Para evitar conflitos de nome com os métodos de `T`, os métodos do próprio `Arc<T>` são funções associadas, chamadas usando o [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arco<T>As implementações de traits como `Clone` também podem ser chamadas usando uma sintaxe totalmente qualificada.
/// Algumas pessoas preferem usar sintaxe totalmente qualificada, enquanto outras preferem usar sintaxe de chamada de método.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Sintaxe de chamada de método
/// let arc2 = arc.clone();
/// // Sintaxe totalmente qualificada
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] não desreferencia automaticamente para `T`, porque o valor interno pode já ter sido descartado.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Compartilhando alguns dados imutáveis entre threads:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Observe que **não** executamos esses testes aqui.
// Os construtores do windows ficam extremamente infelizes se um thread sobrevive ao thread principal e sai ao mesmo tempo (algo entra em impasse), portanto, evitamos isso totalmente não executando esses testes.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Compartilhando um [`AtomicUsize`] mutável:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Consulte o [`rc` documentation][rc_examples] para obter mais exemplos de contagem de referência em geral.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` é uma versão do [`Arc`] que contém uma referência não proprietária para a alocação gerenciada.
/// A alocação é acessada chamando [`upgrade`] no ponteiro `Weak`, que retorna um [`Option`]`<`[`Arc`] `<T>>`.
///
/// Como uma referência `Weak` não conta para propriedade, ela não impedirá que o valor armazenado na alocação seja descartado, e o próprio `Weak` não oferece garantias sobre o valor ainda presente.
///
/// Portanto, ele pode retornar [`None`] quando [`atualizar`] d.
/// Observe, entretanto, que uma referência `Weak`*impede* que a própria alocação (o armazenamento de apoio) seja desalocada.
///
/// Um ponteiro `Weak` é útil para manter uma referência temporária à alocação gerenciada pelo [`Arc`] sem evitar que seu valor interno seja descartado.
/// Também é usado para evitar referências circulares entre ponteiros [`Arc`], uma vez que as referências de propriedade mútua nunca permitiriam que o [`Arc`] fosse descartado.
/// Por exemplo, uma árvore pode ter ponteiros [`Arc`] fortes dos nós pais para os filhos e ponteiros `Weak` dos filhos de volta aos pais.
///
/// A maneira típica de obter um ponteiro `Weak` é chamar [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Este é um `NonNull` para permitir a otimização do tamanho desse tipo em enums, mas não é necessariamente um ponteiro válido.
    //
    // `Weak::new` define isso como `usize::MAX` para que não precise alocar espaço no heap.
    // Esse não é um valor que um ponteiro real jamais terá porque RcBox tem alinhamento de pelo menos 2.
    // Isso só é possível quando `T: Sized`;`T` não dimensionado nunca balança.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Isso é à prova de repr(C) a future contra possível reordenamento de campo, o que interferiria com o [into|from]_raw() seguro de tipos internos transmutáveis de outra forma.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // o valor usize::MAX atua como uma sentinela para o "locking" temporariamente, a capacidade de atualizar os ponteiros fracos ou diminuir os ponteiros fortes;isso é usado para evitar corridas no `make_mut` e no `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Constrói um novo `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Inicie a contagem do ponteiro fraco como 1, que é o ponteiro fraco mantido por todos os ponteiros fortes (kinda), consulte std/rc.rs para obter mais informações
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Constrói um novo `Arc<T>` usando uma referência fraca para si mesmo.
    /// A tentativa de atualizar a referência fraca antes que esta função retorne resultará em um valor `None`.
    /// No entanto, a referência fraca pode ser clonada livremente e armazenada para uso posterior.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Construa o interior no estado "uninitialized" com uma única referência fraca.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // É importante não abrirmos mão do ponteiro fraco, caso contrário, a memória pode ser liberada quando o `data_fn` retornar.
        // Se realmente quiséssemos passar a propriedade, poderíamos criar um ponteiro fraco adicional para nós mesmos, mas isso resultaria em atualizações adicionais para a contagem de referência fraca que poderia não ser necessária de outra forma.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Agora podemos inicializar adequadamente o valor interno e transformar nossa referência fraca em uma referência forte.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // A gravação acima no campo de dados deve ser visível para qualquer thread que observe uma contagem forte diferente de zero.
            // Portanto, precisamos de pelo menos um pedido do "Release" para sincronizar com o `compare_exchange_weak` no `Weak::upgrade`.
            //
            // "Acquire" não é necessário fazer o pedido.
            // Ao considerar os possíveis comportamentos do `data_fn`, precisamos apenas ver o que ele poderia fazer com uma referência a um `Weak` não atualizável:
            //
            // - Ele pode *clonar* o `Weak`, aumentando a contagem de referência fraca.
            // - Ele pode descartar esses clones, diminuindo a contagem de referência fraca (mas nunca a zero).
            //
            // Esses efeitos colaterais não nos afetam de forma alguma, e nenhum outro efeito colateral é possível apenas com o código seguro.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Referências fortes devem possuir coletivamente uma referência fraca compartilhada, portanto, não execute o destruidor para nossa referência fraca antiga.
        //
        mem::forget(weak);
        strong
    }

    /// Constrói um novo `Arc` com conteúdo não inicializado.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inicialização adiada:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Constrói um novo `Arc` com conteúdo não inicializado, com a memória sendo preenchida com bytes `0`.
    ///
    ///
    /// Consulte [`MaybeUninit::zeroed`][zeroed] para obter exemplos de uso correto e incorreto desse método.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Constrói um novo `Pin<Arc<T>>`.
    /// Se o `T` não implementar o `Unpin`, o `data` ficará preso na memória e não poderá ser movido.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Constrói um novo `Arc<T>`, retornando um erro se a alocação falhar.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Inicie a contagem do ponteiro fraco como 1, que é o ponteiro fraco mantido por todos os ponteiros fortes (kinda), consulte std/rc.rs para obter mais informações
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Constrói um novo `Arc` com conteúdo não inicializado, retornando um erro se a alocação falhar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Inicialização adiada:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Constrói um novo `Arc` com conteúdo não inicializado, com a memória sendo preenchida com bytes `0`, retornando um erro se a alocação falhar.
    ///
    ///
    /// Consulte [`MaybeUninit::zeroed`][zeroed] para obter exemplos de uso correto e incorreto desse método.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Retorna o valor interno, se o `Arc` tiver exatamente uma referência forte.
    ///
    /// Caso contrário, um [`Err`] é retornado com o mesmo `Arc` que foi passado.
    ///
    ///
    /// Isso terá sucesso mesmo se houver referências fracas pendentes.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Faça um ponteiro fraco para limpar a referência forte-fraca implícita
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Constrói uma nova fatia contada por referência atomicamente com conteúdo não inicializado.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inicialização adiada:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Constrói uma nova fatia contada por referência atomicamente com conteúdo não inicializado, com a memória sendo preenchida com bytes `0`.
    ///
    ///
    /// Consulte [`MaybeUninit::zeroed`][zeroed] para obter exemplos de uso correto e incorreto desse método.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Converte para `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Assim como no [`MaybeUninit::assume_init`], cabe ao chamador garantir que o valor interno realmente esteja em um estado inicializado.
    ///
    /// Chamar isso quando o conteúdo ainda não foi totalmente inicializado causa um comportamento indefinido imediato.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inicialização adiada:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Converte para `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Assim como no [`MaybeUninit::assume_init`], cabe ao chamador garantir que o valor interno realmente esteja em um estado inicializado.
    ///
    /// Chamar isso quando o conteúdo ainda não foi totalmente inicializado causa um comportamento indefinido imediato.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inicialização adiada:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Consome o `Arc`, retornando o ponteiro empacotado.
    ///
    /// Para evitar um vazamento de memória, o ponteiro deve ser convertido de volta para um `Arc` usando o [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Fornece um ponteiro bruto para os dados.
    ///
    /// As contagens não são afetadas de forma alguma e o `Arc` não é consumido.
    /// O ponteiro é válido enquanto houver contagens fortes no `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // SEGURANÇA: Não pode passar por Deref::deref ou RcBoxPtr::inner porque
        // isso é necessário para manter a proveniência do raw/mut de forma que, por exemplo,
        // `get_mut` pode escrever por meio do ponteiro após o Rc ser recuperado por meio do `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Constrói um `Arc<T>` a partir de um ponteiro bruto.
    ///
    /// O ponteiro bruto deve ter sido retornado anteriormente por uma chamada para [`Arc<U>::into_raw`][into_raw], onde `U` deve ter o mesmo tamanho e alinhamento que `T`.
    /// Isso é trivialmente verdadeiro se `U` for `T`.
    /// Observe que, se o `U` não for o `T`, mas tiver o mesmo tamanho e alinhamento, será basicamente como transmutar referências de tipos diferentes.
    /// Consulte [`mem::transmute`][transmute] para obter mais informações sobre quais restrições se aplicam neste caso.
    ///
    /// O usuário do `from_raw` deve certificar-se de que um valor específico de `T` seja descartado apenas uma vez.
    ///
    /// Esta função não é segura porque o uso impróprio pode levar à insegurança da memória, mesmo se o `Arc<T>` retornado nunca for acessado.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Converta novamente para um `Arc` para evitar vazamentos.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Outras chamadas para o `Arc::from_raw(x_ptr)` não seriam seguras para a memória.
    /// }
    ///
    /// // A memória foi liberada quando o `x` saiu do escopo acima, então o `x_ptr` agora está pendurado!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Inverta o deslocamento para encontrar o ArcInner original.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Cria um novo ponteiro [`Weak`] para esta alocação.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Isso é relaxado porque estamos verificando o valor no CAS abaixo.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // verifique se o contador fraco é atualmente "locked";em caso afirmativo, gire.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: este código atualmente ignora a possibilidade de estouro
            // em usize::MAX;em geral, tanto Rc quanto Arc precisam ser ajustados para lidar com o estouro.
            //

            // Ao contrário do Clone(), precisamos que seja uma leitura Acquire para sincronizar com a gravação proveniente do `is_unique`, para que os eventos anteriores a essa gravação aconteçam antes dessa leitura.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Certifique-se de não criar um Weak pendente
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Obtém o número de ponteiros [`Weak`] para esta alocação.
    ///
    /// # Safety
    ///
    /// Este método por si só é seguro, mas usá-lo corretamente requer cuidado extra.
    /// Outro thread pode alterar a contagem fraca a qualquer momento, incluindo potencialmente entre chamar esse método e agir no resultado.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Essa afirmação é determinística porque não compartilhamos o `Arc` ou o `Weak` entre os encadeamentos.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Se a contagem fraca estiver bloqueada no momento, o valor da contagem era 0 antes de fazer o bloqueio.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Obtém o número de ponteiros (`Arc`) fortes para essa alocação.
    ///
    /// # Safety
    ///
    /// Este método por si só é seguro, mas usá-lo corretamente requer cuidado extra.
    /// Outro thread pode alterar a contagem forte a qualquer momento, incluindo potencialmente entre chamar esse método e agir no resultado.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Essa afirmação é determinística porque não compartilhamos o `Arc` entre os encadeamentos.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Aumenta em um a contagem de referência forte no `Arc<T>` associado ao ponteiro fornecido.
    ///
    /// # Safety
    ///
    /// O ponteiro deve ter sido obtido através do `Arc::into_raw`, e a instância `Arc` associada deve ser válida (ou seja
    /// a contagem forte deve ser pelo menos 1) para a duração deste método.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Essa afirmação é determinística porque não compartilhamos o `Arc` entre os encadeamentos.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Retenha o arco, mas não toque no refcount envolvendo o ManualmenteDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Agora aumente o refcount, mas também não descarte o novo refcount
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Diminui em um a contagem de referência forte no `Arc<T>` associado ao ponteiro fornecido.
    ///
    /// # Safety
    ///
    /// O ponteiro deve ter sido obtido através do `Arc::into_raw`, e a instância `Arc` associada deve ser válida (ou seja
    /// a contagem forte deve ser pelo menos 1) ao invocar este método.
    /// Este método pode ser usado para liberar o `Arc` final e o armazenamento de apoio, mas **não deve** ser chamado após o lançamento do `Arc` final.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Essas afirmações são determinísticas porque não compartilhamos o `Arc` entre os encadeamentos.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Esta insegurança está ok porque enquanto este arco estiver ativo, temos a garantia de que o ponteiro interno é válido.
        // Além disso, sabemos que a própria estrutura do `ArcInner` é `Sync` porque os dados internos também são `Sync`, portanto, não há problema em emprestar um ponteiro imutável para esses conteúdos.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Parte não embutida do `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Destrua os dados neste momento, mesmo que não possamos liberar a alocação da caixa em si (ainda pode haver indicadores fracos por aí).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Abandone o ref fraco coletivamente mantido por todas as referências fortes
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Retorna `true` se os dois `Arc`s apontam para a mesma alocação (em uma veia semelhante a [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Aloca um `ArcInner<T>` com espaço suficiente para um valor interno possivelmente não dimensionado, onde o valor tem o layout fornecido.
    ///
    /// A função `mem_to_arcinner` é chamada com o ponteiro de dados e deve retornar um ponteiro (potencialmente gordo) para o `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Calcule o layout usando o layout de valor dado.
        // Anteriormente, o layout era calculado na expressão `&*(ptr as* const ArcInner<T>)`, mas isso criava uma referência desalinhada (consulte #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Aloca um `ArcInner<T>` com espaço suficiente para um valor interno possivelmente não dimensionado onde o valor tem o layout fornecido, retornando um erro se a alocação falhar.
    ///
    ///
    /// A função `mem_to_arcinner` é chamada com o ponteiro de dados e deve retornar um ponteiro (potencialmente gordo) para o `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Calcule o layout usando o layout de valor dado.
        // Anteriormente, o layout era calculado na expressão `&*(ptr as* const ArcInner<T>)`, mas isso criava uma referência desalinhada (consulte #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Inicialize o ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Aloca um `ArcInner<T>` com espaço suficiente para um valor interno não dimensionado.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Aloque para o `ArcInner<T>` usando o valor fornecido.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Copiar valor como bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Libere a alocação sem descartar seu conteúdo
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Aloca um `ArcInner<[T]>` com o comprimento fornecido.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Copie os elementos da fatia para o arco recém-alocado <\[T\]>
    ///
    /// Inseguro porque o chamador deve assumir a propriedade ou vincular o `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Constrói um `Arc<[T]>` a partir de um iterador conhecido por ter um determinado tamanho.
    ///
    /// O comportamento é indefinido caso o tamanho esteja incorreto.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic guarda ao clonar elementos T.
        // No caso de um panic, os elementos que foram gravados no novo ArcInner serão descartados e a memória será liberada.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Ponteiro para o primeiro elemento
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Tudo limpo.Esqueça a proteção para que ele não libere o novo ArcInner.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Especialização trait usada para `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Faz um clone do ponteiro `Arc`.
    ///
    /// Isso cria outro ponteiro para a mesma alocação, aumentando a contagem de referência forte.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Usar uma ordenação relaxada está certo aqui, já que o conhecimento da referência original evita que outros threads excluam erroneamente o objeto.
        //
        // Conforme explicado no [Boost documentation][1], o aumento do contador de referência sempre pode ser feito com memory_order_relaxed: novas referências a um objeto só podem ser formadas a partir de uma referência existente e passar uma referência existente de um thread para outro já deve fornecer qualquer sincronização necessária.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // No entanto, precisamos nos proteger contra recontagens massivas caso alguém esteja `mem: : esquecendo` Arcs.
        // Se não fizermos isso, a contagem pode transbordar e os usuários usarão depois de graça.
        // Nós saturamos racialmente para `isize::MAX` na suposição de que não há ~2 bilhões de threads incrementando a contagem de referência de uma vez.
        //
        // Este branch nunca será usado em nenhum programa realista.
        //
        // Abortamos porque esse programa é incrivelmente degenerado e não nos importamos em apoiá-lo.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Faz uma referência mutável no `Arc` fornecido.
    ///
    /// Se houver outros ponteiros `Arc` ou [`Weak`] para a mesma alocação, o `make_mut` criará uma nova alocação e chamará o [`clone`][clone] no valor interno para garantir a propriedade exclusiva.
    /// Isso também é conhecido como clone na gravação.
    ///
    /// Observe que isso difere do comportamento do [`Rc::make_mut`], que desassocia todos os ponteiros `Weak` restantes.
    ///
    /// Consulte também [`get_mut`][get_mut], que falhará em vez de clonar.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Não vai clonar nada
    /// let mut other_data = Arc::clone(&data); // Não clonará dados internos
    /// *Arc::make_mut(&mut data) += 1;         // Clona dados internos
    /// *Arc::make_mut(&mut data) += 1;         // Não vai clonar nada
    /// *Arc::make_mut(&mut other_data) *= 2;   // Não vai clonar nada
    ///
    /// // Agora, o `data` e o `other_data` apontam para diferentes alocações.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Observe que temos uma referência forte e uma referência fraca.
        // Assim, liberar apenas nossa referência forte não fará, por si só, que a memória seja desalocada.
        //
        // Use Acquire para garantir que vejamos quaisquer gravações no `weak` que ocorram antes das gravações de liberação (ou seja, decréscimos) no `strong`.
        // Como temos uma contagem fraca, não há chance de o próprio ArcInner ser desalocado.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Existe outro indicador forte, então devemos clonar.
            // Pré-aloque a memória para permitir a gravação direta do valor clonado.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Relaxar é suficiente no acima, porque isso é fundamentalmente uma otimização: estamos sempre correndo com ponteiros fracos sendo descartados.
            // Na pior das hipóteses, acabamos alocando um novo Arco desnecessariamente.
            //

            // Removemos o último árbitro forte, mas existem outros árbitros fracos restantes.
            // Vamos mover o conteúdo para um novo arco e invalidar os outros árbitros fracos.
            //

            // Observe que não é possível que a leitura de `weak` produza usize::MAX (ou seja, bloqueado), uma vez que a contagem fraca só pode ser bloqueada por um thread com uma referência forte.
            //
            //

            // Materialize nosso próprio ponteiro fraco implícito, para que ele possa limpar o ArcInner conforme necessário.
            //
            let _weak = Weak { ptr: this.ptr };

            // Pode simplesmente roubar os dados, tudo o que resta é o Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Éramos a única referência de qualquer tipo;aumentar a forte contagem de árbitros.
            //
            this.inner().strong.store(1, Release);
        }

        // Como com o `get_mut()`, a insegurança está ok porque nossa referência era única para começar ou se tornou uma ao clonar o conteúdo.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Retorna uma referência mutável no `Arc` fornecido, se não houver outros ponteiros `Arc` ou [`Weak`] para a mesma alocação.
    ///
    ///
    /// Caso contrário, retorna [`None`], porque não é seguro alterar um valor compartilhado.
    ///
    /// Consulte também [`make_mut`][make_mut], que [`clone`][clone] será o valor interno quando houver outros ponteiros.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Esta insegurança está ok porque temos a garantia de que o ponteiro retornado é o *único* ponteiro que sempre será retornado para T.
            // Nossa contagem de referência é garantida como 1 neste ponto, e exigimos que o próprio Arc fosse `mut`, portanto, estamos retornando a única referência possível para os dados internos.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Retorna uma referência mutável no `Arc` fornecido, sem qualquer verificação.
    ///
    /// Consulte também [`get_mut`], que é seguro e faz as verificações apropriadas.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Quaisquer outros ponteiros `Arc` ou [`Weak`] para a mesma alocação não devem ser referenciados durante o empréstimo retornado.
    ///
    /// Este é o caso trivial se não existirem tais ponteiros, por exemplo, imediatamente após o `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Temos o cuidado de *não* criar uma referência cobrindo os campos do "count", pois isso seria um alias com acesso simultâneo às contagens de referência (por exemplo,
        // por `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Determine se esta é a referência exclusiva (incluindo referências fracas) para os dados subjacentes.
    ///
    ///
    /// Observe que isso requer o bloqueio da contagem de referências fracas.
    fn is_unique(&mut self) -> bool {
        // bloqueie a contagem do ponteiro fraco se parecermos ser o único suporte do ponteiro fraco.
        //
        // O rótulo de aquisição aqui garante uma relação acontece antes com qualquer gravação no `strong` (em particular no `Weak::upgrade`) antes dos decréscimos da contagem do `weak` (via `Weak::drop`, que usa liberação).
        // Se a referência fraca atualizada nunca foi descartada, o CAS aqui irá falhar, então não nos importamos em sincronizar.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Ele precisa ser um `Acquire` para sincronizar com o decréscimo do contador `strong` no `drop`-o único acesso que acontece quando qualquer uma, exceto a última referência, está sendo descartada.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // A gravação de liberação aqui sincroniza com uma leitura no `downgrade`, evitando efetivamente que a leitura acima do `strong` aconteça após a gravação.
            //
            //
            self.inner().weak.store(1, Release); // libere o bloqueio
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Descarta o `Arc`.
    ///
    /// Isso diminuirá a contagem de referência forte.
    /// Se a contagem de referência forte chegar a zero, as únicas outras referências (se houver) serão [`Weak`], portanto, `drop` será o valor interno.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Não imprime nada
    /// drop(foo2);   // Imprime "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Como o `fetch_sub` já é atômico, não precisamos sincronizar com outros threads, a menos que vamos excluir o objeto.
        // Essa mesma lógica se aplica ao `fetch_sub` abaixo para a contagem do `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Esta cerca é necessária para evitar a reordenação do uso dos dados e a exclusão dos dados.
        // Por ser marcado como `Release`, a diminuição da contagem de referência é sincronizada com esta cerca `Acquire`.
        // Isso significa que o uso dos dados acontece antes de diminuir a contagem de referência, o que acontece antes desse fence, o que acontece antes da exclusão dos dados.
        //
        // Conforme explicado no [Boost documentation][1],
        //
        // > É importante garantir qualquer acesso possível ao objeto em um
        // > thread (por meio de uma referência existente) para *acontecer antes* da exclusão
        // > o objeto em um segmento diferente.Isso é conseguido por um "release"
        // > operação após descartar uma referência (qualquer acesso ao objeto
        // > através desta referência obviamente aconteceu antes), e um
        // > "acquire" operação antes de excluir o objeto.
        //
        // Em particular, embora os conteúdos de um Arc sejam geralmente imutáveis, é possível ter gravações internas em algo como um Mutex<T>.
        // Como um Mutex não é adquirido quando é excluído, não podemos confiar em sua lógica de sincronização para tornar as gravações no encadeamento A visíveis para um destruidor em execução no encadeamento B.
        //
        //
        // Observe também que a cerca de aquisição aqui provavelmente poderia ser substituída por uma carga de aquisição, o que poderia melhorar o desempenho em situações de alta contenção.Consulte [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Tente fazer o downcast do `Arc<dyn Any + Send + Sync>` para um tipo concreto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Constrói um novo `Weak<T>`, sem alocar memória.
    /// Chamar [`upgrade`] no valor de retorno sempre dá [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Tipo auxiliar para permitir o acesso às contagens de referência sem fazer nenhuma afirmação sobre o campo de dados.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Retorna um ponteiro bruto para o objeto `T` apontado por este `Weak<T>`.
    ///
    /// O ponteiro é válido apenas se houver algumas referências fortes.
    /// O ponteiro pode estar pendente, desalinhado ou até mesmo [`null`] de outra forma.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Ambos apontam para o mesmo objeto
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // O forte aqui o mantém vivo, então ainda podemos acessar o objeto.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Mas não mais.
    /// // Podemos fazer weak.as_ptr(), mas acessar o ponteiro levaria a um comportamento indefinido.
    /// // assert_eq! ("olá", inseguro {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Se o ponteiro estiver pendurado, retornamos a sentinela diretamente.
            // Este não pode ser um endereço de carga útil válido, pois a carga útil é pelo menos tão alinhada quanto ArcInner (usize).
            ptr as *const T
        } else {
            // SEGURANÇA: se is_dangling retornar falso, então o ponteiro é desreferenciável.
            // A carga útil pode ser descartada neste ponto, e temos que manter a procedência, então use a manipulação bruta do ponteiro.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Consome o `Weak<T>` e o transforma em um ponteiro bruto.
    ///
    /// Isso converte o ponteiro fraco em um ponteiro bruto, enquanto ainda preserva a propriedade de uma referência fraca (a contagem fraca não é modificada por esta operação).
    /// Ele pode ser transformado novamente no `Weak<T>` com o [`from_raw`].
    ///
    /// As mesmas restrições de acesso ao destino do ponteiro do [`as_ptr`] se aplicam.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Converte um ponteiro bruto criado anteriormente pelo [`into_raw`] de volta para o `Weak<T>`.
    ///
    /// Isso pode ser usado para obter uma referência forte com segurança (chamando o [`upgrade`] posteriormente) ou para desalocar a contagem fraca descartando o `Weak<T>`.
    ///
    /// Ele se apropria de uma referência fraca (com exceção dos ponteiros criados pelo [`new`], já que eles não possuem nada; o método ainda funciona neles).
    ///
    /// # Safety
    ///
    /// O ponteiro deve ter se originado do [`into_raw`] e ainda deve possuir sua referência fraca potencial.
    ///
    /// É permitido que a contagem forte seja 0 no momento da chamada.
    /// No entanto, isso assume a propriedade de uma referência fraca atualmente representada como um ponteiro bruto (a contagem fraca não é modificada por esta operação) e, portanto, deve ser emparelhada com uma chamada anterior para o [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Diminua a última contagem fraca.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Consulte Weak::as_ptr para obter o contexto de como o ponteiro de entrada é derivado.

        let ptr = if is_dangling(ptr as *mut T) {
            // Este é um fraco oscilante.
            ptr as *mut ArcInner<T>
        } else {
            // Caso contrário, temos a garantia de que o ponteiro veio de um Fraco não emaranhado.
            // SEGURANÇA: data_offset é seguro para chamar, já que ptr faz referência a um T. real (potencialmente descartado).
            let offset = unsafe { data_offset(ptr) };
            // Assim, invertemos o deslocamento para obter todo o RcBox.
            // SEGURANÇA: o ponteiro se originou de um Fraco, então este deslocamento é seguro.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SEGURANÇA: agora recuperamos o ponteiro Fraco original, então podemos criar o Fraco.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Tenta atualizar o ponteiro `Weak` para um [`Arc`], atrasando a eliminação do valor interno se for bem-sucedido.
    ///
    ///
    /// Retorna [`None`] se o valor interno já foi descartado.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Destrua todos os ponteiros fortes.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Usamos um loop CAS para incrementar a contagem forte em vez de fetch_add, pois essa função nunca deve levar a contagem de referência de zero a um.
        //
        //
        let inner = self.inner()?;

        // Carga relaxada porque qualquer gravação de 0 que podemos observar deixa o campo em um estado permanentemente zero (portanto, uma leitura "stale" de 0 é adequada) e qualquer outro valor é confirmado por meio do CAS abaixo.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Consulte os comentários no `Arc::clone` para saber por que fazemos isso (para o `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Relaxado é bom para o caso de falha porque não temos nenhuma expectativa sobre o novo estado.
            // A aquisição é necessária para que o caso de sucesso sincronize com o `Arc::new_cyclic`, quando o valor interno pode ser inicializado após as referências `Weak` já terem sido criadas.
            // Nesse caso, esperamos observar o valor totalmente inicializado.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // nulo verificado acima
                Err(old) => n = old,
            }
        }
    }

    /// Obtém o número de ponteiros (`Arc`) fortes que apontam para esta alocação.
    ///
    /// Se o `self` foi criado usando o [`Weak::new`], retornará 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Obtém uma aproximação do número de ponteiros `Weak` apontando para esta alocação.
    ///
    /// Se o `self` foi criado usando o [`Weak::new`], ou se não houver ponteiros fortes restantes, isso retornará 0.
    ///
    /// # Accuracy
    ///
    /// Devido aos detalhes de implementação, o valor retornado pode ser desviado em 1 em qualquer direção quando outros threads estão manipulando qualquer `Arc`s ou`Weak`s apontando para a mesma alocação.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Como observamos que havia pelo menos um indicador forte após a leitura da contagem fraca, sabemos que a referência fraca implícita (presente sempre que qualquer referência forte estiver viva) ainda estava por perto quando observamos a contagem fraca e, portanto, podemos subtraí-la com segurança.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Retorna `None` quando o ponteiro está pendurado e não há nenhum `ArcInner` alocado (ou seja, quando este `Weak` foi criado por `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Temos o cuidado de *não* criar uma referência cobrindo o campo "data", pois o campo pode sofrer mutação simultaneamente (por exemplo, se o último `Arc` for descartado, o campo de dados será descartado no local).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Retorna `true` se os dois `Weak`s apontam para a mesma alocação (semelhante a [`ptr::eq`]), ou se ambos não apontam para nenhuma alocação (porque foram criados com `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Como isso compara ponteiros, significa que o `Weak::new()` será igual um ao outro, embora eles não apontem para nenhuma alocação.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Comparando `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Faz um clone do ponteiro `Weak` que aponta para a mesma alocação.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Veja os comentários no Arc::clone() para saber por que isso é tranquilo.
        // Isso pode usar um fetch_add (ignorando o bloqueio) porque a contagem fraca só é bloqueada onde *não há outros* ponteiros fracos existentes.
        //
        // (Portanto, não podemos executar este código nesse caso).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Consulte os comentários no Arc::clone() para saber por que fazemos isso (para o mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Constrói um novo `Weak<T>`, sem alocar memória.
    /// Chamar [`upgrade`] no valor de retorno sempre dá [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Deixa cair o ponteiro `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Não imprime nada
    /// drop(foo);        // Imprime "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Se descobrirmos que fomos o último indicador fraco, então é hora de desalocar os dados inteiramente.Veja a discussão no Arc::drop() sobre os pedidos de memória
        //
        // Não é necessário verificar o estado travado aqui, porque a contagem fraca só pode ser travada se houver precisamente um ref fraco, o que significa que a queda só pode ser executada posteriormente no ref fraco restante, o que só pode acontecer após o travamento ser liberado.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Estamos fazendo essa especialização aqui, e não como uma otimização mais geral no `&T`, porque, de outra forma, acrescentaria um custo a todas as verificações de igualdade nos refs.
/// Assumimos que os `Arc`s são usados para armazenar grandes valores, que são lentos para clonar, mas também pesados para verificar a igualdade, fazendo com que esse custo seja compensado mais facilmente.
///
/// Também é mais provável que haja dois clones `Arc`, que apontam para o mesmo valor, do que dois `&T`s.
///
/// Só podemos fazer isso quando o `T: Eq`, como `PartialEq`, pode ser deliberadamente irreflexivo.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Igualdade para dois `Arc`s.
    ///
    /// Dois `Arc`s são iguais se seus valores internos forem iguais, mesmo se eles estiverem armazenados em alocações diferentes.
    ///
    /// Se `T` também implementa `Eq` (implicando reflexividade de igualdade), dois `Arc`s que apontam para a mesma alocação são sempre iguais.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Desigualdade para dois `Arc`s.
    ///
    /// Dois `Arc`s são desiguais se seus valores internos são desiguais.
    ///
    /// Se `T` também implementa `Eq` (implicando reflexividade de igualdade), dois `Arc`s que apontam para o mesmo valor nunca são desiguais.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Comparação parcial para dois `Arc`s.
    ///
    /// Os dois são comparados chamando `partial_cmp()` em seus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Comparação inferior para dois `Arc`s.
    ///
    /// Os dois são comparados chamando `<` em seus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Comparação 'menor ou igual a' para dois 'Arc`s.
    ///
    /// Os dois são comparados chamando `<=` em seus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Comparação maior que para dois `Arc`s.
    ///
    /// Os dois são comparados chamando `>` em seus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Comparação 'maior ou igual a' para dois 'Arc`s.
    ///
    /// Os dois são comparados chamando `>=` em seus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Comparação para dois `Arc`s.
    ///
    /// Os dois são comparados chamando `cmp()` em seus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Cria um novo `Arc<T>`, com o valor `Default` para `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Aloque uma fatia contada por referência e preencha-a clonando os itens de `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Aloque um `str` com contagem de referência e copie o `v` nele.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Aloque um `str` com contagem de referência e copie o `v` nele.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Mova um objeto em caixa para uma nova alocação com contagem de referência.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Aloque uma fatia contada por referência e mova os itens de `v` para ela.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Permita que o Vec libere sua memória, mas não destrua seu conteúdo
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Pega cada elemento no `Iterator` e os coleta em um `Arc<[T]>`.
    ///
    /// # Características de desempenho
    ///
    /// ## O caso geral
    ///
    /// No caso geral, a coleta no `Arc<[T]>` é feita primeiro na coleta em um `Vec<T>`.Ou seja, ao escrever o seguinte:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// isso se comporta como se escrevêssemos:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // O primeiro conjunto de alocações acontece aqui.
    ///     .into(); // Uma segunda alocação para `Arc<[T]>` acontece aqui.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Isso alocará quantas vezes forem necessárias para construir o `Vec<T>` e, em seguida, alocará uma vez para transformar o `Vec<T>` no `Arc<[T]>`.
    ///
    ///
    /// ## Iteradores de comprimento conhecido
    ///
    /// Quando o seu `Iterator` implementa o `TrustedLen` e tem um tamanho exato, uma única alocação é feita para o `Arc<[T]>`.Por exemplo:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Apenas uma única alocação acontece aqui.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Especialização trait usada para coleta em `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Esse é o caso de um iterador `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SEGURANÇA: Precisamos garantir que o iterador tenha um comprimento exato e nós temos.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Retorne à implementação normal.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Obtenha o deslocamento em um `ArcInner` para a carga atrás de um ponteiro.
///
/// # Safety
///
/// O ponteiro deve apontar para (e ter metadados válidos para) uma instância anteriormente válida de T, mas o T pode ser descartado.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Alinhe o valor não dimensionado ao final do ArcInner.
    // Como RcBox é repr(C), ele sempre será o último campo na memória.
    // SEGURANÇA: uma vez que os únicos tipos não dimensionados possíveis são fatias, objetos trait,
    // e tipos externos, o requisito de segurança de entrada é atualmente suficiente para satisfazer os requisitos de align_of_val_raw;este é um detalhe de implementação da linguagem que não pode ser confiado fora de std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}