#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// O conteúdo da nova memória não foi inicializado.
    Uninitialized,
    /// A nova memória é garantida para ser zerada.
    Zeroed,
}

/// Um utilitário de baixo nível para alocar, realocar e desalocar ergonomicamente um buffer de memória no heap sem ter que se preocupar com todos os casos secundários envolvidos.
///
/// Este tipo é excelente para construir suas próprias estruturas de dados como Vec e VecDeque.
/// Em particular:
///
/// * Produz `Unique::dangling()` em tipos de tamanho zero.
/// * Produz `Unique::dangling()` em alocações de comprimento zero.
/// * Evita liberar o `Unique::dangling()`.
/// * Captura todos os overflows em cálculos de capacidade (promove-os para "capacity overflow" panics).
/// * Protege contra sistemas de 32 bits que alocam mais de isize::MAX bytes.
/// * Protege contra transbordar de seu comprimento.
/// * Chama o `handle_alloc_error` para alocações falíveis.
/// * Contém um `ptr::Unique` e, portanto, oferece ao usuário todos os benefícios relacionados.
/// * Usa o excesso retornado do alocador para usar a maior capacidade disponível.
///
/// Esse tipo não inspeciona de forma alguma a memória que gerencia.Quando solto,*irá* liberar sua memória, mas *não* tentará descartar seu conteúdo.
/// Cabe ao usuário do `RawVec` lidar com as coisas reais *armazenadas* dentro de um `RawVec`.
///
/// Observe que o excesso de tipos de tamanho zero é sempre infinito, portanto, `capacity()` sempre retorna `usize::MAX`.
/// Isso significa que você precisa ter cuidado ao fazer viagens de ida e volta com um `Box<[T]>`, já que o `capacity()` não fornecerá o comprimento.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Isso existe porque o `#[unstable]` `const fn`s não precisa estar em conformidade com o `min_const_fn` e, portanto, também não podem ser chamados em`min_const_fn`s.
    ///
    /// Se você alterar o `RawVec<T>::new` ou dependências, tome cuidado para não introduzir nada que realmente viole o `min_const_fn`.
    ///
    /// NOTE: Poderíamos evitar esse hack e verificar a conformidade com algum atributo `#[rustc_force_min_const_fn]` que requer conformidade com `min_const_fn`, mas não necessariamente permite chamá-lo em `stable(...) const fn`/código de usuário não habilitando `foo` quando `#[rustc_const_unstable(feature = "foo", issue = "01234")]` está presente.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Cria o maior `RawVec` possível (na pilha do sistema) sem alocação.
    /// Se o `T` tiver tamanho positivo, será um `RawVec` com capacidade `0`.
    /// Se o `T` tiver tamanho zero, ele fará um `RawVec` com capacidade `usize::MAX`.
    /// Útil para implementar alocação atrasada.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Cria um `RawVec` (no heap do sistema) com exatamente os requisitos de capacidade e alinhamento de um `[T; capacity]`.
    /// Isso é equivalente a chamar `RawVec::new` quando `capacity` é `0` ou `T` tem tamanho zero.
    /// Observe que se o `T` tiver tamanho zero, isso significa que você *não* obterá um `RawVec` com a capacidade solicitada.
    ///
    /// # Panics
    ///
    /// Panics se a capacidade solicitada exceder `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Aborta no OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Como o `with_capacity`, mas garante que o buffer seja zerado.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Reconstitui um `RawVec` a partir de um ponteiro e capacidade.
    ///
    /// # Safety
    ///
    /// O `ptr` deve ser alocado (na pilha do sistema) e com o `capacity` fornecido.
    /// O `capacity` não pode exceder o `isize::MAX` para tipos de tamanhos.(apenas uma preocupação em sistemas de 32 bits).
    /// ZST vectors pode ter uma capacidade de até `usize::MAX`.
    /// Se o `ptr` e o `capacity` vierem de um `RawVec`, isso é garantido.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Tiny Vecs são burros.Pule para:
    // - 8 se o tamanho do elemento for 1, porque qualquer alocador de heap provavelmente arredondará uma solicitação de menos de 8 bytes para pelo menos 8 bytes.
    //
    // - 4 se os elementos forem de tamanho moderado (<=1 KiB).
    // - 1 caso contrário, para evitar o desperdício de muito espaço para Vecs muito curtos.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Como o `new`, mas parametrizado em relação à escolha do alocador para o `RawVec` retornado.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` significa "unallocated".tipos de tamanho zero são ignorados.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Como o `with_capacity`, mas parametrizado em relação à escolha do alocador para o `RawVec` retornado.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Como o `with_capacity_zeroed`, mas parametrizado em relação à escolha do alocador para o `RawVec` retornado.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Converte um `Box<[T]>` em um `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Converte todo o buffer em `Box<[MaybeUninit<T>]>` com o `len` especificado.
    ///
    /// Observe que isso reconstituirá corretamente quaisquer alterações do `cap` que possam ter sido realizadas.(Veja a descrição do tipo para detalhes.)
    ///
    /// # Safety
    ///
    /// * `len` deve ser maior ou igual à capacidade solicitada mais recentemente, e
    /// * `len` deve ser menor ou igual a `self.capacity()`.
    ///
    /// Observe que a capacidade solicitada e o `self.capacity()` podem ser diferentes, pois um alocador pode superalocar e retornar um bloco de memória maior do que o solicitado.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Verifique a integridade de uma metade do requisito de segurança (não podemos verificar a outra metade).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Evitamos o `unwrap_or_else` aqui porque ele aumenta a quantidade de LLVM IR gerada.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Reconstitui um `RawVec` a partir de um ponteiro, capacidade e alocador.
    ///
    /// # Safety
    ///
    /// O `ptr` deve ser alocado (por meio do alocador `alloc` fornecido) e com o `capacity` fornecido.
    /// O `capacity` não pode exceder o `isize::MAX` para tipos de tamanhos.
    /// (apenas uma preocupação em sistemas de 32 bits).
    /// ZST vectors pode ter uma capacidade de até `usize::MAX`.
    /// Se o `ptr` e o `capacity` vierem de um `RawVec` criado por meio do `alloc`, isso é garantido.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Obtém um ponteiro bruto para o início da alocação.
    /// Observe que este é `Unique::dangling()` se `capacity == 0` ou `T` tiver tamanho zero.
    /// No primeiro caso, você deve ter cuidado.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Obtém a capacidade da alocação.
    ///
    /// Será sempre `usize::MAX` se `T` tiver tamanho zero.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Retorna uma referência compartilhada para o alocador que apoia este `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Temos um pedaço de memória alocado, portanto, podemos ignorar as verificações de tempo de execução para obter nosso layout atual.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Garante que o buffer contém pelo menos espaço suficiente para conter os elementos `len + additional`.
    /// Se ainda não tiver capacidade suficiente, realocará espaço suficiente mais espaço de folga confortável para obter o comportamento *O*(1) amortizado.
    ///
    /// Limitará este comportamento se for desnecessariamente causado a panic.
    ///
    /// Se `len` exceder `self.capacity()`, pode haver falha na alocação do espaço solicitado.
    /// Isso não é realmente inseguro, mas o código inseguro *que você* escreve que depende do comportamento desta função pode falhar.
    ///
    /// Isso é ideal para implementar uma operação bulk-push como o `extend`.
    ///
    /// # Panics
    ///
    /// Panics se a nova capacidade exceder `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Aborta no OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // reserve teria abortado ou entrado em pânico se o len excedesse `isize::MAX`, portanto, é seguro fazer isso desmarcado agora.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// O mesmo que `reserve`, mas retorna em caso de erros em vez de entrar em pânico ou interromper.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Garante que o buffer contém pelo menos espaço suficiente para conter os elementos `len + additional`.
    /// Se ainda não o fizer, o realocará a quantidade mínima possível de memória necessária.
    /// Geralmente, essa será exatamente a quantidade de memória necessária, mas, em princípio, o alocador está livre para devolver mais do que solicitamos.
    ///
    ///
    /// Se `len` exceder `self.capacity()`, pode haver falha na alocação do espaço solicitado.
    /// Isso não é realmente inseguro, mas o código inseguro *que você* escreve que depende do comportamento desta função pode falhar.
    ///
    /// # Panics
    ///
    /// Panics se a nova capacidade exceder `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Aborta no OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// O mesmo que `reserve_exact`, mas retorna em caso de erros em vez de entrar em pânico ou interromper.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Reduz a alocação até o valor especificado.
    /// Se a quantidade fornecida for 0, na verdade desaloca completamente.
    ///
    /// # Panics
    ///
    /// Panics se a quantidade fornecida for *maior* do que a capacidade atual.
    ///
    /// # Aborts
    ///
    /// Aborta no OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Retorna se o buffer precisa crescer para preencher a capacidade extra necessária.
    /// Usado principalmente para possibilitar chamadas de reserva inlining sem o `grow` inlining.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Esse método geralmente é instanciado várias vezes.Portanto, queremos que seja o menor possível, para melhorar os tempos de compilação.
    // Mas também queremos que o máximo possível de seu conteúdo seja estaticamente computável, para fazer com que o código gerado seja executado com mais rapidez.
    // Portanto, esse método é cuidadosamente escrito para que todo o código que depende do `T` esteja dentro dele, enquanto a maior parte do código que não depende do `T` quanto possível está em funções que não são genéricas em relação ao `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Isso é garantido pelos contextos de chamada.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Uma vez que retornamos uma capacidade de `usize::MAX` quando `elem_size` é
            // 0, chegar aqui necessariamente significa que o `RawVec` está lotado.
            return Err(CapacityOverflow);
        }

        // Nada que possamos realmente fazer sobre essas verificações, infelizmente.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Isso garante um crescimento exponencial.
        // A duplicação não pode estourar porque `cap <= isize::MAX` e o tipo de `cap` é `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` não é genérico em relação ao `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // As restrições desse método são praticamente as mesmas do `grow_amortized`, mas esse método geralmente é instanciado com menos frequência, por isso é menos crítico.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Uma vez que retornamos uma capacidade de `usize::MAX` quando o tamanho do tipo é
            // 0, chegar aqui necessariamente significa que o `RawVec` está lotado.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` não é genérico em relação ao `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Esta função está fora do `RawVec` para minimizar os tempos de compilação.Veja o comentário acima `RawVec::grow_amortized` para detalhes.
// (O parâmetro `A` não é significativo, porque o número de diferentes tipos de `A` vistos na prática é muito menor do que o número de tipos de `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Verifique o erro aqui para minimizar o tamanho do `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // O alocador verifica a igualdade de alinhamento
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Libera a memória do `RawVec`*sem* tentar descartar seu conteúdo.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Função central para tratamento de erros de reserva.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Precisamos garantir o seguinte:
// * Nunca alocamos objetos de tamanho de byte `> isize::MAX`.
// * Não sobrecarregamos o `usize::MAX` e realmente alocamos muito pouco.
//
// Em 64 bits, só precisamos verificar o estouro, pois a tentativa de alocar bytes `> isize::MAX` certamente falhará.
// Em 32 bits e 16 bits, precisamos adicionar uma proteção extra para isso, caso estejamos executando em uma plataforma que pode usar todos os 4 GB no espaço do usuário, por exemplo, PAE ou x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Uma função central responsável por relatar estouros de capacidade.
// Isso garantirá que a geração de código relacionado a esses panics seja mínima, pois há apenas um local em que panics, em vez de um monte em todo o módulo.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}