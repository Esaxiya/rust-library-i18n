// Esta é uma tentativa de implementação seguindo o ideal
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Uma vez que Rust não tem realmente tipos dependentes e recursão polimórfica, nós nos contentamos com muita insegurança.
//

// Um dos principais objetivos deste módulo é evitar a complexidade, tratando a árvore como um contêiner genérico (de formato estranho) e evitando lidar com a maioria dos invariantes da B-Tree.
//
// Como tal, este módulo não se importa se as entradas são classificadas, quais nós podem estar underfull ou mesmo o que significa underfull.No entanto, contamos com algumas invariantes:
//
// - As árvores devem ter depth/height uniforme.Isso significa que todo caminho até uma folha de um determinado nó tem exatamente o mesmo comprimento.
// - Um nó de comprimento `n` tem chaves `n`, valores `n` e bordas `n + 1`.
//   Isso implica que mesmo um nó vazio tem pelo menos um edge.
//   Para um nó folha, "having an edge" significa apenas que podemos identificar uma posição no nó, uma vez que as bordas da folha estão vazias e não precisam de representação de dados.
// Em um nó interno, um edge identifica uma posição e contém um ponteiro para um nó filho.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// A representação subjacente de nós folha e parte da representação de nós internos.
struct LeafNode<K, V> {
    /// Queremos ser covariantes em `K` e `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// O índice deste nó na matriz `edges` do nó pai.
    /// `*node.parent.edges[node.parent_idx]` deve ser a mesma coisa que `node`.
    /// A inicialização só é garantida quando o `parent` não é nulo.
    parent_idx: MaybeUninit<u16>,

    /// O número de chaves e valores que este nó armazena.
    len: u16,

    /// Os arrays que armazenam os dados reais do nó.
    /// Apenas os primeiros elementos `len` de cada array são inicializados e válidos.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Inicializa um novo `LeafNode` no local.
    unsafe fn init(this: *mut Self) {
        // Como política geral, deixamos os campos não inicializados, se possível, pois isso deve ser um pouco mais rápido e fácil de rastrear no Valgrind.
        //
        unsafe {
            // parent_idx, keys e vals são todos MaybeUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Cria um novo `LeafNode` em caixa.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// A representação subjacente de nós internos.Tal como acontece com `LeafNode`s, eles devem ser escondidos atrás de`BoxedNode`s para evitar a perda de chaves e valores não inicializados.
/// Qualquer ponteiro para um `InternalNode` pode ser convertido diretamente para um ponteiro para a parte `LeafNode` subjacente do nó, permitindo que o código atue em nós folha e internos genericamente sem ter que nem mesmo verificar para qual dos dois um ponteiro está apontando.
///
/// Esta propriedade é habilitada pelo uso do `repr(C)`.
///
#[repr(C)]
// gdb_providers.py usa este nome de tipo para introspecção.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Os ponteiros para os filhos deste nó.
    /// `len + 1` desses são considerados inicializados e válidos, exceto que próximo ao final, enquanto a árvore é mantida por meio do tipo de empréstimo `Dying`, alguns desses ponteiros estão pendurados.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Cria um novo `InternalNode` em caixa.
    ///
    /// # Safety
    /// Uma invariante dos nós internos é que eles têm pelo menos um edge inicializado e válido.
    /// Esta função não configura tal edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Precisamos apenas inicializar os dados;as bordas são MaybeUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Um ponteiro não nulo gerenciado para um nó.Este é um ponteiro proprietário para `LeafNode<K, V>` ou um ponteiro proprietário para `InternalNode<K, V>`.
///
/// No entanto, o `BoxedNode` não contém informações sobre qual dos dois tipos de nós realmente contém e, parcialmente devido a essa falta de informações, não é um tipo separado e não tem destruidor.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// O nó raiz de uma árvore própria.
///
/// Observe que isso não tem um destruidor e deve ser limpo manualmente.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Retorna uma nova árvore própria, com seu próprio nó raiz que está inicialmente vazio.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` não deve ser zero.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Empresta mutuamente o nó raiz de propriedade.
    /// Ao contrário do `reborrow_mut`, isso é seguro porque o valor de retorno não pode ser usado para destruir a raiz e não pode haver outras referências à árvore.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Toma emprestado o nó raiz de propriedade de maneira um pouco mutável.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Transições irreversíveis para uma referência que permite a travessia e oferece métodos destrutivos e pouco mais.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Adiciona um novo nó interno com um único edge apontando para o nó raiz anterior, torna esse novo nó o nó raiz e o retorna.
    /// Isso aumenta a altura em 1 e é o oposto de `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, exceto que apenas esquecemos que somos internos agora:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Remove o nó raiz interno, usando seu primeiro filho como o novo nó raiz.
    /// Como ele deve ser chamado apenas quando o nó raiz tiver apenas um filho, nenhuma limpeza é feita em qualquer uma das chaves, valores e outros filhos.
    ///
    /// Isso diminui a altura em 1 e é o oposto de `push_internal_level`.
    ///
    /// Requer acesso exclusivo ao objeto `Root`, mas não ao nó raiz;
    /// não invalidará outros identificadores ou referências ao nó raiz.
    ///
    /// Panics se não houver nível interno, ou seja, se o nó raiz for uma folha.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // SEGURANÇA: afirmamos ser internos.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // SEGURANÇA: tomamos emprestado o `self` exclusivamente e seu tipo de empréstimo é exclusivo.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // SEGURANÇA: o primeiro edge é sempre inicializado.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` é sempre covariante em `K` e `V`, mesmo quando o `BorrowType` é `Mut`.
// Isso é tecnicamente errado, mas não pode resultar em nenhuma insegurança devido ao uso interno do `NodeRef` porque permanecemos completamente genéricos em relação ao `K` e `V`.
//
// No entanto, sempre que um tipo público envolve o `NodeRef`, certifique-se de que ele tenha a variação correta.
//
/// Uma referência a um nó.
///
/// Este tipo possui uma série de parâmetros que controlam como ele atua:
/// - `BorrowType`: Um tipo fictício que descreve o tipo de empréstimo e dura para toda a vida.
///    - Quando este é o `Immut<'a>`, o `NodeRef` funciona quase como o `&'a Node`.
///    - Quando este é o `ValMut<'a>`, o `NodeRef` atua aproximadamente como o `&'a Node` com relação às chaves e à estrutura da árvore, mas também permite que muitas referências mutáveis a valores em toda a árvore coexistam.
///    - Quando este é o `Mut<'a>`, o `NodeRef` age quase como o `&'a mut Node`, embora os métodos de inserção permitam que um ponteiro mutável para um valor coexista.
///    - Quando este é o `Owned`, o `NodeRef` funciona quase como o `Box<Node>`, mas não tem um destruidor e deve ser limpo manualmente.
///    - Quando este é o `Dying`, o `NodeRef` ainda age quase como o `Box<Node>`, mas tem métodos para destruir a árvore pouco a pouco e os métodos comuns, embora não marcados como inseguros para chamada, podem invocar o UB se chamados incorretamente.
///
///   Uma vez que qualquer `NodeRef` permite navegar pela árvore, o `BorrowType` se aplica efetivamente a toda a árvore, não apenas ao próprio nó.
/// - `K` e `V`: esses são os tipos de chaves e valores armazenados nos nós.
/// - `Type`: Isso pode ser `Leaf`, `Internal` ou `LeafOrInternal`.
/// Quando este é o `Leaf`, o `NodeRef` aponta para um nó folha, quando este é o `Internal`, o `NodeRef` aponta para um nó interno e, quando este é o `LeafOrInternal`, o `NodeRef` pode estar apontando para qualquer tipo de nó.
///   `Type` é denominado `NodeType` quando usado fora do `NodeRef`.
///
/// Tanto o `BorrowType` quanto o `NodeType` restringem os métodos que implementamos para explorar a segurança do tipo estático.Existem limitações na forma como podemos aplicar essas restrições:
/// - Para cada parâmetro de tipo, só podemos definir um método genericamente ou para um tipo específico.
/// Por exemplo, não podemos definir um método como `into_kv` genericamente para todos os `BorrowType`, ou uma vez para todos os tipos que duram uma vida inteira, porque queremos que ele retorne referências `&'a`.
///   Portanto, nós o definimos apenas para o tipo menos poderoso `Immut<'a>`.
/// - Não podemos obter coerção implícita de, digamos, `Mut<'a>` a `Immut<'a>`.
///   Portanto, temos que chamar explicitamente o `reborrow` em um `NodeRef` mais poderoso para chegar a um método como o `into_kv`.
///
/// Todos os métodos no `NodeRef` que retornam algum tipo de referência:
/// - Pegue o `self` por valor e retorne a vida útil do `BorrowType`.
///   Às vezes, para invocar esse método, precisamos chamar o `reborrow_mut`.
/// - Tome o `self` por referência e o (implicitly) retornará o tempo de vida dessa referência, em vez do tempo de vida transportado pelo `BorrowType`.
/// Dessa forma, o verificador de empréstimo garante que o `NodeRef` permaneça emprestado enquanto a referência retornada for usada.
///   Os métodos que suportam a inserção dobram essa regra retornando um ponteiro bruto, ou seja, uma referência sem qualquer tempo de vida.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// O número de níveis que o nó e o nível das folhas estão separados, uma constante do nó que não pode ser totalmente descrita pelo `Type` e que o próprio nó não armazena.
    /// Precisamos apenas armazenar a altura do nó raiz e derivar a altura de todos os outros nós a partir dele.
    /// Deve ser zero se `Type` for `Leaf` e diferente de zero se `Type` for `Internal`.
    ///
    ///
    height: usize,
    /// O ponteiro para a folha ou nó interno.
    /// A definição de `InternalNode` garante que o ponteiro seja válido de qualquer maneira.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Descompacte uma referência de nó que foi compactada como `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Expõe os dados de um nó interno.
    ///
    /// Retorna um ptr bruto para evitar invalidar outras referências a este nó.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // SEGURANÇA: o tipo de nó estático é `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Empresta acesso exclusivo aos dados de um nó interno.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Encontra o comprimento do nó.Este é o número de chaves ou valores.
    /// O número de arestas é `len() + 1`.
    /// Observe que, apesar de ser seguro, chamar essa função pode ter o efeito colateral de invalidar as referências mutáveis que o código inseguro criou.
    ///
    pub fn len(&self) -> usize {
        // Crucialmente, só acessamos o campo `len` aqui.
        // Se BorrowType for marker::ValMut, pode haver referências mutáveis pendentes para valores que não devemos invalidar.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Retorna o número de níveis que o nó e as folhas estão separados.
    /// Altura zero significa que o nó é uma folha em si.
    /// Se você imaginar árvores com a raiz no topo, o número indica em qual elevação o nó aparece.
    /// Se você imaginar árvores com folhas no topo, o número indica a altura em que a árvore se estende acima do nó.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Remove temporariamente outra referência imutável para o mesmo nó.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Expõe a parte folha de qualquer folha ou nó interno.
    ///
    /// Retorna um ptr bruto para evitar invalidar outras referências a este nó.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // O nó deve ser válido para pelo menos a parte LeafNode.
        // Esta não é uma referência no tipo NodeRef porque não sabemos se deve ser exclusivo ou compartilhado.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Encontra o pai do nó atual.
    /// Retorna `Ok(handle)` se o nó atual realmente tem um pai, onde `handle` aponta para o edge do pai que aponta para o nó atual.
    ///
    /// Retorna `Err(self)` se o nó atual não tem pai, devolvendo o `NodeRef` original.
    ///
    /// O nome do método pressupõe que você imagine árvores com o nó raiz no topo.
    ///
    /// `edge.descend().ascend().unwrap()` e o `node.ascend().unwrap().descend()`, após o sucesso, não deve fazer nada.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Precisamos usar ponteiros brutos para nós porque, se BorrowType for marker::ValMut, pode haver referências mutáveis pendentes para valores que não devemos invalidar.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Observe que o `self` não deve estar vazio.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Observe que o `self` não deve estar vazio.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Expõe a parte folha de qualquer folha ou nó interno em uma árvore imutável.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // SEGURANÇA: não pode haver referências mutáveis nesta árvore emprestada como `Immut`.
        unsafe { &*ptr }
    }

    /// Empresta uma visão das chaves armazenadas no nó.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Semelhante ao `ascend`, obtém uma referência ao nó pai de um nó, mas também desaloca o nó atual no processo.
    /// Isso não é seguro porque o nó atual ainda estará acessível, apesar de ser desalocado.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// De forma insegura, declara ao compilador a informação estática de que este nó é um `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// De forma insegura, declara ao compilador a informação estática de que este nó é um `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Remove temporariamente outra referência mutável para o mesmo nó.Cuidado, pois esse método é muito perigoso, duplamente, pois pode não parecer perigoso imediatamente.
    ///
    /// Como os ponteiros mutáveis podem se mover em qualquer lugar ao redor da árvore, o ponteiro retornado pode ser facilmente usado para tornar o ponteiro original pendente, fora dos limites ou inválido sob regras de empréstimo empilhadas.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) considere adicionar ainda outro parâmetro de tipo ao `NodeRef` que restrinja o uso de métodos de navegação em ponteiros recuperados, evitando esta insegurança.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Empresta acesso exclusivo à parte folha de qualquer nó folha ou interno.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // SEGURANÇA: temos acesso exclusivo a todo o nó.
        unsafe { &mut *ptr }
    }

    /// Oferece acesso exclusivo à parte folha de qualquer nó folha ou interno.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // SEGURANÇA: temos acesso exclusivo a todo o nó.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Empresta acesso exclusivo a um elemento da área de armazenamento de chaves.
    ///
    /// # Safety
    /// `index` está dentro dos limites de 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // SEGURANÇA: o chamador não será capaz de chamar outros métodos em si mesmo
        // até que a referência de fatia de chave seja descartada, pois temos acesso exclusivo durante o tempo de vida do empréstimo.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Empresta acesso exclusivo a um elemento ou fatia da área de armazenamento de valor do nó.
    ///
    /// # Safety
    /// `index` está dentro dos limites de 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // SEGURANÇA: o chamador não será capaz de chamar outros métodos em si mesmo
        // até que a referência de fatia de valor seja descartada, pois temos acesso exclusivo durante o tempo de vida do empréstimo.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Empresta acesso exclusivo a um elemento ou fatia da área de armazenamento do nó para conteúdo edge.
    ///
    /// # Safety
    /// `index` está dentro dos limites de 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // SEGURANÇA: o chamador não será capaz de chamar outros métodos em si mesmo
        // até que a referência de fatia edge seja descartada, pois temos acesso exclusivo durante o tempo de vida do empréstimo.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - O nó possui mais de elementos inicializados `idx`.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Nós apenas criamos uma referência para o elemento no qual estamos interessados, para evitar aliasing com referências pendentes a outros elementos, em particular, aqueles retornados ao chamador em iterações anteriores.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Devemos forçar a ponteiros de array não dimensionados por causa do problema de Rust #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Empresta acesso exclusivo ao comprimento do nó.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Define o link do nó para seu pai edge, sem invalidar outras referências ao nó.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Limpa o link da raiz para seu pai edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Adiciona um par de valores-chave ao final do nó.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Cada item retornado pelo `range` é um índice edge válido para o nó.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Adiciona um par de valor-chave e um edge para ir para a direita desse par, até o final do nó.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Verifica se um nó é um nó `Internal` ou um nó `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Uma referência a um par de valor-chave específico ou edge dentro de um nó.
/// O parâmetro `Node` deve ser um `NodeRef`, enquanto o `Type` pode ser `KV` (significando um identificador em um par de valores-chave) ou `Edge` (significando um identificador em um edge).
///
/// Observe que mesmo os nós `Leaf` podem ter alças `Edge`.
/// Em vez de representar um ponteiro para um nó filho, eles representam os espaços onde os ponteiros filhos iriam entre os pares de valores-chave.
/// Por exemplo, em um nó com comprimento 2, haveria 3 localizações edge possíveis, uma à esquerda do nó, uma entre os dois pares e uma à direita do nó.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Não precisamos de toda a generalidade do `#[derive(Clone)]`, já que o único momento em que o `Node` será `Clone`able é quando for uma referência imutável e, portanto, `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Recupera o nó que contém o edge ou par de valor-chave para o qual este identificador aponta.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Retorna a posição desta alça no nó.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Cria um novo identificador para um par de valores-chave no `node`.
    /// Inseguro porque o chamador deve garantir que o `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Pode ser uma implementação pública de PartialEq, mas usada apenas neste módulo.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Tira temporariamente outra alça imutável no mesmo local.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Não podemos usar Handle::new_kv ou Handle::new_edge porque não sabemos nosso tipo
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// De forma insegura, declara ao compilador a informação estática de que o nó do identificador é um `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Remove temporariamente outro identificador mutável no mesmo local.
    /// Cuidado, pois esse método é muito perigoso, duplamente, pois pode não parecer perigoso imediatamente.
    ///
    ///
    /// Para obter detalhes, consulte `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Não podemos usar Handle::new_kv ou Handle::new_edge porque não sabemos nosso tipo
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Cria um novo identificador para um edge em `node`.
    /// Inseguro porque o chamador deve garantir que o `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Dado um índice edge onde queremos inserir em um nó cheio até a capacidade, calcula um índice KV sensível de um ponto de divisão e onde realizar a inserção.
///
/// O objetivo do ponto de divisão é que sua chave e valor acabem em um nó pai;
/// as chaves, valores e arestas à esquerda do ponto de divisão se tornam o filho esquerdo;
/// as chaves, valores e arestas à direita do ponto de divisão se tornam o filho certo.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // O problema do Rust #74834 tenta explicar essas regras simétricas.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Insere um novo par de valores-chave entre os pares de valores-chave à direita e à esquerda deste edge.
    /// Este método assume que há espaço suficiente no nó para o novo par caber.
    ///
    /// O ponteiro retornado aponta para o valor inserido.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Insere um novo par de valores-chave entre os pares de valores-chave à direita e à esquerda deste edge.
    /// Este método divide o nó se não houver espaço suficiente.
    ///
    /// O ponteiro retornado aponta para o valor inserido.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Corrige o ponteiro pai e o índice no nó filho ao qual este edge se vincula.
    /// Isso é útil quando a ordem das arestas foi alterada,
    fn correct_parent_link(self) {
        // Crie backpointer sem invalidar outras referências ao nó.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Insere um novo par de valor-chave e um edge que irá para a direita desse novo par entre este edge e o par de valor-chave à direita deste edge.
    /// Este método assume que há espaço suficiente no nó para o novo par caber.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Insere um novo par de valor-chave e um edge que irá para a direita desse novo par entre este edge e o par de valor-chave à direita deste edge.
    /// Este método divide o nó se não houver espaço suficiente.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Insere um novo par de valores-chave entre os pares de valores-chave à direita e à esquerda deste edge.
    /// Este método divide o nó se não houver espaço suficiente e tenta inserir a parte separada no nó pai recursivamente, até que a raiz seja alcançada.
    ///
    ///
    /// Se o resultado retornado for um `Fit`, o nó de seu identificador pode ser o nó deste edge ou um ancestral.
    /// Se o resultado retornado for um `Split`, o campo `left` será o nó raiz.
    /// O ponteiro retornado aponta para o valor inserido.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Encontra o nó apontado por este edge.
    ///
    /// O nome do método pressupõe que você imagine árvores com o nó raiz no topo.
    ///
    /// `edge.descend().ascend().unwrap()` e o `node.ascend().unwrap().descend()`, após o sucesso, não deve fazer nada.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Precisamos usar ponteiros brutos para nós porque, se BorrowType for marker::ValMut, pode haver referências mutáveis pendentes para valores que não devemos invalidar.
        // Não há preocupação em acessar o campo de altura porque esse valor é copiado.
        // Esteja ciente de que, uma vez que o ponteiro do nó é desreferenciado, acessamos o array arestas com uma referência (Rust problema #73987) e invalidamos qualquer outra referência para ou dentro do array, se houver alguma por perto.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Não podemos chamar métodos separados de chave e valor, porque chamar o segundo invalida a referência retornada pelo primeiro.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Substitua a chave e o valor aos quais o identificador KV se refere.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Ajuda a implementações de `split` para um `NodeType` específico, cuidando dos dados de folha.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Divide o nó subjacente em três partes:
    ///
    /// - O nó é truncado para conter apenas os pares de valores-chave à esquerda deste identificador.
    /// - A chave e o valor apontado por este identificador são extraídos.
    /// - Todos os pares de valores-chave à direita desse identificador são colocados em um nó recém-alocado.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Remove o par de valor-chave apontado por este identificador e o retorna, junto com o edge no qual o par de valor-chave foi recolhido.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Divide o nó subjacente em três partes:
    ///
    /// - O nó é truncado para conter apenas as bordas e pares de valores-chave à esquerda deste identificador.
    /// - A chave e o valor apontado por este identificador são extraídos.
    /// - Todas as arestas e pares de valores-chave à direita deste identificador são colocados em um nó recém-alocado.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Representa uma sessão para avaliar e realizar uma operação de equilíbrio em torno de um par de valor-chave interno.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Escolhe um contexto de balanceamento envolvendo o nó como filho, portanto, entre o KV imediatamente à esquerda ou à direita no nó pai.
    /// Retorna um `Err` se não houver pai.
    /// Panics se o pai estiver vazio.
    ///
    /// Prefere o lado esquerdo, para ser ótimo se o nó fornecido estiver de alguma forma insuficiente, significando aqui apenas que ele tem menos elementos do que seu irmão esquerdo e do que seu irmão direito, se existirem.
    /// Nesse caso, mesclar com o irmão esquerdo é mais rápido, uma vez que precisamos apenas mover os N elementos do nó, em vez de deslocá-los para a direita e mover mais de N elementos na frente.
    /// Roubar do irmão esquerdo também é tipicamente mais rápido, uma vez que precisamos apenas deslocar os N elementos do nó para a direita, em vez de deslocar pelo menos N dos elementos do irmão para a esquerda.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Retorna se a fusão é possível, ou seja, se há espaço suficiente em um nó para combinar o KV central com os dois nós filhos adjacentes.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Executa uma mesclagem e permite que um fechamento decida o que retornar.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // SEGURANÇA: a altura dos nós sendo mesclados é um abaixo da altura
                // do nó deste edge, portanto acima de zero, então eles são internos.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Mescla o par de valores-chave do pai e os dois nós filhos adjacentes no nó filho esquerdo e retorna o nó pai reduzido.
    ///
    ///
    /// Panics a menos que `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Mescla o par de valores-chave do pai e os dois nós filhos adjacentes no nó filho esquerdo e retorna esse nó filho.
    ///
    ///
    /// Panics a menos que `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Mescla o par de valores-chave do pai e os dois nós filhos adjacentes no nó filho esquerdo e retorna o identificador edge naquele nó filho onde o filho edge rastreado acabou,
    ///
    ///
    /// Panics a menos que `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Remove um par de valor-chave do filho esquerdo e o coloca no armazenamento de valor-chave do pai, enquanto empurra o par de valor-chave pai antigo para o filho direito.
    ///
    /// Retorna um identificador para o edge no filho certo correspondente a onde o edge original especificado por `track_right_edge_idx` terminou.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Remove um par de valor-chave do filho direito e o coloca no armazenamento de valor-chave do pai, enquanto empurra o par de valor-chave pai antigo para o filho esquerdo.
    ///
    /// Retorna um identificador para o edge no filho esquerdo especificado por `track_left_edge_idx`, que não se moveu.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Isso rouba semelhante ao `steal_left`, mas rouba vários elementos de uma vez.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Certifique-se de que podemos roubar com segurança.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Mova os dados da folha.
            {
                // Abra espaço para elementos roubados na criança certa.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Mova os elementos do filho esquerdo para o direito.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Mova o par roubado mais à esquerda para o pai.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Mova o par de valores-chave do pai para o filho certo.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Abra espaço para bordas roubadas.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Roube bordas.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// O clone simétrico de `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Certifique-se de que podemos roubar com segurança.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Mova os dados da folha.
            {
                // Mova o par roubado mais à direita para o pai.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Mova o par de valores-chave do pai para o filho esquerdo.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Mova os elementos do filho direito para o esquerdo.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Preencha a lacuna onde os elementos roubados costumavam estar.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Roube bordas.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Preencha a lacuna onde as bordas roubadas costumavam estar.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Remove qualquer informação estática afirmando que este nó é um nó `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Remove qualquer informação estática afirmando que este nó é um nó `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Verifica se o nó subjacente é um nó `Internal` ou um nó `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Mova o sufixo após `self` de um nó para outro.`right` deve estar vazio.
    /// O primeiro edge do `right` permanece inalterado.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Resultado da inserção, quando um nó precisava se expandir além de sua capacidade.
pub struct SplitResult<'a, K, V, NodeType> {
    // Nó alterado na árvore existente com elementos e arestas que pertencem à esquerda do `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Alguma chave e valor se separaram, para serem inseridos em outro lugar.
    pub kv: (K, V),
    // Novo nó próprio, não anexado, com elementos e arestas que pertencem à direita do `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Se as referências de nó desse tipo emprestado permitem a passagem para outros nós na árvore.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal não é necessário, acontece usando o resultado do `borrow_mut`.
        // Ao desativar a travessia e apenas criar novas referências às raízes, sabemos que cada referência do tipo `Owned` é para um nó raiz.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Insere um valor em uma fatia de elementos inicializados seguidos por um elemento não inicializado.
///
/// # Safety
/// A fatia tem mais de elementos `idx`.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Remove e retorna um valor de uma fatia de todos os elementos inicializados, deixando para trás um elemento não inicializado final.
///
///
/// # Safety
/// A fatia tem mais de elementos `idx`.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Desloca os elementos em uma posição `distance` de fatia para a esquerda.
///
/// # Safety
/// A fatia tem pelo menos elementos `distance`.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Desloca os elementos em uma posição de fatia `distance` para a direita.
///
/// # Safety
/// A fatia tem pelo menos elementos `distance`.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Move todos os valores de uma fatia de elementos inicializados para uma fatia de elementos não inicializados, deixando para trás `src` como todos não inicializados.
///
/// Funciona como o `dst.copy_from_slice(src)`, mas não exige que o `T` seja o `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;