use core::intrinsics;
use core::mem;
use core::ptr;

/// Isso substitui o valor por trás da referência exclusiva do `v` chamando a função relevante.
///
///
/// Se um panic ocorrer no fechamento do `change`, todo o processo será abortado.
#[allow(dead_code)] // manter como ilustração e para uso future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Isso substitui o valor por trás da referência exclusiva do `v` chamando a função relevante e retorna um resultado obtido ao longo do caminho.
///
///
/// Se um panic ocorrer no fechamento do `change`, todo o processo será abortado.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}