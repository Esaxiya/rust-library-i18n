use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Remove temporariamente outro equivalente imutável do mesmo intervalo.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Encontra as bordas das folhas distintas que delimitam um intervalo especificado em uma árvore.
    /// Retorna um par de alças diferentes na mesma árvore ou um par de opções vazias.
    ///
    /// # Safety
    ///
    /// A menos que `BorrowType` seja `Immut`, não use as alças duplicadas para visitar o mesmo KV duas vezes.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Equivalente a `(root1.first_leaf_edge(), root2.last_leaf_edge())`, mas mais eficiente.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Encontra o par de arestas de folhas que delimitam um intervalo específico em uma árvore.
    ///
    /// O resultado é significativo apenas se a árvore for ordenada por chave, como a árvore em um `BTreeMap`.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // SEGURANÇA: nosso tipo de empréstimo é imutável.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Encontra o par de arestas de folha que delimita uma árvore inteira.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Divide uma referência única em um par de arestas de folha delimitando um intervalo especificado.
    /// O resultado são referências não exclusivas que permitem a mutação (some), que devem ser usadas com cuidado.
    ///
    /// O resultado é significativo apenas se a árvore for ordenada por chave, como a árvore em um `BTreeMap`.
    ///
    ///
    /// # Safety
    /// Não use as alças duplicadas para visitar o mesmo KV duas vezes.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Divide uma referência única em um par de arestas de folha delimitando toda a extensão da árvore.
    /// Os resultados são referências não exclusivas que permitem a mutação (apenas de valores), portanto, devem ser usados com cuidado.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Duplicamos a raiz NodeRef aqui-nunca visitaremos o mesmo KV duas vezes e nunca terminaremos com referências de valor sobrepostas.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Divide uma referência única em um par de arestas de folha delimitando toda a extensão da árvore.
    /// Os resultados são referências não únicas que permitem mutações destrutivas massivas, portanto, devem ser usados com o máximo cuidado.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Duplicamos o NodeRef raiz aqui-nunca iremos acessá-lo de uma forma que se sobreponha às referências obtidas da raiz.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Dado um identificador folha edge, retorna [`Result::Ok`] com um identificador para o KV vizinho no lado direito, que está no mesmo nó folha ou em um nó ancestral.
    ///
    /// Se a folha edge for a última na árvore, retorna [`Result::Err`] com o nó raiz.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Dado um identificador folha edge, retorna [`Result::Ok`] com um identificador para o KV vizinho no lado esquerdo, que está no mesmo nó folha ou em um nó ancestral.
    ///
    /// Se a folha edge for a primeira na árvore, retorna [`Result::Err`] com o nó raiz.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Dado um identificador edge interno, retorna [`Result::Ok`] com um identificador para o KV vizinho no lado direito, que está no mesmo nó interno ou em um nó ancestral.
    ///
    /// Se o edge interno for o último na árvore, retorna [`Result::Err`] com o nó raiz.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Dado um identificador de folha edge em uma árvore morrendo, retorna a próxima folha edge no lado direito, e o par de valores-chave entre eles, que está no mesmo nó folha, em um nó ancestral ou inexistente.
    ///
    ///
    /// Esse método também desaloca qualquer node(s) que atingir o fim.
    /// Isso implica que, se não houver mais par de valores-chave, todo o restante da árvore terá sido desalocado e não haverá mais nada a ser retornado.
    ///
    /// # Safety
    /// O edge fornecido não deve ter sido devolvido anteriormente pela contraparte `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Dado um identificador de folha edge em uma árvore morrendo, retorna a próxima folha edge no lado esquerdo, e o par de valores-chave entre eles, que está no mesmo nó folha, em um nó ancestral ou inexistente.
    ///
    ///
    /// Esse método também desaloca qualquer node(s) que atingir o fim.
    /// Isso implica que, se não houver mais par de valores-chave, todo o restante da árvore terá sido desalocado e não haverá mais nada a ser retornado.
    ///
    /// # Safety
    /// O edge fornecido não deve ter sido devolvido anteriormente pela contraparte `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Desaloca uma pilha de nós da folha até a raiz.
    /// Esta é a única maneira de desalocar o restante de uma árvore depois que o `deallocating_next` e o `deallocating_next_back` estão mordiscando os dois lados da árvore e atingem o mesmo edge.
    /// Como ele deve ser chamado apenas quando todas as chaves e valores forem retornados, nenhuma limpeza é feita em qualquer uma das chaves ou valores.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Move a alça edge da folha para a próxima folha edge e retorna as referências à chave e ao valor intermediário.
    ///
    ///
    /// # Safety
    /// Deve haver outro KV na direção percorrida.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Move a alça edge da folha para a folha anterior edge e retorna as referências à chave e ao valor intermediário.
    ///
    ///
    /// # Safety
    /// Deve haver outro KV na direção percorrida.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Move a alça edge da folha para a próxima folha edge e retorna as referências à chave e ao valor intermediário.
    ///
    ///
    /// # Safety
    /// Deve haver outro KV na direção percorrida.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Fazer isso por último é mais rápido, de acordo com os benchmarks.
        kv.into_kv_valmut()
    }

    /// Move a alça edge da folha para a folha anterior e retorna as referências à chave e ao valor intermediário.
    ///
    ///
    /// # Safety
    /// Deve haver outro KV na direção percorrida.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Fazer isso por último é mais rápido, de acordo com os benchmarks.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Move a alça edge da folha para a próxima folha edge e retorna a chave e o valor intermediário, desalocando qualquer nó deixado para trás enquanto deixa o edge correspondente em seu nó pai pendente.
    ///
    /// # Safety
    /// - Deve haver outro KV na direção percorrida.
    /// - Esse KV não foi retornado anteriormente pela contraparte `next_back_unchecked` em nenhuma cópia das alças sendo usadas para atravessar a árvore.
    ///
    /// A única maneira segura de prosseguir com o identificador atualizado é compará-lo, descartá-lo, chamar esse método novamente, sujeito às suas condições de segurança, ou chamar a contraparte `next_back_unchecked` sujeito às suas condições de segurança.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Move a alça edge da folha para a folha anterior edge e retorna a chave e o valor intermediário, desalocando qualquer nó deixado para trás enquanto deixa o edge correspondente em seu nó pai pendente.
    ///
    /// # Safety
    /// - Deve haver outro KV na direção percorrida.
    /// - Essa folha edge não foi retornada anteriormente pela contraparte `next_unchecked` em nenhuma cópia das alças sendo usadas para atravessar a árvore.
    ///
    /// A única maneira segura de prosseguir com o identificador atualizado é compará-lo, descartá-lo, chamar esse método novamente, sujeito às suas condições de segurança, ou chamar a contraparte `next_unchecked` sujeito às suas condições de segurança.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Retorna a folha mais à esquerda edge dentro ou abaixo de um nó, em outras palavras, o edge que você precisa primeiro ao navegar para frente (ou por último ao navegar para trás).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Retorna a folha mais à direita edge dentro ou abaixo de um nó, em outras palavras, o edge que você precisa por último ao navegar para frente (ou primeiro ao navegar para trás).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Visita os nós folha e KVs internos na ordem das chaves ascendentes, e também visita os nós internos como um todo em uma profundidade de primeira ordem, o que significa que os nós internos precedem seus KVs individuais e seus nós filhos.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Calcula o número de elementos em uma (sub) árvore.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Retorna a folha edge mais próxima de um KV para navegação direta.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Retorna a folha edge mais próxima de um KV para navegação para trás.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}