use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modela um novo amanhã de alguma referência única, quando você sabe que o novo amanhã e todos os seus descendentes (ou seja, todos os ponteiros e referências derivadas dele) não serão mais usados em algum ponto, após o qual você deseja usar a referência única original novamente .
///
///
/// O verificador de empréstimos geralmente lida com esse empilhamento de empréstimos para você, mas alguns fluxos de controle que realizam esse empilhamento são muito complicados para serem seguidos pelo compilador.
/// Um `DormantMutRef` permite que você verifique se você mesmo está emprestando, ao mesmo tempo em que expressa sua natureza empilhada e encapsula o código de ponteiro bruto necessário para fazer isso sem comportamento indefinido.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Faça um empréstimo exclusivo e imediatamente o peça novamente.
    /// Para o compilador, o tempo de vida da nova referência é o mesmo que o tempo de vida da referência original, mas você promisa para usá-lo por um período mais curto.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SEGURANÇA: nós mantemos o empréstimo ao longo de 'a via `_marker`, e expomos
        // apenas esta referência, por isso é único.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Reverta para o empréstimo exclusivo inicialmente capturado.
    ///
    /// # Safety
    ///
    /// O novo amanhã deve ter terminado, ou seja, a referência retornada pelo `new` e todos os ponteiros e referências dele derivados não devem ser mais utilizados.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // SEGURANÇA: nossas próprias condições de segurança implicam que esta referência seja novamente única.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;