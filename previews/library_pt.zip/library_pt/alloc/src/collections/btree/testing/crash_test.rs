use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// Um blueprint para instâncias fictícias de teste de travamento que monitoram eventos específicos.
/// Algumas instâncias podem ser configuradas para panic em algum ponto.
/// Os eventos são `clone`, `drop` ou algum `query` anônimo.
///
/// Bonecos de teste de falha são identificados e ordenados por um id, para que possam ser usados como chaves em um BTreeMap.
/// A implementação usa intencionalmente não depende de nada definido no crate, além do `Debug` trait.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// Cria um design fictício de teste de travamento.O `id` determina a ordem e a igualdade das instâncias.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// Cria uma instância de um simulador de teste de travamento que registra quais eventos ele experimenta e, opcionalmente, panics.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// Retorna quantas vezes as instâncias do dummy foram clonadas.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// Retorna quantas vezes as instâncias do dummy foram descartadas.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// Retorna quantas vezes as instâncias do manequim tiveram seu membro `query` invocado.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// Alguma consulta anônima, o resultado da qual já foi fornecido.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}