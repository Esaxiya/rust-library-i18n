use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Acrescenta todos os pares de valores-chave da união de dois iteradores ascendentes, incrementando uma variável `length` ao longo do caminho.O último torna mais fácil para o chamador evitar um vazamento quando um manipulador de queda entra em pânico.
    ///
    /// Se ambos os iteradores produzirem a mesma chave, este método descarta o par do iterador esquerdo e anexa o par do iterador direito.
    ///
    /// Se você deseja que a árvore termine em ordem estritamente crescente, como para um `BTreeMap`, ambos os iteradores devem produzir chaves em ordem estritamente crescente, cada uma maior que todas as chaves na árvore, incluindo quaisquer chaves já existentes na árvore na entrada.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Nós nos preparamos para fundir o `left` e o `right` em uma sequência ordenada no tempo linear.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Enquanto isso, construímos uma árvore a partir da sequência ordenada em tempo linear.
        self.bulk_push(iter, length)
    }

    /// Empurra todos os pares de valores-chave para o final da árvore, incrementando uma variável `length` ao longo do caminho.
    /// O último torna mais fácil para o chamador evitar um vazamento quando o iterador entra em pânico.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Faça a iteração por todos os pares de valores-chave, empurrando-os para os nós no nível certo.
        for (key, value) in iter {
            // Tente colocar o par de valores-chave no nó folha atual.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Não há espaço sobrando, suba e empurre lá.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Encontrado um nó com espaço restante, pressione aqui.
                                open_node = parent;
                                break;
                            } else {
                                // Suba novamente.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Estamos no topo, crie um novo nó raiz e empurre para lá.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Empurre o par de valores-chave e a nova subárvore direita.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Vá até a folha mais à direita novamente.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Incremente o comprimento a cada iteração para garantir que o mapa elimine os elementos anexados, mesmo se o avanço do iterador entrar em pânico.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Um iterador para mesclar duas sequências classificadas em uma
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Se duas chaves forem iguais, retorna o par de valores-chave da fonte certa.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}