//! Uma fila de prioridade implementada com um heap binário.
//!
//! A inserção e o estalo do maior elemento têm complexidade de tempo *O*(log(*n*)).
//! Verificar o maior elemento é *O*(1).A conversão de um vector em um heap binário pode ser feito no local e tem complexidade *O*(*n*).
//! Um heap binário também pode ser convertido em um vector classificado no local, permitindo que seja usado para um heapsort *O*(*n*\*log(* n*)) local no local.
//!
//! # Examples
//!
//! Este é um exemplo maior que implementa o [Dijkstra's algorithm][dijkstra] para solucionar o [shortest path problem][sssp] em um [directed graph][dir_graph].
//!
//! Mostra como usar o [`BinaryHeap`] com tipos personalizados.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // A fila de prioridade depende do `Ord`.
//! // Implemente explicitamente o trait para que a fila se torne um heap mínimo em vez de um heap máximo.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Observe que invertemos os custos do pedido.
//!         // Em caso de empate, comparamos as posições, esta etapa é necessária para tornar as implementações de `PartialEq` e `Ord` consistentes.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` também precisa ser implementado.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Cada nó é representado como um `usize`, para uma implementação mais curta.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Algoritmo de caminho mais curto de Dijkstra.
//!
//! // Comece no `start` e use o `dist` para rastrear a distância mais curta atual para cada nó.Esta implementação não é eficiente em termos de memória, pois pode deixar nós duplicados na fila.
//! //
//! // Ele também usa `usize::MAX` como um valor sentinela, para uma implementação mais simples.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [nó]=distância mais curta atual de `start` a `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Estamos no `start`, com custo zero
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Examine a fronteira com nós de custo mais baixo primeiro (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Alternativamente, poderíamos ter continuado a encontrar todos os caminhos mais curtos
//!         if position == goal { return Some(cost); }
//!
//!         // Importante porque podemos já ter encontrado uma maneira melhor
//!         if cost > dist[position] { continue; }
//!
//!         // Para cada nó que podemos alcançar, veja se podemos encontrar um caminho com um custo menor passando por este nó
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Em caso afirmativo, adicione-o à fronteira e continue
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Relaxamento, agora encontramos uma maneira melhor
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Objetivo não alcançável
//!     None
//! }
//!
//! fn main() {
//!     // Este é o gráfico direcionado que vamos usar.
//!     // Os números dos nós correspondem aos diferentes estados, e os pesos edge simbolizam o custo de mover de um nó para outro.
//!     //
//!     // Observe que as bordas são unilaterais.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10|
//!     //                   +---------------+
//!     //
//!     // O grafo é representado como uma lista de adjacências onde cada índice, correspondendo a um valor de nó, possui uma lista de arestas de saída.
//!     // Escolhido por sua eficiência.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Nó 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Nó 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Nó 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Nó 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Nó 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Uma fila de prioridade implementada com um heap binário.
///
/// Este será um heap máximo.
///
/// É um erro lógico um item ser modificado de forma que a ordem do item em relação a qualquer outro item, conforme determinado pelo `Ord` trait, mude enquanto ele está na pilha.
///
/// Normalmente, isso só é possível por meio de `Cell`, `RefCell`, estado global, I/O ou código não seguro.
/// O comportamento resultante de tal erro lógico não é especificado, mas não resultará em comportamento indefinido.
/// Isso pode incluir panics, resultados incorretos, abortos, vazamentos de memória e não encerramento.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // A inferência de tipo nos permite omitir uma assinatura de tipo explícita (que seria `BinaryHeap<i32>` neste exemplo).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Podemos usar peek para ver o próximo item na pilha.
/// // Neste caso, não há itens lá ainda, então obtemos Nenhum.
/// assert_eq!(heap.peek(), None);
///
/// // Vamos adicionar algumas pontuações ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Agora, espreitar mostra o item mais importante da pilha.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Podemos verificar o comprimento de uma pilha.
/// assert_eq!(heap.len(), 3);
///
/// // Podemos iterar sobre os itens no heap, embora eles sejam retornados em uma ordem aleatória.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Se, em vez disso, estourarmos essas pontuações, elas devem voltar em ordem.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Podemos limpar a pilha de todos os itens restantes.
/// heap.clear();
///
/// // A pilha agora deve estar vazia.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Tanto o `std::cmp::Reverse` quanto uma implementação `Ord` customizada podem ser usados para tornar o `BinaryHeap` um min-heap.
/// Isso faz com que o `heap.pop()` retorne o menor valor em vez do maior.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Envolva valores em `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Se estourarmos essas pontuações agora, elas devem voltar na ordem inversa.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Complexidade de tempo
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// O valor para `push` é um custo esperado;a documentação do método fornece uma análise mais detalhada.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Estrutura envolvendo uma referência mutável para o maior item em um `BinaryHeap`.
///
///
/// Este `struct` é criado pelo método [`peek_mut`] no [`BinaryHeap`].
/// Veja sua documentação para mais.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // SEGURANÇA: PeekMut é instanciado apenas para heaps não vazios.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // SEGURO: PeekMut só é instanciado para pilhas não vazias
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // SEGURO: PeekMut só é instanciado para pilhas não vazias
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Remove o valor peeked do heap e o retorna.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Cria um `BinaryHeap<T>` vazio.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Cria um `BinaryHeap` vazio como um heap máximo.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Cria um `BinaryHeap` vazio com uma capacidade específica.
    /// Isso pré-aloca memória suficiente para os elementos do `capacity`, de modo que o `BinaryHeap` não precise ser realocado até que contenha pelo menos essa quantidade de valores.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Retorna uma referência mutável para o maior item no heap binário ou `None` se estiver vazio.
    ///
    /// Note: Se o valor `PeekMut` vazar, o heap pode estar em um estado inconsistente.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Complexidade de tempo
    ///
    /// Se o item for modificado, o pior caso de complexidade de tempo é *O*(log(*n*)), caso contrário, é *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Remove o maior item do heap binário e o retorna, ou `None` se estiver vazio.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Complexidade de tempo
    ///
    /// O pior caso de custo de `pop` em um heap contendo *n* elementos é *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // SEGURANÇA: !self.is_empty() significa que self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Coloca um item no heap binário.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Complexidade de tempo
    ///
    /// O custo esperado de `push`, calculado sobre cada ordem possível dos elementos que estão sendo empurrados, e sobre um número suficientemente grande de impulsos, é *O*(1).
    ///
    /// Esta é a métrica de custo mais significativa ao enviar elementos que *não* já estão em algum padrão classificado.
    ///
    /// A complexidade do tempo se degrada se os elementos forem empurrados em ordem predominantemente ascendente.
    /// No pior caso, os elementos são colocados em ordem crescente de classificação e o custo amortizado por push é *O*(log(*n*)) em relação a um heap contendo *n* elementos.
    ///
    /// O custo do pior caso de uma chamada *única* para o `push` é *O*(*n*).O pior caso ocorre quando a capacidade se esgota e precisa ser redimensionada.
    /// O custo de redimensionamento foi amortizado nas figuras anteriores.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // SEGURANÇA: Como lançamos um novo item, significa que
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Consome o `BinaryHeap` e retorna um vector na ordem (ascending) classificada.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // SEGURANÇA: `end` vai de `self.len() - 1` para 1 (ambos incluídos),
            //  portanto, é sempre um índice válido para acessar.
            //  É seguro acessar o índice 0 (ou seja, `ptr`), porque
            //  1 <=fim <self.len(), o que significa self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // SEGURANÇA: `end` vai de `self.len() - 1` para 1 (ambos incluídos), então:
            //  0 <1 <=fim <= self.len(), 1 <self.len() O que significa 0 <fim e fim <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // As implementações de sift_up e sift_down usam blocos inseguros a fim de mover um elemento para fora do vector (deixando para trás um buraco), deslocar ao longo dos outros e mover o elemento removido de volta para o vector no local final do buraco.
    //
    // O tipo `Hole` é usado para representar isso e certifique-se de que o buraco seja preenchido no final de seu escopo, mesmo em panic.
    // Usar um furo reduz o fator constante em comparação com o uso de trocas, que envolve o dobro de movimentos.
    //
    //
    //
    //

    /// # Safety
    ///
    /// O chamador deve garantir esse `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Retire o valor em `pos` e crie um furo.
        // SEGURANÇA: O chamador garante que pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // SEGURANÇA: hole.pos()> iniciar>=0, o que significa hole.pos()> 0
            //  e, portanto, hole.pos(), 1 não posso underflow.
            //  Isso garante que o pai <hole.pos(), portanto, é um índice válido e também!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // SEGURANÇA: O mesmo que acima
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Pegue um elemento em `pos` e mova-o para baixo no heap, enquanto seus filhos são maiores.
    ///
    ///
    /// # Safety
    ///
    /// O chamador deve garantir esse `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // SEGURANÇA: O chamador garante que pos <end <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Invariante de loop: filho==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // compare com o maior dos dois filhos SEGURANÇA: filho <fim, 1 <self.len() e filho + 1 <fim <= self.len(), então eles são índices válidos.
            //
            //  filho==2 *hole.pos() + 1!= hole.pos() e filho + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 ou 2* hole.pos() + 2 pode estourar se T for um ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // se já estamos em ordem, pare.
            // SEGURANÇA: a criança agora é a velha criança ou a velha criança + 1
            //  Já provamos que ambos são <self.len() e!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // SEGURANÇA: igual ao anterior.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // SEGURANÇA: &&curto-circuito, o que significa que no
        //  segunda condição já é verdade que filho==fim, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // SEGURANÇA: criança já provou ser um índice válido e
            //  filho==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// O chamador deve garantir esse `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // SEGURANÇA: pos <len é garantido pelo chamador e
        //  obviamente len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Pegue um elemento em `pos` e mova-o para baixo na pilha, então peneire-o até sua posição.
    ///
    ///
    /// Note: Isso é mais rápido quando o elemento é conhecido por ser grande/deveria estar mais próximo da parte inferior.
    ///
    /// # Safety
    ///
    /// O chamador deve garantir esse `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // SEGURANÇA: O chamador garante que pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Invariante de loop: filho==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // SEGURANÇA: criança <fim, 1 <self.len() e
            //  child + 1 <end <= self.len(), então eles são índices válidos.
            //  filho==2 *hole.pos() + 1!= hole.pos() e filho + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 ou 2* hole.pos() + 2 pode estourar se T for um ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // SEGURANÇA: O mesmo que acima
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // SEGURANÇA: filho==fim, 1 <self.len(), então é um índice válido
            //  e filho==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // SEGURANÇA: pos é a posição no buraco e já foi comprovada
        //  para ser um índice válido.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // SEGURANÇA: n começa em self.len()/2 e desce para 0.
            //  O único caso quando! (N <self.len()) é se self.len() ==0, mas é excluído pela condição de loop.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Move todos os elementos do `other` para o `self`, deixando o `other` vazio.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` leva operações O(len1 + len2) e cerca de 2 *(len1 + len2) comparações no pior caso, enquanto `extend` leva operações O(len2* log(len1)) e cerca de 1 *len2* comparações log_2(len1) no pior caso, assumindo len1>= len2.
        // Para pilhas maiores, o ponto de cruzamento não segue mais esse raciocínio e foi determinado empiricamente.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Retorna um iterador que recupera os elementos na ordem do heap.
    /// Os elementos recuperados são removidos do heap original.
    /// Os elementos restantes serão removidos ao soltar na ordem de heap.
    ///
    /// Note:
    /// * `.drain_sorted()` é *O*(*n*\*log(* n*)); muito mais lento que o `.drain()`.
    ///   Você deve usar o último para a maioria dos casos.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // remove todos os elementos em ordem de heap
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Retém apenas os elementos especificados pelo predicado.
    ///
    /// Em outras palavras, remova todos os elementos `e` de forma que `f(&e)` retorne `false`.
    /// Os elementos são visitados em ordem não classificada (e não especificada).
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // mantenha apenas números pares
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Retorna um iterador visitando todos os valores no vector subjacente, em ordem arbitrária.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Imprima 1, 2, 3, 4 em ordem arbitrária
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Retorna um iterador que recupera os elementos na ordem do heap.
    /// Este método consome o heap original.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Retorna o maior item no heap binário ou `None` se estiver vazio.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Complexidade de tempo
    ///
    /// O custo é *O*(1) no pior caso.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Retorna o número de elementos que o heap binário pode conter sem realocar.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Reserva a capacidade mínima para exatamente `additional` mais elementos a serem inseridos no `BinaryHeap` fornecido.
    /// Não faz nada se a capacidade já for suficiente.
    ///
    /// Observe que o alocador pode fornecer à coleção mais espaço do que ele solicita.
    /// Portanto, a capacidade não pode ser considerada precisamente mínima.
    /// Prefira [`reserve`] se inserções future são esperadas.
    ///
    /// # Panics
    ///
    /// Panics se a nova capacidade ultrapassar `usize`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Reserva capacidade para pelo menos `additional` mais elementos a serem inseridos no `BinaryHeap`.
    /// A coleção pode reservar mais espaço para evitar realocações frequentes.
    ///
    /// # Panics
    ///
    /// Panics se a nova capacidade ultrapassar `usize`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Descarta o máximo de capacidade adicional possível.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Descarta a capacidade com um limite inferior.
    ///
    /// A capacidade permanecerá pelo menos tão grande quanto o comprimento e o valor fornecido.
    ///
    ///
    /// Se a capacidade atual for menor que o limite inferior, este é um ambiente autônomo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Consome o `BinaryHeap` e retorna o vector subjacente em ordem arbitrária.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Irá imprimir em alguma ordem
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Retorna o comprimento do heap binário.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Verifica se o heap binário está vazio.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Limpa o heap binário, retornando um iterador sobre os elementos removidos.
    ///
    /// Os elementos são removidos em ordem arbitrária.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Exclui todos os itens do heap binário.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// O furo representa um furo em uma fatia, ou seja, um índice sem valor válido (porque foi movido ou duplicado).
///
/// Em queda, o `Hole` restaurará a fatia preenchendo a posição do orifício com o valor que foi removido originalmente.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Crie um novo `Hole` no índice `pos`.
    ///
    /// Inseguro porque pos deve estar dentro da fatia de dados.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // SEGURO: o pos deve estar dentro da fatia
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Retorna uma referência ao elemento removido.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Retorna uma referência ao elemento em `index`.
    ///
    /// Inseguro porque o índice deve estar dentro da fatia de dados e não igual a pos.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Mova o buraco para o novo local
    ///
    /// Inseguro porque o índice deve estar dentro da fatia de dados e não igual a pos.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // preencha o buraco novamente
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Um iterador sobre os elementos de um `BinaryHeap`.
///
/// Este `struct` foi criado pelo [`BinaryHeap::iter()`].
/// Veja sua documentação para mais.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Remover em favor de `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Um iterador proprietário sobre os elementos de um `BinaryHeap`.
///
/// Este `struct` é criado pelo [`BinaryHeap::into_iter()`] (fornecido pelo `IntoIterator` trait).
/// Veja sua documentação para mais.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Um iterador de drenagem sobre os elementos de um `BinaryHeap`.
///
/// Este `struct` foi criado pelo [`BinaryHeap::drain()`].
/// Veja sua documentação para mais.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Um iterador de drenagem sobre os elementos de um `BinaryHeap`.
///
/// Este `struct` foi criado pelo [`BinaryHeap::drain_sorted()`].
/// Veja sua documentação para mais.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Remove os elementos do heap na ordem do heap.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Converte um `Vec<T>` em um `BinaryHeap<T>`.
    ///
    /// Essa conversão ocorre no local e tem complexidade de tempo *O*(*n*).
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Converte um `BinaryHeap<T>` em um `Vec<T>`.
    ///
    /// Essa conversão não requer movimentação ou alocação de dados e tem complexidade de tempo constante.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Cria um iterador de consumo, ou seja, aquele que move cada valor para fora do heap binário em ordem arbitrária.
    /// O heap binário não pode ser usado depois de chamar isso.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Imprima 1, 2, 3, 4 em ordem arbitrária
    /// for x in heap.into_iter() {
    ///     // x tem o tipo i32, não &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}