//! Uma string codificada em UTF-8, que pode ser aumentada.
//!
//! Este módulo contém o tipo [`String`], o [`ToString`] trait para conversão em strings e vários tipos de erros que podem resultar do trabalho com [`String`] s.
//!
//!
//! # Examples
//!
//! Existem várias maneiras de criar um novo [`String`] a partir de um literal de string:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Você pode criar um novo [`String`] a partir de um existente concatenando com
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Se você tiver um vector de bytes UTF-8 válidos, poderá fazer um [`String`] com ele.Você também pode fazer o inverso.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Sabemos que esses bytes são válidos, então usaremos o `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// Uma string codificada em UTF-8, que pode ser aumentada.
///
/// O tipo `String` é o tipo de string mais comum que possui propriedade sobre o conteúdo da string.Ele tem um relacionamento próximo com sua contraparte emprestada, o primitivo [`str`].
///
/// # Examples
///
/// Você pode criar um `String` a partir do [a literal string][`str`] com o [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Você pode anexar um [`char`] a um `String` com o método [`push`] e anexar um [`&str`] com o método [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Se você tiver um vector de bytes UTF-8, poderá criar um `String` a partir dele com o método [`from_utf8`]:
///
/// ```
/// // alguns bytes, em um vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Sabemos que esses bytes são válidos, então usaremos o `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `String`s são sempre UTF-8 válidos.Isso tem algumas implicações, a primeira delas é que, se você precisar de uma string não UTF-8, considere o [`OsString`].É semelhante, mas sem a restrição UTF-8.A segunda implicação é que você não pode indexar em um `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// A indexação deve ser uma operação de tempo constante, mas a codificação UTF-8 não nos permite fazer isso.Além disso, não está claro que tipo de coisa o índice deve retornar: um byte, um ponto de código ou um cluster de grafema.
/// Os métodos [`bytes`] e [`chars`] retornam iteradores sobre os dois primeiros, respectivamente.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// Implementar `String` [`Deref`] `<Target=str>`, e assim herda todos os métodos de [`str`].Além disso, isso significa que você pode passar um `String` para uma função que recebe um [`&str`] usando um E comercial (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Isso criará um [`&str`] a partir do `String` e o transmitirá. Essa conversão é muito barata e, portanto, geralmente, as funções aceitam [`&str`] s como argumentos, a menos que precisem de um `String` por algum motivo específico.
///
/// Em certos casos, Rust não possui informações suficientes para fazer essa conversão, conhecida como coerção [`Deref`].No exemplo a seguir, uma fatia de string [`&'a str`][`&str`] implementa o trait `TraitExample`, e a função `example_func` pega qualquer coisa que implemente o trait.
/// Nesse caso, Rust precisaria fazer duas conversões implícitas, as quais Rust não tem os meios para fazer.
/// Por esse motivo, o exemplo a seguir não será compilado.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Existem duas opções que funcionariam em seu lugar.A primeira seria mudar a linha `example_func(&example_string);` para `example_func(example_string.as_str());`, usando o método [`as_str()`] para extrair explicitamente a fatia da string que contém a string.
/// A segunda forma muda de `example_func(&example_string);` para `example_func(&*example_string);`.
/// Neste caso, estamos desreferenciando um `String` para um [`str`][`&str`] e, em seguida, referenciando o [`str`][`&str`] de volta para [`&str`].
/// A segunda maneira é mais idiomática, no entanto, ambas trabalham para fazer a conversão explicitamente, em vez de depender da conversão implícita.
///
/// # Representation
///
/// Um `String` é feito de três componentes: um ponteiro para alguns bytes, um comprimento e uma capacidade.O ponteiro aponta para um buffer interno que o `String` usa para armazenar seus dados.O comprimento é o número de bytes armazenados atualmente no buffer e a capacidade é o tamanho do buffer em bytes.
///
/// Como tal, o comprimento será sempre menor ou igual à capacidade.
///
/// Esse buffer é sempre armazenado no heap.
///
/// Você pode ver isso com os métodos [`as_ptr`], [`len`] e [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Atualize quando vec_into_raw_parts estiver estabilizado.
/// // Impedir a eliminação automática dos dados da String
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // a história tem dezenove bytes
/// assert_eq!(19, len);
///
/// // Podemos reconstruir uma String com ptr, len e capacidade.
/// // Tudo isso é inseguro porque somos responsáveis por garantir que os componentes sejam válidos:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Se um `String` tiver capacidade suficiente, adicionar elementos a ele não será realocado.Por exemplo, considere este programa:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Isso resultará no seguinte:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// No início, não temos nenhuma memória alocada, mas à medida que acrescentamos à string, ela aumenta sua capacidade apropriadamente.Se, em vez disso, usarmos o método [`with_capacity`] para alocar a capacidade correta inicialmente:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Acabamos com uma saída diferente:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Aqui, não há necessidade de alocar mais memória dentro do loop.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Um possível valor de erro ao converter um `String` de um UTF-8 byte vector.
///
/// Este tipo é o tipo de erro para o método [`from_utf8`] no [`String`].
/// Ele é projetado de forma a evitar cuidadosamente realocações: o método [`into_bytes`] retornará o byte vector que foi usado na tentativa de conversão.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// O tipo [`Utf8Error`] fornecido pelo [`std::str`] representa um erro que pode ocorrer ao converter uma fatia de [`u8`] s em um [`&str`].
/// Nesse sentido, é um análogo ao `FromUtf8Error` e você pode obter um de um `FromUtf8Error` por meio do método [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// // alguns bytes inválidos, em um vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Um possível valor de erro ao converter um `String` de uma fatia de bytes UTF-16.
///
/// Este tipo é o tipo de erro para o método [`from_utf16`] no [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Uso básico:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Cria um novo `String` vazio.
    ///
    /// Dado que o `String` está vazio, isso não alocará nenhum buffer inicial.Embora isso signifique que essa operação inicial seja muito barata, ela pode causar alocação excessiva posteriormente, quando você adicionar dados.
    ///
    /// Se você tem uma ideia de quantos dados o `String` irá armazenar, considere o método [`with_capacity`] para evitar uma realocação excessiva.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Cria um novo `String` vazio com uma capacidade específica.
    ///
    /// `String`s têm um buffer interno para armazenar seus dados.
    /// A capacidade é o comprimento desse buffer e pode ser consultada com o método [`capacity`].
    /// Este método cria um `String` vazio, mas com um buffer inicial que pode conter bytes `capacity`.
    /// Isso é útil quando você pode anexar muitos dados ao `String`, reduzindo o número de realocações que ele precisa fazer.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Se a capacidade fornecida for `0`, nenhuma alocação ocorrerá e este método é idêntico ao método [`new`].
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // A String não contém caracteres, embora tenha capacidade para mais
    /// assert_eq!(s.len(), 0);
    ///
    /// // Tudo isso é feito sem realocar ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... mas isso pode fazer com que a string seja realocada
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): com cfg(test), o método `[T]::to_vec` inerente, que é necessário para esta definição de método, não está disponível.
    // Como não exigimos esse método para fins de teste, vou apenas criar um esboço NB, ver o módulo slice::hack em slice.rs para obter mais informações
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Converte um vector de bytes em um `String`.
    ///
    /// Uma string ([`String`]) é feita de bytes ([`u8`]), e um vector de bytes ([`Vec<u8>`]) é feito de bytes, portanto, essa função converte entre os dois.
    /// Nem todas as fatias de bytes são `String`s válidas, no entanto: `String` requer que seja UTF-8 válido.
    /// `from_utf8()` verifica se os bytes são UTF-8 válidos e, em seguida, faz a conversão.
    ///
    /// Se você tiver certeza de que a fatia de byte é UTF-8 válida e não quiser incorrer na sobrecarga da verificação de validade, há uma versão não segura dessa função, [`from_utf8_unchecked`], que tem o mesmo comportamento, mas ignora a verificação.
    ///
    ///
    /// Este método terá o cuidado de não copiar o vector, por uma questão de eficiência.
    ///
    /// Se você precisa de um [`&str`] em vez de um `String`, considere o [`str::from_utf8`].
    ///
    /// O inverso desse método é [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Retorna [`Err`] se a fatia não for UTF-8 com uma descrição do motivo pelo qual os bytes fornecidos não são UTF-8.O vector para o qual você mudou também está incluído.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // alguns bytes, em um vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Sabemos que esses bytes são válidos, então usaremos o `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Bytes incorretos:
    ///
    /// ```
    /// // alguns bytes inválidos, em um vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Consulte a documentação do [`FromUtf8Error`] para obter mais detalhes sobre o que você pode fazer com esse erro.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Converte uma fatia de bytes em uma string, incluindo caracteres inválidos.
    ///
    /// As strings são feitas de bytes ([`u8`]) e uma fatia de bytes ([`&[u8]`][byteslice]) é feita de bytes, portanto, essa função converte entre os dois.No entanto, nem todas as fatias de bytes são strings válidas: as strings precisam ser UTF-8 válidas.
    /// Durante essa conversão, o `from_utf8_lossy()` substituirá todas as sequências UTF-8 inválidas por [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], que se parece com isto:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Se você tiver certeza de que a fatia de byte é UTF-8 válida e não quiser incorrer na sobrecarga da conversão, há uma versão não segura dessa função, [`from_utf8_unchecked`], que tem o mesmo comportamento, mas ignora as verificações.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Esta função retorna um [`Cow<'a, str>`].Se nossa fatia de byte for UTF-8 inválida, precisamos inserir os caracteres de substituição, o que mudará o tamanho da string e, portanto, exigirá um `String`.
    /// Mas se já for UTF-8 válido, não precisamos de uma nova alocação.
    /// Este tipo de retorno nos permite lidar com ambos os casos.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // alguns bytes, em um vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Bytes incorretos:
    ///
    /// ```
    /// // alguns bytes inválidos
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Decodifique um vector `v` codificado em UTF-16 em um `String`, retornando [`Err`] se o `v` contiver dados inválidos.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Isso não é feito por meio de collect: : <Result<_, _>> () por motivos de desempenho.
        // FIXME: a função pode ser simplificada novamente quando o #48994 é fechado.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Decodifique um `v` de fatia codificado em UTF-16 em um `String`, substituindo os dados inválidos por [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// Ao contrário do [`from_utf8_lossy`], que retorna um [`Cow<'a, str>`], o `from_utf16_lossy` retorna um `String`, pois a conversão de UTF-16 em UTF-8 requer uma alocação de memória.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Decompõe um `String` em seus componentes brutos.
    ///
    /// Retorna o ponteiro bruto para os dados subjacentes, o comprimento da string (em bytes) e a capacidade alocada dos dados (em bytes).
    /// Esses são os mesmos argumentos na mesma ordem que os argumentos para [`from_raw_parts`].
    ///
    /// Depois de chamar esta função, o chamador é responsável pela memória anteriormente gerenciada pelo `String`.
    /// A única maneira de fazer isso é converter o ponteiro bruto, o comprimento e a capacidade de volta em um `String` com a função [`from_raw_parts`], permitindo que o destruidor execute a limpeza.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Cria um novo `String` a partir de comprimento, capacidade e ponteiro.
    ///
    /// # Safety
    ///
    /// Isso é altamente inseguro, devido ao número de invariantes que não são verificados:
    ///
    /// * A memória no `buf` precisa ter sido alocada anteriormente pelo mesmo alocador que a biblioteca padrão usa, com um alinhamento necessário de exatamente 1.
    /// * `length` precisa ser menor ou igual a `capacity`.
    /// * `capacity` precisa ser o valor correto.
    /// * Os primeiros bytes `length` em `buf` precisam ser UTF-8 válidos.
    ///
    /// Violá-los pode causar problemas como corromper as estruturas de dados internas do alocador.
    ///
    /// A propriedade do `buf` é efetivamente transferida para o `String`, que pode então desalocar, realocar ou alterar o conteúdo da memória apontado pelo ponteiro à vontade.
    /// Certifique-se de que nada mais use o ponteiro após chamar esta função.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Atualize quando vec_into_raw_parts estiver estabilizado.
    ///     // Impedir a eliminação automática dos dados da String
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Converte um vector de bytes em um `String` sem verificar se a string contém UTF-8 válido.
    ///
    /// Veja a versão segura, [`from_utf8`], para mais detalhes.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Esta função não é segura porque não verifica se os bytes transmitidos a ela são UTF-8 válidos.
    /// Se esta restrição for violada, pode causar problemas de insegurança de memória com usuários future do `String`, já que o resto da biblioteca padrão assume que `String`s são UTF-8 válidos.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // alguns bytes, em um vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Converte um `String` em um byte vector.
    ///
    /// Isso consome o `String`, portanto, não precisamos copiar seu conteúdo.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Extrai uma fatia de string contendo todo o `String`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Converte um `String` em uma fatia de string mutável.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Acrescenta uma determinada fatia de string no final deste `String`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Retorna a capacidade desta `String`, em bytes.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Garante que a capacidade desta `String` seja pelo menos `additional` bytes maior que seu comprimento.
    ///
    /// A capacidade pode ser aumentada em mais de `additional` bytes se desejar, para evitar realocações frequentes.
    ///
    ///
    /// Se você não quiser esse comportamento do "at least", consulte o método [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics se a nova capacidade ultrapassar [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Isso pode não aumentar realmente a capacidade:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s agora tem um comprimento de 2 e uma capacidade de 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Como já temos uma capacidade extra de 8, chamando isso de ...
    /// s.reserve(8);
    ///
    /// // ... na verdade não aumenta.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Garante que a capacidade desta `String` seja `additional` bytes maior que seu comprimento.
    ///
    /// Considere o uso do método [`reserve`], a menos que você saiba absolutamente melhor do que o alocador.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics se a nova capacidade ultrapassar `usize`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Isso pode não aumentar realmente a capacidade:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s agora tem um comprimento de 2 e uma capacidade de 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Como já temos uma capacidade extra de 8, chamando isso de ...
    /// s.reserve_exact(8);
    ///
    /// // ... na verdade não aumenta.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Tenta reservar capacidade para pelo menos `additional` mais elementos a serem inseridos no `String` fornecido.
    /// A coleção pode reservar mais espaço para evitar realocações frequentes.
    /// Depois de chamar `reserve`, a capacidade será maior ou igual a `self.len() + additional`.
    /// Não faz nada se a capacidade já for suficiente.
    ///
    /// # Errors
    ///
    /// Se a capacidade estourar ou o alocador relatar uma falha, um erro será retornado.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Pré-reserve a memória, saindo se não pudermos
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Agora sabemos que isso não OOM no meio de nosso trabalho complexo
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Tenta reservar a capacidade mínima para exatamente `additional` mais elementos a serem inseridos no `String` determinado.
    ///
    /// Depois de chamar `reserve_exact`, a capacidade será maior ou igual a `self.len() + additional`.
    /// Não faz nada se a capacidade já for suficiente.
    ///
    /// Observe que o alocador pode fornecer à coleção mais espaço do que ele solicita.
    /// Portanto, a capacidade não pode ser considerada precisamente mínima.
    /// Prefira `reserve` se inserções future são esperadas.
    ///
    /// # Errors
    ///
    /// Se a capacidade estourar ou o alocador relatar uma falha, um erro será retornado.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Pré-reserve a memória, saindo se não pudermos
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Agora sabemos que isso não OOM no meio de nosso trabalho complexo
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Reduz a capacidade deste `String` para corresponder ao seu comprimento.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Reduz a capacidade deste `String` com um limite inferior.
    ///
    /// A capacidade permanecerá pelo menos tão grande quanto o comprimento e o valor fornecido.
    ///
    ///
    /// Se a capacidade atual for menor que o limite inferior, este é um ambiente autônomo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Acrescenta o [`char`] fornecido ao final deste `String`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Retorna uma fatia de byte do conteúdo desta `String`.
    ///
    /// O inverso desse método é [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Encurta este `String` para o comprimento especificado.
    ///
    /// Se `new_len` for maior que o comprimento atual da string, isso não terá efeito.
    ///
    ///
    /// Observe que este método não tem efeito sobre a capacidade alocada da string
    ///
    /// # Panics
    ///
    /// Panics se `new_len` não estiver em um limite [`char`].
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Remove o último caractere do buffer de string e o retorna.
    ///
    /// Retorna [`None`] se este `String` estiver vazio.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Remove um [`char`] deste `String` em uma posição de byte e o retorna.
    ///
    /// Esta é uma operação *O*(*n*), pois requer a cópia de todos os elementos do buffer.
    ///
    /// # Panics
    ///
    /// Panics se `idx` for maior ou igual ao comprimento da `String`, ou se não estiver em um limite [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Remova todas as correspondências do padrão `pat` no `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// As correspondências serão detectadas e removidas iterativamente, portanto, nos casos em que os padrões se sobrepõem, apenas o primeiro padrão será removido:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // SEGURANÇA: o início e o fim serão nos limites de bytes utf8 por
        // os documentos do Searcher
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Retém apenas os caracteres especificados pelo predicado.
    ///
    /// Em outras palavras, remova todos os caracteres `c` de forma que `f(c)` retorne `false`.
    /// Esse método opera no local, visitando cada personagem exatamente uma vez na ordem original e preserva a ordem dos personagens retidos.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// A ordem exata pode ser útil para rastrear o estado externo, como um índice.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Aponte idx para o próximo caractere
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Insere um caractere neste `String` em uma posição de byte.
    ///
    /// Esta é uma operação *O*(*n*), pois requer a cópia de todos os elementos do buffer.
    ///
    /// # Panics
    ///
    /// Panics se `idx` for maior que o comprimento da `String`, ou se não estiver em um limite [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Insere uma fatia de string neste `String` em uma posição de byte.
    ///
    /// Esta é uma operação *O*(*n*), pois requer a cópia de todos os elementos do buffer.
    ///
    /// # Panics
    ///
    /// Panics se `idx` for maior que o comprimento da `String`, ou se não estiver em um limite [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Retorna uma referência mutável ao conteúdo deste `String`.
    ///
    /// # Safety
    ///
    /// Esta função não é segura porque não verifica se os bytes transmitidos a ela são UTF-8 válidos.
    /// Se esta restrição for violada, pode causar problemas de insegurança de memória com usuários future do `String`, já que o resto da biblioteca padrão assume que `String`s são UTF-8 válidos.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Retorna o comprimento deste `String`, em bytes, não [`char`] s ou grafemas.
    /// Em outras palavras, pode não ser o que um humano considera o comprimento da corda.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Retorna `true` se este `String` tiver comprimento zero e `false` caso contrário.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Divide a string em duas no índice de bytes fornecido.
    ///
    /// Retorna um `String` recém-alocado.
    /// `self` contém bytes `[0, at)` e o `String` retornado contém bytes `[at, len)`.
    /// `at` deve estar no limite de um ponto de código UTF-8.
    ///
    /// Observe que a capacidade do `self` não muda.
    ///
    /// # Panics
    ///
    /// Panics se `at` não estiver em um limite de ponto de código `UTF-8` ou se estiver além do último ponto de código da string.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Trunca este `String`, removendo todo o conteúdo.
    ///
    /// Embora isso signifique que o `String` terá comprimento zero, ele não atinge sua capacidade.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Cria um iterador de drenagem que remove o intervalo especificado no `String` e produz o `chars` removido.
    ///
    ///
    /// Note: O intervalo do elemento é removido mesmo se o iterador não for consumido até o final.
    ///
    /// # Panics
    ///
    /// Panics se o ponto inicial ou final não estiver em um limite [`char`] ou se eles estiverem fora dos limites.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Remova o intervalo até o β da corda
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Uma gama completa limpa a corda
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Segurança de memória
        //
        // A versão String do Drain não tem os problemas de segurança de memória da versão vector.
        // Os dados são apenas bytes simples.
        // Como a remoção do intervalo acontece no Drop, se o iterador Drain estiver vazando, a remoção não acontecerá.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Faça dois empréstimos simultâneos.
        // O &mut String não será acessado até que a iteração termine, no Drop.
        let self_ptr = self as *mut _;
        // SEGURANÇA: `slice::range` e `is_char_boundary` fazem as verificações de limites apropriadas.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Remove o intervalo especificado na string e o substitui pela string fornecida.
    /// A string fornecida não precisa ter o mesmo comprimento do intervalo.
    ///
    /// # Panics
    ///
    /// Panics se o ponto inicial ou final não estiver em um limite [`char`] ou se eles estiverem fora dos limites.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Substitua a faixa até o β da string
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Segurança de memória
        //
        // Replace_range não tem os problemas de segurança de memória de um vector Splice.
        // da versão vector.Os dados são apenas bytes simples.

        // AVISO: Inlining esta variável seria incorreto (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // AVISO: Inlining esta variável seria incorreto (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Usar o `range` novamente não seria adequado. (#81138) Presumimos que os limites relatados pelo `range` permanecem os mesmos, mas uma implementação adversária pode mudar entre as chamadas
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Converte este `String` em um [`Box`]`<`[`str`] `>`.
    ///
    /// Isso eliminará qualquer excesso de capacidade.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Retorna uma fatia dos bytes de [`u8`] s que foram tentados para converter para um `String`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // alguns bytes inválidos, em um vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Retorna os bytes que tentaram converter para um `String`.
    ///
    /// Este método é cuidadosamente construído para evitar a alocação.
    /// Ele consumirá o erro, retirando os bytes, de forma que não seja necessário fazer uma cópia dos bytes.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // alguns bytes inválidos, em um vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Busque um `Utf8Error` para obter mais detalhes sobre a falha de conversão.
    ///
    /// O tipo [`Utf8Error`] fornecido pelo [`std::str`] representa um erro que pode ocorrer ao converter uma fatia de [`u8`] s em um [`&str`].
    /// Nesse sentido, é um análogo ao `FromUtf8Error`.
    /// Consulte sua documentação para obter mais detalhes sobre como usá-lo.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // alguns bytes inválidos, em um vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // o primeiro byte é inválido aqui
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Como estamos iterando em `String`s, podemos evitar pelo menos uma alocação obtendo a primeira string do iterador e anexando a ela todas as strings subsequentes.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Como estamos iterando em CoWs, podemos (potentially) evitar pelo menos uma alocação obtendo o primeiro item e anexando a ele todos os itens subsequentes.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Um implemento de conveniência que delega ao impl para `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Cria um `String` vazio.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Implementa o operador `+` para concatenar duas strings.
///
/// Isso consome o `String` no lado esquerdo e reutiliza seu buffer (aumentando-o, se necessário).
/// Isso é feito para evitar a alocação de um novo `String` e a cópia de todo o conteúdo em cada operação, o que levaria a um tempo de execução de *O*(*n*^ 2) ao construir uma string de *n* bytes por concatenação repetida.
///
///
/// A corda do lado direito é apenas emprestada;seu conteúdo é copiado para o `String` retornado.
///
/// # Examples
///
/// Concatenar duas `String`s pega a primeira por valor e pega emprestada a segunda:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` é movido e não pode mais ser usado aqui.
/// ```
///
/// Se quiser continuar usando o primeiro `String`, você pode cloná-lo e anexá-lo ao clone:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` ainda é válido aqui.
/// ```
///
/// A concatenação de fatias `&str` pode ser feita convertendo a primeira em uma `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Implementa o operador `+=` para anexar a um `String`.
///
/// Ele tem o mesmo comportamento do método [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Um alias de tipo para [`Infallible`].
///
/// Este alias existe para compatibilidade com versões anteriores e pode ser substituído eventualmente.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// Um trait para converter um valor em um `String`.
///
/// Este trait é implementado automaticamente para qualquer tipo que implemente o [`Display`] trait.
/// Como tal, o `ToString` não deve ser implementado diretamente:
/// [`Display`] deve ser implementado, e você obtém a implementação do `ToString` gratuitamente.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Converte o valor fornecido em um `String`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// Nesta implementação, o método `to_string` panics se a implementação `Display` retornar um erro.
/// Isso indica uma implementação incorreta do `Display`, pois o `fmt::Write for String` nunca retorna um erro.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Uma diretriz comum é não incorporar funções genéricas.
    // No entanto, remover o `#[inline]` deste método causa regressões não desprezíveis.
    // Veja <https://github.com/rust-lang/rust/pull/74852>, a última tentativa de tentar removê-lo.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Converte um `&mut str` em um `String`.
    ///
    /// O resultado é alocado na pilha.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: test puxa em libstd, o que causa erros aqui
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Converte a fatia `str` em caixa fornecida em um `String`.
    /// É notável que a fatia `str` pertence.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Converte o `String` fornecido em uma fatia `str` em caixa de sua propriedade.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Converte uma fatia de string em uma variante emprestada.
    /// Nenhuma alocação de heap é executada e a sequência não é copiada.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Converte uma string em uma variante de propriedade.
    /// Nenhuma alocação de heap é executada e a sequência não é copiada.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Converte uma referência de String em uma variante emprestada.
    /// Nenhuma alocação de heap é executada e a sequência não é copiada.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Converte o `String` fornecido em um vector `Vec` que contém valores do tipo `u8`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Um iterador de drenagem para `String`.
///
/// Essa estrutura é criada pelo método [`drain`] no [`String`].
/// Veja sua documentação para mais.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Será usado como&'uma string mut no destruidor
    string: *mut String,
    /// Início da parte para remover
    start: usize,
    /// Fim da parte para remover
    end: usize,
    /// Intervalo restante atual para remover
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Use o Vec::drain.
            // "Reaffirm" os limites verificam para evitar que o código panic seja inserido novamente.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Retorna a (sub) string restante deste iterador como uma fatia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: descomente AsRef impls abaixo ao estabilizar.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Remova o comentário ao estabilizar o `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>para Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> para Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}