`core::arch` - Intrínsecos específicos da arquitetura da biblioteca central do Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

O módulo `core::arch` implementa intrínsecos dependentes de arquitetura (por exemplo, SIMD).

# Usage 

`core::arch` está disponível como parte do `libcore` e é reexportado pelo `libstd`.Prefira usá-lo via `core::arch` ou `std::arch` do que via crate.
Os recursos instáveis geralmente estão disponíveis no Rust noturno por meio do `feature(stdsimd)`.

Usar o `core::arch` por meio deste crate requer Rust noturno e pode (e falha) com frequência.Os únicos casos em que você deve considerar usá-lo por meio deste crate são:

* se você mesmo precisar recompilar o `core::arch`, por exemplo, com recursos específicos de destino habilitados que não estão habilitados para o `libcore`/`libstd`.
Note: se você precisar recompilá-lo para um destino não padrão, prefira usar o `xargo` e recompilar o `libcore`/`libstd` conforme apropriado em vez de usar este crate.
  
* usando alguns recursos que podem não estar disponíveis mesmo por trás dos recursos Rust instáveis.Tentamos reduzir isso ao mínimo.
Se você precisar usar alguns desses recursos, abra um problema para que possamos expô-los todas as noites no Rust e você possa usá-los a partir daí.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` é distribuído principalmente sob os termos da licença MIT e da licença Apache (Versão 2.0), com partes cobertas por várias licenças semelhantes a BSD.

Consulte LICENSE-APACHE e LICENSE-MIT para obter detalhes.

# Contribution

A menos que você declare explicitamente o contrário, qualquer contribuição enviada intencionalmente para inclusão no `core_arch` por você, conforme definido na licença Apache-2.0, será licenciada dupla conforme acima, sem quaisquer termos ou condições adicionais.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












