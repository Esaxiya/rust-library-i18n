use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Usado para informar às nossas anotações `#[assert_instr]` que todos os intrínsecos simd estão disponíveis para testar seu codegen, já que alguns estão protegidos por um `-Ctarget-feature=+unimplemented-simd128` extra que não tem nenhum equivalente no `#[target_feature]` agora.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}