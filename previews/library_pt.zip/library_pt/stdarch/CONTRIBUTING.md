# Contribuindo para stdarch

O `stdarch` crate está mais do que disposto a aceitar contribuições!Primeiro, você provavelmente vai querer verificar o repositório e certificar-se de que os testes passam para você:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Onde `<your-target-arch>` é o triplo alvo usado pelo `rustup`, por exemplo, `x86_x64-unknown-linux-gnu` (sem qualquer `nightly-` anterior ou semelhante).
Lembre-se também de que este repositório requer o canal noturno de Rust!
Os testes acima requerem, de fato, que o rust noturno seja o padrão em seu sistema, para definir que use o `rustup default nightly` (e o `rustup default stable` para reverter).

Se alguma das etapas acima não funcionar, [please let us know][new]!

Em seguida, você pode usar o [find an issue][issues] para ajudar, selecionamos alguns com as tags [`help wanted`][help] e [`impl-period`][impl] que podem precisar de alguma ajuda. 
Você pode estar mais interessado no [#40][vendor], implementando todos os intrínsecos do fornecedor no x86.Essa edição tem algumas boas dicas sobre por onde começar!

Se você tiver perguntas gerais, sinta-se à vontade para [join us on gitter][gitter] e pergunte por aí!Sinta-se à vontade para enviar um ping para@BurntSushi ou@alexcrichton com perguntas.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Como escrever exemplos para intrínsecos stdarch

Existem alguns recursos que devem ser habilitados para que o intrínseco fornecido funcione corretamente e o exemplo só deve ser executado pelo `cargo test --doc` quando o recurso for compatível com a CPU.

Como resultado, o `fn main` padrão gerado pelo `rustdoc` não funcionará (na maioria dos casos).
Considere usar o seguinte como um guia para garantir que seu exemplo funcione conforme o esperado.

```rust
/// # // Precisamos de cfg_target_feature para garantir que o exemplo seja apenas
/// # // executado por `cargo test --doc` quando a CPU suporta o recurso
/// # #![feature(cfg_target_feature)]
/// # // Precisamos de target_feature para que o intrínseco funcione
/// # #![feature(target_feature)]
/// #
/// # // rustdoc por padrão usa `extern crate stdarch`, mas precisamos do
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // A verdadeira função principal
/// # fn main() {
/// #     // Só execute isto se `<target feature>` for suportado
/// #     if cfg_feature_enabled! ("<target feature>"){
/// #         // Crie uma função `worker` que só será executada se o recurso de destino
/// #         // é compatível e certifique-se de que o `target_feature` esteja habilitado para o seu trabalhador
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         inseguro fn worker() {
/// // Escreva seu exemplo aqui.Os intrínsecos específicos do recurso funcionarão aqui!Enlouquecer!
///
/// #         }
///
/// #         inseguro { worker(); }
/// #     }
/// # }
```

Se alguma das sintaxes acima não parecer familiar, a seção [Documentation as tests] do [Rust Book] descreve a sintaxe `rustdoc` muito bem.
Como sempre, sinta-se à vontade para [join us on gitter][gitter] e pergunte-nos se você encontrou algum obstáculo e obrigado por ajudar a melhorar a documentação do `stdarch`!

# Instruções de teste alternativas

Geralmente, é recomendável usar o `ci/run.sh` para executar os testes.
No entanto, isso pode não funcionar para você, por exemplo, se você estiver no Windows.

Nesse caso, você pode voltar a executar o `cargo +nightly test` e o `cargo +nightly test --release -p core_arch` para testar a geração do código.
Observe que eles exigem que o conjunto de ferramentas noturno seja instalado e que o `rustc` saiba sobre seu triplo de destino e sua CPU.
Em particular, você precisa definir a variável de ambiente `TARGET` como faria para o `ci/run.sh`.
Além disso, você precisa definir o `RUSTCFLAGS` (é necessário o `C`) para indicar os recursos de destino, por exemplo `RUSTCFLAGS="-C -target-features=+avx2"`.
Você também pode definir o `-C -target-cpu=native` se estiver desenvolvendo o "just" em relação à sua CPU atual.

Esteja avisado de que ao usar essas instruções alternativas, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], por exemplo
os testes de geração de instrução podem falhar porque o desmontador os nomeou de forma diferente, por exemplo
ele pode gerar instruções `vaesenc` em vez de `aesenc`, apesar de se comportarem da mesma forma.
Além disso, essas instruções executam menos testes do que normalmente seriam feitos, portanto, não se surpreenda se, eventualmente, você fizer uma solicitação de pull, alguns erros podem aparecer em testes não cobertos aqui.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






