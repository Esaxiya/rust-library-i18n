#![feature(no_core)]
#![no_core]

// Consulte rustc-std-workspace-core para saber por que este crate é necessário.

// Renomeie crate para evitar conflito com o módulo de alocação em liballoc.
extern crate alloc as foo;

pub use foo::*;