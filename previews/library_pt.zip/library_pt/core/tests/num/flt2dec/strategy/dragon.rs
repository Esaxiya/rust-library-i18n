use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri é muito lenta
fn exact_sanity_test() {
    // Este teste acaba executando o que eu só posso supor ser algum caso esquemático da função de biblioteca do `exp2`, definida em qualquer tempo de execução C que estivermos usando.
    // No VS 2013, essa função aparentemente tinha um bug, pois este teste falha quando vinculado, mas com o VS 2015 o bug parece corrigido enquanto o teste é executado perfeitamente.
    //
    // O bug parece ser uma diferença no valor de retorno do `exp2(-1057)`, onde no VS 2013 ele retorna um double com o padrão de bits 0x2 e no VS 2015 ele retorna 0x20000.
    //
    //
    // Por enquanto, ignore totalmente este teste no MSVC, já que ele é testado em outro lugar e não estamos muito interessados em testar a implementação de cada plataforma exp2.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}