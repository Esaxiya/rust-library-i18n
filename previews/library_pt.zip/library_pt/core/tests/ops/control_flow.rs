use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Esta não é uma área de superfície estável, mas ajuda a manter o `?` barato entre eles, mesmo que o LLVM nem sempre possa tirar vantagem disso agora.
    //
    // (Infelizmente, o resultado e a opção são inconsistentes, então ControlFlow não pode corresponder a ambos.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}