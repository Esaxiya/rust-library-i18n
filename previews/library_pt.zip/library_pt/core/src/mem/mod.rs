//! Funções básicas para lidar com a memória.
//!
//! Este módulo contém funções para consultar o tamanho e alinhamento dos tipos, inicializar e manipular a memória.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Assume a propriedade e "forgets" sobre o valor **sem executar seu destruidor**.
///
/// Todos os recursos que o valor gerencia, como memória heap ou um identificador de arquivo, permanecerão para sempre em um estado inacessível.No entanto, isso não garante que os ponteiros para essa memória permanecerão válidos.
///
/// * Se você quiser vazar memória, consulte [`Box::leak`].
/// * Se você deseja obter um ponteiro bruto para a memória, consulte [`Box::into_raw`].
/// * Se você quiser descartar um valor corretamente, executando seu destruidor, consulte [`mem::drop`].
///
/// # Safety
///
/// `forget` não está marcado como `unsafe`, porque as garantias de segurança do Rust não incluem uma garantia de que os destruidores sempre funcionarão.
/// Por exemplo, um programa pode criar um ciclo de referência usando o [`Rc`][rc] ou chamar o [`process::exit`][exit] para sair sem executar destruidores.
/// Portanto, permitir o `mem::forget` a partir de um código seguro não altera fundamentalmente as garantias de segurança do Rust.
///
/// Dito isso, o vazamento de recursos, como memória ou objetos I/O, geralmente é indesejável.
/// A necessidade surge em alguns casos de uso especializados para FFI ou código inseguro, mas mesmo assim, o [`ManuallyDrop`] é normalmente o preferido.
///
/// Como é permitido esquecer um valor, qualquer código `unsafe` que você escrever deve permitir essa possibilidade.Você não pode retornar um valor e esperar que o chamador necessariamente execute o destruidor do valor.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// O uso seguro canônico do `mem::forget` é contornar o destruidor de um valor implementado pelo `Drop` trait.Por exemplo, isso vai vazar um `File`, ou seja,
/// recupere o espaço ocupado pela variável, mas nunca feche o recurso do sistema subjacente:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Isso é útil quando a propriedade do recurso subjacente foi anteriormente transferida para o código fora de Rust, por exemplo, transmitindo o descritor de arquivo bruto para o código C.
///
/// # Relacionamento com `ManuallyDrop`
///
/// Embora o `mem::forget` também possa ser usado para transferir a propriedade de *memória*, isso está sujeito a erros.
/// [`ManuallyDrop`] deve ser usado em seu lugar.Considere, por exemplo, este código:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Construir um `String` usando o conteúdo do `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // vazar `v` porque sua memória agora é gerenciada pelo `s`
/// mem::forget(v);  // ERROR, v é inválido e não deve ser passado para uma função
/// assert_eq!(s, "Az");
/// // `s` é descartado implicitamente e sua memória desalocada.
/// ```
///
/// Existem dois problemas com o exemplo acima:
///
/// * Se mais código fosse adicionado entre a construção do `String` e a invocação do `mem::forget()`, um panic dentro dele causaria um double free porque a mesma memória é controlada pelo `v` e pelo `s`.
/// * Depois de chamar o `v.as_mut_ptr()` e transmitir a propriedade dos dados para o `s`, o valor do `v` é inválido.
/// Mesmo quando um valor acaba de ser movido para o `mem::forget` (o que não o inspeciona), alguns tipos têm requisitos rígidos em seus valores que os tornam inválidos quando pendentes ou não são mais possuídos.
/// Usar valores inválidos de qualquer forma, incluindo transmiti-los ou retorná-los de funções, constitui um comportamento indefinido e pode quebrar as suposições feitas pelo compilador.
///
/// Mudar para o `ManuallyDrop` evita os dois problemas:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Antes de desmontar o `v` em suas partes brutas, certifique-se de que ele não caia!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Agora desmonte o `v`.Essas operações não podem ser panic, portanto, não pode haver vazamento.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Finalmente, construa um `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` é descartado implicitamente e sua memória desalocada.
/// ```
///
/// `ManuallyDrop` previne de forma robusta o double-free porque desabilitamos o destruidor de `v` antes de fazer qualquer coisa.
/// `mem::forget()` não permite isso porque consome seu argumento, forçando-nos a chamá-lo apenas depois de extrair tudo o que precisamos do `v`.
/// Mesmo se um panic fosse introduzido entre a construção do `ManuallyDrop` e a construção da string (o que não pode acontecer no código conforme mostrado), isso resultaria em um vazamento e não em uma liberação dupla.
/// Em outras palavras, o `ManuallyDrop` erra pelo lado do vazamento em vez de errar pelo lado da queda (dupla).
///
/// Além disso, o `ManuallyDrop` evita que precisemos usar o "touch" `v` após transferir a propriedade para o `s`-a etapa final de interagir com o `v` para descartá-lo sem executar seu destruidor é totalmente evitada.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Como o [`forget`], mas também aceita valores não dimensionados.
///
/// Esta função é apenas um calço que deve ser removido quando o recurso `unsized_locals` for estabilizado.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Retorna o tamanho de um tipo em bytes.
///
/// Mais especificamente, este é o deslocamento em bytes entre os elementos sucessivos em uma matriz com esse tipo de item, incluindo preenchimento de alinhamento.
///
/// Portanto, para qualquer tipo `T` e comprimento `n`, o tamanho `[T; n]` é `n * size_of::<T>()`.
///
/// Em geral, o tamanho de um tipo não é estável nas compilações, mas tipos específicos, como os primitivos, são.
///
/// A tabela a seguir fornece o tamanho das primitivas.
///
/// Tipo |tamanho de: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Além disso, o `usize` e o `isize` têm o mesmo tamanho.
///
/// Os tipos `*const T`, `&T`, `Box<T>`, `Option<&T>` e `Option<Box<T>>` têm todos o mesmo tamanho.
/// Se o `T` for Sized, todos esses tipos terão o mesmo tamanho que o `usize`.
///
/// A mutabilidade de um ponteiro não altera seu tamanho.Como tal, `&T` e `&mut T` têm o mesmo tamanho.
/// Da mesma forma para `*const T` e `* mut T`.
///
/// # Tamanho dos itens `#[repr(C)]`
///
/// A representação do `C` para itens possui um layout definido.
/// Com este layout, o tamanho dos itens também é estável, desde que todos os campos tenham um tamanho estável.
///
/// ## Tamanho das Estruturas
///
/// Para `structs`, o tamanho é determinado pelo seguinte algoritmo.
///
/// Para cada campo na estrutura ordenado por ordem de declaração:
///
/// 1. Adicione o tamanho do campo.
/// 2. Arredonde o tamanho atual para o múltiplo mais próximo do [alignment] do próximo campo.
///
/// Finalmente, arredonde o tamanho da estrutura para o múltiplo mais próximo de seu [alignment].
/// O alinhamento da estrutura é geralmente o maior alinhamento de todos os seus campos;isso pode ser alterado com o uso do `repr(align(N))`.
///
/// Ao contrário do `C`, as estruturas de tamanho zero não são arredondadas para um byte de tamanho.
///
/// ## Tamanho de Enums
///
/// Os enums que não carregam nenhum dado diferente do discriminante têm o mesmo tamanho que os enums C na plataforma para a qual foram compilados.
///
/// ## Tamanho dos sindicatos
///
/// O tamanho de uma união é o tamanho de seu maior campo.
///
/// Ao contrário do `C`, as uniões de tamanho zero não são arredondadas para um byte de tamanho.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Alguns primitivos
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Algumas matrizes
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Igualdade de tamanho do ponteiro
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Usando o `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // O tamanho do primeiro campo é 1, então adicione 1 ao tamanho.O tamanho é 1.
/// // O alinhamento do segundo campo é 2, portanto, adicione 1 ao tamanho do preenchimento.O tamanho é 2.
/// // O tamanho do segundo campo é 2, portanto, adicione 2 ao tamanho.O tamanho é 4.
/// // O alinhamento do terceiro campo é 1, portanto, adicione 0 ao tamanho do preenchimento.O tamanho é 4.
/// // O tamanho do terceiro campo é 1, portanto, adicione 1 ao tamanho.O tamanho é 5.
/// // Finalmente, o alinhamento da estrutura é 2 (porque o maior alinhamento entre seus campos é 2), então adicione 1 ao tamanho do preenchimento.
/// // O tamanho é 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // As estruturas de tupla seguem as mesmas regras.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Observe que reorganizar os campos pode diminuir o tamanho.
/// // Podemos remover os dois bytes de preenchimento colocando `third` antes de `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // O tamanho da união é o tamanho do maior campo.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Retorna o tamanho do valor apontado em bytes.
///
/// Geralmente é igual ao `size_of::<T>()`.
/// No entanto, quando o `T`*não tem* nenhum tamanho conhecido estaticamente, por exemplo, um slice [`[T]`][slice] ou um [trait object], então o `size_of_val` pode ser usado para obter o tamanho conhecido dinamicamente.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SEGURANÇA: `val` é uma referência, portanto, é um ponteiro bruto válido
    unsafe { intrinsics::size_of_val(val) }
}

/// Retorna o tamanho do valor apontado em bytes.
///
/// Geralmente é igual ao `size_of::<T>()`.No entanto, quando o `T`*não tem* nenhum tamanho conhecido estaticamente, por exemplo, um slice [`[T]`][slice] ou um [trait object], então o `size_of_val_raw` pode ser usado para obter o tamanho conhecido dinamicamente.
///
/// # Safety
///
/// Essa função só pode ser chamada com segurança se as seguintes condições forem mantidas:
///
/// - Se `T` for `Sized`, é sempre seguro chamar esta função.
/// - Se a cauda não dimensionada do `T` for:
///     - um [slice], então o comprimento da cauda da fatia deve ser um inteiro inicializado e o tamanho do *valor inteiro*(comprimento da cauda dinâmica + prefixo de tamanho estático) deve caber em `isize`.
///     - um [trait object], então a parte vtable do ponteiro deve apontar para uma vtable válida adquirida por uma coerção de desdimensionamento, e o tamanho do *valor inteiro*(comprimento da cauda dinâmica + prefixo estaticamente dimensionado) deve caber em `isize`.
///
///     - um (unstable) [extern type], então esta função é sempre segura para chamar, mas pode panic ou de outra forma retornar o valor errado, pois o layout do tipo externo não é conhecido.
///     Este é o mesmo comportamento do [`size_of_val`] em uma referência a um tipo com uma cauda de tipo externa.
///     - caso contrário, não é permitido, de maneira conservadora, chamar essa função.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SEGURANÇA: o chamador deve fornecer um ponteiro bruto válido
    unsafe { intrinsics::size_of_val(val) }
}

/// Retorna o alinhamento mínimo exigido [ABI] de um tipo.
///
/// Cada referência a um valor do tipo `T` deve ser um múltiplo desse número.
///
/// Este é o alinhamento usado para campos de estrutura.Pode ser menor do que o alinhamento preferido.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Retorna o alinhamento mínimo exigido [ABI] do tipo de valor para o qual `val` aponta.
///
/// Cada referência a um valor do tipo `T` deve ser um múltiplo desse número.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SEGURANÇA: val é uma referência, então é um ponteiro bruto válido
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Retorna o alinhamento mínimo exigido [ABI] de um tipo.
///
/// Cada referência a um valor do tipo `T` deve ser um múltiplo desse número.
///
/// Este é o alinhamento usado para campos de estrutura.Pode ser menor do que o alinhamento preferido.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Retorna o alinhamento mínimo exigido [ABI] do tipo de valor para o qual `val` aponta.
///
/// Cada referência a um valor do tipo `T` deve ser um múltiplo desse número.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SEGURANÇA: val é uma referência, então é um ponteiro bruto válido
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Retorna o alinhamento mínimo exigido [ABI] do tipo de valor para o qual `val` aponta.
///
/// Cada referência a um valor do tipo `T` deve ser um múltiplo desse número.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Essa função só pode ser chamada com segurança se as seguintes condições forem mantidas:
///
/// - Se `T` for `Sized`, é sempre seguro chamar esta função.
/// - Se a cauda não dimensionada do `T` for:
///     - um [slice], então o comprimento da cauda da fatia deve ser um inteiro inicializado e o tamanho do *valor inteiro*(comprimento da cauda dinâmica + prefixo de tamanho estático) deve caber em `isize`.
///     - um [trait object], então a parte vtable do ponteiro deve apontar para uma vtable válida adquirida por uma coerção de desdimensionamento, e o tamanho do *valor inteiro*(comprimento da cauda dinâmica + prefixo estaticamente dimensionado) deve caber em `isize`.
///
///     - um (unstable) [extern type], então esta função é sempre segura para chamar, mas pode panic ou de outra forma retornar o valor errado, pois o layout do tipo externo não é conhecido.
///     Este é o mesmo comportamento do [`align_of_val`] em uma referência a um tipo com uma cauda de tipo externa.
///     - caso contrário, não é permitido, de maneira conservadora, chamar essa função.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SEGURANÇA: o chamador deve fornecer um ponteiro bruto válido
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Retorna `true` se a eliminação de valores do tipo `T` for importante.
///
/// Esta é puramente uma dica de otimização e pode ser implementada de forma conservadora:
/// ele pode retornar `true` para tipos que realmente não precisam ser descartados.
/// Como tal, sempre retornar `true` seria uma implementação válida desta função.No entanto, se essa função realmente retornar `false`, você pode ter certeza de que descartar o `T` não terá nenhum efeito colateral.
///
/// Implementações de baixo nível de coisas como coleções, que precisam descartar manualmente seus dados, devem usar esta função para evitar a tentativa desnecessária de descartar todo o seu conteúdo quando são destruídos.
///
/// Isso pode não fazer diferença nas compilações de lançamento (onde um loop sem efeitos colaterais é facilmente detectado e eliminado), mas geralmente é uma grande vitória para compilações de depuração.
///
/// Observe que o [`drop_in_place`] já realiza essa verificação, portanto, se sua carga de trabalho puder ser reduzida a um pequeno número de chamadas [`drop_in_place`], usar isso é desnecessário.
/// Em particular, observe que você pode executar o [`drop_in_place`] em uma fatia, e isso fará uma única verificação need_drop para todos os valores.
///
/// Tipos como Vec, portanto, apenas `drop_in_place(&mut self[..])` sem usar `needs_drop` explicitamente.
/// Tipos como [`HashMap`], por outro lado, precisam descartar valores um de cada vez e devem usar essa API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Aqui está um exemplo de como uma coleção pode usar o `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // solte os dados
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Retorna o valor do tipo `T` representado pelo padrão de bytes totalmente zero.
///
/// Isso significa que, por exemplo, o byte de preenchimento no `(u8, u16)` não é necessariamente zerado.
///
/// Não há garantia de que um padrão de bytes totalmente zero represente um valor válido de algum tipo `T`.
/// Por exemplo, o padrão de bytes totalmente zero não é um valor válido para tipos de referência (`&T`, `&mut T`) e ponteiros de funções.
/// Usar `zeroed` nesses tipos causa [undefined behavior][ub] imediato porque [the Rust compiler assumes][inv] sempre há um valor válido em uma variável que ele considera inicializada.
///
///
/// Isso tem o mesmo efeito que o [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Às vezes é útil para FFI, mas geralmente deve ser evitado.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Uso correto desta função: inicializando um inteiro com zero.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Uso incorreto* desta função: inicializando uma referência com zero.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Comportamento indefinido!
/// let _y: fn() = unsafe { mem::zeroed() }; // E de novo!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // SEGURANÇA: o chamador deve garantir que um valor zero é válido para `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Ignora as verificações normais de inicialização de memória do Rust fingindo produzir um valor do tipo `T`, sem fazer nada.
///
/// **Esta função está obsoleta.** Use o [`MaybeUninit<T>`] em seu lugar.
///
/// O motivo da suspensão é que a função basicamente não pode ser usada corretamente: ela tem o mesmo efeito que o [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Como o [`assume_init` documentation][assume_init] explica, os valores do [the Rust compiler assumes][inv] são inicializados corretamente.
/// Como consequência, chamando, por exemplo
/// `mem::uninitialized::<bool>()` causa comportamento indefinido imediato para retornar um `bool` que não é definitivamente `true` ou `false`.
/// Pior, a memória realmente não inicializada, como o que é retornado aqui, é especial porque o compilador sabe que não tem um valor fixo.
/// Isso torna um comportamento indefinido ter dados não inicializados em uma variável, mesmo se essa variável tiver um tipo inteiro.
/// (Observe que as regras sobre números inteiros não inicializados ainda não foram finalizadas, mas até que sejam, é aconselhável evitá-las.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // SEGURANÇA: o chamador deve garantir que um valor unitializado é válido para `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Troca os valores em dois locais mutáveis, sem desinicializar nenhum deles.
///
/// * Se você deseja trocar com um valor padrão ou fictício, consulte [`take`].
/// * Se você deseja trocar com um valor passado, retornando o valor antigo, consulte [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // SEGURANÇA: os ponteiros brutos foram criados a partir de referências mutáveis seguras que satisfazem todos os
    // restrições no `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Substitui `dest` pelo valor padrão de `T`, retornando o valor `dest` anterior.
///
/// * Se você deseja substituir os valores de duas variáveis, consulte [`swap`].
/// * Se você deseja substituir por um valor passado em vez do valor padrão, consulte [`replace`].
///
/// # Examples
///
/// Um exemplo simples:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` permite assumir a propriedade de um campo de estrutura substituindo-o por um valor "empty".
/// Sem o `take`, você pode encontrar problemas como estes:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Observe que o `T` não necessariamente implementa o [`Clone`], portanto, ele não pode nem mesmo clonar e redefinir o `self.buf`.
/// Mas `take` pode ser usado para desassociar o valor original de `self.buf` de `self`, permitindo que ele seja retornado:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Move `src` para o `dest` referenciado, retornando o valor `dest` anterior.
///
/// Nenhum valor é descartado.
///
/// * Se você deseja substituir os valores de duas variáveis, consulte [`swap`].
/// * Se você deseja substituir por um valor padrão, consulte [`take`].
///
/// # Examples
///
/// Um exemplo simples:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` permite o consumo de um campo de estrutura substituindo-o por outro valor.
/// Sem o `replace`, você pode encontrar problemas como estes:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Observe que o `T` não necessariamente implementa o [`Clone`], portanto, não podemos nem mesmo clonar o `self.buf[i]` para evitar a mudança.
/// Mas `replace` pode ser usado para desassociar o valor original nesse índice de `self`, permitindo que ele seja retornado:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // SEGURANÇA: lemos do `dest`, mas gravamos diretamente o `src` nele depois,
    // de modo que o valor antigo não seja duplicado.
    // Nada é descartado e nada aqui pode panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Dispõe de um valor.
///
/// Isso faz isso chamando a implementação do argumento de [`Drop`][drop].
///
/// Isso efetivamente não faz nada para tipos que implementam `Copy`, por exemplo
/// integers.
/// Esses valores são copiados e o _then_ movido para a função, portanto, o valor persiste após essa chamada de função.
///
///
/// Esta função não é mágica;é literalmente definido como
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Como o `_x` é movido para a função, ele é automaticamente descartado antes que a função retorne.
///
/// [drop]: Drop
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // elimine explicitamente o vector
/// ```
///
/// Como o [`RefCell`] impõe as regras de empréstimo em tempo de execução, o `drop` pode lançar um empréstimo [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // renunciar ao empréstimo mutável neste slot
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Inteiros e outros tipos que implementam o [`Copy`] não são afetados pelo `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // uma cópia do `x` é movida e descartada
/// drop(y); // uma cópia do `y` é movida e descartada
///
/// println!("x: {}, y: {}", x, y.0); // ainda disponível
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Interpreta `src` como tendo o tipo `&U` e, em seguida, lê `src` sem mover o valor contido.
///
/// Esta função assumirá de forma insegura que o ponteiro `src` é válido para bytes [`size_of::<U>`][size_of] transmutando `&T` em `&U` e, em seguida, lendo o `&U` (exceto que isso é feito de uma forma correta mesmo quando `&U` tem requisitos de alinhamento mais rígidos do que `&T`).
/// Ele também criará de forma insegura uma cópia do valor contido em vez de sair do `src`.
///
/// Não é um erro de tempo de compilação se o `T` e o `U` têm tamanhos diferentes, mas é altamente recomendável invocar essa função apenas quando o `T` e o `U` tiverem o mesmo tamanho.Esta função aciona [undefined behavior][ub] se `U` for maior que `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Copie os dados do 'foo_array' e trate-os como um 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Modifique os dados copiados
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // O conteúdo do 'foo_array' não deveria ter mudado
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Se U tiver um requisito de alinhamento maior, src pode não estar alinhado adequadamente.
    if align_of::<U>() > align_of::<T>() {
        // SEGURANÇA: `src` é uma referência com garantia de validade para leituras.
        // O chamador deve garantir que a transmutação real é segura.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SEGURANÇA: `src` é uma referência com garantia de validade para leituras.
        // Acabamos de verificar se o `src as *const U` estava alinhado corretamente.
        // O chamador deve garantir que a transmutação real é segura.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Tipo opaco que representa o discriminante de um enum.
///
/// Consulte a função [`discriminant`] neste módulo para obter mais informações.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Essas implementações trait não podem ser derivadas porque não queremos nenhum limite em T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Retorna um valor que identifica exclusivamente a variante enum no `v`.
///
/// Se `T` não for um enum, chamar essa função não resultará em um comportamento indefinido, mas o valor de retorno não é especificado.
///
///
/// # Stability
///
/// O discriminante de uma variante de enum pode mudar se a definição de enum mudar.
/// Um discriminante de alguma variante não mudará entre compilações com o mesmo compilador.
///
/// # Examples
///
/// Isso pode ser usado para comparar enums que transportam dados, enquanto desconsidera os dados reais:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Retorna o número de variantes no tipo de enum `T`.
///
/// Se `T` não for um enum, chamar essa função não resultará em um comportamento indefinido, mas o valor de retorno não é especificado.
/// Da mesma forma, se `T` for um enum com mais variantes do que `usize::MAX`, o valor de retorno não será especificado.
/// Variantes desabitadas serão contadas.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}