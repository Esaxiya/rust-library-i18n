use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Um tipo de invólucro para construir instâncias não inicializadas do `T`.
///
/// # Invariante de inicialização
///
/// O compilador, em geral, assume que uma variável foi inicializada corretamente de acordo com os requisitos do tipo da variável.Por exemplo, uma variável do tipo de referência deve ser alinhada e não NULL.
/// Esta é uma invariante que deve *sempre* ser mantida, mesmo em código não seguro.
/// Como consequência, a inicialização de zero de uma variável do tipo de referência causa [undefined behavior][ub] instantâneo, não importa se essa referência é usada para acessar a memória:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // comportamento indefinido!⚠️
/// // O código equivalente com `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // comportamento indefinido!⚠️
/// ```
///
/// Isso é explorado pelo compilador para várias otimizações, como omitir verificações de tempo de execução e otimizar o layout do `enum`.
///
/// Da mesma forma, a memória totalmente não inicializada pode ter qualquer conteúdo, enquanto um `bool` deve ser sempre `true` ou `false`.Portanto, criar um `bool` não inicializado é um comportamento indefinido:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // comportamento indefinido!⚠️
/// // O código equivalente com `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // comportamento indefinido!⚠️
/// ```
///
/// Além disso, a memória não inicializada é especial porque não tem um valor fixo ("fixed" significa "it won't change without being written to").Ler o mesmo byte não inicializado várias vezes pode fornecer resultados diferentes.
/// Isso torna um comportamento indefinido ter dados não inicializados em uma variável, mesmo se essa variável tiver um tipo inteiro, que, de outra forma, pode conter qualquer padrão de bit *fixo*:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // comportamento indefinido!⚠️
/// // O código equivalente com `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // comportamento indefinido!⚠️
/// ```
/// (Observe que as regras sobre números inteiros não inicializados ainda não foram finalizadas, mas até que sejam, é aconselhável evitá-las.)
///
/// Além disso, lembre-se de que a maioria dos tipos tem invariantes adicionais além de meramente serem considerados inicializados no nível do tipo.
/// Por exemplo, um [`Vec<T>`] inicializado com `1` é considerado inicializado (na implementação atual; isso não constitui uma garantia estável) porque o único requisito que o compilador conhece é que o ponteiro de dados deve ser não nulo.
/// A criação de tal `Vec<T>` não causa um comportamento indefinido *imediato*, mas causará um comportamento indefinido com a maioria das operações seguras (incluindo descartá-lo).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` serve para permitir que um código não seguro lide com dados não inicializados.
/// É um sinal para o compilador indicando que os dados aqui podem *não* ser inicializados:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Crie uma referência explicitamente não inicializada.
/// // O compilador sabe que os dados dentro de um `MaybeUninit<T>` podem ser inválidos e, portanto, não é UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Defina-o com um valor válido.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Extraia os dados inicializados-isso só é permitido *após* inicializar corretamente o `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// O compilador então sabe que não deve fazer suposições ou otimizações incorretas neste código.
///
/// Você pode pensar no `MaybeUninit<T>` como sendo um pouco como o `Option<T>`, mas sem nenhum controle de tempo de execução e sem nenhuma das verificações de segurança.
///
/// ## out-pointers
///
/// Você pode usar o `MaybeUninit<T>` para implementar o "out-pointers": em vez de retornar dados de uma função, passe um ponteiro para alguma memória (uninitialized) para colocar o resultado.
/// Isso pode ser útil quando é importante para o chamador controlar como a memória em que o resultado está armazenado é alocada e você deseja evitar movimentos desnecessários.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` não descarta o conteúdo antigo, o que é importante.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Agora sabemos que o `v` foi inicializado!Isso também garante que o vector seja devidamente descartado.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Inicializando um array elemento por elemento
///
/// `MaybeUninit<T>` pode ser usado para inicializar um grande array elemento por elemento:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Crie uma matriz não inicializada de `MaybeUninit`.
///     // O `assume_init` é seguro porque o tipo que afirmamos ter inicializado aqui é um monte de `MaybeUninit`s, que não requerem inicialização.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Deixar cair um `MaybeUninit` não faz nada.
///     // Portanto, usar a atribuição de ponteiro bruto em vez de `ptr::write` não faz com que o antigo valor não inicializado seja descartado.
/////
///     // Além disso, se houver um panic durante este loop, temos um vazamento de memória, mas não há nenhum problema de segurança de memória.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Tudo é inicializado.
///     // Transmute a matriz para o tipo inicializado.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Você também pode trabalhar com matrizes parcialmente inicializadas, que podem ser encontradas em estruturas de dados de baixo nível.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Crie uma matriz não inicializada de `MaybeUninit`.
/// // O `assume_init` é seguro porque o tipo que afirmamos ter inicializado aqui é um monte de `MaybeUninit`s, que não requerem inicialização.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Conte o número de elementos que atribuímos.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Para cada item do array, descarte se o alocamos.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Inicializando uma estrutura campo a campo
///
/// Você pode usar o `MaybeUninit<T>` e a macro [`std::ptr::addr_of_mut`] para inicializar estruturas campo a campo:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Inicializando o campo `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Inicializando o campo `list` Se houver um panic aqui, então o `String` no campo `name` vaza.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Todos os campos são inicializados, então chamamos `assume_init` para obter um Foo inicializado.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` tem a garantia de ter o mesmo tamanho, alinhamento e ABI que o `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// No entanto, lembre-se de que um tipo *contendo* um `MaybeUninit<T>` não é necessariamente o mesmo layout;Rust em geral não garante que os campos de um `Foo<T>` tenham a mesma ordem que um `Foo<U>`, mesmo que `T` e `U` tenham o mesmo tamanho e alinhamento.
///
/// Além disso, como qualquer valor de bit é válido para um `MaybeUninit<T>`, o compilador não pode aplicar otimizações non-zero/niche-filling, resultando potencialmente em um tamanho maior:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Se o `T` for seguro para FFI, o `MaybeUninit<T>` também será.
///
/// Embora `MaybeUninit` seja `#[repr(transparent)]` (indicando que garante o mesmo tamanho, alinhamento e ABI que `T`), isso *não* altera nenhuma das advertências anteriores.
/// `Option<T>` e `Option<MaybeUninit<T>>` ainda podem ter tamanhos diferentes e os tipos que contêm um campo do tipo `T` podem ser dispostos (e dimensionados) de maneira diferente do que se esse campo fosse `MaybeUninit<T>`.
/// `MaybeUninit` é um tipo de união e o `#[repr(transparent)]` em uniões é instável (consulte [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Com o tempo, as garantias exatas do `#[repr(transparent)]` em uniões podem evoluir e o `MaybeUninit` pode ou não permanecer como `#[repr(transparent)]`.
/// Dito isso, o `MaybeUninit<T>`*sempre* garantirá que tenha o mesmo tamanho, alinhamento e ABI que o `T`;é que a maneira como o `MaybeUninit` implementa essa garantia pode evoluir.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang item para que possamos envolver outros tipos nele.Isso é útil para geradores.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Não chamando o `T::clone()`, não podemos saber se fomos inicializados o suficiente para isso.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Cria um novo `MaybeUninit<T>` inicializado com o valor fornecido.
    /// É seguro chamar o [`assume_init`] no valor de retorno desta função.
    ///
    /// Observe que descartar um `MaybeUninit<T>` nunca chamará o código de eliminação de `T`.
    /// É sua responsabilidade garantir que o `T` seja descartado se for inicializado.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Cria um novo `MaybeUninit<T>` em um estado não inicializado.
    ///
    /// Observe que descartar um `MaybeUninit<T>` nunca chamará o código de eliminação de `T`.
    /// É sua responsabilidade garantir que o `T` seja descartado se for inicializado.
    ///
    /// Veja o [type-level documentation][MaybeUninit] para alguns exemplos.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Crie uma nova matriz de itens `MaybeUninit<T>`, em um estado não inicializado.
    ///
    /// Note: em uma versão future Rust, este método pode se tornar desnecessário quando a sintaxe literal da matriz permite [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// O exemplo abaixo pode usar o `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Retorna uma fatia (possivelmente menor) de dados que foi realmente lida
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // SEGURANÇA: Um `[MaybeUninit<_>; LEN]` não inicializado é válido.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Cria um novo `MaybeUninit<T>` em um estado não inicializado, com a memória sendo preenchida com bytes `0`.Depende do `T` se isso já permite a inicialização adequada.
    ///
    /// Por exemplo, `MaybeUninit<usize>::zeroed()` é inicializado, mas `MaybeUninit<&'static i32>::zeroed()` não é porque as referências não devem ser nulas.
    ///
    /// Observe que descartar um `MaybeUninit<T>` nunca chamará o código de eliminação de `T`.
    /// É sua responsabilidade garantir que o `T` seja descartado se for inicializado.
    ///
    /// # Example
    ///
    /// Uso correto desta função: inicializando uma estrutura com zero, onde todos os campos da estrutura podem conter o padrão de bits 0 como um valor válido.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// Uso *incorreto* desta função: chamar `x.zeroed().assume_init()` quando `0` não for um padrão de bits válido para o tipo:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Dentro de um par, criamos um `NotZero` que não possui um discriminante válido.
    /// // Este é um comportamento indefinido.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // SEGURANÇA: `u.as_mut_ptr()` aponta para a memória alocada.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Define o valor do `MaybeUninit<T>`.
    /// Isso sobrescreve qualquer valor anterior sem eliminá-lo, portanto, tome cuidado para não usar isso duas vezes, a menos que queira pular a execução do destruidor.
    ///
    /// Para sua conveniência, isso também retorna uma referência mutável ao conteúdo (agora inicializado com segurança) do `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // SEGURANÇA: Acabamos de inicializar este valor.
        unsafe { self.assume_init_mut() }
    }

    /// Obtém um ponteiro para o valor contido.
    /// Ler a partir deste ponteiro ou transformá-lo em uma referência é um comportamento indefinido, a menos que o `MaybeUninit<T>` seja inicializado.
    /// A gravação na memória para a qual este ponteiro (non-transitively) aponta é um comportamento indefinido (exceto dentro de um `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Uso correto deste método:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Crie uma referência no `MaybeUninit<T>`.Está tudo bem porque nós o inicializamos.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// Uso *incorreto* deste método:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Criamos uma referência a um vector não inicializado!Este é um comportamento indefinido.⚠️
    /// ```
    ///
    /// (Observe que as regras sobre referências a dados não inicializados ainda não foram finalizadas, mas até que sejam, é aconselhável evitá-las.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` e `ManuallyDrop` são ambos `repr(transparent)` para que possamos lançar o ponteiro.
        self as *const _ as *const T
    }

    /// Obtém um ponteiro mutável para o valor contido.
    /// Ler a partir deste ponteiro ou transformá-lo em uma referência é um comportamento indefinido, a menos que o `MaybeUninit<T>` seja inicializado.
    ///
    /// # Examples
    ///
    /// Uso correto deste método:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Crie uma referência no `MaybeUninit<Vec<u32>>`.
    /// // Está tudo bem porque nós o inicializamos.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// Uso *incorreto* deste método:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Criamos uma referência a um vector não inicializado!Este é um comportamento indefinido.⚠️
    /// ```
    ///
    /// (Observe que as regras sobre referências a dados não inicializados ainda não foram finalizadas, mas até que sejam, é aconselhável evitá-las.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` e `ManuallyDrop` são ambos `repr(transparent)` para que possamos lançar o ponteiro.
        self as *mut _ as *mut T
    }

    /// Extrai o valor do contêiner `MaybeUninit<T>`.Essa é uma ótima maneira de garantir que os dados sejam descartados, porque o `T` resultante está sujeito ao tratamento normal de queda.
    ///
    /// # Safety
    ///
    /// Cabe ao chamador garantir que o `MaybeUninit<T>` realmente esteja em um estado inicializado.Chamar isso quando o conteúdo ainda não foi totalmente inicializado causa um comportamento indefinido imediato.
    /// O [type-level documentation][inv] contém mais informações sobre essa invariante de inicialização.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Além disso, lembre-se de que a maioria dos tipos tem invariantes adicionais além de meramente serem considerados inicializados no nível do tipo.
    /// Por exemplo, um [`Vec<T>`] inicializado com `1` é considerado inicializado (na implementação atual; isso não constitui uma garantia estável) porque o único requisito que o compilador conhece é que o ponteiro de dados deve ser não nulo.
    ///
    /// A criação de tal `Vec<T>` não causa um comportamento indefinido *imediato*, mas causará um comportamento indefinido com a maioria das operações seguras (incluindo descartá-lo).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Uso correto deste método:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// Uso *incorreto* deste método:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` ainda não havia sido inicializado, então esta última linha causou um comportamento indefinido.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // SEGURANÇA: o chamador deve garantir que o `self` seja inicializado.
        // Isso também significa que o `self` deve ser uma variante do `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Lê o valor do contêiner `MaybeUninit<T>`.O `T` resultante está sujeito ao tratamento de queda usual.
    ///
    /// Sempre que possível, é preferível usar o [`assume_init`], o que evita a duplicação do conteúdo do `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Cabe ao chamador garantir que o `MaybeUninit<T>` realmente esteja em um estado inicializado.Chamar isso quando o conteúdo ainda não foi totalmente inicializado causa um comportamento indefinido.
    /// O [type-level documentation][inv] contém mais informações sobre essa invariante de inicialização.
    ///
    /// Além disso, isso deixa uma cópia dos mesmos dados para trás no `MaybeUninit<T>`.
    /// Ao usar várias cópias dos dados (chamando o `assume_init_read` várias vezes ou primeiro chamando o `assume_init_read` e depois o [`assume_init`]), é sua responsabilidade garantir que esses dados possam de fato ser duplicados.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Uso correto deste método:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` é `Copy`, então podemos ler várias vezes.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Pode-se duplicar um valor `None`, então podemos ler várias vezes.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// Uso *incorreto* deste método:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Agora criamos duas cópias do mesmo vector, levando a um ⚠️ duplo-livre quando ambos são descartados!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // SEGURANÇA: o chamador deve garantir que o `self` seja inicializado.
        // A leitura do `self.as_ptr()` é segura, pois o `self` deve ser inicializado.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Descarta o valor contido no lugar.
    ///
    /// Se você é proprietário do `MaybeUninit`, pode usar o [`assume_init`].
    ///
    /// # Safety
    ///
    /// Cabe ao chamador garantir que o `MaybeUninit<T>` realmente esteja em um estado inicializado.Chamar isso quando o conteúdo ainda não foi totalmente inicializado causa um comportamento indefinido.
    ///
    /// Além disso, todas as invariáveis adicionais do tipo `T` devem ser satisfeitas, já que a implementação `Drop` de `T` (ou seus membros) pode contar com isso.
    /// Por exemplo, um [`Vec<T>`] inicializado com `1` é considerado inicializado (na implementação atual; isso não constitui uma garantia estável) porque o único requisito que o compilador conhece é que o ponteiro de dados deve ser não nulo.
    ///
    /// Abandonar tal `Vec<T>`, entretanto, causará um comportamento indefinido.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // SEGURANÇA: o chamador deve garantir que o `self` seja inicializado e
        // satisfaz todas as invariantes do `T`.
        // Deixar cair o valor no lugar é seguro, se for esse o caso.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Obtém uma referência compartilhada para o valor contido.
    ///
    /// Isso pode ser útil quando queremos acessar um `MaybeUninit` que foi inicializado, mas não tem propriedade do `MaybeUninit` (impedindo o uso do `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Chamar isso quando o conteúdo ainda não foi totalmente inicializado causa um comportamento indefinido: cabe ao chamador garantir que o `MaybeUninit<T>` realmente está em um estado inicializado.
    ///
    ///
    /// # Examples
    ///
    /// ### Uso correto deste método:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Inicialize `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Agora que nosso `MaybeUninit<_>` foi inicializado, não há problema em criar uma referência compartilhada para ele:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // SEGURANÇA: `x` foi inicializado.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### Usos *incorretos* deste método:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Criamos uma referência a um vector não inicializado!Este é um comportamento indefinido.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Inicialize o `MaybeUninit` usando o `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Referência a um `Cell<bool>` não inicializado: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // SEGURANÇA: o chamador deve garantir que o `self` seja inicializado.
        // Isso também significa que o `self` deve ser uma variante do `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Obtém uma referência (unique) mutável para o valor contido.
    ///
    /// Isso pode ser útil quando queremos acessar um `MaybeUninit` que foi inicializado, mas não tem propriedade do `MaybeUninit` (impedindo o uso do `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Chamar isso quando o conteúdo ainda não foi totalmente inicializado causa um comportamento indefinido: cabe ao chamador garantir que o `MaybeUninit<T>` realmente está em um estado inicializado.
    /// Por exemplo, o `.assume_init_mut()` não pode ser usado para inicializar um `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Uso correto deste método:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Inicializa *todos* os bytes do buffer de entrada.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Inicialize `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Agora sabemos que o `buf` foi inicializado, então podemos `.assume_init()` isso.
    /// // No entanto, o uso de `.assume_init()` pode acionar um `memcpy` de 2048 bytes.
    /// // Para garantir que nosso buffer foi inicializado sem copiá-lo, atualizamos o `&mut MaybeUninit<[u8; 2048]>` para um `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // SEGURANÇA: `buf` foi inicializado.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Agora podemos usar o `buf` como uma fatia normal:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### Usos *incorretos* deste método:
    ///
    /// Você não pode usar o `.assume_init_mut()` para inicializar um valor:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Criamos uma referência (mutable) para um `bool` não inicializado!
    ///     // Este é um comportamento indefinido.⚠️
    /// }
    /// ```
    ///
    /// Por exemplo, você não pode usar [`Read`] em um buffer não inicializado:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) referência à memória não inicializada!
    ///                             // Este é um comportamento indefinido.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Nem você pode usar o acesso de campo direto para fazer a inicialização gradual campo a campo:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) referência à memória não inicializada!
    ///                  // Este é um comportamento indefinido.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) referência à memória não inicializada!
    ///                  // Este é um comportamento indefinido.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Atualmente, acreditamos que o acima está incorreto, ou seja, temos referências a dados não inicializados (por exemplo, no `libcore/fmt/float.rs`).
    // Devemos tomar uma decisão final sobre as regras antes da estabilização.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // SEGURANÇA: o chamador deve garantir que o `self` seja inicializado.
        // Isso também significa que o `self` deve ser uma variante do `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Extrai os valores de uma matriz de contêineres `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Cabe ao chamador garantir que todos os elementos da matriz estejam em um estado inicializado.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // SEGURANÇA: agora seguro, pois inicializamos todos os elementos
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * O chamador garante que todos os elementos da matriz sejam inicializados
        // * `MaybeUninit<T>` e T têm a garantia de ter o mesmo layout
        // * MaybeUnint não cai, então não há double-free E, portanto, a conversão é segura
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Assumindo que todos os elementos foram inicializados, obtenha uma fatia para eles.
    ///
    /// # Safety
    ///
    /// Cabe ao chamador garantir que os elementos do `MaybeUninit<T>` realmente estejam em um estado inicializado.
    ///
    /// Chamar isso quando o conteúdo ainda não foi totalmente inicializado causa um comportamento indefinido.
    ///
    /// Consulte [`assume_init_ref`] para obter mais detalhes e exemplos.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // SEGURANÇA: o lançamento de uma fatia para um `*const [T]` é seguro, uma vez que o chamador garante que
        // `slice` é inicializado e `MaybeUninit` tem a garantia de ter o mesmo layout do `T`.
        // O ponteiro obtido é válido porque se refere à memória de propriedade do `slice`, que é uma referência e, portanto, é válida para leituras.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Assumindo que todos os elementos foram inicializados, obtenha uma fatia mutável para eles.
    ///
    /// # Safety
    ///
    /// Cabe ao chamador garantir que os elementos do `MaybeUninit<T>` realmente estejam em um estado inicializado.
    ///
    /// Chamar isso quando o conteúdo ainda não foi totalmente inicializado causa um comportamento indefinido.
    ///
    /// Consulte [`assume_init_mut`] para obter mais detalhes e exemplos.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // SEGURANÇA: semelhante às notas de segurança para `slice_get_ref`, mas temos um
        // referência mutável que também é válida para gravações.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Obtém um ponteiro para o primeiro elemento da matriz.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Obtém um ponteiro mutável para o primeiro elemento da matriz.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Copia os elementos de `src` para `this`, retornando uma referência mutável para o conteúdo agora inicializado de `this`.
    ///
    /// Se `T` não implementar `Copy`, use [`write_slice_cloned`]
    ///
    /// Isso é semelhante ao [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Esta função será panic se os dois cortes tiverem comprimentos diferentes.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SEGURANÇA: acabamos de copiar todos os elementos de len para a capacidade sobressalente
    /// // os primeiros elementos src.len() do vec são válidos agora.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // SEGURANÇA: &[T] e&[MaybeUninit<T>] tem o mesmo layout
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // SEGURANÇA: os elementos válidos acabaram de ser copiados para o `this` para que seja inicializado
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Clona os elementos de `src` em `this`, retornando uma referência mutável para o conteúdo agora inicializado de `this`.
    /// Quaisquer elementos já inicializados não serão eliminados.
    ///
    /// Se o `T` implementa o `Copy`, use o [`write_slice`]
    ///
    /// Isso é semelhante ao [`slice::clone_from_slice`], mas não elimina os elementos existentes.
    ///
    /// # Panics
    ///
    /// Esta função será panic se as duas fatias têm comprimentos diferentes, ou se a implementação de `Clone` panics.
    ///
    /// Se houver um panic, os elementos já clonados serão descartados.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SEGURANÇA: acabamos de clonar todos os elementos de len na capacidade sobressalente
    /// // os primeiros elementos src.len() do vec são válidos agora.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // ao contrário de copy_from_slice, isso não chama clone_from_slice no slice porque o `MaybeUninit<T: Clone>` não implementa Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // SEGURANÇA: esta fatia bruta conterá apenas objetos inicializados
                // por isso, é permitido abandoná-lo.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Precisamos cortá-los explicitamente no mesmo comprimento
        // para que a verificação de limites seja eliminada, o otimizador gerará memcpy para casos simples (por exemplo, T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // proteção é necessária b/c panic pode acontecer durante um clone
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // SEGURANÇA: Os elementos válidos acabaram de ser escritos no `this` para que seja inicializado
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}