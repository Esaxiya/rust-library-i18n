use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Um wrapper para inibir o compilador de chamar automaticamente o destruidor de `T`.
/// Este invólucro tem custo 0.
///
/// `ManuallyDrop<T>` está sujeito às mesmas otimizações de layout do `T`.
/// Como consequência, ele *não tem efeito* nas suposições que o compilador faz sobre seu conteúdo.
/// Por exemplo, inicializar um `ManuallyDrop<&mut T>` com [`mem::zeroed`] é um comportamento indefinido.
/// Se você precisar lidar com dados não inicializados, use o [`MaybeUninit<T>`].
///
/// Observe que acessar o valor dentro de um `ManuallyDrop<T>` é seguro.
/// Isso significa que um `ManuallyDrop<T>` cujo conteúdo foi descartado não deve ser exposto por meio de uma API de segurança pública.
/// Da mesma forma, o `ManuallyDrop::drop` não é seguro.
///
/// # `ManuallyDrop` e ordem de entrega.
///
/// Rust tem um [drop order] de valores bem definido.
/// Para garantir que os campos ou locais sejam eliminados em uma ordem específica, reordene as declarações de forma que a ordem de eliminação implícita seja a correta.
///
/// É possível usar o `ManuallyDrop` para controlar a ordem de descarte, mas isso requer código inseguro e é difícil de fazer corretamente na presença de desenrolamento.
///
///
/// Por exemplo, se você quiser ter certeza de que um campo específico seja descartado após os outros, torne-o o último campo de uma estrutura:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` será descartado após o `children`.
///     // Rust garante que os campos sejam eliminados na ordem de declaração.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Encapsule um valor para ser descartado manualmente.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Você ainda pode operar com segurança no valor
    /// assert_eq!(*x, "Hello");
    /// // Mas o `Drop` não será executado aqui
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Extrai o valor do contêiner `ManuallyDrop`.
    ///
    /// Isso permite que o valor seja descartado novamente.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Isso descarta o `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Retira o valor do contêiner `ManuallyDrop<T>`.
    ///
    /// Este método destina-se principalmente a mover os valores em queda.
    /// Em vez de usar o [`ManuallyDrop::drop`] para descartar manualmente o valor, você pode usar este método para obter o valor e usá-lo como desejar.
    ///
    /// Sempre que possível, é preferível usar o [`into_inner`][`ManuallyDrop::into_inner`], o que evita a duplicação do conteúdo do `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Essa função remove semanticamente o valor contido sem impedir o uso adicional, deixando o estado deste contêiner inalterado.
    /// É sua responsabilidade garantir que este `ManuallyDrop` não seja usado novamente.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // SEGURANÇA: estamos lendo de uma referência, que é garantida
        // para ser válido para leituras.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Elimina manualmente o valor contido.Isso é exatamente equivalente a chamar o [`ptr::drop_in_place`] com um ponteiro para o valor contido.
    /// Assim, a menos que o valor contido seja uma estrutura compactada, o destruidor será chamado no local sem mover o valor e, portanto, pode ser usado para descartar dados [pinned] com segurança.
    ///
    /// Se você for o proprietário do valor, poderá usar o [`ManuallyDrop::into_inner`].
    ///
    /// # Safety
    ///
    /// Esta função executa o destruidor do valor contido.
    /// Além das alterações feitas pelo próprio destruidor, a memória é deixada inalterada e, no que diz respeito ao compilador, ainda mantém um padrão de bits válido para o tipo `T`.
    ///
    ///
    /// No entanto, esse valor "zombie" não deve ser exposto a um código seguro e essa função não deve ser chamada mais de uma vez.
    /// Usar um valor depois de eliminado ou eliminar um valor várias vezes pode causar comportamento indefinido (dependendo do que o `drop` faz).
    /// Isso normalmente é evitado pelo sistema de tipos, mas os usuários do `ManuallyDrop` devem manter essas garantias sem a ajuda do compilador.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // SEGURANÇA: estamos eliminando o valor apontado por uma referência mutável
        // que é garantidamente válido para gravações.
        // É responsabilidade do chamador garantir que o `slot` não seja desconectado novamente.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}