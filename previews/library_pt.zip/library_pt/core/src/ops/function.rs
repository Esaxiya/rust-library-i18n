/// A versão da operadora de chamadas que recebe um receptor imutável.
///
/// As instâncias do `Fn` podem ser chamadas repetidamente sem mutação do estado.
///
/// *Este trait (`Fn`) não deve ser confundido com o [function pointers] (`fn`).*
///
/// `Fn` é implementado automaticamente por fechamentos que só levam referências imutáveis para variáveis capturadas ou não capturam nada, bem como (safe) [function pointers] (com algumas ressalvas, consulte sua documentação para mais detalhes).
///
/// Além disso, para qualquer tipo de `F` que implemente `Fn`, o `&F` também implementa `Fn`.
///
/// Uma vez que [`FnMut`] e [`FnOnce`] são supertraits de `Fn`, qualquer instância de `Fn` pode ser usada como um parâmetro onde um [`FnMut`] ou [`FnOnce`] é esperado.
///
/// Use o `Fn` como limite quando quiser aceitar um parâmetro do tipo semelhante a uma função e precisar chamá-lo repetidamente e sem estado de mutação (por exemplo, ao chamá-lo simultaneamente).
/// Se você não precisar desses requisitos rígidos, use [`FnMut`] ou [`FnOnce`] como limites.
///
/// Consulte o [chapter on closures in *The Rust Programming Language*][book] para obter mais informações sobre este tópico.
///
/// Também digno de nota é a sintaxe especial para `Fn` traits (por exemplo
/// `Fn(usize, bool) -> usize`).Os interessados nos detalhes técnicos disso podem consultar o [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Chamando um encerramento
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Usando um parâmetro `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // de modo que regex pode confiar que `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Executa a operação de chamada.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// A versão da operadora de chamada que usa um receptor mutável.
///
/// As instâncias do `FnMut` podem ser chamadas repetidamente e podem sofrer mutação.
///
/// `FnMut` é implementado automaticamente por fechamentos que levam referências mutáveis para variáveis capturadas, bem como todos os tipos que implementam [`Fn`], por exemplo, (safe) [function pointers] (já que `FnMut` é um super estreito de [`Fn`]).
/// Além disso, para qualquer tipo de `F` que implemente `FnMut`, o `&mut F` também implementa `FnMut`.
///
/// Uma vez que [`FnOnce`] é um sub-estreito de `FnMut`, qualquer instância de `FnMut` pode ser usada onde um [`FnOnce`] é esperado, e uma vez que [`Fn`] é um subtítulo de `FnMut`, qualquer instância de [`Fn`] pode ser usada onde `FnMut` é esperado.
///
/// Use o `FnMut` como um limite quando quiser aceitar um parâmetro do tipo semelhante a uma função e precisar chamá-lo repetidamente, enquanto permite que ele mude de estado.
/// Se você não quiser que o parâmetro mude de estado, use [`Fn`] como um limite;se você não precisar chamá-lo repetidamente, use o [`FnOnce`].
///
/// Consulte o [chapter on closures in *The Rust Programming Language*][book] para obter mais informações sobre este tópico.
///
/// Também digno de nota é a sintaxe especial para `Fn` traits (por exemplo
/// `Fn(usize, bool) -> usize`).Os interessados nos detalhes técnicos disso podem consultar o [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Chamando um encerramento de captura mutável
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Usando um parâmetro `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // de modo que regex pode confiar que `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Executa a operação de chamada.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// A versão da operadora de chamadas que recebe um receptor por valor.
///
/// As instâncias de `FnOnce` podem ser chamadas, mas não podem ser chamadas várias vezes.Por isso, se a única coisa conhecida sobre um tipo é que ele implementa o `FnOnce`, ele só pode ser chamado uma vez.
///
/// `FnOnce` é implementado automaticamente por fechamentos que podem consumir variáveis capturadas, bem como todos os tipos que implementam [`FnMut`], por exemplo, (safe) [function pointers] (já que `FnOnce` é um super estreito de [`FnMut`]).
///
///
/// Uma vez que [`Fn`] e [`FnMut`] são subtraits de `FnOnce`, qualquer instância de [`Fn`] ou [`FnMut`] pode ser usada onde um `FnOnce` é esperado.
///
/// Use o `FnOnce` como um limite quando quiser aceitar um parâmetro do tipo semelhante a uma função e só precisar chamá-lo uma vez.
/// Se você precisar chamar o parâmetro repetidamente, use [`FnMut`] como um limite;se você também precisar dele para não alterar o estado, use o [`Fn`].
///
/// Consulte o [chapter on closures in *The Rust Programming Language*][book] para obter mais informações sobre este tópico.
///
/// Também digno de nota é a sintaxe especial para `Fn` traits (por exemplo
/// `Fn(usize, bool) -> usize`).Os interessados nos detalhes técnicos disso podem consultar o [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Usando um parâmetro `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` consome suas variáveis capturadas, portanto, não pode ser executado mais de uma vez.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // A tentativa de invocar o `func()` novamente gerará um erro `use of moved value` para o `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` não pode mais ser invocado neste ponto
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // de modo que regex pode confiar que `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// O tipo retornado após o operador de chamada ser usado.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Executa a operação de chamada.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}