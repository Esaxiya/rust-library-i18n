use crate::marker::Unsize;

/// Trait que indica que este é um ponteiro ou um invólucro para um, onde o desdimensionamento pode ser executado na ponta.
///
/// Consulte o [DST coercion RFC][dst-coerce] e o [the nomicon entry on coercion][nomicon-coerce] para obter mais detalhes.
///
/// Para tipos de ponteiros embutidos, ponteiros para `T` forçarão ponteiros para `U` se `T: Unsize<U>`, convertendo de um ponteiro fino para um ponteiro grande.
///
/// Para tipos personalizados, a coerção aqui funciona coagindo `Foo<T>` a `Foo<U>`, desde que exista um impl de `CoerceUnsized<Foo<U>> for Foo<T>`.
/// Tal impl só pode ser escrito se o `Foo<T>` tiver apenas um único campo não fantasma envolvendo o `T`.
/// Se o tipo desse campo for `Bar<T>`, deve existir uma implementação de `CoerceUnsized<Bar<U>> for Bar<T>`.
/// A coerção funcionará coagindo o campo `Bar<T>` em `Bar<U>` e preenchendo os demais campos de `Foo<T>` para criar um `Foo<U>`.
/// Isso irá efetivamente detalhar um campo de ponteiro e forçá-lo.
///
/// Geralmente, para ponteiros inteligentes, você implementará o `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, com um `?Sized` opcional vinculado ao próprio `T`.
/// Para tipos de invólucro que incorporam diretamente `T` como `Cell<T>` e `RefCell<T>`, você pode implementar `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` diretamente.
///
/// Isso permitirá que coações de tipos como o `Cell<Box<T>>` funcionem.
///
/// [`Unsize`][unsize] é usado para marcar tipos que podem ser coagidos para DSTs se estiverem atrás de ponteiros.Ele é implementado automaticamente pelo compilador.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Isso é usado para segurança do objeto, para verificar se o tipo de receptor de um método pode ser despachado.
///
/// Um exemplo de implementação do trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}