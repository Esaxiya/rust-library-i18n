/// Usado para operações de desreferenciamento imutáveis, como `*v`.
///
/// Além de ser usado para operações de desreferenciamento explícito com o operador (unary) `*` em contextos imutáveis, o `Deref` também é usado implicitamente pelo compilador em muitas circunstâncias.
/// Este mecanismo é denominado ['`Deref` coercion'][more].
/// Em contextos mutáveis, o [`DerefMut`] é usado.
///
/// Implementar o `Deref` para ponteiros inteligentes torna o acesso aos dados por trás deles conveniente, e é por isso que eles implementam o `Deref`.
/// Por outro lado, as regras relativas ao `Deref` e [`DerefMut`] foram projetadas especificamente para acomodar ponteiros inteligentes.
/// Por causa disso,**`Deref` deve ser implementado apenas para ponteiros inteligentes** para evitar confusão.
///
/// Por razões semelhantes,**este trait nunca deve falhar**.A falha durante a desreferenciação pode ser extremamente confusa quando o `Deref` é invocado implicitamente.
///
/// # Mais sobre coerção `Deref`
///
/// Se `T` implementar `Deref<Target = U>` e `x` for um valor do tipo `T`, então:
///
/// * Em contextos imutáveis, `*x` (em que `T` não é uma referência nem um ponteiro bruto) é equivalente a `* Deref::deref(&x)`.
/// * Valores do tipo `&T` são forçados para valores do tipo `&U`
/// * `T` implementa implicitamente todos os métodos (immutable) do tipo `U`.
///
/// Para obter mais detalhes, visite [the chapter in *The Rust Programming Language*][book], bem como as seções de referência em [the dereference operator][ref-deref-op], [method resolution] e [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Uma estrutura com um único campo que pode ser acessada desreferenciando a estrutura.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// O tipo resultante após a desreferenciação.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Cancela a referência do valor.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Usado para operações mutáveis de desreferenciamento, como no `*v = 1;`.
///
/// Além de ser usado para operações de desreferenciamento explícitas com o operador (unary) `*` em contextos mutáveis, o `DerefMut` também é usado implicitamente pelo compilador em muitas circunstâncias.
/// Este mecanismo é denominado ['`Deref` coercion'][more].
/// Em contextos imutáveis, o [`Deref`] é usado.
///
/// Implementar o `DerefMut` para ponteiros inteligentes torna conveniente a mutação dos dados por trás deles, e é por isso que eles implementam o `DerefMut`.
/// Por outro lado, as regras relativas ao [`Deref`] e `DerefMut` foram projetadas especificamente para acomodar ponteiros inteligentes.
/// Por causa disso,**`DerefMut` só deve ser implementado para ponteiros inteligentes** para evitar confusão.
///
/// Por razões semelhantes,**este trait nunca deve falhar**.A falha durante a desreferenciação pode ser extremamente confusa quando o `DerefMut` é invocado implicitamente.
///
/// # Mais sobre coerção `Deref`
///
/// Se `T` implementar `DerefMut<Target = U>` e `x` for um valor do tipo `T`, então:
///
/// * Em contextos mutáveis, `*x` (em que `T` não é uma referência nem um ponteiro bruto) é equivalente a `* DerefMut::deref_mut(&mut x)`.
/// * Valores do tipo `&mut T` são forçados para valores do tipo `&mut U`
/// * `T` implementa implicitamente todos os métodos (mutable) do tipo `U`.
///
/// Para obter mais detalhes, visite [the chapter in *The Rust Programming Language*][book], bem como as seções de referência em [the dereference operator][ref-deref-op], [method resolution] e [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Uma estrutura com um único campo que é modificável desreferenciando a estrutura.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Desreferencia mutuamente o valor.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Indica que uma estrutura pode ser usada como um receptor de método, sem o recurso `arbitrary_self_types`.
///
/// Isso é implementado por tipos de ponteiro stdlib como `Box<T>`, `Rc<T>`, `&T` e `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}