use crate::marker::Unpin;
use crate::pin::Pin;

/// O resultado de uma retomada do gerador.
///
/// Este enum é retornado do método `Generator::resume` e indica os possíveis valores de retorno de um gerador.
/// Atualmente, isso corresponde a um ponto de suspensão (`Yielded`) ou a um ponto de terminação (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// O gerador suspendeu com um valor.
    ///
    /// Este estado indica que um gerador foi suspenso e normalmente corresponde a uma instrução `yield`.
    /// O valor fornecido nesta variante corresponde à expressão passada ao `yield` e permite que os geradores forneçam um valor cada vez que produzirem.
    ///
    ///
    Yielded(Y),

    /// O gerador foi concluído com um valor de retorno.
    ///
    /// Este estado indica que um gerador terminou a execução com o valor fornecido.
    /// Depois que um gerador retorna o `Complete`, é considerado um erro do programador chamar o `resume` novamente.
    ///
    Complete(R),
}

/// O trait implementado por tipos de gerador embutidos.
///
/// Geradores, também comumente chamados de co-rotinas, são atualmente um recurso de linguagem experimental no Rust.
/// Os geradores adicionados ao [RFC 2033] têm como objetivo principal fornecer um bloco de construção para a sintaxe async/await, mas provavelmente se estenderão para fornecer uma definição ergonômica para iteradores e outros primitivos.
///
///
/// A sintaxe e a semântica dos geradores são instáveis e exigirão um RFC adicional para estabilização.No momento, porém, a sintaxe é semelhante a um fechamento:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Mais documentação sobre geradores pode ser encontrada no livro instável.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// O tipo de valor que este gerador produz.
    ///
    /// Este tipo associado corresponde à expressão `yield` e aos valores que podem ser retornados cada vez que um gerador cede.
    ///
    /// Por exemplo, um iterador como gerador provavelmente teria esse tipo como `T`, o tipo sendo iterado.
    ///
    type Yield;

    /// O tipo de valor que este gerador retorna.
    ///
    /// Isso corresponde ao tipo retornado de um gerador com uma instrução `return` ou implicitamente como a última expressão de um literal de gerador.
    /// Por exemplo, futures usaria isso como `Result<T, E>`, pois representa um future completo.
    ///
    ///
    type Return;

    /// Retoma a execução deste gerador.
    ///
    /// Esta função irá retomar a execução do gerador ou iniciar a execução se ainda não o fez.
    /// Essa chamada retornará ao último ponto de suspensão do gerador, retomando a execução do `yield` mais recente.
    /// O gerador continuará executando até que produza ou retorne, ponto em que esta função retornará.
    ///
    /// # Valor de retorno
    ///
    /// O enum `GeneratorState` retornado desta função indica em que estado o gerador está ao retornar.
    /// Se a variante `Yielded` for retornada, o gerador atingiu um ponto de suspensão e um valor foi gerado.
    /// Os geradores neste estado estão disponíveis para serem reiniciados posteriormente.
    ///
    /// Se `Complete` for retornado, o gerador terminou completamente com o valor fornecido.É inválido que o gerador seja reiniciado.
    ///
    /// # Panics
    ///
    /// Esta função pode ser panic se for chamada depois que a variante `Complete` tiver sido retornada anteriormente.
    /// Embora os literais do gerador na linguagem sejam garantidos para panic ao retomar após o `Complete`, isso não é garantido para todas as implementações do `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}