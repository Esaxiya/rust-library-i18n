/// Um trait para personalizar o comportamento do operador `?`.
///
/// Um tipo que implementa o `Try` é aquele que possui uma maneira canônica de visualizá-lo em termos de uma dicotomia success/failure.
/// Este trait permite extrair esses valores de sucesso ou falha de uma instância existente e criar uma nova instância a partir de um valor de sucesso ou falha.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// O tipo deste valor quando visto como bem-sucedido.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// O tipo deste valor quando visto como falha.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Aplica o operador "?".Um retorno de `Ok(t)` significa que a execução deve continuar normalmente, e o resultado de `?` é o valor `t`.
    /// Um retorno de `Err(e)` significa que a execução deve branch para o `catch` mais interno ou retornar da função.
    ///
    /// Se um resultado `Err(e)` for retornado, o valor `e` será "wrapped" no tipo de retorno do escopo delimitador (que deve por si só implementar `Try`).
    ///
    /// Especificamente, o valor `X::from_error(From::from(e))` é retornado, onde `X` é o tipo de retorno da função envolvente.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Envolva um valor de erro para construir o resultado composto.
    /// Por exemplo, `Result::Err(x)` e `Result::from_error(x)` são equivalentes.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Envolva um valor OK para construir o resultado composto.
    /// Por exemplo, `Result::Ok(x)` e `Result::from_ok(x)` são equivalentes.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}