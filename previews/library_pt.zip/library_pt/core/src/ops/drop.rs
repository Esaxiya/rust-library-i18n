/// Código personalizado dentro do destruidor.
///
/// Quando um valor não é mais necessário, Rust executará um "destructor" naquele valor.
/// A maneira mais comum de um valor não ser mais necessário é quando ele sai do escopo.Os destruidores ainda podem funcionar em outras circunstâncias, mas vamos nos concentrar no escopo dos exemplos aqui.
/// Para saber mais sobre alguns desses outros casos, consulte a seção [the reference] sobre destruidores.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Este destruidor consiste em dois componentes:
/// - Uma chamada para `Drop::drop` para esse valor, se este `Drop` trait especial for implementado para seu tipo.
/// - O "drop glue" gerado automaticamente que chama recursivamente os destruidores de todos os campos deste valor.
///
/// Como Rust chama automaticamente os destruidores de todos os campos contidos, você não precisa implementar o `Drop` na maioria dos casos.
/// Mas existem alguns casos em que é útil, por exemplo, para tipos que gerenciam diretamente um recurso.
/// Esse recurso pode ser memória, pode ser um descritor de arquivo, pode ser um soquete de rede.
/// Quando um valor desse tipo não for mais usado, ele deve "clean up" seu recurso, liberando a memória ou fechando o arquivo ou soquete.
/// Este é o trabalho de um destruidor e, portanto, o trabalho do `Drop::drop`.
///
/// ## Examples
///
/// Para ver os destruidores em ação, vamos dar uma olhada no seguinte programa:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust primeiro chamará `Drop::drop` para `_x` e depois para `_x.one` e `_x.two`, o que significa que executar isso imprimirá
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Mesmo se removermos a implementação de `Drop` para `HasTwoDrop`, os destruidores de seus campos ainda são chamados.
/// Isso resultaria em
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Você não pode ligar para o `Drop::drop` sozinho
///
/// Como o `Drop::drop` é usado para limpar um valor, pode ser perigoso usar esse valor depois que o método for chamado.
/// Como o `Drop::drop` não assume a propriedade de sua entrada, o Rust evita o uso indevido, não permitindo que você chame o `Drop::drop` diretamente.
///
/// Em outras palavras, se você tentar chamar explicitamente o `Drop::drop` no exemplo acima, receberá um erro do compilador.
///
/// Se desejar chamar explicitamente o destruidor de um valor, [`mem::drop`] pode ser usado em seu lugar.
///
/// [`mem::drop`]: drop
///
/// ## Ordem de entrega
///
/// Qual dos nossos dois `HasDrop` cai primeiro, entretanto?Para structs, é a mesma ordem em que são declarados: primeiro `one`, depois `two`.
/// Se você quiser tentar fazer isso sozinho, pode modificar o `HasDrop` acima para conter alguns dados, como um número inteiro, e então usá-lo no `println!` dentro do `Drop`.
/// Esse comportamento é garantido pelo idioma.
///
/// Ao contrário de structs, as variáveis locais são descartadas na ordem inversa:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Isso vai imprimir
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Consulte o [the reference] para obter as regras completas.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` e `Drop` são exclusivos
///
/// Você não pode implementar [`Copy`] e `Drop` no mesmo tipo.Os tipos `Copy` são duplicados implicitamente pelo compilador, tornando muito difícil prever quando e com que freqüência os destruidores serão executados.
///
/// Como tal, esses tipos não podem ter destruidores.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Executa o destruidor para este tipo.
    ///
    /// Este método é chamado implicitamente quando o valor sai do escopo e não pode ser chamado explicitamente (este é o erro do compilador [E0040]).
    /// No entanto, a função [`mem::drop`] no prelude pode ser usada para chamar a implementação `Drop` do argumento.
    ///
    /// Quando esse método foi chamado, o `self` ainda não foi desalocado.
    /// Isso só acontece depois que o método termina.
    /// Se este não fosse o caso, o `self` seria uma referência pendente.
    ///
    /// # Panics
    ///
    /// Dado que um [`panic!`] chamará `drop` à medida que se desenrola, qualquer [`panic!`] em uma implementação `drop` provavelmente será abortado.
    ///
    /// Observe que mesmo se este panics, o valor é considerado como descartado;
    /// você não deve fazer com que o `drop` seja chamado novamente.
    /// Isso normalmente é tratado automaticamente pelo compilador, mas ao usar código inseguro, às vezes pode ocorrer de forma não intencional, especialmente ao usar o [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}