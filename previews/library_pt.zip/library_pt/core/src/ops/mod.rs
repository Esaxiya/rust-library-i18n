//! Operadores sobrecarregáveis.
//!
//! Implementar esses traits permite sobrecarregar certos operadores.
//!
//! Alguns desses traits são importados pelo prelude, portanto, estão disponíveis em todos os programas Rust.Apenas operadores apoiados por traits podem ser sobrecarregados.
//! Por exemplo, o operador de adição (`+`) pode ser sobrecarregado por meio do [`Add`] trait, mas como o operador de atribuição (`=`) não tem suporte trait, não há como sobrecarregar sua semântica.
//! Além disso, este módulo não fornece nenhum mecanismo para criar novos operadores.
//! Se sobrecarga sem características ou operadores personalizados forem necessários, você deve olhar para macros ou plug-ins do compilador para estender a sintaxe do Rust.
//!
//! As implementações do operador traits não devem surpreender em seus respectivos contextos, tendo em mente seus significados usuais e [operator precedence].
//! Por exemplo, ao implementar o [`Mul`], a operação deve ter alguma semelhança com a multiplicação (e compartilhar propriedades esperadas como associatividade).
//!
//! Observe que os operadores `&&` e `||` entram em curto-circuito, ou seja, só avaliam seu segundo operando se ele contribuir com o resultado.Uma vez que este comportamento não é aplicável por traits, `&&` e `||` não são suportados como operadores sobrecarregáveis.
//!
//! Muitos dos operadores consideram seus operandos por valor.Em contextos não genéricos que envolvem tipos internos, isso geralmente não é um problema.
//! No entanto, usar esses operadores em código genérico requer alguma atenção se os valores tiverem que ser reutilizados em vez de permitir que os operadores os consumam.Uma opção é usar ocasionalmente o [`clone`].
//! Outra opção é confiar nos tipos envolvidos, fornecendo implementações de operador adicionais para referências.
//! Por exemplo, para um tipo definido pelo usuário `T` que supostamente suporta adição, é provavelmente uma boa ideia ter o `T` e o `&T` implementando o traits [`Add<T>`][`Add`] e o [`Add<&T>`][`Add`] para que o código genérico possa ser escrito sem clonagem desnecessária.
//!
//!
//! # Examples
//!
//! Este exemplo cria uma estrutura `Point` que implementa [`Add`] e [`Sub`] e, em seguida, demonstra a adição e subtração de dois `Point`s.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Veja a documentação de cada trait para um exemplo de implementação.
//!
//! O [`Fn`], [`FnMut`] e [`FnOnce`] traits são implementados por tipos que podem ser chamados como funções.Observe que [`Fn`] leva `&self`, [`FnMut`] leva `&mut self` e [`FnOnce`] leva `self`.
//! Eles correspondem aos três tipos de métodos que podem ser invocados em uma instância: chamada por referência, chamada por referência mutável e chamada por valor.
//! O uso mais comum desses traits é atuar como limites para funções de nível superior que usam funções ou encerramentos como argumentos.
//!
//! Tomando um [`Fn`] como parâmetro:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Tomando um [`FnMut`] como parâmetro:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Tomando um [`FnOnce`] como parâmetro:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` consome suas variáveis capturadas, portanto, não pode ser executado mais de uma vez
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Tentar invocar o `func()` novamente gerará um erro `use of moved value` para o `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` não pode mais ser invocado neste ponto
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;