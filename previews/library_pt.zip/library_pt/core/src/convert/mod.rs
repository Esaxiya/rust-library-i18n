//! Traits para conversões entre tipos.
//!
//! O traits neste módulo fornece uma maneira de converter de um tipo para outro.
//! Cada trait serve a um propósito diferente:
//!
//! - Implemente o [`AsRef`] trait para conversões baratas de referência a referência
//! - Implemente o [`AsMut`] trait para conversões baratas de mutável para mutável
//! - Implemente o [`From`] trait para consumir conversões de valor para valor
//! - Implemente o [`Into`] trait para consumir conversões de valor a valor para tipos fora do crate atual
//! - O [`TryFrom`] e o [`TryInto`] traits se comportam como o [`From`] e o [`Into`], mas devem ser implementados quando a conversão pode falhar.
//!
//! Os traits neste módulo são freqüentemente usados como trait bounds para funções genéricas de modo que argumentos de vários tipos sejam suportados.Veja a documentação de cada trait para exemplos.
//!
//! Como autor de uma biblioteca, você deve sempre preferir implementar [`From<T>`][`From`] ou [`TryFrom<T>`][`TryFrom`] em vez de [`Into<U>`][`Into`] ou [`TryInto<U>`][`TryInto`], pois [`From`] e [`TryFrom`] fornecem maior flexibilidade e oferecem implementações [`Into`] ou [`TryInto`] equivalentes gratuitamente, graças a uma implementação abrangente na biblioteca padrão.
//! Ao direcionar uma versão anterior a Rust 1.41, pode ser necessário implementar [`Into`] ou [`TryInto`] diretamente ao converter para um tipo fora do crate atual.
//!
//! # Implementações Genéricas
//!
//! - [`AsRef`] e auto-desreferência [`AsMut`] se o tipo interno for uma referência
//! - [`De`]`<U>para T` implica [`Into`]`</u><T><U>para U`</u>
//! - [`TryFrom`]`<U>para T` implica [`TryInto`]`</u><T><U>para U`</u>
//! - [`From`] e [`Into`] são reflexivos, o que significa que todos os tipos podem usar o `into` e o `from`
//!
//! Veja cada trait para exemplos de uso.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// A função de identidade.
///
/// Duas coisas são importantes a serem observadas sobre esta função:
///
/// - Nem sempre é equivalente a uma tampa como o `|x| x`, uma vez que a tampa pode forçar o `x` a um tipo diferente.
///
/// - Ele move a entrada `x` passada para a função.
///
/// Embora possa parecer estranho ter uma função que apenas retorna a entrada, existem alguns usos interessantes.
///
///
/// # Examples
///
/// Usar o `identity` para não fazer nada em uma sequência de outras funções interessantes:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Vamos fingir que adicionar um é uma função interessante.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Usando o `identity` como um caso base do "do nothing" em uma condição:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Faça coisas mais interessantes ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Usando o `identity` para manter as variantes `Some` de um iterador do `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Usado para fazer uma conversão de referência para referência barata.
///
/// Este trait é semelhante ao [`AsMut`] que é usado para converter entre referências mutáveis.
/// Se você precisar fazer uma conversão cara, é melhor implementar o [`From`] com o tipo `&T` ou escrever uma função personalizada.
///
/// `AsRef` tem a mesma assinatura que [`Borrow`], mas [`Borrow`] é diferente em alguns aspectos:
///
/// - Ao contrário do `AsRef`, o [`Borrow`] tem um implemento de cobertura para qualquer `T` e pode ser usado para aceitar uma referência ou um valor.
/// - [`Borrow`] também requer que [`Hash`], [`Eq`] e [`Ord`] para o valor emprestado sejam equivalentes aos do valor de propriedade.
/// Por esse motivo, se você deseja emprestar apenas um único campo de uma estrutura, pode implementar o `AsRef`, mas não o [`Borrow`].
///
/// **Note: Este trait não deve falhar **.Se a conversão falhar, use um método dedicado que retorna um [`Option<T>`] ou um [`Result<T, E>`].
///
/// # Implementações Genéricas
///
/// - `AsRef` auto-desreferências se o tipo interno for uma referência ou uma referência mutável (por exemplo: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Usando trait bounds, podemos aceitar argumentos de diferentes tipos, desde que possam ser convertidos para o tipo especificado `T`.
///
/// Por exemplo: Ao criar uma função genérica que usa um `AsRef<str>`, expressamos que queremos aceitar todas as referências que podem ser convertidas para [`&str`] como um argumento.
/// Como o [`String`] e o [`&str`] implementam o `AsRef<str>`, podemos aceitar ambos como argumento de entrada.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Executa a conversão.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Usado para fazer uma conversão de referência mutável em mutável barata.
///
/// Este trait é semelhante ao [`AsRef`], mas usado para converter entre referências mutáveis.
/// Se você precisar fazer uma conversão cara, é melhor implementar o [`From`] com o tipo `&mut T` ou escrever uma função personalizada.
///
/// **Note: Este trait não deve falhar **.Se a conversão falhar, use um método dedicado que retorna um [`Option<T>`] ou um [`Result<T, E>`].
///
/// # Implementações Genéricas
///
/// - `AsMut` auto-desreferências se o tipo interno for uma referência mutável (por exemplo: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Usando `AsMut` como trait bound para uma função genérica, podemos aceitar todas as referências mutáveis que podem ser convertidas para o tipo `&mut T`.
/// Como o [`Box<T>`] implementa o `AsMut<T>`, podemos escrever uma função `add_one` que recebe todos os argumentos que podem ser convertidos em `&mut u64`.
/// Como o [`Box<T>`] implementa o `AsMut<T>`, o `add_one` também aceita argumentos do tipo `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Executa a conversão.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Uma conversão de valor em valor que consome o valor de entrada.O oposto de [`From`].
///
/// Deve-se evitar a implementação do [`Into`] e, em vez disso, implementar o [`From`].
/// A implementação do [`From`] fornece automaticamente uma implementação do [`Into`] graças à implementação abrangente na biblioteca padrão.
///
/// Prefira usar [`Into`] em vez de [`From`] ao especificar trait bounds em uma função genérica para garantir que os tipos que apenas implementam [`Into`] também possam ser usados.
///
/// **Note: Este trait não deve falhar **.Se a conversão falhar, use o [`TryInto`].
///
/// # Implementações Genéricas
///
/// - [`De`]`<T>para U` implica `Into<U> for T`
/// - [`Into`] é reflexivo, o que significa que o `Into<T> for T` é implementado
///
/// # Implementando [`Into`] para conversões para tipos externos em versões antigas de Rust
///
/// Antes de Rust 1.41, se o tipo de destino não fazia parte do crate atual, então você não podia implementar o [`From`] diretamente.
/// Por exemplo, pegue este código:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Isso falhará ao compilar em versões anteriores da linguagem porque as regras de órfão do Rust costumavam ser um pouco mais rígidas.
/// Para contornar isso, você pode implementar o [`Into`] diretamente:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// É importante entender que o [`Into`] não fornece uma implementação [`From`] (como o [`From`] faz com o [`Into`]).
/// Portanto, você deve sempre tentar implementar o [`From`] e depois voltar para o [`Into`] se o [`From`] não puder ser implementado.
///
/// # Examples
///
/// [`String`] implementa [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// A fim de expressar que queremos uma função genérica para receber todos os argumentos que podem ser convertidos para um tipo especificado `T`, podemos usar um trait bound de [`Into`]`<T>`.
///
/// Por exemplo: A função `is_hello` leva todos os argumentos que podem ser convertidos em um [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Executa a conversão.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Usado para fazer conversões de valor para valor enquanto consome o valor de entrada.É o recíproco do [`Into`].
///
/// Deve-se sempre preferir implementar `From` em vez de [`Into`] porque implementar `From` automaticamente fornece uma implementação de [`Into`] graças à implementação abrangente na biblioteca padrão.
///
///
/// Implemente o [`Into`] apenas quando tiver como alvo uma versão anterior a Rust 1.41 e converter para um tipo fora do crate atual.
/// `From` não foi capaz de fazer esses tipos de conversões em versões anteriores por causa das regras de órfão do Rust.
/// Consulte [`Into`] para obter mais detalhes.
///
/// Prefira usar [`Into`] em vez de `From` ao especificar trait bounds em uma função genérica.
/// Dessa forma, os tipos que implementam diretamente o [`Into`] também podem ser usados como argumentos.
///
/// O `From` também é muito útil ao executar o tratamento de erros.Ao construir uma função que pode falhar, o tipo de retorno geralmente será no formato `Result<T, E>`.
/// O `From` trait simplifica o tratamento de erros, permitindo que uma função retorne um único tipo de erro que encapsula vários tipos de erro.Consulte a seção "Examples" e [the book][book] para obter mais detalhes.
///
/// **Note: Este trait não deve falhar **.Se a conversão falhar, use o [`TryFrom`].
///
/// # Implementações Genéricas
///
/// - `From<T> for U` implica [`Into`]`<U>para T`</u>
/// - `From` é reflexivo, o que significa que o `From<T> for T` é implementado
///
/// # Examples
///
/// [`String`] implementa `From<&str>`:
///
/// Uma conversão explícita de um `&str` para uma String é feita da seguinte maneira:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Ao executar o tratamento de erros, geralmente é útil implementar o `From` para seu próprio tipo de erro.
/// Ao converter tipos de erro subjacentes em nosso próprio tipo de erro personalizado que encapsula o tipo de erro subjacente, podemos retornar um único tipo de erro sem perder informações sobre a causa subjacente.
/// O operador '?' converte automaticamente o tipo de erro subjacente em nosso tipo de erro personalizado chamando o `Into<CliError>::into`, que é fornecido automaticamente ao implementar o `From`.
/// O compilador então infere qual implementação do `Into` deve ser usada.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Executa a conversão.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Uma tentativa de conversão que consome `self`, que pode ou não ser cara.
///
/// Os autores da biblioteca normalmente não devem implementar diretamente este trait, mas devem preferir implementar o [`TryFrom`] trait, que oferece maior flexibilidade e fornece uma implementação equivalente do `TryInto` gratuitamente, graças a uma implementação abrangente na biblioteca padrão.
/// Para obter mais informações sobre isso, consulte a documentação do [`Into`].
///
/// # Implementando `TryInto`
///
/// Isso sofre as mesmas restrições e raciocínio da implementação do [`Into`], consulte lá para obter detalhes.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// O tipo retornado no caso de um erro de conversão.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Executa a conversão.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Conversões de tipo simples e seguras que podem falhar de forma controlada em algumas circunstâncias.É o recíproco do [`TryInto`].
///
/// Isso é útil quando você está fazendo uma conversão de tipo que pode ser bem-sucedida trivialmente, mas também pode precisar de tratamento especial.
/// Por exemplo, não há como converter um [`i64`] em um [`i32`] usando o [`From`] trait, porque um [`i64`] pode conter um valor que um [`i32`] não pode representar e, portanto, a conversão pode perder dados.
///
/// Isso pode ser tratado truncando o [`i64`] para um [`i32`] (essencialmente fornecendo o módulo de valor de [`i64`] [`i32::MAX`]) ou simplesmente retornando [`i32::MAX`], ou por algum outro método.
/// O [`From`] trait é projetado para conversões perfeitas, então o `TryFrom` trait informa o programador quando uma conversão de tipo pode dar errado e permite que ele decida como lidar com isso.
///
/// # Implementações Genéricas
///
/// - `TryFrom<T> for U` implica [`TryInto`]`<U>para T`</u>
/// - [`try_from`] é reflexivo, o que significa que `TryFrom<T> for T` é implementado e não pode falhar-o tipo `Error` associado para chamar `T::try_from()` em um valor do tipo `T` é [`Infallible`].
/// Quando o tipo [`!`] é estabilizado, [`Infallible`] e [`!`] serão equivalentes.
///
/// `TryFrom<T>` pode ser implementado da seguinte forma:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Conforme descrito, o [`i32`] implementa `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Trunca silenciosamente o `big_number`, requer a detecção e o tratamento do truncamento após o fato.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Retorna um erro porque o `big_number` é muito grande para caber em um `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Retorna `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// O tipo retornado no caso de um erro de conversão.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Executa a conversão.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// IMPLICAÇÕES GENÉRICAS
////////////////////////////////////////////////////////////////////////////////

// À medida que sobe e
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Como elevadores sobre &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): substitua o impls acima para&/&mut pelo seguinte mais geral:
// // Como elevadores sobre Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Sized> AsRef <U>para D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut eleva sobre &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): substitua o impl acima para &mut pelo seguinte mais geral:
// // AsMut sobe sobre DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Sized> AsMut <U>para D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// De implica em
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// De (e, portanto, para dentro) é reflexivo
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Nota de estabilidade:** Este impl ainda não existe, mas estamos "reserving space" para adicioná-lo ao future.
/// Consulte [rust-lang/rust#64715][#64715] para obter detalhes.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): em vez disso, faça uma correção baseada em princípios.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom implica TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Conversões infalíveis são semanticamente equivalentes a conversões falíveis com um tipo de erro inabitado.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// IMPLICAÇÕES DE CONCRETO
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// O TIPO DE ERRO SEM ERRO
////////////////////////////////////////////////////////////////////////////////

/// O tipo de erro para erros que nunca podem acontecer.
///
/// Como esse enum não tem variante, um valor desse tipo nunca pode realmente existir.
/// Isso pode ser útil para APIs genéricas que usam [`Result`] e parametrizam o tipo de erro, para indicar que o resultado é sempre [`Ok`].
///
/// Por exemplo, o [`TryFrom`] trait (conversão que retorna um [`Result`]) tem uma implementação geral para todos os tipos onde existe uma implementação reversa de [`Into`].
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Compatibilidade Future
///
/// Este enum tem a mesma função do [the `!`“never”type][never], que é instável nesta versão do Rust.
/// Quando o `!` estiver estabilizado, planejamos fazer do `Infallible` um alias de tipo para ele:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …E eventualmente descontinuar o `Infallible`.
///
/// No entanto, há um caso em que a sintaxe `!` pode ser usada antes que `!` seja estabilizado como um tipo completo: na posição de um tipo de retorno de função.
/// Especificamente, são possíveis implementações para dois tipos diferentes de ponteiro de função:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Com o `Infallible` sendo um enum, esse código é válido.
/// No entanto, quando `Infallible` se torna um apelido para never type, os dois `impl`s começarão a se sobrepor e, portanto, não serão permitidos pelas regras de coerência trait da linguagem.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}