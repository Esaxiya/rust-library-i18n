//! Recipientes mutáveis compartilháveis.
//!
//! A segurança da memória Rust é baseada nesta regra: Dado um objeto `T`, só é possível ter um dos seguintes:
//!
//! - Ter várias referências imutáveis (`&T`) ao objeto (também conhecido como **aliasing**).
//! - Ter uma referência mutável (`&mut T`) para o objeto (também conhecido como **mutabilidade**).
//!
//! Isso é reforçado pelo compilador Rust.No entanto, existem situações em que essa regra não é flexível o suficiente.Às vezes, é necessário ter várias referências a um objeto e, ainda assim, modificá-lo.
//!
//! Os contêineres mutáveis compartilháveis existem para permitir a mutabilidade de uma maneira controlada, mesmo na presença de aliasing.Tanto o [`Cell<T>`] quanto o [`RefCell<T>`] permitem fazer isso de uma maneira de encadeamento único.
//! No entanto, nem o `Cell<T>` nem o `RefCell<T>` são thread-safe (eles não implementam o [`Sync`]).
//! Se você precisar fazer aliasing e mutação entre vários threads, é possível usar os tipos [`Mutex<T>`], [`RwLock<T>`] ou [`atomic`].
//!
//! Os valores dos tipos `Cell<T>` e `RefCell<T>` podem sofrer mutação por meio de referências compartilhadas (ou seja,
//! o tipo `&T` comum), enquanto a maioria dos tipos Rust só podem sofrer mutação por meio de referências exclusivas (`&mut T`).
//! Dizemos que o `Cell<T>` e o `RefCell<T>` fornecem 'mutabilidade interior', em contraste com os tipos Rust típicos que exibem 'mutabilidade herdada'.
//!
//! Os tipos de células vêm em dois sabores: `Cell<T>` e `RefCell<T>`.O `Cell<T>` implementa mutabilidade interior movendo valores para dentro e para fora do `Cell<T>`.
//! Para usar referências em vez de valores, deve-se usar o tipo `RefCell<T>`, adquirindo um bloqueio de gravação antes da mutação.O `Cell<T>` fornece métodos para recuperar e alterar o valor interior atual:
//!
//!  - Para tipos que implementam [`Copy`], o método [`get`](Cell::get) recupera o valor interior atual.
//!  - Para tipos que implementam [`Default`], o método [`take`](Cell::take) substitui o valor interior atual por [`Default::default()`] e retorna o valor substituído.
//!  - Para todos os tipos, o método [`replace`](Cell::replace) substitui o valor interno atual e retorna o valor substituído e o método [`into_inner`](Cell::into_inner) consome o `Cell<T>` e retorna o valor interno.
//!  Além disso, o método [`set`](Cell::set) substitui o valor interno, descartando o valor substituído.
//!
//! `RefCell<T>` usa o tempo de vida do Rust para implementar 'empréstimo dinâmico', um processo pelo qual se pode reivindicar acesso temporário, exclusivo e mutável ao valor interno.
//! Empresta para `RefCell<T>`s são rastreados 'em tempo de execução', ao contrário dos tipos de referência nativos do Rust que são inteiramente rastreados estaticamente, em tempo de compilação.
//! Como os empréstimos do `RefCell<T>` são dinâmicos, é possível tentar obter um valor que já foi mutuamente emprestado;quando isso acontece, resulta no segmento panic.
//!
//! # Quando escolher a mutabilidade interior
//!
//! A mutabilidade herdada mais comum, onde se deve ter acesso exclusivo para alterar um valor, é um dos elementos-chave da linguagem que permite ao Rust raciocinar fortemente sobre aliasing de ponteiro, impedindo estaticamente erros de travamento.
//! Por causa disso, a mutabilidade herdada é preferida, e a mutabilidade interior é o último recurso.
//! Uma vez que os tipos de células permitem a mutação onde, de outra forma, ela não seria permitida, há ocasiões em que a mutabilidade interior pode ser apropriada, ou mesmo *deve* ser usada, por exemplo
//!
//! * Apresentando a mutabilidade 'inside' de algo imutável
//! * Detalhes de implementação de métodos logicamente imutáveis.
//! * Implementações mutantes de [`Clone`].
//!
//! ## Apresentando a mutabilidade 'inside' de algo imutável
//!
//! Muitos tipos de ponteiros inteligentes compartilhados, incluindo [`Rc<T>`] e [`Arc<T>`], fornecem recipientes que podem ser clonados e compartilhados entre várias partes.
//! Como os valores contidos podem ter aliases múltiplos, eles só podem ser emprestados com o `&`, não com o `&mut`.
//! Sem células, seria impossível alterar os dados dentro desses ponteiros inteligentes.
//!
//! É muito comum colocar um `RefCell<T>` dentro de tipos de ponteiros compartilhados para reintroduzir a mutabilidade:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Crie um novo bloco para limitar o escopo do empréstimo dinâmico
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Observe que, se não tivéssemos deixado o empréstimo anterior do cache sair do escopo, o empréstimo subsequente causaria um encadeamento dinâmico panic.
//!     //
//!     // Este é o maior risco de usar o `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Observe que este exemplo usa `Rc<T>` e não `Arc<T>`.`RefCell<T>`s são para cenários de thread único.Considere o uso de [`RwLock<T>`] ou [`Mutex<T>`] se precisar de mutabilidade compartilhada em uma situação multithread.
//!
//! ## Detalhes de implementação de métodos logicamente imutáveis
//!
//! Ocasionalmente, pode ser desejável não expor em uma API que há mutação acontecendo no "under the hood".
//! Isso pode ser porque logicamente a operação é imutável, mas, por exemplo, o armazenamento em cache força a implementação a realizar a mutação;ou porque você deve empregar mutação para implementar um método trait que foi originalmente definido para tomar `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Cálculo caro vai aqui
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Implementações mutantes de `Clone`
//!
//! Este é simplesmente um caso especial, mas comum, do anterior: ocultar a mutabilidade para operações que parecem ser imutáveis.
//! Espera-se que o método [`clone`](Clone::clone) não altere o valor de origem e é declarado que aceita `&self`, não `&mut self`.
//! Portanto, qualquer mutação que ocorra no método `clone` deve usar tipos de células.
//! Por exemplo, o [`Rc<T>`] mantém suas contagens de referência em um `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Um local de memória mutável.
///
/// # Examples
///
/// Neste exemplo, você pode ver que o `Cell<T>` permite a mutação dentro de uma estrutura imutável.
/// Em outras palavras, ele habilita o "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ERROR: `my_struct` é imutável
/// // my_struct.regular_field =novo_valor;
///
/// // FUNCIONA: embora o `my_struct` seja imutável, o `special_field` é um `Cell`,
/// // que sempre pode ser mutado
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Consulte o [module-level documentation](self) para obter mais informações.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Cria um `Cell<T>`, com o valor `Default` para T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Cria um novo `Cell` contendo o valor fornecido.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Define o valor contido.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Troca os valores de duas células.
    /// A diferença com o `std::mem::swap` é que essa função não requer a referência do `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // SEGURANÇA: Isso pode ser arriscado se chamado de threads diferentes, mas `Cell`
        // é `!Sync`, então isso não vai acontecer.
        // Isso também não invalidará nenhum ponteiro, já que o `Cell` garante que nada mais estará apontando para qualquer uma dessas `Cell`s.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Substitui o valor contido por `val` e retorna o valor contido antigo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // SEGURANÇA: Isso pode causar disputas de dados se chamado de um thread separado,
        // mas `Cell` é `!Sync`, então isso não acontecerá.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Desfaz o valor.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Retorna uma cópia do valor contido.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // SEGURANÇA: Isso pode causar disputas de dados se chamado de um thread separado,
        // mas `Cell` é `!Sync`, então isso não acontecerá.
        unsafe { *self.value.get() }
    }

    /// Atualiza o valor contido usando uma função e retorna o novo valor.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Retorna um ponteiro bruto para os dados subjacentes nesta célula.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Retorna uma referência mutável aos dados subjacentes.
    ///
    /// Esta chamada toma emprestado o `Cell` mutably (em tempo de compilação), o que garante que possuímos a única referência.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Retorna um `&Cell<T>` de um `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // SEGURANÇA: `&mut` garante acesso exclusivo.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Assume o valor da célula, deixando `Default::default()` em seu lugar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Retorna um `&[Cell<T>]` de um `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // SEGURANÇA: o `Cell<T>` tem o mesmo layout de memória do `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Um local de memória mutável com regras de empréstimo verificadas dinamicamente
///
/// Consulte o [module-level documentation](self) para obter mais informações.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Um erro retornado pelo [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Um erro retornado pelo [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Os valores positivos representam o número de `Ref` ativos.Os valores negativos representam o número de `RefMut` ativos.
// Vários `RefMut`s só podem estar ativos por vez se eles se referirem a componentes distintos e não sobrepostos de um `RefCell` (por exemplo, diferentes intervalos de uma fatia).
//
// `Ref` e `RefMut` são duas palavras em tamanho e, portanto, provavelmente nunca haverá `Ref`s ou`RefMut`s existentes para estourar metade do intervalo `usize`.
// Portanto, um `BorrowFlag` provavelmente nunca irá estourar ou estourar.
// No entanto, isso não é uma garantia, pois um programa patológico pode criar repetidamente e, em seguida, `Ref`s ou`RefMut`s mem::forget.
// Assim, todo código deve verificar explicitamente o estouro e o estouro negativo para evitar a insegurança, ou pelo menos se comportar corretamente no caso de estouro ou estouro negativo (por exemplo, consulte BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Cria um novo `RefCell` contendo `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Consome o `RefCell`, retornando o valor empacotado.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Como essa função usa `self` (o `RefCell`) por valor, o compilador verifica estaticamente se ele não foi emprestado no momento.
        //
        self.value.into_inner()
    }

    /// Substitui o valor agrupado por um novo, retornando o valor antigo, sem desinicializar nenhum deles.
    ///
    ///
    /// Esta função corresponde a [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics se o valor for emprestado no momento.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Substitui o valor agrupado por um novo calculado a partir do `f`, retornando o valor antigo, sem desinicializar nenhum deles.
    ///
    ///
    /// # Panics
    ///
    /// Panics se o valor for emprestado no momento.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Troca o valor empacotado de `self` com o valor empacotado de `other`, sem desinicializar nenhum deles.
    ///
    ///
    /// Esta função corresponde a [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics se o valor em qualquer um dos `RefCell` for emprestado no momento.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Imutavelmente toma emprestado o valor empacotado.
    ///
    /// O empréstimo dura até que o `Ref` retornado saia do escopo.
    /// Vários empréstimos imutáveis podem ser feitos ao mesmo tempo.
    ///
    /// # Panics
    ///
    /// Panics se o valor for mutuamente emprestado no momento.
    /// Para uma variante sem pânico, use [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Um exemplo de panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Imutavelmente toma emprestado o valor empacotado, retornando um erro se o valor estiver mutuamente emprestado no momento.
    ///
    ///
    /// O empréstimo dura até que o `Ref` retornado saia do escopo.
    /// Vários empréstimos imutáveis podem ser feitos ao mesmo tempo.
    ///
    /// Esta é a variante sem pânico do [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // SEGURANÇA: `BorrowRef` garante que haja apenas acesso imutável
            // ao valor durante o empréstimo.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Solicita mutuamente o valor empacotado.
    ///
    /// O empréstimo dura até que o `RefMut` retornado ou todos os `RefMut`s derivados dele saiam do escopo.
    ///
    /// O valor não pode ser emprestado enquanto este empréstimo estiver ativo.
    ///
    /// # Panics
    ///
    /// Panics se o valor for emprestado no momento.
    /// Para uma variante sem pânico, use [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Um exemplo de panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Empresta mutuamente o valor empacotado, retornando um erro se o valor for emprestado no momento.
    ///
    ///
    /// O empréstimo dura até que o `RefMut` retornado ou todos os `RefMut`s derivados dele saiam do escopo.
    /// O valor não pode ser emprestado enquanto este empréstimo estiver ativo.
    ///
    /// Esta é a variante sem pânico do [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // SEGURANÇA: `BorrowRef` garante acesso exclusivo.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Retorna um ponteiro bruto para os dados subjacentes nesta célula.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Retorna uma referência mutável aos dados subjacentes.
    ///
    /// Essa chamada toma emprestado o `RefCell` mutably (em tempo de compilação), portanto, não há necessidade de verificações dinâmicas.
    ///
    /// No entanto, tenha cuidado: este método espera que o `self` seja mutável, o que geralmente não é o caso ao usar um `RefCell`.
    ///
    /// Em vez disso, dê uma olhada no método [`borrow_mut`] se o `self` não for mutável.
    ///
    /// Além disso, esteja ciente de que esse método é apenas para circunstâncias especiais e geralmente não é o que você deseja.
    /// Em caso de dúvida, use o [`borrow_mut`].
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Desfaça o efeito do vazamento de proteções no estado de empréstimo do `RefCell`.
    ///
    /// Essa chamada é semelhante ao [`get_mut`], mas mais especializada.
    /// Ele toma emprestado o `RefCell` mutably para garantir que não existam empréstimos e, em seguida, redefine os empréstimos compartilhados de rastreamento de estado.
    /// Isso é relevante se algum empréstimo de `Ref` ou `RefMut` vazar.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Imutavelmente toma emprestado o valor empacotado, retornando um erro se o valor estiver mutuamente emprestado no momento.
    ///
    /// # Safety
    ///
    /// Ao contrário do `RefCell::borrow`, este método não é seguro porque não retorna um `Ref`, deixando assim o sinalizador de empréstimo intocado.
    /// Tomar emprestado mutuamente o `RefCell` enquanto a referência retornada por esse método está ativa é um comportamento indefinido.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // SEGURANÇA: Verificamos se ninguém está escrevendo ativamente agora, mas está
            // responsabilidade do chamador de garantir que ninguém escreva até que a referência retornada não esteja mais em uso.
            // Além disso, `self.value.get()` se refere ao valor pertencente ao `self` e, portanto, é garantido como válido durante toda a vida útil do `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Assume o valor agrupado, deixando o `Default::default()` em seu lugar.
    ///
    /// # Panics
    ///
    /// Panics se o valor for emprestado no momento.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics se o valor for mutuamente emprestado no momento.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Cria um `RefCell<T>`, com o valor `Default` para T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics se o valor em qualquer um dos `RefCell` for emprestado no momento.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics se o valor em qualquer um dos `RefCell` for emprestado no momento.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics se o valor em qualquer um dos `RefCell` for emprestado no momento.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics se o valor em qualquer um dos `RefCell` for emprestado no momento.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics se o valor em qualquer um dos `RefCell` for emprestado no momento.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics se o valor em qualquer um dos `RefCell` for emprestado no momento.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics se o valor em qualquer um dos `RefCell` for emprestado no momento.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Incrementar o empréstimo pode resultar em um valor de não leitura (<=0) nestes casos:
            // 1. Era <0, ou seja, há empréstimos de escrita, então não podemos permitir um empréstimo de leitura devido às regras de alias de referência de Rust
            // 2.
            // Era isize::MAX (a quantidade máxima de empréstimos de leitura) e transbordou para isize::MIN (a quantidade máxima de empréstimos de escrita), então não podemos permitir um empréstimo de leitura adicional porque isize não pode representar tantos empréstimos de leitura (isso só pode acontecer se você mem::forget mais do que uma pequena quantidade constante de `Ref`s, o que não é uma boa prática)
            //
            //
            //
            //
            None
        } else {
            // Incrementar o empréstimo pode resultar em um valor de leitura (> 0) nestes casos:
            // 1. Era=0, ou seja, não foi emprestado e estamos pegando emprestado a primeira leitura
            // 2. Era> 0 e <isize::MAX, ou seja
            // foram lidas emprestadas, e isize é grande o suficiente para representar ter mais uma leitura emprestada
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Uma vez que este Ref existe, sabemos que o sinalizador de empréstimo é um empréstimo de leitura.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Evite que o contador de empréstimos transborde em um empréstimo escrito.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Envolve uma referência emprestada a um valor em uma caixa `RefCell`.
/// Um tipo de invólucro para um valor imutavelmente emprestado de um `RefCell<T>`.
///
/// Consulte o [module-level documentation](self) para obter mais informações.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Copia um `Ref`.
    ///
    /// O `RefCell` já foi imutavelmente emprestado, portanto, isso não pode falhar.
    ///
    /// Esta é uma função associada que precisa ser usada como `Ref::clone(...)`.
    /// Uma implementação ou método do `Clone` interfere no uso generalizado do `r.borrow().clone()` para clonar o conteúdo de um `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Cria um novo `Ref` para um componente dos dados emprestados.
    ///
    /// O `RefCell` já foi imutavelmente emprestado, portanto, isso não pode falhar.
    ///
    /// Esta é uma função associada que deve ser usada como `Ref::map(...)`.
    /// Um método interfere nos métodos de mesmo nome no conteúdo de um `RefCell` usado por meio do `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Cria um novo `Ref` para um componente opcional dos dados emprestados.
    /// A proteção original é retornada como um `Err(..)` se o fechamento retornar `None`.
    ///
    /// O `RefCell` já foi imutavelmente emprestado, portanto, isso não pode falhar.
    ///
    /// Esta é uma função associada que deve ser usada como `Ref::filter_map(...)`.
    /// Um método interfere nos métodos de mesmo nome no conteúdo de um `RefCell` usado por meio do `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Divide um `Ref` em vários `Ref`s para diferentes componentes dos dados emprestados.
    ///
    /// O `RefCell` já foi imutavelmente emprestado, portanto, isso não pode falhar.
    ///
    /// Esta é uma função associada que deve ser usada como `Ref::map_split(...)`.
    /// Um método interfere nos métodos de mesmo nome no conteúdo de um `RefCell` usado por meio do `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Converta em uma referência aos dados subjacentes.
    ///
    /// O `RefCell` subjacente nunca pode ser mutuamente emprestado novamente e sempre aparecerá imutavelmente emprestado.
    ///
    /// Não é uma boa ideia vazar mais do que um número constante de referências.
    /// O `RefCell` pode ser imutavelmente emprestado novamente se apenas um número menor de vazamentos tiver ocorrido no total.
    ///
    /// Esta é uma função associada que precisa ser usada como `Ref::leak(...)`.
    /// Um método interfere nos métodos de mesmo nome no conteúdo de um `RefCell` usado por meio do `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Ao esquecer esta Ref, garantimos que o contador de empréstimos no RefCell não pode voltar a NÃO UTILIZADO durante a vida útil do `'b`.
        // A redefinição do estado de rastreamento de referência exigiria uma referência exclusiva para o RefCell emprestado.
        // Nenhuma outra referência mutável pode ser criada a partir da célula original.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Cria um novo `RefMut` para um componente dos dados emprestados, por exemplo, uma variante de enum.
    ///
    /// O `RefCell` já foi mutuamente emprestado, portanto, isso não pode falhar.
    ///
    /// Esta é uma função associada que deve ser usada como `RefMut::map(...)`.
    /// Um método interfere nos métodos de mesmo nome no conteúdo de um `RefCell` usado por meio do `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): consertar cheque emprestado
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Cria um novo `RefMut` para um componente opcional dos dados emprestados.
    /// A proteção original é retornada como um `Err(..)` se o fechamento retornar `None`.
    ///
    /// O `RefCell` já foi mutuamente emprestado, portanto, isso não pode falhar.
    ///
    /// Esta é uma função associada que deve ser usada como `RefMut::filter_map(...)`.
    /// Um método interfere nos métodos de mesmo nome no conteúdo de um `RefCell` usado por meio do `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): consertar cheque emprestado
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // SEGURANÇA: a função mantém uma referência exclusiva para a duração
        // de sua chamada por meio do `orig`, e o ponteiro é referenciado apenas dentro da chamada de função, nunca permitindo que a referência exclusiva escape.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // SEGURANÇA: igual ao anterior.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Divide um `RefMut` em vários `RefMut`s para diferentes componentes dos dados emprestados.
    ///
    /// O `RefCell` subjacente permanecerá mutuamente emprestado até que ambos os `RefMut`s retornados saiam do escopo.
    ///
    /// O `RefCell` já foi mutuamente emprestado, portanto, isso não pode falhar.
    ///
    /// Esta é uma função associada que deve ser usada como `RefMut::map_split(...)`.
    /// Um método interfere nos métodos de mesmo nome no conteúdo de um `RefCell` usado por meio do `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Converta em uma referência mutável para os dados subjacentes.
    ///
    /// O `RefCell` subjacente não pode ser emprestado novamente e sempre aparecerá mutably emprestado, tornando a referência retornada apenas para o interior.
    ///
    ///
    /// Esta é uma função associada que deve ser usada como `RefMut::leak(...)`.
    /// Um método interfere nos métodos de mesmo nome no conteúdo de um `RefCell` usado por meio do `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Ao esquecer este BorrowRefMut, garantimos que o contador de empréstimos no RefCell não pode voltar a NÃO UTILIZADO durante a vida útil do `'b`.
        // A redefinição do estado de rastreamento de referência exigiria uma referência exclusiva para o RefCell emprestado.
        // Nenhuma outra referência pode ser criada a partir da célula original dentro desse tempo de vida, tornando o empréstimo atual a única referência para o tempo de vida restante.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Ao contrário do BorrowRefMut::clone, new é chamado para criar o inicial
        // referência mutável e, portanto, não deve haver nenhuma referência existente.
        // Assim, enquanto o clone incrementa o refcount mutável, aqui explicitamente permitimos apenas ir de NÃO USADO para NÃO USADO, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Clona um `BorrowRefMut`.
    //
    // Isso só é válido se cada `BorrowRefMut` for usado para rastrear uma referência mutável a um intervalo distinto e não sobreposto do objeto original.
    //
    // Isso não está em um implemento clone, de modo que o código não o chama implicitamente.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Evite que o contador de empréstimos não chegue.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Um tipo de invólucro para um valor mutably emprestado de um `RefCell<T>`.
///
/// Consulte o [module-level documentation](self) para obter mais informações.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// O núcleo primitivo para mutabilidade interior em Rust.
///
/// Se você tiver uma referência `&T`, normalmente em Rust o compilador realiza otimizações com base no conhecimento de que `&T` aponta para dados imutáveis.A mutação desses dados, por exemplo, por meio de um alias ou pela transmutação de um `&T` em um `&mut T`, é considerado um comportamento indefinido.
/// `UnsafeCell<T>` desativa a garantia de imutabilidade para `&T`: uma referência compartilhada `&UnsafeCell<T>` pode apontar para dados que estão sendo alterados.Isso é chamado de "interior mutability".
///
/// Todos os outros tipos que permitem mutabilidade interna, como `Cell<T>` e `RefCell<T>`, usam `UnsafeCell` internamente para agrupar seus dados.
///
/// Observe que apenas a garantia de imutabilidade para referências compartilhadas é afetada pelo `UnsafeCell`.A garantia de exclusividade para referências mutáveis não é afetada.Não há *nenhuma* maneira legal de obter aliasing `&mut`, nem mesmo com `UnsafeCell<T>`.
///
/// A API do `UnsafeCell` em si é tecnicamente muito simples: o [`.get()`] fornece um ponteiro `*mut T` bruto para seu conteúdo.Depende do _you_ como designer de abstração usar esse ponteiro bruto corretamente.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// As regras de aliasing Rust precisas estão um tanto em fluxo, mas os pontos principais não são controversos:
///
/// - Se você criar uma referência segura com `'a` vitalício (uma referência `&T` ou `&mut T`) que seja acessível por código seguro (por exemplo, porque você o retornou), você não deve acessar os dados de qualquer forma que contradiga essa referência para o restante de `'a`.
/// Por exemplo, isso significa que se você pegar o `*mut T` de um `UnsafeCell<T>` e convertê-lo em um `&T`, os dados no `T` devem permanecer imutáveis (módulo de quaisquer dados `UnsafeCell` encontrados no `T`, é claro) até que a vida útil dessa referência expire.
/// Da mesma forma, se você criar uma referência `&mut T` liberada para um código seguro, não deverá acessar os dados no `UnsafeCell` até que essa referência expire.
///
/// - Em todos os momentos, você deve evitar disputas de dados.Se vários encadeamentos tiverem acesso ao mesmo `UnsafeCell`, então qualquer gravação deve ter uma relação acontece-antes adequada com todos os outros acessos (ou usar atomics).
///
/// Para ajudar no design adequado, os seguintes cenários são explicitamente declarados legais para código de thread único:
///
/// 1. Uma referência `&T` pode ser liberada para um código seguro e lá pode coexistir com outras referências `&T`, mas não com um `&mut T`
///
/// 2. Uma referência `&mut T` pode ser liberada para um código seguro, desde que nenhum outro `&mut T` ou `&T` coexista com ela.Um `&mut T` deve ser sempre exclusivo.
///
/// Observe que, embora a mutação do conteúdo de um `&UnsafeCell<T>` (mesmo enquanto outras referências `&UnsafeCell<T>` apelidam da célula) estiver ok (desde que você imponha as invariáveis acima de outra maneira), ainda é um comportamento indefinido ter vários apelidos `&mut UnsafeCell<T>`.
/// Ou seja, o `UnsafeCell` é um wrapper projetado para ter uma interação especial com o _shared_ accesses (_i.e._, por meio de uma referência `&UnsafeCell<_>`);não há mágica alguma ao lidar com _exclusive_ accesses (_e.g._, por meio de um `&mut UnsafeCell<_>`): nem a célula nem o valor encapsulado podem ter um alias durante o empréstimo do `&mut`.
///
/// Isso é mostrado pelo acessador [`.get_mut()`], que é um _safe_ getter que produz um `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Aqui está um exemplo que mostra como alterar profundamente o conteúdo de um `UnsafeCell<_>`, apesar de haver várias referências criando um alias na célula:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Obtenha referências múltiplas/simultâneas/compartilhadas para o mesmo `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // SEGURANÇA: dentro deste escopo não há outras referências ao conteúdo de `x`,
///     // então o nosso é efetivamente único.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- emprestar-+
///     *p1_exclusive += 27; // |
/// } // <---------- não pode ir além deste ponto -------------------+
///
/// unsafe {
///     // SEGURANÇA: dentro deste escopo ninguém espera ter acesso exclusivo ao conteúdo de `x`,
///     // para que possamos ter vários acessos compartilhados simultaneamente.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// O exemplo a seguir mostra o fato de que o acesso exclusivo a um `UnsafeCell<T>` implica acesso exclusivo a seu `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // com acessos exclusivos,
///                         // `UnsafeCell` é um invólucro não operacional transparente, portanto, não há necessidade de `unsafe` aqui.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Obtenha uma referência exclusiva verificada no tempo de compilação para o `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Com uma referência exclusiva, podemos alterar o conteúdo gratuitamente.
/// *p_unique.get_mut() = 0;
/// // Ou equivalente:
/// x = UnsafeCell::new(0);
///
/// // Quando possuímos o valor, podemos extrair o conteúdo gratuitamente.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Constrói uma nova instância de `UnsafeCell` que envolverá o valor especificado.
    ///
    ///
    /// Todo acesso ao valor interno por meio de métodos é `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Desfaz o valor.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Obtém um ponteiro mutável para o valor empacotado.
    ///
    /// Isso pode ser convertido para um ponteiro de qualquer tipo.
    /// Certifique-se de que o acesso seja exclusivo (sem referências ativas, mutáveis ou não) ao transmitir para o `&mut T` e certifique-se de que não haja mutações ou aliases mutáveis ocorrendo durante a transmissão para o `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Podemos apenas lançar o ponteiro de `UnsafeCell<T>` para `T` por causa do #[repr(transparent)].
        // Isso explora o status especial da libstd, não há garantia para o código do usuário de que funcionará nas versões future do compilador!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Retorna uma referência mutável aos dados subjacentes.
    ///
    /// Esta chamada toma emprestado o `UnsafeCell` mutably (em tempo de compilação), o que garante que possuímos a única referência.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Obtém um ponteiro mutável para o valor empacotado.
    /// A diferença com o [`get`] é que esta função aceita um ponteiro bruto, o que é útil para evitar a criação de referências temporárias.
    ///
    /// O resultado pode ser lançado em um ponteiro de qualquer tipo.
    /// Certifique-se de que o acesso seja exclusivo (sem referências ativas, mutáveis ou não) ao transmitir para o `&mut T` e certifique-se de que não haja mutações ou aliases mutáveis ocorrendo durante a transmissão para o `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// A inicialização gradual de um `UnsafeCell` requer `raw_get`, pois chamar `get` exigiria a criação de uma referência para dados não inicializados:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Podemos apenas lançar o ponteiro de `UnsafeCell<T>` para `T` por causa do #[repr(transparent)].
        // Isso explora o status especial da libstd, não há garantia para o código do usuário de que funcionará nas versões future do compilador!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Cria um `UnsafeCell`, com o valor `Default` para T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}