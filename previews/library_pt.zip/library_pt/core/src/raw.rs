#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Contém definições de estrutura para o layout de tipos internos do compilador.
//!
//! Eles podem ser usados como alvos de transmutação em código inseguro para manipular as representações brutas diretamente.
//!
//!
//! Sua definição deve sempre corresponder à ABI definida no `rustc_middle::ty::layout`.
//!

/// A representação de um objeto trait como `&dyn SomeTrait`.
///
/// Essa estrutura tem o mesmo layout de tipos como `&dyn SomeTrait` e `Box<dyn AnotherTrait>`.
///
/// `TraitObject` é garantido para combinar layouts, mas não é o tipo de objeto trait (por exemplo, os campos não são diretamente acessíveis em um `&dyn SomeTrait`) nem controla esse layout (alterar a definição não mudará o layout de um `&dyn SomeTrait`).
///
/// Ele foi projetado para ser usado apenas por código inseguro que precisa manipular os detalhes de baixo nível.
///
/// Não há como se referir a todos os objetos trait genericamente, então a única maneira de criar valores desse tipo é com funções como [`std::mem::transmute`][transmute].
/// Da mesma forma, a única maneira de criar um objeto trait verdadeiro a partir de um valor `TraitObject` é com `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Sintetizar um objeto trait com tipos incompatíveis-aquele em que vtable não corresponde ao tipo de valor para o qual o ponteiro de dados aponta-é altamente provável que leve a um comportamento indefinido.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // um exemplo trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // deixe o compilador fazer um objeto trait
/// let object: &dyn Foo = &value;
///
/// // olhe para a representação bruta
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // o ponteiro de dados é o endereço de `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // construir um novo objeto, apontando para um `i32` diferente, tendo o cuidado de usar o `i32` vtable do `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // deve funcionar como se tivéssemos construído um objeto trait diretamente do `other_value`
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}