//! Tradução Rust quase direta (mas ligeiramente otimizada) da Figura 3 de "Impressão de números de ponto flutuante com rapidez e precisão" [^ 1].
//!
//!
//! [^1]: Burger, RG e Dybvig, RK 1996. Impressão de números de ponto flutuante
//!   com rapidez e precisão.SIGPLAN Não.31, 5 (maio de 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// matrizes pré-calculadas de `dígitos` para 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// utilizável apenas quando `x < 16 * scale`;`scaleN` deve ser `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// A implementação de modo mais curta para Dragon.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // o número `v` a formatar é conhecido por ser:
    // - igual a `mant * 2^exp`;
    // - precedido por `(mant - 2 *minus)* 2^exp` no tipo original;e
    // - seguido por `(mant + 2 *plus)* 2^exp` no tipo original.
    //
    // obviamente, `minus` e `plus` não podem ser zero.(para infinitos, usamos valores fora do intervalo.) também assumimos que pelo menos um dígito é gerado, ou seja, `mant` não pode ser zero também.
    //
    // isso também significa que qualquer número entre `low = (mant - minus)*2^exp` e `high = (mant + plus)* 2^exp` será mapeado para esse número de ponto flutuante exato, com limites incluídos quando a mantissa original era par (ou seja, `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` é `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // estimar o `k_0` a partir de entradas originais que satisfaçam o `10^(k_0-1) < high <= 10^(k_0+1)`.
    // o `k` estreito que satisfaz o `10^(k-1) < high <= 10^k` é calculado posteriormente.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // converter `{mant, plus, minus} * 2^exp` na forma fracionária para que:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // divida `mant` por `10^k`.agora `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // correção quando `mant + plus > scale` (ou `>=`).
    // não estamos realmente modificando o `scale`, já que podemos pular a multiplicação inicial.
    // agora `scale < mant + plus <= scale * 10` e estamos prontos para gerar dígitos.
    //
    // observe que `d[0]`*pode* ser zero, quando `scale - plus < mant < scale`.
    // neste caso, a condição de arredondamento (`up` abaixo) será acionada imediatamente.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // equivalente a dimensionar `scale` em 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // cache `(2, 4, 8) * scale` para geração de dígitos.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // invariantes, onde `d[0..n-1]` são dígitos gerados até agora:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (portanto, `mant / scale < 10`) onde `d[i..j]` é uma abreviação para `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // gerar um dígito: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // esta é uma descrição simplificada do algoritmo Dragon modificado.
        // muitas derivações intermediárias e argumentos de integridade são omitidos por conveniência.
        //
        // comece com invariantes modificados, conforme atualizamos o `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // presuma que `d[0..n-1]` é a representação mais curta entre `low` e `high`, ou seja, `d[0..n-1]` satisfaz ambos os seguintes, mas `d[0..n-2]` não:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijetividade: dígitos arredondados para `v`);e
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (o último dígito está correto).
        //
        // a segunda condição simplifica para `2 * mant <= scale`.
        // resolver invariantes em termos de `mant`, `low` e `high` resulta em uma versão mais simples da primeira condição: `-plus < mant < minus`.
        // desde `-plus < 0 <= mant`, temos a representação mais curta correta quando `mant < minus` e `2 * mant <= scale`.
        // (o primeiro torna-se `mant <= minus` quando a mantissa original é par.)
        //
        // quando o segundo não se sustenta (`2 * mant> scale`), precisamos aumentar o último dígito.
        // isso é suficiente para restaurar essa condição: já sabemos que a geração de dígitos garante `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // neste caso, a primeira condição se torna `-plus < mant - scale < minus`.
        // desde `mant < scale` após a geração, temos `scale < mant + plus`.
        // (novamente, torna-se `scale <= mant + plus` quando a mantissa original é par.)
        //
        // resumidamente:
        // - parar e arredondar `down` (manter os dígitos como estão) quando `mant < minus` (ou `<=`).
        // - pare e arredonde `up` (aumentar o último dígito) quando `scale < mant + plus` (ou `<=`).
        // - continue gerando de outra forma.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // temos a representação mais curta, prossiga para o arredondamento

        // restaurar os invariantes.
        // isso faz com que o algoritmo sempre termine: `minus` e `plus` sempre aumentam, mas `mant` é módulo recortado `scale` e `scale` é corrigido.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // o arredondamento acontece quando i) apenas a condição de arredondamento foi acionada, ou ii) ambas as condições foram acionadas e o desempate prefere o arredondamento.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // se o arredondamento mudar o comprimento, o expoente também deve mudar.
        // parece que essa condição é muito difícil de satisfazer (possivelmente impossível), mas estamos apenas sendo seguros e consistentes aqui.
        //
        // SEGURANÇA: inicializamos essa memória acima.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // SEGURANÇA: inicializamos essa memória acima.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// A implementação de modo exato e fixo para Dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // estimar o `k_0` a partir de entradas originais que satisfaçam o `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // divida `mant` por `10^k`.agora `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // correção quando `mant + plus >= scale`, onde `plus / scale = 10^-buf.len() / 2`.
    // para manter o bignum de tamanho fixo, usamos o `mant + floor(plus) >= scale`.
    // não estamos realmente modificando o `scale`, já que podemos pular a multiplicação inicial.
    // novamente com o algoritmo mais curto, `d[0]` pode ser zero, mas será eventualmente arredondado.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // equivalente a dimensionar `scale` em 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // se estivermos trabalhando com a limitação do último dígito, precisamos encurtar o buffer antes da renderização real para evitar o arredondamento duplo.
    //
    // note que temos que aumentar o buffer novamente quando o arredondamento acontecer!
    let mut len = if k < limit {
        // opa, não podemos nem mesmo produzir *um* dígito.
        // isso é possível quando, digamos, temos algo como 9.5 e ele está sendo arredondado para 10.
        // retornamos um buffer vazio, com exceção do último caso de arredondamento que ocorre quando `k == limit` e tem que produzir exatamente um dígito.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // cache `(2, 4, 8) * scale` para geração de dígitos.
        // (isso pode ser caro, então não os calcule quando o buffer estiver vazio.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // os dígitos seguintes são todos zeros, paramos aqui,*não* tente fazer o arredondamento!em vez disso, preencha os dígitos restantes.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // SEGURANÇA: inicializamos essa memória acima.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // arredondando para cima se pararmos no meio dos dígitos se os dígitos seguintes forem exatamente 5000 ..., verifique o dígito anterior e tente arredondar para par (ou seja, evite arredondar para cima quando o dígito anterior for par).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // SEGURANÇA: `buf[len-1]` é inicializado.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // se o arredondamento mudar o comprimento, o expoente também deve mudar.
        // mas nos foi solicitado um número fixo de dígitos, então não altere o buffer ...
        // SEGURANÇA: inicializamos essa memória acima.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... a menos que tenhamos solicitado a precisão fixa.
            // também precisamos verificar se, se o buffer original estava vazio, o dígito adicional só pode ser adicionado quando `k == limit` (caso edge).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // SEGURANÇA: inicializamos essa memória acima.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}