//! Decodifica um valor de ponto flutuante em partes individuais e intervalos de erro.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Valor finito sem sinal decodificado, tal que:
///
/// - O valor original é igual a `mant * 2^exp`.
///
/// - Qualquer número de `(mant - minus)*2^exp` a `(mant + plus)* 2^exp` será arredondado para o valor original.
/// O intervalo é inclusivo apenas quando `inclusive` é `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// A mantissa escalada.
    pub mant: u64,
    /// O intervalo de erro inferior.
    pub minus: u64,
    /// A faixa de erro superior.
    pub plus: u64,
    /// O expoente compartilhado na base 2.
    pub exp: i16,
    /// Verdadeiro quando o intervalo de erro é inclusivo.
    ///
    /// No IEEE 754, isso é verdade quando a mantissa original era uniforme.
    pub inclusive: bool,
}

/// Valor sem sinal decodificado.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infinidades, positivas ou negativas.
    Infinite,
    /// Zero, positivo ou negativo.
    Zero,
    /// Números finitos com outros campos decodificados.
    Finite(Decoded),
}

/// Um tipo de ponto flutuante que pode ser `decodificar`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// O valor normalizado positivo mínimo.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Retorna um sinal (verdadeiro quando negativo) e um valor `FullDecoded` de um determinado número de ponto flutuante.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // vizinhos: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode sempre preserva o expoente, então a mantissa é dimensionada para subnormais.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // vizinhos: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // onde maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // vizinhos: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}