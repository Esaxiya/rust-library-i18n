//! Os vários algoritmos do papel.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Número de bits de significando em Fp
const P: u32 = 64;

// Simplesmente armazenamos a melhor aproximação para *todos* os expoentes, de forma que a variável "h" e as condições associadas possam ser omitidas.
// Isso troca desempenho por alguns kilobytes de espaço.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Na maioria das arquiteturas, as operações de ponto flutuante têm um tamanho de bit explícito, portanto, a precisão do cálculo é determinada por operação.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// No x86, o x87 FPU é usado para operações flutuantes se as extensões SSE/SSE2 não estiverem disponíveis.
// O x87 FPU opera com 80 bits de precisão por padrão, o que significa que as operações serão arredondadas para 80 bits, causando o arredondamento duplo quando os valores forem eventualmente representados como
//
// 32/64 valores flutuantes de bits.Para superar isso, a palavra de controle da FPU pode ser definida de forma que os cálculos sejam realizados com a precisão desejada.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Uma estrutura usada para preservar o valor original da palavra de controle da FPU, para que possa ser restaurada quando a estrutura for eliminada.
    ///
    ///
    /// O x87 FPU é um registro de 16 bits cujos campos são os seguintes:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// A documentação para todos os campos está disponível no Manual do desenvolvedor de software do IA-32 Architectures (Volume 1).
    ///
    /// O único campo relevante para o código a seguir é PC, Controle de precisão.
    /// Este campo determina a precisão das operações realizadas pela FPU.
    /// Pode ser definido para:
    ///  - 0b00, precisão simples, ou seja, 32 bits
    ///  - 0b10, precisão dupla, ou seja, 64 bits
    ///  - 0b11, precisão estendida dupla, ou seja, 80 bits (estado padrão) O valor 0b01 é reservado e não deve ser usado.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // SEGURANÇA: a instrução `fldcw` foi auditada para funcionar corretamente com
        // qualquer `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Estamos usando a sintaxe ATT para dar suporte ao LLVM 8 e ao LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Define o campo de precisão da FPU para `T` e retorna um `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Calcule o valor do campo Controle de precisão apropriado para `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bits
            8 => 0x0200, // 64 bits
            _ => 0x0300, // padrão, 80 bits
        };

        // Obtenha o valor original da palavra de controle para restaurá-lo mais tarde, quando a estrutura `FPUControlWord` for descartada SEGURANÇA: a instrução `fnstcw` foi auditada para poder funcionar corretamente com qualquer `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Estamos usando a sintaxe ATT para dar suporte ao LLVM 8 e ao LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Defina a palavra de controle com a precisão desejada.
        // Isso é obtido mascarando a antiga precisão (bits 8 e 9, 0x300) e substituindo-a pelo sinalizador de precisão calculado acima.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// O caminho rápido de Bellerophon usando números inteiros e flutuantes do tamanho de uma máquina.
///
/// Isso é extraído em uma função separada para que possa ser tentado antes de construir um bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Comparamos o valor exato com MAX_SIG próximo ao final, isso é apenas uma rejeição rápida e barata (e também livra o resto do código de se preocupar com o estouro negativo).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // O caminho rápido depende crucialmente de a aritmética ser arredondada para o número correto de bits sem nenhum arredondamento intermediário.
    // No x86 (sem SSE ou SSE2), isso requer que a precisão da pilha FPU x87 seja alterada para que seja arredondada diretamente para o bit 64/32.
    // A função do `set_precision` se encarrega de definir a precisão nas arquiteturas que requerem configuração, alterando o estado global (como a palavra de controle do FPU x87).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // O caso e <0 não pode ser dobrado no outro branch.
    // Potências negativas resultam em uma parte fracionária repetida em binário, que é arredondada, o que causa erros reais (e ocasionalmente bastante significativos!) No resultado final.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// O algoritmo Bellerophon é um código trivial justificado por uma análise numérica não trivial.
///
/// Ele arredonda ``f`` para um ponto flutuante com significando de 64 bits e o multiplica pela melhor aproximação de `10^e` (no mesmo formato de ponto flutuante).Geralmente, isso é suficiente para obter o resultado correto.
/// No entanto, quando o resultado está perto da metade do caminho entre dois flutuadores (ordinary) adjacentes, o erro de arredondamento composto da multiplicação de duas aproximações significa que o resultado pode estar errado por alguns bits.
/// Quando isso acontece, o Algoritmo R iterativo conserta as coisas.
///
/// O "close to halfway" ondulado à mão torna-se preciso pela análise numérica do papel.
/// Nas palavras de Clinger:
///
/// > Slop, expresso em unidades do bit menos significativo, é um limite inclusivo para o erro
/// > acumulado durante o cálculo de ponto flutuante da aproximação para f * 10 ^ e.(Slop é
/// > não um limite para o erro verdadeiro, mas limita a diferença entre a aproximação z e
/// > a melhor aproximação possível que usa p bits de significando.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // As caixas abs(e) <log5(2^N) estão em fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // O slop é grande o suficiente para fazer diferença ao arredondar para n bits?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Um algoritmo iterativo que melhora uma aproximação de ponto flutuante de `f * 10^e`.
///
/// Cada iteração deixa uma unidade no último lugar mais próxima, o que obviamente leva muito tempo para convergir se o `z0` estiver ligeiramente desligado.
/// Felizmente, quando usado como substituto para Belerofonte, a aproximação inicial está errada em no máximo um ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Encontre números inteiros positivos `x`, `y` de forma que `x / y` seja exatamente `(f *10^e) / (m* 2^k)`.
        // Isso não apenas evita lidar com os sinais do `e` e `k`, mas também eliminamos o poder de dois comuns ao `10^e` e `2^k` para tornar os números menores.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Isso foi escrito de maneira um pouco estranha porque nossos bignums não suportam números negativos, então usamos o valor absoluto + informação do sinal.
        // A multiplicação com m_digits não pode transbordar.
        // Se `x` ou `y` forem grandes o suficiente para que precisemos nos preocupar com estouro, eles também serão grandes o suficiente para que o `make_ratio` tenha reduzido a fração por um fator de 2 ^ 64 ou mais.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Não precisa mais de x, salve um clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Ainda preciso de você, faça uma cópia.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Dados `x = f` e `y = m` onde `f` representam dígitos decimais de entrada como de costume e `m` é o significando de uma aproximação de ponto flutuante, faça a proporção `x / y` igual a `(f *10^e) / (m* 2^k)`, possivelmente reduzida por uma potência de dois que ambos têm em comum.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, exceto que reduzimos a fração por alguma potência de dois.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Isso não pode estourar porque requer `e` positivo e `k` negativo, o que só pode acontecer para valores extremamente próximos a 1, o que significa que `e` e `k` serão comparativamente pequenos.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Também não pode transbordar, veja acima.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), novamente reduzindo por uma potência comum de dois.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Conceitualmente, o Algoritmo M é a maneira mais simples de converter um decimal em um float.
///
/// Formamos uma proporção igual a `f * 10^e` e, em seguida, adicionamos potências de dois até que forneça um significando de float válido.
/// O expoente binário `k` é o número de vezes que multiplicamos o numerador ou denominador por dois, ou seja, sempre que `f *10^e` é igual a `(u / v)* 2^k`.
/// Quando descobrimos o significando, precisamos apenas arredondar inspecionando o restante da divisão, o que é feito nas funções auxiliares mais adiante.
///
///
/// Este algoritmo é super lento, mesmo com a otimização descrita no `quick_start()`.
/// No entanto, é o mais simples dos algoritmos para se adaptar a resultados de estouro, estouro negativo e subnormais.
/// Esta implementação assume quando Belerofonte e Algoritmo R são sobrecarregados.
/// Detectar underflow e overflow é fácil: a proporção ainda não é um significando dentro da faixa, mas o expoente minimum/maximum foi alcançado.
/// No caso de estouro, simplesmente retornamos o infinito.
///
/// Lidar com underflow e subnormais é mais complicado.
/// Um grande problema é que, com o expoente mínimo, a proporção ainda pode ser muito grande para um significando.
/// Consulte underflow() para obter detalhes.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // Otimização FIXME possível: generalize big_to_fp para que possamos fazer o equivalente a fp_to_float(big_to_fp(u)) aqui, mas sem o duplo arredondamento.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Temos que parar no expoente mínimo, se esperarmos até `k < T::MIN_EXP_INT`, então estaremos errados por um fator de dois.
            // Infelizmente, isso significa que temos que colocar números normais em letras maiúsculas e minúsculas.
            // FIXME encontre uma formulação mais elegante, mas execute o teste `tiny-pow10` para se certificar de que está realmente correta!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Ignora a maioria das iterações do algoritmo M verificando o comprimento do bit.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // O comprimento do bit é uma estimativa do logaritmo de base dois e log(u / v) = log(u), log(v).
    // A estimativa está errada em no máximo 1, mas sempre uma subestimativa, portanto, os erros no log(u) e no log(v) são do mesmo sinal e se cancelam (se ambos forem grandes).
    // Portanto, o erro para o log(u / v) é no máximo um também.
    // A taxa de destino é aquela em que u/v está em um significando dentro do intervalo.Portanto, nossa condição de terminação é log2(u / v) sendo os bits significativos, plus/minus um.
    // FIXME Olhar para o segundo bit pode melhorar a estimativa e evitar mais algumas divisões.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Underflow ou subnormal.Deixe para a função principal.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Transbordar.Deixe para a função principal.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // A proporção não é um significando dentro do intervalo com o expoente mínimo, portanto, precisamos arredondar os bits em excesso e ajustar o expoente de acordo.
    // O valor real agora se parece com este:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(representado por rem)
    //
    // Portanto, quando os bits arredondados são!= 0.5 ULP, eles decidem o arredondamento por conta própria.
    // Quando eles são iguais e o restante é diferente de zero, o valor ainda precisa ser arredondado.
    // Somente quando os bits arredondados são 1/2 e o restante é zero, temos uma situação de meio para igual.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Rodar para igual comum, ofuscado por ter de arredondar com base no restante de uma divisão.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}