//! Um pouco mexendo em flutuadores IEEE 754 positivos.Números negativos não são e não precisam ser tratados.
//! Os números de ponto flutuante normais têm uma representação canônica como (frac, exp) de forma que o valor seja 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) onde N é o número de bits.
//!
//! Subnormais são ligeiramente diferentes e estranhos, mas o mesmo princípio se aplica.
//!
//! Aqui, no entanto, nós os representamos como (sig, k) com f positivo, de modo que o valor é f *
//! 2 <sup>e</sup> .Além de tornar o "hidden bit" explícito, isso altera o expoente pelo chamado deslocamento da mantissa.
//!
//! Dito de outra forma, normalmente os flutuadores são escritos como (1), mas aqui eles são escritos como (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Chamamos (1) de **representação fracionária** e (2) de **representação integral**.
//!
//! Muitas funções neste módulo lidam apenas com números normais.As rotinas dec2flt seguem de forma conservadora o caminho lento universalmente correto (Algoritmo M) para números muito pequenos e muito grandes.
//! Esse algoritmo precisa apenas de next_float(), que lida com subnormais e zeros.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Um ajudante trait para evitar duplicar basicamente todo o código de conversão para `f32` e `f64`.
///
/// Veja o comentário do doc do módulo pai para saber por que isso é necessário.
///
/// **Nunca** deve ser implementado para outros tipos ou usado fora do módulo dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Tipo usado por `to_bits` e `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Executa uma transmutação bruta para um inteiro.
    fn to_bits(self) -> Self::Bits;

    /// Executa uma transmutação bruta de um inteiro.
    fn from_bits(v: Self::Bits) -> Self;

    /// Retorna a categoria em que este número se enquadra.
    fn classify(self) -> FpCategory;

    /// Retorna a mantissa, expoente e sinal como inteiros.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Decodifica o flutuador.
    fn unpack(self) -> Unpacked;

    /// Casts de um pequeno inteiro que pode ser representado exatamente.
    /// Panic se o número inteiro não puder ser representado, o outro código neste módulo garante que isso nunca aconteça.
    fn from_int(x: u64) -> Self;

    /// Obtém o valor 10 <sup>e</sup> de uma tabela pré-calculada.
    /// Panics para `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// O que o nome diz.
    /// É mais fácil codificar do que lidar com intrínsecos e esperar que a constante do LLVM o dobre.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Um limite conservador nos dígitos decimais de entradas que não podem produzir estouro ou zero ou
    /// subnormais.Provavelmente o expoente decimal do valor normal máximo, daí o nome.
    const MAX_NORMAL_DIGITS: usize;

    /// Quando o dígito decimal mais significativo tem um valor de casa maior do que este, o número é certamente arredondado para o infinito.
    ///
    const INF_CUTOFF: i64;

    /// Quando o dígito decimal mais significativo tem um valor de casa inferior a esse, o número certamente é arredondado para zero.
    ///
    const ZERO_CUTOFF: i64;

    /// O número de bits no expoente.
    const EXP_BITS: u8;

    /// O número de bits no significando,*incluindo* o bit oculto.
    const SIG_BITS: u8;

    /// O número de bits no significando,*excluindo* o bit oculto.
    const EXPLICIT_SIG_BITS: u8;

    /// O expoente legal máximo na representação fracionária.
    const MAX_EXP: i16;

    /// O expoente legal mínimo na representação fracionária, excluindo subnormais.
    const MIN_EXP: i16;

    /// `MAX_EXP` para representação integral, ou seja, com o deslocamento aplicado.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` codificado (ou seja, com desvio de deslocamento)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` para representação integral, ou seja, com o deslocamento aplicado.
    const MIN_EXP_INT: i16;

    /// O significando máximo normalizado em representação integral.
    const MAX_SIG: u64;

    /// O significando mínimo normalizado na representação integral.
    const MIN_SIG: u64;
}

// Principalmente uma solução alternativa para o #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Retorna a mantissa, expoente e sinal como inteiros.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Viés do expoente + mudança da mantissa
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe não tem certeza se o `as` roda corretamente em todas as plataformas.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Retorna a mantissa, expoente e sinal como inteiros.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Viés do expoente + mudança da mantissa
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe não tem certeza se o `as` roda corretamente em todas as plataformas.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Converte um `Fp` no tipo flutuante de máquina mais próximo.
/// Não lida com resultados subnormais.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f é de 64 bits, então xe tem uma mudança de mantissa de 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Arredonde o significando de 64 bits para bits T::SIG_BITS com meio para par.
/// Não lida com estouro de expoente.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Ajustar mudança de mantissa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Inverso de `RawFloat::unpack()` para números normalizados.
/// Panics se o significando ou expoente não são válidos para números normalizados.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Remova a parte escondida
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Ajuste o expoente para o viés do expoente e o deslocamento da mantissa
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Deixe o bit do sinal em 0 ("+"), nossos números são todos positivos
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Construa um subnormal.Uma mantissa de 0 é permitida e constrói zero.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // O expoente codificado é 0, o bit de sinal é 0, então só temos que reinterpretar os bits.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Aproxime um bignum com um Fp.Arredonda dentro do 0.5 ULP com meio para par.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Cortamos todos os bits antes do índice `start`, ou seja, efetivamente deslocamos para a direita uma quantidade de `start`, portanto, este também é o expoente de que precisamos.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Arredondar (half-to-even) dependendo dos bits truncados.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Encontra o maior número de ponto flutuante estritamente menor que o argumento.
/// Não lida com subnormais, zero ou estouro negativo de expoente.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Encontre o menor número de ponto flutuante estritamente maior que o argumento.
// Esta operação é saturante, ou seja, next_float(inf) ==inf.
// Ao contrário da maioria dos códigos neste módulo, esta função lida com zero, subnormais e infinitos.
// No entanto, como todos os outros códigos aqui, ele não lida com NaN e números negativos.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Parece bom demais para ser verdade, mas funciona.
        // 0.0 é codificado como a palavra zero.Subnormais são 0x000m ... m onde m é a mantissa.
        // Em particular, o menor subnormal é 0x0 ... 01 e o maior é 0x000F ... F.
        // O menor número normal é 0x0010 ... 0, portanto, este caso de canto também funciona.
        // Se o incremento ultrapassar a mantissa, o bit carry incrementa o expoente como desejamos e os bits da mantissa tornam-se zero.
        // Por causa da convenção de bits ocultos, isso também é exatamente o que queremos!
        // Finalmente, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}