//! Funções utilitárias para bignums que não fazem muito sentido para se transformar em métodos.

// FIXME O nome deste módulo é um pouco infeliz, já que outros módulos também importam `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Teste se truncar todos os bits menos significativos que `ones_place` introduz um erro relativo menor, igual ou maior que 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Se todos os bits restantes forem zero, é= 0.5 ULP, caso contrário> 0.5 Se não houver mais bits (half_bit==0), o valor abaixo também retorna igual corretamente.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Converte uma string ASCII contendo apenas dígitos decimais em um `u64`.
///
/// Não executa verificações de estouro ou caracteres inválidos, portanto, se o chamador não for cuidadoso, o resultado é falso e pode panic (embora não seja `unsafe`).
/// Além disso, strings vazias são tratadas como zero.
/// Esta função existe porque
///
/// 1. usar `FromStr` em `&[u8]` requer `from_utf8_unchecked`, o que é ruim, e
/// 2. juntar os resultados do `integral.parse()` e do `fractional.parse()` é mais complicado do que toda esta função.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Converte uma string de dígitos ASCII em um bignum.
///
/// Como o `from_str_unchecked`, esta função depende do analisador para eliminar os não-dígitos.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Desdobra um bignum em um inteiro de 64 bits.Panics se o número for muito grande.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Extrai uma série de bits.

/// O índice 0 é o bit menos significativo e o intervalo está semi-aberto, como de costume.
/// Panics se solicitado a extrair mais bits do que cabem no tipo de retorno.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}