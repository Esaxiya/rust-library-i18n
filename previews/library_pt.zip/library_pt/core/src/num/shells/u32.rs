//! Constantes para o tipo inteiro sem sinal de 32 bits.
//!
//! *[See also the `u32` primitive type][u32].*
//!
//! O novo código deve usar as constantes associadas diretamente no tipo primitivo.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u32`"
)]

int_module! { u32 }