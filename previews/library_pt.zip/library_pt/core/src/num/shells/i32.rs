//! Constantes para o tipo inteiro assinado de 32 bits.
//!
//! *[See also the `i32` primitive type][i32].*
//!
//! O novo código deve usar as constantes associadas diretamente no tipo primitivo.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i32`"
)]

int_module! { i32 }