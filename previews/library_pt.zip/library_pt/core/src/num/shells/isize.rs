//! Constantes para o tipo inteiro assinado de tamanho de ponteiro.
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! O novo código deve usar as constantes associadas diretamente no tipo primitivo.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }