//! Implementação de número (bignum) de precisão arbitrária personalizada.
//!
//! Isso foi projetado para evitar a alocação de heap em detrimento da memória da pilha.
//! O tipo de bignum mais usado, `Big32x40`, é limitado por 32 × 40=1.280 bits e ocupará no máximo 160 bytes de memória de pilha.
//! Isso é mais do que suficiente para o retorno de todos os valores `f64` finitos possíveis.
//!
//! Em princípio, é possível ter vários tipos de bignum para diferentes entradas, mas não fazemos isso para evitar o inchaço do código.
//!
//! Cada bignum ainda é rastreado para os usos reais, então normalmente não importa.
//!

// Este módulo é apenas para dec2flt e flt2dec, e apenas público por causa de corretestes.
// Não se destina a ser estabilizado.
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// Operações aritméticas exigidas por bignums.
pub trait FullOps: Sized {
    /// Retorna `(carry', v')` como `carry' * 2^W + v' = self + other + carry`, onde `W` é o número de bits em `Self`.
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// Retorna `(carry', v')` como `carry'*2^W + v' = self* other + carry`, onde `W` é o número de bits em `Self`.
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// Retorna `(carry', v')` como `carry'*2^W + v' = self* other + other2 + carry`, onde `W` é o número de bits em `Self`.
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// Retorna `(quo, rem)` como `borrow *2^W + self = quo* other + rem` e `0 <= rem < other`, onde `W` é o número de bits em `Self`.
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // Isso não pode transbordar;a saída está entre `0` e `2 * 2^nbits - 1`.
                    // FIXME: o LLVM otimizará isso para ADC ou similar?
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // Isso não pode transbordar;
                    // a saída está entre `0` e `2^nbits * (2^nbits - 1)`.
                    // FIXME: o LLVM otimizará isso para ADC ou similar?
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // Isso não pode transbordar;
                    // a saída está entre `0` e `2^nbits * (2^nbits - 1)`.
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // Isso não pode transbordar;a saída está entre `0` e `other * (2^nbits - 1)`.
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // Consulte RFC #521 para habilitar isso.
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// Tabela de potências de 5 representáveis em dígitos.Especificamente, o maior valor {u8, u16, u32} que é uma potência de cinco, mais o expoente correspondente.
/// Usado no `mul_pow5`.
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// Número inteiro de precisão arbitrária alocado na pilha (até certo limite).
        ///
        /// Isso é apoiado por uma matriz de tamanho fixo de determinado tipo ("digit").
        /// Embora a matriz não seja muito grande (normalmente algumas centenas de bytes), copiá-la de forma imprudente pode resultar em queda de desempenho.
        ///
        /// Portanto, este não é intencionalmente o `Copy`.
        ///
        /// Todas as operações disponíveis para bignums panic em caso de transbordamentos.
        /// O chamador é responsável por usar tipos de bignum grandes o suficiente.
        pub struct $name {
            /// Um mais o deslocamento para o "digit" máximo em uso.
            /// Isso não diminui, portanto, esteja ciente da ordem de cálculo.
            /// `base[size..]` deve ser zero.
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` representa `a + b *2^W + c* 2^(2W) + ...` onde `W` é o número de bits no tipo de dígito.
            base: [$ty; $n],
        }

        impl $name {
            /// Faz um bignum de um dígito.
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// Faz um bignum a partir do valor `u64`.
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// Retorna os dígitos internos como uma fatia `[a, b, c, ...]` de forma que o valor numérico seja `a + b *2^W + c* 2^(2W) + ...`, onde `W` é o número de bits no tipo de dígito.
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// Retorna o bit `i`-ésimo, onde o bit 0 é o menos significativo.
            /// Em outras palavras, a broca com peso `2^i`.
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// Retorna `true` se o bignum for zero.
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// Retorna o número de bits necessários para representar este valor.
            /// Observe que zero é considerado como precisando de 0 bits.
            pub fn bit_length(&self) -> usize {
                // Pule os dígitos mais significativos que são zero.
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // Não há dígitos diferentes de zero, ou seja, o número é zero.
                    return 0;
                }
                // Isso poderia ser otimizado com leading_zeros() e trocas de bits, mas provavelmente não vale a pena o incômodo.
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// Adiciona `other` a si mesmo e retorna sua própria referência mutável.
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// Subtrai `other` de si mesmo e retorna sua própria referência mutável.
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// Multiplica-se por um `other` do tamanho de um dígito e retorna sua própria referência mutável.
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// Multiplica-se por `2^bits` e retorna sua própria referência mutável.
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // deslocamento por bits `digits * digitbits`
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // deslocamento por bits `bits`
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // self.base [.. digits] é zero, não há necessidade de mudar
                }

                self.size = sz;
                self
            }

            /// Multiplica-se por `5^e` e retorna sua própria referência mutável.
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // Existem exatamente n zeros à direita em 2 ^ n, e os únicos tamanhos de dígitos relevantes são potências consecutivas de dois, portanto, esse é um índice adequado para a tabela.
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // Multiplique com a maior potência de um dígito o maior tempo possível ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... então acabe com o restante.
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// Multiplica-se por um número descrito por `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` (onde `W` é o número de bits no tipo de dígito) e retorna sua própria referência mutável.
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // a rotina interna.funciona melhor quando aa.len() <= bb.len().
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// Divide-se por um `other` do tamanho de um dígito e retorna sua própria referência mutável *e* o restante.
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// Divida-se por outro bignum, sobrescrevendo `q` com o quociente e `r` com o restante.
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // Estúpida e lenta divisão longa do base-2 tirada de
                // https://en.wikipedia.org/wiki/Division_algorithm
                // FIXME usa uma base maior ($ty) para a divisão longa.
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // Defina o bit `i` de q como 1.
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// O tipo de dígito para `Big32x40`.
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// este é usado apenas para teste.
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}