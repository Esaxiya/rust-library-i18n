//! Tipos de erro para conversão em tipos integrais.

use crate::convert::Infallible;
use crate::fmt;

/// O tipo de erro retornado quando uma conversão de tipo integral verificado falha.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Combine em vez de coagir para ter certeza de que o código como o `From<Infallible> for TryFromIntError` acima continuará funcionando quando o `Infallible` se tornar um apelido para o `!`.
        //
        //
        match never {}
    }
}

/// Um erro que pode ser retornado ao analisar um número inteiro.
///
/// Este erro é usado como o tipo de erro para as funções `from_str_radix()` nos tipos de inteiros primitivos, como [`i8::from_str_radix`].
///
/// # Causas potenciais
///
/// Entre outras causas, `ParseIntError` pode ser acionado por causa de espaços em branco à esquerda ou à direita na string, por exemplo, quando ela é obtida da entrada padrão.
///
/// Usar o método [`str::trim()`] garante que nenhum espaço em branco permaneça antes da análise.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum para armazenar os vários tipos de erros que podem fazer com que a análise de um inteiro falhe.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// O valor que está sendo analisado está vazio.
    ///
    /// Entre outras causas, essa variante será construída ao analisar uma string vazia.
    Empty,
    /// Contém um dígito inválido em seu contexto.
    ///
    /// Entre outras causas, essa variante será construída ao analisar uma string que contém um caractere não ASCII.
    ///
    /// Essa variante também é construída quando um `+` ou `-` é colocado no lugar errado em uma string, sozinho ou no meio de um número.
    ///
    ///
    InvalidDigit,
    /// O número inteiro é muito grande para armazenar no tipo de número inteiro de destino.
    PosOverflow,
    /// O número inteiro é muito pequeno para armazenar no tipo de número inteiro de destino.
    NegOverflow,
    /// O valor era zero
    ///
    /// Essa variante será emitida quando a string de análise tiver um valor zero, o que seria ilegal para tipos diferentes de zero.
    ///
    Zero,
}

impl ParseIntError {
    /// Exibe a causa detalhada da falha de análise de um inteiro.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}