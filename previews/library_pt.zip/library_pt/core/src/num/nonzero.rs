//! Definições de número inteiro que não é igual a zero.

use crate::fmt;
use crate::ops::{BitOr, BitOrAssign, Div, Rem};
use crate::str::FromStr;

use super::from_str_radix;
use super::{IntErrorKind, ParseIntError};
use crate::intrinsics;

macro_rules! impl_nonzero_fmt {
    ( #[$stability: meta] ( $( $Trait: ident ),+ ) for $Ty: ident ) => {
        $(
            #[$stability]
            impl fmt::$Trait for $Ty {
                #[inline]
                fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                    self.get().fmt(f)
                }
            }
        )+
    }
}

macro_rules! nonzero_integers {
    ( $( #[$stability: meta] $Ty: ident($Int: ty); )+ ) => {
        $(
            /// Um número inteiro que não é igual a zero.
            ///
            /// Isso permite alguma otimização do layout da memória.
            #[doc = concat!("For example, `Option<", stringify!($Ty), ">` is the same size as `", stringify!($Int), "`:")]
            /// ```rust
            /// use std::mem::size_of;
            #[doc = concat!("assert_eq!(size_of::<Option<core::num::", stringify!($Ty), ">>(), size_of::<", stringify!($Int), ">());")]
            /// ```
            #[$stability]
            #[derive(Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
            #[repr(transparent)]
            #[rustc_layout_scalar_valid_range_start(1)]
            #[rustc_nonnull_optimization_guaranteed]
            pub struct $Ty($Int);

            impl $Ty {
                /// Cria um diferente de zero sem verificar o valor.
                ///
                /// # Safety
                ///
                /// O valor não deve ser zero.
                #[$stability]
                #[rustc_const_stable(feature = "nonzero", since = "1.34.0")]
                #[inline]
                pub const unsafe fn new_unchecked(n: $Int) -> Self {
                    // SEGURANÇA: a segurança é garantida por quem liga.
                    unsafe { Self(n) }
                }

                /// Cria um diferente de zero se o valor fornecido não for zero.
                #[$stability]
                #[rustc_const_stable(feature = "const_nonzero_int_methods", since = "1.47.0")]
                #[inline]
                pub const fn new(n: $Int) -> Option<Self> {
                    if n != 0 {
                        // SEGURANÇA: acabamos de verificar se não há `0`
                        Some(unsafe { Self(n) })
                    } else {
                        None
                    }
                }

                /// Retorna o valor como um tipo primitivo.
                #[$stability]
                #[inline]
                #[rustc_const_stable(feature = "nonzero", since = "1.34.0")]
                pub const fn get(self) -> $Int {
                    self.0
                }

            }

            #[stable(feature = "from_nonzero", since = "1.31.0")]
            impl From<$Ty> for $Int {
                #[doc = concat!("Converts a `", stringify!($Ty), "` into an `", stringify!($Int), "`")]
                #[inline]
                fn from(nonzero: $Ty) -> Self {
                    nonzero.0
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOr for $Ty {
                type Output = Self;
                #[inline]
                fn bitor(self, rhs: Self) -> Self::Output {
                    // SEGURANÇA: como `self` e `rhs` são diferentes de zero, o
                    // resultado do bit a bit-or será diferente de zero.
                    unsafe { $Ty::new_unchecked(self.get() | rhs.get()) }
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOr<$Int> for $Ty {
                type Output = Self;
                #[inline]
                fn bitor(self, rhs: $Int) -> Self::Output {
                    // SEGURANÇA: como `self` é diferente de zero, o resultado do
                    // bit a bit ou será diferente de zero, independentemente do valor de `rhs`.
                    //
                    unsafe { $Ty::new_unchecked(self.get() | rhs) }
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOr<$Ty> for $Int {
                type Output = $Ty;
                #[inline]
                fn bitor(self, rhs: $Ty) -> Self::Output {
                    // SEGURANÇA: como `rhs` é diferente de zero, o resultado do
                    // bit a bit ou será diferente de zero, independentemente do valor de `self`.
                    //
                    unsafe { $Ty::new_unchecked(self | rhs.get()) }
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOrAssign for $Ty {
                #[inline]
                fn bitor_assign(&mut self, rhs: Self) {
                    *self = *self | rhs;
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOrAssign<$Int> for $Ty {
                #[inline]
                fn bitor_assign(&mut self, rhs: $Int) {
                    *self = *self | rhs;
                }
            }

            impl_nonzero_fmt! {
                #[$stability] (Debug, Display, Binary, Octal, LowerHex, UpperHex) for $Ty
            }
        )+
    }
}

nonzero_integers! {
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU8(u8);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU16(u16);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU32(u32);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU64(u64);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU128(u128);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroUsize(usize);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI8(i8);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI16(i16);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI32(i32);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI64(i64);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI128(i128);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroIsize(isize);
}

macro_rules! from_str_radix_nzint_impl {
    ($($t:ty)*) => {$(
        #[stable(feature = "nonzero_parse", since = "1.35.0")]
        impl FromStr for $t {
            type Err = ParseIntError;
            fn from_str(src: &str) -> Result<Self, Self::Err> {
                Self::new(from_str_radix(src, 10)?)
                    .ok_or(ParseIntError {
                        kind: IntErrorKind::Zero
                    })
            }
        }
    )*}
}

from_str_radix_nzint_impl! { NonZeroU8 NonZeroU16 NonZeroU32 NonZeroU64 NonZeroU128 NonZeroUsize
NonZeroI8 NonZeroI16 NonZeroI32 NonZeroI64 NonZeroI128 NonZeroIsize }

macro_rules! nonzero_leading_trailing_zeros {
    ( $( $Ty: ident($Uint: ty) , $LeadingTestExpr:expr ;)+ ) => {
        $(
            impl $Ty {
                /// Retorna o número de zeros à esquerda na representação binária de `self`.
                ///
                /// Em muitas arquiteturas, essa função pode ter um desempenho melhor do que `leading_zeros()` no tipo inteiro subjacente, pois o tratamento especial de zero pode ser evitado.
                ///
                /// # Examples
                ///
                /// Uso básico:
                ///
                /// ```
                /// #![feature(nonzero_leading_trailing_zeros)]
                #[doc = concat!("let n = std::num::", stringify!($Ty), "::new(", stringify!($LeadingTestExpr), ").unwrap();")]
                /// assert_eq!(n.leading_zeros(), 0);
                /// ```
                #[unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[rustc_const_unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[inline]
                pub const fn leading_zeros(self) -> u32 {
                    // SEGURANÇA: como `self` não pode ser zero, é seguro chamar ctlz_nonzero
                    unsafe { intrinsics::ctlz_nonzero(self.0 as $Uint) as u32 }
                }

                /// Retorna o número de zeros à direita na representação binária de `self`.
                ///
                /// Em muitas arquiteturas, essa função pode ter um desempenho melhor do que `trailing_zeros()` no tipo inteiro subjacente, pois o tratamento especial de zero pode ser evitado.
                ///
                ///
                /// # Examples
                ///
                /// Uso básico:
                ///
                /// ```
                /// #![feature(nonzero_leading_trailing_zeros)]
                #[doc = concat!("let n = std::num::", stringify!($Ty), "::new(0b0101000).unwrap();")]
                /// assert_eq!(n.trailing_zeros(), 3);
                /// ```
                #[unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[rustc_const_unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[inline]
                pub const fn trailing_zeros(self) -> u32 {
                    // SEGURANÇA: como `self` não pode ser zero, é seguro chamar cttz_nonzero
                    unsafe { intrinsics::cttz_nonzero(self.0 as $Uint) as u32 }
                }

            }
        )+
    }
}

nonzero_leading_trailing_zeros! {
    NonZeroU8(u8), u8::MAX;
    NonZeroU16(u16), u16::MAX;
    NonZeroU32(u32), u32::MAX;
    NonZeroU64(u64), u64::MAX;
    NonZeroU128(u128), u128::MAX;
    NonZeroUsize(usize), usize::MAX;
    NonZeroI8(u8), -1i8;
    NonZeroI16(u16), -1i16;
    NonZeroI32(u32), -1i32;
    NonZeroI64(u64), -1i64;
    NonZeroI128(u128), -1i128;
    NonZeroIsize(usize), -1isize;
}

macro_rules! nonzero_integers_div {
    ( $( $Ty: ident($Int: ty); )+ ) => {
        $(
            #[stable(feature = "nonzero_div", since = "1.51.0")]
            impl Div<$Ty> for $Int {
                type Output = $Int;
                /// Esta operação é arredondada para zero, truncando qualquer parte fracionária do resultado exato, e não pode panic.
                ///
                #[inline]
                fn div(self, other: $Ty) -> $Int {
                    // SEGURANÇA: div por zero é verificado porque `other` é diferente de zero,
                    // e MIN/-1 é verificado porque `self` é um int não assinado.
                    unsafe { crate::intrinsics::unchecked_div(self, other.get()) }
                }
            }

            #[stable(feature = "nonzero_div", since = "1.51.0")]
            impl Rem<$Ty> for $Int {
                type Output = $Int;
                /// Esta operação satisfaz `n % d == n - (n / d) * d` e não pode panic.
                #[inline]
                fn rem(self, other: $Ty) -> $Int {
                    // SEGURANÇA: rem por zero é verificado porque `other` é diferente de zero,
                    // e MIN/-1 é verificado porque `self` é um int não assinado.
                    unsafe { crate::intrinsics::unchecked_rem(self, other.get()) }
                }
            }
        )+
    }
}

nonzero_integers_div! {
    NonZeroU8(u8);
    NonZeroU16(u16);
    NonZeroU32(u32);
    NonZeroU64(u64);
    NonZeroU128(u128);
    NonZeroUsize(usize);
}

macro_rules! nonzero_unsigned_is_power_of_two {
    ( $( $Ty: ident )+ ) => {
        $(
            impl $Ty {

                /// Retorna `true` se e somente se `self == (1 << k)` para algum `k`.
                ///
                /// Em muitas arquiteturas, essa função pode ter um desempenho melhor do que `is_power_of_two()` no tipo inteiro subjacente, pois o tratamento especial de zero pode ser evitado.
                ///
                ///
                /// # Examples
                ///
                /// Uso básico:
                ///
                /// ```
                /// #![feature(nonzero_is_power_of_two)]
                ///
                #[doc = concat!("let eight = std::num::", stringify!($Ty), "::new(8).unwrap();")]
                /// assert!(eight.is_power_of_two());
                #[doc = concat!("let ten = std::num::", stringify!($Ty), "::new(10).unwrap();")]
                /// assert!(!ten.is_power_of_two());
                /// ```
                #[unstable(feature = "nonzero_is_power_of_two", issue = "81106")]
                #[inline]
                pub const fn is_power_of_two(self) -> bool {
                    // O LLVM 11 normaliza o `unchecked_sub(x, 1) & x == 0` para a implementação vista aqui.
                    // No destino x86-64 básico, isso salva 3 instruções para a verificação de zero.
                    // No x86_64 com BMI1, ser diferente de zero permite codegen para `BLSR`, que salva uma instrução em comparação com a implementação do `POPCNT` no tipo inteiro subjacente.
                    //

                    intrinsics::ctpop(self.get()) < 2
                }

            }
        )+
    }
}

nonzero_unsigned_is_power_of_two! { NonZeroU8 NonZeroU16 NonZeroU32 NonZeroU64 NonZeroU128 NonZeroUsize }