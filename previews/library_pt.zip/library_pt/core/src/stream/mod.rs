//! Iteração assíncrona combinável.
//!
//! Se futures são valores assíncronos, então os fluxos são iteradores assíncronos.
//! Se você se encontrou com uma coleção assíncrona de algum tipo e precisou realizar uma operação nos elementos dessa coleção, você encontrará rapidamente o 'streams'.
//! Os fluxos são amplamente usados no código Rust assíncrono idiomático, portanto, vale a pena se familiarizar com eles.
//!
//! Antes de explicar mais, vamos falar sobre como este módulo está estruturado:
//!
//! # Organization
//!
//! Este módulo é amplamente organizado por tipo:
//!
//! * [Traits] são a parte central: estes traits definem que tipo de streams existem e o que você pode fazer com eles.Os métodos desses traits valem a pena investir algum tempo extra de estudo.
//! * As funções fornecem algumas maneiras úteis de criar alguns fluxos básicos.
//! * As estruturas são frequentemente os tipos de retorno dos vários métodos no traits deste módulo.Normalmente, você desejará examinar o método que cria o `struct`, em vez do próprio `struct`.
//! Para obter mais detalhes sobre o motivo, consulte '[Implementing Stream](#defining-stream)'.
//!
//! [Traits]: #traits
//!
//! É isso!Vamos explorar os riachos.
//!
//! # Stream
//!
//! O coração e a alma deste módulo é o [`Stream`] trait.O núcleo do [`Stream`] é assim:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Ao contrário do `Iterator`, o `Stream` faz uma distinção entre o método [`poll_next`] que é usado ao implementar um `Stream` e um método (to-be-implemented) `next` que é usado ao consumir um fluxo.
//!
//! Os consumidores de `Stream` precisam apenas considerar `next`, que quando chamado, retorna um future que produz `Option<Stream::Item>`.
//!
//! O future retornado pelo `next` renderá `Some(Item)` enquanto houver elementos e, uma vez que todos eles tenham sido esgotados, renderá `None` para indicar que a iteração foi concluída.
//! Se estivermos esperando que algo assíncrono seja resolvido, o future esperará até que o fluxo esteja pronto para render novamente.
//!
//! Fluxos individuais podem optar por retomar a iteração e, portanto, chamar o `next` novamente pode ou não eventualmente render o `Some(Item)` novamente em algum ponto.
//!
//! A definição completa do [`Stream`] inclui uma série de outros métodos também, mas eles são métodos padrão, construídos sobre o [`poll_next`] e, portanto, você os obtém gratuitamente.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Implementando Stream
//!
//! A criação de um fluxo próprio envolve duas etapas: criar um `struct` para manter o estado do fluxo e, em seguida, implementar o [`Stream`] para esse `struct`.
//!
//! Vamos fazer um fluxo denominado `Counter` que conta de `1` a `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Primeiro, a estrutura:
//!
//! /// Um riacho que conta de um a cinco
//! struct Counter {
//!     count: usize,
//! }
//!
//! // queremos que nossa contagem comece em um, então vamos adicionar um método new() para ajudar.
//! // Isso não é estritamente necessário, mas é conveniente.
//! // Observe que iniciamos o `count` do zero, veremos o motivo na implementação do `poll_next()`'s a seguir.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Em seguida, implementamos `Stream` para nosso `Counter`:
//!
//! impl Stream for Counter {
//!     // estaremos contando com usize
//!     type Item = usize;
//!
//!     // poll_next() é o único método necessário
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Aumente nossa contagem.É por isso que começamos do zero.
//!         self.count += 1;
//!
//!         // Verifique se terminamos a contagem ou não.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Streams são *preguiçosos*.Isso significa que apenas criar um fluxo não é muito _do_.Nada realmente acontece até você ligar para o `next`.
//! Isso às vezes é uma fonte de confusão ao criar um fluxo apenas para seus efeitos colaterais.
//! O compilador nos avisará sobre este tipo de comportamento:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;