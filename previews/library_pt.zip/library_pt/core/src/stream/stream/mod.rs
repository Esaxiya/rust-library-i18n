use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Uma interface para lidar com iteradores assíncronos.
///
/// Este é o fluxo principal trait.
/// Para obter mais informações sobre o conceito de fluxos em geral, consulte o [module-level documentation].
/// Em particular, você pode querer saber como fazer [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// O tipo de itens produzidos pelo fluxo.
    type Item;

    /// Tente extrair o próximo valor deste fluxo, registrando a tarefa atual para despertar se o valor ainda não estiver disponível e retornando `None` se o fluxo estiver esgotado.
    ///
    /// # Valor de retorno
    ///
    /// Existem vários valores de retorno possíveis, cada um indicando um estado de fluxo distinto:
    ///
    /// - `Poll::Pending` significa que o próximo valor deste fluxo ainda não está pronto.As implementações garantirão que a tarefa atual seja notificada quando o próximo valor estiver pronto.
    ///
    /// - `Poll::Ready(Some(val))` significa que o fluxo produziu com sucesso um valor, `val`, e pode produzir outros valores nas chamadas `poll_next` subsequentes.
    ///
    /// - `Poll::Ready(None)` significa que o fluxo foi encerrado e o `poll_next` não deve ser chamado novamente.
    ///
    /// # Panics
    ///
    /// Uma vez que um fluxo tenha terminado (`Ready(None)` from `poll_next`) retornado, chamar seu método `poll_next` novamente pode panic, bloquear para sempre ou causar outros tipos de problemas; o `Stream` trait não impõe requisitos sobre os efeitos de tal chamada.
    ///
    /// No entanto, como o método `poll_next` não está marcado como `unsafe`, as regras usuais de Rust se aplicam: as chamadas nunca devem causar comportamento indefinido (corrupção de memória, uso incorreto de funções `unsafe` ou semelhantes), independentemente do estado do fluxo.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Retorna os limites do comprimento restante do fluxo.
    ///
    /// Especificamente, `size_hint()` retorna uma tupla em que o primeiro elemento é o limite inferior e o segundo elemento é o limite superior.
    ///
    /// A segunda metade da tupla que é retornada é uma [`Option`]`<`[`usize`] `>`.
    /// Um [`None`] aqui significa que não há limite superior conhecido ou o limite superior é maior do que [`usize`].
    ///
    /// # Notas de implementação
    ///
    /// Não é obrigatório que uma implementação de fluxo produza o número declarado de elementos.Um fluxo de buggy pode render menos do que o limite inferior ou mais do que o limite superior dos elementos.
    ///
    /// `size_hint()` destina-se principalmente a ser usado para otimizações, como reservar espaço para os elementos do fluxo, mas não deve ser confiável para, por exemplo, omitir verificações de limites em código inseguro.
    /// Uma implementação incorreta do `size_hint()` não deve levar a violações de segurança da memória.
    ///
    /// Dito isso, a implementação deve fornecer uma estimativa correta, pois caso contrário, seria uma violação do protocolo trait.
    ///
    /// A implementação padrão retorna `(0,` [`None`]`)`que é correto para qualquer fluxo.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}