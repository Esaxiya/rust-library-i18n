//! Tipos que fixam os dados em sua localização na memória.
//!
//! Às vezes é útil ter objetos que não se movem, no sentido de que sua colocação na memória não muda e, portanto, pode-se confiar.
//! Um exemplo primordial de tal cenário seria a construção de estruturas autorreferenciais, pois mover um objeto com ponteiros para si mesmo os invalidará, o que poderia causar um comportamento indefinido.
//!
//! Em um nível alto, um [`Pin<P>`] garante que a ponta de qualquer tipo de ponteiro `P` tenha uma localização estável na memória, o que significa que não pode ser movida para outro lugar e sua memória não pode ser desalocada até que seja descartada.Dizemos que a ponta é "pinned".As coisas ficam mais sutis ao discutir tipos que combinam dados fixos com dados não fixados;[see below](#projections-and-structural-pinning) para mais detalhes.
//!
//! Por padrão, todos os tipos em Rust são móveis.
//! Rust permite passar todos os tipos por valor, e os tipos de ponteiro inteligente comuns, como [`Box<T>`] e `&mut T`, permitem substituir e mover os valores que eles contêm: você pode sair de um [`Box<T>`] ou usar o [`mem::swap`].
//! [`Pin<P>`] envolve um tipo de ponteiro `P`, então [`Pin`]`<`[`Box`] `<T>>`funciona como um normal
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Box`] `<T>>`é descartado, assim como seu conteúdo, e a memória é
//!
//! desalocado.Da mesma forma, [`Pin`]`<&mut T>`é muito parecido com o `&mut T`.No entanto, o [`Pin<P>`] não permite que os clientes realmente obtenham um [`Box<T>`] ou `&mut T` para dados fixados, o que implica que você não pode usar operações como o [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` precisa do `&mut T`, mas não podemos obtê-lo.
//!     // Estamos presos, não podemos trocar o conteúdo dessas referências.
//!     // Poderíamos usar o `Pin::get_unchecked_mut`, mas isso não é seguro por um motivo:
//!     // não temos permissão para usá-lo para remover coisas do `Pin`.
//! }
//! ```
//!
//! Vale a pena reiterar que o [`Pin<P>`]*não* muda o fato de que um compilador Rust considera todos os tipos móveis.O [`mem::swap`] continua a ser chamado para qualquer `T`.Em vez disso, o [`Pin<P>`] evita que certos *valores*(apontados por ponteiros incluídos no [`Pin<P>`]) sejam movidos, tornando impossível chamar métodos que requerem `&mut T` neles (como o [`mem::swap`]).
//!
//! [`Pin<P>`] pode ser usado para envolver qualquer tipo de ponteiro `P` e, como tal, interage com [`Deref`] e [`DerefMut`].Um [`Pin<P>`] onde `P: Deref` deve ser considerado como um "`P`-style pointer" para um `P::Target` fixado-então, um [`Pin`]`<`[`Box`] `<T>>`é um ponteiro pertencente a um `T` fixado, e um [`Pin`] `<` [`Rc`]`<T>>`é um ponteiro com contagem de referência para um `T` fixado.
//! Para correção, o [`Pin<P>`] depende das implementações de [`Deref`] e [`DerefMut`] para não sair de seu parâmetro `self` e apenas para retornar um ponteiro para dados fixados quando eles são chamados em um ponteiro fixado.
//!
//! # `Unpin`
//!
//! Muitos tipos sempre podem ser movidos livremente, mesmo quando fixados, porque não dependem de um endereço estável.Isso inclui todos os tipos básicos (como [`bool`], [`i32`] e referências), bem como os tipos que consistem apenas nesses tipos.Tipos que não se importam com a fixação implementam o [`Unpin`] auto-trait, que cancela o efeito do [`Pin<P>`].
//! Para `T: Unpin`, [`Pin`]`<`[`Box`] `<T>>`e [`Box<T>`] funcionam de forma idêntica, assim como [`Pin`] `<&mut T>` e `&mut T`.
//!
//! Observe que a fixação e o [`Unpin`] afetam apenas o tipo `P::Target` apontado, não o tipo de ponteiro `P` em si que foi encapsulado no [`Pin<P>`].Por exemplo, o fato de [`Box<T>`] ser ou não [`Unpin`] não tem efeito no comportamento de [`Pin`]`<`[`Box`] `<T>>`(aqui, `T` é o tipo indicado).
//!
//! # Exemplo: estrutura autorreferencial
//!
//! Antes de entrarmos em mais detalhes para explicar as garantias e opções associadas ao `Pin<T>`, discutiremos alguns exemplos de como ele pode ser usado.
//! Sinta-se à vontade para [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Esta é uma estrutura autorreferencial porque o campo de fatia aponta para o campo de dados.
//! // Não podemos informar o compilador sobre isso com uma referência normal, pois esse padrão não pode ser descrito com as regras usuais de empréstimo.
//! //
//! // Em vez disso, usamos um ponteiro bruto, embora um que não seja nulo, pois sabemos que está apontando para a string.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Para garantir que os dados não se movam quando a função retornar, nós os colocamos no heap onde permanecerão por toda a vida do objeto, e a única maneira de acessá-los seria por meio de um ponteiro para ele.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // nós apenas criamos o ponteiro uma vez que os dados estão no lugar, caso contrário ele já terá se movido antes mesmo de começarmos
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // sabemos que isso é seguro porque modificar um campo não move toda a estrutura
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // O ponteiro deve apontar para o local correto, desde que a estrutura não tenha se movido.
//! //
//! // Enquanto isso, estamos livres para mover o ponteiro.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Uma vez que nosso tipo não implementa Desafixar, ele não conseguirá compilar:
//! // deixe mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Exemplo: lista duplamente vinculada intrusiva
//!
//! Em uma lista duplamente vinculada intrusiva, a coleção não aloca de fato a memória para os próprios elementos.
//! A alocação é controlada pelos clientes e os elementos podem viver em uma estrutura de pilha que dura menos do que a coleção.
//!
//! Para fazer isso funcionar, cada elemento possui ponteiros para seu predecessor e sucessor na lista.Os elementos só podem ser adicionados quando são fixados, porque mover os elementos invalidaria os ponteiros.Além disso, a implementação do [`Drop`] de um elemento de lista vinculada corrigirá os ponteiros de seu predecessor e sucessor para se remover da lista.
//!
//! Crucialmente, temos que ser capazes de contar com a chamada de [`drop`].Se um elemento pudesse ser desalocado ou de outra forma invalidado sem chamar o [`drop`], os ponteiros para ele a partir de seus elementos vizinhos se tornariam inválidos, o que quebraria a estrutura de dados.
//!
//! Portanto, a fixação também vem com uma garantia relacionada a [`drop`].
//!
//! # `Drop` guarantee
//!
//! O objetivo da fixação é poder contar com a colocação de alguns dados na memória.
//! Para fazer isso funcionar, não apenas mover os dados é restrito;desalocar, redefinir a finalidade ou de outra forma invalidar a memória usada para armazenar os dados também é restrita.
//! Concretamente, para dados fixados, você deve manter a invariante para que *sua memória não seja invalidada ou reaproveitada a partir do momento em que é fixada até quando o [`drop`] é chamado*.Somente quando o [`drop`] retornar ou panics, a memória poderá ser reutilizada.
//!
//! A memória pode ser "invalidated" por desalocação, mas também substituindo um [`Some(v)`] por [`None`] ou chamando [`Vec::set_len`] a "kill" de alguns elementos de um vector.Ele pode ser reaproveitado usando o [`ptr::write`] para sobrescrevê-lo sem chamar o destruidor primeiro.Nada disso é permitido para dados fixados sem chamar o [`drop`].
//!
//! Esse é exatamente o tipo de garantia de que a lista vinculada intrusiva da seção anterior precisa funcionar corretamente.
//!
//! Observe que esta garantia *não* significa que a memória não vaza!Ainda não há problema em nunca chamar o [`drop`] em um elemento fixado (por exemplo, você ainda pode chamar o [`mem::forget`] em um [`Pin`]`<`[`Box`] `<T>>`).No exemplo da lista duplamente vinculada, esse elemento apenas permaneceria na lista.No entanto, você não pode liberar ou reutilizar o armazenamento *sem chamar [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Se o seu tipo usa fixação (como os dois exemplos acima), você deve ter cuidado ao implementar o [`Drop`].A função [`drop`] usa `&mut self`, mas isso é chamado *mesmo se o seu tipo foi previamente fixado*!É como se o compilador automaticamente chamasse [`Pin::get_unchecked_mut`].
//!
//! Isso nunca pode causar um problema no código seguro porque a implementação de um tipo que depende de fixação requer código inseguro, mas esteja ciente de que decidir usar a fixação em seu tipo (por exemplo, implementando alguma operação em [`Pin`]`<&Self>`ou [`Pin`] `<&mut Self>`) também tem consequências para a implementação do [`Drop`]: se um elemento do seu tipo poderia ter sido fixado, você deve tratar o [`Drop`] como implicitamente assumindo [`Pin`]`<&mut Auto>`.
//!
//!
//! Por exemplo, você pode implementar o `Drop` da seguinte maneira:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` está tudo bem porque sabemos que esse valor nunca será usado novamente após ser descartado.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // O código de descarte real vai aqui.
//!         }
//!     }
//! }
//! ```
//!
//! A função `inner_drop` tem o tipo que o [`drop`]*deveria* ter, então isso garante que você não use acidentalmente o `self`/`this` de uma forma que esteja em conflito com a fixação.
//!
//! Além disso, se o seu tipo for `#[repr(packed)]`, o compilador moverá os campos automaticamente para poder eliminá-los.Pode até fazer isso para campos que estejam suficientemente alinhados.Como consequência, você não pode usar a fixação com um tipo `#[repr(packed)]`.
//!
//! # Projeções e fixação estrutural
//!
//! Ao trabalhar com estruturas fixadas, surge a questão de como acessar os campos dessa estrutura em um método que usa apenas [`Pin`]`<&mut Struct>`.
//! A abordagem usual é escrever métodos auxiliares (chamados de *projeções*) que transformam [`Pin`]`<&mut Struct>`em uma referência para o campo, mas que tipo essa referência deve ter?É [`Pin`]`<&mut Field>`ou `&mut Field`?
//! A mesma pergunta surge com os campos de um `enum` e também quando se considera os tipos container/wrapper, como [`Vec<T>`], [`Box<T>`] ou [`RefCell<T>`].
//! (Esta questão se aplica a referências mutáveis e compartilhadas, apenas usamos o caso mais comum de referências mutáveis aqui para ilustração.)
//!
//! Acontece que, na verdade, cabe ao autor da estrutura de dados decidir se a projeção fixada para um determinado campo transforma [`Pin`]`<&mut Struct>`em [`Pin`] `<&mut Field>` ou `&mut Field`.No entanto, existem algumas restrições, e a restrição mais importante é a *consistência*:
//! cada campo pode ser *ou* projetado para uma referência fixada *ou* ter a fixação removida como parte da projeção.
//! Se ambos forem feitos para o mesmo campo, provavelmente será incorreto!
//!
//! Como autor de uma estrutura de dados, você pode decidir para cada campo se vai fixar o "propagates" a este campo ou não.
//! A fixação que se propaga também é chamada de "structural", porque segue a estrutura do tipo.
//! Nas subseções a seguir, descrevemos as considerações que devem ser feitas para qualquer uma das opções.
//!
//! ## A fixação *não é* estrutural para `field`
//!
//! Pode parecer contra-intuitivo que o campo de uma estrutura fixada não seja fixada, mas essa é realmente a escolha mais fácil: se um [`Pin`]`<&mut Field>`nunca for criado, nada pode dar errado!Portanto, se você decidir que algum campo não tem fixação estrutural, tudo o que você precisa garantir é que nunca crie uma referência fixada para aquele campo.
//!
//! Os campos sem fixação estrutural podem ter um método de projeção que transforma [`Pin`]`<&mut Struct>`em `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Isso está certo porque o `field` nunca é considerado fixado.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Você também pode usar o `impl Unpin for Struct`*mesmo se* o tipo de `field` não for [`Unpin`].O que esse tipo pensa sobre a fixação não é relevante quando nenhum [`Pin`]`<&mut Field>`é criado.
//!
//! ## Fixação *é* estrutural para `field`
//!
//! A outra opção é decidir que a fixação é "structural" para `field`, o que significa que se a estrutura for fixada, o campo também estará.
//!
//! Isso permite escrever uma projeção que cria um [`Pin`]`<&mut Field>`, testemunhando assim que o campo está fixado:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Isso está certo porque o `field` está fixado quando o `self` está.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! No entanto, a fixação estrutural vem com alguns requisitos extras:
//!
//! 1. A estrutura só deve ser [`Unpin`] se todos os campos estruturais forem [`Unpin`].Este é o padrão, mas o [`Unpin`] é um trait seguro, portanto, como autor da estrutura, é sua responsabilidade *não* adicionar algo como o `impl<T> Unpin for Struct<T>`.
//! (Observe que adicionar uma operação de projeção requer código inseguro, então o fato de que [`Unpin`] é um trait seguro não quebra o princípio de que você só precisa se preocupar com isso se usar `inseguro '.)
//! 2. O destruidor da estrutura não deve mover campos estruturais para fora de seu argumento.Este é o ponto exato levantado no [previous section][drop-impl]: o `drop` usa o `&mut self`, mas a estrutura (e, portanto, seus campos) pode ter sido fixada antes.
//!     Você tem que garantir que não moverá um campo dentro da implementação do [`Drop`].
//!     Em particular, conforme explicado anteriormente, isso significa que sua estrutura *não* deve ser `#[repr(packed)]`.
//!     Consulte aquela seção para saber como escrever o [`drop`] de forma que o compilador possa ajudá-lo a não quebrar a fixação acidentalmente.
//! 3. Você deve certificar-se de que mantém o [`Drop` guarantee][drop-guarantee]:
//!     depois que sua estrutura é fixada, a memória que contém o conteúdo não é substituída ou desalocada sem chamar os destruidores do conteúdo.
//!     Isso pode ser complicado, como testemunhado por [`VecDeque<T>`]: o destruidor de [`VecDeque<T>`] pode falhar ao chamar [`drop`] em todos os elementos se um dos destruidores panics.Isso viola a garantia do [`Drop`], porque pode fazer com que os elementos sejam desalocados sem que seu destruidor seja chamado.([`VecDeque<T>`] não tem projeções de fixação, portanto, isso não causa problemas.)
//! 4. Você não deve oferecer nenhuma outra operação que possa fazer com que os dados sejam movidos para fora dos campos estruturais quando seu tipo for fixado.Por exemplo, se a estrutura contém um [`Option<T>`] e há uma operação semelhante a `take` com o tipo `fn(Pin<&mut Struct<T>>) -> Option<T>`, essa operação pode ser usada para mover um `T` para fora de um `Struct<T>` fixado-o que significa que a fixação não pode ser estrutural para o campo que o contém dados.
//!
//!     Para um exemplo mais complexo de movimentação de dados de um tipo fixado, imagine se o [`RefCell<T>`] tivesse um método `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Então, poderíamos fazer o seguinte:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Isso é catastrófico, significa que podemos primeiro fixar o conteúdo do [`RefCell<T>`] (usando o `RefCell::get_pin_mut`) e, em seguida, mover esse conteúdo usando a referência mutável que obtivemos mais tarde.
//!
//! ## Examples
//!
//! Para um tipo como o [`Vec<T>`], ambas as possibilidades (fixação estrutural ou não) fazem sentido.
//! Um [`Vec<T>`] com fixação estrutural pode ter métodos `get_pin`/`get_pin_mut` para obter referências fixadas a elementos.No entanto, ele *não* poderia permitir a chamada do [`pop`][Vec::pop] em um [`Vec<T>`] fixado porque isso moveria o conteúdo (estruturalmente fixado)!Nem poderia permitir o [`push`][Vec::push], que pode realocar e, portanto, também mover o conteúdo.
//!
//! Um [`Vec<T>`] sem fixação estrutural poderia `impl<T> Unpin for Vec<T>`, porque o conteúdo nunca é fixado e o próprio [`Vec<T>`] também pode ser movido.
//! Nesse ponto, a fixação simplesmente não tem efeito sobre o vector.
//!
//! Na biblioteca padrão, os tipos de ponteiro geralmente não têm fixação estrutural e, portanto, não oferecem projeções de fixação.É por isso que o `Box<T>: Unpin` vale para todos os `T`.
//! Faz sentido fazer isso para tipos de ponteiro, porque mover o `Box<T>` não move o `T`: o [`Box<T>`] pode ser movido livremente (também conhecido como `Unpin`) mesmo se o `T` não for.Na verdade, mesmo [`Pin`]`<`[`Box`] `<T>>`e [`Pin`] `<&mut T>` são sempre [`Unpin`], pela mesma razão: seus conteúdos (o `T`) são fixados, mas os próprios ponteiros podem ser movidos sem mover os dados fixados.
//! Para [`Box<T>`] e [`Pin`]`<`[`Box`] `<T>>`, se o conteúdo está fixado é totalmente independente de o ponteiro estar fixado, o que significa que a fixação *não* é estrutural.
//!
//! Ao implementar um combinador [`Future`], você geralmente precisará de fixação estrutural para os futures aninhados, pois você precisa obter referências fixadas a eles para chamar o [`poll`].
//! Mas se o seu combinador contém quaisquer outros dados que não precisam ser fixados, você pode tornar esses campos não estruturais e, portanto, acessá-los livremente com uma referência mutável, mesmo quando você apenas tem [`Pin`]`<&mut Self>`(tal como em sua própria implementação [`poll`]).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Um ponteiro fixado.
///
/// Este é um invólucro em torno de um tipo de ponteiro que torna esse ponteiro "pin" seu valor no lugar, evitando que o valor referenciado por esse ponteiro seja movido a menos que implemente [`Unpin`].
///
///
/// *Consulte a documentação do [`pin` module] para obter uma explicação sobre a fixação.*
///
/// [`pin` module]: self
///
// Note: o `Clone` derivado abaixo causa insalubridade, pois é possível implementar
// `Clone` para referências mutáveis.
// Consulte <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> para obter mais detalhes.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// As implementações a seguir não são derivadas para evitar problemas de solidez.
// `&self.pointer` não deve ser acessível para implementações trait não confiáveis.
//
// Consulte <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> para obter mais detalhes.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Construa um novo `Pin<P>` em torno de um ponteiro para alguns dados de um tipo que implementa o [`Unpin`].
    ///
    /// Ao contrário do `Pin::new_unchecked`, este método é seguro porque o ponteiro `P` desreferencia para um tipo [`Unpin`], o que cancela as garantias de fixação.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SEGURANÇA: o valor apontado é `Unpin` e, portanto, não tem requisitos
        // em torno da fixação.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Desembrulha este `Pin<P>` retornando o ponteiro subjacente.
    ///
    /// Isso requer que os dados dentro deste `Pin` sejam [`Unpin`] para que possamos ignorar as invariantes de fixação ao desempacotá-los.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Construa um novo `Pin<P>` em torno de uma referência a alguns dados de um tipo que pode ou não implementar o `Unpin`.
    ///
    /// Se `pointer` desreferenciar para um tipo `Unpin`, `Pin::new` deve ser usado em seu lugar.
    ///
    /// # Safety
    ///
    /// Este construtor não é seguro porque não podemos garantir que os dados apontados pelo `pointer` sejam fixados, o que significa que os dados não serão movidos ou seu armazenamento invalidado até que sejam descartados.
    /// Se o `Pin<P>` construído não garantir que os dados para os quais o `P` aponta sejam fixados, isso é uma violação do contrato de API e pode levar a um comportamento indefinido em operações posteriores do (safe).
    ///
    /// Ao usar este método, você está fazendo uma promessa Z0 sobre as implementações `P::Deref` e `P::DerefMut`, se houver.
    /// Mais importante ainda, eles não devem sair de seus argumentos `self`: `Pin::as_mut` e `Pin::as_ref` chamarão `DerefMut::deref_mut` e `Deref::deref`*no ponteiro fixado* e esperar que esses métodos sustentem as invariáveis de fixação.
    /// Além disso, ao chamar esse método, você promete que as desreferências de referência do `P` não serão removidas novamente;em particular, não deve ser possível obter um `&mut P::Target` e depois sair dessa referência (usando, por exemplo, [`mem::swap`]).
    ///
    ///
    /// Por exemplo, chamar o `Pin::new_unchecked` em um `&'a mut T` não é seguro porque, embora você seja capaz de fixá-lo durante a vida útil do `'a`, não tem controle sobre se ele será mantido fixado após o término do `'a`:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Isso deve significar que a ponteira `a` nunca mais poderá se mover.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // O endereço do `a` mudou para o slot de pilha de `b`, então o `a` foi movido embora já o tenhamos fixado!Violamos o contrato de pinning API.
    /////
    /// }
    /// ```
    ///
    /// Um valor, uma vez fixado, deve permanecer fixado para sempre (a menos que seu tipo implemente `Unpin`).
    ///
    /// Da mesma forma, chamar o `Pin::new_unchecked` em um `Rc<T>` não é seguro porque pode haver aliases para os mesmos dados que não estão sujeitos às restrições de fixação:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Isso deve significar que a ponta da ponta nunca pode se mover novamente.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Agora, se `x` fosse a única referência, teríamos uma referência mutável aos dados que fixamos acima, que poderíamos usar para movê-los como vimos no exemplo anterior.
    ///     // Violamos o contrato de pinning API.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Obtém uma referência compartilhada fixada a partir deste ponteiro fixado.
    ///
    /// Este é um método genérico para ir do `&Pin<Pointer<T>>` ao `Pin<&T>`.
    /// É seguro porque, como parte do contrato do `Pin::new_unchecked`, a ponta não pode se mover após a criação do `Pin<Pointer<T>>`.
    ///
    /// "Malicious" as implementações do `Pointer::Deref` também estão excluídas pelo contrato do `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SEGURANÇA: veja a documentação sobre esta função
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Desembrulha este `Pin<P>` retornando o ponteiro subjacente.
    ///
    /// # Safety
    ///
    /// Esta função não é segura.Você deve garantir que continuará a tratar o ponteiro `P` como fixado após chamar esta função, para que as invariáveis no tipo `Pin` possam ser mantidas.
    /// Se o código que usa o `P` resultante não continuar a manter as invariáveis de fixação, isso é uma violação do contrato de API e pode levar a um comportamento indefinido em operações (safe) posteriores.
    ///
    ///
    /// Se os dados subjacentes forem [`Unpin`], [`Pin::into_inner`] deve ser usado em seu lugar.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Obtém uma referência mutável fixada a partir deste ponteiro fixado.
    ///
    /// Este é um método genérico para ir do `&mut Pin<Pointer<T>>` ao `Pin<&mut T>`.
    /// É seguro porque, como parte do contrato do `Pin::new_unchecked`, a ponta não pode se mover após a criação do `Pin<Pointer<T>>`.
    ///
    /// "Malicious" as implementações do `Pointer::DerefMut` também estão excluídas pelo contrato do `Pin::new_unchecked`.
    ///
    /// Este método é útil ao fazer várias chamadas para funções que consomem o tipo fixado.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // faça alguma coisa
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` consome `self`, então pegue novamente o `Pin<&mut Self>` via `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SEGURANÇA: veja a documentação sobre esta função
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Atribui um novo valor à memória por trás da referência fixada.
    ///
    /// Isso sobrescreve os dados fixados, mas tudo bem: seu destruidor é executado antes de ser sobrescrito, portanto, nenhuma garantia de fixação é violada.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Constrói um novo pino mapeando o valor interno.
    ///
    /// Por exemplo, se você quiser obter um `Pin` de um campo de algo, poderá usar isso para obter acesso a esse campo em uma linha de código.
    /// No entanto, existem vários truques com esses "pinning projections";
    /// consulte a documentação do [`pin` module] para obter mais detalhes sobre esse tópico.
    ///
    /// # Safety
    ///
    /// Esta função não é segura.
    /// Você deve garantir que os dados retornados não se movam, contanto que o valor do argumento não se mova (por exemplo, porque é um dos campos desse valor), e também que você não saia do argumento que recebe para a função interior.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SEGURANÇA: o contrato de segurança para `new_unchecked` deve ser
        // confirmado pelo chamador.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Obtém uma referência compartilhada de um pino.
    ///
    /// Isso é seguro porque não é possível sair de uma referência compartilhada.
    /// Pode parecer que há um problema aqui com a mutabilidade interna: na verdade,*é* possível remover um `T` de um `&RefCell<T>`.
    /// No entanto, isso não é um problema, desde que também não exista um `Pin<&T>` apontando para os mesmos dados e o `RefCell<T>` não permita que você crie uma referência fixa para seu conteúdo.
    ///
    /// Consulte a discussão sobre o ["pinning projections"] para obter mais detalhes.
    ///
    /// Note: O `Pin` também implementa o `Deref` no destino, que pode ser usado para acessar o valor interno.
    /// No entanto, o `Deref` fornece apenas uma referência que dura enquanto o `Pin` foi emprestado, não a vida útil do próprio `Pin`.
    /// Este método permite transformar o `Pin` em uma referência com a mesma vida útil do `Pin` original.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Converte este `Pin<&mut T>` em um `Pin<&T>` com a mesma vida útil.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Obtém uma referência mutável para os dados dentro deste `Pin`.
    ///
    /// Isso requer que os dados dentro deste `Pin` sejam `Unpin`.
    ///
    /// Note: `Pin` também implementa `DerefMut` para os dados, que podem ser usados para acessar o valor interno.
    /// No entanto, o `DerefMut` fornece apenas uma referência que dura enquanto o `Pin` foi emprestado, não a vida útil do próprio `Pin`.
    ///
    /// Este método permite transformar o `Pin` em uma referência com a mesma vida útil do `Pin` original.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Obtém uma referência mutável para os dados dentro deste `Pin`.
    ///
    /// # Safety
    ///
    /// Esta função não é segura.
    /// Você deve garantir que nunca moverá os dados para fora da referência mutável que recebe ao chamar esta função, para que as invariáveis no tipo `Pin` possam ser mantidas.
    ///
    ///
    /// Se os dados subjacentes forem `Unpin`, `Pin::get_mut` deve ser usado em seu lugar.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Construa um novo pino mapeando o valor interno.
    ///
    /// Por exemplo, se você quiser obter um `Pin` de um campo de algo, poderá usar isso para obter acesso a esse campo em uma linha de código.
    /// No entanto, existem vários truques com esses "pinning projections";
    /// consulte a documentação do [`pin` module] para obter mais detalhes sobre esse tópico.
    ///
    /// # Safety
    ///
    /// Esta função não é segura.
    /// Você deve garantir que os dados retornados não se movam, contanto que o valor do argumento não se mova (por exemplo, porque é um dos campos desse valor), e também que você não saia do argumento que recebe para a função interior.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // SEGURANÇA: o chamador é responsável por não mover o
        // valor fora desta referência.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SEGURANÇA: como o valor de `this` é garantido não ter
        // removido, esta chamada para o `new_unchecked` é segura.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Obtenha uma referência fixada de uma referência estática.
    ///
    /// Isso é seguro, porque o `T` é emprestado durante a vida útil do `'static`, que nunca termina.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // SEGURANÇA: O empréstimo estático garante que os dados não serão
        // moved/invalidated até que seja descartado (o que nunca é).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Obtenha uma referência mutável fixada de uma referência mutável estática.
    ///
    /// Isso é seguro, porque o `T` é emprestado durante a vida útil do `'static`, que nunca termina.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // SEGURANÇA: O empréstimo estático garante que os dados não serão
        // moved/invalidated até que seja descartado (o que nunca é).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: isso significa que qualquer impl de `CoerceUnsized` que permite coagir de
// um tipo que impls `Deref<Target=impl !Unpin>` para um tipo que impls `Deref<Target=Unpin>` é incorreto.
// Porém, qualquer desses impls provavelmente seria incorreto por outros motivos, então só precisamos tomar cuidado para não permitir que tais impls pousem em std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}