//! Formatação de números inteiros e de ponto flutuante

use crate::fmt;
use crate::mem::MaybeUninit;
use crate::num::flt2dec;
use crate::ops::{Div, Rem, Sub};
use crate::ptr;
use crate::slice;
use crate::str;

#[doc(hidden)]
trait DisplayInt:
    PartialEq + PartialOrd + Div<Output = Self> + Rem<Output = Self> + Sub<Output = Self> + Copy
{
    fn zero() -> Self;
    fn from_u8(u: u8) -> Self;
    fn to_u8(&self) -> u8;
    fn to_u16(&self) -> u16;
    fn to_u32(&self) -> u32;
    fn to_u64(&self) -> u64;
    fn to_u128(&self) -> u128;
}

macro_rules! impl_int {
    ($($t:ident)*) => (
      $(impl DisplayInt for $t {
          fn zero() -> Self { 0 }
          fn from_u8(u: u8) -> Self { u as Self }
          fn to_u8(&self) -> u8 { *self as u8 }
          fn to_u16(&self) -> u16 { *self as u16 }
          fn to_u32(&self) -> u32 { *self as u32 }
          fn to_u64(&self) -> u64 { *self as u64 }
          fn to_u128(&self) -> u128 { *self as u128 }
      })*
    )
}
macro_rules! impl_uint {
    ($($t:ident)*) => (
      $(impl DisplayInt for $t {
          fn zero() -> Self { 0 }
          fn from_u8(u: u8) -> Self { u as Self }
          fn to_u8(&self) -> u8 { *self as u8 }
          fn to_u16(&self) -> u16 { *self as u16 }
          fn to_u32(&self) -> u32 { *self as u32 }
          fn to_u64(&self) -> u64 { *self as u64 }
          fn to_u128(&self) -> u128 { *self as u128 }
      })*
    )
}

impl_int! { i8 i16 i32 i64 i128 isize }
impl_uint! { u8 u16 u32 u64 u128 usize }

/// Um tipo que representa uma raiz específica
#[doc(hidden)]
trait GenericRadix: Sized {
    /// O número de dígitos.
    const BASE: u8;

    /// Uma string de prefixo específico de raiz.
    const PREFIX: &'static str;

    /// Converte um número inteiro no dígito raiz correspondente.
    fn digit(x: u8) -> u8;

    /// Formate um inteiro usando a raiz usando um formatador.
    fn fmt_int<T: DisplayInt>(&self, mut x: T, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // A raiz pode ser tão baixa quanto 2, então precisamos de um buffer de pelo menos 128 caracteres para um número de base 2.
        //
        let zero = T::zero();
        let is_nonnegative = x >= zero;
        let mut buf = [MaybeUninit::<u8>::uninit(); 128];
        let mut curr = buf.len();
        let base = T::from_u8(Self::BASE);
        if is_nonnegative {
            // Acumule cada dígito do número, do menos significativo para o mais significativo.
            //
            for byte in buf.iter_mut().rev() {
                let n = x % base; // Obtenha o valor atual do lugar.
                x = x / base; // Diminua o número.
                byte.write(Self::digit(n.to_u8())); // Armazene o dígito no buffer.
                curr -= 1;
                if x == zero {
                    // Não há mais dígitos para se acumular.
                    break;
                };
            }
        } else {
            // Faça o mesmo que acima, mas levando em consideração o complemento de dois.
            for byte in buf.iter_mut().rev() {
                let n = zero - (x % base); // Obtenha o valor atual do lugar.
                x = x / base; // Diminua o número.
                byte.write(Self::digit(n.to_u8())); // Armazene o dígito no buffer.
                curr -= 1;
                if x == zero {
                    // Não há mais dígitos para se acumular.
                    break;
                };
            }
        }
        let buf = &buf[curr..];
        // SEGURANÇA: Os únicos caracteres no `buf` são criados pelo `Self::digit` e são considerados
        // UTF-8 válido
        let buf = unsafe {
            str::from_utf8_unchecked(slice::from_raw_parts(
                MaybeUninit::slice_as_ptr(buf),
                buf.len(),
            ))
        };
        f.pad_integral(is_nonnegative, Self::PREFIX, buf)
    }
}

/// Uma raiz binária (base 2)
#[derive(Clone, PartialEq)]
struct Binary;

/// Um radical octal (base 8)
#[derive(Clone, PartialEq)]
struct Octal;

/// Um radical hexadecimal (base 16), formatado com caracteres minúsculos
#[derive(Clone, PartialEq)]
struct LowerHex;

/// Um radical hexadecimal (base 16), formatado com caracteres maiúsculos
#[derive(Clone, PartialEq)]
struct UpperHex;

macro_rules! radix {
    ($T:ident, $base:expr, $prefix:expr, $($x:pat => $conv:expr),+) => {
        impl GenericRadix for $T {
            const BASE: u8 = $base;
            const PREFIX: &'static str = $prefix;
            fn digit(x: u8) -> u8 {
                match x {
                    $($x => $conv,)+
                    x => panic!("number not in the range 0..={}: {}", Self::BASE - 1, x),
                }
            }
        }
    }
}

radix! { Binary,    2, "0b", x @  0 ..=  1 => b'0' + x }
radix! { Octal,     8, "0o", x @  0 ..=  7 => b'0' + x }
radix! { LowerHex, 16, "0x", x @  0 ..=  9 => b'0' + x, x @ 10 ..= 15 => b'a' + (x - 10) }
radix! { UpperHex, 16, "0x", x @  0 ..=  9 => b'0' + x, x @ 10 ..= 15 => b'A' + (x - 10) }

macro_rules! int_base {
    (fmt::$Trait:ident for $T:ident as $U:ident -> $Radix:ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl fmt::$Trait for $T {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                $Radix.fmt_int(*self as $U, f)
            }
        }
    };
}

macro_rules! integer {
    ($Int:ident, $Uint:ident) => {
        int_base! { fmt::Binary   for $Int as $Uint  -> Binary }
        int_base! { fmt::Octal    for $Int as $Uint  -> Octal }
        int_base! { fmt::LowerHex for $Int as $Uint  -> LowerHex }
        int_base! { fmt::UpperHex for $Int as $Uint  -> UpperHex }

        int_base! { fmt::Binary   for $Uint as $Uint -> Binary }
        int_base! { fmt::Octal    for $Uint as $Uint -> Octal }
        int_base! { fmt::LowerHex for $Uint as $Uint -> LowerHex }
        int_base! { fmt::UpperHex for $Uint as $Uint -> UpperHex }
    };
}
integer! { isize, usize }
integer! { i8, u8 }
integer! { i16, u16 }
integer! { i32, u32 }
integer! { i64, u64 }
integer! { i128, u128 }
macro_rules! debug {
    ($($T:ident)*) => {$(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl fmt::Debug for $T {
            #[inline]
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if f.debug_lower_hex() {
                    fmt::LowerHex::fmt(self, f)
                } else if f.debug_upper_hex() {
                    fmt::UpperHex::fmt(self, f)
                } else {
                    fmt::Display::fmt(self, f)
                }
            }
        }
    )*};
}
debug! {
  i8 i16 i32 i64 i128 isize
  u8 u16 u32 u64 u128 usize
}

// Tabela de consulta decimal de 2 dígitos
static DEC_DIGITS_LUT: &[u8; 200] = b"0001020304050607080910111213141516171819\
      2021222324252627282930313233343536373839\
      4041424344454647484950515253545556575859\
      6061626364656667686970717273747576777879\
      8081828384858687888990919293949596979899";

macro_rules! impl_Display {
    ($($t:ident),* as $u:ident via $conv_fn:ident named $name:ident) => {
        fn $name(mut n: $u, is_nonnegative: bool, f: &mut fmt::Formatter<'_>) -> fmt::Result {
            // 2 ^ 128 é cerca de 3 * 10 ^ 38, então 39 dá um byte extra de espaço
            let mut buf = [MaybeUninit::<u8>::uninit(); 39];
            let mut curr = buf.len() as isize;
            let buf_ptr = MaybeUninit::slice_as_mut_ptr(&mut buf);
            let lut_ptr = DEC_DIGITS_LUT.as_ptr();

            // SEGURANÇA: Como `d1` e `d2` são sempre menores ou iguais a `198`, nós
            // pode copiar do `lut_ptr[d1..d1 + 1]` e `lut_ptr[d2..d2 + 1]`.
            // Para mostrar que não há problema em copiar para o `buf_ptr`, observe que no início o `curr == buf.len() == 39 > log(n)` desde o `n < 2^128 < 10^39`, e em cada etapa isso é mantido da mesma forma que o `n` é dividido.
            //
            // Como o `n` é sempre não negativo, isso significa que o `curr > 0`, portanto, o `buf_ptr[curr..curr + 1]` é seguro para acesso.
            //
            //
            unsafe {
                // precisa de pelo menos 16 bits para que os 4 caracteres de cada vez funcionem.
                assert!(crate::mem::size_of::<$u>() >= 2);

                // decodifique avidamente 4 caracteres por vez
                while n >= 10000 {
                    let rem = (n % 10000) as isize;
                    n /= 10000;

                    let d1 = (rem / 100) << 1;
                    let d2 = (rem % 100) << 1;
                    curr -= 4;

                    // Temos permissão para copiar para `buf_ptr[curr..curr + 3]` aqui, caso contrário, `curr < 0`.
                    // Mas então o `n` era originalmente pelo menos `10000^10`, que é o `10^40 > 2^128 > n`.
                    //
                    ptr::copy_nonoverlapping(lut_ptr.offset(d1), buf_ptr.offset(curr), 2);
                    ptr::copy_nonoverlapping(lut_ptr.offset(d2), buf_ptr.offset(curr + 2), 2);
                }

                // se chegarmos aqui, os números são <=9999, portanto, no máximo 4 caracteres
                let mut n = n as isize; // possivelmente reduzirá matemática de 64 bits

                // decodifique mais 2 caracteres, se> 2 caracteres
                if n >= 100 {
                    let d1 = (n % 100) << 1;
                    n /= 100;
                    curr -= 2;
                    ptr::copy_nonoverlapping(lut_ptr.offset(d1), buf_ptr.offset(curr), 2);
                }

                // decodificar os últimos 1 ou 2 caracteres
                if n < 10 {
                    curr -= 1;
                    *buf_ptr.offset(curr) = (n as u8) + b'0';
                } else {
                    let d1 = n << 1;
                    curr -= 2;
                    ptr::copy_nonoverlapping(lut_ptr.offset(d1), buf_ptr.offset(curr), 2);
                }
            }

            // SEGURANÇA: `curr`> 0 (já que tornamos o `buf` grande o suficiente), e todos os caracteres são válidos
            // UTF-8 já que `DEC_DIGITS_LUT` é
            let buf_slice = unsafe {
                str::from_utf8_unchecked(
                    slice::from_raw_parts(buf_ptr.offset(curr), buf.len() - curr as usize))
            };
            f.pad_integral(is_nonnegative, "", buf_slice)
        }

        $(#[stable(feature = "rust1", since = "1.0.0")]
        impl fmt::Display for $t {
            #[allow(unused_comparisons)]
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                let is_nonnegative = *self >= 0;
                let n = if is_nonnegative {
                    self.$conv_fn()
                } else {
                    // converta o número negativo em positivo somando 1 em seu complemento de 2
                    (!self.$conv_fn()).wrapping_add(1)
                };
                $name(n, is_nonnegative, f)
            }
        })*
    };
}

macro_rules! impl_Exp {
    ($($t:ident),* as $u:ident via $conv_fn:ident named $name:ident) => {
        fn $name(
            mut n: $u,
            is_nonnegative: bool,
            upper: bool,
            f: &mut fmt::Formatter<'_>
        ) -> fmt::Result {
            let (mut n, mut exponent, trailing_zeros, added_precision) = {
                let mut exponent = 0;
                // conte e remova os zeros decimais à direita
                while n % 10 == 0 && n >= 10 {
                    n /= 10;
                    exponent += 1;
                }
                let trailing_zeros = exponent;

                let (added_precision, subtracted_precision) = match f.precision() {
                    Some(fmt_prec) => {
                        // número de dígitos decimais menos 1
                        let mut tmp = n;
                        let mut prec = 0;
                        while tmp >= 10 {
                            tmp /= 10;
                            prec += 1;
                        }
                        (fmt_prec.saturating_sub(prec), prec.saturating_sub(fmt_prec))
                    }
                    None => (0,0)
                };
                for _ in 1..subtracted_precision {
                    n/=10;
                    exponent += 1;
                }
                if subtracted_precision != 0 {
                    let rem = n % 10;
                    n /= 10;
                    exponent += 1;
                    // arredondar o último dígito
                    if rem >= 5 {
                        n += 1;
                    }
                }
                (n, exponent, trailing_zeros, added_precision)
            };

            // 39 dígitos (pior caso u128) +.
            // =40 Como o `curr` sempre diminui pelo número de dígitos copiados, isso significa que o `curr >= 0`.
            //
            let mut buf = [MaybeUninit::<u8>::uninit(); 40];
            let mut curr = buf.len() as isize; // índice para buf
            let buf_ptr = MaybeUninit::slice_as_mut_ptr(&mut buf);
            let lut_ptr = DEC_DIGITS_LUT.as_ptr();

            // decodificar 2 caracteres por vez
            while n >= 100 {
                let d1 = ((n % 100) as isize) << 1;
                curr -= 2;
                // SEGURANÇA: `d1 <= 198`, então podemos copiar do `lut_ptr[d1..d1 + 2]` desde
                // `DEC_DIGITS_LUT` tem um comprimento de 200.
                unsafe {
                    ptr::copy_nonoverlapping(lut_ptr.offset(d1), buf_ptr.offset(curr), 2);
                }
                n /= 100;
                exponent += 2;
            }
            // n é <=99, portanto, no máximo 2 caracteres
            let mut n = n as isize; // possivelmente reduzirá matemática de 64 bits
            // decodificar o penúltimo caractere
            if n >= 10 {
                curr -= 1;
                // SEGURANÇA: Seguro desde o `40 > curr >= 0` (ver comentário)
                unsafe {
                    *buf_ptr.offset(curr) = (n as u8 % 10_u8) + b'0';
                }
                n /= 10;
                exponent += 1;
            }
            // adicione o ponto decimal iff> 1 dígito da mantissa será impresso
            if exponent != trailing_zeros || added_precision != 0 {
                curr -= 1;
                // SEGURANÇA: Seguro desde o `40 > curr >= 0`
                unsafe {
                    *buf_ptr.offset(curr) = b'.';
                }
            }

            // SEGURANÇA: Seguro desde o `40 > curr >= 0`
            let buf_slice = unsafe {
                // decodificar o último caractere
                curr -= 1;
                *buf_ptr.offset(curr) = (n as u8) + b'0';

                let len = buf.len() - curr as usize;
                slice::from_raw_parts(buf_ptr.offset(curr), len)
            };

            // armazena 'e' (ou 'E') e o expoente de até 2 dígitos
            let mut exp_buf = [MaybeUninit::<u8>::uninit(); 3];
            let exp_ptr = MaybeUninit::slice_as_mut_ptr(&mut exp_buf);
            // SEGURANÇA: Em ambos os casos, `exp_buf` é escrito dentro dos limites e `exp_ptr[..len]`
            // está contido no `exp_buf` desde o `len <= 3`.
            let exp_slice = unsafe {
                *exp_ptr.offset(0) = if upper {b'E'} else {b'e'};
                let len = if exponent < 10 {
                    *exp_ptr.offset(1) = (exponent as u8) + b'0';
                    2
                } else {
                    let off = exponent << 1;
                    ptr::copy_nonoverlapping(lut_ptr.offset(off), exp_ptr.offset(1), 2);
                    3
                };
                slice::from_raw_parts(exp_ptr, len)
            };

            let parts = &[
                flt2dec::Part::Copy(buf_slice),
                flt2dec::Part::Zero(added_precision),
                flt2dec::Part::Copy(exp_slice)
            ];
            let sign = if !is_nonnegative {
                "-"
            } else if f.sign_plus() {
                "+"
            } else {
                ""
            };
            let formatted = flt2dec::Formatted{sign, parts};
            f.pad_formatted_parts(&formatted)
        }

        $(
            #[stable(feature = "integer_exp_format", since = "1.42.0")]
            impl fmt::LowerExp for $t {
                #[allow(unused_comparisons)]
                fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                    let is_nonnegative = *self >= 0;
                    let n = if is_nonnegative {
                        self.$conv_fn()
                    } else {
                        // converta o número negativo em positivo somando 1 em seu complemento de 2
                        (!self.$conv_fn()).wrapping_add(1)
                    };
                    $name(n, is_nonnegative, false, f)
                }
            })*
        $(
            #[stable(feature = "integer_exp_format", since = "1.42.0")]
            impl fmt::UpperExp for $t {
                #[allow(unused_comparisons)]
                fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                    let is_nonnegative = *self >= 0;
                    let n = if is_nonnegative {
                        self.$conv_fn()
                    } else {
                        // converta o número negativo em positivo somando 1 em seu complemento de 2
                        (!self.$conv_fn()).wrapping_add(1)
                    };
                    $name(n, is_nonnegative, true, f)
                }
            })*
    };
}

// Inclua o wasm32 aqui, pois ele não reflete o tamanho do ponteiro nativo e geralmente se preocupa muito em obter um tamanho de código menor.
//
#[cfg(any(target_pointer_width = "64", target_arch = "wasm32"))]
mod imp {
    use super::*;
    impl_Display!(
        i8, u8, i16, u16, i32, u32, i64, u64, usize, isize
            as u64 via to_u64 named fmt_u64
    );
    impl_Exp!(
        i8, u8, i16, u16, i32, u32, i64, u64, usize, isize
            as u64 via to_u64 named exp_u64
    );
}

#[cfg(not(any(target_pointer_width = "64", target_arch = "wasm32")))]
mod imp {
    use super::*;
    impl_Display!(i8, u8, i16, u16, i32, u32, isize, usize as u32 via to_u32 named fmt_u32);
    impl_Display!(i64, u64 as u64 via to_u64 named fmt_u64);
    impl_Exp!(i8, u8, i16, u16, i32, u32, isize, usize as u32 via to_u32 named exp_u32);
    impl_Exp!(i64, u64 as u64 via to_u64 named exp_u64);
}
impl_Exp!(i128, u128 as u128 via to_u128 named exp_u128);

/// Função auxiliar para escrever um u64 no `buf` do último ao primeiro, com o `curr`.
fn parse_u64_into<const N: usize>(mut n: u64, buf: &mut [MaybeUninit<u8>; N], curr: &mut isize) {
    let buf_ptr = MaybeUninit::slice_as_mut_ptr(buf);
    let lut_ptr = DEC_DIGITS_LUT.as_ptr();
    assert!(*curr > 19);

    // SAFETY:
    // Grava no máximo 19 caracteres no buffer.Garantido que qualquer ptr em LUT é no máximo
    // 198, então nunca OOB.
    // Há uma verificação acima de que há pelo menos 19 caracteres restantes.
    unsafe {
        if n >= 1e16 as u64 {
            let to_parse = n % 1e16 as u64;
            n /= 1e16 as u64;

            // Alguns deles são nops, mas parecem mais elegantes dessa forma.
            let d1 = ((to_parse / 1e14 as u64) % 100) << 1;
            let d2 = ((to_parse / 1e12 as u64) % 100) << 1;
            let d3 = ((to_parse / 1e10 as u64) % 100) << 1;
            let d4 = ((to_parse / 1e8 as u64) % 100) << 1;
            let d5 = ((to_parse / 1e6 as u64) % 100) << 1;
            let d6 = ((to_parse / 1e4 as u64) % 100) << 1;
            let d7 = ((to_parse / 1e2 as u64) % 100) << 1;
            let d8 = ((to_parse / 1e0 as u64) % 100) << 1;

            *curr -= 16;

            ptr::copy_nonoverlapping(lut_ptr.offset(d1 as isize), buf_ptr.offset(*curr + 0), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d2 as isize), buf_ptr.offset(*curr + 2), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d3 as isize), buf_ptr.offset(*curr + 4), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d4 as isize), buf_ptr.offset(*curr + 6), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d5 as isize), buf_ptr.offset(*curr + 8), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d6 as isize), buf_ptr.offset(*curr + 10), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d7 as isize), buf_ptr.offset(*curr + 12), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d8 as isize), buf_ptr.offset(*curr + 14), 2);
        }
        if n >= 1e8 as u64 {
            let to_parse = n % 1e8 as u64;
            n /= 1e8 as u64;

            // Alguns deles são nops, mas parecem mais elegantes dessa forma.
            let d1 = ((to_parse / 1e6 as u64) % 100) << 1;
            let d2 = ((to_parse / 1e4 as u64) % 100) << 1;
            let d3 = ((to_parse / 1e2 as u64) % 100) << 1;
            let d4 = ((to_parse / 1e0 as u64) % 100) << 1;
            *curr -= 8;

            ptr::copy_nonoverlapping(lut_ptr.offset(d1 as isize), buf_ptr.offset(*curr + 0), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d2 as isize), buf_ptr.offset(*curr + 2), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d3 as isize), buf_ptr.offset(*curr + 4), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d4 as isize), buf_ptr.offset(*curr + 6), 2);
        }
        // `n` <1e8 <(1 << 32)
        let mut n = n as u32;
        if n >= 1e4 as u32 {
            let to_parse = n % 1e4 as u32;
            n /= 1e4 as u32;

            let d1 = (to_parse / 100) << 1;
            let d2 = (to_parse % 100) << 1;
            *curr -= 4;

            ptr::copy_nonoverlapping(lut_ptr.offset(d1 as isize), buf_ptr.offset(*curr + 0), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d2 as isize), buf_ptr.offset(*curr + 2), 2);
        }

        // `n` <1e4 <(1 << 16)
        let mut n = n as u16;
        if n >= 100 {
            let d1 = (n % 100) << 1;
            n /= 100;
            *curr -= 2;
            ptr::copy_nonoverlapping(lut_ptr.offset(d1 as isize), buf_ptr.offset(*curr), 2);
        }

        // decodificar os últimos 1 ou 2 caracteres
        if n < 10 {
            *curr -= 1;
            *buf_ptr.offset(*curr) = (n as u8) + b'0';
        } else {
            let d1 = n << 1;
            *curr -= 2;
            ptr::copy_nonoverlapping(lut_ptr.offset(d1 as isize), buf_ptr.offset(*curr), 2);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for u128 {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt_u128(*self, true, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for i128 {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let is_nonnegative = *self >= 0;
        let n = if is_nonnegative {
            self.to_u128()
        } else {
            // converta o número negativo em positivo somando 1 em seu complemento de 2
            (!self.to_u128()).wrapping_add(1)
        };
        fmt_u128(n, is_nonnegative, f)
    }
}

/// Otimização especializada para u128.
/// Em vez de pegar dois itens por vez, ele se divide em no máximo 2 u64s e, em seguida, é dividido em 10e16, 10e8, 10e4, 10e2 e, em seguida, 10e1.
/// Ele também deve lidar com 1 último item, como 10 ^ 40> 2 ^ 128> 10 ^ 39, enquanto
/// 10 ^ 20> 2 ^ 64> 10 ^ 19.
fn fmt_u128(n: u128, is_nonnegative: bool, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    // 2 ^ 128 é cerca de 3 * 10 ^ 38, então 39 dá um byte extra de espaço
    let mut buf = [MaybeUninit::<u8>::uninit(); 39];
    let mut curr = buf.len() as isize;

    let (n, rem) = udiv_1e19(n);
    parse_u64_into(rem, &mut buf, &mut curr);

    if n != 0 {
        // 0 pad até apontar
        let target = (buf.len() - 19) as isize;
        // SEGURANÇA: Garantido que escrevemos no máximo 19 bytes, e deve haver espaço
        // restante, pois tem comprimento de 39
        unsafe {
            ptr::write_bytes(
                MaybeUninit::slice_as_mut_ptr(&mut buf).offset(target),
                b'0',
                (curr - target) as usize,
            );
        }
        curr = target;

        let (n, rem) = udiv_1e19(n);
        parse_u64_into(rem, &mut buf, &mut curr);
        // Deve este branch seguinte ser anotado como improvável?
        if n != 0 {
            let target = (buf.len() - 38) as isize;
            // O ponteiro `buf_ptr` bruto só é válido até que `buf` seja usado da próxima vez, buf `buf` não é usado neste escopo, então estamos bem.
            //
            let buf_ptr = MaybeUninit::slice_as_mut_ptr(&mut buf);
            // SEGURANÇA: neste ponto, escrevemos no máximo 38 bytes, preencha até esse ponto,
            // Só pode haver no máximo 1 dígito restante.
            unsafe {
                ptr::write_bytes(buf_ptr.offset(target), b'0', (curr - target) as usize);
                curr = target - 1;
                *buf_ptr.offset(curr) = (n as u8) + b'0';
            }
        }
    }

    // SEGURANÇA: `curr`> 0 (já que tornamos o `buf` grande o suficiente), e todos os caracteres são válidos
    // UTF-8 já que `DEC_DIGITS_LUT` é
    let buf_slice = unsafe {
        str::from_utf8_unchecked(slice::from_raw_parts(
            MaybeUninit::slice_as_mut_ptr(&mut buf).offset(curr),
            buf.len() - curr as usize,
        ))
    };
    f.pad_integral(is_nonnegative, "", buf_slice)
}

/// Partição de `n` em n> 1e19 e rem <=1e19
///
/// O algoritmo de divisão inteira é baseado no seguinte artigo:
///
///   T. Granlund e P.
///   Montgomery, "Divisão por inteiros invariantes usando multiplicação" in Proc.
///   da SIGPLAN94 Conference on Programming Language Design and Implementation, 1994, pp.
///   61–72
fn udiv_1e19(n: u128) -> (u128, u64) {
    const DIV: u64 = 1e19 as u64;
    const FACTOR: u128 = 156927543384667019095894735580191660403;

    let quot = if n < 1 << 83 {
        ((n >> 19) as u64 / (DIV >> 19)) as u128
    } else {
        u128_mulhi(n, FACTOR) >> 62
    };

    let rem = (n - quot * DIV as u128) as u64;
    (quot, rem)
}

/// Multiplique os inteiros de 128 bits não assinados, retorne os 128 bits superiores do resultado
#[inline]
fn u128_mulhi(x: u128, y: u128) -> u128 {
    let x_lo = x as u64;
    let x_hi = (x >> 64) as u64;
    let y_lo = y as u64;
    let y_hi = (y >> 64) as u64;

    // lidar com a possibilidade de estouro
    let carry = (x_lo as u128 * y_lo as u128) >> 64;
    let m = x_lo as u128 * y_hi as u128 + carry;
    let high1 = m >> 64;

    let m_lo = m as u64;
    let high2 = (x_hi as u128 * y_lo as u128 + m_lo as u128) >> 64;

    x_hi as u128 * y_hi as u128 + high1 + high2
}