//! Este é um módulo interno usado pelo ifmt!tempo de execução.Essas estruturas são emitidas para matrizes estáticas para pré-compilar strings de formato com antecedência.
//!
//! Essas definições são semelhantes aos seus equivalentes `ct`, mas diferem porque podem ser alocados estaticamente e são ligeiramente otimizados para o tempo de execução
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Possíveis alinhamentos que podem ser solicitados como parte de uma diretiva de formatação.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Indicação de que o conteúdo deve ser alinhado à esquerda.
    Left,
    /// Indicação de que o conteúdo deve ser alinhado à direita.
    Right,
    /// Indicação de que o conteúdo deve ser alinhado ao centro.
    Center,
    /// Nenhum alinhamento foi solicitado.
    Unknown,
}

/// Usado pelos especificadores [width](https://doc.rust-lang.org/std/fmt/#width) e [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Especificado com um número literal, armazena o valor
    Is(usize),
    /// Especificado usando as sintaxes `$` e `*`, armazena o índice em `args`
    Param(usize),
    /// Não especificado
    Implied,
}