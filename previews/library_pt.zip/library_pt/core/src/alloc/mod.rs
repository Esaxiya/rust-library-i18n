//! APIs de alocação de memória

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// O erro `AllocError` indica uma falha de alocação que pode ser devido ao esgotamento de recursos ou a algo errado ao combinar os argumentos de entrada fornecidos com este alocador.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (precisamos disso para impl downstream do erro trait)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Uma implementação do `Allocator` pode alocar, aumentar, reduzir e desalocar blocos arbitrários de dados descritos por meio do [`Layout`][].
///
/// `Allocator` foi projetado para ser implementado em ZSTs, referências ou ponteiros inteligentes porque ter um alocador como o `MyAlloc([u8; N])` não pode ser movido, sem atualizar os ponteiros para a memória alocada.
///
/// Ao contrário do [`GlobalAlloc`][], alocações de tamanho zero são permitidas no `Allocator`.
/// Se um alocador subjacente não suportar isso (como jemalloc) ou retornar um ponteiro nulo (como `libc::malloc`), isso deve ser detectado pela implementação.
///
/// ### Memória atualmente alocada
///
/// Alguns dos métodos requerem que um bloco de memória seja *atualmente alocado* por meio de um alocador.Isso significa que:
///
/// * o endereço inicial para esse bloco de memória foi retornado anteriormente por [`allocate`], [`grow`] ou [`shrink`], e
///
/// * o bloco de memória não foi desalocado subsequentemente, onde os blocos são desalocados diretamente ao serem passados para o [`deallocate`] ou alterados ao serem passados para o [`grow`] ou [`shrink`] que retorna o `Ok`.
///
/// Se `grow` ou `shrink` retornou `Err`, o ponteiro passado permanece válido.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Adaptação de memória
///
/// Alguns dos métodos requerem que um layout *se ajuste* a um bloco de memória.
/// O que significa para um layout para "fit" um bloco de memória significa (ou equivalentemente, para um bloco de memória para um layout "fit") é que as seguintes condições devem ser mantidas:
///
/// * O bloco deve ser alocado com o mesmo alinhamento do [`layout.align()`], e
///
/// * O [`layout.size()`] fornecido deve estar no intervalo `min ..= max`, onde:
///   - `min` é o tamanho do layout usado mais recentemente para alocar o bloco, e
///   - `max` é o tamanho real mais recente retornado de [`allocate`], [`grow`] ou [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Os blocos de memória retornados de um alocador devem apontar para a memória válida e reter sua validade até que a instância e todos os seus clones sejam descartados,
///
/// * clonar ou mover o alocador não deve invalidar os blocos de memória retornados deste alocador.Um alocador clonado deve se comportar como o mesmo alocador, e
///
/// * qualquer ponteiro para um bloco de memória que seja [*currently allocated*] pode ser passado para qualquer outro método do alocador.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Tenta alocar um bloco de memória.
    ///
    /// Em caso de sucesso, retorna um [`NonNull<[u8]>`][NonNull] que atende às garantias de tamanho e alinhamento do `layout`.
    ///
    /// O bloco retornado pode ter um tamanho maior do que o especificado pelo `layout.size()` e pode ou não ter seu conteúdo inicializado.
    ///
    /// # Errors
    ///
    /// Retornar `Err` indica que a memória está esgotada ou o `layout` não atende às restrições de tamanho ou alinhamento do alocador.
    ///
    /// As implementações são encorajadas a retornar o `Err` em caso de esgotamento da memória, em vez de entrar em pânico ou abortar, mas esse não é um requisito estrito.
    /// (Especificamente: é *legal* implementar este trait sobre uma biblioteca de alocação nativa subjacente que aborta no esgotamento da memória.)
    ///
    /// Os clientes que desejam abortar a computação em resposta a um erro de alocação são incentivados a chamar a função [`handle_alloc_error`], em vez de invocar diretamente o `panic!` ou similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Se comporta como `allocate`, mas também garante que a memória retornada seja inicializada com zero.
    ///
    /// # Errors
    ///
    /// Retornar `Err` indica que a memória está esgotada ou o `layout` não atende às restrições de tamanho ou alinhamento do alocador.
    ///
    /// As implementações são encorajadas a retornar o `Err` em caso de esgotamento da memória, em vez de entrar em pânico ou abortar, mas esse não é um requisito estrito.
    /// (Especificamente: é *legal* implementar este trait sobre uma biblioteca de alocação nativa subjacente que aborta no esgotamento da memória.)
    ///
    /// Os clientes que desejam abortar a computação em resposta a um erro de alocação são incentivados a chamar a função [`handle_alloc_error`], em vez de invocar diretamente o `panic!` ou similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // SEGURANÇA: `alloc` retorna um bloco de memória válido
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Desaloca a memória referenciada pelo `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` deve denotar um bloco de memória [*currently allocated*] através deste alocador, e
    /// * `layout` deve [*fit*] esse bloco de memória.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Tenta estender o bloco de memória.
    ///
    /// Retorna um novo [`NonNull<[u8]>`][NonNull] contendo um ponteiro e o tamanho real da memória alocada.O ponteiro é adequado para armazenar dados descritos pelo `new_layout`.
    /// Para fazer isso, o alocador pode estender a alocação referenciada pelo `ptr` para se ajustar ao novo layout.
    ///
    /// Se isso retornar `Ok`, a propriedade do bloco de memória referenciado por `ptr` foi transferida para este alocador.
    /// A memória pode ou não ter sido liberada e deve ser considerada inutilizável, a menos que seja transferida de volta para o chamador novamente por meio do valor de retorno deste método.
    ///
    /// Se este método retornar `Err`, a propriedade do bloco de memória não foi transferida para este alocador e o conteúdo do bloco de memória não foi alterado.
    ///
    /// # Safety
    ///
    /// * `ptr` deve denotar um bloco de memória [*currently allocated*] por meio deste alocador.
    /// * `old_layout` deve [*fit*] aquele bloco de memória (O argumento `new_layout` não precisa caber nele.).
    /// * `new_layout.size()` deve ser maior ou igual a `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Retorna `Err` se o novo layout não atender às restrições de tamanho e alinhamento do alocador ou se o crescimento falhar.
    ///
    /// As implementações são encorajadas a retornar o `Err` em caso de esgotamento da memória, em vez de entrar em pânico ou abortar, mas esse não é um requisito estrito.
    /// (Especificamente: é *legal* implementar este trait sobre uma biblioteca de alocação nativa subjacente que aborta no esgotamento da memória.)
    ///
    /// Os clientes que desejam abortar a computação em resposta a um erro de alocação são incentivados a chamar a função [`handle_alloc_error`], em vez de invocar diretamente o `panic!` ou similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SEGURANÇA: porque `new_layout.size()` deve ser maior ou igual a
        // `old_layout.size()`, tanto a alocação de memória antiga quanto a nova são válidas para leituras e gravações de bytes `old_layout.size()`.
        // Além disso, como a alocação antiga ainda não foi desalocada, ela não pode se sobrepor ao `new_ptr`.
        // Portanto, a chamada para o `copy_nonoverlapping` é segura.
        // O contrato de segurança para `dealloc` deve ser mantido pelo chamador.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Se comporta como o `grow`, mas também garante que o novo conteúdo seja definido como zero antes de ser retornado.
    ///
    /// O bloco de memória conterá o seguinte conteúdo após uma chamada bem-sucedida para
    /// `grow_zeroed`:
    ///   * Os bytes `0..old_layout.size()` são preservados da alocação original.
    ///   * Os bytes `old_layout.size()..old_size` serão preservados ou zerados, dependendo da implementação do alocador.
    ///   `old_size` refere-se ao tamanho do bloco de memória anterior à chamada `grow_zeroed`, que pode ser maior do que o tamanho que foi originalmente solicitado quando foi alocado.
    ///   * Bytes `old_size..new_size` são zerados.`new_size` refere-se ao tamanho do bloco de memória retornado pela chamada `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` deve denotar um bloco de memória [*currently allocated*] por meio deste alocador.
    /// * `old_layout` deve [*fit*] aquele bloco de memória (O argumento `new_layout` não precisa caber nele.).
    /// * `new_layout.size()` deve ser maior ou igual a `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Retorna `Err` se o novo layout não atender às restrições de tamanho e alinhamento do alocador ou se o crescimento falhar.
    ///
    /// As implementações são encorajadas a retornar o `Err` em caso de esgotamento da memória, em vez de entrar em pânico ou abortar, mas esse não é um requisito estrito.
    /// (Especificamente: é *legal* implementar este trait sobre uma biblioteca de alocação nativa subjacente que aborta no esgotamento da memória.)
    ///
    /// Os clientes que desejam abortar a computação em resposta a um erro de alocação são incentivados a chamar a função [`handle_alloc_error`], em vez de invocar diretamente o `panic!` ou similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SEGURANÇA: porque `new_layout.size()` deve ser maior ou igual a
        // `old_layout.size()`, tanto a alocação de memória antiga quanto a nova são válidas para leituras e gravações de bytes `old_layout.size()`.
        // Além disso, como a alocação antiga ainda não foi desalocada, ela não pode se sobrepor ao `new_ptr`.
        // Portanto, a chamada para o `copy_nonoverlapping` é segura.
        // O contrato de segurança para `dealloc` deve ser mantido pelo chamador.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Tenta diminuir o bloco de memória.
    ///
    /// Retorna um novo [`NonNull<[u8]>`][NonNull] contendo um ponteiro e o tamanho real da memória alocada.O ponteiro é adequado para armazenar dados descritos pelo `new_layout`.
    /// Para fazer isso, o alocador pode reduzir a alocação referenciada pelo `ptr` para se ajustar ao novo layout.
    ///
    /// Se isso retornar `Ok`, a propriedade do bloco de memória referenciado por `ptr` foi transferida para este alocador.
    /// A memória pode ou não ter sido liberada e deve ser considerada inutilizável, a menos que seja transferida de volta para o chamador novamente por meio do valor de retorno deste método.
    ///
    /// Se este método retornar `Err`, a propriedade do bloco de memória não foi transferida para este alocador e o conteúdo do bloco de memória não foi alterado.
    ///
    /// # Safety
    ///
    /// * `ptr` deve denotar um bloco de memória [*currently allocated*] por meio deste alocador.
    /// * `old_layout` deve [*fit*] aquele bloco de memória (O argumento `new_layout` não precisa caber nele.).
    /// * `new_layout.size()` deve ser menor ou igual a `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Retorna `Err` se o novo layout não atender às restrições de tamanho e alinhamento do alocador ou se a redução falhar.
    ///
    /// As implementações são encorajadas a retornar o `Err` em caso de esgotamento da memória, em vez de entrar em pânico ou abortar, mas esse não é um requisito estrito.
    /// (Especificamente: é *legal* implementar este trait sobre uma biblioteca de alocação nativa subjacente que aborta no esgotamento da memória.)
    ///
    /// Os clientes que desejam abortar a computação em resposta a um erro de alocação são incentivados a chamar a função [`handle_alloc_error`], em vez de invocar diretamente o `panic!` ou similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SEGURANÇA: porque `new_layout.size()` deve ser menor ou igual a
        // `old_layout.size()`, tanto a alocação de memória antiga quanto a nova são válidas para leituras e gravações de bytes `new_layout.size()`.
        // Além disso, como a alocação antiga ainda não foi desalocada, ela não pode se sobrepor ao `new_ptr`.
        // Portanto, a chamada para o `copy_nonoverlapping` é segura.
        // O contrato de segurança para `dealloc` deve ser mantido pelo chamador.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Cria um adaptador "by reference" para esta instância do `Allocator`.
    ///
    /// O adaptador devolvido também implementa o `Allocator` e simplesmente o pegará emprestado.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // SEGURANÇA: o contrato de segurança deve ser respeitado pelo chamador
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEGURANÇA: o contrato de segurança deve ser respeitado pelo chamador
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEGURANÇA: o contrato de segurança deve ser respeitado pelo chamador
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEGURANÇA: o contrato de segurança deve ser respeitado pelo chamador
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}