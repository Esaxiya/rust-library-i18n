use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Um alocador de memória que pode ser registrado como o padrão da biblioteca padrão por meio do atributo `#[global_allocator]`.
///
/// Alguns dos métodos requerem que um bloco de memória seja *atualmente alocado* por meio de um alocador.Isso significa que:
///
/// * o endereço inicial para esse bloco de memória foi retornado anteriormente por uma chamada anterior para um método de alocação, como `alloc`, e
///
/// * o bloco de memória não foi desalocado subsequentemente, onde os blocos são desalocados sendo passados para um método de desalocação como `dealloc` ou sendo passados para um método de realocação que retorna um ponteiro não nulo.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// O `GlobalAlloc` trait é um `unsafe` trait por uma série de razões, e os implementadores devem garantir que cumpram estes contratos:
///
/// * É um comportamento indefinido se os alocadores globais forem desenrolados.Essa restrição pode ser suspensa no future, mas atualmente um panic de qualquer uma dessas funções pode levar à insegurança da memória.
///
/// * `Layout` consultas e cálculos em geral devem ser corretos.Os chamadores deste trait podem confiar nos contratos definidos em cada método, e os implementadores devem garantir que tais contratos permaneçam verdadeiros.
///
/// * Você não pode confiar nas alocações que realmente acontecem, mesmo se houver alocações de heap explícitas na origem.
/// O otimizador pode detectar alocações não utilizadas que pode eliminar totalmente ou mover para a pilha e, portanto, nunca invocar o alocador.
/// O otimizador pode ainda assumir que a alocação é infalível, de modo que o código que costumava falhar devido a falhas do alocador agora pode funcionar repentinamente porque o otimizador contornou a necessidade de uma alocação.
/// Mais concretamente, o exemplo de código a seguir é incorreto, independentemente de seu alocador personalizado permitir a contagem de quantas alocações aconteceram.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Observe que as otimizações mencionadas acima não são as únicas que podem ser aplicadas.Geralmente, você não pode confiar nas alocações de heap que acontecem se elas puderem ser removidas sem alterar o comportamento do programa.
///   O fato de as alocações acontecerem ou não não faz parte do comportamento do programa, mesmo que pudesse ser detectado por meio de um alocador que rastreia as alocações por impressão ou de outra forma tendo efeitos colaterais.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Aloque a memória conforme descrito pelo `layout` fornecido.
    ///
    /// Retorna um ponteiro para a memória recém-alocada ou nulo para indicar falha na alocação.
    ///
    /// # Safety
    ///
    /// Esta função não é segura porque pode ocorrer um comportamento indefinido se o chamador não garantir que o `layout` tenha um tamanho diferente de zero.
    ///
    /// (Subtraits de extensão podem fornecer limites mais específicos no comportamento, por exemplo, garantir um endereço sentinela ou um ponteiro nulo em resposta a uma solicitação de alocação de tamanho zero.)
    ///
    /// O bloco de memória alocado pode ou não ser inicializado.
    ///
    /// # Errors
    ///
    /// Retornar um ponteiro nulo indica que a memória está esgotada ou o `layout` não atende às restrições de tamanho ou alinhamento deste alocador.
    ///
    /// As implementações são encorajadas a retornar nulo no esgotamento da memória ao invés de abortar, mas este não é um requisito estrito.
    /// (Especificamente: é *legal* implementar este trait sobre uma biblioteca de alocação nativa subjacente que aborta no esgotamento da memória.)
    ///
    /// Os clientes que desejam abortar a computação em resposta a um erro de alocação são incentivados a chamar a função [`handle_alloc_error`], em vez de invocar diretamente o `panic!` ou similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Desaloque o bloco de memória no ponteiro `ptr` fornecido com o `layout` fornecido.
    ///
    /// # Safety
    ///
    /// Esta função não é segura porque pode ocorrer um comportamento indefinido se o chamador não garantir todos os itens a seguir:
    ///
    ///
    /// * `ptr` deve denotar um bloco de memória atualmente alocado por meio deste alocador,
    ///
    /// * `layout` deve ser o mesmo layout que foi usado para alocar aquele bloco de memória.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Se comporta como o `alloc`, mas também garante que o conteúdo seja definido como zero antes de ser retornado.
    ///
    /// # Safety
    ///
    /// Esta função não é segura pelos mesmos motivos que o `alloc`.
    /// No entanto, é garantido que o bloco de memória alocado seja inicializado.
    ///
    /// # Errors
    ///
    /// Retornar um ponteiro nulo indica que a memória está esgotada ou o `layout` não atende às restrições de tamanho ou alinhamento do alocador, assim como no `alloc`.
    ///
    /// Os clientes que desejam abortar a computação em resposta a um erro de alocação são incentivados a chamar a função [`handle_alloc_error`], em vez de invocar diretamente o `panic!` ou similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // SEGURANÇA: o contrato de segurança para o `alloc` deve ser respeitado pelo chamador.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // SEGURANÇA: como a alocação foi bem-sucedida, a região do `ptr`
            // do tamanho `size` é garantidamente válido para gravações.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Reduza ou aumente um bloco de memória para o `new_size` fornecido.
    /// O bloco é descrito pelo ponteiro `ptr` e `layout` fornecidos.
    ///
    /// Se isso retornar um ponteiro não nulo, a propriedade do bloco de memória referenciado pelo `ptr` foi transferida para este alocador.
    /// A memória pode ou não ter sido desalocada e deve ser considerada inutilizável (a menos, é claro, que tenha sido transferida de volta para o chamador por meio do valor de retorno deste método).
    /// O novo bloco de memória é alocado com o `layout`, mas com o `size` atualizado para o `new_size`.
    /// Este novo layout deve ser usado ao desalocar o novo bloco de memória com o `dealloc`.
    /// O intervalo `0..min(layout.size(), new_size) `do novo bloco de memória tem a garantia de ter os mesmos valores do bloco original.
    ///
    /// Se este método retornar nulo, a propriedade do bloco de memória não foi transferida para este alocador e o conteúdo do bloco de memória não foi alterado.
    ///
    /// # Safety
    ///
    /// Esta função não é segura porque pode ocorrer um comportamento indefinido se o chamador não garantir todos os itens a seguir:
    ///
    /// * `ptr` deve ser alocado atualmente através deste alocador,
    ///
    /// * `layout` deve ser o mesmo layout que foi usado para alocar aquele bloco de memória,
    ///
    /// * `new_size` deve ser maior que zero.
    ///
    /// * `new_size`, quando arredondado para o múltiplo mais próximo de `layout.align()`, não deve estourar (ou seja, o valor arredondado deve ser menor que `usize::MAX`).
    ///
    /// (Subtraits de extensão podem fornecer limites mais específicos no comportamento, por exemplo, garantir um endereço sentinela ou um ponteiro nulo em resposta a uma solicitação de alocação de tamanho zero.)
    ///
    /// # Errors
    ///
    /// Retorna null se o novo layout não atender às restrições de tamanho e alinhamento do alocador ou se a realocação falhar.
    ///
    /// As implementações são incentivadas a retornar nulo no esgotamento da memória, em vez de entrar em pânico ou abortar, mas esse não é um requisito estrito.
    /// (Especificamente: é *legal* implementar este trait sobre uma biblioteca de alocação nativa subjacente que aborta no esgotamento da memória.)
    ///
    /// Os clientes que desejam abortar a computação em resposta a um erro de realocação são incentivados a chamar a função [`handle_alloc_error`], em vez de invocar diretamente o `panic!` ou similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SEGURANÇA: o chamador deve garantir que o `new_size` não transborde.
        // `layout.align()` vem de um `Layout` e, portanto, tem garantia de validade.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // SEGURANÇA: o chamador deve garantir que `new_layout` seja maior que zero.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // SEGURANÇA: o bloco alocado anteriormente não pode se sobrepor ao bloco recém-alocado.
            // O contrato de segurança para `dealloc` deve ser mantido pelo chamador.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}