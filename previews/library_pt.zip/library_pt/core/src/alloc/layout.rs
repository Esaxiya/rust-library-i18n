use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Embora essa função seja usada em um lugar e sua implementação possa ser sequencial, as tentativas anteriores de fazer isso tornaram rustc mais lento:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Layout de um bloco de memória.
///
/// Uma instância do `Layout` descreve um layout específico de memória.
/// Você constrói um `Layout` como uma entrada para fornecer a um alocador.
///
/// Todos os layouts têm um tamanho associado e um alinhamento de potência de dois.
///
/// (Observe que *não* é necessário que os layouts tenham tamanho diferente de zero, embora o `GlobalAlloc` exija que todas as solicitações de memória tenham tamanho diferente de zero.
/// Um chamador deve garantir que condições como essa sejam atendidas, usar alocadores específicos com requisitos mais flexíveis ou usar a interface `Allocator` mais tolerante.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // tamanho do bloco de memória solicitado, medido em bytes.
    size_: usize,

    // alinhamento do bloco de memória solicitado, medido em bytes.
    // garantimos que esta seja sempre uma potência de dois, porque APIs como o `posix_memalign` exigem isso e é uma restrição razoável para impor aos construtores de layout.
    //
    //
    // (No entanto, não exigimos analogamente `alinhar>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Constrói um `Layout` a partir de um determinado `size` e `align` ou retorna `LayoutError` se qualquer uma das seguintes condições não for atendida:
    ///
    /// * `align` não deve ser zero,
    ///
    /// * `align` deve ser uma potência de dois,
    ///
    /// * `size`, quando arredondado para o múltiplo mais próximo de `align`, não deve estourar (ou seja, o valor arredondado deve ser menor ou igual a `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (potência de dois implica alinhar!=0)

        // O tamanho arredondado é:
        //   size_rounded_up=(tamanho + alinhar, 1)&! (alinhar, 1);
        //
        // Sabemos de cima que align!=0.
        // Se adicionar (alinhar, 1) não transbordar, arredondar para cima será suficiente.
        //
        // Inversamente,&-mascarar com! (Alinhar, 1) subtrairá apenas os bits de ordem inferior.
        // Portanto, se ocorrer estouro com a soma, a máscara&não pode subtrair o suficiente para desfazer esse estouro.
        //
        //
        // Acima implica que a verificação de estouro de soma é necessária e suficiente.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // SEGURANÇA: as condições para `from_size_align_unchecked` foram
        // verificado acima.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Cria um layout, ignorando todas as verificações.
    ///
    /// # Safety
    ///
    /// Esta função não é segura, pois não verifica as pré-condições do [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // SEGURANÇA: o chamador deve garantir que `align` seja maior que zero.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// O tamanho mínimo em bytes para um bloco de memória deste layout.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// O alinhamento mínimo de bytes para um bloco de memória deste layout.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Constrói um `Layout` adequado para armazenar um valor do tipo `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // SEGURANÇA: o alinhamento é garantido por Rust como uma potência de dois e
        // a combinação tamanho + alinhamento tem a garantia de caber em nosso espaço de endereço.
        // Como resultado, use o construtor não verificado aqui para evitar a inserção de código que panics se não estiver otimizado o suficiente.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produz um layout que descreve um registro que pode ser usado para alocar uma estrutura de apoio para o `T` (que pode ser um trait ou outro tipo não dimensionado como um slice).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SEGURANÇA: veja a justificativa no `new` para saber por que está usando a variante insegura
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produz um layout que descreve um registro que pode ser usado para alocar uma estrutura de apoio para o `T` (que pode ser um trait ou outro tipo não dimensionado como um slice).
    ///
    /// # Safety
    ///
    /// Essa função só pode ser chamada com segurança se as seguintes condições forem mantidas:
    ///
    /// - Se `T` for `Sized`, é sempre seguro chamar esta função.
    /// - Se a cauda não dimensionada do `T` for:
    ///     - um [slice], então o comprimento da cauda da fatia deve ser um inteiro inicializado e o tamanho do *valor inteiro*(comprimento da cauda dinâmica + prefixo de tamanho estático) deve caber em `isize`.
    ///     - um [trait object], então a parte vtable do ponteiro deve apontar para uma vtable válida para o tipo `T` adquirido por uma coersão de desdimensionamento, e o tamanho do *valor inteiro*(comprimento da cauda dinâmica + prefixo de tamanho estático) deve caber em `isize`.
    ///
    ///     - um (unstable) [extern type], então esta função é sempre segura para chamar, mas pode panic ou de outra forma retornar o valor errado, pois o layout do tipo externo não é conhecido.
    ///     Este é o mesmo comportamento do [`Layout::for_value`] em uma referência a uma cauda de tipo externo.
    ///     - caso contrário, não é permitido, de maneira conservadora, chamar essa função.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // SEGURANÇA: passamos os pré-requisitos dessas funções ao chamador
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SEGURANÇA: veja a justificativa no `new` para saber por que está usando a variante insegura
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Cria um `NonNull` pendente, mas bem alinhado para este Layout.
    ///
    /// Observe que o valor do ponteiro pode representar potencialmente um ponteiro válido, o que significa que ele não deve ser usado como um valor sentinela "not yet initialized".
    /// Os tipos que alocam lentamente devem rastrear a inicialização por algum outro meio.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // SEGURANÇA: o alinhamento tem garantia de ser diferente de zero
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Cria um layout que descreve o registro que pode conter um valor do mesmo layout de `self`, mas que também é alinhado ao alinhamento `align` (medido em bytes).
    ///
    ///
    /// Se o `self` já atende ao alinhamento prescrito, retorna o `self`.
    ///
    /// Observe que esse método não adiciona nenhum preenchimento ao tamanho geral, independentemente de o layout retornado ter um alinhamento diferente.
    /// Em outras palavras, se o `K` tiver o tamanho 16, o `K.align_to(32)`*ainda* terá o tamanho 16.
    ///
    /// Retorna um erro se a combinação de `self.size()` e o `align` fornecido violar as condições listadas em [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Retorna a quantidade de preenchimento que devemos inserir após `self` para garantir que o endereço a seguir satisfaça `align` (medido em bytes).
    ///
    /// por exemplo, se `self.size()` for 9, então `self.padding_needed_for(4)` retornará 3, porque esse é o número mínimo de bytes de preenchimento necessário para obter um endereço alinhado 4 (assumindo que o bloco de memória correspondente comece em um endereço alinhado 4).
    ///
    ///
    /// O valor de retorno desta função não tem significado se `align` não for uma potência de dois.
    ///
    /// Observe que a utilidade do valor retornado requer que `align` seja menor ou igual ao alinhamento do endereço inicial para todo o bloco de memória alocado.Uma maneira de satisfazer essa restrição é garantir o `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // O valor arredondado é:
        //   len_rounded_up=(len + alinhar, 1)&! (alinhar, 1);
        // e então retornamos a diferença de preenchimento: `len_rounded_up - len`.
        //
        // Usamos aritmética modular em:
        //
        // 1. Alinhar é garantido como> 0, então alinhe, 1 é sempre válido.
        //
        // 2.
        // `len + align - 1` pode estourar em no máximo `align - 1`, então a máscara&com `!(align - 1)` garantirá que, no caso de estouro, o próprio `len_rounded_up` será 0.
        //
        //    Portanto, o preenchimento retornado, quando adicionado ao `len`, resulta em 0, o que satisfaz trivialmente o alinhamento `align`.
        //
        // (Obviamente, as tentativas de alocar blocos de memória cujo tamanho e preenchimento estouram da maneira acima devem fazer com que o alocador produza um erro de qualquer maneira.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Cria um layout arredondando o tamanho desse layout até um múltiplo do alinhamento do layout.
    ///
    ///
    /// Isso é equivalente a adicionar o resultado de `padding_needed_for` ao tamanho atual do layout.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Isso não pode transbordar.Citando o invariante de Layout:
        // > `size`, quando arredondado para o múltiplo mais próximo de `align`,
        // > não deve estourar (ou seja, o valor arredondado deve ser menor que
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Cria um layout que descreve o registro para instâncias `n` de `self`, com uma quantidade adequada de preenchimento entre cada uma para garantir que cada instância receba seu tamanho e alinhamento solicitados.
    /// Em caso de sucesso, retorna `(k, offs)`, onde `k` é o layout do array e `offs` é a distância entre o início de cada elemento do array.
    ///
    /// Em estouro aritmético, retorna `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Isso não pode transbordar.Citando o invariante de Layout:
        // > `size`, quando arredondado para o múltiplo mais próximo de `align`,
        // > não deve estourar (ou seja, o valor arredondado deve ser menor que
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // SEGURANÇA: self.align já é conhecido por ser válido e aloc_size foi
        // já acolchoado.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Cria um layout que descreve o registro para `self` seguido por `next`, incluindo qualquer preenchimento necessário para garantir que o `next` seja alinhado corretamente, mas *nenhum preenchimento final*.
    ///
    /// Para corresponder ao layout de representação C `repr(C)`, você deve chamar `pad_to_align` após estender o layout com todos os campos.
    /// (Não há como combinar o layout de representação padrão Rust `repr(Rust)`, as it is unspecified.)
    ///
    /// Observe que o alinhamento do layout resultante será o máximo do `self` e `next`, a fim de garantir o alinhamento de ambas as partes.
    ///
    /// Retorna `Ok((k, offset))`, onde `k` é o layout do registro concatenado e `offset` é a localização relativa, em bytes, do início do `next` incorporado no registro concatenado (supondo que o próprio registro comece no deslocamento 0).
    ///
    ///
    /// Em estouro aritmético, retorna `LayoutError`.
    ///
    /// # Examples
    ///
    /// Para calcular o layout de uma estrutura `#[repr(C)]` e os deslocamentos dos campos dos layouts de seus campos:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Lembre-se de finalizar com o `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // teste se funciona
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Cria um layout que descreve o registro para instâncias `n` de `self`, sem preenchimento entre cada instância.
    ///
    /// Observe que, ao contrário do `repeat`, o `repeat_packed` não garante que as instâncias repetidas do `self` sejam alinhadas corretamente, mesmo se uma determinada instância do `self` estiver alinhada corretamente.
    /// Em outras palavras, se o layout retornado pelo `repeat_packed` for usado para alocar um array, não há garantia de que todos os elementos do array serão alinhados corretamente.
    ///
    /// Em estouro aritmético, retorna `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Cria um layout que descreve o registro para `self` seguido por `next` sem preenchimento adicional entre os dois.
    /// Como nenhum preenchimento é inserido, o alinhamento do `next` é irrelevante e não é incorporado *de forma alguma* no layout resultante.
    ///
    ///
    /// Em estouro aritmético, retorna `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Cria um layout que descreve o registro de um `[T; n]`.
    ///
    /// Em estouro aritmético, retorna `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Os parâmetros fornecidos ao `Layout::from_size_align` ou a algum outro construtor `Layout` não satisfazem suas restrições documentadas.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (precisamos disso para impl downstream do erro trait)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}