//! Conversões de personagens.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Converte um `u32` em um `char`.
///
/// Observe que todos os [`char`] s são [`u32`] s válidos e podem ser convertidos em um com
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// No entanto, o inverso não é verdadeiro: nem todos os [`u32`] s válidos são [`char`] s válidos.
/// `from_u32()` retornará `None` se a entrada não for um valor válido para um [`char`].
///
/// Para obter uma versão não segura dessa função que ignora essas verificações, consulte [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Retornando `None` quando a entrada não é um [`char`] válido:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Converte um `u32` em um `char`, ignorando a validade.
///
/// Observe que todos os [`char`] s são [`u32`] s válidos e podem ser convertidos em um com
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// No entanto, o inverso não é verdadeiro: nem todos os [`u32`] s válidos são [`char`] s válidos.
/// `from_u32_unchecked()` irá ignorar isso e lançar cegamente para o [`char`], possivelmente criando um inválido.
///
///
/// # Safety
///
/// Esta função não é segura, pois pode construir valores `char` inválidos.
///
/// Para obter uma versão segura desta função, consulte a função [`from_u32`].
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // SEGURANÇA: o chamador deve garantir que `i` é um valor de char válido.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Converte um [`char`] em um [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Converte um [`char`] em um [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // O char é convertido para o valor do ponto de código e, em seguida, estendido de zero para 64 bits.
        // Veja [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Converte um [`char`] em um [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // O char é convertido para o valor do ponto de código e, em seguida, estendido com zero para 128 bits.
        // Veja [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Mapeia um byte em 0x00 ..=0xFF para um `char` cujo ponto de código tem o mesmo valor, em U + 0000 ..=U + 00FF.
///
/// O Unicode é projetado de forma que decodifique efetivamente os bytes com a codificação de caracteres que a IANA chama de ISO-8859-1.
/// Esta codificação é compatível com ASCII.
///
/// Observe que isso é diferente do ISO/IEC 8859-1, também conhecido como
/// ISO 8859-1 (com um hífen a menos), o que deixa alguns valores de byte "blanks" que não são atribuídos a nenhum caractere.
/// ISO-8859-1 (o da IANA) os atribui aos códigos de controle C0 e C1.
///
/// Observe que isso é *também* diferente do Windows-1252, também conhecido como
/// página de código 1252, que é um superconjunto ISO/IEC 8859-1 que atribui alguns (não todos!) espaços em branco à pontuação e vários caracteres latinos.
///
/// Para confundir ainda mais as coisas, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` e `windows-1252` são todos apelidos para um superconjunto do Windows-1252 que preenche os espaços em branco restantes com os códigos de controle C0 e C1 correspondentes.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Converte um [`u8`] em um [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Um erro que pode ser retornado ao analisar um char.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // SEGURANÇA: verificado se é um valor Unicode legal
            Ok(unsafe { transmute(i) })
        }
    }
}

/// O tipo de erro retornado quando uma conversão de u32 para char falha.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Converte um dígito na raiz fornecida em um `char`.
///
/// Um 'radix' aqui às vezes também é chamado de 'base'.
/// Uma raiz de dois indica um número binário, uma raiz de dez, decimal, e uma raiz de dezesseis, hexadecimal, para fornecer alguns valores comuns.
///
/// Radices arbitrários são suportados.
///
/// `from_digit()` retornará `None` se a entrada não for um dígito na raiz fornecida.
///
/// # Panics
///
/// Panics se dado um radical maior que 36.
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // 11 decimal é um único dígito na base 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Retornando `None` quando a entrada não é um dígito:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Passando por um grande radix, causando um panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}