#![stable(feature = "core_hint", since = "1.27.0")]

//! Dicas para o compilador que afetam como o código deve ser emitido ou otimizado.
//! As dicas podem ser tempo de compilação ou tempo de execução.

use crate::intrinsics;

/// Informa ao compilador que este ponto do código não é alcançável, possibilitando novas otimizações.
///
/// # Safety
///
/// Alcançar essa função é completamente *comportamento indefinido*(UB).Em particular, o compilador assume que todos os UB nunca devem acontecer e, portanto, eliminará todas as ramificações que chegam a uma chamada para o `unreachable_unchecked()`.
///
/// Como todas as instâncias de UB, se essa suposição estiver errada, ou seja, a chamada `unreachable_unchecked()` é realmente alcançável entre todos os fluxos de controle possíveis, o compilador aplicará a estratégia de otimização errada e pode às vezes até corromper o código aparentemente não relacionado, dificultando problemas para depurar.
///
///
/// Use esta função apenas quando puder provar que o código nunca a chamará.
/// Caso contrário, considere usar a macro [`unreachable!`], que não permite otimizações, mas irá panic quando executada.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` é sempre positivo (diferente de zero), portanto, `checked_div` nunca retornará `None`.
/////
///     // Portanto, o outro branch é inacessível.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // SEGURANÇA: o contrato de segurança para `intrinsics::unreachable` deve
    // ser confirmado pelo chamador.
    unsafe { intrinsics::unreachable() }
}

/// Emite uma instrução de máquina para sinalizar ao processador que ele está executando em um loop de rotação de espera ocupada ("bloqueio de rotação").
///
/// Ao receber o sinal de loop de rotação, o processador pode otimizar seu comportamento, por exemplo, economizando energia ou alternando threads hyper.
///
/// Esta função é diferente do [`thread::yield_now`] que cede diretamente ao programador do sistema, enquanto o `spin_loop` não interage com o sistema operacional.
///
/// Um caso de uso comum para o `spin_loop` é implementar a rotação otimista limitada em um loop CAS em primitivas de sincronização.
/// Para evitar problemas como inversão de prioridade, é altamente recomendado que o loop de rotação seja encerrado após uma quantidade finita de iterações e uma syscall de bloqueio apropriada seja feita.
///
///
/// **Nota**: Em plataformas que não suportam o recebimento de dicas de loop de rotação, essa função não faz nada.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Um valor atômico compartilhado que os threads usarão para coordenar
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Em um thread de segundo plano, definiremos o valor
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Faça algum trabalho e, em seguida, faça o valor viver
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // De volta ao nosso tópico atual, esperamos que o valor seja definido
/// while !live.load(Ordering::Acquire) {
///     // O loop de rotação é uma dica para a CPU de que estamos esperando, mas provavelmente não por muito tempo
/////
///     hint::spin_loop();
/// }
///
/// // O valor agora está definido
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // SEGURANÇA: o `cfg` attr garante que só executemos isso em destinos x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // SEGURANÇA: o `cfg` attr garante que só executemos isso em destinos x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // SEGURANÇA: o `cfg` attr garante que só executemos isso em destinos aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // SEGURANÇA: o `cfg` attr garante que só executemos isso em alvos de braço
            // com suporte para o recurso v6.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Uma função de identidade que *__ indica __* para o compilador ser o mais pessimista sobre o que o `black_box` pode fazer.
///
/// Ao contrário do [`std::convert::identity`], um compilador Rust é encorajado a assumir que o `black_box` pode usar o `dummy` de qualquer maneira válida possível que o código Rust tenha permissão para usar, sem introduzir um comportamento indefinido no código de chamada.
///
/// Esta propriedade torna o `black_box` útil para escrever código no qual certas otimizações não são desejadas, como benchmarks.
///
/// Observe, entretanto, que o `black_box` é (e só pode ser) fornecido com base no "best-effort".A extensão em que ele pode bloquear otimizações pode variar dependendo da plataforma e do back-end de geração de código usado.
/// Os programas não podem depender do `black_box` para *correção* de forma alguma.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Precisamos "use" o argumento de alguma forma que o LLVM não pode introspectar, e em alvos que o suportam, podemos tipicamente alavancar o assembly embutido para fazer isso.
    // A interpretação do LLVM de assembly embutido é que é, bem, uma caixa preta.
    // Esta não é a melhor implementação, pois provavelmente desotimiza mais do que desejamos, mas até agora é boa o suficiente.
    //
    //

    #[cfg(not(miri))] // Esta é apenas uma dica, então não há problema em pular em Miri.
    // SEGURANÇA: o assembly inline é autônomo.
    unsafe {
        // FIXME: Não é possível usar `asm!` porque não oferece suporte a MIPS e outras arquiteturas.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}