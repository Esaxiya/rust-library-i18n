#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Um future representa uma computação assíncrona.
///
/// Um future é um valor que pode não ter concluído o cálculo ainda.
/// Esse tipo de "asynchronous value" possibilita que um thread continue realizando um trabalho útil enquanto aguarda o valor ficar disponível.
///
///
/// # O método `poll`
///
/// O método principal de future, `poll`,*tenta* resolver o future em um valor final.
/// Este método não bloqueia se o valor não estiver pronto.
/// Em vez disso, a tarefa atual é agendada para ser ativada quando for possível fazer mais progresso ao `sondar` novamente.
/// O `context` passado para o método `poll` pode fornecer um [`Waker`], que é um identificador para ativar a tarefa atual.
///
/// Ao usar um future, você geralmente não chamará `poll` diretamente, mas sim `.await` o valor.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// O tipo de valor produzido na conclusão.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Tente resolver o future para um valor final, registrando a tarefa atual para despertar se o valor ainda não estiver disponível.
    ///
    /// # Valor de retorno
    ///
    /// Esta função retorna:
    ///
    /// - [`Poll::Pending`] se o future ainda não está pronto
    /// - [`Poll::Ready(val)`] com o resultado `val` deste future se tiver terminado com sucesso.
    ///
    /// Depois que um future for concluído, os clientes não devem `poll` novamente.
    ///
    /// Quando um future ainda não está pronto, o `poll` retorna o `Poll::Pending` e armazena um clone do [`Waker`] copiado do [`Context`] atual.
    /// Este [`Waker`] é então ativado quando o future pode fazer progresso.
    /// Por exemplo, um future esperando que um soquete se torne legível chamaria o `.clone()` no [`Waker`] e o armazenaria.
    /// Quando um sinal chega em outro lugar indicando que o soquete está legível, [`Waker::wake`] é chamado e a tarefa do soquete future é ativada.
    /// Assim que uma tarefa for ativada, ela deve tentar `poll` o future novamente, o que pode ou não produzir um valor final.
    ///
    /// Observe que em várias chamadas para o `poll`, apenas o [`Waker`] do [`Context`] passado para a chamada mais recente deve ser agendado para receber um despertador.
    ///
    /// # Características de tempo de execução
    ///
    /// Futures sozinho são *inertes*;eles devem ser *ativamente*`sondados` para progredir, o que significa que cada vez que a tarefa atual é ativada, ela deve re-`pollar` ativamente o futures pendente no qual ainda tem interesse.
    ///
    /// A função `poll` não é chamada repetidamente em um loop fechado-em vez disso, ela só deve ser chamada quando o future indica que está pronto para fazer progresso (chamando o `wake()`).
    /// Se você estiver familiarizado com as syscalls `poll(2)` ou `select(2)` no Unix, é importante notar que o futures normalmente *não* sofre os mesmos problemas do "all wakeups must poll all events";eles são mais parecidos com o `epoll(4)`.
    ///
    /// Uma implementação do `poll` deve se esforçar para retornar rapidamente e não deve ser bloqueada.O retorno rápido evita o entupimento desnecessário de threads ou loops de eventos.
    /// Se for sabido com antecedência que uma chamada para o `poll` pode demorar um pouco, o trabalho deve ser transferido para um pool de threads (ou algo semelhante) para garantir que o `poll` possa retornar rapidamente.
    ///
    /// # Panics
    ///
    /// Depois que um future for concluído (retornado `Ready` de `poll`), chamar seu método `poll` novamente pode panic, bloquear para sempre ou causar outros tipos de problemas;o `Future` trait não impõe requisitos sobre os efeitos de tal chamada.
    /// No entanto, como o método `poll` não está marcado como `unsafe`, as regras usuais de Rust se aplicam: as chamadas nunca devem causar comportamento indefinido (corrupção de memória, uso incorreto de funções `unsafe` ou semelhantes), independentemente do estado do future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}