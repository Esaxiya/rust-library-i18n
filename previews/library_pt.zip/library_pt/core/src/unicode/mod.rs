#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// A versão do [Unicode](http://www.unicode.org/) na qual as partes Unicode dos métodos `char` e `str` se baseiam.
///
/// Novas versões do Unicode são lançadas regularmente e, subsequentemente, todos os métodos na biblioteca padrão dependendo do Unicode são atualizados.
/// Portanto, o comportamento de alguns métodos `char` e `str` e o valor dessa constante mudam com o tempo.
/// Isso *não* é considerado uma alteração significativa.
///
/// O esquema de numeração de versão é explicado no [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// Para uso em liballoc, não reexportado em libstd.
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;