//! O libcore prelude
//!
//! Este módulo é destinado a usuários de libcore que também não possuem links para libstd.
//! Este módulo é importado por padrão quando o `#![no_std]` é usado da mesma maneira que o prelude da biblioteca padrão.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// A versão 2015 do núcleo prelude.
///
/// Consulte o [module-level documentation](self) para obter mais informações.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// A versão 2018 do núcleo prelude.
///
/// Consulte o [module-level documentation](self) para obter mais informações.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// A versão 2021 do núcleo prelude.
///
/// Consulte o [module-level documentation](self) para obter mais informações.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Adicione mais coisas.
}