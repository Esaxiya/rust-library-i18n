//! Um módulo para trabalhar com dados emprestados.

#![stable(feature = "rust1", since = "1.0.0")]

/// Um trait para dados de empréstimo.
///
/// Em Rust, é comum fornecer diferentes representações de um tipo para diferentes casos de uso.
/// Por exemplo, o local de armazenamento e o gerenciamento de um valor podem ser escolhidos especificamente como apropriados para um uso específico por meio de tipos de ponteiro, como [`Box<T>`] ou [`Rc<T>`].
/// Além desses invólucros genéricos que podem ser usados com qualquer tipo, alguns tipos fornecem facetas opcionais que fornecem funcionalidade potencialmente cara.
/// Um exemplo desse tipo é o [`String`], que adiciona a capacidade de estender uma string ao [`str`] básico.
/// Isso requer manter informações adicionais desnecessárias para uma string simples e imutável.
///
/// Esses tipos fornecem acesso aos dados subjacentes por meio de referências ao tipo desses dados.Diz-se que são "emprestados" desse tipo.
/// Por exemplo, um [`Box<T>`] pode ser emprestado como `T` enquanto um [`String`] pode ser emprestado como `str`.
///
/// Os tipos expressam que podem ser emprestados como algum tipo `T` implementando `Borrow<T>`, fornecendo uma referência a um `T` no método [`borrow`] do trait.Um tipo pode ser emprestado gratuitamente como vários tipos diferentes.
/// Se desejar emprestar mutably como o tipo-permitindo que os dados subjacentes sejam modificados, ele pode implementar adicionalmente o [`BorrowMut<T>`].
///
/// Além disso, ao fornecer implementações para traits adicionais, é necessário considerar se eles devem se comportar idênticos aos do tipo subjacente como consequência de atuar como uma representação desse tipo subjacente.
/// O código genérico normalmente usa `Borrow<T>` quando se baseia no comportamento idêntico dessas implementações trait adicionais.
/// Esses traits provavelmente aparecerão como trait bounds adicionais.
///
/// Em particular, `Eq`, `Ord` e `Hash` devem ser equivalentes para valores emprestados e possuídos: `x.borrow() == y.borrow()` deve fornecer o mesmo resultado que `x == y`.
///
/// Se o código genérico precisa apenas funcionar para todos os tipos que podem fornecer uma referência ao tipo relacionado `T`, geralmente é melhor usar o [`AsRef<T>`], pois mais tipos podem implementá-lo com segurança.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Como uma coleção de dados, o [`HashMap<K, V>`] possui chaves e valores.Se os dados reais da chave estiverem agrupados em algum tipo de gerenciamento, ainda deve ser possível pesquisar um valor usando uma referência aos dados da chave.
/// Por exemplo, se a chave for uma string, ela provavelmente será armazenada com o mapa hash como um [`String`], embora seja possível pesquisar usando um [`&str`][`str`].
/// Portanto, o `insert` precisa operar em um `String` enquanto o `get` precisa ser capaz de usar um `&str`.
///
/// Ligeiramente simplificado, as partes relevantes do `HashMap<K, V>` são assim:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // campos omitidos
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Todo o mapa hash é genérico sobre um tipo de chave `K`.Como essas chaves são armazenadas com o mapa hash, esse tipo deve possuir os dados da chave.
/// Ao inserir um par de valores-chave, o mapa recebe um `K` e precisa encontrar o intervalo de hash correto e verificar se a chave já está presente com base nesse `K`.Portanto, requer `K: Hash + Eq`.
///
/// Ao pesquisar um valor no mapa, no entanto, ter que fornecer uma referência a um `K` como a chave a ser pesquisada exigiria sempre criar esse valor de propriedade.
/// Para chaves de string, isso significaria que um valor `String` precisa ser criado apenas para a pesquisa de casos em que apenas um `str` está disponível.
///
/// Em vez disso, o método `get` é genérico em relação ao tipo dos dados de chave subjacentes, chamados de `Q` na assinatura do método acima.Ele afirma que o `K` é emprestado como um `Q` ao exigir esse `K: Borrow<Q>`.
/// Ao exigir adicionalmente o `Q: Hash + Eq`, ele sinaliza o requisito de que o `K` e o `Q` tenham implementações do `Hash` e `Eq` traits que produzem resultados idênticos.
///
/// A implementação de `get` depende em particular de implementações idênticas de `Hash` determinando o intervalo de hash da chave chamando `Hash::hash` no valor `Q`, embora ele tenha inserido a chave com base no valor hash calculado a partir do valor `K`.
///
///
/// Como consequência, o mapa de hash será quebrado se um `K` envolvendo um valor `Q` produzir um hash diferente do `Q`.Por exemplo, imagine que você tem um tipo que envolve uma string, mas compara letras ASCII ignorando suas maiúsculas e minúsculas:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Como dois valores iguais precisam produzir o mesmo valor de hash, a implementação do `Hash` também precisa ignorar maiúsculas e minúsculas ASCII:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// O `CaseInsensitiveString` pode implementar o `Borrow<str>`?Certamente pode fornecer uma referência a uma fatia de string por meio de sua string de propriedade contida.
/// Mas, como a implementação do `Hash` é diferente, ele se comporta de maneira diferente do `str` e, portanto, não deve, de fato, implementar o `Borrow<str>`.
/// Se quiser permitir que outros acessem o `str` subjacente, ele pode fazer isso por meio do `AsRef<str>`, que não carrega nenhum requisito extra.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Imutavelmente toma emprestado de um valor de propriedade.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// Um trait para dados mutáveis de empréstimo.
///
/// Como um companheiro para [`Borrow<T>`], este trait permite que um tipo seja emprestado como um tipo subjacente, fornecendo uma referência mutável.
/// Consulte [`Borrow<T>`] para obter mais informações sobre empréstimos de outro tipo.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Empresta mutuamente de um valor de propriedade.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}