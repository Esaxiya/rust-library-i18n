//! traits primitivos e tipos que representam propriedades básicas de tipos.
//!
//! Os tipos Rust podem ser classificados de várias maneiras úteis de acordo com suas propriedades intrínsecas.
//! Essas classificações são representadas como traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Tipos que podem ser transferidos através dos limites do thread.
///
/// Este trait é implementado automaticamente quando o compilador determina que é apropriado.
///
/// Um exemplo de um tipo não `Enviar` é o ponteiro de contagem de referência [`rc::Rc`][`Rc`].
/// Se dois threads tentarem clonar [`Rc`] s que apontam para o mesmo valor de contagem de referência, eles podem tentar atualizar a contagem de referência ao mesmo tempo, que é [undefined behavior][ub] porque [`Rc`] não usa operações atômicas.
///
/// Seu primo [`sync::Arc`][arc] usa operações atômicas (incorrendo em alguma sobrecarga) e, portanto, é o `Send`.
///
/// Consulte [the Nomicon](../../nomicon/send-and-sync.html) para obter mais detalhes.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Tipos com tamanho constante conhecido em tempo de compilação.
///
/// Todos os parâmetros de tipo têm um limite implícito de `Sized`.A sintaxe especial `?Sized` pode ser usada para remover esse limite se não for apropriado.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//erro: Sized não implementado para [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// A única exceção é o tipo `Self` implícito de um trait.
/// Um trait não tem um limite `Sized` implícito, pois isso é incompatível com [trait object] s onde, por definição, o trait precisa trabalhar com todos os implementadores possíveis e, portanto, pode ter qualquer tamanho.
///
///
/// Embora Rust permita que você vincule `Sized` a um trait, você não poderá usá-lo para formar um objeto trait posteriormente:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // deixe y: &dyn Bar= &Impl;//erro: o trait `Bar` não pode ser transformado em um objeto
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // para padrão, por exemplo, que requer que `[T]: !Default` seja avaliável
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Tipos que podem ser de "unsized" a um tipo de tamanho dinâmico.
///
/// Por exemplo, o tipo de array dimensionado `[i8; 2]` implementa `Unsize<[i8]>` e `Unsize<dyn fmt::Debug>`.
///
/// Todas as implementações do `Unsize` são fornecidas automaticamente pelo compilador.
///
/// `Unsize` é implementado para:
///
/// - `[T; N]` é `Unsize<[T]>`
/// - `T` é `Unsize<dyn Trait>` quando `T: Trait`
/// - `Foo<..., T, ...>` é `Unsize<Foo<..., U, ...>>` se:
///   - `T: Unsize<U>`
///   - Foo é uma estrutura
///   - Apenas o último campo de `Foo` tem um tipo envolvendo `T`
///   - `T` não faz parte do tipo de nenhum outro campo
///   - `Bar<T>: Unsize<Bar<U>>`, se o último campo de `Foo` tiver o tipo `Bar<T>`
///
/// `Unsize` é usado junto com o [`ops::CoerceUnsized`] para permitir que os contêineres "user-defined", como o [`Rc`], contenham tipos de tamanho dinâmico.
/// Consulte o [DST coercion RFC][RFC982] e o [the nomicon entry on coercion][nomicon-coerce] para obter mais detalhes.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// trait necessário para constantes usadas em correspondências de padrões.
///
/// Qualquer tipo que deriva `PartialEq` implementa automaticamente este trait,*independentemente* de seus parâmetros de tipo implementarem `Eq`.
///
/// Se um item `const` contém algum tipo que não implementa este trait, então esse tipo (1.) não implementa `PartialEq` (o que significa que a constante não fornecerá esse método de comparação, que a geração de código assume que está disponível), ou (2.) ele implementa *seu próprio* versão do `PartialEq` (que assumimos não está em conformidade com uma comparação de igualdade estrutural).
///
///
/// Em qualquer um dos dois cenários acima, rejeitamos o uso de tal constante em uma correspondência de padrão.
///
/// Veja também o [structural match RFC][RFC1445] e o [issue 63438] que motivou a migração do design baseado em atributos para este trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// trait necessário para constantes usadas em correspondências de padrões.
///
/// Qualquer tipo que derive `Eq` implementa automaticamente este trait,*independentemente* de seus parâmetros de tipo implementarem `Eq`.
///
/// Este é um hack para contornar uma limitação em nosso sistema de tipos.
///
/// # Background
///
/// Queremos exigir que os tipos de consts usados em correspondências de padrões tenham o atributo `#[derive(PartialEq, Eq)]`.
///
/// Em um mundo mais ideal, poderíamos verificar esse requisito apenas verificando se o tipo fornecido implementa tanto o `StructuralPartialEq` trait *quanto* o `Eq` trait.
/// No entanto, você pode ter ADTs que *fazem*`derive(PartialEq, Eq)`, e é um caso que queremos que o compilador aceite, e ainda assim o tipo da constante falha em implementar `Eq`.
///
/// Ou seja, um caso como este:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (O problema no código acima é que `Wrap<fn(&())>` não implementa `PartialEq`, nem `Eq`, porque `para <'a> fn(&'a _)` does not implement those traits.)
///
/// Portanto, não podemos confiar na verificação ingênua para `StructuralPartialEq` e apenas `Eq`.
///
/// Como um hack para contornar isso, usamos dois traits separados injetados por cada um dos dois derivados (`#[derive(PartialEq)]` e `#[derive(Eq)]`) e verificamos se ambos estão presentes como parte da verificação de correspondência estrutural.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Tipos cujos valores podem ser duplicados simplesmente copiando bits.
///
/// Por padrão, as associações de variáveis têm 'semântica de movimentação'.Em outras palavras:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` mudou para o `y` e, portanto, não pode ser usado
///
/// // println! ("{: ?}", x);//erro: uso do valor movido
/// ```
///
/// No entanto, se um tipo implementa `Copy`, ele tem 'semântica de cópia':
///
/// ```
/// // Podemos derivar uma implementação `Copy`.
/// // `Clone` também é necessário, pois é um super estreito do `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` é uma cópia do `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// É importante observar que, nesses dois exemplos, a única diferença é se você tem permissão para acessar o `x` após a atribuição.
/// Nos bastidores, uma cópia e uma movimentação podem resultar na cópia de bits na memória, embora isso às vezes seja otimizado.
///
/// ## Como posso implementar o `Copy`?
///
/// Existem duas maneiras de implementar o `Copy` em seu tipo.O mais simples é usar o `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Você também pode implementar `Copy` e `Clone` manualmente:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Há uma pequena diferença entre os dois: a estratégia `derive` também colocará um limite `Copy` nos parâmetros de tipo, o que nem sempre é desejado.
///
/// ## Qual é a diferença entre `Copy` e `Clone`?
///
/// As cópias acontecem implicitamente, por exemplo, como parte de uma atribuição `y = x`.O comportamento do `Copy` não é sobrecarregável;é sempre uma cópia bit a bit simples.
///
/// A clonagem é uma ação explícita, `x.clone()`.A implementação do [`Clone`] pode fornecer qualquer comportamento específico do tipo necessário para duplicar valores com segurança.
/// Por exemplo, a implementação de [`Clone`] para [`String`] precisa copiar o buffer de string apontado no heap.
/// Uma cópia simples bit a bit dos valores [`String`] simplesmente copiaria o ponteiro, levando a uma liberação dupla na linha.
/// Por esse motivo, [`String`] é [`Clone`], mas não `Copy`.
///
/// [`Clone`] é um super estreito de `Copy`, então tudo que é `Copy` também deve implementar [`Clone`].
/// Se um tipo for `Copy`, sua implementação [`Clone`] precisará retornar apenas `*self` (consulte o exemplo acima).
///
/// ## Quando meu tipo pode ser `Copy`?
///
/// Um tipo pode implementar `Copy` se todos os seus componentes implementarem `Copy`.Por exemplo, esta estrutura pode ser `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Uma estrutura pode ser `Copy` e [`i32`] é `Copy`, portanto, `Point` pode ser `Copy`.
/// Em contraste, considere
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// A struct `PointList` não pode implementar `Copy`, porque [`Vec<T>`] não é `Copy`.Se tentarmos derivar uma implementação `Copy`, obteremos um erro:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Referências compartilhadas (`&T`) também são `Copy`, portanto, um tipo pode ser `Copy`, mesmo quando contém referências compartilhadas de tipos `T` que *não*`Copy`.
/// Considere a seguinte estrutura, que pode implementar `Copy`, porque ela contém apenas uma *referência compartilhada* para nosso tipo `PointList` não `Copy` acima:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Quando *não pode* meu tipo ser `Copy`?
///
/// Alguns tipos não podem ser copiados com segurança.Por exemplo, copiar `&mut T` criaria uma referência mutável com alias.
/// Copiar o [`String`] duplicaria a responsabilidade de gerenciar o buffer da [`String`], resultando em um double free.
///
/// Generalizando o último caso, qualquer tipo de implementação de [`Drop`] não pode ser `Copy`, porque está gerenciando algum recurso além de seus próprios bytes [`size_of::<T>`].
///
/// Se você tentar implementar `Copy` em uma estrutura ou enum contendo dados não `Copy`, receberá o erro [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Quando *deveria* meu tipo ser `Copy`?
///
/// De modo geral, se o seu tipo _can_ implementar `Copy`, deve.
/// Lembre-se, porém, de que a implementação do `Copy` faz parte da API pública do seu tipo.
/// Se o tipo puder se tornar não `Cópia` no future, pode ser prudente omitir a implementação do `Copy` agora, para evitar uma alteração interrompida da API.
///
/// ## Implementadores adicionais
///
/// Além do [implementors listed below][impls], os seguintes tipos também implementam o `Copy`:
///
/// * Tipos de item de função (ou seja, os tipos distintos definidos para cada função)
/// * Tipos de ponteiro de função (por exemplo, `fn() -> i32`)
/// * Tipos de matriz, para todos os tamanhos, se o tipo de item também implementa `Copy` (por exemplo, `[i32; 123456]`)
/// * Tipos de tupla, se cada componente também implementa `Copy` (por exemplo, `()`, `(i32, bool)`)
/// * Tipos de fechamento, se eles não capturarem nenhum valor do ambiente ou se todos esses valores capturados implementarem `Copy`.
///   Observe que as variáveis capturadas por referência compartilhada sempre implementam `Copy` (mesmo se o referente não), enquanto variáveis capturadas por referência mutável nunca implementam `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Isso permite copiar um tipo que não implementa `Copy` devido a limites de vida útil insatisfeitos (copiar `A<'_>` quando apenas `A<'static>: Copy` e `A<'_>: Clone`).
// Temos esse atributo aqui por enquanto apenas porque existem algumas especializações existentes no `Copy` que já existem na biblioteca padrão e não há como ter esse comportamento com segurança agora.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Derive macro gerando um impl do trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Tipos para os quais é seguro compartilhar referências entre threads.
///
/// Este trait é implementado automaticamente quando o compilador determina que é apropriado.
///
/// A definição precisa é: um tipo `T` é [`Sync`] se e somente se `&T` for [`Send`].
/// Em outras palavras, se não houver possibilidade de [undefined behavior][ub] (incluindo corridas de dados) ao passar referências `&T` entre threads.
///
/// Como seria de se esperar, tipos primitivos como [`u8`] e [`f64`] são todos [`Sync`] e, portanto, são tipos de agregação simples que os contêm, como tuplas, estruturas e enums.
/// Mais exemplos de tipos básicos de [`Sync`] incluem tipos "immutable" como `&T` e aqueles com mutabilidade herdada simples, como [`Box<T>`][box], [`Vec<T>`][vec] e a maioria dos outros tipos de coleção.
///
/// (Os parâmetros genéricos precisam ser [`Sync`] para que seu contêiner seja [`Sync`].)
///
/// Uma consequência um tanto surpreendente da definição é que `&mut T` é `Sync` (se `T` for `Sync`), embora pareça que isso pode fornecer mutação não sincronizada.
/// O truque é que uma referência mutável por trás de uma referência compartilhada (ou seja, `& &mut T`) torna-se somente leitura, como se fosse um `& &T`.
/// Portanto, não há risco de uma disputa de dados.
///
/// Tipos que não são `Sync` são aqueles que possuem "interior mutability" em uma forma não segura para thread, como [`Cell`][cell] e [`RefCell`][refcell].
/// Esses tipos permitem a mutação de seus conteúdos, mesmo por meio de uma referência compartilhada e imutável.
/// Por exemplo, o método `set` em [`Cell<T>`][cell] usa `&self`, portanto, requer apenas uma referência compartilhada [`&Cell<T>`][cell].
/// O método não realiza sincronização, portanto, [`Cell`][cell] não pode ser `Sync`.
///
/// Outro exemplo de um tipo não `Sync` é o ponteiro de contagem de referência [`Rc`][rc].
/// Dada qualquer referência [`&Rc<T>`][rc], você pode clonar um novo [`Rc<T>`][rc], modificando as contagens de referência de uma maneira não atômica.
///
/// Para casos em que é necessário mutabilidade interior thread-safe, Rust fornece [atomic data types], bem como bloqueio explícito via [`sync::Mutex`][mutex] e [`sync::RwLock`][rwlock].
/// Esses tipos garantem que qualquer mutação não possa causar disputas de dados, portanto, os tipos são `Sync`.
/// Da mesma forma, o [`sync::Arc`][arc] oferece um análogo thread-safe do [`Rc`][rc].
///
/// Qualquer tipo com mutabilidade interna também deve usar o invólucro do [`cell::UnsafeCell`][unsafecell] ao redor do value(s), que pode ser alterado por meio de uma referência compartilhada.
/// Deixar de fazer isso é [undefined behavior][ub].
/// Por exemplo, [`transmute`][transmute]-ing de `&T` para `&mut T` é inválido.
///
/// Consulte [the Nomicon][nomicon-send-and-sync] para obter mais detalhes sobre o `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): uma vez que o suporte para adicionar notas no `rustc_on_unimplemented` chega ao beta e foi estendido para verificar se um fechamento está em qualquer lugar na cadeia de requisitos, estenda-o como (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Tipo de tamanho zero usado para marcar coisas que "act like" eles possuem um `T`.
///
/// Adicionar um campo `PhantomData<T>` ao seu tipo informa ao compilador que seu tipo age como se armazenasse um valor do tipo `T`, embora realmente não o faça.
/// Essas informações são usadas ao calcular certas propriedades de segurança.
///
/// Para obter uma explicação mais detalhada sobre como usar o `PhantomData<T>`, consulte [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Uma nota horrível 👻👻👻
///
/// Embora ambos tenham nomes assustadores, `PhantomData` e 'tipos fantasmas' estão relacionados, mas não são idênticos.Um parâmetro de tipo fantasma é simplesmente um parâmetro de tipo que nunca é usado.
/// Em Rust, isso geralmente faz com que o compilador reclame, e a solução é adicionar um uso de "dummy" por meio de `PhantomData`.
///
/// # Examples
///
/// ## Parâmetros de vida não utilizados
///
/// Talvez o caso de uso mais comum para o `PhantomData` seja uma estrutura que tem um parâmetro de vida útil não utilizado, normalmente como parte de algum código não seguro.
/// Por exemplo, aqui está uma estrutura `Slice` que tem dois ponteiros do tipo `*const T`, provavelmente apontando para uma matriz em algum lugar:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// A intenção é que os dados subjacentes sejam válidos apenas para o `'a` vitalício, portanto, o `Slice` não deve sobreviver ao `'a`.
/// No entanto, essa intenção não é expressa no código, uma vez que não há usos do `'a` vitalício e, portanto, não está claro a quais dados ele se aplica.
/// Podemos corrigir isso dizendo ao compilador para agir *como se* a estrutura `Slice` contivesse uma referência `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Por sua vez, isso também requer a anotação `T: 'a`, indicando que todas as referências em `T` são válidas durante a vida útil do `'a`.
///
/// Ao inicializar um `Slice`, você simplesmente fornece o valor `PhantomData` para o campo `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Parâmetros de tipo não usados
///
/// Às vezes acontece que você tem parâmetros de tipo não usados que indicam para qual tipo de dados uma estrutura é "tied", mesmo que esses dados não sejam realmente encontrados na estrutura em si.
/// Aqui está um exemplo de onde isso ocorre com o [FFI].
/// A interface externa usa identificadores do tipo `*mut ()` para se referir aos valores Rust de diferentes tipos.
/// Rastreamos o tipo Rust usando um parâmetro de tipo fantasma no struct `ExternalResource` que envolve um identificador.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Propriedade e cheque de entrega
///
/// Adicionar um campo do tipo `PhantomData<T>` indica que seu tipo possui dados do tipo `T`.Isso, por sua vez, implica que, quando seu tipo for eliminado, ele poderá descartar uma ou mais instâncias do tipo `T`.
/// Isso tem influência na análise [drop check] do compilador Rust.
///
/// Se sua estrutura de fato não *possuir* os dados do tipo `T`, é melhor usar um tipo de referência, como `PhantomData<&'a T>` (ideally) ou `PhantomData<*const T>` (se nenhum tempo de vida se aplicar), para não indicar a propriedade.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// trait interno do compilador usado para indicar o tipo de discriminantes enum.
///
/// Este trait é implementado automaticamente para todos os tipos e não adiciona nenhuma garantia ao [`mem::Discriminant`].
/// É **comportamento indefinido** transmutar entre `DiscriminantKind::Discriminant` e `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// O tipo de discriminante, que deve satisfazer o trait bounds exigido pelo `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// trait interno do compilador usado para determinar se um tipo contém qualquer `UnsafeCell` internamente, mas não por via indireta.
///
/// Isso afeta, por exemplo, se um `static` desse tipo é colocado na memória estática somente leitura ou na memória estática gravável.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Tipos que podem ser movidos com segurança após serem fixados.
///
/// O próprio Rust não tem noção de tipos imóveis e considera os movimentos (por exemplo, por meio de atribuição ou [`mem::replace`]) sempre seguros.
///
/// O tipo [`Pin`][Pin] é usado em vez disso para evitar movimentos através do sistema de tipos.Os ponteiros `P<T>` envolvidos no invólucro [`Pin<P<T>>`][Pin] não podem ser removidos.
/// Consulte a documentação do [`pin` module] para obter mais informações sobre a fixação.
///
/// Implementar o `Unpin` trait para `T` elimina as restrições de pinagem do tipo, o que permite mover o `T` para fora do [`Pin<P<T>>`][Pin] com funções como [`mem::replace`].
///
///
/// `Unpin` não tem nenhuma conseqüência para dados não fixados.
/// Em particular, o [`mem::replace`] move alegremente os dados do `!Unpin` (funciona para qualquer `&mut T`, não apenas quando o `T: Unpin`).
/// No entanto, você não pode usar o [`mem::replace`] em dados agrupados dentro de um [`Pin<P<T>>`][Pin] porque você não pode obter o `&mut T` de que precisa para isso, e *isso* é o que faz este sistema funcionar.
///
/// Portanto, isso, por exemplo, só pode ser feito em tipos que implementam `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Precisamos de uma referência mutável para chamar `mem::replace`.
/// // Podemos obter essa referência pelo (implicitly) invocando o `Pin::deref_mut`, mas isso só é possível porque o `String` implementa o `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Este trait é implementado automaticamente para quase todos os tipos.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Um tipo de marcador que não implementa `Unpin`.
///
/// Se um tipo contiver um `PhantomPinned`, ele não implementará o `Unpin` por padrão.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implementações de `Copy` para tipos primitivos.
///
/// Implementações que não podem ser descritas em Rust são implementadas em `traits::SelectionContext::copy_clone_conditions()` em `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// As referências compartilhadas podem ser copiadas, mas as referências mutáveis *não*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}