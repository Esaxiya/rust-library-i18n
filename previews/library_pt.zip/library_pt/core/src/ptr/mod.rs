//! Gerencie manualmente a memória por meio de indicadores brutos.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Muitas funções neste módulo pegam ponteiros brutos como argumentos e lêem ou escrevem neles.Para que isso seja seguro, esses ponteiros devem ser *válidos*.
//! Se um ponteiro é válido depende da operação para a qual é usado (leitura ou gravação) e da extensão da memória que é acessada (ou seja, quantos bytes são read/written).
//! A maioria das funções usa `*mut T` e `* const T` para acessar apenas um único valor; nesse caso, a documentação omite o tamanho e implicitamente assume que sejam bytes `size_of::<T>()`.
//!
//! As regras precisas de validade ainda não foram determinadas.As garantias fornecidas neste ponto são mínimas:
//!
//! * Um ponteiro [null]*nunca* é válido, nem mesmo para acessos de [size zero][zst].
//! * Para um ponteiro ser válido, é necessário, mas nem sempre suficiente, que o ponteiro seja *desreferenciável*: o intervalo de memória do tamanho dado começando no ponteiro deve estar dentro dos limites de um único objeto alocado.
//!
//! Observe que em Rust, cada variável (stack-allocated) é considerada um objeto alocado separado.
//! * Mesmo para operações do [size zero][zst], o ponteiro não deve apontar para a memória desalocada, ou seja, a desalocação torna os ponteiros inválidos mesmo para operações de tamanho zero.
//! No entanto, lançar qualquer *literal* inteiro diferente de zero para um ponteiro é válido para acessos de tamanho zero, mesmo se alguma memória existir naquele endereço e for desalocada.
//! Isso corresponde a escrever seu próprio alocador: alocar objetos de tamanho zero não é muito difícil.
//! A maneira canônica de obter um ponteiro válido para acessos de tamanho zero é [`NonNull::dangling`].
//! * Todos os acessos realizados por funções neste módulo são *não atômicos* no sentido de [atomic operations] usado para sincronizar entre threads.
//! Isso significa que é um comportamento indefinido realizar dois acessos simultâneos ao mesmo local de threads diferentes, a menos que ambos os acessos sejam lidos apenas da memória.
//! Observe que isso inclui explicitamente [`read_volatile`] e [`write_volatile`]: os acessos voláteis não podem ser usados para sincronização entre threads.
//! * O resultado da projeção de uma referência a um ponteiro é válido enquanto o objeto subjacente estiver ativo e nenhuma referência (apenas ponteiros brutos) for usada para acessar a mesma memória.
//!
//! Esses axiomas, junto com o uso cuidadoso de [`offset`] para aritmética de ponteiro, são suficientes para implementar corretamente muitas coisas úteis em código não seguro.
//! Garantias mais fortes serão fornecidas eventualmente, conforme as regras do [aliasing] estão sendo determinadas.
//! Para obter mais informações, consulte o [book], bem como a seção na referência dedicada ao [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Ponteiros brutos válidos conforme definidos acima não são necessariamente alinhados corretamente (onde o alinhamento "proper" é definido pelo tipo de ponteira, ou seja, `*const T` deve ser alinhado a `mem::align_of::<T>()`).
//! No entanto, a maioria das funções exige que seus argumentos sejam alinhados de forma adequada e declararão explicitamente esse requisito em sua documentação.
//! Exceções notáveis a isso são [`read_unaligned`] e [`write_unaligned`].
//!
//! Quando uma função requer alinhamento adequado, ela o faz mesmo se o acesso tiver tamanho 0, ou seja, mesmo se a memória não for realmente tocada.Considere o uso do [`NonNull::dangling`] nesses casos.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Executa o destruidor (se houver) do valor apontado.
///
/// Isso é semanticamente equivalente a chamar o [`ptr::read`] e descartar o resultado, mas tem as seguintes vantagens:
///
/// * É *necessário* usar o `drop_in_place` para descartar tipos não dimensionados como objetos trait, porque eles não podem ser lidos na pilha e descartados normalmente.
///
/// * É mais amigável para o otimizador fazer isso em relação ao [`ptr::read`] ao descartar a memória alocada manualmente (por exemplo, nas implementações do `Box`/`Rc`/`Vec`), pois o compilador não precisa provar que está correto para omitir a cópia.
///
///
/// * Ele pode ser usado para eliminar dados do [pinned] quando o `T` não for `repr(packed)` (os dados fixados não devem ser movidos antes de serem eliminados).
///
/// Valores desalinhados não podem ser descartados no lugar, eles devem ser copiados para um local alinhado primeiro usando o [`ptr::read_unaligned`].Para estruturas compactadas, essa movimentação é feita automaticamente pelo compilador.
/// Isso significa que os campos de estruturas compactadas não são descartados no local.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// O comportamento é indefinido se qualquer uma das seguintes condições for violada:
///
/// * `to_drop` deve ser [valid] para leituras e gravações.
///
/// * `to_drop` deve estar devidamente alinhado.
///
/// * O valor para o qual `to_drop` aponta deve ser válido para eliminação, o que pode significar que ele deve manter invariantes adicionais, isso depende do tipo.
///
/// Além disso, se `T` não for [`Copy`], usar o valor apontado após chamar `drop_in_place` pode causar um comportamento indefinido.Observe que o `*to_drop = foo` conta como um uso porque fará com que o valor seja descartado novamente.
/// [`write()`] pode ser usado para sobrescrever dados sem causar sua eliminação.
///
/// Observe que mesmo se `T` tiver o tamanho `0`, o ponteiro não deve ser NULL e deve estar alinhado corretamente.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Remova manualmente o último item de um vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Obtenha um ponteiro bruto para o último elemento no `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Encurte o `v` para evitar que o último item caia.
///     // Fazemos isso primeiro, para evitar problemas se o `drop_in_place` estiver abaixo de panics.
///     v.set_len(1);
///     // Sem uma chamada `drop_in_place`, o último item nunca seria descartado e a memória que ele gerencia seria perdida.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Certifique-se de que o último item foi descartado.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Observe que o compilador executa essa cópia automaticamente ao descartar estruturas compactadas, ou seja, normalmente você não precisa se preocupar com tais questões, a menos que chame o `drop_in_place` manualmente.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Código aqui não importa, ele é substituído pela cola real do compilador.
    //

    // SEGURANÇA: veja o comentário acima
    unsafe { drop_in_place(to_drop) }
}

/// Cria um ponteiro nulo bruto.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Cria um ponteiro nulo e mutável.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// O impl manual é necessário para evitar o limite do `T: Clone`.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// O impl manual é necessário para evitar o limite do `T: Copy`.
impl<T> Copy for FatPtr<T> {}

/// Forma uma fatia bruta de um ponteiro e um comprimento.
///
/// O argumento `len` é o número de **elementos**, não o número de bytes.
///
/// Esta função é segura, mas realmente usar o valor de retorno não é seguro.
/// Consulte a documentação do [`slice::from_raw_parts`] para obter os requisitos de segurança de fatia.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // crie um ponteiro de fatia ao começar com um ponteiro para o primeiro elemento
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // SEGURANÇA: Acessar o valor da união `Repr` é seguro desde * const [T]
        //
        // e FatPtr têm os mesmos layouts de memória.Apenas std pode fazer esta garantia.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Desempenha a mesma funcionalidade do [`slice_from_raw_parts`], exceto que uma fatia mutável bruta é retornada, em oposição a uma fatia imutável bruta.
///
///
/// Consulte a documentação do [`slice_from_raw_parts`] para obter mais detalhes.
///
/// Esta função é segura, mas realmente usar o valor de retorno não é seguro.
/// Consulte a documentação do [`slice::from_raw_parts_mut`] para obter os requisitos de segurança de fatia.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // atribuir um valor em um índice na fatia
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // SEGURANÇA: Acessar o valor da união `Repr` é seguro desde * mut [T]
        // e FatPtr têm os mesmos layouts de memória
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Troca os valores em dois locais mutáveis do mesmo tipo, sem desinicializar nenhum deles.
///
/// Mas para as duas exceções a seguir, esta função é semanticamente equivalente a [`mem::swap`]:
///
///
/// * Ele opera em ponteiros brutos em vez de referências.
/// Quando houver referências disponíveis, deve-se dar preferência ao [`mem::swap`].
///
/// * Os dois valores apontados podem se sobrepor.
/// Se os valores se sobreporem, a região de sobreposição da memória do `x` será usada.
/// Isso é demonstrado no segundo exemplo abaixo.
///
/// # Safety
///
/// O comportamento é indefinido se qualquer uma das seguintes condições for violada:
///
/// * Tanto o `x` quanto o `y` devem ser [valid] para leituras e gravações.
///
/// * Tanto o `x` quanto o `y` devem ser alinhados corretamente.
///
/// Observe que, mesmo se `T` tiver o tamanho `0`, os ponteiros não devem ser NULL e estar alinhados corretamente.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Trocando duas regiões não sobrepostas:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // este é o `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // este é o `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Trocando duas regiões sobrepostas:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // este é o `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // este é o `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Os índices `1..3` da fatia se sobrepõem entre `x` e `y`.
///     // Resultados razoáveis seriam para eles serem `[2, 3]`, de forma que os índices `0..3` sejam `[1, 2, 3]` (combinando com o `y` antes do `swap`);ou para eles serem `[0, 1]` de forma que os índices `1..4` sejam `[0, 1, 2]` (combinando com o `x` antes do `swap`).
/////
///     // Essa implementação é definida para fazer a última escolha.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Dê a nós mesmos algum espaço para trabalhar.
    // Não precisamos nos preocupar com quedas: o `MaybeUninit` não faz nada quando cai.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Realize a troca SEGURANÇA: o chamador deve garantir que o `x` e o `y` são válidos para gravações e devidamente alinhados.
    // `tmp` não pode se sobrepor ao `x` ou ao `y` porque o `tmp` acabou de ser alocado na pilha como um objeto alocado separado.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` e `y` pode se sobrepor
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Troca bytes `count * size_of::<T>()` entre as duas regiões da memória, começando em `x` e `y`.
/// As duas regiões *não* devem se sobrepor.
///
/// # Safety
///
/// O comportamento é indefinido se qualquer uma das seguintes condições for violada:
///
/// * Ambos `x` e `y` devem ser [valid] para leituras e gravações de `contagem *
///   tamanho de: :<T>() `bytes.
///
/// * Tanto o `x` quanto o `y` devem ser alinhados corretamente.
///
/// * A região da memória começando em `x` com um tamanho de `contagem *
///   tamanho de: :<T>() `bytes *não* devem se sobrepor à região da memória começando em `y` com o mesmo tamanho.
///
/// Observe que mesmo se o tamanho efetivamente copiado (`contagem * size_of: :<T>()`) é `0`, os ponteiros devem ser diferentes de NULL e estar devidamente alinhados.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SEGURANÇA: o chamador deve garantir que `x` e `y` são
    // válido para gravações e devidamente alinhado.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Para tipos menores do que a otimização de bloco abaixo, basta trocar diretamente para evitar codegen pessimizando.
    //
    if mem::size_of::<T>() < 32 {
        // SEGURANÇA: o chamador deve garantir que `x` e `y` são válidos
        // para gravações, alinhado corretamente e sem sobreposição.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // SEGURANÇA: o chamador deve respeitar o contrato de segurança do `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // A abordagem aqui é utilizar simd para trocar x e y com eficiência.
    // Os testes revelam que trocar 32 bytes ou 64 bytes por vez é mais eficiente para os processadores Intel Haswell E.
    // O LLVM é mais capaz de otimizar se dermos a uma estrutura um #[repr(simd)], mesmo se não usarmos essa estrutura diretamente.
    //
    //
    // FIXME repr(simd) quebrado em emscripten e redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Loop por meio de x e y, copiando-os `Block` por vez O otimizador deve desenrolar o loop completamente para a maioria dos tipos de NB
    // Não podemos usar um loop for porque o impl `range` chama o `mem::swap` recursivamente
    //
    let mut i = 0;
    while i + block_size <= len {
        // Crie alguma memória não inicializada como espaço temporário Declarar `t` aqui evita o alinhamento da pilha quando este loop não é usado
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SEGURANÇA: Como `i < len`, e como o chamador deve garantir que `x` e `y` são válidos
        // para bytes `len`, `x + i` e `y + i` devem ser endereços válidos, o que cumpre o contrato de segurança para `add`.
        //
        // Além disso, o chamador deve garantir que `x` e `y` sejam válidos para gravações, alinhados corretamente e não sobrepostos, o que cumpre o contrato de segurança para `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Troque um bloco de bytes de x e y, usando t como um buffer temporário Isso deve ser otimizado para operações SIMD eficientes, quando disponível
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Troque todos os bytes restantes
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // SEGURANÇA: consulte o comentário de segurança anterior.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Move `src` para o `dst` pontiagudo, retornando o valor `dst` anterior.
///
/// Nenhum valor é descartado.
///
/// Esta função é semanticamente equivalente ao [`mem::replace`], exceto que opera em ponteiros brutos em vez de referências.
/// Quando houver referências disponíveis, deve-se dar preferência ao [`mem::replace`].
///
/// # Safety
///
/// O comportamento é indefinido se qualquer uma das seguintes condições for violada:
///
/// * `dst` deve ser [valid] para leituras e gravações.
///
/// * `dst` deve estar devidamente alinhado.
///
/// * `dst` deve apontar para um valor devidamente inicializado do tipo `T`.
///
/// Observe que mesmo se `T` tiver o tamanho `0`, o ponteiro não deve ser NULL e deve estar alinhado corretamente.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` teria o mesmo efeito sem exigir o bloqueio inseguro.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SEGURANÇA: o chamador deve garantir que o `dst` é válido para ser
    // convertido para uma referência mutável (válido para gravações, alinhado, inicializado) e não pode se sobrepor ao `src`, pois o `dst` deve apontar para um objeto distinto alocado.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // não pode se sobrepor
    }
    src
}

/// Lê o valor do `src` sem movê-lo.Isso deixa a memória no `src` inalterada.
///
/// # Safety
///
/// O comportamento é indefinido se qualquer uma das seguintes condições for violada:
///
/// * `src` deve ser [valid] para leituras.
///
/// * `src` deve estar devidamente alinhado.Use o [`read_unaligned`] se este não for o caso.
///
/// * `src` deve apontar para um valor devidamente inicializado do tipo `T`.
///
/// Observe que mesmo se `T` tiver o tamanho `0`, o ponteiro não deve ser NULL e deve estar alinhado corretamente.
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Implemente o [`mem::swap`] manualmente:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Crie uma cópia bit a bit do valor em `a` em `tmp`.
///         let tmp = ptr::read(a);
///
///         // Sair neste ponto (retornando explicitamente ou chamando uma função que panics) faria com que o valor em `tmp` fosse descartado enquanto o mesmo valor ainda fosse referenciado pelo `a`.
///         // Isso pode desencadear um comportamento indefinido se `T` não for `Copy`.
/////
/////
///
///         // Crie uma cópia bit a bit do valor em `b` em `a`.
///         // Isso é seguro porque as referências mutáveis não podem ser alteradas.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Como acima, sair aqui pode desencadear um comportamento indefinido porque o mesmo valor é referenciado por `a` e `b`.
/////
///
///         // Mova o `tmp` para o `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` foi movido (o `write` assume a propriedade de seu segundo argumento), portanto, nada é descartado implicitamente aqui.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Propriedade do valor devolvido
///
/// `read` cria uma cópia bit a bit de `T`, independentemente de `T` ser [`Copy`].
/// Se `T` não for [`Copy`], usar o valor retornado e o valor em `*src` pode violar a segurança da memória.
/// Observe que atribuir a `*src` conta como um uso porque tentará diminuir o valor em `* src`.
///
/// [`write()`] pode ser usado para sobrescrever dados sem causar sua eliminação.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` agora aponta para a mesma memória subjacente do `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Atribuir ao `s2` faz com que seu valor original seja descartado.
///     // Além desse ponto, o `s` não deve mais ser usado, pois a memória subjacente foi liberada.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Atribuir a `s` faria com que o valor antigo fosse descartado novamente, resultando em um comportamento indefinido.
/////
///     // s= String::from("bar");//ERROR
///
///     // `ptr::write` pode ser usado para substituir um valor sem eliminá-lo.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SEGURANÇA: o chamador deve garantir que o `src` é válido para leituras.
    // `src` não pode se sobrepor ao `tmp` porque o `tmp` acabou de ser alocado na pilha como um objeto alocado separado.
    //
    //
    // Além disso, como acabamos de escrever um valor válido no `tmp`, é garantido que ele seja inicializado corretamente.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Lê o valor do `src` sem movê-lo.Isso deixa a memória no `src` inalterada.
///
/// Ao contrário do [`read`], o `read_unaligned` funciona com ponteiros não alinhados.
///
/// # Safety
///
/// O comportamento é indefinido se qualquer uma das seguintes condições for violada:
///
/// * `src` deve ser [valid] para leituras.
///
/// * `src` deve apontar para um valor devidamente inicializado do tipo `T`.
///
/// Como o [`read`], o `read_unaligned` cria uma cópia bit a bit do `T`, independentemente de `T` ser [`Copy`].
/// Se `T` não for [`Copy`], usar o valor retornado e o valor em `*src` pode ser [violate memory safety][read-ownership].
///
/// Observe que, mesmo se `T` tiver o tamanho `0`, o ponteiro não deve ser NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Em estruturas `packed`
///
/// Atualmente, é impossível criar ponteiros brutos para campos não alinhados de uma estrutura compactada.
///
/// A tentativa de criar um ponteiro bruto para um campo de estrutura `unaligned` com uma expressão como `&packed.unaligned as *const FieldType` cria uma referência não alinhada intermediária antes de convertê-la em um ponteiro bruto.
///
/// O fato de essa referência ser temporária e ser convertida imediatamente é irrelevante, pois o compilador sempre espera que as referências estejam alinhadas corretamente.
/// Como resultado, o uso do `&packed.unaligned as *const FieldType` causa* comportamento indefinido * imediato em seu programa.
///
/// Um exemplo do que não fazer e como isso se relaciona com o `read_unaligned` é:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Aqui, tentamos obter o endereço de um inteiro de 32 bits que não está alinhado.
///     let unaligned =
///         // Uma referência não alinhada temporária é criada aqui, o que resulta em um comportamento indefinido, independentemente de a referência ser usada ou não.
/////
///         &packed.unaligned
///         // A projeção para um ponteiro bruto não ajuda;o erro já aconteceu.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Acessar campos não alinhados diretamente com, por exemplo, `packed.unaligned` é seguro.
///
///
///
///
///
///
// FIXME: Atualize os documentos com base no resultado do RFC #2582 e amigos.
/// # Examples
///
/// Leia um valor usize de um buffer de bytes:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SEGURANÇA: o chamador deve garantir que o `src` é válido para leituras.
    // `src` não pode se sobrepor ao `tmp` porque o `tmp` acabou de ser alocado na pilha como um objeto alocado separado.
    //
    //
    // Além disso, como acabamos de escrever um valor válido no `tmp`, é garantido que ele seja inicializado corretamente.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Substitui um local da memória com o valor fornecido sem ler ou descartar o valor antigo.
///
/// `write` não descarta o conteúdo do `dst`.
/// Isso é seguro, mas pode vazar alocações ou recursos, portanto, tome cuidado para não sobrescrever um objeto que deve ser descartado.
///
///
/// Além disso, ele não descarta o `src`.Semanticamente, o `src` é movido para o local apontado pelo `dst`.
///
/// Isso é apropriado para inicializar a memória não inicializada ou sobrescrever a memória que foi anteriormente usada para o [`read`].
///
/// # Safety
///
/// O comportamento é indefinido se qualquer uma das seguintes condições for violada:
///
/// * `dst` deve ser [valid] para gravações.
///
/// * `dst` deve estar devidamente alinhado.Use o [`write_unaligned`] se este não for o caso.
///
/// Observe que mesmo se `T` tiver o tamanho `0`, o ponteiro não deve ser NULL e deve estar alinhado corretamente.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Implemente o [`mem::swap`] manualmente:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Crie uma cópia bit a bit do valor em `a` em `tmp`.
///         let tmp = ptr::read(a);
///
///         // Sair neste ponto (retornando explicitamente ou chamando uma função que panics) faria com que o valor em `tmp` fosse descartado enquanto o mesmo valor ainda fosse referenciado pelo `a`.
///         // Isso pode desencadear um comportamento indefinido se `T` não for `Copy`.
/////
/////
///
///         // Crie uma cópia bit a bit do valor em `b` em `a`.
///         // Isso é seguro porque as referências mutáveis não podem ser alteradas.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Como acima, sair aqui pode desencadear um comportamento indefinido porque o mesmo valor é referenciado por `a` e `b`.
/////
///
///         // Mova o `tmp` para o `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` foi movido (o `write` assume a propriedade de seu segundo argumento), portanto, nada é descartado implicitamente aqui.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Estamos chamando os intrínsecos diretamente para evitar chamadas de função no código gerado, pois `intrinsics::copy_nonoverlapping` é uma função de invólucro.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SEGURANÇA: o chamador deve garantir que o `dst` é válido para gravações.
    // `dst` não pode se sobrepor ao `src` porque o chamador tem acesso mutável ao `dst` enquanto o `src` pertence a esta função.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Substitui um local da memória com o valor fornecido sem ler ou descartar o valor antigo.
///
/// Ao contrário do [`write()`], o ponteiro pode estar desalinhado.
///
/// `write_unaligned` não descarta o conteúdo do `dst`.Isso é seguro, mas pode vazar alocações ou recursos, portanto, tome cuidado para não sobrescrever um objeto que deve ser descartado.
///
/// Além disso, ele não descarta o `src`.Semanticamente, o `src` é movido para o local apontado pelo `dst`.
///
/// Isso é apropriado para inicializar a memória não inicializada ou sobrescrever a memória que foi lida anteriormente com o [`read_unaligned`].
///
/// # Safety
///
/// O comportamento é indefinido se qualquer uma das seguintes condições for violada:
///
/// * `dst` deve ser [valid] para gravações.
///
/// Observe que, mesmo se `T` tiver o tamanho `0`, o ponteiro não deve ser NULL.
///
/// [valid]: self#safety
///
/// ## Em estruturas `packed`
///
/// Atualmente, é impossível criar ponteiros brutos para campos não alinhados de uma estrutura compactada.
///
/// A tentativa de criar um ponteiro bruto para um campo de estrutura `unaligned` com uma expressão como `&packed.unaligned as *const FieldType` cria uma referência não alinhada intermediária antes de convertê-la em um ponteiro bruto.
///
/// O fato de essa referência ser temporária e ser convertida imediatamente é irrelevante, pois o compilador sempre espera que as referências estejam alinhadas corretamente.
/// Como resultado, o uso do `&packed.unaligned as *const FieldType` causa* comportamento indefinido * imediato em seu programa.
///
/// Um exemplo do que não fazer e como isso se relaciona com o `write_unaligned` é:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Aqui, tentamos obter o endereço de um inteiro de 32 bits que não está alinhado.
///     let unaligned =
///         // Uma referência não alinhada temporária é criada aqui, o que resulta em um comportamento indefinido, independentemente de a referência ser usada ou não.
/////
///         &mut packed.unaligned
///         // A projeção para um ponteiro bruto não ajuda;o erro já aconteceu.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Acessar campos não alinhados diretamente com, por exemplo, `packed.unaligned` é seguro.
///
///
///
///
///
///
///
///
///
// FIXME: Atualize os documentos com base no resultado do RFC #2582 e amigos.
/// # Examples
///
/// Escreva um valor usize em um buffer de bytes:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SEGURANÇA: o chamador deve garantir que o `dst` é válido para gravações.
    // `dst` não pode se sobrepor ao `src` porque o chamador tem acesso mutável ao `dst` enquanto o `src` pertence a esta função.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Estamos chamando o intrínseco diretamente para evitar chamadas de função no código gerado.
        intrinsics::forget(src);
    }
}

/// Executa uma leitura volátil do valor de `src` sem movê-lo.Isso deixa a memória no `src` inalterada.
///
/// As operações voláteis têm como objetivo atuar na memória do I/O e têm a garantia de não serem eliminadas ou reordenadas pelo compilador em outras operações voláteis.
///
/// # Notes
///
/// Rust não tem atualmente um modelo de memória definido de forma rigorosa e formal, portanto, a semântica precisa do que o "volatile" significa aqui está sujeita a alterações com o tempo.
/// Dito isso, a semântica quase sempre terminará muito semelhante à do [C11's definition of volatile][c11].
///
/// O compilador não deve alterar a ordem relativa ou o número de operações de memória volátil.
/// No entanto, as operações de memória volátil em tipos de tamanho zero (por exemplo, se um tipo de tamanho zero for passado para o `read_volatile`) são noops e podem ser ignoradas.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// O comportamento é indefinido se qualquer uma das seguintes condições for violada:
///
/// * `src` deve ser [valid] para leituras.
///
/// * `src` deve estar devidamente alinhado.
///
/// * `src` deve apontar para um valor devidamente inicializado do tipo `T`.
///
/// Como o [`read`], o `read_volatile` cria uma cópia bit a bit do `T`, independentemente de `T` ser [`Copy`].
/// Se `T` não for [`Copy`], usar o valor retornado e o valor em `*src` pode ser [violate memory safety][read-ownership].
/// No entanto, armazenar tipos não-[`Copiar`] na memória volátil é quase certamente incorreto.
///
/// Observe que mesmo se `T` tiver o tamanho `0`, o ponteiro não deve ser NULL e deve estar alinhado corretamente.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Assim como em C, o fato de uma operação ser volátil não tem qualquer relação com as questões que envolvem o acesso simultâneo de vários threads.Os acessos voláteis se comportam exatamente como os acessos não atômicos nesse aspecto.
///
/// Em particular, uma corrida entre um `read_volatile` e qualquer operação de gravação no mesmo local é um comportamento indefinido.
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Não entre em pânico para manter o impacto do codegen menor.
        abort();
    }
    // SEGURANÇA: o chamador deve respeitar o contrato de segurança do `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Executa uma gravação volátil de um local da memória com o valor fornecido sem ler ou descartar o valor antigo.
///
/// As operações voláteis têm como objetivo atuar na memória do I/O e têm a garantia de não serem eliminadas ou reordenadas pelo compilador em outras operações voláteis.
///
/// `write_volatile` não descarta o conteúdo do `dst`.Isso é seguro, mas pode vazar alocações ou recursos, portanto, tome cuidado para não sobrescrever um objeto que deve ser descartado.
///
/// Além disso, ele não descarta o `src`.Semanticamente, o `src` é movido para o local apontado pelo `dst`.
///
/// # Notes
///
/// Rust não tem atualmente um modelo de memória definido de forma rigorosa e formal, portanto, a semântica precisa do que o "volatile" significa aqui está sujeita a alterações com o tempo.
/// Dito isso, a semântica quase sempre terminará muito semelhante à do [C11's definition of volatile][c11].
///
/// O compilador não deve alterar a ordem relativa ou o número de operações de memória volátil.
/// No entanto, as operações de memória volátil em tipos de tamanho zero (por exemplo, se um tipo de tamanho zero for passado para o `write_volatile`) são noops e podem ser ignoradas.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// O comportamento é indefinido se qualquer uma das seguintes condições for violada:
///
/// * `dst` deve ser [valid] para gravações.
///
/// * `dst` deve estar devidamente alinhado.
///
/// Observe que mesmo se `T` tiver o tamanho `0`, o ponteiro não deve ser NULL e deve estar alinhado corretamente.
///
/// [valid]: self#safety
///
/// Assim como em C, o fato de uma operação ser volátil não tem qualquer relação com as questões que envolvem o acesso simultâneo de vários threads.Os acessos voláteis se comportam exatamente como os acessos não atômicos nesse aspecto.
///
/// Em particular, uma corrida entre um `write_volatile` e qualquer outra operação (leitura ou gravação) no mesmo local é um comportamento indefinido.
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Não entre em pânico para manter o impacto do codegen menor.
        abort();
    }
    // SEGURANÇA: o chamador deve respeitar o contrato de segurança do `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Alinhe o ponteiro `p`.
///
/// Calcule o deslocamento (em termos de elementos do passo `stride`) que deve ser aplicado ao ponteiro `p` para que o ponteiro `p` fique alinhado com o `a`.
///
/// Note: Esta implementação foi cuidadosamente adaptada para não panic.É UB para panic.
/// A única mudança real que pode ser feita aqui é a mudança de `INV_TABLE_MOD_16` e constantes associadas.
///
/// Se decidirmos tornar possível chamar o intrínseco com o `a` que não é uma potência de dois, provavelmente será mais prudente apenas mudar para uma implementação ingênua em vez de tentar adaptá-la para acomodar essa mudança.
///
///
/// Qualquer dúvida vá para@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): O uso direto desses intrínsecos melhora o codegen significativamente no nível de otimização <=
    // 1, onde as versões do método dessas operações não são sequenciais.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Calcule o inverso modular multiplicativo do módulo `x` `m`.
    ///
    /// Esta implementação é adaptada para `align_offset` e tem as seguintes pré-condições:
    ///
    /// * `m` é uma potência de dois;
    /// * `x < m`; (se for `x ≥ m`, passe `x % m` em seu lugar)
    ///
    /// A implementação desta função não deve panic.Sempre.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Módulo de tabela inversa modular multiplicativa 2⁴=16.
        ///
        /// Observe que esta tabela não contém valores onde o inverso não existe (ou seja, para `0⁻¹ mod 16`, `2⁻¹ mod 16`, etc.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Módulo para o qual o `INV_TABLE_MOD_16` se destina.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // SEGURANÇA: O `m` deve ser uma potência de dois, portanto, diferente de zero.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Repetimos o "up" usando a seguinte fórmula:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // até 2²ⁿ ≥ m.Então, podemos reduzir ao nosso `m` desejado, obtendo o resultado `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Observe que usamos operações de agrupamento aqui intencionalmente-a fórmula original usa, por exemplo, subtração `mod n`.
                // É perfeitamente normal fazer `mod usize::MAX` em vez disso, porque pegamos o resultado `mod n` no final de qualquer maneira.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SEGURANÇA: `a` é uma potência de dois, portanto diferente de zero.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` O caso pode ser calculado de forma mais simples por meio do `-p (mod a)`, mas isso inibe a capacidade do LLVM de selecionar instruções como o `lea`.Em vez disso, calculamos
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // que distribui as operações em torno do suporte de carga, mas pessimizando o `and` o suficiente para que o LLVM possa utilizar as várias otimizações que conhece.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Já alinhado.Yay!
        return 0;
    } else if stride == 0 {
        // Se o ponteiro não estiver alinhado e o elemento tiver tamanho zero, nenhuma quantidade de elementos alinhará o ponteiro.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // SEGURANÇA: a é potência de dois, portanto, diferente de zero.stride==0 caso é tratado acima.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SEGURANÇA: gcdpow tem um limite superior que é no máximo o número de bits em um usize.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SEGURANÇA: mdc é sempre maior ou igual a 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Este branch resolve a seguinte equação de congruência linear:
        //
        // ` p + so = 0 mod a `
        //
        // `p` aqui está o valor do ponteiro, `s`, passo de `T`, deslocamento `o` em `T`s e `a`, o alinhamento solicitado.
        //
        // Com `g = gcd(a, s)`, e a condição acima afirmando que `p` também é divisível por `g`, podemos denotar `a' = a/g`, `s' = s/g`, `p' = p/g`, então isso se torna equivalente a:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // O primeiro termo é "the relative alignment of `p` to `a`" (dividido por `g`), o segundo termo é "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (novamente dividido por `g`).
        //
        // A divisão por `g` é necessária para fazer o inverso bem formado se `a` e `s` não forem co-prime.
        //
        // Além disso, o resultado produzido por esta solução não é "minimal", por isso é necessário tirar o resultado `o mod lcm(s, a)`.Podemos substituir o `lcm(s, a)` por apenas um `a'`.
        //
        //
        //
        //
        //

        // SEGURANÇA: `gcdpow` tem um limite superior não maior que o número de bits 0 à direita no `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SEGURANÇA: `a2` é diferente de zero.O deslocamento de `a` por `gcdpow` não pode deslocar nenhum dos bits definidos
        // no `a` (do qual possui exatamente um).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SEGURANÇA: `gcdpow` tem um limite superior não maior que o número de bits 0 à direita no `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SEGURANÇA: `gcdpow` tem um limite superior não maior que o número de bits 0 à direita em
        // `a`.
        // Além disso, a subtração não pode estourar, porque `a2 = a >> gcdpow` sempre será estritamente maior que `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SEGURANÇA: `a2` é uma potência de dois, conforme comprovado acima.`s2` é estritamente menor que `a2`
        // porque `(s % a) >> gcdpow` é estritamente menor que `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Não pode ser alinhado de forma alguma.
    usize::MAX
}

/// Compara ponteiros brutos para igualdade.
///
/// É o mesmo que usar o operador `==`, mas menos genérico:
/// os argumentos devem ser ponteiros brutos do `*const T`, não qualquer coisa que implemente o `PartialEq`.
///
/// Isso pode ser usado para comparar referências `&T` (que coagem a `*const T` implicitamente) por seu endereço em vez de comparar os valores para os quais eles apontam (que é o que a implementação `PartialEq for &T` faz).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// As fatias também são comparadas por seu comprimento (indicadores de gordura):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits também são comparados por sua implementação:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Os ponteiros têm endereços iguais.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Os objetos têm endereços iguais, mas o `Trait` tem implementações diferentes.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Converter a referência em um `*const u8` compara por endereço.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash um ponteiro bruto.
///
/// Isso pode ser usado para fazer o hash de uma referência `&T` (que coage a `*const T` implicitamente) por seu endereço em vez do valor para o qual ele aponta (que é o que a implementação `Hash for &T` faz).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impls para ponteiros de função
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: O elenco intermediário como usize é necessário para AVR
                // para que o espaço de endereço do ponteiro de função de origem seja preservado no ponteiro de função final.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: O elenco intermediário como usize é necessário para AVR
                // para que o espaço de endereço do ponteiro de função de origem seja preservado no ponteiro de função final.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Sem funções variáveis com 0 parâmetros
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Crie um ponteiro bruto `const` para um local, sem criar uma referência intermediária.
///
/// A criação de uma referência com o `&`/`&mut` só é permitida se o ponteiro estiver alinhado corretamente e apontar para os dados inicializados.
/// Para os casos em que esses requisitos não são válidos, ponteiros brutos devem ser usados.
/// No entanto, o `&expr as *const _` cria uma referência antes de convertê-la em um ponteiro bruto, e essa referência está sujeita às mesmas regras de todas as outras referências.
///
/// Esta macro pode criar um ponteiro bruto *sem* criar uma referência primeiro.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` criaria uma referência desalinhada e, portanto, seria um comportamento indefinido!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Crie um ponteiro bruto `mut` para um local, sem criar uma referência intermediária.
///
/// A criação de uma referência com o `&`/`&mut` só é permitida se o ponteiro estiver alinhado corretamente e apontar para os dados inicializados.
/// Para os casos em que esses requisitos não são válidos, ponteiros brutos devem ser usados.
/// No entanto, o `&mut expr as *mut _` cria uma referência antes de convertê-la em um ponteiro bruto, e essa referência está sujeita às mesmas regras de todas as outras referências.
///
/// Esta macro pode criar um ponteiro bruto *sem* criar uma referência primeiro.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` criaria uma referência desalinhada e, portanto, seria um comportamento indefinido!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` força a cópia do campo em vez de criar uma referência.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}