use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// Retorna `true` se o ponteiro for nulo.
    ///
    /// Observe que os tipos não dimensionados têm muitos ponteiros nulos possíveis, já que apenas o ponteiro de dados brutos é considerado, não seu comprimento, vtable, etc.
    /// Portanto, dois ponteiros que são nulos ainda podem não ser comparados entre si.
    ///
    /// ## Comportamento durante a avaliação const
    ///
    /// Quando esta função é usada durante a avaliação const, ela pode retornar `false` para ponteiros que se revelam nulos no tempo de execução.
    /// Especificamente, quando um ponteiro para alguma memória é deslocado além de seus limites de forma que o ponteiro resultante seja nulo, a função ainda retornará `false`.
    ///
    /// Não há como o CTFE saber a posição absoluta dessa memória, então não podemos dizer se o ponteiro é nulo ou não.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Compare por meio de um elenco com um ponteiro fino, então ponteiros gordos estão considerando apenas sua parte "data" para nulidade.
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// Converte para um ponteiro de outro tipo.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// Decompor um ponteiro (possivelmente largo) em seus componentes de endereço e metadados.
    ///
    /// O ponteiro pode ser reconstruído posteriormente com o [`from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// Retorna `None` se o ponteiro for nulo ou então retorna uma referência compartilhada para o valor empacotado em `Some`.Se o valor não for inicializado, [`as_uninit_ref`] deve ser usado em seu lugar.
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// Ao chamar este método, você deve garantir que *ou* o ponteiro seja NULL *ou* todas as opções a seguir sejam verdadeiras:
    ///
    /// * O ponteiro deve estar alinhado corretamente.
    ///
    /// * Deve ser "dereferencable" no sentido definido em [the module documentation].
    ///
    /// * O ponteiro deve apontar para uma instância inicializada de `T`.
    ///
    /// * Você deve aplicar as regras de aliasing de Rust, uma vez que o tempo de vida retornado `'a` é escolhido arbitrariamente e não reflete necessariamente o tempo de vida real dos dados.
    ///   Em particular, durante esse tempo de vida, a memória para a qual o ponteiro aponta não deve sofrer mutação (exceto dentro do `UnsafeCell`).
    ///
    /// Isso se aplica mesmo se o resultado deste método não for usado!
    /// (A parte sobre a inicialização ainda não foi totalmente decidida, mas até que seja, a única abordagem segura é garantir que eles sejam realmente inicializados.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Versão nula não verificada
    ///
    /// Se você tiver certeza de que o ponteiro nunca pode ser nulo e está procurando algum tipo de `as_ref_unchecked` que retorne o `&T` em vez de `Option<&T>`, saiba que você pode cancelar a referência do ponteiro diretamente.
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SEGURANÇA: o chamador deve garantir que o `self` é válido
        // para uma referência se não for nulo.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Retorna `None` se o ponteiro for nulo ou então retorna uma referência compartilhada para o valor empacotado em `Some`.
    /// Ao contrário do [`as_ref`], isso não exige que o valor seja inicializado.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Ao chamar este método, você deve garantir que *ou* o ponteiro seja NULL *ou* todas as opções a seguir sejam verdadeiras:
    ///
    /// * O ponteiro deve estar alinhado corretamente.
    ///
    /// * Deve ser "dereferencable" no sentido definido em [the module documentation].
    ///
    /// * Você deve aplicar as regras de aliasing de Rust, uma vez que o tempo de vida retornado `'a` é escolhido arbitrariamente e não reflete necessariamente o tempo de vida real dos dados.
    ///
    ///   Em particular, durante esse tempo de vida, a memória para a qual o ponteiro aponta não deve sofrer mutação (exceto dentro do `UnsafeCell`).
    ///
    /// Isso se aplica mesmo se o resultado deste método não for usado!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SEGURANÇA: o chamador deve garantir que o `self` atenda a todos os
        // requisitos para uma referência.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Calcula o deslocamento de um ponteiro.
    ///
    /// `count` está em unidades de T;por exemplo, um `count` de 3 representa um deslocamento de ponteiro de bytes `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Se qualquer uma das seguintes condições for violada, o resultado será Comportamento Indefinido:
    ///
    /// * Tanto o ponteiro inicial quanto o resultante devem estar dentro dos limites ou um byte após o final do mesmo objeto alocado.
    /// Observe que em Rust, cada variável (stack-allocated) é considerada um objeto alocado separado.
    ///
    /// * O deslocamento calculado,**em bytes**, não pode estourar um `isize`.
    ///
    /// * O deslocamento dentro dos limites não pode depender do espaço de endereço "wrapping around".Ou seja, a soma de precisão infinita,**em bytes** deve caber em um usize.
    ///
    /// O compilador e a biblioteca padrão geralmente tentam garantir que as alocações nunca atinjam um tamanho em que um deslocamento seja uma preocupação.
    /// Por exemplo, o `Vec` e o `Box` garantem que nunca alocem mais de `isize::MAX` bytes, portanto, o `vec.as_ptr().add(vec.len())` está sempre seguro.
    ///
    /// A maioria das plataformas fundamentalmente não consegue nem construir tal alocação.
    /// Por exemplo, nenhuma plataforma de 64 bits conhecida pode atender a uma solicitação de 2 <sup>63</sup> bytes devido a limitações da tabela de páginas ou divisão do espaço de endereço.
    /// No entanto, algumas plataformas de 32 e 16 bits podem atender com êxito a uma solicitação de mais de `isize::MAX` bytes com itens como Extensão de endereço físico.
    ///
    /// Como tal, a memória adquirida diretamente de alocadores ou arquivos mapeados de memória *pode* ser muito grande para lidar com esta função.
    ///
    /// Considere usar o [`wrapping_offset`] se essas restrições forem difíceis de satisfazer.
    /// A única vantagem desse método é que ele permite otimizações de compilador mais agressivas.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SEGURANÇA: o chamador deve respeitar o contrato de segurança do `offset`.
        unsafe { intrinsics::offset(self, count) }
    }

    /// Calcula o deslocamento de um ponteiro usando a aritmética de agrupamento.
    ///
    /// `count` está em unidades de T;por exemplo, um `count` de 3 representa um deslocamento de ponteiro de bytes `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Esta operação em si é sempre segura, mas usar o ponteiro resultante não é.
    ///
    /// O ponteiro resultante permanece anexado ao mesmo objeto alocado para o qual o `self` aponta.
    /// Ele *não* pode ser usado para acessar um objeto alocado diferente.Observe que em Rust, cada variável (stack-allocated) é considerada um objeto alocado separado.
    ///
    /// Em outras palavras, o `let z = x.wrapping_offset((y as isize) - (x as isize))`*não* torna o `z` igual ao `y`, mesmo se assumirmos que o `T` tem o tamanho `1` e não há estouro: o `z` ainda está anexado ao objeto ao qual o `x` está anexado e desreferenciou-o como comportamento indefinido, a menos que `x` e Ponto `y` no mesmo objeto alocado.
    ///
    /// Comparado ao [`offset`], este método basicamente atrasa o requisito de permanecer dentro do mesmo objeto alocado: [`offset`] é um comportamento indefinido imediato ao cruzar os limites do objeto;O `wrapping_offset` produz um ponteiro, mas ainda leva a um comportamento indefinido se um ponteiro for desreferenciado quando estiver fora dos limites do objeto ao qual está anexado.
    /// [`offset`] pode ser otimizado melhor e, portanto, é preferível em código sensível ao desempenho.
    ///
    /// A verificação atrasada considera apenas o valor do ponteiro que foi desreferenciado, não os valores intermediários usados durante o cálculo do resultado final.
    /// Por exemplo, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` é sempre igual a `x`.Em outras palavras, é permitido deixar o objeto alocado e inseri-lo novamente mais tarde.
    ///
    /// Se você precisar cruzar os limites do objeto, lance o ponteiro para um inteiro e faça a aritmética lá.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // Iterar usando um ponteiro bruto em incrementos de dois elementos
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // Este loop imprime "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SEGURANÇA: o `arith_offset` intrínseco não possui pré-requisitos para ser acionado.
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// Calcula a distância entre dois ponteiros.O valor retornado está em unidades de T: a distância em bytes é dividida por `mem::size_of::<T>()`.
    ///
    /// Esta função é o inverso de [`offset`].
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// Se qualquer uma das seguintes condições for violada, o resultado será Comportamento Indefinido:
    ///
    /// * O ponteiro inicial e o outro devem estar dentro dos limites ou um byte após o final do mesmo objeto alocado.
    /// Observe que em Rust, cada variável (stack-allocated) é considerada um objeto alocado separado.
    ///
    /// * Ambos os ponteiros devem ser *derivados* de um ponteiro para o mesmo objeto.
    ///   (Veja abaixo um exemplo.)
    ///
    /// * A distância entre os ponteiros, em bytes, deve ser um múltiplo exato do tamanho de `T`.
    ///
    /// * A distância entre os ponteiros,**em bytes**, não pode ultrapassar um `isize`.
    ///
    /// * A distância dentro dos limites não pode depender do espaço de endereço "wrapping around".
    ///
    /// Os tipos Rust nunca são maiores que as alocações `isize::MAX` e Rust nunca envolvem o espaço de endereço, portanto, dois ponteiros dentro de algum valor de qualquer tipo Rust `T` sempre satisfarão as duas últimas condições.
    ///
    /// A biblioteca padrão também geralmente garante que as alocações nunca atinjam um tamanho em que um deslocamento seja uma preocupação.
    /// Por exemplo, o `Vec` e o `Box` garantem que nunca alocem mais de `isize::MAX` bytes, portanto, o `ptr_into_vec.offset_from(vec.as_ptr())` sempre satisfaz as duas últimas condições.
    ///
    /// A maioria das plataformas fundamentalmente não consegue nem construir uma alocação tão grande.
    /// Por exemplo, nenhuma plataforma de 64 bits conhecida pode atender a uma solicitação de 2 <sup>63</sup> bytes devido a limitações da tabela de páginas ou divisão do espaço de endereço.
    /// No entanto, algumas plataformas de 32 e 16 bits podem atender com êxito a uma solicitação de mais de `isize::MAX` bytes com itens como Extensão de endereço físico.
    /// Como tal, a memória adquirida diretamente de alocadores ou arquivos mapeados de memória *pode* ser muito grande para lidar com esta função.
    /// (Observe que o [`offset`] e o [`add`] também têm uma limitação semelhante e, portanto, também não podem ser usados em alocações tão grandes.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Esta função panics se `T` for um Tipo ("ZST") de tamanho zero.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Uso incorreto*:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Torne ptr2_other um "alias" de ptr2, mas derivado de ptr1.
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Como ptr2_other e ptr2 são derivados de ponteiros para objetos diferentes, calcular seu deslocamento é um comportamento indefinido, embora eles apontem para o mesmo endereço!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Comportamento Indefinido
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // SEGURANÇA: o chamador deve respeitar o contrato de segurança do `ptr_offset_from`.
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// Retorna se dois ponteiros são iguais.
    ///
    /// Em tempo de execução, essa função se comporta como `self == other`.
    /// No entanto, em alguns contextos (por exemplo, avaliação em tempo de compilação), nem sempre é possível determinar a igualdade de dois ponteiros, portanto, essa função pode retornar de forma espúria `false` para ponteiros que mais tarde acabam sendo iguais.
    ///
    /// Mas quando ele retorna `true`, os ponteiros são garantidos como iguais.
    ///
    /// Esta função é o espelho do [`guaranteed_ne`], mas não seu inverso.Existem comparações de ponteiro para as quais ambas as funções retornam `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// O valor de retorno pode mudar dependendo da versão do compilador e o código não seguro pode não depender do resultado desta função para integridade.
    /// É sugerido usar esta função apenas para otimizações de desempenho onde valores de retorno `false` espúrios por esta função não afetam o resultado, mas apenas o desempenho.
    /// As consequências de usar esse método para fazer o código de tempo de execução e de tempo de compilação se comportarem de maneira diferente não foram exploradas.
    /// Este método não deve ser usado para introduzir tais diferenças, e também não deve ser estabilizado antes de termos um melhor entendimento deste assunto.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// Retorna se dois ponteiros são desiguais.
    ///
    /// Em tempo de execução, essa função se comporta como `self != other`.
    /// No entanto, em alguns contextos (por exemplo, avaliação em tempo de compilação), nem sempre é possível determinar a desigualdade de dois ponteiros, portanto, essa função pode retornar de forma espúria `false` para ponteiros que mais tarde acabam sendo desiguais.
    ///
    /// Mas quando ele retorna `true`, os ponteiros são certamente desiguais.
    ///
    /// Esta função é o espelho do [`guaranteed_eq`], mas não seu inverso.Existem comparações de ponteiro para as quais ambas as funções retornam `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// O valor de retorno pode mudar dependendo da versão do compilador e o código não seguro pode não depender do resultado desta função para integridade.
    /// É sugerido usar esta função apenas para otimizações de desempenho onde valores de retorno `false` espúrios por esta função não afetam o resultado, mas apenas o desempenho.
    /// As consequências de usar esse método para fazer o código de tempo de execução e de tempo de compilação se comportarem de maneira diferente não foram exploradas.
    /// Este método não deve ser usado para introduzir tais diferenças, e também não deve ser estabilizado antes de termos um melhor entendimento deste assunto.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// Calcula o deslocamento de um ponteiro (conveniência para `.offset(count as isize)`).
    ///
    /// `count` está em unidades de T;por exemplo, um `count` de 3 representa um deslocamento de ponteiro de bytes `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Se qualquer uma das seguintes condições for violada, o resultado será Comportamento Indefinido:
    ///
    /// * Tanto o ponteiro inicial quanto o resultante devem estar dentro dos limites ou um byte após o final do mesmo objeto alocado.
    /// Observe que em Rust, cada variável (stack-allocated) é considerada um objeto alocado separado.
    ///
    /// * O deslocamento calculado,**em bytes**, não pode estourar um `isize`.
    ///
    /// * O deslocamento dentro dos limites não pode depender do espaço de endereço "wrapping around".Ou seja, a soma de precisão infinita deve caber em um `usize`.
    ///
    /// O compilador e a biblioteca padrão geralmente tentam garantir que as alocações nunca atinjam um tamanho em que um deslocamento seja uma preocupação.
    /// Por exemplo, o `Vec` e o `Box` garantem que nunca alocem mais de `isize::MAX` bytes, portanto, o `vec.as_ptr().add(vec.len())` está sempre seguro.
    ///
    /// A maioria das plataformas fundamentalmente não consegue nem construir tal alocação.
    /// Por exemplo, nenhuma plataforma de 64 bits conhecida pode atender a uma solicitação de 2 <sup>63</sup> bytes devido a limitações da tabela de páginas ou divisão do espaço de endereço.
    /// No entanto, algumas plataformas de 32 e 16 bits podem atender com êxito a uma solicitação de mais de `isize::MAX` bytes com itens como Extensão de endereço físico.
    ///
    /// Como tal, a memória adquirida diretamente de alocadores ou arquivos mapeados de memória *pode* ser muito grande para lidar com esta função.
    ///
    /// Considere usar o [`wrapping_add`] se essas restrições forem difíceis de satisfazer.
    /// A única vantagem desse método é que ele permite otimizações de compilador mais agressivas.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SEGURANÇA: o chamador deve respeitar o contrato de segurança do `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Calcula o deslocamento de um ponteiro (conveniência para `.offset ((conte como isize).wrapping_neg())`).
    ///
    /// `count` está em unidades de T;por exemplo, um `count` de 3 representa um deslocamento de ponteiro de bytes `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Se qualquer uma das seguintes condições for violada, o resultado será Comportamento Indefinido:
    ///
    /// * Tanto o ponteiro inicial quanto o resultante devem estar dentro dos limites ou um byte após o final do mesmo objeto alocado.
    /// Observe que em Rust, cada variável (stack-allocated) é considerada um objeto alocado separado.
    ///
    /// * O deslocamento calculado não pode exceder `isize::MAX`**bytes**.
    ///
    /// * O deslocamento dentro dos limites não pode depender do espaço de endereço "wrapping around".Ou seja, a soma de precisão infinita deve caber em um usize.
    ///
    /// O compilador e a biblioteca padrão geralmente tentam garantir que as alocações nunca atinjam um tamanho em que um deslocamento seja uma preocupação.
    /// Por exemplo, o `Vec` e o `Box` garantem que nunca alocem mais de `isize::MAX` bytes, portanto, o `vec.as_ptr().add(vec.len()).sub(vec.len())` está sempre seguro.
    ///
    /// A maioria das plataformas fundamentalmente não consegue nem construir tal alocação.
    /// Por exemplo, nenhuma plataforma de 64 bits conhecida pode atender a uma solicitação de 2 <sup>63</sup> bytes devido a limitações da tabela de páginas ou divisão do espaço de endereço.
    /// No entanto, algumas plataformas de 32 e 16 bits podem atender com êxito a uma solicitação de mais de `isize::MAX` bytes com itens como Extensão de endereço físico.
    ///
    /// Como tal, a memória adquirida diretamente de alocadores ou arquivos mapeados de memória *pode* ser muito grande para lidar com esta função.
    ///
    /// Considere usar o [`wrapping_sub`] se essas restrições forem difíceis de satisfazer.
    /// A única vantagem desse método é que ele permite otimizações de compilador mais agressivas.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SEGURANÇA: o chamador deve respeitar o contrato de segurança do `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Calcula o deslocamento de um ponteiro usando a aritmética de agrupamento.
    /// (conveniência para `.wrapping_offset(count as isize)`)
    ///
    /// `count` está em unidades de T;por exemplo, um `count` de 3 representa um deslocamento de ponteiro de bytes `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Esta operação em si é sempre segura, mas usar o ponteiro resultante não é.
    ///
    /// O ponteiro resultante permanece anexado ao mesmo objeto alocado para o qual o `self` aponta.
    /// Ele *não* pode ser usado para acessar um objeto alocado diferente.Observe que em Rust, cada variável (stack-allocated) é considerada um objeto alocado separado.
    ///
    /// Em outras palavras, o `let z = x.wrapping_add((y as usize) - (x as usize))`*não* torna o `z` igual ao `y`, mesmo se assumirmos que o `T` tem o tamanho `1` e não há estouro: o `z` ainda está anexado ao objeto ao qual o `x` está anexado e desreferenciou-o como comportamento indefinido, a menos que `x` e Ponto `y` no mesmo objeto alocado.
    ///
    /// Comparado ao [`add`], este método basicamente atrasa o requisito de permanecer dentro do mesmo objeto alocado: [`add`] é um comportamento indefinido imediato ao cruzar os limites do objeto;O `wrapping_add` produz um ponteiro, mas ainda leva a um comportamento indefinido se um ponteiro for desreferenciado quando estiver fora dos limites do objeto ao qual está anexado.
    /// [`add`] pode ser otimizado melhor e, portanto, é preferível em código sensível ao desempenho.
    ///
    /// A verificação atrasada considera apenas o valor do ponteiro que foi desreferenciado, não os valores intermediários usados durante o cálculo do resultado final.
    /// Por exemplo, `x.wrapping_add(o).wrapping_sub(o)` é sempre igual a `x`.Em outras palavras, é permitido deixar o objeto alocado e inseri-lo novamente mais tarde.
    ///
    /// Se você precisar cruzar os limites do objeto, lance o ponteiro para um inteiro e faça a aritmética lá.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // Iterar usando um ponteiro bruto em incrementos de dois elementos
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Este loop imprime "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Calcula o deslocamento de um ponteiro usando a aritmética de agrupamento.
    /// (conveniência para `.wrapping_offset ((conta como isize).wrapping_neg())`)
    ///
    /// `count` está em unidades de T;por exemplo, um `count` de 3 representa um deslocamento de ponteiro de bytes `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Esta operação em si é sempre segura, mas usar o ponteiro resultante não é.
    ///
    /// O ponteiro resultante permanece anexado ao mesmo objeto alocado para o qual o `self` aponta.
    /// Ele *não* pode ser usado para acessar um objeto alocado diferente.Observe que em Rust, cada variável (stack-allocated) é considerada um objeto alocado separado.
    ///
    /// Em outras palavras, o `let z = x.wrapping_sub((x as usize) - (y as usize))`*não* torna o `z` igual ao `y`, mesmo se assumirmos que o `T` tem o tamanho `1` e não há estouro: o `z` ainda está anexado ao objeto ao qual o `x` está anexado e desreferenciou-o como comportamento indefinido, a menos que `x` e Ponto `y` no mesmo objeto alocado.
    ///
    /// Comparado ao [`sub`], este método basicamente atrasa o requisito de permanecer dentro do mesmo objeto alocado: [`sub`] é um comportamento indefinido imediato ao cruzar os limites do objeto;O `wrapping_sub` produz um ponteiro, mas ainda leva a um comportamento indefinido se um ponteiro for desreferenciado quando estiver fora dos limites do objeto ao qual está anexado.
    /// [`sub`] pode ser otimizado melhor e, portanto, é preferível em código sensível ao desempenho.
    ///
    /// A verificação atrasada considera apenas o valor do ponteiro que foi desreferenciado, não os valores intermediários usados durante o cálculo do resultado final.
    /// Por exemplo, `x.wrapping_add(o).wrapping_sub(o)` é sempre igual a `x`.Em outras palavras, é permitido deixar o objeto alocado e inseri-lo novamente mais tarde.
    ///
    /// Se você precisar cruzar os limites do objeto, lance o ponteiro para um inteiro e faça a aritmética lá.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // Iterar usando um ponteiro bruto em incrementos de dois elementos (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Este loop imprime "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Define o valor do ponteiro em `ptr`.
    ///
    /// No caso de `self` ser um ponteiro (fat) para um tipo não dimensionado, esta operação afetará apenas a parte do ponteiro, enquanto que para os ponteiros (thin) para tipos dimensionados, isso tem o mesmo efeito de uma atribuição simples.
    ///
    /// O ponteiro resultante terá proveniência de `val`, ou seja, para um ponteiro gordo, esta operação é semanticamente igual a criar um novo ponteiro gordo com o valor do ponteiro de dados de `val` mas os metadados de `self`.
    ///
    ///
    /// # Examples
    ///
    /// Esta função é útil principalmente para permitir a aritmética de ponteiros por byte em ponteiros potencialmente gordos:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // irá imprimir "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // SEGURANÇA: No caso de um ponteiro fino, esta operação é idêntica
        // para uma tarefa simples.
        // No caso de um ponteiro gordo, com a implementação atual do layout do ponteiro gordo, o primeiro campo desse ponteiro é sempre o ponteiro de dados, que também é atribuído.
        //
        unsafe { *thin = val };
        self
    }

    /// Lê o valor do `self` sem movê-lo.
    /// Isso deixa a memória do `self` inalterada.
    ///
    /// Consulte [`ptr::read`] para questões de segurança e exemplos.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SEGURANÇA: o chamador deve respeitar o contrato de segurança do `read`.
        unsafe { read(self) }
    }

    /// Executa uma leitura volátil do valor de `self` sem movê-lo.Isso deixa a memória no `self` inalterada.
    ///
    /// As operações voláteis têm como objetivo atuar na memória do I/O e têm a garantia de não serem eliminadas ou reordenadas pelo compilador em outras operações voláteis.
    ///
    ///
    /// Consulte [`ptr::read_volatile`] para questões de segurança e exemplos.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SEGURANÇA: o chamador deve respeitar o contrato de segurança do `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Lê o valor do `self` sem movê-lo.
    /// Isso deixa a memória do `self` inalterada.
    ///
    /// Ao contrário do `read`, o ponteiro pode estar desalinhado.
    ///
    /// Consulte [`ptr::read_unaligned`] para questões de segurança e exemplos.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SEGURANÇA: o chamador deve respeitar o contrato de segurança do `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Copia bytes `count * size_of<T>` de `self` para `dest`.
    /// A origem e o destino podem se sobrepor.
    ///
    /// NOTE: ele tem a *mesma* ordem de argumentos do [`ptr::copy`].
    ///
    /// Consulte [`ptr::copy`] para questões de segurança e exemplos.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SEGURANÇA: o chamador deve respeitar o contrato de segurança do `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Copia bytes `count * size_of<T>` de `self` para `dest`.
    /// A origem e o destino *não* podem se sobrepor.
    ///
    /// NOTE: ele tem a *mesma* ordem de argumentos do [`ptr::copy_nonoverlapping`].
    ///
    /// Consulte [`ptr::copy_nonoverlapping`] para questões de segurança e exemplos.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SEGURANÇA: o chamador deve respeitar o contrato de segurança do `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Calcula o deslocamento que precisa ser aplicado ao ponteiro para torná-lo alinhado ao `align`.
    ///
    /// Se não for possível alinhar o ponteiro, a implementação retorna `usize::MAX`.
    /// É permitido que a implementação *sempre* retorne `usize::MAX`.
    /// Apenas o desempenho do seu algoritmo pode depender da obtenção de um deslocamento utilizável aqui, não de sua correção.
    ///
    /// O deslocamento é expresso em número de elementos `T` e não em bytes.O valor retornado pode ser usado com o método `wrapping_add`.
    ///
    /// Não há garantias de que deslocar o ponteiro não irá estourar ou ir além da alocação para a qual o ponteiro aponta.
    ///
    /// É responsabilidade do chamador garantir que o deslocamento retornado esteja correto em todos os termos, exceto alinhamento.
    ///
    /// # Panics
    ///
    /// A função panics se `align` não for uma potência de dois.
    ///
    /// # Examples
    ///
    /// Acessando `u8` adjacente como `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // embora o ponteiro possa ser alinhado via `offset`, ele apontaria para fora da alocação
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // SEGURANÇA: `align` foi verificado para ser uma potência de 2 acima
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// Retorna o comprimento de uma fatia bruta.
    ///
    /// O valor retornado é o número de **elementos**, não o número de bytes.
    ///
    /// Esta função é segura, mesmo quando a fatia bruta não pode ser convertida em uma referência de fatia porque o ponteiro é nulo ou desalinhado.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SEGURANÇA: isso é seguro porque `*const [T]` e `FatPtr<T>` têm o mesmo layout.
            // Somente o `std` pode fazer essa garantia.
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Retorna um ponteiro bruto para o buffer da fatia.
    ///
    /// Isso é equivalente a fundir `self` em `*const T`, mas é mais seguro para tipos.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// Retorna um ponteiro bruto para um elemento ou subslice, sem fazer a verificação de limites.
    ///
    /// Chamar este método com um índice fora dos limites ou quando o `self` não é desreferenciável é *[comportamento indefinido]* mesmo se o ponteiro resultante não for usado.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // SEGURANÇA: o chamador garante que o `self` seja desreferenciável e o `index` dentro dos limites.
        unsafe { index.get_unchecked(self) }
    }

    /// Retorna `None` se o ponteiro for nulo ou então retorna uma fatia compartilhada para o valor empacotado em `Some`.
    /// Ao contrário do [`as_ref`], isso não exige que o valor seja inicializado.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Ao chamar este método, você deve garantir que *ou* o ponteiro seja NULL *ou* todas as opções a seguir sejam verdadeiras:
    ///
    /// * O ponteiro deve ser [valid] para leituras de muitos bytes `ptr.len() * mem::size_of::<T>()` e deve estar alinhado corretamente.Isso significa em particular:
    ///
    ///     * Todo o intervalo de memória desta fatia deve estar contido em um único objeto alocado!
    ///       As fatias nunca podem se estender por vários objetos alocados.
    ///
    ///     * O ponteiro deve estar alinhado mesmo para fatias de comprimento zero.
    ///     Um motivo para isso é que as otimizações de layout enum podem contar com referências (incluindo fatias de qualquer comprimento) alinhadas e não nulas para distingui-las de outros dados.
    ///
    ///     Você pode obter um ponteiro que pode ser usado como `data` para fatias de comprimento zero usando [`NonNull::dangling()`].
    ///
    /// * O tamanho total `ptr.len() * mem::size_of::<T>()` da fatia não deve ser maior que `isize::MAX`.
    ///   Consulte a documentação de segurança do [`pointer::offset`].
    ///
    /// * Você deve aplicar as regras de aliasing de Rust, uma vez que o tempo de vida retornado `'a` é escolhido arbitrariamente e não reflete necessariamente o tempo de vida real dos dados.
    ///   Em particular, durante esse tempo de vida, a memória para a qual o ponteiro aponta não deve sofrer mutação (exceto dentro do `UnsafeCell`).
    ///
    /// Isso se aplica mesmo se o resultado deste método não for usado!
    ///
    /// Consulte também [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SEGURANÇA: o chamador deve respeitar o contrato de segurança do `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// Igualdade para ponteiros
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// Comparação para ponteiros
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}