use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` mas diferente de zero e covariante.
///
/// Geralmente, essa é a coisa correta a ser usada ao construir estruturas de dados usando ponteiros brutos, mas, em última análise, é mais perigosa de usar devido a suas propriedades adicionais.Se você não tem certeza se deve usar o `NonNull<T>`, basta usar o `*mut T`!
///
/// Ao contrário de `*mut T`, o ponteiro deve sempre ser não nulo, mesmo se o ponteiro nunca for desreferenciado.Isso ocorre para que enums possam usar este valor proibido como discriminante-`Option<NonNull<T>>` tem o mesmo tamanho que `* mut T`.
/// No entanto, o ponteiro ainda pode oscilar se não for desreferenciado.
///
/// Ao contrário do `*mut T`, o `NonNull<T>` foi escolhido para ser covariante sobre o `T`.Isso torna possível usar `NonNull<T>` ao construir tipos covariantes, mas apresenta o risco de insalubridade se usado em um tipo que não deveria ser covariante.
/// (A escolha oposta foi feita para o `*mut T`, embora tecnicamente a deficiência só pudesse ser causada pela chamada de funções não seguras.)
///
/// A covariância está correta para a maioria das abstrações seguras, como `Box`, `Rc`, `Arc`, `Vec` e `LinkedList`.Este é o caso porque eles fornecem uma API pública que segue as regras mutáveis XOR compartilhadas normais de Rust.
///
/// Se o seu tipo não pode ser covariante com segurança, você deve garantir que ele contenha algum campo adicional para fornecer invariância.Freqüentemente, esse campo será do tipo [`PhantomData`], como `PhantomData<Cell<T>>` ou `PhantomData<&'a mut T>`.
///
/// Observe que `NonNull<T>` tem uma instância `From` para `&T`.No entanto, isso não altera o fato de que a mutação por meio de uma referência compartilhada (ponteiro derivado de uma) é um comportamento indefinido, a menos que a mutação aconteça dentro de um [`UnsafeCell<T>`].O mesmo vale para a criação de uma referência mutável a partir de uma referência compartilhada.
///
/// Ao usar esta instância `From` sem um `UnsafeCell<T>`, é sua responsabilidade garantir que o `as_mut` nunca seja chamado e o `as_ptr` nunca seja usado para mutação.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` os ponteiros não são `Send` porque os dados aos quais eles fazem referência podem ter um alias.
// NB, este impl é desnecessário, mas deve fornecer melhores mensagens de erro.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` os ponteiros não são `Sync` porque os dados aos quais eles fazem referência podem ter um alias.
// NB, este impl é desnecessário, mas deve fornecer melhores mensagens de erro.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Cria um novo `NonNull` oscilante, mas bem alinhado.
    ///
    /// Isso é útil para inicializar tipos que alocam lentamente, como o `Vec::new` faz.
    ///
    /// Observe que o valor do ponteiro pode representar potencialmente um ponteiro válido para um `T`, o que significa que ele não deve ser usado como um valor sentinela "not yet initialized".
    /// Os tipos que alocam lentamente devem rastrear a inicialização por algum outro meio.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // SEGURANÇA: mem::align_of() retorna um usize diferente de zero que é então convertido
        // para um * mut T.
        // Portanto, `ptr` não é nulo e as condições para chamar new_unchecked() são respeitadas.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Retorna uma referência compartilhada para o valor.Ao contrário do [`as_ref`], isso não exige que o valor seja inicializado.
    ///
    /// Para a contraparte mutável, consulte [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Ao chamar este método, você deve garantir que todas as opções a seguir sejam verdadeiras:
    ///
    /// * O ponteiro deve estar alinhado corretamente.
    ///
    /// * Deve ser "dereferencable" no sentido definido em [the module documentation].
    ///
    /// * Você deve aplicar as regras de aliasing de Rust, uma vez que o tempo de vida retornado `'a` é escolhido arbitrariamente e não reflete necessariamente o tempo de vida real dos dados.
    ///
    ///   Em particular, durante esse tempo de vida, a memória para a qual o ponteiro aponta não deve sofrer mutação (exceto dentro do `UnsafeCell`).
    ///
    /// Isso se aplica mesmo se o resultado deste método não for usado!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // SEGURANÇA: o chamador deve garantir que o `self` atenda a todos os
        // requisitos para uma referência.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Retorna referências exclusivas ao valor.Ao contrário do [`as_mut`], isso não exige que o valor seja inicializado.
    ///
    /// Para obter a contrapartida compartilhada, consulte [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Ao chamar este método, você deve garantir que todas as opções a seguir sejam verdadeiras:
    ///
    /// * O ponteiro deve estar alinhado corretamente.
    ///
    /// * Deve ser "dereferencable" no sentido definido em [the module documentation].
    ///
    /// * Você deve aplicar as regras de aliasing de Rust, uma vez que o tempo de vida retornado `'a` é escolhido arbitrariamente e não reflete necessariamente o tempo de vida real dos dados.
    ///
    ///   Em particular, durante este tempo de vida, a memória para a qual o ponteiro aponta não deve ser acessada (lida ou escrita) por meio de qualquer outro ponteiro.
    ///
    /// Isso se aplica mesmo se o resultado deste método não for usado!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // SEGURANÇA: o chamador deve garantir que o `self` atenda a todos os
        // requisitos para uma referência.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Cria um novo `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` deve ser não nulo.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SEGURANÇA: o chamador deve garantir que o `ptr` não é nulo.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Cria um novo `NonNull` se `ptr` não for nulo.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SEGURANÇA: O ponteiro já está verificado e não é nulo
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Executa a mesma funcionalidade do [`std::ptr::from_raw_parts`], exceto que um ponteiro `NonNull` é retornado, ao contrário de um ponteiro `*const` bruto.
    ///
    ///
    /// Consulte a documentação do [`std::ptr::from_raw_parts`] para obter mais detalhes.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SEGURANÇA: O resultado de `ptr::from::raw_parts_mut` não é nulo porque `data_address` é.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Decompor um ponteiro (possivelmente largo) em seus componentes de endereço e metadados.
    ///
    /// O ponteiro pode ser reconstruído posteriormente com o [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Adquire o ponteiro `*mut` subjacente.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Retorna uma referência compartilhada para o valor.Se o valor não for inicializado, [`as_uninit_ref`] deve ser usado em seu lugar.
    ///
    /// Para a contraparte mutável, consulte [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Ao chamar este método, você deve garantir que todas as opções a seguir sejam verdadeiras:
    ///
    /// * O ponteiro deve estar alinhado corretamente.
    ///
    /// * Deve ser "dereferencable" no sentido definido em [the module documentation].
    ///
    /// * O ponteiro deve apontar para uma instância inicializada de `T`.
    ///
    /// * Você deve aplicar as regras de aliasing de Rust, uma vez que o tempo de vida retornado `'a` é escolhido arbitrariamente e não reflete necessariamente o tempo de vida real dos dados.
    ///
    ///   Em particular, durante esse tempo de vida, a memória para a qual o ponteiro aponta não deve sofrer mutação (exceto dentro do `UnsafeCell`).
    ///
    /// Isso se aplica mesmo se o resultado deste método não for usado!
    /// (A parte sobre a inicialização ainda não foi totalmente decidida, mas até que seja, a única abordagem segura é garantir que eles sejam realmente inicializados.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SEGURANÇA: o chamador deve garantir que o `self` atenda a todos os
        // requisitos para uma referência.
        unsafe { &*self.as_ptr() }
    }

    /// Retorna uma referência única para o valor.Se o valor não for inicializado, [`as_uninit_mut`] deve ser usado em seu lugar.
    ///
    /// Para obter a contrapartida compartilhada, consulte [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Ao chamar este método, você deve garantir que todas as opções a seguir sejam verdadeiras:
    ///
    /// * O ponteiro deve estar alinhado corretamente.
    ///
    /// * Deve ser "dereferencable" no sentido definido em [the module documentation].
    ///
    /// * O ponteiro deve apontar para uma instância inicializada de `T`.
    ///
    /// * Você deve aplicar as regras de aliasing de Rust, uma vez que o tempo de vida retornado `'a` é escolhido arbitrariamente e não reflete necessariamente o tempo de vida real dos dados.
    ///
    ///   Em particular, durante este tempo de vida, a memória para a qual o ponteiro aponta não deve ser acessada (lida ou escrita) por meio de qualquer outro ponteiro.
    ///
    /// Isso se aplica mesmo se o resultado deste método não for usado!
    /// (A parte sobre a inicialização ainda não foi totalmente decidida, mas até que seja, a única abordagem segura é garantir que eles sejam realmente inicializados.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SEGURANÇA: o chamador deve garantir que o `self` atenda a todos os
        // requisitos para uma referência mutável.
        unsafe { &mut *self.as_ptr() }
    }

    /// Converte para um ponteiro de outro tipo.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SEGURANÇA: `self` é um ponteiro `NonNull` que é necessariamente não nulo
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Cria uma fatia bruta não nula a partir de um ponteiro fino e um comprimento.
    ///
    /// O argumento `len` é o número de **elementos**, não o número de bytes.
    ///
    /// Esta função é segura, mas cancelar a referência do valor de retorno não é seguro.
    /// Consulte a documentação do [`slice::from_raw_parts`] para obter os requisitos de segurança de fatia.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // crie um ponteiro de fatia ao começar com um ponteiro para o primeiro elemento
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Observe que este exemplo demonstra artificialmente o uso deste método, mas `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SEGURANÇA: `data` é um ponteiro `NonNull` que é necessariamente não nulo
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Retorna o comprimento de uma fatia bruta não nula.
    ///
    /// O valor retornado é o número de **elementos**, não o número de bytes.
    ///
    /// Essa função é segura, mesmo quando a fatia bruta não nula não pode ser desreferenciada para uma fatia porque o ponteiro não tem um endereço válido.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Retorna um ponteiro não nulo para o buffer da fatia.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SEGURANÇA: sabemos que o `self` não é nulo.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Retorna um ponteiro bruto para o buffer da fatia.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Retorna uma referência compartilhada a uma fatia de valores possivelmente não inicializados.Ao contrário do [`as_ref`], isso não exige que o valor seja inicializado.
    ///
    /// Para a contraparte mutável, consulte [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Ao chamar este método, você deve garantir que todas as opções a seguir sejam verdadeiras:
    ///
    /// * O ponteiro deve ser [valid] para leituras de muitos bytes `ptr.len() * mem::size_of::<T>()` e deve estar alinhado corretamente.Isso significa em particular:
    ///
    ///     * Todo o intervalo de memória desta fatia deve estar contido em um único objeto alocado!
    ///       As fatias nunca podem se estender por vários objetos alocados.
    ///
    ///     * O ponteiro deve estar alinhado mesmo para fatias de comprimento zero.
    ///     Um motivo para isso é que as otimizações de layout enum podem contar com referências (incluindo fatias de qualquer comprimento) alinhadas e não nulas para distingui-las de outros dados.
    ///
    ///     Você pode obter um ponteiro que pode ser usado como `data` para fatias de comprimento zero usando [`NonNull::dangling()`].
    ///
    /// * O tamanho total `ptr.len() * mem::size_of::<T>()` da fatia não deve ser maior que `isize::MAX`.
    ///   Consulte a documentação de segurança do [`pointer::offset`].
    ///
    /// * Você deve aplicar as regras de aliasing de Rust, uma vez que o tempo de vida retornado `'a` é escolhido arbitrariamente e não reflete necessariamente o tempo de vida real dos dados.
    ///   Em particular, durante esse tempo de vida, a memória para a qual o ponteiro aponta não deve sofrer mutação (exceto dentro do `UnsafeCell`).
    ///
    /// Isso se aplica mesmo se o resultado deste método não for usado!
    ///
    /// Consulte também [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // SEGURANÇA: o chamador deve respeitar o contrato de segurança do `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Retorna uma referência exclusiva a uma fatia de valores possivelmente não inicializados.Ao contrário do [`as_mut`], isso não exige que o valor seja inicializado.
    ///
    /// Para obter a contrapartida compartilhada, consulte [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Ao chamar este método, você deve garantir que todas as opções a seguir sejam verdadeiras:
    ///
    /// * O ponteiro deve ser [valid] para leituras e gravações de muitos bytes `ptr.len() * mem::size_of::<T>()` e deve estar alinhado corretamente.Isso significa em particular:
    ///
    ///     * Todo o intervalo de memória desta fatia deve estar contido em um único objeto alocado!
    ///       As fatias nunca podem se estender por vários objetos alocados.
    ///
    ///     * O ponteiro deve estar alinhado mesmo para fatias de comprimento zero.
    ///     Um motivo para isso é que as otimizações de layout enum podem contar com referências (incluindo fatias de qualquer comprimento) alinhadas e não nulas para distingui-las de outros dados.
    ///
    ///     Você pode obter um ponteiro que pode ser usado como `data` para fatias de comprimento zero usando [`NonNull::dangling()`].
    ///
    /// * O tamanho total `ptr.len() * mem::size_of::<T>()` da fatia não deve ser maior que `isize::MAX`.
    ///   Consulte a documentação de segurança do [`pointer::offset`].
    ///
    /// * Você deve aplicar as regras de aliasing de Rust, uma vez que o tempo de vida retornado `'a` é escolhido arbitrariamente e não reflete necessariamente o tempo de vida real dos dados.
    ///   Em particular, durante este tempo de vida, a memória para a qual o ponteiro aponta não deve ser acessada (lida ou escrita) por meio de qualquer outro ponteiro.
    ///
    /// Isso se aplica mesmo se o resultado deste método não for usado!
    ///
    /// Consulte também [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Isso é seguro, pois o `memory` é válido para leituras e gravações de muitos bytes de `memory.len()`.
    /// // Observe que chamar `memory.as_mut()` não é permitido aqui, pois o conteúdo pode não ter sido inicializado.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // SEGURANÇA: o chamador deve respeitar o contrato de segurança do `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Retorna um ponteiro bruto para um elemento ou subslice, sem fazer a verificação de limites.
    ///
    /// Chamar este método com um índice fora dos limites ou quando o `self` não é desreferenciável é *[comportamento indefinido]* mesmo se o ponteiro resultante não for usado.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SEGURANÇA: o chamador garante que o `self` seja desreferenciável e o `index` dentro dos limites.
        // Como consequência, o ponteiro resultante não pode ser NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SEGURANÇA: um ponteiro exclusivo não pode ser nulo, portanto, as condições para
        // new_unchecked() são respeitados.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SEGURANÇA: uma referência mutável não pode ser nula.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SEGURANÇA: Uma referência não pode ser nula, então as condições para
        // new_unchecked() são respeitados.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}