#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Fornece o tipo de metadados de ponteiro de qualquer tipo apontado.
///
/// # Metadados de ponteiro
///
/// Os tipos de ponteiro brutos e os tipos de referência em Rust podem ser considerados como compostos de duas partes:
/// um ponteiro de dados que contém o endereço de memória do valor e alguns metadados.
///
/// Para tipos de tamanho estático (que implementam o `Sized` traits), bem como para os tipos `extern`, os ponteiros são chamados de "finos": os metadados têm tamanho zero e seu tipo é `()`.
///
///
/// Os ponteiros para [dynamically-sized types][dst] são considerados "largos" ou "gordos", eles têm metadados de tamanho diferente de zero:
///
/// * Para estruturas cujo último campo é um DST, metadados são os metadados do último campo
/// * Para o tipo `str`, metadados são o comprimento em bytes como `usize`
/// * Para tipos de fatia como `[T]`, metadados são o comprimento em itens como `usize`
/// * Para objetos trait como `dyn SomeTrait`, os metadados são [`DynMetadata<Self>`][DynMetadata] (por exemplo, `DynMetadata<dyn SomeTrait>`)
///
/// No future, a linguagem Rust pode ganhar novos tipos de tipos que possuem metadados de ponteiro diferentes.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # The `Pointee` trait
///
/// O ponto deste trait é seu tipo associado `Metadata`, que é `()` ou `usize` ou `DynMetadata<_>` conforme descrito acima.
/// Ele é implementado automaticamente para cada tipo.
/// Pode-se presumir que ele seja implementado em um contexto genérico, mesmo sem um limite correspondente.
///
/// # Usage
///
/// Ponteiros brutos podem ser decompostos no endereço de dados e componentes de metadados com seu método [`to_raw_parts`].
///
/// Como alternativa, os metadados sozinhos podem ser extraídos com a função [`metadata`].
/// Uma referência pode ser passada para o [`metadata`] e coagida implicitamente.
///
/// Um ponteiro (possibly-wide) pode ser reunido a partir de seu endereço e metadados com [`from_raw_parts`] ou [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// O tipo de metadados em ponteiros e referências para `Self`.
    #[lang = "metadata_type"]
    // NOTE: Mantenha trait bounds em `static_assert_expected_bounds_for_metadata`
    //
    // no `library/core/src/ptr/metadata.rs` em sincronia com aqueles aqui:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Ponteiros para tipos que implementam este alias trait são `finos`.
///
/// Isso inclui os tipos estaticamente `Sized` e os tipos `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: não estabilize isso antes que os aliases trait sejam estáveis no idioma?
pub trait Thin = Pointee<Metadata = ()>;

/// Extraia o componente de metadados de um ponteiro.
///
/// Valores do tipo `*mut T`, `&T` ou `&mut T` podem ser passados diretamente para esta função, pois eles implicitamente coagem para `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // SEGURANÇA: Acessar o valor da união `PtrRepr` é seguro desde * const T
    // e PtrComponents<T>têm os mesmos layouts de memória.
    // Apenas std pode fazer esta garantia.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Forma um ponteiro (possibly-wide) bruto a partir de um endereço de dados e metadados.
///
/// Esta função é segura, mas o ponteiro retornado não é necessariamente seguro para desreferenciamento.
/// Para fatias, consulte a documentação do [`slice::from_raw_parts`] para obter os requisitos de segurança.
/// Para objetos trait, os metadados devem vir de um ponteiro para o mesmo tipo de liberação subjacente.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // SEGURANÇA: Acessar o valor da união `PtrRepr` é seguro desde * const T
    // e PtrComponents<T>têm os mesmos layouts de memória.
    // Apenas std pode fazer esta garantia.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Executa a mesma funcionalidade do [`from_raw_parts`], exceto que um ponteiro `*mut` bruto é retornado, ao contrário de um ponteiro `* const` bruto.
///
///
/// Consulte a documentação do [`from_raw_parts`] para obter mais detalhes.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // SEGURANÇA: Acessar o valor da união `PtrRepr` é seguro desde * const T
    // e PtrComponents<T>têm os mesmos layouts de memória.
    // Apenas std pode fazer esta garantia.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// O impl manual é necessário para evitar o limite do `T: Copy`.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// O impl manual é necessário para evitar o limite do `T: Clone`.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Os metadados para um tipo de objeto `Dyn = dyn SomeTrait` trait.
///
/// É um ponteiro para uma vtable (tabela de chamada virtual) que representa todas as informações necessárias para manipular o tipo concreto armazenado dentro de um objeto trait.
/// O vtable notavelmente contém:
///
/// * tamanho do tipo
/// * alinhamento de tipo
/// * um ponteiro para o impl `drop_in_place` do tipo (pode ser um ambiente autônomo para dados antigos simples)
/// * ponteiros para todos os métodos para a implementação do tipo do trait
///
/// Observe que os três primeiros são especiais porque são necessários para alocar, descartar e desalocar qualquer objeto trait.
///
/// É possível nomear esta estrutura com um parâmetro de tipo que não seja um objeto `dyn` trait (por exemplo, `DynMetadata<u64>`), mas não para obter um valor significativo dessa estrutura.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// O prefixo comum de todos os vtables.Ele é seguido por ponteiros de função para métodos trait.
///
/// Detalhe de implementação privada do `DynMetadata::size_of` etc.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Retorna o tamanho do tipo associado a esta vtable.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Retorna o alinhamento do tipo associado a esta vtable.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Retorna o tamanho e o alinhamento juntos como um `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SEGURANÇA: o compilador emitiu esta vtable para um tipo Rust concreto que
        // é conhecido por ter um layout válido.Mesma lógica do `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Impls manuais necessários para evitar limites `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}