use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Um invólucro em torno de um `*mut T` não nulo bruto que indica que o possuidor desse invólucro possui o referente.
/// Útil para construir abstrações como `Box<T>`, `Vec<T>`, `String` e `HashMap<K, V>`.
///
/// Ao contrário do `*mut T`, o `Unique<T>` se comporta como "as if" como uma instância do `T`.
/// Ele implementa `Send`/`Sync` se `T` for `Send`/`Sync`.
/// Também implica no tipo de garantias de aliasing fortes que uma instância do `T` pode esperar:
/// o referente do ponteiro não deve ser modificado sem um caminho exclusivo para o seu único proprietário.
///
/// Se você não tiver certeza se é correto usar o `Unique` para seus propósitos, considere o uso do `NonNull`, que tem uma semântica mais fraca.
///
///
/// Ao contrário do `*mut T`, o ponteiro deve sempre ser não nulo, mesmo se o ponteiro nunca tiver a referência cancelada.
/// Isso ocorre para que enums possam usar este valor proibido como discriminante-`Option<Unique<T>>` tem o mesmo tamanho que `Unique<T>`.
/// No entanto, o ponteiro ainda pode oscilar se não for desreferenciado.
///
/// Ao contrário do `*mut T`, o `Unique<T>` é covariante do `T`.
/// Isso sempre deve estar correto para qualquer tipo que atenda aos requisitos de aliasing da Unique.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: este marcador não tem consequências para a variação, mas é necessário
    // para dropck entender que logicamente possuímos um `T`.
    //
    // Para obter detalhes, consulte:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` os ponteiros são `Send` se `T` for `Send` porque os dados aos quais eles fazem referência não têm distorção.
/// Observe que essa invariante de aliasing não é reforçada pelo sistema de tipos;a abstração usando o `Unique` deve aplicá-la.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` os ponteiros são `Sync` se `T` for `Sync` porque os dados aos quais eles fazem referência não têm distorção.
/// Observe que essa invariante de aliasing não é reforçada pelo sistema de tipos;a abstração usando o `Unique` deve aplicá-la.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Cria um novo `Unique` oscilante, mas bem alinhado.
    ///
    /// Isso é útil para inicializar tipos que alocam lentamente, como o `Vec::new` faz.
    ///
    /// Observe que o valor do ponteiro pode representar potencialmente um ponteiro válido para um `T`, o que significa que ele não deve ser usado como um valor sentinela "not yet initialized".
    /// Os tipos que alocam lentamente devem rastrear a inicialização por algum outro meio.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SEGURANÇA: mem::align_of() retorna um ponteiro válido e não nulo.O
        // as condições para chamar o new_unchecked() são, portanto, respeitadas.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Cria um novo `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` deve ser não nulo.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SEGURANÇA: o chamador deve garantir que o `ptr` não é nulo.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Cria um novo `Unique` se `ptr` não for nulo.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SEGURANÇA: O ponteiro já foi verificado e não é nulo.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Adquire o ponteiro `*mut` subjacente.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Cancela a referência do conteúdo.
    ///
    /// O tempo de vida resultante é vinculado ao self, portanto, este se comporta "as if"; na verdade, é uma instância de T que está sendo emprestada.
    /// Se for necessária uma vida útil mais longa do (unbound), use o `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SEGURANÇA: o chamador deve garantir que o `self` atenda a todos os
        // requisitos para uma referência.
        unsafe { &*self.as_ptr() }
    }

    /// Desreferencia mutuamente o conteúdo.
    ///
    /// O tempo de vida resultante é vinculado ao self, portanto, este se comporta "as if"; na verdade, é uma instância de T que está sendo emprestada.
    /// Se for necessária uma vida útil mais longa do (unbound), use o `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SEGURANÇA: o chamador deve garantir que o `self` atenda a todos os
        // requisitos para uma referência mutável.
        unsafe { &mut *self.as_ptr() }
    }

    /// Converte para um ponteiro de outro tipo.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // SEGURANÇA: Unique::new_unchecked() cria um novo e único e necessidades
        // o ponteiro fornecido não deve ser nulo.
        // Como estamos passando self como um ponteiro, ele não pode ser nulo.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SEGURANÇA: uma referência mutável não pode ser nula
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}