//! Este módulo implementa o `Any` trait, que permite a digitação dinâmica de qualquer tipo de `'static` por meio de reflexão do tempo de execução.
//!
//! `Any` em si pode ser usado para obter um `TypeId` e tem mais recursos quando usado como um objeto trait.
//! Como `&dyn Any` (um objeto trait emprestado), ele possui os métodos `is` e `downcast_ref` para testar se o valor contido é de um determinado tipo e para obter uma referência ao valor interno como um tipo.
//! Como `&mut dyn Any`, existe também o método `downcast_mut`, para obter uma referência mutável para o valor interno.
//! `Box<dyn Any>` adiciona o método `downcast`, que tenta converter para um `Box<T>`.
//! Consulte a documentação do [`Box`] para obter os detalhes completos.
//!
//! Observe que `&dyn Any` é limitado a testar se um valor é de um tipo concreto especificado e não pode ser usado para testar se um tipo implementa um trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Ponteiros inteligentes e `dyn Any`
//!
//! Um comportamento a ter em mente ao usar `Any` como um objeto trait, especialmente com tipos como `Box<dyn Any>` ou `Arc<dyn Any>`, é que simplesmente chamar `.type_id()` no valor produzirá o `TypeId` do *contêiner*, não o objeto trait subjacente.
//!
//! Isso pode ser evitado convertendo o ponteiro inteligente em um `&dyn Any`, que retornará o `TypeId` do objeto.
//! Por exemplo:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // É mais provável que você queira isto:
//! let actual_id = (&*boxed).type_id();
//! // ... do que este:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Considere uma situação em que desejamos efetuar logout de um valor passado para uma função.
//! Sabemos o valor em que estamos trabalhando para implementar o Debug, mas não sabemos seu tipo concreto.Queremos dar um tratamento especial a certos tipos: neste caso, imprimir o comprimento dos valores de String antes de seu valor.
//! Não sabemos o tipo concreto de nosso valor em tempo de compilação, então precisamos usar a reflexão em tempo de execução.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Função de logger para qualquer tipo que implemente Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Tente converter nosso valor para um `String`.
//!     // Se for bem-sucedido, queremos mostrar o comprimento da String, bem como seu valor.
//!     // Caso contrário, é um tipo diferente: basta imprimi-lo sem adornos.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Esta função deseja desconectar seu parâmetro antes de trabalhar com ele.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... fazer algum outro trabalho
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Qualquer trait
///////////////////////////////////////////////////////////////////////////////

/// Um trait para emular a digitação dinâmica.
///
/// A maioria dos tipos implementa `Any`.No entanto, qualquer tipo que contenha uma referência não `'static` não contém.
/// Consulte o [module-level documentation][mod] para obter mais detalhes.
///
/// [mod]: crate::any
// Este trait não é inseguro, embora dependamos das especificações da função `type_id` de seu único impl em código inseguro (por exemplo, `downcast`).Normalmente, isso seria um problema, mas como o único impl do `Any` é uma implementação geral, nenhum outro código pode implementar o `Any`.
//
// Poderíamos plausivelmente tornar este trait inseguro-não causaria quebra, uma vez que controlamos todas as implementações-mas optamos por não fazê-lo, pois isso não é realmente necessário e pode confundir os usuários sobre a distinção de traits inseguro e métodos inseguros (ou seja, O `type_id` ainda pode ser chamado com segurança, mas provavelmente gostaríamos de indicá-lo na documentação).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Obtém o `TypeId` do `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Métodos de extensão para qualquer objeto trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Certifique-se de que o resultado de, por exemplo, juntar um fio, possa ser impresso e, portanto, usado com o `unwrap`.
// Pode eventualmente não ser mais necessário se o envio funcionar com upcasting.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Retorna `true` se o tipo em caixa for igual a `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Obtenha o `TypeId` do tipo com o qual esta função é instanciada.
        let t = TypeId::of::<T>();

        // Obtenha `TypeId` do tipo no objeto trait (`self`).
        let concrete = self.type_id();

        // Compare os dois `TypeId`s na igualdade.
        t == concrete
    }

    /// Retorna alguma referência ao valor em caixa se for do tipo `T` ou `None` se não for.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // SEGURANÇA: apenas verificamos se estamos apontando para o tipo correto, e podemos confiar em
            // que verificam a segurança da memória porque implementamos Any para todos os tipos;nenhum outro impls pode existir, pois eles entrariam em conflito com o nosso impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Retorna alguma referência mutável ao valor em caixa se for do tipo `T` ou `None` se não for.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // SEGURANÇA: apenas verificamos se estamos apontando para o tipo correto, e podemos confiar em
            // que verificam a segurança da memória porque implementamos Any para todos os tipos;nenhum outro impls pode existir, pois eles entrariam em conflito com o nosso impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Avança para o método definido no tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Avança para o método definido no tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Avança para o método definido no tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Avança para o método definido no tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Avança para o método definido no tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Avança para o método definido no tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID e seus métodos
///////////////////////////////////////////////////////////////////////////////

/// Um `TypeId` representa um identificador globalmente exclusivo para um tipo.
///
/// Cada `TypeId` é um objeto opaco que não permite a inspeção do que está dentro, mas permite operações básicas como clonagem, comparação, impressão e exibição.
///
///
/// Um `TypeId` está atualmente disponível apenas para tipos que atribuem ao `'static`, mas esta limitação pode ser removida no future.
///
/// Embora o `TypeId` implemente `Hash`, `PartialOrd` e `Ord`, é importante notar que os hashes e a ordem variam entre as versões Rust.
/// Cuidado para não confiar neles dentro do seu código!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Retorna o `TypeId` do tipo com o qual esta função genérica foi instanciada.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Retorna o nome de um tipo como uma fatia de string.
///
/// # Note
///
/// Destina-se ao uso diagnóstico.
/// O conteúdo e o formato exatos da string retornada não são especificados, a não ser uma descrição de melhor esforço do tipo.
/// Por exemplo, entre as strings que `type_name::<Option<String>>()` pode retornar estão `"Option<String>"` e `"std::option::Option<std::string::String>"`.
///
///
/// A string retornada não deve ser considerada um identificador exclusivo de um tipo, pois vários tipos podem ser mapeados para o mesmo nome de tipo.
/// Da mesma forma, não há garantia de que todas as partes de um tipo aparecerão na string retornada: por exemplo, os especificadores de duração não estão incluídos no momento.
/// Além disso, a saída pode mudar entre as versões do compilador.
///
/// A implementação atual usa a mesma infraestrutura de diagnóstico do compilador e debuginfo, mas isso não é garantido.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Retorna o nome do tipo do valor apontado como uma fatia de string.
/// É o mesmo que `type_name::<T>()`, mas pode ser usado onde o tipo de uma variável não está facilmente disponível.
///
/// # Note
///
/// Destina-se ao uso diagnóstico.O conteúdo e formato exatos da string não são especificados, a não ser uma descrição de melhor esforço do tipo.
/// Por exemplo, `type_name_of_val::<Option<String>>(None)` pode retornar `"Option<String>"` ou `"std::option::Option<std::string::String>"`, mas não `"foobar"`.
///
/// Além disso, a saída pode mudar entre as versões do compilador.
///
/// Esta função não resolve objetos trait, o que significa que `type_name_of_val(&7u32 as &dyn Debug)` pode retornar `"dyn Debug"`, mas não `"u32"`.
///
/// O nome do tipo não deve ser considerado um identificador exclusivo de um tipo;
/// vários tipos podem compartilhar o mesmo nome de tipo.
///
/// A implementação atual usa a mesma infraestrutura de diagnóstico do compilador e debuginfo, mas isso não é garantido.
///
/// # Examples
///
/// Imprime os tipos inteiro e flutuante padrão.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}