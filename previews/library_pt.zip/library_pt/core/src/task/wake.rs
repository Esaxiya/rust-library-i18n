#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// Um `RawWaker` permite que o implementador de um executor de tarefa crie um [`Waker`] que fornece um comportamento de ativação personalizado.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Consiste em um ponteiro de dados e um [virtual function pointer table (vtable)][vtable] que personaliza o comportamento do `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Um ponteiro de dados, que pode ser usado para armazenar dados arbitrários conforme exigido pelo executor.
    /// Isso poderia ser, por exemplo
    /// um ponteiro apagado para um `Arc` associado à tarefa.
    /// O valor deste campo é passado para todas as funções que fazem parte da vtable como o primeiro parâmetro.
    ///
    data: *const (),
    /// Tabela de ponteiro de função virtual que personaliza o comportamento deste waker.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Cria um novo `RawWaker` a partir do ponteiro `data` e `vtable` fornecidos.
    ///
    /// O ponteiro `data` pode ser usado para armazenar dados arbitrários conforme exigido pelo executor.Isso poderia ser, por exemplo
    /// um ponteiro apagado para um `Arc` associado à tarefa.
    /// O valor deste ponteiro será passado para todas as funções que fazem parte do `vtable` como o primeiro parâmetro.
    ///
    /// O `vtable` personaliza o comportamento de um `Waker` criado a partir de um `RawWaker`.
    /// Para cada operação no `Waker`, a função associada no `vtable` do `RawWaker` subjacente será chamada.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Uma tabela de ponteiro de função virtual (vtable) que especifica o comportamento de um [`RawWaker`].
///
/// O ponteiro passado para todas as funções dentro da vtable é o ponteiro `data` do objeto [`RawWaker`] delimitador.
///
/// As funções dentro dessa estrutura devem ser chamadas apenas no ponteiro `data` de um objeto [`RawWaker`] construído corretamente de dentro da implementação [`RawWaker`].
/// Chamar uma das funções contidas usando qualquer outro ponteiro `data` causará um comportamento indefinido.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Esta função será chamada quando o [`RawWaker`] for clonado, por exemplo, quando o [`Waker`] no qual o [`RawWaker`] está armazenado for clonado.
    ///
    /// A implementação desta função deve reter todos os recursos necessários para esta instância adicional de um [`RawWaker`] e tarefa associada.
    /// Chamar o `wake` no [`RawWaker`] resultante deve resultar em uma ativação da mesma tarefa que teria sido ativada pelo [`RawWaker`] original.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Esta função será chamada quando o `wake` for chamado no [`Waker`].
    /// Ele deve despertar a tarefa associada a este [`RawWaker`].
    ///
    /// A implementação desta função deve garantir a liberação de todos os recursos associados a esta instância de um [`RawWaker`] e à tarefa associada.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Esta função será chamada quando o `wake_by_ref` for chamado no [`Waker`].
    /// Ele deve despertar a tarefa associada a este [`RawWaker`].
    ///
    /// Esta função é semelhante ao `wake`, mas não deve consumir o ponteiro de dados fornecido.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Esta função é chamada quando um [`RawWaker`] é descartado.
    ///
    /// A implementação desta função deve garantir a liberação de todos os recursos associados a esta instância de um [`RawWaker`] e à tarefa associada.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Cria um novo `RawWakerVTable` a partir das funções `clone`, `wake`, `wake_by_ref` e `drop` fornecidas.
    ///
    /// # `clone`
    ///
    /// Esta função será chamada quando o [`RawWaker`] for clonado, por exemplo, quando o [`Waker`] no qual o [`RawWaker`] está armazenado for clonado.
    ///
    /// A implementação desta função deve reter todos os recursos necessários para esta instância adicional de um [`RawWaker`] e tarefa associada.
    /// Chamar o `wake` no [`RawWaker`] resultante deve resultar em uma ativação da mesma tarefa que teria sido ativada pelo [`RawWaker`] original.
    ///
    /// # `wake`
    ///
    /// Esta função será chamada quando o `wake` for chamado no [`Waker`].
    /// Ele deve despertar a tarefa associada a este [`RawWaker`].
    ///
    /// A implementação desta função deve garantir a liberação de todos os recursos associados a esta instância de um [`RawWaker`] e à tarefa associada.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Esta função será chamada quando o `wake_by_ref` for chamado no [`Waker`].
    /// Ele deve despertar a tarefa associada a este [`RawWaker`].
    ///
    /// Esta função é semelhante ao `wake`, mas não deve consumir o ponteiro de dados fornecido.
    ///
    /// # `drop`
    ///
    /// Esta função é chamada quando um [`RawWaker`] é descartado.
    ///
    /// A implementação desta função deve garantir a liberação de todos os recursos associados a esta instância de um [`RawWaker`] e à tarefa associada.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// O `Context` de uma tarefa assíncrona.
///
/// Atualmente, o `Context` serve apenas para fornecer acesso a um `&Waker` que pode ser usado para despertar a tarefa atual.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Certifique-se de que temos future-proof contra mudanças de variância, forçando o tempo de vida a ser invariante (tempos de vida de posição de argumento são contravariantes, enquanto tempos de vida de posição de retorno são covariantes).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Crie um novo `Context` a partir de um `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Retorna uma referência ao `Waker` para a tarefa atual.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// Um `Waker` é um identificador para despertar uma tarefa notificando seu executor de que está pronto para ser executado.
///
/// Esse identificador encapsula uma instância [`RawWaker`], que define o comportamento de ativação específico do executor.
///
///
/// Implementa [`Clone`], [`Send`] e [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Desperte a tarefa associada a este `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // A chamada de ativação real é delegada por meio de uma chamada de função virtual para a implementação que é definida pelo executor.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Não chame o `drop`-o waker será consumido pelo `wake`.
        crate::mem::forget(self);

        // SEGURANÇA: Isso é seguro porque `Waker::from_raw` é a única maneira
        // para inicializar o `wake` e o `data`, exigindo que o usuário reconheça que o contrato do `RawWaker` foi mantido.
        //
        unsafe { (wake)(data) };
    }

    /// Desperte a tarefa associada a este `Waker` sem consumir o `Waker`.
    ///
    /// Isso é semelhante ao `wake`, mas pode ser um pouco menos eficiente no caso em que um `Waker` próprio está disponível.
    /// Este método deve ser preferido em vez de chamar o `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // A chamada de ativação real é delegada por meio de uma chamada de função virtual para a implementação que é definida pelo executor.
        //

        // SEGURANÇA: consulte `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Retorna `true` se este `Waker` e outro `Waker` despertaram a mesma tarefa.
    ///
    /// Esta função funciona com base no melhor esforço e pode retornar falso mesmo quando o `Waker`s despertaria a mesma tarefa.
    /// Porém, se esta função retornar `true`, é garantido que o `Waker`s despertará a mesma tarefa.
    ///
    /// Esta função é usada principalmente para fins de otimização.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Cria um novo `Waker` a partir do [`RawWaker`].
    ///
    /// O comportamento do `Waker` retornado é indefinido se o contrato definido na documentação de [`RawWaker`] e [`RawWakerVTable`] não for mantido.
    ///
    /// Portanto, esse método não é seguro.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // SEGURANÇA: Isso é seguro porque `Waker::from_raw` é a única maneira
            // para inicializar o `clone` e o `data`, exigindo que o usuário reconheça que o contrato do [`RawWaker`] foi mantido.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // SEGURANÇA: Isso é seguro porque `Waker::from_raw` é a única maneira
        // para inicializar o `drop` e o `data`, exigindo que o usuário reconheça que o contrato do `RawWaker` foi mantido.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}