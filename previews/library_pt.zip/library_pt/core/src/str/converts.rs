//! Maneiras de criar um `str` a partir de uma fatia de bytes.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Converte uma fatia de bytes em uma fatia de string.
///
/// Uma fatia de string ([`&str`]) é feita de bytes ([`u8`]) e uma fatia de byte ([`&[u8]`][byteslice]) é feita de bytes, portanto, essa função converte entre os dois.
/// No entanto, nem todas as fatias de byte são fatias de string válidas: [`&str`] requer que seja UTF-8 válido.
/// `from_utf8()` verifica se os bytes são UTF-8 válidos e, em seguida, faz a conversão.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Se você tiver certeza de que a fatia de byte é UTF-8 válida e não quiser incorrer na sobrecarga da verificação de validade, há uma versão não segura dessa função, [`from_utf8_unchecked`], que tem o mesmo comportamento, mas ignora a verificação.
///
///
/// Se você precisa de um `String` em vez de um `&str`, considere o [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Como você pode alocar em pilha um `[u8; N]` e tirar um [`&[u8]`][byteslice] dele, esta função é uma maneira de ter uma string alocada em pilha.Há um exemplo disso na seção de exemplos abaixo.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Retorna `Err` se a fatia não for UTF-8 com uma descrição de por que a fatia fornecida não é UTF-8.
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::str;
///
/// // alguns bytes, em um vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Sabemos que esses bytes são válidos, então use apenas `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Bytes incorretos:
///
/// ```
/// use std::str;
///
/// // alguns bytes inválidos, em um vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Consulte a documentação do [`Utf8Error`] para obter mais detalhes sobre os tipos de erros que podem ser retornados.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // alguns bytes, em uma matriz alocada em pilha
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Sabemos que esses bytes são válidos, então use apenas `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SEGURANÇA: Basta executar a validação.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Converte uma fatia mutável de bytes em uma fatia de string mutável.
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" como um vector mutável
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Como sabemos que esses bytes são válidos, podemos usar `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Bytes incorretos:
///
/// ```
/// use std::str;
///
/// // Alguns bytes inválidos em um vector mutável
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Consulte a documentação do [`Utf8Error`] para obter mais detalhes sobre os tipos de erros que podem ser retornados.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SEGURANÇA: Basta executar a validação.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Converte uma fatia de bytes em uma fatia de string sem verificar se a string contém UTF-8 válido.
///
/// Consulte a versão segura, [`from_utf8`], para obter mais informações.
///
/// # Safety
///
/// Esta função não é segura porque não verifica se os bytes transmitidos a ela são UTF-8 válidos.
/// Se esta restrição for violada, resultará em comportamento indefinido, já que o resto de Rust assume que [`&str`] s são UTF-8 válidos.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::str;
///
/// // alguns bytes, em um vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SEGURANÇA: o chamador deve garantir que os bytes `v` são UTF-8 válidos.
    // Também conta com o `&str` e o `&[u8]` com o mesmo layout.
    unsafe { mem::transmute(v) }
}

/// Converte uma fatia de bytes em uma fatia de string sem verificar se a string contém UTF-8 válido;versão mutável.
///
///
/// Veja a versão imutável, [`from_utf8_unchecked()`] para mais informações.
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // SEGURANÇA: o chamador deve garantir que os bytes `v`
    // são UTF-8 válidos, portanto, a conversão para `*mut str` é segura.
    // Além disso, a desreferência do ponteiro é segura porque esse ponteiro vem de uma referência que é garantida como válida para gravações.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}