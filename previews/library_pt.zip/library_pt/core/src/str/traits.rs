//! Implementações Trait para `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Implementa ordenação de strings.
///
/// As strings são ordenadas [lexicographically](Ord#lexicographical-comparison) por seus valores de byte.
/// Isso ordena os pontos de código Unicode com base em suas posições nos gráficos de código.
/// Isso não é necessariamente o mesmo que o pedido do "alphabetical", que varia de acordo com o idioma e a localidade.
/// A classificação das strings de acordo com os padrões culturalmente aceitos requer dados específicos do local que estão fora do escopo do tipo `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Implementa operações de comparação em strings.
///
/// Strings são comparados [lexicographically](Ord#lexicographical-comparison) por seus valores de byte.
/// Isso compara os pontos de código Unicode com base em suas posições nos gráficos de código.
/// Isso não é necessariamente o mesmo que o pedido do "alphabetical", que varia de acordo com o idioma e a localidade.
/// Comparar strings de acordo com padrões culturalmente aceitos requer dados específicos do local que estão fora do escopo do tipo `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Implementa segmentação de substring com sintaxe `&self[..]` ou `&mut self[..]`.
///
/// Retorna uma fatia de toda a string, ou seja, retorna `&self` ou `&mut self`.Equivalente a `&self [0 ..
/// len] `ou`&mut self [0 ..
/// len]`.
/// Ao contrário de outras operações de indexação, isso nunca pode panic.
///
/// Esta operação é *O*(1).
///
/// Antes do 1.20.0, essas operações de indexação ainda eram suportadas pela implementação direta do `Index` e do `IndexMut`.
///
/// Equivalente a `&self[0 .. len]` ou `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Implementa segmentação de substring com sintaxe `&self[begin .. end]` ou `&mut self[begin .. end]`.
///
/// Retorna uma fatia da string fornecida do intervalo de bytes [`begin`, `end`).
///
/// Esta operação é *O*(1).
///
/// Antes do 1.20.0, essas operações de indexação ainda eram suportadas pela implementação direta do `Index` e do `IndexMut`.
///
/// # Panics
///
/// Panics se `begin` ou `end` não aponta para o deslocamento de byte inicial de um caractere (conforme definido por `is_char_boundary`), se `begin > end` ou se `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // estes serão panic:
/// // byte 2 está dentro de `ö`:
/// // &s [2 ..3];
///
/// // o byte 8 está dentro do `老`&s [1 ..
/// // 8];
///
/// // byte 100 está fora da string&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SEGURANÇA: verifiquei apenas se `start` e `end` estão em um limite de char,
            // e estamos passando uma referência segura, então o valor de retorno também será um.
            // Também verificamos os limites de caracteres, então este é o UTF-8 válido.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SEGURANÇA: verifiquei apenas se `start` e `end` estão em um limite de char.
            // Sabemos que o ponteiro é único porque o adquirimos no `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SEGURANÇA: o chamador garante que o `self` está dentro dos limites do `slice`
        // que satisfaz todas as condições para o `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SEGURANÇA: veja comentários para `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary verifica se o índice está em [0, .len()] não pode reutilizar `get` como acima, devido a problemas de NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SEGURANÇA: verifiquei apenas se `start` e `end` estão em um limite de char,
            // e estamos passando uma referência segura, então o valor de retorno também será um.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Implementa segmentação de substring com sintaxe `&self[.. end]` ou `&mut self[.. end]`.
///
/// Retorna uma parte da string fornecida do intervalo de bytes [`0`, `end`).
/// Equivalente a `&self[0 .. end]` ou `&mut self[0 .. end]`.
///
/// Esta operação é *O*(1).
///
/// Antes do 1.20.0, essas operações de indexação ainda eram suportadas pela implementação direta do `Index` e do `IndexMut`.
///
/// # Panics
///
/// Panics se `end` não apontar para o deslocamento de byte inicial de um caractere (conforme definido por `is_char_boundary`), ou se `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SEGURANÇA: acabei de verificar se o `end` está em um limite de char,
            // e estamos passando uma referência segura, então o valor de retorno também será um.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SEGURANÇA: acabei de verificar se o `end` está em um limite de char,
            // e estamos passando uma referência segura, então o valor de retorno também será um.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // SEGURANÇA: acabei de verificar se o `end` está em um limite de char,
            // e estamos passando uma referência segura, então o valor de retorno também será um.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Implementa segmentação de substring com sintaxe `&self[begin ..]` ou `&mut self[begin ..]`.
///
/// Retorna uma fatia da string fornecida do intervalo de bytes [`begin`, `len`).Equivalente a `&self [begin ..
/// len] `ou`&mut self [começar ..
/// len]`.
///
/// Esta operação é *O*(1).
///
/// Antes do 1.20.0, essas operações de indexação ainda eram suportadas pela implementação direta do `Index` e do `IndexMut`.
///
/// # Panics
///
/// Panics se `begin` não apontar para o deslocamento de byte inicial de um caractere (conforme definido por `is_char_boundary`), ou se `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SEGURANÇA: acabei de verificar se o `start` está em um limite de char,
            // e estamos passando uma referência segura, então o valor de retorno também será um.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SEGURANÇA: acabei de verificar se o `start` está em um limite de char,
            // e estamos passando uma referência segura, então o valor de retorno também será um.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SEGURANÇA: o chamador garante que o `self` está dentro dos limites do `slice`
        // que satisfaz todas as condições para o `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SEGURANÇA: idêntico ao `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // SEGURANÇA: acabei de verificar se o `start` está em um limite de char,
            // e estamos passando uma referência segura, então o valor de retorno também será um.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Implementa segmentação de substring com sintaxe `&self[begin ..= end]` ou `&mut self[begin ..= end]`.
///
/// Retorna uma fatia da string fornecida do intervalo de bytes [`begin`, `end`].Equivalente a `&self [begin .. end + 1]` ou `&mut self[begin .. end + 1]`, exceto se `end` tiver o valor máximo para `usize`.
///
/// Esta operação é *O*(1).
///
/// # Panics
///
/// Panics se `begin` não aponta para o deslocamento de byte inicial de um caractere (conforme definido por `is_char_boundary`), se `end` não aponta para o deslocamento de byte final de um caractere (`end + 1` é um deslocamento de byte inicial ou igual a `len`), se `begin > end`, ou se `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SEGURANÇA: o chamador deve respeitar o contrato de segurança do `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SEGURANÇA: o chamador deve respeitar o contrato de segurança do `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Implementa segmentação de substring com sintaxe `&self[..= end]` ou `&mut self[..= end]`.
///
/// Retorna uma fatia da string fornecida do intervalo de bytes [0, `end`].
/// Equivalente a `&self [0 .. end + 1]`, exceto se `end` tiver o valor máximo para `usize`.
///
/// Esta operação é *O*(1).
///
/// # Panics
///
/// Panics se `end` não apontar para o deslocamento de byte final de um caractere (`end + 1` é um deslocamento de byte inicial conforme definido por `is_char_boundary` ou igual a `len`) ou se `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SEGURANÇA: o chamador deve respeitar o contrato de segurança do `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SEGURANÇA: o chamador deve respeitar o contrato de segurança do `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Analisa um valor de uma string
///
/// O método [`from_str`] de `FromStr` é freqüentemente usado implicitamente, através do método [`parse`] de [`str`].
/// Veja a documentação de [`parse`] para exemplos.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` não tem um parâmetro de tempo de vida e, portanto, você só pode analisar os tipos que não contêm um parâmetro de tempo de vida.
///
/// Em outras palavras, você pode analisar um `i32` com `FromStr`, mas não um `&i32`.
/// Você pode analisar uma estrutura que contém um `i32`, mas não uma que contém um `&i32`.
///
/// # Examples
///
/// Implementação básica de `FromStr` em um tipo de `Point` de exemplo:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// O erro associado que pode ser retornado da análise.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Analisa uma string `s` para retornar um valor desse tipo.
    ///
    /// Se a análise for bem-sucedida, retorne o valor dentro de [`Ok`], caso contrário, quando a string estiver mal formatada, retorne um erro específico para dentro do [`Err`].
    /// O tipo de erro é específico para implementação do trait.
    ///
    /// # Examples
    ///
    /// Uso básico com [`i32`], um tipo que implementa `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Analisa um `bool` a partir de uma string.
    ///
    /// Rende um `Result<bool, ParseBoolError>`, porque o `s` pode ou não ser analisável.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Observe que, em muitos casos, o método `.parse()` no `str` é mais adequado.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}