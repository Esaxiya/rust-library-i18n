//! Define o tipo de erro utf8.

use crate::fmt;

/// Erros que podem ocorrer ao tentar interpretar uma sequência do [`u8`] como uma string.
///
/// Como tal, a família `from_utf8` de funções e métodos para [`String`] se [`&str`] s usam esse erro, por exemplo.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Os métodos desse tipo de erro podem ser usados para criar uma funcionalidade semelhante ao `String::from_utf8_lossy` sem alocar memória heap:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Retorna o índice na string fornecida até a qual o UTF-8 válido foi verificado.
    ///
    /// É o índice máximo de forma que `from_utf8(&input[..index])` retornaria `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::str;
    ///
    /// // alguns bytes inválidos, em um vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 retorna um Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // o segundo byte é inválido aqui
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Fornece mais informações sobre a falha:
    ///
    /// * `None`: o fim da entrada foi alcançado inesperadamente.
    ///   `self.valid_up_to()` é de 1 a 3 bytes do final da entrada.
    ///   Se um fluxo de bytes (como um arquivo ou um soquete de rede) estiver sendo decodificado de forma incremental, pode ser um `char` válido cuja sequência de bytes UTF-8 está abrangendo vários blocos.
    ///
    ///
    /// * `Some(len)`: um byte inesperado foi encontrado.
    ///   O comprimento fornecido é o da sequência de bytes inválida que começa no índice fornecido por `valid_up_to()`.
    ///   A decodificação deve continuar após essa sequência (após inserir um [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) em caso de decodificação com perdas.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Um erro retornado ao analisar um `bool` usando [`from_str`] falha
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}