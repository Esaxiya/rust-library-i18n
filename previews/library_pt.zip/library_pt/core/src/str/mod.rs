//! Manipulação de cordas.
//!
//! Para obter mais detalhes, consulte o módulo [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. fora dos limites
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. começo <=fim
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. limite de personagem
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // encontre o personagem
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` deve ser menor que len e um limite de char
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Retorna o comprimento de `self`.
    ///
    /// Este comprimento é em bytes, não [`char`] s ou grafemas.
    /// Em outras palavras, pode não ser o que um humano considera o comprimento da corda.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // fantasia f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Retorna `true` se `self` tem um comprimento de zero bytes.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Verifica se `index`-th byte é o primeiro byte em uma sequência de ponto de código UTF-8 ou o final da string.
    ///
    ///
    /// O início e o fim da string (quando `index== self.len()`) são considerados limites.
    ///
    /// Retorna `false` se `index` for maior que `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // início do `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // segundo byte de `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // terceiro byte de `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 e len estão sempre ok.
        // Teste 0 explicitamente para que possa otimizar a verificação facilmente e pular a leitura de dados de string para esse caso.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Isso é um bit mágico equivalente a: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Converte uma fatia de string em uma fatia de byte.
    /// Para converter a fatia de byte de volta em uma fatia de string, use a função [`from_utf8`].
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // SEGURANÇA: som constante porque transmutamos dois tipos com o mesmo layout
        unsafe { mem::transmute(self) }
    }

    /// Converte uma fatia de string mutável em uma fatia de byte mutável.
    ///
    /// # Safety
    ///
    /// O chamador deve garantir que o conteúdo da fatia é UTF-8 válido antes que o empréstimo termine e o `str` subjacente seja usado.
    ///
    ///
    /// O uso de um `str` cujo conteúdo não é válido UTF-8 é um comportamento indefinido.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // SEGURANÇA: o elenco de `&str` para `&[u8]` é seguro desde `str`
        // tem o mesmo layout do `&[u8]` (apenas libstd pode fazer essa garantia).
        // A desreferência do ponteiro é segura, pois vem de uma referência mutável que é garantida como válida para gravações.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Converte uma fatia de string em um ponteiro bruto.
    ///
    /// Como as fatias de string são uma fatia de bytes, o ponteiro bruto aponta para um [`u8`].
    /// Este ponteiro estará apontando para o primeiro byte da fatia da string.
    ///
    /// O chamador deve garantir que o ponteiro retornado nunca seja escrito.
    /// Se você precisar alterar o conteúdo da fatia da string, use o [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Converte uma fatia de string mutável em um ponteiro bruto.
    ///
    /// Como as fatias de string são uma fatia de bytes, o ponteiro bruto aponta para um [`u8`].
    /// Este ponteiro estará apontando para o primeiro byte da fatia da string.
    ///
    /// É sua responsabilidade certificar-se de que a fatia da string apenas seja modificada de forma que permaneça válida UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Retorna um subforte de `str`.
    ///
    /// Esta é a alternativa sem pânico para indexar o `str`.
    /// Retorna [`None`] sempre que a operação de indexação equivalente seria panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // índices fora dos limites da sequência UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // fora dos limites
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Retorna um subslice mutável de `str`.
    ///
    /// Esta é a alternativa sem pânico para indexar o `str`.
    /// Retorna [`None`] sempre que a operação de indexação equivalente seria panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // comprimento correto
    /// assert!(v.get_mut(0..5).is_some());
    /// // fora dos limites
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Retorna um subforte não verificado de `str`.
    ///
    /// Esta é a alternativa não verificada para indexar o `str`.
    ///
    /// # Safety
    ///
    /// Os chamadores desta função são responsáveis pelo cumprimento destas pré-condições:
    ///
    /// * O índice inicial não deve exceder o índice final;
    /// * Os índices devem estar dentro dos limites da fatia original;
    /// * Os índices devem estar nos limites da sequência UTF-8.
    ///
    /// Caso contrário, a fatia da string retornada pode fazer referência à memória inválida ou violar as invariantes comunicadas pelo tipo `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // SEGURANÇA: o chamador deve respeitar o contrato de segurança para o `get_unchecked`;
        // a fatia pode ser desreferenciada porque `self` é uma referência segura.
        // O ponteiro retornado é seguro porque impls de `SliceIndex` tem que garantir que é.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Retorna um subforte mutável e não verificado de `str`.
    ///
    /// Esta é a alternativa não verificada para indexar o `str`.
    ///
    /// # Safety
    ///
    /// Os chamadores desta função são responsáveis pelo cumprimento destas pré-condições:
    ///
    /// * O índice inicial não deve exceder o índice final;
    /// * Os índices devem estar dentro dos limites da fatia original;
    /// * Os índices devem estar nos limites da sequência UTF-8.
    ///
    /// Caso contrário, a fatia da string retornada pode fazer referência à memória inválida ou violar as invariantes comunicadas pelo tipo `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // SEGURANÇA: o chamador deve respeitar o contrato de segurança para o `get_unchecked_mut`;
        // a fatia pode ser desreferenciada porque `self` é uma referência segura.
        // O ponteiro retornado é seguro porque impls de `SliceIndex` tem que garantir que é.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Cria uma fatia de string a partir de outra fatia de string, ignorando as verificações de segurança.
    ///
    /// Isso geralmente não é recomendado, use com cuidado!Para uma alternativa segura, consulte [`str`] e [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Esta nova fatia vai de `begin` a `end`, incluindo `begin`, mas excluindo `end`.
    ///
    /// Para obter uma fatia de string mutável, consulte o método [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Os chamadores desta função são responsáveis pelo cumprimento de três pré-condições:
    ///
    /// * `begin` não deve exceder `end`.
    /// * `begin` e `end` devem ser posições de byte dentro da fatia da string.
    /// * `begin` e o `end` deve estar nos limites da sequência UTF-8.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // SEGURANÇA: o chamador deve respeitar o contrato de segurança para o `get_unchecked`;
        // a fatia pode ser desreferenciada porque `self` é uma referência segura.
        // O ponteiro retornado é seguro porque impls de `SliceIndex` tem que garantir que é.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Cria uma fatia de string a partir de outra fatia de string, ignorando as verificações de segurança.
    /// Isso geralmente não é recomendado, use com cuidado!Para uma alternativa segura, consulte [`str`] e [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Esta nova fatia vai de `begin` a `end`, incluindo `begin`, mas excluindo `end`.
    ///
    /// Para obter uma fatia de string imutável, consulte o método [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Os chamadores desta função são responsáveis pelo cumprimento de três pré-condições:
    ///
    /// * `begin` não deve exceder `end`.
    /// * `begin` e `end` devem ser posições de byte dentro da fatia da string.
    /// * `begin` e o `end` deve estar nos limites da sequência UTF-8.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // SEGURANÇA: o chamador deve respeitar o contrato de segurança para o `get_unchecked_mut`;
        // a fatia pode ser desreferenciada porque `self` é uma referência segura.
        // O ponteiro retornado é seguro porque impls de `SliceIndex` tem que garantir que é.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Divida uma fatia da corda em duas em um índice.
    ///
    /// O argumento, `mid`, deve ser um deslocamento de byte desde o início da string.
    /// Ele também deve estar no limite de um ponto de código UTF-8.
    ///
    /// As duas fatias retornadas vão do início da fatia da string até o `mid` e de `mid` até o final da fatia da string.
    ///
    /// Para obter fatias de string mutáveis, consulte o método [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics se `mid` não estiver em um limite de ponto de código UTF-8 ou se tiver passado do final do último ponto de código da fatia da string.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary verifica se o índice está em [0, .len()]
        if self.is_char_boundary(mid) {
            // SEGURANÇA: apenas verifiquei que o `mid` está em um limite de char.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Divida uma fatia de string mutável em duas em um índice.
    ///
    /// O argumento, `mid`, deve ser um deslocamento de byte desde o início da string.
    /// Ele também deve estar no limite de um ponto de código UTF-8.
    ///
    /// As duas fatias retornadas vão do início da fatia da string até o `mid` e de `mid` até o final da fatia da string.
    ///
    /// Para obter fatias de string imutáveis, consulte o método [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics se `mid` não estiver em um limite de ponto de código UTF-8 ou se tiver passado do final do último ponto de código da fatia da string.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary verifica se o índice está em [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // SEGURANÇA: apenas verifiquei que o `mid` está em um limite de char.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Retorna um iterador sobre os [`char`] s de uma fatia de string.
    ///
    /// Como uma fatia de string consiste em UTF-8 válido, podemos iterar por meio de uma fatia de string por [`char`].
    /// Este método retorna esse iterador.
    ///
    /// É importante lembrar que [`char`] representa um valor escalar Unicode e pode não corresponder à sua ideia do que é um 'character'.
    ///
    /// Iteração sobre clusters de grafemas pode ser o que você realmente deseja.
    /// Esta funcionalidade não é fornecida pela biblioteca padrão do Rust; em vez disso, verifique o crates.io.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Lembre-se, [`char`] s podem não corresponder à sua intuição sobre os personagens:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // não 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Retorna um iterador sobre os [`char`] s de uma fatia de string e suas posições.
    ///
    /// Como uma fatia de string consiste em UTF-8 válido, podemos iterar por meio de uma fatia de string por [`char`].
    /// Este método retorna um iterador de ambos os [`char`] s, bem como suas posições de byte.
    ///
    /// O iterador produz tuplas.A posição é a primeira, o [`char`] é a segunda.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Lembre-se, [`char`] s podem não corresponder à sua intuição sobre os personagens:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // não (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // observe o 3 aqui, o último caractere ocupou dois bytes
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Um iterador sobre os bytes de uma fatia de string.
    ///
    /// Como uma fatia de string consiste em uma sequência de bytes, podemos iterar por meio de uma fatia de string por byte.
    /// Este método retorna esse iterador.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Divide uma fatia de string por espaço em branco.
    ///
    /// O iterador retornado retornará fatias de string que são sub-fatias da fatia de string original, separadas por qualquer quantidade de espaço em branco.
    ///
    ///
    /// 'Whitespace' é definido de acordo com os termos da Unicode Derived Core Property `White_Space`.
    /// Se você quiser apenas dividir em espaços em branco ASCII, use o [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Todos os tipos de espaço em branco são considerados:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Divide uma fatia de string por espaços em branco ASCII.
    ///
    /// O iterador retornado retornará fatias de string que são sub-fatias da fatia de string original, separadas por qualquer quantidade de espaço em branco ASCII.
    ///
    ///
    /// Para dividir por Unicode `Whitespace`, use [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Todos os tipos de espaços em branco ASCII são considerados:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Um iterador sobre as linhas de uma string, como fatias de string.
    ///
    /// As linhas são terminadas com um (`\n`) de nova linha ou um retorno de carro com um avanço de linha (`\r\n`).
    ///
    /// O final da linha final é opcional.
    /// Uma string que termina com um final de linha final retornará as mesmas linhas de uma string idêntica sem um final de linha final.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// O final da linha final não é obrigatório:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Um iterador nas linhas de uma string.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Retorna um iterador de `u16` sobre a string codificada como UTF-16.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Retorna `true` se o padrão fornecido corresponder a uma sub-fatia desta fatia da string.
    ///
    /// Retorna `false` se não retornar.
    ///
    /// O [pattern] pode ser um `&str`, [`char`], uma fatia de [`char`] s ou uma função ou fechamento que determina se um caractere corresponde.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Retorna `true` se o padrão fornecido corresponder a um prefixo desta fatia da string.
    ///
    /// Retorna `false` se não retornar.
    ///
    /// O [pattern] pode ser um `&str`, [`char`], uma fatia de [`char`] s ou uma função ou fechamento que determina se um caractere corresponde.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Retorna `true` se o padrão fornecido corresponder a um sufixo desta fatia da string.
    ///
    /// Retorna `false` se não retornar.
    ///
    /// O [pattern] pode ser um `&str`, [`char`], uma fatia de [`char`] s ou uma função ou fechamento que determina se um caractere corresponde.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Retorna o índice de bytes do primeiro caractere desta fatia da string que corresponde ao padrão.
    ///
    /// Retorna [`None`] se o padrão não corresponder.
    ///
    /// O [pattern] pode ser um `&str`, [`char`], uma fatia de [`char`] s ou uma função ou fechamento que determina se um caractere corresponde.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Padrões simples:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Padrões mais complexos usando estilo sem pontos e fechamentos:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Não encontrando o padrão:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Retorna o índice de bytes para o primeiro caractere da correspondência mais à direita do padrão nesta fatia de string.
    ///
    /// Retorna [`None`] se o padrão não corresponder.
    ///
    /// O [pattern] pode ser um `&str`, [`char`], uma fatia de [`char`] s ou uma função ou fechamento que determina se um caractere corresponde.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Padrões simples:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Padrões mais complexos com fechamentos:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Não encontrando o padrão:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Um iterador sobre substrings dessa fatia de string, separados por caracteres correspondidos por um padrão.
    ///
    /// O [pattern] pode ser um `&str`, [`char`], uma fatia de [`char`] s ou uma função ou fechamento que determina se um caractere corresponde.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportamento do iterador
    ///
    /// O iterador retornado será um [`DoubleEndedIterator`] se o padrão permitir uma pesquisa reversa e a pesquisa forward/reverse gerar os mesmos elementos.
    /// Isso é verdade para, por exemplo, [`char`], mas não para `&str`.
    ///
    /// Se o padrão permitir uma busca reversa, mas seus resultados puderem ser diferentes de uma busca direta, o método [`rsplit`] pode ser usado.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Padrões simples:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Se o padrão for uma fatia de caracteres, divida em cada ocorrência de qualquer um dos caracteres:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Um padrão mais complexo, usando um fechamento:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Se uma string contém vários separadores contíguos, você terminará com strings vazias na saída:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Os separadores contíguos são separados por uma string vazia.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Os separadores no início ou no final de uma string são vizinhos de strings vazias.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Quando a string vazia é usada como separador, ela separa todos os caracteres da string, junto com o início e o fim da string.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Os separadores contíguos podem levar a um comportamento possivelmente surpreendente quando o espaço em branco é usado como separador.Este código está correto:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// O _not_ oferece:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Use o [`split_whitespace`] para esse comportamento.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Um iterador sobre substrings dessa fatia de string, separados por caracteres correspondidos por um padrão.
    /// Difere do iterador produzido pelo `split` no sentido de que o `split_inclusive` deixa a parte combinada como o terminador da substring.
    ///
    ///
    /// O [pattern] pode ser um `&str`, [`char`], uma fatia de [`char`] s ou uma função ou fechamento que determina se um caractere corresponde.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Se o último elemento da string for correspondido, esse elemento será considerado o terminador da substring anterior.
    /// Essa substring será o último item retornado pelo iterador.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Um iterador sobre substrings da fatia de string fornecida, separados por caracteres correspondidos por um padrão e produzidos na ordem inversa.
    ///
    /// O [pattern] pode ser um `&str`, [`char`], uma fatia de [`char`] s ou uma função ou fechamento que determina se um caractere corresponde.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportamento do iterador
    ///
    /// O iterador retornado requer que o padrão suporte uma pesquisa reversa e será um [`DoubleEndedIterator`] se uma pesquisa forward/reverse produzir os mesmos elementos.
    ///
    ///
    /// Para iterar pela frente, o método [`split`] pode ser usado.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Padrões simples:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Um padrão mais complexo, usando um fechamento:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Um iterador sobre substrings da fatia de string fornecida, separados por caracteres correspondidos por um padrão.
    ///
    /// O [pattern] pode ser um `&str`, [`char`], uma fatia de [`char`] s ou uma função ou fechamento que determina se um caractere corresponde.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Equivalente a [`split`], exceto que a substring final é ignorada se estiver vazia.
    ///
    /// [`split`]: str::split
    ///
    /// Este método pode ser usado para dados de string _terminated_, em vez de _separated_ por um padrão.
    ///
    /// # Comportamento do iterador
    ///
    /// O iterador retornado será um [`DoubleEndedIterator`] se o padrão permitir uma pesquisa reversa e a pesquisa forward/reverse gerar os mesmos elementos.
    /// Isso é verdade para, por exemplo, [`char`], mas não para `&str`.
    ///
    /// Se o padrão permitir uma busca reversa, mas seus resultados puderem ser diferentes de uma busca direta, o método [`rsplit_terminator`] pode ser usado.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Um iterador sobre substrings de `self`, separados por caracteres correspondidos por um padrão e produzidos na ordem inversa.
    ///
    /// O [pattern] pode ser um `&str`, [`char`], uma fatia de [`char`] s ou uma função ou fechamento que determina se um caractere corresponde.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Equivalente a [`split`], exceto que a substring final é ignorada se estiver vazia.
    ///
    /// [`split`]: str::split
    ///
    /// Este método pode ser usado para dados de string _terminated_, em vez de _separated_ por um padrão.
    ///
    /// # Comportamento do iterador
    ///
    /// O iterador retornado requer que o padrão suporte uma pesquisa reversa e será duplamente finalizado se uma pesquisa forward/reverse produzir os mesmos elementos.
    ///
    ///
    /// Para iterar pela frente, o método [`split_terminator`] pode ser usado.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Um iterador sobre substrings da fatia de string fornecida, separada por um padrão, restrito a retornar no máximo itens `n`.
    ///
    /// Se substrings `n` forem retornadas, a última substring (a `n`ésima substring) conterá o restante da string.
    ///
    /// O [pattern] pode ser um `&str`, [`char`], uma fatia de [`char`] s ou uma função ou fechamento que determina se um caractere corresponde.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportamento do iterador
    ///
    /// O iterador retornado não terá finalização dupla, porque não é eficiente para dar suporte.
    ///
    /// Se o padrão permitir uma busca reversa, o método [`rsplitn`] pode ser usado.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Padrões simples:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Um padrão mais complexo, usando um fechamento:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Um iterador sobre substrings dessa fatia de string, separada por um padrão, começando no final da string, restrito a retornar no máximo itens `n`.
    ///
    ///
    /// Se substrings `n` forem retornadas, a última substring (a `n`ésima substring) conterá o restante da string.
    ///
    /// O [pattern] pode ser um `&str`, [`char`], uma fatia de [`char`] s ou uma função ou fechamento que determina se um caractere corresponde.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportamento do iterador
    ///
    /// O iterador retornado não terá finalização dupla, porque não é eficiente para dar suporte.
    ///
    /// Para divisão pela frente, o método [`splitn`] pode ser usado.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Padrões simples:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Um padrão mais complexo, usando um fechamento:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Divide a string na primeira ocorrência do delimitador especificado e retorna o prefixo antes do delimitador e o sufixo depois do delimitador.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Divide a string na última ocorrência do delimitador especificado e retorna o prefixo antes do delimitador e o sufixo depois do delimitador.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Um iterador sobre as correspondências disjuntas de um padrão dentro da fatia de string fornecida.
    ///
    /// O [pattern] pode ser um `&str`, [`char`], uma fatia de [`char`] s ou uma função ou fechamento que determina se um caractere corresponde.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportamento do iterador
    ///
    /// O iterador retornado será um [`DoubleEndedIterator`] se o padrão permitir uma pesquisa reversa e a pesquisa forward/reverse gerar os mesmos elementos.
    /// Isso é verdade para, por exemplo, [`char`], mas não para `&str`.
    ///
    /// Se o padrão permitir uma busca reversa, mas seus resultados puderem ser diferentes de uma busca direta, o método [`rmatches`] pode ser usado.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Um iterador sobre as correspondências disjuntas de um padrão dentro dessa fatia da string, produzida na ordem inversa.
    ///
    /// O [pattern] pode ser um `&str`, [`char`], uma fatia de [`char`] s ou uma função ou fechamento que determina se um caractere corresponde.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportamento do iterador
    ///
    /// O iterador retornado requer que o padrão suporte uma pesquisa reversa e será um [`DoubleEndedIterator`] se uma pesquisa forward/reverse produzir os mesmos elementos.
    ///
    ///
    /// Para iterar pela frente, o método [`matches`] pode ser usado.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Um iterador sobre as correspondências disjuntas de um padrão dentro dessa fatia da string, bem como o índice em que a correspondência começa.
    ///
    /// Para correspondências de `pat` dentro de `self` que se sobrepõem, apenas os índices correspondentes à primeira correspondência são retornados.
    ///
    /// O [pattern] pode ser um `&str`, [`char`], uma fatia de [`char`] s ou uma função ou fechamento que determina se um caractere corresponde.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportamento do iterador
    ///
    /// O iterador retornado será um [`DoubleEndedIterator`] se o padrão permitir uma pesquisa reversa e a pesquisa forward/reverse gerar os mesmos elementos.
    /// Isso é verdade para, por exemplo, [`char`], mas não para `&str`.
    ///
    /// Se o padrão permitir uma busca reversa, mas seus resultados puderem ser diferentes de uma busca direta, o método [`rmatch_indices`] pode ser usado.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // apenas o primeiro `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Um iterador sobre as correspondências disjuntas de um padrão no `self`, gerado na ordem reversa junto com o índice da correspondência.
    ///
    /// Para correspondências de `pat` dentro de `self` que se sobrepõem, apenas os índices correspondentes à última correspondência são retornados.
    ///
    /// O [pattern] pode ser um `&str`, [`char`], uma fatia de [`char`] s ou uma função ou fechamento que determina se um caractere corresponde.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportamento do iterador
    ///
    /// O iterador retornado requer que o padrão suporte uma pesquisa reversa e será um [`DoubleEndedIterator`] se uma pesquisa forward/reverse produzir os mesmos elementos.
    ///
    ///
    /// Para iterar pela frente, o método [`match_indices`] pode ser usado.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // apenas o último `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Retorna uma fatia de string com espaços em branco à esquerda e à direita removidos.
    ///
    /// 'Whitespace' é definido de acordo com os termos da Unicode Derived Core Property `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Retorna uma fatia de string com o espaço em branco removido.
    ///
    /// 'Whitespace' é definido de acordo com os termos da Unicode Derived Core Property `White_Space`.
    ///
    /// # Direcionalidade do texto
    ///
    /// Uma string é uma sequência de bytes.
    /// `start` neste contexto, significa a primeira posição dessa string de bytes;para um idioma da esquerda para a direita, como inglês ou russo, será o lado esquerdo, e para idiomas da direita para a esquerda, como árabe ou hebraico, será o lado direito.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Retorna uma fatia de string com o espaço em branco final removido.
    ///
    /// 'Whitespace' é definido de acordo com os termos da Unicode Derived Core Property `White_Space`.
    ///
    /// # Direcionalidade do texto
    ///
    /// Uma string é uma sequência de bytes.
    /// `end` neste contexto, significa a última posição daquela string de bytes;para um idioma da esquerda para a direita, como inglês ou russo, será o lado direito, e para idiomas da direita para a esquerda, como árabe ou hebraico, será o lado esquerdo.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Retorna uma fatia de string com o espaço em branco removido.
    ///
    /// 'Whitespace' é definido de acordo com os termos da Unicode Derived Core Property `White_Space`.
    ///
    /// # Direcionalidade do texto
    ///
    /// Uma string é uma sequência de bytes.
    /// 'Left' neste contexto, significa a primeira posição daquela string de bytes;para um idioma como árabe ou hebraico, que são da 'direita para a esquerda' em vez de 'da esquerda para a direita', este será o lado _right_, não o esquerdo.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Retorna uma fatia de string com o espaço em branco final removido.
    ///
    /// 'Whitespace' é definido de acordo com os termos da Unicode Derived Core Property `White_Space`.
    ///
    /// # Direcionalidade do texto
    ///
    /// Uma string é uma sequência de bytes.
    /// 'Right' neste contexto, significa a última posição daquela string de bytes;para um idioma como árabe ou hebraico, que são da 'direita para a esquerda' em vez de 'da esquerda para a direita', este será o lado _left_, não o direito.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Retorna uma fatia de string com todos os prefixos e sufixos que correspondem a um padrão removido repetidamente.
    ///
    /// O [pattern] pode ser um [`char`], uma fatia de [`char`] s ou uma função ou fechamento que determina se um caractere corresponde.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Padrões simples:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Um padrão mais complexo, usando um fechamento:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Lembre-se de correspondência mais antiga conhecida, corrija-a abaixo se
            // última partida é diferente
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SEGURANÇA: O `Searcher` é conhecido por retornar índices válidos.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Retorna uma fatia de string com todos os prefixos que correspondem a um padrão removido repetidamente.
    ///
    /// O [pattern] pode ser um `&str`, [`char`], uma fatia de [`char`] s ou uma função ou fechamento que determina se um caractere corresponde.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Direcionalidade do texto
    ///
    /// Uma string é uma sequência de bytes.
    /// `start` neste contexto, significa a primeira posição dessa string de bytes;para um idioma da esquerda para a direita, como inglês ou russo, será o lado esquerdo, e para idiomas da direita para a esquerda, como árabe ou hebraico, será o lado direito.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // SEGURANÇA: O `Searcher` é conhecido por retornar índices válidos.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Retorna uma fatia de string com o prefixo removido.
    ///
    /// Se a string começar com o padrão `prefix`, retornará a substring após o prefixo, embrulhado em `Some`.
    /// Ao contrário do `trim_start_matches`, este método remove o prefixo exatamente uma vez.
    ///
    /// Se a string não começar com `prefix`, retornará `None`.
    ///
    /// O [pattern] pode ser um `&str`, [`char`], uma fatia de [`char`] s ou uma função ou fechamento que determina se um caractere corresponde.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Retorna uma fatia de string com o sufixo removido.
    ///
    /// Se a string termina com o padrão `suffix`, retorna a substring antes do sufixo, embrulhado em `Some`.
    /// Ao contrário do `trim_end_matches`, este método remove o sufixo exatamente uma vez.
    ///
    /// Se a string não terminar com `suffix`, retornará `None`.
    ///
    /// O [pattern] pode ser um `&str`, [`char`], uma fatia de [`char`] s ou uma função ou fechamento que determina se um caractere corresponde.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Retorna uma fatia de string com todos os sufixos que correspondem a um padrão removido repetidamente.
    ///
    /// O [pattern] pode ser um `&str`, [`char`], uma fatia de [`char`] s ou uma função ou fechamento que determina se um caractere corresponde.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Direcionalidade do texto
    ///
    /// Uma string é uma sequência de bytes.
    /// `end` neste contexto, significa a última posição daquela string de bytes;para um idioma da esquerda para a direita, como inglês ou russo, será o lado direito, e para idiomas da direita para a esquerda, como árabe ou hebraico, será o lado esquerdo.
    ///
    ///
    /// # Examples
    ///
    /// Padrões simples:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Um padrão mais complexo, usando um fechamento:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SEGURANÇA: O `Searcher` é conhecido por retornar índices válidos.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Retorna uma fatia de string com todos os prefixos que correspondem a um padrão removido repetidamente.
    ///
    /// O [pattern] pode ser um `&str`, [`char`], uma fatia de [`char`] s ou uma função ou fechamento que determina se um caractere corresponde.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Direcionalidade do texto
    ///
    /// Uma string é uma sequência de bytes.
    /// 'Left' neste contexto, significa a primeira posição daquela string de bytes;para um idioma como árabe ou hebraico, que são da 'direita para a esquerda' em vez de 'da esquerda para a direita', este será o lado _right_, não o esquerdo.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Retorna uma fatia de string com todos os sufixos que correspondem a um padrão removido repetidamente.
    ///
    /// O [pattern] pode ser um `&str`, [`char`], uma fatia de [`char`] s ou uma função ou fechamento que determina se um caractere corresponde.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Direcionalidade do texto
    ///
    /// Uma string é uma sequência de bytes.
    /// 'Right' neste contexto, significa a última posição daquela string de bytes;para um idioma como árabe ou hebraico, que são da 'direita para a esquerda' em vez de 'da esquerda para a direita', este será o lado _left_, não o direito.
    ///
    ///
    /// # Examples
    ///
    /// Padrões simples:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Um padrão mais complexo, usando um fechamento:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Analisa essa fatia da string em outro tipo.
    ///
    /// Como o `parse` é tão geral, ele pode causar problemas com a inferência de tipo.
    /// Como tal, o `parse` é uma das poucas vezes em que você verá a sintaxe carinhosamente conhecida como 'turbofish': `::<>`.
    ///
    /// Isso ajuda o algoritmo de inferência a entender especificamente para qual tipo você está tentando analisar.
    ///
    /// `parse` pode analisar em qualquer tipo que implemente o [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// Retornará [`Err`] se não for possível analisar esta fatia de string no tipo desejado.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Uso básico
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Usando o 'turbofish' em vez de anotar o `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Falha ao analisar:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Verifica se todos os caracteres nesta string estão dentro do intervalo ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Podemos tratar cada byte como caractere aqui: todos os caracteres multibyte começam com um byte que não está na faixa ascii, portanto, já vamos parar por aí.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Verifica se duas strings são uma correspondência ASCII sem distinção entre maiúsculas e minúsculas.
    ///
    /// Igual ao `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, mas sem alocar e copiar temporários.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Converte esta string em seu equivalente em maiúsculas ASCII no local.
    ///
    /// As letras ASCII 'a' a 'z' são mapeadas para 'A' a 'Z', mas as letras não ASCII permanecem inalteradas.
    ///
    /// Para retornar um novo valor em maiúsculas sem modificar o existente, use o [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // SEGURANÇA: seguro porque transmutamos dois tipos com o mesmo layout.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Converte esta string em seu equivalente em minúsculas ASCII no local.
    ///
    /// As letras ASCII 'A' a 'Z' são mapeadas para 'a' a 'z', mas as letras não ASCII permanecem inalteradas.
    ///
    /// Para retornar um novo valor em minúsculas sem modificar o existente, use [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // SEGURANÇA: seguro porque transmutamos dois tipos com o mesmo layout.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Retorne um iterador que escape de cada caractere em `self` com [`char::escape_debug`].
    ///
    ///
    /// Note: apenas pontos de código de grafema estendido que começam a seqüência de caracteres serão escapados.
    ///
    /// # Examples
    ///
    /// Como um iterador:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Usando o `println!` diretamente:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Ambos são equivalentes a:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Usando `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Retorne um iterador que escape de cada caractere em `self` com [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Como um iterador:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Usando o `println!` diretamente:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Ambos são equivalentes a:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Usando `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Retorne um iterador que escape de cada caractere em `self` com [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Como um iterador:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Usando o `println!` diretamente:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Ambos são equivalentes a:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Usando `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Cria um str vazio
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Cria um str mutável vazio
    #[inline]
    fn default() -> Self {
        // SEGURANÇA: A string vazia é UTF-8 válido.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Um tipo fn identificável e clonável
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // SEGURANÇA: não seguro
        unsafe { from_utf8_unchecked(bytes) }
    };
}