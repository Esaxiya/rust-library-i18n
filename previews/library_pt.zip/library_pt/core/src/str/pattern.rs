//! A string Pattern API.
//!
//! A API Pattern fornece um mecanismo genérico para usar diferentes tipos de padrão ao pesquisar uma string.
//!
//! Para obter mais detalhes, consulte traits [`Pattern`], [`Searcher`], [`ReverseSearcher`] e [`DoubleEndedSearcher`].
//!
//! Embora essa API seja instável, ela é exposta por meio de APIs estáveis no tipo [`str`].
//!
//! # Examples
//!
//! [`Pattern`] é [implemented][pattern-impls] na API estável para [`&str`][`str`], [`char`], fatias de [`char`] e funções e fechamentos que implementam `FnMut(char) -> bool`.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // padrão de char
//! assert_eq!(s.find('n'), Some(2));
//! // padrão de fatia de chars
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // padrão de fechamento
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Um padrão de corda.
///
/// Um `Pattern<'a>` expressa que o tipo de implementação pode ser usado como um padrão de string para pesquisa em um [`&'a str`][str].
///
/// Por exemplo, tanto `'a'` quanto `"aa"` são padrões que corresponderiam ao índice `1` na string `"baaaab"`.
///
/// O próprio trait atua como um construtor para um tipo [`Searcher`] associado, que faz o trabalho real de encontrar ocorrências do padrão em uma string.
///
///
/// Dependendo do tipo de padrão, o comportamento de métodos como [`str::find`] e [`str::contains`] pode mudar.
/// A tabela abaixo descreve alguns desses comportamentos.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Pesquisador associado a este padrão
    type Searcher: Searcher<'a>;

    /// Constrói o buscador associado de `self` e `haystack` para pesquisar.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Verifica se o padrão corresponde a qualquer lugar no palheiro
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Verifica se o padrão corresponde à frente do palheiro
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Verifica se o padrão corresponde na parte de trás do palheiro
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Remove o padrão da frente do palheiro, se corresponder.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // SEGURANÇA: O `Searcher` é conhecido por retornar índices válidos.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Remove o padrão da parte de trás do palheiro, se corresponder.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // SEGURANÇA: O `Searcher` é conhecido por retornar índices válidos.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Resultado de chamar [`Searcher::next()`] ou [`ReverseSearcher::next_back()`].
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Expressa que uma correspondência do padrão foi encontrada no `haystack[a..b]`.
    ///
    Match(usize, usize),
    /// Expressa que o `haystack[a..b]` foi rejeitado como uma possível combinação do padrão.
    ///
    /// Observe que pode haver mais de um `Reject` entre dois `Match`es, não há necessidade de combiná-los em um.
    ///
    ///
    Reject(usize, usize),
    /// Expressa que cada byte do palheiro foi visitado, encerrando a iteração.
    ///
    Done,
}

/// Um pesquisador de um padrão de string.
///
/// Este trait fornece métodos para busca de correspondências não sobrepostas de um padrão a partir do (left) frontal de uma string.
///
/// Ele será implementado pelos tipos `Searcher` associados do [`Pattern`] trait.
///
/// O trait é marcado como inseguro porque os índices retornados pelos métodos [`next()`][Searcher::next] devem estar em limites utf8 válidos no palheiro.
/// Isso permite que os consumidores deste trait cortem o palheiro sem verificações adicionais de tempo de execução.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter para a string subjacente a ser pesquisada
    ///
    /// Sempre retornará o mesmo [`&str`][str].
    fn haystack(&self) -> &'a str;

    /// Executa a próxima etapa de pesquisa, começando pela frente.
    ///
    /// - Retorna [`Match(a, b)`][SearchStep::Match] se `haystack[a..b]` corresponder ao padrão.
    /// - Retorna [`Reject(a, b)`][SearchStep::Reject] se `haystack[a..b]` não pode corresponder ao padrão, mesmo parcialmente.
    /// - Retorna [`Done`][SearchStep::Done] se cada byte do palheiro tiver sido visitado.
    ///
    /// O fluxo de valores [`Match`][SearchStep::Match] e [`Reject`][SearchStep::Reject] até um [`Done`][SearchStep::Done] conterá faixas de índice que são adjacentes, não sobrepostas, cobrindo todo o palheiro e situando-se nos limites utf8.
    ///
    ///
    /// Um resultado [`Match`][SearchStep::Match] precisa conter todo o padrão correspondente, no entanto, os resultados [`Reject`][SearchStep::Reject] podem ser divididos em muitos fragmentos adjacentes arbitrários.Ambos os intervalos podem ter comprimento zero.
    ///
    /// Por exemplo, o padrão `"aaa"` e o palheiro `"cbaaaaab"` podem produzir o fluxo
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Encontra o próximo resultado do [`Match`][SearchStep::Match].Consulte [`next()`][Searcher::next].
    ///
    /// Ao contrário do [`next()`][Searcher::next], não há garantia de que os intervalos retornados deste e do [`next_reject`][Searcher::next_reject] se sobreporão.
    /// Isso retornará `(start_match, end_match)`, onde start_match é o índice de onde a correspondência começa e end_match é o índice após o final da correspondência.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Encontra o próximo resultado do [`Reject`][SearchStep::Reject].Consulte [`next()`][Searcher::next] e [`next_match()`][Searcher::next_match].
    ///
    /// Ao contrário do [`next()`][Searcher::next], não há garantia de que os intervalos retornados deste e do [`next_match`][Searcher::next_match] se sobreporão.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Um buscador reverso para um padrão de string.
///
/// Este trait fornece métodos para pesquisar por correspondências não sobrepostas de um padrão começando no (right) posterior de uma string.
///
/// Ele será implementado pelos tipos [`Searcher`] associados do [`Pattern`] trait se o padrão permitir a busca por ele na parte de trás.
///
///
/// Os intervalos de índice retornados por este trait não precisam corresponder exatamente aos da pesquisa direta reversa.
///
/// Para saber o motivo pelo qual este trait está marcado como inseguro, consulte o pai trait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Executa a próxima etapa da pesquisa começando de trás.
    ///
    /// - Retorna [`Match(a, b)`][SearchStep::Match] se `haystack[a..b]` corresponder ao padrão.
    /// - Retorna [`Reject(a, b)`][SearchStep::Reject] se `haystack[a..b]` não pode corresponder ao padrão, mesmo parcialmente.
    /// - Retorna [`Done`][SearchStep::Done] se cada byte do palheiro tiver sido visitado
    ///
    /// O fluxo de valores [`Match`][SearchStep::Match] e [`Reject`][SearchStep::Reject] até um [`Done`][SearchStep::Done] conterá faixas de índice que são adjacentes, não sobrepostas, cobrindo todo o palheiro e situando-se nos limites utf8.
    ///
    ///
    /// Um resultado [`Match`][SearchStep::Match] precisa conter todo o padrão correspondente, no entanto, os resultados [`Reject`][SearchStep::Reject] podem ser divididos em muitos fragmentos adjacentes arbitrários.Ambos os intervalos podem ter comprimento zero.
    ///
    /// Por exemplo, o padrão `"aaa"` e o palheiro `"cbaaaaab"` podem produzir o fluxo `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Encontra o próximo resultado do [`Match`][SearchStep::Match].
    /// Consulte [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Encontra o próximo resultado do [`Reject`][SearchStep::Reject].
    /// Consulte [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Um marcador trait para expressar que um [`ReverseSearcher`] pode ser usado para uma implementação [`DoubleEndedIterator`].
///
/// Para isso, o implemento de [`Searcher`] e [`ReverseSearcher`] precisa seguir estas condições:
///
/// - Todos os resultados do `next()` precisam ser idênticos aos resultados do `next_back()` na ordem inversa.
/// - `next()` e `next_back()` precisam se comportar como as duas extremidades de um intervalo de valores, ou seja, eles não podem "walk past each other".
///
/// # Examples
///
/// `char::Searcher` é um `DoubleEndedSearcher` porque procurar um [`char`] requer apenas olhar um de cada vez, que se comporta da mesma forma em ambas as extremidades.
///
/// `(&str)::Searcher` não é um `DoubleEndedSearcher` porque o padrão `"aa"` no palheiro `"aaa"` corresponde a `"[aa]a"` ou `"a[aa]"`, dependendo de qual lado ele é pesquisado.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Impl para char
/////////////////////////////////////////////////////////////////////////////

/// Tipo associado para `<char as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // invariante de segurança: `finger`/`finger_back` deve ser um índice de bytes utf8 válido de `haystack` Este invariante pode ser quebrado *em* next_match e next_match_back, no entanto, eles devem sair com os dedos nos limites de pontos de código válidos.
    //
    //
    /// `finger` é o índice de bytes atual da pesquisa direta.
    /// Imagine que ele existe antes do byte em seu índice, ou seja,
    /// `haystack[finger]` é o primeiro byte da fatia que devemos inspecionar durante a busca direta
    ///
    finger: usize,
    /// `finger_back` é o índice de bytes atual da pesquisa reversa.
    /// Imagine que existe após o byte em seu índice, ou seja,
    /// haystack [finger_back, 1] é o último byte da fatia que devemos inspecionar durante a pesquisa direta (e, portanto, o primeiro byte a ser inspecionado ao chamar o next_back()).
    ///
    finger_back: usize,
    /// O personagem que está sendo pesquisado
    needle: char,

    // invariante de segurança: `utf8_size` deve ser menor que 5
    /// O número de bytes que `needle` ocupa quando codificado em utf8.
    utf8_size: usize,
    /// Uma cópia codificada utf8 do `needle`
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // SEGURANÇA: 1-4 garantia de segurança do `get_unchecked`
        // 1. `self.finger` e `self.finger_back` são mantidos em limites unicode (isso é invariável)
        // 2. `self.finger >= 0` uma vez que começa em 0 e só aumenta
        // 3. `self.finger < self.finger_back` porque senão o char `iter` retornaria `SearchStep::Done`
        // 4.
        // `self.finger` vem antes do final do palheiro porque o `self.finger_back` começa no final e só diminui
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // adicionar deslocamento de byte do caractere atual sem recodificar como utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // pegue o palheiro após o último personagem encontrado
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // o último byte da agulha codificada utf8 SEGURANÇA: temos um invariante que `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // O novo dedo é o índice do byte que encontramos, mais um, já que memorizamos o último byte do caractere.
                //
                // Observe que isso nem sempre indica um limite do UTF8.
                // Se *não* encontramos nosso caractere, podemos ter indexado para o não último byte de um caractere de 3 ou 4 bytes.
                // Não podemos simplesmente pular para o próximo byte inicial válido porque um caractere como ꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` nos fará sempre encontrar o segundo byte ao procurar o terceiro.
                //
                //
                // No entanto, está tudo bem.
                // Embora tenhamos a invariante de que self.finger está em um limite UTF8, esta invariante não é invariável neste método (é invariável no CharSearcher::next()).
                //
                // Só saímos desse método quando chegarmos ao final da string ou se encontrarmos algo.Quando encontrarmos algo, o `finger` será definido para um limite UTF8.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // não encontrou nada, saia
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // deixe next_reject usar a implementação padrão do Searcher trait
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // SEGURANÇA: veja o comentário para next() acima
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // subtraia o deslocamento de byte do caractere atual sem recodificar como utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // aumentar o palheiro, mas não incluindo o último caractere pesquisado
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // o último byte da agulha codificada utf8 SEGURANÇA: temos um invariante que `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // pesquisamos uma fatia que foi compensada por self.finger, adicione self.finger para recuperar o índice original
                //
                let index = self.finger + index;
                // memrchr retornará o índice do byte que desejamos encontrar.
                // No caso de um caractere ASCII, este é de fato onde desejamos que nosso novo dedo seja ("after" o char encontrado no paradigma da iteração reversa).
                //
                // Para caracteres multibyte, precisamos pular para baixo pelo número de bytes a mais que eles têm do que ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // mova o dedo para antes do caractere encontrado (ou seja, em seu índice inicial)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Não podemos usar finger_back=index, size + 1 aqui.
                // Se encontrarmos o último caractere de um caractere de tamanho diferente (ou o byte do meio de um caractere diferente), precisamos aumentar o finger_back para `index`.
                // Da mesma forma, isso faz com que o `finger_back` tenha o potencial de não estar mais em um limite, mas não há problema, pois só saímos dessa função em um limite ou quando o palheiro foi pesquisado completamente.
                //
                //
                // Ao contrário de next_match, isso não tem o problema de bytes repetidos no utf-8 porque estamos pesquisando o último byte e só podemos ter encontrado o último byte ao pesquisar no sentido inverso.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // não encontrou nada, saia
                return None;
            }
        }
    }

    // deixe next_reject_back usar a implementação padrão do Searcher trait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Pesquisa caracteres iguais a um determinado [`char`].
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Impl para um wrapper MultiCharEq
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Compare os comprimentos do iterador de fatia de byte interno para encontrar o comprimento do caractere atual
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Compare os comprimentos do iterador de fatia de byte interno para encontrar o comprimento do caractere atual
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Impl para&[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: Alterar/remover devido à ambiguidade de significado.

/// Tipo associado para `<&[char] as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Pesquisa caracteres iguais a qualquer um dos [`char`] s na fatia.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl para F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Tipo associado para `<F as Pattern<'a>>::Searcher`.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Pesquisa por [`char`] s que correspondem ao predicado fornecido.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl para&&str
/////////////////////////////////////////////////////////////////////////////

/// Delegados ao `&str` impl.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Impl para &str
/////////////////////////////////////////////////////////////////////////////

/// Pesquisa de substring sem alocação.
///
/// Manipulará o padrão `""` como retornando correspondências vazias em cada limite de caractere.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Verifica se o padrão corresponde à frente do palheiro.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Remove o padrão da frente do palheiro, se corresponder.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // SEGURANÇA: o prefixo acabou de verificar a existência.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Verifica se o padrão corresponde na parte de trás do palheiro.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Remove o padrão da parte de trás do palheiro, se corresponder.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // SEGURANÇA: a existência do sufixo acaba de ser verificada.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Pesquisador de substring bidirecional
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Tipo associado para `<&str as Pattern<'a>>::Searcher`.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // agulha vazia rejeita todos os caracteres e combina todas as strings vazias entre eles
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher produz índices *Match* válidos que se dividem em limites de caracteres, desde que faça correspondência correta e que haystack e agulha sejam UTF-8 *Rejeições* válidas do algoritmo podem cair em qualquer índice, mas iremos conduzi-los manualmente para o próximo limite de caractere, para que sejam seguros para o utf-8.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // pular para o próximo limite de caracteres
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // escreva os casos `true` e `false` para encorajar o compilador a especializar os dois casos separadamente.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // pular para o próximo limite de caracteres
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // escreva `true` e `false`, como `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// O estado interno do algoritmo de pesquisa de substring bidirecional.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// índice de fatoração crítica
    crit_pos: usize,
    /// índice crítico de fatoração para agulha reversa
    crit_pos_back: usize,
    period: usize,
    /// `byteset` é uma extensão (não faz parte do algoritmo bidirecional);
    /// é um "fingerprint" de 64 bits onde cada bit definido `j` corresponde a um (byte&63)==j presente na agulha.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// indexe na agulha antes da qual já combinamos
    memory: usize,
    /// indexe na agulha, após o qual já combinamos
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Uma explicação particularmente legível do que está acontecendo aqui pode ser encontrada no livro "Text Algorithms" de Crochemore e Rytter, cap 13.
        // Consulte especificamente o código para "Algorithm CP" na pág.
        // 323.
        //
        // O que está acontecendo é que temos alguma fatoração crítica (u, v) da agulha e queremos determinar se u é um sufixo de&v [.. ponto final].
        // Se for, usamos o "Algorithm CP1".
        // Caso contrário, usamos "Algorithm CP2", que é otimizado para quando o período da agulha é grande.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // caso de período curto-o período é exato, calcule uma fatoração crítica separada para a agulha invertida x=u 'v' onde | v '|<period(x).
            //
            // Isso é acelerado pelo período já conhecido.
            // Observe que um caso como x= "acba" pode ser fatorado exatamente para a frente (crit_pos=1, período=3) enquanto é fatorado com o período aproximado no reverso (crit_pos=2, período=2).
            // Usamos a fatoração reversa fornecida, mas mantemos o período exato.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // caso de longo período-temos uma aproximação do período real e não usamos memorização.
            //
            //
            // Aproxime o período pelo limite inferior max(|u|, |v|) + 1.
            // A fatoração crítica é eficiente para uso tanto para busca direta quanto reversa.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Valor fictício para significar que o período é longo
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Uma das idéias principais do Two-Way é que fatoramos a agulha em duas metades, (u, v), e começamos a tentar encontrar v no palheiro examinando da esquerda para a direita.
    // Se v corresponder, tentamos corresponder a u examinando da direita para a esquerda.
    // Até onde podemos pular quando encontramos uma incompatibilidade é tudo baseado no fato de que (u, v) é uma fatoração crítica para a agulha.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` usa `self.position` como seu cursor
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Verifique se temos espaço para pesquisar na posição + needle_last não pode transbordar se assumirmos que as fatias são limitadas pelo intervalo de isize.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Pule rapidamente por grandes porções não relacionadas à nossa substring
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Veja se a parte certa da agulha combina
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Veja se a parte esquerda da agulha combina
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Encontramos uma correspondência!
            let match_pos = self.position;

            // Note: adicione self.period em vez de needle.len() para ter correspondências sobrepostas
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // definido como needle.len(), self.period para correspondências sobrepostas
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Segue as ideias do `next()`.
    //
    // As definições são simétricas, com period(x) = period(reverse(x)) e local_period(u, v) = local_period(reverse(v), reverse(u)), então se (u, v) é uma fatoração crítica, então é (reverse(v), reverse(u)).
    //
    //
    // Para o caso inverso, calculamos uma fatoração crítica x=u 'v' (campo `crit_pos_back`).Precisamos de | u |<period(x) para o caso dianteiro e, portanto, | v '|<period(x) para o reverso.
    //
    // Para pesquisar em sentido inverso através do palheiro, procuramos adiante através de um palheiro invertido com uma agulha invertida, combinando primeiro u 'e depois v'.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` usa `self.end` como seu cursor-de forma que `next()` e `next_back()` são independentes.
        //
        let old_end = self.end;
        'search: loop {
            // Verifique se há espaço para a busca no final, o needle.len() se enrolará quando não houver mais espaço, mas devido aos limites de comprimento da fatia, ele nunca poderá se estender completamente de volta ao comprimento do palheiro.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Pule rapidamente por grandes porções não relacionadas à nossa substring
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Veja se a parte esquerda da agulha combina
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Veja se a parte certa da agulha combina
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Encontramos uma correspondência!
            let match_pos = self.end - needle.len();
            // Note: sub self.period em vez de needle.len() para ter correspondências sobrepostas
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Calcule o sufixo máximo de `arr`.
    //
    // O sufixo máximo é uma possível fatoração crítica (u, v) de `arr`.
    //
    // Retorna (`i`, `p`) onde `i` é o índice inicial de ve `p` é o período de v.
    //
    // `order_greater` determina se a ordem lexical é `<` ou `>`.
    // Ambos os pedidos devem ser calculados-o pedido com o maior `i` fornece uma fatoração crítica.
    //
    //
    // Para casos de longo período, o período resultante não é exato (é muito curto).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Corresponde a i no papel
        let mut right = 1; // Corresponde a j no papel
        let mut offset = 0; // Corresponde a k no papel, mas começando em 0
        // para corresponder à indexação baseada em 0.
        let mut period = 1; // Corresponde a p no papel

        while let Some(&a) = arr.get(right + offset) {
            // `left` estará dentro dos limites quando o `right` estiver.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // O sufixo é menor, o período é o prefixo inteiro até agora.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Avança através da repetição do período atual.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // O sufixo é maior, recomece a partir da localização atual.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Calcule o sufixo máximo do reverso de `arr`.
    //
    // O sufixo máximo é uma possível fatoração crítica (u ', v') de `arr`.
    //
    // Retorna `i` onde `i` é o índice inicial de v ', de trás;
    // retorna imediatamente quando um período de `known_period` é atingido.
    //
    // `order_greater` determina se a ordem lexical é `<` ou `>`.
    // Ambos os pedidos devem ser calculados-o pedido com o maior `i` fornece uma fatoração crítica.
    //
    //
    // Para casos de longo período, o período resultante não é exato (é muito curto).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Corresponde a i no papel
        let mut right = 1; // Corresponde a j no papel
        let mut offset = 0; // Corresponde a k no papel, mas começando em 0
        // para corresponder à indexação baseada em 0.
        let mut period = 1; // Corresponde a p no papel
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // O sufixo é menor, o período é o prefixo inteiro até agora.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Avança através da repetição do período atual.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // O sufixo é maior, recomece a partir da localização atual.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy permite que o algoritmo ignore as não correspondências o mais rápido possível ou funcione em um modo em que emite rejeições com relativa rapidez.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Pule para intervalos de correspondência o mais rápido possível
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Emitir rejeições regularmente
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}