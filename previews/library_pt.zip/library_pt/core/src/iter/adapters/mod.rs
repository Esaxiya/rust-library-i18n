use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Este trait fornece acesso transitivo ao estágio de origem em um pipeline interator-adaptador sob as condições que
/// * a própria fonte do iterador `S` implementa `SourceIter<Source = S>`
/// * há uma implementação de delegação deste trait para cada adaptador no pipeline entre a origem e o consumidor do pipeline.
///
/// Quando a origem é uma estrutura iteradora proprietária (comumente chamada de `IntoIter`), isso pode ser útil para se especializar em implementações [`FromIterator`] ou recuperar os elementos restantes depois que um iterador foi parcialmente esgotado.
///
///
/// Observe que as implementações não precisam necessariamente fornecer acesso à fonte mais interna de um pipeline.Um adaptador intermediário com estado pode avaliar avidamente uma parte do pipeline e expor seu armazenamento interno como fonte.
///
/// O trait não é seguro porque os implementadores devem manter propriedades de segurança adicionais.
/// Consulte [`as_inner`] para obter detalhes.
///
/// # Examples
///
/// Recuperando uma fonte parcialmente consumida:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Um estágio de origem em um pipeline de iterador.
    type Source: Iterator;

    /// Recupere a fonte de um pipeline de iterador.
    ///
    /// # Safety
    ///
    /// As implementações de devem retornar a mesma referência mutável para o seu tempo de vida, a menos que substituída por um chamador.
    /// Os chamadores só podem substituir a referência quando interromperem a iteração e descartar o pipeline do iterador após extrair a origem.
    ///
    /// Isso significa que os adaptadores do iterador podem contar com a não alteração da origem durante a iteração, mas não podem contar com ela em suas implementações Drop.
    ///
    /// Implementar este método significa que os adaptadores renunciam ao acesso somente privado à sua origem e podem contar apenas com garantias feitas com base nos tipos de receptor do método.
    /// A falta de acesso restrito também exige que os adaptadores mantenham a API pública da fonte, mesmo quando eles têm acesso a seus componentes internos.
    ///
    /// Os chamadores, por sua vez, devem esperar que a fonte esteja em qualquer estado consistente com sua API pública, uma vez que os adaptadores situados entre ela e a fonte têm o mesmo acesso.
    /// Em particular, um adaptador pode ter consumido mais elementos do que o estritamente necessário.
    ///
    /// O objetivo geral desses requisitos é permitir que o consumidor de um pipeline use
    /// * o que quer que permaneça na fonte após a iteração parar
    /// * a memória que se tornou não utilizada pelo avanço de um iterador de consumo
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Um adaptador de iterador que produz saída desde que o iterador subjacente produza valores `Result::Ok`.
///
///
/// Se um erro for encontrado, o iterador para e o erro é armazenado.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Processe o iterador fornecido como se ele gerasse um `T` em vez de um `Result<T, _>`.
/// Quaisquer erros irão parar o iterador interno e o resultado geral será um erro.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}