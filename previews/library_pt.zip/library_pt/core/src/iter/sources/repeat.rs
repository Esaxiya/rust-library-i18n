use crate::iter::{FusedIterator, TrustedLen};

/// Cria um novo iterador que repete indefinidamente um único elemento.
///
/// A função `repeat()` repete um único valor indefinidamente.
///
/// Iteradores infinitos como o `repeat()` são freqüentemente usados com adaptadores como o [`Iterator::take()`], para torná-los finitos.
///
/// Se o tipo de elemento do iterador de que você precisa não implementa `Clone`, ou se você não deseja manter o elemento repetido na memória, você pode usar a função [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::iter;
///
/// // o número quatro 4 sempre:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // sim, ainda quatro
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Tornando-se finito com o [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // esse último exemplo foi muitos quatros.Vamos ter apenas quatro quatros.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... e agora terminamos
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Um iterador que repete um elemento indefinidamente.
///
/// Este `struct` é criado pela função [`repeat()`].Veja sua documentação para mais.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}