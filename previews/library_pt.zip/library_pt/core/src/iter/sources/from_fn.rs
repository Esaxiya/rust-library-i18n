use crate::fmt;

/// Cria um novo iterador em que cada iteração chama o encerramento fornecido `F: FnMut() -> Option<T>`.
///
/// Isso permite criar um iterador personalizado com qualquer comportamento sem usar a sintaxe mais detalhada de criar um tipo dedicado e implementar o [`Iterator`] trait para ele.
///
/// Observe que o iterador `FromFn` não faz suposições sobre o comportamento do fechamento e, portanto, de maneira conservadora, não implementa o [`FusedIterator`] ou substitui o [`Iterator::size_hint()`] de seu `(0, None)` padrão.
///
///
/// O encerramento pode usar capturas e seu ambiente para rastrear o estado nas iterações.Dependendo de como o iterador é usado, isso pode exigir a especificação da palavra-chave [`move`] no encerramento.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Vamos reimplementar o contador iterador do [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Aumente nossa contagem.É por isso que começamos do zero.
///     count += 1;
///
///     // Verifique se terminamos a contagem ou não.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Um iterador em que cada iteração chama o encerramento fornecido `F: FnMut() -> Option<T>`.
///
/// Este `struct` é criado pela função [`iter::from_fn()`].
/// Veja sua documentação para mais.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}