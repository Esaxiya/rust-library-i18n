use crate::iter::{FusedIterator, TrustedLen};

/// Cria um iterador que produz um elemento exatamente uma vez.
///
/// Isso é comumente usado para adaptar um único valor em um [`chain()`] de outros tipos de iteração.
/// Talvez você tenha um iterador que cubra quase tudo, mas você precisa de um caso especial extra.
/// Talvez você tenha uma função que funcione em iteradores, mas só precisa processar um valor.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::iter;
///
/// // um é o número mais solitário
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // apenas um, é tudo o que temos
/// assert_eq!(None, one.next());
/// ```
///
/// Encadeando com outro iterador.
/// Digamos que queremos iterar sobre cada arquivo do diretório `.foo`, mas também um arquivo de configuração,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // precisamos converter de um iterador de DirEntry-s em um iterador de PathBufs, então usamos map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // agora, nosso iterador apenas para nosso arquivo de configuração
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // encadeie os dois iteradores em um grande iterador
/// let files = dirs.chain(config);
///
/// // isso nos dará todos os arquivos no .foo, bem como no .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Um iterador que produz um elemento exatamente uma vez.
///
/// Este `struct` é criado pela função [`once()`].Veja sua documentação para mais.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}