use crate::iter::{FusedIterator, TrustedLen};

/// Cria um novo iterador que repete elementos do tipo `A` indefinidamente, aplicando o fechamento fornecido, o repetidor, `F: FnMut() -> A`.
///
/// A função `repeat_with()` chama o repetidor continuamente.
///
/// Iteradores infinitos como o `repeat_with()` são freqüentemente usados com adaptadores como o [`Iterator::take()`], para torná-los finitos.
///
/// Se o tipo de elemento do iterador de que você precisa implementar o [`Clone`] e for possível manter o elemento de origem na memória, você deve usar a função [`repeat()`].
///
///
/// Um iterador produzido pelo `repeat_with()` não é um [`DoubleEndedIterator`].
/// Se você precisar que o `repeat_with()` devolva um [`DoubleEndedIterator`], abra um problema do GitHub explicando seu caso de uso.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::iter;
///
/// // vamos supor que temos algum valor de um tipo que não é `Clone` ou que não queremos ter na memória ainda porque é caro:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // um determinado valor para sempre:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Usando mutação e tornando-se finito:
///
/// ```rust
/// use std::iter;
///
/// // Do zero ao terceiro poder de dois:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... e agora terminamos
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Um iterador que repete elementos do tipo `A` indefinidamente, aplicando o fecho `F: FnMut() -> A` fornecido.
///
///
/// Este `struct` é criado pela função [`repeat_with()`].
/// Veja sua documentação para mais.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}