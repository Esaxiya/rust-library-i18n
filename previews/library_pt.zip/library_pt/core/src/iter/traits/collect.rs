/// Conversão de um [`Iterator`].
///
/// Ao implementar o `FromIterator` para um tipo, você define como ele será criado a partir de um iterador.
/// Isso é comum para tipos que descrevem uma coleção de algum tipo.
///
/// [`FromIterator::from_iter()`] raramente é chamado explicitamente e, em vez disso, é usado por meio do método [`Iterator::collect()`].
///
/// Consulte a documentação do [`Iterator::collect()`]'s para obter mais exemplos.
///
/// Veja também: [`IntoIterator`].
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Usando [`Iterator::collect()`] para usar `FromIterator` implicitamente:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Implementando `FromIterator` para seu tipo:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Uma coleção de amostra, que é apenas um invólucro sobre Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Vamos fornecer alguns métodos para que possamos criar um e adicionar coisas a ele.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // e vamos implementar FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Agora podemos fazer um novo iterador ...
/// let iter = (0..5).into_iter();
///
/// // ... e faça uma MyCollection disso
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // colete obras também!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Cria um valor de um iterador.
    ///
    /// Consulte o [module-level documentation] para obter mais informações.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Conversão em um [`Iterator`].
///
/// Ao implementar o `IntoIterator` para um tipo, você define como ele será convertido em um iterador.
/// Isso é comum para tipos que descrevem uma coleção de algum tipo.
///
/// Um benefício de implementar o `IntoIterator` é que seu tipo será [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Veja também: [`FromIterator`].
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Implementando `IntoIterator` para seu tipo:
///
/// ```
/// // Uma coleção de amostra, que é apenas um invólucro sobre Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Vamos fornecer alguns métodos para que possamos criar um e adicionar coisas a ele.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // e vamos implementar o IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Agora podemos fazer uma nova coleção ...
/// let mut c = MyCollection::new();
///
/// // ... adicione algumas coisas a ele ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... e, em seguida, transformá-lo em um Iterador:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// É comum usar o `IntoIterator` como trait bound.Isso permite que o tipo de coleção de entrada mude, desde que ainda seja um iterador.
/// Limites adicionais podem ser especificados ao restringir
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// O tipo dos elementos que estão sendo iterados.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Em que tipo de iterador estamos transformando isso?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Cria um iterador a partir de um valor.
    ///
    /// Consulte o [module-level documentation] para obter mais informações.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Estenda uma coleção com o conteúdo de um iterador.
///
/// Os iteradores produzem uma série de valores e as coleções também podem ser consideradas como uma série de valores.
/// O `Extend` trait preenche essa lacuna, permitindo que você estenda uma coleção incluindo o conteúdo desse iterador.
/// Ao estender uma coleção com uma chave já existente, essa entrada é atualizada ou, no caso de coleções que permitem várias entradas com chaves iguais, essa entrada é inserida.
///
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// // Você pode estender uma String com alguns caracteres:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Implementando `Extend`:
///
/// ```
/// // Uma coleção de amostra, que é apenas um invólucro sobre Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Vamos fornecer alguns métodos para que possamos criar um e adicionar coisas a ele.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // como MyCollection tem uma lista de i32s, implementamos Extend para i32
/// impl Extend<i32> for MyCollection {
///
///     // Isso é um pouco mais simples com a assinatura de tipo concreto: podemos chamar extend em qualquer coisa que possa ser transformada em um Iterator que nos dê i32s.
///     // Porque precisamos de i32s para colocar em MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // A implementação é muito direta: loop através do iterador e add() cada elemento para nós mesmos.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // vamos estender nossa coleção com mais três números
/// c.extend(vec![1, 2, 3]);
///
/// // adicionamos esses elementos no final
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Estende uma coleção com o conteúdo de um iterador.
    ///
    /// Como este é o único método necessário para este trait, os documentos do [trait-level] contêm mais detalhes.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // Você pode estender uma String com alguns caracteres:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Estende uma coleção com exatamente um elemento.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Reserva capacidade em uma coleção para um determinado número de elementos adicionais.
    ///
    /// A implementação padrão não faz nada.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}