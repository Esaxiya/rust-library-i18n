use crate::ops::{ControlFlow, Try};

/// Um iterador capaz de produzir elementos de ambas as extremidades.
///
/// Algo que implementa `DoubleEndedIterator` tem uma capacidade extra em relação a algo que implementa [`Iterator`]: a capacidade de também pegar `Itens` pela parte de trás, assim como pela frente.
///
///
/// É importante observar que tanto para a frente quanto para trás trabalham no mesmo intervalo e não se cruzam: a iteração termina quando eles se encontram no meio.
///
/// De maneira semelhante ao protocolo [`Iterator`], quando um `DoubleEndedIterator` retorna o [`None`] de um [`next_back()`], chamá-lo novamente pode ou não retornar o [`Some`] novamente.
/// [`next()`] e [`next_back()`] são intercambiáveis para essa finalidade.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Remove e retorna um elemento do final do iterador.
    ///
    /// Retorna `None` quando não há mais elementos.
    ///
    /// Os documentos do [trait-level] contêm mais detalhes.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Os elementos produzidos pelos métodos de `DoubleEndedIterator` podem ser diferentes daqueles produzidos pelos métodos do [`Iterator`]:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Avança o iterador na parte traseira por elementos `n`.
    ///
    /// `advance_back_by` é a versão reversa do [`advance_by`].Este método irá pular ansiosamente os elementos do `n` começando de trás, chamando o [`next_back`] até o `n` vezes até que o [`None`] seja encontrado.
    ///
    /// `advance_back_by(n)` retornará [`Ok(())`] se o iterador avançar com sucesso por elementos `n`, ou [`Err(k)`] se [`None`] for encontrado, onde `k` é o número de elementos que o iterador é avançado antes de esgotar os elementos (ou seja
    /// o comprimento do iterador).
    /// Observe que `k` é sempre menor que `n`.
    ///
    /// Chamar `advance_back_by(0)` não consome nenhum elemento e sempre retorna [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // apenas `&3` foi ignorado
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Retorna o `n`ésimo elemento do final do iterador.
    ///
    /// Esta é essencialmente a versão reversa do [`Iterator::nth()`].
    /// Embora, como a maioria das operações de indexação, a contagem comece do zero, então `nth_back(0)` retorna o primeiro valor do final, `nth_back(1)` o segundo e assim por diante.
    ///
    ///
    /// Observe que todos os elementos entre o final e o elemento retornado serão consumidos, incluindo o elemento retornado.
    /// Isso também significa que chamar o `nth_back(0)` várias vezes no mesmo iterador retornará elementos diferentes.
    ///
    /// `nth_back()` retornará [`None`] se `n` for maior ou igual ao comprimento do iterador.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Chamar o `nth_back()` várias vezes não retrocede o iterador:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Retornando `None` se houver menos de elementos `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Esta é a versão reversa do [`Iterator::try_fold()`]: ele pega elementos começando na parte de trás do iterador.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Como ele entrou em curto-circuito, os elementos restantes ainda estão disponíveis por meio do iterador.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Um método iterador que reduz os elementos do iterador a um único valor final, começando de trás.
    ///
    /// Esta é a versão reversa do [`Iterator::fold()`]: ele pega elementos começando na parte de trás do iterador.
    ///
    /// `rfold()` recebe dois argumentos: um valor inicial e um encerramento com dois argumentos: um 'accumulator' e um elemento.
    /// O fechamento retorna o valor que o acumulador deve ter para a próxima iteração.
    ///
    /// O valor inicial é o valor que o acumulador terá na primeira chamada.
    ///
    /// Depois de aplicar esse fechamento a cada elemento do iterador, o `rfold()` retorna o acumulador.
    ///
    /// Essa operação às vezes é chamada de 'reduce' ou 'inject'.
    ///
    /// A dobragem é útil sempre que você possui uma coleção de algo e deseja produzir um único valor a partir dela.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // a soma de todos os elementos de um
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Este exemplo cria uma string, começando com um valor inicial e continuando com cada elemento de trás até a frente:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Pesquisa um elemento de um iterador na parte de trás que satisfaça um predicado.
    ///
    /// `rfind()` obtém um fechamento que retorna `true` ou `false`.
    /// Ele aplica esse fechamento a cada elemento do iterador, começando no final, e se algum deles retornar `true`, então `rfind()` retornará [`Some(element)`].
    /// Se todos eles retornarem `false`, ele retornará [`None`].
    ///
    /// `rfind()` está em curto-circuito;em outras palavras, ele interromperá o processamento assim que o fechamento retornar `true`.
    ///
    /// Como o `rfind()` usa uma referência e muitos iteradores iteram sobre as referências, isso leva a uma situação possivelmente confusa em que o argumento é uma referência dupla.
    ///
    /// Você pode ver esse efeito nos exemplos abaixo, com o `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Parando no primeiro `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // ainda podemos usar o `iter`, pois há mais elementos.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}