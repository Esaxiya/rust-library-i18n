/// Um iterador que sempre continua a render `None` quando exausto.
///
/// Chamar next em um iterador fundido que retornou o `None` uma vez com certeza retornará o [`None`] novamente.
/// Este trait deve ser implementado por todos os iteradores que se comportam desta forma, pois permite otimizar o [`Iterator::fuse()`].
///
///
/// Note: Em geral, você não deve usar o `FusedIterator` em limites genéricos se precisar de um iterador fundido.
/// Em vez disso, você deve apenas chamar [`Iterator::fuse()`] no iterador.
/// Se o iterador já estiver fundido, o wrapper [`Fuse`] adicional será autônomo e sem penalidade de desempenho.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Um iterador que relata um comprimento preciso usando size_hint.
///
/// O iterador relata uma dica de tamanho em que é exata (o limite inferior é igual ao limite superior) ou o limite superior é [`None`].
///
/// O limite superior só deve ser [`None`] se o comprimento real do iterador for maior que [`usize::MAX`].
/// Nesse caso, o limite inferior deve ser [`usize::MAX`], resultando em um [`Iterator::size_hint()`] de `(usize::MAX, None)`.
///
/// O iterador deve produzir exatamente o número de elementos que relatou ou divergir antes de chegar ao fim.
///
/// # Safety
///
/// Este trait só deve ser implementado quando o contrato for mantido.
/// Os consumidores deste trait devem inspecionar o limite superior do [`Iterator::size_hint()`]’s.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Um iterador que, ao gerar um item, terá obtido pelo menos um elemento de seu [`SourceIter`] subjacente.
///
/// Chamar qualquer método que avance o iterador, por exemplo
/// [`next()`] ou [`try_fold()`], garante que para cada etapa pelo menos um valor da fonte subjacente do iterador foi movido e o resultado da cadeia do iterador pode ser inserido em seu lugar, assumindo que as restrições estruturais da fonte permitem tal inserção.
///
/// Em outras palavras, este trait indica que um pipeline de iterador pode ser coletado no local.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}