/// Um iterador que conhece seu comprimento exato.
///
/// Muitos [`Iterator`] s não sabem quantas vezes eles irão iterar, mas alguns sim.
/// Se um iterador souber quantas vezes pode iterar, fornecer acesso a essas informações pode ser útil.
/// Por exemplo, se você deseja iterar para trás, um bom começo é saber onde está o fim.
///
/// Ao implementar um `ExactSizeIterator`, você também deve implementar o [`Iterator`].
/// Ao fazer isso, a implementação de [`Iterator::size_hint`]*deve* retornar o tamanho exato do iterador.
///
/// O método [`len`] tem uma implementação padrão, então você geralmente não deve implementá-la.
/// No entanto, você pode fornecer uma implementação com mais desempenho do que o padrão, portanto, substituí-la neste caso faz sentido.
///
///
/// Observe que este trait é um trait seguro e, como tal,*não* e *não pode* garantir que o comprimento retornado esteja correto.
/// Isso significa que o código `unsafe`**não deve** depender da exatidão do [`Iterator::size_hint`].
/// O [`TrustedLen`](super::marker::TrustedLen) trait instável e inseguro oferece essa garantia adicional.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// // um intervalo finito sabe exatamente quantas vezes iterará
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// No [module-level docs], implementamos um [`Iterator`], `Counter`.
/// Vamos implementar o `ExactSizeIterator` também:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Podemos calcular facilmente o número restante de iterações.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // E agora podemos usar!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Retorna o comprimento exato do iterador.
    ///
    /// A implementação garante que o iterador retornará exatamente `len()` mais vezes um valor [`Some(T)`], antes de retornar [`None`].
    ///
    /// Este método tem uma implementação padrão, então você geralmente não deve implementá-lo diretamente.
    /// No entanto, se você puder fornecer uma implementação mais eficiente, poderá fazê-lo.
    /// Consulte a documentação do [trait-level] para obter um exemplo.
    ///
    /// Esta função tem as mesmas garantias de segurança que a função [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // um intervalo finito sabe exatamente quantas vezes iterará
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Esta afirmação é excessivamente defensiva, mas verifica o invariante
        // garantido pelo trait.
        // Se este trait fosse rust-internal, poderíamos usar debug_assert !;assert_eq!irá verificar todas as implementações do usuário Rust também.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Retorna `true` se o iterador estiver vazio.
    ///
    /// Este método tem uma implementação padrão usando [`ExactSizeIterator::len()`], portanto, você não precisa implementá-lo sozinho.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}