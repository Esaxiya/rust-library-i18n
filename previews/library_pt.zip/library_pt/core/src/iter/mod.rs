//! Iteração externa combinável.
//!
//! Se você se deparou com algum tipo de coleção e precisou realizar uma operação nos elementos dessa coleção, rapidamente encontrará o 'iterators'.
//! Os iteradores são muito usados no código idiomático Rust, portanto, vale a pena se familiarizar com eles.
//!
//! Antes de explicar mais, vamos falar sobre como este módulo está estruturado:
//!
//! # Organization
//!
//! Este módulo é amplamente organizado por tipo:
//!
//! * [Traits] são a parte central: esses traits definem que tipo de iteradores existem e o que você pode fazer com eles.Os métodos desses traits valem a pena investir algum tempo extra de estudo.
//! * [Functions] fornecem algumas maneiras úteis de criar alguns iteradores básicos.
//! * [Structs] são frequentemente os tipos de retorno dos vários métodos no traits deste módulo.Normalmente, você desejará examinar o método que cria o `struct`, em vez do próprio `struct`.
//! Para obter mais detalhes sobre o motivo, consulte '[Implementando Iterador](#implementando-iterador)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! É isso!Vamos nos aprofundar nos iteradores.
//!
//! # Iterator
//!
//! O coração e a alma deste módulo é o [`Iterator`] trait.O núcleo do [`Iterator`] é assim:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Um iterador tem um método, [`next`], que quando chamado, retorna um [`Option`]`<Item>`.
//! [`next`] retornará [`Some(Item)`] enquanto houver elementos e, uma vez que todos eles tenham sido esgotados, retornará `None` para indicar que a iteração foi concluída.
//! Os iteradores individuais podem escolher retomar a iteração e, portanto, chamar o [`next`] novamente pode ou não começar a retornar o [`Some(Item)`] novamente em algum ponto (por exemplo, consulte [`TryIter`]).
//!
//!
//! A definição completa do [`Iterator`] inclui uma série de outros métodos também, mas eles são métodos padrão, construídos sobre o [`next`] e, portanto, você os obtém gratuitamente.
//!
//! Os iteradores também podem ser combinados e é comum encadea-los para fazer formas mais complexas de processamento.Consulte a seção [Adapters](#adapters) abaixo para obter mais detalhes.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # As três formas de iteração
//!
//! Existem três métodos comuns que podem criar iteradores a partir de uma coleção:
//!
//! * `iter()`, que itera sobre `&T`.
//! * `iter_mut()`, que itera sobre `&mut T`.
//! * `into_iter()`, que itera sobre `T`.
//!
//! Várias coisas na biblioteca padrão podem implementar um ou mais dos três, quando apropriado.
//!
//! # Implementando Iterator
//!
//! A criação de um iterador próprio envolve duas etapas: criar um `struct` para manter o estado do iterador e, em seguida, implementar o [`Iterator`] para esse `struct`.
//! É por isso que existem tantos `struct`s neste módulo: há um para cada iterador e adaptador de iterador.
//!
//! Vamos fazer um iterador denominado `Counter` que conta de `1` a `5`:
//!
//! ```
//! // Primeiro, a estrutura:
//!
//! /// Um iterador que conta de um a cinco
//! struct Counter {
//!     count: usize,
//! }
//!
//! // queremos que nossa contagem comece em um, então vamos adicionar um método new() para ajudar.
//! // Isso não é estritamente necessário, mas é conveniente.
//! // Observe que iniciamos o `count` do zero, veremos o motivo na implementação do `next()`'s a seguir.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Em seguida, implementamos `Iterator` para nosso `Counter`:
//!
//! impl Iterator for Counter {
//!     // estaremos contando com usize
//!     type Item = usize;
//!
//!     // next() é o único método necessário
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Aumente nossa contagem.É por isso que começamos do zero.
//!         self.count += 1;
//!
//!         // Verifique se terminamos a contagem ou não.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // E agora podemos usar!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Chamar [`next`] dessa forma se torna repetitivo.Rust tem uma construção que pode chamar [`next`] em seu iterador, até atingir `None`.Vamos repassar isso a seguir.
//!
//! Observe também que o `Iterator` fornece uma implementação padrão de métodos como `nth` e `fold`, que chamam o `next` internamente.
//! No entanto, também é possível escrever uma implementação personalizada de métodos como `nth` e `fold` se um iterador puder computá-los com mais eficiência sem chamar o `next`.
//!
//! # `for` loops e `IntoIterator`
//!
//! A sintaxe de loop `for` de Rust é, na verdade, açúcar para iteradores.Aqui está um exemplo básico de `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Isso imprimirá os números de um a cinco, cada um em sua própria linha.Mas você notará algo aqui: nunca chamamos nada em nosso vector para produzir um iterador.O que da?
//!
//! Há um trait na biblioteca padrão para converter algo em um iterador: [`IntoIterator`].
//! Este trait tem um método, [`into_iter`], que converte o que implementa [`IntoIterator`] em um iterador.
//! Vamos dar uma olhada nesse loop `for` novamente, e no que o compilador o converte:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust desaçúcares em:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Primeiro, chamamos `into_iter()` no valor.Em seguida, combinamos o iterador que retorna, chamando o [`next`] repetidamente até ver um `None`.
//! Nesse ponto, saímos do loop com o `break` e terminamos a iteração.
//!
//! Há mais um detalhe sutil aqui: a biblioteca padrão contém uma implementação interessante do [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Em outras palavras, todos os [`Iterator`] s implementam o [`IntoIterator`], apenas retornando a si próprios.Isso significa duas coisas:
//!
//! 1. Se você estiver escrevendo um [`Iterator`], poderá usá-lo com um loop `for`.
//! 2. Se você estiver criando uma coleção, implementar o [`IntoIterator`] para ela permitirá que sua coleção seja usada com o loop `for`.
//!
//! # Iterando por referência
//!
//! Como o [`into_iter()`] assume o valor `self`, usar um loop `for` para iterar em uma coleção consome essa coleção.Freqüentemente, você pode querer iterar em uma coleção sem consumi-la.
//! Muitas coleções oferecem métodos que fornecem iteradores sobre referências, convencionalmente chamados de `iter()` e `iter_mut()`, respectivamente:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` ainda pertence a esta função.
//! ```
//!
//! Se um tipo de coleção `C` fornece `iter()`, geralmente também implementa `IntoIterator` para `&C`, com uma implementação que apenas chama `iter()`.
//! Da mesma forma, uma coleção `C` que fornece `iter_mut()` geralmente implementa `IntoIterator` para `&mut C` delegando a `iter_mut()`.Isso permite um atalho conveniente:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // igual a `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // igual a `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Embora muitas coleções ofereçam `iter()`, nem todas oferecem `iter_mut()`.
//! Por exemplo, a mutação das chaves de um [`HashSet<T>`] ou [`HashMap<K, V>`] pode colocar a coleção em um estado inconsistente se os hashes de chave mudarem, portanto, essas coleções oferecem apenas `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Funções que pegam um [`Iterator`] e retornam outro [`Iterator`] são frequentemente chamadas de 'adaptadores iteradores', pois são uma forma do 'adaptador
//! pattern'.
//!
//! Os adaptadores de iterador comuns incluem [`map`], [`take`] e [`filter`].
//! Para mais informações, consulte a documentação.
//!
//! Se for um adaptador de iterador panics, o iterador estará em um estado não especificado (mas seguro para a memória).
//! Este estado também não tem garantia de permanecer o mesmo nas versões de Rust, portanto, você deve evitar confiar nos valores exatos retornados por um iterador que entrou em pânico.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iteradores (e o iterador [adapters](#adapters)) são *preguiçosos*. Isso significa que apenas criar um iterador não faz muito _do_. Nada realmente acontece até que você chame o [`next`].
//! Isso às vezes é uma fonte de confusão ao criar um iterador apenas para seus efeitos colaterais.
//! Por exemplo, o método [`map`] chama um fechamento em cada elemento sobre o qual itera:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Isso não imprimirá nenhum valor, já que apenas criamos um iterador, em vez de usá-lo.O compilador nos avisará sobre este tipo de comportamento:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! A maneira idiomática de escrever um [`map`] para seus efeitos colaterais é usar um loop `for` ou chamar o método [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Outra maneira comum de avaliar um iterador é usar o método [`collect`] para produzir uma nova coleção.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Os iteradores não precisam ser finitos.Por exemplo, um intervalo aberto é um iterador infinito:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! É comum usar o adaptador de iterador [`take`] para transformar um iterador infinito em um finito:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Isso imprimirá os números de `0` a `4`, cada um em sua própria linha.
//!
//! Tenha em mente que os métodos em iteradores infinitos, mesmo aqueles para os quais um resultado pode ser determinado matematicamente em tempo finito, podem não terminar.
//! Especificamente, métodos como o [`min`], que no caso geral requerem a passagem de todos os elementos no iterador, provavelmente não retornarão com êxito para quaisquer iteradores infinitos.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Ah não!Um loop infinito!
//! // `ones.min()` causa um loop infinito, então não chegaremos a este ponto!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;