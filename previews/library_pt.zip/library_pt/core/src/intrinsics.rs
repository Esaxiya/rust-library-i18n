//! Intrínsecos do compilador.
//!
//! As definições correspondentes estão no `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! As implementações const correspondentes estão em `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const intrínsecos
//!
//! Note: quaisquer mudanças na constância dos intrínsecos devem ser discutidas com a equipe de linguagem.
//! Isso inclui mudanças na estabilidade da constância.
//!
//! Para tornar um intrínseco utilizável em tempo de compilação, é necessário copiar a implementação de <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> para `compiler/rustc_mir/src/interpret/intrinsics.rs` e adicionar um `#[rustc_const_unstable(feature = "foo", issue = "01234")]` ao intrínseco.
//!
//!
//! Se um intrínseco deve ser usado a partir de um `const fn` com um atributo `rustc_const_stable`, o atributo do intrínseco também deve ser `rustc_const_stable`.
//! Essa mudança não deve ser feita sem a consulta do T-lang, porque ela incorpora um recurso na linguagem que não pode ser replicado no código do usuário sem o suporte do compilador.
//!
//! # Volatiles
//!
//! Os intrínsecos voláteis fornecem operações destinadas a atuar na memória I/O, que têm a garantia de não serem reordenadas pelo compilador em outros intrínsecos voláteis.Consulte a documentação do LLVM no [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Os intrínsecos atômicos fornecem operações atômicas comuns em palavras de máquina, com várias ordenações de memória possíveis.Eles obedecem à mesma semântica que C++ 11.Consulte a documentação do LLVM no [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Uma rápida atualização sobre a ordem da memória:
//!
//! * Adquirir, uma barreira para adquirir uma fechadura.As leituras e gravações subsequentes ocorrem após a barreira.
//! * Liberar, uma barreira para liberar uma fechadura.As leituras e gravações precedentes ocorrem antes da barreira.
//! * Operações sequencialmente consistentes e sequencialmente consistentes têm a garantia de acontecer em ordem.Este é o modo padrão para trabalhar com tipos atômicos e é equivalente ao `volatile` do Java.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Essas importações são usadas para simplificar os links intra-doc
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // SEGURANÇA: consulte `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, esses intrínsecos pegam ponteiros brutos porque eles alteram a memória com alias, o que não é válido para o `&` ou `&mut`.
    //

    /// Armazena um valor se o valor atual for igual ao valor `old`.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `compare_exchange`, passando [`Ordering::SeqCst`] como os parâmetros `success` e `failure`.
    ///
    /// Por exemplo, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Armazena um valor se o valor atual for igual ao valor `old`.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `compare_exchange`, passando [`Ordering::Acquire`] como os parâmetros `success` e `failure`.
    ///
    /// Por exemplo, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Armazena um valor se o valor atual for igual ao valor `old`.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `compare_exchange`, passando [`Ordering::Release`] como `success` e [`Ordering::Relaxed`] como parâmetros `failure`.
    /// Por exemplo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Armazena um valor se o valor atual for igual ao valor `old`.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `compare_exchange`, passando [`Ordering::AcqRel`] como `success` e [`Ordering::Acquire`] como parâmetros `failure`.
    /// Por exemplo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Armazena um valor se o valor atual for igual ao valor `old`.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `compare_exchange`, passando [`Ordering::Relaxed`] como os parâmetros `success` e `failure`.
    ///
    /// Por exemplo, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Armazena um valor se o valor atual for igual ao valor `old`.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `compare_exchange`, passando [`Ordering::SeqCst`] como `success` e [`Ordering::Relaxed`] como parâmetros `failure`.
    /// Por exemplo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Armazena um valor se o valor atual for igual ao valor `old`.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `compare_exchange`, passando [`Ordering::SeqCst`] como `success` e [`Ordering::Acquire`] como parâmetros `failure`.
    /// Por exemplo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Armazena um valor se o valor atual for igual ao valor `old`.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `compare_exchange`, passando [`Ordering::Acquire`] como `success` e [`Ordering::Relaxed`] como parâmetros `failure`.
    /// Por exemplo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Armazena um valor se o valor atual for igual ao valor `old`.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `compare_exchange`, passando [`Ordering::AcqRel`] como `success` e [`Ordering::Relaxed`] como parâmetros `failure`.
    /// Por exemplo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Armazena um valor se o valor atual for igual ao valor `old`.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `compare_exchange_weak`, passando [`Ordering::SeqCst`] como os parâmetros `success` e `failure`.
    ///
    /// Por exemplo, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Armazena um valor se o valor atual for igual ao valor `old`.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `compare_exchange_weak`, passando [`Ordering::Acquire`] como os parâmetros `success` e `failure`.
    ///
    /// Por exemplo, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Armazena um valor se o valor atual for igual ao valor `old`.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `compare_exchange_weak`, passando [`Ordering::Release`] como `success` e [`Ordering::Relaxed`] como parâmetros `failure`.
    /// Por exemplo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Armazena um valor se o valor atual for igual ao valor `old`.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `compare_exchange_weak`, passando [`Ordering::AcqRel`] como `success` e [`Ordering::Acquire`] como parâmetros `failure`.
    /// Por exemplo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Armazena um valor se o valor atual for igual ao valor `old`.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `compare_exchange_weak`, passando [`Ordering::Relaxed`] como os parâmetros `success` e `failure`.
    ///
    /// Por exemplo, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Armazena um valor se o valor atual for igual ao valor `old`.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `compare_exchange_weak`, passando [`Ordering::SeqCst`] como `success` e [`Ordering::Relaxed`] como parâmetros `failure`.
    /// Por exemplo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Armazena um valor se o valor atual for igual ao valor `old`.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `compare_exchange_weak`, passando [`Ordering::SeqCst`] como `success` e [`Ordering::Acquire`] como parâmetros `failure`.
    /// Por exemplo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Armazena um valor se o valor atual for igual ao valor `old`.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `compare_exchange_weak`, passando [`Ordering::Acquire`] como `success` e [`Ordering::Relaxed`] como parâmetros `failure`.
    /// Por exemplo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Armazena um valor se o valor atual for igual ao valor `old`.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `compare_exchange_weak`, passando [`Ordering::AcqRel`] como `success` e [`Ordering::Relaxed`] como parâmetros `failure`.
    /// Por exemplo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Carrega o valor atual do ponteiro.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `load`, passando o [`Ordering::SeqCst`] como `order`.
    /// Por exemplo, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Carrega o valor atual do ponteiro.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `load`, passando o [`Ordering::Acquire`] como `order`.
    /// Por exemplo, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Carrega o valor atual do ponteiro.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `load`, passando o [`Ordering::Relaxed`] como `order`.
    /// Por exemplo, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Armazena o valor no local de memória especificado.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `store`, passando o [`Ordering::SeqCst`] como `order`.
    /// Por exemplo, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Armazena o valor no local de memória especificado.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `store`, passando o [`Ordering::Release`] como `order`.
    /// Por exemplo, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Armazena o valor no local de memória especificado.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `store`, passando o [`Ordering::Relaxed`] como `order`.
    /// Por exemplo, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Armazena o valor no local de memória especificado, retornando o valor antigo.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `swap`, passando o [`Ordering::SeqCst`] como `order`.
    /// Por exemplo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Armazena o valor no local de memória especificado, retornando o valor antigo.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `swap`, passando o [`Ordering::Acquire`] como `order`.
    /// Por exemplo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Armazena o valor no local de memória especificado, retornando o valor antigo.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `swap`, passando o [`Ordering::Release`] como o `order`.
    /// Por exemplo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Armazena o valor no local de memória especificado, retornando o valor antigo.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `swap`, passando o [`Ordering::AcqRel`] como `order`.
    /// Por exemplo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Armazena o valor no local de memória especificado, retornando o valor antigo.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `swap`, passando o [`Ordering::Relaxed`] como `order`.
    /// Por exemplo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Adiciona ao valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `fetch_add`, passando o [`Ordering::SeqCst`] como `order`.
    /// Por exemplo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Adiciona ao valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `fetch_add`, passando o [`Ordering::Acquire`] como `order`.
    /// Por exemplo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Adiciona ao valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `fetch_add`, passando o [`Ordering::Release`] como `order`.
    /// Por exemplo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Adiciona ao valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `fetch_add`, passando o [`Ordering::AcqRel`] como `order`.
    /// Por exemplo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Adiciona ao valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `fetch_add`, passando o [`Ordering::Relaxed`] como `order`.
    /// Por exemplo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Subtraia do valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `fetch_sub`, passando o [`Ordering::SeqCst`] como `order`.
    /// Por exemplo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Subtraia do valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `fetch_sub`, passando o [`Ordering::Acquire`] como `order`.
    /// Por exemplo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Subtraia do valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `fetch_sub`, passando o [`Ordering::Release`] como `order`.
    /// Por exemplo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Subtraia do valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `fetch_sub`, passando o [`Ordering::AcqRel`] como `order`.
    /// Por exemplo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Subtraia do valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `fetch_sub`, passando o [`Ordering::Relaxed`] como `order`.
    /// Por exemplo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise e com o valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `fetch_and`, passando o [`Ordering::SeqCst`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise e com o valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `fetch_and`, passando o [`Ordering::Acquire`] como o `order`.
    /// Por exemplo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise e com o valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `fetch_and`, passando o [`Ordering::Release`] como o `order`.
    /// Por exemplo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise e com o valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `fetch_and`, passando o [`Ordering::AcqRel`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise e com o valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `fetch_and`, passando o [`Ordering::Relaxed`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Nand bit a bit com o valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível no tipo [`AtomicBool`] por meio do método `fetch_nand`, passando o [`Ordering::SeqCst`] como o `order`.
    /// Por exemplo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nand bit a bit com o valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível no tipo [`AtomicBool`] por meio do método `fetch_nand`, passando o [`Ordering::Acquire`] como o `order`.
    /// Por exemplo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nand bit a bit com o valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível no tipo [`AtomicBool`] por meio do método `fetch_nand`, passando o [`Ordering::Release`] como o `order`.
    /// Por exemplo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nand bit a bit com o valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível no tipo [`AtomicBool`] por meio do método `fetch_nand`, passando o [`Ordering::AcqRel`] como o `order`.
    /// Por exemplo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nand bit a bit com o valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível no tipo [`AtomicBool`] por meio do método `fetch_nand`, passando o [`Ordering::Relaxed`] como o `order`.
    /// Por exemplo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise ou com o valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `fetch_or`, passando o [`Ordering::SeqCst`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ou com o valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `fetch_or`, passando o [`Ordering::Acquire`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ou com o valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `fetch_or`, passando o [`Ordering::Release`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ou com o valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `fetch_or`, passando o [`Ordering::AcqRel`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ou com o valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `fetch_or`, passando o [`Ordering::Relaxed`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Xor bit a bit com o valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `fetch_xor`, passando o [`Ordering::SeqCst`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Xor bit a bit com o valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `fetch_xor`, passando o [`Ordering::Acquire`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Xor bit a bit com o valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `fetch_xor`, passando o [`Ordering::Release`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Xor bit a bit com o valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `fetch_xor`, passando o [`Ordering::AcqRel`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Xor bit a bit com o valor atual, retornando o valor anterior.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos [`atomic`] por meio do método `fetch_xor`, passando o [`Ordering::Relaxed`] como o `order`.
    /// Por exemplo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Máximo com o valor atual usando uma comparação assinada.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos inteiros assinados [`atomic`] por meio do método `fetch_max`, passando o [`Ordering::SeqCst`] como o `order`.
    /// Por exemplo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Máximo com o valor atual usando uma comparação assinada.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos inteiros assinados [`atomic`] por meio do método `fetch_max`, passando o [`Ordering::Acquire`] como o `order`.
    /// Por exemplo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Máximo com o valor atual usando uma comparação assinada.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos inteiros assinados [`atomic`] por meio do método `fetch_max`, passando o [`Ordering::Release`] como o `order`.
    /// Por exemplo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Máximo com o valor atual usando uma comparação assinada.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos inteiros assinados [`atomic`] por meio do método `fetch_max`, passando o [`Ordering::AcqRel`] como o `order`.
    /// Por exemplo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Máximo com o valor atual.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos inteiros assinados [`atomic`] por meio do método `fetch_max`, passando o [`Ordering::Relaxed`] como o `order`.
    /// Por exemplo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Mínimo com o valor atual usando uma comparação assinada.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos inteiros assinados [`atomic`] por meio do método `fetch_min`, passando o [`Ordering::SeqCst`] como o `order`.
    /// Por exemplo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínimo com o valor atual usando uma comparação assinada.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos inteiros assinados [`atomic`] por meio do método `fetch_min`, passando o [`Ordering::Acquire`] como o `order`.
    /// Por exemplo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínimo com o valor atual usando uma comparação assinada.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos inteiros assinados [`atomic`] por meio do método `fetch_min`, passando o [`Ordering::Release`] como o `order`.
    /// Por exemplo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínimo com o valor atual usando uma comparação assinada.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos inteiros assinados [`atomic`] por meio do método `fetch_min`, passando o [`Ordering::AcqRel`] como o `order`.
    /// Por exemplo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínimo com o valor atual usando uma comparação assinada.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos inteiros assinados [`atomic`] por meio do método `fetch_min`, passando o [`Ordering::Relaxed`] como o `order`.
    /// Por exemplo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Mínimo com o valor atual usando uma comparação sem sinal.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos inteiros sem sinal [`atomic`] por meio do método `fetch_min`, passando o [`Ordering::SeqCst`] como o `order`.
    /// Por exemplo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínimo com o valor atual usando uma comparação sem sinal.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos inteiros sem sinal [`atomic`] por meio do método `fetch_min`, passando o [`Ordering::Acquire`] como o `order`.
    /// Por exemplo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínimo com o valor atual usando uma comparação sem sinal.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos inteiros sem sinal [`atomic`] por meio do método `fetch_min`, passando o [`Ordering::Release`] como o `order`.
    /// Por exemplo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínimo com o valor atual usando uma comparação sem sinal.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos inteiros sem sinal [`atomic`] por meio do método `fetch_min`, passando o [`Ordering::AcqRel`] como o `order`.
    /// Por exemplo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínimo com o valor atual usando uma comparação sem sinal.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos inteiros sem sinal [`atomic`] por meio do método `fetch_min`, passando o [`Ordering::Relaxed`] como o `order`.
    /// Por exemplo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Máximo com o valor atual usando uma comparação sem sinal.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos inteiros sem sinal [`atomic`] por meio do método `fetch_max`, passando o [`Ordering::SeqCst`] como o `order`.
    /// Por exemplo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Máximo com o valor atual usando uma comparação sem sinal.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos inteiros sem sinal [`atomic`] por meio do método `fetch_max`, passando o [`Ordering::Acquire`] como o `order`.
    /// Por exemplo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Máximo com o valor atual usando uma comparação sem sinal.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos inteiros sem sinal [`atomic`] por meio do método `fetch_max`, passando o [`Ordering::Release`] como o `order`.
    /// Por exemplo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Máximo com o valor atual usando uma comparação sem sinal.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos inteiros sem sinal [`atomic`] por meio do método `fetch_max`, passando o [`Ordering::AcqRel`] como o `order`.
    /// Por exemplo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Máximo com o valor atual usando uma comparação sem sinal.
    ///
    /// A versão estabilizada desse intrínseco está disponível nos tipos inteiros sem sinal [`atomic`] por meio do método `fetch_max`, passando o [`Ordering::Relaxed`] como o `order`.
    /// Por exemplo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// O `prefetch` intrínseco é uma dica para o gerador de código inserir uma instrução de pré-busca, se houver suporte;caso contrário, é um ambiente autônomo.
    /// As pré-buscas não afetam o comportamento do programa, mas podem alterar suas características de desempenho.
    ///
    /// O argumento `locality` deve ser um número inteiro constante e é um especificador de localidade temporal que varia de (0), sem localidade, a (3), armazenamento extremamente local em cache.
    ///
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// O `prefetch` intrínseco é uma dica para o gerador de código inserir uma instrução de pré-busca, se houver suporte;caso contrário, é um ambiente autônomo.
    /// As pré-buscas não afetam o comportamento do programa, mas podem alterar suas características de desempenho.
    ///
    /// O argumento `locality` deve ser um número inteiro constante e é um especificador de localidade temporal que varia de (0), sem localidade, a (3), armazenamento extremamente local em cache.
    ///
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// O `prefetch` intrínseco é uma dica para o gerador de código inserir uma instrução de pré-busca, se houver suporte;caso contrário, é um ambiente autônomo.
    /// As pré-buscas não afetam o comportamento do programa, mas podem alterar suas características de desempenho.
    ///
    /// O argumento `locality` deve ser um número inteiro constante e é um especificador de localidade temporal que varia de (0), sem localidade, a (3), armazenamento extremamente local em cache.
    ///
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// O `prefetch` intrínseco é uma dica para o gerador de código inserir uma instrução de pré-busca, se houver suporte;caso contrário, é um ambiente autônomo.
    /// As pré-buscas não afetam o comportamento do programa, mas podem alterar suas características de desempenho.
    ///
    /// O argumento `locality` deve ser um número inteiro constante e é um especificador de localidade temporal que varia de (0), sem localidade, a (3), armazenamento extremamente local em cache.
    ///
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Uma cerca atômica.
    ///
    /// A versão estabilizada deste intrínseco está disponível no [`atomic::fence`] passando o [`Ordering::SeqCst`] como o `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Uma cerca atômica.
    ///
    /// A versão estabilizada deste intrínseco está disponível no [`atomic::fence`] passando o [`Ordering::Acquire`] como o `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Uma cerca atômica.
    ///
    /// A versão estabilizada deste intrínseco está disponível no [`atomic::fence`] passando o [`Ordering::Release`] como o `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Uma cerca atômica.
    ///
    /// A versão estabilizada deste intrínseco está disponível no [`atomic::fence`] passando o [`Ordering::AcqRel`] como o `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Uma barreira de memória apenas do compilador.
    ///
    /// Os acessos à memória nunca serão reordenados através dessa barreira pelo compilador, mas nenhuma instrução será emitida para isso.
    /// Isso é apropriado para operações no mesmo encadeamento que podem ser interrompidas, como ao interagir com manipuladores de sinal.
    ///
    /// A versão estabilizada deste intrínseco está disponível no [`atomic::compiler_fence`] passando o [`Ordering::SeqCst`] como o `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Uma barreira de memória apenas do compilador.
    ///
    /// Os acessos à memória nunca serão reordenados através dessa barreira pelo compilador, mas nenhuma instrução será emitida para isso.
    /// Isso é apropriado para operações no mesmo encadeamento que podem ser interrompidas, como ao interagir com manipuladores de sinal.
    ///
    /// A versão estabilizada deste intrínseco está disponível no [`atomic::compiler_fence`] passando o [`Ordering::Acquire`] como o `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Uma barreira de memória apenas do compilador.
    ///
    /// Os acessos à memória nunca serão reordenados através dessa barreira pelo compilador, mas nenhuma instrução será emitida para isso.
    /// Isso é apropriado para operações no mesmo encadeamento que podem ser interrompidas, como ao interagir com manipuladores de sinal.
    ///
    /// A versão estabilizada desse intrínseco está disponível no [`atomic::compiler_fence`] passando o [`Ordering::Release`] como o `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Uma barreira de memória apenas do compilador.
    ///
    /// Os acessos à memória nunca serão reordenados através dessa barreira pelo compilador, mas nenhuma instrução será emitida para isso.
    /// Isso é apropriado para operações no mesmo encadeamento que podem ser interrompidas, como ao interagir com manipuladores de sinal.
    ///
    /// A versão estabilizada deste intrínseco está disponível no [`atomic::compiler_fence`] passando o [`Ordering::AcqRel`] como o `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Magia intrínseca que deriva seu significado de atributos vinculados à função.
    ///
    /// Por exemplo, o fluxo de dados usa isso para injetar asserções estáticas para que o `rustc_peek(potentially_uninitialized)` verifique novamente se o fluxo de dados realmente calculou que não foi inicializado naquele ponto do fluxo de controle.
    ///
    ///
    /// Este intrínseco não deve ser usado fora do compilador.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Aborta a execução do processo.
    ///
    /// Uma versão mais estável e fácil de usar dessa operação é o [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Informa ao otimizador que este ponto do código não é alcançável, possibilitando novas otimizações.
    ///
    /// NB, isso é muito diferente da macro `unreachable!()`: Ao contrário da macro, que panics quando é executada, é *comportamento indefinido* chegar ao código marcado com esta função.
    ///
    ///
    /// A versão estabilizada desse intrínseco é o [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Informa ao otimizador que uma condição é sempre verdadeira.
    /// Se a condição for falsa, o comportamento é indefinido.
    ///
    /// Nenhum código é gerado para esse intrínseco, mas o otimizador tentará preservá-lo (e sua condição) entre as passagens, o que pode interferir na otimização do código circundante e reduzir o desempenho.
    /// Não deve ser usado se o invariante puder ser descoberto pelo otimizador por conta própria ou se não permitir nenhuma otimização significativa.
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Sugere ao compilador que a condição branch provavelmente é verdadeira.
    /// Retorna o valor passado a ele.
    ///
    /// Qualquer uso diferente das instruções `if` provavelmente não surtirá efeito.
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Sugere ao compilador que a condição branch provavelmente é falsa.
    /// Retorna o valor passado a ele.
    ///
    /// Qualquer uso diferente das instruções `if` provavelmente não surtirá efeito.
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Executa uma interceptação de ponto de interrupção, para inspeção por um depurador.
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    pub fn breakpoint();

    /// O tamanho de um tipo em bytes.
    ///
    /// Mais especificamente, este é o deslocamento em bytes entre itens sucessivos do mesmo tipo, incluindo preenchimento de alinhamento.
    ///
    ///
    /// A versão estabilizada desse intrínseco é o [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// O alinhamento mínimo de um tipo.
    ///
    /// A versão estabilizada desse intrínseco é o [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// O alinhamento preferido de um tipo.
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// O tamanho do valor referenciado em bytes.
    ///
    /// A versão estabilizada desse intrínseco é o [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// O alinhamento necessário do valor referenciado.
    ///
    /// A versão estabilizada desse intrínseco é o [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Obtém uma fatia de string estática contendo o nome de um tipo.
    ///
    /// A versão estabilizada desse intrínseco é o [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Obtém um identificador que é globalmente exclusivo para o tipo especificado.
    /// Esta função retornará o mesmo valor para um tipo, independentemente de qualquer crate em que seja chamada.
    ///
    ///
    /// A versão estabilizada desse intrínseco é o [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Uma proteção para funções inseguras que nunca podem ser executadas se o `T` estiver desabitado:
    /// Isso irá estaticamente panic ou não fará nada.
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Uma proteção para funções inseguras que nunca podem ser executadas se o `T` não permitir a inicialização de zero: Isso irá panic estaticamente ou não fará nada.
    ///
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    pub fn assert_zero_valid<T>();

    /// Uma proteção para funções inseguras que nunca podem ser executadas se o `T` tiver padrões de bits inválidos: Isso irá estaticamente panic ou não fará nada.
    ///
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    pub fn assert_uninit_valid<T>();

    /// Obtém uma referência a um `Location` estático indicando onde foi chamado.
    ///
    /// Considere usar o [`core::panic::Location::caller`](crate::panic::Location::caller).
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Move um valor para fora do escopo sem aplicar cola drop.
    ///
    /// Isso existe apenas para o [`mem::forget_unsized`];O `forget` normal usa o `ManuallyDrop` em seu lugar.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Reinterpreta os bits de um valor de um tipo como outro tipo.
    ///
    /// Ambos os tipos devem ter o mesmo tamanho.
    /// Nem o original, nem o resultado, pode ser um [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` é semanticamente equivalente a uma movimentação bit a bit de um tipo para outro.Ele copia os bits do valor de origem para o valor de destino e, a seguir, esquece o original.
    /// É equivalente ao `memcpy` do C sob o capô, assim como o `transmute_copy`.
    ///
    /// Como `transmute` é uma operação por valor, o alinhamento dos *valores transmutados* não é uma preocupação.
    /// Como com qualquer outra função, o compilador já garante que o `T` e o `U` estejam alinhados corretamente.
    /// No entanto, ao transmutar valores que *apontam para outro lugar*(como ponteiros, referências, caixas ...), o chamador deve garantir o alinhamento adequado dos valores apontados.
    ///
    /// `transmute` é **incrivelmente** inseguro.Há um grande número de maneiras de causar o [undefined behavior][ub] com esta função.`transmute` deve ser o último recurso absoluto.
    ///
    /// O [nomicon](../../nomicon/transmutes.html) possui documentação adicional.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Existem algumas coisas para as quais o `transmute` é realmente útil.
    ///
    /// Transformar um ponteiro em um ponteiro de função.Isso *não* é portátil para máquinas onde ponteiros de função e ponteiros de dados têm tamanhos diferentes.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Prolongando a vida útil ou encurtando uma vida invariável.Este é um Rust avançado e muito inseguro!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Não se desespere: muitos usos do `transmute` podem ser obtidos por outros meios.
    /// Abaixo estão as aplicações comuns do `transmute` que podem ser substituídas por construções mais seguras.
    ///
    /// Transformando bytes(`&[u8]`) bruto em `u32`, `f64`, etc .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // use `u32::from_ne_bytes` em vez disso
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // ou use `u32::from_le_bytes` ou `u32::from_be_bytes` para especificar o endianness
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Transformando um ponteiro em um `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Use um elenco `as` em vez disso
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Transformando um `*mut T` em um `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Use um novo amanhã
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Transformando um `&mut T` em um `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Agora, junte o `as` e o novo empréstimo, observe que o encadeamento do `as` `as` não é transitivo
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Transformando um `&str` em um `&[u8]`:
    ///
    /// ```
    /// // esta não é uma boa maneira de fazer isso.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Você poderia usar `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Ou, apenas use uma string de byte, se você tiver controle sobre o literal de string
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Transformando um `Vec<&T>` em um `Vec<Option<&T>>`.
    ///
    /// Para transmutar o tipo interno do conteúdo de um contêiner, você deve se certificar de não violar nenhuma das invariáveis do contêiner.
    /// Para o `Vec`, isso significa que o tamanho *e o alinhamento* dos tipos internos devem corresponder.
    /// Outros contêineres podem depender do tamanho do tipo, alinhamento ou mesmo do `TypeId`, caso em que a transmutação não seria possível sem violar as invariáveis do contêiner.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // clone o vector, pois iremos reutilizá-los mais tarde
    /// let v_clone = v_orig.clone();
    ///
    /// // Usando transmutar: depende do layout de dados não especificado do `Vec`, o que é uma má ideia e pode causar comportamento indefinido.
    /////
    /// // No entanto, não é cópia.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Esta é a maneira sugerida e segura.
    /// // Ele copia todo o vector, entretanto, em uma nova matriz.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Esta é a maneira adequada de não copiar e não segura de "transmuting" a `Vec`, sem depender do layout de dados.
    /// // Em vez de chamar literalmente o `transmute`, executamos uma conversão de ponteiro, mas em termos de conversão do tipo interno original (`&i32`) para o novo (`Option<&i32>`), isso tem as mesmas ressalvas.
    /////
    /// // Além das informações fornecidas acima, consulte também a documentação do [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Atualize quando vec_into_raw_parts estiver estabilizado.
    ///     // Certifique-se de que o vector original não caiu.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Implementando `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Existem várias maneiras de fazer isso e vários problemas com a seguinte maneira do (transmute).
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // primeiro: transmutar não é seguro para o tipo;tudo o que verifica é que T e
    ///         // Você é do mesmo tamanho.
    ///         // Em segundo lugar, bem aqui, você tem duas referências mutáveis apontando para a mesma memória.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Isso elimina os problemas de segurança de tipo;O `&mut *`* apenas *fornecerá um `&mut T` de um `&mut T` ou `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // entretanto, você ainda tem duas referências mutáveis apontando para a mesma memória.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // É assim que a biblioteca padrão faz.
    /// // Este é o melhor método, se você precisar fazer algo assim
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Isso agora tem três referências mutáveis apontando para a mesma memória.`slice`, o rvalue ret.0 e o rvalue ret.1.
    ///         // `slice` nunca é usado após o `let ptr = ...` e, portanto, pode-se tratá-lo como "dead" e, portanto, você só tem dois segmentos mutáveis reais.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Embora isso torne o const intrínseco estável, temos alguns códigos personalizados em const fn
    // verificações que impedem seu uso no `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Retorna `true` se o tipo real fornecido como `T` requer cola drop;retorna `false` se o tipo real fornecido para `T` implementar `Copy`.
    ///
    ///
    /// Se o tipo real não requer cola nem implementa `Copy`, então o valor de retorno desta função não é especificado.
    ///
    /// A versão estabilizada desse intrínseco é o [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Calcula o deslocamento de um ponteiro.
    ///
    /// Isso é implementado como um intrínseco para evitar a conversão de e para um inteiro, uma vez que a conversão descartaria informações de aliasing.
    ///
    /// # Safety
    ///
    /// Tanto o ponteiro inicial quanto o resultante devem estar dentro dos limites ou um byte após o final de um objeto alocado.
    /// Se um dos ponteiros estiver fora dos limites ou ocorrer um estouro aritmético, qualquer uso posterior do valor retornado resultará em um comportamento indefinido.
    ///
    ///
    /// A versão estabilizada desse intrínseco é o [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Calcula o deslocamento de um ponteiro, potencialmente envolvendo.
    ///
    /// Isso é implementado como um intrínseco para evitar a conversão de e para um inteiro, uma vez que a conversão inibe certas otimizações.
    ///
    /// # Safety
    ///
    /// Ao contrário do intrínseco do `offset`, este intrínseco não restringe o ponteiro resultante para apontar para dentro ou um byte após o final de um objeto alocado e envolve a aritmética de complemento de dois.
    /// O valor resultante não é necessariamente válido para ser usado para acessar a memória de fato.
    ///
    /// A versão estabilizada desse intrínseco é o [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Equivalente ao `llvm.memcpy.p0i8.0i8.*` intrínseco apropriado, com um tamanho de `count`*`size_of::<T>()` e um alinhamento de
    ///
    /// `min_align_of::<T>()`
    ///
    /// O parâmetro volátil é definido como `true`, portanto, não será otimizado a menos que o tamanho seja igual a zero.
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Equivalente ao `llvm.memmove.p0i8.0i8.*` intrínseco apropriado, com um tamanho de `count* size_of::<T>()` e um alinhamento de
    ///
    /// `min_align_of::<T>()`
    ///
    /// O parâmetro volátil é definido como `true`, portanto, não será otimizado a menos que o tamanho seja igual a zero.
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Equivalente ao `llvm.memset.p0i8.*` intrínseco apropriado, com um tamanho de `count* size_of::<T>()` e um alinhamento de `min_align_of::<T>()`.
    ///
    ///
    /// O parâmetro volátil é definido como `true`, portanto, não será otimizado a menos que o tamanho seja igual a zero.
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Executa uma carga volátil do ponteiro `src`.
    ///
    /// A versão estabilizada desse intrínseco é o [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Executa um armazenamento volátil para o ponteiro `dst`.
    ///
    /// A versão estabilizada desse intrínseco é o [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Executa uma carga volátil do ponteiro `src`. O ponteiro não precisa estar alinhado.
    ///
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Executa um armazenamento volátil para o ponteiro `dst`.
    /// O ponteiro não precisa estar alinhado.
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Retorna a raiz quadrada de um `f32`
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Retorna a raiz quadrada de um `f64`
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Eleva um `f32` a uma potência inteira.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Eleva um `f64` a uma potência inteira.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Retorna o seno de um `f32`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Retorna o seno de um `f64`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Retorna o cosseno de um `f32`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Retorna o cosseno de um `f64`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Eleva um `f32` a uma potência de `f32`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Eleva um `f64` a uma potência de `f64`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Retorna o exponencial de um `f32`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Retorna o exponencial de um `f64`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Retorna 2 elevado à potência de um `f32`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Retorna 2 elevado à potência de um `f64`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Retorna o logaritmo natural de um `f32`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Retorna o logaritmo natural de um `f64`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Retorna o logaritmo de base 10 de um `f32`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Retorna o logaritmo de base 10 de um `f64`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Retorna o logaritmo de base 2 de um `f32`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Retorna o logaritmo de base 2 de um `f64`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Retorna `a * b + c` para valores `f32`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Retorna `a * b + c` para valores `f64`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Retorna o valor absoluto de um `f32`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Retorna o valor absoluto de um `f64`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Retorna o mínimo de dois valores `f32`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Retorna o mínimo de dois valores `f64`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Retorna o máximo de dois valores `f32`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Retorna o máximo de dois valores `f64`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Copia o sinal de `y` para `x` para valores `f32`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Copia o sinal de `y` para `x` para valores `f64`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Retorna o maior inteiro menor ou igual a `f32`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Retorna o maior inteiro menor ou igual a `f64`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Retorna o menor inteiro maior ou igual a `f32`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Retorna o menor inteiro maior ou igual a `f64`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Retorna a parte inteira de um `f32`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Retorna a parte inteira de um `f64`.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Retorna o número inteiro mais próximo a um `f32`.
    /// Pode gerar uma exceção de ponto flutuante inexata se o argumento não for um inteiro.
    pub fn rintf32(x: f32) -> f32;
    /// Retorna o número inteiro mais próximo a um `f64`.
    /// Pode gerar uma exceção de ponto flutuante inexata se o argumento não for um inteiro.
    pub fn rintf64(x: f64) -> f64;

    /// Retorna o número inteiro mais próximo a um `f32`.
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Retorna o número inteiro mais próximo a um `f64`.
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Retorna o número inteiro mais próximo a um `f32`.Arredonda os casos intermediários para longe de zero.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Retorna o número inteiro mais próximo a um `f64`.Arredonda os casos intermediários para longe de zero.
    ///
    /// A versão estabilizada deste intrínseco é
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Adição de flutuação que permite otimizações baseadas em regras algébricas.
    /// Pode assumir que as entradas são finitas.
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Subtração de flutuação que permite otimizações com base em regras algébricas.
    /// Pode assumir que as entradas são finitas.
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Multiplicação de flutuação que permite otimizações baseadas em regras algébricas.
    /// Pode assumir que as entradas são finitas.
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Divisão flutuante que permite otimizações baseadas em regras algébricas.
    /// Pode assumir que as entradas são finitas.
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Restante flutuante que permite otimizações baseadas em regras algébricas.
    /// Pode assumir que as entradas são finitas.
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Converta com o fptoui/fptosi do LLVM, que pode retornar undef para valores fora do intervalo
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Estabilizado como [`f32::to_int_unchecked`] e [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Retorna o número de bits definidos em um tipo inteiro `T`
    ///
    /// As versões estabilizadas desse intrínseco estão disponíveis nas primitivas inteiras por meio do método `count_ones`.
    /// Por exemplo,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Retorna o número de bits iniciais não definidos (zeroes) em um tipo inteiro `T`.
    ///
    /// As versões estabilizadas desse intrínseco estão disponíveis nas primitivas inteiras por meio do método `leading_zeros`.
    /// Por exemplo,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// Um `x` com o valor `0` retornará a largura de bits de `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Como o `ctlz`, mas extremamente inseguro, pois retorna `undef` quando é fornecido um `x` com o valor `0`.
    ///
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Retorna o número de bits não definidos à direita (zeroes) em um tipo inteiro `T`.
    ///
    /// As versões estabilizadas desse intrínseco estão disponíveis nas primitivas inteiras por meio do método `trailing_zeros`.
    /// Por exemplo,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// Um `x` com o valor `0` retornará a largura de bits de `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Como o `cttz`, mas extremamente inseguro, pois retorna `undef` quando é fornecido um `x` com o valor `0`.
    ///
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Reverte os bytes em um tipo inteiro `T`.
    ///
    /// As versões estabilizadas desse intrínseco estão disponíveis nas primitivas inteiras por meio do método `swap_bytes`.
    /// Por exemplo,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Inverte os bits em um tipo inteiro `T`.
    ///
    /// As versões estabilizadas desse intrínseco estão disponíveis nas primitivas inteiras por meio do método `reverse_bits`.
    /// Por exemplo,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Executa adição de inteiro verificado.
    ///
    /// As versões estabilizadas desse intrínseco estão disponíveis nas primitivas inteiras por meio do método `overflowing_add`.
    /// Por exemplo,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Executa subtração de inteiro verificado
    ///
    /// As versões estabilizadas desse intrínseco estão disponíveis nas primitivas inteiras por meio do método `overflowing_sub`.
    /// Por exemplo,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Executa multiplicação de inteiros verificados
    ///
    /// As versões estabilizadas desse intrínseco estão disponíveis nas primitivas inteiras por meio do método `overflowing_mul`.
    /// Por exemplo,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Executa uma divisão exata, resultando em comportamento indefinido onde `x % y != 0` ou `y == 0` ou `x == T::MIN && y == -1`
    ///
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Executa uma divisão não verificada, resultando em comportamento indefinido onde `y == 0` ou `x == T::MIN && y == -1`
    ///
    ///
    /// Wrappers seguros para este intrínseco estão disponíveis nas primitivas inteiras por meio do método `checked_div`.
    /// Por exemplo,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Retorna o restante de uma divisão não verificada, resultando em comportamento indefinido quando `y == 0` ou `x == T::MIN && y == -1`
    ///
    ///
    /// Wrappers seguros para este intrínseco estão disponíveis nas primitivas inteiras por meio do método `checked_rem`.
    /// Por exemplo,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Executa um deslocamento à esquerda não verificado, resultando em um comportamento indefinido quando `y < 0` ou `y >= N`, onde N é a largura de T em bits.
    ///
    ///
    /// Wrappers seguros para este intrínseco estão disponíveis nas primitivas inteiras por meio do método `checked_shl`.
    /// Por exemplo,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Executa um deslocamento para a direita não verificado, resultando em um comportamento indefinido quando `y < 0` ou `y >= N`, onde N é a largura de T em bits.
    ///
    ///
    /// Wrappers seguros para este intrínseco estão disponíveis nas primitivas inteiras por meio do método `checked_shr`.
    /// Por exemplo,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Retorna o resultado de uma adição não verificada, resultando em comportamento indefinido quando `x + y > T::MAX` ou `x + y < T::MIN`.
    ///
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Retorna o resultado de uma subtração não verificada, resultando em comportamento indefinido quando `x - y > T::MAX` ou `x - y < T::MIN`.
    ///
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Retorna o resultado de uma multiplicação não verificada, resultando em comportamento indefinido quando `x *y > T::MAX` ou `x* y < T::MIN`.
    ///
    ///
    /// Este intrínseco não tem uma contrapartida estável.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Executa a rotação para a esquerda.
    ///
    /// As versões estabilizadas desse intrínseco estão disponíveis nas primitivas inteiras por meio do método `rotate_left`.
    /// Por exemplo,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Executa a rotação para a direita.
    ///
    /// As versões estabilizadas desse intrínseco estão disponíveis nas primitivas inteiras por meio do método `rotate_right`.
    /// Por exemplo,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Retorna (a + b) mod 2 <sup>N</sup>, onde N é a largura de T em bits.
    ///
    /// As versões estabilizadas desse intrínseco estão disponíveis nas primitivas inteiras por meio do método `wrapping_add`.
    /// Por exemplo,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Retorna (a, b) mod 2 <sup>N</sup>, onde N é a largura de T em bits.
    ///
    /// As versões estabilizadas desse intrínseco estão disponíveis nas primitivas inteiras por meio do método `wrapping_sub`.
    /// Por exemplo,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Retorna (a * b) mod 2 <sup>N</sup>, onde N é a largura de T em bits.
    ///
    /// As versões estabilizadas desse intrínseco estão disponíveis nas primitivas inteiras por meio do método `wrapping_mul`.
    /// Por exemplo,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Calcula `a + b`, saturando em limites numéricos.
    ///
    /// As versões estabilizadas desse intrínseco estão disponíveis nas primitivas inteiras por meio do método `saturating_add`.
    /// Por exemplo,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Calcula `a - b`, saturando em limites numéricos.
    ///
    /// As versões estabilizadas desse intrínseco estão disponíveis nas primitivas inteiras por meio do método `saturating_sub`.
    /// Por exemplo,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Retorna o valor do discriminante para a variante em 'v';
    /// se `T` não tiver discriminante, retorna `0`.
    ///
    /// A versão estabilizada desse intrínseco é o [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Retorna o número de variantes do tipo `T` convertido em um `usize`;
    /// se `T` não tiver variantes, retorna `0`.Variantes desabitadas serão contadas.
    ///
    /// A versão a ser estabilizada desse intrínseco é o [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// A construção "try catch" de Rust que invoca o ponteiro de função `try_fn` com o ponteiro de dados `data`.
    ///
    /// O terceiro argumento é uma função chamada se ocorrer um panic.
    /// Esta função usa o ponteiro de dados e um ponteiro para o objeto de exceção específico do destino que foi capturado.
    ///
    /// Para obter mais informações, consulte o código-fonte do compilador, bem como a implementação de captura de std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Emite um armazenamento `!nontemporal` de acordo com LLVM (veja seus documentos).
    /// Provavelmente nunca ficará estável.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Consulte a documentação do `<*const T>::offset_from` para obter detalhes.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Consulte a documentação do `<*const T>::guaranteed_eq` para obter detalhes.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Consulte a documentação do `<*const T>::guaranteed_ne` para obter detalhes.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Alocar em tempo de compilação.Não deve ser chamado em tempo de execução.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Algumas funções são definidas aqui porque foram acidentalmente disponibilizadas neste módulo no stable.
// Consulte <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` também se enquadra nesta categoria, mas não pode ser agrupado devido à verificação de que `T` e `U` têm o mesmo tamanho.)
//

/// Verifica se o `ptr` está alinhado corretamente em relação ao `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Copia bytes `count *size_of::<T>()` de `src` para `dst`.A origem e o destino* não * devem se sobrepor.
///
/// Para regiões de memória que podem se sobrepor, use o [`copy`].
///
/// `copy_nonoverlapping` é semanticamente equivalente ao [`memcpy`] do C, mas com a ordem dos argumentos trocada.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// O comportamento é indefinido se qualquer uma das seguintes condições for violada:
///
/// * `src` deve ser [valid] para leituras de bytes `count * size_of::<T>()`.
///
/// * `dst` deve ser [valid] para gravações de bytes `count * size_of::<T>()`.
///
/// * Tanto o `src` quanto o `dst` devem ser alinhados corretamente.
///
/// * A região da memória começando em `src` com um tamanho de `contagem *
///   tamanho de: :<T>() `bytes *não* devem se sobrepor à região da memória começando em `dst` com o mesmo tamanho.
///
/// Como o [`read`], o `copy_nonoverlapping` cria uma cópia bit a bit do `T`, independentemente de `T` ser [`Copy`].
/// Se `T` não for [`Copy`], usar *ambos* os valores na região começando em `*src` e a região começando em `* dst` pode [violate memory safety][read-ownership].
///
///
/// Observe que mesmo se o tamanho efetivamente copiado (`contagem * size_of: :<T>()`) é `0`, os ponteiros devem ser diferentes de NULL e estar devidamente alinhados.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Implemente o [`Vec::append`] manualmente:
///
/// ```
/// use std::ptr;
///
/// /// Move todos os elementos do `src` para o `dst`, deixando o `src` vazio.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Certifique-se de que o `dst` tenha capacidade suficiente para conter todo o `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // A chamada para o deslocamento é sempre segura porque o `Vec` nunca alocará mais de `isize::MAX` bytes.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Trunque o `src` sem eliminar seu conteúdo.
///         // Fazemos isso primeiro, para evitar problemas no caso de algo mais abaixo do panics.
///         src.set_len(0);
///
///         // As duas regiões não podem se sobrepor porque as referências mutáveis não têm alias e dois vectors diferentes não podem possuir a mesma memória.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Notifique o `dst` que agora ele contém o conteúdo do `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Execute essas verificações apenas em tempo de execução
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Não entre em pânico para manter o impacto do codegen menor.
        abort();
    }*/

    // SEGURANÇA: o contrato de segurança para `copy_nonoverlapping` deve ser
    // confirmado pelo chamador.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Copia bytes `count * size_of::<T>()` de `src` para `dst`.A origem e o destino podem se sobrepor.
///
/// Se a origem e o destino *nunca* se sobreporem, o [`copy_nonoverlapping`] pode ser usado em seu lugar.
///
/// `copy` é semanticamente equivalente ao [`memmove`] do C, mas com a ordem dos argumentos trocada.
/// A cópia ocorre como se os bytes tivessem sido copiados do `src` para um array temporário e depois copiados do array para o `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// O comportamento é indefinido se qualquer uma das seguintes condições for violada:
///
/// * `src` deve ser [valid] para leituras de bytes `count * size_of::<T>()`.
///
/// * `dst` deve ser [valid] para gravações de bytes `count * size_of::<T>()`.
///
/// * Tanto o `src` quanto o `dst` devem ser alinhados corretamente.
///
/// Como o [`read`], o `copy` cria uma cópia bit a bit do `T`, independentemente de `T` ser [`Copy`].
/// Se `T` não for [`Copy`], usar os valores na região começando em `*src` e na região começando em `* dst` pode [violate memory safety][read-ownership].
///
///
/// Observe que mesmo se o tamanho efetivamente copiado (`contagem * size_of: :<T>()`) é `0`, os ponteiros devem ser diferentes de NULL e estar devidamente alinhados.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Crie com eficiência um Rust vector a partir de um buffer não seguro:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` deve estar alinhado corretamente para seu tipo e diferente de zero.
/// /// * `ptr` deve ser válido para leituras de elementos contíguos `elts` do tipo `T`.
/// /// * Esses elementos não devem ser usados após chamar esta função, a menos que `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // SEGURANÇA: Nossa pré-condição garante que a fonte esteja alinhada e válida,
///     // e o `Vec::with_capacity` garante que temos espaço utilizável para gravá-los.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // SEGURANÇA: Nós o criamos com tanta capacidade antes,
///     // e o `copy` anterior inicializou esses elementos.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Execute essas verificações apenas em tempo de execução
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Não entre em pânico para manter o impacto do codegen menor.
        abort();
    }*/

    // SEGURANÇA: o contrato de segurança para o `copy` deve ser respeitado pelo chamador.
    unsafe { copy(src, dst, count) }
}

/// Define bytes de memória `count * size_of::<T>()` começando em `dst` a `val`.
///
/// `write_bytes` é semelhante ao [`memset`] do C, mas define bytes `count * size_of::<T>()` para `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// O comportamento é indefinido se qualquer uma das seguintes condições for violada:
///
/// * `dst` deve ser [valid] para gravações de bytes `count * size_of::<T>()`.
///
/// * `dst` deve estar devidamente alinhado.
///
/// Além disso, o chamador deve garantir que a gravação de bytes `count * size_of::<T>()` em uma determinada região da memória resulte em um valor válido de `T`.
/// Usar uma região da memória digitada como `T` que contém um valor inválido de `T` é um comportamento indefinido.
///
/// Observe que mesmo se o tamanho efetivamente copiado (`contagem * size_of: :<T>()`) é `0`, o ponteiro não deve ser NULL e deve estar alinhado corretamente.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Criação de um valor inválido:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Vazamentos do valor anteriormente mantido sobrescrevendo o `Box<T>` com um ponteiro nulo.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Nesse ponto, usar ou descartar o `v` resulta em um comportamento indefinido.
/// // drop(v); // ERROR
///
/// // Mesmo vazando `v` "uses" isso, e, portanto, é um comportamento indefinido.
/// // mem::forget(v); // ERROR
///
/// // Na verdade, `v` é inválido de acordo com as invariáveis de layout de tipo básico, portanto,*qualquer* operação que toque nele é um comportamento indefinido.
/////
/// // deixe v2 =v;//ERROR
///
/// unsafe {
///     // Em vez disso, vamos colocar um valor válido
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Agora a caixa esta bem
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // SEGURANÇA: o contrato de segurança para o `write_bytes` deve ser respeitado pelo chamador.
    unsafe { write_bytes(dst, val, count) }
}