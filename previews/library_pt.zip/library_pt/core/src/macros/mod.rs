#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Expande-se para `$crate::panic::panic_2015` ou `$crate::panic::panic_2021`, dependendo da edição do chamador.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Afirma que duas expressões são iguais (usando [`PartialEq`]).
///
/// Em panic, esta macro imprimirá os valores das expressões com suas representações de depuração.
///
///
/// Como o [`assert!`], esta macro tem um segundo formulário, onde uma mensagem panic personalizada pode ser fornecida.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Os reborrows abaixo são intencionais.
                    // Sem eles, o slot de pilha para o empréstimo é inicializado mesmo antes de os valores serem comparados, levando a uma desaceleração perceptível.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Os reborrows abaixo são intencionais.
                    // Sem eles, o slot de pilha para o empréstimo é inicializado mesmo antes de os valores serem comparados, levando a uma desaceleração perceptível.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Afirma que duas expressões não são iguais (usando [`PartialEq`]).
///
/// Em panic, esta macro imprimirá os valores das expressões com suas representações de depuração.
///
///
/// Como o [`assert!`], esta macro tem um segundo formulário, onde uma mensagem panic personalizada pode ser fornecida.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Os reborrows abaixo são intencionais.
                    // Sem eles, o slot de pilha para o empréstimo é inicializado mesmo antes de os valores serem comparados, levando a uma desaceleração perceptível.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Os reborrows abaixo são intencionais.
                    // Sem eles, o slot de pilha para o empréstimo é inicializado mesmo antes de os valores serem comparados, levando a uma desaceleração perceptível.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Afirma que uma expressão booleana é `true` em tempo de execução.
///
/// Isso invocará a macro [`panic!`] se a expressão fornecida não puder ser avaliada para `true` no tempo de execução.
///
/// Como o [`assert!`], esta macro também tem uma segunda versão, onde uma mensagem panic personalizada pode ser fornecida.
///
/// # Uses
///
/// Ao contrário do [`assert!`], as instruções `debug_assert!` são ativadas apenas em compilações não otimizadas por padrão.
/// Uma construção otimizada não executará instruções `debug_assert!` a menos que `-C debug-assertions` seja passado para o compilador.
/// Isso torna o `debug_assert!` útil para verificações que são muito caras para estar presentes em um build de lançamento, mas podem ser úteis durante o desenvolvimento.
/// O resultado da expansão do `debug_assert!` é sempre verificado por tipo.
///
/// Uma asserção não verificada permite que um programa em um estado inconsistente continue em execução, o que pode ter consequências inesperadas, mas não apresenta insegurança, desde que isso aconteça apenas em código seguro.
///
/// O custo de desempenho das afirmações, no entanto, não é mensurável em geral.
/// Substituir o [`assert!`] pelo `debug_assert!` é, portanto, apenas encorajado após um perfil completo e, mais importante, apenas em código seguro!
///
/// # Examples
///
/// ```
/// // a mensagem panic para essas afirmações é o valor stringificado da expressão fornecida.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // uma função muito simples
/// debug_assert!(some_expensive_computation());
///
/// // afirmar com uma mensagem personalizada
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Afirma que duas expressões são iguais uma à outra.
///
/// Em panic, esta macro imprimirá os valores das expressões com suas representações de depuração.
///
/// Ao contrário do [`assert_eq!`], as instruções `debug_assert_eq!` são ativadas apenas em compilações não otimizadas por padrão.
/// Uma construção otimizada não executará instruções `debug_assert_eq!` a menos que `-C debug-assertions` seja passado para o compilador.
/// Isso torna o `debug_assert_eq!` útil para verificações que são muito caras para estar presentes em um build de lançamento, mas podem ser úteis durante o desenvolvimento.
///
/// O resultado da expansão do `debug_assert_eq!` é sempre verificado por tipo.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Afirma que duas expressões não são iguais.
///
/// Em panic, esta macro imprimirá os valores das expressões com suas representações de depuração.
///
/// Ao contrário do [`assert_ne!`], as instruções `debug_assert_ne!` são ativadas apenas em compilações não otimizadas por padrão.
/// Uma construção otimizada não executará instruções `debug_assert_ne!` a menos que `-C debug-assertions` seja passado para o compilador.
/// Isso torna o `debug_assert_ne!` útil para verificações que são muito caras para estar presentes em uma versão de lançamento, mas podem ser úteis durante o desenvolvimento.
///
/// O resultado da expansão do `debug_assert_ne!` é sempre verificado por tipo.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Retorna se a expressão fornecida corresponde a qualquer um dos padrões fornecidos.
///
/// Como em uma expressão `match`, o padrão pode ser seguido opcionalmente por `if` e uma expressão de guarda que tem acesso a nomes vinculados ao padrão.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Desfaz um resultado ou propaga seu erro.
///
/// O operador `?` foi adicionado para substituir o `try!` e deve ser usado em seu lugar.
/// Além disso, `try` é uma palavra reservada no Rust 2018, portanto, se for necessário usá-la, você precisará usar o [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` corresponde ao [`Result`] fornecido.No caso da variante `Ok`, a expressão possui o valor do valor empacotado.
///
/// No caso da variante `Err`, ele recupera o erro interno.O `try!` então realiza a conversão usando o `From`.
/// Isso fornece conversão automática entre erros especializados e erros mais gerais.
/// O erro resultante é retornado imediatamente.
///
/// Por causa do retorno antecipado, o `try!` só pode ser usado em funções que retornam o [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // O método preferido de retorno rápido de erros
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // O método anterior de retorno rápido de erros
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Isso é equivalente a:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Grava dados formatados em um buffer.
///
/// Esta macro aceita um 'writer', uma string de formato e uma lista de argumentos.
/// Os argumentos serão formatados de acordo com a string de formato especificada e o resultado será passado para o redator.
/// O gravador pode ser qualquer valor com um método `write_fmt`;geralmente isso vem de uma implementação do [`fmt::Write`] ou do [`io::Write`] trait.
/// A macro retorna tudo o que o método `write_fmt` retorna;comumente um [`fmt::Result`] ou um [`io::Result`].
///
/// Consulte [`std::fmt`] para obter mais informações sobre a sintaxe da string de formato.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Um módulo pode importar `std::fmt::Write` e `std::io::Write` e chamar `write!` em objetos que implementam qualquer um, já que os objetos normalmente não implementam ambos.
///
/// No entanto, o módulo deve importar o traits qualificado para que seus nomes não entrem em conflito:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // usa fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // usa io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Esta macro também pode ser usada nas configurações do `no_std`.
/// Em uma configuração `no_std`, você é responsável pelos detalhes de implementação dos componentes.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Grave dados formatados em um buffer, com uma nova linha acrescentada.
///
/// Em todas as plataformas, a nova linha é o caractere LINE FEED (`\n`/`U+000A`) sozinho (sem CARRIAGE RETURN (`\r`/`U+000D`) adicional.
///
/// Para obter mais informações, consulte [`write!`].Para obter informações sobre a sintaxe da string de formato, consulte [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Um módulo pode importar `std::fmt::Write` e `std::io::Write` e chamar `write!` em objetos que implementam qualquer um, já que os objetos normalmente não implementam ambos.
/// No entanto, o módulo deve importar o traits qualificado para que seus nomes não entrem em conflito:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // usa fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // usa io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Indica código inacessível.
///
/// Isso é útil sempre que o compilador não consegue determinar que algum código está inacessível.Por exemplo:
///
/// * Combine os braços com as condições de guarda.
/// * Loops que terminam dinamicamente.
/// * Iteradores que terminam dinamicamente.
///
/// Se a determinação de que o código está inacessível for incorreta, o programa termina imediatamente com um [`panic!`].
///
/// A contraparte insegura dessa macro é a função [`unreachable_unchecked`], que causará um comportamento indefinido se o código for alcançado.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Isso sempre será [`panic!`].
///
/// # Examples
///
/// Combinar os braços:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // erro de compilação se comentado
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // uma das implementações mais pobres de x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Indica código não implementado entrando em pânico com uma mensagem de "not implemented".
///
/// Isso permite que seu código verifique o tipo, o que é útil se você estiver criando um protótipo ou implementando um trait que requer vários métodos que você não planeja usar todos.
///
/// A diferença entre o `unimplemented!` e o [`todo!`] é que, embora o `todo!` transmita a intenção de implementar a funcionalidade posteriormente e a mensagem seja o "not yet implemented", o `unimplemented!` não faz essas afirmações.
/// Sua mensagem é "not implemented".
/// Além disso, alguns IDEs marcarão `todo!` S.
///
/// # Panics
///
/// Será sempre [`panic!`] porque `unimplemented!` é apenas uma abreviação de `panic!` com uma mensagem fixa e específica.
///
/// Como o `panic!`, esta macro tem um segundo formulário para exibir valores personalizados.
///
/// # Examples
///
/// Digamos que temos um trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Queremos implementar `Foo` para 'MyStruct', mas por algum motivo, só faz sentido implementar a função `bar()`.
/// `baz()` e `qux()` ainda precisará ser definido em nossa implementação de `Foo`, mas podemos usar `unimplemented!` em suas definições para permitir que nosso código seja compilado.
///
/// Ainda queremos que nosso programa pare de funcionar se os métodos não implementados forem alcançados.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Não faz sentido `baz` a `MyStruct`, então não temos nenhuma lógica aqui.
/////
///         // Isso exibirá "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Temos alguma lógica aqui, podemos adicionar uma mensagem ao não implementado!para mostrar nossa omissão.
///         // Isso exibirá: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Indica código inacabado.
///
/// Isso pode ser útil se você estiver fazendo um protótipo e apenas procurando uma verificação de tipo de código.
///
/// A diferença entre o [`unimplemented!`] e o `todo!` é que, embora o `todo!` transmita a intenção de implementar a funcionalidade posteriormente e a mensagem seja o "not yet implemented", o `unimplemented!` não faz essas afirmações.
/// Sua mensagem é "not implemented".
/// Além disso, alguns IDEs marcarão `todo!` S.
///
/// # Panics
///
/// Isso sempre será [`panic!`].
///
/// # Examples
///
/// Aqui está um exemplo de algum código em andamento.Temos um trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Queremos implementar o `Foo` em um de nossos tipos, mas também queremos trabalhar apenas no `bar()` primeiro.Para que nosso código seja compilado, precisamos implementar `baz()`, para que possamos usar `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // implementação vai aqui
///     }
///
///     fn baz(&self) {
///         // não vamos nos preocupar com a implementação do baz() por enquanto
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // nem mesmo estamos usando o baz(), então tudo bem.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Definições de macros integradas.
///
/// A maioria das propriedades da macro (estabilidade, visibilidade, etc.) são obtidas do código-fonte aqui, com exceção das funções de expansão que transformam as entradas da macro em saídas, essas funções são fornecidas pelo compilador.
///
///
pub(crate) mod builtin {

    /// Faz com que a compilação falhe com a mensagem de erro fornecida quando encontrada.
    ///
    /// Esta macro deve ser usada quando um crate usa uma estratégia de compilação condicional para fornecer melhores mensagens de erro para condições errôneas.
    ///
    /// É a forma de nível de compilador do [`panic!`], mas emite um erro durante a *compilação* em vez de no *tempo de execução*.
    ///
    /// # Examples
    ///
    /// Dois desses exemplos são macros e ambientes `#[cfg]`.
    ///
    /// Emite melhor erro do compilador se uma macro receber valores inválidos.
    /// Sem o branch final, o compilador ainda emitiria um erro, mas a mensagem de erro não mencionaria os dois valores válidos.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Emita um erro do compilador se um dos vários recursos não estiver disponível.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Constrói parâmetros para as outras macros de formatação de string.
    ///
    /// Esta macro funciona tomando um literal de string de formatação contendo `{}` para cada argumento adicional passado.
    /// `format_args!` prepara os parâmetros adicionais para garantir que a saída possa ser interpretada como uma string e canoniza os argumentos em um único tipo.
    /// Qualquer valor que implemente o [`Display`] trait pode ser passado para o `format_args!`, assim como qualquer implementação do [`Debug`] pode ser passada para um `{:?}` dentro da string de formatação.
    ///
    ///
    /// Esta macro produz um valor do tipo [`fmt::Arguments`].Este valor pode ser passado para as macros no [`std::fmt`] para realizar um redirecionamento útil.
    /// Todas as outras macros de formatação ([`format!`], [`write!`], [`println!`], etc) são representadas por proxy por meio desta.
    /// `format_args!`, ao contrário de suas macros derivadas, evita alocações de heap.
    ///
    /// Você pode usar o valor [`fmt::Arguments`] que `format_args!` retorna nos contextos `Debug` e `Display`, conforme mostrado abaixo.
    /// O exemplo também mostra que o formato `Debug` e `Display` são a mesma coisa: a string de formato interpolada em `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Para obter mais informações, consulte a documentação do [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// O mesmo que o `format_args`, mas adiciona uma nova linha no final.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Inspeciona uma variável de ambiente em tempo de compilação.
    ///
    /// Essa macro se expandirá para o valor da variável de ambiente nomeada no tempo de compilação, produzindo uma expressão do tipo `&'static str`.
    ///
    ///
    /// Se a variável de ambiente não for definida, um erro de compilação será emitido.
    /// Para não emitir um erro de compilação, use a macro [`option_env!`].
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Você pode personalizar a mensagem de erro passando uma string como o segundo parâmetro:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Se a variável de ambiente `documentation` não for definida, você receberá o seguinte erro:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Opcionalmente, inspeciona uma variável de ambiente em tempo de compilação.
    ///
    /// Se a variável de ambiente nomeada estiver presente no tempo de compilação, isso se expandirá em uma expressão do tipo `Option<&'static str>` cujo valor é `Some` do valor da variável de ambiente.
    /// Se a variável de ambiente não estiver presente, isso se expandirá para `None`.
    /// Consulte [`Option<T>`][Option] para obter mais informações sobre este tipo.
    ///
    /// Um erro de tempo de compilação nunca é emitido ao usar essa macro, independentemente se a variável de ambiente está presente ou não.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatena identificadores em um identificador.
    ///
    /// Essa macro pega qualquer número de identificadores separados por vírgula e os concatena em um, produzindo uma expressão que é um novo identificador.
    /// Observe que a higiene faz com que essa macro não possa capturar variáveis locais.
    /// Além disso, como regra geral, as macros só são permitidas na posição do item, instrução ou expressão.
    /// Isso significa que embora você possa usar esta macro para se referir a variáveis, funções ou módulos existentes, etc., você não pode definir um novo com ela.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (novo, divertido, nome) { }//não pode ser usado desta forma!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatena literais em uma fatia de string estática.
    ///
    /// Essa macro aceita qualquer número de literais separados por vírgula, produzindo uma expressão do tipo `&'static str` que representa todos os literais concatenados da esquerda para a direita.
    ///
    ///
    /// Literais inteiros e de ponto flutuante são sequenciados para serem concatenados.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Expande-se para o número da linha em que foi invocado.
    ///
    /// Com o [`column!`] e o [`file!`], essas macros fornecem informações de depuração para desenvolvedores sobre a localização na fonte.
    ///
    /// A expressão expandida tem o tipo `u32` e é baseada em 1, portanto, a primeira linha em cada arquivo é avaliada como 1, a segunda como 2, etc.
    /// Isso é consistente com mensagens de erro de compiladores comuns ou editores populares.
    /// A linha retornada *não é necessariamente* a linha da própria chamada do `line!`, mas sim a primeira chamada da macro que conduz à chamada da macro `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Expande-se para o número da coluna em que foi invocado.
    ///
    /// Com o [`line!`] e o [`file!`], essas macros fornecem informações de depuração para desenvolvedores sobre a localização na fonte.
    ///
    /// A expressão expandida tem o tipo `u32` e é baseada em 1, portanto, a primeira coluna em cada linha é avaliada como 1, a segunda como 2, etc.
    /// Isso é consistente com mensagens de erro de compiladores comuns ou editores populares.
    /// A coluna retornada *não necessariamente* é a linha da própria chamada do `column!`, mas sim a primeira chamada da macro que conduz à chamada da macro `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Expande-se para o nome do arquivo no qual foi chamado.
    ///
    /// Com o [`line!`] e o [`column!`], essas macros fornecem informações de depuração para desenvolvedores sobre a localização na fonte.
    ///
    /// A expressão expandida tem o tipo `&'static str` e o arquivo retornado não é a invocação da macro `file!` em si, mas a primeira invocação da macro que leva à invocação da macro `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stringifica seus argumentos.
    ///
    /// Essa macro produzirá uma expressão do tipo `&'static str` que é a estringificação de todos os tokens passados para a macro.
    /// Nenhuma restrição é colocada na sintaxe da própria chamada da macro.
    ///
    /// Observe que os resultados expandidos da entrada tokens podem mudar no future.Você deve ter cuidado ao confiar na saída.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Inclui um arquivo codificado UTF-8 como uma string.
    ///
    /// O arquivo está localizado em relação ao arquivo atual (de forma semelhante à forma como os módulos são encontrados).
    /// O caminho fornecido é interpretado de uma maneira específica da plataforma em tempo de compilação.
    /// Portanto, por exemplo, uma chamada com um caminho Windows contendo barras invertidas `\` não compilaria corretamente no Unix.
    ///
    ///
    /// Esta macro produzirá uma expressão do tipo `&'static str` que é o conteúdo do arquivo.
    ///
    /// # Examples
    ///
    /// Suponha que haja dois arquivos no mesmo diretório com o seguinte conteúdo:
    ///
    /// Arquivo 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Arquivo 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Compilar 'main.rs' e executar o binário resultante imprimirá "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Inclui um arquivo como referência a uma matriz de bytes.
    ///
    /// O arquivo está localizado em relação ao arquivo atual (de forma semelhante à forma como os módulos são encontrados).
    /// O caminho fornecido é interpretado de uma maneira específica da plataforma em tempo de compilação.
    /// Portanto, por exemplo, uma chamada com um caminho Windows contendo barras invertidas `\` não compilaria corretamente no Unix.
    ///
    ///
    /// Esta macro produzirá uma expressão do tipo `&'static [u8; N]` que é o conteúdo do arquivo.
    ///
    /// # Examples
    ///
    /// Suponha que haja dois arquivos no mesmo diretório com o seguinte conteúdo:
    ///
    /// Arquivo 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Arquivo 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Compilar 'main.rs' e executar o binário resultante imprimirá "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Expande-se para uma string que representa o caminho do módulo atual.
    ///
    /// O caminho do módulo atual pode ser considerado como a hierarquia de módulos que leva de volta ao crate root.
    /// O primeiro componente do caminho retornado é o nome do crate que está sendo compilado no momento.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Avalia combinações booleanas de sinalizadores de configuração em tempo de compilação.
    ///
    /// Além do atributo `#[cfg]`, esta macro é fornecida para permitir a avaliação da expressão booleana dos sinalizadores de configuração.
    /// Isso freqüentemente leva a menos código duplicado.
    ///
    /// A sintaxe fornecida a esta macro é a mesma sintaxe do atributo [`cfg`].
    ///
    /// `cfg!`, ao contrário do `#[cfg]`, não remove nenhum código e só é avaliado como verdadeiro ou falso.
    /// Por exemplo, todos os blocos em uma expressão if/else precisam ser válidos quando `cfg!` é usado para a condição, independentemente do que `cfg!` está avaliando.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Analisa um arquivo como uma expressão ou um item de acordo com o contexto.
    ///
    /// O arquivo está localizado em relação ao arquivo atual (de forma semelhante à forma como os módulos são encontrados).O caminho fornecido é interpretado de uma maneira específica da plataforma em tempo de compilação.
    /// Portanto, por exemplo, uma chamada com um caminho Windows contendo barras invertidas `\` não compilaria corretamente no Unix.
    ///
    /// Usar essa macro costuma ser uma má ideia, porque se o arquivo for analisado como uma expressão, ele será colocado no código ao redor de forma anti-higiênica.
    /// Isso pode resultar em variáveis ou funções diferentes do que o arquivo esperava, se houver variáveis ou funções com o mesmo nome no arquivo atual.
    ///
    ///
    /// # Examples
    ///
    /// Suponha que haja dois arquivos no mesmo diretório com o seguinte conteúdo:
    ///
    /// Arquivo 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Arquivo 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Compilar 'main.rs' e executar o binário resultante imprimirá "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Afirma que uma expressão booleana é `true` em tempo de execução.
    ///
    /// Isso invocará a macro [`panic!`] se a expressão fornecida não puder ser avaliada para `true` no tempo de execução.
    ///
    /// # Uses
    ///
    /// As asserções são sempre verificadas nas compilações de depuração e liberação e não podem ser desabilitadas.
    /// Consulte [`debug_assert!`] para ver as afirmações que não são habilitadas nas compilações por padrão.
    ///
    /// O código inseguro pode contar com o `assert!` para impor invariáveis de tempo de execução que, se violadas, podem levar à insegurança.
    ///
    /// Outros casos de uso do `assert!` incluem testar e impor invariáveis de tempo de execução em código seguro (cuja violação não pode resultar em insegurança).
    ///
    ///
    /// # Mensagens Personalizadas
    ///
    /// Esta macro tem um segundo formato, onde uma mensagem panic personalizada pode ser fornecida com ou sem argumentos para formatação.
    /// Consulte [`std::fmt`] para obter a sintaxe deste formulário.
    /// As expressões usadas como argumentos de formato só serão avaliadas se a asserção falhar.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // a mensagem panic para essas afirmações é o valor stringificado da expressão fornecida.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // uma função muito simples
    ///
    /// assert!(some_computation());
    ///
    /// // afirmar com uma mensagem personalizada
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Montagem embutida.
    ///
    /// Leia o [unstable book] para o uso.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Montagem embutida no estilo LLVM.
    ///
    /// Leia o [unstable book] para o uso.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Montagem embutida de nível de módulo.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// As impressões passaram tokens para a saída padrão.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Habilita ou desabilita a funcionalidade de rastreamento usada para depurar outras macros.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Macro de atributo usado para aplicar macros derivadas.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Macro de atributo aplicado a uma função para transformá-la em um teste de unidade.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Macro de atributo aplicado a uma função para transformá-la em um teste de benchmark.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Um detalhe de implementação das macros `#[test]` e `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Macro de atributo aplicada a um estático para registrá-lo como um alocador global.
    ///
    /// Consulte também [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Mantém o item ao qual está aplicado se o caminho passado estiver acessível e remove-o caso contrário.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Expande todos os atributos `#[cfg]` e `#[cfg_attr]` no fragmento de código ao qual é aplicado.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Detalhe de implementação instável do compilador `rustc`, não use.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Detalhe de implementação instável do compilador `rustc`, não use.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}