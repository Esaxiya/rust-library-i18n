Panics o segmento atual.

Isso permite que um programa seja encerrado imediatamente e forneça feedback ao chamador do programa.
`panic!` deve ser usado quando um programa atinge um estado irrecuperável.

Essa macro é a maneira perfeita de declarar condições em códigos de exemplo e em testes.
`panic!` está intimamente ligado ao método `unwrap` de enums [`Option`][ounwrap] e [`Result`][runwrap].
Ambas as implementações chamam `panic!` quando são definidas para variantes [`None`] ou [`Err`].

Ao usar o `panic!()`, você pode especificar uma carga útil da string, que é construída usando a sintaxe [`format!`].
Essa carga útil é usada ao injetar o panic no encadeamento Rust de chamada, fazendo com que o encadeamento seja panic inteiramente.

O comportamento do padrão `std` hook, ou seja,
o código que é executado diretamente depois que o panic é invocado, é para imprimir a carga útil da mensagem para o `stderr` junto com as informações do file/line/column da chamada `panic!()`.

Você pode substituir o panic hook usando [`std::panic::set_hook()`].
Dentro do hook, um panic pode ser acessado como um `&dyn Any + Send`, que contém um `&str` ou `String` para invocações `panic!()` regulares.
Para panic com um valor de outro tipo, [`panic_any`] pode ser usado.

[`Result`] enum geralmente é uma solução melhor para a recuperação de erros do que usar a macro `panic!`.
Esta macro deve ser usada para evitar o uso de valores incorretos, como de fontes externas.
Informações detalhadas sobre o tratamento de erros podem ser encontradas no [book].

Consulte também a macro [`compile_error!`], para levantar erros durante a compilação.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Implementação atual

Se o thread principal panics, ele encerrará todos os seus threads e finalizará seu programa com o código `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





