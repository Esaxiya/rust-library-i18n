//! Suporte Panic para libcore
//!
//! A biblioteca central não pode definir pânico, mas *declara* pânico.
//! Isso significa que as funções dentro da libcore são permitidas para panic, mas para ser útil, um crate upstream deve definir pânico para que a libcore use.
//! A interface atual para pânico é:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Esta definição permite entrar em pânico com qualquer mensagem geral, mas não permite falha com um valor `Box<Any>`.
//! (`PanicInfo` contém apenas um `&(dyn Any + Send)`, para o qual preenchemos um valor fictício em `PanicInfo: : internal_constructor`.) A razão para isso é que libcore não tem permissão para alocar.
//!
//!
//! Este módulo contém algumas outras funções de pânico, mas essas são apenas os itens de linguagem necessários para o compilador.Todos os panics são canalizados por meio desta função.
//! O símbolo real é declarado por meio do atributo `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// A implementação subjacente da macro `panic!` da libcore quando nenhuma formatação é usada.
#[cold]
// nunca inline, a menos que panic_immediate_abort para evitar o inchaço do código nos sites de chamada, tanto quanto possível
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // necessário para codegen para panic em overflow e outros terminadores `Assert` MIR
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Use Arguments::new_v1 em vez de format_args! ("{}", Expr) para reduzir potencialmente a sobrecarga de tamanho.
    // O format_args!A macro usa Display trait de str para escrever expr, que chama Formatter::pad, que deve acomodar o truncamento e o preenchimento da string (embora nenhum seja usado aqui).
    //
    // Usar o Arguments::new_v1 pode permitir que o compilador omita o Formatter::pad do binário de saída, economizando até alguns kilobytes.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // necessário para panics avaliado por const
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // necessário para codegen para panic no acesso OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// A implementação subjacente da macro `panic!` da libcore durante a formatação é usada.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // NOTA Esta função nunca cruza o limite FFI;é uma chamada Rust-a-Rust que é resolvida para a função `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // SEGURANÇA: `panic_impl` é definido no código Rust seguro e, portanto, é seguro para chamadas.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Função interna para macros `assert_eq!` e `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}