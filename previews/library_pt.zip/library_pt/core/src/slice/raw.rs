//! Funções gratuitas para criar `&[T]` e `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Forma uma fatia de um ponteiro e um comprimento.
///
/// O argumento `len` é o número de **elementos**, não o número de bytes.
///
/// # Safety
///
/// O comportamento é indefinido se qualquer uma das seguintes condições for violada:
///
/// * `data` deve ser [valid] para leituras de muitos bytes `len * mem::size_of::<T>()` e deve estar devidamente alinhado.Isso significa em particular:
///
///     * Todo o intervalo de memória desta fatia deve estar contido em um único objeto alocado!
///       As fatias nunca podem se estender por vários objetos alocados.Consulte [below](#incorrect-usage) para obter um exemplo incorreto, sem levar isso em consideração.
///     * `data` deve ser não nulo e alinhado mesmo para fatias de comprimento zero.
///     Um motivo para isso é que as otimizações de layout enum podem contar com referências (incluindo fatias de qualquer comprimento) alinhadas e não nulas para distingui-las de outros dados.
///     Você pode obter um ponteiro que pode ser usado como `data` para fatias de comprimento zero usando [`NonNull::dangling()`].
///
/// * `data` deve apontar para valores consecutivos adequadamente inicializados de `len` do tipo `T`.
///
/// * A memória referenciada pela fatia retornada não deve sofrer mutação durante a vida útil do `'a`, exceto dentro de um `UnsafeCell`.
///
/// * O tamanho total `len * mem::size_of::<T>()` da fatia não deve ser maior que `isize::MAX`.
///   Consulte a documentação de segurança do [`pointer::offset`].
///
/// # Caveat
///
/// O tempo de vida da fatia retornada é inferido de seu uso.
/// Para evitar o uso indevido acidental, sugere-se vincular o tempo de vida a qualquer tempo de vida de origem que seja seguro no contexto, como fornecendo uma função auxiliar que leva o tempo de vida de um valor de host para a fatia ou por anotação explícita.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // manifestar uma fatia para um único elemento
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Uso incorreto
///
/// A seguinte função `join_slices` é **inadequada** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // A afirmação acima garante que `fst` e `snd` sejam contíguos, mas eles ainda podem estar contidos no _different allocated objects_, caso em que a criação dessa fatia é um comportamento indefinido.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` e `b` são diferentes objetos alocados ...
///     let a = 42;
///     let b = 27;
///     // ... que pode, no entanto, ser representado de forma contígua na memória: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SEGURANÇA: o chamador deve respeitar o contrato de segurança do `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Desempenha a mesma funcionalidade que o [`from_raw_parts`], exceto que uma fatia mutável é retornada.
///
/// # Safety
///
/// O comportamento é indefinido se qualquer uma das seguintes condições for violada:
///
/// * `data` deve ser [valid] para leituras e gravações de muitos bytes `len * mem::size_of::<T>()` e deve estar alinhado corretamente.Isso significa em particular:
///
///     * Todo o intervalo de memória desta fatia deve estar contido em um único objeto alocado!
///       As fatias nunca podem se estender por vários objetos alocados.
///     * `data` deve ser não nulo e alinhado mesmo para fatias de comprimento zero.
///     Um motivo para isso é que as otimizações de layout enum podem contar com referências (incluindo fatias de qualquer comprimento) alinhadas e não nulas para distingui-las de outros dados.
///
///     Você pode obter um ponteiro que pode ser usado como `data` para fatias de comprimento zero usando [`NonNull::dangling()`].
///
/// * `data` deve apontar para valores consecutivos adequadamente inicializados de `len` do tipo `T`.
///
/// * A memória referenciada pela fatia retornada não deve ser acessada por meio de nenhum outro ponteiro (não derivado do valor de retorno) durante a vida útil do `'a`.
///   Os acessos de leitura e gravação são proibidos.
///
/// * O tamanho total `len * mem::size_of::<T>()` da fatia não deve ser maior que `isize::MAX`.
///   Consulte a documentação de segurança do [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SEGURANÇA: o chamador deve respeitar o contrato de segurança do `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Converte uma referência a T em uma fatia de comprimento 1 (sem copiar).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Converte uma referência a T em uma fatia de comprimento 1 (sem copiar).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}