// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Gira o intervalo `[mid-left, mid+right)` de forma que o elemento em `mid` se torne o primeiro elemento.Equivalentemente, gira os elementos do intervalo `left` para a esquerda ou os elementos `right` para a direita.
///
/// # Safety
///
/// O intervalo especificado deve ser válido para leitura e gravação.
///
/// # Algorithm
///
/// O algoritmo 1 é usado para pequenos valores de `left + right` ou para grandes `T`.
/// Os elementos são movidos para suas posições finais, um de cada vez, começando em `mid - left` e avançando pelos passos `right` módulo `left + right`, de forma que apenas um temporário seja necessário.
/// Eventualmente, chegamos de volta ao `mid - left`.
/// No entanto, se `gcd(left + right, right)` não for 1, as etapas acima ignoraram os elementos.
/// Por exemplo:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Felizmente, o número de elementos ignorados entre os elementos finalizados é sempre igual, então podemos apenas deslocar nossa posição inicial e fazer mais voltas (o número total de voltas é o `gcd(left + right, right)` value).
///
/// O resultado final é que todos os elementos são finalizados uma vez e apenas uma vez.
///
/// O algoritmo 2 é usado se o `left + right` for grande, mas o `min(left, right)` for pequeno o suficiente para caber em um buffer de pilha.
/// Os elementos do `min(left, right)` são copiados no buffer, o `memmove` é aplicado aos outros e os que estão no buffer são movidos de volta para o orifício no lado oposto de onde foram originados.
///
/// Algoritmos que podem ser vetorizados superam o desempenho acima, uma vez que o `left + right` se torna grande o suficiente.
/// O algoritmo 1 pode ser vetorizado dividindo e executando muitas rodadas de uma vez, mas existem poucas rodadas em média até que `left + right` seja enorme, e o pior caso de uma única rodada está sempre lá.
/// Em vez disso, o algoritmo 3 utiliza a troca repetida de elementos `min(left, right)` até que um problema de rotação menor seja deixado.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// quando o `left < right`, a troca ocorre da esquerda.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. os algoritmos abaixo podem falhar se esses casos não forem verificados
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Os microbenchmarks do Algoritmo 1 indicam que o desempenho médio para mudanças aleatórias é melhor até cerca de `left + right == 32`, mas o desempenho do pior caso ainda fica por volta de 16.
            // 24 foi escolhido como meio termo.
            // Se o tamanho do `T` for maior que 4 `usize`s, este algoritmo também supera outros algoritmos.
            //
            //
            let x = unsafe { mid.sub(left) };
            // começo da primeira rodada
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` pode ser encontrado de antemão calculando `gcd(left + right, right)`, mas é mais rápido fazer um loop que calcula o mdc como um efeito colateral, então fazer o resto do pedaço
            //
            //
            let mut gcd = right;
            // benchmarks revelam que é mais rápido trocar temporários por todo o caminho em vez de ler um temporário uma vez, copiar para trás e escrever aquele temporário bem no final.
            // Isso possivelmente se deve ao fato de que a troca ou substituição de temporários usa apenas um endereço de memória no loop em vez de precisar gerenciar dois.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // em vez de incrementar o `i` e depois verificar se está fora dos limites, verificamos se o `i` sairá dos limites no próximo incremento.
                // Isso evita qualquer quebra de ponteiros ou `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // fim da primeira rodada
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // esta condicional deve estar aqui se `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // termine o pedaço com mais rodadas
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` não é um tipo de tamanho zero, portanto, não há problema em dividir por seu tamanho.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algoritmo 2 O `[T; 0]` aqui é para garantir que ele esteja devidamente alinhado para T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algoritmo 3 Existe uma maneira alternativa de trocar que envolve descobrir onde seria a última troca desse algoritmo, e trocar usando esse último trecho em vez de trocar trechos adjacentes como este algoritmo está fazendo, mas dessa forma ainda é mais rápida.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algoritmo 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}