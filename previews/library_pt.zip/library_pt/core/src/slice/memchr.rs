// Implementação original retirada de rust-memchr.
// Copyright 2015 Andrew Gallant, bluss e Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Use truncamento.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Retorna `true` se `x` contiver qualquer byte zero.
///
/// De *Matters Computational*, J. Arndt:
///
/// "A ideia é subtrair um de cada um dos bytes e, em seguida, procurar os bytes onde o empréstimo se propagou até o mais significativo
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Retorna o primeiro índice que corresponde ao byte `x` em `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Caminho rápido para pequenas fatias
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Procure um valor de byte único lendo duas palavras `usize` de cada vez.
    //
    // Divida o `text` em três partes
    // - parte inicial não alinhada, antes da primeira palavra alinhada endereço no texto
    // - corpo, escaneie por 2 palavras por vez
    // - a última parte restante, <2 tamanho de palavra

    // pesquise até um limite alinhado
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // pesquise o corpo do texto
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // SEGURANÇA: o predicado do while garante uma distância de pelo menos 2 * usize_bytes
        // entre o deslocamento e o final da fatia.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // quebrar se houver um byte correspondente
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Encontre o byte após o ponto em que o loop do corpo parou.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Retorna o último índice correspondente ao byte `x` em `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Procure um valor de byte único lendo duas palavras `usize` de cada vez.
    //
    // Divida o `text` em três partes:
    // - cauda não alinhada, após a última palavra alinhada endereço no texto,
    // - corpo, lido por 2 palavras de cada vez,
    // - os primeiros bytes restantes, <2 tamanho de palavra.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Chamamos isso apenas para obter o comprimento do prefixo e do sufixo.
        // No meio, sempre processamos dois blocos de uma vez.
        // SEGURANÇA: transmutar `[u8]` em `[usize]` é seguro, exceto para diferenças de tamanho que são tratadas pelo `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Pesquise o corpo do texto, certifique-se de não cruzar min_aligned_offset.
    // o deslocamento está sempre alinhado, portanto, apenas testar o `>` é suficiente e evita possível estouro.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // SEGURANÇA: o deslocamento começa em len, suffix.len(), contanto que seja maior que
        // min_aligned_offset (prefix.len()) a distância restante é de pelo menos 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Quebre se houver um byte correspondente.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Encontre o byte antes do ponto em que o loop do corpo parou.
    text[..offset].iter().rposition(|elt| *elt == x)
}