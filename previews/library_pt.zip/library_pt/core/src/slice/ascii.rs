//! Operações em ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Verifica se todos os bytes nesta fatia estão dentro do intervalo ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Verifica se duas fatias são uma correspondência ASCII insensível a maiúsculas e minúsculas.
    ///
    /// Igual ao `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, mas sem alocar e copiar temporários.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Converte esta fatia em seu equivalente em maiúsculas ASCII no local.
    ///
    /// As letras ASCII 'a' a 'z' são mapeadas para 'A' a 'Z', mas as letras não ASCII permanecem inalteradas.
    ///
    /// Para retornar um novo valor em maiúsculas sem modificar o existente, use o [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Converte esta fatia em seu equivalente em minúsculas ASCII no local.
    ///
    /// As letras ASCII 'A' a 'Z' são mapeadas para 'a' a 'z', mas as letras não ASCII permanecem inalteradas.
    ///
    /// Para retornar um novo valor em minúsculas sem modificar o existente, use [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Retorna `true` se qualquer byte na palavra `v` for nonascii (>=128).
/// Snarfed do `../str/mod.rs`, que faz algo semelhante para a validação do utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Teste ASCII otimizado que usará operações de uso por vez em vez de operações de byte por vez (quando possível).
///
/// O algoritmo que usamos aqui é muito simples.Se o `s` for muito curto, basta verificar cada byte e terminar com ele.Por outro lado:
///
/// - Leia a primeira palavra com uma carga desalinhada.
/// - Alinhe o ponteiro, leia as palavras subsequentes até o final com as cargas alinhadas.
/// - Leia o último `usize` do `s` com uma carga desalinhada.
///
/// Se alguma dessas cargas produzir algo para o qual o `contains_nonascii` (above) retorne verdadeiro, então sabemos que a resposta é falsa.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Se não ganharmos nada com a implementação palavra por vez, volte para um loop escalar.
    //
    // Também fazemos isso para arquiteturas onde o `size_of::<usize>()` não é alinhamento suficiente para o `usize`, porque é um gabinete edge estranho.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Sempre lemos a primeira palavra desalinhada, o que significa que `align_offset` é
    // 0, leríamos o mesmo valor novamente para a leitura alinhada.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // SEGURANÇA: Verificamos o `len < USIZE_SIZE` acima.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Verificamos isso acima, um tanto implicitamente.
    // Observe que `offset_to_aligned` é `align_offset` ou `USIZE_SIZE`, ambos explicitamente verificados acima.
    //
    debug_assert!(offset_to_aligned <= len);

    // SEGURANÇA: word_ptr é o (corretamente alinhado) usize ptr que usamos para ler o
    // pedaço médio da fatia.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` é o índice de bytes de `word_ptr`, usado para verificações de fim de loop.
    let mut byte_pos = offset_to_aligned;

    // Paranóia, verifique o alinhamento, já que estamos prestes a fazer um monte de cargas desalinhadas.
    // Na prática, isso deveria ser impossível, exceto por um bug no `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Leia as palavras subsequentes até a última palavra alinhada, excluindo a última palavra alinhada por si só para verificar a cauda posteriormente, para garantir que a cauda seja sempre um `usize` no máximo a branch `byte_pos == len` extra.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Verifique se a leitura está dentro dos limites
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // E que nossas suposições sobre o `byte_pos` são válidas.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // SEGURANÇA: Sabemos que o `word_ptr` está devidamente alinhado (devido ao
        // `align_offset`), e sabemos que temos bytes suficientes entre o `word_ptr` e o fim
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SEGURANÇA: sabemos que `byte_pos <= len - USIZE_SIZE`, o que significa que
        // após este `add`, o `word_ptr` terá no máximo um ultrapassado.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Verificação de integridade para garantir que realmente resta apenas um `usize`.
    // Isso deve ser garantido por nossa condição de loop.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SEGURANÇA: Isso depende do `len >= USIZE_SIZE`, que verificamos no início.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}