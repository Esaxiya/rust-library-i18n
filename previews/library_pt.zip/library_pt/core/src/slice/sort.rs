//! Classificação de fatias
//!
//! Este módulo contém um algoritmo de classificação baseado no quicksort de derrota de padrões de Orson Peters, publicado em: <https://github.com/orlp/pdqsort>
//!
//!
//! A classificação instável é compatível com libcore porque não aloca memória, ao contrário de nossa implementação de classificação estável.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Quando descartado, copia do `src` para o `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // SEGURANÇA: Esta é uma classe auxiliar.
        //          Por favor, consulte seu uso para correção.
        //          Ou seja, deve-se ter certeza de que `src` e `dst` não se sobrepõem conforme exigido pelo `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Desloca o primeiro elemento para a direita até encontrar um elemento maior ou igual.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SEGURANÇA: As operações inseguras abaixo envolvem indexação sem uma verificação de limite (`get_unchecked` e `get_unchecked_mut`)
    // e cópia de memória (`ptr::copy_nonoverlapping`).
    //
    // uma.Indexando:
    //  1. Verificamos o tamanho da matriz para>=2.
    //  2. Toda a indexação que faremos é sempre entre {0 <= index < len} no máximo.
    //
    // b.Cópia de memória
    //  1. Estamos obtendo indicadores para referências que são garantidamente válidas.
    //  2. Eles não podem se sobrepor porque obtemos indicadores para os índices de diferença da fatia.
    //     Ou seja, `i` e `i-1`.
    //  3. Se a fatia estiver alinhada corretamente, os elementos estão alinhados corretamente.
    //     É responsabilidade do chamador verificar se a fatia está devidamente alinhada.
    //
    // Veja os comentários abaixo para mais detalhes.
    unsafe {
        // Se os primeiros dois elementos estiverem fora de ordem ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Leia o primeiro elemento em uma variável alocada na pilha.
            // Se uma operação de comparação for panics, o `hole` será descartado e gravará automaticamente o elemento de volta na fatia.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Mova o elemento `i`-th um lugar para a esquerda, deslocando assim o furo para a direita.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` é descartado e, portanto, copia o `tmp` no orifício restante do `v`.
        }
    }
}

/// Desloca o último elemento para a esquerda até encontrar um elemento menor ou igual.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SEGURANÇA: As operações inseguras abaixo envolvem indexação sem uma verificação de limite (`get_unchecked` e `get_unchecked_mut`)
    // e cópia de memória (`ptr::copy_nonoverlapping`).
    //
    // uma.Indexando:
    //  1. Verificamos o tamanho do array para>=2.
    //  2. Toda a indexação que faremos é sempre entre `0 <= index < len-1` no máximo.
    //
    // b.Cópia de memória
    //  1. Estamos obtendo indicadores para referências que são garantidamente válidas.
    //  2. Eles não podem se sobrepor porque obtemos indicadores para os índices de diferença da fatia.
    //     Ou seja, `i` e `i+1`.
    //  3. Se a fatia estiver alinhada corretamente, os elementos estão alinhados corretamente.
    //     É responsabilidade do chamador verificar se a fatia está devidamente alinhada.
    //
    // Veja os comentários abaixo para mais detalhes.
    unsafe {
        // Se os dois últimos elementos estiverem fora de ordem ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Leia o último elemento em uma variável alocada na pilha.
            // Se uma operação de comparação for panics, o `hole` será descartado e gravará automaticamente o elemento de volta na fatia.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Mova o elemento `i`-th um lugar para a direita, deslocando o orifício para a esquerda.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` é descartado e, portanto, copia o `tmp` no orifício restante do `v`.
        }
    }
}

/// Classifica parcialmente uma fatia deslocando vários elementos fora de ordem.
///
/// Retorna `true` se a fatia for classificada no final.Esta função é *O*(*n*) de pior caso.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Número máximo de pares adjacentes fora de ordem que serão deslocados.
    const MAX_STEPS: usize = 5;
    // Se a fatia for menor do que isso, não mude nenhum elemento.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // SEGURANÇA: Já fizemos explicitamente a verificação de limite com o `i < len`.
        // Toda a nossa indexação subsequente está apenas na faixa `0 <= index < len`
        unsafe {
            // Encontre o próximo par de elementos adjacentes fora de ordem.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Nós terminamos?
        if i == len {
            return true;
        }

        // Não mude elementos em matrizes curtas, isso tem um custo de desempenho.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Troque o par de elementos encontrado.Isso os coloca na ordem correta.
        v.swap(i - 1, i);

        // Desloque o elemento menor para a esquerda.
        shift_tail(&mut v[..i], is_less);
        // Mude o elemento maior para a direita.
        shift_head(&mut v[i..], is_less);
    }

    // Não conseguiu classificar a fatia no número limitado de etapas.
    false
}

/// Classifica uma fatia usando a classificação por inserção, que é o pior caso *O*(*n*^ 2).
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Classifica o `v` usando o heapsort, que garante *O*(*n*\*o pior caso do log(* n*)).
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Este heap binário respeita o invariante `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Filhos do `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Escolha o filho maior.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Pare se o invariante se mantiver em `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Troque o `node` pelo filho maior, desça um degrau e continue peneirando.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Construa a pilha em tempo linear.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Retire os elementos máximos da pilha.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Particiona `v` em elementos menores que `pivot`, seguidos por elementos maiores ou iguais a `pivot`.
///
///
/// Retorna o número de elementos menores que `pivot`.
///
/// O particionamento é executado bloco a bloco para minimizar o custo das operações de ramificação.
/// Essa ideia é apresentada no artigo [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Número de elementos em um bloco típico.
    const BLOCK: usize = 128;

    // O algoritmo de particionamento repete as seguintes etapas até a conclusão:
    //
    // 1. Trace um bloco do lado esquerdo para identificar os elementos maiores ou iguais ao pivô.
    // 2. Trace um bloco do lado direito para identificar os elementos menores que o pivô.
    // 3. Troque os elementos identificados entre os lados esquerdo e direito.
    //
    // Mantemos as seguintes variáveis para um bloco de elementos:
    //
    // 1. `block` - Número de elementos no bloco.
    // 2. `start` - Comece o ponteiro no array `offsets`.
    // 3. `end` - Ponteiro final na matriz `offsets`.
    // 4. `offsets, índices de elementos fora de ordem dentro do bloco.

    // O bloco atual no lado esquerdo (de `l` a `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // O bloco atual no lado direito (de `r.sub(block_r)` to `r`).
    // SEGURANÇA: A documentação do .add() menciona especificamente que o `vec.as_ptr().add(vec.len())` é sempre seguro.
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Quando obtivermos VLAs, tente criar uma matriz de comprimento `min(v.len(), 2 * BLOCK) `em vez
    // do que duas matrizes de tamanho fixo de comprimento `BLOCK`.Os VLAs podem ser mais eficientes em cache.

    // Retorna o número de elementos entre os ponteiros `l` (inclusive) e `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Terminamos o particionamento bloco a bloco quando o `l` e o `r` se aproximam.
        // Em seguida, fazemos alguns remendos para particionar os elementos restantes entre eles.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Número de elementos restantes (ainda não comparado ao pivô).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Ajuste os tamanhos dos blocos para que os blocos esquerdo e direito não se sobreponham, mas fiquem perfeitamente alinhados para cobrir toda a lacuna restante.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Rastreie os elementos do `block_l` do lado esquerdo.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // SEGURANÇA: As operações inseguras abaixo envolvem o uso do `offset`.
                //         De acordo com as condições exigidas pela função, nós as satisfazemos porque:
                //         1. `offsets_l` é alocado em pilha e, portanto, considerado um objeto alocado separado.
                //         2. A função `is_less` retorna um `bool`.
                //            Lançar um `bool` nunca irá sobrecarregar o `isize`.
                //         3. Garantimos que o `block_l` será o `<= BLOCK`.
                //            Além disso, o `end_l` foi inicialmente definido como o ponteiro inicial do `offsets_`, que foi declarado na pilha.
                //            Assim, sabemos que mesmo no pior caso (todas as invocações de `is_less` retornam falso), teremos no máximo 1 byte no final.
                //        Outra operação insegura aqui é desreferenciar o `elem`.
                //        No entanto, o `elem` foi inicialmente o ponteiro inicial para a fatia, que é sempre válido.
                unsafe {
                    // Comparação sem ramificações.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Rastreie os elementos `block_r` do lado direito.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // SEGURANÇA: As operações inseguras abaixo envolvem o uso do `offset`.
                //         De acordo com as condições exigidas pela função, nós as satisfazemos porque:
                //         1. `offsets_r` é alocado em pilha e, portanto, considerado um objeto alocado separado.
                //         2. A função `is_less` retorna um `bool`.
                //            Lançar um `bool` nunca irá sobrecarregar o `isize`.
                //         3. Garantimos que o `block_r` será o `<= BLOCK`.
                //            Além disso, o `end_r` foi inicialmente definido como o ponteiro inicial do `offsets_`, que foi declarado na pilha.
                //            Assim, sabemos que mesmo no pior caso (todas as invocações de `is_less` retornam verdadeiras), teremos no máximo 1 byte no final.
                //        Outra operação insegura aqui é desreferenciar o `elem`.
                //        No entanto, o `elem` foi inicialmente `1 *sizeof(T)` além do fim e nós o diminuímos em `1* sizeof(T)` antes de acessá-lo.
                //        Além disso, `block_r` foi declarado ser menor que `BLOCK` e `elem`, portanto, no máximo apontará para o início da fatia.
                unsafe {
                    // Comparação sem ramificações.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Número de elementos fora de ordem para trocar entre os lados esquerdo e direito.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Em vez de trocar um par de cada vez, é mais eficiente realizar uma permutação cíclica.
            // Isso não é estritamente equivalente à troca, mas produz um resultado semelhante usando menos operações de memória.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Todos os elementos fora de ordem no bloco esquerdo foram movidos.Passe para o próximo bloco.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Todos os elementos fora de ordem no bloco direito foram movidos.Vá para o bloco anterior.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Tudo o que resta agora é no máximo um bloco (à esquerda ou à direita) com elementos fora de ordem que precisam ser movidos.
    // Esses elementos restantes podem ser simplesmente deslocados para o final dentro de seu bloco.
    //

    if start_l < end_l {
        // O bloco esquerdo permanece.
        // Mova seus elementos fora de ordem restantes para a extrema direita.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // O bloco certo permanece.
        // Mova seus elementos fora de ordem restantes para a extrema esquerda.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Nada mais a fazer, terminamos.
        width(v.as_mut_ptr(), l)
    }
}

/// Particiona `v` em elementos menores que `v[pivot]`, seguidos por elementos maiores ou iguais a `v[pivot]`.
///
///
/// Retorna uma tupla de:
///
/// 1. Número de elementos menores que `v[pivot]`.
/// 2. Verdadeiro se o `v` já tiver sido particionado.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Coloque o pivô no início da fatia.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Leia o pivô em uma variável alocada na pilha para obter eficiência.
        // Se uma operação de comparação for panics, o pivô será automaticamente gravado de volta na fatia.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Encontre o primeiro par de elementos fora de ordem.
        let mut l = 0;
        let mut r = v.len();

        // SEGURANÇA: A insegurança abaixo envolve a indexação de uma matriz.
        // Para o primeiro: Já fazemos a verificação dos limites aqui com o `l < r`.
        // Para o segundo: inicialmente temos o `l == 0` e o `r == v.len()` e verificamos esse `l < r` em cada operação de indexação.
        //                     A partir daqui sabemos que `r` deve ser pelo menos `r == l` que se mostrou válido desde o primeiro.
        unsafe {
            // Encontre o primeiro elemento maior ou igual ao pivô.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Encontre o último elemento menor que o pivô.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` sai do escopo e grava o pivô (que é uma variável alocada na pilha) de volta na fatia onde estava originalmente.
        // Esta etapa é crítica para garantir a segurança!
        //
    };

    // Coloque o pivô entre as duas partições.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Particiona `v` em elementos iguais a `v[pivot]` seguidos por elementos maiores que `v[pivot]`.
///
/// Retorna o número de elementos igual ao pivô.
/// Presume-se que o `v` não contém elementos menores que o pivô.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Coloque o pivô no início da fatia.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Leia o pivô em uma variável alocada na pilha para obter eficiência.
    // Se uma operação de comparação for panics, o pivô será automaticamente gravado de volta na fatia.
    // SEGURANÇA: O ponteiro aqui é válido porque é obtido a partir de uma referência a uma fatia.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Agora divida a fatia.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // SEGURANÇA: A insegurança abaixo envolve a indexação de uma matriz.
        // Para o primeiro: Já fazemos a verificação dos limites aqui com o `l < r`.
        // Para o segundo: inicialmente temos o `l == 0` e o `r == v.len()` e verificamos esse `l < r` em cada operação de indexação.
        //                     A partir daqui sabemos que `r` deve ser pelo menos `r == l` que se mostrou válido desde o primeiro.
        unsafe {
            // Encontre o primeiro elemento maior que o pivô.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Encontre o último elemento igual ao pivô.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Nós terminamos?
            if l >= r {
                break;
            }

            // Troque o par encontrado de elementos fora de ordem.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Encontramos elementos `l` iguais ao pivô.Adicione 1 para contabilizar o próprio pivô.
    l + 1

    // `_pivot_guard` sai do escopo e grava o pivô (que é uma variável alocada na pilha) de volta na fatia onde estava originalmente.
    // Esta etapa é crítica para garantir a segurança!
}

/// Espalha alguns elementos na tentativa de quebrar padrões que podem causar partições desequilibradas na classificação rápida.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Gerador de números pseudoaleatórios do artigo "Xorshift RNGs" de George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Pegue números aleatórios modulo este número.
        // O número se encaixa em `usize` porque `len` não é maior que `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Alguns candidatos de pivô estarão próximos a este índice.Vamos randomizá-los.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Gere um módulo de número aleatório `len`.
            // No entanto, para evitar operações caras, primeiro consideramos módulo uma potência de dois e, em seguida, diminuímos em `len` até que se encaixe no intervalo `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` tem garantia de ser menor que `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Escolhe um pivô em `v` e retorna o índice e `true` se a fatia provavelmente já estiver classificada.
///
/// Os elementos no `v` podem ser reordenados no processo.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Comprimento mínimo para escolher o método das medianas das medianas.
    // Fatias mais curtas usam o método simples de mediana de três.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Número máximo de trocas que podem ser realizadas nesta função.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Três índices próximos dos quais vamos escolher um pivô.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Conta o número total de trocas que estamos prestes a realizar enquanto classifica os índices.
    let mut swaps = 0;

    if len >= 8 {
        // Troca índices para que `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Troca índices para que `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Encontra a mediana de `v[a - 1], v[a], v[a + 1]` e armazena o índice em `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Encontre medianas nas vizinhanças de `a`, `b` e `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Encontre a mediana entre `a`, `b` e `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // O número máximo de trocas foi realizado.
        // Provavelmente, a fatia está descendo ou principalmente descendo, portanto, a reversão provavelmente ajudará a classificá-la mais rapidamente.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Classifica `v` recursivamente.
///
/// Se a fatia tiver um predecessor na matriz original, ela será especificada como `pred`.
///
/// `limit` é o número de partições desequilibradas permitidas antes de alternar para o `heapsort`.
/// Se for zero, esta função mudará imediatamente para heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Fatias de até esse comprimento são classificadas usando a classificação por inserção.
    const MAX_INSERTION: usize = 20;

    // Verdadeiro se o último particionamento foi razoavelmente balanceado.
    let mut was_balanced = true;
    // Verdadeiro se o último particionamento não embaralhou elementos (a fatia já estava particionada).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Fatias muito curtas são classificadas usando a classificação por inserção.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Se muitas escolhas erradas de pivô forem feitas, basta recorrer ao heapsort para garantir o pior caso do `O(n * log(n))`.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Se a última partição foi desequilibrada, tente quebrar os padrões na fatia misturando alguns elementos.
        // Esperamos escolher um pivô melhor desta vez.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Escolha um pivô e tente adivinhar se a fatia já está classificada.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Se o último particionamento foi decentemente balanceado e não misturou elementos, e se a seleção dinâmica prediz a fatia provavelmente já está classificada ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Tente identificar vários elementos fora de ordem e deslocá-los para as posições corretas.
            // Se a fatia acabar completamente classificada, estamos prontos.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Se o pivô escolhido for igual ao predecessor, será o menor elemento da fatia.
        // Particione a fatia em elementos iguais e maiores que o pivô.
        // Este caso é geralmente atingido quando a fatia contém muitos elementos duplicados.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Continue classificando os elementos maiores que o pivô.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Divida a fatia.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Divida a fatia em `left`, `pivot` e `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Recurso para o lado mais curto apenas para minimizar o número total de chamadas recursivas e consumir menos espaço de pilha.
        // Em seguida, continue com o lado mais longo (isso é semelhante à recursão da cauda).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Classifica o `v` usando o quicksort de eliminação de padrões, que é *O*(*n*\*o pior caso do log(* n*)).
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // A classificação não tem comportamento significativo em tipos de tamanho zero.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Limite o número de partições desequilibradas a `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Para fatias de até esse comprimento, é provavelmente mais rápido simplesmente classificá-las.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Escolha um pivô
        let (pivot, _) = choose_pivot(v, is_less);

        // Se o pivô escolhido for igual ao predecessor, será o menor elemento da fatia.
        // Particione a fatia em elementos iguais e maiores que o pivô.
        // Este caso é geralmente atingido quando a fatia contém muitos elementos duplicados.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Se tivermos passado em nosso índice, estamos bem.
                if mid > index {
                    return;
                }

                // Caso contrário, continue classificando os elementos maiores que o pivô.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Divida a fatia em `left`, `pivot` e `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Se mid==index, então terminou, pois partition() garantiu que todos os elementos após mid são maiores ou iguais a mid.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // A classificação não tem comportamento significativo em tipos de tamanho zero.Fazer nada.
    } else if index == v.len() - 1 {
        // Encontre o elemento max e coloque-o na última posição do array.
        // Temos a liberdade de usar o `unwrap()` aqui porque sabemos que v não deve estar vazio.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Encontre o elemento min e coloque-o na primeira posição da matriz.
        // Temos a liberdade de usar o `unwrap()` aqui porque sabemos que v não deve estar vazio.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}