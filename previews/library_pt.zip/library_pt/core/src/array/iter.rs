//! Define o iterador pertencente ao `IntoIter` para matrizes.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Um iterador [array] por valor.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Esta é a matriz sobre a qual estamos iterando.
    ///
    /// Elementos com índice `i` onde `alive.start <= i < alive.end` ainda não foi gerado e são entradas de array válidas.
    /// Elementos com índices `i < alive.start` ou `i >= alive.end` já foram produzidos e não devem mais ser acessados!Esses elementos mortos podem até estar em um estado completamente não inicializado!
    ///
    ///
    /// Portanto, os invariantes são:
    /// - `data[alive]` está ativo (ou seja, contém elementos válidos)
    /// - `data[..alive.start]` e `data[alive.end..]` estão mortos (ou seja, os elementos já foram lidos e não devem ser mais tocados!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Os elementos no `data` que ainda não foram produzidos.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Cria um novo iterador sobre o `array` fornecido.
    ///
    /// *Nota*: este método pode ser descontinuado no future, após o [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // O tipo de `value` é um `i32` aqui, em vez de `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SEGURANÇA: O transmutar aqui é realmente seguro.Os documentos do `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` tem a garantia de ter o mesmo tamanho e alinhamento
        // > como `T`.
        //
        // Os documentos mostram até mesmo uma transmutação de um array de `MaybeUninit<T>` para um array de `T`.
        //
        //
        // Com isso, essa inicialização satisfaz os invariantes.

        // FIXME(LukasKalbertodt): use `mem::transmute` aqui, uma vez que funciona com genéricos const:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Até então, podemos usar o `mem::transmute_copy` para criar uma cópia bit a bit como um tipo diferente e, em seguida, esquecer o `array` para que não seja descartado.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Retorna uma fatia imutável de todos os elementos que ainda não foram produzidos.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // SEGURANÇA: sabemos que todos os elementos do `alive` foram inicializados corretamente.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Retorna uma fatia mutável de todos os elementos que ainda não foram produzidos.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // SEGURANÇA: sabemos que todos os elementos do `alive` foram inicializados corretamente.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Obtenha o próximo índice da frente.
        //
        // Aumentar o `alive.start` em 1 mantém a invariável em relação ao `alive`.
        // Porém, devido a essa mudança, por um curto período, a zona viva não é mais `data[alive]`, mas `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Leia o elemento da matriz.
            // SEGURANÇA: `idx` é um índice para a antiga região "alive" da
            // variedade.Ler este elemento significa que o `data[idx]` é considerado morto agora (ou seja, não toque).
            // Como o `idx` foi o início da zona ativa, a zona ativa agora é `data[alive]` novamente, restaurando todas as invariáveis.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Obtenha o próximo índice na parte de trás.
        //
        // Diminuir o `alive.end` em 1 mantém a invariável em relação ao `alive`.
        // Porém, devido a essa mudança, por um curto período, a zona viva não é mais `data[alive]`, mas `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Leia o elemento da matriz.
            // SEGURANÇA: `idx` é um índice para a antiga região "alive" da
            // variedade.Ler este elemento significa que o `data[idx]` é considerado morto agora (ou seja, não toque).
            // Como o `idx` era o fim da zona ativa, a zona ativa agora é `data[alive]` novamente, restaurando todas as invariáveis.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SEGURANÇA: Isto é seguro: o `as_mut_slice` retorna exatamente a sub-fatia
        // de elementos que ainda não foram removidos e que ainda não foram removidos.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Nunca irá underflow devido ao invariante `alive.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// O iterador de fato relata o comprimento correto.
// O número de elementos "alive" (que ainda serão produzidos) é o comprimento do intervalo `alive`.
// Este intervalo é diminuído em comprimento em `next` ou `next_back`.
// É sempre diminuído em 1 nesses métodos, mas apenas se `Some(_)` for retornado.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Observe que realmente não precisamos corresponder exatamente ao mesmo intervalo ativo, portanto, podemos apenas clonar no deslocamento 0, independentemente de onde o `self` está.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Clone todos os elementos vivos.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Grave um clone na nova matriz e atualize seu intervalo ativo.
            // Se clonar panics, removeremos corretamente os itens anteriores.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Imprime apenas os elementos que ainda não foram cedidos: não podemos mais acessar os elementos cedidos.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}