//! O `Clone` trait para tipos que não podem ser 'copiados implicitamente'.
//!
//! No Rust, alguns tipos simples são "implicitly copyable" e quando você os atribui ou os passa como argumentos, o receptor obterá uma cópia, deixando o valor original no lugar.
//! Esses tipos não requerem alocação para copiar e não têm finalizadores (ou seja, eles não contêm caixas próprias ou implementam [`Drop`]), portanto, o compilador os considera baratos e seguros para copiar.
//!
//! Para outros tipos, as cópias devem ser feitas explicitamente, por convenção implementando o [`Clone`] trait e chamando o método [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Exemplo de uso básico:
//!
//! ```
//! let s = String::new(); // Tipo de string implementa Clone
//! let copy = s.clone(); // para que possamos cloná-lo
//! ```
//!
//! Para implementar facilmente o Clone trait, você também pode usar o `#[derive(Clone)]`.Exemplo:
//!
//! ```
//! #[derive(Clone)] // adicionamos o clone trait à estrutura de Morpheus
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // e agora podemos cloná-lo!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Um trait comum para a capacidade de duplicar explicitamente um objeto.
///
/// Difere do [`Copy`] porque o [`Copy`] é implícito e extremamente barato, enquanto o `Clone` é sempre explícito e pode ou não ser caro.
/// Para reforçar essas características, Rust não permite que você reimplemente o [`Copy`], mas você pode reimplementar o `Clone` e executar código arbitrário.
///
/// Como o `Clone` é mais geral do que o [`Copy`], você também pode fazer com que qualquer [`Copy`] seja `Clone` automaticamente.
///
/// ## Derivable
///
/// Este trait pode ser usado com `#[derive]` se todos os campos forem `Clone`.A implementação `derive`d de [`Clone`] chama [`clone`] em cada campo.
///
/// [`clone`]: Clone::clone
///
/// Para uma estrutura genérica, o `#[derive]` implementa o `Clone` condicionalmente, adicionando o `Clone` vinculado aos parâmetros genéricos.
///
/// ```
/// // `derive` implementa Clone para Leitura<T>quando T é Clone.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Como posso implementar o `Clone`?
///
/// Os tipos que são [`Copy`] devem ter uma implementação trivial de `Clone`.Mais formalmente:
/// se `T: Copy`, `x: T` e `y: &T`, então `let x = y.clone();` é equivalente a `let x = *y;`.
/// As implementações manuais devem ter o cuidado de manter essa invariante;entretanto, o código não seguro não deve depender dele para garantir a segurança da memória.
///
/// Um exemplo é uma estrutura genérica que contém um ponteiro de função.Nesse caso, a implementação do `Clone` não pode ser `derivar`d, mas pode ser implementada como:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Implementadores adicionais
///
/// Além do [implementors listed below][impls], os seguintes tipos também implementam o `Clone`:
///
/// * Tipos de item de função (ou seja, os tipos distintos definidos para cada função)
/// * Tipos de ponteiro de função (por exemplo, `fn() -> i32`)
/// * Tipos de matriz, para todos os tamanhos, se o tipo de item também implementa `Clone` (por exemplo, `[i32; 123456]`)
/// * Tipos de tupla, se cada componente também implementa `Clone` (por exemplo, `()`, `(i32, bool)`)
/// * Tipos de fechamento, se eles não capturarem nenhum valor do ambiente ou se todos esses valores capturados implementarem `Clone`.
///   Observe que as variáveis capturadas por referência compartilhada sempre implementam `Clone` (mesmo se o referente não), enquanto variáveis capturadas por referência mutável nunca implementam `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Retorna uma cópia do valor.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str implementa clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Executa a atribuição de cópias do `source`.
    ///
    /// `a.clone_from(&b)` é equivalente ao `a = b.clone()` em funcionalidade, mas pode ser substituído para reutilizar os recursos do `a` para evitar alocações desnecessárias.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Derive macro gerando um impl do trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): essas estruturas são usadas exclusivamente por#[derivar] para afirmar que cada componente de um tipo implementa Clone ou Copiar.
//
//
// Essas estruturas nunca devem aparecer no código do usuário.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Implementações de `Clone` para tipos primitivos.
///
/// Implementações que não podem ser descritas em Rust são implementadas em `traits::SelectionContext::copy_clone_conditions()` em `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// As referências compartilhadas podem ser clonadas, mas as referências mutáveis *não*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// As referências compartilhadas podem ser clonadas, mas as referências mutáveis *não*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}