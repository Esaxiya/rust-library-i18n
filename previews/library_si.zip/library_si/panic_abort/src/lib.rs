//! ක්‍රියාවලි අත්හිටුවීම් හරහා Rust panics ක්‍රියාත්මක කිරීම
//!
//! නොදැනුවත්වම ක්‍රියාත්මක කිරීම හා සසඳන විට, මෙම crate * වඩා සරලයි!එසේ පැවසුවහොත් එය එතරම් බහුකාර්ය නොවේ, නමුත් මෙහි යයි!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" සැක සහිත වේදිකාවේ අදාළ ගබ්සා කිරීම සඳහා ගෙවීම සහ දිලිසීම.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // std::sys::abort_internal අමතන්න
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Windows හි, ප්‍රොසෙසරයට විශේෂිත __fastfail යාන්ත්‍රණය භාවිතා කරන්න.Windows 8 සහ ඊට පසු, මෙය කිසිදු ක්‍රියාවලියක ව්‍යතිරේක හසුරුවන්නන් ක්‍රියාත්මක නොකර වහාම ක්‍රියාවලිය අවසන් කරනු ඇත.
            // Windows හි පෙර සංස්කරණ වලදී, මෙම උපදෙස් මාලාව ප්‍රවේශ උල්ලං as නය කිරීමක් ලෙස සලකනු ලබන අතර එය ක්‍රියාවලිය අවසන් කරන නමුත් අවශ්‍යයෙන්ම සියලු ව්‍යතිරේක හසුරුවන්නන් මඟ හරිනු නොලැබේ.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: මෙය libstd හි `abort_internal` හි ක්‍රියාත්මක කිරීමම වේ
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// මේක ... ටිකක් අමුතු දෙයක්.ටීඑල්; ඩ්‍ර;මෙය නිවැරදිව සම්බන්ධ කිරීම සඳහා අවශ්‍ය වේ, දිගු පැහැදිලි කිරීම පහතින්.
//
// මේ වන විට අප නැව්ගත කරන libcore/libstd හි ද්විමය සියල්ල `-C panic=unwind` සමඟ සම්පාදනය කර ඇත.මෙය සිදු කරනුයේ ද්විමය හැකිතාක් තත්වයන් සමඟ උපරිම ලෙස අනුකූල වන බව සහතික කිරීම සඳහා ය.
// කෙසේ වෙතත්, සම්පාදකයාට `-C panic=unwind` සමඟ සම්පාදනය කරන ලද සියලුම කාර්යයන් සඳහා "personality function" අවශ්‍ය වේ.මෙම පෞරුෂ ශ්‍රිතය `rust_eh_personality` සංකේතයට තදින් කේතනය කර ඇති අතර එය `eh_personality` lang අයිතමය මගින් අර්ථ දක්වා ඇත.
//
// So...
// ඇයි ඒ ලැන්ග් අයිතමය මෙහි අර්ථ දක්වන්නේ නැත්තේ?හොඳ ප්රශ්නයක්!panic ධාවන වේලාවන් සම්බන්ධ කර ඇති ආකාරය ඇත්ත වශයෙන්ම මඳක් සියුම් ය, ඒවා සම්පාදකයාගේ crate ගබඩාවේ "sort of" වේ, නමුත් ඇත්ත වශයෙන්ම සම්බන්ධ වී ඇත්තේ වෙනත් එකක් සම්බන්ධ නොවන්නේ නම් පමණි.
//
// මෙයින් අවසන් වන්නේ මෙම crate සහ panic_unwind crate යන දෙකම සම්පාදකයාගේ crate ගබඩාවේ දිස්විය හැකි අතර දෙකම `eh_personality` lang අයිතමය නිර්වචනය කළහොත් එය දෝෂයකට ලක් වනු ඇති බවයි.
//
// මෙය හැසිරවීම සඳහා `eh_personality` නිර්වචනය කළ යුත්තේ panic ධාවන කාලය සම්බන්ධ වී ඇත්තේ නොදැනුවත්වම ක්‍රියාත්මක වන වේලාව නම් පමණි. එසේ නොමැතිනම් එය නිර්වචනය කිරීම අවශ්‍ය නොවේ (නිවැරදිව එසේ).
// කෙසේ වෙතත්, මෙම අවස්ථාවේ දී, මෙම පුස්තකාලය මෙම සංකේතය නිර්වචනය කරයි, එබැවින් අවම වශයෙන් යම්කිසි පෞරුෂයක් කොතැනක හෝ තිබේ.
//
// අත්යවශ්යයෙන්ම මෙම සංකේතය libcore/libstd ද්විමය දක්වා වයර් ලබා ගැනීම සඳහා අර්ථ දක්වා ඇත, නමුත් අපි කිසි විටෙකත් නොදැනුවත්වම ධාවන වේලාවට සම්බන්ධ නොවන බැවින් එය කිසි විටෙකත් හැඳින්විය යුතු නොවේ.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // X86_64-pc-windows-gnu හි අපි අපගේම රාමු පසුකරමින් සිටින විට `ExceptionContinueSearch` ආපසු ලබා දිය යුතු අපගේම පෞරුෂත්ව ශ්‍රිතයක් භාවිතා කරමු.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // ඉහත ආකාරයටම, මෙය දැනට එම්ස්ක්‍රිප්ටෙන් හි පමණක් භාවිතා වන `eh_catch_typeinfo` lang අයිතමයට අනුරූප වේ.
    //
    // panics ව්‍යතිරේක ජනනය නොකරන අතර විදේශීය ව්‍යතිරේක දැනට UB සමඟ -C panic=නවතා දමන්න (මෙය වෙනස් වීමට යටත් වුවද), ඕනෑම catch_unwind ඇමතුම් කිසි විටෙකත් මෙම typeinfo භාවිතා නොකරනු ඇත.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // I686-pc-windows-gnu හි අපගේ ආරම්භක වස්තූන් විසින් මේ දෙක හඳුන්වනු ලැබේ, නමුත් ඒවාට කිසිවක් කිරීමට අවශ්‍ය නොවන බැවින් සිරුරු උච්ච වේ.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}