use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // මිරි ඉතා මන්දගාමී ය
fn exact_sanity_test() {
    // මෙම පරීක්ෂණය අවසන් වන්නේ මට උපකල්පනය කළ හැකි දේ පමණක් වන අතර එය `exp2` පුස්තකාල ශ්‍රිතයේ යම්කිසි අංගයක් වන අතර එය අප භාවිතා කරන ඕනෑම C ධාවන වේලාවක අර්ථ දක්වා ඇත.
    // VS 2013 හි මෙම ශ්‍රිතය සම්බන්ධ වූ විට මෙම පරීක්ෂණය අසමත් වන බැවින් මෙම ශ්‍රිතයට දෝෂයක් ඇති බව පෙනේ, නමුත් VS 2015 සමඟ පරීක්ෂණය හොඳින් ක්‍රියාත්මක වන විට දෝෂය ස්ථාවර බව පෙනේ.
    //
    // දෝෂය `exp2(-1057)` හි ප්‍රතිලාභ අගයෙහි වෙනසක් ලෙස පෙනේ, VS 2013 දී එය 0x2 බිට් රටාව සමඟ දෙගුණයක් ලබා දෙන අතර VS 2015 දී එය 0x20000 ලබා දෙයි.
    //
    //
    // දැන් මෙම පරීක්ෂණය එම්එස්වීසී මත සම්පූර්ණයෙන්ම නොසලකා හරින්න, එය වෙනත් තැනක පරීක්‍ෂා කර ඇති බැවින් සහ එක් එක් වේදිකාවේ exp2 ක්‍රියාත්මක කිරීම පරීක්ෂා කිරීමට අප එතරම් උනන්දු නොවේ.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}