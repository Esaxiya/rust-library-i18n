//! Note
//! ----
//! ඔබ බොහෝ විට මෙම ගොනුව නරඹන්නේ ඔබ පරීක්ෂණයක් එකතු කරන නිසා විය හැකිය (නැතහොත් ඔබ ගවේෂණය කරමින් සිටිනවා නම්, ඒ අවස්ථාවේ දී, ඒයි!).
//!
//! Iter පරීක්ෂණ කට්ටලය විශාල මොඩියුල දෙකකට බෙදා ඇති අතර සමහර කුඩා මොඩියුල.විශාල මොඩියුල දෙක වන්නේ `adapters` සහ `traits` ය.
//!
//! `adapters` එක් එක් අයිතමය වැසීමෙන් පසු වෙනත් අනුකාරකයක් විමෝචනය කිරීමෙන් හෝ අයිටරේටරය තුළ සිට අයිතමයක් ආපසු ලබා දීමෙන් Xe `Iterator` හි ක්‍රම සඳහා වේ.
//!
//!
//! `traits` `Iterator` (සහ `Iterator` trait ම විස්තාරණය කරන trait සඳහා වන අතර බොහෝ දුරට විවිධ ක්‍රම අඩංගු වේ).
//! බොහෝ දුරට, `traits` හි පරීක්ෂණයක් විශේෂිත ඇඩැප්ටරයක් භාවිතා කරන්නේ නම්, එය `adapters` හි ඇති ඇඩැප්ටරයේ පරීක්ෂණ ගොනුව වෙත ගෙන යා යුතුය.
//!
//!
//!
//!
//!

mod adapters;
mod range;
mod sources;
mod traits;

use core::cell::Cell;
use core::convert::TryFrom;
use core::iter::*;

pub fn is_trusted_len<I: TrustedLen>(_: I) {}

#[test]
fn test_multi_iter() {
    let xs = [1, 2, 3, 4];
    let ys = [4, 3, 2, 1];
    assert!(xs.iter().eq(ys.iter().rev()));
    assert!(xs.iter().lt(xs.iter().skip(2)));
}

#[test]
fn test_counter_from_iter() {
    let it = (0..).step_by(5).take(10);
    let xs: Vec<isize> = FromIterator::from_iter(it);
    assert_eq!(xs, [0, 5, 10, 15, 20, 25, 30, 35, 40, 45]);
}

#[test]
fn test_functor_laws() {
    // identity:
    fn identity<T>(x: T) -> T {
        x
    }
    assert_eq!((0..10).map(identity).sum::<usize>(), (0..10).sum());

    // composition:
    fn f(x: usize) -> usize {
        x + 3
    }
    fn g(x: usize) -> usize {
        x * 2
    }
    fn h(x: usize) -> usize {
        g(f(x))
    }
    assert_eq!((0..10).map(f).map(g).sum::<usize>(), (0..10).map(h).sum());
}

#[test]
fn test_monad_laws_left_identity() {
    fn f(x: usize) -> impl Iterator<Item = usize> {
        (0..10).map(move |y| x * y)
    }
    assert_eq!(once(42).flat_map(f.clone()).sum::<usize>(), f(42).sum());
}

#[test]
fn test_monad_laws_right_identity() {
    assert_eq!((0..10).flat_map(|x| once(x)).sum::<usize>(), (0..10).sum());
}

#[test]
fn test_monad_laws_associativity() {
    fn f(x: usize) -> impl Iterator<Item = usize> {
        0..x
    }
    fn g(x: usize) -> impl Iterator<Item = usize> {
        (0..x).rev()
    }
    assert_eq!(
        (0..10).flat_map(f).flat_map(g).sum::<usize>(),
        (0..10).flat_map(|x| f(x).flat_map(g)).sum::<usize>()
    );
}

#[test]
pub fn extend_for_unit() {
    let mut x = 0;
    {
        let iter = (0..5).map(|_| {
            x += 1;
        });
        ().extend(iter);
    }
    assert_eq!(x, 5);
}