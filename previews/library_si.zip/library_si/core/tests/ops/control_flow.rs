use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // මෙය ස්ථායී පෘෂ් area වර්ග area ලයක් නොවේ, නමුත් LLVM හට සෑම විටම එහි වාසිය ලබා ගත නොහැකි වුවද, ඔවුන් අතර `?` ලාභදායී ලෙස තබා ගැනීමට උපකාරී වේ.
    //
    // (කනගාටුදායක ප්‍රති ult ලය සහ විකල්පය නොගැලපෙන බැවින් පාලක ප්‍රවාහයට මේ දෙකම ගැලපෙන්නේ නැත.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}