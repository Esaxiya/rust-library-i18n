use core::pin::Pin;

#[test]
fn pin_const() {
    // `Pin` හි ක්‍රමෝපායන් සන්දර්භය තුළ භාවිතා කළ හැකි දැයි පරීක්ෂා කරන්න

    const POINTER: &'static usize = &2;

    const PINNED: Pin<&'static usize> = Pin::new(POINTER);
    const PINNED_UNCHECKED: Pin<&'static usize> = unsafe { Pin::new_unchecked(POINTER) };
    assert_eq!(PINNED_UNCHECKED, PINNED);

    const INNER: &'static usize = Pin::into_inner(PINNED);
    assert_eq!(INNER, POINTER);

    const INNER_UNCHECKED: &'static usize = unsafe { Pin::into_inner_unchecked(PINNED) };
    assert_eq!(INNER_UNCHECKED, POINTER);

    const REF: &'static usize = PINNED.get_ref();
    assert_eq!(REF, POINTER);

    // Note: `pin_mut_const` පරීක්ෂණ `Pin<&mut T>` හි ක්‍රමෝපායන් සන්දර්භය තුළ භාවිතා කළ හැකි බව පරීක්ෂා කරයි.
    // `&mut` යනු නියතයන්හි භාවිතා කළ හැකි (yet) නොවන නිසා const fn භාවිතා වේ.
    const fn pin_mut_const() {
        let _ = Pin::new(&mut 2).into_ref();
        let _ = Pin::new(&mut 2).get_mut();
        let _ = unsafe { Pin::new(&mut 2).get_unchecked_mut() };
    }

    pin_mut_const();
}