use core::task::Poll;

#[test]
fn poll_const() {
    // `Poll` හි ක්‍රමෝපායන් සන්දර්භය තුළ භාවිතා කළ හැකි දැයි පරීක්ෂා කරන්න

    const POLL: Poll<usize> = Poll::Pending;

    const IS_READY: bool = POLL.is_ready();
    assert!(!IS_READY);

    const IS_PENDING: bool = POLL.is_pending();
    assert!(IS_PENDING);
}