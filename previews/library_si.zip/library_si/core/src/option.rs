//! විකල්ප අගයන්.
//!
//! [`Option`] වර්ගය විකල්ප අගයක් නිරූපණය කරයි: සෑම [`Option`] එකක්ම [`Some`] වන අතර එහි අගය හෝ [`None`] අඩංගු වන අතර එසේ නොවේ.
//! [`Option`] Rust කේතයේ වර්ග බහුලව දක්නට ලැබේ, ඒවාට භාවිතයන් ගණනාවක් ඇත:
//!
//! * ආරම්භක අගයන්
//! * ඒවායේ සම්පූර්ණ ආදාන පරාසය තුළ අර්ථ දක්වා නොමැති ශ්‍රිත සඳහා ප්‍රතිලාභ අගයන් (අර්ධ ශ්‍රිත)
//! * [`None`] දෝෂයක් මත ආපසු ලබා දෙන සරල දෝෂ වාර්තා කිරීම සඳහා ප්‍රතිලාභ අගය
//! * විකල්ප ව්‍යුහාත්මක ක්ෂේත්‍ර
//! * ණය ලබා ගත හැකි ක්ෂේත්‍ර හෝ "taken"
//! * විකල්ප ශ්‍රිත තර්ක
//! * අවලංගු කළ හැකි දර්ශක
//! * දුෂ්කර අවස්ථාවන්ගෙන් දේවල් මාරු කිරීම
//!
//! [`විකල්පය] සාමාන්‍යයෙන් යුගලනය වන්නේ රටාව ගැලපීම සමඟ අගයක පැවැත්ම විමසීමට සහ ක්‍රියා කිරීමටය, සෑම විටම [`None`] නඩුව සඳහා ගණනය කෙරේ.
//!
//!
//! ```
//! fn divide(numerator: f64, denominator: f64) -> Option<f64> {
//!     if denominator == 0.0 {
//!         None
//!     } else {
//!         Some(numerator / denominator)
//!     }
//! }
//!
//! // ශ්‍රිතයේ ප්‍රතිලාභ අගය විකල්පයකි
//! let result = divide(2.0, 3.0);
//!
//! // අගය ලබා ගැනීමට රටා ගැලපීම
//! match result {
//!     // බෙදීම වලංගු විය
//!     Some(x) => println!("Result: {}", x),
//!     // බෙදීම අවලංගු විය
//!     None    => println!("Cannot divide by 0"),
//! }
//! ```
//!
//!
//!
//!
//!
// FIXME: බොහෝ ක්‍රම සමඟ `Option` ප්‍රායෝගිකව භාවිතා කරන ආකාරය පෙන්වන්න
//
//! # විකල්ප සහ දර්ශක ("nullable" දර්ශක)
//!
//! Rust හි දර්ශක වර්ග සෑම විටම වලංගු ස්ථානයකට යොමු විය යුතුය;"null" යොමු කිරීම් නොමැත.ඒ වෙනුවට, Rust සතුව විකල්ප අයිතිකරු කොටුව වැනි *විකල්ප* දර්ශක ඇත, [`විකල්පය]]` <`[` කොටුව<T>`]`> `.
//!
//! පහත දැක්වෙන උදාහරණය [`i32`] හි විකල්ප කොටුවක් නිර්මාණය කිරීම සඳහා [`Option`] භාවිතා කරයි.
//! පළමුවෙන්ම අභ්‍යන්තර [`i32`] අගය භාවිතා කිරීම සඳහා, කොටුවට වටිනාකමක් තිබේද යන්න තීරණය කිරීම සඳහා `check_optional` ශ්‍රිතයට රටා ගැලපීම භාවිතා කළ යුතු බව සලකන්න (එනම්, එය [`Some(...)`][`Some`]) හෝ ([`None`]) නොවේ.
//!
//!
//! ```
//! let optional = None;
//! check_optional(optional);
//!
//! let optional = Some(Box::new(9000));
//! check_optional(optional);
//!
//! fn check_optional(optional: Option<Box<i32>>) {
//!     match optional {
//!         Some(p) => println!("has value {}", p),
//!         None => println!("has no value"),
//!     }
//! }
//! ```
//!
//! # Representation
//!
//! [`Option<T>`] `T` ට සමාන ප්‍රමාණයක් ඇති `T` පහත දැක්වෙන වර්ග ප්‍රශස්තිකරණය කිරීමට Rust සහතික කරයි:
//!
//! * [`Box<U>`]
//! * `&U`
//! * `&mut U`
//! * `fn`, `extern "C" fn`
//! * [`num::NonZero*`]
//! * [`ptr::NonNull<U>`]
//! * `#[repr(transparent)]` මෙම ලැයිස්තුවේ එක් වර්ගයක් වටා ව්‍යුහය.
//!
//! ඉහත අවස්ථා සඳහා යමෙකුට [`mem::transmute`] හි `T` සිට `Option<T>` දක්වා සහ `Some::<T>(_)` සිට `T` දක්වා වලංගු අගයන්ගෙන් [`mem::transmute`] කළ හැකි බව තවදුරටත් සහතික වේ (නමුත් `None::<T>` සිට `T` දක්වා සම්ප්‍රේෂණය කිරීම නිර්වචනය නොකළ හැසිරීමකි).
//!
//! # Examples
//!
//! [`Option`] හි මූලික රටා ගැලපීම:
//!
//! ```
//! let msg = Some("howdy");
//!
//! // අඩංගු නූලට යොමු වන්න
//! if let Some(m) = &msg {
//!     println!("{}", *m);
//! }
//!
//! // විකල්පය විනාශ කරමින් අඩංගු නූල ඉවත් කරන්න
//! let unwrapped_msg = msg.unwrap_or("default message");
//! ```
//!
//! ලූපයකට පෙර [`None`] වෙත ප්‍රති result ලයක් ආරම්භ කරන්න:
//!
//! ```
//! enum Kingdom { Plant(u32, &'static str), Animal(u32, &'static str) }
//!
//! // සෙවිය යුතු දත්ත ලැයිස්තුවක්.
//! let all_the_big_things = [
//!     Kingdom::Plant(250, "redwood"),
//!     Kingdom::Plant(230, "noble fir"),
//!     Kingdom::Plant(229, "sugar pine"),
//!     Kingdom::Animal(25, "blue whale"),
//!     Kingdom::Animal(19, "fin whale"),
//!     Kingdom::Animal(15, "north pacific right whale"),
//! ];
//!
//! // අපි විශාලතම සත්වයාගේ නම සෙවීමට යන්නෙමු, නමුත් ආරම්භ කිරීමට අපට දැන් ඇත්තේ `None` ය.
//! //
//! let mut name_of_biggest_animal = None;
//! let mut size_of_biggest_animal = 0;
//! for big_thing in &all_the_big_things {
//!     match *big_thing {
//!         Kingdom::Animal(size, name) if size > size_of_biggest_animal => {
//!             // දැන් අපි විශාල සතෙකුගේ නම සොයාගෙන ඇත
//!             size_of_biggest_animal = size;
//!             name_of_biggest_animal = Some(name);
//!         }
//!         Kingdom::Animal(..) | Kingdom::Plant(..) => ()
//!     }
//! }
//!
//! match name_of_biggest_animal {
//!     Some(name) => println!("the biggest animal is {}", name),
//!     None => println!("there are no animals :("),
//! }
//! ```
//!
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Box<U>`]: ../../std/boxed/struct.Box.html
//! [`num::NonZero*`]: crate::num
//! [`ptr::NonNull<U>`]: crate::ptr::NonNull
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{FromIterator, FusedIterator, TrustedLen};
use crate::pin::Pin;
use crate::{
    fmt, hint, mem,
    ops::{self, Deref, DerefMut},
};

/// `Option` වර්ගය.වැඩි විස්තර සඳහා [the module level documentation](self) බලන්න.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[rustc_diagnostic_item = "option_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Option<T> {
    /// වටිනාකමක් නැත
    #[lang = "None"]
    #[stable(feature = "rust1", since = "1.0.0")]
    None,
    /// සමහර අගය `T`
    #[lang = "Some"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Some(#[stable(feature = "rust1", since = "1.0.0")] T),
}

/////////////////////////////////////////////////////////////////////////////
// ක්‍රියාත්මක කිරීම ටයිප් කරන්න
/////////////////////////////////////////////////////////////////////////////

impl<T> Option<T> {
    /////////////////////////////////////////////////////////////////////////
    // අඩංගු අගයන් විමසීම
    /////////////////////////////////////////////////////////////////////////

    /// විකල්පය [`Some`] අගයක් නම් `true` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_some(), true);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_some(), false);
    /// ```
    #[must_use = "if you intended to assert that this has a value, consider `.unwrap()` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_some(&self) -> bool {
        matches!(*self, Some(_))
    }

    /// විකල්පය [`None`] අගයක් නම් `true` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_none(), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_none(), true);
    /// ```
    #[must_use = "if you intended to assert that this doesn't have a value, consider \
                  `.and_then(|| panic!(\"`Option` had a value when expected `None`\"))` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_none(&self) -> bool {
        !self.is_some()
    }

    /// විකල්පය දී ඇති අගය අඩංගු [`Some`] අගයක් නම් `true` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Option<u32> = Some(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Some(y) => x == y,
            None => false,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // යොමු කිරීම් සමඟ වැඩ කිරීම සඳහා ඇඩැප්ටරය
    /////////////////////////////////////////////////////////////////////////

    /// `&Option<T>` සිට `Option<&T>` දක්වා පරිවර්තනය කරයි.
    ///
    /// # Examples
    ///
    /// මුල් විකල්පය ආරක්ෂා කරමින් `විකල්පයක් <` [`නූල්`]`>`විකල්පයක් බවට පරිවර්තනය කරයි <`[`භාවිතා කරන්න`]`> `.
    /// [`map`] ක්‍රමය `self` තර්කය අගය අනුව ගෙන, මුල් පිටපත පරිභෝජනය කරයි, එබැවින් මෙම තාක්ෂණය `as_ref` භාවිතා කරන්නේ මුලින් `Option` මුල් පිටපතෙහි ඇති අගය වෙත යොමු කිරීම සඳහා ය.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let text: Option<String> = Some("Hello, world!".to_string());
    /// // පළමුව, `as_ref` සමඟ `Option<String>` සිට `Option<&String>` දක්වා දමන්න, ඉන්පසු `map` සමඟ *එය* පරිභෝජනය කරන්න, `text` තොගයේ ඉතිරි වේ.
    /////
    /// let text_length: Option<usize> = text.as_ref().map(|s| s.len());
    /// println!("still can print text: {:?}", text);
    /// ```
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Option<&T> {
        match *self {
            Some(ref x) => Some(x),
            None => None,
        }
    }

    /// `&mut Option<T>` සිට `Option<&mut T>` දක්වා පරිවර්තනය කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// match x.as_mut() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Option<&mut T> {
        match *self {
            Some(ref mut x) => Some(x),
            None => None,
        }
    }

    /// [`පින්`]`<සහ විකල්පයෙන් පරිවර්තනය වේ<T>>`සිට`විකල්පය <`[`පින්`] `<&ටී>>`.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_ref(self: Pin<&Self>) -> Option<Pin<&T>> {
        // ආරක්ෂාව: `x` `self` වෙතින් එන බැවින් එය ඇලවීම සහතික කෙරේ
        // ඇලවූ.
        unsafe { Pin::get_ref(self).as_ref().map(|x| Pin::new_unchecked(x)) }
    }

    /// [`පින්`]`<සහ විකෘති විකල්පයෙන් පරිවර්තනය වේ<T>>`සිට`විකල්පය <` [`පින්`]`<&විකෘති ටී>>`.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_mut(self: Pin<&mut Self>) -> Option<Pin<&mut T>> {
        // සුරක්ෂිතභාවය: `self` තුළ `Option` ගෙනයාමට `get_unchecked_mut` කිසි විටෙකත් භාවිතා නොවේ.
        // `x` එය ඇලවූ `self` වෙතින් එන බැවින් එය ඇලවීමට සහතික වේ.
        unsafe { Pin::get_unchecked_mut(self).as_mut().map(|x| Pin::new_unchecked(x)) }
    }

    /////////////////////////////////////////////////////////////////////////
    // අඩංගු අගයන් වෙත ළඟා වීම
    /////////////////////////////////////////////////////////////////////////

    /// `self` අගය පරිභෝජනය කරමින් අඩංගු [`Some`] අගය ලබා දෙයි.
    ///
    /// # Panics
    ///
    /// Panics අගය `msg` විසින් සපයන ලද අභිරුචි panic පණිවිඩයක් සහිත [`None`] නම්.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("value");
    /// assert_eq!(x.expect("fruits are healthy"), "value");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// x.expect("fruits are healthy"); // panics with `fruits are healthy`
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Some(val) => val,
            None => expect_failed(msg),
        }
    }

    /// `self` අගය පරිභෝජනය කරමින් අඩංගු [`Some`] අගය ලබා දෙයි.
    ///
    /// මෙම ශ්‍රිතය panic විය හැකි බැවින්, එහි භාවිතය සාමාන්‍යයෙන් අධෛර්යමත් වේ.
    /// ඒ වෙනුවට, රටා ගැලපීම භාවිතා කිරීමට සහ [`None`] නඩුව පැහැදිලිව හැසිරවීමට කැමති හෝ [`unwrap_or`], [`unwrap_or_else`], හෝ [`unwrap_or_default`] අමතන්න.
    ///
    ///
    /// [`unwrap_or`]: Option::unwrap_or
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    /// [`unwrap_or_default`]: Option::unwrap_or_default
    ///
    /// # Panics
    ///
    /// ස්වයං අගය [`None`] ට සමාන නම් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("air");
    /// assert_eq!(x.unwrap(), "air");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// assert_eq!(x.unwrap(), "air"); // fails
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn unwrap(self) -> T {
        match self {
            Some(val) => val,
            None => panic!("called `Option::unwrap()` on a `None` value"),
        }
    }

    /// අඩංගු [`Some`] අගය හෝ ලබා දී ඇති පෙරනිමිය ලබා දෙයි.
    ///
    /// `unwrap_or` වෙත ඉදිරිපත් කරන ලද තර්ක උනන්දුවෙන් ඇගයීමට ලක් කෙරේ;ඔබ ශ්‍රිත ඇමතුමක ප්‍රති result ලය පසුකරන්නේ නම්, කම්මැලි ලෙස ඇගයීමට ලක් කරන [`unwrap_or_else`] භාවිතා කිරීම රෙකමදාරු කරනු ලැබේ.
    ///
    ///
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(Some("car").unwrap_or("bike"), "car");
    /// assert_eq!(None.unwrap_or("bike"), "bike");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Some(x) => x,
            None => default,
        }
    }

    /// අඩංගු [`Some`] අගය ලබා දෙයි හෝ වසා දැමීමෙන් ගණනය කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 10;
    /// assert_eq!(Some(4).unwrap_or_else(|| 2 * k), 4);
    /// assert_eq!(None.unwrap_or_else(|| 2 * k), 20);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce() -> T>(self, f: F) -> T {
        match self {
            Some(x) => x,
            None => f(),
        }
    }

    /// අගය [`None`] නොවන බව පරික්ෂා නොකර `self` අගය පරිභෝජනය කරන [`Some`] අගය ලබා දෙයි.
    ///
    ///
    /// # Safety
    ///
    /// [`None`] හි මෙම ක්‍රමය ඇමතීම *[නිර්වචනය නොකළ හැසිරීම]*.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x = Some("air");
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air");
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Option<&str> = None;
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air"); // නිර්වචනය නොකළ හැසිරීම!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_some());
        match self {
            Some(val) => val,
            // ආරක්ෂාව: ආරක්ෂිත කොන්ත්රාත්තුව අමතන්නා විසින් තහවුරු කළ යුතුය.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // අඩංගු අගයන් පරිවර්තනය කිරීම
    /////////////////////////////////////////////////////////////////////////

    /// අඩංගු අගයකට ශ්‍රිතයක් යෙදීමෙන් `Option<T>` සිට `Option<U>` දක්වා සිතියම් ගත කරන්න.
    ///
    /// # Examples
    ///
    /// මුල් විකල්පය පරිභෝජනය කරමින් `විකල්පයක් <` [`නූල්`]`>`විකල්පයක් බවට පරිවර්තනය කරයි <`[`භාවිතා කරන්න`]`> `:
    ///
    /// [`String`]: ../../std/string/struct.String.html
    /// ```
    /// let maybe_some_string = Some(String::from("Hello, World!"));
    /// // `Option::map` `maybe_some_string` පරිභෝජනය කරමින් ස්වයං *අගය* ගනී
    /// let maybe_some_len = maybe_some_string.map(|s| s.len());
    ///
    /// assert_eq!(maybe_some_len, Some(13));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, f: F) -> Option<U> {
        match self {
            Some(x) => Some(f(x)),
            None => None,
        }
    }

    /// අඩංගු අගයට ශ්‍රිතයක් යොදයි (ඇත්නම්), හෝ ලබා දී ඇති පෙරනිමිය නැවත ලබා දෙයි (එසේ නොවේ නම්).
    ///
    /// `map_or` වෙත ඉදිරිපත් කරන ලද තර්ක උනන්දුවෙන් ඇගයීමට ලක් කෙරේ;ඔබ ශ්‍රිත ඇමතුමක ප්‍රති result ලය පසුකරන්නේ නම්, කම්මැලි ලෙස ඇගයීමට ලක් කරන [`map_or_else`] භාවිතා කිරීම රෙකමදාරු කරනු ලැබේ.
    ///
    ///
    /// [`map_or_else`]: Option::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default,
        }
    }

    /// අඩංගු අගයට ශ්‍රිතයක් යෙදේ (ඇත්නම්), හෝ පෙරනිමිය ගණනය කරයි (එසේ නොවේ නම්).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x = Some("foo");
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 42);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or_else<U, D: FnOnce() -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default(),
        }
    }

    /// `Option<T>` [`Result<T, E>`] බවට පරිවර්තනය කරයි, [`Some(v)`] සිට [`Ok(v)`] දක්වාද [`None`] සිට [`Err(err)`] දක්වාද සිතියම් ගත කරයි.
    ///
    /// `ok_or` වෙත ඉදිරිපත් කරන ලද තර්ක උනන්දුවෙන් ඇගයීමට ලක් කෙරේ;ඔබ ශ්‍රිත ඇමතුමක ප්‍රති result ලය පසුකරන්නේ නම්, කම්මැලි ලෙස ඇගයීමට ලක් කරන [`ok_or_else`] භාවිතා කිරීම රෙකමදාරු කරනු ලැබේ.
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err)`]: Err
    /// [`Some(v)`]: Some
    /// [`ok_or_else`]: Option::ok_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or(0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or(0), Err(0));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or<E>(self, err: E) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err),
        }
    }

    /// `Option<T>` [`Result<T, E>`] බවට පරිවර්තනය කරයි, [`Some(v)`] සිට [`Ok(v)`] දක්වාද [`None`] සිට [`Err(err())`] දක්වාද සිතියම් ගත කරයි.
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err())`]: Err
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or_else(|| 0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or_else(|| 0), Err(0));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or_else<E, F: FnOnce() -> E>(self, err: F) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err()),
        }
    }

    /// විකල්පයට `value` ඇතුල් කිරීමෙන් පසුව ඒ සඳහා විකෘති යොමු කිරීමක් ලබා දේ.
    ///
    /// විකල්පය තුළ දැනටමත් අගයක් තිබේ නම්, පැරණි අගය පහත වැටේ.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(option_insert)]
    ///
    /// let mut opt = None;
    /// let val = opt.insert(1);
    /// assert_eq!(*val, 1);
    /// assert_eq!(opt.unwrap(), 1);
    /// let val = opt.insert(2);
    /// assert_eq!(*val, 2);
    /// *val = 3;
    /// assert_eq!(opt.unwrap(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "option_insert", reason = "newly added", issue = "78271")]
    pub fn insert(&mut self, value: T) -> &mut T {
        *self = Some(value);

        match self {
            Some(v) => v,
            // ආරක්ෂාව: ඉහත කේතය විකල්පය පුරවා ඇත
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // අනුකාරක ඉදිකිරීම්කරුවන්
    /////////////////////////////////////////////////////////////////////////

    /// අඩංගු විය හැකි වටිනාකමට වඩා අනුකාරකයක් ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(4);
    /// assert_eq!(x.iter().next(), Some(&4));
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn iter(&self) -> Iter<'_, T> {
        Iter { inner: Item { opt: self.as_ref() } }
    }

    /// අඩංගු විය හැකි අගයට වඩා විකෘති පුනරාවර්තකයක් ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(4);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    ///
    /// let mut x: Option<u32> = None;
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: Item { opt: self.as_mut() } }
    }

    /////////////////////////////////////////////////////////////////////////
    // සාරධර්ම, උනන්දුවෙන් හා කම්මැලි ලෙස බූලියන් මෙහෙයුම්
    /////////////////////////////////////////////////////////////////////////

    /// විකල්පය [`None`] නම් [`None`] ලබා දෙයි, එසේ නොමැතිනම් `optb` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), None);
    ///
    /// let x = Some(2);
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), Some("foo"));
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, optb: Option<U>) -> Option<U> {
        match self {
            Some(_) => optb,
            None => None,
        }
    }

    /// විකල්පය [`None`] නම් [`None`] ලබා දෙයි, එසේ නොමැතිනම් ඔතා ඇති අගය සමඟ `f` අමතා ප්‍රති .ලය ලබා දෙයි.
    ///
    ///
    /// සමහර භාෂා මෙම මෙහෙයුම පැතලි සිතියම ලෙස හැඳින්වේ.
    ///
    /// # Examples
    ///
    /// ```
    /// fn sq(x: u32) -> Option<u32> { Some(x * x) }
    /// fn nope(_: u32) -> Option<u32> { None }
    ///
    /// assert_eq!(Some(2).and_then(sq).and_then(sq), Some(16));
    /// assert_eq!(Some(2).and_then(sq).and_then(nope), None);
    /// assert_eq!(Some(2).and_then(nope).and_then(sq), None);
    /// assert_eq!(None.and_then(sq).and_then(sq), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Option<U>>(self, f: F) -> Option<U> {
        match self {
            Some(x) => f(x),
            None => None,
        }
    }

    /// විකල්පය [`None`] නම් [`None`] ලබා දෙයි, එසේ නොමැතිනම් ඔතා ඇති අගය සමඟ `predicate` අමතා ආපසු එයි:
    ///
    ///
    /// - [`Some(t)`] `predicate` විසින් `true` ආපසු ලබා දෙන්නේ නම් (එහිදී `t` යනු ඔතා ඇති අගයයි), සහ
    /// - [`None`] `predicate` `false` ආපසු ලබා දෙන්නේ නම්.
    ///
    /// මෙම ශ්‍රිතය [`Iterator::filter()`] හා සමාන වේ.
    /// `Option<T>` මූලද්‍රව්‍ය එකක් හෝ ශුන්‍යයට වඩා අනුකාරකයක් ලෙස ඔබට සිතාගත හැකිය.
    /// `filter()` කුමන අංග තබා ගත යුතුද යන්න තීරණය කිරීමට ඔබට ඉඩ දෙයි.
    ///
    /// # Examples
    ///
    /// ```rust
    /// fn is_even(n: &i32) -> bool {
    ///     n % 2 == 0
    /// }
    ///
    /// assert_eq!(None.filter(is_even), None);
    /// assert_eq!(Some(3).filter(is_even), None);
    /// assert_eq!(Some(4).filter(is_even), Some(4));
    /// ```
    ///
    /// [`Some(t)`]: Some
    ///
    #[inline]
    #[stable(feature = "option_filter", since = "1.27.0")]
    pub fn filter<P: FnOnce(&T) -> bool>(self, predicate: P) -> Self {
        if let Some(x) = self {
            if predicate(&x) {
                return Some(x);
            }
        }
        None
    }

    /// එහි අගයක් තිබේ නම් විකල්පය ලබා දෙයි, එසේ නොමැතිනම් `optb` ලබා දෙයි.
    ///
    /// `or` වෙත ඉදිරිපත් කරන ලද තර්ක උනන්දුවෙන් ඇගයීමට ලක් කෙරේ;ඔබ ශ්‍රිත ඇමතුමක ප්‍රති result ලය පසුකරන්නේ නම්, කම්මැලි ලෙස ඇගයීමට ලක් කරන [`or_else`] භාවිතා කිරීම රෙකමදාරු කරනු ලැබේ.
    ///
    ///
    /// [`or_else`]: Option::or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y = None;
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x = None;
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(100));
    ///
    /// let x = Some(2);
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = None;
    /// assert_eq!(x.or(y), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or(self, optb: Option<T>) -> Option<T> {
        match self {
            Some(_) => self,
            None => optb,
        }
    }

    /// එහි අගයක් තිබේ නම් විකල්පය ලබා දෙයි, එසේ නොමැතිනම් `f` අමතා ප්‍රති .ලය ලබා දෙයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn nobody() -> Option<&'static str> { None }
    /// fn vikings() -> Option<&'static str> { Some("vikings") }
    ///
    /// assert_eq!(Some("barbarians").or_else(vikings), Some("barbarians"));
    /// assert_eq!(None.or_else(vikings), Some("vikings"));
    /// assert_eq!(None.or_else(nobody), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F: FnOnce() -> Option<T>>(self, f: F) -> Option<T> {
        match self {
            Some(_) => self,
            None => f(),
        }
    }

    /// `self` වලින් එකක් නම් [`Some`], `optb` යනු [`Some`] වේ, එසේ නොමැතිනම් [`None`] ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x = Some(2);
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), None);
    /// ```
    #[inline]
    #[stable(feature = "option_xor", since = "1.37.0")]
    pub fn xor(self, optb: Option<T>) -> Option<T> {
        match (self, optb) {
            (Some(a), None) => Some(a),
            (None, Some(b)) => Some(b),
            _ => None,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // කිසිවක් නොමැති නම් ඇතුළු කර යොමු කිරීමක් ලබා දීම සඳහා ඇතුළත් කිරීම් වැනි මෙහෙයුම්
    /////////////////////////////////////////////////////////////////////////

    /// [`None`] නම් විකල්පයට `value` ඇතුල් කරන්න, පසුව අඩංගු අගයට විකෘති යොමු කිරීමක් ලබා දෙයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert(5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert(&mut self, value: T) -> &mut T {
        self.get_or_insert_with(|| value)
    }

    /// [`None`] නම් පෙරනිමි අගය විකල්පයට ඇතුල් කරයි, පසුව අඩංගු අගයට විකෘති යොමු කිරීමක් ලබා දෙයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_get_or_insert_default)]
    ///
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_default();
    ///     assert_eq!(y, &0);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[unstable(feature = "option_get_or_insert_default", issue = "82901")]
    pub fn get_or_insert_default(&mut self) -> &mut T
    where
        T: Default,
    {
        self.get_or_insert_with(Default::default)
    }

    /// `f` සිට ගණනය කළ අගයක් [`None`] නම් විකල්පයට ඇතුල් කරයි, පසුව අඩංගු අගයට විකෘති යොමු කිරීමක් ලබා දෙයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_with(|| 5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert_with<F: FnOnce() -> T>(&mut self, f: F) -> &mut T {
        if let None = *self {
            *self = Some(f());
        }

        match self {
            Some(v) => v,
            // ආරක්ෂාව: `self` සඳහා `None` ප්‍රභේදයක් `Some` මගින් ප්‍රතිස්ථාපනය වීමට ඉඩ තිබුණි
            // ඉහත කේතයේ ප්‍රභේදය.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Misc
    /////////////////////////////////////////////////////////////////////////

    /// විකල්පයෙන් පිටත වටිනාකම ගෙන, [`None`] එහි ස්ථානයේ තබයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, Some(2));
    ///
    /// let mut x: Option<u32> = None;
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self)
    }

    /// පරාමිතියෙහි දක්වා ඇති අගය අනුව විකල්පයේ සත්‍ය අගය ප්‍රතිස්ථාපනය කරයි, පැරණි අගය තිබේ නම් එය ආපසු ලබා දෙයි, එක් එකක් අක්‍රීය නොකර [`Some`] එහි ස්ථානයේ තබයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let old = x.replace(5);
    /// assert_eq!(x, Some(5));
    /// assert_eq!(old, Some(2));
    ///
    /// let mut x = None;
    /// let old = x.replace(3);
    /// assert_eq!(x, Some(3));
    /// assert_eq!(old, None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "option_replace", since = "1.31.0")]
    pub fn replace(&mut self, value: T) -> Option<T> {
        mem::replace(self, Some(value))
    }

    /// තවත් `Option` සමඟ Zips `self`.
    ///
    /// `self` `Some(s)` සහ `other` `Some(o)` නම්, මෙම ක්‍රමය `Some((s, o))` ලබා දෙයි.
    /// එසේ නොමැතිනම්, `None` ආපසු ලබා දෙනු ලැබේ.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(1);
    /// let y = Some("hi");
    /// let z = None::<u8>;
    ///
    /// assert_eq!(x.zip(y), Some((1, "hi")));
    /// assert_eq!(x.zip(z), None);
    /// ```
    #[stable(feature = "option_zip_option", since = "1.46.0")]
    pub fn zip<U>(self, other: Option<U>) -> Option<(T, U)> {
        match (self, other) {
            (Some(a), Some(b)) => Some((a, b)),
            _ => None,
        }
    }

    /// සිප්ස් `self` සහ `f` ශ්‍රිතය සහිත තවත් `Option`.
    ///
    /// `self` `Some(s)` සහ `other` `Some(o)` නම්, මෙම ක්‍රමය `Some(f(s, o))` ලබා දෙයි.
    /// එසේ නොමැතිනම්, `None` ආපසු ලබා දෙනු ලැබේ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_zip)]
    ///
    /// #[derive(Debug, PartialEq)]
    /// struct Point {
    ///     x: f64,
    ///     y: f64,
    /// }
    ///
    /// impl Point {
    ///     fn new(x: f64, y: f64) -> Self {
    ///         Self { x, y }
    ///     }
    /// }
    ///
    /// let x = Some(17.5);
    /// let y = Some(42.7);
    ///
    /// assert_eq!(x.zip_with(y, Point::new), Some(Point { x: 17.5, y: 42.7 }));
    /// assert_eq!(x.zip_with(None, Point::new), None);
    /// ```
    #[unstable(feature = "option_zip", issue = "70086")]
    pub fn zip_with<U, F, R>(self, other: Option<U>, f: F) -> Option<R>
    where
        F: FnOnce(T, U) -> R,
    {
        Some(f(self?, other?))
    }
}

impl<T: Copy> Option<&T> {
    /// විකල්පයේ අන්තර්ගතය පිටපත් කිරීමෙන් `Option<&T>` සිට `Option<T>` දක්වා සිතියම් ගත කරන්න.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&t| t)
    }
}

impl<T: Copy> Option<&mut T> {
    /// විකල්පයේ අන්තර්ගතය පිටපත් කිරීමෙන් `Option<&mut T>` සිට `Option<T>` දක්වා සිතියම් ගත කරන්න.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone> Option<&T> {
    /// විකල්පයේ අන්තර්ගතය ක්ලෝන කිරීමෙන් `Option<&T>` සිට `Option<T>` දක්වා සිතියම් ගත කරන්න.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone> Option<&mut T> {
    /// විකල්පයේ අන්තර්ගතය ක්ලෝන කිරීමෙන් `Option<&mut T>` සිට `Option<T>` දක්වා සිතියම් ගත කරන්න.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(since = "1.26.0", feature = "option_ref_mut_cloned")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: fmt::Debug> Option<T> {
    /// [`None`] අපේක්ෂා කරන අතර කිසිවක් ආපසු නොදෙන අතර `self` පරිභෝජනය කරයි.
    ///
    /// # Panics
    ///
    /// Panics අගය [`Some`] නම්, සම්මත කළ පණිවිඩය ඇතුළුව panic පණිවිඩයක් සහ [`Some`] හි අන්තර්ගතය.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // සියලුම යතුරු අද්විතීය බැවින් මෙය panic නොවනු ඇත.
    ///     squares.insert(i, i * i).expect_none("duplicate key");
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).expect_none("duplicate key");
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_expect_none", reason = "newly added", issue = "62633")]
    pub fn expect_none(self, msg: &str) {
        if let Some(val) = self {
            expect_none_failed(msg, &val);
        }
    }

    /// [`None`] අපේක්ෂා කරන අතර කිසිවක් ආපසු නොදෙන අතර `self` පරිභෝජනය කරයි.
    ///
    /// # Panics
    ///
    /// Panics අගය [`Some`] නම්, අභිරුචි panic පණිවිඩයක් සමඟ [`සමහර`] අගය මඟින් සපයනු ලැබේ.
    ///
    ///
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // සියලුම යතුරු අද්විතීය බැවින් මෙය panic නොවනු ඇත.
    ///     squares.insert(i, i * i).unwrap_none();
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).unwrap_none();
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_unwrap_none", reason = "newly added", issue = "62633")]
    pub fn unwrap_none(self) {
        if let Some(val) = self {
            expect_none_failed("called `Option::unwrap_none()` on a `Some` value", &val);
        }
    }
}

impl<T: Default> Option<T> {
    /// අඩංගු [`Some`] අගය හෝ පෙරනිමිය ලබා දෙයි
    ///
    /// `self` තර්කය පරිභෝජනය කරයි, [`Some`] නම්, අඩංගු අගය නැවත ලබා දෙයි, එසේ නොමැතිනම් [`None`] නම්, එම වර්ගය සඳහා [default value] ආපසු ලබා දේ.
    ///
    ///
    /// # Examples
    ///
    /// දුර්වල ලෙස සාදන ලද නූල් 0 බවට හරවන (පූර්ණ සංඛ්‍යා සඳහා පෙරනිමි අගය) නූලක් පූර්ණ සංඛ්‍යාවක් බවට පරිවර්තනය කරයි.
    /// [`parse`] [`FromStr`] ක්‍රියාත්මක කරන වෙනත් වර්ගයකට නූලක් පරිවර්තනය කරයි, දෝෂයක් මත [`None`] ආපසු එයි.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().ok().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().ok().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [default value]: Default::default
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Some(x) => x,
            None => Default::default(),
        }
    }
}

impl<T: Deref> Option<T> {
    /// `Option<T>` (හෝ `&Option<T>`) සිට `Option<&T::Target>` දක්වා පරිවර්තනය කරයි.
    ///
    /// මුල් විකල්පය තැනින් තැන තබමින්, මුල් එකක් ගැන සඳහනක් සහිතව නව එකක් නිර්මාණය කිරීම, ඊට අමතරව [`Deref`] හරහා අන්තර්ගතය බල කිරීම.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref(), Some("hey"));
    ///
    /// let x: Option<String> = None;
    /// assert_eq!(x.as_deref(), None);
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref(&self) -> Option<&T::Target> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut> Option<T> {
    /// `Option<T>` (හෝ `&mut Option<T>`) සිට `Option<&mut T::Target>` දක්වා පරිවර්තනය කරයි.
    ///
    /// මුල් වර්ගයේ `Option` ස්ථානයෙන් ඉවත්ව, අභ්‍යන්තර වර්ගයේ `Deref::Target` වර්ගයට විකෘති යොමු කිරීමක් සහිත නව එකක් නිර්මාණය කරයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref_mut().map(|x| {
    ///     x.make_ascii_uppercase();
    ///     x
    /// }), Some("HEY".to_owned().as_mut_str()));
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref_mut(&mut self) -> Option<&mut T::Target> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Option<Result<T, E>> {
    /// [`Result`] හි `Option`, `Option` හි [`Result`] බවට පරිවර්තනය කරයි.
    ///
    /// [`None`] [`හරි`]`(`[`කිසිවක් නැත]]`) වෙත අනුරූපණය වේ.
    /// [`සමහර`]`(`[`හරි`] `(_)) සහ [` සමහර`]`(`[`වැරදි ']`(_))`[`හරි`]' වෙත සිතියම් ගත කෙරේ. `[` සමහරක්`]`(_))`සහ [`වැරදි`]` (_) `.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x, y.transpose());
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn transpose(self) -> Result<Option<T>, E> {
        match self {
            Some(Ok(x)) => Ok(Some(x)),
            Some(Err(e)) => Err(e),
            None => Ok(None),
        }
    }
}

// .expect() හි කේත ප්‍රමාණය අඩු කිරීම සඳහා මෙය වෙනම කාර්යයකි.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_failed(msg: &str) -> ! {
    panic!("{}", msg)
}

// .expect_none() හි කේත ප්‍රමාණය අඩු කිරීම සඳහා මෙය වෙනම කාර්යයකි.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_none_failed(msg: &str, value: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, value)
}

/////////////////////////////////////////////////////////////////////////////
// Trait ක්‍රියාත්මක කිරීම
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for Option<T> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Some(x) => Some(x.clone()),
            None => None,
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Some(to), Some(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Option<T> {
    /// [`None`][Option::None] ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let opt: Option<u32> = Option::default();
    /// assert!(opt.is_none());
    /// ```
    #[inline]
    fn default() -> Option<T> {
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for Option<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// අඩංගු විය හැකි වටිනාකමට වඩා පරිභෝජන අනුකාරකයක් ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("string");
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert_eq!(v, ["string"]);
    ///
    /// let x = None;
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: Item { opt: self } }
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a Option<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a mut Option<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(since = "1.12.0", feature = "option_from")]
impl<T> From<T> for Option<T> {
    /// `val` නව `Some` වෙත පිටපත් කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let o: Option<u8> = Option::from(67);
    ///
    /// assert_eq!(Some(67), o);
    /// ```
    fn from(val: T) -> Option<T> {
        Some(val)
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a Option<T>> for Option<&'a T> {
    /// `&Option<T>` සිට `Option<&T>` දක්වා පරිවර්තනය කරයි.
    ///
    /// # Examples
    ///
    /// මුල් විකල්පය ආරක්ෂා කරමින් `විකල්පයක් <` [`නූල්`]`>`විකල්පයක් බවට පරිවර්තනය කරයි <`[`භාවිතා කරන්න`]`> `.
    /// [`map`] ක්‍රමය `self` තර්කය අගය අනුව ගෙන, මුල් පිටපත පරිභෝජනය කරයි, එබැවින් මෙම තාක්ෂණය `as_ref` භාවිතා කරන්නේ මුලින් `Option` මුල් පිටපතෙහි ඇති අගය වෙත යොමු කිරීම සඳහා ය.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let s: Option<String> = Some(String::from("Hello, Rustaceans!"));
    /// let o: Option<usize> = Option::from(&s).map(|ss: &String| ss.len());
    ///
    /// println!("Can still print s: {:?}", s);
    ///
    /// assert_eq!(o, Some(18));
    /// ```
    ///
    fn from(o: &'a Option<T>) -> Option<&'a T> {
        o.as_ref()
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a mut Option<T>> for Option<&'a mut T> {
    /// `&mut Option<T>` සිට `Option<&mut T>` දක්වා පරිවර්තනය කරයි
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = Some(String::from("Hello"));
    /// let o: Option<&mut String> = Option::from(&mut s);
    ///
    /// match o {
    ///     Some(t) => *t = String::from("Hello, Rustaceans!"),
    ///     None => (),
    /// }
    ///
    /// assert_eq!(s, Some(String::from("Hello, Rustaceans!")));
    /// ```
    fn from(o: &'a mut Option<T>) -> Option<&'a mut T> {
        o.as_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// විකල්පය අනුකරණය කරන්නන්
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
struct Item<A> {
    opt: Option<A>,
}

impl<A> Iterator for Item<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.opt.take()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        match self.opt {
            Some(_) => (1, Some(1)),
            None => (0, Some(0)),
        }
    }
}

impl<A> DoubleEndedIterator for Item<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.opt.take()
    }
}

impl<A> ExactSizeIterator for Item<A> {}
impl<A> FusedIterator for Item<A> {}
unsafe impl<A> TrustedLen for Item<A> {}

/// [`Option`] හි [`Some`] ප්‍රභේදය පිළිබඳ සඳහනක් හරහා iterator.
///
/// [`Option`] යනු [`Some`] නම් iterator එක අගයක් ලබා දෙයි, එසේ නොමැති නම් කිසිවක් නැත.
///
/// මෙම `struct` නිර්මාණය කර ඇත්තේ [`Option::iter`] ශ්‍රිතයෙනි.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct Iter<'a, A: 'a> {
    inner: Item<&'a A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for Iter<'a, A> {
    type Item = &'a A;

    #[inline]
    fn next(&mut self) -> Option<&'a A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for Iter<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for Iter<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for Iter<'_, A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Clone for Iter<'_, A> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner.clone() }
    }
}

/// [`Option`] හි [`Some`] ප්‍රභේදයට විකෘති කළ හැකි යොමු කිරීමක් හරහා ඉරේටරයක්.
///
/// [`Option`] යනු [`Some`] නම් iterator එක අගයක් ලබා දෙයි, එසේ නොමැති නම් කිසිවක් නැත.
///
/// මෙම `struct` නිර්මාණය කර ඇත්තේ [`Option::iter_mut`] ශ්‍රිතයෙනි.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, A: 'a> {
    inner: Item<&'a mut A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for IterMut<'a, A> {
    type Item = &'a mut A;

    #[inline]
    fn next(&mut self) -> Option<&'a mut A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for IterMut<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IterMut<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IterMut<'_, A> {}
#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// [`Option`] හි [`Some`] ප්‍රභේදයේ වටිනාකමට වඩා ඉරේටරයක්.
///
/// [`Option`] යනු [`Some`] නම් iterator එක අගයක් ලබා දෙයි, එසේ නොමැති නම් කිසිවක් නැත.
///
/// මෙම `struct` නිර්මාණය කර ඇත්තේ [`Option::into_iter`] ශ්‍රිතයෙනි.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<A> {
    inner: Item<A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Iterator for IntoIter<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> DoubleEndedIterator for IntoIter<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IntoIter<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IntoIter<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, V: FromIterator<A>> FromIterator<Option<A>> for Option<V> {
    /// [`Iterator`] හි එක් එක් මූලද්‍රව්‍යය ගනී: එය [`None`][Option::None] නම්, තවත් මූලද්‍රව්‍යයන් නොගන්නා අතර [`None`][Option::None] ආපසු ලබා දෙනු ලැබේ.
    /// [`None`][Option::None] කිසිවක් සිදු නොවන්නේ නම්, එක් එක් [`Option`] හි අගයන් සහිත බහාලුමක් ආපසු ලබා දෙනු ලැබේ.
    ///
    /// # Examples
    ///
    /// vector හි සෑම පූර්ණ සංඛ්‍යාවක්ම වැඩි කරන උදාහරණයක් මෙන්න.
    /// ගණනය කිරීම පිටාර ගැලීමකට තුඩු දෙන විට අපි `add` හි පරීක්ෂා කළ ප්‍රභේදය භාවිතා කරමු.
    ///
    /// ```
    /// let items = vec![0_u16, 1, 2];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_add(1))
    ///     .collect();
    ///
    /// assert_eq!(res, Some(vec![1, 2, 3]));
    /// ```
    ///
    /// ඔබට පෙනෙන පරිදි, මෙය අපේක්ෂිත වලංගු අයිතම නැවත ලබා දෙනු ඇත.
    ///
    /// මෙන්න තවත් නිඛිල ලැයිස්තුවකින් තවත් එකක් අඩු කිරීමට උත්සාහ කරන තවත් උදාහරණයක්, මේ වතාවේ ගලායාම පරීක්ෂා කරයි:
    ///
    /// ```
    /// let items = vec![2_u16, 1, 0];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_sub(1))
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// ```
    ///
    /// අවසාන මූලද්‍රව්‍යය ශුන්‍ය බැවින් එය ගලා එනු ඇත.මේ අනුව, එහි ප්‍රති value ලයක් ලෙස ලැබෙන අගය `None` වේ.
    ///
    /// පළමු `None` පසු `iter` වෙතින් තවත් මූලද්‍රව්‍යයන් නොගන්නා බව පෙන්වන පෙර උදාහරණයේ විචලනය මෙන්න.
    ///
    /// ```
    /// let items = vec![3_u16, 2, 1, 10];
    ///
    /// let mut shared = 0;
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| { shared += x; x.checked_sub(2) })
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// තෙවන මූලද්‍රව්‍යය යටින් ගලායාමට හේතු වූ බැවින්, තවත් මූලද්‍රව්‍යයන් ගනු නොලැබූ බැවින් `shared` හි අවසාන අගය 6 (= `3 + 2 + 1`) මිස 16 නොවේ.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Option<A>>>(iter: I) -> Option<V> {
        // FIXME(#11084): මෙම කාර්ය සාධන දෝෂය වසා ඇති විට මෙය Iterator::scan සමඟ ප්‍රතිස්ථාපනය කළ හැකිය.
        //

        iter.into_iter().map(|x| x.ok_or(())).collect::<Result<_, _>>().ok()
    }
}

/// උත්සාහක ක්‍රියාකරු (`?`) `None` අගයකට යෙදීමෙන් ඇතිවන දෝෂ වර්ගය.
/// ඔබේ දෝෂ වර්ගය බවට පරිවර්තනය කිරීමට ඔබට `x?` (`x` යනු `Option<T>`) ඉඩ දීමට අවශ්‍ය නම්, ඔබට `YourErrorType` සඳහා `impl From<NoneError>` ක්‍රියාත්මක කළ හැකිය.
///
/// එවැනි අවස්ථාවකදී, `Result<_, YourErrorType>` ලබා දෙන ශ්‍රිතයක් තුළ ඇති `x?`, `None` අගය `Err` ප්‍රති .ලයක් බවට පරිවර්තනය කරයි.
#[rustc_diagnostic_item = "none_error"]
#[unstable(feature = "try_trait", issue = "42327")]
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
pub struct NoneError;

#[unstable(feature = "try_trait", issue = "42327")]
impl<T> ops::Try for Option<T> {
    type Ok = T;
    type Error = NoneError;

    #[inline]
    fn into_result(self) -> Result<T, NoneError> {
        self.ok_or(NoneError)
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Some(v)
    }

    #[inline]
    fn from_error(_: NoneError) -> Self {
        None
    }
}

impl<T> Option<Option<T>> {
    /// `Option<Option<T>>` සිට `Option<T>` දක්වා පරිවර්තනය කරයි
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let x: Option<Option<u32>> = Some(Some(6));
    /// assert_eq!(Some(6), x.flatten());
    ///
    /// let x: Option<Option<u32>> = Some(None);
    /// assert_eq!(None, x.flatten());
    ///
    /// let x: Option<Option<u32>> = None;
    /// assert_eq!(None, x.flatten());
    /// ```
    ///
    /// පැතලි කිරීම මඟින් වරකට එක් කැදැල්ලක් ඉවත් කරයි:
    ///
    /// ```
    /// let x: Option<Option<Option<u32>>> = Some(Some(Some(6)));
    /// assert_eq!(Some(Some(6)), x.flatten());
    /// assert_eq!(Some(6), x.flatten().flatten());
    /// ```
    #[inline]
    #[stable(feature = "option_flattening", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn flatten(self) -> Option<T> {
        match self {
            Some(inner) => inner,
            None => None,
        }
    }
}