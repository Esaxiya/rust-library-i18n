//! කම්මැලි අගයන් සහ ස්ථිතික දත්ත එක් වරක් ආරම්භ කිරීම.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// එක් වරක් පමණක් ලිවිය හැකි කොටුවක්.
///
/// `RefCell` මෙන් නොව, `OnceCell` මඟින් එහි වටිනාකමට හවුල් `&T` යොමු කිරීම් පමණක් සපයයි.
/// `Cell` මෙන් නොව, `OnceCell` වෙත ප්‍රවේශ වීමට වටිනාකම පිටපත් කිරීම හෝ ප්‍රතිස්ථාපනය කිරීම අවශ්‍ය නොවේ.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // වෙනස් නොවන: එකවරම ලියා ඇත.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// නව හිස් කොටුවක් සාදයි.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// යටින් පවතින අගය වෙත යොමු කිරීම ලබා ගනී.
    ///
    /// සෛලය හිස් නම් `None` ලබා දෙයි.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // ආරක්ෂාව: 'අභ්‍යන්තරය' වෙනස් වීම නිසා ආරක්ෂිතයි
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// යටින් පවතින අගයට විකෘති යොමුව ලබා ගනී.
    ///
    /// සෛලය හිස් නම් `None` ලබා දෙයි.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // ආරක්ෂාව: අපට අද්විතීය ප්‍රවේශයක් ඇති නිසා ආරක්ෂිතයි
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// සෛලයේ අන්තර්ගතය `value` ලෙස සකසයි.
    ///
    /// # Errors
    ///
    /// මෙම ක්‍රමය සෛලය හිස් නම් `Ok(())` සහ එය පිරී ඇත්නම් `Err(value)` ලබා දෙයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // සුරක්ෂිතභාවය: අපට විකෘති ණය අතිච්ඡාදනය කළ නොහැකි නිසා ආරක්ෂිතයි
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // ආරක්ෂාව: අපි තව් තැබූ එකම ස්ථානය මෙයයි
        // reentrancy/concurrency නිසා විය හැකි අතර, අපි තව් දැනට `None` බව පරීක්ෂා කර ඇත්තෙමු, එබැවින් මෙම ලිවීම 'අභ්‍යන්තරයේ' අක්‍රීයතාව පවත්වා ගනී.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// සෛලය හිස් නම් `f` සමඟ ආරම්භ කරමින් සෛලයේ අන්තර්ගතය ලබා ගනී.
    ///
    /// # Panics
    ///
    /// `f` panics නම්, panic අමතන්නාට ප්‍රචාරය වන අතර සෛලය ආරම්භ නොවී පවතී.
    ///
    ///
    /// `f` වෙතින් සෛලය නැවත ආරම්භ කිරීම දෝෂයකි.එසේ කිරීමෙන් panic ප්‍රති in ල ලැබේ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// සෛලය හිස් නම් `f` සමඟ ආරම්භ කරමින් සෛලයේ අන්තර්ගතය ලබා ගනී.
    /// කොටුව හිස් නම් සහ `f` අසමත් නම්, දෝෂයක් නැවත ලබා දෙනු ලැබේ.
    ///
    /// # Panics
    ///
    /// `f` panics නම්, panic අමතන්නාට ප්‍රචාරය වන අතර සෛලය ආරම්භ නොවී පවතී.
    ///
    ///
    /// `f` වෙතින් සෛලය නැවත ආරම්භ කිරීම දෝෂයකි.එසේ කිරීමෙන් panic ප්‍රති in ල ලැබේ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // *සමහර* පුනරාවර්තන ආරම්භක යූබී වෙත යොමු විය හැකි බව සලකන්න (`reentrant_init` පරීක්ෂණය බලන්න).
        // මෙම `assert` ඉවත් කිරීම, `set/get` තබා ගැනීම හොඳ යැයි මම විශ්වාස කරමි, නමුත් පැරණි වටිනාකමක් නිහ ly ව භාවිතා කරනවාට වඩා panic ට වඩා හොඳ බව පෙනේ.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// ඔතා ඇති අගය නැවත ලබා දෙමින් සෛලය පරිභෝජනය කරයි.
    ///
    /// සෛලය හිස් නම් `None` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // `into_inner` අගය අනුව `self` ගන්නා බැවින්, සම්පාදකයා එය දැනට ණයට ගෙන නොමැති බව සංඛ්‍යාත්මකව තහවුරු කරයි.
        // එබැවින් `Option<T>` පිටතට යාම ආරක්ෂිතයි.
        self.inner.into_inner()
    }

    /// මෙම `OnceCell` හි වටිනාකම ඉවතට ගෙන එය නැවත ආරම්භක තත්වයකට ගෙන යයි.
    ///
    /// කිසිදු බලපෑමක් නොමැති අතර `OnceCell` ආරම්භ කර නොමැති නම් `None` ආපසු ලබා දේ.
    ///
    /// විකෘති යොමු කිරීමක් අවශ්‍ය වීමෙන් ආරක්ෂාව සහතික කෙරේ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// පළමු ප්‍රවේශය මත ආරම්භ කළ අගය.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   ආරම්භ කිරීම සූදානම්
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// දී ඇති ආරම්භක ශ්‍රිතය සමඟ නව කම්මැලි අගයක් නිර්මාණය කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// මෙම කම්මැලි අගය තක්සේරු කිරීමට බල කරන අතර ප්‍රති .ලය වෙත යොමු කිරීමක් ලබා දෙයි.
    ///
    ///
    /// මෙය `Deref` impl ට සමාන නමුත් පැහැදිලි ය.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// ආරම්භක කාර්යය ලෙස `Default` භාවිතා කරමින් නව කම්මැලි අගයක් නිර්මාණය කරයි.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}