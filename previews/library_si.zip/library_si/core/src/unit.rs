use crate::iter::FromIterator;

/// සියළුම ඒකක අයිතමයන් අනුකාරකයේ සිට එකකට බිඳ දමයි.
///
/// ඔබ දෝෂ ගැන පමණක් සැලකිලිමත් වන `Result<(), E>` වෙත එකතු කිරීම වැනි ඉහළ මට්ටමේ වියුක්ත කිරීම් සමඟ සංයුක්ත වන විට මෙය වඩාත් ප්‍රයෝජනවත් වේ:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}