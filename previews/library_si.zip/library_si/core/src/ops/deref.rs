/// `*v` වැනි වෙනස් කළ නොහැකි විරූපණ මෙහෙයුම් සඳහා භාවිතා වේ.
///
/// නිශ්චල නොවන සන්දර්භයන් තුළ (unary) `*` ක්‍රියාකරු සමඟ පැහැදිලිව විරූපණය කිරීමේ මෙහෙයුම් සඳහා භාවිතා කිරීමට අමතරව, `Deref` බොහෝ අවස්ථාවන්හිදී සම්පාදකයා විසින් ව්‍යංගයෙන් භාවිතා කරයි.
/// මෙම යාන්ත්‍රණය ['`Deref` coercion'][more] ලෙස හැඳින්වේ.
/// විකෘති සන්දර්භය තුළ, [`DerefMut`] භාවිතා වේ.
///
/// ස්මාර්ට් පොයින්ටර් සඳහා `Deref` ක්‍රියාත්මක කිරීමෙන් ඔවුන් පිටුපස ඇති දත්ත වලට ප්‍රවේශ වීම පහසු කරයි, එබැවින් ඔවුන් `Deref` ක්‍රියාත්මක කරයි.
/// අනෙක් අතට, `Deref` සහ [`DerefMut`] සම්බන්ධ නීති විශේෂයෙන් නිර්මාණය කර ඇත්තේ ස්මාර්ට් පොයින්ටර්ස් සඳහා ඉඩ සැලසීම සඳහා ය.
/// මේ නිසා,**`ඩෙරෙෆ්` ක්‍රියාත්මක කළ යුත්තේ ව්‍යාකූලත්වය මඟහරවා ගැනීම සඳහා ස්මාර්ට් පොයින්ටර්ස්** සඳහා පමණි.
///
/// සමාන හේතු නිසා,**මෙම trait කිසි විටෙකත් අසමත් නොවිය යුතුය**.`Deref` ව්‍යංගයෙන් ආයාචනා කරන විට විරූපණය කිරීමේදී අසමත් වීම අතිශයින් ව්‍යාකූල විය හැකිය.
///
/// # `Deref` බලහත්කාරය පිළිබඳ තවත්
///
/// `T` `Deref<Target = U>` ක්‍රියාත්මක කරන්නේ නම් සහ `x` යනු `T` වර්ගයේ අගය නම්,
///
/// * වෙනස් කළ නොහැකි සන්දර්භය තුළ, `*x` (එහිදී `T` යනු යොමු කිරීමක් හෝ අමු දර්ශකයක් නොවේ) `* Deref::deref(&x)` ට සමාන වේ.
/// * `&T` වර්ගයේ අගයන් `&U` වර්ගයේ අගයන්ට බල කෙරේ
/// * `T` `U` වර්ගයේ සියලුම (immutable) ක්‍රම ව්‍යංගයෙන් ක්‍රියාත්මක කරයි.
///
/// වැඩි විස්තර සඳහා, [the chapter in *The Rust Programming Language*][book] මෙන්ම [the dereference operator][ref-deref-op], [method resolution] සහ [type coercions] හි විමර්ශන අංශ වෙත පිවිසෙන්න.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// ව්‍යුහය අවලංගු කිරීමෙන් ප්‍රවේශ විය හැකි තනි ක්ෂේත්‍රයක් සහිත ව්‍යුහයකි.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// විරූපණය කිරීමෙන් පසු ඇතිවන වර්ගය.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// වටිනාකම අඩු කරයි.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// `*v = 1;` හි මෙන් විකෘති විරූපණය කිරීමේ මෙහෙයුම් සඳහා භාවිතා වේ.
///
/// විකෘති සන්දර්භයන් තුළ (unary) `*` ක්‍රියාකරු සමඟ පැහැදිලිව විරූපණය කිරීමේ මෙහෙයුම් සඳහා භාවිතා කිරීමට අමතරව, `DerefMut` බොහෝ අවස්ථාවන්හිදී සම්පාදකයා විසින් ව්‍යංගයෙන් භාවිතා කරයි.
/// මෙම යාන්ත්‍රණය ['`Deref` coercion'][more] ලෙස හැඳින්වේ.
/// වෙනස් කළ නොහැකි සන්දර්භය තුළ, [`Deref`] භාවිතා වේ.
///
/// ස්මාර්ට් පොයින්ටර් සඳහා `DerefMut` ක්‍රියාත්මක කිරීමෙන් ඔවුන් පිටුපස ඇති දත්ත විකෘති කිරීම පහසු කරයි, එබැවින් ඔවුන් `DerefMut` ක්‍රියාත්මක කරයි.
/// අනෙක් අතට, [`Deref`] සහ `DerefMut` සම්බන්ධ නීති විශේෂයෙන් නිර්මාණය කර ඇත්තේ ස්මාර්ට් පොයින්ටර්ස් සඳහා ඉඩ සැලසීම සඳහා ය.
/// මේ නිසා,**`DerefMut` ක්‍රියාත්මක කළ යුත්තේ ව්‍යාකූලත්වය මඟහරවා ගැනීම සඳහා ස්මාර්ට් පොයින්ටර්ස්** සඳහා පමණි.
///
/// සමාන හේතු නිසා,**මෙම trait කිසි විටෙකත් අසමත් නොවිය යුතුය**.`DerefMut` ව්‍යංගයෙන් ආයාචනා කරන විට විරූපණය කිරීමේදී අසමත් වීම අතිශයින් ව්‍යාකූල විය හැකිය.
///
/// # `Deref` බලහත්කාරය පිළිබඳ තවත්
///
/// `T` `DerefMut<Target = U>` ක්‍රියාත්මක කරන්නේ නම් සහ `x` යනු `T` වර්ගයේ අගය නම්,
///
/// * විකෘති සන්දර්භය තුළ, `*x` (එහිදී `T` යනු යොමු කිරීමක් හෝ අමු දර්ශකයක් නොවේ) `* DerefMut::deref_mut(&mut x)` ට සමාන වේ.
/// * `&mut T` වර්ගයේ අගයන් `&mut U` වර්ගයේ අගයන්ට බල කෙරේ
/// * `T` `U` වර්ගයේ සියලුම (mutable) ක්‍රම ව්‍යංගයෙන් ක්‍රියාත්මක කරයි.
///
/// වැඩි විස්තර සඳහා, [the chapter in *The Rust Programming Language*][book] මෙන්ම [the dereference operator][ref-deref-op], [method resolution] සහ [type coercions] හි විමර්ශන අංශ වෙත පිවිසෙන්න.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// ව්‍යුහය අවලංගු කිරීමෙන් වෙනස් කළ හැකි තනි ක්ෂේත්‍රයක් සහිත ව්‍යුහයකි.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// විකෘති ලෙස වටිනාකම අඩු කරයි.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// `arbitrary_self_types` විශේෂාංගය නොමැතිව ව්‍යුහයක් ක්‍රම ග්‍රාහකයක් ලෙස භාවිතා කළ හැකි බව දක්වයි.
///
/// මෙය ක්‍රියාත්මක වන්නේ `Box<T>`, `Rc<T>`, `&T`, සහ `Pin<P>` වැනි stdlib pointer වර්ග මගිනි.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}