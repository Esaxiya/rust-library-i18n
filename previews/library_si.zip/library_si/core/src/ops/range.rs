use crate::fmt;
use crate::hash::Hash;

/// අසීමිත පරාසයක (`..`).
///
/// `RangeFull` මූලික වශයෙන් [slicing index] ලෙස භාවිතා කරයි, එහි කෙටිමං `..` වේ.
/// ආරම්භක ස්ථානයක් නොමැති නිසා එයට [`Iterator`] ලෙස සේවය කළ නොහැක.
///
/// # Examples
///
/// `..` සින්ටැක්ස් යනු `RangeFull`:
///
/// ```
/// assert_eq!((..), std::ops::RangeFull);
/// ```
///
/// එයට [`IntoIterator`] ක්‍රියාත්මක කිරීමක් නොමැත, එබැවින් ඔබට එය `for` පුඩුවක් තුළ කෙලින්ම භාවිතා කළ නොහැක.
/// මෙය සම්පාදනය නොකරයි:
///
/// ```compile_fail,E0277
/// for i in .. {
///     // ...
/// }
/// ```
///
/// [slicing index] ලෙස භාවිතා කරන `RangeFull` සම්පූර්ණ අරාව පෙත්තක් ලෙස නිපදවයි.
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]); // මෙය `RangeFull` ය
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeFull"]
#[doc(alias = "..")]
#[derive(Copy, Clone, Default, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFull;

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for RangeFull {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")
    }
}

/// (half-open) පරාසයක් ඇතුළත් කර ඇත්තේ ඊට පහළින් සහ තනිකරම (`start..end`) ට වඩා ඉහළින්.
///
///
/// `start..end` පරාසය තුළ `start <= x < end` සමඟ සියලු අගයන් අඩංගු වේ.
/// `start >= end` නම් එය හිස් ය.
///
/// # Examples
///
/// `start..end` සින්ටැක්ස් යනු `Range`:
///
/// ```
/// assert_eq!((3..5), std::ops::Range { start: 3, end: 5 });
/// assert_eq!(3 + 4 + 5, (3..6).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]); // මෙය `Range` ය
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
#[lang = "Range"]
#[doc(alias = "..")]
#[derive(Clone, Default, PartialEq, Eq, Hash)] // පිටපත් නොකෙරේ-#27186 බලන්න
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Range<Idx> {
    /// (inclusive) පරාසයේ පහළ සීමාව.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
    /// (exclusive) පරාසයේ ඉහළ සීමාව.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for Range<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> Range<Idx> {
    /// `item` පරාසය තුළ තිබේ නම් `true` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).contains(&2));
    /// assert!( (3..5).contains(&3));
    /// assert!( (3..5).contains(&4));
    /// assert!(!(3..5).contains(&5));
    ///
    /// assert!(!(3..3).contains(&3));
    /// assert!(!(3..2).contains(&3));
    ///
    /// assert!( (0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// පරාසය තුළ අයිතම නොමැති නම් `true` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).is_empty());
    /// assert!( (3..3).is_empty());
    /// assert!( (3..2).is_empty());
    /// ```
    ///
    /// දෙපැත්තටම අසමසම නම් පරාසය හිස් ය:
    ///
    /// ```
    /// assert!(!(3.0..5.0).is_empty());
    /// assert!( (3.0..f32::NAN).is_empty());
    /// assert!( (f32::NAN..5.0).is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    pub fn is_empty(&self) -> bool {
        !(self.start < self.end)
    }
}

/// පරාසය (`start..`) ට වඩා අඩුවෙන් පමණක් සීමා වේ.
///
/// `RangeFrom` `start..` හි සියලු අගයන් `x >= start` සමඟ අඩංගු වේ.
///
/// *සටහන*: [`Iterator`] ක්‍රියාත්මක කිරීමේදී පිටාර ගැලීම (අඩංගු දත්ත වර්ගය එහි සංඛ්‍යාත්මක සීමාව කරා ළඟා වූ විට) panic, එතුම හෝ සංතෘප්ත කිරීමට අවසර දෙනු ලැබේ.
/// මෙම හැසිරීම අර්ථ දැක්වෙන්නේ [`Step`] trait ක්‍රියාත්මක කිරීමෙනි.
/// ප්‍රාථමික නිඛිල සඳහා, මෙය සාමාන්‍ය නීති රීති අනුගමනය කරන අතර පිටාර ගැලීම් පැතිකඩට ගරු කරයි (නිදොස් කිරීමේදී panic, මුදා හැරීමේදී එතීම).
/// ඔබ සිතනවාට වඩා කලින් පිටාර ගැලීම සිදු වන බව සලකන්න: `next` ඇමතුමෙහි පිටාර ගැලීම සිදුවන්නේ උපරිම අගය ලබා දෙන නිසාය, ඊළඟ අගය ලබා දීම සඳහා පරාසය තත්වයකට සැකසිය යුතුය.
///
///
/// [`Step`]: crate::iter::Step
///
/// # Examples
///
/// `start..` සින්ටැක්ස් යනු `RangeFrom`:
///
/// ```
/// assert_eq!((2..), std::ops::RangeFrom { start: 2 });
/// assert_eq!(2 + 3 + 4, (2..).take(3).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]); // මෙය `RangeFrom` ය
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
///
///
#[lang = "RangeFrom"]
#[doc(alias = "..")]
#[derive(Clone, PartialEq, Eq, Hash)] // පිටපත් නොකෙරේ-#27186 බලන්න
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFrom<Idx> {
    /// (inclusive) පරාසයේ පහළ සීමාව.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeFrom<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeFrom<Idx> {
    /// `item` පරාසය තුළ තිබේ නම් `true` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..).contains(&2));
    /// assert!( (3..).contains(&3));
    /// assert!( (3..).contains(&1_000_000_000));
    ///
    /// assert!( (0.0..).contains(&0.5));
    /// assert!(!(0.0..).contains(&f32::NAN));
    /// assert!(!(f32::NAN..).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// පරාසය (`..end`) ට ඉහළින් පමණක් සීමා වේ.
///
/// `RangeTo` `..end` හි සියලු අගයන් `x < end` සමඟ අඩංගු වේ.
/// ආරම්භක ස්ථානයක් නොමැති නිසා එයට [`Iterator`] ලෙස සේවය කළ නොහැක.
///
/// # Examples
///
/// `..end` සින්ටැක්ස් යනු `RangeTo`:
///
/// ```
/// assert_eq!((..5), std::ops::RangeTo { end: 5 });
/// ```
///
/// එයට [`IntoIterator`] ක්‍රියාත්මක කිරීමක් නොමැත, එබැවින් ඔබට එය `for` පුඩුවක් තුළ කෙලින්ම භාවිතා කළ නොහැක.
/// මෙය සම්පාදනය නොකරයි:
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeTo<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..5 {
///     // ...
/// }
/// ```
///
/// [slicing index] ලෙස භාවිතා කරන විට, `end` මඟින් දැක්වෙන දර්ශකයට පෙර `RangeTo` සියළුම අරාව මූලද්‍රව්‍ය පෙත්තක් නිෂ්පාදනය කරයි.
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]); // මෙය `RangeTo` ය
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeTo"]
#[doc(alias = "..")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeTo<Idx> {
    /// (exclusive) පරාසයේ ඉහළ සීමාව.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeTo<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeTo<Idx> {
    /// `item` පරාසය තුළ තිබේ නම් `true` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..5).contains(&-1_000_000_000));
    /// assert!( (..5).contains(&4));
    /// assert!(!(..5).contains(&5));
    ///
    /// assert!( (..1.0).contains(&0.5));
    /// assert!(!(..1.0).contains(&f32::NAN));
    /// assert!(!(..f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// (`start..=end`) ට පහළින් සහ ඉහළින් ඇතුළත් පරාසයක්.
///
/// `RangeInclusive` `start..=end` හි `x >= start` සහ `x <= end` සමඟ සියලු අගයන් අඩංගු වේ.`start <= end` හැර එය හිස් ය.
///
/// මෙම iterator [fused] වේ, නමුත් පුනරාවර්තනය අවසන් වූ පසු `start` සහ `end` හි නිශ්චිත අගයන් **නිශ්චිතව දක්වා නැත** හැරෙන්නට [`.is_empty()`] `true` නැවත ලබා දෙනු ඇත.
///
///
/// [fused]: crate::iter::FusedIterator
/// [`.is_empty()`]: RangeInclusive::is_empty
///
/// # Examples
///
/// `start..=end` සින්ටැක්ස් යනු `RangeInclusive`:
///
/// ```
/// assert_eq!((3..=5), std::ops::RangeInclusive::new(3, 5));
/// assert_eq!(3 + 4 + 5, (3..=5).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]); // මෙය `RangeInclusive` ය
/// ```
///
///
#[lang = "RangeInclusive"]
#[doc(alias = "..=")]
#[derive(Clone, PartialEq, Eq, Hash)] // පිටපත් නොකෙරේ-#27186 බලන්න
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeInclusive<Idx> {
    // future හි නිරූපණය වෙනස් කිරීමට ඉඩ දීම සඳහා මෙහි ක්ෂේත්‍ර පොදු නොවන බව සලකන්න;විශේෂයෙන්, අපට start/end නිරාවරණය කළ හැකි අතර, (future/current) පුද්ගලික ක්ෂේත්‍ර වෙනස් නොකර ඒවා වෙනස් කිරීම වැරදි හැසිරීමට හේතු විය හැක, එබැවින් අපට එම ක්‍රමයට සහය දැක්වීමට අවශ්‍ය නැත.
    //
    //
    //
    //
    pub(crate) start: Idx,
    pub(crate) end: Idx,

    // මෙම ක්ෂේත්‍රය:
    //  - `false` ඉදිකිරීම මත
    //  - `false` පුනරාවර්තනය මූලද්‍රව්‍යයක් ලබා දී ඇති විට සහ නැවත ක්‍රියාකරු වෙහෙසට පත් නොවන විට
    //  - `true` පුනරාවර්තනය භාවිතා කිරීමට භාවිතා කරන විට
    //
    // PartialOrd මායිමක් හෝ විශේෂීකරණයකින් තොරව PartialEq සහ Hash සඳහා සහාය වීමට මෙය අවශ්‍ය වේ.
    pub(crate) exhausted: bool,
}

impl<Idx> RangeInclusive<Idx> {
    /// නව ඇතුළත් කිරීමේ පරාසයක් නිර්මාණය කරයි.`start..=end` ලිවීමට සමාන වේ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ops::RangeInclusive;
    ///
    /// assert_eq!(3..=5, RangeInclusive::new(3, 5));
    /// ```
    #[lang = "range_inclusive_new"]
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    #[rustc_promotable]
    #[rustc_const_stable(feature = "const_range_new", since = "1.32.0")]
    pub const fn new(start: Idx, end: Idx) -> Self {
        Self { start, end, exhausted: false }
    }

    /// (inclusive) පරාසයේ පහළ සීමාව ලබා දෙයි.
    ///
    /// පුනරාවර්තනය සඳහා ඇතුළත් කළ හැකි පරාසයක් භාවිතා කරන විට, පුනරාවර්තනය අවසන් වූ පසු `start()` සහ [`end()`] හි අගයන් නිශ්චිතව දක්වා නැත.
    /// ඇතුළත් කිරීමේ පරාසය හිස් දැයි තීරණය කිරීම සඳහා, `start() > end()` සංසන්දනය කිරීම වෙනුවට [`is_empty()`] ක්‍රමය භාවිතා කරන්න.
    ///
    /// Note: පරාසය වෙහෙසට පත්වීමෙන් පසුව මෙම ක්‍රමය මඟින් ලබා දුන් අගය නිශ්චිතව දක්වා නැත.
    ///
    /// [`end()`]: RangeInclusive::end
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).start(), &3);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn start(&self) -> &Idx {
        &self.start
    }

    /// (inclusive) පරාසයේ ඉහළ සීමාව ලබා දෙයි.
    ///
    /// පුනරාවර්තනය සඳහා ඇතුළත් කළ හැකි පරාසයක් භාවිතා කරන විට, පුනරාවර්තනය අවසන් වූ පසු [`start()`] සහ `end()` හි අගයන් නිශ්චිතව දක්වා නැත.
    /// ඇතුළත් කිරීමේ පරාසය හිස් දැයි තීරණය කිරීම සඳහා, `start() > end()` සංසන්දනය කිරීම වෙනුවට [`is_empty()`] ක්‍රමය භාවිතා කරන්න.
    ///
    /// Note: පරාසය වෙහෙසට පත්වීමෙන් පසුව මෙම ක්‍රමය මඟින් ලබා දුන් අගය නිශ්චිතව දක්වා නැත.
    ///
    /// [`start()`]: RangeInclusive::start
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).end(), &5);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn end(&self) -> &Idx {
        &self.end
    }

    /// `RangeInclusive` (පහළ මායිම, ඉහළ (inclusive) මායිම) බවට විනාශ කරයි.
    ///
    /// Note: පරාසය වෙහෙසට පත්වීමෙන් පසුව මෙම ක්‍රමය මඟින් ලබා දුන් අගය නිශ්චිතව දක්වා නැත.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).into_inner(), (3, 5));
    /// ```
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    pub fn into_inner(self) -> (Idx, Idx) {
        (self.start, self.end)
    }
}

impl RangeInclusive<usize> {
    /// `SliceIndex` ක්‍රියාත්මක කිරීම සඳහා සුවිශේෂී `Range` බවට පරිවර්තනය කරයි.
    /// `end == usize::MAX` සමඟ ගනුදෙනු කිරීම සඳහා අමතන්නා වගකිව යුතුය.
    #[inline]
    pub(crate) fn into_slice_range(self) -> Range<usize> {
        // අපි වෙහෙසට පත් නොවන්නේ නම්, අපට අවශ්‍ය වන්නේ `start..end + 1` පෙත්තක් කැපීමට ය.
        // අප වෙහෙසට පත්ව සිටී නම්, `end + 1..end + 1` සමඟ පෙති දැමීමෙන් අපට හිස් පරාසයක් ලබා ගත හැකි අතර එය තවමත් එම අන්ත ලක්ෂ්‍යය සඳහා සීමාවන් පරීක්ෂා කිරීමට යටත් වේ.
        //
        let exclusive_end = self.end + 1;
        let start = if self.exhausted { exclusive_end } else { self.start };
        start..exclusive_end
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        if self.exhausted {
            write!(fmt, " (exhausted)")?;
        }
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeInclusive<Idx> {
    /// `item` පරාසය තුළ තිබේ නම් `true` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).contains(&2));
    /// assert!( (3..=5).contains(&3));
    /// assert!( (3..=5).contains(&4));
    /// assert!( (3..=5).contains(&5));
    /// assert!(!(3..=5).contains(&6));
    ///
    /// assert!( (3..=3).contains(&3));
    /// assert!(!(3..=2).contains(&3));
    ///
    /// assert!( (0.0..=1.0).contains(&1.0));
    /// assert!(!(0.0..=1.0).contains(&f32::NAN));
    /// assert!(!(0.0..=f32::NAN).contains(&0.0));
    /// assert!(!(f32::NAN..=1.0).contains(&1.0));
    /// ```
    ///
    /// පුනරාවර්තනය අවසන් වූ පසු මෙම ක්‍රමය සෑම විටම `false` ලබා දෙයි:
    ///
    /// ```
    /// let mut r = 3..=5;
    /// assert!(r.contains(&3) && r.contains(&5));
    /// for _ in r.by_ref() {}
    /// // නිරවද්‍ය ක්ෂේත්‍ර අගයන් මෙහි නිශ්චිතව දක්වා නැත
    /// assert!(!r.contains(&3) && !r.contains(&5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// පරාසය තුළ අයිතම නොමැති නම් `true` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).is_empty());
    /// assert!(!(3..=3).is_empty());
    /// assert!( (3..=2).is_empty());
    /// ```
    ///
    /// දෙපැත්තටම අසමසම නම් පරාසය හිස් ය:
    ///
    /// ```
    /// assert!(!(3.0..=5.0).is_empty());
    /// assert!( (3.0..=f32::NAN).is_empty());
    /// assert!( (f32::NAN..=5.0).is_empty());
    /// ```
    ///
    /// පුනරාවර්තනය අවසන් වූ පසු මෙම ක්‍රමය `true` නැවත ලබා දෙයි:
    ///
    /// ```
    /// let mut r = 3..=5;
    /// for _ in r.by_ref() {}
    /// // නිරවද්‍ය ක්ෂේත්‍ර අගයන් මෙහි නිශ්චිතව දක්වා නැත
    /// assert!(r.is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    #[inline]
    pub fn is_empty(&self) -> bool {
        self.exhausted || !(self.start <= self.end)
    }
}

/// පරාසය (`..=end`) ට වඩා ඉහළින් සීමා කර ඇත.
///
/// `RangeToInclusive` `..=end` හි සියලු අගයන් `x <= end` සමඟ අඩංගු වේ.
/// ආරම්භක ස්ථානයක් නොමැති නිසා එයට [`Iterator`] ලෙස සේවය කළ නොහැක.
///
/// # Examples
///
/// `..=end` සින්ටැක්ස් යනු `RangeToInclusive`:
///
/// ```
/// assert_eq!((..=5), std::ops::RangeToInclusive{ end: 5 });
/// ```
///
/// එයට [`IntoIterator`] ක්‍රියාත්මක කිරීමක් නොමැත, එබැවින් ඔබට එය `for` පුඩුවක් තුළ කෙලින්ම භාවිතා කළ නොහැක.මෙය සම්පාදනය නොකරයි:
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeToInclusive<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..=5 {
///     // ...
/// }
/// ```
///
/// [slicing index] ලෙස භාවිතා කරන විට, `RangeToInclusive` විසින් `end` මඟින් දක්වා ඇති දර්ශකය ද ඇතුළුව සියලු අරාව මූලද්‍රව්‍ය පෙත්තක් නිෂ්පාදනය කරයි.
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]); // මෙය `RangeToInclusive` ය
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
///
#[lang = "RangeToInclusive"]
#[doc(alias = "..=")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeToInclusive<Idx> {
    /// (inclusive) පරාසයේ ඉහළ සීමාව
    #[stable(feature = "inclusive_range", since = "1.26.0")]
    pub end: Idx,
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeToInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeToInclusive<Idx> {
    /// `item` පරාසය තුළ තිබේ නම් `true` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..=5).contains(&-1_000_000_000));
    /// assert!( (..=5).contains(&5));
    /// assert!(!(..=5).contains(&6));
    ///
    /// assert!( (..=1.0).contains(&1.0));
    /// assert!(!(..=1.0).contains(&f32::NAN));
    /// assert!(!(..=f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

// RangeToInclusive<Idx>සිට impl කළ නොහැක <RangeTo<Idx>> මන්දයත් (..0).into() සමඟ පිටාර ගැලීම සිදුවිය හැකි බැවිනි
//

/// යතුරු පරාසයක අවසාන ලක්ෂ්‍යය.
///
/// # Examples
///
/// 'මායිම්' යනු පරාසයේ අන්ත ලක්ෂ්‍ය වේ:
///
/// ```
/// use std::ops::Bound::*;
/// use std::ops::RangeBounds;
///
/// assert_eq!((..100).start_bound(), Unbounded);
/// assert_eq!((1..12).start_bound(), Included(&1));
/// assert_eq!((1..12).end_bound(), Excluded(&12));
/// ```
///
/// [`BTreeMap::range`] සඳහා තර්කයක් ලෙස `මායිම් 'ටුපල් එකක් භාවිතා කිරීම.
/// බොහෝ අවස්ථාවන්හීදී, ඒ වෙනුවට පරාසයේ සින්ටැක්ස් (`1..5`) භාවිතා කිරීම වඩා හොඳ බව සලකන්න.
///
/// ```
/// use std::collections::BTreeMap;
/// use std::ops::Bound::{Excluded, Included, Unbounded};
///
/// let mut map = BTreeMap::new();
/// map.insert(3, "a");
/// map.insert(5, "b");
/// map.insert(8, "c");
///
/// for (key, value) in map.range((Excluded(3), Included(8))) {
///     println!("{}: {}", key, value);
/// }
///
/// assert_eq!(Some((&3, &"a")), map.range((Unbounded, Included(5))).next());
/// ```
///
/// [`BTreeMap::range`]: ../../std/collections/btree_map/struct.BTreeMap.html#method.range
#[stable(feature = "collections_bound", since = "1.17.0")]
#[derive(Clone, Copy, Debug, Hash, PartialEq, Eq)]
pub enum Bound<T> {
    /// ඇතුළත් බැඳීමක්.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Included(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// සුවිශේෂී බැඳීමක්.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Excluded(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// අසීමිත අන්ත ලක්ෂ්‍යයකි.මෙම දිශාවට බැඳීමක් නොමැති බව පෙන්නුම් කරයි.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Unbounded,
}

#[unstable(feature = "bound_as_ref", issue = "80996")]
impl<T> Bound<T> {
    /// `&Bound<T>` සිට `Bound<&T>` දක්වා පරිවර්තනය කරයි.
    #[inline]
    pub fn as_ref(&self) -> Bound<&T> {
        match *self {
            Included(ref x) => Included(x),
            Excluded(ref x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }

    /// `&mut Bound<T>` සිට `Bound<&T>` දක්වා පරිවර්තනය කරයි.
    #[inline]
    pub fn as_mut(&mut self) -> Bound<&mut T> {
        match *self {
            Included(ref mut x) => Included(x),
            Excluded(ref mut x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }
}

impl<T: Clone> Bound<&T> {
    /// මායිමේ අන්තර්ගතය ක්ලෝන කිරීමෙන් `Bound<&T>` සිට `Bound<T>` දක්වා සිතියම් ගත කරන්න.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(bound_cloned)]
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((1..12).start_bound(), Included(&1));
    /// assert_eq!((1..12).start_bound().cloned(), Included(1));
    /// ```
    #[unstable(feature = "bound_cloned", issue = "61356")]
    pub fn cloned(self) -> Bound<T> {
        match self {
            Bound::Unbounded => Bound::Unbounded,
            Bound::Included(x) => Bound::Included(x.clone()),
            Bound::Excluded(x) => Bound::Excluded(x.clone()),
        }
    }
}

/// `RangeBounds` `..`, `a..`, `..b`, `..=c`, `d..e`, හෝ `f..=g` වැනි පරාස සින්ටැක්ස් මගින් නිපදවන Rust හි සාදන ලද පරාස වර්ග මඟින් ක්‍රියාත්මක වේ.
///
#[stable(feature = "collections_range", since = "1.28.0")]
pub trait RangeBounds<T: ?Sized> {
    /// ආරම්භක දර්ශකය බැඳී ඇත.
    ///
    /// ආරම්භක අගය `Bound` ලෙස ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((..10).start_bound(), Unbounded);
    /// assert_eq!((3..10).start_bound(), Included(&3));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn start_bound(&self) -> Bound<&T>;

    /// අවසන් දර්ශකය බැඳී ඇත.
    ///
    /// අවසාන අගය `Bound` ලෙස ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((3..).end_bound(), Unbounded);
    /// assert_eq!((3..10).end_bound(), Excluded(&10));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn end_bound(&self) -> Bound<&T>;

    /// `item` පරාසය තුළ තිබේ නම් `true` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// ((3..5).contains(&4));
    /// assert!(!(3..5).contains(&2));
    ///
    /// ((0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    #[stable(feature = "range_contains", since = "1.35.0")]
    fn contains<U>(&self, item: &U) -> bool
    where
        T: PartialOrd<U>,
        U: ?Sized + PartialOrd<T>,
    {
        (match self.start_bound() {
            Included(ref start) => *start <= item,
            Excluded(ref start) => *start < item,
            Unbounded => true,
        }) && (match self.end_bound() {
            Included(ref end) => item <= *end,
            Excluded(ref end) => item < *end,
            Unbounded => true,
        })
    }
}

use self::Bound::{Excluded, Included, Unbounded};

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T: ?Sized> RangeBounds<T> for RangeFull {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        if self.exhausted {
            // අනුකාරකය අවසන් වූ විට, අපට සාමාන්‍යයෙන් ආරම්භය==අවසානය ඇත, නමුත් අපට අවශ්‍ය වන්නේ පරාසය හිස්ව පෙනෙන්නට තිබීමයි.
            //
            Excluded(&self.end)
        } else {
            Included(&self.end)
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for (Bound<T>, Bound<T>) {
    fn start_bound(&self) -> Bound<&T> {
        match *self {
            (Included(ref start), _) => Included(start),
            (Excluded(ref start), _) => Excluded(start),
            (Unbounded, _) => Unbounded,
        }
    }

    fn end_bound(&self) -> Bound<&T> {
        match *self {
            (_, Included(ref end)) => Included(end),
            (_, Excluded(ref end)) => Excluded(end),
            (_, Unbounded) => Unbounded,
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<'a, T: ?Sized + 'a> RangeBounds<T> for (Bound<&'a T>, Bound<&'a T>) {
    fn start_bound(&self) -> Bound<&T> {
        self.0
    }

    fn end_bound(&self) -> Bound<&T> {
        self.1
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}