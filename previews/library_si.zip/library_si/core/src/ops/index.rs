/// වෙනස් කළ නොහැකි සන්දර්භය තුළ (`container[index]`) මෙහෙයුම් සුචිගත කිරීම සඳහා භාවිතා කරයි.
///
/// `container[index]` ඇත්ත වශයෙන්ම `*container.index(index)` සඳහා සින්ටැක්ටික් සීනි වේ, නමුත් වෙනස් කළ නොහැකි අගයක් ලෙස භාවිතා කළ විට පමණි.
/// විකෘති අගයක් ඉල්ලා සිටී නම්, ඒ වෙනුවට [`IndexMut`] භාවිතා වේ.
/// `value` වර්ගය [`Copy`] ක්‍රියාත්මක කරන්නේ නම් මෙය `let value = v[index]` වැනි හොඳ දේවලට ඉඩ දෙයි.
///
/// # Examples
///
/// පහත උදාහරණයෙන් කියවීමට පමණක් ඇති `NucleotideCount` බහාලුමක් මත `Index` ක්‍රියාත්මක වන අතර දර්ශක සින්ටැක්ස් සමඟ තනි ගණනය කිරීම් ලබා ගත හැකිය.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// සුචිගත කිරීමෙන් පසු ආපසු එන වර්ගය.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// සුචිගත කිරීමේ (`container[index]`) මෙහෙයුම සිදු කරයි.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// විකෘති සන්දර්භයන් තුළ (`container[index]`) මෙහෙයුම් සුචිගත කිරීම සඳහා භාවිතා වේ.
///
/// `container[index]` ඇත්ත වශයෙන්ම `*container.index_mut(index)` සඳහා සින්ටැක්ටික් සීනි, නමුත් විකෘති අගයක් ලෙස භාවිතා කළ විට පමණි.
/// වෙනස් කළ නොහැකි අගයක් ඉල්ලා සිටියහොත්, ඒ වෙනුවට [`Index`] trait භාවිතා වේ.
/// මෙය `v[index] = value` වැනි හොඳ දේවලට ඉඩ දෙයි.
///
/// # Examples
///
/// පැති දෙකක් ඇති `Balance` ව්‍යුහයක් ඉතා සරල ලෙස ක්‍රියාත්මක කිරීම, එහිදී එක් එක් විකෘති හා වෙනස් කළ නොහැකි ලෙස සුචිගත කළ හැකිය.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // මෙම අවස්ථාවේ දී, `balance[Side::Right]` යනු `*balance.index(Side::Right)` සඳහා සීනි වේ, මන්ද අප කියවන්නේ*`balance[Side::Right]` පමණක් වන බැවින් එය ලිවීම නොවේ.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // කෙසේ වෙතත්, මේ අවස්ථාවේ දී `balance[Side::Left]` යනු `*balance.index_mut(Side::Left)` සඳහා සීනි වේ, මන්ද අප ලියන්නේ `balance[Side::Left]` ය.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// විකෘති සුචිගත කිරීමේ (`container[index]`) මෙහෙයුම සිදු කරයි.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}