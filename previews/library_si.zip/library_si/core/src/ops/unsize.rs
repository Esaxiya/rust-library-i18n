use crate::marker::Unsize;

/// Trait එයින් ඇඟවෙන්නේ මෙය එක් දර්ශකයක් හෝ එතීමකි, එහිදී දර්ශකයේ ලකුණු කිරීම සිදු කළ හැකිය.
///
/// වැඩි විස්තර සඳහා [DST coercion RFC][dst-coerce] සහ [the nomicon entry on coercion][nomicon-coerce] බලන්න.
///
/// බිල්ඩින් පොයින්ටර් වර්ග සඳහා, සිහින් පොයින්ටරයක සිට මේද පොයින්ටරයක් බවට පරිවර්තනය කිරීමෙන් `T: Unsize<U>` නම් `T` වෙත යොමු කරන්නන් `U` වෙත යොමු කරයි.
///
/// අභිරුචි වර්ග සඳහා, මෙහි බලහත්කාරය ක්‍රියාත්මක වන්නේ `Foo<T>` සිට `Foo<U>` දක්වා බල කිරීමෙනි.
/// එවැනි ආවේගයක් ලිවිය හැක්කේ `Foo<T>` සතුව `T` සම්බන්ධ වන එකම ෆැන්ටම්ඩේටා නොවන ක්ෂේත්‍රයක් තිබේ නම් පමණි.
/// එම ක්ෂේත්‍රයේ වර්ගය `Bar<T>` නම්, `CoerceUnsized<Bar<U>> for Bar<T>` ක්‍රියාත්මක කිරීම පැවතිය යුතුය.
/// `Bar<T>` ක්ෂේත්‍රය `Bar<U>` වෙතට බල කිරීමෙන් සහ `Foo<T>` සිට ඉතිරි ක්ෂේත්‍ර පුරවා `Foo<U>` නිර්මාණය කිරීමෙන් බලහත්කාරය ක්‍රියාත්මක වේ.
/// මෙය effectively ලදායි ලෙස දර්ශක ක්ෂේත්‍රයකට සරඹ කර එය බල කරනු ඇත.
///
/// සාමාන්‍යයෙන්, ස්මාර්ට් පොයින්ටර් සඳහා ඔබ `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` ක්‍රියාත්මක කරනු ඇත, විකල්ප `?Sized` `T` මත බැඳී ඇත.
/// `Cell<T>` සහ `RefCell<T>` වැනි `T` කෙලින්ම කාවැද්දූ ආවරණ වර්ග සඳහා, ඔබට කෙලින්ම `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` ක්‍රියාත්මක කළ හැකිය.
///
/// මෙමඟින් `Cell<Box<T>>` වැනි වර්ගවල බලහත්කාරය වැඩ කිරීමට ඉඩ දෙනු ඇත.
///
/// [`Unsize`][unsize] දර්ශක පිටුපස තිබේ නම් ඩීඑස්ටී වෙත බල කළ හැකි වර්ග සලකුණු කිරීමට භාවිතා කරයි.එය සම්පාදකයා විසින් ස්වයංක්‍රීයව ක්‍රියාත්මක කරයි.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut ටී-> &mut යූ
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut ටී-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut ටී-> * විකෘති යූ
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut ටී-> * const යූ
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// මෙය වස්තු ආරක්ෂාව සඳහා භාවිතා කරනු ලැබේ, ක්‍රමයක ග්‍රාහක වර්ගය යැවිය හැකිදැයි පරීක්ෂා කිරීම.
///
/// trait ක්‍රියාත්මක කිරීම සඳහා උදාහරණයක්:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut ටී-> &mut යූ
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U.
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U.
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}