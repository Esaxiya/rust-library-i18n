/// `?` ක්‍රියාකරුගේ හැසිරීම රිසිකරණය කිරීම සඳහා trait.
///
/// `Try` ක්‍රියාත්මක කරන වර්ගයක් යනු success/failure ද්විභාෂාවකට අනුව එය බැලීමට කැනොනිකල් ක්‍රමයක් ඇති එකකි.
/// මෙම trait පවත්නා අවස්ථාවකින් එම සාර්ථකත්වය හෝ අසාර්ථක අගයන් උකහා ගැනීමට සහ සාර්ථක හෝ අසාර්ථක අගයකින් නව අවස්ථාවක් නිර්මාණය කිරීමට ඉඩ දෙයි.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// සාර්ථක ලෙස සලකන විට මෙම අගය වර්ගය.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// අසමත් යැයි සලකන විට මෙම අගය වර්ගය.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// "?" ක්‍රියාකරුට අදාළ වේ.`Ok(t)` නැවත පැමිණීම යනු ක්‍රියාත්මක කිරීම සාමාන්‍යයෙන් ඉදිරියට යා යුතු අතර `?` හි ප්‍රති result ලය `t` අගය වේ.
    /// `Err(e)` නැවත පැමිණීම යන්නෙන් අදහස් වන්නේ ක්‍රියාත්මක කිරීම branch අභ්‍යන්තරයේ වටකර ඇති `catch` වෙතට හෝ ශ්‍රිතයෙන් ආපසු යා යුතු බවයි.
    ///
    /// `Err(e)` ප්‍රති result ලයක් ආපසු ලබා දෙන්නේ නම්, සංවෘත විෂය පථයේ ප්‍රතිලාභ වර්ගයට `e` අගය "wrapped" වනු ඇත (එයම `Try` ක්‍රියාත්මක කළ යුතුය).
    ///
    /// නිශ්චිතවම, `X::from_error(From::from(e))` අගය ආපසු ලබා දෙනු ලැබේ, එහිදී `X` යනු සංවෘත ශ්‍රිතයේ ආපසු වර්ගයයි.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// සංයුක්ත ප්‍රති .ලය තැනීම සඳහා දෝෂ අගයක් ඔතා.
    /// උදාහරණයක් ලෙස, `Result::Err(x)` සහ `Result::from_error(x)` සමාන වේ.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// සංයුක්ත ප්‍රති .ලය තැනීම සඳහා හරි අගයක් ඔතා.
    /// උදාහරණයක් ලෙස, `Result::Ok(x)` සහ `Result::from_ok(x)` සමාන වේ.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}