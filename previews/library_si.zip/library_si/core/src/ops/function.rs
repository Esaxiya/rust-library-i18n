/// වෙනස් කළ නොහැකි ග්‍රාහකයක් ගන්නා ඇමතුම් ක්‍රියාකරුගේ අනුවාදය.
///
/// `Fn` හි අවස්ථා විකෘති තත්වයකින් තොරව නැවත නැවත හැඳින්විය හැකිය.
///
/// *මෙම trait (`Fn`) [function pointers] (`fn`) සමඟ පටලවා නොගත යුතුය.*
///
/// `Fn` ග්‍රහණය කර ඇති විචල්‍යයන් සඳහා වෙනස් කළ නොහැකි යොමු කිරීම් පමණක් වන අතර කිසිවක් ග්‍රහණය කර නොගන්නා (safe) [function pointers] (සමහර අවවාද සමඟ, වැඩි විස්තර සඳහා ඒවායේ ප්‍රලේඛනය බලන්න).
///
/// මීට අමතරව, `Fn` ක්‍රියාත්මක කරන ඕනෑම වර්ගයක `F` සඳහා, `&F` `Fn` ද ක්‍රියාත්මක කරයි.
///
/// [`FnMut`] සහ [`FnOnce`] යන දෙකම `Fn` හි සුපිරි මාර්ග බැවින්, `Fn` හි ඕනෑම අවස්ථාවක් [`FnMut`] හෝ [`FnOnce`] අපේක්ෂා කරන පරාමිතියක් ලෙස භාවිතා කළ හැකිය.
///
/// ශ්‍රිතයට සමාන ආකාරයේ පරාමිතියක් පිළිගැනීමට අවශ්‍ය වන විට `Fn` සීමාවක් ලෙස භාවිතා කරන්න. එය නැවත නැවත හා විකෘති තත්වයකින් තොරව ඇමතීමට අවශ්‍ය වේ (උදා: එය සමගාමීව ඇමතීමේදී).
/// ඔබට එවැනි දැඩි අවශ්‍යතා අවශ්‍ය නොවේ නම්, සීමාවන් ලෙස [`FnMut`] හෝ [`FnOnce`] භාවිතා කරන්න.
///
/// මෙම මාතෘකාව පිළිබඳ වැඩි විස්තර සඳහා [chapter on closures in *The Rust Programming Language*][book] බලන්න.
///
/// `Fn` traits සඳහා විශේෂ සින්ටැක්ස් ද සැලකිල්ලට ගත යුතුය (උදා
/// `Fn(usize, bool) -> usize`).මෙහි තාක්ෂණික විස්තර ගැන උනන්දුවක් දක්වන අයට [the relevant section in the *Rustonomicon*][nomicon] වෙත යොමු විය හැකිය.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## වසා දැමීමක් කැඳවීම
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## `Fn` පරාමිතියක් භාවිතා කිරීම
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // එවිට regex හට එම `&str: !FnMut` මත විශ්වාසය තැබිය හැකිය
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// ඇමතුම් මෙහෙයුම සිදු කරයි.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// විකෘති ග්‍රාහකයක් ගන්නා ඇමතුම් ක්‍රියාකරුගේ අනුවාදය.
///
/// `FnMut` හි අවස්ථා නැවත නැවත හැඳින්විය හැකි අතර එය විකෘති තත්වයට පත්විය හැකිය.
///
/// `FnMut` ග්‍රහණය කරන ලද විචල්‍යයන් සඳහා විකෘති යොමු කිරීම් මෙන්ම [`Fn`], උදා: (safe) [function pointers] ක්‍රියාත්මක කරන සියලුම වර්ගයන් (`FnMut` යනු [`Fn`] හි සුපිරි මාර්ගයක් බැවින්) ස්වයංක්‍රීයව ක්‍රියාත්මක වේ.
/// මීට අමතරව, `FnMut` ක්‍රියාත්මක කරන ඕනෑම වර්ගයක `F` සඳහා, `&mut F` `FnMut` ද ක්‍රියාත්මක කරයි.
///
/// [`FnOnce`] යනු `FnMut` හි සුපිරි මාර්ගයක් බැවින්, `FnMut` හි ඕනෑම අවස්ථාවක් [`FnOnce`] අපේක්ෂා කරන තැනක භාවිතා කළ හැකි අතර, [`Fn`] යනු `FnMut` හි උප සිරැසියක් වන බැවින්, `FnMut` අපේක්ෂා කරන තැන [`Fn`] හි ඕනෑම අවස්ථාවක් භාවිතා කළ හැකිය.
///
/// ක්‍රියාකාරීත්වයට සමාන වර්ගයක පරාමිතියක් පිළිගැනීමට සහ එය විකෘති තත්වයට පත් කිරීමට ඉඩ දෙන අතරම නැවත නැවත ඇමතීමට අවශ්‍ය වූ විට `FnMut` සීමාවක් ලෙස භාවිතා කරන්න.
/// පරාමිතිය විකෘති තත්වයට පත්වීමට ඔබට අවශ්‍ය නැතිනම්, [`Fn`] සීමාවක් ලෙස භාවිතා කරන්න;ඔබට එය නැවත නැවත ඇමතීමට අවශ්‍ය නැතිනම්, [`FnOnce`] භාවිතා කරන්න.
///
/// මෙම මාතෘකාව පිළිබඳ වැඩි විස්තර සඳහා [chapter on closures in *The Rust Programming Language*][book] බලන්න.
///
/// `Fn` traits සඳහා විශේෂ සින්ටැක්ස් ද සැලකිල්ලට ගත යුතුය (උදා
/// `Fn(usize, bool) -> usize`).මෙහි තාක්ෂණික විස්තර ගැන උනන්දුවක් දක්වන අයට [the relevant section in the *Rustonomicon*][nomicon] වෙත යොමු විය හැකිය.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## විකෘති ලෙස අල්ලා ගැනීමේ වසා දැමීමක් කැඳවීම
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## `FnMut` පරාමිතියක් භාවිතා කිරීම
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // එවිට regex හට එම `&str: !FnMut` මත විශ්වාසය තැබිය හැකිය
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// ඇමතුම් මෙහෙයුම සිදු කරයි.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// අතුරු වටිනාකම් ලබන්නා ගන්නා ඇමතුම් ක්‍රියාකරුගේ අනුවාදය.
///
/// `FnOnce` හි අවස්ථා හැඳින්විය හැකි නමුත් කිහිප වතාවක්ම ඇමතිය නොහැක.මේ නිසා, වර්ගයක් ගැන දන්නා එකම දෙය නම් එය `FnOnce` ක්‍රියාත්මක කිරීම නම්, එය හැඳින්විය හැක්කේ එක් වරක් පමණි.
///
/// `FnOnce` අල්ලා ගන්නා ලද විචල්‍යයන් මෙන්ම [`FnMut`], උදා: (safe) [function pointers] (`FnOnce` යනු [`FnMut`] හි සුපිරි මාර්ගයක් බැවින්) ක්‍රියාත්මක කරන සියලුම වර්ගයන් ස්වයංක්‍රීයව ක්‍රියාත්මක වේ.
///
///
/// [`Fn`] සහ [`FnMut`] යන දෙකම `FnOnce` හි උප සිරැසි වන බැවින්, `FnOnce` හෝ [`FnMut`] හි ඕනෑම අවස්ථාවක් `FnOnce` අපේක්ෂා කරන තැන භාවිතා කළ හැකිය.
///
/// ශ්‍රිතයට සමාන ආකාරයේ පරාමිතියක් පිළිගැනීමට අවශ්‍ය වූ විට එය එක් වරක් පමණක් ඇමතීමට අවශ්‍ය වූ විට `FnOnce` සීමාවක් ලෙස භාවිතා කරන්න.
/// ඔබට නැවත නැවතත් පරාමිතිය ඇමතීමට අවශ්‍ය නම්, සීමාවක් ලෙස [`FnMut`] භාවිතා කරන්න;තත්වය විකෘති නොකිරීමට ඔබට එය අවශ්‍ය නම්, [`Fn`] භාවිතා කරන්න.
///
/// මෙම මාතෘකාව පිළිබඳ වැඩි විස්තර සඳහා [chapter on closures in *The Rust Programming Language*][book] බලන්න.
///
/// `Fn` traits සඳහා විශේෂ සින්ටැක්ස් ද සැලකිල්ලට ගත යුතුය (උදා
/// `Fn(usize, bool) -> usize`).මෙහි තාක්ෂණික විස්තර ගැන උනන්දුවක් දක්වන අයට [the relevant section in the *Rustonomicon*][nomicon] වෙත යොමු විය හැකිය.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## `FnOnce` පරාමිතියක් භාවිතා කිරීම
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` එහි ග්‍රහණය කරගත් විචල්‍යයන් පරිභෝජනය කරයි, එබැවින් එය එක් වරකට වඩා ධාවනය කළ නොහැක.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // `func()` නැවත කැඳවීමට උත්සාහ කිරීමෙන් `func` සඳහා `use of moved value` දෝෂයක් ඇතිවේ.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` මෙම අවස්ථාවේදී තවදුරටත් ආයාචනා කළ නොහැක
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // එවිට regex හට එම `&str: !FnMut` මත විශ්වාසය තැබිය හැකිය
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// ඇමතුම් ක්‍රියාකරු භාවිතා කිරීමෙන් පසු ආපසු එන වර්ගය.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// ඇමතුම් මෙහෙයුම සිදු කරයි.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}