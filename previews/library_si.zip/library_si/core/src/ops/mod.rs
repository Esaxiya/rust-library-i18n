//! අධි බර පැටවිය හැකි ක්‍රියාකරුවන්.
//!
//! මෙම traits ක්‍රියාත්මක කිරීමෙන් ඇතැම් ක්‍රියාකරුවන් අධික ලෙස පැටවීමට ඔබට ඉඩ සලසයි.
//!
//! මෙම traits වලින් සමහරක් ආනයනය කරනු ලබන්නේ prelude, එබැවින් ඒවා සෑම Rust වැඩසටහනකින්ම ලබාගත හැකිය.traits හි සහාය ඇති ක්‍රියාකරුවන්ට පමණක් අධික ලෙස පැටවිය හැකිය.
//! නිදසුනක් ලෙස, එකතු කිරීමේ ක්‍රියාකරු (`+`), [`Add`] trait හරහා අධික ලෙස පැටවිය හැකිය, නමුත් පැවරුම් ක්‍රියාකරු (`=`) හට trait හි පිටුබලය නොමැති බැවින්, එහි අර්ථ නිරූපණය අධික ලෙස පැටවීමේ ක්‍රමයක් නොමැත.
//! මීට අමතරව, මෙම මොඩියුලය නව ක්‍රියාකරුවන් නිර්මාණය කිරීම සඳහා කිසිදු යාන්ත්‍රණයක් සපයන්නේ නැත.
//! ගතිලක්ෂණ රහිතව පැටවීම හෝ අභිරුචි ක්‍රියාකරුවන් අවශ්‍ය නම්, ඔබ Rust හි වාක්‍ය ඛණ්ඩය දීර් extend කිරීම සඳහා මැක්‍රෝස් හෝ සම්පාදක ප්ලගීන දෙස බැලිය යුතුය.
//!
//! traits ක්‍රියාකරුගේ සුපුරුදු අර්ථයන් සහ [operator precedence] මතක තබා ගනිමින් අදාළ සන්දර්භය තුළ පුදුමයට පත් නොවිය යුතුය.
//! උදාහරණයක් ලෙස, [`Mul`] ක්‍රියාත්මක කිරීමේදී, මෙහෙයුමට ගුණ කිරීම සඳහා යම් සමානකමක් තිබිය යුතුය (සහ ඇසෝසියේටිව් වැනි අපේක්ෂිත ගුණාංග බෙදා ගන්න).
//!
//! `&&` සහ `||` ක්‍රියාකරුවන්ගේ කෙටි පරිපථය, එනම්, ඔවුන් ඔවුන්ගේ දෙවන ක්‍රියාකාරිත්වය ඇගයීමට ලක් කරන්නේ එය ප්‍රති .ලයට දායක වන්නේ නම් පමණි.මෙම හැසිරීම traits මගින් බලාත්මක කළ නොහැකි බැවින්, අධික බර පැටවිය හැකි ක්‍රියාකරුවන් ලෙස `&&` සහ `||` සහාය නොදක්වයි.
//!
//! බොහෝ ක්‍රියාකරුවන් ඔවුන්ගේ ක්‍රියාකාරිත්වය අගය අනුව ගනී.සාදන ලද වර්ග සම්බන්ධ වන සාමාන්‍ය නොවන සන්දර්භය තුළ, මෙය සාමාන්‍යයෙන් ගැටළුවක් නොවේ.
//! කෙසේ වෙතත්, මෙම ක්‍රියාකරුවන් සාමාන්‍ය කේතයෙන් භාවිතා කිරීම, ක්‍රියාකරුවන්ට ඒවා පරිභෝජනයට ඉඩ හැරීමට වඩා අගයන් නැවත භාවිතා කළ යුතු නම් යම් අවධානයක් අවශ්‍ය වේ.එක් විකල්පයක් වන්නේ ඉඳහිට [`clone`] භාවිතා කිරීමයි.
//! තවත් විකල්පයක් වන්නේ යොමු කිරීම් සඳහා අතිරේක ක්‍රියාකරු ක්‍රියාත්මක කිරීම් සපයන වර්ග මත රඳා සිටීමයි.
//! උදාහරණයක් ලෙස, එකතු කිරීම සඳහා සහය දැක්විය යුතු පරිශීලක-නිර්වචනය කරන ලද `T` වර්ගයක් සඳහා, බොහෝ විට `T` සහ `&T` යන දෙකම traits [`Add<T>`][`Add`] සහ [`Add<&T>`][`Add`] ක්‍රියාත්මක කිරීම හොඳ අදහසකි, එවිට අනවශ්‍ය ක්ලෝනකරණයකින් තොරව සාමාන්‍ය කේතය ලිවිය හැකිය.
//!
//!
//! # Examples
//!
//! මෙම උදාහරණය [`Add`] සහ [`Sub`] ක්‍රියාත්මක කරන `Point` ව්‍යුහයක් නිර්මාණය කරයි, පසුව `ලක්ෂ්‍ය 'දෙකක් එකතු කිරීම හා අඩු කිරීම පෙන්නුම් කරයි.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! උදාහරණ ක්‍රියාත්මක කිරීම සඳහා එක් එක් trait සඳහා ප්‍රලේඛනය බලන්න.
//!
//! [`Fn`], [`FnMut`], සහ [`FnOnce`] traits ක්‍රියාත්මක කරනු ලබන්නේ ශ්‍රිත වැනි ආයාචනා කළ හැකි වර්ග මගිනි.[`Fn`] `&self`, [`FnMut`] `&mut self` සහ [`FnOnce`] `self` ගනී.
//! මේවා උදාහරණයකට ආයාචනා කළ හැකි ක්‍රම තුනකට අනුරූප වේ: ඇමතුමකින්-යොමු කිරීම, ඇමතුම අනුව විකෘති-යොමු කිරීම, සහ ඇමතුම් අනුව වටිනාකම.
//! මෙම traits හි වඩාත් පොදු භාවිතය වන්නේ ශ්‍රිත හෝ වසා දැමීම් තර්ක ලෙස ගන්නා ඉහළ මට්ටමේ ශ්‍රිතයන්ට මායිම් ලෙස ක්‍රියා කිරීමයි.
//!
//! [`Fn`] පරාමිතියක් ලෙස ගැනීම:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! [`FnMut`] පරාමිතියක් ලෙස ගැනීම:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! [`FnOnce`] පරාමිතියක් ලෙස ගැනීම:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` එහි ග්‍රහණය කරගත් විචල්‍යයන් පරිභෝජනය කරයි, එබැවින් එය එක් වරකට වඩා ධාවනය කළ නොහැක
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // `func()` නැවත කැඳවීමට උත්සාහ කිරීමෙන් `func` සඳහා `use of moved value` දෝෂයක් ඇතිවේ
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` මෙම අවස්ථාවේදී තවදුරටත් ආයාචනා කළ නොහැක
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;