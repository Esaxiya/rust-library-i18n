//! `Result` වර්ගය සමඟ හැසිරවීමේ දෝෂයකි.
//!
//! [`Result<T, E>`][`Result`] දෝෂ නැවත පැමිණීමට සහ ප්‍රචාරය කිරීමට භාවිතා කරන වර්ගයයි.
//! එය [`Ok(T)`] ප්‍රභේදයන්ගෙන් සමන්විත වන අතර, සාර්ථකත්වය නියෝජනය කරන සහ වටිනාකමක් අඩංගු වන අතර [`Err(E)`], දෝෂය නිරූපණය කරන අතර දෝෂ අගයක් අඩංගු වේ.
//!
//! ```
//! # #[allow(dead_code)]
//! enum Result<T, E> {
//!    Ok(T),
//!    Err(E),
//! }
//! ```
//!
//! දෝෂ අපේක්ෂා කළ විට සහ නැවත ලබා ගත හැකි සෑම අවස්ථාවකම කාර්යයන් [`Result`] ලබා දෙයි.`std` crate හි, [`Result`] වඩාත් කැපී පෙනෙන ලෙස [I/O](../../std/io/index.html) සඳහා භාවිතා වේ.
//!
//! [`Result`] ආපසු ලබා දෙන සරල ශ්‍රිතයක් අර්ථ දැක්විය හැකි අතර එසේ භාවිතා කළ හැකිය:
//!
//! ```
//! #[derive(Debug)]
//! enum Version { Version1, Version2 }
//!
//! fn parse_version(header: &[u8]) -> Result<Version, &'static str> {
//!     match header.get(0) {
//!         None => Err("invalid header length"),
//!         Some(&1) => Ok(Version::Version1),
//!         Some(&2) => Ok(Version::Version2),
//!         Some(_) => Err("invalid version"),
//!     }
//! }
//!
//! let version = parse_version(&[1, 2, 3, 4]);
//! match version {
//!     Ok(v) => println!("working with version: {:?}", v),
//!     Err(e) => println!("error parsing header: {:?}", e),
//! }
//! ```
//!
//! [`ප්‍රති ult ල] හි රටා ගැලපීම සරල අවස්ථා සඳහා පැහැදිලි සහ සරල ය, නමුත් [`Result`] සමහර පහසු ක්‍රම සමඟ එන අතර එය සමඟ වැඩ කිරීම වඩාත් සංක්ෂිප්ත වේ.
//!
//! ```
//! let good_result: Result<i32, i32> = Ok(10);
//! let bad_result: Result<i32, i32> = Err(10);
//!
//! // `is_ok` සහ `is_err` ක්‍රම ඔවුන් කියන දේ කරයි.
//! assert!(good_result.is_ok() && !good_result.is_err());
//! assert!(bad_result.is_err() && !bad_result.is_ok());
//!
//! // `map` `Result` පරිභෝජනය කර තවත් එකක් නිෂ්පාදනය කරයි.
//! let good_result: Result<i32, i32> = good_result.map(|i| i + 1);
//! let bad_result: Result<i32, i32> = bad_result.map(|i| i - 1);
//!
//! // ගණනය කිරීම දිගටම කරගෙන යාමට `and_then` භාවිතා කරන්න.
//! let good_result: Result<bool, i32> = good_result.and_then(|i| Ok(i == 11));
//!
//! // දෝෂය හැසිරවීමට `or_else` භාවිතා කරන්න.
//! let bad_result: Result<i32, i32> = bad_result.or_else(|i| Ok(i + 20));
//!
//! // ප්රති result ලය පරිභෝජනය කර `unwrap` සමඟ අන්තර්ගතය නැවත ලබා දෙන්න.
//! let final_awesome_result = good_result.unwrap();
//! ```
//!
//! # ප්‍රති Results ල භාවිතා කළ යුතුය
//!
//! දෝෂ දැක්වීමට ප්‍රතිලාභ අගයන් භාවිතා කිරීමේ පොදු ගැටළුවක් නම් ප්‍රතිලාභ අගය නොසලකා හැරීම පහසු වන අතර එමඟින් දෝෂය හැසිරවීමට අපොහොසත් වේ.
//! [`Result`] `#[must_use]` ගුණාංගය සමඟ විවරණය කර ඇති අතර, එමඟින් ප්‍රති ult ල අගයක් නොසලකා හරින විට සම්පාදකයාට අනතුරු ඇඟවීමක් කරනු ඇත.
//! මෙය [`Result`] විශේෂයෙන් ප්‍රයෝජනවත් වන්නේ දෝෂ ඇතිවිය හැකි නමුත් වෙනත් ආකාරයකින් ප්‍රයෝජනවත් අගයක් ලබා නොදෙන කාර්යයන් සමඟ ය.
//!
//! [`Write`] trait විසින් I/O වර්ග සඳහා අර්ථ දක්වා ඇති [`write_all`] ක්‍රමය සලකා බලන්න:
//!
//! ```
//! use std::io;
//!
//! trait Write {
//!     fn write_all(&mut self, bytes: &[u8]) -> Result<(), io::Error>;
//! }
//! ```
//!
//! *Note: [`Write`] හි සත්‍ය අර්ථ දැක්වීම [`io::Result`] භාවිතා කරයි, එය [`ප්‍රති ult ලය`] සඳහා සමාන පදයකි<T, `[`io: :Error`]`>`.*
//!
//! මෙම ක්‍රමය මඟින් වටිනාකමක් නොලැබෙන නමුත් ලිවීම අසමත් විය හැකිය.දෝෂ නඩුව හැසිරවීම ඉතා වැදගත් වන අතර * මේ වගේ දෙයක් ලිවීමට නොවේ:
//!
//! ```no_run
//! # #![allow(unused_must_use)] // \o/
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! // `write_all` දෝෂ තිබේ නම්, අපි කිසි විටෙකත් නොදනිමු, මන්ද ප්‍රතිලාභ අගය නොසලකා හරිනු ලැබේ.
//! //
//! file.write_all(b"important message");
//! ```
//!
//! ඔබ එය Rust හි ලිවුවහොත්, සම්පාදකයා ඔබට අනතුරු ඇඟවීමක් ලබා දෙනු ඇත (පෙරනිමියෙන්, `unused_must_use` lint මගින් පාලනය වේ).
//!
//! ඔබට ඒ වෙනුවට, ඔබට දෝෂය හැසිරවීමට අවශ්‍ය නැතිනම්, [`expect`] සමඟ සාර්ථකත්වය තහවුරු කරන්න.
//! ලිවීම අසමත් වුවහොත් මෙය panic වනු ඇත.
//!
//! ```no_run
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! file.write_all(b"important message").expect("failed to write message");
//! ```
//!
//! ඔබට සාර්ථකත්වය තහවුරු කළ හැකිය:
//!
//! ```no_run
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # let mut file = File::create("valuable_data.txt").unwrap();
//! assert!(file.write_all(b"important message").is_ok());
//! ```
//!
//! නැතහොත් [`?`] සමඟ ඇමතුම් තොගයේ දෝෂය ප්‍රචාරය කරන්න:
//!
//! ```
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # use std::io;
//! # #[allow(dead_code)]
//! fn write_message() -> io::Result<()> {
//!     let mut file = File::create("valuable_data.txt")?;
//!     file.write_all(b"important message")?;
//!     Ok(())
//! }
//! ```
//!
//! # ප්‍රශ්න සලකුණු ක්‍රියාකරු, `?`
//!
//! [`Result`] වර්ගය නැවත ලබා දෙන බොහෝ කාර්යයන් කැඳවන කේත ලිවීමේදී, දෝෂ හැසිරවීම වෙහෙසකාරී විය හැකිය.
//! ප්‍රශ්න සලකුණු ක්‍රියාකරු, [`?`], ඇමතුම් තොගය දක්වා දෝෂ ප්‍රචාරණය කිරීමේ බොයිලේරු කිහිපයක් සඟවයි.
//!
//! එය මෙය ප්‍රතිස්ථාපනය කරයි:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     // දෝෂය මත නැවත පැමිණීම
//!     let mut file = match File::create("my_best_friends.txt") {
//!            Err(e) => return Err(e),
//!            Ok(f) => f,
//!     };
//!     if let Err(e) = file.write_all(format!("name: {}\n", info.name).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("age: {}\n", info.age).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("rating: {}\n", info.rating).as_bytes()) {
//!         return Err(e)
//!     }
//!     Ok(())
//! }
//! ```
//!
//! මේ සමඟ:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     let mut file = File::create("my_best_friends.txt")?;
//!     // දෝෂය මත නැවත පැමිණීම
//!     file.write_all(format!("name: {}\n", info.name).as_bytes())?;
//!     file.write_all(format!("age: {}\n", info.age).as_bytes())?;
//!     file.write_all(format!("rating: {}\n", info.rating).as_bytes())?;
//!     Ok(())
//! }
//! ```
//!
//! *එය වඩාත් හොඳයි!*
//!
//! [`?`] සමඟ ප්‍රකාශනය අවසන් කිරීමෙන් ප්‍රති result ලය [`Err`] නොවන්නේ නම්, සාර්ථක නොවූ ([`Ok`]) අගය ලැබෙනු ඇත, එවැනි අවස්ථාවකදී [`Err`] සංවෘත ශ්‍රිතයෙන් ආපසු ලබා දෙනු ලැබේ.
//!
//!
//! [`?`] [`Result`] ආපසු ලබා දෙන කාර්යයන් සඳහා පමණක් භාවිතා කළ හැක්කේ එය සපයන [`Err`] හි මුල් ප්‍රතිලාභ නිසාය.
//!
//! [`expect`]: Result::expect
//! [`Write`]: ../../std/io/trait.Write.html
//! [`write_all`]: ../../std/io/trait.Write.html#method.write_all
//! [`io::Result`]: ../../std/io/type.Result.html
//! [`?`]: crate::ops::Try
//! [`Ok(T)`]: Ok
//! [`Err(E)`]: Err
//! [`io::Error`]: ../../std/io/struct.Error.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{self, FromIterator, FusedIterator, TrustedLen};
use crate::ops::{self, Deref, DerefMut};
use crate::{convert, fmt, hint};

/// `Result` ([`Ok`]) හෝ අසාර්ථක ([`Err`]) සාර්ථකත්වය නියෝජනය කරන වර්ගයකි.
///
/// විස්තර සඳහා [module documentation](self) බලන්න.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[must_use = "this `Result` may be an `Err` variant, which should be handled"]
#[rustc_diagnostic_item = "result_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Result<T, E> {
    /// සාර්ථකත්වයේ අගය අඩංගු වේ
    #[lang = "Ok"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Ok(#[stable(feature = "rust1", since = "1.0.0")] T),

    /// දෝෂ අගය අඩංගු වේ
    #[lang = "Err"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Err(#[stable(feature = "rust1", since = "1.0.0")] E),
}

/////////////////////////////////////////////////////////////////////////////
// ක්‍රියාත්මක කිරීම ටයිප් කරන්න
/////////////////////////////////////////////////////////////////////////////

impl<T, E> Result<T, E> {
    /////////////////////////////////////////////////////////////////////////
    // අඩංගු අගයන් විමසීම
    /////////////////////////////////////////////////////////////////////////

    /// ප්‍රති result ලය [`Ok`] නම් `true` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_ok(), true);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_ok(), false);
    /// ```
    #[must_use = "if you intended to assert that this is ok, consider `.unwrap()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_ok(&self) -> bool {
        matches!(*self, Ok(_))
    }

    /// ප්‍රති result ලය [`Err`] නම් `true` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_err(), false);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_err(), true);
    /// ```
    #[must_use = "if you intended to assert that this is err, consider `.unwrap_err()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_err(&self) -> bool {
        !self.is_ok()
    }

    /// ප්‍රති result ලය ලබා දී ඇති අගය අඩංගු [`Ok`] අගයක් නම් `true` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Result<u32, &str> = Ok(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Ok(y) => x == y,
            Err(_) => false,
        }
    }

    /// ප්‍රති result ලය ලබා දී ඇති අගය අඩංගු [`Err`] අගයක් නම් `true` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_contains_err)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains_err(&"Some error message"), true);
    ///
    /// let x: Result<u32, &str> = Err("Some other error message");
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "result_contains_err", issue = "62358")]
    pub fn contains_err<F>(&self, f: &F) -> bool
    where
        F: PartialEq<E>,
    {
        match self {
            Ok(_) => false,
            Err(e) => f == e,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // එක් එක් ප්‍රභේදය සඳහා ඇඩැප්ටරය
    /////////////////////////////////////////////////////////////////////////

    /// `Result<T, E>` සිට [`Option<T>`] දක්වා පරිවර්තනය කරයි.
    ///
    /// `self` [`Option<T>`] බවට පරිවර්තනය කිරීම, `self` පරිභෝජනය කිරීම සහ දෝෂය ඇත්නම් ඒවා ඉවතලීම.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.ok(), Some(2));
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.ok(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok(self) -> Option<T> {
        match self {
            Ok(x) => Some(x),
            Err(_) => None,
        }
    }

    /// `Result<T, E>` සිට [`Option<E>`] දක්වා පරිවර්තනය කරයි.
    ///
    /// `self` [`Option<E>`] බවට පරිවර්තනය කිරීම, `self` පරිභෝජනය කිරීම සහ සාර්ථකත්වයේ අගය ඇත්නම් ඒවා ඉවතලීම.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.err(), None);
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.err(), Some("Nothing here"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn err(self) -> Option<E> {
        match self {
            Ok(_) => None,
            Err(x) => Some(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // යොමු කිරීම් සමඟ වැඩ කිරීම සඳහා ඇඩැප්ටරය
    /////////////////////////////////////////////////////////////////////////

    /// `&Result<T, E>` සිට `Result<&T, &E>` දක්වා පරිවර්තනය කරයි.
    ///
    /// නව `Result` නිපදවන අතර, මුල් පිටපතට යොමු කිරීමක් අඩංගු වන අතර මුල් පිටපත තබයි.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.as_ref(), Ok(&2));
    ///
    /// let x: Result<u32, &str> = Err("Error");
    /// assert_eq!(x.as_ref(), Err(&"Error"));
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Result<&T, &E> {
        match *self {
            Ok(ref x) => Ok(x),
            Err(ref x) => Err(x),
        }
    }

    /// `&mut Result<T, E>` සිට `Result<&mut T, &mut E>` දක්වා පරිවර්තනය කරයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// fn mutate(r: &mut Result<i32, i32>) {
    ///     match r.as_mut() {
    ///         Ok(v) => *v = 42,
    ///         Err(e) => *e = 0,
    ///     }
    /// }
    ///
    /// let mut x: Result<i32, i32> = Ok(2);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap(), 42);
    ///
    /// let mut x: Result<i32, i32> = Err(13);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap_err(), 0);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Result<&mut T, &mut E> {
        match *self {
            Ok(ref mut x) => Ok(x),
            Err(ref mut x) => Err(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // අඩංගු අගයන් පරිවර්තනය කිරීම
    /////////////////////////////////////////////////////////////////////////

    /// අඩංගු [`Ok`] අගයකට ශ්‍රිතයක් යෙදීමෙන් `Result<T, E>` සිට `Result<U, E>` දක්වා සිතියම් ගත කිරීම, [`Err`] අගය ස්පර්ශ නොකෙරේ.
    ///
    ///
    /// මෙම ශ්‍රිතය ශ්‍රිත දෙකක ප්‍රති results ල රචනා කිරීමට භාවිතා කළ හැකිය.
    ///
    /// # Examples
    ///
    /// නූලක එක් එක් පේළියේ අංක දෙකකින් ගුණ කරන්න.
    ///
    /// ```
    /// let line = "1\n2\n3\n4\n";
    ///
    /// for num in line.lines() {
    ///     match num.parse::<i32>().map(|i| i * 2) {
    ///         Ok(n) => println!("{}", n),
    ///         Err(..) => {}
    ///     }
    /// }
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => Ok(op(t)),
            Err(e) => Err(e),
        }
    }

    /// අඩංගු අගයට ([`Ok`] නම්) ශ්‍රිතයක් යොදයි, නැතහොත් ලබා දී ඇති පෙරනිමිය ([`Err`] නම්) ලබා දෙයි.
    ///
    /// `map_or` වෙත ඉදිරිපත් කරන ලද තර්ක උනන්දුවෙන් ඇගයීමට ලක් කෙරේ;ඔබ ශ්‍රිත ඇමතුමක ප්‍රති result ලය පසුකරන්නේ නම්, කම්මැලි ලෙස ඇගයීමට ලක් කරන [`map_or_else`] භාවිතා කිරීම රෙකමදාරු කරනු ලැබේ.
    ///
    ///
    /// [`map_or_else`]: Result::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or", since = "1.41.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(_) => default,
        }
    }

    /// අඩංගු [`Ok`] අගයකට ශ්‍රිතයක් යෙදීමෙන් `Result<T, E>` සිට `U` දක්වා සිතියම් ගත කරන්න, නැතහොත් අඩංගු [`Err`] අගයට ආපසු හැරවීමේ ශ්‍රිතයක්.
    ///
    ///
    /// දෝෂයක් හසුරුවමින් සාර්ථක ප්‍රති result ලයක් ඉවත් කිරීමට මෙම ශ්‍රිතය භාවිතා කළ හැකිය.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x : Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 3);
    ///
    /// let x : Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 42);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or_else", since = "1.41.0")]
    pub fn map_or_else<U, D: FnOnce(E) -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(e) => default(e),
        }
    }

    /// අඩංගු [`Err`] අගයකට ශ්‍රිතයක් යෙදීමෙන් `Result<T, E>` සිට `Result<T, F>` දක්වා සිතියම් ගත කිරීම, [`Ok`] අගය ස්පර්ශ නොකෙරේ.
    ///
    ///
    /// දෝෂයක් හසුරුවමින් සාර්ථක ප්‍රති result ලයක් ලබා දීමට මෙම ශ්‍රිතය භාවිතා කළ හැකිය.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// fn stringify(x: u32) -> String { format!("error code: {}", x) }
    ///
    /// let x: Result<u32, u32> = Ok(2);
    /// assert_eq!(x.map_err(stringify), Ok(2));
    ///
    /// let x: Result<u32, u32> = Err(13);
    /// assert_eq!(x.map_err(stringify), Err("error code: 13".to_string()));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_err<F, O: FnOnce(E) -> F>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => Err(op(e)),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // අනුකාරක ඉදිකිරීම්කරුවන්
    /////////////////////////////////////////////////////////////////////////

    /// අඩංගු විය හැකි වටිනාකමට වඩා අනුකාරකයක් ලබා දෙයි.
    ///
    /// ප්‍රති result ලය [`Result::Ok`] නම් iterator එක අගයක් ලබා දෙයි, එසේ නොමැති නම් කිසිවක් නැත.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(7);
    /// assert_eq!(x.iter().next(), Some(&7));
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { inner: self.as_ref().ok() }
    }

    /// අඩංගු විය හැකි අගයට වඩා විකෘති පුනරාවර්තකයක් ලබා දෙයි.
    ///
    /// ප්‍රති result ලය [`Result::Ok`] නම් iterator එක අගයක් ලබා දෙයි, එසේ නොමැති නම් කිසිවක් නැත.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let mut x: Result<u32, &str> = Ok(7);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 40,
    ///     None => {},
    /// }
    /// assert_eq!(x, Ok(40));
    ///
    /// let mut x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: self.as_mut().ok() }
    }

    ////////////////////////////////////////////////////////////////////////
    // සාරධර්ම, උනන්දුවෙන් හා කම්මැලි ලෙස බූලියන් මෙහෙයුම්
    /////////////////////////////////////////////////////////////////////////

    /// ප්‍රති result ලය [`Ok`] නම් `res` ලබා දෙයි, එසේ නොමැතිනම් `self` හි [`Err`] අගය ලබා දෙයි.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<&str, &str> = Ok("foo");
    /// assert_eq!(x.and(y), Err("early error"));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("not a 2"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Ok("different result type");
    /// assert_eq!(x.and(y), Ok("different result type"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, res: Result<U, E>) -> Result<U, E> {
        match self {
            Ok(_) => res,
            Err(e) => Err(e),
        }
    }

    /// ප්‍රති 0 ලය [`Ok`] නම් `op` අමතන්න, එසේ නොමැතිනම් `self` හි [`Err`] අගය ලබා දෙයි.
    ///
    ///
    /// `Result` අගයන් මත පදනම්ව පාලන ප්‍රවාහ සඳහා මෙම ශ්‍රිතය භාවිතා කළ හැකිය.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).and_then(sq).and_then(sq), Ok(16));
    /// assert_eq!(Ok(2).and_then(sq).and_then(err), Err(4));
    /// assert_eq!(Ok(2).and_then(err).and_then(sq), Err(2));
    /// assert_eq!(Err(3).and_then(sq).and_then(sq), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Result<U, E>>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => op(t),
            Err(e) => Err(e),
        }
    }

    /// ප්‍රති result ලය [`Err`] නම් `res` ලබා දෙයි, එසේ නොමැතිනම් `self` හි [`Ok`] අගය ලබා දෙයි.
    ///
    /// `or` වෙත ඉදිරිපත් කරන ලද තර්ක උනන්දුවෙන් ඇගයීමට ලක් කෙරේ;ඔබ ශ්‍රිත ඇමතුමක ප්‍රති result ලය පසුකරන්නේ නම්, කම්මැලි ලෙස ඇගයීමට ලක් කරන [`or_else`] භාවිතා කිරීම රෙකමදාරු කරනු ලැබේ.
    ///
    ///
    /// [`or_else`]: Result::or_else
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Ok(100);
    /// assert_eq!(x.or(y), Ok(2));
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or<F>(self, res: Result<T, F>) -> Result<T, F> {
        match self {
            Ok(v) => Ok(v),
            Err(_) => res,
        }
    }

    /// ප්‍රති 0 ලය [`Err`] නම් `op` අමතන්න, එසේ නොමැතිනම් `self` හි [`Ok`] අගය ලබා දෙයි.
    ///
    ///
    /// ප්‍රති function ල අගයන් මත පදනම්ව පාලන ප්‍රවාහය සඳහා මෙම ශ්‍රිතය භාවිතා කළ හැකිය.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).or_else(sq).or_else(sq), Ok(2));
    /// assert_eq!(Ok(2).or_else(err).or_else(sq), Ok(2));
    /// assert_eq!(Err(3).or_else(sq).or_else(err), Ok(9));
    /// assert_eq!(Err(3).or_else(err).or_else(err), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F, O: FnOnce(E) -> Result<T, F>>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => op(e),
        }
    }

    /// අඩංගු [`Ok`] අගය හෝ ලබා දී ඇති පෙරනිමිය ලබා දෙයි.
    ///
    /// `unwrap_or` වෙත ඉදිරිපත් කරන ලද තර්ක උනන්දුවෙන් ඇගයීමට ලක් කෙරේ;ඔබ ශ්‍රිත ඇමතුමක ප්‍රති result ලය පසුකරන්නේ නම්, කම්මැලි ලෙස ඇගයීමට ලක් කරන [`unwrap_or_else`] භාවිතා කිරීම රෙකමදාරු කරනු ලැබේ.
    ///
    ///
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let default = 2;
    /// let x: Result<u32, &str> = Ok(9);
    /// assert_eq!(x.unwrap_or(default), 9);
    ///
    /// let x: Result<u32, &str> = Err("error");
    /// assert_eq!(x.unwrap_or(default), default);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Ok(t) => t,
            Err(_) => default,
        }
    }

    /// අඩංගු [`Ok`] අගය ලබා දෙයි හෝ වසා දැමීමෙන් ගණනය කරයි.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// fn count(x: &str) -> usize { x.len() }
    ///
    /// assert_eq!(Ok(2).unwrap_or_else(count), 2);
    /// assert_eq!(Err("foo").unwrap_or_else(count), 3);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce(E) -> T>(self, op: F) -> T {
        match self {
            Ok(t) => t,
            Err(e) => op(e),
        }
    }

    /// අගය [`Err`] නොවන බව පරික්ෂා නොකර `self` අගය පරිභෝජනය කරන [`Ok`] අගය ලබා දෙයි.
    ///
    ///
    /// # Safety
    ///
    /// මෙම ක්‍රමය [`Err`] මත ඇමතීම *[නිර්වචනය නොකළ හැසිරීම]*.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, 2);
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// unsafe { x.unwrap_unchecked(); } // නිර්වචනය නොකළ හැසිරීම!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_ok());
        match self {
            Ok(t) => t,
            // ආරක්ෂාව: ආරක්ෂිත කොන්ත්රාත්තුව අමතන්නා විසින් තහවුරු කළ යුතුය.
            Err(_) => unsafe { hint::unreachable_unchecked() },
        }
    }

    /// අගය [`Ok`] නොවන බව පරික්ෂා නොකර `self` අගය පරිභෝජනය කරන [`Err`] අගය ලබා දෙයි.
    ///
    ///
    /// # Safety
    ///
    /// මෙම ක්‍රමය [`Ok`] මත ඇමතීම *[නිර්වචනය නොකළ හැසිරීම]*.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// unsafe { x.unwrap_err_unchecked() }; // නිර්වචනය නොකළ හැසිරීම!
    /// ```
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(unsafe { x.unwrap_err_unchecked() }, "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_err_unchecked(self) -> E {
        debug_assert!(self.is_err());
        match self {
            // ආරක්ෂාව: ආරක්ෂිත කොන්ත්රාත්තුව අමතන්නා විසින් තහවුරු කළ යුතුය.
            Ok(_) => unsafe { hint::unreachable_unchecked() },
            Err(e) => e,
        }
    }
}

impl<T: Copy, E> Result<&T, E> {
    /// `Ok` කොටසෙහි අන්තර්ගතය පිටපත් කිරීමෙන් `Result<&T, E>` සිට `Result<T, E>` දක්වා සිතියම් ගත කරන්න.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&t| t)
    }
}

impl<T: Copy, E> Result<&mut T, E> {
    /// `Ok` කොටසෙහි අන්තර්ගතය පිටපත් කිරීමෙන් `Result<&mut T, E>` සිට `Result<T, E>` දක්වා සිතියම් ගත කරන්න.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone, E> Result<&T, E> {
    /// `Ok` කොටසෙහි අන්තර්ගතය ක්ලෝන කිරීමෙන් `Result<&T, E>` සිට `Result<T, E>` දක්වා සිතියම් ගත කරන්න.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone, E> Result<&mut T, E> {
    /// `Ok` කොටසෙහි අන්තර්ගතය ක්ලෝන කිරීමෙන් `Result<&mut T, E>` සිට `Result<T, E>` දක්වා සිතියම් ගත කරන්න.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T, E: fmt::Debug> Result<T, E> {
    /// `self` අගය පරිභෝජනය කරමින් අඩංගු [`Ok`] අගය ලබා දෙයි.
    ///
    /// # Panics
    ///
    /// Panics අගය [`Err`] නම්, සම්මත කළ පණිවිඩය ඇතුළුව panic පණිවිඩයක් සහ [`Err`] හි අන්තර්ගතය.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.expect("Testing expect"); // panics with `Testing expect: emergency failure`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect", since = "1.4.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed(msg, &e),
        }
    }

    /// `self` අගය පරිභෝජනය කරමින් අඩංගු [`Ok`] අගය ලබා දෙයි.
    ///
    /// මෙම ශ්‍රිතය panic විය හැකි බැවින්, එහි භාවිතය සාමාන්‍යයෙන් අධෛර්යමත් වේ.
    /// ඒ වෙනුවට, රටා ගැලපීම භාවිතා කිරීමට සහ [`Err`] නඩුව පැහැදිලිව හැසිරවීමට කැමති හෝ [`unwrap_or`], [`unwrap_or_else`], හෝ [`unwrap_or_default`] අමතන්න.
    ///
    ///
    /// [`unwrap_or`]: Result::unwrap_or
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    /// [`unwrap_or_default`]: Result::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics අගය [`Err`] නම්, panic පණිවිඩයක් සමඟ [`Err`] හි අගය සපයයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.unwrap(), 2);
    /// ```
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.unwrap(); // panics with `emergency failure`
    /// ```
    ///
    ///
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap(self) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed("called `Result::unwrap()` on an `Err` value", &e),
        }
    }
}

impl<T: fmt::Debug, E> Result<T, E> {
    /// `self` අගය පරිභෝජනය කරමින් අඩංගු [`Err`] අගය ලබා දෙයි.
    ///
    /// # Panics
    ///
    /// Panics අගය [`Ok`] නම්, සම්මත කළ පණිවිඩය ඇතුළුව panic පණිවිඩයක් සහ [`Ok`] හි අන්තර්ගතය.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(10);
    /// x.expect_err("Testing expect_err"); // panics with `Testing expect_err: 10`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect_err", since = "1.17.0")]
    pub fn expect_err(self, msg: &str) -> E {
        match self {
            Ok(t) => unwrap_failed(msg, &t),
            Err(e) => e,
        }
    }

    /// `self` අගය පරිභෝජනය කරමින් අඩංගු [`Err`] අගය ලබා දෙයි.
    ///
    /// # Panics
    ///
    /// Panics අගය [`Ok`] නම්, අභිරුචි panic පණිවිඩයක් [`හරි`] හි අගය මඟින් සපයනු ලැබේ.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(2);
    /// x.unwrap_err(); // panics with `2`
    /// ```
    ///
    /// ```
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(x.unwrap_err(), "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_err(self) -> E {
        match self {
            Ok(t) => unwrap_failed("called `Result::unwrap_err()` on an `Ok` value", &t),
            Err(e) => e,
        }
    }
}

impl<T: Default, E> Result<T, E> {
    /// අඩංගු [`Ok`] අගය හෝ පෙරනිමිය ලබා දෙයි
    ///
    /// `self` තර්කය පරිභෝජනය කරයි, [`Ok`] නම්, අඩංගු අගය නැවත ලබා දෙයි, එසේ නොමැතිනම් [`Err`] නම්, එම වර්ගය සඳහා පෙරනිමි අගය ලබා දෙයි.
    ///
    ///
    /// # Examples
    ///
    /// දුර්වල ලෙස සාදන ලද නූල් 0 බවට හරවන (පූර්ණ සංඛ්‍යා සඳහා පෙරනිමි අගය) නූලක් පූර්ණ සංඛ්‍යාවක් බවට පරිවර්තනය කරයි.
    /// [`parse`] [`FromStr`] ක්‍රියාත්මක කරන වෙනත් වර්ගයකට නූලක් පරිවර්තනය කරයි, දෝෂයක් මත [`Err`] යවයි.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_unwrap_or_default", since = "1.16.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Ok(x) => x,
            Err(_) => Default::default(),
        }
    }
}

#[unstable(feature = "unwrap_infallible", reason = "newly added", issue = "61695")]
impl<T, E: Into<!>> Result<T, E> {
    /// අඩංගු [`Ok`] අගය ලබා දෙයි, නමුත් කිසි විටෙකත් panics.
    ///
    /// [`unwrap`] මෙන් නොව, මෙම ක්‍රමය කිසි විටෙකත් panic සඳහා ප්‍රති result ල වර්ග මත ක්‍රියාත්මක නොවන බව දන්නා කරුණකි.
    /// එමනිසා, එය `unwrap` වෙනුවට නඩත්තු කළ හැකි ආරක්ෂාවක් ලෙස භාවිතා කළ හැකි අතර එය `Result` හි දෝෂ වර්ගය පසුව සත්‍ය වශයෙන්ම සිදුවිය හැකි දෝෂයක් ලෙස වෙනස් කළ හොත් එය සම්පාදනය කිරීමට අසමත් වේ.
    ///
    ///
    /// [`unwrap`]: Result::unwrap
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// # #![feature(never_type)]
    /// # #![feature(unwrap_infallible)]
    ///
    /// fn only_good_news() -> Result<String, !> {
    ///     Ok("this is fine".into())
    /// }
    ///
    /// let s: String = only_good_news().into_ok();
    /// println!("{}", s);
    /// ```
    ///
    ///
    #[inline]
    pub fn into_ok(self) -> T {
        match self {
            Ok(x) => x,
            Err(e) => e.into(),
        }
    }
}

impl<T: Deref, E> Result<T, E> {
    /// `Result<T, E>` (හෝ `&Result<T, E>`) සිට `Result<&<T as Deref>::Target, &E>` දක්වා පරිවර්තනය කරයි.
    ///
    /// මුල් [`Result`] හි [`Ok`] ප්‍රභේදය [`Deref`](crate::ops::Deref) හරහා බල කර නව [`Result`] ලබා දෙයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&str, &u32> = Ok("hello");
    /// assert_eq!(x.as_deref(), y);
    ///
    /// let x: Result<String, u32> = Err(42);
    /// let y: Result<&str, &u32> = Err(&42);
    /// assert_eq!(x.as_deref(), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref(&self) -> Result<&T::Target, &E> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut, E> Result<T, E> {
    /// `Result<T, E>` (හෝ `&mut Result<T, E>`) සිට `Result<&mut <T as DerefMut>::Target, &mut E>` දක්වා පරිවර්තනය කරයි.
    ///
    /// මුල් [`Result`] හි [`Ok`] ප්‍රභේදය [`DerefMut`](crate::ops::DerefMut) හරහා බල කර නව [`Result`] ලබා දෙයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = "HELLO".to_string();
    /// let mut x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&mut str, &mut u32> = Ok(&mut s);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    ///
    /// let mut i = 42;
    /// let mut x: Result<String, u32> = Err(42);
    /// let y: Result<&mut str, &mut u32> = Err(&mut i);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref_mut(&mut self) -> Result<&mut T::Target, &mut E> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Result<Option<T>, E> {
    /// `Option` හි `Result`, `Result` හි `Option` බවට පරිවර්තනය කරයි.
    ///
    /// `Ok(None)` `None` වෙත සිතියම් ගත කෙරේ.
    /// `Ok(Some(_))` `Err(_)` `Some(Ok(_))` සහ `Some(Err(_))` වෙත සිතියම් ගත කෙරේ.
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x.transpose(), y);
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_result", issue = "82814")]
    pub const fn transpose(self) -> Option<Result<T, E>> {
        match self {
            Ok(Some(x)) => Some(Ok(x)),
            Ok(None) => None,
            Err(e) => Some(Err(e)),
        }
    }
}

impl<T, E> Result<Result<T, E>, E> {
    /// `Result<Result<T, E>, E>` සිට `Result<T, E>` දක්වා පරිවර්තනය කරයි
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Ok("hello"));
    /// assert_eq!(Ok("hello"), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Err(6));
    /// assert_eq!(Err(6), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Err(6);
    /// assert_eq!(Err(6), x.flatten());
    /// ```
    ///
    /// පැතලි කිරීම මඟින් වරකට එක් කැදැල්ලක් ඉවත් කරයි:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<Result<&'static str, u32>, u32>, u32> = Ok(Ok(Ok("hello")));
    /// assert_eq!(Ok(Ok("hello")), x.flatten());
    /// assert_eq!(Ok("hello"), x.flatten().flatten());
    /// ```
    #[inline]
    #[unstable(feature = "result_flattening", issue = "70142")]
    pub fn flatten(self) -> Result<T, E> {
        self.and_then(convert::identity)
    }
}

impl<T> Result<T, T> {
    /// `self` `Ok` නම් [`Ok`] අගය ද, `self` `Err` නම් [`Err`] අගය ද ලබා දෙයි.
    ///
    /// වෙනත් වචන වලින් කිවහොත්, මෙම ශ්‍රිතය `Result<T, T>` හෝ `Err` වේ ද යන්න නොසලකා `Result<T, T>` හි අගය (`T`) ලබා දෙයි.
    ///
    /// [`Atomic*::compare_exchange`], හෝ [`slice::binary_search`] වැනි ඒපීඅයි සමඟ ඒකාබද්ධව මෙය ප්‍රයෝජනවත් විය හැකි නමුත් ප්‍රති result ලය `Ok` ද නැද්ද යන්න ඔබ ගණන් නොගන්නා අවස්ථාවන්හිදී පමණි.
    ///
    ///
    /// [`Atomic*::compare_exchange`]: crate::sync::atomic::AtomicBool::compare_exchange
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_into_ok_or_err)]
    /// let ok: Result<u32, u32> = Ok(3);
    /// let err: Result<u32, u32> = Err(4);
    ///
    /// assert_eq!(ok.into_ok_or_err(), 3);
    /// assert_eq!(err.into_ok_or_err(), 4);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "result_into_ok_or_err", reason = "newly added", issue = "82223")]
    pub const fn into_ok_or_err(self) -> T {
        match self {
            Ok(v) => v,
            Err(v) => v,
        }
    }
}

// ක්‍රමවල කේත ප්‍රමාණය අඩු කිරීම සඳහා මෙය වෙනම කාර්යයකි
#[inline(never)]
#[cold]
#[track_caller]
fn unwrap_failed(msg: &str, error: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, error)
}

/////////////////////////////////////////////////////////////////////////////
// Trait ක්‍රියාත්මක කිරීම
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, E: Clone> Clone for Result<T, E> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Ok(x) => Ok(x.clone()),
            Err(x) => Err(x.clone()),
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Ok(to), Ok(from)) => to.clone_from(from),
            (Err(to), Err(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, E> IntoIterator for Result<T, E> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// අඩංගු විය හැකි වටිනාකමට වඩා පරිභෝජන අනුකාරකයක් ලබා දෙයි.
    ///
    /// ප්‍රති result ලය [`Result::Ok`] නම් iterator එක අගයක් ලබා දෙයි, එසේ නොමැති නම් කිසිවක් නැත.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(5);
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, [5]);
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, []);
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self.ok() }
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a Result<T, E> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a mut Result<T, E> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// ප්‍රති ult ල අනුභව කරන්නන්
/////////////////////////////////////////////////////////////////////////////

/// [`Result`] හි [`Ok`] ප්‍රභේදය පිළිබඳ සඳහනක් හරහා iterator.
///
/// ප්‍රති result ලය [`Ok`] නම් iterator එක අගයක් ලබා දෙයි, එසේ නොමැති නම් කිසිවක් නැත.
///
/// [`Result::iter`] විසින් නිර්මාණය කරන ලදි.
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    inner: Option<&'a T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner }
    }
}

/// [`Result`] හි [`Ok`] ප්‍රභේදයට විකෘති කළ හැකි යොමු කිරීමක් හරහා ඉරේටරයක්.
///
/// [`Result::iter_mut`] විසින් නිර්මාණය කරන ලදි.
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    inner: Option<&'a mut T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// [`Result`] හි [`Ok`] ප්‍රභේදයක වටිනාකමට වඩා ඉරේටරයක්.
///
/// ප්‍රති result ලය [`Ok`] නම් iterator එක අගයක් ලබා දෙයි, එසේ නොමැති නම් කිසිවක් නැත.
///
/// මෙම ව්‍යුහය [`Result`] හි [`into_iter`] ක්‍රමය මඟින් නිර්මාණය කර ඇත ([`IntoIterator`] trait විසින් සපයනු ලැබේ).
///
///
/// [`into_iter`]: IntoIterator::into_iter
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    inner: Option<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, E, V: FromIterator<A>> FromIterator<Result<A, E>> for Result<V, E> {
    /// `Iterator` හි එක් එක් මූලද්‍රව්‍යය ගනී: එය `Err` නම්, තවත් මූලද්‍රව්‍ය කිසිවක් නොගන්නා අතර `Err` ආපසු ලබා දෙනු ලැබේ.
    /// `Err` කිසිවක් සිදු නොවන්නේ නම්, එක් එක් `Result` හි අගයන් සහිත බහාලුමක් ආපසු ලබා දෙනු ලැබේ.
    ///
    /// vector හි සෑම පූර්ණ සංඛ්‍යාවක්ම වැඩි කරන, පිටාර ගැලීම සඳහා පරීක්ෂා කරන උදාහරණයක් මෙන්න:
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_add(1).ok_or("Overflow!")
    /// ).collect();
    /// assert_eq!(res, Ok(vec![2, 3]));
    /// ```
    ///
    /// මෙන්න තවත් නිඛිල ලැයිස්තුවකින් තවත් එකක් අඩු කිරීමට උත්සාහ කරන තවත් උදාහරණයක්, මේ වතාවේ ගලායාම පරීක්ෂා කරයි:
    ///
    /// ```
    /// let v = vec![1, 2, 0];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_sub(1).ok_or("Underflow!")
    /// ).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// ```
    ///
    /// පළමු `Err` පසු `iter` වෙතින් තවත් මූලද්‍රව්‍යයන් නොගන්නා බව පෙන්වන පෙර උදාහරණයේ විචලනය මෙන්න.
    ///
    /// ```
    /// let v = vec![3, 2, 1, 10];
    /// let mut shared = 0;
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32| {
    ///     shared += x;
    ///     x.checked_sub(2).ok_or("Underflow!")
    /// }).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// තෙවන මූලද්‍රව්‍යය යටින් ගලායාමට හේතු වූ බැවින්, තවත් මූලද්‍රව්‍යයන් ගනු නොලැබූ බැවින් `shared` හි අවසාන අගය 6 (= `3 + 2 + 1`) මිස 16 නොවේ.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Result<A, E>>>(iter: I) -> Result<V, E> {
        // FIXME(#11084): මෙම කාර්ය සාධන දෝෂය වසා ඇති විට මෙය Iterator::scan සමඟ ප්‍රතිස්ථාපනය කළ හැකිය.
        //

        iter::process_results(iter.into_iter(), |i| i.collect())
    }
}

#[unstable(feature = "try_trait", issue = "42327")]
impl<T, E> ops::Try for Result<T, E> {
    type Ok = T;
    type Error = E;

    #[inline]
    fn into_result(self) -> Self {
        self
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Ok(v)
    }

    #[inline]
    fn from_error(v: E) -> Self {
        Err(v)
    }
}