//! SipHash ක්‍රියාත්මක කිරීම.

#![allow(deprecated)] // මෙම මොඩියුලයේ වර්ග ඉවත් කර ඇත

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// SipHash 1-3 ක් ක්‍රියාත්මක කිරීම.
///
/// මෙය දැනට සම්මත පුස්තකාලය භාවිතා කරන පෙරනිමි හැෂිං ශ්‍රිතයයි (උදා: `collections::HashMap` එය පෙරනිමියෙන් භාවිතා කරයි).
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// SipHash 2-4 ක්‍රියාත්මක කිරීම.
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// SipHash 2-4 ක්‍රියාත්මක කිරීම.
///
/// See: <https://131002.net/siphash/>
///
/// SipHash යනු පොදු අරමුණු සහිත හැෂිං ශ්‍රිතයකි: එය හොඳ වේගයකින් ධාවනය වේ (ස්පූකි සහ නගරය සමඟ තරඟකාරී වේ) සහ ශක්තිමත් _keyed_ හැෂිං සඳහා අවසර දෙයි.
///
/// [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html) වැනි ශක්තිමත් RNG එකකින් ඔබගේ හැෂ් වගු යතුරු කිරීමට මෙය ඔබට ඉඩ දෙයි.
///
/// SipHash ඇල්ගොරිතම සාමාන්‍යයෙන් ශක්තිමත් යැයි සලකනු ලැබුවද, එය ගුප්ත ලේඛනකරණ අරමුණු සඳහා අදහස් නොකෙරේ.
/// එනිසා, මෙම ක්‍රියාවට නැංවීමේ සියලුම ගුප්ත ලේඛන භාවිතයන් _strongly discouraged_ වේ.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // අපි බයිට් කීයක් සැකසුවාද?
    state: State,  // හැෂ් රාජ්ය
    tail: u64,     // සැකසූ බයිට් ලෙ
    ntail: usize,  // වලිගයේ බයිට් කීයක් වලංගු ද?
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, v2 සහ v1, v3 ඇල්ගොරිතමයේ යුගල වශයෙන් පෙන්වන අතර සිප් හැෂ් ක්‍රියාත්මක කිරීම මඟින් v02 සහ v13 හි vectors භාවිතා කරනු ඇත.
    //
    // මෙම අනුපිළිවෙලෙහි ව්‍යුහය තුළ තැබීමෙන්, සම්පාදකයාට තනිවම ප්‍රශස්තිකරණයන් කිහිපයක් ලබා ගත හැකිය.
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// LE අනුපිළිවෙලින් බයිට් ප්‍රවාහයකින් අපේක්ෂිත වර්ගයේ පූර්ණ සංඛ්‍යාවක් පූරණය කරයි.
/// නොබැඳි ලිපිනයකින් එය පැටවීම සඳහා වඩාත් කාර්යක්ෂම ක්‍රමයක් සම්පාදකයාට ජනනය කිරීමට `copy_nonoverlapping` භාවිතා කරයි.
///
///
/// අනාරක්ෂිත නිසා: i..i+size_of(int_ty) හි පරීක්ෂා නොකළ සුචිගත කිරීම
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// බයිට් පෙත්තක බයිට් 7 ක් භාවිතා කරමින් u64 පටවනු ලැබේ.
/// එය අවුල්සහගත පෙනුමක් ඇති නමුත් සිදුවන `copy_nonoverlapping` ඇමතුම් (`load_int_le!` හරහා) සියල්ලටම ස්ථාවර ප්‍රමාණ ඇති අතර `memcpy` ඇමතීමෙන් වළකින්න, එය වේගයට හොඳය.
///
///
/// අනාරක්ෂිත නිසා: ආරම්භයේදීම පරීක්ෂා නොකළ සුචිගත කිරීම..ස්ටාර්ට් + ලෙන්
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // u64 නිමැවුමේ වත්මන් බයිට් දර්ශකය (LSB වෙතින්)
    let mut out = 0;
    if i + 3 < len {
        // ආරක්ෂාව: `i` `len` ට වඩා වැඩි විය නොහැකි අතර අමතන්නා සහතික විය යුතුය
        // දර්ශකය ආරම්භය .. ස්ටාර්ට් + ලෙන් සීමාව ඉක්මවා ඇති බව.
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // ආරක්ෂාව: ඉහත ආකාරයටම.
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // ආරක්ෂාව: ඉහත ආකාරයටම.
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// ආරම්භක යතුරු දෙක 0 ලෙස සකසා ඇති නව `SipHasher` නිර්මාණය කරයි.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// සපයන ලද යතුරු වලින් යතුරු ලබා ඇති `SipHasher` සාදයි.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// ආරම්භක යතුරු දෙක 0 ලෙස සකසා ඇති නව `SipHasher13` නිර්මාණය කරයි.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// සපයන ලද යතුරු වලින් යතුරු ලබා ඇති `SipHasher13` සාදයි.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: පූර්ණ සංඛ්‍යා හැෂිං ක්‍රම (`write_u *`, `write_i*`) අර්ථ දක්වා නැත
    // මෙම වර්ගය සඳහා.
    // අපට ඒවා එකතු කළ හැකිය, librustc_data_structures/sip128.rs හි `short_write` ක්‍රියාත්මක කිරීම පිටපත් කළ හැකිය, සහ `SipHasher`, `SipHasher13`, සහ `DefaultHasher` වෙත `write_u *`/`write_i*` ක්‍රම එකතු කළ හැකිය.
    //
    // සමහර මිණුම් සලකුණු මත සංයුක්ත වේගය තරමක් මන්දගාමී කිරීමේ වියදමින්, මෙම හැෂර් විසින් පූර්ණ සංඛ්‍යා හැෂිං කිරීම මෙය බෙහෙවින් වේගවත් කරනු ඇත.
    // විස්තර සඳහා #69152 බලන්න.
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // ආරක්ෂාව: `cmp::min(length, needed)` `length` ට වඩා වැඩි නොවන බවට සහතික වේ
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // බෆර් කළ වලිගය දැන් පිස දමා ඇත, නව ආදානය සකසන්න.
        let len = length - needed;
        let left = len & 0x7; // len% 8

        let mut i = needed;
        while i < len - left {
            // ආරක්ෂාව: `len - left` යනු 8 ට අඩු විශාලතම ගුණකය වන බැවිනි
            // `len`, `i` `needed` වෙතින් ආරම්භ වන `len` `length - needed` වන බැවින්, `i + 8` `length` ට වඩා අඩු හෝ සමාන බව සහතික කෙරේ.
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // ආරක්ෂාව: `i` දැන් `needed + len.div_euclid(8) * 8` වේ,
        // එබැවින් `i + left` = `needed + len` = `length`, එය අර්ථ දැක්වීම අනුව `msg.len()` ට සමාන වේ.
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// ආරම්භක යතුරු දෙක 0 ලෙස සකසා `Hasher<S>` සාදයි.
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}