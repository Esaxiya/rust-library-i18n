//! ලිබ්කෝර් prelude
//!
//! මෙම මොඩියුලය libstd හා සම්බන්ධ නොවන libcore භාවිතා කරන්නන් සඳහා අදහස් කෙරේ.
//! සම්මත පුස්තකාලයේ prelude ආකාරයටම `#![no_std]` භාවිතා කරන විට මෙම මොඩියුලය පෙරනිමියෙන් ආනයනය කෙරේ.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// prelude මධ්‍යයේ 2015 අනුවාදය.
///
/// වැඩි විස්තර සඳහා [module-level documentation](self) බලන්න.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// හරයේ prelude හි 2018 අනුවාදය.
///
/// වැඩි විස්තර සඳහා [module-level documentation](self) බලන්න.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// prelude මධ්‍යයේ 2021 අනුවාදය.
///
/// වැඩි විස්තර සඳහා [module-level documentation](self) බලන්න.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: තවත් දේවල් එකතු කරන්න.
}