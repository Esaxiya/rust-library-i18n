//! සම්මත පුස්තකාලයේ Panic සහාය.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// panic පිළිබඳ තොරතුරු සපයන ව්‍යුහයකි.
///
/// `PanicInfo` ව්‍යුහය [`set_hook`] ශ්‍රිතය මඟින් සකසන ලද panic hook වෙත යවනු ලැබේ.
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// panic හා සම්බන්ධ ගෙවීම් ආපසු ලබා දෙයි.
    ///
    /// මෙය පොදුවේ, නමුත් සැමවිටම නොවේ, `&'static str` හෝ [`String`] වේ.
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// `core` crate වෙතින් `panic!` මැක්‍රෝ (`std` වෙතින් නොවේ) ආකෘතිකරණ නූලක් සහ අමතර තර්ක කිහිපයක් සමඟ භාවිතා කර ඇත්නම්, එම පණිවිඩය [`fmt::write`] සමඟ භාවිතා කිරීමට සුදානම්ය.
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// panic ආරම්භ වූ ස්ථානය පිළිබඳ තොරතුරු තිබේ නම් ලබා දෙයි.
    ///
    /// මෙම ක්‍රමය දැනට සෑම විටම [`Some`] නැවත ලබා දෙනු ඇත, නමුත් මෙය future අනුවාද වල වෙනස් විය හැකිය.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: සමහර විට කිසිවක් ආපසු ලබා දීමට මෙය වෙනස් කළහොත්,
        // std::panicking::default_hook සහ std::panicking::begin_panic_fmt වලින් එම නඩුව සමඟ කටයුතු කරන්න.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: අපට downcast_ref: : භාවිතා කළ නොහැක<String>() මෙතන
        // සංගීත භාණ්ඩ ලිබ්කෝර් හි නොමැති නිසා!
        // `std::panic!` බහුවිධ තර්ක සමඟ කැඳවූ විට ගෙවීම් භාරය වේ, නමුත් එවැනි අවස්ථාවකදී පණිවිඩය ද ඇත.
        //

        self.location.fmt(formatter)
    }
}

/// panic හි පිහිටීම පිළිබඳ තොරතුරු අඩංගු ව්‍යුහයකි.
///
/// මෙම ව්යුහය [`PanicInfo::location()`] විසින් නිර්මාණය කර ඇත.
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// සමානාත්මතාවය සහ ඇණවුම සඳහා සැසඳීම් ගොනුව, රේඛාව සහ තීරු ප්‍රමුඛතාවයෙන් සිදු කෙරේ.
/// ලිපිගොනු සංසන්දනය කරනුයේ අනපේක්ෂිත විය හැකි `Path` නොව නූල් ලෙස ය.
/// වැඩි විස්තර සඳහා [`ස්ථානය: : ගොනුව] ලේඛනය බලන්න.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// මෙම ශ්‍රිතයේ ඇමතුම්කරුගේ ප්‍රභව ස්ථානය ලබා දෙයි.
    /// එම ශ්‍රිතයේ ඇමතුම විවරණය කර ඇත්නම්, එහි ඇමතුම් ස්ථානය නැවත ලබා දෙනු ඇත, එසේ නැතිනම් ලුහුබැඳ නොයන ශ්‍රිත ආයතනයක් තුළ පළමු ඇමතුම දක්වා සිරස් අතට ගන්න.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// [`Location`] ලෙස හැඳින්වෙන එය ලබා දෙයි.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// මෙම ශ්‍රිතයේ අර්ථ දැක්වීම තුළ සිට [`Location`] ලබා දෙයි.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // එකම හඳුනා නොගත් ශ්‍රිතය වෙනත් ස්ථානයක ධාවනය කිරීමෙන් අපට එකම ප්‍රති .ලය ලැබේ
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // ලුහුබැඳ ඇති ශ්‍රිතය වෙනත් ස්ථානයක ධාවනය කිරීමෙන් වෙනස් අගයක් ලැබේ
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// panic ආරම්භ වූ ප්‍රභව ගොනුවේ නම ලබා දෙයි.
    ///
    /// # `&str`, `&Path` නොවේ
    ///
    /// ආපසු ලබා දුන් නම සම්පාදක පද්ධතියේ ප්‍රභව මාර්ගයක් ගැන සඳහන් කරයි, නමුත් මෙය කෙලින්ම `&Path` ලෙස නිරූපණය කිරීම වලංගු නොවේ.
    /// සම්පාදනය කරන ලද කේතය අන්තර්ගතය සපයන පද්ධතියට වඩා වෙනස් `Path` ක්‍රියාත්මක කිරීමක් සහිත වෙනත් පද්ධතියක ක්‍රියාත්මක විය හැකි අතර මෙම පුස්තකාලයට දැනට වෙනත් "host path" වර්ගයක් නොමැත.
    ///
    /// වඩාත්ම පුදුම සහගත හැසිරීම සිදුවන්නේ "the same" ගොනුව මොඩියුල පද්ධතියේ විවිධ මාර්ග ඔස්සේ ළඟා විය හැකි විටය (සාමාන්‍යයෙන් `#[path = "..."]` ගුණාංගය හෝ ඊට සමාන)
    ///
    ///
    /// # Cross-compilation
    ///
    /// ධාරක වේදිකාව සහ ඉලක්ක වේදිකාව වෙනස් වන විට මෙම අගය `Path::new` හෝ ඒ හා සමාන ඉදිකිරීම්කරුවන් වෙත යැවීමට සුදුසු නොවේ.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// panic ආරම්භ වූ රේඛා අංකය ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// panic ආරම්භ වූ තීරුව ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// අභ්‍යන්තර trait libstd විසින් libstd සිට `panic_unwind` සහ අනෙකුත් panic ධාවන වේලාවන් වෙත දත්ත යැවීමට භාවිතා කරයි.
/// ඕනෑම වේලාවක ස්ථාවර කිරීමට අදහස් නොකෙරේ, භාවිතා නොකරන්න.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// අන්තර්ගතයේ සම්පූර්ණ අයිතිය ගන්න.
    /// ආපසු එන වර්ගය ඇත්ත වශයෙන්ම `Box<dyn Any + Send>` වේ, නමුත් අපට libcore හි `Box` භාවිතා කළ නොහැක.
    ///
    /// මෙම ක්‍රමය ඇමතීමෙන් පසුව, `self` හි ඉතිරිව ඇත්තේ ව්‍යාජ පෙරනිමි අගයක් පමණි.
    /// මෙම ක්‍රමය දෙවරක් ඇමතීම හෝ මෙම ක්‍රමය ඇමතීමෙන් පසු `get` ඇමතීම දෝෂයකි.
    ///
    /// panic ධාවන කාලය (`__rust_start_panic`) ලබා ගන්නේ ණයට ගත් `dyn BoxMeUp` පමණි.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// අන්තර්ගතය ණයට ගන්න.
    fn get(&mut self) -> &(dyn Any + Send);
}