#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! සම්පාදක බිල්ට් වර්ගවල පිරිසැලසුම සඳහා ව්‍යුහාත්මක අර්ථ දැක්වීම් අඩංගු වේ.
//!
//! අමු නිරූපණයන් සෘජුවම හැසිරවීම සඳහා අනාරක්ෂිත කේතයේ සම්ප්‍රේෂණ ඉලක්ක ලෙස ඒවා භාවිතා කළ හැකිය.
//!
//!
//! ඔවුන්ගේ අර්ථ දැක්වීම සෑම විටම `rustc_middle::ty::layout` හි අර්ථ දක්වා ඇති ABI සමඟ සැසඳිය යුතුය.
//!

/// `&dyn SomeTrait` වැනි trait වස්තුවක නිරූපණය.
///
/// මෙම ව්‍යුහයට `&dyn SomeTrait` සහ `Box<dyn AnotherTrait>` වැනි වර්ග වලට සමාන පිරිසැලසුමක් ඇත.
///
/// `TraitObject` පිරිසැලසුම් ගැලපීම සහතික කර ඇත, නමුත් එය trait වස්තු වර්ගය නොවේ (උදා: `&dyn SomeTrait` මත ක්ෂේත්‍ර කෙලින්ම ප්‍රවේශ විය නොහැක) හෝ එම පිරිසැලසුම පාලනය නොකරයි (අර්ථ දැක්වීම වෙනස් කිරීමෙන් `&dyn SomeTrait` හි පිරිසැලසුම වෙනස් නොවේ).
///
/// එය සැලසුම් කර ඇත්තේ පහත් මට්ටමේ තොරතුරු හැසිරවීමට අවශ්‍ය අනාරක්ෂිත කේතයක් භාවිතා කිරීමට පමණි.
///
/// සියලුම trait වස්තු සාමාන්‍යයෙන් යොමු කිරීමට ක්‍රමයක් නොමැත, එබැවින් මෙම වර්ගයේ අගයන් නිර්මාණය කිරීමට ඇති එකම ක්‍රමය වන්නේ [`std::mem::transmute`][transmute] වැනි ශ්‍රිතයන්ය.
/// ඒ හා සමානව, `TraitObject` අගයකින් සත්‍ය trait වස්තුවක් නිර්මාණය කිරීමට ඇති එකම ක්‍රමය `transmute` ය.
///
/// [transmute]: crate::intrinsics::transmute
///
/// නොගැලපෙන වර්ග සමඟ trait වස්තුවක් සංස්ලේෂණය කිරීම-දත්ත දර්ශක ලක්ෂ්‍යයේ අගය වර්ගයට vtable අනුරූප නොවන-නිර්වචනය නොකළ හැසිරීමට බොහෝ දුරට ඉඩ ඇත.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // උදාහරණයක් ලෙස trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // සම්පාදකයාට trait වස්තුවක් සෑදීමට ඉඩ දෙන්න
/// let object: &dyn Foo = &value;
///
/// // අමු නිරූපණය දෙස බලන්න
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // දත්ත දර්ශකය යනු `value` හි ලිපිනයයි
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // `object` වෙතින් `i32` vtable භාවිතා කිරීමට ප්‍රවේශම් වෙමින්, වෙනත් `i32` වෙත යොමු කරමින් නව වස්තුවක් සාදන්න
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // එය ක්‍රියා කළ යුත්තේ අප කෙලින්ම `other_value` වෙතින් trait වස්තුවක් සාදා ඇති ආකාරයට ය
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}