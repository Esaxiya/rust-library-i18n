//! මතක වෙන් කිරීමේ API

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// `AllocError` දෝෂය මඟින් සම්පත් විඩාව නිසා හෝ ලබා දී ඇති ආදාන තර්ක මෙම විබෙදන්නා සමඟ සංයෝජනය කිරීමේදී යම්කිසි වැරැද්දක් සිදුවිය හැකිය.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (trait දෝෂයේ පහළ ප්‍රවාහය සඳහා අපට මෙය අවශ්‍ය වේ)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// `Allocator` ක්‍රියාත්මක කිරීම මඟින් [`Layout`][] හරහා විස්තර කර ඇති අත්තනෝමතික දත්ත කොටස් වෙන් කිරීම, වර්ධනය කිරීම, හැකිලීම සහ ඉවත් කිරීම කළ හැකිය.
///
/// `Allocator` වෙන් කර ඇති මතකයට දර්ශක යාවත්කාලීන නොකර, `MyAlloc([u8; N])` වැනි විබෙදන්නෙකු ගෙනයාමට නොහැකි නිසා ZSTs, යොමු කිරීම් හෝ ස්මාර්ට් පොයින්ටර් මත ක්‍රියාත්මක කිරීමට සැලසුම් කර ඇත.
///
/// [`GlobalAlloc`][] මෙන් නොව, `Allocator` හි ශුන්‍ය ප්‍රමාණයේ වෙන් කිරීම් වලට අවසර ඇත.
/// යටින් ඇති විබෙදන්නෙක් මේ සඳහා (ජෙමල්ලොක් වැනි) සහය නොදක්වන්නේ නම් හෝ ශුන්‍ය දර්ශකයක් (`libc::malloc` වැනි) ආපසු ලබා දෙන්නේ නම්, මෙය ක්‍රියාත්මක කිරීමෙන් අල්ලා ගත යුතුය.
///
/// ### දැනට වෙන් කර ඇති මතකය
///
/// සමහර ක්‍රම මඟින් මතක බ්ලොක් එකක් * දැනට වෙන්කරන්නෙකු හරහා වෙන් කළ යුතුය.මෙයින් අදහස් කරන්නේ:
///
/// * එම මතක කොටස සඳහා ආරම්භක ලිපිනය මීට පෙර [`allocate`], [`grow`], හෝ [`shrink`] විසින් ආපසු ලබා දෙන ලදි
///
/// * මතක වාරණය පසුව අවලංගු කර නොමැත, එහිදී බ්ලොක් එක්කෝ [`deallocate`] වෙත කෙලින්ම විස්ථාපනය කරනු ලැබේ හෝ `Ok` ආපසු ලබා දෙන [`grow`] හෝ [`shrink`] වෙත යැවීමෙන් වෙනස් කරනු ලැබේ.
///
/// `grow` හෝ `shrink` විසින් `Err` ආපසු ලබා දී ඇත්නම්, සම්මත දර්ශකය වලංගු වේ.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### මතක ගැලපීම
///
/// සමහර ක්‍රම මඟින් පිරිසැලසුමක් * මතක බ්ලොක් එකකට ගැලපේ.
/// "fit" දක්වා වූ පිරිසැලසුමක් සඳහා මතක බ්ලොක් එකක් අදහස් කරන්නේ (හෝ ඒ හා සමානව, මතක බ්ලොක් එකක් "fit" දක්වා පිරිසැලසුමක් සඳහා) පහත සඳහන් කොන්දේසි තිබිය යුතුය:
///
/// * බ්ලොක් එක [`layout.align()`] හා සමාන පෙළගැස්වීමකින් වෙන් කළ යුතුය, සහ
///
/// * සපයා ඇති [`layout.size()`], `min ..= max` පරාසය තුළට වැටිය යුතුය, එහිදී:
///   - `min` බ්ලොක් වෙන් කිරීම සඳහා මෑතකදී භාවිතා කළ පිරිසැලසුමේ ප්‍රමාණය, සහ
///   - `max` යනු [`allocate`], [`grow`], හෝ [`shrink`] වෙතින් ආපසු ලබා දුන් නවතම සත්‍ය ප්‍රමාණයයි.
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * විබෙදන්නෙකුගෙන් ආපසු ලබා දෙන මතක කොටස් වලංගු මතකය වෙත යොමු විය යුතු අතර, එම අවස්ථාව සහ එහි සියලු ක්ලෝන ඉවත් වන තෙක් ඒවායේ වලංගු භාවය රඳවා ගත යුතුය.
///
/// * ක්ලෝනකරණය හෝ විබෙදන්නා ගෙනයාම මෙම විබෙදන්නාගෙන් ආපසු ලබා දුන් මතක කොටස් අවලංගු නොකළ යුතුය.ක්ලෝන විබෙදන්නෙකු එකම විබෙදන්නා මෙන් හැසිරිය යුතුය, සහ
///
/// * [*currently allocated*] වන මතක කොටසකට ඕනෑම දර්ශකයක් විබෙදන්නාගේ වෙනත් ක්‍රමයකට යොමු කළ හැකිය.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// මතක කොටසක් වෙන් කිරීමට උත්සාහ කරයි.
    ///
    /// සාර්ථක වූ විට, `layout` හි ප්‍රමාණය හා පෙළගැස්වීමේ සහතිකය සපුරාලන [`NonNull<[u8]>`][NonNull] නැවත ලබා දේ.
    ///
    /// ආපසු ලබා දුන් කොටසෙහි `layout.size()` හි නිශ්චිතව දක්වා ඇති ප්‍රමාණයට වඩා විශාල ප්‍රමාණයක් තිබිය හැකි අතර එහි අන්තර්ගතය ආරම්භක හෝ නොතිබිය හැකිය.
    ///
    /// # Errors
    ///
    /// `Err` නැවත ලබා දීමෙන් පෙන්නුම් කරන්නේ එක්කෝ මතකය අවසන් වී ඇති බව හෝ `layout`, විබෙදන්නාගේ ප්‍රමාණය හෝ පෙළගැස්වීමේ සීමාවන් සපුරාලන්නේ නැති බවයි.
    ///
    /// කලබල වීම හෝ ගබ්සා කිරීම වෙනුවට මතකය වෙහෙසට පත් කිරීම සඳහා `Err` නැවත ලබා දීමට ක්‍රියාත්මක කිරීම් දිරිමත් කරනු ලැබේ, නමුත් මෙය දැඩි අවශ්‍යතාවයක් නොවේ.
    /// (නිශ්චිතවම: මෙම trait මතකය වෙහෙසට පත්වීම නවත්වන යටින් පවතින දේශීය ප්‍රතිපාදන පුස්තකාලයක් මත ක්‍රියාත්මක කිරීම * නීත්‍යානුකූලයි.)
    ///
    /// ප්‍රතිපාදන දෝෂයකට ප්‍රතිචාර වශයෙන් ගණනය කිරීම අත්හිටුවීමට අපේක්ෂා කරන සේවාදායකයින්ට `panic!` හෝ ඊට සමාන සෘජුවම ආයාචනා කරනවාට වඩා [`handle_alloc_error`] ශ්‍රිතය ඇමතීමට උනන්දු කරනු ලැබේ.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// `allocate` වැනි හැසිරීම්, නමුත් ආපසු ලබා දුන් මතකය ශුන්‍ය-ආරම්භක බව සහතික කරයි.
    ///
    /// # Errors
    ///
    /// `Err` නැවත ලබා දීමෙන් පෙන්නුම් කරන්නේ එක්කෝ මතකය අවසන් වී ඇති බව හෝ `layout`, විබෙදන්නාගේ ප්‍රමාණය හෝ පෙළගැස්වීමේ සීමාවන් සපුරාලන්නේ නැති බවයි.
    ///
    /// කලබල වීම හෝ ගබ්සා කිරීම වෙනුවට මතකය වෙහෙසට පත් කිරීම සඳහා `Err` නැවත ලබා දීමට ක්‍රියාත්මක කිරීම් දිරිමත් කරනු ලැබේ, නමුත් මෙය දැඩි අවශ්‍යතාවයක් නොවේ.
    /// (නිශ්චිතවම: මෙම trait මතකය වෙහෙසට පත්වීම නවත්වන යටින් පවතින දේශීය ප්‍රතිපාදන පුස්තකාලයක් මත ක්‍රියාත්මක කිරීම * නීත්‍යානුකූලයි.)
    ///
    /// ප්‍රතිපාදන දෝෂයකට ප්‍රතිචාර වශයෙන් ගණනය කිරීම අත්හිටුවීමට අපේක්ෂා කරන සේවාදායකයින්ට `panic!` හෝ ඊට සමාන සෘජුවම ආයාචනා කරනවාට වඩා [`handle_alloc_error`] ශ්‍රිතය ඇමතීමට උනන්දු කරනු ලැබේ.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // ආරක්ෂාව: `alloc` වලංගු මතක වාරණයක් ලබා දෙයි
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// `ptr` විසින් යොමු කරන ලද මතකය අවලංගු කරයි.
    ///
    /// # Safety
    ///
    /// * `ptr` මෙම විබෙදන්නා හරහා [*currently allocated*] මතකය අවහිර කළ යුතුය, සහ
    /// * `layout` මතකය අවහිර කරන [*fit*] විය යුතුය.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// මතක කොටස දීර් extend කිරීමට උත්සාහ කරයි.
    ///
    /// දර්ශකයක් සහ වෙන් කළ මතකයේ සත්‍ය ප්‍රමාණය අඩංගු නව [`NonNull<[u8]>`][NonNull] ලබා දෙයි.`new_layout` විසින් විස්තර කරන ලද දත්ත රඳවා තබා ගැනීම සඳහා දර්ශකය සුදුසු වේ.
    /// මෙය සිදු කිරීම සඳහා, නව පිරිසැලසුමට සරිලන පරිදි `ptr` විසින් යොමු කරන ලද ප්‍රතිපාදන වෙන් කරන්නාට දීර් extend කළ හැකිය.
    ///
    /// මෙය `Ok` ආපසු ලබා දෙන්නේ නම්, `ptr` විසින් යොමු කරන ලද මතක කොටසෙහි හිමිකාරිත්වය මෙම විබෙදන්නා වෙත මාරු කර ඇත.
    /// මතකය නිදහස් වී හෝ නොතිබිය හැකි අතර, මෙම ක්‍රමයේ ප්‍රතිලාභ අගය හරහා එය නැවත අමතන්නා වෙත මාරු නොකළහොත් එය භාවිතයට ගත නොහැකි යැයි සැලකිය යුතුය.
    ///
    /// මෙම ක්‍රමය `Err` ආපසු ලබා දෙන්නේ නම්, මතක කොටසෙහි හිමිකාරිත්වය මෙම විබෙදන්නා වෙත මාරු කර නොමැති අතර මතක කොටසෙහි අන්තර්ගතය වෙනස් නොවේ.
    ///
    /// # Safety
    ///
    /// * `ptr` මෙම විබෙදන්නා හරහා [*currently allocated*] මතකය අවහිර කළ යුතුය.
    /// * `old_layout` මතකය අවහිර කරන [*fit*] විය යුතුය (`new_layout` තර්කය එයට නොගැලපේ.).
    /// * `new_layout.size()` `old_layout.size()` ට වඩා වැඩි හෝ සමාන විය යුතුය.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// නව පිරිසැලසුම මඟින් විබෙදන්නාගේ ප්‍රමාණය හා පෙළගැස්වීමේ සීමාවන් සපුරාලන්නේ නැතිනම් හෝ වර්ධනය වීම අසමත් වුවහොත් `Err` ලබා දෙයි.
    ///
    /// කලබල වීම හෝ ගබ්සා කිරීම වෙනුවට මතකය වෙහෙසට පත් කිරීම සඳහා `Err` නැවත ලබා දීමට ක්‍රියාත්මක කිරීම් දිරිමත් කරනු ලැබේ, නමුත් මෙය දැඩි අවශ්‍යතාවයක් නොවේ.
    /// (නිශ්චිතවම: මෙම trait මතකය වෙහෙසට පත්වීම නවත්වන යටින් පවතින දේශීය ප්‍රතිපාදන පුස්තකාලයක් මත ක්‍රියාත්මක කිරීම * නීත්‍යානුකූලයි.)
    ///
    /// ප්‍රතිපාදන දෝෂයකට ප්‍රතිචාර වශයෙන් ගණනය කිරීම අත්හිටුවීමට අපේක්ෂා කරන සේවාදායකයින්ට `panic!` හෝ ඊට සමාන සෘජුවම ආයාචනා කරනවාට වඩා [`handle_alloc_error`] ශ්‍රිතය ඇමතීමට උනන්දු කරනු ලැබේ.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // ආරක්ෂාව: මන්ද `new_layout.size()` වඩා විශාල හෝ සමාන විය යුතුය
        // `old_layout.size()`, පැරණි හා නව මතක වෙන් කිරීම `old_layout.size()` බයිට් සඳහා කියවීම සහ ලිවීම සඳහා වලංගු වේ.
        // එසේම, පැරණි ප්‍රතිපාදන තවමත් වෙන් කර නොමැති නිසා එයට `new_ptr` අතිච්ඡාදනය කළ නොහැක.
        // මේ අනුව, `copy_nonoverlapping` වෙත ඇමතුම ආරක්ෂිතයි.
        // `dealloc` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව අමතන්නා විසින් තහවුරු කළ යුතුය.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// `grow` වැනි හැසිරීම් පමණක් නොව, නව අන්තර්ගතයන් නැවත ලබා දීමට පෙර බිංදුවට සකසා ඇති බව සහතික කරයි.
    ///
    /// සාර්ථක ඇමතුමකින් පසු මතක කොටසෙහි පහත අන්තර්ගතයන් අඩංගු වේ
    /// `grow_zeroed`:
    ///   * `0..old_layout.size()` බයිට් මුල් වෙන් කිරීමෙන් ආරක්ෂා වේ.
    ///   * විබෙදුම්කරු ක්‍රියාත්මක කිරීම මත පදනම්ව `old_layout.size()..old_size` බයිට් සංරක්ෂණය කර හෝ ශුන්‍ය වේ.
    ///   `old_size` `grow_zeroed` ඇමතුමට පෙර මතක කොටසෙහි විශාලත්වය, එය වෙන් කළ විට මුලින් ඉල්ලා සිටි ප්‍රමාණයට වඩා විශාල විය හැකිය.
    ///   * `old_size..new_size` බයිට් ශුන්‍ය වේ.`new_size` යන්නෙන් අදහස් කරන්නේ `grow_zeroed` ඇමතුම මඟින් ලබා දුන් මතක කොටසෙහි ප්‍රමාණයයි.
    ///
    /// # Safety
    ///
    /// * `ptr` මෙම විබෙදන්නා හරහා [*currently allocated*] මතකය අවහිර කළ යුතුය.
    /// * `old_layout` මතකය අවහිර කරන [*fit*] විය යුතුය (`new_layout` තර්කය එයට නොගැලපේ.).
    /// * `new_layout.size()` `old_layout.size()` ට වඩා වැඩි හෝ සමාන විය යුතුය.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// නව පිරිසැලසුම මඟින් විබෙදන්නාගේ ප්‍රමාණය හා පෙළගැස්වීමේ සීමාවන් සපුරාලන්නේ නැතිනම් හෝ වර්ධනය වීම අසමත් වුවහොත් `Err` ලබා දෙයි.
    ///
    /// කලබල වීම හෝ ගබ්සා කිරීම වෙනුවට මතකය වෙහෙසට පත් කිරීම සඳහා `Err` නැවත ලබා දීමට ක්‍රියාත්මක කිරීම් දිරිමත් කරනු ලැබේ, නමුත් මෙය දැඩි අවශ්‍යතාවයක් නොවේ.
    /// (නිශ්චිතවම: මෙම trait මතකය වෙහෙසට පත්වීම නවත්වන යටින් පවතින දේශීය ප්‍රතිපාදන පුස්තකාලයක් මත ක්‍රියාත්මක කිරීම * නීත්‍යානුකූලයි.)
    ///
    /// ප්‍රතිපාදන දෝෂයකට ප්‍රතිචාර වශයෙන් ගණනය කිරීම අත්හිටුවීමට අපේක්ෂා කරන සේවාදායකයින්ට `panic!` හෝ ඊට සමාන සෘජුවම ආයාචනා කරනවාට වඩා [`handle_alloc_error`] ශ්‍රිතය ඇමතීමට උනන්දු කරනු ලැබේ.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // ආරක්ෂාව: මන්ද `new_layout.size()` වඩා විශාල හෝ සමාන විය යුතුය
        // `old_layout.size()`, පැරණි හා නව මතක වෙන් කිරීම `old_layout.size()` බයිට් සඳහා කියවීම සහ ලිවීම සඳහා වලංගු වේ.
        // එසේම, පැරණි ප්‍රතිපාදන තවමත් වෙන් කර නොමැති නිසා එයට `new_ptr` අතිච්ඡාදනය කළ නොහැක.
        // මේ අනුව, `copy_nonoverlapping` වෙත ඇමතුම ආරක්ෂිතයි.
        // `dealloc` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව අමතන්නා විසින් තහවුරු කළ යුතුය.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// මතක කොටස හැකිලීමට උත්සාහ කරයි.
    ///
    /// දර්ශකයක් සහ වෙන් කළ මතකයේ සත්‍ය ප්‍රමාණය අඩංගු නව [`NonNull<[u8]>`][NonNull] ලබා දෙයි.`new_layout` විසින් විස්තර කරන ලද දත්ත රඳවා තබා ගැනීම සඳහා දර්ශකය සුදුසු වේ.
    /// මෙය සිදු කිරීම සඳහා, නව පිරිසැලසුමට සරිලන පරිදි `ptr` විසින් යොමු කරන ලද ප්‍රතිපාදන වෙන් කරන්නා විසින් හැකිලෙනු ඇත.
    ///
    /// මෙය `Ok` ආපසු ලබා දෙන්නේ නම්, `ptr` විසින් යොමු කරන ලද මතක කොටසෙහි හිමිකාරිත්වය මෙම විබෙදන්නා වෙත මාරු කර ඇත.
    /// මතකය නිදහස් වී හෝ නොතිබිය හැකි අතර, මෙම ක්‍රමයේ ප්‍රතිලාභ අගය හරහා එය නැවත අමතන්නා වෙත මාරු නොකළහොත් එය භාවිතයට ගත නොහැකි යැයි සැලකිය යුතුය.
    ///
    /// මෙම ක්‍රමය `Err` ආපසු ලබා දෙන්නේ නම්, මතක කොටසෙහි හිමිකාරිත්වය මෙම විබෙදන්නා වෙත මාරු කර නොමැති අතර මතක කොටසෙහි අන්තර්ගතය වෙනස් නොවේ.
    ///
    /// # Safety
    ///
    /// * `ptr` මෙම විබෙදන්නා හරහා [*currently allocated*] මතකය අවහිර කළ යුතුය.
    /// * `old_layout` මතකය අවහිර කරන [*fit*] විය යුතුය (`new_layout` තර්කය එයට නොගැලපේ.).
    /// * `new_layout.size()` `old_layout.size()` ට වඩා කුඩා හෝ සමාන විය යුතුය.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// නව පිරිසැලසුම මඟින් විබෙදන්නාගේ ප්‍රමාණය හා පෙළගැස්වීමේ සීමාවන් සපුරාලන්නේ නැතිනම් හෝ හැකිලීම අසමත් වුවහොත් `Err` ලබා දෙයි.
    ///
    /// කලබල වීම හෝ ගබ්සා කිරීම වෙනුවට මතකය වෙහෙසට පත් කිරීම සඳහා `Err` නැවත ලබා දීමට ක්‍රියාත්මක කිරීම් දිරිමත් කරනු ලැබේ, නමුත් මෙය දැඩි අවශ්‍යතාවයක් නොවේ.
    /// (නිශ්චිතවම: මෙම trait මතකය වෙහෙසට පත්වීම නවත්වන යටින් පවතින දේශීය ප්‍රතිපාදන පුස්තකාලයක් මත ක්‍රියාත්මක කිරීම * නීත්‍යානුකූලයි.)
    ///
    /// ප්‍රතිපාදන දෝෂයකට ප්‍රතිචාර වශයෙන් ගණනය කිරීම අත්හිටුවීමට අපේක්ෂා කරන සේවාදායකයින්ට `panic!` හෝ ඊට සමාන සෘජුවම ආයාචනා කරනවාට වඩා [`handle_alloc_error`] ශ්‍රිතය ඇමතීමට උනන්දු කරනු ලැබේ.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // ආරක්ෂාව: මන්ද `new_layout.size()` වඩා අඩු හෝ සමාන විය යුතුය
        // `old_layout.size()`, පැරණි හා නව මතක වෙන් කිරීම `new_layout.size()` බයිට් සඳහා කියවීම සහ ලිවීම සඳහා වලංගු වේ.
        // එසේම, පැරණි ප්‍රතිපාදන තවමත් වෙන් කර නොමැති නිසා එයට `new_ptr` අතිච්ඡාදනය කළ නොහැක.
        // මේ අනුව, `copy_nonoverlapping` වෙත ඇමතුම ආරක්ෂිතයි.
        // `dealloc` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව අමතන්නා විසින් තහවුරු කළ යුතුය.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// `Allocator` හි මෙම අවස්ථාව සඳහා "by reference" ඇඩැප්ටරයක් සාදයි.
    ///
    /// ආපසු ලබා දුන් ඇඩැප්ටරය `Allocator` ද ක්‍රියාත්මක කරන අතර මෙය සරලවම ණයට ගනී.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // ආරක්ෂාව: ආරක්ෂිත කොන්ත්රාත්තුව අමතන්නා විසින් තහවුරු කළ යුතුය
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ආරක්ෂාව: ආරක්ෂිත කොන්ත්රාත්තුව අමතන්නා විසින් තහවුරු කළ යුතුය
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ආරක්ෂාව: ආරක්ෂිත කොන්ත්රාත්තුව අමතන්නා විසින් තහවුරු කළ යුතුය
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ආරක්ෂාව: ආරක්ෂිත කොන්ත්රාත්තුව අමතන්නා විසින් තහවුරු කළ යුතුය
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}