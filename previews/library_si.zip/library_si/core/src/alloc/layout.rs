use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// මෙම ශ්‍රිතය එක් තැනක භාවිතා වන අතර එය ක්‍රියාත්මක කිරීම සඳහා පෙළඹවිය හැකි අතර, එසේ කිරීමට පෙර දැරූ උත්සාහයන් rustc මන්දගාමී විය:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// මතක කොටසක පිරිසැලසුම.
///
/// `Layout` හි උදාහරණයක් විශේෂිත මතක සැකැස්මක් විස්තර කරයි.
/// විබෙදන්නෙකුට ලබා දීම සඳහා ඔබ ආදාන ලෙස `Layout` ඉහළට සාදයි.
///
/// සියලුම පිරිසැලසුම් වලට සම්බන්ධිත ප්‍රමාණයක් සහ බලයේ දෙකක පෙළගැස්මක් ඇත.
///
/// (සියලු මතක ඉල්ලීම් ශුන්‍ය නොවන ප්‍රමාණයෙන් `GlobalAlloc` ට අවශ්‍ය වුවද, පිරිසැලසුමට ශුන්‍ය නොවන ප්‍රමාණයක් තිබිය යුතු බව සලකන්න.
/// අමතන්නා විසින් මෙවැනි කොන්දේසි සපුරා ඇති බවට සහතික විය යුතුය, ලිහිල් අවශ්‍යතා සහිත නිශ්චිත විබෙදන්නන් භාවිතා කරන්න, නැතහොත් වඩා සැහැල්ලු `Allocator` අතුරුමුහුණත භාවිතා කරන්න.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // ඉල්ලූ මතක කොටසෙහි ප්‍රමාණය, බයිට් වලින් මනිනු ලැබේ.
    size_: usize,

    // ඉල්ලූ මතක කොටස පෙළගැස්වීම, බයිට් වලින් මනිනු ලැබේ.
    // `posix_memalign` වැනි API වලට එය අවශ්‍ය වන නිසාත්, පිරිසැලසුම් සාදන්නන් මත පැටවීම සාධාරණ බාධාවක් වන නිසාත් මෙය සැමවිටම දෙයාකාරයක බලයක් බව අපි සහතික කරමු.
    //
    //
    // (කෙසේ වෙතත්, අපට සමානව `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.) අවශ්‍ය නොවේ
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// දී ඇති `size` සහ `align` වෙතින් `Layout` සාදයි, නැතහොත් පහත සඳහන් කොන්දේසි කිසිවක් සපුරා නොමැති නම් `LayoutError` ආපසු ලබා දෙයි:
    ///
    /// * `align` ශුන්‍ය නොවිය යුතුය,
    ///
    /// * `align` දෙකක බලයක් විය යුතුය,
    ///
    /// * `size`, `align` හි ආසන්නතම ගුණකය දක්වා වටකුරු විට, පිටාර ගැලීම නොකළ යුතුය (එනම්, වටකුරු අගය `usize::MAX` ට වඩා අඩු හෝ සමාන විය යුතුය).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (බලය දෙකේ ඇඟවුම් කරන්නේ පෙළගැස්වීම!=0.)

        // වටකුරු ප්‍රමාණය:
        //   size_rounded_up=(ප්‍රමාණය + පෙළගස්වන්න, 1)&! (පෙළගස්වන්න, 1);
        //
        // එම පෙළගැස්ම ඉහළින් අපි දනිමු!=0.
        // එකතු කිරීම (පෙළගස්වන්න, 1) පිටාර ගැලෙන්නේ නැත්නම්, වටකුරු කිරීම හොඳ වනු ඇත.
        //
        // අනෙක් අතට,&-මාස්ක් සමඟ! (පෙළගස්වන්න, 1) අඩු කරන්නේ අඩු ඇණවුම්-බිටු පමණි.
        // මේ අනුව එකතුව සමඟ පිටාර ගැලීම සිදුවුවහොත්, එම පිටාර ගැලීම අහෝසි කිරීමට තරම්&-මාස්ක් අඩු කළ නොහැක.
        //
        //
        // ඉහත ඇඟවෙන්නේ සාරාංශ පිටාර ගැලීම සඳහා පරීක්ෂා කිරීම අත්‍යවශ්‍ය සහ ප්‍රමාණවත් බවයි.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // ආරක්ෂාව: `from_size_align_unchecked` සඳහා කොන්දේසි තිබේ
        // ඉහත පරීක්ෂා කර ඇත.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// සියලු චෙක්පත් මඟ හැර, පිරිසැලසුමක් සාදයි.
    ///
    /// # Safety
    ///
    /// [`Layout::from_size_align`] වෙතින් පූර්ව කොන්දේසි සත්‍යාපනය නොකරන බැවින් මෙම ශ්‍රිතය අනාරක්ෂිත ය.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // ආරක්ෂාව: අමතන්නා `align` බිංදුවට වඩා වැඩි බව සහතික කළ යුතුය.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// මෙම පිරිසැලසුමේ මතක කොටස සඳහා අවම ප්‍රමාණය බයිට් වලින්.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// මෙම පිරිසැලසුමේ මතක කොටස සඳහා අවම බයිට් පෙළගැස්ම.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// `T` වර්ගයේ අගයක් රඳවා ගැනීමට සුදුසු `Layout` සාදයි.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // සුරක්ෂිතතාව: පෙළගැස්ම Rust මගින් දෙකක බලයක් බවට සහතික වේ
        // ප්‍රමාණය + පෙළගැස්වීම අපගේ ලිපින අවකාශයට ගැලපෙන බවට සහතික වේ.
        // එහි ප්‍රති As ලයක් ලෙස panics කේතය ප්‍රමාණවත් ලෙස ප්‍රශස්තිකරණය කර නොමැති නම් ඇතුළත් කිරීම වළක්වා ගැනීමට මෙහි පරීක්ෂා නොකළ ඉදිකිරීම්කරු භාවිතා කරන්න.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` සඳහා පසුබිම් ව්‍යුහය වෙන් කිරීම සඳහා භාවිතා කළ හැකි වාර්තාවක් විස්තර කරන පිරිසැලසුම නිෂ්පාදනය කරයි (එය trait හෝ පෙත්තක් වැනි වෙනත් ප්‍රමාණයේ වර්ගයක් විය හැකිය).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // ආරක්ෂාව: මෙය අනාරක්ෂිත ප්‍රභේදය භාවිතා කරන්නේ ඇයිද යන්න සඳහා `new` හි තාර්කිකත්වය බලන්න
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` සඳහා පසුබිම් ව්‍යුහය වෙන් කිරීම සඳහා භාවිතා කළ හැකි වාර්තාවක් විස්තර කරන පිරිසැලසුම නිෂ්පාදනය කරයි (එය trait හෝ පෙත්තක් වැනි වෙනත් ප්‍රමාණයේ වර්ගයක් විය හැකිය).
    ///
    /// # Safety
    ///
    /// මෙම ශ්‍රිතය ඇමතීමට ආරක්ෂිත වන්නේ පහත සඳහන් කොන්දේසි තිබේ නම් පමණි:
    ///
    /// - `T` යනු `Sized` නම්, මෙම ක්‍රියාව සැමවිටම ඇමතීමට ආරක්ෂිත වේ.
    /// - `T` හි නම් නොකළ වලිගය නම්:
    ///     - [slice], පසුව පෙති වලිගයේ දිග සමෝධානික සංඛ්‍යාවක් විය යුතු අතර,*සම්පූර්ණ අගය*(ගතික වලිගයේ දිග + සංඛ්‍යානමය ප්‍රමාණයේ උපසර්ගය) ප්‍රමාණය `isize` ට ගැලපේ.
    ///     - [trait object], එවිට දර්ශකයේ vtable කොටස, අවලංගු නොවන සංයෝජනයක් මගින් අත්පත් කරගත් `T` වර්ගය සඳහා වලංගු vtable එකකට යොමු විය යුතු අතර,*සම්පූර්ණ වටිනාකම*(ගතික වලිගයේ දිග + සංඛ්‍යානමය ප්‍රමාණයේ උපසර්ගය) `isize` ට ගැලපේ.
    ///
    ///     - (unstable) [extern type], එවිට මෙම ශ්‍රිතය ඇමතීමට සැමවිටම ආරක්ෂිත වේ, නමුත් බාහිර වර්ගයේ පිරිසැලසුම නොදන්නා බැවින් panic හෝ වෙනත් ආකාරයකින් වැරදි අගයක් ලබා දිය හැකිය.
    ///     බාහිර වර්ගයේ වලිගයකට යොමු කිරීමේදී [`Layout::for_value`] හා සමාන හැසිරීම මෙයයි.
    ///     - එසේ නොමැති නම්, මෙම ශ්‍රිතය ඇමතීමට සම්ප්‍රදායිකව අවසර නැත.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // ආරක්ෂාව: අපි මෙම කාර්යයන්හි පූර්වාවශ්‍යතාවයන් අමතන්නාට ලබා දෙන්නෙමු
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // ආරක්ෂාව: මෙය අනාරක්ෂිත ප්‍රභේදය භාවිතා කරන්නේ ඇයිද යන්න සඳහා `new` හි තාර්කිකත්වය බලන්න
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// මෙම පිරිසැලසුම සඳහා හොඳින් ගැලපෙන `NonNull` නිර්මාණය කරයි.
    ///
    /// දර්ශක අගය වලංගු දර්ශකයක් නිරූපණය කළ හැකි බව සලකන්න, එයින් අදහස් වන්නේ මෙය "not yet initialized" සෙන්ඩිනල් අගයක් ලෙස භාවිතා නොකළ යුතු බවයි.
    /// කම්මැලි ලෙස වෙන් කරන වර්ග වෙනත් ආකාරයකින් ආරම්භ කිරීම නිරීක්ෂණය කළ යුතුය.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // ආරක්ෂාව: පෙළගැස්ම ශුන්‍ය නොවන බවට සහතික වේ
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// `self` හා සමාන පිරිසැලසුමක අගය රඳවා තබා ගත හැකි වාර්තාවක් විස්තර කරන පිරිසැලසුමක් සාදයි, නමුත් එය `align` (බයිට් වලින් මනිනු ලැබේ) පෙළගැස්වීමට පෙළගස්වා ඇත.
    ///
    ///
    /// `self` දැනටමත් නියමිත පෙළගැස්ම සපුරාලන්නේ නම්, එවිට `self` ආපසු ලබා දේ.
    ///
    /// ආපසු ලබා දුන් පිරිසැලසුමට වෙනස් පෙළගැස්මක් තිබේද යන්න නොසලකා මෙම ක්‍රමය සමස්ත ප්‍රමාණයට කිසිදු පෑඩින් එකක් එකතු නොකරන බව සලකන්න.
    /// වෙනත් වචන වලින් කිවහොත්, `K` ප්‍රමාණය 16 නම්, `K.align_to(32)`*තවමත්* ප්‍රමාණය 16 වේ.
    ///
    /// `self.size()` සහ දී ඇති `align` සංයෝජනය [`Layout::from_size_align`] හි ලැයිස්තුගත කර ඇති කොන්දේසි උල්ලං if නය කරන්නේ නම් දෝෂයක් ලබා දෙයි.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// පහත සඳහන් ලිපිනය `align` (බයිට් වලින් මනිනු ලැබේ) තෘප්තිමත් කරනු ඇති බව සහතික කිරීම සඳහා අපි `self` ට පසුව ඇතුළත් කළ යුතු පෑඩින් ප්‍රමාණය ලබා දෙයි.
    ///
    /// උදා: `self.size()` 9 නම්, `self.padding_needed_for(4)` 3 නැවත ලබා දෙයි, මන්ද එය 4-පෙළගස්වන ලිපිනයක් ලබා ගැනීමට අවශ්‍ය අවම පයිට් ගණනයි (අනුරූප මතක කොටස 4-පෙළගැස්වූ ලිපිනයකින් ආරම්භ වේ යැයි උපකල්පනය කර).
    ///
    ///
    /// `align` යනු දෙකක බලයක් නොවේ නම් මෙම ශ්‍රිතයේ ප්‍රතිලාභ අගයට අර්ථයක් නැත.
    ///
    /// ආපසු ලබා දුන් අගයෙහි උපයෝගීතාවයට `align` මුළු වෙන් කළ මතක කොටස සඳහා ආරම්භක ලිපිනය පෙළගැස්වීමට වඩා අඩු හෝ සමාන විය යුතු බව සලකන්න.මෙම බාධකය සපුරාලිය හැකි එක් ක්‍රමයක් වන්නේ `align <= self.align()` සහතික කිරීමයි.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // වටකුරු අගය:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // ඉන්පසු අපි පෑඩින් වෙනස නැවත ලබා දෙන්නෙමු: `len_rounded_up - len`.
        //
        // අපි පුරාම මොඩියුලර් අංක ගණිතය භාවිතා කරමු:
        //
        // 1. align යනු 0 ලෙස සහතික කර ඇත, එබැවින් පෙළගස්වන්න, 1 සැමවිටම වලංගු වේ.
        //
        // 2.
        // `len + align - 1` බොහෝ විට `align - 1` මගින් පිටාර ගැලිය හැකිය, එබැවින් `!(align - 1)` සමඟ&-mask පිටාර ගැලීමේදී `len_rounded_up` 0 බව සහතික කරයි.
        //
        //    මේ අනුව ආපසු ලබා දුන් පෑඩින්, `len` වෙත එකතු කළ විට, 0 ලබා දෙයි, එය `align` පෙළගැස්ම සුළු වශයෙන් තෘප්තිමත් කරයි.
        //
        // (ඇත්ත වශයෙන්ම, ඉහත ආකාරයට ප්‍රමාණය හා පෑඩින් පිටාර ගැලීම මතකයේ කොටස් වෙන් කිරීමට උත්සාහ කිරීම, කෙසේ වෙතත්, විබෙදන්නාට කෙසේ හෝ දෝෂයක් ඇතිවිය හැකිය.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// පිරිසැලසුමේ පෙළගැස්මේ ගුණයක් දක්වා මෙම පිරිසැලසුමේ ප්‍රමාණය වට කර පිරිසැලසුමක් සාදයි.
    ///
    ///
    /// මෙය `padding_needed_for` හි ප්‍රති result ලය පිරිසැලසුමේ වත්මන් ප්‍රමාණයට එකතු කිරීමට සමාන වේ.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // මෙය පිටාර ගැලිය නොහැක.පිරිසැලසුමේ වෙනස්වීමෙන් උපුටා දැක්වීම:
        // > `size`, `align` හි ආසන්නතම ගුණකය දක්වා වූ විට,
        // > පිටාර ගැලීම නොකළ යුතුය (එනම් වටකුරු අගය ඊට වඩා අඩු විය යුතුය
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// `self` හි `n` අවස්ථාවන් සඳහා වන වාර්තාව විස්තර කරන පිරිසැලසුමක් සාදයි, එක් එක් අවස්ථාව සඳහා ඉල්ලුම් කළ ප්‍රමාණය හා පෙළගැස්ම ලබා දී ඇති බව සහතික කිරීම සඳහා එකිනෙකා අතර සුදුසු පෑඩින් ප්‍රමාණයක් ඇත.
    /// සාර්ථක වූ විට, `(k, offs)` ආපසු ලබා දෙන අතර `k` යනු අරාවෙහි පිරිසැලසුම වන අතර `offs` යනු අරාවෙහි එක් එක් මූලද්‍රව්‍යයේ ආරම්භය අතර දුර වේ.
    ///
    /// අංක ගණිත පිටාර ගැලීමේදී, `LayoutError` ආපසු ලබා දේ.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // මෙය පිටාර ගැලිය නොහැක.පිරිසැලසුමේ වෙනස්වීමෙන් උපුටා දැක්වීම:
        // > `size`, `align` හි ආසන්නතම ගුණකය දක්වා වූ විට,
        // > පිටාර ගැලීම නොකළ යුතුය (එනම් වටකුරු අගය ඊට වඩා අඩු විය යුතුය
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // සුරක්ෂිතභාවය: self.align දැනටමත් වලංගු බව දන්නා අතර වෙන්කිරීමේ ප්‍රමාණයද ඇත
        // පෑඩ් දැනටමත්.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// `next` නිසියාකාරව පෙලගැසී ඇති බව සහතික කිරීම සඳහා අවශ්‍ය ඕනෑම පෑඩින් එකක් ඇතුළුව `self` සහ `next` සඳහා වන වාර්තාව විස්තර කරන පිරිසැලසුමක් සාදයි, නමුත් *පසුපස පෑඩින් නොමැත*.
    ///
    /// C නිරූපණ පිරිසැලසුම `repr(C)` හා සැසඳීම සඳහා, සියලු ක්ෂේත්‍ර සමඟ පිරිසැලසුම දීර් after කිරීමෙන් පසු ඔබ `pad_to_align` අමතන්න.
    /// (සුපුරුදු Rust නිරූපණ පිරිසැලසුම `repr(Rust)`, as it is unspecified.) හා සැසඳීමට ක්‍රමයක් නොමැත
    ///
    /// කොටස් දෙකේම පෙළගැස්ම සහතික කිරීම සඳහා, එහි ප්‍රති layout ලයක් ලෙස සැකැස්ම පෙළගැස්වීම `self` සහ `next` හි උපරිම වේ.
    ///
    /// `Ok((k, offset))` නැවත ලබා දෙයි, එහිදී `k` යනු සංයුක්ත වාර්තාවේ පිරිසැලසුම වන අතර `offset` යනු බයිට් වලින්, සංයුක්ත වාර්තාව තුළ කාවැදී ඇති `next` ආරම්භයේ සාපේක්ෂ ස්ථානයයි (වාර්තාව ඕෆ්සෙට් 0 සිට ආරම්භ වේ යැයි උපකල්පනය කර).
    ///
    ///
    /// අංක ගණිත පිටාර ගැලීමේදී, `LayoutError` ආපසු ලබා දේ.
    ///
    /// # Examples
    ///
    /// `#[repr(C)]` ව්‍යුහයක පිරිසැලසුම සහ එහි ක්ෂේත්‍ර පිරිසැලසුම් වලින් ක්ෂේත්‍රවල ඕෆ්සෙට් ගණනය කිරීම සඳහා:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // `pad_to_align` සමඟ අවසන් කිරීමට මතක තබා ගන්න!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // එය ක්‍රියාත්මක වන බව පරීක්ෂා කරන්න
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// `self` හි `n` අවස්ථා සඳහා වන වාර්තාව විස්තර කරන පිරිසැලසුමක් සාදයි.
    ///
    /// `repeat` මෙන් නොව, `repeat_packed` හි පුනරාවර්තන අවස්ථා නිසි ලෙස පෙලගැසී ඇති බවට `repeat_packed` සහතික නොවන බව සලකන්න.
    /// වෙනත් වචන වලින් කිවහොත්, `repeat_packed` මඟින් ආපසු ලබා දුන් පිරිසැලසුම අරාව වෙන් කිරීම සඳහා භාවිතා කරන්නේ නම්, අරාවෙහි ඇති සියලුම අංග නිසි ලෙස පෙළ ගැසී ඇති බවට සහතික නොවේ.
    ///
    /// අංක ගණිත පිටාර ගැලීමේදී, `LayoutError` ආපසු ලබා දේ.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// `self` සඳහා වන වාර්තාව විස්තර කරන පිරිසැලසුමක් සාදයි, පසුව `next` දෙක අතර අමතර පෑඩින් නොමැත.
    /// පෑඩින් කිසිවක් ඇතුළත් කර නොමැති බැවින්, `next` පෙළගැස්වීම අදාල නොවේ, ප්‍රති ing ලයක් ලෙස සැකැස්ම තුළට * කිසිසේත් ඇතුළත් නොවේ.
    ///
    ///
    /// අංක ගණිත පිටාර ගැලීමේදී, `LayoutError` ආපසු ලබා දේ.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// `[T; n]` සඳහා වාර්තාව විස්තර කරන පිරිසැලසුමක් සාදයි.
    ///
    /// අංක ගණිත පිටාර ගැලීමේදී, `LayoutError` ආපසු ලබා දේ.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// `Layout::from_size_align` හෝ වෙනත් `Layout` ඉදිකිරීම්කරුට ලබා දී ඇති පරාමිතීන් එහි ලේඛනගත සීමාවන් සපුරාලන්නේ නැත.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (trait දෝෂයේ පහළ ප්‍රවාහය සඳහා අපට මෙය අවශ්‍ය වේ)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}