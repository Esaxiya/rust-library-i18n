//! නිශ්චිත දිග අරා සඳහා `Eq` වැනි දේවල් නිශ්චිත දිගක් දක්වා ක්‍රියාත්මක කිරීම.
//! අවසානයේදී, අපට සෑම දිගකටම සාමාන්‍යකරණය කිරීමට හැකි විය යුතුය.
//!
//! *[See also the array primitive type](array).*
//!

#![stable(feature = "core_array", since = "1.36.0")]

use crate::borrow::{Borrow, BorrowMut};
use crate::cmp::Ordering;
use crate::convert::{Infallible, TryFrom};
use crate::fmt;
use crate::hash::{self, Hash};
use crate::iter::TrustedLen;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{Index, IndexMut};
use crate::slice::{Iter, IterMut};

mod iter;

#[stable(feature = "array_value_iter", since = "1.51.0")]
pub use iter::IntoIter;

/// `T` වෙත යොමු කිරීම දිග 1 අරාවකට යොමු කිරීමක් බවට පරිවර්තනය කරයි (පිටපත් නොකර).
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_ref<T>(s: &T) -> &[T; 1] {
    // ආරක්ෂාව: `&T` සිට `&[T; 1]` දක්වා පරිවර්තනය කිරීම ශබ්දය.
    unsafe { &*(s as *const T).cast::<[T; 1]>() }
}

/// `T` වෙත විකෘති යොමුව 1 දිගට (පිටපත් නොකර) විකෘති යොමු කිරීමක් බවට පරිවර්තනය කරයි.
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_mut<T>(s: &mut T) -> &mut [T; 1] {
    // ආරක්ෂාව: `&mut T` සිට `&mut [T; 1]` දක්වා පරිවර්තනය කිරීම ශබ්දය.
    unsafe { &mut *(s as *mut T).cast::<[T; 1]>() }
}

/// trait උපයෝගීතාව ක්‍රියාත්මක කරනු ලබන්නේ ස්ථාවර ප්‍රමාණයේ අරා මත පමණි
///
/// මෙම trait බොහෝ පාර-දත්ත පිපිරීමක් ඇති නොකර ස්ථාවර ප්‍රමාණයේ අරා මත වෙනත් traits ක්‍රියාත්මක කිරීමට භාවිතා කළ හැකිය.
///
/// ක්‍රියාත්මක කරන්නන් ස්ථාවර ප්‍රමාණයේ අරා වලට සීමා කිරීම සඳහා trait අනාරක්ෂිත ලෙස සලකුණු කර ඇත.
/// මෙම trait භාවිතා කරන්නෙකුට ස්ථාවර ප්‍රමාණයේ අරාව මතකයේ නිශ්චිත පිරිසැලසුමක් ඇති බව උපකල්පනය කළ හැකිය (නිදසුනක් ලෙස, අනාරක්ෂිත ආරම්භය සඳහා).
///
///
/// traits [`AsRef`] සහ [`AsMut`] ස්ථාවර ප්‍රමාණයේ අරා නොවිය හැකි වර්ග සඳහා සමාන ක්‍රම සපයන බව සලකන්න.
/// ක්‍රියාත්මක කරන්නන් ඒ වෙනුවට traits වලට වැඩි කැමැත්තක් දැක්විය යුතුය.
///
///
///
#[unstable(feature = "fixed_size_array", issue = "27778")]
pub unsafe trait FixedSizeArray<T> {
    /// අරාව වෙනස් කළ නොහැකි පෙත්තක් බවට පරිවර්තනය කරයි
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_slice(&self) -> &[T];
    /// අරාව විකෘති පෙත්තක් බවට පරිවර්තනය කරයි
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_mut_slice(&mut self) -> &mut [T];
}

#[unstable(feature = "fixed_size_array", issue = "27778")]
unsafe impl<T, A: Unsize<[T]>> FixedSizeArray<T> for A {
    #[inline]
    fn as_slice(&self) -> &[T] {
        self
    }
    #[inline]
    fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }
}

/// පෙත්තක සිට අරාවකට පරිවර්තනය කිරීම අසමත් වූ විට දෝෂ වර්ගය නැවත ලැබුණි.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone)]
pub struct TryFromSliceError(());

#[stable(feature = "core_array", since = "1.36.0")]
impl fmt::Display for TryFromSliceError {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self.__description(), f)
    }
}

impl TryFromSliceError {
    #[unstable(
        feature = "array_error_internals",
        reason = "available through Error trait and this method should not \
                     be exposed publicly",
        issue = "none"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "could not convert slice to array"
    }
}

#[stable(feature = "try_from_slice_error", since = "1.36.0")]
impl From<Infallible> for TryFromSliceError {
    fn from(x: Infallible) -> TryFromSliceError {
        match x {}
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsRef<[T]> for [T; N] {
    #[inline]
    fn as_ref(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsMut<[T]> for [T; N] {
    #[inline]
    fn as_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> Borrow<[T]> for [T; N] {
    fn borrow(&self) -> &[T] {
        self
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> BorrowMut<[T]> for [T; N] {
    fn borrow_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<T, const N: usize> TryFrom<&[T]> for [T; N]
where
    T: Copy,
{
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<[T; N], TryFromSliceError> {
        <&Self>::try_from(slice).map(|r| *r)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a [T]> for &'a [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<&[T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_ptr() as *const [T; N];
            // ආරක්ෂාව: හරි, අපි දිගට ගැළපෙන බව පරීක්ෂා කළ නිසා
            unsafe { Ok(&*ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a mut [T]> for &'a mut [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &mut [T]) -> Result<&mut [T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_mut_ptr() as *mut [T; N];
            // ආරක්ෂාව: හරි, අපි දිගට ගැළපෙන බව පරීක්ෂා කළ නිසා
            unsafe { Ok(&mut *ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, const N: usize> Hash for [T; N] {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        Hash::hash(&self[..], state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for [T; N] {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&&self[..], f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a [T; N] {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a mut [T; N] {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> Index<I> for [T; N]
where
    [T]: Index<I>,
{
    type Output = <[T] as Index<I>>::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(self as &[T], index)
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> IndexMut<I> for [T; N]
where
    [T]: IndexMut<I>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(self as &mut [T], index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B; N]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &[B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&mut [B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&mut [B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&mut [B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &mut [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

// NOTE: කේත ඉදිමීම අඩු කිරීම සඳහා අඩු වැදගත්කමක් ඇති සමහරක් ඉවත් කර ඇත
// __impl_slice_eq2!{ [A; $N], &'b [B; $N] } __impl_slice_eq2! { [A; $N], &'b mut [B; $N] }
//

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, const N: usize> Eq for [T; N] {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, const N: usize> PartialOrd for [T; N] {
    #[inline]
    fn partial_cmp(&self, other: &[T; N]) -> Option<Ordering> {
        PartialOrd::partial_cmp(&&self[..], &&other[..])
    }
    #[inline]
    fn lt(&self, other: &[T; N]) -> bool {
        PartialOrd::lt(&&self[..], &&other[..])
    }
    #[inline]
    fn le(&self, other: &[T; N]) -> bool {
        PartialOrd::le(&&self[..], &&other[..])
    }
    #[inline]
    fn ge(&self, other: &[T; N]) -> bool {
        PartialOrd::ge(&&self[..], &&other[..])
    }
    #[inline]
    fn gt(&self, other: &[T; N]) -> bool {
        PartialOrd::gt(&&self[..], &&other[..])
    }
}

/// [lexicographically](Ord#lexicographical-comparison) අරා සංසන්දනය ක්‍රියාත්මක කරයි.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, const N: usize> Ord for [T; N] {
    #[inline]
    fn cmp(&self, other: &[T; N]) -> Ordering {
        Ord::cmp(&&self[..], &&other[..])
    }
}

// `[T; 0]` ට පෙරනිමිය ක්‍රියාත්මක කිරීම අවශ්‍ය නොවන නිසාත්, විවිධ සංඛ්‍යා සඳහා විවිධ impl වාරණ තිබීම සඳහා තවමත් සහය නොදක්වන නිසාත්, පෙරනිමි impls const generics සමඟ කළ නොහැක.
//
//

macro_rules! array_impl_default {
    {$n:expr, $t:ident $($ts:ident)*} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] where T: Default {
            fn default() -> [T; $n] {
                [$t::default(), $($ts::default()),*]
            }
        }
        array_impl_default!{($n - 1), $($ts)*}
    };
    {$n:expr,} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] {
            fn default() -> [T; $n] { [] }
        }
    };
}

array_impl_default! {32, T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T}

#[lang = "array"]
impl<T, const N: usize> [T; N] {
    /// එක් එක් මූලද්‍රව්‍යයට අනුපිළිවෙලින් `f` ශ්‍රිතය යොදන `self` හා සමාන ප්‍රමාණයේ පෙළක් ලබා දෙයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_map)]
    /// let x = [1, 2, 3];
    /// let y = x.map(|v| v + 1);
    /// assert_eq!(y, [2, 3, 4]);
    ///
    /// let x = [1, 2, 3];
    /// let mut temp = 0;
    /// let y = x.map(|v| { temp += 1; v * temp });
    /// assert_eq!(y, [1, 4, 9]);
    ///
    /// let x = ["Ferris", "Bueller's", "Day", "Off"];
    /// let y = x.map(|v| v.len());
    /// assert_eq!(y, [6, 9, 3, 3]);
    /// ```
    #[unstable(feature = "array_map", issue = "75243")]
    pub fn map<F, U>(self, f: F) -> [U; N]
    where
        F: FnMut(T) -> U,
    {
        // ආරක්ෂාව: මෙම අනුකාරකය හරියටම `N` ලබා දෙන බව අපි දනිමු
        // items.
        unsafe { collect_into_array_unchecked(&mut IntoIter::new(self).map(f)) }
    }

    /// අරා දෙකක් යුගල යුගලයකට 'සිප්ස් අප්' කරන්න.
    ///
    /// `zip()` සෑම මූලද්‍රව්‍යයක්ම පළමු අරාව වෙතින් එන මූලද්‍රව්‍යයක් වන දෙවන අරාව නැවත ලබා දෙන අතර දෙවන මූලද්‍රව්‍යය දෙවන අරාවෙන් පැමිණේ.
    ///
    /// වෙනත් වචන වලින් කිවහොත්, එය අරා දෙකක් එකට, එකකට සිප් කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_zip)]
    /// let x = [1, 2, 3];
    /// let y = [4, 5, 6];
    /// let z = x.zip(y);
    /// assert_eq!(z, [(1, 4), (2, 5), (3, 6)]);
    /// ```
    ///
    #[unstable(feature = "array_zip", issue = "80094")]
    pub fn zip<U>(self, rhs: [U; N]) -> [(T, U); N] {
        let mut iter = IntoIter::new(self).zip(IntoIter::new(rhs));

        // ආරක්ෂාව: මෙම අනුකාරකය හරියටම `N` ලබා දෙන බව අපි දනිමු
        // items.
        unsafe { collect_into_array_unchecked(&mut iter) }
    }

    /// සම්පූර්ණ අරාව අඩංගු පෙත්තක් ලබා දෙයි.`&s[..]` ට සමාන වේ.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// සම්පූර්ණ අරාව අඩංගු විකෘති පෙත්තක් ලබා දෙයි.
    /// `&mut s[..]` ට සමාන වේ.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// එක් එක් මූලද්රව්යය ණයට ගෙන `self` ට සමාන ප්රමාණයක් සහිත යොමු මාලාවක් ලබා දෙයි.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&f64; 3] = floats.each_ref();
    /// assert_eq!(float_refs, [&3.1, &2.7, &-1.0]);
    /// ```
    ///
    /// [`map`](#method.map) වැනි වෙනත් ක්‍රම සමඟ සංයුක්ත වුවහොත් මෙම ක්‍රමය විශේෂයෙන් ප්‍රයෝජනවත් වේ.
    /// මේ ආකාරයෙන්, එහි මූලද්‍රව්‍ය `Copy` නොවේ නම් මුල් අරාව චලනය කිරීමෙන් වළක්වා ගත හැකිය.
    ///
    /// ```
    /// #![feature(array_methods, array_map)]
    ///
    /// let strings = ["Ferris".to_string(), "♥".to_string(), "Rust".to_string()];
    /// let is_ascii = strings.each_ref().map(|s| s.is_ascii());
    /// assert_eq!(is_ascii, [true, false, true]);
    ///
    /// // අපට තවමත් මුල් අරාව වෙත පිවිසිය හැකිය: එය ගෙන ගොස් නැත.
    /// assert_eq!(strings.len(), 3);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_ref(&self) -> [&T; N] {
        // ආරක්ෂාව: මෙම අනුකාරකය හරියටම `N` ලබා දෙන බව අපි දනිමු
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter()) }
    }

    /// එක් එක් මූලද්‍රව්‍යය විකෘති ලෙස ණයට ගන්නා අතර `self` හා සමාන ප්‍රමාණයේ විකෘති යොමු දැක්වීම් සමූහයක් ලබා දෙයි.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let mut floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&mut f64; 3] = floats.each_mut();
    /// *float_refs[0] = 0.0;
    /// assert_eq!(float_refs, [&mut 0.0, &mut 2.7, &mut -1.0]);
    /// assert_eq!(floats, [0.0, 2.7, -1.0]);
    /// ```
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_mut(&mut self) -> [&mut T; N] {
        // ආරක්ෂාව: මෙම අනුකාරකය හරියටම `N` ලබා දෙන බව අපි දනිමු
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter_mut()) }
    }
}

/// `iter` වෙතින් `N` අයිතම ඇදගෙන ඒවා අරාව ලෙස ලබා දෙයි.
/// අනුකාරකය `N` අයිතමවලට වඩා අඩුවෙන් ලබා දෙන්නේ නම්, මෙම ශ්‍රිතය මඟින් නිර්වචනය නොකළ හැසිරීම පෙන්නුම් කරයි.
///
///
/// වැඩි විස්තර සඳහා [`collect_into_array`] බලන්න.
///
/// # Safety
///
/// `iter` අවම වශයෙන් `N` අයිතම ලබා දෙන බවට සහතික වීම ඇමතුම්කරුගේ වගකීම වේ.
/// මෙම තත්වය උල්ලං ting නය කිරීම නිර්වචනය නොකළ හැසිරීමට හේතු වේ.
unsafe fn collect_into_array_unchecked<I, const N: usize>(iter: &mut I) -> [I::Item; N]
where
    // Note: මෙහි `TrustedLen` තරමක් අත්හදා බැලීමකි.මෙය හුදෙක් අ
    // අභ්‍යන්තර ක්‍රියාකාරිත්වය, එබැවින් මෙම බැඳීම නරක අදහසක් බවට පත්වුවහොත් ඉවත් කිරීමට නිදහස් වන්න.
    // එවැනි අවස්ථාවක, පහළින් බැඳී ඇති `debug_assert!` ද ඉවත් කිරීමට මතක තබා ගන්න!
    //
    I: Iterator + TrustedLen,
{
    debug_assert!(N <= iter.size_hint().1.unwrap_or(usize::MAX));
    debug_assert!(N <= iter.size_hint().0);

    match collect_into_array(iter) {
        Some(array) => array,
        // ආරක්ෂාව: ශ්‍රිත කොන්ත්‍රාත්තුවෙන් ආවරණය වේ.
        None => unsafe { crate::hint::unreachable_unchecked() },
    }
}

/// `iter` වෙතින් `N` අයිතම ඇදගෙන ඒවා අරාව ලෙස ලබා දෙයි.අනුකාරකය `N` අයිතමවලට වඩා අඩු අස්වැන්නක් ලබා දෙන්නේ නම්, `None` ආපසු ලබා දෙන අතර දැනටමත් ලබා දී ඇති සියලුම අයිතම අතහැර දමනු ලැබේ.
///
/// Iterator විකෘති යොමු කිරීමක් ලෙස සම්මත කර ඇති අතර මෙම ශ්‍රිතය `next` බොහෝ විට `N` වාර ගණනක් අමතයි, ඉතිරි අයිතම ලබා ගැනීමට iterator තවමත් භාවිතා කළ හැකිය.
///
///
/// `iter.next()` භීතියට පත් වුවහොත්, අනුකාරකය විසින් දැනටමත් ලබා දී ඇති සියලුම අයිතම අතහැර දමනු ලැබේ.
///
///
///
///
fn collect_into_array<I, const N: usize>(iter: &mut I) -> Option<[I::Item; N]>
where
    I: Iterator,
{
    if N == 0 {
        // ආරක්ෂාව: හිස් අරාවක් සැමවිටම වාසය කරන අතර වලංගු වෙනස්වීම් නොමැත.
        return unsafe { Some(mem::zeroed()) };
    }

    struct Guard<T, const N: usize> {
        ptr: *mut T,
        initialized: usize,
    }

    impl<T, const N: usize> Drop for Guard<T, N> {
        fn drop(&mut self) {
            debug_assert!(self.initialized <= N);

            let initialized_part = crate::ptr::slice_from_raw_parts_mut(self.ptr, self.initialized);

            // ආරක්ෂාව: මෙම අමු පෙත්තෙහි අඩංගු වන්නේ ආරම්භක වස්තු පමණි.
            unsafe {
                crate::ptr::drop_in_place(initialized_part);
            }
        }
    }

    let mut array = MaybeUninit::uninit_array::<N>();
    let mut guard: Guard<_, N> =
        Guard { ptr: MaybeUninit::slice_as_mut_ptr(&mut array), initialized: 0 };

    while let Some(item) = iter.next() {
        // ආරක්ෂාව: `guard.initialized` 0 සිට ආරම්භ වන අතර එය එකකින් වැඩි වේ
        // පුඩුවක් සහ ලූපය N වෙත ළඟා වූ වහාම එය ගබ්සා කරනු ලැබේ (එය `array.len()`) වේ.
        //
        unsafe {
            array.get_unchecked_mut(guard.initialized).write(item);
        }
        guard.initialized += 1;

        // සම්පූර්ණ අරාව ආරම්භ කර ඇත්දැයි පරීක්ෂා කරන්න.
        if guard.initialized == N {
            mem::forget(guard);

            // ආරක්ෂාව: ඉහත කොන්දේසිය මගින් සියලු මූලද්‍රව්‍යයන් බව තහවුරු කරයි
            // initialized.
            let out = unsafe { MaybeUninit::array_assume_init(array) };
            return Some(out);
        }
    }

    // මෙය ළඟා වන්නේ `guard.initialized` `N` වෙත ළඟා වීමට පෙර iterator අවසන් වී ඇත්නම් පමණි.
    //
    // `guard` මෙහි අතහැර දමා ඇති බවත්, දැනටමත් ආරම්භ කර ඇති සියලුම අංග අතහැර දමන්න.
    None
}