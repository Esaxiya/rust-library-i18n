//! අරා සඳහා `IntoIter` සතු iterator අර්ථ දක්වයි.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// අතුරු-අගය [array] iterator.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// මෙය අප නැවත නැවතත් කරන අරාවයි.
    ///
    /// `alive.start <= i < alive.end` දර්ශකය සහිත මූලද්‍රව්‍යයන් `alive.start <= i < alive.end` තවමත් ලබා දී නොමැති අතර වලංගු අරා ඇතුළත් කිරීම් වේ.
    /// `i < alive.start` හෝ `i >= alive.end` දර්ශක සහිත මූලද්‍රව්‍ය දැනටමත් ලබා දී ඇති අතර ඒවා තවදුරටත් ප්‍රවේශ නොවිය යුතුය!එම මළ මූලද්‍රව්‍යයන් මුළුමනින්ම ආරම්භ නොකළ තත්වයක තිබිය හැකිය!
    ///
    ///
    /// එබැවින් ආක්‍රමණ:
    /// - `data[alive]` ජීවමානයි (එනම් වලංගු අංග අඩංගු වේ)
    /// - `data[..alive.start]` සහ `data[alive.end..]` මිය ගොස් ඇත (එනම් මූලද්‍රව්‍ය දැනටමත් කියවා ඇති අතර ඒවා තවදුරටත් ස්පර්ශ නොකළ යුතුය!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// `data` හි මූලද්රව්ය තවමත් ලබා දී නොමැත.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// දී ඇති `array` ට වඩා නව අනුකාරකයක් සාදයි.
    ///
    /// *සටහන*: මෙම ක්‍රමය [`IntoIterator` is implemented for arrays][array-into-iter] ට පසුව future හි ඉවත් කළ හැකිය.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // X001 වෙනුවට `value` වර්ගය මෙහි `i32` වේ
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // සුරක්ෂිතභාවය: මෙහි සම්ප්‍රේෂණය සැබවින්ම ආරක්ෂිතයි.`MaybeUninit` හි ලියකියවිලි
        // promise:
        //
        // > `MaybeUninit<T>` එකම ප්‍රමාණය හා පෙළගැස්ම ඇති බවට සහතික වේ
        // > `T` ලෙස.
        //
        // ඩොක්ස් පවා `MaybeUninit<T>` අරා සිට `T` අරා දක්වා සම්ප්‍රේෂණය පෙන්වයි.
        //
        //
        // ඒ සමඟ, මෙම ආරම්භය ආක්‍රමණිකයින් තෘප්තිමත් කරයි.

        // FIXME(LukasKalbertodt): සැබවින්ම මෙහි `mem::transmute` භාවිතා කරන්න, එය const generics සමඟ වැඩ කළ පසු:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // එතෙක්, අපට වෙනත් වර්ගයක් ලෙස බිට්වේස් පිටපතක් සෑදීමට `mem::transmute_copy` භාවිතා කළ හැකිය, පසුව `array` අමතක කරන්න එවිට එය අතහරින්නේ නැත.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// තවමත් ලබා දී නොමැති සියලුම මූලද්‍රව්‍යවල වෙනස් කළ නොහැකි පෙත්තක් ලබා දෙයි.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // ආරක්ෂාව: `alive` තුළ ඇති සියලුම අංග නිසි ලෙස ආරම්භ කර ඇති බව අපි දනිමු.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// තවමත් ලබා දී නොමැති සියලුම මූලද්‍රව්‍යයන්ගේ විකෘති පෙත්තක් ලබා දෙයි.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // ආරක්ෂාව: `alive` තුළ ඇති සියලුම අංග නිසි ලෙස ආරම්භ කර ඇති බව අපි දනිමු.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // ඊළඟ දර්ශකය ඉදිරිපසින් ලබා ගන්න.
        //
        // `alive.start` 1 කින් වැඩි කිරීමෙන් `alive` සම්බන්ධව අක්‍රීයතාව පවත්වා ගනී.
        // කෙසේ වෙතත්, මෙම වෙනස හේතුවෙන්, කෙටි කාලයක් සඳහා, සජීවී කලාපය තවදුරටත් `data[alive]` නොව `data[idx..alive.end]` වේ.
        //
        self.alive.next().map(|idx| {
            // අරාවෙන් මූලද්‍රව්‍යය කියවන්න.
            // ආරක්ෂාව: `idx` යනු කලින් පැවති "alive" කලාපයට දර්ශකයකි
            // අරාව.මෙම මූලද්‍රව්‍යය කියවීමෙන් අදහස් වන්නේ `data[idx]` දැන් මිය ගොස් ඇති බවයි (එනම් ස්පර්ශ නොකරන්න).
            // `idx` සජීවී කලාපයේ ආරම්භය වූ බැවින්, සජීවී කලාපය දැන් නැවතත් `data[alive]` බවට පත්වී ඇති අතර, සියලු වෙනස්වීම් ප්‍රතිෂ් oring ාපනය කරයි.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // ඊළඟ දර්ශකය පිටුපසින් ලබා ගන්න.
        //
        // `alive.end` 1 කින් අඩු කිරීමෙන් `alive` සම්බන්ධව අක්‍රීයතාව පවත්වා ගනී.
        // කෙසේ වෙතත්, මෙම වෙනස හේතුවෙන්, කෙටි කාලයක් සඳහා, සජීවී කලාපය තවදුරටත් `data[alive]` නොව `data[alive.start..=idx]` වේ.
        //
        self.alive.next_back().map(|idx| {
            // අරාවෙන් මූලද්‍රව්‍යය කියවන්න.
            // ආරක්ෂාව: `idx` යනු කලින් පැවති "alive" කලාපයට දර්ශකයකි
            // අරාව.මෙම මූලද්‍රව්‍යය කියවීමෙන් අදහස් වන්නේ `data[idx]` දැන් මිය ගොස් ඇති බවයි (එනම් ස්පර්ශ නොකරන්න).
            // `idx` සජීවී කලාපයේ අවසානය වූ බැවින්, සජීවී කලාපය දැන් නැවතත් `data[alive]` බවට පත්වී, සියලු ආක්‍රමණ ප්‍රතිෂ් oring ාපනය කරයි.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // ආරක්ෂාව: මෙය ආරක්ෂිතයි: `as_mut_slice` හරියටම උප පෙත්ත නැවත ලබා දෙයි
        // තවම පිටතට ගෙන ගොස් නැති සහ අතහැර දැමිය යුතු මූලද්‍රව්‍ය.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // වෙනස් නොවන `සජීවී. ස්ටාර්ට් <=නිසා කිසි විටෙකත් ගලා නොයනු ඇත
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// අනුකාරකය ඇත්ත වශයෙන්ම නිවැරදි දිග වාර්තා කරයි.
// "alive" මූලද්‍රව්‍ය ගණන (එය තවමත් ලබා දෙනු ඇත) `alive` පරාසයේ දිග වේ.
// මෙම පරාසය `next` හෝ `next_back` වලින් දිගින් අඩු වේ.
// එය සෑම විටම එම ක්‍රම වලින් 1 කින් අඩු වේ, නමුත් `Some(_)` ආපසු ලබා දෙන්නේ නම් පමණි.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // සටහන, අපට හරියටම එකම සජීවී පරාසයට ගැලපීමට අවශ්‍ය නැත, එබැවින් අපට `self` කොතැනක සිටියත් ඕෆ්සෙට් 0 වෙත ක්ලෝන කළ හැකිය.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // සියලුම ජීවමාන මූලද්‍රව්‍ය ක්ලෝන කරන්න.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // නව අරාවකට ක්ලෝනයක් ලියන්න, ඉන්පසු එහි සජීවී පරාසය යාවත්කාලීන කරන්න.
            // panics ක්ලෝන කරන්නේ නම්, අපි පෙර අයිතම නිවැරදිව අතහරිමු.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // තවමත් ලබා නොදුන් මූලද්‍රව්‍ය පමණක් මුද්‍රණය කරන්න: අපට තවදුරටත් yield ලදූ මූලද්‍රව්‍යයන්ට ප්‍රවේශ විය නොහැක.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}