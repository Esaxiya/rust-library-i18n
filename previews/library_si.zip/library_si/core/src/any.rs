//! මෙම මොඩියුලය `Any` trait ක්‍රියාත්මක කරන අතර එමඟින් ඕනෑම `'static` වර්ගයක ගතික ටයිප් කිරීම ධාවන කාල පරාවර්තනය හරහා සිදු කරයි.
//!
//! `Any` `TypeId` ලබා ගැනීම සඳහාම භාවිතා කළ හැකි අතර, trait වස්තුවක් ලෙස භාවිතා කරන විට තවත් විශේෂාංග ඇත.
//! `&dyn Any` (ණයට ගත් trait වස්තුවක්) ලෙස, එහි `is` සහ `downcast_ref` ක්‍රම ඇත, එහි අඩංගු අගය ලබා දී ඇති වර්ගයක් දැයි පරීක්ෂා කිරීමට සහ වර්ගයක් ලෙස අභ්‍යන්තර අගය පිළිබඳ සඳහනක් ලබා ගැනීමට.
//! `&mut dyn Any` ලෙස, අභ්‍යන්තර අගයට විකෘති යොමු කිරීමක් ලබා ගැනීම සඳහා `downcast_mut` ක්‍රමය ද ඇත.
//! `Box<dyn Any>` `downcast` ක්‍රමය එක් කරයි, එය `Box<T>` බවට පරිවර්තනය කිරීමට උත්සාහ කරයි.
//! සම්පූර්ණ විස්තර සඳහා [`Box`] ප්‍රලේඛනය බලන්න.
//!
//! `&dyn Any` අගය නිශ්චිත කොන්ක්‍රීට් වර්ගයක දැයි පරීක්ෂා කිරීමට පමණක් සීමා වී ඇති අතර, වර්ගයක් trait ක්‍රියාත්මක කරන්නේ දැයි පරීක්ෂා කිරීමට භාවිතා කළ නොහැකි බව සලකන්න.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # ස්මාර්ට් පොයින්ටර් සහ `dyn Any`
//!
//! `Any` trait වස්තුවක් ලෙස භාවිතා කරන විට මතක තබා ගත යුතු එක් හැසිරීමක් නම්, විශේෂයෙන් `Box<dyn Any>` හෝ `Arc<dyn Any>` වැනි වර්ග සමඟ, හුදෙක් අගය මත `.type_id()` ඇමතීමෙන් * කන්ටේනරයේ `TypeId` නිපදවනු ඇත, නමුත් යටින් පවතින trait වස්තුව නොවේ.
//!
//! ස්මාර්ට් පොයින්ටරය ඒ වෙනුවට `&dyn Any` බවට පරිවර්තනය කිරීමෙන් මෙය වළක්වා ගත හැකි අතර එමඟින් වස්තුවේ `TypeId` නැවත ලැබෙනු ඇත.
//! උදාහරණ වශයෙන්:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // ඔබට මෙය අවශ්‍ය වීමට වැඩි ඉඩක් ඇත:
//! let actual_id = (&*boxed).type_id();
//! // ... මෙයට වඩා:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! ශ්‍රිතයකට ලබා දුන් අගයක් ඉවත් කිරීමට අපට අවශ්‍ය තත්වයක් සලකා බලන්න.
//! නිදොස් කිරීම ක්‍රියාත්මක කිරීමේදී අප වැඩ කරන වටිනාකම අපි දනිමු, නමුත් එහි කොන්ක්‍රීට් වර්ගය අපි නොදනිමු.සමහර වර්ග සඳහා විශේෂ ප්‍රතිකාර ලබා දීමට අපට අවශ්‍යය: මේ අවස්ථාවේ දී ඒවායේ අගයට පෙර නූල් අගයන්හි දිග මුද්‍රණය කිරීම.
//! සම්පාදනය කරන වේලාවේදී අපගේ වටිනාකමේ කොන්ක්‍රීට් වර්ගය අපි නොදනිමු, එබැවින් අපි ඒ වෙනුවට ධාවන කාල පරාවර්තනය භාවිතා කළ යුතුය.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // නිදොස්කරණය ක්‍රියාත්මක කරන ඕනෑම වර්ගයක ලොගර් ක්‍රියාකාරිත්වය.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // අපගේ අගය `String` බවට පරිවර්තනය කිරීමට උත්සාහ කරන්න.
//!     // එය සාර්ථක නම්, අපට අවශ්‍ය වන්නේ නූල් වල දිග මෙන්ම එහි වටිනාකමයි.
//!     // එසේ නොවේ නම්, එය වෙනස් වර්ගයකි: එය අලංකාර ලෙස මුද්‍රණය කරන්න.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // මෙම ශ්‍රිතයට අවශ්‍ය වන්නේ එහි පරාමිතිය සමඟ වැඩ කිරීමට පෙර එය ඉවත් කිරීමට ය.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... වෙනත් වැඩක් කරන්න
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// ඕනෑම trait
///////////////////////////////////////////////////////////////////////////////

/// ගතික ටයිප් කිරීම අනුකරණය කිරීමට trait.
///
/// බොහෝ වර්ගයන් `Any` ක්‍රියාත්මක කරයි.කෙසේ වෙතත්, ස්ථිතික නොවන යොමු කිරීමක් අඩංගු ඕනෑම වර්ගයක නැත.
/// වැඩි විස්තර සඳහා [module-level documentation][mod] බලන්න.
///
/// [mod]: crate::any
// මෙම trait අනාරක්ෂිත නොවේ, නමුත් අපි එහි එකම impl හි `type_id` ක්‍රියාකාරීත්වයේ අනාරක්ෂිත කේතයේ (උදා: `downcast`) විශේෂතා මත රඳා සිටිමු.සාමාන්‍යයෙන් එය ගැටළුවක් වනු ඇත, නමුත් `Any` හි එකම ආවේගය බ්ලැන්කට් ක්‍රියාත්මක කිරීමක් බැවින් වෙනත් කිසිදු කේතයකට `Any` ක්‍රියාත්මක කළ නොහැක.
//
// අපට මෙම trait අනාරක්ෂිත බවට පත් කළ හැකිය-එය සියලු ක්‍රියාත්මක කිරීම් පාලනය කරන බැවින් එය බිඳවැටීමක් ඇති නොකරනු ඇත-නමුත් අපි ඒ දෙකම සැබවින්ම අවශ්‍ය නොවන බැවින් තෝරා නොගන්නා අතර අනාරක්ෂිත traits සහ අනාරක්ෂිත ක්‍රම (එනම්, `type_id` ඇමතීමට තවමත් ආරක්ෂිත වනු ඇත, නමුත් අපට ලේඛනවල සඳහන් කිරීමට අවශ්‍ය වනු ඇත).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// `self` හි `TypeId` ලබා ගනී.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// ඕනෑම trait වස්තු සඳහා දිගු කිරීමේ ක්‍රම.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// උදා: නූල් එකකට සම්බන්ධ වීමේ ප්‍රති result ලය මුද්‍රණය කළ හැකි බවට සහතික වන්න. එබැවින් `unwrap` සමඟ භාවිතා කරන්න.
// පිටත් කර යැවීම උඩු යටිකුරු කිරීම සමඟ ක්‍රියා කරන්නේ නම් අවසානයේදී තවදුරටත් අවශ්‍ය නොවනු ඇත.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// කොටු කළ වර්ගය `T` ට සමාන නම් `true` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // මෙම ශ්‍රිතය ක්ෂණිකව ක්‍රියාත්මක වන ආකාරයේ `TypeId` ලබා ගන්න.
        let t = TypeId::of::<T>();

        // trait වස්තුව (`self`) හි වර්ගයේ `TypeId` ලබා ගන්න.
        let concrete = self.type_id();

        // සමානාත්මතාවය මත ටයිප් අයිඩ් දෙකම සංසන්දනය කරන්න.
        t == concrete
    }

    /// කොටු කළ අගය `T` වර්ගයේ නම් හෝ `None` නොමැති නම් එය වෙත යම් සඳහනක් ලබා දෙයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // ආරක්ෂාව: අප නිවැරදි වර්ගයට යොමු වන්නේ දැයි පරීක්ෂා කර බැලූ විට අපට විශ්වාසය තැබිය හැකිය
            // මතක ආරක්ෂාව සඳහා වන පරීක්ෂාව අප සියලු වර්ග සඳහා ඕනෑම දෙයක් ක්‍රියාත්මක කර ඇති නිසා;අපගේ ආවේගයට පටහැනි වන පරිදි වෙනත් කිසිදු ආවේගයක් පැවතිය නොහැක.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// කොටු කළ අගය `T` වර්ගයේ නම් හෝ `None` නොමැති නම් එය වෙනස් කළ හැකි යොමු කිරීමක් ලබා දෙයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // ආරක්ෂාව: අප නිවැරදි වර්ගයට යොමු වන්නේ දැයි පරීක්ෂා කර බැලූ විට අපට විශ්වාසය තැබිය හැකිය
            // මතක ආරක්ෂාව සඳහා වන පරීක්ෂාව අප සියලු වර්ග සඳහා ඕනෑම දෙයක් ක්‍රියාත්මක කර ඇති නිසා;අපගේ ආවේගයට පටහැනි වන පරිදි වෙනත් කිසිදු ආවේගයක් පැවතිය නොහැක.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// `Any` වර්ගයේ අර්ථ දක්වා ඇති ක්‍රමයට ඉදිරියට.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` වර්ගයේ අර්ථ දක්වා ඇති ක්‍රමයට ඉදිරියට.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` වර්ගයේ අර්ථ දක්වා ඇති ක්‍රමයට ඉදිරියට.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// `Any` වර්ගයේ අර්ථ දක්වා ඇති ක්‍රමයට ඉදිරියට.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` වර්ගයේ අර්ථ දක්වා ඇති ක්‍රමයට ඉදිරියට.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` වර්ගයේ අර්ථ දක්වා ඇති ක්‍රමයට ඉදිරියට.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID සහ එහි ක්‍රම
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` වර්ගයක් සඳහා ගෝලීය වශයෙන් අද්විතීය හඳුනාගැනීමක් නියෝජනය කරයි.
///
/// සෑම `TypeId` පාරාන්ධ වස්තුවක් වන අතර එය ඇතුළත ඇති දේ පරීක්ෂා කිරීමට ඉඩ නොදෙන නමුත් ක්ලෝනකරණය, සංසන්දනය, මුද්‍රණය සහ පෙන්වීම වැනි මූලික මෙහෙයුම් සඳහා ඉඩ ලබා දේ.
///
///
/// `TypeId` දැනට ලබා ගත හැක්කේ `'static` ට අනුරූප වන වර්ග සඳහා පමණි, නමුත් මෙම සීමාව future තුළ ඉවත් කළ හැකිය.
///
/// `TypeId` විසින් `Hash`, `PartialOrd` සහ `Ord` ක්‍රියාත්මක කරන අතර, Rust නිකුතු අතර හැෂ් සහ ඇණවුම් වෙනස් වන බව සඳහන් කිරීම වටී.
/// ඔබේ කේතය තුළ ඒවා මත විශ්වාසය තැබීමෙන් පරිස්සම් වන්න!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// මෙම සාමාන්‍ය ශ්‍රිතය ක්ෂණිකව සකසා ඇති වර්ගයේ `TypeId` ලබා දෙයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// වර්ගයක නම නූල් පෙත්තක් ලෙස ලබා දෙයි.
///
/// # Note
///
/// මෙය රෝග විනිශ්චය සඳහා අදහස් කෙරේ.
/// වර්ගය පිළිබඳ හොඳම උත්සාහය විස්තරයක් හැරුණු විට ආපසු ලබා දුන් නූල් වල නිශ්චිත අන්තර්ගතයන් සහ ආකෘතිය නිශ්චිතව දක්වා නැත.
/// උදාහරණයක් ලෙස, `type_name::<Option<String>>()` නැවත පැමිණිය හැකි නූල් අතර `"Option<String>"` සහ `"std::option::Option<std::string::String>"` වේ.
///
///
/// බහුවිධ වර්ග එකම වර්ගයේ නමට සිතියම් ගත කළ හැකි බැවින් ආපසු ලබා දුන් නූල වර්ගයක අද්විතීය හඳුනාගැනීමක් ලෙස නොසැලකිය යුතුය.
/// ඒ හා සමානව, ආපසු ලබා දුන් නූලෙහි යම් වර්ගයක සියලුම කොටස් දිස්වනු ඇති බවට කිසිදු සහතිකයක් නොමැත: නිදසුනක් ලෙස, ජීවිත කාල නියමයන් දැනට ඇතුළත් කර නොමැත.
/// ඊට අමතරව, සම්පාදකයාගේ අනුවාද අතර ප්‍රතිදානය වෙනස් විය හැකිය.
///
/// වර්තමාන ක්‍රියාත්මක කිරීම සම්පාදක රෝග නිර්ණය සහ නිදොස්කරණය වැනි යටිතල පහසුකම් භාවිතා කරයි, නමුත් මෙය සහතික නොවේ.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// පෙන්වා ඇති අගයේ වර්ගය නූල පෙත්තක් ලෙස ලබා දෙයි.
/// මෙය `type_name::<T>()` හා සමාන වේ, නමුත් විචල්‍යයක වර්ගය පහසුවෙන් ලබාගත නොහැකි තැන භාවිතා කළ හැකිය.
///
/// # Note
///
/// මෙය රෝග විනිශ්චය සඳහා අදහස් කෙරේ.වර්ගය පිළිබඳ හොඳම උත්සාහය විස්තර කිරීම හැර, නූල් වල නිශ්චිත අන්තර්ගතයන් සහ ආකෘතිය නිශ්චිතව දක්වා නැත.
/// උදාහරණයක් ලෙස, `type_name_of_val::<Option<String>>(None)` හට `"Option<String>"` හෝ `"std::option::Option<std::string::String>"` ආපසු ලබා දිය හැකි නමුත් `"foobar"` නොවේ.
///
/// ඊට අමතරව, සම්පාදකයාගේ අනුවාද අතර ප්‍රතිදානය වෙනස් විය හැකිය.
///
/// මෙම ශ්‍රිතය trait වස්තු නිරාකරණය නොකරයි, එයින් අදහස් වන්නේ `type_name_of_val(&7u32 as &dyn Debug)` මඟින් `"dyn Debug"` ආපසු ලබා දිය හැකි නමුත් `"u32"` නොවේ.
///
/// වර්ගයේ නම වර්ගයක අද්විතීය හඳුනාගැනීමක් ලෙස නොසැලකිය යුතුය;
/// බහුවිධ වර්ග එකම වර්ගයේ නම බෙදා ගත හැකිය.
///
/// වර්තමාන ක්‍රියාත්මක කිරීම සම්පාදක රෝග නිර්ණය සහ නිදොස්කරණය වැනි යටිතල පහසුකම් භාවිතා කරයි, නමුත් මෙය සහතික නොවේ.
///
/// # Examples
///
/// පෙරනිමි නිඛිල සහ පාවෙන වර්ග මුද්‍රණය කරයි.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}