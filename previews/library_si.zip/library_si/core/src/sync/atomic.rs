//! පරමාණුක වර්ග
//!
//! පරමාණුක වර්ග නූල් අතර ප්‍රාථමික හවුල්-මතක සන්නිවේදනයක් සපයන අතර අනෙකුත් සමගාමී වර්ගවල ගොඩනැඟිලි කොටස් වේ.
//!
//! මෙම මොඩියුලය [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], ඇතුළු තෝරාගත් ප්‍රාථමික වර්ග ගණනාවක පරමාණුක අනුවාදයන් අර්ථ දක්වයි.
//! පරමාණුක වර්ග නිවැරදිව භාවිතා කරන විට, නූල් අතර යාවත්කාලීනයන් සමමුහුර්ත කරන මෙහෙයුම් ඉදිරිපත් කරයි.
//!
//! සෑම ක්‍රමයක්ම [`Ordering`] එකක් ගන්නා අතර එම ක්‍රියාව සඳහා මතක බාධකයේ ශක්තිය නිරූපණය කරයි.මෙම ඇණවුම් [C++20 atomic orderings][1] ට සමාන වේ.වැඩි විස්තර සඳහා [nomicon][2] බලන්න.
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! පරමාණුක විචල්‍යයන් නූල් අතර බෙදා ගැනීමට ආරක්ෂිත වේ (ඒවා [`Sync`] ක්‍රියාත්මක කරයි) නමුත් ඒවා බෙදාහදා ගැනීමේ යාන්ත්‍රණය සපයන්නේ නැති අතර Rust හි [threading model](../../../std/thread/index.html#the-threading-model) අනුගමනය කරයි.
//!
//! පරමාණුක විචල්‍යයක් බෙදාහදා ගැනීම සඳහා වඩාත් පොදු ක්‍රමය වන්නේ එය [`Arc`][arc] (පරමාණුක-යොමු-ගණනය කළ හවුල් දර්ශකයක්) තුළට දැමීමයි.
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! පරමාණුක වර්ග ස්ථිතික විචල්‍යයන්හි ගබඩා කළ හැකි අතර [`AtomicBool::new`] වැනි නියත ආරම්භක භාවිතා කරමින් ආරම්භ කරනු ලැබේ.කම්මැලි ගෝලීය ආරම්භය සඳහා පරමාණුක සංඛ්‍යාන බොහෝ විට භාවිතා වේ.
//!
//! # Portability
//!
//! මෙම මොඩියුලයේ ඇති සියලුම පරමාණුක වර්ග තිබේ නම් ඒවා [lock-free] බවට සහතික වේ.මෙයින් අදහස් කරන්නේ ඔවුන් අභ්‍යන්තරව ගෝලීය මූටෙක්ස් ලබා නොගන්නා බවයි.පරමාණුක වර්ග සහ මෙහෙයුම් පොරොත්තු රහිත බවට සහතික නොවේ.
//! මෙයින් අදහස් කරන්නේ `fetch_or` වැනි මෙහෙයුම් සංසන්දනාත්මක හා හුවමාරු ලූපයක් සමඟ ක්‍රියාත්මක කළ හැකි බවයි.
//!
//! පරමාණුක මෙහෙයුම් විශාල ප්‍රමාණයේ පරමාණු සමඟ උපදෙස් ස්ථරයේ ක්‍රියාත්මක කළ හැකිය.උදාහරණයක් ලෙස සමහර වේදිකා `AtomicI8` ක්‍රියාත්මක කිරීම සඳහා 4-බයිට් පරමාණුක උපදෙස් භාවිතා කරයි.
//! මෙම අනුකරණය කේතයේ නිරවද්‍යතාවයට බලපෑමක් ඇති නොකළ යුතු බව සලකන්න, එය දැනුවත් විය යුතු දෙයක් පමණි.
//!
//! මෙම මොඩියුලයේ පරමාණුක වර්ග සියලු වේදිකාවල නොතිබිය හැකිය.කෙසේ වෙතත් මෙහි පරමාණුක වර්ග සියල්ලම පුළුල් ලෙස ලබා ගත හැකි අතර සාමාන්‍යයෙන් පවතින දේ මත විශ්වාසය තැබිය හැකිය.සැලකිය යුතු ව්‍යතිරේකයන් නම්:
//!
//! * PowerPC සහ බිට් 32 දර්ශක සහිත MIPS වේදිකාවලට `AtomicU64` හෝ `AtomicI64` වර්ග නොමැත.
//! * ARM Linux සඳහා නොවන `armv5te` වැනි වේදිකා `load` සහ `store` මෙහෙයුම් පමණක් සපයන අතර `swap`, `fetch_add` වැනි සංසන්දනාත්මක හා හුවමාරු (CAS) මෙහෙයුම් සඳහා සහය නොදක්වයි.
//! Linux ට අමතරව, මෙම CAS මෙහෙයුම් ක්‍රියාත්මක වන්නේ [operating system support] හරහා වන අතර එය කාර්ය සාධන ද .ුවමක් සමඟ පැමිණිය හැකිය.
//! * ARM `thumbv6m` සමඟ ඉලක්ක `load` සහ `store` මෙහෙයුම් පමණක් සපයන අතර `swap`, `fetch_add`, වැනි (CAS) මෙහෙයුම් සංසන්දනය හා හුවමාරු කිරීමට සහාය නොදක්වයි.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! සමහර පරමාණුක මෙහෙයුම් සඳහා සහය නොදක්වන future වේදිකා එකතු කළ හැකි බව සලකන්න.උපරිම අතේ ගෙන යා හැකි කේතයට කුමන පරමාණුක වර්ග භාවිතා කරන්නේද යන්න ගැන සැලකිලිමත් වීමට අවශ්‍ය වනු ඇත.
//! `AtomicUsize` සහ `AtomicIsize` සාමාන්‍යයෙන් වඩාත්ම අතේ ගෙන යා හැකි ඒවා වන නමුත් ඒවා සෑම තැනකම ලබාගත නොහැක.
//! යොමු කිරීම සඳහා, `std` පුස්තකාලයට දර්ශක ප්‍රමාණයේ පරමාණු අවශ්‍ය වේ, නමුත් `core` අවශ්‍ය නොවේ.
//!
//! දැනට ඔබට පරමාණුක සමඟ කේත සම්පාදනය කිරීම සඳහා මූලික වශයෙන් `#[cfg(target_arch)]` භාවිතා කිරීමට අවශ්‍ය වේ.අස්ථායී `#[cfg(target_has_atomic)]` මෙන්ම future හි ස්ථාවර විය හැක.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! සරල භ්‍රමණය:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // අනෙක් නූල් අගුල මුදා හරින තෙක් රැඳී සිටින්න
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! ගෝලීය සජීවී නූල් ගණනක් තබා ගන්න:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// නූල් අතර ආරක්ෂිතව බෙදා ගත හැකි බූලියන් වර්ගයකි.
///
/// මෙම වර්ගයට [`bool`] හා සමාන මතක නිරූපණයක් ඇත.
///
/// **සටහන**: මෙම වර්ගය ලබා ගත හැක්කේ `u8` හි පරමාණුක පැටවීම් සහ ගබඩා සඳහා සහාය වන වේදිකා වල පමණි.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// `false` වෙත ආරම්භ කරන ලද `AtomicBool` නිර්මාණය කරයි.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// යැවීම පරමාණුක බූල් සඳහා ව්‍යංගයෙන් ක්‍රියාත්මක වේ.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// නූල් අතර ආරක්ෂිතව බෙදා ගත හැකි අමු දර්ශක වර්ගයකි.
///
/// මෙම වර්ගයට `*mut T` හා සමාන මතක නිරූපණයක් ඇත.
///
/// **සටහන**: මෙම වර්ගය ලබා ගත හැක්කේ පරමාණුක පැටවීම් සහ දර්ශක ගබඩාවලට සහාය වන වේදිකාවල පමණි.
/// එහි ප්‍රමාණය ඉලක්කගත දර්ශකයේ ප්‍රමාණය මත රඳා පවතී.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// ශුන්‍ය `AtomicPtr<T>` නිර්මාණය කරයි.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// පරමාණුක මතක අනුපිළිවෙල
///
/// මතක අනුපිළිවෙලින් පරමාණුක මෙහෙයුම් මගින් මතකය සමමුහුර්ත කරන ආකාරය නියම කරයි.
/// එහි දුර්වලම [`Ordering::Relaxed`] හි, මෙහෙයුම මගින් කෙලින්ම ස්පර්ශ කළ මතකය පමණක් සමමුහුර්ත වේ.
/// අනෙක් අතට, [`Ordering::SeqCst`] මෙහෙයුම් යුගලයක් වෙනත් මතකය සමමුහුර්ත කරන අතරම ඊට අමතරව සියලු නූල් හරහා එවැනි මෙහෙයුම් වල සම්පූර්ණ අනුපිළිවෙල ආරක්ෂා කරයි.
///
///
/// Rust හි මතක ඇණවුම් [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order) වේ.
///
/// වැඩි විස්තර සඳහා [nomicon] බලන්න.
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// ඇණවුම් කිරීමේ සීමාවන් නොමැත, පරමාණුක මෙහෙයුම් පමණි.
    ///
    /// C ++ 20 හි [`memory_order_relaxed`] ට අනුරූප වේ.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// වෙළඳසැලක් සමඟ සම්බන්ධ වූ විට, [`Acquire`] (හෝ වඩා ශක්තිමත්) ඇණවුමක් සමඟ මෙම අගය පැටවීමට පෙර පෙර පැවති සියලුම මෙහෙයුම් ඇණවුම් කරනු ලැබේ.
    ///
    /// විශේෂයෙන්, මෙම අගයෙහි [`Acquire`] (හෝ වඩා ශක්තිමත්) බරක් සිදු කරන සියලුම නූල් වලට පෙර ලියවිලි සියල්ලම දෘශ්‍යමාන වේ.
    ///
    /// පැටවුම් සහ ගබඩා ඒකාබද්ධ කරන මෙහෙයුමක් සඳහා මෙම ඇණවුම භාවිතා කිරීම [`Relaxed`] පැටවීමේ මෙහෙයුමකට තුඩු දෙන බව සලකන්න!
    ///
    /// මෙම ඇණවුම අදාළ වන්නේ වෙළඳසැලක් කළ හැකි මෙහෙයුම් සඳහා පමණි.
    ///
    /// C ++ 20 හි [`memory_order_release`] ට අනුරූප වේ.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// බරක් සමඟ සම්බන්ධ වූ විට, පැටවූ අගය [`Release`] (හෝ වඩා ශක්තිමත්) ඇණවුමක් සහිත ගබඩා මෙහෙයුමක් මගින් ලියා තිබේ නම්, පසුව සිදුකරන සියලුම මෙහෙයුම් එම ගබඩාවෙන් පසුව ඇණවුම් කරනු ලැබේ.
    /// විශේෂයෙන්, සියලු පසු පැටවීම් ගබඩාවට පෙර ලියා ඇති දත්ත දකිනු ඇත.
    ///
    /// බර හා වෙළඳසැල් ඒකාබද්ධ කරන මෙහෙයුමක් සඳහා මෙම ඇණවුම භාවිතා කිරීම [`Relaxed`] ගබඩා මෙහෙයුමකට මඟ පෙන්වන බව සලකන්න!
    ///
    /// මෙම ඇණවුම අදාළ වන්නේ බරක් කළ හැකි මෙහෙයුම් සඳහා පමණි.
    ///
    /// C ++ 20 හි [`memory_order_acquire`] ට අනුරූප වේ.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// [`Acquire`] සහ [`Release`] යන දෙකෙහිම බලපෑම් එකට ඇත:
    /// පැටවීම සඳහා එය [`Acquire`] ඇණවුම භාවිතා කරයි.වෙළඳසැල් සඳහා එය [`Release`] ඇණවුම භාවිතා කරයි.
    ///
    /// `compare_and_swap` සම්බන්ධයෙන් ගත් කල, මෙහෙයුම කිසිදු ගබඩාවක් සිදු නොකිරීමට ඉඩ ඇති බවත්, එබැවින් එය ඇත්තේ [`Acquire`] ඇණවුමක් පමණක් බවත් සැලකිල්ලට ගන්න.
    ///
    /// කෙසේ වෙතත්, `AcqRel` කිසි විටෙකත් [`Relaxed`] ප්‍රවේශයන් සිදු නොකරනු ඇත.
    ///
    /// මෙම ඇණවුම අදාළ වන්නේ බර සහ ගබඩා දෙකම ඒකාබද්ධ කරන මෙහෙයුම් සඳහා පමණි.
    ///
    /// C ++ 20 හි [`memory_order_acq_rel`] ට අනුරූප වේ.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// [`අත්පත් කර ගන්න]]/[` මුදා හැරීම`]/[`ඇක්ක්‍රෙල්`](පිළිවෙලින් පැටවීම, ගබඩා කිරීම සහ ගබඩාව සමඟ පැටවීම සඳහා), සියලු නූල් සියල්ලම අනුපිළිවෙලින් ස්ථාවර මෙහෙයුම් එකම අනුපිළිවෙලින් දකින බවට අමතර සහතිකයක් ඇත. .
    ///
    ///
    /// C ++ 20 හි [`memory_order_seq_cst`] ට අනුරූප වේ.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// [`AtomicBool`] `false` වෙත ආරම්භ කරන ලදි.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// නව `AtomicBool` නිර්මාණය කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// යටින් පවතින [`bool`] වෙත විකෘති යොමු කිරීමක් ලබා දෙයි.
    ///
    /// මෙය ආරක්ෂිත වන්නේ විකෘති යොමුව වෙනත් නූල් සමගාමීව පරමාණුක දත්ත වලට ප්‍රවේශ නොවන බවට සහතික වන බැවිනි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // ආරක්ෂාව: විකෘති යොමුව අද්විතීය හිමිකම සහතික කරයි.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// `&mut bool` වෙත පරමාණුක ප්‍රවේශය ලබා ගන්න.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // ආරක්ෂාව: විකෘති යොමුව අද්විතීය හිමිකම සහතික කරයි, සහ
        // `bool` සහ `Self` යන දෙකෙහිම පෙළගැස්ම 1 වේ.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// පරමාණුක පරිභෝජනය කර අඩංගු අගය ලබා දෙයි.
    ///
    /// `self` අගය අනුව ගමන් කිරීම වෙනත් නූල් සමගාමීව පරමාණුක දත්ත වලට ප්‍රවේශ නොවන බවට සහතික වන බැවින් මෙය ආරක්ෂිත වේ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// bool වෙතින් අගයක් පූරණය වේ.
    ///
    /// `load` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කරන [`Ordering`] තර්කයක් ගනී.
    /// විය හැකි අගයන් වන්නේ [`SeqCst`], [`Acquire`] සහ [`Relaxed`] ය.
    ///
    /// # Panics
    ///
    /// `order` [`Release`] හෝ [`AcqRel`] නම් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // සුරක්ෂිතතාව: ඕනෑම දත්ත තරඟයක් පරමාණුක අභ්‍යන්තර සහ අමු මගින් වළක්වනු ලැබේ
        // අප යොමු කිරීමකින් එය ලබාගත් නිසා දර්ශකය සම්මත වේ.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// bool වෙත අගයක් ගබඩා කරයි.
    ///
    /// `store` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කරන [`Ordering`] තර්කයක් ගනී.
    /// විය හැකි අගයන් වන්නේ [`SeqCst`], [`Release`] සහ [`Relaxed`] ය.
    ///
    /// # Panics
    ///
    /// `order` [`Acquire`] හෝ [`AcqRel`] නම් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // සුරක්ෂිතතාව: ඕනෑම දත්ත තරඟයක් පරමාණුක අභ්‍යන්තර සහ අමු මගින් වළක්වනු ලැබේ
        // අප යොමු කිරීමකින් එය ලබාගත් නිසා දර්ශකය සම්මත වේ.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// bool වෙත අගයක් ගබඩා කරයි, පෙර අගය ලබා දෙයි.
    ///
    /// `swap` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කරන [`Ordering`] තර්කයක් ගනී.සියලුම ඇණවුම් ක්‍රම කළ හැකිය.
    /// [`Acquire`] භාවිතා කිරීමෙන් ගබඩාව [`Relaxed`] වන අතර [`Release`] භාවිතා කිරීමෙන් බර කොටස [`Relaxed`] බවට පත් වේ.
    ///
    ///
    /// **Note:** මෙම ක්‍රමය ලබා ගත හැක්කේ `u8` හි පරමාණුක මෙහෙයුම් සඳහා සහාය වන වේදිකාවල පමණි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // ආරක්ෂාව: පරමාණුක අභ්‍යන්තරය මගින් දත්ත තරඟ වලක්වනු ලැබේ.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// වත්මන් අගය `current` අගයට සමාන නම් [`bool`] වෙත අගයක් ගබඩා කරයි.
    ///
    /// ප්‍රතිලාභ අගය සෑම විටම පෙර අගය වේ.එය `current` ට සමාන නම්, අගය යාවත්කාලීන කරන ලදි.
    ///
    /// `compare_and_swap` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කරන [`Ordering`] තර්කයක් ද ගනී.
    /// [`AcqRel`] භාවිතා කරන විට පවා, ක්‍රියාකාරිත්වය අසාර්ථක විය හැකි අතර එබැවින් `Acquire` බරක් පමණක් සිදු කළ හැකි නමුත් `Release` අර්ථ නිරූපණයන් නොමැති බව සැලකිල්ලට ගන්න.
    /// [`Acquire`] භාවිතා කිරීමෙන් ගබඩාව මෙම මෙහෙයුමේ [`Relaxed`] සිදු වුවහොත් එය සිදු වන අතර [`Release`] භාවිතා කිරීමෙන් බර කොටස [`Relaxed`] වේ.
    ///
    /// **Note:** මෙම ක්‍රමය ලබා ගත හැක්කේ `u8` හි පරමාණුක මෙහෙයුම් සඳහා සහාය වන වේදිකාවල පමණි.
    ///
    /// # `compare_exchange` සහ `compare_exchange_weak` වෙත සංක්‍රමණය වීම
    ///
    /// `compare_and_swap` මතක ඇණවුම් සඳහා පහත සිතියම්ගත කිරීම සමඟ `compare_exchange` ට සමාන වේ:
    ///
    /// මුල් |සාර්ථකත්වය |අසමත් වීම
    /// -------- | ------- | -------
    /// සන්සුන් |සන්සුන් |ලිහිල් අත්පත් කර ගැනීම |ලබා ගන්න |මුදා හැරීම ලබා ගන්න |මුදා හැරීම |ලිහිල් කළ AcqRel |AcqRel |SeqCst ලබා ගන්න |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` සංසන්දනය සාර්ථක වූ විට පවා ව්‍යාජ ලෙස අසමත් වීමට ඉඩ දී ඇති අතර, එමඟින් සංසන්දනය හා හුවමාරුව ලූපයක භාවිතා කරන විට වඩා හොඳ එකලස් කේතයක් ජනනය කිරීමට සම්පාදකයාට ඉඩ දෙයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// වත්මන් අගය `current` අගයට සමාන නම් [`bool`] වෙත අගයක් ගබඩා කරයි.
    ///
    /// ප්‍රතිලාභ අගය යනු නව අගය ලියා ඇත්ද සහ පෙර අගය අඩංගුද යන්න දැක්වෙන ප්‍රති result ලයකි.
    /// සාර්ථක වූ විට මෙම අගය `current` ට සමාන බව සහතික කෙරේ.
    ///
    /// `compare_exchange` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කිරීම සඳහා [`Ordering`] තර්ක දෙකක් ගනී.
    /// `success` `current` සමඟ සංසන්දනය සාර්ථක වුවහොත් සිදුවන කියවීම්-වෙනස් කිරීම-ලිවීමේ මෙහෙයුම සඳහා අවශ්‍ය ඇණවුම විස්තර කරයි.
    /// `failure` සංසන්දනය අසමත් වූ විට සිදුවන බර පැටවීමේ ක්‍රියාවලිය සඳහා අවශ්‍ය ඇණවුම විස්තර කරයි.
    /// [`Acquire`] සාර්ථක අනුපිළිවෙලක් ලෙස භාවිතා කිරීම ගබඩාව මෙම මෙහෙයුමේ [`Relaxed`] බවට පත් කරයි, සහ [`Release`] භාවිතා කිරීමෙන් [`Relaxed`] සාර්ථක බර පැටවේ.
    ///
    /// අසමත් වීමේ ඇණවුම [`SeqCst`], [`Acquire`] හෝ [`Relaxed`] පමණක් විය හැකි අතර එය සාර්ථක අනුපිළිවෙලට සමාන හෝ දුර්වල විය යුතුය.
    ///
    /// **Note:** මෙම ක්‍රමය ලබා ගත හැක්කේ `u8` හි පරමාණුක මෙහෙයුම් සඳහා සහාය වන වේදිකාවල පමණි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // ආරක්ෂාව: පරමාණුක අභ්‍යන්තරය මගින් දත්ත තරඟ වලක්වනු ලැබේ.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// වත්මන් අගය `current` අගයට සමාන නම් [`bool`] වෙත අගයක් ගබඩා කරයි.
    ///
    /// [`AtomicBool::compare_exchange`] මෙන් නොව, සංසන්දනය සාර්ථක වූ විට පවා මෙම ශ්‍රිතය ව්‍යාජ ලෙස අසමත් වීමට ඉඩ දී ඇති අතර එමඟින් සමහර වේදිකාවල වඩාත් කාර්යක්ෂම කේතයක් ඇති විය හැකිය.
    ///
    /// ප්‍රතිලාභ අගය යනු නව අගය ලියා ඇත්ද සහ පෙර අගය අඩංගුද යන්න දැක්වෙන ප්‍රති result ලයකි.
    ///
    /// `compare_exchange_weak` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කිරීම සඳහා [`Ordering`] තර්ක දෙකක් ගනී.
    /// `success` `current` සමඟ සංසන්දනය සාර්ථක වුවහොත් සිදුවන කියවීම්-වෙනස් කිරීම-ලිවීමේ මෙහෙයුම සඳහා අවශ්‍ය ඇණවුම විස්තර කරයි.
    /// `failure` සංසන්දනය අසමත් වූ විට සිදුවන බර පැටවීමේ ක්‍රියාවලිය සඳහා අවශ්‍ය ඇණවුම විස්තර කරයි.
    /// [`Acquire`] සාර්ථක අනුපිළිවෙලක් ලෙස භාවිතා කිරීම ගබඩාව මෙම මෙහෙයුමේ [`Relaxed`] බවට පත් කරයි, සහ [`Release`] භාවිතා කිරීමෙන් [`Relaxed`] සාර්ථක බර පැටවේ.
    /// අසමත් වීමේ ඇණවුම [`SeqCst`], [`Acquire`] හෝ [`Relaxed`] පමණක් විය හැකි අතර එය සාර්ථක අනුපිළිවෙලට සමාන හෝ දුර්වල විය යුතුය.
    ///
    /// **Note:** මෙම ක්‍රමය ලබා ගත හැක්කේ `u8` හි පරමාණුක මෙහෙයුම් සඳහා සහාය වන වේදිකාවල පමණි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // ආරක්ෂාව: පරමාණුක අභ්‍යන්තරය මගින් දත්ත තරඟ වලක්වනු ලැබේ.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// තාර්කික "and" බූලියන් අගයක් සහිත.
    ///
    /// වත්මන් අගය සහ `val` පරාමිතිය මත තාර්කික "and" මෙහෙයුමක් සිදු කරන අතර ප්‍රති value ලයට නව අගය සකසයි.
    ///
    /// පෙර අගය ලබා දෙයි.
    ///
    /// `fetch_and` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කරන [`Ordering`] තර්කයක් ගනී.සියලුම ඇණවුම් ක්‍රම කළ හැකිය.
    /// [`Acquire`] භාවිතා කිරීමෙන් ගබඩාව [`Relaxed`] වන අතර [`Release`] භාවිතා කිරීමෙන් බර කොටස [`Relaxed`] බවට පත් වේ.
    ///
    ///
    /// **Note:** මෙම ක්‍රමය ලබා ගත හැක්කේ `u8` හි පරමාණුක මෙහෙයුම් සඳහා සහාය වන වේදිකාවල පමණි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // ආරක්ෂාව: පරමාණුක අභ්‍යන්තරය මගින් දත්ත තරඟ වලක්වනු ලැබේ.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// තාර්කික "nand" බූලියන් අගයක් සහිත.
    ///
    /// වත්මන් අගය සහ `val` පරාමිතිය මත තාර්කික "nand" මෙහෙයුමක් සිදු කරන අතර ප්‍රති value ලයට නව අගය සකසයි.
    ///
    /// පෙර අගය ලබා දෙයි.
    ///
    /// `fetch_nand` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කරන [`Ordering`] තර්කයක් ගනී.සියලුම ඇණවුම් ක්‍රම කළ හැකිය.
    /// [`Acquire`] භාවිතා කිරීමෙන් ගබඩාව [`Relaxed`] වන අතර [`Release`] භාවිතා කිරීමෙන් බර කොටස [`Relaxed`] බවට පත් වේ.
    ///
    ///
    /// **Note:** මෙම ක්‍රමය ලබා ගත හැක්කේ `u8` හි පරමාණුක මෙහෙයුම් සඳහා සහාය වන වේදිකාවල පමණි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // අපට මෙහි පරමාණුක_නන්ඩ් භාවිතා කළ නොහැක, මන්ද එය අවලංගු අගයක් සහිත bool වලට හේතු විය හැක.
        // මෙය සිදු වන්නේ පරමාණුක ක්‍රියාකාරිත්වය අභ්‍යන්තරව බිටු 8 ක පූර්ණ සංඛ්‍යාවක් සමඟ සිදු කරන අතර එමඟින් ඉහළ බිටු 7 සැකසෙනු ඇත.
        //
        // ඒ නිසා අපි ඒ වෙනුවට fetch_xor හෝ swap භාවිතා කරමු.
        if val {
            // ! (x&true)== !x අපි bool පෙරළා දැමිය යුතුයි.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true අපි bool සත්‍ය ලෙස සැකසිය යුතුයි.
            //
            self.swap(true, order)
        }
    }

    /// තාර්කික "or" බූලියන් අගයක් සහිත.
    ///
    /// වත්මන් අගය සහ `val` පරාමිතිය මත තාර්කික "or" මෙහෙයුමක් සිදු කරන අතර ප්‍රති value ලයට නව අගය සකසයි.
    ///
    /// පෙර අගය ලබා දෙයි.
    ///
    /// `fetch_or` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කරන [`Ordering`] තර්කයක් ගනී.සියලුම ඇණවුම් ක්‍රම කළ හැකිය.
    /// [`Acquire`] භාවිතා කිරීමෙන් ගබඩාව [`Relaxed`] වන අතර [`Release`] භාවිතා කිරීමෙන් බර කොටස [`Relaxed`] බවට පත් වේ.
    ///
    ///
    /// **Note:** මෙම ක්‍රමය ලබා ගත හැක්කේ `u8` හි පරමාණුක මෙහෙයුම් සඳහා සහාය වන වේදිකාවල පමණි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // ආරක්ෂාව: පරමාණුක අභ්‍යන්තරය මගින් දත්ත තරඟ වලක්වනු ලැබේ.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// තාර්කික "xor" බූලියන් අගයක් සහිත.
    ///
    /// වත්මන් අගය සහ `val` පරාමිතිය මත තාර්කික "xor" මෙහෙයුමක් සිදු කරන අතර ප්‍රති value ලයට නව අගය සකසයි.
    ///
    /// පෙර අගය ලබා දෙයි.
    ///
    /// `fetch_xor` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කරන [`Ordering`] තර්කයක් ගනී.සියලුම ඇණවුම් ක්‍රම කළ හැකිය.
    /// [`Acquire`] භාවිතා කිරීමෙන් ගබඩාව [`Relaxed`] වන අතර [`Release`] භාවිතා කිරීමෙන් බර කොටස [`Relaxed`] බවට පත් වේ.
    ///
    ///
    /// **Note:** මෙම ක්‍රමය ලබා ගත හැක්කේ `u8` හි පරමාණුක මෙහෙයුම් සඳහා සහාය වන වේදිකාවල පමණි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // ආරක්ෂාව: පරමාණුක අභ්‍යන්තරය මගින් දත්ත තරඟ වලක්වනු ලැබේ.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// විකෘති වූ දර්ශකයක් යටින් පවතින [`bool`] වෙත ලබා දෙයි.
    ///
    /// පරමාණුක නොවන කියවීම් හා ප්‍රති ing ලයක් ලෙස ඇති වන පූර්ණ සංඛ්‍යා මත ලිවීම දත්ත තරඟයක් විය හැකිය.
    /// මෙම ක්‍රමය බොහෝ දුරට FFI සඳහා ප්‍රයෝජනවත් වේ, එහිදී ශ්‍රිත අත්සන `&AtomicBool` වෙනුවට `*mut bool` භාවිතා කළ හැකිය.
    ///
    /// මෙම පරමාණුව පිළිබඳ හවුල් සඳහනකින් `*mut` දර්ශකයක් නැවත ලබා දීම ආරක්ෂිත වන්නේ පරමාණුක වර්ග අභ්‍යන්තර විකෘතිතාව සමඟ ක්‍රියා කරන බැවිනි.
    /// පරමාණුවක සියළුම වෙනස් කිරීම් හවුල් යොමුවකින් අගය වෙනස් කරන අතර පරමාණුක මෙහෙයුම් භාවිතා කරන තාක් කල් එය ආරක්ෂිතව කළ හැකිය.
    /// ආපසු ලබා දුන් අමු දර්ශකයේ ඕනෑම භාවිතයකට `unsafe` වාරණයක් අවශ්‍ය වන අතර තවමත් එම සීමාවම පිළිගත යුතුය: එය මත මෙහෙයුම් පරමාණුක විය යුතුය.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// අගය ලබා ගන්නා අතර විකල්ප නව අගයක් ලබා දෙන ශ්‍රිතයක් එයට අදාළ කරයි.ශ්‍රිතය `Some(_)` නැවත ලබා දුන්නේ නම් `Ok(previous_value)` හි `Result`, වෙනත් `Err(previous_value)` ලබා දෙයි.
    ///
    /// Note: `Some(_)` ශ්‍රිතය ආපසු ලබා දෙන තාක් කල්, වෙනත් නූල් වලින් අගය වෙනස් කර ඇත්නම් මෙය ශ්‍රිතය කිහිප වතාවක්ම හැඳින්විය හැක, නමුත් ශ්‍රිතය යෙදී ඇත්තේ ගබඩා කළ අගයට එක් වරක් පමණි.
    ///
    ///
    /// `fetch_update` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කිරීම සඳහා [`Ordering`] තර්ක දෙකක් ගනී.
    /// පළමුවැන්න මෙහෙයුම සාර්ථක වූ විට අවශ්‍ය ඇණවුම විස්තර කරන අතර දෙවැන්න බර පැටවීම සඳහා අවශ්‍ය ඇණවුම විස්තර කරයි.
    /// මේවා පිළිවෙලින් [`AtomicBool::compare_exchange`] හි සාර්ථකත්වය සහ අසාර්ථක අනුපිළිවෙලට අනුරූප වේ.
    ///
    /// [`Acquire`] සාර්ථක ඇණවුමක් ලෙස භාවිතා කිරීමෙන් ගබඩාව [`Relaxed`] වන අතර [`Release`] භාවිතා කිරීමෙන් අවසාන සාර්ථක භාරය [`Relaxed`] වේ.
    /// (failed) පැටවුම් ඇණවුම විය හැක්කේ [`SeqCst`], [`Acquire`] හෝ [`Relaxed`] පමණක් වන අතර එය සාර්ථක අනුපිළිවෙලට සමාන හෝ දුර්වල විය යුතුය.
    ///
    /// **Note:** මෙම ක්‍රමය ලබා ගත හැක්කේ `u8` හි පරමාණුක මෙහෙයුම් සඳහා සහාය වන වේදිකාවල පමණි.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// නව `AtomicPtr` නිර්මාණය කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// යටින් ඇති දර්ශකය වෙත විකෘති යොමු කිරීමක් ලබා දෙයි.
    ///
    /// මෙය ආරක්ෂිත වන්නේ විකෘති යොමුව වෙනත් නූල් සමගාමීව පරමාණුක දත්ත වලට ප්‍රවේශ නොවන බවට සහතික වන බැවිනි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// දර්ශකයකට පරමාණුක ප්‍රවේශය ලබා ගන්න.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - විකෘති යොමුව අද්විතීය හිමිකම සහතික කරයි.
        //  - ඉහත සත්‍යාපනය කර ඇති පරිදි rust මඟින් සහය දක්වන සියලුම වේදිකා වල `*mut T` සහ `Self` පෙළගැස්ම සමාන වේ.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// පරමාණුක පරිභෝජනය කර අඩංගු අගය ලබා දෙයි.
    ///
    /// `self` අගය අනුව ගමන් කිරීම වෙනත් නූල් සමගාමීව පරමාණුක දත්ත වලට ප්‍රවේශ නොවන බවට සහතික වන බැවින් මෙය ආරක්ෂිත වේ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// දර්ශකයෙන් අගයක් පූරණය වේ.
    ///
    /// `load` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කරන [`Ordering`] තර්කයක් ගනී.
    /// විය හැකි අගයන් වන්නේ [`SeqCst`], [`Acquire`] සහ [`Relaxed`] ය.
    ///
    /// # Panics
    ///
    /// `order` [`Release`] හෝ [`AcqRel`] නම් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // ආරක්ෂාව: පරමාණුක අභ්‍යන්තරය මගින් දත්ත තරඟ වලක්වනු ලැබේ.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// අගයක් දර්ශකයට ගබඩා කරයි.
    ///
    /// `store` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කරන [`Ordering`] තර්කයක් ගනී.
    /// විය හැකි අගයන් වන්නේ [`SeqCst`], [`Release`] සහ [`Relaxed`] ය.
    ///
    /// # Panics
    ///
    /// `order` [`Acquire`] හෝ [`AcqRel`] නම් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // ආරක්ෂාව: පරමාණුක අභ්‍යන්තරය මගින් දත්ත තරඟ වලක්වනු ලැබේ.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// පෙර අගය ලබා දෙමින් අගයක් දර්ශකයට ගබඩා කරයි.
    ///
    /// `swap` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කරන [`Ordering`] තර්කයක් ගනී.සියලුම ඇණවුම් ක්‍රම කළ හැකිය.
    /// [`Acquire`] භාවිතා කිරීමෙන් ගබඩාව [`Relaxed`] වන අතර [`Release`] භාවිතා කිරීමෙන් බර කොටස [`Relaxed`] බවට පත් වේ.
    ///
    ///
    /// **Note:** මෙම ක්‍රමය ලබා ගත හැක්කේ දර්ශක මත පරමාණුක ක්‍රියාකාරිත්වයට සහාය වන වේදිකාවල පමණි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // ආරක්ෂාව: පරමාණුක අභ්‍යන්තරය මගින් දත්ත තරඟ වලක්වනු ලැබේ.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// වත්මන් අගය `current` අගයට සමාන නම් අගයක් දර්ශකයට ගබඩා කරයි.
    ///
    /// ප්‍රතිලාභ අගය සෑම විටම පෙර අගය වේ.එය `current` ට සමාන නම්, අගය යාවත්කාලීන කරන ලදි.
    ///
    /// `compare_and_swap` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කරන [`Ordering`] තර්කයක් ද ගනී.
    /// [`AcqRel`] භාවිතා කරන විට පවා, ක්‍රියාකාරිත්වය අසාර්ථක විය හැකි අතර එබැවින් `Acquire` බරක් පමණක් සිදු කළ හැකි නමුත් `Release` අර්ථ නිරූපණයන් නොමැති බව සැලකිල්ලට ගන්න.
    /// [`Acquire`] භාවිතා කිරීමෙන් ගබඩාව මෙම මෙහෙයුමේ [`Relaxed`] සිදු වුවහොත් එය සිදු වන අතර [`Release`] භාවිතා කිරීමෙන් බර කොටස [`Relaxed`] වේ.
    ///
    /// **Note:** මෙම ක්‍රමය ලබා ගත හැක්කේ දර්ශක මත පරමාණුක ක්‍රියාකාරිත්වයට සහාය වන වේදිකාවල පමණි.
    ///
    /// # `compare_exchange` සහ `compare_exchange_weak` වෙත සංක්‍රමණය වීම
    ///
    /// `compare_and_swap` මතක ඇණවුම් සඳහා පහත සිතියම්ගත කිරීම සමඟ `compare_exchange` ට සමාන වේ:
    ///
    /// මුල් |සාර්ථකත්වය |අසමත් වීම
    /// -------- | ------- | -------
    /// සන්සුන් |සන්සුන් |ලිහිල් අත්පත් කර ගැනීම |ලබා ගන්න |මුදා හැරීම ලබා ගන්න |මුදා හැරීම |ලිහිල් කළ AcqRel |AcqRel |SeqCst ලබා ගන්න |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` සංසන්දනය සාර්ථක වූ විට පවා ව්‍යාජ ලෙස අසමත් වීමට ඉඩ දී ඇති අතර, එමඟින් සංසන්දනය හා හුවමාරුව ලූපයක භාවිතා කරන විට වඩා හොඳ එකලස් කේතයක් ජනනය කිරීමට සම්පාදකයාට ඉඩ දෙයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// වත්මන් අගය `current` අගයට සමාන නම් අගයක් දර්ශකයට ගබඩා කරයි.
    ///
    /// ප්‍රතිලාභ අගය යනු නව අගය ලියා ඇත්ද සහ පෙර අගය අඩංගුද යන්න දැක්වෙන ප්‍රති result ලයකි.
    /// සාර්ථක වූ විට මෙම අගය `current` ට සමාන බව සහතික කෙරේ.
    ///
    /// `compare_exchange` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කිරීම සඳහා [`Ordering`] තර්ක දෙකක් ගනී.
    /// `success` `current` සමඟ සංසන්දනය සාර්ථක වුවහොත් සිදුවන කියවීම්-වෙනස් කිරීම-ලිවීමේ මෙහෙයුම සඳහා අවශ්‍ය ඇණවුම විස්තර කරයි.
    /// `failure` සංසන්දනය අසමත් වූ විට සිදුවන බර පැටවීමේ ක්‍රියාවලිය සඳහා අවශ්‍ය ඇණවුම විස්තර කරයි.
    /// [`Acquire`] සාර්ථක අනුපිළිවෙලක් ලෙස භාවිතා කිරීම ගබඩාව මෙම මෙහෙයුමේ [`Relaxed`] බවට පත් කරයි, සහ [`Release`] භාවිතා කිරීමෙන් [`Relaxed`] සාර්ථක බර පැටවේ.
    ///
    /// අසමත් වීමේ ඇණවුම [`SeqCst`], [`Acquire`] හෝ [`Relaxed`] පමණක් විය හැකි අතර එය සාර්ථක අනුපිළිවෙලට සමාන හෝ දුර්වල විය යුතුය.
    ///
    /// **Note:** මෙම ක්‍රමය ලබා ගත හැක්කේ දර්ශක මත පරමාණුක ක්‍රියාකාරිත්වයට සහාය වන වේදිකාවල පමණි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // ආරක්ෂාව: පරමාණුක අභ්‍යන්තරය මගින් දත්ත තරඟ වලක්වනු ලැබේ.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// වත්මන් අගය `current` අගයට සමාන නම් අගයක් දර්ශකයට ගබඩා කරයි.
    ///
    /// [`AtomicPtr::compare_exchange`] මෙන් නොව, සංසන්දනය සාර්ථක වූ විට පවා මෙම ශ්‍රිතය ව්‍යාජ ලෙස අසමත් වීමට ඉඩ දී ඇති අතර එමඟින් සමහර වේදිකාවල වඩාත් කාර්යක්ෂම කේතයක් ඇති විය හැකිය.
    ///
    /// ප්‍රතිලාභ අගය යනු නව අගය ලියා ඇත්ද සහ පෙර අගය අඩංගුද යන්න දැක්වෙන ප්‍රති result ලයකි.
    ///
    /// `compare_exchange_weak` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කිරීම සඳහා [`Ordering`] තර්ක දෙකක් ගනී.
    /// `success` `current` සමඟ සංසන්දනය සාර්ථක වුවහොත් සිදුවන කියවීම්-වෙනස් කිරීම-ලිවීමේ මෙහෙයුම සඳහා අවශ්‍ය ඇණවුම විස්තර කරයි.
    /// `failure` සංසන්දනය අසමත් වූ විට සිදුවන බර පැටවීමේ ක්‍රියාවලිය සඳහා අවශ්‍ය ඇණවුම විස්තර කරයි.
    /// [`Acquire`] සාර්ථක අනුපිළිවෙලක් ලෙස භාවිතා කිරීම ගබඩාව මෙම මෙහෙයුමේ [`Relaxed`] බවට පත් කරයි, සහ [`Release`] භාවිතා කිරීමෙන් [`Relaxed`] සාර්ථක බර පැටවේ.
    /// අසමත් වීමේ ඇණවුම [`SeqCst`], [`Acquire`] හෝ [`Relaxed`] පමණක් විය හැකි අතර එය සාර්ථක අනුපිළිවෙලට සමාන හෝ දුර්වල විය යුතුය.
    ///
    /// **Note:** මෙම ක්‍රමය ලබා ගත හැක්කේ දර්ශක මත පරමාණුක ක්‍රියාකාරිත්වයට සහාය වන වේදිකාවල පමණි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // ආරක්ෂාව: අමු දර්ශකයක් මත ක්‍රියාත්මක වන බැවින් මෙම සහජ අනාරක්ෂිත ය
        // නමුත් දර්ශකය වලංගු බව අපි නිසැකවම දනිමු (අප එය ලබාගෙන ඇත්තේ `UnsafeCell` වෙතින් ය.) පරමාණුක ක්‍රියාකාරිත්වය මඟින් `UnsafeCell` අන්තර්ගතය ආරක්ෂිතව විකෘති කිරීමට අපට ඉඩ සලසයි.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// අගය ලබා ගන්නා අතර විකල්ප නව අගයක් ලබා දෙන ශ්‍රිතයක් එයට අදාළ කරයි.ශ්‍රිතය `Some(_)` නැවත ලබා දුන්නේ නම් `Ok(previous_value)` හි `Result`, වෙනත් `Err(previous_value)` ලබා දෙයි.
    ///
    /// Note: `Some(_)` ශ්‍රිතය ආපසු ලබා දෙන තාක් කල්, වෙනත් නූල් වලින් අගය වෙනස් කර ඇත්නම් මෙය ශ්‍රිතය කිහිප වතාවක්ම හැඳින්විය හැක, නමුත් ශ්‍රිතය යෙදී ඇත්තේ ගබඩා කළ අගයට එක් වරක් පමණි.
    ///
    ///
    /// `fetch_update` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කිරීම සඳහා [`Ordering`] තර්ක දෙකක් ගනී.
    /// පළමුවැන්න මෙහෙයුම සාර්ථක වූ විට අවශ්‍ය ඇණවුම විස්තර කරන අතර දෙවැන්න බර පැටවීම සඳහා අවශ්‍ය ඇණවුම විස්තර කරයි.
    /// මේවා පිළිවෙලින් [`AtomicPtr::compare_exchange`] හි සාර්ථකත්වයට හා අසාර්ථක අනුපිළිවෙලට අනුරූප වේ.
    ///
    /// [`Acquire`] සාර්ථක ඇණවුමක් ලෙස භාවිතා කිරීමෙන් ගබඩාව [`Relaxed`] වන අතර [`Release`] භාවිතා කිරීමෙන් අවසාන සාර්ථක භාරය [`Relaxed`] වේ.
    /// (failed) පැටවුම් ඇණවුම විය හැක්කේ [`SeqCst`], [`Acquire`] හෝ [`Relaxed`] පමණක් වන අතර එය සාර්ථක අනුපිළිවෙලට සමාන හෝ දුර්වල විය යුතුය.
    ///
    /// **Note:** මෙම ක්‍රමය ලබා ගත හැක්කේ දර්ශක මත පරමාණුක ක්‍රියාකාරිත්වයට සහාය වන වේදිකාවල පමණි.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// `bool` `AtomicBool` බවට පරිවර්තනය කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // මෙම සාර්ව සමහර ගෘහ නිර්මාණ සඳහා භාවිතා නොකෙරේ.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// නූල් අතර ආරක්ෂිතව බෙදා ගත හැකි පූර්ණ සංඛ්‍යා වර්ගයකි.
        ///
        /// මෙම වර්ගයට යටින් පවතින පූර්ණ සංඛ්‍යා වර්ගයට සමාන මතක මතකයක් ඇත, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// පරමාණුක වර්ග සහ පරමාණුක නොවන වර්ග අතර ඇති වෙනස්කම් ගැන මෙන්ම මෙම වර්ගයේ අතේ ගෙන යා හැකි හැකියාව පිළිබඳ වැඩි විස්තර සඳහා කරුණාකර [module-level documentation] බලන්න.
        ///
        ///
        /// **Note:** මෙම වර්ගය ලබා ගත හැක්කේ පරමාණුක පැටවීම් සහ [`හි ගබඩා සඳහා සහාය වන වේදිකා වල පමණි
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// `0` වෙත ආරම්භ කරන ලද පරමාණුක පූර්ණ සංඛ්‍යාවක්.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // යැවීම ව්‍යංගයෙන් ක්‍රියාත්මක වේ.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// නව පරමාණුක පූර්ණ සංඛ්‍යාවක් නිර්මාණය කරයි.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// යටින් පවතින නිඛිලයට විකෘති යොමු කිරීමක් ලබා දෙයි.
            ///
            /// මෙය ආරක්ෂිත වන්නේ විකෘති යොමුව වෙනත් නූල් සමගාමීව පරමාණුක දත්ත වලට ප්‍රවේශ නොවන බවට සහතික වන බැවිනි.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - විකෘති යොමුව අද්විතීය හිමිකම සහතික කරයි.
                //  - X002 සහ `Self` හි පෙළගැස්ම $cfg_align විසින් පොරොන්දු වූ සහ ඉහත සත්‍යාපනය කළ ආකාරයටම වේ.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// පරමාණුක පරිභෝජනය කර අඩංගු අගය ලබා දෙයි.
            ///
            /// `self` අගය අනුව ගමන් කිරීම වෙනත් නූල් සමගාමීව පරමාණුක දත්ත වලට ප්‍රවේශ නොවන බවට සහතික වන බැවින් මෙය ආරක්ෂිත වේ.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// පරමාණුක පූර්ණ සංඛ්‍යාවෙන් අගයක් පටවයි.
            ///
            /// `load` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කරන [`Ordering`] තර්කයක් ගනී.
            /// විය හැකි අගයන් වන්නේ [`SeqCst`], [`Acquire`] සහ [`Relaxed`] ය.
            ///
            /// # Panics
            ///
            /// `order` [`Release`] හෝ [`AcqRel`] නම් Panics.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // ආරක්ෂාව: පරමාණුක අභ්‍යන්තරය මගින් දත්ත තරඟ වලක්වනු ලැබේ.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// පරමාණුක පූර්ණ සංඛ්‍යාවට අගයක් ගබඩා කරයි.
            ///
            /// `store` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කරන [`Ordering`] තර්කයක් ගනී.
            ///  විය හැකි අගයන් වන්නේ [`SeqCst`], [`Release`] සහ [`Relaxed`] ය.
            ///
            /// # Panics
            ///
            /// `order` [`Acquire`] හෝ [`AcqRel`] නම් Panics.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // ආරක්ෂාව: පරමාණුක අභ්‍යන්තරය මගින් දත්ත තරඟ වලක්වනු ලැබේ.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// පරමාණුක පූර්ණ සංඛ්‍යාවට අගයක් ගබඩා කර පෙර අගය ලබා දෙයි.
            ///
            /// `swap` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කරන [`Ordering`] තර්කයක් ගනී.සියලුම ඇණවුම් ක්‍රම කළ හැකිය.
            /// [`Acquire`] භාවිතා කිරීමෙන් ගබඩාව [`Relaxed`] වන අතර [`Release`] භාවිතා කිරීමෙන් බර කොටස [`Relaxed`] බවට පත් වේ.
            ///
            ///
            /// **සටහන**: මෙම ක්‍රමය ලබා ගත හැක්කේ පරමාණුක ක්‍රියාකාරිත්වයට සහාය වන වේදිකාවල පමණි
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // ආරක්ෂාව: පරමාණුක අභ්‍යන්තරය මගින් දත්ත තරඟ වලක්වනු ලැබේ.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// වත්මන් අගය `current` අගයට සමාන නම් පරමාණුක නිඛිලයට අගයක් ගබඩා කරයි.
            ///
            /// ප්‍රතිලාභ අගය සෑම විටම පෙර අගය වේ.එය `current` ට සමාන නම්, අගය යාවත්කාලීන කරන ලදි.
            ///
            /// `compare_and_swap` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කරන [`Ordering`] තර්කයක් ද ගනී.
            /// [`AcqRel`] භාවිතා කරන විට පවා, ක්‍රියාකාරිත්වය අසාර්ථක විය හැකි අතර එබැවින් `Acquire` බරක් පමණක් සිදු කළ හැකි නමුත් `Release` අර්ථ නිරූපණයන් නොමැති බව සැලකිල්ලට ගන්න.
            ///
            /// [`Acquire`] භාවිතා කිරීමෙන් ගබඩාව මෙම මෙහෙයුමේ [`Relaxed`] සිදු වුවහොත් එය සිදු වන අතර [`Release`] භාවිතා කිරීමෙන් බර කොටස [`Relaxed`] වේ.
            ///
            /// **සටහන**: මෙම ක්‍රමය ලබා ගත හැක්කේ පරමාණුක ක්‍රියාකාරිත්වයට සහාය වන වේදිකාවල පමණි
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # `compare_exchange` සහ `compare_exchange_weak` වෙත සංක්‍රමණය වීම
            ///
            /// `compare_and_swap` මතක ඇණවුම් සඳහා පහත සිතියම්ගත කිරීම සමඟ `compare_exchange` ට සමාන වේ:
            ///
            /// මුල් |සාර්ථකත්වය |අසමත් වීම
            /// -------- | ------- | -------
            /// සන්සුන් |සන්සුන් |ලිහිල් අත්පත් කර ගැනීම |ලබා ගන්න |මුදා හැරීම ලබා ගන්න |මුදා හැරීම |ලිහිල් කළ AcqRel |AcqRel |SeqCst ලබා ගන්න |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` සංසන්දනය සාර්ථක වූ විට පවා ව්‍යාජ ලෙස අසමත් වීමට ඉඩ දී ඇති අතර, එමඟින් සංසන්දනය හා හුවමාරුව ලූපයක භාවිතා කරන විට වඩා හොඳ එකලස් කේතයක් ජනනය කිරීමට සම්පාදකයාට ඉඩ දෙයි.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// වත්මන් අගය `current` අගයට සමාන නම් පරමාණුක නිඛිලයට අගයක් ගබඩා කරයි.
            ///
            /// ප්‍රතිලාභ අගය යනු නව අගය ලියා ඇත්ද සහ පෙර අගය අඩංගුද යන්න දැක්වෙන ප්‍රති result ලයකි.
            /// සාර්ථක වූ විට මෙම අගය `current` ට සමාන බව සහතික කෙරේ.
            ///
            /// `compare_exchange` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කිරීම සඳහා [`Ordering`] තර්ක දෙකක් ගනී.
            /// `success` `current` සමඟ සංසන්දනය සාර්ථක වුවහොත් සිදුවන කියවීම්-වෙනස් කිරීම-ලිවීමේ මෙහෙයුම සඳහා අවශ්‍ය ඇණවුම විස්තර කරයි.
            /// `failure` සංසන්දනය අසමත් වූ විට සිදුවන බර පැටවීමේ ක්‍රියාවලිය සඳහා අවශ්‍ය ඇණවුම විස්තර කරයි.
            /// [`Acquire`] සාර්ථක අනුපිළිවෙලක් ලෙස භාවිතා කිරීම ගබඩාව මෙම මෙහෙයුමේ [`Relaxed`] බවට පත් කරයි, සහ [`Release`] භාවිතා කිරීමෙන් [`Relaxed`] සාර්ථක බර පැටවේ.
            ///
            /// අසමත් වීමේ ඇණවුම [`SeqCst`], [`Acquire`] හෝ [`Relaxed`] පමණක් විය හැකි අතර එය සාර්ථක අනුපිළිවෙලට සමාන හෝ දුර්වල විය යුතුය.
            ///
            /// **සටහන**: මෙම ක්‍රමය ලබා ගත හැක්කේ පරමාණුක ක්‍රියාකාරිත්වයට සහාය වන වේදිකාවල පමණි
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // ආරක්ෂාව: පරමාණුක අභ්‍යන්තරය මගින් දත්ත තරඟ වලක්වනු ලැබේ.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// වත්මන් අගය `current` අගයට සමාන නම් පරමාණුක නිඛිලයට අගයක් ගබඩා කරයි.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// සංසන්දනය සාර්ථක වූ විට පවා මෙම ශ්‍රිතය ව්‍යාජ ලෙස අසමත් වීමට ඉඩ දී ඇති අතර එමඟින් සමහර වේදිකාවල වඩාත් කාර්යක්ෂම කේතයක් ඇති විය හැකිය.
            /// ප්‍රතිලාභ අගය යනු නව අගය ලියා ඇත්ද සහ පෙර අගය අඩංගුද යන්න දැක්වෙන ප්‍රති result ලයකි.
            ///
            /// `compare_exchange_weak` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කිරීම සඳහා [`Ordering`] තර්ක දෙකක් ගනී.
            /// `success` `current` සමඟ සංසන්දනය සාර්ථක වුවහොත් සිදුවන කියවීම්-වෙනස් කිරීම-ලිවීමේ මෙහෙයුම සඳහා අවශ්‍ය ඇණවුම විස්තර කරයි.
            /// `failure` සංසන්දනය අසමත් වූ විට සිදුවන බර පැටවීමේ ක්‍රියාවලිය සඳහා අවශ්‍ය ඇණවුම විස්තර කරයි.
            /// [`Acquire`] සාර්ථක අනුපිළිවෙලක් ලෙස භාවිතා කිරීම ගබඩාව මෙම මෙහෙයුමේ [`Relaxed`] බවට පත් කරයි, සහ [`Release`] භාවිතා කිරීමෙන් [`Relaxed`] සාර්ථක බර පැටවේ.
            ///
            /// අසමත් වීමේ ඇණවුම [`SeqCst`], [`Acquire`] හෝ [`Relaxed`] පමණක් විය හැකි අතර එය සාර්ථක අනුපිළිවෙලට සමාන හෝ දුර්වල විය යුතුය.
            ///
            /// **සටහන**: මෙම ක්‍රමය ලබා ගත හැක්කේ පරමාණුක ක්‍රියාකාරිත්වයට සහාය වන වේදිකාවල පමණි
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// mut old= val.load(Ordering::Relaxed);
            /// loop new නව=පැරණි * 2 ඉඩ දෙන්න;
            ///     val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, } match ගැලපෙන්න
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // ආරක්ෂාව: පරමාණුක අභ්‍යන්තරය මගින් දත්ත තරඟ වලක්වනු ලැබේ.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// වත්මන් අගයට එකතු කරයි, පෙර අගය නැවත ලබා දෙයි.
            ///
            /// මෙම මෙහෙයුම පිටාර ගැලීම වටා එති.
            ///
            /// `fetch_add` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කරන [`Ordering`] තර්කයක් ගනී.සියලුම ඇණවුම් ක්‍රම කළ හැකිය.
            /// [`Acquire`] භාවිතා කිරීමෙන් ගබඩාව [`Relaxed`] වන අතර [`Release`] භාවිතා කිරීමෙන් බර කොටස [`Relaxed`] බවට පත් වේ.
            ///
            ///
            /// **සටහන**: මෙම ක්‍රමය ලබා ගත හැක්කේ පරමාණුක ක්‍රියාකාරිත්වයට සහාය වන වේදිකාවල පමණි
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // ආරක්ෂාව: පරමාණුක අභ්‍යන්තරය මගින් දත්ත තරඟ වලක්වනු ලැබේ.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// වත්මන් අගයෙන් අඩු කර, පෙර අගය ආපසු ලබා දේ.
            ///
            /// මෙම මෙහෙයුම පිටාර ගැලීම වටා එති.
            ///
            /// `fetch_sub` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කරන [`Ordering`] තර්කයක් ගනී.සියලුම ඇණවුම් ක්‍රම කළ හැකිය.
            /// [`Acquire`] භාවිතා කිරීමෙන් ගබඩාව [`Relaxed`] වන අතර [`Release`] භාවිතා කිරීමෙන් බර කොටස [`Relaxed`] බවට පත් වේ.
            ///
            ///
            /// **සටහන**: මෙම ක්‍රමය ලබා ගත හැක්කේ පරමාණුක ක්‍රියාකාරිත්වයට සහාය වන වේදිකාවල පමණි
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // ආරක්ෂාව: පරමාණුක අභ්‍යන්තරය මගින් දත්ත තරඟ වලක්වනු ලැබේ.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// වත්මන් අගය සමඟ බිට්වයිස් "and".
            ///
            /// වත්මන් අගය සහ `val` පරාමිතිය මත බිට්වේස් "and" මෙහෙයුමක් සිදු කරන අතර ප්‍රති value ලයට නව අගය සකසයි.
            ///
            /// පෙර අගය ලබා දෙයි.
            ///
            /// `fetch_and` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කරන [`Ordering`] තර්කයක් ගනී.සියලුම ඇණවුම් ක්‍රම කළ හැකිය.
            /// [`Acquire`] භාවිතා කිරීමෙන් ගබඩාව [`Relaxed`] වන අතර [`Release`] භාවිතා කිරීමෙන් බර කොටස [`Relaxed`] බවට පත් වේ.
            ///
            ///
            /// **සටහන**: මෙම ක්‍රමය ලබා ගත හැක්කේ පරමාණුක ක්‍රියාකාරිත්වයට සහාය වන වේදිකාවල පමණි
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // ආරක්ෂාව: පරමාණුක අභ්‍යන්තරය මගින් දත්ත තරඟ වලක්වනු ලැබේ.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// වත්මන් අගය සමඟ බිට්වයිස් "nand".
            ///
            /// වත්මන් අගය සහ `val` පරාමිතිය මත බිට්වේස් "nand" මෙහෙයුමක් සිදු කරන අතර ප්‍රති value ලයට නව අගය සකසයි.
            ///
            /// පෙර අගය ලබා දෙයි.
            ///
            /// `fetch_nand` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කරන [`Ordering`] තර්කයක් ගනී.සියලුම ඇණවුම් ක්‍රම කළ හැකිය.
            /// [`Acquire`] භාවිතා කිරීමෙන් ගබඩාව [`Relaxed`] වන අතර [`Release`] භාවිතා කිරීමෙන් බර කොටස [`Relaxed`] බවට පත් වේ.
            ///
            ///
            /// **සටහන**: මෙම ක්‍රමය ලබා ගත හැක්කේ පරමාණුක ක්‍රියාකාරිත්වයට සහාය වන වේදිකාවල පමණි
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // ආරක්ෂාව: පරමාණුක අභ්‍යන්තරය මගින් දත්ත තරඟ වලක්වනු ලැබේ.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// වත්මන් අගය සමඟ බිට්වයිස් "or".
            ///
            /// වත්මන් අගය සහ `val` පරාමිතිය මත බිට්වේස් "or" මෙහෙයුමක් සිදු කරන අතර ප්‍රති value ලයට නව අගය සකසයි.
            ///
            /// පෙර අගය ලබා දෙයි.
            ///
            /// `fetch_or` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කරන [`Ordering`] තර්කයක් ගනී.සියලුම ඇණවුම් ක්‍රම කළ හැකිය.
            /// [`Acquire`] භාවිතා කිරීමෙන් ගබඩාව [`Relaxed`] වන අතර [`Release`] භාවිතා කිරීමෙන් බර කොටස [`Relaxed`] බවට පත් වේ.
            ///
            ///
            /// **සටහන**: මෙම ක්‍රමය ලබා ගත හැක්කේ පරමාණුක ක්‍රියාකාරිත්වයට සහාය වන වේදිකාවල පමණි
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // ආරක්ෂාව: පරමාණුක අභ්‍යන්තරය මගින් දත්ත තරඟ වලක්වනු ලැබේ.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// වත්මන් අගය සමඟ බිට්වයිස් "xor".
            ///
            /// වත්මන් අගය සහ `val` පරාමිතිය මත බිට්වේස් "xor" මෙහෙයුමක් සිදු කරන අතර ප්‍රති value ලයට නව අගය සකසයි.
            ///
            /// පෙර අගය ලබා දෙයි.
            ///
            /// `fetch_xor` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කරන [`Ordering`] තර්කයක් ගනී.සියලුම ඇණවුම් ක්‍රම කළ හැකිය.
            /// [`Acquire`] භාවිතා කිරීමෙන් ගබඩාව [`Relaxed`] වන අතර [`Release`] භාවිතා කිරීමෙන් බර කොටස [`Relaxed`] බවට පත් වේ.
            ///
            ///
            /// **සටහන**: මෙම ක්‍රමය ලබා ගත හැක්කේ පරමාණුක ක්‍රියාකාරිත්වයට සහාය වන වේදිකාවල පමණි
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // ආරක්ෂාව: පරමාණුක අභ්‍යන්තරය මගින් දත්ත තරඟ වලක්වනු ලැබේ.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// අගය ලබා ගන්නා අතර විකල්ප නව අගයක් ලබා දෙන ශ්‍රිතයක් එයට අදාළ කරයි.ශ්‍රිතය `Some(_)` නැවත ලබා දුන්නේ නම් `Ok(previous_value)` හි `Result`, වෙනත් `Err(previous_value)` ලබා දෙයි.
            ///
            /// Note: `Some(_)` ශ්‍රිතය ආපසු ලබා දෙන තාක් කල්, වෙනත් නූල් වලින් අගය වෙනස් කර ඇත්නම් මෙය ශ්‍රිතය කිහිප වතාවක්ම හැඳින්විය හැක, නමුත් ශ්‍රිතය යෙදී ඇත්තේ ගබඩා කළ අගයට එක් වරක් පමණි.
            ///
            ///
            /// `fetch_update` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කිරීම සඳහා [`Ordering`] තර්ක දෙකක් ගනී.
            /// පළමුවැන්න මෙහෙයුම සාර්ථක වූ විට අවශ්‍ය ඇණවුම විස්තර කරන අතර දෙවැන්න බර පැටවීම සඳහා අවශ්‍ය ඇණවුම විස්තර කරයි.මේවායේ සාර්ථකත්වය හා අසාර්ථක අනුපිළිවෙලට අනුරූප වේ
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// [`Acquire`] සාර්ථක ඇණවුමක් ලෙස භාවිතා කිරීමෙන් ගබඩාව [`Relaxed`] වන අතර [`Release`] භාවිතා කිරීමෙන් අවසාන සාර්ථක භාරය [`Relaxed`] වේ.
            /// (failed) පැටවුම් ඇණවුම විය හැක්කේ [`SeqCst`], [`Acquire`] හෝ [`Relaxed`] පමණක් වන අතර එය සාර්ථක අනුපිළිවෙලට සමාන හෝ දුර්වල විය යුතුය.
            ///
            /// **සටහන**: මෙම ක්‍රමය ලබා ගත හැක්කේ පරමාණුක ක්‍රියාකාරිත්වයට සහාය වන වේදිකාවල පමණි
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (ඇණවුම් කිරීම: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (ඇණවුම් කිරීම: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// වත්මන් අගය සමඟ උපරිම.
            ///
            /// වත්මන් අගයෙහි උපරිම අගය සහ `val` පරාමිතිය සොයාගෙන නව අගය ප්‍රති .ලයට සකසයි.
            ///
            /// පෙර අගය ලබා දෙයි.
            ///
            /// `fetch_max` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කරන [`Ordering`] තර්කයක් ගනී.සියලුම ඇණවුම් ක්‍රම කළ හැකිය.
            /// [`Acquire`] භාවිතා කිරීමෙන් ගබඩාව [`Relaxed`] වන අතර [`Release`] භාවිතා කිරීමෙන් බර කොටස [`Relaxed`] බවට පත් වේ.
            ///
            ///
            /// **සටහන**: මෙම ක්‍රමය ලබා ගත හැක්කේ පරමාණුක ක්‍රියාකාරිත්වයට සහාය වන වේදිකාවල පමණි
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// ඉඩ දෙන්න බාර්=42;
            /// max_foo=foo.fetch_max (තීරුව, Ordering::SeqCst).max(bar);
            /// තහවුරු කරන්න! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // ආරක්ෂාව: පරමාණුක අභ්‍යන්තරය මගින් දත්ත තරඟ වලක්වනු ලැබේ.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// වත්මන් අගය සමඟ අවම.
            ///
            /// වත්මන් අගයේ අවම අගය සහ `val` පරාමිතිය සොයාගෙන නව අගය ප්‍රති .ලයට සකසයි.
            ///
            /// පෙර අගය ලබා දෙයි.
            ///
            /// `fetch_min` මෙම මෙහෙයුමේ මතක අනුපිළිවෙල විස්තර කරන [`Ordering`] තර්කයක් ගනී.සියලුම ඇණවුම් ක්‍රම කළ හැකිය.
            /// [`Acquire`] භාවිතා කිරීමෙන් ගබඩාව [`Relaxed`] වන අතර [`Release`] භාවිතා කිරීමෙන් බර කොටස [`Relaxed`] බවට පත් වේ.
            ///
            ///
            /// **සටහන**: මෙම ක්‍රමය ලබා ගත හැක්කේ පරමාණුක ක්‍රියාකාරිත්වයට සහාය වන වේදිකාවල පමණි
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// ඉඩ දෙන්න බාර්=12;
            /// min_foo=foo.fetch_min (තීරුව, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // ආරක්ෂාව: පරමාණුක අභ්‍යන්තරය මගින් දත්ත තරඟ වලක්වනු ලැබේ.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// විකෘති වූ දර්ශකයක් යටින් පවතින පූර්ණ සංඛ්‍යාවට ලබා දෙයි.
            ///
            /// පරමාණුක නොවන කියවීම් හා ප්‍රති ing ලයක් ලෙස ඇති වන පූර්ණ සංඛ්‍යා මත ලිවීම දත්ත තරඟයක් විය හැකිය.
            /// මෙම ක්‍රමය බොහෝ දුරට FFI සඳහා ප්‍රයෝජනවත් වේ, එහිදී ශ්‍රිත අත්සන භාවිතා කළ හැකිය
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// මෙම පරමාණුව පිළිබඳ හවුල් සඳහනකින් `*mut` දර්ශකයක් නැවත ලබා දීම ආරක්ෂිත වන්නේ පරමාණුක වර්ග අභ්‍යන්තර විකෘතිතාව සමඟ ක්‍රියා කරන බැවිනි.
            /// පරමාණුවක සියළුම වෙනස් කිරීම් හවුල් යොමුවකින් අගය වෙනස් කරන අතර පරමාණුක මෙහෙයුම් භාවිතා කරන තාක් කල් එය ආරක්ෂිතව කළ හැකිය.
            /// ආපසු ලබා දුන් අමු දර්ශකයේ ඕනෑම භාවිතයකට `unsafe` වාරණයක් අවශ්‍ය වන අතර තවමත් එම සීමාවම පිළිගත යුතුය: එය මත මෙහෙයුම් පරමාණුක විය යුතුය.
            ///
            ///
            /// # Examples
            ///
            /// `` (extern-declaration) නොසලකා හරින්න
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// බාහිර "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // ආරක්ෂාව: `my_atomic_op` පරමාණුක පවතින තාක් කල් ආරක්ෂිතයි.
            /// අනාරක්ෂිත {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // ආරක්ෂාව: අමතන්නා `atomic_store` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // ආරක්ෂාව: අමතන්නා `atomic_load` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ආරක්ෂාව: අමතන්නා `atomic_swap` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// පෙර අගය ලබා දෙයි (__sync_fetch_and_add වැනි).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ආරක්ෂාව: අමතන්නා `atomic_add` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// පෙර අගය ලබා දෙයි (__sync_fetch_and_sub වැනි).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ආරක්ෂාව: අමතන්නා `atomic_sub` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // ආරක්ෂාව: අමතන්නා `atomic_compare_exchange` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // ආරක්ෂාව: අමතන්නා `atomic_compare_exchange_weak` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ආරක්ෂාව: අමතන්නා `atomic_and` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ආරක්ෂාව: අමතන්නා `atomic_nand` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ආරක්ෂාව: අමතන්නා `atomic_or` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ආරක්ෂාව: අමතන්නා `atomic_xor` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// උපරිම අගය ලබා දෙයි (අත්සන් කළ සංසන්දනය)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ආරක්ෂාව: අමතන්නා `atomic_max` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// අවම අගය ලබා දෙයි (අත්සන් කළ සංසන්දනය)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ආරක්ෂාව: අමතන්නා `atomic_min` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// උපරිම අගය ලබා දෙයි (අත්සන් නොකළ සංසන්දනය)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ආරක්ෂාව: අමතන්නා `atomic_umax` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// අවම අගය ලබා දෙයි (අත්සන් නොකළ සංසන්දනය)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ආරක්ෂාව: අමතන්නා `atomic_umin` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// පරමාණුක වැටක්.
///
/// නිශ්චිත අනුපිළිවෙල අනුව, වැටක් මඟින් සම්පාදකයා සහ සීපීයූ වටා ඇති ඇතැම් මතක මෙහෙයුම් නැවත සකස් කිරීම වළක්වයි.
/// එමඟින් සමමුහුර්තතාවයන් ඇති කරයි-එය අතර පරමාණුක මෙහෙයුම් හෝ වැටවල් අතර සම්බන්ධතා.
///
/// (අවම වශයෙන්) [`Release`] ඇණවුම් කිරීමේ අර්ථයක් ඇති වැටක් 'A', වැටක් සමඟ 'B' (අවම වශයෙන්) [`Acquire`] අර්ථ නිරූපණයන් සමඟ සමමුහුර්ත කරයි, X සහ Y මෙහෙයුම් තිබේ නම් සහ පමණක් නම්, දෙකම 'M' පරමාණුක වස්තුවක් මත ක්‍රියාත්මක වන අතර ඒ දෙකම පෙර අනුපිළිවෙලට සකසා ඇත. X, Y B ට පෙර සමමුහුර්ත කර ඇති අතර Y වෙත වෙනස නිරීක්ෂණය කරයි.
/// මෙය A සහ B අතර සිදුවීමට පෙර යැපීමක් සපයයි.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// [`Release`] හෝ [`Acquire`] අර්ථ නිරූපණයන් සමඟ පරමාණුක මෙහෙයුම් ද වැටක් සමඟ සමමුහුර්ත කළ හැකිය.
///
/// [`SeqCst`] ඇණවුම සහිත වැටක්, [`Acquire`] සහ [`Release`] අර්ථකථන දෙකම තිබීමට අමතරව, අනෙක් [`SeqCst`] මෙහෙයුම් සහ/හෝ වැටවල් වල ගෝලීය වැඩසටහන් අනුපිළිවෙලට සහභාගී වේ.
///
/// [`Acquire`], [`Release`], [`AcqRel`] සහ [`SeqCst`] ඇණවුම් භාර ගනී.
///
/// # Panics
///
/// `order` [`Relaxed`] නම් Panics.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // භ්‍රමණය වන අන්‍යෝන්‍ය බැහැර කිරීමේ ප්‍රාථමිකය.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // පැරණි අගය `false` වන තෙක් රැඳී සිටින්න.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // මෙම වැට `unlock` හි ගබඩාව සමඟ සමමුහුර්ත කරයි.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // ආරක්ෂාව: පරමාණුක වැටක් භාවිතා කිරීම ආරක්ෂිතයි.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// සම්පාදක මතක වැටක්.
///
/// `compiler_fence` කිසිදු යන්ත්‍ර කේතයක් විමෝචනය නොකරයි, නමුත් සම්පාදකයාට කිරීමට අවසර දී ඇති මතකය නැවත ඇණවුම් කිරීම සීමා කරයි.නිශ්චිතවම, දී ඇති [`Ordering`] අර්ථ නිරූපණය මත පදනම්ව, `compiler_fence` වෙත ඇමතුමේ අනෙක් පැත්තට ඇමතුමට පෙර හෝ පසුව කියවීම් හෝ ලිවීම් සම්පාදනය කිරීමට අවසර නොදේ.එවැනි දෘඩාංග *නැවත ඇණවුම් කිරීමෙන් එය** වළක්වන්නේ නැති බව සලකන්න.
///
/// මෙය තනි-නූල්, ක්‍රියාත්මක කිරීමේ සන්දර්භය තුළ ගැටළුවක් නොවේ, නමුත් වෙනත් නූල් එකවර මතකය වෙනස් කළ හැකි විට, [`fence`] වැනි ශක්තිමත් සමමුහුර්ත ප්‍රාථමිකයන් අවශ්‍ය වේ.
///
/// විවිධ ඇණවුම් අර්ථකථන මගින් නැවත ඇණවුම් කිරීම වළක්වා ඇත:
///
///  - [`SeqCst`] සමඟ, මෙම ලක්ෂ්‍යය හරහා කියවීම් සහ ලිවීම් නැවත ඇණවුම් කිරීමට අවසර නැත.
///  - [`Release`] සමඟ, පෙර කියවීම් සහ ලිවීම් පසුකාලීන ලිවීම් පසුකර යා නොහැක.
///  - [`Acquire`] සමඟ, පසු කියවීම් හා ලිවීම් පෙර කියවීම් වලට වඩා ඉදිරියට ගෙන යා නොහැක.
///  - [`AcqRel`] සමඟ, ඉහත නීති දෙකම බලාත්මක වේ.
///
/// `compiler_fence` සාමාන්‍යයෙන් ප්‍රයෝජනවත් වන්නේ නූල් එකක් * තමා සමඟ ධාවනය කිරීමෙන් වලක්වා ගැනීම සඳහා පමණි.එනම්, දී ඇති නූල් එක කේත කැබැල්ලක් ක්‍රියාත්මක කරන්නේ නම්, පසුව එය බාධා වී වෙනත් තැනක කේත ක්‍රියාත්මක කිරීමට පටන් ගනී නම් (තවමත් එකම ත්‍රෙඩ් එකේ සිටියදීත්, සංකල්පමය වශයෙන් තවමත් එකම හරයේ).සාම්ප්‍රදායික වැඩසටහන් වලදී මෙය සිදුවිය හැක්කේ සං hand ා හසුරුවන්නෙකු ලියාපදිංචි වූ විට පමණි.
/// වඩාත් පහත් මට්ටමේ කේත වලදී, බාධා කිරීම් හැසිරවීමේදී, පූර්ව-විභේදනය සමඟ හරිත කෙඳි ක්‍රියාත්මක කිරීමේදී ද එවැනි තත්වයන් ඇතිවිය හැකිය.
/// කුතුහලය දනවන පා readers කයන්ට [memory barriers] පිළිබඳ Linux කර්නලයේ සාකච්ඡාව කියවීමට දිරිගන්වනු ලැබේ.
///
/// # Panics
///
/// `order` [`Relaxed`] නම් Panics.
///
/// # Examples
///
/// `compiler_fence` නොමැතිව, සෑම කේතයක්ම එකම ත්‍රෙඩ් එකක සිදු වුවද, පහත දැක්වෙන කේතයේ ඇති `assert_eq!` සාර්ථක වීමට සහතික නොවේ.
/// හේතුව බැලීමට, සම්පාදකයාට `IMPORTANT_VARIABLE` සහ `IS_READ` වෙත වෙළඳසැල් මාරු කිරීමට නිදහස ඇති බව මතක තබා ගන්න.එය සිදු වුවහොත් සහ `IS_READY` යාවත්කාලීන වූ වහාම සං hand ා හසුරුවන්නාට ආයාචනා කළහොත්, සං signal ා හසුරුවන්නාට `IS_READY=1` පෙනෙනු ඇත, නමුත් `IMPORTANT_VARIABLE=0`.
/// `compiler_fence` ප්‍රතිකර්මයක් භාවිතා කිරීමෙන් මෙම තත්වයට පිළියම් යෙදේ.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // කලින් ලියවිලි මෙම කරුණෙන් ඔබ්බට යාම වළක්වන්න
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // ආරක්ෂාව: පරමාණුක වැටක් භාවිතා කිරීම ආරක්ෂිතයි.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// ප්‍රොසෙසරය කාර්යබහුල-රැඳී සිටින භ්‍රමණය වන ලූපයක් ("භ්‍රමණ අගුල") තුළ ඇති බවට සං als ා කරයි.
///
/// මෙම ශ්‍රිතය [`hint::spin_loop`] සඳහා වාසිදායක ලෙස ඉවත් කර ඇත.
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}