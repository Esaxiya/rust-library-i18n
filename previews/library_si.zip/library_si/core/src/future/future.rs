#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future යනු අසමමුහුර්ත ගණනය කිරීමකි.
///
/// future යනු තවමත් පරිගණකය අවසන් කර නොමැති අගයකි.
/// මේ ආකාරයේ "asynchronous value" මඟින් වටිනාකමක් ලබා ගත හැකි තෙක් බලා සිටින අතරතුර නූල් එකකට ප්‍රයෝජනවත් වැඩ දිගටම කරගෙන යාමට හැකි වේ.
///
///
/// # `poll` ක්‍රමය
///
/// future, `poll` හි මූලික ක්‍රමය future අවසාන අගයක් ලෙස නිරාකරණය කිරීමට උත්සාහ කරයි.
/// අගය සූදානම් නැතිනම් මෙම ක්‍රමය අවහිර නොවේ.
/// ඒ වෙනුවට, වර්තමාන කාර්යය නැවත ඡන්ද විමසීමෙන් තවදුරටත් ප්‍රගතියක් ලබා ගත හැකි වූ විට අවදි කිරීමට සැලසුම් කර ඇත.
/// `poll` ක්‍රමයට ලබා දුන් `context` හට [`Waker`] ලබා දිය හැකි අතර එය වර්තමාන කාර්යය අවදි කිරීම සඳහා හසුරුවකි.
///
/// future භාවිතා කරන විට, ඔබ සාමාන්‍යයෙන් `poll` කෙලින්ම අමතන්නේ නැත, නමුත් ඒ වෙනුවට `.await` අගය.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// සම්පුර්ණ වූ විට නිපදවන අගය වර්ගය.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// future අවසාන අගයකට විසඳීමට උත්සාහ කිරීම, වටිනාකම තවමත් නොමැති නම් අවදි කිරීම සඳහා වත්මන් කාර්යය ලියාපදිංචි කිරීම.
    ///
    /// # ප්‍රතිලාභ අගය
    ///
    /// මෙම ශ්‍රිතය නැවත පැමිණේ:
    ///
    /// - [`Poll::Pending`] future තවමත් සූදානම් නැතිනම්
    /// - [`Poll::Ready(val)`] මෙම future හි `val` ප්‍රති result ලය සමඟ එය සාර්ථකව අවසන් වුවහොත්.
    ///
    /// future අවසන් වූ පසු, සේවාදායකයින් එය නැවත `poll` නොකළ යුතුය.
    ///
    /// future තවමත් සුදානම් නැති විට, `poll` `Poll::Pending` ආපසු ලබා දෙන අතර වත්මන් [`Context`] වෙතින් පිටපත් කරන ලද [`Waker`] හි ක්ලෝනයක් ගබඩා කරයි.
    /// future ප්‍රගතියක් ලබා ගත හැකි වූ විට මෙම [`Waker`] අවදි වේ.
    /// උදාහරණයක් ලෙස, සොකට් එකක් කියවිය හැකි වන තෙක් බලා සිටින future, [`Waker`] හි `.clone()` අමතා එය ගබඩා කරයි.
    /// සොකට්ටුව කියවිය හැකි බව අඟවන සං signal ාවක් වෙනත් තැනකට පැමිණි විට, [`Waker::wake`] ලෙස හැඳින්වෙන අතර සොකට් future හි කාර්යය අවදි වේ.
    /// කර්තව්‍යයක් අවදි වූ පසු, එය නැවත `poll` future වෙත උත්සාහ කළ යුතුය, එය අවසාන අගයක් හෝ නොතිබිය හැකිය.
    ///
    /// `poll` වෙත බහු ඇමතුම් වලදී, නවතම ඇමතුමට ලබා දුන් [`Context`] සිට [`Waker`] පමණක් අවදි වීමට නියමිත බව සලකන්න.
    ///
    /// # ධාවන කාල ලක්ෂණ
    ///
    /// Futures පමණක් *නිෂ්ක්‍රීය*;ප්‍රගතියක් ලබා ගැනීම සඳහා ඒවා *ක්‍රියාශීලීව* ඡන්ද විමසීමක් කළ යුතු අතර, එයින් අදහස් වන්නේ වර්තමාන කර්තව්‍යය අවදි වන සෑම අවස්ථාවකම, එය තවමත් උනන්දුවක් දක්වන futures හි ඉතිරිව ඇති futures සක්‍රීයව නැවත ප්‍රතිස්ථාපනය කළ යුතු බවයි.
    ///
    /// `poll` ශ්‍රිතය තද පුඩුවක් තුළ නැවත නැවත නොකියයි-ඒ වෙනුවට, එය හැඳින්විය යුත්තේ future එය ප්‍රගතියක් ලබා ගැනීමට සූදානම් බව පෙන්නුම් කළ විට පමණි (`wake()`) ඇමතීමෙන්).
    /// ඔබ Unix හි `poll(2)` හෝ `select(2)` syscalls ගැන හුරුපුරුදු නම්, futures සාමාන්‍යයෙන් "all wakeups must poll all events" හි සමාන ගැටළු වලට ගොදුරු නොවන බව සඳහන් කිරීම වටී;ඒවා `epoll(4)` වගේ.
    ///
    /// `poll` ක්‍රියාත්මක කිරීම ඉක්මණින් ආපසු යාමට උත්සාහ කළ යුතු අතර එය අවහිර නොකළ යුතුය.ඉක්මණින් ආපසු යාම අනවශ්‍ය ලෙස නූල් හෝ සිදුවීම් ලූප අවහිර වීම වළක්වයි.
    /// `poll` වෙත ඇමතුමක් ලබා ගැනීමට ටික වේලාවක් ගතවනු ඇතැයි කල්තියා දැනගත හොත්, `poll` ඉක්මනින් ආපසු පැමිණිය හැකි බව සහතික කිරීම සඳහා වැඩ නූල් තටාකයකට (හෝ ඊට සමාන දෙයක්) පටවා තිබිය යුතුය.
    ///
    /// # Panics
    ///
    /// future සම්පුර්ණ වූ පසු (`Ready` වෙතින් `Ready` ආපසු ලබා දෙන ලදි), එහි `poll` ක්‍රමය නැවත කැඳවීම panic, සදහටම අවහිර කිරීම හෝ වෙනත් ආකාරයේ ගැටළු ඇති කළ හැකිය;`Future` trait එවැනි ඇමතුමක ප්‍රති on ල සඳහා අවශ්‍යතා නොමැත.
    /// කෙසේ වෙතත්, `poll` ක්‍රමය `unsafe` ලෙස සලකුණු කර නොමැති බැවින්, Rust හි සුපුරුදු නීති අදාළ වේ: ඇමතුම් කිසි විටෙකත් නිර්වචනය නොකළ හැසිරීමට හේතු නොවිය යුතුය (මතක දූෂණය, `unsafe` ශ්‍රිත වැරදි ලෙස භාවිතා කිරීම හෝ ඒ හා සමාන), future හි තත්වය කුමක් වුවත්.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}