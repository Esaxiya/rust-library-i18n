#![stable(feature = "futures_api", since = "1.36.0")]

//! අසමමුහුර්ත අගයන්.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// මෙම වර්ගය අවශ්‍ය වන්නේ:
///
/// a) උත්පාදක යන්ත්‍රවලට `for<'a, 'b> Generator<&'a mut Context<'b>>` ක්‍රියාත්මක කළ නොහැක, එබැවින් අපට අමු දර්ශකයක් පසු කළ යුතුය (<https://github.com/rust-lang/rust/issues/68923> බලන්න).
///
/// b) අමු දර්ශක සහ `NonNull` යනු `Send` හෝ `Sync` නොවේ, එම නිසා සෑම future non-Send/Sync ද සෑදිය හැකි අතර අපට එය අවශ්‍ය නොවේ.
///
/// එය HIR `.await` පහත හෙලීමද සරල කරයි.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// future තුළ ජනක යන්ත්‍රයක් ඔතා.
///
/// මෙම ශ්‍රිතය යටින් `GenFuture` ලබා දෙයි, නමුත් වඩා හොඳ දෝෂ පණිවිඩ ලබා දීම සඳහා එය `impl Trait` හි සඟවයි (`GenFuture<[closure.....]>` වෙනුවට `impl Future`).
///
// අපි `const async fn` වෙතින් යථා තත්ත්වයට පත් වූ පසු අමතර දෝෂ මඟහරවා ගැනීම සඳහා මෙය `const` වේ
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // යටින් පවතින උත්පාදක යන්ත්රය තුළ ස්වයං-යොමු ණය ලබා ගැනීම සඳහා async/await futures නිශ්චල බව අපි විශ්වාස කරමු.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // ආරක්ෂාව: අප !Unpin + !Drop නිසා ආරක්ෂිතයි, මෙය ක්ෂේත්‍ර ප්‍රක්ෂේපණයක් පමණයි.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // උත්පාදක යන්ත්රය නැවත අරඹන්න, `&mut Context` `NonNull` අමු දර්ශකයක් බවට පත් කරන්න.
            // `.await` අඩු කිරීම ආරක්ෂිතව එය නැවත `&mut Context` වෙත දමනු ඇත.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // ආරක්ෂාව: අමතන්නා `cx.0` වලංගු දර්ශකයක් බව සහතික කළ යුතුය
    // විකෘති යොමු කිරීමක් සඳහා වන සියලු අවශ්‍යතා සපුරාලන.
    unsafe { &mut *cx.0.as_ptr().cast() }
}