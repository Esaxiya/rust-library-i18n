use crate::future::Future;

/// `Future` බවට පරිවර්තනය කිරීම.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// future නිමැවුම නිම කිරීමෙන් පසු නිපදවනු ඇත.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// අපි මෙය කුමන ආකාරයේ future බවට හරවන්නේද?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// අගයකින් future නිර්මාණය කරයි.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}