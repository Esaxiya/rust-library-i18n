//! හුවමාරු කළ හැකි විකෘති බහාලුම්.
//!
//! Rust මතක ආරක්ෂාව මෙම රීතිය මත පදනම් වේ: `T` වස්තුවක් ලබා දී ඇති විට, කළ හැක්කේ පහත සඳහන් දේවලින් එකක් පමණි:
//!
//! - (`&T`) වස්තුවට වෙනස් කළ නොහැකි යොමු කිරීම් කිහිපයක් තිබීම (**අන්වර්ථකරණය** ලෙසද හැඳින්වේ).
//! - වස්තුවට එක් විකෘති යොමු කිරීමක් (`&mut T`) තිබීම (**විකෘතිතාව** ලෙසද හැඳින්වේ).
//!
//! මෙය Rust සම්පාදකයා විසින් බලාත්මක කරනු ලැබේ.කෙසේ වෙතත්, මෙම නියමය ප්‍රමාණවත් ලෙස නම්‍යශීලී නොවන අවස්ථා තිබේ.සමහර විට එය වස්තුවකට බහුවිධ යොමු කිරීම් අවශ්‍ය වන අතර එය විකෘති කරයි.
//!
//! අන්වර්ථකරණය තිබියදීත්, පාලනය කළ හැකි ආකාරයකට විකෘතිතාවයට ඉඩ දීම සඳහා හුවමාරු කළ හැකි විකෘති බහාලුම් පවතී.[`Cell<T>`] සහ [`RefCell<T>`] යන දෙකම තනි නූල් ආකාරයකින් මෙය කිරීමට ඉඩ දෙයි.
//! කෙසේ වෙතත්, `Cell<T>` හෝ `RefCell<T>` නූල් ආරක්ෂිත නොවේ (ඒවා [`Sync`] ක්‍රියාත්මක නොකරයි).
//! ඔබට බහු නූල් අතර අන්වර්ථකරණය සහ විකෘතියක් කිරීමට අවශ්‍ය නම් [`Mutex<T>`], [`RwLock<T>`] හෝ [`atomic`] වර්ග භාවිතා කළ හැකිය.
//!
//! `Cell<T>` සහ `RefCell<T>` වර්ගවල අගයන් හවුල් යොමු කිරීම් හරහා විකෘති කළ හැකිය (එනම්
//! පොදු `&T` වර්ගය), නමුත් බොහෝ Rust වර්ග විකෘති කළ හැක්කේ අද්විතීය (`සහ mut T`) යොමු කිරීම් හරහා පමණි.
//! `Cell<T>` සහ `RefCell<T>` 'අභ්‍යන්තර විකෘතිතාව' සපයන බව අපි කියමු. සාමාන්‍ය Rust වර්ග වලට වඩා වෙනස්ව 'උරුම වූ විකෘතිතාව' පෙන්නුම් කරයි.
//!
//! සෛල වර්ග රස දෙකකින් යුක්ත වේ: `Cell<T>` සහ `RefCell<T>`.`Cell<T>`, `Cell<T>` තුළට සහ ඉන් පිටත අගයන් චලනය කිරීමෙන් අභ්‍යන්තර විකෘතිතාව ක්‍රියාත්මක කරයි.
//! අගයන් වෙනුවට යොමු භාවිතා කිරීමට, යමෙකු විකෘති වීමට පෙර ලිවීමේ අගුලක් ලබා ගනිමින් `RefCell<T>` වර්ගය භාවිතා කළ යුතුය.`Cell<T>` වත්මන් අභ්‍යන්තර අගය ලබා ගැනීමට සහ වෙනස් කිරීමට ක්‍රම සපයයි:
//!
//!  - [`Copy`] ක්‍රියාත්මක කරන වර්ග සඳහා, [`get`](Cell::get) ක්‍රමය මඟින් වර්තමාන අභ්‍යන්තර අගය ලබා ගනී.
//!  - [`Default`] ක්‍රියාත්මක කරන වර්ග සඳහා, [`take`](Cell::take) ක්‍රමය මඟින් වර්තමාන අභ්‍යන්තර අගය [`Default::default()`] සමඟ ප්‍රතිස්ථාපනය කර ප්‍රතිස්ථාපිත අගය ලබා දෙයි.
//!  - සියලුම වර්ග සඳහා, [`replace`](Cell::replace) ක්‍රමය වත්මන් අභ්‍යන්තර අගය ප්‍රතිස්ථාපනය කර ප්‍රතිස්ථාපනය කළ අගය නැවත ලබා දෙන අතර [`into_inner`](Cell::into_inner) ක්‍රමය `Cell<T>` පරිභෝජනය කර අභ්‍යන්තර අගය ලබා දෙයි.
//!  මීට අමතරව, [`set`](Cell::set) ක්රමය අභ්යන්තර අගය ප්රතිස්ථාපනය කරයි, ප්රතිස්ථාපනය කළ අගය පහත වැටේ.
//!
//! `RefCell<T>` 'ගතික ණය ගැනීම' ක්‍රියාත්මක කිරීම සඳහා Rust හි ජීවිත කාලය භාවිතා කරයි, එම ක්‍රියාවලිය අභ්‍යන්තර වටිනාකමට තාවකාලික, සුවිශේෂී, විකෘති ප්‍රවේශයක් ඉල්ලා සිටිය හැකිය.
//! `RefCell 'සඳහා ණය<T>Rust හි ස්වදේශීය යොමු වර්ග මෙන් නොව, සම්පුර්ණ කරන ලද වේලාවේදී සම්පුර්ණයෙන්ම සංඛ්‍යානමය වශයෙන් නිරීක්ෂණය කරනු ලැබේ.
//! `RefCell<T>` ණය ගැනීම් ගතික බැවින් දැනටමත් විකෘති ලෙස ණයට ගත් වටිනාකමක් ණයට ගැනීමට උත්සාහ කළ හැකිය;මෙය සිදු වූ විට එහි ප්‍රති Z ලය panic නූල් වේ.
//!
//! # අභ්යන්තර විකෘතිතාව තෝරා ගත යුත්තේ කවදාද?
//!
//! වටිනාකමක් විකෘති කිරීම සඳහා අද්විතීය ප්‍රවේශයක් තිබිය යුතු වඩාත් පොදු උරුම විකෘතිතාව, පොයින්ටර් අන්වර්ථකරණය පිළිබඳව දැඩි ලෙස තර්ක කිරීමට Rust සක්‍රීය කරන ප්‍රධාන භාෂා අංගයකි, බිඳවැටීම් දෝෂ සංඛ්‍යාත්මකව වළක්වයි.
//! එම හේතුව නිසා, උරුම වූ විකෘතිතාවයට වැඩි කැමැත්තක් දක්වන අතර අභ්‍යන්තර විකෘතිතාව යනු අවසාන පියවරකි.
//! සෛල වර්ග විකෘතියට ඉඩ නොදෙන තැනට විකෘති කිරීමට ඉඩ සලසන හෙයින්, අභ්‍යන්තර විකෘතිතාව සුදුසු විය හැකි අවස්ථා තිබේ, නැතහොත් * භාවිතා කළ යුතුය, උදා.
//!
//! * වෙනස් කළ නොහැකි දෙයක විකෘතිතා 'inside' හඳුන්වා දීම
//! * තාර්කිකව වෙනස් කළ නොහැකි ක්‍රම ක්‍රියාත්මක කිරීමේ තොරතුරු.
//! * [`Clone`] විකෘති ක්‍රියාත්මක කිරීම.
//!
//! ## වෙනස් කළ නොහැකි දෙයක විකෘතිතා 'inside' හඳුන්වා දීම
//!
//! [`Rc<T>`] සහ [`Arc<T>`] ඇතුළුව බොහෝ හවුල් ස්මාර්ට් පොයින්ටර් වර්ග, ක්ලෝන කළ හැකි සහ විවිධ පාර්ශව අතර බෙදා ගත හැකි බහාලුම් සපයයි.
//! අඩංගු අගයන් ගුණ-අන්වර්ථ කළ හැකි බැවින්, ඒවා ණයට ගත හැක්කේ `&mut` නොව `&` සමඟ පමණි.
//! සෛල නොමැතිව මෙම ස්මාර්ට් පොයින්ටර් තුළ දත්ත විකෘති කිරීමට කිසිසේත් නොහැකි වනු ඇත.
//!
//! විකෘතිතාව නැවත හඳුන්වාදීම සඳහා හවුල් පොයින්ටර් වර්ග තුළ `RefCell<T>` තැබීම සාමාන්‍ය දෙයකි:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // ගතික ණය ලබා ගැනීමේ විෂය පථය සීමා කිරීම සඳහා නව බ්ලොක් එකක් සාදන්න
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // හැඹිලියේ පෙර ණය මුදල විෂය පථයෙන් බැහැර වීමට අප ඉඩ නොදුන්නේ නම්, පසුව ලබා ගත් ණය මගින් ගතික නූල් panic ඇති වන බව සලකන්න.
//!     //
//!     // `RefCell` භාවිතා කිරීමේ ප්‍රධාන අනතුර මෙයයි.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! මෙම උදාහරණය X001 නොව `Rc<T>` භාවිතා කරන බව සලකන්න.`RefCell<T>තනි නූල් සහිත අවස්ථා සඳහා ය.ඔබට බහු-නූල් තත්වයක් තුළ හවුල් විකෘතිතාවයක් අවශ්‍ය නම් [`RwLock<T>`] හෝ [`Mutex<T>`] භාවිතා කිරීම සලකා බලන්න.
//!
//! ## තාර්කිකව වෙනස් කළ නොහැකි ක්‍රම ක්‍රියාත්මක කිරීමේ තොරතුරු
//!
//! ඇතැම් විට "under the hood" විකෘතියක් සිදුවන බවට API එකක නිරාවරණය නොකිරීම යෝග්‍ය වේ.
//! මෙයට හේතුව තාර්කිකව මෙහෙයුම වෙනස් කළ නොහැකි නමුත් උදා: හැඹිලිය විකෘතියක් සිදු කිරීමට ක්‍රියාත්මක කිරීමට බල කරයි;හෝ `&self` ගැනීමට මුලින් අර්ථ දක්වා ඇති trait ක්‍රමයක් ක්‍රියාත්මක කිරීම සඳහා ඔබ විකෘතියක් භාවිතා කළ යුතු බැවිනි.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // මිල අධික ගණනය කිරීම මෙතැනට යයි
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## `Clone` විකෘති ක්‍රියාත්මක කිරීම
//!
//! මෙය හුදෙක් පෙර පැවති විශේෂ, නමුත් පොදු අවස්ථාවකි: වෙනස් කළ නොහැකි බව පෙනෙන මෙහෙයුම් සඳහා විකෘතිතාව සැඟවීම.
//! [`clone`](Clone::clone) ක්‍රමය ප්‍රභව අගය වෙනස් නොකරනු ඇතැයි අපේක්ෂා කරන අතර `&mut self` නොව `&self` ගන්නා බව ප්‍රකාශ කෙරේ.
//! එබැවින්, `clone` ක්‍රමයේදී සිදුවන ඕනෑම විකෘතියක් සෛල වර්ග භාවිතා කළ යුතුය.
//! උදාහරණයක් ලෙස, [`Rc<T>`] එහි යොමු ගණන් `Cell<T>` තුළ පවත්වා ගනී.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// විකෘති මතක ස්ථානයක්.
///
/// # Examples
///
/// මෙම උදාහරණයේ දී, `Cell<T>` විසින් වෙනස් කළ නොහැකි ව්‍යුහයක් තුළ විකෘතිය සක්‍රීය කරන බව ඔබට පෙනේ.
/// වෙනත් වචන වලින් කිවහොත්, එය "interior mutability" සක්‍රීය කරයි.
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // දෝෂය: `my_struct` වෙනස් කළ නොහැක
/// // my_struct.regular_field =නව_ අගය;
///
/// // වැඩ: `my_struct` වෙනස් කළ නොහැකි වුවද, `special_field` යනු `Cell`,
/// // එය සැමවිටම විකෘති කළ හැකිය
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// වැඩි විස්තර සඳහා [module-level documentation](self) බලන්න.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// T සඳහා `Default` අගය සමඟ `Cell<T>` නිර්මාණය කරයි.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// දී ඇති අගය අඩංගු නව `Cell` සාදයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// අඩංගු අගය සකසයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// සෛල දෙකක අගයන් මාරු කරයි.
    /// `std::mem::swap` සමඟ ඇති වෙනස නම් මෙම ශ්‍රිතයට `&mut` යොමුව අවශ්‍ය නොවේ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // ආරක්ෂාව: වෙනම නූල් වලින් ඇමතුවහොත් මෙය අවදානම් විය හැකි නමුත් `Cell`
        // `!Sync` බැවින් මෙය සිදු නොවේ.
        // `Cell` මෙම 'සෛල' දෙකටම වෙනත් කිසිවක් යොමු නොවන බවට වග බලා ගන්නා බැවින් මෙය කිසිදු දර්ශකයක් අවලංගු නොකරයි.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// අඩංගු අගය `val` සමඟ ප්‍රතිස්ථාපනය කර පැරණි අඩංගු අගය නැවත ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // ආරක්ෂාව: මෙය වෙනම ත්‍රෙඩ් එකකින් කැඳවනු ලැබුවහොත් දත්ත තරඟවලට හේතු විය හැක,
        // නමුත් `Cell` යනු `!Sync` බැවින් මෙය සිදු නොවේ.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// වටිනාකම ලිහා දමයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// අඩංගු අගයේ පිටපතක් ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // ආරක්ෂාව: මෙය වෙනම ත්‍රෙඩ් එකකින් කැඳවනු ලැබුවහොත් දත්ත තරඟවලට හේතු විය හැක,
        // නමුත් `Cell` යනු `!Sync` බැවින් මෙය සිදු නොවේ.
        unsafe { *self.value.get() }
    }

    /// ශ්‍රිතයක් භාවිතා කර අඩංගු අගය යාවත්කාලීන කර නව අගය ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// මෙම කොටුවේ යටින් පවතින දත්ත වෙත අමු දර්ශකයක් ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// යටින් පවතින දත්ත වලට විකෘති යොමු කිරීමක් ලබා දෙයි.
    ///
    /// මෙම ඇමතුම `Cell` විකෘති ලෙස ණයට ගනී (සම්පාදනය කරන වේලාවේදී) එය අපට එකම සඳහනක් ඇති බවට සහතික කරයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `&mut T` වෙතින් `&Cell<T>` ලබා දෙයි
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // ආරක්ෂාව: `&mut` අද්විතීය ප්‍රවේශය සහතික කරයි.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// සෛලයේ වටිනාකම සැලකිල්ලට ගනිමින් `Default::default()` එහි ස්ථානයේ තබයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// `&Cell<[T]>` වෙතින් `&[Cell<T>]` ලබා දෙයි
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // ආරක්ෂාව: `Cell<T>` හි `T` හා සමාන මතක පිරිසැලසුමක් ඇත.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// ගතිකව පරීක්ෂා කරන ලද ණය නීති සහිත විකෘති මතක ස්ථානයක්
///
/// වැඩි විස්තර සඳහා [module-level documentation](self) බලන්න.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// [`RefCell::try_borrow`] විසින් ලබා දුන් දෝෂයකි.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// [`RefCell::try_borrow_mut`] විසින් ලබා දුන් දෝෂයකි.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// ධනාත්මක අගයන් නියෝජනය කරන්නේ `Ref` සක්‍රීය සංඛ්‍යාවයි.0 ණ අගයන් `RefMut` සක්‍රිය ගණන නියෝජනය කරයි.
// බහුවිධ `රීෆ්මූට් 'සක්‍රිය විය හැක්කේ එක් වරකට `RefCell` හි වෙනස් නොවන, නොගැලපෙන සංරචක (උදා: පෙත්තක විවිධ පරාසයන්) වෙත යොමු වුවහොත් පමණි.
//
// `Ref` සහ `RefMut` යන දෙකම ප්‍රමාණයේ වචන දෙකකි, එබැවින් `usize` පරාසයෙන් අඩක් පිටාර ගැලීම සඳහා ප්‍රමාණවත් තරම් `Ref` හෝ `RefMut` නොපවතිනු ඇත.
// මේ අනුව, `BorrowFlag` කිසි විටෙකත් පිටාර ගැලීමක් හෝ පිටාර ගැලීමක් සිදු නොවේ.
// කෙසේ වෙතත්, මෙය සහතිකයක් නොවේ, මන්ද ව්යාධිජනක වැඩසටහනක් නැවත නැවත නිර්මාණය කළ හැකි අතර පසුව mem::forget `Ref`s හෝ`RefMut`s.
// මේ අනුව, අනාරක්ෂිත බව වළක්වා ගැනීම සඳහා සියලු කේතයන් පිටාර ගැලීම සහ පිටාර ගැලීම පිළිබඳව පැහැදිලිව පරික්ෂා කළ යුතුය, නැතහොත් පිටාර ගැලීම හෝ පිටාර ගැලීම සිදුවුවහොත් අවම වශයෙන් නිවැරදිව හැසිරිය යුතුය (උදා: BorrowRef::new බලන්න).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// `value` අඩංගු නව `RefCell` සාදයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// `RefCell` පරිභෝජනය කරයි, ඔතා ඇති අගය නැවත ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // මෙම ශ්‍රිතය අගය අනුව `self` (`RefCell`) ගන්නා බැවින්, සම්පාදකයා එය දැනට ණයට ගෙන නොමැති බව සංඛ්‍යාත්මකව තහවුරු කරයි.
        //
        self.value.into_inner()
    }

    /// ඔතා ඇති අගය නව එකක් සමඟ ප්‍රතිස්ථාපනය කර, පැරණි අගය නැවත ලබා දෙයි.
    ///
    ///
    /// මෙම ශ්‍රිතය [`std::mem::replace`](../mem/fn.replace.html) ට අනුරූප වේ.
    ///
    /// # Panics
    ///
    /// වටිනාකම දැනට ණයට ගෙන තිබේ නම් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// ඔතා ඇති අගය `f` වෙතින් ගණනය කළ නව එකක් සමඟ ප්‍රතිස්ථාපනය කර පැරණි අගය නැවත ලබා දෙයි.
    ///
    ///
    /// # Panics
    ///
    /// වටිනාකම දැනට ණයට ගෙන තිබේ නම් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// `self` හි ඔතා ඇති අගය `other` හි ඔතා ඇති අගය සමඟ මාරු කරන්න.
    ///
    ///
    /// මෙම ශ්‍රිතය [`std::mem::swap`](../mem/fn.swap.html) ට අනුරූප වේ.
    ///
    /// # Panics
    ///
    /// `RefCell` හි වටිනාකම දැනට ණයට ගෙන තිබේ නම් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// ඔතා ඇති වටිනාකම නොවරදවාම ණයට ගනී.
    ///
    /// ආපසු ලබා දුන් `Ref` විෂය පථයෙන් පිටවන තුරු ණය ගැනීම පවතී.
    /// එකවර වෙනස් කළ නොහැකි ණය කිහිපයක් ලබා ගත හැකිය.
    ///
    /// # Panics
    ///
    /// Panics අගය දැනට විකෘති ලෙස ණයට ගෙන තිබේ නම්.
    /// භීතියට පත් නොවන ප්‍රභේදයක් සඳහා, [`try_borrow`](#method.try_borrow) භාවිතා කරන්න.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// panic සඳහා උදාහරණයක්:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// ඔතා ඇති අගය වෙනස් කළ නොහැකි ලෙස ණයට ගනී, වටිනාකම දැනට විකෘති ලෙස ණයට ගෙන තිබේ නම් දෝෂයක් නැවත ලබා දේ.
    ///
    ///
    /// ආපසු ලබා දුන් `Ref` විෂය පථයෙන් පිටවන තුරු ණය ගැනීම පවතී.
    /// එකවර වෙනස් කළ නොහැකි ණය කිහිපයක් ලබා ගත හැකිය.
    ///
    /// මෙය [`borrow`](#method.borrow) හි භීතික නොවන ප්‍රභේදයයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // ආරක්ෂාව: වෙනස් කළ නොහැකි ප්‍රවේශයක් පමණක් ඇති බව `BorrowRef` සහතික කරයි
            // ණයට ගත් අතර වටිනාකමට.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// ඔතා ඇති වටිනාකම විකෘති ලෙස ණයට ගනී.
    ///
    /// ආපසු ලබා දුන් `RefMut` හෝ එයින් ලබාගත් සියලුම `RefMut` වලින් ඉවත්ව යන තෙක් ණය ලබා ගනී.
    ///
    /// මෙම ණය ගැනීම සක්‍රියව තිබියදී වටිනාකම ණයට ගත නොහැක.
    ///
    /// # Panics
    ///
    /// වටිනාකම දැනට ණයට ගෙන තිබේ නම් Panics.
    /// භීතියට පත් නොවන ප්‍රභේදයක් සඳහා, [`try_borrow_mut`](#method.try_borrow_mut) භාවිතා කරන්න.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// panic සඳහා උදාහරණයක්:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// ඔතා ඇති අගය විකෘති ලෙස ණයට ගන්නා අතර, වටිනාකම දැනට ණයට ගෙන තිබේ නම් දෝෂයක් නැවත ලබා දේ.
    ///
    ///
    /// ආපසු ලබා දුන් `RefMut` හෝ එයින් ලබාගත් සියලුම `RefMut` වලින් ඉවත්ව යන තෙක් ණය ලබා ගනී.
    /// මෙම ණය ගැනීම සක්‍රියව තිබියදී වටිනාකම ණයට ගත නොහැක.
    ///
    /// මෙය [`borrow_mut`](#method.borrow_mut) හි භීතික නොවන ප්‍රභේදයයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // ආරක්ෂාව: `BorrowRef` අද්විතීය ප්‍රවේශය සහතික කරයි.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// මෙම කොටුවේ යටින් පවතින දත්ත වෙත අමු දර්ශකයක් ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// යටින් පවතින දත්ත වලට විකෘති යොමු කිරීමක් ලබා දෙයි.
    ///
    /// මෙම ඇමතුම `RefCell` විකෘති ලෙස ණයට ගනී (සම්පාදනය කරන වේලාවේදී) එබැවින් ගතික චෙක්පත් අවශ්‍ය නොවේ.
    ///
    /// කෙසේ වෙතත් ප්‍රවේශම් වන්න: මෙම ක්‍රමය `self` විකෘති වනු ඇතැයි අපේක්ෂා කරයි, සාමාන්‍යයෙන් `RefCell` භාවිතා කරන විට එය එසේ නොවේ.
    ///
    /// `self` විකෘති නොවන්නේ නම් ඒ වෙනුවට [`borrow_mut`] ක්‍රමය දෙස බලන්න.
    ///
    /// එසේම, මෙම ක්‍රමය විශේෂ තත්වයන් සඳහා පමණක් වන අතර සාමාන්‍යයෙන් ඔබට අවශ්‍ය දේ නොවන බව කරුණාවෙන් සලකන්න.
    /// සැකයක් ඇත්නම්, ඒ වෙනුවට [`borrow_mut`] භාවිතා කරන්න.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `RefCell` හි ණය තත්වයට කාන්දු වූ ආරක්ෂකයින්ගේ බලපෑම අහෝසි කරන්න.
    ///
    /// මෙම ඇමතුම [`get_mut`] ට සමාන නමුත් වඩා විශේෂිතයි.
    /// ණය කිසිවක් නොපවතින බව සහතික කිරීම සඳහා එය `RefCell` අන්‍යොන්‍ය වශයෙන් ණයට ගන්නා අතර පසුව හවුල් වූ ණය ආපසු ගෙවීම නැවත සොයා ගනී.
    /// සමහර `Ref` හෝ `RefMut` ණය ගැනීම් කාන්දු වී ඇත්නම් මෙය අදාළ වේ.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// ඔතා ඇති අගය වෙනස් කළ නොහැකි ලෙස ණයට ගනී, වටිනාකම දැනට විකෘති ලෙස ණයට ගෙන තිබේ නම් දෝෂයක් නැවත ලබා දේ.
    ///
    /// # Safety
    ///
    /// `RefCell::borrow` මෙන් නොව, මෙම ක්‍රමය අනාරක්ෂිත වන්නේ එය `Ref` ආපසු නොදෙන නිසා ණය ධජය ස්පර්ශ නොකෙරේ.
    /// මෙම ක්‍රමය මඟින් නැවත යොමු කිරීම ජීවමානව තිබියදී `RefCell` විකෘති ලෙස ණයට ගැනීම නිර්වචනය නොකළ හැසිරීමකි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // ආරක්ෂාව: කිසිවෙකු සක්‍රීයව ලියන්නේ නැති බව අපි පරීක්ෂා කරමු, නමුත් එය එසේ ය
            // ආපසු යොමු කිරීම තවදුරටත් භාවිතයේ නොමැති තෙක් කිසිවෙකු ලියන්නේ නැති බව සහතික කිරීම ඇමතුම්කරුගේ වගකීමයි.
            // එසේම, `self.value.get()` යනු `self` සතු වටිනාකමට යොමු වන අතර එමඟින් `self` හි ආයු කාලය සඳහා වලංගු බවට සහතික වේ.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// ඔතා ඇති අගය ගනී, `Default::default()` එහි ස්ථානයේ තබයි.
    ///
    /// # Panics
    ///
    /// වටිනාකම දැනට ණයට ගෙන තිබේ නම් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics අගය දැනට විකෘති ලෙස ණයට ගෙන තිබේ නම්.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// T සඳහා `Default` අගය සමඟ `RefCell<T>` නිර්මාණය කරයි.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// `RefCell` හි වටිනාකම දැනට ණයට ගෙන තිබේ නම් Panics.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// `RefCell` හි වටිනාකම දැනට ණයට ගෙන තිබේ නම් Panics.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// `RefCell` හි වටිනාකම දැනට ණයට ගෙන තිබේ නම් Panics.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// `RefCell` හි වටිනාකම දැනට ණයට ගෙන තිබේ නම් Panics.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// `RefCell` හි වටිනාකම දැනට ණයට ගෙන තිබේ නම් Panics.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// `RefCell` හි වටිනාකම දැනට ණයට ගෙන තිබේ නම් Panics.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// `RefCell` හි වටිනාකම දැනට ණයට ගෙන තිබේ නම් Panics.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // ණය ලබා ගැනීම වැඩි කිරීමෙන් මෙම අවස්ථා වලදී කියවිය නොහැකි අගයක් (<=0) ඇති විය හැකිය:
            // 1. එය <0, එනම් ලිවීමේ ණය තිබේ, එබැවින් Rust හි යොමු අන්වර්ථකරණ නීති නිසා අපට කියවීමට ණයක් ලබා ගැනීමට ඉඩ දිය නොහැක.
            // 2.
            // එය isize::MAX (කියවීමේ ණයවල උපරිම ප්‍රමාණය) වන අතර එය isize::MIN (උපරිම ලිවීමේ ණය ප්‍රමාණය) වෙතට පිරී ගියේය. එබැවින් අපට අමතර කියවීමේ ණයක් ලබා ගැනීමට ඉඩ දිය නොහැක. මන්දයත් බොහෝ කියවීම් ණය නියෝජනය කළ නොහැකි නිසා (මෙය සිදුවිය හැක්කේ ඔබ mem::forget කුඩා නියත `Ref`s ප්‍රමාණයකට වඩා වැඩිය, එය හොඳ පුහුණුවක් නොවේ)
            //
            //
            //
            //
            None
        } else {
            // ණය වැඩි කිරීමෙන් මෙම අවස්ථා වලදී කියවීමේ අගය (> 0) ඇති විය හැකිය:
            // 1. එය=0 විය, එනම් එය ණයට නොගත් අතර, අපි පළමු කියවීමේ ණය ලබා ගනිමු
            // 2. එය> 0 සහ <isize::MAX, එනම්
            // කියවීමේ ණය ලබාගෙන ඇති අතර තවත් එක් කියවීමක් ලබා ගැනීම නිරූපණය කිරීමට තරම් විශාල වේ
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // මෙම Ref පවතින බැවින්, ණය ධජය කියවීමේ ණයක් බව අපි දනිමු.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // ණය කවුන්ටරය ලිඛිත ණයක් වෙත පිරී ඉතිරී යාම වළක්වන්න.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// `RefCell` පෙට්ටියක ඇති අගයක් සඳහා ණයට ගත් සඳහනක් ඔතා.
/// `RefCell<T>` වෙතින් වෙනස් කළ නොහැකි ණයට ගත් වටිනාකමක් සඳහා එතීමේ වර්ගයක්.
///
/// වැඩි විස්තර සඳහා [module-level documentation](self) බලන්න.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// `Ref` පිටපත් කරයි.
    ///
    /// `RefCell` දැනටමත් වෙනස් කළ නොහැකි ලෙස ණයට ගෙන ඇති බැවින් මෙය අසාර්ථක විය නොහැක.
    ///
    /// මෙය `Ref::clone(...)` ලෙස භාවිතා කළ යුතු සම්බන්ධිත ශ්‍රිතයකි.
    /// `Clone` ක්‍රියාවට නැංවීම හෝ ක්‍රමයක් මඟින් `RefCell` හි අන්තර්ගතය ක්ලෝන කිරීම සඳහා `r.borrow().clone()` පුළුල් ලෙස භාවිතා කිරීමට බාධා ඇති වේ.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// ණයට ගත් දත්තවල අංගයක් සඳහා නව `Ref` සාදයි.
    ///
    /// `RefCell` දැනටමත් වෙනස් කළ නොහැකි ලෙස ණයට ගෙන ඇති බැවින් මෙය අසාර්ථක විය නොහැක.
    ///
    /// මෙය `Ref::map(...)` ලෙස භාවිතා කළ යුතු සම්බන්ධිත ශ්‍රිතයකි.
    /// `Deref` හරහා භාවිතා කරන `RefCell` හි අන්තර්ගතය මත එකම නමේ ක්‍රමවේදයන්ට ක්‍රමයක් බාධා කරයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// ණයට ගත් දත්තවල විකල්ප අංගයක් සඳහා නව `Ref` සාදයි.
    /// වසා දැමීම `None` ආපසු ලබා දෙන්නේ නම් මුල් ආරක්ෂකයා `Err(..)` ලෙස ආපසු ලබා දෙනු ලැබේ.
    ///
    /// `RefCell` දැනටමත් වෙනස් කළ නොහැකි ලෙස ණයට ගෙන ඇති බැවින් මෙය අසාර්ථක විය නොහැක.
    ///
    /// මෙය `Ref::filter_map(...)` ලෙස භාවිතා කළ යුතු සම්බන්ධිත ශ්‍රිතයකි.
    /// `Deref` හරහා භාවිතා කරන `RefCell` හි අන්තර්ගතය මත එකම නමේ ක්‍රමවේදයන්ට ක්‍රමයක් බාධා කරයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// ණයට ගත් දත්තවල විවිධ සංරචක සඳහා `Ref` බහු `Ref` වලට බෙදයි.
    ///
    /// `RefCell` දැනටමත් වෙනස් කළ නොහැකි ලෙස ණයට ගෙන ඇති බැවින් මෙය අසාර්ථක විය නොහැක.
    ///
    /// මෙය `Ref::map_split(...)` ලෙස භාවිතා කළ යුතු සම්බන්ධිත ශ්‍රිතයකි.
    /// `Deref` හරහා භාවිතා කරන `RefCell` හි අන්තර්ගතය මත එකම නමේ ක්‍රමවේදයන්ට ක්‍රමයක් බාධා කරයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// යටින් පවතින දත්ත වෙත යොමු කිරීමක් බවට පරිවර්තනය කරන්න.
    ///
    /// යටින් පවතින `RefCell` කිසි විටෙකත් විකෘති ලෙස ණයට ගත නොහැකි අතර සෑම විටම දැනටමත් වෙනස් කළ නොහැකි ලෙස ණයට ගත් බව පෙනේ.
    ///
    /// නියත යොමු සංඛ්‍යාවකට වඩා කාන්දු වීම හොඳ අදහසක් නොවේ.
    /// සමස්තයක් වශයෙන් කුඩා කාන්දුවීම් සිදුවී ඇත්නම් `RefCell` නැවත වෙනස් කළ නොහැකි ලෙස ණයට ගත හැකිය.
    ///
    /// මෙය `Ref::leak(...)` ලෙස භාවිතා කළ යුතු සම්බන්ධිත ශ්‍රිතයකි.
    /// `Deref` හරහා භාවිතා කරන `RefCell` හි අන්තර්ගතය මත එකම නමේ ක්‍රමවේදයන්ට ක්‍රමයක් බාධා කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // මෙම Ref අමතක කිරීමෙන්, RefCell හි ණය ලබා ගැනීමේ කවුන්ටරය `'b` ජීවිත කාලය තුළ UNUSED වෙත ආපසු යා නොහැකි බව අපි සහතික කරමු.
        // විමර්ශන ලුහුබැඳීමේ තත්වය නැවත සැකසීමට ණයට ගත් RefCell වෙත අද්විතීය සඳහනක් අවශ්‍ය වේ.
        // මුල් කොටුවෙන් තවත් විකෘති යොමු කිරීම් නිර්මාණය කළ නොහැක.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// ණයට ගත් දත්තවල සං component ටකයක් සඳහා නව `RefMut` සාදයි, උදා: enum ප්‍රභේදයකි.
    ///
    /// `RefCell` දැනටමත් විකෘති ලෙස ණයට ගෙන ඇති බැවින් මෙය අසාර්ථක විය නොහැක.
    ///
    /// මෙය `RefMut::map(...)` ලෙස භාවිතා කළ යුතු සම්බන්ධිත ශ්‍රිතයකි.
    /// `Deref` හරහා භාවිතා කරන `RefCell` හි අන්තර්ගතය මත එකම නමේ ක්‍රමවේදයන්ට ක්‍රමයක් බාධා කරයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): ණය-චෙක්පත් සවි කරන්න
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// ණයට ගත් දත්තවල විකල්ප අංගයක් සඳහා නව `RefMut` සාදයි.
    /// වසා දැමීම `None` ආපසු ලබා දෙන්නේ නම් මුල් ආරක්ෂකයා `Err(..)` ලෙස ආපසු ලබා දෙනු ලැබේ.
    ///
    /// `RefCell` දැනටමත් විකෘති ලෙස ණයට ගෙන ඇති බැවින් මෙය අසාර්ථක විය නොහැක.
    ///
    /// මෙය `RefMut::filter_map(...)` ලෙස භාවිතා කළ යුතු සම්බන්ධිත ශ්‍රිතයකි.
    /// `Deref` හරහා භාවිතා කරන `RefCell` හි අන්තර්ගතය මත එකම නමේ ක්‍රමවේදයන්ට ක්‍රමයක් බාධා කරයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): ණය-චෙක්පත් සවි කරන්න
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // ආරක්ෂාව: ශ්‍රිතය කාලසීමාව සඳහා සුවිශේෂී සඳහනක් දරයි
        // `orig` හරහා එහි ඇමතුම, සහ දර්ශකය ක්‍රියා විරහිත ඇමතුම තුළ පමණක් යොමු නොකෙරේ.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // ආරක්ෂාව: ඉහත ආකාරයටම.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// ණයට ගත් දත්තවල විවිධ සංරචක සඳහා `RefMut` බහුවිධ `RefMut` වලට බෙදයි.
    ///
    /// ආපසු ලබා දුන් `RefMut 'දෙකම විෂය පථයෙන් බැහැර වන තුරු යටින් පවතින `RefCell` අන්‍යෝන්‍ය වශයෙන් ණයට ගනු ලැබේ.
    ///
    /// `RefCell` දැනටමත් විකෘති ලෙස ණයට ගෙන ඇති බැවින් මෙය අසාර්ථක විය නොහැක.
    ///
    /// මෙය `RefMut::map_split(...)` ලෙස භාවිතා කළ යුතු සම්බන්ධිත ශ්‍රිතයකි.
    /// `Deref` හරහා භාවිතා කරන `RefCell` හි අන්තර්ගතය මත එකම නමේ ක්‍රමවේදයන්ට ක්‍රමයක් බාධා කරයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// යටින් පවතින දත්ත වලට විකෘති යොමු කිරීමක් බවට පරිවර්තනය කරන්න.
    ///
    /// යටින් පවතින `RefCell` නැවත ණයට ගත නොහැකි අතර සෑම විටම දැනටමත් අන්‍යෝන්‍ය වශයෙන් ණයට ගත් ඒවා ලෙස පෙනෙනු ඇත, ආපසු යොමු කිරීම අභ්‍යන්තරයට පමණක් ඇති කරයි.
    ///
    ///
    /// මෙය `RefMut::leak(...)` ලෙස භාවිතා කළ යුතු සම්බන්ධිත ශ්‍රිතයකි.
    /// `Deref` හරහා භාවිතා කරන `RefCell` හි අන්තර්ගතය මත එකම නමේ ක්‍රමවේදයන්ට ක්‍රමයක් බාධා කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // මෙම BorrowRefMut අමතක කිරීමෙන්, RefCell හි ණය කවුන්ටරයට `'b` ජීවිත කාලය තුළ UNUSED වෙත ආපසු යා නොහැකි බව අපි සහතික කරමු.
        // විමර්ශන ලුහුබැඳීමේ තත්වය නැවත සැකසීමට ණයට ගත් RefCell වෙත අද්විතීය සඳහනක් අවශ්‍ය වේ.
        // එම ජීවිත කාලය තුළ මුල් කොටුවෙන් වැඩිදුර සඳහනක් නිර්මාණය කළ නොහැකි අතර, දැනට පවතින ණය මුදල ඉතිරි ජීවිත කාලය සඳහා එකම යොමු කිරීම වේ.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: BorrowRefMut::clone මෙන් නොව, ආරම්භය නිර්මාණය කිරීම සඳහා නව යැයි කියනු ලැබේ
        // විකෘති යොමු කිරීම, එබැවින් දැනට පවතින යොමු කිරීම් නොතිබිය යුතුය.
        // මේ අනුව, ක්ලෝන විකෘති වූ ප්‍රතිමූර්තිය වැඩි කරන අතර, මෙහිදී අපි පැහැදිලිවම අවසර දෙන්නේ UNUSED සිට UNUSED දක්වා යාමට පමණි, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // `BorrowRefMut` ක්ලෝන කරයි.
    //
    // මෙය වලංගු වන්නේ එක් එක් `BorrowRefMut` මුල් වස්තුවෙහි පැහැදිලි, නොබැඳි පරාසයක විකෘති යොමු කිරීමක් නිරීක්ෂණය කිරීමට භාවිතා කරන්නේ නම් පමණි.
    //
    // මෙය ක්ලෝන ආවේගයක නොමැති බැවින් කේතය මෙය ව්‍යංගයෙන් නොකියයි.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // ණය කවුන්ටරය යටින් ගලා යාම වළක්වන්න.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// `RefCell<T>` වෙතින් විකෘති ලෙස ණයට ගත් වටිනාකමක් සඳහා එතීමේ වර්ගයක්.
///
/// වැඩි විස්තර සඳහා [module-level documentation](self) බලන්න.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Rust හි අභ්‍යන්තර විකෘතිතාව සඳහා මූලික ප්‍රාථමිකය.
///
/// ඔබට `&T` යොමු කිරීමක් තිබේ නම්, සාමාන්‍යයෙන් Rust හි සම්පාදකයා විසින් `&T` වෙනස් කළ නොහැකි දත්ත වෙත යොමු කරන දැනුම මත පදනම්ව ප්‍රශස්තිකරණය සිදු කරයි.එම දත්ත විකෘති කිරීම, උදාහරණයක් ලෙස අන්වර්ථයක් හරහා හෝ `&T` `&mut T` බවට සම්ප්‍රේෂණය කිරීමෙන් නිර්වචනය නොකළ හැසිරීමක් ලෙස සැලකේ.
/// `UnsafeCell<T>` `&T` සඳහා වෙනස් කළ නොහැකි සහතිකයෙන් ඉවත් වීම: හවුල් යොමුව `&UnsafeCell<T>` විකෘති වන දත්ත වෙත යොමු විය හැකිය.මෙය "interior mutability" ලෙස හැඳින්වේ.
///
/// `Cell<T>` සහ `RefCell<T>` වැනි අභ්‍යන්තර විකෘතිතාවයට ඉඩ දෙන අනෙකුත් සියලුම වර්ගයන් ඔවුන්ගේ දත්ත එතීමට අභ්‍යන්තරව `UnsafeCell` භාවිතා කරයි.
///
/// `UnsafeCell` මගින් බලපානුයේ හවුල් යොමු කිරීම් සඳහා වෙනස් කළ නොහැකි සහතිකය පමණි.විකෘති යොමු කිරීම් සඳහා අද්විතීය සහතිකය බලපාන්නේ නැත.අන්වර්ථ `&mut` ලබා ගැනීමට * නෛතික ක්‍රමයක් නොමැත, `UnsafeCell<T>` සමඟ පවා නැත.
///
/// `UnsafeCell` API ම තාක්‍ෂණිකව ඉතා සරල ය: [`.get()`] එහි අන්තර්ගතයට `*mut T` අමු දර්ශකයක් ලබා දෙයි.එම අමු දර්ශකය නිවැරදිව භාවිතා කිරීම වියුක්ත නිර්මාණකරු ලෙස _you_ දක්වා වේ.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// නිශ්චිත Rust අන්වර්ථ නීති රීති තරමක් ප්‍රවාහයේ පවතී, නමුත් ප්‍රධාන කරුණු විවාදාත්මක නොවේ:
///
/// - ඔබ ආරක්ෂිත කේතයකින් ප්‍රවේශ විය හැකි ජීවිතාරක්ෂක `'a` (`&T` හෝ `&mut T` යොමුව) සමඟ ආරක්ෂිත සඳහනක් නිර්මාණය කරන්නේ නම් (නිදසුනක් ලෙස, ඔබ එය ආපසු ලබා දුන් නිසා), එවිට ඔබ ඉතිරි දත්ත සඳහා එම සඳහනට පටහැනි කිසිදු ආකාරයකින් දත්ත වෙත ප්‍රවේශ නොවිය යුතුය. `'a` හි.
/// උදාහරණයක් ලෙස, මෙයින් අදහස් වන්නේ ඔබ `UnsafeCell<T>` වෙතින් `*mut T` ගෙන එය `&T` වෙත දමන්නේ නම්, එම යොමු ආයු කාලය ඉකුත්වන තෙක් `T` හි දත්ත වෙනස් කළ නොහැකි ලෙස (`T` තුළ ඇති ඕනෑම `UnsafeCell` දත්ත මොඩියුලෝ කරන්න).
/// ඒ හා සමානව, ඔබ ආරක්ෂිත කේතයකට මුදා හරින `&mut T` යොමු කිරීමක් නිර්මාණය කරන්නේ නම්, එම යොමු කිරීම කල් ඉකුත්වන තෙක් ඔබ `UnsafeCell` තුළ ඇති දත්ත වලට ප්‍රවේශ නොවිය යුතුය.
///
/// - සෑම විටම, ඔබ දත්ත තරඟ වලින් වැළකී සිටිය යුතුය.එකම `UnsafeCell` වෙත බහු නූල් වලට ප්‍රවේශය තිබේ නම්, ඕනෑම ලිවීමකට නිසි සිදුවීමක් තිබිය යුතුය-අනෙක් සියලුම ප්‍රවේශයන්ට සාපේක්ෂව (හෝ පරමාණු භාවිතා කරන්න).
///
/// නිසි සැලසුමට සහාය වීම සඳහා, තනි නූල් කේතය සඳහා පහත දැක්වෙන අවස්ථා පැහැදිලිවම නීත්‍යානුකූලව ප්‍රකාශයට පත් කෙරේ:
///
/// 1. `&T` යොමුව ආරක්ෂිත කේතයකට මුදා හැරිය හැකි අතර එහිදී එය වෙනත් `&T` යොමු කිරීම් සමඟ සමපාත විය හැකිය, නමුත් `&mut T` සමඟ නොවේ
///
/// 2. වෙනත් `&mut T` හෝ `&T` සමඟ සමපාත නොවන්නේ නම් `&mut T` යොමුව ආරක්ෂිත කේතයට මුදා හැරිය හැක.`&mut T` සෑම විටම අද්විතීය විය යුතුය.
///
/// `&UnsafeCell<T>` හි අන්තර්ගතය විකෘති කරන අතරම (සෛලයට වෙනත් `&UnsafeCell<T>` යොමු කිරීම් තිබියදීත්) හරි (ඔබ ඉහත ආක්‍රමණ වෙනත් ආකාරයකින් බලාත්මක කරන්නේ නම්), බහු `&mut UnsafeCell<T>` අන්වර්ථයන් තිබීම තවමත් නිර්වචනය නොකළ හැසිරීමකි.
/// එනම්, `UnsafeCell` යනු _shared_ accesses (_i.e._ සමඟ විශේෂ අන්තර්ක්‍රියාකාරිත්වයක් ඇති කිරීම සඳහා නිර්මාණය කරන ලද එතුමකි, `&UnsafeCell<_>` යොමු කිරීමක් හරහා);`&mut UnsafeCell<_>` හරහා _exclusive_ accesses (_e.g._ සමඟ ගනුදෙනු කිරීමේදී කිසිදු ඉන්ද්‍රජාලයක් නොමැත): එම `&mut` ණයට ගන්නා කාල සීමාව සඳහා කොටුව හෝ ඔතා ඇති අගය වෙනස් කළ නොහැක.
///
/// මෙය [`.get_mut()`] ප්‍රවේශකය මඟින් ප්‍රදර්ශනය කර ඇති අතර එය _safe_ getter වන අතර එය `&mut T` ලබා දෙයි.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// සෛලය අන්වර්ථ කිරීම සඳහා බහුවිධ යොමු කිරීම් තිබියදීත්, `UnsafeCell<_>` හි අන්තර්ගතය ශබ්ද විකෘති කරන්නේ කෙසේද යන්න පෙන්වන උදාහරණයක් මෙන්න:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // එකම `x` වෙත බහු/සමගාමී/හවුල් යොමු කිරීම් ලබා ගන්න.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // ආරක්ෂාව: මෙම විෂය පථය තුළ `x` හි අන්තර්ගතය පිළිබඳ වෙනත් සඳහනක් නොමැත,
///     // එබැවින් අපගේ effectively ලදායී ලෙස අද්විතීය වේ.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- ණයට ගන්න-+
///     *p1_exclusive += 27; // |
/// } // <---------- මෙම කරුණෙන් ඔබ්බට යා නොහැක -------------------+
///
/// unsafe {
///     // ආරක්ෂාව: මෙම විෂය පථය තුළ කිසිවෙකු විසින් x හි අන්තර්ගතයට පමණක් ප්‍රවේශ වීමට අපේක්ෂා නොකරයි,
///     // එබැවින් අපට සමගාමීව බහු හවුල් ප්‍රවේශයන් ලබා ගත හැකිය.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// පහත දැක්වෙන උදාහරණයෙන් දැක්වෙන්නේ `UnsafeCell<T>` වෙත පමණක් ප්‍රවේශ වීමෙන් එහි `T` වෙත පමණක් ප්‍රවේශ විය හැකි බවයි:
///
/// ```rust
/// #![forbid(unsafe_code)] // සුවිශේෂී ප්‍රවේශයන් සමඟ,
///                         // `UnsafeCell` විනිවිද පෙනෙන නො-ඔප් එතීමකි, එබැවින් මෙහි `unsafe` අවශ්‍ය නොවේ.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // `x` සඳහා සම්පාදිත-කාල පරික්‍ෂා කළ අද්විතීය යොමු කිරීමක් ලබා ගන්න.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // සුවිශේෂී සඳහනක් සමඟ, අපට නොමිලේ අන්තර්ගතය විකෘති කළ හැකිය.
/// *p_unique.get_mut() = 0;
/// // හෝ, සමානව:
/// x = UnsafeCell::new(0);
///
/// // අපට වටිනාකම හිමි වූ විට, අපට නොමිලේ අන්තර්ගතය උකහා ගත හැකිය.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// `UnsafeCell` හි නව අවස්ථාවක් සාදයි, එමඟින් නිශ්චිත අගය ආවරණය කරයි.
    ///
    ///
    /// ක්රම හරහා අභ්යන්තර වටිනාකමට ප්රවේශ වීම `unsafe` වේ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// වටිනාකම ලිහා දමයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// ඔතා ඇති වටිනාකමට විකෘති දර්ශකයක් ලබා ගනී.
    ///
    /// මෙය ඕනෑම ආකාරයක දර්ශකයකට දැමිය හැකිය.
    /// `&mut T` වෙත වාත්තු කිරීමේදී ප්‍රවේශය අද්විතීය බව (ක්‍රියාකාරී යොමු කිරීම්, විකෘති හෝ නොවේ) සහතික කර, `&T` වෙත වාත්තු කිරීමේදී විකෘති හෝ විකෘති අන්වර්ථයන් සිදු නොවන බවට වග බලා ගන්න.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // #[repr(transparent)] නිසා අපට දර්ශකය `UnsafeCell<T>` සිට `T` දක්වා දැමිය හැකිය.
        // මෙය libstd හි විශේෂ තත්වය ගසාකයි, මෙය සම්පාදකයාගේ future අනුවාද වල ක්‍රියාත්මක වන බවට පරිශීලක කේතයක් සඳහා සහතිකයක් නොමැත!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// යටින් පවතින දත්ත වලට විකෘති යොමු කිරීමක් ලබා දෙයි.
    ///
    /// මෙම ඇමතුම `UnsafeCell` විකෘති ලෙස ණයට ගනී (සම්පාදනය කරන වේලාවේදී) එය අපට එකම සඳහනක් ඇති බවට සහතික කරයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// ඔතා ඇති වටිනාකමට විකෘති දර්ශකයක් ලබා ගනී.
    /// [`get`] හි වෙනස නම්, මෙම ශ්‍රිතය අමු දර්ශකයක් පිළිගන්නා අතර එය තාවකාලික යොමු කිරීම් වලක්වා ගැනීම සඳහා ප්‍රයෝජනවත් වේ.
    ///
    /// ප්‍රති result ලය ඕනෑම ආකාරයක දර්ශකයකට දැමිය හැකිය.
    /// `&mut T` වෙත වාත්තු කිරීමේදී ප්‍රවේශය අද්විතීය බව (ක්‍රියාකාරී යොමු කිරීම්, විකෘති හෝ නොවේ) සහතික කර, `&T` වෙත වාත්තු කිරීමේදී විකෘති හෝ විකෘති අන්වර්ථයන් සිදු නොවන බවට වග බලා ගන්න.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// `UnsafeCell` ක්‍රමානුකූලව ආරම්භ කිරීම සඳහා `raw_get` අවශ්‍ය වේ, `get` ඇමතීම මඟින් ආරම්භ නොකළ දත්ත වෙත යොමු කිරීමක් අවශ්‍ය වේ:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // #[repr(transparent)] නිසා අපට දර්ශකය `UnsafeCell<T>` සිට `T` දක්වා දැමිය හැකිය.
        // මෙය libstd හි විශේෂ තත්වය ගසාකයි, මෙය සම්පාදකයාගේ future අනුවාද වල ක්‍රියාත්මක වන බවට පරිශීලක කේතයක් සඳහා සහතිකයක් නොමැත!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// T සඳහා `Default` අගය සමඟ `UnsafeCell` සාදයි.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}