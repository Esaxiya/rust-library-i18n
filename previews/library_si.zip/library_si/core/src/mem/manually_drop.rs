use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// සම්පාදකයා ස්වයංක්‍රීයව `ටී` හි ඩිස්ට්‍රැක්ටරය ඇමතීමෙන් වලක්වන රැප් එකක්.
/// මෙම එතුම 0-පිරිවැය.
///
/// `ManuallyDrop<T>` `T` හා සමාන පිරිසැලසුම් ප්‍රශස්තිකරණයකට යටත් වේ.
/// එහි ප්‍රති consequ ලයක් ලෙස, සම්පාදකයා එහි අන්තර්ගතය පිළිබඳව කරන උපකල්පනවලට * කිසිදු බලපෑමක් නැත.
/// උදාහරණයක් ලෙස, [`mem::zeroed`] සමඟ `ManuallyDrop<&mut T>` ආරම්භ කිරීම නිර්වචනය නොකළ හැසිරීමකි.
/// ඔබට ආරම්භ නොකළ දත්ත හැසිරවීමට අවශ්‍ය නම්, ඒ වෙනුවට [`MaybeUninit<T>`] භාවිතා කරන්න.
///
/// `ManuallyDrop<T>` තුළ ඇති වටිනාකමට ප්‍රවේශ වීම ආරක්ෂිත බව සලකන්න.
/// මෙයින් අදහස් කරන්නේ `ManuallyDrop<T>` අන්තර්ගතය අතහැර දමා ඇති බව පොදු ආරක්ෂිත API හරහා නිරාවරණය නොකළ යුතු බවයි.
/// ඊට අනුරූපව, `ManuallyDrop::drop` අනාරක්ෂිත ය.
///
/// # `ManuallyDrop` සහ ඇණවුම අතහරින්න.
///
/// Rust හි මනාව නිර්වචනය කරන ලද [drop order] අගයන් ඇත.
/// ක්ෂේත්‍ර හෝ ප්‍රදේශ නිශ්චිත අනුපිළිවෙලකට දමා ඇති බවට වග බලා ගැනීම සඳහා, ප්‍රකාශයන් නැවත සකසන්න, එනම් ව්‍යංග බිංදු අනුපිළිවෙල නිවැරදි එකකි.
///
/// පතන අනුපිළිවෙල පාලනය කිරීම සඳහා `ManuallyDrop` භාවිතා කළ හැකි නමුත් මේ සඳහා අනාරක්ෂිත කේතයක් අවශ්‍ය වන අතර නොදැනුවත්වම නිවැරදිව කිරීමට අපහසුය.
///
///
/// නිදසුනක් ලෙස, නිශ්චිත ක්ෂේත්‍රයක් අනෙක් ඒවාට පසුව අතහැර දමා ඇති බවට ඔබට සහතික වීමට අවශ්‍ය නම්, එය ව්‍යුහයක අවසාන ක්ෂේත්‍රය බවට පත් කරන්න:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` `children` පසු අතහැර දමනු ඇත.
///     // Rust ප්‍රකාශන අනුපිළිවෙලට ක්ෂේත්‍ර අතහැර දැමූ බවට සහතික වේ.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// අතින් අතහැර දැමිය යුතු අගයක් ඔතා.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // ඔබට තවමත් වටිනාකම මත ආරක්ෂිතව ක්‍රියා කළ හැකිය
    /// assert_eq!(*x, "Hello");
    /// // නමුත් `Drop` මෙහි ධාවනය නොවේ
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// `ManuallyDrop` බහාලුමෙන් වටිනාකම උපුටා ගනී.
    ///
    /// මෙය නැවත අගය අතහැර දැමීමට ඉඩ දෙයි.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // මෙය `Box` පහත වැටේ.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// `ManuallyDrop<T>` බහාලුමේ වටිනාකම පිටතට ගනී.
    ///
    /// මෙම ක්‍රමය මූලික වශයෙන් අදහස් කරන්නේ පහත වැටෙන අගයන් පිටතට ගෙනයාම සඳහා ය.
    /// අගය අතින් අතහැර දැමීමට [`ManuallyDrop::drop`] භාවිතා කරනවා වෙනුවට, ඔබට මෙම ක්‍රමය භාවිතා කර අගය ලබාගෙන එය කෙසේ වෙතත් භාවිතා කළ හැකිය.
    ///
    /// හැකි සෑම විටම, ඒ වෙනුවට [`into_inner`][`ManuallyDrop::into_inner`] භාවිතා කිරීම වඩාත් සුදුසුය, එමඟින් `ManuallyDrop<T>` හි අන්තර්ගතය අනුපිටපත් කිරීම වළක්වයි.
    ///
    ///
    /// # Safety
    ///
    /// මෙම ශ්‍රිතය තවදුරටත් භාවිතා කිරීම වලක්වා නොගෙන අඩංගු අගය අර්ථ නිරූපණය කරයි, මෙම බහාලුමේ තත්වය නොවෙනස්ව පවතී.
    /// මෙම `ManuallyDrop` නැවත භාවිතා නොකිරීමට වග බලා ගැනීම ඔබේ වගකීමකි.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // ආරක්ෂාව: අප කියවන්නේ යොමු කිරීමකින් වන අතර එය සහතික වේ
        // කියවීම සඳහා වලංගු වේ.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// අඩංගු අගය අතින් පහත වැටේ.මෙය හරියටම අඩංගු වටිනාකමට දර්ශකයක් සහිත [`ptr::drop_in_place`] ඇමතීමට සමාන වේ.
    /// එනිසා, අඩංගු අගය ඇසුරුම් කරන ලද ව්‍යුහයක් නොවේ නම්, අගය චලනය නොකර ඩිස්ට්‍රැක්ටරය තැනින් තැනට කැඳවනු ලබන අතර එමඟින් [pinned] දත්ත ආරක්ෂිතව අතහැර දැමීමට භාවිතා කළ හැකිය.
    ///
    /// ඔබට වටිනාකමේ හිමිකාරිත්වයක් තිබේ නම්, ඒ වෙනුවට ඔබට [`ManuallyDrop::into_inner`] භාවිතා කළ හැකිය.
    ///
    /// # Safety
    ///
    /// මෙම ශ්‍රිතය අඩංගු අගයේ විනාශ කරන්නා ක්‍රියාත්මක කරයි.
    /// ඩිස්ට්‍රැක්ටර් විසින්ම කරන ලද වෙනස්කම් හැරුණු විට, මතකය නොවෙනස්ව පවතින අතර, සම්පාදකයා සැලකිලිමත් වන තාක් දුරට `T` වර්ගයට වලංගු වන බිට්-රටාවක් පවතී.
    ///
    ///
    /// කෙසේ වෙතත්, මෙම "zombie" අගය ආරක්ෂිත කේතයට නිරාවරණය නොවිය යුතු අතර, මෙම ශ්‍රිතය එක් වරකට වඩා කැඳවිය යුතු නොවේ.
    /// වටිනාකමක් අතහැර දැමූ පසු එය භාවිතා කිරීම හෝ අගය කිහිප වතාවක් පහත දැමීම, නිර්වචනය නොකළ හැසිරීමට හේතු විය හැක (`drop` කරන දේ අනුව).
    /// මෙය සාමාන්‍යයෙන් වර්ග පද්ධතිය මඟින් වලක්වනු ලැබේ, නමුත් `ManuallyDrop` භාවිතා කරන්නන් සම්පාදකයාගේ සහාය නොමැතිව එම සහතිකයන් පිළිගත යුතුය.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // සුරක්ෂිතභාවය: විකෘති යොමුවකින් පෙන්වා ඇති අගය අපි පහත දමමු
        // එය ලිවීම් සඳහා වලංගු බවට සහතික වේ.
        // `slot` නැවත අතහැර නොයන බවට වග බලා ගැනීම ඇමතුම්කරුගේ ය.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}