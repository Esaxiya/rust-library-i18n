use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// `T` හි ආරම්භක නොවන අවස්ථා තැනීම සඳහා වූ ආවරණ වර්ගයකි.
///
/// # ආරම්භක වෙනස් කිරීම
///
/// සම්පාදකයා, සාමාන්‍යයෙන් උපකල්පනය කරන්නේ විචල්‍යයේ වර්ගයෙහි අවශ්‍යතා අනුව විචල්‍යයක් නිසි ලෙස ආරම්භ කර ඇති බවයි.උදාහරණයක් ලෙස, යොමු වර්ගයක විචල්‍යයක් පෙළගස්වා NULL නොවන විය යුතුය.
/// මෙය අනාරක්ෂිත කේතයක් තුළ වුවද *සැමවිටම* තහවුරු කළ යුතු වෙනස් කිරීමකි.
/// ප්‍රති consequ ලයක් ලෙස, විමර්ශන වර්ගයක විචල්‍යයක් ශුන්‍ය-ආරම්භ කිරීම ක්ෂණික [undefined behavior][ub] වලට හේතු වේ, එම සඳහන කවදා හෝ මතකයට ප්‍රවේශ වීමට භාවිතා කරයිද යන්න නොසලකා:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // නිර්වචනය නොකළ හැසිරීම!⚠️
/// // `MaybeUninit<&i32>` සමඟ සමාන කේතය:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // නිර්වචනය නොකළ හැසිරීම!⚠️
/// ```
///
/// ධාවන කාල චෙක්පත් ඉවත් කිරීම සහ `enum` පිරිසැලසුම ප්‍රශස්තිකරණය කිරීම වැනි විවිධ ප්‍රශස්තිකරණයන් සඳහා මෙය සම්පාදකයා විසින් සූරාකනු ලැබේ.
///
/// ඒ හා සමානව, මුලුමනින්ම ආරම්භ නොකළ මතකයේ ඕනෑම අන්තර්ගතයක් තිබිය හැකි අතර, `bool` සෑම විටම `true` හෝ `false` විය යුතුය.එබැවින්, ආරම්භ නොකළ `bool` නිර්මාණය කිරීම නිර්වචනය නොකළ හැසිරීමකි:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // නිර්වචනය නොකළ හැසිරීම!⚠️
/// // `MaybeUninit<bool>` සමඟ සමාන කේතය:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // නිර්වචනය නොකළ හැසිරීම!⚠️
/// ```
///
/// තවද, ආරම්භ නොකළ මතකය විශේෂිත වන්නේ එයට ස්ථාවර අගයක් නොමැති නිසාය ("fixed" යන්නෙහි අර්ථය "it won't change without being written to").එකම ආරම්භක බයිටය කිහිප වතාවක් කියවීමෙන් විවිධ ප්‍රති .ල ලබා ගත හැකිය.
/// මෙම විචල්‍යයට පූර්ණ සංඛ්‍යා වර්ගයක් තිබුණත් විචල්‍යයක ආරම්භක දත්ත තිබීම නිර්වචනය නොකළ හැසිරීමක් බවට පත් කරයි, එසේ නොමැතිනම් ඕනෑම *ස්ථාවර* බිට් රටාවක් රඳවා ගත හැකිය:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // නිර්වචනය නොකළ හැසිරීම!⚠️
/// // `MaybeUninit<i32>` සමඟ සමාන කේතය:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // නිර්වචනය නොකළ හැසිරීම!⚠️
/// ```
/// (ආරම්භ නොකළ පූර්ණ සංඛ්‍යා පිළිබඳ නීති තවමත් අවසන් කර නොමැති බව සලකන්න, නමුත් ඒවා පවතින තුරු ඒවා වළක්වා ගැනීම සුදුසුය.)
///
/// ඊට ඉහළින්, බොහෝ වර්ගවල අතිරේක මට්ටමක් ඇති බව මතක තබා ගන්න.
/// නිදසුනක් ලෙස, `1` ආරම්භක [`Vec<T>`] ආරම්භයක් ලෙස සලකනු ලැබේ (වර්තමාන ක්‍රියාත්මක කිරීම යටතේ මෙය ස්ථිර සහතිකයක් නොවේ) මක්නිසාද යත්, සම්පාදකයා ඒ ගැන දන්නා එකම අවශ්‍යතාව වන්නේ දත්ත දර්ශකය අහෝසි විය යුතු බවයි.
/// එවැනි `Vec<T>` නිර්මාණය කිරීම *ක්ෂණික* නිර්වචනය නොකළ හැසිරීමට හේතු නොවේ, නමුත් බොහෝ ආරක්ෂිත මෙහෙයුම් සමඟ (එය අතහැර දැමීම ඇතුළුව) නිර්වචනය නොකළ හැසිරීමට හේතු වේ.
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` ආරම්භ නොකළ දත්ත සමඟ කටයුතු කිරීමට අනාරක්ෂිත කේත සක්‍රීය කිරීමට සේවය කරයි.
/// එය සම්පාදකයාට සං signal ාවක් වන අතර මෙහි දත්ත * ආරම්භ කළ නොහැකි බව අඟවයි:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // පැහැදිලිවම ආරම්භ නොකළ සඳහනක් සාදන්න.
/// // `MaybeUninit<T>` තුළ ඇති දත්ත අවලංගු විය හැකි බව සම්පාදකයා දනී, එබැවින් මෙය UB නොවේ:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // එය වලංගු අගයකට සකසන්න.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // ආරම්භක දත්ත උපුටා ගැනීම-මෙය අවසර දෙනුයේ `x` නිසියාකාරව ආරම්භ කිරීමෙන් පසුව පමණි *!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// මෙම කේතය පිළිබඳ වැරදි උපකල්පන හෝ ප්‍රශස්තිකරණය නොකිරීමට සම්පාදකයා පසුව දනී.
///
/// ඔබට `MaybeUninit<T>` තරමක් `Option<T>` වැනි යැයි සිතිය හැකි නමුත් කිසිදු ධාවන කාල ලුහුබැඳීමකින් තොරව සහ කිසිදු ආරක්‍ෂිත පරීක්‍ෂාවකින් තොරව.
///
/// ## out-pointers
///
/// "out-pointers" ක්‍රියාත්මක කිරීම සඳහා ඔබට `MaybeUninit<T>` භාවිතා කළ හැකිය: ශ්‍රිතයකින් දත්ත නැවත ලබා දෙනවා වෙනුවට, ප්‍රති X ලය ලබා දීම සඳහා එය (uninitialized) මතකයකට යොමු කරන්න.
/// ප්‍රති the ලය ගබඩා කර ඇති මතකය වෙන් කරන්නේ කෙසේද යන්න පාලනය කිරීම ඇමතුම්කරුට වැදගත් වන විට මෙය ප්‍රයෝජනවත් විය හැකි අතර අනවශ්‍ය චලනයන් වළක්වා ගැනීමට ඔබට අවශ්‍යය.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` වැදගත් වන පැරණි අන්තර්ගතයන් අතහරින්නේ නැත.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // දැන් අපි දන්නවා `v` ආරම්භ කර ඇති බව!මෙය vector නිසියාකාරව පහත වැටෙන බවට සහතික කරයි.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## මූලද්රව්ය අනුව මූලද්රව්යයක් ආරම්භ කිරීම
///
/// `MaybeUninit<T>` මූලද්‍රව්‍ය අනුව මූලද්‍රව්‍යයක් ආරම්භ කිරීමට භාවිතා කළ හැකිය:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // `MaybeUninit` හි ආරම්භක නොවන අරාවක් සාදන්න.
///     // `assume_init` ආරක්ෂිත වන්නේ අප මෙහි ආරම්භ කර ඇති බව කියා සිටින වර්ගය ආරම්භක අවශ්‍ය නොවන `සමහර විට යුනිට් 'පොකුරක් වන බැවිනි.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // `MaybeUninit` හැලීම කිසිවක් නොකරයි.
///     // මේ අනුව `ptr::write` වෙනුවට අමු දර්ශක පැවරුම භාවිතා කිරීමෙන් පැරණි ආරම්භක අගය පහත වැටෙන්නේ නැත.
/////
///     // මෙම ලූපය තුළ panic තිබේ නම්, අපට මතක කාන්දුවක් ඇත, නමුත් මතක ආරක්ෂණ ගැටළුවක් නොමැත.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // සෑම දෙයක්ම ආරම්භ කර ඇත.
///     // අරාව ආරම්භක වර්ගයට සම්ප්‍රේෂණය කරන්න.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// ඔබට අර්ධ වශයෙන් ආරම්භක අරා සමඟ වැඩ කළ හැකිය, ඒවා පහත් මට්ටමේ දත්ත ව්‍යුහයන්ගෙන් සොයාගත හැකිය.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // `MaybeUninit` හි ආරම්භක නොවන අරාවක් සාදන්න.
/// // `assume_init` ආරක්ෂිත වන්නේ අප මෙහි ආරම්භ කර ඇති බව කියා සිටින වර්ගය ආරම්භක අවශ්‍ය නොවන `සමහර විට යුනිට් 'පොකුරක් වන බැවිනි.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // අප විසින් පවරා ඇති මූලද්‍රව්‍ය ගණන ගණන් කරන්න.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // අරාවෙහි ඇති සෑම අයිතමයක් සඳහාම, අපි එය වෙන් කළහොත් අතහරින්න.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## ක්ෂේත්‍රයක් අනුව ව්‍යුහයක් ආරම්භ කිරීම
///
/// ක්ෂේත්‍රය අනුව ව්‍යුහ ක්ෂේත්‍රය ආරම්භ කිරීම සඳහා ඔබට `MaybeUninit<T>` සහ [`std::ptr::addr_of_mut`] මැක්‍රෝ භාවිතා කළ හැකිය:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // `name` ක්ෂේත්‍රය ආරම්භ කිරීම
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // `list` ක්ෂේත්‍රය ආරම්භ කිරීම මෙහි panic තිබේ නම්, `name` ක්ෂේත්‍රයේ `String` කාන්දු වේ.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // සියලුම ක්ෂේත්‍ර ආරම්භ කර ඇත, එබැවින් අපි ආරම්භක Foo ලබා ගැනීම සඳහා `assume_init` අමතන්නෙමු.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` `T` ට සමාන ප්‍රමාණයක්, පෙළගැස්මක් සහ ABI ඇති බවට සහතික වේ:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// කෙසේ වෙතත්, `MaybeUninit<T>`*අඩංගු* වර්ගයක් එකම සැකැස්මක් නොවන බව මතක තබා ගන්න;`T` සහ `U` එකම ප්‍රමාණයේ හා පෙළගැස්මක් තිබුණද `Foo<T>` හි ක්ෂේත්‍රයන්ට `Foo<U>` හා සමාන අනුපිළිවෙලක් ඇති බවට Rust සාමාන්‍යයෙන් සහතික නොවේ.
///
/// තවද, ඕනෑම බිට් අගයක් `MaybeUninit<T>` සඳහා වලංගු බැවින් සම්පාදකයාට non-zero/niche-filling ප්‍රශස්තිකරණය යෙදිය නොහැක, එහි ප්‍රති ing ලයක් වශයෙන් විශාල ප්‍රමාණයක්:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// `T` FFI-ආරක්ෂිත නම්, `MaybeUninit<T>` ද එසේමය.
///
/// `MaybeUninit` යනු `#[repr(transparent)]` වන අතර (එය `T` ලෙස එකම ප්‍රමාණය, පෙළගැස්ම සහ ABI සහතික කරන බව අඟවයි), මෙය පෙර කිසිදු අවවාදයක් * වෙනස් නොකරයි.
/// `Option<T>` සහ `Option<MaybeUninit<T>>` හි තවමත් විවිධ ප්‍රමාණ තිබිය හැකි අතර, `T` වර්ගයේ ක්ෂේත්‍රයක් අඩංගු වර්ග එම ක්ෂේත්‍රය `MaybeUninit<T>` ට වඩා වෙනස් ලෙස සැකසිය හැකිය.
/// `MaybeUninit` වෘත්තීය සමිති වර්ගයක් වන අතර වෘත්තීය සමිතිවල `#[repr(transparent)]` අස්ථායි ([the tracking issue](https://github.com/rust-lang/rust/issues/60405)) බලන්න.
/// කාලයාගේ ඇවෑමෙන්, වෘත්තීය සමිති සඳහා `#[repr(transparent)]` පිළිබඳ නිශ්චිත ඇපකරයන් පරිණාමය විය හැකි අතර, `MaybeUninit` `#[repr(transparent)]` ලෙස පැවතිය හැකිය.
/// `MaybeUninit<T>` `T` ට සමාන ප්‍රමාණයක්, පෙළගැස්මක් සහ ABI ඇති බව *සැමවිටම* සහතික කරයි;`MaybeUninit` සහතික කරන ක්‍රියාවට නැංවෙන ආකාරය පරිණාමය විය හැකිය.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// ලැන්ග් අයිතමය නිසා අපට වෙනත් වර්ග ඔතා ගත හැකිය.මෙය ජනක යන්ත්‍ර සඳහා ප්‍රයෝජනවත් වේ.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // `T::clone()` අමතන්නේ නැත, ඒ සඳහා අප ආරම්භ කර ඇත්දැයි අපට දැනගත නොහැක.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// දී ඇති අගය සමඟ ආරම්භ කළ නව `MaybeUninit<T>` නිර්මාණය කරයි.
    /// මෙම ශ්‍රිතයේ ප්‍රතිලාභ අගය මත [`assume_init`] ඇමතීම ආරක්ෂිතයි.
    ///
    /// `MaybeUninit<T>` අතහැර දැමීමෙන් කිසි විටෙකත් `T` හි බිංදු කේතය නොකියන බව සලකන්න.
    /// `T` ආරම්භ වුවහොත් එය පහත වැටෙන බවට වග බලා ගැනීම ඔබේ වගකීමකි.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// නව `MaybeUninit<T>` ආරම්භ නොකළ තත්වයක නිර්මාණය කරයි.
    ///
    /// `MaybeUninit<T>` අතහැර දැමීමෙන් කිසි විටෙකත් `T` හි බිංදු කේතය නොකියන බව සලකන්න.
    /// `T` ආරම්භ වුවහොත් එය පහත වැටෙන බවට වග බලා ගැනීම ඔබේ වගකීමකි.
    ///
    /// උදාහරණ කිහිපයක් සඳහා [type-level documentation][MaybeUninit] බලන්න.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// ආරම්භක නොවන තත්වයක `MaybeUninit<T>` අයිතම නව පෙළක් සාදන්න.
    ///
    /// Note: future Rust අනුවාදයක අරාව වචනාර්ථයෙන් වාක්‍ය ඛණ්ඩය [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) ට ඉඩ දෙන විට මෙම ක්‍රමය අනවශ්‍ය වනු ඇත.
    ///
    /// පහත උදාහරණයට පසුව `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` භාවිතා කළ හැකිය.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// සැබවින්ම කියවන ලද (සමහර විට කුඩා) දත්ත පෙත්තක් ලබා දෙයි
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // ආරක්ෂාව: ආරම්භ නොකළ `[MaybeUninit<_>; LEN]` වලංගු වේ.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// මතකය `0` බයිට් වලින් පුරවා ඇති, නවීකරණය නොකළ තත්වයක නව `MaybeUninit<T>` නිර්මාණය කරයි.එය දැනටමත් නිසි ආරම්භයක් ලබා දෙන්නේද යන්න `T` මත රඳා පවතී.
    ///
    /// උදාහරණයක් ලෙස, `MaybeUninit<usize>::zeroed()` ආරම්භ කර ඇත, නමුත් `MaybeUninit<&'static i32>::zeroed()` එසේ වන්නේ යොමු කිරීම් අහෝසි නොවිය යුතු බැවිනි.
    ///
    /// `MaybeUninit<T>` අතහැර දැමීමෙන් කිසි විටෙකත් `T` හි බිංදු කේතය නොකියන බව සලකන්න.
    /// `T` ආරම්භ වුවහොත් එය පහත වැටෙන බවට වග බලා ගැනීම ඔබේ වගකීමකි.
    ///
    /// # Example
    ///
    /// මෙම ශ්‍රිතයේ නිවැරදි භාවිතය: ව්‍යුහය ශුන්‍යය සමඟ ආරම්භ කිරීම, එහිදී ව්‍යුහයේ සියලුම ක්ෂේත්‍රයන්ට බිට්-රටාව 0 වලංගු අගයක් ලෙස තබා ගත හැකිය.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *මෙම ශ්‍රිතයේ වැරදි* භාවිතය: `0` වර්ගය සඳහා වලංගු බිට් රටාවක් නොවන විට `x.zeroed().assume_init()` ඇමතීම:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // යුගලයක් තුළ, අපි වලංගු වෙනස්කම් කිරීමක් නොමැති `NotZero` නිර්මාණය කරමු.
    /// // මෙය නිර්වචනය නොකළ හැසිරීමකි.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // ආරක්ෂාව: වෙන් කළ මතකයට `u.as_mut_ptr()` ලකුණු කරයි.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// `MaybeUninit<T>` හි අගය සකසයි.
    /// මෙය කිසියම් පෙර අගයක් අතහැර දැමීමෙන් තොරව නැවත ලියයි, එබැවින් ඔබට ඩිස්ට්‍රැක්ටරය ධාවනය කිරීම මඟ හැරීමට අවශ්‍ය නම් මිස දෙවරක් භාවිතා නොකිරීමට වගබලා ගන්න.
    ///
    /// ඔබගේ පහසුව සඳහා, මෙය `self` හි (දැන් ආරක්ෂිතව ආරම්භ කර ඇති) අන්තර්ගතයන් සඳහා විකෘති යොමු කිරීමක් ද ලබා දෙයි.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // ආරක්ෂාව: අපි මේ අගය ආරම්භ කළා.
        unsafe { self.assume_init_mut() }
    }

    /// අඩංගු අගයට දර්ශකයක් ලබා ගනී.
    /// `MaybeUninit<T>` ආරම්භ නොකළහොත් මෙම දර්ශකයෙන් කියවීම හෝ එය යොමු කිරීමක් බවට පත් කිරීම නිර්වචනය නොකළ හැසිරීමකි.
    /// මෙම දර්ශකය (non-transitively) පෙන්වා දෙන මතකයට ලිවීම නිර්වචනය නොකළ හැසිරීමකි (`UnsafeCell<T>` ඇතුළත හැර).
    ///
    /// # Examples
    ///
    /// මෙම ක්‍රමයේ නිවැරදි භාවිතය:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<T>` වෙත යොමු කිරීමක් සාදන්න.අපි එය ආරම්භ කළ නිසා මෙය හරි.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// මෙම ක්‍රමයේ *වැරදි* භාවිතය:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // අපි ආරම්භ නොකළ vector වෙත යොමු කිරීමක් නිර්මාණය කර ඇත්තෙමු!මෙය නිර්වචනය නොකළ හැසිරීමකි.⚠️
    /// ```
    ///
    /// (ආරම්භ නොකළ දත්ත පිළිබඳ යොමු කිරීම් පිළිබඳ නීති තවමත් අවසන් කර නොමැති බව සලකන්න, නමුත් ඒවා පවතින තුරු ඒවා වළක්වා ගැනීම සුදුසුය.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` සහ `ManuallyDrop` යන දෙකම `repr(transparent)` වන බැවින් අපට දර්ශකය දැමිය හැකිය.
        self as *const _ as *const T
    }

    /// අඩංගු අගයට විකෘති දර්ශකයක් ලබා ගනී.
    /// `MaybeUninit<T>` ආරම්භ නොකළහොත් මෙම දර්ශකයෙන් කියවීම හෝ එය යොමු කිරීමක් බවට පත් කිරීම නිර්වචනය නොකළ හැසිරීමකි.
    ///
    /// # Examples
    ///
    /// මෙම ක්‍රමයේ නිවැරදි භාවිතය:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<Vec<u32>>` වෙත යොමු කිරීමක් සාදන්න.
    /// // අපි එය ආරම්භ කළ නිසා මෙය හරි.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// මෙම ක්‍රමයේ *වැරදි* භාවිතය:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // අපි ආරම්භ නොකළ vector වෙත යොමු කිරීමක් නිර්මාණය කර ඇත්තෙමු!මෙය නිර්වචනය නොකළ හැසිරීමකි.⚠️
    /// ```
    ///
    /// (ආරම්භ නොකළ දත්ත පිළිබඳ යොමු කිරීම් පිළිබඳ නීති තවමත් අවසන් කර නොමැති බව සලකන්න, නමුත් ඒවා පවතින තුරු ඒවා වළක්වා ගැනීම සුදුසුය.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` සහ `ManuallyDrop` යන දෙකම `repr(transparent)` වන බැවින් අපට දර්ශකය දැමිය හැකිය.
        self as *mut _ as *mut T
    }

    /// `MaybeUninit<T>` බහාලුමෙන් වටිනාකම උපුටා ගනී.මෙහි ප්‍රති X ලයක් ලෙස `T` සුපුරුදු බිංදු හැසිරවීමට යටත් වන බැවින් දත්ත පහත වැටෙනු ඇති බව සහතික කිරීමට මෙය හොඳ ක්‍රමයකි.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` සැබවින්ම ආරම්භක තත්වයක පවතින බව සහතික කිරීම ඇමතුම්කරුගේ වගකීමයි.අන්තර්ගතය තවමත් සම්පූර්ණයෙන් ආරම්භ කර නොමැති විට මෙය ඇමතීම ක්ෂණිකව නිර්වචනය නොකළ හැසිරීමට හේතු වේ.
    /// [type-level documentation][inv] හි මෙම ආරම්භක ආක්‍රමණ පිළිබඳ වැඩි විස්තර අඩංගු වේ.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// ඊට ඉහළින්, බොහෝ වර්ගවල අතිරේක මට්ටමක් ඇති බව මතක තබා ගන්න.
    /// නිදසුනක් ලෙස, `1` ආරම්භක [`Vec<T>`] ආරම්භයක් ලෙස සලකනු ලැබේ (වර්තමාන ක්‍රියාත්මක කිරීම යටතේ මෙය ස්ථිර සහතිකයක් නොවේ) මක්නිසාද යත්, සම්පාදකයා ඒ ගැන දන්නා එකම අවශ්‍යතාව වන්නේ දත්ත දර්ශකය අහෝසි විය යුතු බවයි.
    ///
    /// එවැනි `Vec<T>` නිර්මාණය කිරීම *ක්ෂණික* නිර්වචනය නොකළ හැසිරීමට හේතු නොවේ, නමුත් බොහෝ ආරක්ෂිත මෙහෙයුම් සමඟ (එය අතහැර දැමීම ඇතුළුව) නිර්වචනය නොකළ හැසිරීමට හේතු වේ.
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// මෙම ක්‍රමයේ නිවැරදි භාවිතය:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// මෙම ක්‍රමයේ *වැරදි* භාවිතය:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` තවම ආරම්භ කර නොතිබූ බැවින් මෙම අවසාන පේළිය නිර්වචනය නොකළ හැසිරීමට හේතු විය.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // ආරක්ෂාව: අමතන්නා `self` ආරම්භ කර ඇති බවට සහතික විය යුතුය.
        // `self` යනු `value` ප්‍රභේදයක් විය යුතු බවද මෙයින් අදහස් වේ.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// `MaybeUninit<T>` බහාලුමෙන් වටිනාකම කියවයි.එහි ප්‍රති ing ලයක් ලෙස `T` සුපුරුදු බිංදු හැසිරවීමට යටත් වේ.
    ///
    /// හැකි සෑම විටම, ඒ වෙනුවට [`assume_init`] භාවිතා කිරීම වඩාත් සුදුසුය, එමඟින් `MaybeUninit<T>` හි අන්තර්ගතය අනුපිටපත් කිරීම වළක්වයි.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` සැබවින්ම ආරම්භක තත්වයක පවතින බව සහතික කිරීම ඇමතුම්කරුගේ වගකීමයි.අන්තර්ගතය තවමත් සම්පූර්ණයෙන් ආරම්භ කර නොමැති විට මෙය ඇමතීමෙන් නිර්වචනය නොකළ හැසිරීමට හේතු වේ.
    /// [type-level documentation][inv] හි මෙම ආරම්භක ආක්‍රමණ පිළිබඳ වැඩි විස්තර අඩංගු වේ.
    ///
    /// එපමණක් නොව, මෙය එකම දත්තවල පිටපතක් `MaybeUninit<T>` හි ඉතිරි වේ.
    /// දත්තවල පිටපත් කිහිපයක් භාවිතා කරන විට (`assume_init_read` කිහිප වතාවක් ඇමතීමෙන් හෝ පළමුව `assume_init_read` හා පසුව [`assume_init`] ඇමතීමෙන්), එම දත්ත ඇත්ත වශයෙන්ම අනුපිටපත් විය හැකි බව සහතික කිරීම ඔබේ වගකීමකි.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// මෙම ක්‍රමයේ නිවැරදි භාවිතය:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` `Copy` වේ, එබැවින් අපට කිහිප වතාවක් කියවිය හැකිය.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `None` අගයක් අනුපිටපත් කිරීම කමක් නැත, එබැවින් අපට කිහිප වතාවක් කියවිය හැකිය.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// මෙම ක්‍රමයේ *වැරදි* භාවිතය:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // අපි දැන් එකම vector හි පිටපත් දෙකක් නිර්මාණය කර ඇති අතර එය දෙවරක් නිදහස් වීමට හේතු වේ.
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // ආරක්ෂාව: අමතන්නා `self` ආරම්භ කර ඇති බවට සහතික විය යුතුය.
        // `self` ආරම්භ කළ යුතු බැවින් `self.as_ptr()` වෙතින් කියවීම ආරක්ෂිත වේ.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// එහි අඩංගු අගය පහත වැටේ.
    ///
    /// ඔබට `MaybeUninit` හි හිමිකාරිත්වය තිබේ නම්, ඒ වෙනුවට ඔබට [`assume_init`] භාවිතා කළ හැකිය.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` සැබවින්ම ආරම්භක තත්වයක පවතින බව සහතික කිරීම ඇමතුම්කරුගේ වගකීමයි.අන්තර්ගතය තවමත් සම්පූර්ණයෙන් ආරම්භ කර නොමැති විට මෙය ඇමතීමෙන් නිර්වචනය නොකළ හැසිරීමට හේතු වේ.
    ///
    /// ඊට ඉහළින්, `T` වර්ගයේ සියලුම අතිරේක වෙනස්වීම් සෑහීමකට පත්විය යුතුය, මන්ද `T` ක්‍රියාත්මක කිරීම `T` (හෝ එහි සාමාජිකයන්) මේ මත රඳා පවතී.
    /// නිදසුනක් ලෙස, `1` ආරම්භක [`Vec<T>`] ආරම්භයක් ලෙස සලකනු ලැබේ (වර්තමාන ක්‍රියාත්මක කිරීම යටතේ මෙය ස්ථිර සහතිකයක් නොවේ) මක්නිසාද යත්, සම්පාදකයා ඒ ගැන දන්නා එකම අවශ්‍යතාව වන්නේ දත්ත දර්ශකය අහෝසි විය යුතු බවයි.
    ///
    /// කෙසේ වෙතත් එවැනි `Vec<T>` අතහැර දැමීම නිර්වචනය නොකළ හැසිරීමට හේතු වේ.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // ආරක්ෂාව: අමතන්නා විසින් `self` ආරම්භ කර ඇති බවට සහතික විය යුතුය
        // `T` හි සියලුම වෙනස්වීම් තෘප්තිමත් කරයි.
        // එය එසේ නම් එහි වටිනාකම පහත වැටීම ආරක්ෂිත වේ.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// අඩංගු වටිනාකමට හවුල් සඳහනක් ලබා ගනී.
    ///
    /// අපට ආරම්භ කර ඇති නමුත් `MaybeUninit` හි හිමිකාරිත්වයක් නොමැති `MaybeUninit` වෙත ප්‍රවේශ වීමට අවශ්‍ය විට මෙය ප්‍රයෝජනවත් වේ (`.assume_init()`) භාවිතය වළක්වයි.
    ///
    /// # Safety
    ///
    /// අන්තර්ගතය තවමත් සම්පූර්ණයෙන් ආරම්භ කර නොමැති විට මෙය ඇමතීම නිර්වචනය නොකළ හැසිරීමට හේතු වේ: `MaybeUninit<T>` සැබවින්ම ආරම්භක තත්වයක පවතින බව සහතික කිරීම ඇමතුම්කරුගේ වගකීම වේ.
    ///
    ///
    /// # Examples
    ///
    /// ### මෙම ක්‍රමයේ නිවැරදි භාවිතය:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // `x` ආරම්භ කරන්න:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // දැන් අපගේ `MaybeUninit<_>` ආරම්භ කර ඇති බව දන්නා බැවින්, ඒ පිළිබඳව හවුල් සඳහනක් නිර්මාණය කිරීම කමක් නැත:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // ආරක්ෂාව: `x` ආරම්භ කර ඇත.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### මෙම ක්‍රමයේ *වැරදි* භාවිතයන්:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // අපි ආරම්භ නොකළ vector වෙත යොමු කිරීමක් නිර්මාණය කර ඇත්තෙමු!මෙය නිර්වචනය නොකළ හැසිරීමකි.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // `Cell::set` භාවිතා කරමින් `MaybeUninit` ආරම්භ කරන්න:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // ආරම්භ නොකළ `Cell<bool>` වෙත යොමුව: යූබී!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // ආරක්ෂාව: අමතන්නා `self` ආරම්භ කර ඇති බවට සහතික විය යුතුය.
        // `self` යනු `value` ප්‍රභේදයක් විය යුතු බවද මෙයින් අදහස් වේ.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// අඩංගු අගයට විකෘති (unique) යොමු කිරීමක් ලබා ගනී.
    ///
    /// අපට ආරම්භ කර ඇති නමුත් `MaybeUninit` හි හිමිකාරිත්වයක් නොමැති `MaybeUninit` වෙත ප්‍රවේශ වීමට අවශ්‍ය විට මෙය ප්‍රයෝජනවත් වේ (`.assume_init()`) භාවිතය වළක්වයි.
    ///
    /// # Safety
    ///
    /// අන්තර්ගතය තවමත් සම්පූර්ණයෙන් ආරම්භ කර නොමැති විට මෙය ඇමතීම නිර්වචනය නොකළ හැසිරීමට හේතු වේ: `MaybeUninit<T>` සැබවින්ම ආරම්භක තත්වයක පවතින බව සහතික කිරීම ඇමතුම්කරුගේ වගකීම වේ.
    /// උදාහරණයක් ලෙස, `MaybeUninit` ආරම්භ කිරීම සඳහා `.assume_init_mut()` භාවිතා කළ නොහැක.
    ///
    /// # Examples
    ///
    /// ### මෙම ක්‍රමයේ නිවැරදි භාවිතය:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// ආදාන බෆරයේ බයිට් *සියල්ල* ආරම්භ කරයි.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // `buf` ආරම්භ කරන්න:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // දැන් අපි දන්නවා `buf` ආරම්භ කර ඇති නිසා අපට එය `.assume_init()` කළ හැකිය.
    /// // කෙසේ වෙතත්, `.assume_init()` භාවිතා කිරීමෙන් බයිට් 2048 න් `memcpy` අවුලුවනු ඇත.
    /// // අපගේ බෆරය පිටපත් නොකර ආරම්භ කර ඇති බව තහවුරු කර ගැනීම සඳහා, අපි `&mut MaybeUninit<[u8; 2048]>` `&mut [u8; 2048]` වෙත යාවත්කාලීන කරමු:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // ආරක්ෂාව: `buf` ආරම්භ කර ඇත.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // දැන් අපට සාමාන්‍ය පෙත්තක් ලෙස `buf` භාවිතා කළ හැකිය:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### මෙම ක්‍රමයේ *වැරදි* භාවිතයන්:
    ///
    /// අගයක් ආරම්භ කිරීමට ඔබට `.assume_init_mut()` භාවිතා කළ නොහැක:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // අපි ආරම්භ නොකළ `bool` වෙත (mutable) යොමු කිරීමක් නිර්මාණය කර ඇත්තෙමු!
    ///     // මෙය නිර්වචනය නොකළ හැසිරීමකි.⚠️
    /// }
    /// ```
    ///
    /// උදාහරණයක් ලෙස, ඔබට ආරම්භ නොකළ බෆරයකට [`Read`] කළ නොහැක:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) ආරම්භක මතකය වෙත යොමු කිරීම!
    ///                             // මෙය නිර්වචනය නොකළ හැසිරීමකි.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// ක්ෂේත්‍රයෙන් ක්ෂේත්‍ර ක්‍රමයෙන් ආරම්භ කිරීම සඳහා ඔබට සෘජු ක්ෂේත්‍ර ප්‍රවේශය භාවිතා කළ නොහැක:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) ආරම්භක මතකය වෙත යොමු කිරීම!
    ///                  // මෙය නිර්වචනය නොකළ හැසිරීමකි.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) ආරම්භක මතකය වෙත යොමු කිරීම!
    ///                  // මෙය නිර්වචනය නොකළ හැසිරීමකි.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): අප දැනට ඉහත සඳහන් කර ඇති දේ වැරදියි, එනම්, අපට ආරම්භ නොකළ දත්ත (උදා: `libcore/fmt/float.rs` හි) යොමු කර ඇත.
    // ස්ථාවර වීමට පෙර නීතිරීති පිළිබඳව අප අවසාන තීරණයක් ගත යුතුය.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // ආරක්ෂාව: අමතන්නා `self` ආරම්භ කර ඇති බවට සහතික විය යුතුය.
        // `self` යනු `value` ප්‍රභේදයක් විය යුතු බවද මෙයින් අදහස් වේ.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// `MaybeUninit` බහාලුම් සමූහයකින් අගයන් උපුටා ගනී.
    ///
    /// # Safety
    ///
    /// අරාවෙහි සියලුම අංග ආරම්භක තත්වයක පවතින බව සහතික කිරීම ඇමතුම්කරුගේ වගකීම වේ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // ආරක්ෂාව: අපි සියලු අංග ආරම්භ කළ විට දැන් ආරක්ෂිතයි
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * අරාවෙහි සියලුම අංග ආරම්භ කර ඇති බව අමතන්නා සහතික කරයි
        // * `MaybeUninit<T>` සහ ටී එකම පිරිසැලසුමක් ඇති බවට සහතික වේ
        // * සමහර විට යුනින්ට් පහත වැටෙන්නේ නැත, එබැවින් ද්විත්ව නිදහස් කිරීම් නොමැත, එබැවින් පරිවර්තනය ආරක්ෂිත වේ
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// සියලුම මූලද්රව්ය ආරම්භ කර ඇතැයි උපකල්පනය කර, ඒවාට පෙත්තක් ලබා ගන්න.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` මූලද්‍රව්‍ය සැබවින්ම ආරම්භක තත්වයක පවතින බව සහතික කිරීම ඇමතුම්කරුගේ වගකීම වේ.
    ///
    /// අන්තර්ගතය තවමත් සම්පූර්ණයෙන් ආරම්භ කර නොමැති විට මෙය ඇමතීමෙන් නිර්වචනය නොකළ හැසිරීමට හේතු වේ.
    ///
    /// වැඩි විස්තර සහ උදාහරණ සඳහා [`assume_init_ref`] බලන්න.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // සුරක්ෂිතභාවය: අමතන්නා සහතික කරන බැවින් `*const [T]` වෙත පෙත්තක් දැමීම ආරක්ෂිත වේ
        // `slice` ආරම්භ කර ඇති අතර`MaybeUninit` `T` හා සමාන පිරිසැලසුමක් ඇති බවට සහතික වේ.
        // ලබාගත් දර්ශකය වලංගු වන්නේ එය `slice` සතු මතකය වෙත යොමු වන බැවින් එය යොමු කිරීමක් වන අතර එමඟින් කියවීම් සඳහා වලංගු බව සහතික වේ.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// සියලුම මූලද්රව්ය ආරම්භ කර ඇතැයි උපකල්පනය කර, ඒවාට විකෘති පෙත්තක් ලබා ගන්න.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` මූලද්‍රව්‍ය සැබවින්ම ආරම්භක තත්වයක පවතින බව සහතික කිරීම ඇමතුම්කරුගේ වගකීම වේ.
    ///
    /// අන්තර්ගතය තවමත් සම්පූර්ණයෙන් ආරම්භ කර නොමැති විට මෙය ඇමතීමෙන් නිර්වචනය නොකළ හැසිරීමට හේතු වේ.
    ///
    /// වැඩි විස්තර සහ උදාහරණ සඳහා [`assume_init_mut`] බලන්න.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // ආරක්ෂාව: `slice_get_ref` සඳහා ආරක්ෂිත සටහන් වලට සමාන නමුත් අපට ඇත්තේ a
        // විකෘති යොමු කිරීම ලිවීම් සඳහා වලංගු බවට සහතික වේ.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// අරාවේ පළමු අංගයට දර්ශකයක් ලබා ගනී.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// අරාවෙහි පළමු අංගයට විකෘති දර්ශකයක් ලබා ගනී.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// `src` සිට `this` දක්වා මූලද්‍රව්‍ය පිටපත් කරමින්, දැන් අක්‍රීය කර ඇති `this` අන්තර්ගතයට විකෘති යොමු කිරීමක් ලබා දෙයි.
    ///
    /// `T` `Copy` ක්‍රියාත්මක නොකරන්නේ නම්, [`write_slice_cloned`] භාවිතා කරන්න
    ///
    /// මෙය [`slice::copy_from_slice`] ට සමාන වේ.
    ///
    /// # Panics
    ///
    /// පෙති දෙක එකිනෙකට වෙනස් දිගක් තිබේ නම් මෙම ශ්‍රිතය panic වනු ඇත.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // ආරක්ෂාව: අපි දැන් කාචයේ සියලුම අංග අමතර ධාරිතාවට පිටපත් කර ඇත්තෙමු
    /// // vec හි පළමු src.len() මූලද්‍රව්‍ය දැන් වලංගු වේ.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // ආරක්ෂාව: &[ටී] සහ&[සමහර විට යුනිට්<T>] එකම පිරිසැලසුමක් ඇත
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // ආරක්ෂාව: වලංගු මූලද්‍රව්‍යයන් `this` වෙත පිටපත් කර ඇති බැවින් එය අක්‍රිය වී ඇත
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// `src` සිට `this` දක්වා මූලද්‍රව්‍ය ක්ලෝන කර, දැන් අක්‍රිය කර ඇති `this` අන්තර්ගතයට විකෘති යොමු කිරීමක් ලබා දෙයි.
    /// දැනටමත් අක්‍රිය කර ඇති ඕනෑම මූලද්‍රව්‍යයක් අතහැර දමනු නොලැබේ.
    ///
    /// `T` `Copy` ක්‍රියාත්මක කරන්නේ නම්, [`write_slice`] භාවිතා කරන්න
    ///
    /// මෙය [`slice::clone_from_slice`] ට සමාන නමුත් පවතින මූලද්‍රව්‍ය අතහැර දමන්නේ නැත.
    ///
    /// # Panics
    ///
    /// පෙති දෙක එකිනෙකට වෙනස් දිගක් තිබේ නම් හෝ `Clone` panics ක්‍රියාත්මක කරන්නේ නම් මෙම ශ්‍රිතය panic වේ.
    ///
    /// panic තිබේ නම්, දැනටමත් ක්ලෝන කරන ලද මූලද්රව්ය අතහැර දමනු ඇත.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // ආරක්ෂාව: අපි දැන් කාචයේ සියලුම අංග අමතර ධාරිතාවයට ක්ලෝන කර ඇත්තෙමු
    /// // vec හි පළමු src.len() මූලද්‍රව්‍ය දැන් වලංගු වේ.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // Copy_from_slice මෙන් නොව මෙය පෙත්තෙහි clone_from_slice ලෙස නොකියයි, එයට හේතුව `MaybeUninit<T: Clone>` ක්ලෝනය ක්‍රියාත්මක නොකිරීමයි.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // ආරක්ෂාව: මෙම අමු පෙත්තෙහි අඩංගු වන්නේ ආරම්භක වස්තු පමණි
                // ඒ නිසා, එය අතහැර දැමීමට අවසර ඇත.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: අපි පැහැදිලිවම එකම දිගට ඒවා කපා දැමිය යුතුයි
        // සීමාවන් පරික්ෂා කිරීම සඳහා, සහ ප්‍රශස්තකරණය සරල අවස්ථා සඳහා memcpy ජනනය කරනු ඇත (උදාහරණයක් ලෙස T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // ආරක්ෂකයා අවශ්‍යයි b/c panic ක්ලෝනයක් අතරතුර සිදුවිය හැක
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // ආරක්ෂාව: වලංගු මූලද්‍රව්‍යයන් `this` වෙත ලියා ඇති බැවින් එය අක්‍රිය වී ඇත
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}