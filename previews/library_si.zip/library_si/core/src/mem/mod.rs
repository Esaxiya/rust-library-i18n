//! මතකය සමඟ කටයුතු කිරීම සඳහා මූලික කාර්යයන්.
//!
//! මෙම මොඩියුලයේ වර්ගවල ප්‍රමාණය හා පෙළගැස්ම විමසීම, මතකය ආරම්භ කිරීම සහ හැසිරවීම සඳහා කාර්යයන් අඩංගු වේ.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// **එහි විනාශකාරකය ධාවනය නොකර** වටිනාකම ගැන හිමිකාරිත්වය සහ "forgets" ගනී.
///
/// අගය කළමනාකරණය කරන ඕනෑම සම්පතක්, එනම් ගොඩවල් මතකය හෝ ගොනු හසුරුව වැනි දේ සදහටම ළඟා විය නොහැකි තත්වයක පවතිනු ඇත.කෙසේ වෙතත්, මෙම මතකයට යොමු කරන්නන් වලංගු වන බවට එය සහතික නොවේ.
///
/// * ඔබට මතකය කාන්දු වීමට අවශ්‍ය නම්, [`Box::leak`] බලන්න.
/// * ඔබට මතකයට අමු දර්ශකයක් ලබා ගැනීමට අවශ්‍ය නම්, [`Box::into_raw`] බලන්න.
/// * ඔබට වටිනාකමක් නිසියාකාරව බැහැර කිරීමට අවශ්‍ය නම්, එහි ඩිස්ට්‍රැක්ටරය ක්‍රියාත්මක කරමින්, [`mem::drop`] බලන්න.
///
/// # Safety
///
/// `forget` `unsafe` ලෙස සලකුණු කර නැත, මන්ද Rust හි ආරක්‍ෂිත ඇපකරයන් තුළ විනාශ කරන්නන් සැමවිටම ක්‍රියාත්මක වන බවට සහතිකයක් ඇතුළත් නොවේ.
/// නිදසුනක් ලෙස, වැඩසටහනකට [`Rc`][rc] භාවිතා කරමින් විමර්ශන චක්‍රයක් නිර්මාණය කළ හැකිය, නැතහොත් විනාශ කරන්නන් ධාවනය නොකර පිටවීමට [`process::exit`][exit] අමතන්න.
/// මේ අනුව, `mem::forget` ආරක්ෂිත කේතයෙන් ඉඩ දීමෙන් Rust හි ආරක්‍ෂිත සහතික මූලික වශයෙන් වෙනස් නොවේ.
///
/// එනම්, මතකය හෝ I/O වස්තු වැනි සම්පත් කාන්දු වීම සාමාන්‍යයෙන් නුසුදුසු ය.
/// FFI හෝ අනාරක්ෂිත කේත සඳහා සමහර විශේෂිත භාවිත අවස්ථා වලදී අවශ්‍යතාවය මතු වේ, නමුත් එසේ වුවද, [`ManuallyDrop`] සාමාන්‍යයෙන් වඩාත් කැමති වේ.
///
/// අගයක් අමතක කිරීමට ඉඩ දී ඇති නිසා, ඔබ ලියන ඕනෑම `unsafe` කේතයක් මෙම හැකියාව සඳහා ඉඩ දිය යුතුය.ඔබට වටිනාකමක් ආපසු ලබා දිය නොහැකි අතර අමතන්නා අනිවාර්යයෙන්ම වටිනාකමේ විනාශකාරකය ක්‍රියාත්මක කරනු ඇතැයි අපේක්ෂා කළ හැකිය.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// `mem::forget` හි කැනොනිකල් ආරක්ෂිත භාවිතය වන්නේ `Drop` trait විසින් ක්‍රියාවට නංවන ලද අගය විනාශ කරන්නෙකු මග හැරීමයි.උදාහරණයක් ලෙස, මෙය `File` කාන්දු වනු ඇත, එනම්
/// විචල්‍යය විසින් ලබාගත් අවකාශය නැවත ලබා ගන්න, නමුත් කිසි විටෙකත් යටින් පවතින පද්ධති සම්පත වසා නොදමන්න:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// යටින් පවතින සම්පතේ හිමිකාරිත්වය මීට පෙර Rust වලින් පිටත කේතයකට මාරු කළ විට මෙය ප්‍රයෝජනවත් වේ, උදාහරණයක් ලෙස අමු ගොනු විස්තරය C කේතයට සම්ප්‍රේෂණය කිරීමෙන්.
///
/// # `ManuallyDrop` සමඟ සම්බන්ධතාවය
///
/// *මතක* හිමිකාරිත්වය පැවරීම සඳහා `mem::forget` භාවිතා කළ හැකි නමුත් එසේ කිරීම දෝෂ සහිත වේ.
/// [`ManuallyDrop`] ඒ වෙනුවට භාවිතා කළ යුතුය.උදාහරණයක් ලෙස මෙම කේතය සලකා බලන්න:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // `v` හි අන්තර්ගතය භාවිතා කරමින් `String` සාදන්න
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // `v` කාන්දු වීම නිසා එහි මතකය දැන් `s` විසින් කළමනාකරණය කරයි
/// mem::forget(v);  // දෝෂය, v අවලංගු වන අතර එය ශ්‍රිතයකට නොයැවිය යුතුය
/// assert_eq!(s, "Az");
/// // `s` ව්‍යංගයෙන් පහත වැටී එහි මතකය අවලංගු වේ.
/// ```
///
/// ඉහත උදාහරණය සමඟ ගැටළු දෙකක් තිබේ:
///
/// * `String` ඉදිකිරීම සහ `mem::forget()` හි ආයාචනය අතර තවත් කේතයක් එකතු කර ඇත්නම්, එය තුළ ඇති panic ද්විත්ව නිදහස් වීමට හේතු වනුයේ එකම මතකය `v` සහ `s` යන දෙකම විසින් හසුරුවන බැවිනි.
/// * `v.as_mut_ptr()` අමතා දත්තවල හිමිකාරිත්වය `s` වෙත සම්ප්‍රේෂණය කිරීමෙන් පසුව, `v` අගය අවලංගුය.
/// අගයක් `mem::forget` වෙත ගෙන ගිය විට පවා (එය පරීක්ෂා නොකරනු ඇත), සමහර වර්ගවල ඒවායේ අගයන් පිළිබඳ දැඩි අවශ්‍යතා ඇති අතර එමඟින් ඒවා අවලංගු වන විට හෝ තවදුරටත් අයිති කර නොගන්නා විට ඒවා අවලංගු වේ.
/// අවලංගු අගයන් ඕනෑම ආකාරයකින් භාවිතා කිරීම, ඒවා කාර්යයන් වෙත යැවීම හෝ ඒවා ආපසු ලබා දීම ඇතුළුව, නිර්වචනය නොකළ හැසිරීමක් වන අතර සම්පාදකයා විසින් කරන ලද උපකල්පන බිඳ දැමිය හැකිය.
///
/// `ManuallyDrop` වෙත මාරුවීම ගැටළු දෙකම වළක්වයි:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // අපි `v` එහි අමු කොටස් වලට විසුරුවා හැරීමට පෙර, එය අතහැර නොයන බවට වග බලා ගන්න!
/////
/// let mut v = ManuallyDrop::new(v);
/// // දැන් `v` විසුරුවා හරින්න.මෙම මෙහෙයුම් වලට panic කළ නොහැක, එබැවින් කාන්දුවක් තිබිය නොහැක.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // අවසාන වශයෙන්, `String` සාදන්න.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` ව්‍යංගයෙන් පහත වැටී එහි මතකය අවලංගු වේ.
/// ```
///
/// `ManuallyDrop` වෙන කිසිවක් කිරීමට පෙර අපි 'v` හි විනාශ කරන්නා අක්‍රීය කරන බැවින් ද්විත්ව-නිදහස් ලෙස ශක්තිමත් ලෙස වළක්වයි.
/// `mem::forget()` එයට ඉඩ නොදෙන්නේ එය එහි තර්කය පරිභෝජනය කරන නිසා, අපට එය ඇමතීමට බල කරන්නේ `v` වෙතින් අපට අවශ්‍ය ඕනෑම දෙයක් උකහා ගැනීමෙන් පසුව පමණි.
/// `ManuallyDrop` ඉදිකිරීම සහ නූල් තැනීම අතර panic හඳුන්වා දුන්නද (එය පෙන්වා ඇති පරිදි කේතයේ සිදුවිය නොහැක), එය කාන්දු වීමට හේතු වන අතර දෙවරක් නොමිලේ නොවේ.
/// වෙනත් වචන වලින් කිවහොත්, (ද්විත්ව) පහත වැටීමේ පැත්තෙන් වැරදීම වෙනුවට කාන්දු වන පැත්තේ `ManuallyDrop` වැරදී ඇත.
///
/// එසේම, `ManuallyDrop` හි හිමිකාරිත්වය `s` වෙත මාරු කිරීමෙන් පසු "touch" `v` වෙත යාමෙන් අපව වළක්වයි-`v` සමඟ එහි විනාශකාරකය ධාවනය නොකර එය බැහැර කිරීම සඳහා අන්තර්ක්‍රියා කිරීමේ අවසාන පියවර සම්පූර්ණයෙන්ම මග හැරේ.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// [`forget`] මෙන් නොව, ප්‍රමාණ නොකළ අගයන් ද පිළිගනී.
///
/// මෙම ශ්‍රිතය `unsized_locals` විශේෂාංගය ස්ථාවර වූ විට ඉවත් කිරීමට අදහස් කරන ෂිම් එකක් පමණි.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// බයිට් වර්ගයක ප්‍රමාණය ලබා දෙයි.
///
/// වඩාත් නිශ්චිතවම, පෙළගැස්වීමේ පෑඩින් ඇතුළුව එම අයිතම වර්ගය සමඟ අරාවෙහි අනුක්‍රමික මූලද්‍රව්‍ය අතර බයිට් වල ඕෆ්සෙට් මෙයයි.
///
/// මේ අනුව, ඕනෑම වර්ගයක `T` සහ දිග `n` සඳහා, `[T; n]` හි ප්‍රමාණය `n * size_of::<T>()` වේ.
///
/// පොදුවේ ගත් කල, වර්ගයක ප්‍රමාණය සම්පාදනය හරහා ස්ථායී නොවේ, නමුත් ප්‍රාථමික වර්ග වැනි නිශ්චිත වර්ග වේ.
///
/// පහත වගුව ප්‍රාථමිකයන් සඳහා ප්‍රමාණය ලබා දෙයි.
///
/// වර්ගය |size_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 වරහන් |4
///
/// තවද, `usize` සහ `isize` එකම ප්‍රමාණයෙන් යුක්ත වේ.
///
/// `*const T`, `&T`, `Box<T>`, `Option<&T>`, සහ `Option<Box<T>>` යන වර්ග සියල්ලම එකම ප්‍රමාණයක් ඇත.
/// `T` ප්‍රමාණයෙන් නම්, එම සියලු වර්ගවල ප්‍රමාණය `usize` හා සමාන වේ.
///
/// දර්ශකයේ විකෘතිතාව එහි ප්‍රමාණය වෙනස් නොකරයි.එනිසා `&T` සහ `&mut T` එකම ප්‍රමාණයෙන් යුක්ත වේ.
/// ඒ හා සමානව `*const T` සහ `* mut T` සඳහා.
///
/// # `#[repr(C)]` අයිතමවල ප්‍රමාණය
///
/// අයිතම සඳහා `C` නිරූපණයට අර්ථ දක්වා ඇති පිරිසැලසුමක් ඇත.
/// මෙම පිරිසැලසුම සමඟ, සියලු ක්ෂේත්‍රවල ස්ථාවර ප්‍රමාණයක් පවතින තාක් කල් අයිතමවල ප්‍රමාණයද ස්ථායී වේ.
///
/// ## ව්යුහයන්ගේ ප්රමාණය
///
/// `structs` සඳහා, ප්‍රමාණය පහත දැක්වෙන ඇල්ගොරිතම මගින් තීරණය වේ.
///
/// ප්‍රකාශන අනුපිළිවෙලින් ඇණවුම් කරන ලද ව්‍යුහයේ සෑම ක්ෂේත්‍රයක් සඳහාම:
///
/// 1. ක්ෂේත්රයේ ප්රමාණය එකතු කරන්න.
/// 2. වත්මන් ප්‍රමාණය ඊළඟ ක්ෂේත්‍රයේ [alignment] හි ආසන්නතම ගුණකය දක්වා රවුම් කරන්න.
///
/// අවසාන වශයෙන්, ව්‍යුහයේ ප්‍රමාණය එහි [alignment] හි ආසන්නතම ගුණකය වටා රවුම් කරන්න.
/// ව්‍යුහයේ පෙළගැස්ම සාමාන්‍යයෙන් එහි සියලුම ක්ෂේත්‍රවල විශාලතම පෙළගැස්ම වේ;`repr(align(N))` භාවිතයෙන් මෙය වෙනස් කළ හැකිය.
///
/// `C` මෙන් නොව, ශුන්‍ය ප්‍රමාණයේ ව්‍යුහයන් එක් බයිටයක් දක්වා වටකුරු නොවේ.
///
/// ## එනූම්ස් ප්‍රමාණය
///
/// වෙනස් කොට සැලකීම හැර වෙනත් දත්ත රැගෙන නොයන එනූම් සඳහා ඔවුන් සම්පාදනය කරන ලද වේදිකාවේ සී එනූම්ස් වලට සමාන ප්‍රමාණයක් ඇත.
///
/// ## වෘත්තීය සමිති ප්‍රමාණය
///
/// සමිතියක විශාලත්වය එහි විශාලතම ක්ෂේත්‍රයේ ප්‍රමාණයයි.
///
/// `C` මෙන් නොව, ශුන්‍ය ප්‍රමාණයේ වෘත්තීය සමිති එක් බයිට් ප්‍රමාණයකින් වටකුරු නොවේ.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // සමහර ප්‍රාථමික
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // සමහර අරා
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // දර්ශක ප්‍රමාණයේ සමානාත්මතාවය
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// `#[repr(C)]` භාවිතා කිරීම.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // පළමු ක්ෂේත්‍රයේ ප්‍රමාණය 1 වේ, එබැවින් ප්‍රමාණයට 1 ක් එක් කරන්න.ප්‍රමාණය 1 යි.
/// // දෙවන ක්ෂේත්‍රයේ පෙළගැස්ම 2 ක් වන අතර එමඟින් පෑඩින් කිරීම සඳහා ප්‍රමාණයට 1 ක් එක් කරන්න.ප්‍රමාණය 2 කි.
/// // දෙවන ක්ෂේත්‍රයේ ප්‍රමාණය 2 වේ, එබැවින් ප්‍රමාණයට 2 ක් එක් කරන්න.ප්‍රමාණය 4 කි.
/// // තෙවන ක්ෂේත්‍රයේ පෙළගැස්ම 1 වන අතර එමඟින් පෑඩින් කිරීම සඳහා ප්‍රමාණයට 0 එකතු කරන්න.ප්‍රමාණය 4 කි.
/// // තෙවන ක්ෂේත්රයේ විශාලත්වය 1, එබැවින් ප්රමාණයට 1 එකතු කරන්න.ප්‍රමාණය 5 කි.
/// // අවසාන වශයෙන්, ව්‍යුහයේ පෙළගැස්ම 2 (එහි ක්ෂේත්‍ර අතර විශාලතම පෙළගැස්ම 2 වන නිසා), එබැවින් පෑඩින් කිරීම සඳහා ප්‍රමාණයට 1 ක් එක් කරන්න.
/// // ප්‍රමාණය 6 කි.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // ටුපල් ව්‍යුහයන් එකම නීති රීති අනුගමනය කරයි.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // ක්ෂේත්‍ර නැවත සකස් කිරීමෙන් ප්‍රමාණය අඩු කළ හැකි බව සලකන්න.
/// // `second` ට පෙර `third` තැබීමෙන් අපට පෑඩින් බයිට් දෙකම ඉවත් කළ හැකිය.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // යුනියන් ප්‍රමාණය යනු විශාලතම ක්ෂේත්‍රයේ ප්‍රමාණයයි.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// පෙන්වා ඇති අගයේ ප්‍රමාණය බයිට් වලින් ලබා දෙයි.
///
/// මෙය සාමාන්‍යයෙන් `size_of::<T>()` ට සමාන වේ.
/// කෙසේ වෙතත්, `T`*ට* සංඛ්‍යාත්මකව නොදන්නා ප්‍රමාණයක් නොමැති විට, උදා: පෙත්තක් [`[T]`][slice] හෝ [trait object], එවිට ගතිකව දන්නා ප්‍රමාණය ලබා ගැනීමට `size_of_val` භාවිතා කළ හැකිය.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // ආරක්ෂාව: `val` යනු යොමු කිරීමකි, එබැවින් එය වලංගු අමු දර්ශකයකි
    unsafe { intrinsics::size_of_val(val) }
}

/// පෙන්වා ඇති අගයේ ප්‍රමාණය බයිට් වලින් ලබා දෙයි.
///
/// මෙය සාමාන්‍යයෙන් `size_of::<T>()` ට සමාන වේ.කෙසේ වෙතත්, `T`*ට* සංඛ්‍යාත්මකව නොදන්නා ප්‍රමාණයක් නොමැති විට, උදා: පෙත්තක් [`[T]`][slice] හෝ [trait object], එවිට ගතිකව දන්නා ප්‍රමාණය ලබා ගැනීමට `size_of_val_raw` භාවිතා කළ හැකිය.
///
/// # Safety
///
/// මෙම ශ්‍රිතය ඇමතීමට ආරක්ෂිත වන්නේ පහත සඳහන් කොන්දේසි තිබේ නම් පමණි:
///
/// - `T` යනු `Sized` නම්, මෙම ක්‍රියාව සැමවිටම ඇමතීමට ආරක්ෂිත වේ.
/// - `T` හි නම් නොකළ වලිගය නම්:
///     - [slice], පසුව පෙති වලිගයේ දිග ආරම්භක නිඛිලයක් විය යුතු අතර,*සම්පූර්ණ අගය*(ගතික වලිගයේ දිග + සංඛ්‍යානමය ප්‍රමාණයේ උපසර්ගය) ප්‍රමාණය `isize` ට ගැලපේ.
///     - [trait object], එවිට දර්ශකයේ vtable කොටස, අවලංගු කරන ලද බලහත්කාරයකින් අත්පත් කරගත් වලංගු vtable එකකට යොමු විය යුතු අතර,*සම්පූර්ණ වටිනාකම*(ගතික වලිගයේ දිග + සංඛ්‍යානමය ප්‍රමාණයේ උපසර්ගය) `isize` ට ගැලපේ.
///
///     - (unstable) [extern type], එවිට මෙම ශ්‍රිතය ඇමතීමට සැමවිටම ආරක්ෂිත වේ, නමුත් බාහිර වර්ගයේ පිරිසැලසුම නොදන්නා බැවින් panic හෝ වෙනත් ආකාරයකින් වැරදි අගයක් ලබා දිය හැකිය.
///     බාහිර වර්ගයේ වලිගයක් සහිත වර්ගයක් වෙත යොමු කිරීමේදී [`size_of_val`] හා සමාන හැසිරීම මෙයයි.
///     - එසේ නොමැති නම්, මෙම ශ්‍රිතය ඇමතීමට සම්ප්‍රදායිකව අවසර නැත.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // ආරක්ෂාව: අමතන්නා විසින් වලංගු අමු දර්ශකයක් සැපයිය යුතුය
    unsafe { intrinsics::size_of_val(val) }
}

/// [ABI] ඉල්ලූ අවම පෙළගැස්මක් ලබා දෙයි.
///
/// `T` වර්ගයේ අගය පිළිබඳ සෑම සඳහනක්ම මෙම සංඛ්‍යාවේ ගුණකයක් විය යුතුය.
///
/// ව්‍යුහාත්මක ක්ෂේත්‍ර සඳහා භාවිතා කරන පෙළගැස්ම මෙයයි.එය කැමති පෙළගැස්මට වඩා කුඩා විය හැකිය.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val` පෙන්වා දෙන අගයෙහි [ABI] ඉල්ලූ අවම පෙළගැස්ම ලබා දෙයි.
///
/// `T` වර්ගයේ අගය පිළිබඳ සෑම සඳහනක්ම මෙම සංඛ්‍යාවේ ගුණකයක් විය යුතුය.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // ආරක්ෂාව: val යනු යොමු කිරීමකි, එබැවින් එය වලංගු අමු දර්ශකයකි
    unsafe { intrinsics::min_align_of_val(val) }
}

/// [ABI] ඉල්ලූ අවම පෙළගැස්මක් ලබා දෙයි.
///
/// `T` වර්ගයේ අගය පිළිබඳ සෑම සඳහනක්ම මෙම සංඛ්‍යාවේ ගුණකයක් විය යුතුය.
///
/// ව්‍යුහාත්මක ක්ෂේත්‍ර සඳහා භාවිතා කරන පෙළගැස්ම මෙයයි.එය කැමති පෙළගැස්මට වඩා කුඩා විය හැකිය.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val` පෙන්වා දෙන අගයෙහි [ABI] ඉල්ලූ අවම පෙළගැස්ම ලබා දෙයි.
///
/// `T` වර්ගයේ අගය පිළිබඳ සෑම සඳහනක්ම මෙම සංඛ්‍යාවේ ගුණකයක් විය යුතුය.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // ආරක්ෂාව: val යනු යොමු කිරීමකි, එබැවින් එය වලංගු අමු දර්ශකයකි
    unsafe { intrinsics::min_align_of_val(val) }
}

/// `val` පෙන්වා දෙන අගයෙහි [ABI] ඉල්ලූ අවම පෙළගැස්ම ලබා දෙයි.
///
/// `T` වර්ගයේ අගය පිළිබඳ සෑම සඳහනක්ම මෙම සංඛ්‍යාවේ ගුණකයක් විය යුතුය.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// මෙම ශ්‍රිතය ඇමතීමට ආරක්ෂිත වන්නේ පහත සඳහන් කොන්දේසි තිබේ නම් පමණි:
///
/// - `T` යනු `Sized` නම්, මෙම ක්‍රියාව සැමවිටම ඇමතීමට ආරක්ෂිත වේ.
/// - `T` හි නම් නොකළ වලිගය නම්:
///     - [slice], පසුව පෙති වලිගයේ දිග ආරම්භක නිඛිලයක් විය යුතු අතර,*සම්පූර්ණ අගය*(ගතික වලිගයේ දිග + සංඛ්‍යානමය ප්‍රමාණයේ උපසර්ගය) ප්‍රමාණය `isize` ට ගැලපේ.
///     - [trait object], එවිට දර්ශකයේ vtable කොටස, අවලංගු කරන ලද බලහත්කාරයකින් අත්පත් කරගත් වලංගු vtable එකකට යොමු විය යුතු අතර,*සම්පූර්ණ වටිනාකම*(ගතික වලිගයේ දිග + සංඛ්‍යානමය ප්‍රමාණයේ උපසර්ගය) `isize` ට ගැලපේ.
///
///     - (unstable) [extern type], එවිට මෙම ශ්‍රිතය ඇමතීමට සැමවිටම ආරක්ෂිත වේ, නමුත් බාහිර වර්ගයේ පිරිසැලසුම නොදන්නා බැවින් panic හෝ වෙනත් ආකාරයකින් වැරදි අගයක් ලබා දිය හැකිය.
///     බාහිර වර්ගයේ වලිගයක් සහිත වර්ගයක් වෙත යොමු කිරීමේදී [`align_of_val`] හා සමාන හැසිරීම මෙයයි.
///     - එසේ නොමැති නම්, මෙම ශ්‍රිතය ඇමතීමට සම්ප්‍රදායිකව අවසර නැත.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // ආරක්ෂාව: අමතන්නා විසින් වලංගු අමු දර්ශකයක් සැපයිය යුතුය
    unsafe { intrinsics::min_align_of_val(val) }
}

/// `T` වර්ගයේ අගයන් අතහැර දැමුවහොත් `true` ලබා දෙයි.
///
/// මෙය තනිකරම ප්‍රශස්තිකරණ ඉඟියක් වන අතර එය සම්ප්‍රදායිකව ක්‍රියාත්මක කළ හැකිය:
/// එය අතහැර දැමීමට අවශ්‍ය නොවන වර්ග සඳහා එය `true` ආපසු ලබා දිය හැකිය.
/// සෑම විටම `true` නැවත පැමිණීම මෙම ශ්‍රිතයේ වලංගු ක්‍රියාවලියකි.කෙසේ වෙතත් මෙම ශ්‍රිතය ඇත්ත වශයෙන්ම `false` ආපසු ලබා දෙන්නේ නම්, එවිට ඔබට විශ්වාසයි `T` අතහැර දැමීමෙන් කිසිදු අතුරු ආබාධයක් නොමැත.
///
/// එකතු කිරීම් වැනි දෑ පහත් මට්ටමේ ක්‍රියාත්මක කිරීම, ඒවායේ දත්ත අතින් අතහැර දැමීම අවශ්‍ය වන අතර, ඒවා විනාශ වූ විට අනවශ්‍ය ලෙස ඒවායේ අන්තර්ගතය අතහැර දැමීමට උත්සාහ කිරීම වළක්වා ගත යුතුය.
///
/// මෙය මුදා හැරීම්වල වෙනසක් සිදු නොකරනු ඇත (එහිදී අතුරු ආබාධ නොමැති ලූපයක් පහසුවෙන් හඳුනාගෙන ඉවත් කරනු ලැබේ), නමුත් බොහෝ විට එය නිදොස් කිරීම් සඳහා විශාල ජයග්‍රහණයක් වේ.
///
/// [`drop_in_place`] දැනටමත් මෙම චෙක්පත සිදු කරන බව සලකන්න, එබැවින් ඔබගේ කාර්ය භාරය [`drop_in_place`] ඇමතුම් කුඩා සංඛ්‍යාවක් දක්වා අඩු කළ හැකි නම්, මෙය භාවිතා කිරීම අනවශ්‍යය.
/// විශේෂයෙන් ඔබට පෙත්තක් [`drop_in_place`] කළ හැකි බව සලකන්න, එමඟින් සියලු අගයන් සඳහා තනි අවශ්‍යතා_ඩ්‍රොප් පරීක්‍ෂණයක් කරනු ඇත.
///
/// Vec වැනි වර්ග `needs_drop` පැහැදිලිවම භාවිතා නොකර `drop_in_place(&mut self[..])` පමණි.
/// [`HashMap`] වැනි වර්ග, වරකට එක වරකට අගයන් අතහැර දැමිය යුතු අතර මෙම API භාවිතා කළ යුතුය.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// එකතුවක් `needs_drop` භාවිතා කරන්නේ කෙසේද යන්න පිළිබඳ උදාහරණයක් මෙන්න:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // දත්ත අතහරින්න
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// සියලු ශුන්‍ය බයිට් රටාවෙන් නිරූපණය වන `T` වර්ගයේ අගය ලබා දෙයි.
///
/// මෙයින් අදහස් කරන්නේ, උදාහරණයක් ලෙස, `(u8, u16)` හි පැඩින් බයිට් අනිවාර්යයෙන්ම ශුන්‍ය නොවන බවයි.
///
/// සියලු ශුන්‍ය බයිට් රටාවක් `T` වර්ගයේ වලංගු අගයක් නිරූපණය කරන බවට සහතිකයක් නොමැත.
/// උදාහරණයක් ලෙස, සියලු ශුන්‍ය බයිට් රටාව යොමු වර්ග (`&T`, `&mut T`) සහ ශ්‍රිත දර්ශක සඳහා වලංගු අගයක් නොවේ.
/// එවැනි වර්ග සඳහා `zeroed` භාවිතා කිරීම ක්ෂණික [undefined behavior][ub] වලට හේතු වේ, මන්ද [the Rust compiler assumes][inv] සෑම විටම විචල්‍යයක වලංගු අගයක් ඇති බැවින් එය ආරම්භය ලෙස සලකයි.
///
///
/// මෙය [`MaybeUninit::zeroed().assume_init()`][zeroed] හා සමාන බලපෑමක් ඇති කරයි.
/// සමහර විට එය FFI සඳහා ප්‍රයෝජනවත් වේ, නමුත් සාමාන්‍යයෙන් එය වළක්වා ගත යුතුය.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// මෙම ශ්‍රිතයේ නිවැරදි භාවිතය: ශුන්‍යය සමඟ පූර්ණ සංඛ්‍යාවක් ආරම්භ කිරීම.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// මෙම ශ්‍රිතයේ *වැරදි* භාවිතය: ශුන්‍යය සමඟ යොමු කිරීමක් ආරම්භ කිරීම.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // නිර්වචනය නොකළ හැසිරීම!
/// let _y: fn() = unsafe { mem::zeroed() }; // නැවතත්!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // ආරක්ෂාව: සියලු ශුන්‍ය අගයක් `T` සඳහා වලංගු බවට ඇමතුම්කරු සහතික විය යුතුය.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// කිසිවක් නොකර, `T` වර්ගයේ වටිනාකමක් නිපදවන ලෙස මවා පාමින් Rust හි සාමාන්‍ය මතක-ආරම්භක චෙක්පත් මඟ හැරේ.
///
/// **මෙම ශ්‍රිතය අතහැර දමා ඇත.** ඒ වෙනුවට [`MaybeUninit<T>`] භාවිතා කරන්න.
///
/// ක්ෂය වීමට හේතුව ශ්‍රිතය මූලික වශයෙන් නිවැරදිව භාවිතා කළ නොහැකි වීමයි: එය [`MaybeUninit::uninit().assume_init()`][uninit] හා සමාන බලපෑමක් ඇති කරයි.
///
/// [`assume_init` documentation][assume_init] පැහැදිලි කරන පරිදි, [the Rust compiler assumes][inv] අගයන් නිසි ලෙස ආරම්භ කර ඇත.
/// ප්‍රති consequ ලයක් ලෙස උදා
/// `mem::uninitialized::<bool>()` `bool` හෝ `false` නොවන `bool` ආපසු ලබා දීම සඳහා ක්ෂණිකව නිර්වචනය නොකළ හැසිරීමක් ඇති කරයි.
/// නරකම, සැබවින්ම නැවත ආරම්භ නොකළ මතකය මෙහි නැවත පැමිණීම වැනි දේ විශේෂිත වන්නේ සම්පාදකයාට එය ස්ථාවර අගයක් නොමැති බව දන්නා බැවිනි.
/// මෙමඟින් විචල්‍යයක පූර්ණ සංඛ්‍යා වර්ගයක් තිබුණද විචල්‍යයක ආරම්භක දත්ත තිබීම නිර්වචනය නොකළ හැසිරීමකි.
/// (ආරම්භ නොකළ පූර්ණ සංඛ්‍යා පිළිබඳ නීති තවමත් අවසන් කර නොමැති බව සලකන්න, නමුත් ඒවා පවතින තුරු ඒවා වළක්වා ගැනීම සුදුසුය.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // ආරක්ෂාව: `T` සඳහා ඒකීයකරණය කළ අගය වලංගු බවට ඇමතුම්කරු සහතික විය යුතුය.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// එකක් විකෘති නොකර, විකෘති ස්ථාන දෙකක අගයන් මාරු කරයි.
///
/// * ඔබට පෙරනිමි හෝ ව්‍යාජ අගයක් සමඟ හුවමාරු වීමට අවශ්‍ය නම්, [`take`] බලන්න.
/// * සම්මත අගය සමඟ මාරු වීමට ඔබට අවශ්‍ය නම්, පැරණි අගය නැවත ලබා දීමට, [`replace`] බලන්න.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // ආරක්ෂාව: අමු දර්ශක සියල්ලම සෑහීමකට පත්විය හැකි ආරක්ෂිත විකෘති යොමු කිරීම් වලින් නිර්මාණය කර ඇත
    // `ptr::swap_nonoverlapping_one` හි සීමාවන්
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// `dest` හි පෙරනිමි අගය `T` සමඟ ප්‍රතිස්ථාපනය කරයි, පෙර `dest` අගය නැවත ලබා දෙයි.
///
/// * ඔබට විචල්යයන් දෙකක අගයන් ප්රතිස්ථාපනය කිරීමට අවශ්ය නම්, [`swap`] බලන්න.
/// * පෙරනිමි අගය වෙනුවට සම්මත අගයක් සමඟ ප්‍රතිස්ථාපනය කිරීමට ඔබට අවශ්‍ය නම්, [`replace`] බලන්න.
///
/// # Examples
///
/// සරල උදාහරණයක්:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` "empty" අගය සමඟ ප්‍රතිස්ථාපනය කිරීමෙන් ව්‍යුහාත්මක ක්ෂේත්‍රයක හිමිකාරිත්වය ලබා ගැනීමට ඉඩ ලබා දේ.
/// `take` නොමැතිව ඔබට මෙවැනි ගැටළු වලට මුහුණ දිය හැකිය:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// `T` අනිවාර්යයෙන්ම [`Clone`] ක්‍රියාත්මක නොකරන බව සලකන්න, එබැවින් එයට `self.buf` ක්ලෝන කර නැවත සැකසිය නොහැක.
/// නමුත් `take` හි `self.buf` හි මුල් අගය `self` වෙතින් වෙන් කිරීමට භාවිතා කළ හැකි අතර එය නැවත ලබා දීමට ඉඩ දෙයි:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// `src` යොමු `dest` වෙත ගෙන යන අතර පෙර `dest` අගය ලබා දෙයි.
///
/// කිසිදු වටිනාකමක් පහත වැටෙන්නේ නැත.
///
/// * ඔබට විචල්යයන් දෙකක අගයන් ප්රතිස්ථාපනය කිරීමට අවශ්ය නම්, [`swap`] බලන්න.
/// * ඔබට පෙරනිමි අගයක් සමඟ ප්‍රතිස්ථාපනය කිරීමට අවශ්‍ය නම්, [`take`] බලන්න.
///
/// # Examples
///
/// සරල උදාහරණයක්:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` ව්‍යුහාත්මක ක්ෂේත්‍රයක් වෙනත් අගයකින් ප්‍රතිස්ථාපනය කිරීමෙන් එය පරිභෝජනය කිරීමට ඉඩ දෙයි.
/// `replace` නොමැතිව ඔබට මෙවැනි ගැටළු වලට මුහුණ දිය හැකිය:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// `T` අනිවාර්යයෙන්ම [`Clone`] ක්‍රියාත්මක නොකරන බව සලකන්න, එම නිසා අපට චලනය වළක්වා ගැනීමට `self.buf[i]` ක්ලෝන කිරීමට පවා නොහැකිය.
/// නමුත් `replace` මඟින් එම දර්ශකයේ මුල් අගය `self` වෙතින් වෙන් කිරීමට භාවිතා කළ හැකි අතර එය ආපසු ලබා දීමට ඉඩ දෙයි:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // ආරක්ෂාව: අපි `dest` වෙතින් කියවන නමුත් පසුව කෙලින්ම `src` ලියන්න,
    // පැරණි අගය අනුපිටපත් නොකිරීම.
    // කිසිවක් අතහැර දමා නැති අතර මෙහි කිසිවක් panic කළ නොහැක.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// වටිනාකමක් බැහැර කරයි.
///
/// මෙය සිදු කරන්නේ තර්කය [`Drop`][drop] ක්‍රියාත්මක කිරීම කැඳවීමෙනි.
///
/// `Copy` ක්‍රියාත්මක කරන වර්ග සඳහා මෙය effectively ලදායී ලෙස කිසිවක් නොකරයි, උදා
/// integers.
/// එවැනි අගයන් පිටපත් කර _then_ ශ්‍රිතය තුළට ගෙන යන බැවින් මෙම ශ්‍රිත ඇමතුමෙන් පසුව අගය දිගටම පවතී.
///
///
/// මෙම කාර්යය මැජික් නොවේ;එය වචනාර්ථයෙන් අර්ථ දක්වා ඇත
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// `_x` ශ්‍රිතය තුළට ගෙන යන නිසා, ශ්‍රිතය නැවත පැමිණීමට පෙර එය ස්වයංක්‍රීයව පහත වැටේ.
///
/// [drop]: Drop
///
/// # Examples
///
/// මූලික භාවිතය:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // පැහැදිලිවම vector අතහරින්න
/// ```
///
/// [`RefCell`] ධාවන වේලාවේදී ණය ගැනීමේ නීති ක්‍රියාත්මක කරන බැවින්, `drop` හට [`RefCell`] ණයක් නිදහස් කළ හැකිය:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // මෙම විවරය මත විකෘති ණය ලබා දීම අත්හරින්න
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// [`Copy`] ක්‍රියාත්මක කරන පූර්ණ සංඛ්‍යා සහ වෙනත් වර්ග `drop` මගින් බලපානු නොලැබේ.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // `x` හි පිටපතක් ගෙන ගොස් අතහැර දමනු ලැබේ
/// drop(y); // `y` හි පිටපතක් ගෙන ගොස් අතහැර දමනු ලැබේ
///
/// println!("x: {}, y: {}", x, y.0); // තවමත් පවතී
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// `src` වර්ගය `&U` වර්ගයක් ලෙස අර්ථ නිරූපණය කරයි, පසුව අඩංගු අගය චලනය නොකර `src` කියවයි.
///
/// `&T` `&U` වෙත සම්ප්‍රේෂණය කිරීමෙන් පසුව `&U` කියවීමෙන් `src` දර්ශකය [`size_of::<U>`][size_of] බයිට් සඳහා වලංගු බව මෙම ශ්‍රිතය අනාරක්ෂිත ලෙස උපකල්පනය කරනු ඇත (`&U` `&T` ට වඩා දැඩි පෙළගැස්වීමේ අවශ්‍යතා ඇති විටදී පවා මෙය නිවැරදි ආකාරයකින් සිදු වේ).
/// එය `src` වෙතින් පිටතට යාම වෙනුවට අඩංගු අගයේ පිටපතක් අනාරක්ෂිත ලෙස නිර්මාණය කරනු ඇත.
///
/// `T` සහ `U` එකිනෙකට වෙනස් ප්‍රමාණ තිබේ නම් එය සම්පාදක කාල දෝෂයක් නොවේ, නමුත් `T` සහ `U` එකම ප්‍රමාණයේ මෙම ශ්‍රිතය පමණක් ක්‍රියාත්මක කිරීමට උනන්දු කරනු ලැබේ.`U` `T` ට වඩා විශාල නම් මෙම ශ්‍රිතය [undefined behavior][ub] අවුලුවයි.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // 'foo_array' වෙතින් දත්ත පිටපත් කර එය 'Foo' ලෙස සලකන්න
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // පිටපත් කළ දත්ත වෙනස් කරන්න
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // 'foo_array' හි අන්තර්ගතය වෙනස් නොවිය යුතුය
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // U ට වැඩි පෙළගැස්වීමේ අවශ්‍යතාවයක් තිබේ නම්, src සුදුසු ලෙස පෙළගස්වා නොතිබිය හැකිය.
    if align_of::<U>() > align_of::<T>() {
        // ආරක්ෂාව: `src` යනු කියවීම සඳහා වලංගු බවට සහතික වන යොමු කිරීමකි.
        // සැබෑ සම්ප්‍රේෂණය ආරක්ෂිත බව අමතන්නා සහතික කළ යුතුය.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // ආරක්ෂාව: `src` යනු කියවීම සඳහා වලංගු බවට සහතික වන යොමු කිරීමකි.
        // `src as *const U` නිසියාකාරව පෙලගැසී ඇති බව අපි පරීක්ෂා කළෙමු.
        // සැබෑ සම්ප්‍රේෂණය ආරක්ෂිත බව අමතන්නා සහතික කළ යුතුය.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// එනූමයක වෙනස්කම් කිරීම නියෝජනය කරන පාරාන්ධ වර්ගය.
///
/// වැඩි විස්තර සඳහා මෙම මොඩියුලයේ [`discriminant`] ශ්‍රිතය බලන්න.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. මෙම trait ක්‍රියාත්මක කිරීම් ව්‍යුත්පන්න කළ නොහැක්කේ අපට T හි සීමාවන් අවශ්‍ය නොවන බැවිනි.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// `v` හි එනූම් ප්‍රභේදය අද්විතීයව හඳුනාගැනීමේ අගයක් ලබා දෙයි.
///
/// `T` යනු එනුම් එකක් නොවේ නම්, මෙම ශ්‍රිතය ඇමතීමෙන් නිර්වචනය නොකළ හැසිරීමක් ඇති නොවනු ඇත, නමුත් ප්‍රතිලාභ අගය නිශ්චිතව දක්වා නැත.
///
///
/// # Stability
///
/// එනුම් අර්ථ දැක්වීම වෙනස් වුවහොත් එනුම් ප්‍රභේදයක වෙනස්කම් කිරීම වෙනස් විය හැකිය.
/// කිසියම් ප්‍රභේදයක වෙනස් කොට සැලකීම එකම සම්පාදකයා සමඟ සම්පාදනය අතර වෙනස් නොවේ.
///
/// # Examples
///
/// සත්‍ය දත්ත නොසලකා හරිමින් දත්ත රැගෙන යන එනූම් සංසන්දනය කිරීමට මෙය භාවිතා කළ හැකිය:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// එනුම් වර්ගය `T` හි ප්‍රභේද ගණන ලබා දෙයි.
///
/// `T` යනු එනුම් එකක් නොවේ නම්, මෙම ශ්‍රිතය ඇමතීමෙන් නිර්වචනය නොකළ හැසිරීමක් ඇති නොවනු ඇත, නමුත් ප්‍රතිලාභ අගය නිශ්චිතව දක්වා නැත.
/// ඒ හා සමානව, `T` යනු `usize::MAX` ට වඩා වැඩි ප්‍රභේදයක් සහිත එනූමයක් නම් ප්‍රතිලාභ අගය නිශ්චිතව දක්වා නැත.
/// ජනාවාස නොවන ප්‍රභේද ගණනය කෙරේ.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}