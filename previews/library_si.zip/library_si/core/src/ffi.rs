#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! විදේශීය ශ්‍රිත අතුරුමුහුණත (FFI) බන්ධන හා සම්බන්ධ උපයෝගිතා.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// [pointer] ලෙස භාවිතා කරන විට C හි `void` වර්ගයට සමාන වේ.
///
/// සාරාංශයක් ලෙස, `*const c_void` යනු C හි `const void*` හා `*mut c_void` C හි `void*` ට සමාන වේ.
/// එයින් කියැවෙන්නේ මෙය C හි `void` ප්‍රතිලාභ වර්ගයට සමාන නොවන බවයි, එය Rust හි `()` වර්ගයයි.
///
/// `extern type` ස්ථාවර වන තුරු, එෆ්එෆ්අයි හි පාරාන්ධව වර්ග සඳහා දර්ශකයන් ආකෘතිගත කිරීම සඳහා, හිස් බයිට් අරා වටා newtype එතීම භාවිතා කිරීම රෙකමදාරු කරනු ලැබේ.
///
/// විස්තර සඳහා [Nomicon] බලන්න.
///
/// 1.1.0 දක්වා පැරණි Rust සම්පාදකයාට සහය දැක්වීමට අවශ්‍ය නම් කෙනෙකුට `std::os::raw::c_void` භාවිතා කළ හැකිය.
/// Rust 1.30.0 පසු, මෙම නිර්වචනය අනුව එය නැවත අපනයනය කරන ලදි.
/// වැඩි විස්තර සඳහා කරුණාකර [RFC 2521] කියවන්න.
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// සැ.යු, LLVM සඳහා අවලංගු දර්ශක වර්ගය හඳුනා ගැනීමට සහ malloc() වැනි විස්තාරණ ශ්‍රිතයන්ට අනුව, එය LLVM බිට්කෝඩ් හි i8 * ලෙස නිරූපණය කළ යුතුය.
// මෙහි භාවිතා කරන එනූම් මෙය සහතික කරන අතර පුද්ගලික ප්‍රභේද පමණක් තිබීමෙන් "raw" වර්ගය අනිසි ලෙස භාවිතා කිරීම වළක්වයි.
// අපට ප්‍රභේද දෙකක් අවශ්‍යය, මන්දයත් සම්පාදකයා විසින් repr ගුණාංගය ගැන වෙනත් ආකාරයකින් පැමිණිලි කරන අතර අපට අවම වශයෙන් එක් ප්‍රභේදයක්වත් අවශ්‍ය වන අතර එසේ නොවුවහොත් එනුම් ජනාවාස නොවන අතර අවම වශයෙන් එවැනි දර්ශකයන් අවලංගු කිරීම UB වේ.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// `va_list` හි මූලික ක්‍රියාත්මක කිරීම.
// නම WIP, දැනට `VaListImpl` භාවිතා කරයි.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // `'f` ට වඩා වෙනස් නොවේ, එබැවින් සෑම `VaListImpl<'f>` වස්තුවක්ම එය අර්ථ දක්වා ඇති ශ්‍රිතයේ කලාපයට බැඳී ඇත
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 ABI `va_list` ක්‍රියාත්මක කිරීම.
/// වැඩි විස්තර සඳහා [AArch64 Procedure Call Standard] බලන්න.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC ABI `va_list` ක්‍රියාත්මක කිරීම.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 ABI `va_list` ක්‍රියාත්මක කිරීම.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// `va_list` සඳහා එතුම
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// C හි `va_list` සමඟ ද්විමය අනුකූල වන `VaListImpl` `VaList` බවට පරිවර්තනය කරන්න.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// C හි `va_list` සමඟ ද්විමය අනුකූල වන `VaListImpl` `VaList` බවට පරිවර්තනය කරන්න.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe trait පොදු අතුරුමුහුණත් වල භාවිතා කළ යුතුය, කෙසේ වෙතත්, trait මෙම මොඩියුලයෙන් පිටත භාවිතා කිරීමට ඉඩ නොදිය යුතුය.
// නව වර්ගයක් සඳහා trait ක්‍රියාත්මක කිරීමට පරිශීලකයින්ට ඉඩ දීම (එමඟින් va_arg සහජයෙන්ම නව වර්ගයක් භාවිතා කිරීමට ඉඩ ලබා දේ) නිර්වචනය නොකළ හැසිරීමට හේතු වේ.
//
// FIXME(dlrobertson): VaArgSafe trait පොදු අතුරුමුහුණතක් තුළ භාවිතා කිරීම සඳහා පමණක් නොව එය වෙනත් තැනක භාවිතා කළ නොහැකි බව සහතික කිරීම සඳහා, trait පුද්ගලික මොඩියුලයක් තුළ පොදු විය යුතුය.
// RFC 2145 ක්‍රියාත්මක කිරීමෙන් පසු මෙය වැඩිදියුණු කිරීම පිළිබඳව සොයා බලන්න.
//
//
//
//
mod sealed_trait {
    /// [super::VaListImpl::arg] සමඟ අවසර ලත් වර්ග භාවිතා කිරීමට අවසර දෙන Trait.
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// ඊළඟ තර්කයට ඉදිරියට යන්න.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // ආරක්ෂාව: අමතන්නා `va_arg` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය.
        unsafe { va_arg(self) }
    }

    /// වත්මන් ස්ථානයේ `va_list` පිටපත් කරයි.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // ආරක්ෂාව: අමතන්නා `va_end` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // ආරක්ෂාව: අපි `MaybeUninit` වෙත ලියන්නෙමු, එබැවින් එය ආරම්භ කර ඇති අතර `assume_init` නීත්‍යානුකූල වේ
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: මෙය `va_end` අමතන්න, නමුත් පිරිසිදු ක්‍රමයක් නොමැත
        // `drop` සෑම විටම එහි ඇමතුමට නැඹුරු වන බවට සහතික වන්න, එබැවින් `va_end` අනුරූප `va_copy` හා සමාන ශ්‍රිතයකින් කෙලින්ම කැඳවනු ඇත.
        // `man va_end` C ට මෙය අවශ්‍ය බව පවසන අතර LLVM මූලික වශයෙන් C අර්ථ නිරූපණය අනුගමනය කරයි, එබැවින් `va_end` සෑම විටම `va_copy` හා සමාන ශ්‍රිතයකින් කැඳවන බවට අප සහතික විය යුතුය.
        //
        // වැඩි විස්තර සඳහා, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // මෙය දැනට ක්‍රියාත්මක වන්නේ `va_end` යනු දැනට පවතින සියලුම LLVM ඉලක්ක සඳහා විකල්පයක් නොවන බැවිනි.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// `va_start` හෝ `va_copy` සමඟ ආරම්භ කිරීමෙන් පසු ආර්ග්ලිස්ට් `ap` විනාශ කරන්න.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// ආර්ග්ලිස්ට් `src` හි වත්මන් ස්ථානය ආර්ග්ලිස්ට් `dst` වෙත පිටපත් කරයි.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// `va_list` `ap` වෙතින් `T` වර්ගයේ තර්කයක් පටවා `ap` ලක්ෂ්‍යය දක්වා තර්කය වැඩි කරන්න.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}