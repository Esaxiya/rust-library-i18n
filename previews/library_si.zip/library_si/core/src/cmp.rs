//! ඇණවුම් කිරීම හා සංසන්දනය කිරීම සඳහා ක්‍රියාකාරීත්වය.
//!
//! මෙම මොඩියුලයේ අගයන් ඇණවුම් කිරීම හා සංසන්දනය කිරීම සඳහා විවිධ මෙවලම් අඩංගු වේ.සාරාංශයකින්:
//!
//! * [`Eq`] සහ [`PartialEq`] යනු traits වන අතර එය පිළිවෙලින් අගයන් අතර සම්පූර්ණ හා අර්ධ සමානාත්මතාවය අර්ථ දැක්වීමට ඉඩ සලසයි.
//! ඒවා ක්‍රියාත්මක කිරීමෙන් `==` සහ `!=` ක්‍රියාකරුවන් අධික ලෙස පටවනු ලැබේ.
//! * [`Ord`] සහ [`PartialOrd`] යනු traits වන අතර ඒවා පිළිවෙලින් අගයන් අතර සම්පූර්ණ හා අර්ධ අනුපිළිවෙල අර්ථ දැක්වීමට ඉඩ සලසයි.
//!
//! ඒවා ක්‍රියාත්මක කිරීමෙන් `<`, `<=`, `>`, සහ `>=` ක්‍රියාකරුවන් අධික ලෙස පටවනු ලැබේ.
//! * [`Ordering`] යනු [`Ord`] සහ [`PartialOrd`] හි ප්‍රධාන කාර්යයන් මගින් ආපසු ලබා දෙන ලද එනූම් එකක් වන අතර එය ඇණවුමක් විස්තර කරයි.
//! * [`Reverse`] ඇණවුමක් පහසුවෙන් ආපසු හැරවීමට ඔබට ඉඩ සලසන ව්‍යුහයකි.
//! * [`max`] සහ [`min`] යනු [`Ord`] වලින් සාදන ලද කාර්යයන් වන අතර උපරිම හෝ අවම අගයන් දෙකක් සොයා ගැනීමට ඔබට ඉඩ සලසයි.
//!
//! වැඩි විස්තර සඳහා, ලැයිස්තුවේ ඇති එක් එක් අයිතමයේ අදාළ ලියකියවිලි බලන්න.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation) වන සමානාත්මතා සැසඳීම් සඳහා Trait.
///
/// මෙම trait පූර්ණ සමානතා සම්බන්ධතාවයක් නොමැති වර්ග සඳහා අර්ධ සමානාත්මතාවයට ඉඩ දෙයි.
/// උදාහරණයක් ලෙස, පාවෙන ලක්ෂ්‍ය අංක `NaN != NaN` හි, එබැවින් පාවෙන ලක්ෂ්‍ය වර්ග `PartialEq` ක්‍රියාත්මක කරන නමුත් [`trait@Eq`] නොවේ.
///
/// විධිමත් ලෙස, සමානාත්මතාවය විය යුතුය (සියලුම `a`, `b`, `c` වර්ගයේ `A`, `B`, `C` සඳහා):
///
/// - **සමමිතික**: `A: PartialEq<B>` සහ `B: PartialEq<A>` නම්,**`a==b` යන්නෙන් අදහස් කරන්නේ`b==a`**;සහ
///
/// - **සංක්‍රාන්ති**: `A: PartialEq<B>` සහ `B: PartialEq<C>` සහ `A: නම්:
///   PartialEq<C>`, එවිට **` a==b`සහ `b == c` යන්නෙන් අදහස් කරන්නේ`a==c`**.
///
/// `B: PartialEq<A>` (symmetric) සහ `A: PartialEq<C>` (transitive) impls පැවතීමට බල නොකරන බව සලකන්න, නමුත් මෙම අවශ්‍යතා පවතින සෑම විටම අදාළ වේ.
///
/// ## Derivable
///
/// මෙම trait `#[derive]` සමඟ භාවිතා කළ හැකිය.ව්‍යුහයන් මත ව්‍යුත්පන්න වූ විට, සියලු ක්ෂේත්‍ර සමාන නම් අවස්ථා දෙකක් සමාන වන අතර කිසියම් ක්ෂේත්‍රයක් සමාන නොවේ නම් සමාන නොවේ.එනූම්ස් මත ව්‍යුත්පන්න වූ විට, සෑම ප්‍රභේදයක්ම තමාට සමාන වන අතර අනෙක් ප්‍රභේදයන්ට සමාන නොවේ.
///
/// ## `PartialEq` ක්‍රියාත්මක කරන්නේ කෙසේද?
///
/// `PartialEq` ක්‍රියාත්මක කිරීමට අවශ්‍ය වන්නේ [`eq`] ක්‍රමය පමණි;[`ne`] පෙරනිමියෙන් එය අර්ථ දක්වා ඇත.[`ne`]*හි ඕනෑම අතින් ක්‍රියාත්මක කිරීම*[`eq`] යනු [`ne`] හි දැඩි ප්‍රතිලෝමයක් යන රීතියට ගරු කළ යුතුය;එනම්, `!(a == b)` නම් සහ `a != b` නම් පමණි.
///
/// `PartialEq`, [`PartialOrd`], සහ [`Ord`]*ක්‍රියාත්මක කිරීම* එකිනෙකා සමඟ එකඟ විය යුතුය.සමහර traits ව්‍යුත්පන්න කිරීමෙන් සහ අනෙක් ඒවා අතින් ක්‍රියාත්මක කිරීමෙන් අහම්බෙන් ඔවුන් එකඟ නොවීම පහසුය.
///
/// අයිඑස්බීඑන් ගැලපෙන්නේ නම්, ආකෘතීන් එකිනෙකට වෙනස් වුවත්, පොත් දෙකක් එකම පොතක් ලෙස සලකන වසමක් සඳහා උදාහරණ ක්‍රියාත්මක කිරීම:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## විවිධ වර්ග දෙකක් සංසන්දනය කරන්නේ කෙසේද?
///
/// ඔබට සැසඳිය හැකි වර්ගය පාලනය කරනු ලබන්නේ `PartialEq` වර්ගයේ පරාමිතිය මගිනි.
/// උදාහරණයක් ලෙස, අපගේ පෙර කේතය ටිකක් වෙනස් කරමු:
///
/// ```
/// // ව්‍යුත්පන්න උපකරණ<BookFormat>==<BookFormat>සැසඳීම්
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // ක්‍රියාත්මක කිරීම<Book>==<BookFormat>සැසඳීම්
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // ක්‍රියාත්මක කිරීම<BookFormat>==<Book>සැසඳීම්
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// `impl PartialEq for Book` සිට `impl PartialEq<BookFormat> for Book` දක්වා වෙනස් කිරීමෙන්, අපි 'පොත් ෆෝමැට්' පොත් සමඟ සැසඳීමට ඉඩ දෙමු.
///
/// ව්‍යුහයේ සමහර ක්ෂේත්‍ර නොසලකා හරින ඉහත ආකාරයට සමාන කිරීම භයානක විය හැකිය.අර්ධ සමානතා සම්බන්ධතාවයක් සඳහා වන අවශ්‍යතා අනපේක්ෂිත ලෙස උල්ලං to නය කිරීමකට එය පහසුවෙන්ම හේතු විය හැකිය.
/// උදාහරණයක් ලෙස, අපි ඉහත `PartialEq<Book>` `BookFormat` සඳහා ක්‍රියාත්මක කර `Book` සඳහා `PartialEq<Book>` ක්‍රියාත්මක කිරීමක් එකතු කළහොත් (එක්කෝ `#[derive]` හරහා හෝ පළමු උදාහරණයෙන් අතින් ක්‍රියාත්මක කිරීම හරහා) එවිට ප්‍රති result ලය පාරදෘශ්‍යතාව උල්ලං would නය වේ:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// මෙම ක්‍රමය `self` සහ `other` අගයන් සමානදැයි පරීක්ෂා කරන අතර එය `==` භාවිතා කරයි.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// මෙම ක්‍රමය `!=` සඳහා පරීක්ෂා කරයි.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// trait `PartialEq` හි ආවේගයක් ජනනය කරන ව්‍යුත්පන්න සාර්ව.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation) වන සමානාත්මතා සැසඳීම් සඳහා Trait.
///
/// මෙයින් අදහස් කරන්නේ, `a == b` සහ `a != b` දැඩි ප්‍රතිලෝම වීමට අමතරව, සමානාත්මතාවය (සියලුම `a`, `b` සහ `c` සඳහා) විය යුතුය:
///
/// - reflexive: `a == a`;
/// - සමමිතික: `a == b` යන්නෙන් අදහස් කරන්නේ `b == a`;සහ
/// - සංක්‍රාන්තික: `a == b` සහ `b == c` යන්නෙන් අදහස් කරන්නේ `a == c` ය.
///
/// මෙම දේපල සම්පාදකයාට පරීක්ෂා කළ නොහැකි අතර, එබැවින් `Eq` යන්නෙන් [`PartialEq`] අදහස් වන අතර අමතර ක්‍රම නොමැත.
///
/// ## Derivable
///
/// මෙම trait `#[derive]` සමඟ භාවිතා කළ හැකිය.
/// `Eq` ට අමතර ක්‍රමවේදයන් නොමැති නිසා, ව්‍යුත්පන්න කළ විට, එය සම්පාදකයාට දැනුම් දෙන්නේ මෙය අර්ධ සමානතා සම්බන්ධතාවයකට වඩා සමානතා සම්බන්ධතාවයක් බවයි.
///
/// `derive` උපාය මාර්ගයට සෑම ක්ෂේත්‍රයක්ම `Eq` අවශ්‍ය බව සලකන්න, එය සැමවිටම අපේක්ෂා නොකරයි.
///
/// ## `Eq` ක්‍රියාත්මක කරන්නේ කෙසේද?
///
/// ඔබට `derive` උපායමාර්ගය භාවිතා කළ නොහැකි නම්, ඔබේ වර්ගය `Eq` ක්‍රියාත්මක කරන බව සඳහන් කරන්න, එයට ක්‍රම නොමැත.
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // මෙම ක්‍රමය තනිකරම භාවිතා කරන්නේ#[ව්‍යුත්පන්න] වර්ගයක සෑම අංගයක්ම#[ව්‍යුත්පන්න] ක්‍රියාත්මක කරන බව ප්‍රකාශ කිරීම සඳහාය, වර්තමාන ව්‍යුත්පන්න යටිතල ව්‍යුහය යන්නෙන් අදහස් කරන්නේ මෙම trait හි ක්‍රමයක් භාවිතා නොකර මෙම ප්‍රකාශය කළ නොහැකි බවය.
    //
    //
    // මෙය කිසි විටෙකත් අතින් ක්‍රියාත්මක නොකළ යුතුය.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// trait `Eq` හි ආවේගයක් ජනනය කරන ව්‍යුත්පන්න සාර්ව.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: මෙම ව්‍යුහය භාවිතා කරනුයේ#[ව්‍යුත්පන්න] සිට පමණි
// වර්ගයක සෑම අංගයක්ම Eq ක්‍රියාත්මක කරන බව ප්‍රකාශ කරන්න.
//
// මෙම ව්‍යුහය කිසි විටෙක පරිශීලක කේතයේ නොපෙන්විය යුතුය.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Ordering` යනු අගයන් දෙකක් අතර සංසන්දනයක ප්‍රති result ලයකි.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// සංසන්දනාත්මක අගයක් තවත් අගයකට වඩා අඩු තැනක ඇණවුම් කිරීම.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// සංසන්දනාත්මක අගයක් තවත් අගයකට සමාන වන අනුපිළිවෙලක්.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// සංසන්දනාත්මක අගයක් තවත් අගයකට වඩා වැඩි ඇණවුමක්.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// ඇණවුම් කිරීම `Equal` ප්‍රභේදය නම් `true` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// ඇණවුම් කිරීම `Equal` ප්‍රභේදය නොවේ නම් `true` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// ඇණවුම් කිරීම `Less` ප්‍රභේදය නම් `true` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// ඇණවුම් කිරීම `Greater` ප්‍රභේදය නම් `true` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// ඇණවුම් කිරීම `Less` හෝ `Equal` ප්‍රභේදය නම් `true` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// ඇණවුම් කිරීම `Greater` හෝ `Equal` ප්‍රභේදය නම් `true` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// `Ordering` ආපසු හරවයි.
    ///
    /// * `Less` `Greater` බවට පත්වේ.
    /// * `Greater` `Less` බවට පත්වේ.
    /// * `Equal` `Equal` බවට පත්වේ.
    ///
    /// # Examples
    ///
    /// මූලික හැසිරීම:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// සංසන්දනයක් ආපසු හැරවීමට මෙම ක්‍රමය භාවිතා කළ හැකිය:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // අරාව විශාලතම සිට කුඩාම දක්වා වර්ග කරන්න.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// දම්වැල් ඇණවුම් දෙකක්.
    ///
    /// `Equal` නොවන විට `self` ලබා දෙයි.එසේ නොමැතිනම් `other` ආපසු ලබා දේ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// දී ඇති ශ්‍රිතය සමඟ ඇණවුම් කිරීම.
    ///
    /// `Equal` නොවන විට `self` ලබා දෙයි.
    /// එසේ නොමැතිනම් `f` අමතා ප්‍රති .ලය ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// ප්‍රතිලෝම ඇණවුම් කිරීම සඳහා සහායක ව්‍යුහයකි.
///
/// මෙම ව්‍යුහය [`Vec::sort_by_key`] වැනි ශ්‍රිත සමඟ භාවිතා කළ හැකි සහායකයකු වන අතර යතුරක කොටසක් ආපසු හැරවීමට භාවිතා කළ හැකිය.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// [total order](https://en.wikipedia.org/wiki/Total_order) සාදන වර්ග සඳහා Trait.
///
/// ඇණවුමක් නම් එය සම්පූර්ණ ඇණවුමකි (සියලුම `a`, `b` සහ `c` සඳහා):
///
/// - සම්පූර්ණ සහ අසමමිතික: හරියටම `a < b`, `a == b` හෝ `a > b` වලින් එකක් සත්‍ය වේ;සහ
/// - සංක්‍රාන්ති, `a < b` සහ `b < c` යන්නෙන් අදහස් කරන්නේ `a < c` යන්නයි.`==` සහ `>` යන දෙකටම සමාන විය යුතුය.
///
/// ## Derivable
///
/// මෙම trait `#[derive]` සමඟ භාවිතා කළ හැකිය.
/// ව්‍යුහයන් මත ව්‍යුත්පන්න වූ විට, එය ව්‍යුහයේ සාමාජිකයන්ගේ ඉහළ සිට පහළට ප්‍රකාශන අනුපිළිවෙල මත පදනම්ව [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) ඇණවුමක් නිපදවනු ඇත.
///
/// එනූම්ස් මත ව්‍යුත්පන්න වූ විට, ප්‍රභේදයන් ඉහළ සිට පහළට වෙනස් කොට සැලකීමේ අනුපිළිවෙල අනුව ඇණවුම් කෙරේ.
///
/// ## ශබ්දකෝෂ සංසන්දනය
///
/// ශබ්දකෝෂ සංසන්දනය යනු පහත සඳහන් ගුණාංග සහිත මෙහෙයුමකි:
///  - අනුපිළිවෙල දෙකක් මූලද්‍රව්‍යය අනුව සැසඳේ.
///  - පළමු නොගැලපීමේ මූලද්‍රව්‍යය ශබ්දකෝෂ විද්‍යාත්මකව අනෙක් අනුපිළිවෙලට වඩා අඩු හෝ වැඩි වන්නේ කුමන අනුක්‍රමයද යන්න නිර්වචනය කරයි.
///  - එක් අනුක්‍රමයක් තවත් අනුපිළිවෙලක් නම්, කෙටි අනුක්‍රමය ශබ්ද කෝෂමය වශයෙන් අනෙක් ඒවාට වඩා අඩුය.
///  - අනුක්‍රම දෙකකට සමාන මූලද්‍රව්‍යයන් ඇති අතර එකම දිගකින් යුක්ත නම්, අනුක්‍රමයන් ශබ්දකෝෂ විද්‍යාත්මකව සමාන වේ.
///  - හිස් අනුක්‍රමයක් ශබ්දකෝෂමය වශයෙන් කිසිදු හිස් නොවන අනුක්‍රමයකට වඩා අඩුය.
///  - හිස් අනුපිළිවෙලවල් දෙකක් ශබ්දකෝෂ විද්‍යාත්මකව සමාන වේ.
///
/// ## `Ord` ක්‍රියාත්මක කරන්නේ කෙසේද?
///
/// `Ord` වර්ගය [`PartialOrd`] සහ [`Eq`] විය යුතුය (එයට [`PartialEq`] අවශ්‍ය වේ).
///
/// එවිට ඔබ [`cmp`] සඳහා ක්‍රියාත්මක කිරීමක් අර්ථ දැක්විය යුතුය.ඔබේ වර්ගයේ ක්ෂේත්‍රවල [`cmp`] භාවිතා කිරීම ඔබට ප්‍රයෝජනවත් විය හැකිය.
///
/// [`PartialEq`], [`PartialOrd`], සහ `Ord`*ක්‍රියාත්මක කිරීම* එකිනෙකා සමඟ එකඟ විය යුතුය.
/// එනම්, `a.cmp(b) == Ordering::Equal` නම් සහ සියලු `a` සහ `b` සඳහා `a == b` සහ `Some(a.cmp(b)) == a.partial_cmp(b)` නම් පමණි.
/// සමහර traits ව්‍යුත්පන්න කිරීමෙන් සහ අනෙක් ඒවා අතින් ක්‍රියාත්මක කිරීමෙන් අහම්බෙන් ඔවුන් එකඟ නොවීම පහසුය.
///
/// `id` සහ `name` නොසලකා හරිමින් උසින් පමණක් පුද්ගලයින් වර්ග කිරීමට ඔබට අවශ්‍ය උදාහරණයක් මෙන්න:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// මෙම ක්‍රමය `self` සහ `other` අතර [`Ordering`] ලබා දෙයි.
    ///
    /// සම්මුතිය අනුව, `self.cmp(&other)` සත්‍ය නම් `self <operator> other` ප්‍රකාශනයට ගැලපෙන ඇණවුම ලබා දෙයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// උපරිම අගයන් දෙකක් සංසන්දනය කර ආපසු ලබා දේ.
    ///
    /// සංසන්දනය ඒවා සමාන යැයි තීරණය කරන්නේ නම් දෙවන තර්කය ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// අවම අගයන් දෙකක් සංසන්දනය කර ආපසු ලබා දේ.
    ///
    /// සංසන්දනය ඒවා සමාන යැයි තීරණය කරන්නේ නම් පළමු තර්කය ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// අගය යම් කාල සීමාවකට සීමා කරන්න.
    ///
    /// `self` `max` ට වඩා වැඩි නම් `max` ද, `self` `min` ට වඩා අඩු නම් `min` ද ලබා දෙයි.
    /// එසේ නොමැතිනම් මෙය `self` ආපසු ලබා දෙයි.
    ///
    /// # Panics
    ///
    /// `min > max` නම් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// trait `Ord` හි ආවේගයක් ජනනය කරන ව්‍යුත්පන්න සාර්ව.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// වර්ග කිරීමේ අනුපිළිවෙලක් සඳහා සැසඳිය හැකි අගයන් සඳහා Trait.
///
/// සියලු `a`, `b` සහ `c` සඳහා සංසන්දනය සෑහීමකට පත්විය යුතුය:
///
/// - අසමමිතිය: `a < b` නම් `!(a > b)`, මෙන්ම `a > b` අඟවන `!(a < b)`;සහ
/// - පාරදෘශ්‍යතාව: `a < b` සහ `b < c` යන්නෙන් අදහස් කරන්නේ `a < c` යන්නයි.`==` සහ `>` යන දෙකටම සමාන විය යුතුය.
///
/// මෙම අවශ්‍යතා වලින් අදහස් වන්නේ trait ම සමමිතිකව හා සංක්‍රාන්තිකව ක්‍රියාත්මක කළ යුතු බවයි: `T: PartialOrd<U>` සහ `U: PartialOrd<V>` නම් `U: PartialOrd<T>` සහ `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// මෙම trait `#[derive]` සමඟ භාවිතා කළ හැකිය.ව්‍යුහයන් මත ව්‍යුත්පන්න වූ විට, එය ව්‍යුහයේ සාමාජිකයන්ගේ ඉහළ සිට පහළට ප්‍රකාශන අනුපිළිවෙල මත පදනම්ව ශබ්දකෝෂ අනුපිළිවෙලක් නිපදවනු ඇත.
/// එනූම්ස් මත ව්‍යුත්පන්න වූ විට, ප්‍රභේදයන් ඉහළ සිට පහළට වෙනස් කොට සැලකීමේ අනුපිළිවෙල අනුව ඇණවුම් කෙරේ.
///
/// ## `PartialOrd` ක්‍රියාත්මක කරන්නේ කෙසේද?
///
/// `PartialOrd` [`partial_cmp`] ක්‍රමය ක්‍රියාත්මක කිරීම පමණක් අවශ්‍ය වන අතර අනෙක් ඒවා පෙරනිමි ක්‍රියාත්මක කිරීම් වලින් ජනනය වේ.
///
/// කෙසේ වෙතත්, සම්පූර්ණ අනුපිළිවෙලක් නොමැති වර්ග සඳහා අනෙක් ඒවා වෙන වෙනම ක්‍රියාත්මක කළ හැකිය.
/// උදාහරණයක් ලෙස, පාවෙන ලක්ෂ්‍ය අංක සඳහා, `NaN < 0 == false` සහ `NaN >= 0 == false` (cf.
/// IEEE 754-2008 කොටස 5.11).
///
/// `PartialOrd` ඔබේ වර්ගය [`PartialEq`] විය යුතුය.
///
/// [`PartialEq`], `PartialOrd`, සහ [`Ord`]*ක්‍රියාත්මක කිරීම* එකිනෙකා සමඟ එකඟ විය යුතුය.
/// සමහර traits ව්‍යුත්පන්න කිරීමෙන් සහ අනෙක් ඒවා අතින් ක්‍රියාත්මක කිරීමෙන් අහම්බෙන් ඔවුන් එකඟ නොවීම පහසුය.
///
/// ඔබේ වර්ගය [`Ord`] නම්, ඔබට [`cmp`] භාවිතා කිරීමෙන් [`partial_cmp`] ක්‍රියාත්මක කළ හැකිය:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// ඔබේ වර්ගයේ ක්ෂේත්‍රවල [`partial_cmp`] භාවිතා කිරීමද ඔබට ප්‍රයෝජනවත් විය හැකිය.
/// වර්ග කිරීම සඳහා භාවිතා කළ හැකි එකම ක්ෂේත්‍රය වන පාවෙන ලක්ෂ්‍ය `height` ක්ෂේත්‍රයක් ඇති `Person` වර්ග සඳහා උදාහරණයක් මෙන්න:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// මෙම ක්‍රමය `self` සහ `other` අගයන් අතර ඇණවුමක් තිබේ නම් ඒවා ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// සංසන්දනය කළ නොහැකි විට:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// මෙම ක්‍රමය (`self` සහ `other` සඳහා) වඩා අඩුවෙන් පරික්ෂා කරන අතර එය `<` ක්‍රියාකරු විසින් භාවිතා කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// මෙම ක්‍රමය (`self` සහ `other` සඳහා) වඩා අඩු හෝ සමාන වන අතර එය `<=` ක්‍රියාකරු විසින් භාවිතා කරයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// මෙම ක්‍රමය (`self` සහ `other` සඳහා) වඩා විශාල ලෙස පරික්ෂා කරන අතර එය `>` ක්‍රියාකරු විසින් භාවිතා කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// මෙම ක්‍රමය (`self` සහ `other` සඳහා) වඩා වැඩි හෝ සමාන වන අතර එය `>=` ක්‍රියාකරු විසින් භාවිතා කරයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// trait `PartialOrd` හි ආවේගයක් ජනනය කරන ව්‍යුත්පන්න සාර්ව.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// අවම අගයන් දෙකක් සංසන්දනය කර ආපසු ලබා දේ.
///
/// සංසන්දනය ඒවා සමාන යැයි තීරණය කරන්නේ නම් පළමු තර්කය ලබා දෙයි.
///
/// අභ්‍යන්තරව [`Ord::min`] වෙත අන්වර්ථයක් භාවිතා කරයි.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// නිශ්චිත සංසන්දනාත්මක ශ්‍රිතයට සාපේක්ෂව අවම අගයන් දෙකක් ලබා දෙයි.
///
/// සංසන්දනය ඒවා සමාන යැයි තීරණය කරන්නේ නම් පළමු තර්කය ලබා දෙයි.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// නිශ්චිත ශ්‍රිතයෙන් අවම අගයක් ලබා දෙන මූලද්‍රව්‍යය ලබා දෙයි.
///
/// සංසන්දනය ඒවා සමාන යැයි තීරණය කරන්නේ නම් පළමු තර්කය ලබා දෙයි.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// උපරිම අගයන් දෙකක් සංසන්දනය කර ආපසු ලබා දේ.
///
/// සංසන්දනය ඒවා සමාන යැයි තීරණය කරන්නේ නම් දෙවන තර්කය ලබා දෙයි.
///
/// අභ්‍යන්තරව [`Ord::max`] වෙත අන්වර්ථයක් භාවිතා කරයි.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// නිශ්චිත සංසන්දනාත්මක ශ්‍රිතයට සාපේක්ෂව උපරිම අගයන් දෙකක ප්‍රතිලාභ ලබා දෙයි.
///
/// සංසන්දනය ඒවා සමාන යැයි තීරණය කරන්නේ නම් දෙවන තර්කය ලබා දෙයි.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// නිශ්චිත ශ්‍රිතයෙන් උපරිම අගය ලබා දෙන මූලද්‍රව්‍යය ලබා දෙයි.
///
/// සංසන්දනය ඒවා සමාන යැයි තීරණය කරන්නේ නම් දෙවන තර්කය ලබා දෙයි.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// ප්‍රාථමික වර්ග සඳහා PartialEq, Eq, PartialOrd සහ Ord ක්‍රියාත්මක කිරීම
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // වඩාත් ප්‍රශස්ත එකලස් කිරීමක් ජනනය කිරීම සඳහා මෙහි අනුපිළිවෙල වැදගත් වේ.
                    // වැඩි විස්තර සඳහා <https://github.com/rust-lang/rust/issues/63758> බලන්න.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // I8 වෙත වාත්තු කිරීම සහ ඇණවුමකට වෙනස පරිවර්තනය කිරීම වඩාත් ප්‍රශස්ත එකලස් කිරීමක් ජනනය කරයි.
            //
            // වැඩි විස්තර සඳහා <https://github.com/rust-lang/rust/issues/66780> බලන්න.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // සුරක්ෂිතභාවය: i8 ලෙස bool 0 හෝ 1 ලබා දෙයි, එබැවින් වෙනස වෙන කිසිවක් විය නොහැක
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // සහ දර්ශකයන්

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}