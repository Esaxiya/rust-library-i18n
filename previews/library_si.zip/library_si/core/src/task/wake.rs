#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` මඟින් කාර්ය විධායකය ක්‍රියාත්මක කරන්නාට [`Waker`] නිර්මාණය කිරීමට ඉඩ සලසයි.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// එය දත්ත දර්ශකයක් සහ X001 හි හැසිරීම රිසිකරණය කරන [virtual function pointer table (vtable)][vtable] වලින් සමන්විත වේ.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// දත්ත දර්ශකය, එය ක්‍රියාත්මක කරන්නාට අවශ්‍ය පරිදි අත්තනෝමතික දත්ත ගබඩා කිරීමට භාවිතා කළ හැකිය.
    /// මෙය උදා
    /// කාර්යය හා සම්බන්ධ `Arc` වෙත ටයිප්-මකා දැමූ දර්ශකයක්.
    /// මෙම ක්ෂේත්‍රයේ වටිනාකම පළමු පරාමිතිය ලෙස vtable හි කොටසක් වන සියලුම කාර්යයන් වෙත ලබා දේ.
    ///
    data: *const (),
    /// මෙම වේකර්ගේ හැසිරීම රිසිකරණය කරන අතථ්‍ය ශ්‍රිත දර්ශක වගුව.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// සපයා ඇති `data` දර්ශකය සහ `vtable` වෙතින් නව `RawWaker` සාදයි.
    ///
    /// විධායකයාට අවශ්‍ය පරිදි අත්තනෝමතික දත්ත ගබඩා කිරීම සඳහා `data` දර්ශකය භාවිතා කළ හැකිය.මෙය උදා
    /// කාර්යය හා සම්බන්ධ `Arc` වෙත ටයිප්-මකා දැමූ දර්ශකයක්.
    /// මෙම දර්ශකයේ අගය පළමු පරාමිතිය ලෙස `vtable` හි කොටසක් වන සියලුම කාර්යයන් වෙත ලබා දෙනු ඇත.
    ///
    /// `vtable` `RawWaker` වෙතින් නිර්මාණය වන `Waker` හි හැසිරීම රිසිකරණය කරයි.
    /// `Waker` හි එක් එක් මෙහෙයුම සඳහා, යටින් පවතින `RawWaker` හි `vtable` හි සම්බන්ධිත ශ්‍රිතය කැඳවනු ලැබේ.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// [`RawWaker`] හි හැසිරීම නියම කරන අතථ්‍ය ශ්‍රිත දර්ශක වගුව (vtable).
///
/// Vtable තුළ ඇති සියලුම කාර්යයන් සඳහා යොමු කරන ලද දර්ශකය වන්නේ සංවෘත [`RawWaker`] වස්තුවෙන් `data` දර්ශකයයි.
///
/// මෙම ව්‍යුහය තුළ ඇති කාර්යයන් [`RawWaker`] ක්‍රියාත්මක කිරීමේදී ඇතුළත සිට නිසියාකාරව ඉදිකරන ලද [`RawWaker`] වස්තුවක `data` දර්ශකය මත කැඳවීමට අදහස් කෙරේ.
/// වෙනත් ඕනෑම `data` දර්ශකයක් භාවිතා කර අඩංගු එක් කාර්යයක් ඇමතීමෙන් නිර්වචනය නොකළ හැසිරීමට හේතු වේ.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// [`RawWaker`] ක්ලෝන වූ විට මෙම ශ්‍රිතය කැඳවනු ලැබේ, උදා: [`RawWaker`] ගබඩා කර ඇති [`Waker`] ක්ලෝන වූ විට.
    ///
    /// මෙම ශ්‍රිතය ක්‍රියාත්මක කිරීමේදී [`RawWaker`] සහ ඊට සම්බන්ධ කාර්යයක මෙම අතිරේක අවස්ථාව සඳහා අවශ්‍ය සියලු සම්පත් රඳවා ගත යුතුය.
    /// එහි ප්‍රති ing ලයක් වන [`RawWaker`] වෙත `wake` ඇමතීමෙන් මුල් [`RawWaker`] විසින් අවදි කරනු ලැබූ එම කාර්යයම අවදි විය යුතුය.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// [`Waker`] හි `wake` ඇමතූ විට මෙම ශ්‍රිතය කැඳවනු ලැබේ.
    /// මෙම [`RawWaker`] හා සම්බන්ධ කාර්යය අවදි කළ යුතුය.
    ///
    /// මෙම ශ්‍රිතය ක්‍රියාත්මක කිරීම මඟින් [`RawWaker`] හා ඒ හා සම්බන්ධ කාර්යයක මෙම අවස්ථාව හා සම්බන්ධ ඕනෑම සම්පත් නිදහස් කිරීමට වග බලා ගත යුතුය.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// [`Waker`] හි `wake_by_ref` ඇමතූ විට මෙම ශ්‍රිතය කැඳවනු ලැබේ.
    /// මෙම [`RawWaker`] හා සම්බන්ධ කාර්යය අවදි කළ යුතුය.
    ///
    /// මෙම ශ්‍රිතය `wake` ට සමාන ය, නමුත් ලබා දී ඇති දත්ත දර්ශකය පරිභෝජනය නොකළ යුතුය.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// [`RawWaker`] පහත වැටුණු විට මෙම ශ්‍රිතය කැඳවනු ලැබේ.
    ///
    /// මෙම ශ්‍රිතය ක්‍රියාත්මක කිරීම මඟින් [`RawWaker`] හා ඒ හා සම්බන්ධ කාර්යයක මෙම අවස්ථාව හා සම්බන්ධ ඕනෑම සම්පත් නිදහස් කිරීමට වග බලා ගත යුතුය.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// සපයා ඇති `clone`, `wake`, `wake_by_ref`, සහ `drop` ශ්‍රිත වලින් නව `RawWakerVTable` නිර්මාණය කරයි.
    ///
    /// # `clone`
    ///
    /// [`RawWaker`] ක්ලෝන වූ විට මෙම ශ්‍රිතය කැඳවනු ලැබේ, උදා: [`RawWaker`] ගබඩා කර ඇති [`Waker`] ක්ලෝන වූ විට.
    ///
    /// මෙම ශ්‍රිතය ක්‍රියාත්මක කිරීමේදී [`RawWaker`] සහ ඊට සම්බන්ධ කාර්යයක මෙම අතිරේක අවස්ථාව සඳහා අවශ්‍ය සියලු සම්පත් රඳවා ගත යුතුය.
    /// එහි ප්‍රති ing ලයක් වන [`RawWaker`] වෙත `wake` ඇමතීමෙන් මුල් [`RawWaker`] විසින් අවදි කරනු ලැබූ එම කාර්යයම අවදි විය යුතුය.
    ///
    /// # `wake`
    ///
    /// [`Waker`] හි `wake` ඇමතූ විට මෙම ශ්‍රිතය කැඳවනු ලැබේ.
    /// මෙම [`RawWaker`] හා සම්බන්ධ කාර්යය අවදි කළ යුතුය.
    ///
    /// මෙම ශ්‍රිතය ක්‍රියාත්මක කිරීම මඟින් [`RawWaker`] හා ඒ හා සම්බන්ධ කාර්යයක මෙම අවස්ථාව හා සම්බන්ධ ඕනෑම සම්පත් නිදහස් කිරීමට වග බලා ගත යුතුය.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// [`Waker`] හි `wake_by_ref` ඇමතූ විට මෙම ශ්‍රිතය කැඳවනු ලැබේ.
    /// මෙම [`RawWaker`] හා සම්බන්ධ කාර්යය අවදි කළ යුතුය.
    ///
    /// මෙම ශ්‍රිතය `wake` ට සමාන ය, නමුත් ලබා දී ඇති දත්ත දර්ශකය පරිභෝජනය නොකළ යුතුය.
    ///
    /// # `drop`
    ///
    /// [`RawWaker`] පහත වැටුණු විට මෙම ශ්‍රිතය කැඳවනු ලැබේ.
    ///
    /// මෙම ශ්‍රිතය ක්‍රියාත්මක කිරීම මඟින් [`RawWaker`] හා ඒ හා සම්බන්ධ කාර්යයක මෙම අවස්ථාව හා සම්බන්ධ ඕනෑම සම්පත් නිදහස් කිරීමට වග බලා ගත යුතුය.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// අසමමුහුර්ත කාර්යයක `Context`.
///
/// දැනට, `Context` සේවය කරන්නේ `&Waker` වෙත ප්‍රවේශය ලබා දීම සඳහා වන අතර එය වත්මන් කාර්යය අවදි කිරීමට භාවිතා කළ හැකිය.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // ජීවිත කාලය වෙනස් කිරීමට බල කිරීම මගින් විචල්‍යතා වෙනස්වීම් වලට එරෙහිව අපි future-සාධනය සහතික කරන්න (තර්ක-ස්ථානීය ආයු කාලය පරස්පර වන අතර නැවත ස්ථානගත වීමේ ආයු කාලය සහසංයුජ වේ).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// `&Waker` වෙතින් නව `Context` සාදන්න.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// වත්මන් කාර්යය සඳහා `Waker` වෙත යොමු කිරීමක් ලබා දෙයි.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` යනු කාර්යයක් අවදි කිරීම සඳහා වන හසුරුවකි, එය ක්‍රියාත්මක කිරීමට සූදානම් බව එහි විධායකයාට දැනුම් දීම.
///
/// මෙම හසුරුව [`RawWaker`] නිදසුනක් ආවරණය කරයි, එය ක්‍රියාත්මක කරන්නාට විශේෂිත වූ අවදිවීමේ හැසිරීම අර්ථ දක්වයි.
///
///
/// [`Clone`], [`Send`] සහ [`Sync`] ක්‍රියාත්මක කරයි.
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// මෙම `Waker` හා සම්බන්ධ කාර්යය අවදි කරන්න.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // සත්‍ය අවදි කිරීමේ ඇමතුම ක්‍රියාත්මක කරන්නා විසින් අර්ථ දක්වා ඇති අථත්‍ය ක්‍රියාකාරී ඇමතුමක් මඟින් ක්‍රියාත්මක කිරීම සඳහා පවරනු ලැබේ.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // `drop` අමතන්න එපා-වේකර් `wake` විසින් පරිභෝජනය කරනු ඇත.
        crate::mem::forget(self);

        // ආරක්ෂාව: මෙය ආරක්ෂිත වන්නේ `Waker::from_raw` එකම ක්‍රමය වන බැවිනි
        // `wake` සහ `data` ආරම්භ කිරීම සඳහා පරිශීලකයාට `RawWaker` හි කොන්ත්‍රාත්තුව පිළිගෙන ඇති බව පිළිගැනීමට අවශ්‍ය වේ.
        //
        unsafe { (wake)(data) };
    }

    /// `Waker` පරිභෝජනය නොකර මෙම `Waker` හා සම්බන්ධ කාර්යය අවදි කරන්න.
    ///
    /// මෙය `wake` ට සමාන වේ, නමුත් අයිති `Waker` ලබා ගත හැකි අවස්ථාවකදී එය තරමක් අඩු කාර්යක්ෂම විය හැකිය.
    /// `waker.clone().wake()` ඇමතීමට මෙම ක්‍රමය වඩාත් සුදුසු විය යුතුය.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // සත්‍ය අවදි කිරීමේ ඇමතුම ක්‍රියාත්මක කරන්නා විසින් අර්ථ දක්වා ඇති අථත්‍ය ක්‍රියාකාරී ඇමතුමක් මඟින් ක්‍රියාත්මක කිරීම සඳහා පවරනු ලැබේ.
        //

        // ආරක්ෂාව: `wake` බලන්න
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// මෙම `Waker` සහ තවත් `Waker` එකම කාර්යය අවදි කර ඇත්නම් `true` ලබා දෙයි.
    ///
    /// මෙම ශ්‍රිතය උපරිම උත්සාහයක් මත ක්‍රියාත්මක වන අතර, 'වෝකර්' එකම කාර්යය අවදි කරන විට පවා අසත්‍ය විය හැකිය.
    /// කෙසේ වෙතත්, මෙම ශ්‍රිතය `true` ආපසු ලබා දෙන්නේ නම්, 'වෝකර්' එකම කාර්යය අවදි කරනු ඇති බවට සහතික වේ.
    ///
    /// මෙම ශ්‍රිතය මූලික වශයෙන් භාවිතා කරනුයේ ප්‍රශස්තිකරණ අරමුණු සඳහා ය.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// [`RawWaker`] වෙතින් නව `Waker` සාදයි.
    ///
    /// [`RawWaker`] සහ [`RawWakerVTable`] හි ප්‍රලේඛනයෙහි අර්ථ දක්වා ඇති කොන්ත්‍රාත්තුව තහවුරු කර නොමැති නම් ආපසු ලබා දුන් `Waker` හි හැසිරීම නිර්වචනය නොකෙරේ.
    ///
    /// එබැවින් මෙම ක්‍රමය අනාරක්ෂිත ය.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // ආරක්ෂාව: මෙය ආරක්ෂිත වන්නේ `Waker::from_raw` එකම ක්‍රමය වන බැවිනි
            // `clone` සහ `data` ආරම්භ කිරීමට පරිශීලකයාට [`RawWaker`] හි කොන්ත්‍රාත්තුව පිළිගෙන ඇති බව පිළිගැනීමට අවශ්‍ය වේ.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // ආරක්ෂාව: මෙය ආරක්ෂිත වන්නේ `Waker::from_raw` එකම ක්‍රමය වන බැවිනි
        // `drop` සහ `data` ආරම්භ කිරීමට පරිශීලකයාට `RawWaker` හි කොන්ත්‍රාත්තුව පිළිගෙන ඇති බව පිළිගැනීමට අවශ්‍ය වේ.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}