#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// ඕනෑම ලක්ෂ්‍ය-වර්ගයක දර්ශක පාර-දත්ත වර්ගය සපයයි.
///
/// # දර්ශක පාර-දත්ත
///
/// Rust හි අමු දර්ශක වර්ග සහ විමර්ශන වර්ග කොටස් දෙකකින් සෑදී ඇතැයි සිතිය හැකිය:
/// අගයෙහි මතක ලිපිනය සහ සමහර පාර-දත්ත අඩංගු දත්ත දර්ශකයක්.
///
/// සංඛ්‍යානමය ප්‍රමාණයේ (`Sized` traits ක්‍රියාත්මක කරන) මෙන්ම `extern` වර්ග සඳහා, දර්ශකයන් `තුනී` යැයි කියනු ලැබේ: පාර-දත්ත ශුන්‍ය ප්‍රමාණයේ වන අතර එහි වර්ගය `()` වේ.
///
///
/// [dynamically-sized types][dst] වෙත යොමු කරන්නන් `පුළුල්` හෝ `මේදය` යැයි කියනු ලැබේ, ඒවාට ශුන්‍ය නොවන පාර-දත්ත ඇත:
///
/// * අන්තිම ක්ෂේත්‍රය ඩීඑස්ටී වන ව්‍යුහයන් සඳහා, පාර-දත්ත යනු අවසාන ක්ෂේත්‍රය සඳහා පාර-දත්ත වේ
/// * `str` වර්ගය සඳහා, පාර-දත්ත යනු `usize` ලෙස බයිට් වල දිග වේ
/// * `[T]` වැනි පෙති වර්ග සඳහා, පාර-දත්ත යනු `usize` ලෙස අයිතමවල දිග වේ
/// * `dyn SomeTrait` වැනි trait වස්තු සඳහා, පාර-දත්ත [`DynMetadata<Self>`][DynMetadata] (උදා: `DynMetadata<dyn SomeTrait>`)
///
/// future හි, Rust භාෂාව විවිධ දර්ශක පාර-දත්ත ඇති නව වර්ග ලබා ගත හැකිය.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// මෙම trait හි ලක්ෂ්‍යය එහි `Metadata` ආශ්‍රිත වර්ගය වන අතර එය ඉහත විස්තර කර ඇති පරිදි `()` හෝ `usize` හෝ `DynMetadata<_>` වේ.
/// එය සෑම වර්ගයක් සඳහාම ස්වයංක්‍රීයව ක්‍රියාත්මක වේ.
/// අනුරූපී සීමාවකින් තොරව වුවද එය සාමාන්‍ය සන්දර්භයක් තුළ ක්‍රියාත්මක කළ හැකි යැයි උපකල්පනය කළ හැකිය.
///
/// # Usage
///
/// අමු දර්ශක ඔවුන්ගේ [`to_raw_parts`] ක්‍රමය සමඟ දත්ත ලිපිනය සහ පාර-දත්ත සංරචක වලට දිරාපත් කළ හැකිය.
///
/// විකල්පයක් ලෙස, [`metadata`] ශ්‍රිතය සමඟ පාර-දත්ත පමණක් උකහා ගත හැකිය.
/// යොමු කිරීමක් [`metadata`] වෙත යැවිය හැකි අතර ව්‍යංගයෙන් බල කෙරේ.
///
/// (possibly-wide) දර්ශකයක් එහි ලිපිනයෙන් සහ පාර-දත්ත වලින් [`from_raw_parts`] හෝ [`from_raw_parts_mut`] සමඟ නැවත එකතු කළ හැකිය.
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// දර්ශකවල පාර-දත්ත සඳහා වර්ගය සහ `Self` වෙත යොමු කිරීම.
    #[lang = "metadata_type"]
    // NOTE: `static_assert_expected_bounds_for_metadata` හි trait bounds තබා ගන්න
    //
    // `library/core/src/ptr/metadata.rs` හි මෙහි සිටින අය සමඟ සමපාත වේ:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// මෙම trait අන්වර්ථය ක්‍රියාත්මක කරන වර්ග සඳහා දර්ශක `තුනී` වේ.
///
/// ස්ථිතික-ප්‍රමාණයේ` වර්ග සහ `extern` වර්ග මෙයට ඇතුළත් වේ.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: trait අන්වර්ථයන් භාෂාවෙන් ස්ථාවර වීමට පෙර මෙය ස්ථාවර නොකරන්නේද?
pub trait Thin = Pointee<Metadata = ()>;

/// දර්ශකයක පාර-දත්ත සංරචකය උපුටා ගන්න.
///
/// `*mut T`, `&T`, හෝ `&mut T` වර්ගයේ අගයන් `* const T` වෙත ව්‍යංගයෙන් බල කරන බැවින් මෙම ශ්‍රිතයට කෙලින්ම ලබා දිය හැකිය.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // සුරක්ෂිතභාවය: * const T සිට `PtrRepr` සංගමයෙන් වටිනාකමට ප්‍රවේශ වීම ආරක්ෂිතයි
    // සහ PtrComponents<T>එකම මතක පිරිසැලසුම් ඇත.
    // මෙම සහතිකය ලබා දිය හැක්කේ std ට පමණි.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// දත්ත ලිපිනයකින් සහ පාර-දත්තයකින් (possibly-wide) අමු දර්ශකයක් සාදයි.
///
/// මෙම ශ්‍රිතය ආරක්ෂිත නමුත් ආපසු ලබා දුන් දර්ශකය විරූපණයට අනිවාර්යයෙන්ම ආරක්ෂිත නොවේ.
/// පෙති සඳහා, ආරක්ෂක අවශ්‍යතා සඳහා [`slice::from_raw_parts`] හි ප්‍රලේඛනය බලන්න.
/// trait වස්තු සඳහා, පාර-දත්ත දර්ශකයේ සිට එකම යටින් ඇති ereased වර්ගයට පැමිණිය යුතුය.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // සුරක්ෂිතභාවය: * const T සිට `PtrRepr` සංගමයෙන් වටිනාකමට ප්‍රවේශ වීම ආරක්ෂිතයි
    // සහ PtrComponents<T>එකම මතක පිරිසැලසුම් ඇත.
    // මෙම සහතිකය ලබා දිය හැක්කේ std ට පමණි.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// අමු `*const` දර්ශකයට වඩා අමු `* mut` දර්ශකයක් ආපසු ලබා දීම හැර, [`from_raw_parts`] හා සමාන ක්‍රියාකාරීත්වයක් සිදු කරයි.
///
///
/// වැඩි විස්තර සඳහා [`from_raw_parts`] හි ප්‍රලේඛනය බලන්න.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // සුරක්ෂිතභාවය: * const T සිට `PtrRepr` සංගමයෙන් වටිනාකමට ප්‍රවේශ වීම ආරක්ෂිතයි
    // සහ PtrComponents<T>එකම මතක පිරිසැලසුම් ඇත.
    // මෙම සහතිකය ලබා දිය හැක්කේ std ට පමණි.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// `T: Copy` බැඳීම වළක්වා ගැනීමට අත්පොත අවශ්‍ය වේ.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// `T: Clone` බැඳීම වළක්වා ගැනීමට අත්පොත අවශ්‍ය වේ.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// `Dyn = dyn SomeTrait` trait වස්තු වර්ගයක් සඳහා පාර-දත්ත.
///
/// එය trait වස්තුවක් තුළ ගබඩා කර ඇති කොන්ක්‍රීට් වර්ගය හැසිරවීමට අවශ්‍ය සියලු තොරතුරු නිරූපණය කරන vtable (අතථ්‍ය ඇමතුම් වගුව) වෙත යොමු කිරීමකි.
/// Vtable හි විශේෂයෙන් අඩංගු වන්නේ:
///
/// * වර්ගය ප්‍රමාණය
/// * පෙළගැස්ම ටයිප් කරන්න
/// * වර්ගයේ `drop_in_place` impl වෙත දර්ශකයක් (සරල-පැරණි-දත්ත සඳහා විකල්පයක් නොවිය හැකිය)
/// * trait වර්ගය ක්‍රියාත්මක කිරීම සඳහා වන සියලුම ක්‍රම වෙත යොමු කරයි
///
/// ඕනෑම trait වස්තුවක් වෙන් කිරීම, අතහැර දැමීම සහ ඉවත් කිරීම අවශ්‍ය බැවින් පළමු තිදෙනා විශේෂ බව සලකන්න.
///
/// මෙම ව්‍යුහය `dyn` trait වස්තුවක් නොවන (උදාහරණයක් ලෙස `DynMetadata<u64>`) වර්ග පරාමිතියකින් නම් කළ හැකි නමුත් එම ව්‍යුහයේ අර්ථවත් අගයක් ලබා ගත නොහැක.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// සියලුම vtables වල පොදු උපසර්ගය.එය අනුගමනය කරන්නේ trait ක්‍රම සඳහා ශ්‍රිත දර්ශක මගිනි.
///
/// `DynMetadata::size_of` ආදිය පුද්ගලික ක්‍රියාත්මක කිරීමේ විස්තර.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// මෙම vtable හා සම්බන්ධ වර්ගයේ ප්‍රමාණය ලබා දෙයි.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// මෙම vtable හා සම්බන්ධ වර්ගයේ පෙළගැස්ම ලබා දෙයි.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// `Layout` ලෙස ප්‍රමාණය හා පෙළගැස්ම එකට ලබා දෙයි
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // ආරක්ෂාව: සම්පාදකයා විසින් මෙම vtable එක කොන්ක්‍රීට් Rust වර්ගයක් සඳහා විමෝචනය කරයි
        // වලංගු පිරිසැලසුමක් ඇති බව දන්නා කරුණකි.`Layout::for_value` හි ඇති ආකාරයටම තාර්කිකත්වය.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// `Dyn: $Trait` සීමාවන් වළක්වා ගැනීම සඳහා අත්පොත අවශ්‍ය වේ.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}