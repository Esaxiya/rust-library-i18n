use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` නමුත් ශුන්‍ය නොවන සහ සහසංයුජ.
///
/// අමු දර්ශක භාවිතා කරමින් දත්ත ව්‍යුහයන් තැනීමේදී මෙය බොහෝ විට භාවිතා කළ යුතු නිවැරදි දෙය වන නමුත් අවසානයේ එහි අතිරේක ගුණාංග නිසා භාවිතා කිරීම වඩාත් භයානක ය.ඔබ `NonNull<T>` භාවිතා කළ යුතු දැයි ඔබට විශ්වාස නැත්නම්, `*mut T` භාවිතා කරන්න!
///
/// `*mut T` මෙන් නොව, දර්ශකය කිසි විටෙකත් අවලංගු නොකළද, දර්ශකය සැමවිටම ශුන්‍ය නොවිය යුතුය.මෙය එසේ වන්නේ එන්යූම්ස් විසින් මෙම තහනම් අගය වෙනස් කොට සැලකීමක් ලෙස භාවිතා කළ හැකිය-`Option<NonNull<T>>` ට `* mut T` ට සමාන ප්‍රමාණයක් ඇත.
/// කෙසේ වෙතත්, දර්ශකය අවලංගු නොකළ හොත් එය තවමත් ගැටෙනු ඇත.
///
/// `*mut T` මෙන් නොව, `NonNull<T>` `T` ට වඩා සහසංයුජ ලෙස තෝරාගෙන ඇත.මෙමඟින් සහසංයුජ වර්ග සෑදීමේදී `NonNull<T>` භාවිතා කිරීමට හැකි වන නමුත් ඇත්ත වශයෙන්ම සහසංයුජ නොවිය යුතු වර්ගයක භාවිතා කරන්නේ නම් නිරවද්‍යතාවයේ අවදානම හඳුන්වා දෙයි.
/// (`*mut T` සඳහා ප්‍රතිවිරුද්ධ තේරීම සිදු කරන ලද්දේ තාක්‍ෂණිකව අපැහැදිලි භාවය ඇතිවිය හැක්කේ අනාරක්ෂිත කාර්යයන් ඇමතීමෙන් පමණි.)
///
/// `Box`, `Rc`, `Arc`, `Vec`, සහ `LinkedList` වැනි බොහෝ ආරක්ෂිත වියුක්ත කිරීම් සඳහා කෝවරියන්ස් නිවැරදි වේ.Rust හි සාමාන්‍ය හවුල් XOR විකෘති නීති රීති අනුගමනය කරන පොදු API එකක් ඔවුන් සපයන නිසා මෙය සිදු වේ.
///
/// ඔබේ වර්ගය ආරක්ෂිතව සහසංයුජ විය නොහැකි නම්, එය වෙනස් කිරීම සඳහා අමතර ක්ෂේත්‍රයක් අඩංගු බව සහතික කළ යුතුය.බොහෝ විට මෙම ක්ෂේත්‍රය `PhantomData<Cell<T>>` හෝ `PhantomData<&'a mut T>` වැනි [`PhantomData`] වර්ගයක් වනු ඇත.
///
/// X002 සඳහා `NonNull<T>` සඳහා `From` නිදසුනක් ඇති බව සැලකිල්ලට ගන්න.කෙසේ වෙතත්, [`UnsafeCell<T>`] තුළ විකෘතියක් සිදු නොවන්නේ නම් (අ) ව්‍යුත්පන්න කළ යොමු ලක්ෂ්‍යයක් හරහා විකෘති කිරීම නිර්වචනය නොකළ හැසිරීමක් යන කාරණය මෙයින් වෙනස් නොවේ.හවුල් යොමු කිරීමකින් විකෘති යොමු කිරීමක් නිර්මාණය කිරීම සඳහා ද එයම වේ.
///
/// `UnsafeCell<T>` නොමැතිව මෙම `From` උදාහරණය භාවිතා කරන විට, `as_mut` කිසි විටෙකත් නොකියන බවට වග බලා ගැනීම ඔබේ වගකීම වන අතර `as_ptr` කිසි විටෙකත් විකෘති සඳහා භාවිතා නොවේ.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` දර්ශකයන් `Send` නොවේ, මන්ද ඔවුන් යොමු කරන දත්ත අන්වර්ථ විය හැකිය.
// සැ.යු, මෙම impl අනවශ්‍ය නමුත් වඩා හොඳ දෝෂ පණිවිඩ ලබා දිය යුතුය.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` දර්ශකයන් `Sync` නොවේ, මන්ද ඔවුන් යොමු කරන දත්ත අන්වර්ථ විය හැකිය.
// සැ.යු, මෙම impl අනවශ්‍ය නමුත් වඩා හොඳ දෝෂ පණිවිඩ ලබා දිය යුතුය.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// නව `NonNull` නිර්මාණය කරන්නේ අන්තරාදායක, නමුත් හොඳින් පෙළ ගැසී ඇති බැවිනි.
    ///
    /// `Vec::new` මෙන් කම්මැලි ලෙස වෙන් කරන වර්ග ආරම්භ කිරීම සඳහා මෙය ප්‍රයෝජනවත් වේ.
    ///
    /// දර්ශක අගය `T` සඳහා වලංගු දර්ශකයක් නිරූපණය කළ හැකි බව සලකන්න, එයින් අදහස් වන්නේ මෙය "not yet initialized" සෙන්ඩිනල් අගයක් ලෙස භාවිතා නොකළ යුතු බවයි.
    /// කම්මැලි ලෙස වෙන් කරන වර්ග වෙනත් ආකාරයකින් ආරම්භ කිරීම නිරීක්ෂණය කළ යුතුය.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // සුරක්ෂිතභාවය: mem::align_of() විසින් ශුන්‍ය නොවන භාවිතයක් ලබා දෙයි
        // a * mut T. වෙත.
        // එබැවින්, `ptr` අහෝසි නොවන අතර new_unchecked() ඇමතීමේ කොන්දේසි වලට ගරු කරනු ලැබේ.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// අගය සඳහා හවුල් යොමු කිරීමක් ලබා දෙයි.[`as_ref`] ට ප්‍රතිවිරුද්ධව, අගය ආරම්භ කිරීම අවශ්‍ය නොවේ.
    ///
    /// විකෘති ප්‍රතිවිරුද්ධ පාර්ශවය සඳහා [`as_uninit_mut`] බලන්න.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// මෙම ක්‍රමය අමතන විට, පහත සඳහන් සියල්ල සත්‍ය බව ඔබ සහතික කළ යුතුය:
    ///
    /// * දර්ශකය නිසි ලෙස පෙළ ගැස්විය යුතුය.
    ///
    /// * එය [the module documentation] හි අර්ථ දක්වා ඇති අර්ථයෙන් "dereferencable" විය යුතුය.
    ///
    /// * ආපසු ලබා දුන් ජීවිත කාලය `'a` අත්තනෝමතික ලෙස තෝරාගෙන ඇති අතර දත්තවල සැබෑ ආයු කාලය පිළිබිඹු නොවන බැවින් ඔබ Rust හි අන්වර්ථ නීති ක්‍රියාත්මක කළ යුතුය.
    ///
    ///   විශේෂයෙන්, මෙම ජීවිත කාලය සඳහා, දර්ශකය පෙන්වා දෙන මතකය විකෘති නොවිය යුතුය (`UnsafeCell` ඇතුළත හැර).
    ///
    /// මෙම ක්‍රමයේ ප්‍රති result ලය භාවිතා නොකළද මෙය අදාළ වේ!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // ආරක්ෂාව: අමතන්නා විසින් `self` සියල්ලම සපුරාලන බවට සහතික විය යුතුය
        // යොමු කිරීම සඳහා අවශ්‍යතා.
        unsafe { &*self.cast().as_ptr() }
    }

    /// අගය සඳහා අද්විතීය යොමු කිරීමක් ලබා දෙයි.[`as_mut`] ට ප්‍රතිවිරුද්ධව, අගය ආරම්භ කිරීම අවශ්‍ය නොවේ.
    ///
    /// හවුල් සහකරු සඳහා [`as_uninit_ref`] බලන්න.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// මෙම ක්‍රමය අමතන විට, පහත සඳහන් සියල්ල සත්‍ය බව ඔබ සහතික කළ යුතුය:
    ///
    /// * දර්ශකය නිසි ලෙස පෙළ ගැස්විය යුතුය.
    ///
    /// * එය [the module documentation] හි අර්ථ දක්වා ඇති අර්ථයෙන් "dereferencable" විය යුතුය.
    ///
    /// * ආපසු ලබා දුන් ජීවිත කාලය `'a` අත්තනෝමතික ලෙස තෝරාගෙන ඇති අතර දත්තවල සැබෑ ආයු කාලය පිළිබිඹු නොවන බැවින් ඔබ Rust හි අන්වර්ථ නීති ක්‍රියාත්මක කළ යුතුය.
    ///
    ///   විශේෂයෙන්, මෙම ජීවිත කාලය සඳහා, දර්ශකය පෙන්වා දෙන මතකය වෙනත් කිසිදු දර්ශකයක් හරහා ප්‍රවේශ නොවිය යුතුය (කියවීම හෝ ලිවීම).
    ///
    /// මෙම ක්‍රමයේ ප්‍රති result ලය භාවිතා නොකළද මෙය අදාළ වේ!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // ආරක්ෂාව: අමතන්නා විසින් `self` සියල්ලම සපුරාලන බවට සහතික විය යුතුය
        // යොමු කිරීම සඳහා අවශ්‍යතා.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// නව `NonNull` නිර්මාණය කරයි.
    ///
    /// # Safety
    ///
    /// `ptr` ශුන්‍ය නොවන විය යුතුය.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // ආරක්ෂාව: අමතන්නා විසින් `ptr` ශුන්‍ය නොවන බවට සහතික විය යුතුය.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// `ptr` ශුන්‍ය නොවේ නම් නව `NonNull` සාදයි.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // ආරක්ෂාව: දර්ශකය දැනටමත් පරීක්ෂා කර ඇති අතර එය ශුන්‍ය නොවේ
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// අමු `*const` දර්ශකයට වඩා `NonNull` දර්ශකයක් ආපසු ලබා දීම හැර, [`std::ptr::from_raw_parts`] හා සමාන ක්‍රියාකාරීත්වයක් සිදු කරයි.
    ///
    ///
    /// වැඩි විස්තර සඳහා [`std::ptr::from_raw_parts`] හි ප්‍රලේඛනය බලන්න.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // ආරක්ෂාව: `ptr::from::raw_parts_mut` හි ප්‍රති result ලය ශුන්‍ය නොවන නිසා `data_address` වේ.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// ලිපිනය සහ පාර-දත්ත සංරචක (සමහරවිට පුළුල්) දර්ශකයක් වියෝජනය කරන්න.
    ///
    /// දර්ශකය පසුව [`NonNull::from_raw_parts`] සමඟ ප්‍රතිනිර්මාණය කළ හැකිය.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// යටින් පවතින `*mut` දර්ශකය ලබා ගනී.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// වටිනාකමට හවුල් යොමු කිරීමක් ලබා දෙයි.අගය ආරම්භ කළ නොහැකි නම්, ඒ වෙනුවට [`as_uninit_ref`] භාවිතා කළ යුතුය.
    ///
    /// විකෘති ප්‍රතිවිරුද්ධ පාර්ශවය සඳහා [`as_mut`] බලන්න.
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// මෙම ක්‍රමය අමතන විට, පහත සඳහන් සියල්ල සත්‍ය බව ඔබ සහතික කළ යුතුය:
    ///
    /// * දර්ශකය නිසි ලෙස පෙළ ගැස්විය යුතුය.
    ///
    /// * එය [the module documentation] හි අර්ථ දක්වා ඇති අර්ථයෙන් "dereferencable" විය යුතුය.
    ///
    /// * දර්ශකය `T` හි ආරම්භක අවස්ථාවකට යොමු කළ යුතුය.
    ///
    /// * ආපසු ලබා දුන් ජීවිත කාලය `'a` අත්තනෝමතික ලෙස තෝරාගෙන ඇති අතර දත්තවල සැබෑ ආයු කාලය පිළිබිඹු නොවන බැවින් ඔබ Rust හි අන්වර්ථ නීති ක්‍රියාත්මක කළ යුතුය.
    ///
    ///   විශේෂයෙන්, මෙම ජීවිත කාලය සඳහා, දර්ශකය පෙන්වා දෙන මතකය විකෘති නොවිය යුතුය (`UnsafeCell` ඇතුළත හැර).
    ///
    /// මෙම ක්‍රමයේ ප්‍රති result ලය භාවිතා නොකළද මෙය අදාළ වේ!
    /// (ආරම්භ කිරීම පිළිබඳ කොටස තවමත් සම්පූර්ණයෙන් තීරණය කර නැත, නමුත් එය සිදු වන තුරු එකම ආරක්‍ෂිත ප්‍රවේශය වන්නේ ඒවා සැබවින්ම ආරම්භ කර ඇති බව සහතික කිරීමයි.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // ආරක්ෂාව: අමතන්නා විසින් `self` සියල්ලම සපුරාලන බවට සහතික විය යුතුය
        // යොමු කිරීම සඳහා අවශ්‍යතා.
        unsafe { &*self.as_ptr() }
    }

    /// වටිනාකමට අද්විතීය සඳහනක් ලබා දෙයි.අගය ආරම්භ කළ නොහැකි නම්, ඒ වෙනුවට [`as_uninit_mut`] භාවිතා කළ යුතුය.
    ///
    /// හවුල් සහකරු සඳහා [`as_ref`] බලන්න.
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// මෙම ක්‍රමය අමතන විට, පහත සඳහන් සියල්ල සත්‍ය බව ඔබ සහතික කළ යුතුය:
    ///
    /// * දර්ශකය නිසි ලෙස පෙළ ගැස්විය යුතුය.
    ///
    /// * එය [the module documentation] හි අර්ථ දක්වා ඇති අර්ථයෙන් "dereferencable" විය යුතුය.
    ///
    /// * දර්ශකය `T` හි ආරම්භක අවස්ථාවකට යොමු කළ යුතුය.
    ///
    /// * ආපසු ලබා දුන් ජීවිත කාලය `'a` අත්තනෝමතික ලෙස තෝරාගෙන ඇති අතර දත්තවල සැබෑ ආයු කාලය පිළිබිඹු නොවන බැවින් ඔබ Rust හි අන්වර්ථ නීති ක්‍රියාත්මක කළ යුතුය.
    ///
    ///   විශේෂයෙන්, මෙම ජීවිත කාලය සඳහා, දර්ශකය පෙන්වා දෙන මතකය වෙනත් කිසිදු දර්ශකයක් හරහා ප්‍රවේශ නොවිය යුතුය (කියවීම හෝ ලිවීම).
    ///
    /// මෙම ක්‍රමයේ ප්‍රති result ලය භාවිතා නොකළද මෙය අදාළ වේ!
    /// (ආරම්භ කිරීම පිළිබඳ කොටස තවමත් සම්පූර්ණයෙන් තීරණය කර නැත, නමුත් එය සිදු වන තුරු එකම ආරක්‍ෂිත ප්‍රවේශය වන්නේ ඒවා සැබවින්ම ආරම්භ කර ඇති බව සහතික කිරීමයි.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // ආරක්ෂාව: අමතන්නා විසින් `self` සියල්ලම සපුරාලන බවට සහතික විය යුතුය
        // විකෘති යොමු කිරීමක් සඳහා අවශ්‍යතා.
        unsafe { &mut *self.as_ptr() }
    }

    /// වෙනත් වර්ගයක දර්ශකයකට දමයි.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // ආරක්ෂාව: `self` යනු `NonNull` දර්ශකයක් වන අතර එය අනිවාර්යයෙන්ම ශුන්‍ය නොවේ
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// තුනී දර්ශකයකින් සහ දිගකින් ශුන්‍ය නොවන අමු පෙත්තක් සාදයි.
    ///
    /// `len` තර්කය යනු **මූලද්‍රව්‍ය ගණන** මිස බයිට් ගණන නොවේ.
    ///
    /// මෙම ක්‍රියාව ආරක්ෂිතයි, නමුත් ප්‍රතිලාභ අගය අවලංගු කිරීම අනාරක්ෂිතයි.
    /// පෙති ආරක්ෂණ අවශ්‍යතා සඳහා [`slice::from_raw_parts`] හි ප්‍රලේඛනය බලන්න.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // පළමු මූලද්‍රව්‍යයට දර්ශකයක් සමඟ ආරම්භ කරන විට පෙති දර්ශකයක් සාදන්න
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (මෙම උදාහරණය කෘතිමව මෙම ක්‍රමයේ භාවිතයක් පෙන්නුම් කරන බව සලකන්න, නමුත් `පෙත්ත= NonNull::from(&x[..]);` would be a better way to write code like this.) ඉඩ දෙන්න
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // ආරක්ෂාව: `data` යනු `NonNull` දර්ශකයක් වන අතර එය අනිවාර්යයෙන්ම ශුන්‍ය නොවේ
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// ශුන්‍ය නොවන අමු පෙත්තක දිග ලබා දෙයි.
    ///
    /// ආපසු ලබා දුන් අගය **මූලද්‍රව්‍ය ගණන** මිස බයිට් ගණන නොවේ.
    ///
    /// දර්ශකය වලංගු ලිපිනයක් නොමැති නිසා ශුන්‍ය නොවන අමු පෙත්තක් පෙත්තකට යොමු කළ නොහැකි වුවද මෙම ක්‍රියාව ආරක්ෂිත වේ.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// පෙත්තෙහි බෆරයට ශුන්‍ය නොවන දර්ශකයක් ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // ආරක්ෂාව: අපි දන්නවා `self` ශුන්‍ය නොවන බව.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// පෙත්තෙහි බෆරයට අමු දර්ශකයක් ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// ආරම්භක නොවන අගයන් පෙත්තකට හවුල් යොමු කිරීමක් ලබා දෙයි.[`as_ref`] ට ප්‍රතිවිරුද්ධව, අගය ආරම්භ කිරීම අවශ්‍ය නොවේ.
    ///
    /// විකෘති ප්‍රතිවිරුද්ධ පාර්ශවය සඳහා [`as_uninit_slice_mut`] බලන්න.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// මෙම ක්‍රමය අමතන විට, පහත සඳහන් සියල්ල සත්‍ය බව ඔබ සහතික කළ යුතුය:
    ///
    /// * `ptr.len() * mem::size_of::<T>()` බොහෝ බයිට් සඳහා කියවීම සඳහා දර්ශකය [valid] විය යුතු අතර එය නිසි ලෙස පෙළගස්වා තිබිය යුතුය.මෙයින් විශේෂයෙන් අදහස් කරන්නේ:
    ///
    ///     * මෙම පෙත්තෙහි සම්පූර්ණ මතක පරාසය එක් වෙන් කළ වස්තුවක් තුළ අඩංගු විය යුතුය!
    ///       පෙති කිසි විටෙකත් වෙන් කරන ලද බහු වස්තු හරහා විහිදිය නොහැක.
    ///
    ///     * දර්ශකය ශුන්‍ය දිග පෙති සඳහා පවා පෙළ ගැස්විය යුතුය.
    ///     මෙයට එක් හේතුවක් නම්, එනුම් පිරිසැලසුම් ප්‍රශස්තිකරණය වෙනත් දත්ත වලින් වෙන්කර හඳුනා ගැනීම සඳහා යොමු කිරීම් (ඕනෑම දිගක පෙති ද ඇතුළුව) පෙළගැස්වීම සහ ශුන්‍ය නොවන ඒවා මත රඳා පැවතීමයි.
    ///
    ///     [`NonNull::dangling()`] භාවිතා කරමින් ශුන්‍ය දිග පෙති සඳහා `data` ලෙස භාවිතා කළ හැකි දර්ශකයක් ඔබට ලබා ගත හැකිය.
    ///
    /// * පෙත්තෙහි මුළු ප්‍රමාණය `ptr.len() * mem::size_of::<T>()` `isize::MAX` ට වඩා විශාල නොවිය යුතුය.
    ///   [`pointer::offset`] හි ආරක්‍ෂිත ලියකියවිලි බලන්න.
    ///
    /// * ආපසු ලබා දුන් ජීවිත කාලය `'a` අත්තනෝමතික ලෙස තෝරාගෙන ඇති අතර දත්තවල සැබෑ ආයු කාලය පිළිබිඹු නොවන බැවින් ඔබ Rust හි අන්වර්ථ නීති ක්‍රියාත්මක කළ යුතුය.
    ///   විශේෂයෙන්, මෙම ජීවිත කාලය සඳහා, දර්ශකය පෙන්වා දෙන මතකය විකෘති නොවිය යුතුය (`UnsafeCell` ඇතුළත හැර).
    ///
    /// මෙම ක්‍රමයේ ප්‍රති result ලය භාවිතා නොකළද මෙය අදාළ වේ!
    ///
    /// [`slice::from_raw_parts`] ද බලන්න.
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // ආරක්ෂාව: අමතන්නා `as_uninit_slice` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// ආරම්භ නොකළ අගයන් පෙත්තකට අද්විතීය සඳහනක් ලබා දෙයි.[`as_mut`] ට ප්‍රතිවිරුද්ධව, අගය ආරම්භ කිරීම අවශ්‍ය නොවේ.
    ///
    /// හවුල් සහකරු සඳහා [`as_uninit_slice`] බලන්න.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// මෙම ක්‍රමය අමතන විට, පහත සඳහන් සියල්ල සත්‍ය බව ඔබ සහතික කළ යුතුය:
    ///
    /// * `ptr.len() * mem::size_of::<T>()` බොහෝ බයිට් සඳහා කියවීම සහ ලිවීම සඳහා දර්ශකය [valid] විය යුතු අතර එය නිසි ලෙස පෙළ ගැස්විය යුතුය.මෙයින් විශේෂයෙන් අදහස් කරන්නේ:
    ///
    ///     * මෙම පෙත්තෙහි සම්පූර්ණ මතක පරාසය එක් වෙන් කළ වස්තුවක් තුළ අඩංගු විය යුතුය!
    ///       පෙති කිසි විටෙකත් වෙන් කරන ලද බහු වස්තු හරහා විහිදිය නොහැක.
    ///
    ///     * දර්ශකය ශුන්‍ය දිග පෙති සඳහා පවා පෙළ ගැස්විය යුතුය.
    ///     මෙයට එක් හේතුවක් නම්, එනුම් පිරිසැලසුම් ප්‍රශස්තිකරණය වෙනත් දත්ත වලින් වෙන්කර හඳුනා ගැනීම සඳහා යොමු කිරීම් (ඕනෑම දිගක පෙති ද ඇතුළුව) පෙළගැස්වීම සහ ශුන්‍ය නොවන ඒවා මත රඳා පැවතීමයි.
    ///
    ///     [`NonNull::dangling()`] භාවිතා කරමින් ශුන්‍ය දිග පෙති සඳහා `data` ලෙස භාවිතා කළ හැකි දර්ශකයක් ඔබට ලබා ගත හැකිය.
    ///
    /// * පෙත්තෙහි මුළු ප්‍රමාණය `ptr.len() * mem::size_of::<T>()` `isize::MAX` ට වඩා විශාල නොවිය යුතුය.
    ///   [`pointer::offset`] හි ආරක්‍ෂිත ලියකියවිලි බලන්න.
    ///
    /// * ආපසු ලබා දුන් ජීවිත කාලය `'a` අත්තනෝමතික ලෙස තෝරාගෙන ඇති අතර දත්තවල සැබෑ ආයු කාලය පිළිබිඹු නොවන බැවින් ඔබ Rust හි අන්වර්ථ නීති ක්‍රියාත්මක කළ යුතුය.
    ///   විශේෂයෙන්, මෙම ජීවිත කාලය සඳහා, දර්ශකය පෙන්වා දෙන මතකය වෙනත් කිසිදු දර්ශකයක් හරහා ප්‍රවේශ නොවිය යුතුය (කියවීම හෝ ලිවීම).
    ///
    /// මෙම ක්‍රමයේ ප්‍රති result ලය භාවිතා නොකළද මෙය අදාළ වේ!
    ///
    /// [`slice::from_raw_parts_mut`] ද බලන්න.
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // `memory` බොහෝ බයිට් සඳහා කියවීම සහ ලිවීම සඳහා වලංගු බැවින් මෙය ආරක්ෂිත වේ.
    /// // අන්තර්ගතය ආරම්භ නොකළ බැවින් `memory.as_mut()` ඇමතීමට මෙහි අවසර නැත.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // ආරක්ෂාව: අමතන්නා `as_uninit_slice_mut` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// සීමා මායිම් පරික්ෂා නොකර අමුද්‍රව්‍ය දර්ශකයක් මූලද්‍රව්‍යයකට හෝ උප ග්‍රාහකයකට ලබා දෙයි.
    ///
    /// සීමාවෙන් පිටත දර්ශකයක් සමඟ හෝ `self` අවලංගු කළ නොහැකි විට මෙම ක්‍රමය ඇමතීම *[නිර්වචනය නොකළ හැසිරීම]* එහි ප්‍රති ing ලයක් ලෙස දර්ශකය භාවිතා නොකළද.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // ආරක්ෂාව: අමතන්නා විසින් `self` අවලංගු කළ හැකි සහ `index` සීමාව ඉක්මවා යන බව සහතික කරයි.
        // ප්‍රති consequ ලයක් ලෙස, ලැබෙන දර්ශකය NULL විය නොහැක.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // ආරක්ෂාව: අද්විතීය දර්ශකයක් අහෝසි කළ නොහැක, එබැවින් කොන්දේසි
        // new_unchecked() ගරු කරනු ලැබේ.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // ආරක්ෂාව: විකෘති යොමු කිරීමක් අහෝසි කළ නොහැක.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // ආරක්ෂාව: යොමු කිරීමක් අහෝසි කළ නොහැක, එබැවින් කොන්දේසි
        // new_unchecked() ගරු කරනු ලැබේ.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}