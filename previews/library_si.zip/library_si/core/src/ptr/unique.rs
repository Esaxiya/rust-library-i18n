use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// අමු ශූන්‍ය නොවන `*mut T` වටා එතීම, මෙම ආවරණයේ හිමිකරුට යොමු දැක්වීමේ හිමිකම ඇති බව පෙන්නුම් කරයි.
/// `Box<T>`, `Vec<T>`, `String`, සහ `HashMap<K, V>` වැනි වියුක්තයන් තැනීම සඳහා ප්‍රයෝජනවත් වේ.
///
/// `*mut T` මෙන් නොව, `Unique<T>` හැසිරෙන්නේ "as if" එය `T` හි නිදසුනකි.
/// `T` `Send`/`Sync` නම් එය `Send`/`Sync` ක්‍රියාත්මක කරයි.
/// `T` හි නිදසුනක් අපේක්ෂා කළ හැකි ආකාරයේ ශක්තිමත් අන්වර්ථකරණ සහතිකයක් ද එයින් ගම්‍ය වේ:
/// පොයින්ටරයේ යොමු කිරීම එහි අද්විතීය යුනික් වෙත අද්විතීය මාවතක් නොමැතිව වෙනස් නොකළ යුතුය.
///
/// ඔබේ අරමුණු සඳහා `Unique` භාවිතා කිරීම නිවැරදි දැයි ඔබට අවිනිශ්චිත නම්, දුර්වල අර්ථකථන ඇති `NonNull` භාවිතා කිරීම සලකා බලන්න.
///
///
/// `*mut T` මෙන් නොව, දර්ශකය කිසි විටෙකත් අවලංගු නොකළද, දර්ශකය සැමවිටම ශුන්‍ය නොවිය යුතුය.
/// මෙය එසේ වන්නේ එන්යූම්ස් විසින් මෙම තහනම් අගය වෙනස් කොට සැලකීමක් ලෙස භාවිතා කළ හැකිය-`Option<Unique<T>>` ට `Unique<T>` හා සමාන ප්‍රමාණයක් ඇත.
/// කෙසේ වෙතත්, දර්ශකය අවලංගු නොකළ හොත් එය තවමත් ගැටෙනු ඇත.
///
/// `*mut T` මෙන් නොව, `Unique<T>` යනු `T` ට වඩා සහසංයුජ වේ.
/// යුනික්ගේ අන්වර්ථකරණ අවශ්‍යතා සපුරාලන ඕනෑම වර්ගයකට මෙය සැමවිටම නිවැරදි විය යුතුය.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: මෙම සලකුණ විචල්‍යතාවයට ප්‍රතිවිපාක නැත, නමුත් අවශ්‍ය වේ
    // අපට තාර්කිකව `T` හිමිකමක් ඇති බව ඩ්‍රොප්ක් තේරුම් ගැනීමට.
    //
    // විස්තර සඳහා, බලන්න:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` `T` `Send` නම් දර්ශකයන් `Send` වේ, මන්ද ඔවුන් සඳහන් කරන දත්ත වලංගු නොවේ.
/// මෙම අන්වර්ථ ආක්‍රමණ වර්ගය පද්ධතියට බල රහිත බව සලකන්න;`Unique` භාවිතා කරමින් වියුක්ත කිරීම එය බලාත්මක කළ යුතුය.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` `T` `Sync` නම් දර්ශකයන් `Sync` වේ, මන්ද ඔවුන් සඳහන් කරන දත්ත වලංගු නොවේ.
/// මෙම අන්වර්ථ ආක්‍රමණ වර්ගය පද්ධතියට බල රහිත බව සලකන්න;`Unique` භාවිතා කරමින් වියුක්ත කිරීම එය බලාත්මක කළ යුතුය.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// නව `Unique` නිර්මාණය කරන්නේ අන්තරාදායක, නමුත් හොඳින් පෙළ ගැසී ඇති බැවිනි.
    ///
    /// `Vec::new` මෙන් කම්මැලි ලෙස වෙන් කරන වර්ග ආරම්භ කිරීම සඳහා මෙය ප්‍රයෝජනවත් වේ.
    ///
    /// දර්ශක අගය `T` සඳහා වලංගු දර්ශකයක් නිරූපණය කළ හැකි බව සලකන්න, එයින් අදහස් වන්නේ මෙය "not yet initialized" සෙන්ඩිනල් අගයක් ලෙස භාවිතා නොකළ යුතු බවයි.
    /// කම්මැලි ලෙස වෙන් කරන වර්ග වෙනත් ආකාරයකින් ආරම්භ කිරීම නිරීක්ෂණය කළ යුතුය.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // ආරක්ෂාව: mem::align_of() වලංගු, ශුන්‍ය නොවන දර්ශකයක් ලබා දෙයි.එම
        // මේ අනුව new_unchecked() ඇමතීමේ කොන්දේසි වලට ගරු කරනු ලැබේ.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// නව `Unique` නිර්මාණය කරයි.
    ///
    /// # Safety
    ///
    /// `ptr` ශුන්‍ය නොවන විය යුතුය.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // ආරක්ෂාව: අමතන්නා විසින් `ptr` ශුන්‍ය නොවන බවට සහතික විය යුතුය.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// `ptr` ශුන්‍ය නොවේ නම් නව `Unique` සාදයි.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // ආරක්ෂාව: දර්ශකය දැනටමත් පරීක්ෂා කර ඇති අතර එය ශුන්‍ය නොවේ.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// යටින් පවතින `*mut` දර්ශකය ලබා ගනී.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// අන්තර්ගතය අවලංගු කරයි.
    ///
    /// එහි ප්‍රති ing ලයක් ලෙස ඇති වන ආයු කාලය ස්වයංව බැඳී ඇති බැවින් මෙය "as if" ලෙස හැසිරේ. එය ඇත්ත වශයෙන්ම ණයට ගත් T හි නිදසුනකි.
    /// දිගු (unbound) ජීවිත කාලයක් අවශ්‍ය නම්, `&*my_ptr.as_ptr()` භාවිතා කරන්න.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // ආරක්ෂාව: අමතන්නා විසින් `self` සියල්ලම සපුරාලන බවට සහතික විය යුතුය
        // යොමු කිරීම සඳහා අවශ්‍යතා.
        unsafe { &*self.as_ptr() }
    }

    /// විකෘති ලෙස අන්තර්ගතය අවලංගු කරයි.
    ///
    /// එහි ප්‍රති ing ලයක් ලෙස ඇති වන ආයු කාලය ස්වයංව බැඳී ඇති බැවින් මෙය "as if" ලෙස හැසිරේ. එය ඇත්ත වශයෙන්ම ණයට ගත් T හි නිදසුනකි.
    /// දිගු (unbound) ජීවිත කාලයක් අවශ්‍ය නම්, `&mut *my_ptr.as_ptr()` භාවිතා කරන්න.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // ආරක්ෂාව: අමතන්නා විසින් `self` සියල්ලම සපුරාලන බවට සහතික විය යුතුය
        // විකෘති යොමු කිරීමක් සඳහා අවශ්‍යතා.
        unsafe { &mut *self.as_ptr() }
    }

    /// වෙනත් වර්ගයක දර්ශකයකට දමයි.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // ආරක්ෂාව: Unique::new_unchecked() නව අද්විතීය සහ අවශ්‍යතා නිර්මාණය කරයි
        // ලබා දී ඇති දර්ශකය ශුන්‍ය නොවිය යුතුය.
        // අප විසින් දර්ශකයක් ලෙස ස්වයංව ගමන් කරන බැවින් එය ශුන්‍ය විය නොහැක.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // ආරක්ෂාව: විකෘති යොමු කිරීමක් අහෝසි කළ නොහැක
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}