//! ප්‍රාථමික traits සහ වර්ගවල මූලික ගුණාංග නියෝජනය කරන වර්ග.
//!
//! Rust වර්ග ඒවායේ අභ්‍යන්තර ගුණාංග අනුව විවිධ ප්‍රයෝජනවත් ආකාරවලින් වර්ග කළ හැකිය.
//! මෙම වර්ගීකරණයන් traits ලෙස නිරූපණය කෙරේ.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// නූල් මායිම් හරහා මාරු කළ හැකි වර්ග.
///
/// සම්පාදකයා එය සුදුසු යැයි තීරණය කළ විට මෙම trait ස්වයංක්‍රීයව ක්‍රියාත්මක වේ.
///
/// 'සෙන්ඩ්' නොවන වර්ගයක උදාහරණයක් වන්නේ යොමු-ගණන් කිරීමේ දර්ශකය [`rc::Rc`][`Rc`] ය.
/// එකම යොමු-ගණනය කළ අගයට යොමු කරන නූල් දෙකක් [`Rc`] ක්ලෝන කිරීමට උත්සාහ කරන්නේ නම්, ඔවුන් එකවර විමර්ශන ගණන යාවත්කාලීන කිරීමට උත්සාහ කළ හැකිය, එය [undefined behavior][ub] වන බැවින් [`Rc`] පරමාණුක මෙහෙයුම් භාවිතා නොකරයි.
///
/// එහි ous ාති සහෝදරයා වන [`sync::Arc`][arc] පරමාණුක මෙහෙයුම් භාවිතා කරයි (යම්කිසි පොදු කාර්යයක් දරයි) ඒ අනුව `Send` වේ.
///
/// වැඩි විස්තර සඳහා [the Nomicon](../../nomicon/send-and-sync.html) බලන්න.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// සම්පාදනය කරන වේලාවේ දන්නා නියත ප්‍රමාණයක් සහිත වර්ග.
///
/// සියලුම වර්ගවල පරාමිතීන් සඳහා `Sized` හි ව්‍යංග බැඳීමක් ඇත.`?Sized` විශේෂ සින්ටැක්ස් සුදුසු නොවේ නම් මෙම සීමාව ඉවත් කිරීමට භාවිතා කළ හැකිය.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//දෝෂය: [i32] සඳහා ප්‍රමාණය ක්‍රියාත්මක නොවේ
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// එක් ව්‍යතිරේකය වන්නේ trait හි ව්‍යංග `Self` වර්ගයයි.
/// [trait වස්තුව] සමඟ නොගැලපෙන බැවින් trait සඳහා ව්‍යංග `Sized` බැඳී නොමැත, අර්ථ දැක්වීම අනුව, trait හට හැකි සෑම ක්‍රියාත්මක කරන්නන් සමඟ වැඩ කිරීමට අවශ්‍ය වන අතර එමඟින් ඕනෑම ප්‍රමාණයක් විය හැකිය.
///
///
/// Rust ඔබට `Sized` trait සමඟ බැඳීමට ඉඩ දුන්නද, පසුව ඔබට trait වස්තුවක් සෑදීමට එය භාවිතා කළ නොහැක:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // y ට ඉඩ දෙන්න: &dyn Bar= &Impl;//දෝෂය: trait `Bar` වස්තුවක් බවට පත් කළ නොහැක
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // පෙරනිමිය සඳහා, උදාහරණයක් ලෙස, `[T]: !Default` ඇගයීමට ලක් කළ යුතුය
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// "unsized" ගතික ප්‍රමාණයේ වර්ගයකට විය හැකි වර්ග.
///
/// උදාහරණයක් ලෙස, ප්‍රමාණයේ අරාව වර්ගය `[i8; 2]` `Unsize<[i8]>` සහ `Unsize<dyn fmt::Debug>` ක්‍රියාත්මක කරයි.
///
/// `Unsize` හි සියලුම ක්‍රියාත්මක කිරීම් සම්පාදකයා විසින් ස්වයංක්‍රීයව සපයනු ලැබේ.
///
/// `Unsize` සඳහා ක්‍රියාත්මක වන්නේ:
///
/// - `[T; N]` `Unsize<[T]>` වේ
/// - `T` `T: Trait` විට `Unsize<dyn Trait>` වේ
/// - `Foo<..., T, ...>` `Unsize<Foo<..., U, ...>>` නම්:
///   - `T: Unsize<U>`
///   - Foo යනු ව්‍යුහයකි
///   - `T` සම්බන්ධ වන වර්ගයක් ඇත්තේ `Foo` හි අවසාන ක්ෂේත්‍රයට පමණි
///   - `T` වෙනත් ක්ෂේත්‍රවල කොටසක් නොවේ
///   - `Bar<T>: Unsize<Bar<U>>`, `Foo` හි අවසාන ක්ෂේත්‍රයට `Bar<T>` වර්ගය තිබේ නම්
///
/// `Unsize` [`Rc`] වැනි "user-defined" බහාලුම්වල ගතික ප්‍රමාණයේ වර්ග අඩංගු වීමට ඉඩ දීම සඳහා [`ops::CoerceUnsized`] සමඟ භාවිතා වේ.
/// වැඩි විස්තර සඳහා [DST coercion RFC][RFC982] සහ [the nomicon entry on coercion][nomicon-coerce] බලන්න.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// රටා ගැලපීම් සඳහා භාවිතා කරන නියතයන් සඳහා අවශ්‍ය trait.
///
/// `PartialEq` ව්‍යුත්පන්න කරන ඕනෑම වර්ගයක් ස්වයංක්‍රීයව මෙම trait ක්‍රියාත්මක කරයි, එහි වර්ග පරාමිතීන් `Eq` ක්‍රියාත්මක කරන්නේද යන්න නොසලකා *.
///
/// `const` අයිතමයක මෙම trait ක්‍රියාත්මක නොකරන යම් වර්ගයක් තිබේ නම්, එම වර්ගය එක්කෝ (1.) `PartialEq` ක්‍රියාත්මක නොකරයි (එයින් අදහස් කරන්නේ නියතය එම සංසන්දනාත්මක ක්‍රමය සපයන්නේ නැත, කේත උත්පාදනය ලබා ගත හැකි යැයි උපකල්පනය කරයි), හෝ (2.) එය ක්‍රියාත්මක කරයි * `PartialEq` හි අනුවාදය (ව්‍යුහාත්මක-සමානාත්මතා සංසන්දනයකට අනුකූල නොවන බව අපි උපකල්පනය කරමු).
///
///
/// ඉහත අවස්ථා දෙකෙන් ම, රටා ගැළපුමක දී එවැනි නියතයක් භාවිතා කිරීම අපි ප්‍රතික්ෂේප කරමු.
///
/// මෙම trait වෙත ගුණාංග පදනම් කරගත් සැලසුමෙන් සංක්‍රමණය වීමට පෙළඹවූ [structural match RFC][RFC1445] සහ [issue 63438] ද බලන්න.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// රටා ගැලපීම් සඳහා භාවිතා කරන නියතයන් සඳහා අවශ්‍ය trait.
///
/// `Eq` ව්‍යුත්පන්න කරන ඕනෑම වර්ගයක් ස්වයංක්‍රීයව මෙම trait ක්‍රියාත්මක කරයි, එහි වර්ග පරාමිතීන් `Eq` ක්‍රියාත්මක කරන්නේද යන්න නොසලකා *.
///
/// මෙය අපගේ වර්ගයේ පද්ධතියේ සීමාවක් ඉක්මවා වැඩ කිරීමකි.
///
/// # Background
///
/// රටා ගැලපීම් සඳහා භාවිතා කරන කොන්ස්ට් වර්ගයට `#[derive(PartialEq, Eq)]` ගුණාංගය අවශ්‍ය බව අපට අවශ්‍යය.
///
/// වඩාත් පරමාදර්ශී ලෝකයක, අපට ලබා දී ඇති වර්ගය `StructuralPartialEq` trait *සහ*`Eq` trait යන දෙකම ක්‍රියාත්මක කරන්නේ දැයි පරීක්ෂා කිරීමෙන් අපට එම අවශ්‍යතාවය පරීක්ෂා කළ හැකිය.
/// කෙසේ වෙතත්, ඔබට *X* X * කරන ADTs තිබිය හැකි අතර, සම්පාදකයා පිළිගැනීමට අපට අවශ්‍ය නඩුවකි, නමුත් නියතයේ වර්ගය `Eq` ක්‍රියාත්මක කිරීමට අසමත් වේ.
///
/// එනම්, මෙවැනි නඩුවක්:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (ඉහත කේතයේ ඇති ගැටළුව නම් `Wrap<fn(&())>`, `PartialEq` හෝ `Eq` ක්‍රියාත්මක නොකිරීමයි, මන්ද `සඳහා <'a> fn(&'a _)` does not implement those traits.)
///
/// එබැවින් අපට `StructuralPartialEq` සහ හුදෙක් `Eq` සඳහා බොළඳ චෙක්පත් මත විශ්වාසය තැබිය නොහැක.
///
/// මේ සඳහා වැඩ කිරීම සඳහා, අපි එක් එක් (`#[derive(PartialEq)]` සහ `#[derive(Eq)]`) ව්‍යුත්පන්න දෙකෙන් එන්නත් කරන ලද වෙනම traits දෙකක් භාවිතා කරන අතර ව්‍යුහාත්මක-ගැලපුම් පරීක්ෂාවේ කොටසක් ලෙස ඒ දෙකම තිබේදැයි පරීක්ෂා කරන්න.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// බිටු පිටපත් කිරීමෙන් සරලවම අනුපිටපත් කළ හැකි වර්ග.
///
/// පෙරනිමියෙන්, විචල්‍ය බන්ධනවල 'චලනය වන අර්ථකථන' ඇත.වෙනත් විදිහකින්:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` `y` වෙත මාරු වී ඇති අතර එය භාවිතා කළ නොහැක
///
/// // println! ("{: ?}", x);//දෝෂය: ගෙන ගිය අගය භාවිතා කිරීම
/// ```
///
/// කෙසේ වෙතත්, යම් වර්ගයක් `Copy` ක්‍රියාත්මක කරන්නේ නම්, ඒ වෙනුවට 'පිටපත් අර්ථ නිරූපණයන්' ඇත:
///
/// ```
/// // අපට `Copy` ක්‍රියාත්මක කිරීමක් ලබා ගත හැකිය.
/// // `Clone` එය `Copy` හි සුපිරි මාර්ගයක් බැවින් ද අවශ්‍ය වේ.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` යනු `x` හි පිටපතකි
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// මෙම උදාහරණ දෙකෙහි ඇති එකම වෙනස වන්නේ පැවරුමෙන් පසු ඔබට `x` වෙත පිවිසීමට අවසර තිබේද යන්නයි.
/// කබාය යටතේ, පිටපතක් සහ පියවරක් යන දෙකම බිටු මතකයේ පිටපත් කිරීමට හේතු විය හැක, මෙය සමහර විට ප්‍රශස්ත කර ඇත.
///
/// ## `Copy` ක්‍රියාත්මක කරන්නේ කෙසේද?
///
/// ඔබේ වර්ගය මත `Copy` ක්‍රියාත්මක කිරීමට ක්‍රම දෙකක් තිබේ.සරලම දෙය නම් `derive` භාවිතා කිරීමයි:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// ඔබට `Copy` සහ `Clone` අතින් ක්‍රියාත්මක කළ හැකිය:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// මේ දෙක අතර කුඩා වෙනසක් ඇත: `derive` උපායමාර්ගය සෑම විටම අපේක්ෂා නොකරන ආකාරයේ පරාමිතීන් මත `Copy` බැඳී ඇත.
///
/// ## `Copy` සහ `Clone` අතර වෙනස කුමක්ද?
///
/// පිටපත් ව්‍යංගයෙන් සිදු වේ, උදාහරණයක් ලෙස `y = x` පැවරුමේ කොටසක් ලෙස.`Copy` හි හැසිරීම අධික ලෙස පැටවිය නොහැක;එය සෑම විටම සරල බුද්ධිමත් පිටපතකි.
///
/// ක්ලෝනකරණය යනු පැහැදිලි ක්‍රියාවකි, `x.clone()`.[`Clone`] ක්‍රියාත්මක කිරීමෙන් අගයන් ආරක්ෂිතව අනුපිටපත් කිරීමට අවශ්‍ය ඕනෑම වර්ගයක විශේෂිත හැසිරීමක් ලබා දිය හැකිය.
/// නිදසුනක් ලෙස, [`String`] සඳහා [`Clone`] ක්‍රියාත්මක කිරීම සඳහා ගොඩවල්වල පෙන්වා ඇති නූල් බෆරය පිටපත් කිරීම අවශ්‍ය වේ.
/// [`String`] අගයන්හි සරල බිට්වේස් පිටපතක් හුදෙක් දර්ශකය පිටපත් කරනු ඇති අතර එමඟින් දෙවරක් නිදහස් රේඛාවක් ලැබෙනු ඇත.
/// මෙම හේතුව නිසා, [`String`] යනු [`Clone`] නමුත් `Copy` නොවේ.
///
/// [`Clone`] යනු `Copy` හි සුපිරි මාර්ගයකි, එබැවින් `Copy` වන සෑම දෙයක්ම [`Clone`] ක්‍රියාත්මක කළ යුතුය.
/// වර්ගයක් `Copy` නම් එහි [`Clone`] ක්‍රියාත්මක කිරීමට අවශ්‍ය වන්නේ `*self` ආපසු ලබා දීම පමණි (ඉහත උදාහරණය බලන්න).
///
/// ## මගේ වර්ගය `Copy` විය හැක්කේ කවදාද?
///
/// වර්ගයකට එහි සියලුම සංරචක `Copy` ක්‍රියාත්මක කරන්නේ නම් `Copy` ක්‍රියාත්මක කළ හැකිය.උදාහරණයක් ලෙස, මෙම ව්‍යුහය `Copy` විය හැකිය:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// ව්‍යුහයක් `Copy` විය හැකි අතර [`i32`] යනු `Copy` වේ, එබැවින් `Point` `Copy` වීමට සුදුසුකම් ලබයි.
/// ඊට වෙනස්ව, සලකා බලන්න
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// `PointList` හට `Copy` ක්‍රියාත්මක කළ නොහැක, මන්ද [`Vec<T>`] `Copy` නොවන බැවිනි.අපි `Copy` ක්‍රියාත්මක කිරීම ව්‍යුත්පන්න කිරීමට උත්සාහ කළහොත්, අපට දෝෂයක් ලැබෙනු ඇත:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// හවුල් යොමු කිරීම් (`&T`) ද `Copy` වේ, එබැවින් වර්ගයක් `Copy` විය හැකිය, එය `T` වර්ගවල හවුල් යොමු කිරීම් තිබියදීත් * *`Copy` නොවේ.
/// `Copy` ක්‍රියාත්මක කළ හැකි පහත දැක්වෙන ව්‍යුහය සලකා බලන්න, මන්ද එය සතුව ඇත්තේ අපගේ 'කොපි' නොවන `PointList` වර්ගයට ඉහළින් * හවුල් යොමු කිරීමක් පමණි:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## මගේ වර්ගය `Copy` විය නොහැකි විට *?
///
/// සමහර වර්ග ආරක්ෂිතව පිටපත් කළ නොහැක.උදාහරණයක් ලෙස, `&mut T` පිටපත් කිරීම අන්වර්ථ විකෘති යොමු කිරීමක් නිර්මාණය කරයි.
/// [`String`] පිටපත් කිරීමෙන් [`String`] බෆරය කළමනාකරණය කිරීමේ වගකීම අනුපිටපත් වන අතර එය දෙගුණයකින් තොර වේ.
///
/// [`Drop`] ක්‍රියාත්මක කරන ඕනෑම වර්ගයක් `Copy` විය නොහැක, මන්ද එය තමන්ගේම [`size_of::<T>`] බයිට් වලට අමතරව යම් සම්පතක් කළමනාකරණය කරන බැවිනි.
///
/// 'පිටපත්' නොවන දත්ත අඩංගු ව්‍යුහයක් හෝ එනුම් එකක් මත `Copy` ක්‍රියාත්මක කිරීමට ඔබ උත්සාහ කරන්නේ නම්, ඔබට දෝෂය [E0204] ලැබෙනු ඇත.
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## මගේ වර්ගය `Copy` විය යුත්තේ කවදාද?
///
/// පොදුවේ ගත් කල, ඔබේ වර්ගය _can_ `Copy` ක්‍රියාත්මක කරන්නේ නම්, එය කළ යුතුය.
/// `Copy` ක්‍රියාත්මක කිරීම ඔබේ වර්ගයේ පොදු API හි කොටසක් බව මතක තබා ගන්න.
/// future හි වර්ගය 'කොපි' නොවන බවට පත්විය හැකි නම්, බිඳෙන API වෙනසක් වළක්වා ගැනීම සඳහා දැන් `Copy` ක්‍රියාත්මක කිරීම මඟ හැරීම විචක්ෂණශීලී විය හැකිය.
///
/// ## අතිරේක ක්රියාත්මක කරන්නන්
///
/// [implementors listed below][impls] ට අමතරව, පහත දැක්වෙන වර්ග ද `Copy` ක්‍රියාත්මක කරයි:
///
/// * ක්‍රියාකාරී අයිතම වර්ග (එනම්, එක් එක් ශ්‍රිතය සඳහා අර්ථ දක්වා ඇති විශේෂිත වර්ග)
/// * ක්‍රියාකාරී දර්ශක වර්ග (උදා: `fn() -> i32`)
/// * අයිතම වර්ගය `Copy` (උදා: `[i32; 123456]`) ද ක්‍රියාත්මක කරන්නේ නම්, සියලු ප්‍රමාණ සඳහා අරා වර්ග
/// * එක් එක් සංරචකය `Copy` (උදා: `()`, `(i32, bool)`) ද ක්‍රියාත්මක කරන්නේ නම් ටුපල් වර්ග
/// * සංවෘත වර්ග, ඒවා පරිසරයෙන් කිසිදු වටිනාකමක් ලබා නොගන්නේ නම් හෝ අල්ලා ගන්නා ලද සියලුම අගයන් `Copy` ක්‍රියාත්මක කරන්නේ නම්.
///   හවුල් යොමු කිරීම මඟින් ග්‍රහණය කරගත් විචල්‍යයන් සැමවිටම ක්‍රියාත්මක වන්නේ `Copy` (යොමු කිරීම සිදු නොවුනත්) වන අතර විකෘති යොමු මඟින් ග්‍රහණය කරගත් විචල්‍යයන් කිසි විටෙකත් `Copy` ක්‍රියාත්මක නොකරයි.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) සෑහීමකට පත්නොවන ජීවිත සීමාවන් නිසා `Copy` ක්‍රියාත්මක නොකරන වර්ගයක් පිටපත් කිරීමට මෙය ඉඩ දෙයි (`A<'static>: Copy` සහ `A<'_>: Clone` පමණක් ඇති විට `A<'_>` පිටපත් කිරීම).
// අපට දැන් මෙම ගුණාංගය ඇත්තේ සම්මත පුස්තකාලයේ දැනටමත් පවතින `Copy` හි විශේෂීකරණයන් ස්වල්පයක් ඇති නිසා පමණක් වන අතර, මෙම හැසිරීම ආරක්ෂිතව තබා ගැනීමට ක්‍රමයක් නොමැත.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// trait `Copy` හි ආවේගයක් ජනනය කරන ව්‍යුත්පන්න සාර්ව.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// නූල් අතර යොමු කිරීම් බෙදාගැනීම ආරක්ෂිත වන වර්ග.
///
/// සම්පාදකයා එය සුදුසු යැයි තීරණය කළ විට මෙම trait ස්වයංක්‍රීයව ක්‍රියාත්මක වේ.
///
/// නිශ්චිත අර්ථ දැක්වීම නම්: `T` වර්ගයක් [`Sync`] නම් සහ `&T` [`Send`] නම් පමණි.
/// වෙනත් වචන වලින් කිවහොත්, නූල් අතර `&T` යොමුව පසු කිරීමේදී [undefined behavior][ub] (දත්ත රේස් ඇතුළුව) සඳහා හැකියාවක් නොමැති නම්.
///
/// යමෙකු අපේක්ෂා කරන පරිදි, [`u8`] සහ [`f64`] වැනි ප්‍රාථමික වර්ග සියල්ලම [`Sync`] වන අතර, ඒවා අඩංගු වන්නේ ටුපල්ස්, ස්ට්‍රක්ට්ස් සහ එනූම්ස් වැනි සරල සමස්ත වර්ගයන්ය.
/// මූලික [`Sync`] වර්ග සඳහා තවත් උදාහරණ අතර `&T` වැනි "immutable" වර්ග සහ සරල උරුම විකෘතිතා ඇති [`Box<T>`][box], [`Vec<T>`][vec] සහ වෙනත් බොහෝ එකතු වර්ග ඇතුළත් වේ.
///
/// (සාමාන්‍ය පරාමිතීන් ඒවායේ බහාලුම [`සමමුහුර්ත කිරීම] සඳහා [`Sync`] විය යුතුය.)
///
/// අර්ථ දැක්වීමේ තරමක් පුදුම සහගත ප්‍රතිවිපාකය නම්, `&mut T` යනු `Sync` (`T` යනු `Sync` නම්) එය සමමුහුර්ත නොවන විකෘතියක් ලබා දිය හැකි බවක් පෙනෙන්නට තිබුණත්.
/// උපක්‍රමය නම්, හවුල් යොමුවකට (එනම් `& &mut T`) පිටුපස ඇති විකෘති යොමු කිරීමක් කියවීමට පමණි, එය `& &T` මෙන් ය.
/// එබැවින් දත්ත තරඟයක අවදානමක් නොමැත.
///
/// `Sync` නොවන වර්ග යනු "interior mutability" සහ [`RefCell`][refcell] වැනි නූල්-ආරක්ෂිත නොවන ආකාරයෙන් "interior mutability" ඇති ඒවාය.
/// මෙම වර්ගවල වෙනස් කළ නොහැකි, හවුල් යොමු කිරීමක් හරහා පවා ඒවායේ අන්තර්ගතය විකෘති කිරීමට ඉඩ ලබා දේ.
/// උදාහරණයක් ලෙස [`Cell<T>`][cell] හි `set` ක්‍රමය `&self` ගනී, එබැවින් එයට අවශ්‍ය වන්නේ හවුල් යොමු [`&Cell<T>`][cell] පමණි.
/// මෙම ක්‍රමය සමමුහුර්තකරණය සිදු නොකරයි, එබැවින් [`Cell`][cell] `Sync` විය නොහැක.
///
/// `සින්ක් 'නොවන වර්ගයක තවත් උදාහරණයක් වන්නේ යොමු ගණන් කිරීමේ ලක්ෂ්‍යය [`Rc`][rc] ය.
/// [`&Rc<T>`][rc] හි ඕනෑම සඳහනක් ලබා දී ඇති විට, ඔබට නව [`Rc<T>`][rc] ක්ලෝන කළ හැකිය, පරමාණුක නොවන ආකාරයෙන් යොමු ගණන් වෙනස් කරයි.
///
/// යමෙකුට නූල්-ආරක්ෂිත අභ්‍යන්තර විකෘතිතාව අවශ්‍ය වූ විට, Rust විසින් [atomic data types] මෙන්ම [`sync::Mutex`][mutex] සහ [`sync::RwLock`][rwlock] හරහා පැහැදිලි අගුලු දැමීමද සපයයි.
/// මෙම වර්ගයන් ඕනෑම විකෘතියකට දත්ත තරඟ ඇති කළ නොහැකි බව සහතික කරයි, එබැවින් වර්ග `Sync` වේ.
/// ඒ හා සමානව, [`sync::Arc`][arc] විසින් [`Rc`][rc] හි නූල්-ආරක්ෂිත ඇනලොග් සපයයි.
///
/// අභ්‍යන්තර විකෘතිතා ඇති ඕනෑම වර්ගයක් value(s) වටා [`cell::UnsafeCell`][unsafecell] එතීම භාවිතා කළ යුතු අතර එය හවුල් යොමු කිරීමක් හරහා විකෘති කළ හැකිය.
/// මෙය කිරීමට අපොහොසත් වීම [undefined behavior][ub] වේ.
/// උදාහරණයක් ලෙස, `&T` සිට `&mut T` දක්වා [සම්ප්‍රේෂණය][සම්ප්‍රේෂණය] අවලංගුය.
///
/// `Sync` පිළිබඳ වැඩි විස්තර සඳහා [the Nomicon][nomicon-send-and-sync] බලන්න.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): බීටා හි `rustc_on_unimplemented` ඉඩම්වල සටහන් එක් කිරීමට සහාය වූ පසු, අවශ්‍යතා දාමයේ වසා දැමීමක් කොතැනක හෝ තිබේදැයි පරීක්ෂා කිරීම සඳහා එය දීර් has කර ඇත, එය (#48534) ලෙස දිගු කරන්න:
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// "act like" සතුව `T` ඇති දේවල් සලකුණු කිරීමට භාවිතා කරන ශුන්‍ය ප්‍රමාණයේ වර්ගය.
///
/// ඔබේ වර්ගයට `PhantomData<T>` ක්ෂේත්‍රයක් එක් කිරීම සම්පාදකයාට පවසන්නේ ඔබේ වර්ගය ක්‍රියා කරන්නේ `T` වර්ගයේ වටිනාකමක් ගබඩා කළත් එය ඇත්ත වශයෙන්ම නොවුනත් බවයි.
/// සමහර ආරක්‍ෂිත ගුණාංග ගණනය කිරීමේදී මෙම තොරතුරු භාවිතා වේ.
///
/// `PhantomData<T>` භාවිතා කරන්නේ කෙසේද යන්න පිළිබඳ වඩාත් ගැඹුරු පැහැදිලි කිරීමක් සඳහා කරුණාකර [the Nomicon](../../nomicon/phantom-data.html) බලන්න.
///
/// # භයානක සටහනක්
///
/// ඔවුන් දෙදෙනාටම බියජනක නම් තිබුණද, `PhantomData` සහ 'ෆැන්ටම් වර්ග' සම්බන්ධ නමුත් ඒවා සමාන නොවේ.ෆැන්ටම් වර්ගයේ පරාමිතිය යනු කිසි විටෙකත් භාවිතා නොකරන ආකාරයේ පරාමිතියකි.
/// Rust හි, මෙය බොහෝ විට සම්පාදකයාට පැමිණිලි කිරීමට හේතු වන අතර විසඳුම වන්නේ `PhantomData` මාර්ගයෙන් "dummy" භාවිතය එකතු කිරීමයි.
///
/// # Examples
///
/// ## භාවිතා නොකළ ජීවිත කාලය පරාමිතීන්
///
/// සමහර විට අනාරක්ෂිත කේතයක කොටසක් ලෙස, `PhantomData` සඳහා වඩාත් පොදු භාවිත අවස්ථාව වන්නේ භාවිතයට නොගත් ජීවිත කාල පරාමිතියක් ඇති ව්‍යුහයකි.
/// නිදසුනක් ලෙස, මෙහි `*const T` වර්ගයේ දර්ශක දෙකක් ඇති ව්‍යුහාත්මක `Slice` වේ, අනුමාන වශයෙන් කොතැනක හෝ අරාවකට යොමු කරයි:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// මෙහි අරමුණ වන්නේ යටින් පවතින දත්ත වලංගු වන්නේ `'a` ජීවිත කාලය සඳහා පමණි, එබැවින් `Slice` `'a` ඉක්මවා නොයා යුතුය.
/// කෙසේ වෙතත්, `'a` ජීවිත කාලය පුරාම කිසිදු භාවිතයක් නොමැති බැවින් මෙම අභිප්‍රාය කේතය තුළ ප්‍රකාශ නොවේ. එබැවින් එය අදාළ වන්නේ කුමන දත්ත වලටද යන්න පැහැදිලි නැත.
/// අපට මෙය නිවැරදි කළ හැක්කේ *`Slice` ව්‍යුහයේ `&'a T` යොමුව ඇති ආකාරයට* ක්‍රියා කිරීමට සම්පාදකයාට පැවසීමෙන් ය:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// `T: 'a` හි ව්‍යාඛ්‍යාවද මේ සඳහා අවශ්‍ය වේ, `T` හි ඕනෑම යොමු කිරීමක් `'a` ජීවිත කාලය පුරාම වලංගු බව පෙන්නුම් කරයි.
///
/// `Slice` ආරම්භ කිරීමේදී ඔබ `phantom` ක්ෂේත්‍රය සඳහා `PhantomData` අගය ලබා දෙයි:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## භාවිතා නොකළ වර්ග පරාමිතීන්
///
/// සමහර විට ඔබ භාවිතා නොකරන ආකාරයේ පරාමිතීන් ඇති අතර එය ව්‍යුහයක් "tied" ට කුමන ආකාරයේ දත්තද යන්න දක්වයි, එම දත්ත ව්‍යුහය තුළම සත්‍ය වශයෙන්ම සොයාගත නොහැකි වුවද.
/// [FFI] සමඟ මෙය පැන නගින උදාහරණයක් මෙන්න.
/// විදේශීය අතුරුමුහුණත විවිධ වර්ගවල Rust අගයන් යොමු කිරීම සඳහා `*mut ()` වර්ගයේ හැසිරවීම් භාවිතා කරයි.
/// ව්‍යුහය `ExternalResource` හි ෆැන්ටම් වර්ගයේ පරාමිතියක් භාවිතා කරමින් අපි Rust වර්ගය නිරීක්ෂණය කරමු.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## හිමිකාරිත්වය සහ පහත වැටීමේ චෙක්පත
///
/// `PhantomData<T>` වර්ගයේ ක්ෂේත්‍රයක් එක් කිරීමෙන් පෙන්නුම් කරන්නේ ඔබේ වර්ගයට `T` වර්ගයේ දත්ත ඇති බවයි.මෙයින් ගම්‍ය වන්නේ ඔබේ වර්ගය අතහැර දැමූ විට, එය `T` වර්ගයේ අවස්ථා එකක් හෝ කිහිපයක් අතහැර දැමිය හැකි බවයි.
/// මෙය Rust සම්පාදකයාගේ [drop check] විශ්ලේෂණයට බලපායි.
///
/// ඔබේ ව්‍යුහය ඇත්ත වශයෙන්ම `T` වර්ගයේ දත්ත *සතුව නොමැති නම්, හිමිකාරිත්වය සඳහන් නොකිරීමට `PhantomData<&'a T>` (ideally) හෝ `PhantomData<* const T>` වැනි යොමු වර්ගයක් භාවිතා කිරීම වඩා හොඳය (ජීවිත කාලයම අදාළ නොවේ නම්).
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// සම්පාදක-අභ්‍යන්තර trait, එනුම් විචාරකයින්ගේ වර්ගය දැක්වීමට භාවිතා කරයි.
///
/// මෙම trait සෑම වර්ගයකටම ස්වයංක්‍රීයව ක්‍රියාත්මක වන අතර [`mem::Discriminant`] සඳහා කිසිදු සහතිකයක් එක් නොකරයි.
/// `DiscriminantKind::Discriminant` සහ `mem::Discriminant` අතර සම්ප්‍රේෂණය කිරීම **නිර්වචනය නොකළ හැසිරීම** වේ.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// `mem::Discriminant` ට අවශ්‍ය trait bounds තෘප්තිමත් කළ යුතු වෙනස් කොට සැලකීමේ වර්ගය.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// සම්පාදක-අභ්‍යන්තර trait වර්ගයක අභ්‍යන්තරව කිසියම් `UnsafeCell` අඩංගු වේද යන්න තීරණය කිරීම සඳහා භාවිතා කරනු ලැබේ.
///
/// නිදසුනක් ලෙස, එම වර්ගයේ `static` කියවීමට පමණක් ස්ථිතික මතකයේ හෝ ලිවිය හැකි ස්ථිතික මතකයේ තිබේද යන්න මෙය බලපායි.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// ඇලවූ පසු ආරක්ෂිතව ගෙන යා හැකි වර්ග.
///
/// Rust හි නිශ්චල වර්ග පිළිබඳ අදහසක් නොමැති අතර, චලනයන් (උදා: පැවරුම හරහා හෝ [`mem::replace`] හරහා) සැමවිටම ආරක්ෂිත යැයි සලකයි.
///
/// [`Pin`][Pin] වර්ගය භාවිතා කරනුයේ වර්ගය පද්ධතිය හරහා ගමන් කිරීම වැළැක්වීම සඳහා ය.[`Pin<P<T>>`][Pin] එතීමෙන් ඔතා ඇති `P<T>` දර්ශකයන් පිටතට ගෙන යා නොහැක.
/// පින් කිරීම පිළිබඳ වැඩි විස්තර සඳහා [`pin` module] ප්‍රලේඛනය බලන්න.
///
/// `T` සඳහා `Unpin` trait ක්‍රියාත්මක කිරීම මඟින් වර්ගය ඉවත් කිරීමේ සීමාවන් ඉවත් කරයි, එමඟින් `T` වෙතින් [`Pin<P<T>>`][Pin] වෙතින් `T` පිටතට ගෙනයාමට ඉඩ සලසයි.
///
///
/// `Unpin` පින් නොකළ දත්ත සඳහා කිසිසේත්ම ප්‍රතිවිපාක නොමැත.
/// විශේෂයෙන්, [`mem::replace`] සතුටින් `!Unpin` දත්ත ගෙන යයි (එය ඕනෑම `&mut T` සඳහා ක්‍රියා කරයි, `T: Unpin` විට පමණක් නොවේ).
/// කෙසේ වෙතත්, ඔබට [`Pin<P<T>>`][Pin] තුළ ඔතා ඇති දත්ත මත [`mem::replace`] භාවිතා කළ නොහැක, මන්ද ඒ සඳහා ඔබට අවශ්‍ය `&mut T` ලබා ගත නොහැකි අතර, * මෙම පද්ධතිය ක්‍රියාත්මක වීමට හේතුව එයයි.
///
/// උදාහරණයක් ලෙස, මෙය කළ හැක්කේ `Unpin` ක්‍රියාත්මක කරන වර්ග මත පමණි:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // `mem::replace` ඇමතීමට අපට විකෘති යොමු කිරීමක් අවශ්‍ය වේ.
/// // `Pin::deref_mut` ආයාචනා කිරීමෙන් අපට එවැනි සඳහනක් ලබා ගත හැකිය, නමුත් එය කළ හැක්කේ `String` `Unpin` ක්‍රියාත්මක කරන බැවිනි.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// මෙම trait සෑම වර්ගයකටම පාහේ ස්වයංක්‍රීයව ක්‍රියාත්මක වේ.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// `Unpin` ක්‍රියාත්මක නොකරන සලකුණු වර්ගයකි.
///
/// වර්ගයක `PhantomPinned` අඩංගු නම්, එය පෙරනිමියෙන් `Unpin` ක්‍රියාත්මක නොකරනු ඇත.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// ප්‍රාථමික වර්ග සඳහා `Copy` ක්‍රියාත්මක කිරීම.
///
/// Rust හි විස්තර කළ නොහැකි ක්‍රියාත්මක කිරීම් `traits::SelectionContext::copy_clone_conditions()` හි `rustc_trait_selection` හි ක්‍රියාත්මක වේ.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// හවුල් යොමු කිරීම් පිටපත් කළ හැකි නමුත් විකෘති යොමු කිරීම් *කළ නොහැක*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}