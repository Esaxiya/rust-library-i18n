//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// `char` ට තිබිය හැකි ඉහළම වලංගු කේත ලක්ෂ්‍යය.
    ///
    /// `char` යනු [Unicode Scalar Value], එයින් අදහස් වන්නේ එය [Code Point] වන නමුත් යම් පරාසයක් තුළ ඇති ඒවා පමණි.
    /// `MAX` වලංගු [Unicode Scalar Value] වල ඉහළම වලංගු කේත ලක්ෂ්‍යය වේ.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` විකේතන දෝෂයක් නිරූපණය කිරීම සඳහා () යුනිකෝඩ් හි භාවිතා වේ.
    ///
    /// නිදසුනක් ලෙස, [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy) වෙත වැරදි ලෙස සාදන ලද UTF-8 බයිට් ලබා දීමේදී එය සිදුවිය හැකිය.
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// `char` සහ `str` ක්‍රම වල යුනිකෝඩ් කොටස් පදනම් වූ [Unicode](http://www.unicode.org/) අනුවාදය.
    ///
    /// යුනිකෝඩ් හි නව සංස්කරණ නිතිපතා නිකුත් කරන අතර පසුව යුනිකෝඩ් මත පදනම්ව සම්මත පුස්තකාලයේ ඇති සියලුම ක්‍රම යාවත්කාලීන වේ.
    /// එබැවින් සමහර `char` සහ `str` ක්‍රම වල හැසිරීම සහ මෙම නියතයේ වටිනාකම කාලයත් සමඟ වෙනස් වේ.
    /// මෙය * බිඳෙන වෙනසක් ලෙස නොසැලකේ.
    ///
    /// අනුවාද අංකනය කිරීමේ ක්‍රමය [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) හි විස්තර කර ඇත.
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// `iter` හි UTF-16 කේතනය කරන ලද කේත ලක්ෂ්‍යයන් හරහා අනුකාරකයක් සාදයි, යුගල නොකළ අන්‍යාගමිකයන් 'Err' ලෙස ආපසු එවයි.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// `Err` ප්‍රති results ල ආදේශන අක්‍ෂරයෙන් ආදේශ කිරීමෙන් පාඩු සහිත විකේතකයක් ලබා ගත හැකිය:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// `u32` එකක් `char` බවට පරිවර්තනය කරයි.
    ///
    /// සියලුම වර්‍ග වලංගු [`u32`] වලංගු බව සලකන්න, ඒවා සමඟ එකකට දැමිය හැකිය
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// කෙසේ වෙතත්, ආපසු හැරීම සත්‍ය නොවේ: සියලුම වලංගු [`u32`] වලංගු නොවේ.
    /// `from_u32()` ආදානය `char` සඳහා වලංගු අගයක් නොවේ නම් `None` නැවත ලබා දෙනු ඇත.
    ///
    /// මෙම චෙක්පත් නොසලකා හරින මෙම ශ්‍රිතයේ අනාරක්ෂිත අනුවාදයක් සඳහා, [`from_u32_unchecked`] බලන්න.
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// ආදානය වලංගු `char` නොවන විට `None` නැවත ලබා දීම:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// වලංගු භාවය නොසලකා `u32` එකක් `char` බවට පරිවර්තනය කරයි.
    ///
    /// සියලුම වර්‍ග වලංගු [`u32`] වලංගු බව සලකන්න, ඒවා සමඟ එකකට දැමිය හැකිය
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// කෙසේ වෙතත්, ආපසු හැරීම සත්‍ය නොවේ: සියලුම වලංගු [`u32`] වලංගු නොවේ.
    /// `from_u32_unchecked()` මෙය නොසලකා හරිමින් `char` වෙත අන්ධ ලෙස දමනු ඇත, සමහර විට අවලංගු එකක් නිර්මාණය කරයි.
    ///
    ///
    /// # Safety
    ///
    /// මෙම ක්‍රියාව අනාරක්ෂිත බැවින් එය අවලංගු `char` අගයන් සාදයි.
    ///
    /// මෙම ශ්‍රිතයේ ආරක්ෂිත අනුවාදයක් සඳහා, [`from_u32`] ශ්‍රිතය බලන්න.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // ආරක්ෂාව: ආරක්ෂිත කොන්ත්රාත්තුව අමතන්නා විසින් තහවුරු කළ යුතුය.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// දී ඇති රේඩික්ස් හි ඉලක්කම් `char` බවට පරිවර්තනය කරයි.
    ///
    /// මෙහි 'radix' සමහර විට 'base' ලෙසද හැඳින්වේ.
    /// දෙකකින් යුත් රේඩික්ස් මඟින් පොදු අගයන් ලබා දීම සඳහා ද්විමය සංඛ්‍යාවක්, දහයක, දශමයක, සහ දහසය, හෙක්සැඩිසිමල් හි රේඩික්ස් දැක්වේ.
    ///
    /// අත්තනෝමතික රේඩිකල් සඳහා සහය දක්වයි.
    ///
    /// `from_digit()` දී ඇති රේඩික්ස් හි ආදානය ඉලක්කම් නොවේ නම් `None` නැවත ලබා දෙනු ඇත.
    ///
    /// # Panics
    ///
    /// 36 ට වඩා විශාල රේඩික්ස් එකක් ලබා දෙන්නේ නම් Panics.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // දශම 11 යනු 16 වන පාදයේ තනි ඉලක්කම් වේ
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// ආදානය ඉලක්කම් නොවන විට `None` නැවත ලබා දීම:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// විශාල රේඩික්ස් පසුකරමින් panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// දී ඇති රේඩික්ස් හි `char` ඉලක්කම් දැයි පරීක්ෂා කරයි.
    ///
    /// මෙහි 'radix' සමහර විට 'base' ලෙසද හැඳින්වේ.
    /// දෙකකින් යුත් රේඩික්ස් මඟින් පොදු අගයන් ලබා දීම සඳහා ද්විමය සංඛ්‍යාවක්, දහයක, දශමයක, සහ දහසය, හෙක්සැඩිසිමල් හි රේඩික්ස් දැක්වේ.
    ///
    /// අත්තනෝමතික රේඩිකල් සඳහා සහය දක්වයි.
    ///
    /// [`is_numeric()`] හා සසඳන විට, මෙම ශ්‍රිතය හඳුනා ගන්නේ `0-9`, `a-z` සහ `A-Z` අක්ෂර පමණි.
    ///
    /// 'Digit' පහත දැක්වෙන අක්ෂර පමණක් ලෙස අර්ථ දක්වා ඇත:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// 'digit' පිළිබඳ වඩාත් පුළුල් අවබෝධයක් සඳහා, [`is_numeric()`] බලන්න.
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// 36 ට වඩා විශාල රේඩික්ස් එකක් ලබා දෙන්නේ නම් Panics.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// විශාල රේඩික්ස් පසුකරමින් panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// දී ඇති රේඩික්ස් හි `char` ඉලක්කම් බවට පරිවර්තනය කරයි.
    ///
    /// මෙහි 'radix' සමහර විට 'base' ලෙසද හැඳින්වේ.
    /// දෙකකින් යුත් රේඩික්ස් මඟින් පොදු අගයන් ලබා දීම සඳහා ද්විමය සංඛ්‍යාවක්, දහයක, දශමයක, සහ දහසය, හෙක්සැඩිසිමල් හි රේඩික්ස් දැක්වේ.
    ///
    /// අත්තනෝමතික රේඩිකල් සඳහා සහය දක්වයි.
    ///
    /// 'Digit' පහත දැක්වෙන අක්ෂර පමණක් ලෙස අර්ථ දක්වා ඇත:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// `char` දී ඇති රේඩික්ස් හි ඉලක්කම් වෙත යොමු නොවන්නේ නම් `None` ලබා දෙයි.
    ///
    /// # Panics
    ///
    /// 36 ට වඩා විශාල රේඩික්ස් එකක් ලබා දෙන්නේ නම් Panics.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// ඉලක්කම් නොවන සමත් වීමෙන් අසමත් වේ:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// විශාල රේඩික්ස් පසුකරමින් panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // `radix` නියත හා 10 හෝ ඊට අඩු අවස්ථාවන් සඳහා ක්‍රියාත්මක කිරීමේ වේගය වැඩි දියුණු කිරීම සඳහා කේතය මෙහි බෙදී ඇත
        //
        let val = if likely(radix <= 10) {
            // ඉලක්කම් නොවේ නම්, රේඩික්ස් වලට වඩා විශාල සංඛ්‍යාවක් නිර්මාණය වේ.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// අක්ෂරයක ෂඩාස්රාකාර යුනිකෝඩ් ගැලවීම 'චාර්' ලෙස ලබා දෙන ඉරේටරයක් ලබා දෙයි.
    ///
    /// මෙය `\u{NNNNNN}` ආකෘතියේ Rust සින්ටැක්ස් සමඟ අක්ෂර වලින් ගැලවී යනු ඇත, එහිදී `NNNNNN` යනු ෂඩාස්රාකාර නිරූපණයකි.
    ///
    ///
    /// # Examples
    ///
    /// අනුකාරකයක් ලෙස:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` කෙලින්ම භාවිතා කිරීම:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// දෙකම සමාන වේ:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// `to_string` භාවිතා කිරීම:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // or-ing 1 මඟින් සහතික වන්නේ c==0 සඳහා කේතය ගණනය කරන්නේ එක් ඉලක්කම් මුද්‍රණය කළ යුතු බවත් (එය එකම වේ)(31, 32) ගලායාම වළක්වන බවත්ය.
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // වඩාත්ම වැදගත් හෙක්ස් ඉලක්කම් දර්ශකය
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// විස්තාරිත ග්‍රැෆේම් කේත ස්ථාන වලින් ගැලවීමට විකල්පයක් ලෙස ඉඩ දෙන `escape_debug` හි දීර් version අනුවාදයකි.
    /// නූල් ආරම්භයේදී ලකුණු රහිත ලකුණු වැනි අක්ෂර වඩා හොඳින් සංයුති කිරීමට මෙය අපට ඉඩ දෙයි.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// අක්ෂරයක වචනාර්ථයෙන් ගැලවීමේ කේතය 'char' ලෙස ලබා දෙන iterator එකක් ලබා දෙයි.
    ///
    /// මෙය `str` හෝ `char` හි `Debug` ක්‍රියාත්මක කිරීමට සමාන අක්ෂර වලින් ගැලවී යනු ඇත.
    ///
    ///
    /// # Examples
    ///
    /// අනුකාරකයක් ලෙස:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` කෙලින්ම භාවිතා කිරීම:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// දෙකම සමාන වේ:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// `to_string` භාවිතා කිරීම:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// අක්ෂරයක වචනාර්ථයෙන් ගැලවීමේ කේතය 'char' ලෙස ලබා දෙන iterator එකක් ලබා දෙයි.
    ///
    /// C ++ 11 සහ ඒ හා සමාන C-පවුල් භාෂා ඇතුළුව විවිධ භාෂාවලින් නීත්‍යානුකූල වන සාහිත්‍යකරුවන් බිහිකිරීමේ නැඹුරුවක් සහිතව පෙරනිමිය තෝරා ගනු ලැබේ.
    /// නිශ්චිත නීති:
    ///
    /// * ටැබ් එක `\t` ලෙස ගැලවී ඇත.
    /// * ප්‍රවාහනය නැවත පැමිණීම `\r` ලෙස ගැලවී ඇත.
    /// * රේඛීය සංග්‍රහය `\n` ලෙස ගැලවී ඇත.
    /// * තනි උපුටා දැක්වීම `\'` ලෙස ගැලවී ඇත.
    /// * ද්විත්ව උපුටා දැක්වීම `\"` ලෙස ගැලවී ඇත.
    /// * බැක්ස්ලෑෂ් `\\` ලෙස ගැලවී ඇත.
    /// * 'මුද්‍රණය කළ හැකි ASCII' පරාසයේ `0x20` .. `0x7e` ඇතුළත් ඕනෑම අක්ෂරයක් ගැලවී නැත.
    /// * අනෙක් සියලුම අක්ෂර සඳහා ෂඩාස්රාකාර යුනිකෝඩ් ගැලවී ඇත;[`escape_unicode`] බලන්න.
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// අනුකාරකයක් ලෙස:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` කෙලින්ම භාවිතා කිරීම:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// දෙකම සමාන වේ:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// `to_string` භාවිතා කිරීම:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// UTF-8 හි කේතනය කර ඇත්නම් මෙම `char` ට අවශ්‍ය බයිට් ගණන නැවත ලබා දෙයි.
    ///
    /// එම බයිට් ගණන සැමවිටම 1 ත් 4 ත් අතර වේ.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// `&str` වර්ගය එහි අන්තර්ගතය UTF-8 බව සහතික කරයි, එබැවින් එක් එක් කේත ලක්ෂ්‍යය `&str` එදිරිව `&str` එදිරිව `&str` ලෙස නිරූපණය කළහොත් ගතවන දිග සැසඳිය හැකිය:
    ///
    ///
    /// ```
    /// // අක්ෂර ලෙස
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // දෙකම බයිට් තුනක් ලෙස දැක්විය හැකිය
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // &str ලෙස, මේ දෙක UTF-8 හි කේතනය කර ඇත
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // අපට පේනවා ඔවුන් මුළු බයිට් හයක් ගන්නා බව ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... &str වගේ
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// UTF-16 හි කේතනය කර ඇත්නම් මෙම `char` ට අවශ්‍ය 16-බිට් කේත ඒකක ගණන ලබා දෙයි.
    ///
    ///
    /// මෙම සංකල්පය පිළිබඳ වැඩි විස්තර සඳහා [`len_utf8()`] සඳහා වන ප්‍රලේඛනය බලන්න.
    /// මෙම ශ්‍රිතය කැඩපතකි, නමුත් UTF-8 වෙනුවට UTF-16 සඳහා.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// සපයන ලද බයිට් බෆරයට මෙම අක්‍ෂරය UTF-8 ලෙස සංකේතවත් කර, පසුව කේතනය කළ අක්‍ෂරය අඩංගු බෆරයේ උප කොටස නැවත ලබා දේ.
    ///
    ///
    /// # Panics
    ///
    /// බෆරය ප්‍රමාණවත් නොවන්නේ නම් Panics.
    /// ඕනෑම `char` කේතනය කිරීමට තරම් දිග හතරක බෆරයක් විශාලය.
    ///
    /// # Examples
    ///
    /// මෙම උදාහරණ දෙකෙහිම, 'ß' කේතනය කිරීමට බයිට් දෙකක් ගනී.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// ඉතා කුඩා බෆරයක්:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // ආරක්ෂාව: `char` යනු අන්වාදේශයක් නොවේ, එබැවින් මෙය වලංගු UTF-8 වේ.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// මෙම අක්ෂරය UTF-16 ලෙස සපයා ඇති `u16` බෆරයට සංකේතවත් කරයි, පසුව කේතනය කළ අක්‍ෂරය අඩංගු බෆරයේ උප කොටස නැවත ලබා දෙයි.
    ///
    ///
    /// # Panics
    ///
    /// බෆරය ප්‍රමාණවත් නොවන්නේ නම් Panics.
    /// ඕනෑම `char` කේතනය කිරීමට තරම් දිග 2 බෆරයක් විශාලය.
    ///
    /// # Examples
    ///
    /// මෙම උදාහරණ දෙකෙහිම, '𝕊' කේතනය කිරීමට `u16` දෙකක් ගනී.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// ඉතා කුඩා බෆරයක්:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// මෙම `char` හි `Alphabetic` දේපල තිබේ නම් `true` ලබා දෙයි.
    ///
    /// `Alphabetic` [Unicode Standard] හි 4 වන පරිච්ඡේදයේ (චරිත ගුණාංග) විස්තර කර ඇති අතර [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] හි දක්වා ඇත.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // ආදරය බොහෝ දේ, නමුත් එය අකාරාදී නොවේ
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// මෙම `char` හි `Lowercase` දේපල තිබේ නම් `true` ලබා දෙයි.
    ///
    /// `Lowercase` [Unicode Standard] හි 4 වන පරිච්ඡේදයේ (චරිත ගුණාංග) විස්තර කර ඇති අතර [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] හි දක්වා ඇත.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // විවිධ චීන අක්ෂර සහ විරාම ලකුණු වලට නඩුවක් නොමැත, සහ:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// මෙම `char` හි `Uppercase` දේපල තිබේ නම් `true` ලබා දෙයි.
    ///
    /// `Uppercase` [Unicode Standard] හි 4 වන පරිච්ඡේදයේ (චරිත ගුණාංග) විස්තර කර ඇති අතර [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] හි දක්වා ඇත.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // විවිධ චීන අක්ෂර සහ විරාම ලකුණු වලට නඩුවක් නොමැත, සහ:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// මෙම `char` හි `White_Space` දේපල තිබේ නම් `true` ලබා දෙයි.
    ///
    /// `White_Space` [Unicode Character Database][ucd] [`PropList.txt`] හි දක්වා ඇත.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // නොබිඳිය හැකි ඉඩක්
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// මෙම `char` [`is_alphabetic()`] හෝ [`is_numeric()`] තෘප්තිමත් කරන්නේ නම් `true` ලබා දෙයි.
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// පාලක කේත සඳහා මෙම `char` පොදු කාණ්ඩය තිබේ නම් `true` ලබා දෙයි.
    ///
    /// පාලන කේත (`Cc` හි සාමාන්‍ය කාණ්ඩය සහිත කේත ලකුණු) [Unicode Standard] හි 4 වන පරිච්ඡේදයේ (චරිත ගුණාංග) විස්තර කර ඇති අතර [Unicode Character Database][ucd] [`UnicodeData.txt`] හි දක්වා ඇත.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// // U + 009C, STRING TERMINATOR
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// මෙම `char` හි `Grapheme_Extend` දේපල තිබේ නම් `true` ලබා දෙයි.
    ///
    /// `Grapheme_Extend` [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] හි විස්තර කර ඇති අතර [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] හි දක්වා ඇත.
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// මෙම `char` අංක සඳහා පොදු කාණ්ඩ වලින් එකක් තිබේ නම් `true` ලබා දෙයි.
    ///
    /// අංක සඳහා පොදු කාණ්ඩ (දශම සංඛ්‍යා සඳහා `Nd`, අකුරු වැනි සංඛ්‍යා අක්ෂර සඳහා `Nl`, සහ වෙනත් සංඛ්‍යාත්මක අක්ෂර සඳහා `No`) [Unicode Character Database][ucd] [`UnicodeData.txt`] හි දක්වා ඇත.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// මෙම `char` හි කුඩා අකුරු සිතියම්ගත කිරීම එක් හෝ වැඩි ගණනක් ලබා දෙන ඉරේටරයක් ලබා දෙයි
    /// `char`s.
    ///
    /// මෙම `char` හි කුඩා අකුරු සිතියමක් නොමැති නම්, iterator එකම `char` ලබා දෙයි.
    ///
    /// මෙම `char` හි [Unicode Character Database][ucd] [`UnicodeData.txt`] විසින් ලබා දී ඇති කුඩා-කුඩා සිතියම්කරණයක් තිබේ නම්, iterator මඟින් `char` ලබා දෙයි.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// මෙම `char` සඳහා විශේෂ සලකා බැලීම් අවශ්‍ය නම් (උදා: බහු `char`s) iterator මඟින් [`SpecialCasing.txt`] විසින් ලබා දෙන`char` (ය) ලබා දෙයි.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// මෙම මෙහෙයුම කොන්දේසි විරහිතව සිතියම්ගත කිරීම සිදු කරයි.එනම්, පරිවර්තනය සන්දර්භය හා භාෂාවෙන් ස්වාධීන වේ.
    ///
    /// [Unicode Standard] හි, 4 වන පරිච්ඡේදය (අක්ෂර ගුණාංග) පොදුවේ සිද්ධි සිතියම්ගත කිරීම ගැන සාකච්ඡා කරන අතර 3 වන පරිච්ඡේදයේ (Conformance) සිද්ධි පරිවර්තනය සඳහා පෙරනිමි ඇල්ගොරිතම සාකච්ඡා කරයි.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// අනුකාරකයක් ලෙස:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` කෙලින්ම භාවිතා කිරීම:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// දෙකම සමාන වේ:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// `to_string` භාවිතා කිරීම:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // සමහර විට ප්‍රති result ලය අක්ෂර එකකට වඩා වැඩිය:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // ලොකු අකුරු සහ සිම්පල් යන දෙකම නොමැති අක්ෂර තමන් බවට පරිවර්තනය වේ.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// මෙම `char` හි ලොකු අකුරු සිතියම්ගත කිරීම එකක් හෝ වැඩි ගණනක් ලබා දෙන iterator එකක් ලබා දෙයි
    /// `char`s.
    ///
    /// මෙම `char` හි ලොකු අකුරු සිතියමක් නොමැති නම්, iterator එකම `char` ලබා දෙයි.
    ///
    /// මෙම `char` හි [Unicode Character Database][ucd] [`UnicodeData.txt`] විසින් ලබා දී ඇති එක සිට එක දක්වා විශාල සිතියමක් තිබේ නම්, iterator මඟින් `char` ලබා දෙයි.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// මෙම `char` සඳහා විශේෂ සලකා බැලීම් අවශ්‍ය නම් (උදා: බහු `char`s) iterator මඟින් [`SpecialCasing.txt`] විසින් ලබා දෙන`char` (ය) ලබා දෙයි.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// මෙම මෙහෙයුම කොන්දේසි විරහිතව සිතියම්ගත කිරීම සිදු කරයි.එනම්, පරිවර්තනය සන්දර්භය හා භාෂාවෙන් ස්වාධීන වේ.
    ///
    /// [Unicode Standard] හි, 4 වන පරිච්ඡේදය (අක්ෂර ගුණාංග) පොදුවේ සිද්ධි සිතියම්ගත කිරීම ගැන සාකච්ඡා කරන අතර 3 වන පරිච්ඡේදයේ (Conformance) සිද්ධි පරිවර්තනය සඳහා පෙරනිමි ඇල්ගොරිතම සාකච්ඡා කරයි.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// අනුකාරකයක් ලෙස:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` කෙලින්ම භාවිතා කිරීම:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// දෙකම සමාන වේ:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// `to_string` භාවිතා කිරීම:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // සමහර විට ප්‍රති result ලය අක්ෂර එකකට වඩා වැඩිය:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // ලොකු අකුරු සහ සිම්පල් යන දෙකම නොමැති අක්ෂර තමන් බවට පරිවර්තනය වේ.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # පෙදෙසෙහි සටහන
    ///
    /// තුර්කි බසින්, ලතින් භාෂාවෙන් 'i' ට සමාන ආකාර දෙකක් වෙනුවට ආකාර පහක් ඇත:
    ///
    /// * 'Dotless': I/ı, සමහර විට ලියා ඇත
    /// * 'Dotted': /I
    ///
    /// සිම්පල් තිත් 'i' ලතින් භාෂාවට සමාන බව සලකන්න.එබැවින්:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// මෙහි `upper_i` හි අගය රඳා පවතින්නේ පෙළේ භාෂාව මත ය: අප `en-US` හි සිටී නම් එය `"I"` විය යුතුය, නමුත් අප `tr_TR` හි සිටී නම් එය `"İ"` විය යුතුය.
    /// `to_uppercase()` මෙය සැලකිල්ලට නොගනී, සහ:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// භාෂා පුරා පවතී.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// අගය ASCII පරාසය තුළ තිබේදැයි පරීක්ෂා කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// එහි ASCII ඉහළ නඩුවේ වටිනාකමේ පිටපතක් සමාන කරයි.
    ///
    /// ASCII අක්ෂර 'a' සිට 'z' දක්වා 'A' සිට 'Z' දක්වා සිතියම් ගත කර ඇත, නමුත් ASCII නොවන අකුරු නොවෙනස්ව පවතී.
    ///
    /// ස්ථානයෙහි අගය ඉහළ අගයක් ගැනීමට, [`make_ascii_uppercase()`] භාවිතා කරන්න.
    ///
    /// ASCII නොවන අක්ෂර වලට අමතරව ASCII අක්ෂර විශාල කිරීමට, [`to_uppercase()`] භාවිතා කරන්න.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// එහි ASCII කුඩා අකුරෙහි වටිනාකමේ පිටපතක් සමාන කරයි.
    ///
    /// ASCII අක්ෂර 'A' සිට 'Z' දක්වා 'a' සිට 'z' දක්වා සිතියම් ගත කර ඇත, නමුත් ASCII නොවන අකුරු නොවෙනස්ව පවතී.
    ///
    /// ස්ථානයෙහි අගය අඩු කිරීමට, [`make_ascii_lowercase()`] භාවිතා කරන්න.
    ///
    /// ASCII නොවන අක්ෂර වලට අමතරව ASCII අක්ෂර කුඩා කිරීමට, [`to_lowercase()`] භාවිතා කරන්න.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// අගයන් දෙකක් ASCII සිද්ධි-සංවේදී නොවන ගැලපීමක්දැයි පරීක්ෂා කරයි.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` ට සමාන වේ.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// මෙම වර්ගය එහි ASCII ඉහළ අකුරට සමාන ස්ථානයකට පරිවර්තනය කරයි.
    ///
    /// ASCII අක්ෂර 'a' සිට 'z' දක්වා 'A' සිට 'Z' දක්වා සිතියම් ගත කර ඇත, නමුත් ASCII නොවන අකුරු නොවෙනස්ව පවතී.
    ///
    /// පවතින අගය වෙනස් නොකර නව ඉහළ අගයක් ලබා දීමට, [`to_ascii_uppercase()`] භාවිතා කරන්න.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// මෙම වර්ගය එහි ASCII කුඩා අකුරට සමාන ස්ථානයකට පරිවර්තනය කරයි.
    ///
    /// ASCII අක්ෂර 'A' සිට 'Z' දක්වා 'a' සිට 'z' දක්වා සිතියම් ගත කර ඇත, නමුත් ASCII නොවන අකුරු නොවෙනස්ව පවතී.
    ///
    /// පවතින අගය වෙනස් නොකර නව අඩු අගයක් ලබා දීමට, [`to_ascii_lowercase()`] භාවිතා කරන්න.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// අගය ASCII අකාරාදී අක්‍ෂරයක් දැයි පරීක්ෂා කරයි:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', හෝ
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// අගය ASCII ලොකු අකුරක් දැයි පරීක්ෂා කරයි:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// අගය ASCII සිම්පල් අක්‍ෂරයක් දැයි පරීක්ෂා කරයි:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// අගය ASCII අක්ෂරාංක අක්ෂරයක් දැයි පරීක්ෂා කරයි:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', හෝ
    /// - U + 0061 'a' ..=U + 007A 'z', හෝ
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// අගය ASCII දශම ඉලක්කම් දැයි පරීක්ෂා කරයි:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// අගය ASCII ෂඩාස්රාකාර ඉලක්කම් දැයි පරීක්ෂා කරයි:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', හෝ
    /// - U + 0041 'A' ..=U + 0046 'F', හෝ
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// අගය ASCII විරාම ලකුණු අක්‍ෂරයක් දැයි පරීක්ෂා කරයි:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, හෝ
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, හෝ
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, හෝ
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// අගය ASCII ග්‍රැෆික් චරිතයක් දැයි පරීක්ෂා කරයි:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// අගය ASCII සුදු අවකාශයේ චරිතයක් දැයි පරීක්ෂා කරයි:
    /// U + 0020 SPACE, U + 0009 HORIZONTAL TAB, U + 000A LINE FEED, U + 000C FORM FEED, හෝ U + 000D CARRIAGE Return.
    ///
    /// Rust WhatWG Infra Standard හි [definition of ASCII whitespace][infra-aw] භාවිතා කරයි.පුළුල් භාවිතයේ තවත් අර්ථ දැක්වීම් කිහිපයක් තිබේ.
    /// නිදසුනක් ලෙස, [the POSIX locale][pct] හි U + 000B VERTICAL TAB මෙන්ම ඉහත අක්ෂර සියල්ලම ඇතුළත් වේ, නමුත්-එකම පිරිවිතරයෙන්-[Bourne shell හි "field splitting" සඳහා පෙරනිමි රීතිය][bfs] සලකා බලන්නේ *පමණක්* SPACE, HORIZONTAL TAB සහ සුදු පැහැති අවකාශයක් ලෙස LINE FEED.
    ///
    ///
    /// ඔබ දැනට පවතින ගොනු ආකෘතියක් සැකසෙන වැඩසටහනක් ලියන්නේ නම්, මෙම ශ්‍රිතය භාවිතා කිරීමට පෙර සුදු පැහැති අවකාශය පිළිබඳ එම ආකෘතියේ අර්ථ දැක්වීම කුමක්දැයි පරීක්ෂා කරන්න.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// අගය ASCII පාලන අක්‍ෂරයක් දැයි පරීක්ෂා කරයි:
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR, හෝ U + 007F DELETE.
    /// බොහෝ ASCII සුදු අවකාශයේ අක්ෂර පාලක අක්ෂර බව සලකන්න, නමුත් SPACE එසේ නොවේ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// අමු u32 අගයක් UTF-8 ලෙස සපයා ඇති බයිට් බෆරයට සංකේතවත් කරයි, පසුව කේතනය කළ අක්‍ෂරය අඩංගු බෆරයේ උප කොටස නැවත ලබා දෙයි.
///
///
/// `char::encode_utf8` මෙන් නොව, මෙම ක්‍රමය මඟින් අන්‍යාගමික පරාසය තුළ කේත ලක්ෂ්‍ය ද හසුරුවයි.
/// (අන්‍යාගමික පරාසය තුළ `char` නිර්මාණය කිරීම UB වේ.) ප්‍රති result ලය වලංගු [generalized UTF-8] නමුත් වලංගු UTF-8 නොවේ.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// බෆරය ප්‍රමාණවත් නොවන්නේ නම් Panics.
/// ඕනෑම `char` කේතනය කිරීමට තරම් දිග හතරක බෆරයක් විශාලය.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// අමු u32 අගයක් UTF-16 ලෙස සපයා ඇති `u16` බෆරයට සංකේතවත් කරයි, ඉන්පසු කේතනය කළ අක්‍ෂරය අඩංගු බෆරයේ උප කොටස නැවත ලබා දෙයි.
///
///
/// `char::encode_utf16` මෙන් නොව, මෙම ක්‍රමය මඟින් අන්‍යාගමික පරාසය තුළ කේත ලක්ෂ්‍ය ද හසුරුවයි.
/// (අන්‍යාගමික පරාසය තුළ `char` නිර්මාණය කිරීම යූබී වේ.)
///
/// # Panics
///
/// බෆරය ප්‍රමාණවත් නොවන්නේ නම් Panics.
/// ඕනෑම `char` කේතනය කිරීමට තරම් දිග 2 බෆරයක් විශාලය.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // ආරක්ෂාව: ලිවීමට ප්‍රමාණවත් බිටු තිබේද යන්න සෑම අතකින්ම පරීක්ෂා කරයි
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP හරහා වැටේ
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // අතිරේක ගුවන් යානා අන්වාදේශ වලට කැඩී යයි.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}