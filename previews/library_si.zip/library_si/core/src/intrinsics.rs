//! සම්පාදක අභ්‍යන්තරය.
//!
//! අනුරූප අර්ථ දැක්වීම් `compiler/rustc_codegen_llvm/src/intrinsic.rs` හි ඇත.
//! අනුරූපී නියමය ක්‍රියාත්මක කිරීම `compiler/rustc_mir/src/interpret/intrinsics.rs` හි ඇත
//!
//! # නියත අභ්‍යන්තරය
//!
//! Note: අභ්‍යන්තර විද්‍යාවේ අඛණ්ඩතාවයේ යම් වෙනසක් භාෂා කණ්ඩායම සමඟ සාකච්ඡා කළ යුතුය.
//! ස්ථායිතාවයේ ස්ථායිතාවයේ වෙනස්කම් මෙයට ඇතුළත් වේ.
//!
//! සම්පාදනය කරන වේලාවේදී සහජයෙන්ම භාවිතා කළ හැකි වන පරිදි, යමෙකුට ක්‍රියාත්මක කිරීම <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> සිට `compiler/rustc_mir/src/interpret/intrinsics.rs` දක්වා පිටපත් කර අභ්‍යන්තරයට `#[rustc_const_unstable(feature = "foo", issue = "01234")]` එක් කළ යුතුය.
//!
//!
//! `rustc_const_stable` ගුණාංගයක් සහිත `const fn` වෙතින් අභ්‍යන්තරයක් භාවිතා කිරීමට අවශ්‍ය නම්, අභ්‍යන්තරයේ ගුණාංගය `rustc_const_stable` ද විය යුතුය.
//! එවැනි වෙනසක් ටී-ලැන්ග් උපදේශනයකින් තොරව සිදු නොකළ යුතුය, මන්ද එය සම්පාදක සහාය නොමැතිව පරිශීලක කේතයේ ප්‍රතිවර්තනය කළ නොහැකි භාෂාවට අංගයක් ගෙන යන බැවිනි.
//!
//! # Volatiles
//!
//! වාෂ්පශීලී අභ්‍යන්තර විද්‍යාව I/O මතකය මත ක්‍රියා කිරීමට අදහස් කරන මෙහෙයුම් සපයන අතර ඒවා වෙනත් වාෂ්පශීලී අභ්‍යන්තරයන් හරහා සම්පාදකයා විසින් නැවත සකස් නොකරන බවට සහතික වේ.[[volatile]] හි LLVM ප්‍රලේඛනය බලන්න.
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! පරමාණුක අභ්‍යන්තරය මඟින් යන්ත වචන මත පොදු පරමාණුක මෙහෙයුම් සපයන අතර මතක මතක අනුපිළිවෙලවල් කිහිපයක් ඇත.ඔවුන් C++ 11 හා සමාන අර්ථකථන වලට කීකරු වේ.[[atomics]] හි LLVM ප්‍රලේඛනය බලන්න.
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! මතක ඇණවුම පිළිබඳ ඉක්මන් නැවුම්බවක්:
//!
//! * අත්පත් කර ගැනීම, අගුලක් ලබා ගැනීම සඳහා බාධකයක්.පසුකාලීන කියවීම් හා ලිවීම් බාධකයෙන් පසුව සිදු වේ.
//! * මුදා හැරීම, අගුලක් මුදා හැරීමට බාධකයක්.පූර්ව කියවීම් හා ලිවීම් බාධකයට පෙර සිදු වේ.
//! * අනුක්‍රමිකව, අනුක්‍රමිකව ස්ථාවර මෙහෙයුම් පිළිවෙලින් සිදුවන බවට සහතික වේ.මෙය පරමාණුක වර්ග සමඟ වැඩ කිරීම සඳහා වන සම්මත ප්‍රකාරය වන අතර එය Java හි `volatile` ට සමාන වේ.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// මෙම ආනයන අන්තර්-ලේඛ සම්බන්ධතා සරල කිරීම සඳහා යොදා ගනී
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // ආරක්ෂාව: `ptr::drop_in_place` බලන්න
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // සැ.යු, මෙම අභ්‍යන්තරිකයන් අමු දර්ශක ගන්නේ අන්වර්ථ මතකය විකෘති කරන නිසා වන අතර එය `&` හෝ `&mut` සඳහා වලංගු නොවේ.
    //

    /// වත්මන් අගය `old` අගයට සමාන නම් අගයක් ගබඩා කරයි.
    ///
    /// [`Ordering::SeqCst`] සහ `failure` පරාමිතීන් ලෙස [`Ordering::SeqCst`] පසුකරමින් මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග මත `compare_exchange` ක්‍රමය හරහා ලබා ගත හැකිය.
    ///
    /// උදාහරණ වශයෙන්, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// වත්මන් අගය `old` අගයට සමාන නම් අගයක් ගබඩා කරයි.
    ///
    /// [`Ordering::Acquire`] සහ `failure` පරාමිතීන් ලෙස [`Ordering::Acquire`] පසුකරමින් මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග මත `compare_exchange` ක්‍රමය හරහා ලබා ගත හැකිය.
    ///
    /// උදාහරණ වශයෙන්, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// වත්මන් අගය `old` අගයට සමාන නම් අගයක් ගබඩා කරයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `compare_exchange` ක්‍රමය හරහා [`Ordering::Release`] `success` ලෙසත් [`Ordering::Relaxed`] `failure` පරාමිතීන් ලෙසත් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// වත්මන් අගය `old` අගයට සමාන නම් අගයක් ගබඩා කරයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `compare_exchange` ක්‍රමය හරහා [`Ordering::AcqRel`] `success` ලෙසත් [`Ordering::Acquire`] `failure` පරාමිතීන් ලෙසත් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// වත්මන් අගය `old` අගයට සමාන නම් අගයක් ගබඩා කරයි.
    ///
    /// [`Ordering::Relaxed`] සහ `failure` පරාමිතීන් ලෙස [`Ordering::Relaxed`] පසුකරමින් මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග මත `compare_exchange` ක්‍රමය හරහා ලබා ගත හැකිය.
    ///
    /// උදාහරණ වශයෙන්, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// වත්මන් අගය `old` අගයට සමාන නම් අගයක් ගබඩා කරයි.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය `compare_exchange` ක්‍රමය හරහා [`atomic`] වර්ග වලින් [`Ordering::SeqCst`] `success` ලෙසත් [`Ordering::Relaxed`] `failure` පරාමිතීන් ලෙසත් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// වත්මන් අගය `old` අගයට සමාන නම් අගයක් ගබඩා කරයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `compare_exchange` ක්‍රමය හරහා [`Ordering::SeqCst`] `success` ලෙසත් [`Ordering::Acquire`] `failure` පරාමිතීන් ලෙසත් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// වත්මන් අගය `old` අගයට සමාන නම් අගයක් ගබඩා කරයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `compare_exchange` ක්‍රමය හරහා [`Ordering::Acquire`] `success` ලෙසත් [`Ordering::Relaxed`] `failure` පරාමිතීන් ලෙසත් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// වත්මන් අගය `old` අගයට සමාන නම් අගයක් ගබඩා කරයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `compare_exchange` ක්‍රමය හරහා [`Ordering::AcqRel`] `success` ලෙසත් [`Ordering::Relaxed`] `failure` පරාමිතීන් ලෙසත් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// වත්මන් අගය `old` අගයට සමාන නම් අගයක් ගබඩා කරයි.
    ///
    /// [`Ordering::SeqCst`] සහ `failure` පරාමිතීන් ලෙස [`Ordering::SeqCst`] පසුකරමින් මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග මත `compare_exchange_weak` ක්‍රමය හරහා ලබා ගත හැකිය.
    ///
    /// උදාහරණ වශයෙන්, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// වත්මන් අගය `old` අගයට සමාන නම් අගයක් ගබඩා කරයි.
    ///
    /// [`Ordering::Acquire`] සහ `failure` පරාමිතීන් ලෙස [`Ordering::Acquire`] පසුකරමින් මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග මත `compare_exchange_weak` ක්‍රමය හරහා ලබා ගත හැකිය.
    ///
    /// උදාහරණ වශයෙන්, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// වත්මන් අගය `old` අගයට සමාන නම් අගයක් ගබඩා කරයි.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `compare_exchange_weak` ක්‍රමය හරහා [`Ordering::Release`] `success` ලෙසත් [`Ordering::Relaxed`] `failure` පරාමිතීන් ලෙසත් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// වත්මන් අගය `old` අගයට සමාන නම් අගයක් ගබඩා කරයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `compare_exchange_weak` ක්‍රමය හරහා [`Ordering::AcqRel`] `success` ලෙසත් [`Ordering::Acquire`] `failure` පරාමිතීන් ලෙසත් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// වත්මන් අගය `old` අගයට සමාන නම් අගයක් ගබඩා කරයි.
    ///
    /// [`Ordering::Relaxed`] සහ `failure` පරාමිතීන් ලෙස [`Ordering::Relaxed`] පසුකරමින් මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග මත `compare_exchange_weak` ක්‍රමය හරහා ලබා ගත හැකිය.
    ///
    /// උදාහරණ වශයෙන්, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// වත්මන් අගය `old` අගයට සමාන නම් අගයක් ගබඩා කරයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `compare_exchange_weak` ක්‍රමය හරහා [`Ordering::SeqCst`] `success` ලෙසත් [`Ordering::Relaxed`] `failure` පරාමිතීන් ලෙසත් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// වත්මන් අගය `old` අගයට සමාන නම් අගයක් ගබඩා කරයි.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය `compare_exchange_weak` ක්‍රමය හරහා [`atomic`] වර්ග වලින් [`Ordering::SeqCst`] `success` ලෙසත් [`Ordering::Acquire`] `failure` පරාමිතීන් ලෙසත් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// වත්මන් අගය `old` අගයට සමාන නම් අගයක් ගබඩා කරයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `compare_exchange_weak` ක්‍රමය හරහා [`Ordering::Acquire`] `success` ලෙසත් [`Ordering::Relaxed`] `failure` පරාමිතීන් ලෙසත් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// වත්මන් අගය `old` අගයට සමාන නම් අගයක් ගබඩා කරයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `compare_exchange_weak` ක්‍රමය හරහා [`Ordering::AcqRel`] `success` ලෙසත් [`Ordering::Relaxed`] `failure` පරාමිතීන් ලෙසත් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// දර්ශකයේ වත්මන් අගය පූරණය කරයි.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `load` ක්‍රමය හරහා [`Ordering::SeqCst`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// දර්ශකයේ වත්මන් අගය පූරණය කරයි.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `load` ක්‍රමය හරහා [`Ordering::Acquire`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// දර්ශකයේ වත්මන් අගය පූරණය කරයි.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `load` ක්‍රමය හරහා [`Ordering::Relaxed`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// නිශ්චිත මතක ස්ථානයේ අගය ගබඩා කරයි.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `store` ක්‍රමය හරහා [`Ordering::SeqCst`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// නිශ්චිත මතක ස්ථානයේ අගය ගබඩා කරයි.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `store` ක්‍රමය හරහා [`Ordering::Release`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// නිශ්චිත මතක ස්ථානයේ අගය ගබඩා කරයි.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `store` ක්‍රමය හරහා [`Ordering::Relaxed`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// පැරණි අගය ලබා දෙමින් නිශ්චිත මතක ස්ථානයේ අගය ගබඩා කරයි.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `swap` ක්‍රමය හරහා [`Ordering::SeqCst`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// පැරණි අගය ලබා දෙමින් නිශ්චිත මතක ස්ථානයේ අගය ගබඩා කරයි.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `swap` ක්‍රමය හරහා [`Ordering::Acquire`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// පැරණි අගය ලබා දෙමින් නිශ්චිත මතක ස්ථානයේ අගය ගබඩා කරයි.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `swap` ක්‍රමය හරහා [`Ordering::Release`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// පැරණි අගය ලබා දෙමින් නිශ්චිත මතක ස්ථානයේ අගය ගබඩා කරයි.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `swap` ක්‍රමය හරහා [`Ordering::AcqRel`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// පැරණි අගය ලබා දෙමින් නිශ්චිත මතක ස්ථානයේ අගය ගබඩා කරයි.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `swap` ක්‍රමය හරහා [`Ordering::Relaxed`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// වත්මන් අගයට එකතු කරයි, පෙර අගය නැවත ලබා දෙයි.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `fetch_add` ක්‍රමය හරහා [`Ordering::SeqCst`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// වත්මන් අගයට එකතු කරයි, පෙර අගය නැවත ලබා දෙයි.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `fetch_add` ක්‍රමය හරහා [`Ordering::Acquire`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// වත්මන් අගයට එකතු කරයි, පෙර අගය නැවත ලබා දෙයි.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `fetch_add` ක්‍රමය හරහා [`Ordering::Release`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// වත්මන් අගයට එකතු කරයි, පෙර අගය නැවත ලබා දෙයි.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `fetch_add` ක්‍රමය හරහා [`Ordering::AcqRel`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// වත්මන් අගයට එකතු කරයි, පෙර අගය නැවත ලබා දෙයි.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `fetch_add` ක්‍රමය හරහා [`Ordering::Relaxed`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// වත්මන් අගයෙන් අඩු කරන්න, පෙර අගය ආපසු ලබා දෙන්න.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `fetch_sub` ක්‍රමය හරහා [`Ordering::SeqCst`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// වත්මන් අගයෙන් අඩු කරන්න, පෙර අගය ආපසු ලබා දෙන්න.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `fetch_sub` ක්‍රමය හරහා [`Ordering::Acquire`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// වත්මන් අගයෙන් අඩු කරන්න, පෙර අගය ආපසු ලබා දෙන්න.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `fetch_sub` ක්‍රමය හරහා [`Ordering::Release`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// වත්මන් අගයෙන් අඩු කරන්න, පෙර අගය ආපසු ලබා දෙන්න.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `fetch_sub` ක්‍රමය හරහා [`Ordering::AcqRel`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// වත්මන් අගයෙන් අඩු කරන්න, පෙර අගය ආපසු ලබා දෙන්න.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `fetch_sub` ක්‍රමය හරහා [`Ordering::Relaxed`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise සහ වත්මන් අගය සමඟ, පෙර අගය ආපසු ලබා දේ.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `fetch_and` ක්‍රමය හරහා [`Ordering::SeqCst`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise සහ වත්මන් අගය සමඟ, පෙර අගය ආපසු ලබා දේ.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `fetch_and` ක්‍රමය හරහා [`Ordering::Acquire`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise සහ වත්මන් අගය සමඟ, පෙර අගය ආපසු ලබා දේ.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `fetch_and` ක්‍රමය හරහා [`Ordering::Release`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise සහ වත්මන් අගය සමඟ, පෙර අගය ආපසු ලබා දේ.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `fetch_and` ක්‍රමය හරහා [`Ordering::AcqRel`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise සහ වත්මන් අගය සමඟ, පෙර අගය ආපසු ලබා දේ.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `fetch_and` ක්‍රමය හරහා [`Ordering::Relaxed`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// වත්මන් අගය සමඟ බිට්වේස් නන්ඩ්, පෙර අගය ආපසු ලබා දීම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`AtomicBool`] වර්ගය මත `fetch_nand` ක්‍රමය හරහා [`Ordering::SeqCst`] `order` ලෙස සම්මත කර ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// වත්මන් අගය සමඟ බිට්වේස් නන්ඩ්, පෙර අගය ආපසු ලබා දීම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`AtomicBool`] වර්ගය මත `fetch_nand` ක්‍රමය හරහා [`Ordering::Acquire`] `order` ලෙස සම්මත කර ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// වත්මන් අගය සමඟ බිට්වේස් නන්ඩ්, පෙර අගය ආපසු ලබා දීම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`AtomicBool`] වර්ගය මත `fetch_nand` ක්‍රමය හරහා [`Ordering::Release`] `order` ලෙස සම්මත කර ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// වත්මන් අගය සමඟ බිට්වේස් නන්ඩ්, පෙර අගය ආපසු ලබා දීම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`AtomicBool`] වර්ගය මත `fetch_nand` ක්‍රමය හරහා [`Ordering::AcqRel`] `order` ලෙස සම්මත කර ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// වත්මන් අගය සමඟ බිට්වේස් නන්ඩ්, පෙර අගය ආපසු ලබා දීම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`AtomicBool`] වර්ගය මත `fetch_nand` ක්‍රමය හරහා [`Ordering::Relaxed`] `order` ලෙස සම්මත කර ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// බිට්වේස් හෝ වත්මන් අගය සමඟ, පෙර අගය ආපසු ලබා දීම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `fetch_or` ක්‍රමය හරහා [`Ordering::SeqCst`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// බිට්වේස් හෝ වත්මන් අගය සමඟ, පෙර අගය ආපසු ලබා දීම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `fetch_or` ක්‍රමය හරහා [`Ordering::Acquire`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// බිට්වේස් හෝ වත්මන් අගය සමඟ, පෙර අගය ආපසු ලබා දීම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `fetch_or` ක්‍රමය හරහා [`Ordering::Release`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// බිට්වේස් හෝ වත්මන් අගය සමඟ, පෙර අගය ආපසු ලබා දීම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `fetch_or` ක්‍රමය හරහා [`Ordering::AcqRel`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// බිට්වේස් හෝ වත්මන් අගය සමඟ, පෙර අගය ආපසු ලබා දීම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `fetch_or` ක්‍රමය හරහා [`Ordering::Relaxed`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// වත්මන් අගය සමඟ බිට්වයිස් xor, පෙර අගය ලබා දෙයි.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `fetch_xor` ක්‍රමය හරහා [`Ordering::SeqCst`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// වත්මන් අගය සමඟ බිට්වයිස් xor, පෙර අගය ලබා දෙයි.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `fetch_xor` ක්‍රමය හරහා [`Ordering::Acquire`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// වත්මන් අගය සමඟ බිට්වයිස් xor, පෙර අගය ලබා දෙයි.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `fetch_xor` ක්‍රමය හරහා [`Ordering::Release`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// වත්මන් අගය සමඟ බිට්වයිස් xor, පෙර අගය ලබා දෙයි.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `fetch_xor` ක්‍රමය හරහා [`Ordering::AcqRel`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// වත්මන් අගය සමඟ බිට්වයිස් xor, පෙර අගය ලබා දෙයි.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] වර්ග වලින් `fetch_xor` ක්‍රමය හරහා [`Ordering::Relaxed`] `order` ලෙස ලබා ගැනීමෙන් ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// අත්සන් කළ සංසන්දනයක් භාවිතා කරමින් වත්මන් අගය සමඟ උපරිම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] අත්සන් කළ පූර්ණ සංඛ්‍යා වර්ග වලින් `fetch_max` ක්‍රමය හරහා [`Ordering::SeqCst`] `order` ලෙස සම්මත කර ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// අත්සන් කළ සංසන්දනයක් භාවිතා කරමින් වත්මන් අගය සමඟ උපරිම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] අත්සන් කළ පූර්ණ සංඛ්‍යා වර්ග වලින් `fetch_max` ක්‍රමය හරහා [`Ordering::Acquire`] `order` ලෙස සම්මත කර ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// අත්සන් කළ සංසන්දනයක් භාවිතා කරමින් වත්මන් අගය සමඟ උපරිම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] අත්සන් කළ පූර්ණ සංඛ්‍යා වර්ග වලින් `fetch_max` ක්‍රමය හරහා [`Ordering::Release`] `order` ලෙස සම්මත කර ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// අත්සන් කළ සංසන්දනයක් භාවිතා කරමින් වත්මන් අගය සමඟ උපරිම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] අත්සන් කළ පූර්ණ සංඛ්‍යා වර්ග වලින් `fetch_max` ක්‍රමය හරහා [`Ordering::AcqRel`] `order` ලෙස සම්මත කර ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// වත්මන් අගය සමඟ උපරිම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] අත්සන් කළ පූර්ණ සංඛ්‍යා වර්ග වලින් `fetch_max` ක්‍රමය හරහා [`Ordering::Relaxed`] `order` ලෙස සම්මත කර ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// අත්සන් කළ සංසන්දනයක් භාවිතා කරමින් වත්මන් අගය සමඟ අවම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] අත්සන් කළ පූර්ණ සංඛ්‍යා වර්ග වලින් `fetch_min` ක්‍රමය හරහා [`Ordering::SeqCst`] `order` ලෙස සම්මත කර ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// අත්සන් කළ සංසන්දනයක් භාවිතා කරමින් වත්මන් අගය සමඟ අවම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] අත්සන් කළ පූර්ණ සංඛ්‍යා වර්ග වලින් `fetch_min` ක්‍රමය හරහා [`Ordering::Acquire`] `order` ලෙස සම්මත කර ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// අත්සන් කළ සංසන්දනයක් භාවිතා කරමින් වත්මන් අගය සමඟ අවම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] අත්සන් කළ පූර්ණ සංඛ්‍යා වර්ග වලින් `fetch_min` ක්‍රමය හරහා [`Ordering::Release`] `order` ලෙස සම්මත කර ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// අත්සන් කළ සංසන්දනයක් භාවිතා කරමින් වත්මන් අගය සමඟ අවම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] අත්සන් කළ පූර්ණ සංඛ්‍යා වර්ග වලින් `fetch_min` ක්‍රමය හරහා [`Ordering::AcqRel`] `order` ලෙස සම්මත කර ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// අත්සන් කළ සංසන්දනයක් භාවිතා කරමින් වත්මන් අගය සමඟ අවම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] අත්සන් කළ පූර්ණ සංඛ්‍යා වර්ග වලින් `fetch_min` ක්‍රමය හරහා [`Ordering::Relaxed`] `order` ලෙස සම්මත කර ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// අත්සන් නොකළ සංසන්දනයක් භාවිතා කරමින් වත්මන් අගය සමඟ අවම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] අත්සන් නොකළ පූර්ණ සංඛ්‍යා වලින් `fetch_min` ක්‍රමය හරහා [`Ordering::SeqCst`] `order` ලෙස ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// අත්සන් නොකළ සංසන්දනයක් භාවිතා කරමින් වත්මන් අගය සමඟ අවම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] අත්සන් නොකළ පූර්ණ සංඛ්‍යා වලින් `fetch_min` ක්‍රමය හරහා [`Ordering::Acquire`] `order` ලෙස ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// අත්සන් නොකළ සංසන්දනයක් භාවිතා කරමින් වත්මන් අගය සමඟ අවම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] අත්සන් නොකළ පූර්ණ සංඛ්‍යා වලින් `fetch_min` ක්‍රමය හරහා [`Ordering::Release`] `order` ලෙස ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// අත්සන් නොකළ සංසන්දනයක් භාවිතා කරමින් වත්මන් අගය සමඟ අවම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] අත්සන් නොකළ පූර්ණ සංඛ්‍යා වලින් `fetch_min` ක්‍රමය හරහා [`Ordering::AcqRel`] `order` ලෙස ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// අත්සන් නොකළ සංසන්දනයක් භාවිතා කරමින් වත්මන් අගය සමඟ අවම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] අත්සන් නොකළ පූර්ණ සංඛ්‍යා වලින් `fetch_min` ක්‍රමය හරහා [`Ordering::Relaxed`] `order` ලෙස ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// අත්සන් නොකළ සංසන්දනයක් භාවිතා කරමින් වත්මන් අගය සමඟ උපරිම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] අත්සන් නොකළ පූර්ණ සංඛ්‍යා වලින් `fetch_max` ක්‍රමය හරහා [`Ordering::SeqCst`] `order` ලෙස ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// අත්සන් නොකළ සංසන්දනයක් භාවිතා කරමින් වත්මන් අගය සමඟ උපරිම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] අත්සන් නොකළ පූර්ණ සංඛ්‍යා වලින් `fetch_max` ක්‍රමය හරහා [`Ordering::Acquire`] `order` ලෙස ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// අත්සන් නොකළ සංසන්දනයක් භාවිතා කරමින් වත්මන් අගය සමඟ උපරිම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] අත්සන් නොකළ පූර්ණ සංඛ්‍යා වලින් `fetch_max` ක්‍රමය හරහා [`Ordering::Release`] `order` ලෙස ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// අත්සන් නොකළ සංසන්දනයක් භාවිතා කරමින් වත්මන් අගය සමඟ උපරිම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] අත්සන් නොකළ පූර්ණ සංඛ්‍යා වලින් `fetch_max` ක්‍රමය හරහා [`Ordering::AcqRel`] `order` ලෙස ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// අත්සන් නොකළ සංසන්දනයක් භාවිතා කරමින් වත්මන් අගය සමඟ උපරිම.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic`] අත්සන් නොකළ පූර්ණ සංඛ්‍යා වලින් `fetch_max` ක්‍රමය හරහා [`Ordering::Relaxed`] `order` ලෙස ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// `prefetch` අභ්‍යන්තරය යනු කේත උත්පාදක යන්ත්‍රයට ඉඟියක් වන අතර එය සහාය දක්වන්නේ නම් පූර්ව උපසර්ග උපදෙස් ඇතුළත් කළ හැකිය;එසේ නොමැති නම්, එය කිසිසේත් කළ නොහැකි දෙයකි.
    /// උපසර්ගයන් වැඩසටහනේ හැසිරීමට කිසිදු බලපෑමක් නොකරන නමුත් එහි ක්‍රියාකාරීත්ව ලක්ෂණ වෙනස් කළ හැකිය.
    ///
    /// `locality` තර්කය නියත නිඛිලයක් විය යුතු අතර එය තාවකාලික ස්ථානීය පිරිවිතරයක් වන අතර එය (0) සිට කිසිදු ප්‍රදේශයක් නොමැත, (3) දක්වා වන අතර අතිශයින්ම දේශීය හැඹිලියේ තබා ගනී.
    ///
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// `prefetch` අභ්‍යන්තරය යනු කේත උත්පාදක යන්ත්‍රයට ඉඟියක් වන අතර එය සහාය දක්වන්නේ නම් පූර්ව උපසර්ග උපදෙස් ඇතුළත් කළ හැකිය;එසේ නොමැති නම්, එය කිසිසේත් කළ නොහැකි දෙයකි.
    /// උපසර්ගයන් වැඩසටහනේ හැසිරීමට කිසිදු බලපෑමක් නොකරන නමුත් එහි ක්‍රියාකාරීත්ව ලක්ෂණ වෙනස් කළ හැකිය.
    ///
    /// `locality` තර්කය නියත නිඛිලයක් විය යුතු අතර එය තාවකාලික ස්ථානීය පිරිවිතරයක් වන අතර එය (0) සිට කිසිදු ප්‍රදේශයක් නොමැත, (3) දක්වා වන අතර අතිශයින්ම දේශීය හැඹිලියේ තබා ගනී.
    ///
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// `prefetch` අභ්‍යන්තරය යනු කේත උත්පාදක යන්ත්‍රයට ඉඟියක් වන අතර එය සහාය දක්වන්නේ නම් පූර්ව උපසර්ග උපදෙස් ඇතුළත් කළ හැකිය;එසේ නොමැති නම්, එය කිසිසේත් කළ නොහැකි දෙයකි.
    /// උපසර්ගයන් වැඩසටහනේ හැසිරීමට කිසිදු බලපෑමක් නොකරන නමුත් එහි ක්‍රියාකාරීත්ව ලක්ෂණ වෙනස් කළ හැකිය.
    ///
    /// `locality` තර්කය නියත නිඛිලයක් විය යුතු අතර එය තාවකාලික ස්ථානීය පිරිවිතරයක් වන අතර එය (0) සිට කිසිදු ප්‍රදේශයක් නොමැත, (3) දක්වා වන අතර අතිශයින්ම දේශීය හැඹිලියේ තබා ගනී.
    ///
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// `prefetch` අභ්‍යන්තරය යනු කේත උත්පාදක යන්ත්‍රයට ඉඟියක් වන අතර එය සහාය දක්වන්නේ නම් පූර්ව උපසර්ග උපදෙස් ඇතුළත් කළ හැකිය;එසේ නොමැති නම්, එය කිසිසේත් කළ නොහැකි දෙයකි.
    /// උපසර්ගයන් වැඩසටහනේ හැසිරීමට කිසිදු බලපෑමක් නොකරන නමුත් එහි ක්‍රියාකාරීත්ව ලක්ෂණ වෙනස් කළ හැකිය.
    ///
    /// `locality` තර්කය නියත නිඛිලයක් විය යුතු අතර එය තාවකාලික ස්ථානීය පිරිවිතරයක් වන අතර එය (0) සිට කිසිදු ප්‍රදේශයක් නොමැත, (3) දක්වා වන අතර අතිශයින්ම දේශීය හැඹිලියේ තබා ගනී.
    ///
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// පරමාණුක වැටක්.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic::fence`] හි [`Ordering::SeqCst`] `order` ලෙස සම්මත කිරීමෙන් ලබා ගත හැකිය.
    ///
    ///
    pub fn atomic_fence();
    /// පරමාණුක වැටක්.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic::fence`] හි [`Ordering::Acquire`] `order` ලෙස සම්මත කිරීමෙන් ලබා ගත හැකිය.
    ///
    ///
    pub fn atomic_fence_acq();
    /// පරමාණුක වැටක්.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic::fence`] හි [`Ordering::Release`] `order` ලෙස සම්මත කිරීමෙන් ලබා ගත හැකිය.
    ///
    ///
    pub fn atomic_fence_rel();
    /// පරමාණුක වැටක්.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic::fence`] හි [`Ordering::AcqRel`] `order` ලෙස සම්මත කිරීමෙන් ලබා ගත හැකිය.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// සම්පාදක-පමණක් මතක බාධකයක්.
    ///
    /// සම්පාදකයා විසින් මෙම බාධකය හරහා මතක ප්‍රවේශයන් කිසි විටෙකත් නැවත සකසනු නොලැබේ, නමුත් ඒ සඳහා උපදෙස් නිකුත් නොකෙරේ.
    /// සං signal ා හසුරුවන්නන් සමඟ අන්තර්ක්‍රියා කරන විට වැනි පූර්ව නිගමනයකට එළඹිය හැකි එකම ත්‍රෙඩ් එකක මෙහෙයුම් සඳහා මෙය සුදුසු වේ.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic::compiler_fence`] හි [`Ordering::SeqCst`] `order` ලෙස සම්මත කිරීමෙන් ලබා ගත හැකිය.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// සම්පාදක-පමණක් මතක බාධකයක්.
    ///
    /// සම්පාදකයා විසින් මෙම බාධකය හරහා මතක ප්‍රවේශයන් කිසි විටෙකත් නැවත සකසනු නොලැබේ, නමුත් ඒ සඳහා උපදෙස් නිකුත් නොකෙරේ.
    /// සං signal ා හසුරුවන්නන් සමඟ අන්තර්ක්‍රියා කරන විට වැනි පූර්ව නිගමනයකට එළඹිය හැකි එකම ත්‍රෙඩ් එකක මෙහෙයුම් සඳහා මෙය සුදුසු වේ.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic::compiler_fence`] හි [`Ordering::Acquire`] `order` ලෙස සම්මත කිරීමෙන් ලබා ගත හැකිය.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// සම්පාදක-පමණක් මතක බාධකයක්.
    ///
    /// සම්පාදකයා විසින් මෙම බාධකය හරහා මතක ප්‍රවේශයන් කිසි විටෙකත් නැවත සකසනු නොලැබේ, නමුත් ඒ සඳහා උපදෙස් නිකුත් නොකෙරේ.
    /// සං signal ා හසුරුවන්නන් සමඟ අන්තර්ක්‍රියා කරන විට වැනි පූර්ව නිගමනයකට එළඹිය හැකි එකම ත්‍රෙඩ් එකක මෙහෙයුම් සඳහා මෙය සුදුසු වේ.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic::compiler_fence`] හි [`Ordering::Release`] `order` ලෙස සම්මත කිරීමෙන් ලබා ගත හැකිය.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// සම්පාදක-පමණක් මතක බාධකයක්.
    ///
    /// සම්පාදකයා විසින් මෙම බාධකය හරහා මතක ප්‍රවේශයන් කිසි විටෙකත් නැවත සකසනු නොලැබේ, නමුත් ඒ සඳහා උපදෙස් නිකුත් නොකෙරේ.
    /// සං signal ා හසුරුවන්නන් සමඟ අන්තර්ක්‍රියා කරන විට වැනි පූර්ව නිගමනයකට එළඹිය හැකි එකම ත්‍රෙඩ් එකක මෙහෙයුම් සඳහා මෙය සුදුසු වේ.
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදය [`atomic::compiler_fence`] හි [`Ordering::AcqRel`] `order` ලෙස සම්මත කිරීමෙන් ලබා ගත හැකිය.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// ශ්‍රිතයට අනුයුක්ත කර ඇති ගුණාංග වලින් එහි අර්ථය ලබා ගන්නා මැජික් සහජයෙන්ම.
    ///
    /// නිදසුනක් ලෙස, දත්ත ප්‍රවාහය ස්ථිතික ප්‍රකාශ එන්නත් කිරීම සඳහා මෙය භාවිතා කරයි, එවිට `rustc_peek(potentially_uninitialized)` ඇත්ත වශයෙන්ම දත්ත ප්‍රවාහය ගණනය කරනු ලැබුවේ පාලක ප්‍රවාහයේ එම අවස්ථාවේ දී එය ආරම්භ කර නොමැති බව ගණනය කරමිනි.
    ///
    ///
    /// මෙම අභ්‍යන්තරය සම්පාදකයාට පිටතින් භාවිතා නොකළ යුතුය.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// ක්‍රියාවලිය ක්‍රියාත්මක කිරීම නවතා දමයි.
    ///
    /// මෙම මෙහෙයුමේ වඩාත් පරිශීලක-හිතකාමී සහ ස්ථාවර අනුවාදයක් වන්නේ [`std::process::abort`](../../std/process/fn.abort.html) ය.
    ///
    pub fn abort() -> !;

    /// කේතයේ මෙම ලක්ෂ්‍යය ළඟා විය නොහැකි බව ප්‍රශස්තකරණයට දන්වන අතර තවදුරටත් ප්‍රශස්තිකරණය සක්‍රීය කරයි.
    ///
    /// සැ.යු, මෙය `unreachable!()` සාර්වයට වඩා බෙහෙවින් වෙනස් ය: panics ක්‍රියාත්මක වන විට සාර්ව මෙන් නොව, මෙම ශ්‍රිතය සමඟ සලකුණු කළ කේතයට ලඟා වීම * නිර්වචනය නොකළ හැසිරීමකි.
    ///
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked) වේ.
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// කොන්දේසියක් සැමවිටම සත්‍ය බව ප්‍රශස්තකරණයට දන්වයි.
    /// කොන්දේසිය සාවද්‍ය නම්, හැසිරීම නිර්වචනය කර නැත.
    ///
    /// මෙම අභ්‍යන්තරය සඳහා කිසිදු කේතයක් ජනනය නොකෙරේ, නමුත් ප්‍රශස්තිකරුවා එය (සහ එහි තත්වය) මුරපද අතර ආරක්ෂා කිරීමට උත්සාහ කරයි, එමඟින් අවට කේත ප්‍රශස්තිකරණයට බාධා ඇති විය හැකි අතර ක්‍රියාකාරීත්වය අඩු වේ.
    /// ආක්‍රමණිකය ප්‍රශස්තකරණයට තනිවම සොයාගත හැකි නම් හෝ සැලකිය යුතු ප්‍රශස්තිකරණයන් සක්‍රීය නොකරන්නේ නම් එය භාවිතා නොකළ යුතුය.
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// branch තත්ත්වය සත්‍ය විය හැකි බවට සම්පාදකයාට ඉඟි.
    /// එය වෙත ලබා දුන් අගය ලබා දෙයි.
    ///
    /// `if` ප්‍රකාශ හැර වෙනත් ඕනෑම භාවිතයක් බලපෑමක් ඇති නොකරනු ඇත.
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// branch තත්වය අසත්‍ය විය හැකි බවට සම්පාදකයාට ඉඟි.
    /// එය වෙත ලබා දුන් අගය ලබා දෙයි.
    ///
    /// `if` ප්‍රකාශ හැර වෙනත් ඕනෑම භාවිතයක් බලපෑමක් ඇති නොකරනු ඇත.
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// නිදොස් කරන්නෙකු විසින් පරීක්ෂා කිරීම සඳහා බ්‍රේක්පොයින්ට් උගුලක් ක්‍රියාත්මක කරයි.
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    pub fn breakpoint();

    /// බයිට් වර්ගයක ප්‍රමාණය.
    ///
    /// වඩාත් නිශ්චිතවම, පෙළගැස්වීමේ පෑඩින් ඇතුළුව එකම වර්ගයේ අනුක්‍රමික අයිතම අතර බයිට් වල ඕෆ්සෙට් මෙයයි.
    ///
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය [`core::mem::size_of`](crate::mem::size_of) වේ.
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// වර්ගයක අවම පෙළගැස්ම.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය [`core::mem::align_of`](crate::mem::align_of) වේ.
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// වර්ගයක වඩාත් කැමති පෙළගැස්ම.
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// යොමු කරන ලද අගය බයිට් වල ප්‍රමාණය.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය [`mem::size_of_val`] වේ.
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// යොමු අගයෙහි අවශ්‍ය පෙළගැස්ම.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය [`core::mem::align_of_val`](crate::mem::align_of_val) වේ.
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// වර්ගයක නම අඩංගු ස්ථිතික නූල් පෙත්තක් ලබා ගනී.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය [`core::any::type_name`](crate::any::type_name) වේ.
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// නිශ්චිත වර්ගයට ගෝලීයව අනන්‍ය වූ හඳුනාගැනීමක් ලබා ගනී.
    /// මෙම ශ්‍රිතය කුමන ආකාරයේ crate භාවිතා කළත් එය සඳහා එකම අගය ලබා දෙනු ඇත.
    ///
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය [`core::any::TypeId::of`](crate::any::TypeId::of) වේ.
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// `T` ජනාවාස නොවන්නේ නම් කිසි විටෙකත් ක්‍රියාත්මක කළ නොහැකි අනාරක්ෂිත කාර්යයන් සඳහා ආරක්ෂකයින්:
    /// මෙය ස්ථිතිකව එක්කෝ panic හෝ කිසිවක් නොකරනු ඇත.
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// `T` ශුන්‍ය ආරම්භයට ඉඩ නොදෙන්නේ නම් කිසි විටෙකත් ක්‍රියාත්මක කළ නොහැකි අනාරක්ෂිත කාර්යයන් සඳහා ආරක්ෂකයින්: මෙය ස්ථිතිකව panic හෝ කිසිවක් නොකරනු ඇත.
    ///
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    pub fn assert_zero_valid<T>();

    /// `T` වල වලංගු නොවන බිට් රටා තිබේ නම් කිසි විටෙකත් ක්‍රියාත්මක කළ නොහැකි අනාරක්ෂිත කාර්යයන් සඳහා ආරක්ෂකයින්: මෙය ස්ථිතිකව panic හෝ කිසිවක් නොකරනු ඇත.
    ///
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    pub fn assert_uninit_valid<T>();

    /// ස්ථිතික `Location` වෙත එය යොමු වූයේ කොතැනටද යන්න සඳහන් කරයි.
    ///
    /// ඒ වෙනුවට [`core::panic::Location::caller`](crate::panic::Location::caller) භාවිතා කිරීම සලකා බලන්න.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// බිංදු මැලියම් ධාවනය නොකර වටිනාකමක් විෂය පථයෙන් පිටතට ගෙන යයි.
    ///
    /// මෙය පවතින්නේ [`mem::forget_unsized`] සඳහා පමණි;සාමාන්‍ය `forget` ඒ වෙනුවට `ManuallyDrop` භාවිතා කරයි.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// එක් වර්ගයක වටිනාකමක බිටු තවත් වර්ගයක් ලෙස නැවත අර්ථකථනය කරයි.
    ///
    /// වර්ග දෙකම එකම ප්‍රමාණයක් තිබිය යුතුය.
    /// මුල් පිටපත හෝ ප්‍රති result ලය [invalid value](../../nomicon/what-unsafe-does.html) විය නොහැක.
    ///
    /// `transmute` යනු එක් වර්ගයක සිට තවත් වර්ගයකට මාරුවීමට අර්ථ නිරූපණයකි.එය ප්‍රභව අගයෙන් බිටු ගමනාන්ත අගයට පිටපත් කරයි, පසුව මුල් පිටපත අමතක කරයි.
    /// එය `transmute_copy` මෙන්, හුඩ් යටතේ C හි `memcpy` ට සමාන වේ.
    ///
    /// `transmute` යනු වටිනාකම් සහිත මෙහෙයුමක් වන නිසා,*සම්ප්‍රේෂණය කළ අගයන්* පෙළගැස්වීම සැලකිලිමත් නොවේ.
    /// වෙනත් ඕනෑම ශ්‍රිතයක් මෙන්ම, සම්පාදකයා දැනටමත් `T` සහ `U` යන දෙකම නිසි ලෙස පෙළගස්වා ඇති බව සහතික කරයි.
    /// කෙසේ වෙතත්, * වෙනත් තැනකට යොමු කරන අගයන් සම්ප්‍රේෂණය කිරීමේදී (දර්ශකයන්, යොමු කිරීම්, පෙට්ටි…), ඇමතුම්කරු විසින් පෙන්වා ඇති අගයන් නිසි ලෙස පෙළගැස්වීම සහතික කළ යුතුය.
    ///
    /// `transmute` **ඇදහිය නොහැකි තරම්** අනාරක්ෂිතයි.මෙම ශ්‍රිතය සමඟ [undefined behavior][ub] ඇතිවීමට විශාල ක්‍රම තිබේ.`transmute` යනු නිරපේක්ෂ අවසාන අවස්ථාව විය යුතුය.
    ///
    /// [nomicon](../../nomicon/transmutes.html) හි අතිරේක ලියකියවිලි ඇත.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// `transmute` සැබවින්ම ප්‍රයෝජනවත් වන කරුණු කිහිපයක් තිබේ.
    ///
    /// දර්ශකයක් ශ්‍රිත දර්ශකයක් බවට පත් කිරීම.ක්‍රියාකාරී දර්ශකයන් සහ දත්ත දර්ශකයන් විවිධ ප්‍රමාණ ඇති යන්ත්‍ර සඳහා මෙය * අතේ ගෙන යා නොහැක.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// ජීවිත කාලය දීර් ing කිරීම හෝ වෙනස් නොවන ජීවිත කාලයක් කෙටි කිරීම.මෙය උසස්, ඉතා අනාරක්ෂිත Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// බලාපොරොත්තු සුන් නොකරන්න: `transmute` හි බොහෝ භාවිතයන් වෙනත් ක්‍රම මගින් ලබා ගත හැකිය.
    /// පහත දැක්වෙන්නේ `transmute` හි පොදු යෙදුම් වන අතර ඒවා ආරක්ෂිත ඉදිකිරීම් සමඟ ප්‍රතිස්ථාපනය කළ හැකිය.
    ///
    /// අමු bytes(`&[u8]`) `u32`, `f64`, ආදිය වෙත හැරවීම:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // ඒ වෙනුවට `u32::from_ne_bytes` භාවිතා කරන්න
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // හෝ අවසානය නියම කිරීමට `u32::from_le_bytes` හෝ `u32::from_be_bytes` භාවිතා කරන්න
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// දර්ශකයක් `usize` බවට හැරවීම:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // ඒ වෙනුවට `as` වාත්තු භාවිතා කරන්න
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// `*mut T` `&mut T` බවට හැරවීම:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // ඒ වෙනුවට රෙබොරෝවක් භාවිතා කරන්න
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// `&mut T` `&mut U` බවට හැරවීම:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // දැන්, `as` එකට එකතු කර නැවත පණගැන්වීම, `as` `as` හි දම්වැල සංක්‍රාන්ති නොවන බව සලකන්න
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// `&str` `&[u8]` බවට හැරවීම:
    ///
    /// ```
    /// // මෙය කිරීමට හොඳ ක්‍රමයක් නොවේ.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // ඔබට `str::as_bytes` භාවිතා කළ හැකිය
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // නැතහොත්, ඔබට වචනාර්ථයෙන් වචන පාලනය කළ හැකි නම්, බයිට් නූලක් භාවිතා කරන්න
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// `Vec<&T>` `Vec<Option<&T>>` බවට හැරවීම.
    ///
    /// කන්ටේනරයක අන්තර්ගතයේ අභ්‍යන්තර වර්ගය සම්ප්‍රේෂණය කිරීම සඳහා, බහාලුම්වල කිසිදු ආක්‍රමණයක් උල්ලං නොකිරීමට ඔබ වග බලා ගත යුතුය.
    /// `Vec` සඳහා, මෙයින් අදහස් කරන්නේ අභ්‍යන්තර වර්ගවල ප්‍රමාණය *සහ පෙළගැස්ම* යන දෙකම ගැලපෙන බවයි.
    /// වෙනත් බහාලුම් වර්ගය, පෙළගැස්ම හෝ `TypeId` ප්‍රමාණය මත රඳා පැවතිය හැකිය, එම අවස්ථාවේ දී බහාලුම් ආක්‍රමණ උල්ලං without නය නොකර සම්ප්‍රේෂණය කිසිසේත් කළ නොහැකි ය.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // vector ක්ලෝන කරන්න, පසුව අපි ඒවා නැවත භාවිතා කරමු
    /// let v_clone = v_orig.clone();
    ///
    /// // සම්ප්‍රේෂණය භාවිතා කිරීම: මෙය `Vec` හි නිශ්චිත දත්ත සැකැස්ම මත රඳා පවතින අතර එය නරක අදහසක් වන අතර නිර්වචනය නොකළ හැසිරීමට හේතු විය හැක.
    /////
    /// // කෙසේ වෙතත්, එය පිටපතක් නොවේ.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // මෙය යෝජිත ආරක්ෂිත ක්‍රමයයි.
    /// // එය සමස්ත vector නව අරාවකට පිටපත් කරයි.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // දත්ත පිරිසැලසුම මත විශ්වාසය නොතබා "transmuting" a `Vec` හි නිසි පිටපත්, අනාරක්ෂිත ක්‍රමය මෙයයි.
    /// // වචනාර්ථයෙන් `transmute` ලෙස හඳුන්වනවා වෙනුවට, අපි දර්ශක වාත්තු කිරීමක් සිදු කරන්නෙමු, නමුත් මුල් අභ්‍යන්තර වර්ගය (`&i32`) නව (`Option<&i32>`) බවට පරිවර්තනය කිරීමේදී, මේ සියල්ලම එකම අවවාද ඇත.
    /////
    /// // ඉහත දක්වා ඇති තොරතුරු වලට අමතරව, [`from_raw_parts`] ප්‍රලේඛනය ද බලන්න.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME vec_into_raw_parts ස්ථාවර වූ විට මෙය යාවත්කාලීන කරන්න.
    ///     // මුල් vector අතහැර දමා නැති බවට සහතික වන්න.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// `split_at_mut` ක්‍රියාත්මක කිරීම:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // මෙය කිරීමට විවිධ ක්‍රම තිබේ, සහ පහත දැක්වෙන (transmute) ක්‍රමය සමඟ බහුවිධ ගැටලු ඇත.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // පළමුවැන්න: සම්ප්‍රේෂණය ආරක්ෂිත වර්ගයක් නොවේ;එය පරික්ෂා කරන්නේ ටී සහ
    ///         // U එකම ප්‍රමාණයෙන් යුක්ත වේ.
    ///         // දෙවනුව, මෙන්න, ඔබට එකම මතකය වෙත යොමු කළ හැකි විකෘති යොමු දෙකක් තිබේ.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // මෙය ආරක්ෂිත ගැටළු වලින් මිදෙයි;`&mut *` ඔබට `&mut T` හෝ `* mut T` වෙතින් `&mut T` ලබා දෙනු ඇත.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // කෙසේ වෙතත්, ඔබට තවමත් එකම මතකය වෙත යොමු කළ හැකි විකෘති යොමු දෙකක් ඇත.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // සම්මත පුස්තකාලය එය කරන්නේ එලෙසයි.
    /// // ඔබට මේ වගේ දෙයක් කිරීමට අවශ්‍ය නම් මෙය හොඳම ක්‍රමයයි
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // මෙය දැන් එකම මතකය වෙත යොමු කළ හැකි විකෘති යොමු තුනක් ඇත.`slice`, rvalue ret.0 සහ rvalue ret.1.
    ///         // `slice` `let ptr = ...` ට පසුව කිසි විටෙකත් භාවිතා නොකෙරේ, එබැවින් කෙනෙකුට එය "dead" ලෙස සැලකිය හැකිය, එබැවින් ඔබට ඇත්තේ සැබෑ විකෘති පෙති දෙකක් පමණි.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: මෙමඟින් අභ්‍යන්තර සංයුතිය ස්ථායී වන අතර, අපට const fn හි අභිරුචි කේත කිහිපයක් ඇත
    // `const fn` තුළ එහි භාවිතය වළක්වන චෙක්පත්.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// `T` ලෙස ලබා දී ඇති සත්‍ය වර්ගයට ඩ්‍රොප් මැලියම් අවශ්‍ය නම් `true` ලබා දෙයි;`T` සඳහා සපයා ඇති සත්‍ය වර්ගය `Copy` ක්‍රියාත්මක කරන්නේ නම් `false` ලබා දෙයි.
    ///
    ///
    /// සත්‍ය වර්ගයට ඩ්‍රොප් මැලියම් අවශ්‍ය නොවේ නම් හෝ `Copy` ක්‍රියාත්මක කරන්නේ නම්, මෙම ශ්‍රිතයේ ප්‍රතිලාභ අගය නිශ්චිතව දක්වා නැත.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය [`mem::needs_drop`](crate::mem::needs_drop) වේ.
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// දර්ශකයකින් ඕෆ්සෙට් ගණනය කරයි.
    ///
    /// මෙය පූර්ණ සංඛ්‍යාවක් වෙත හැරීම හා වළක්වා ගැනීම සඳහා සහජයෙන්ම ක්‍රියාත්මක වේ, මන්ද පරිවර්තනය මගින් අන්වර්ථ තොරතුරු ඉවත දමනු ඇත.
    ///
    /// # Safety
    ///
    /// ආරම්භක හා ප්‍රති ing ල දර්ශකය යන දෙකම මායිම් වලින් හෝ වෙන් කළ වස්තුවක අවසානයට එක් බයිට් එකක් විය යුතුය.
    /// එක්කෝ දර්ශකය සීමාවෙන් පිටත හෝ ගණිත පිටාර ගැලීමක් සිදුවුවහොත් ආපසු ලබා දුන් අගය තවදුරටත් භාවිතා කිරීමෙන් නිර්වචනය නොකළ හැසිරීමක් ඇති වේ.
    ///
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය [`pointer::offset`] වේ.
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// පොයින්ටරයකින් ඕෆ්සෙට් ගණනය කරයි, එතීමට හැකිය.
    ///
    /// මෙය පූර්ණ සංඛ්‍යාවක් වෙත හැරීම හා වළක්වා ගැනීම සඳහා සහජයෙන්ම ක්‍රියාත්මක වේ, මන්ද පරිවර්තනය සමහර ප්‍රශස්තිකරණයන් වළක්වයි.
    ///
    /// # Safety
    ///
    /// `offset` අභ්‍යන්තරයට වඩා වෙනස්ව, මෙම සහජයෙන්ම ප්‍රති result ල ලැබෙන දර්ශකය වෙන් කරන ලද වස්තුවක කෙළවරට හෝ එක් බයිට් එකකට යොමු කිරීම සීමා නොකරන අතර එය දෙදෙනෙකුගේ අනුපූරක අංක ගණිතය සමඟ ඔතා ඇත.
    /// එහි ප්‍රති value ලයක් ලෙස ඇති අගය ඇත්ත වශයෙන්ම මතකයට ප්‍රවේශ වීම සඳහා වලංගු නොවේ.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය [`pointer::wrapping_offset`] වේ.
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// `count`*`size_of::<T>()` ප්‍රමාණයෙන් සහ පෙළගැස්වීමකින් යුත් සුදුසු `llvm.memcpy.p0i8.0i8.*` අභ්‍යන්තරයට සමාන වේ
    ///
    /// `min_align_of::<T>()`
    ///
    /// වාෂ්පශීලී පරාමිතිය `true` ලෙස සකසා ඇති බැවින් ප්‍රමාණය ශුන්‍යයට සමාන නොවේ නම් එය ප්‍රශස්තිකරණය නොවේ.
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// `count *size_of::<T>()` ප්‍රමාණයෙන් සහ පෙළගැස්වීමකින් යුත් සුදුසු `llvm.memmove.p0i8.0i8.*` අභ්‍යන්තරයට සමාන වේ
    ///
    /// `min_align_of::<T>()`
    ///
    /// වාෂ්පශීලී පරාමිතිය `true` ලෙස සකසා ඇති බැවින් ප්‍රමාණය ශුන්‍යයට සමාන නොවේ නම් එය ප්‍රශස්තිකරණය නොවේ.
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// `count *size_of::<T>()` ප්‍රමාණයෙන් සහ `min_align_of::<T>()` පෙළගැස්වීමකින් යුත් සුදුසු `llvm.memset.p0i8.*` අභ්‍යන්තරයට සමාන වේ.
    ///
    ///
    /// වාෂ්පශීලී පරාමිතිය `true` ලෙස සකසා ඇති බැවින් ප්‍රමාණය ශුන්‍යයට සමාන නොවේ නම් එය ප්‍රශස්තිකරණය නොවේ.
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// `src` දර්ශකයෙන් වාෂ්පශීලී බරක් සිදු කරයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය [`core::ptr::read_volatile`](crate::ptr::read_volatile) වේ.
    pub fn volatile_load<T>(src: *const T) -> T;
    /// `dst` දර්ශකයට වාෂ්පශීලී ගබඩාවක් සිදු කරයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය [`core::ptr::write_volatile`](crate::ptr::write_volatile) වේ.
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// `src` දර්ශකයෙන් වාෂ්පශීලී බරක් සිදු කරයි දර්ශකය පෙළගැස්වීමට අවශ්‍ය නොවේ.
    ///
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// `dst` දර්ශකයට වාෂ්පශීලී ගබඩාවක් සිදු කරයි.
    /// දර්ශකය පෙළගැස්වීමට අවශ්‍ය නොවේ.
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// `f32` හි වර්ගමූලය ලබා දෙයි
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// `f64` හි වර්ගමූලය ලබා දෙයි
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// `f32` පූර්ණ සංඛ්‍යා බලයකට ඔසවයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// `f64` පූර්ණ සංඛ්‍යා බලයකට ඔසවයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// `f32` හි සයින් නැවත ලබා දෙයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// `f64` හි සයින් නැවත ලබා දෙයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// `f32` හි කොසයින් ලබා දෙයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// `f64` හි කොසයින් ලබා දෙයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// `f32` `f32` බලයකට ඔසවයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// `f64` `f64` බලයකට ඔසවයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// `f32` හි on ාතීය අගය ලබා දෙයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// `f64` හි on ාතීය අගය ලබා දෙයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// `f32` බලයට ඔසවා ඇති 2 ප්‍රතිලාභ.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// `f64` බලයට ඔසවා ඇති 2 ප්‍රතිලාභ.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// `f32` හි ස්වාභාවික ල ar ු ගණකය ලබා දෙයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// `f64` හි ස්වාභාවික ල ar ු ගණකය ලබා දෙයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// `f32` හි පාදක 10 ල ar ු ගණකය ලබා දෙයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// `f64` හි පාදක 10 ල ar ු ගණකය ලබා දෙයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// `f32` හි පාදක 2 ල ar ු ගණකය ලබා දෙයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// `f64` හි පාදක 2 ල ar ු ගණකය ලබා දෙයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// `f32` අගයන් සඳහා `a * b + c` ලබා දෙයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// `f64` අගයන් සඳහා `a * b + c` ලබා දෙයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// `f32` හි නිරපේක්ෂ අගය ලබා දෙයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// `f64` හි නිරපේක්ෂ අගය ලබා දෙයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// අවම `f32` අගයන් දෙකක් ලබා දෙයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// අවම `f64` අගයන් දෙකක් ලබා දෙයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// උපරිම `f32` අගයන් දෙකක් ලබා දෙයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// උපරිම `f64` අගයන් දෙකක් ලබා දෙයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// `f32` අගයන් සඳහා `y` සිට `x` දක්වා ලකුණ පිටපත් කරයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// `f64` අගයන් සඳහා `y` සිට `x` දක්වා ලකුණ පිටපත් කරයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// `f32` ට වඩා අඩු හෝ සමාන විශාලතම නිඛිලය ලබා දෙයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// `f64` ට වඩා අඩු හෝ සමාන විශාලතම නිඛිලය ලබා දෙයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// `f32` ට වඩා වැඩි හෝ සමාන කුඩාම නිඛිලය ලබා දෙයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// `f64` ට වඩා වැඩි හෝ සමාන කුඩාම නිඛිලය ලබා දෙයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// `f32` හි පූර්ණ සංඛ්‍යා කොටස ලබා දෙයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// `f64` හි පූර්ණ සංඛ්‍යා කොටස ලබා දෙයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// ආසන්නතම නිඛිලය `f32` වෙත ලබා දෙයි.
    /// තර්කය පූර්ණ සංඛ්‍යාවක් නොවේ නම් නිරවද්‍ය පාවෙන ලක්ෂ්‍ය ව්‍යතිරේකයක් මතු කළ හැකිය.
    pub fn rintf32(x: f32) -> f32;
    /// ආසන්නතම නිඛිලය `f64` වෙත ලබා දෙයි.
    /// තර්කය පූර්ණ සංඛ්‍යාවක් නොවේ නම් නිරවද්‍ය පාවෙන ලක්ෂ්‍ය ව්‍යතිරේකයක් මතු කළ හැකිය.
    pub fn rintf64(x: f64) -> f64;

    /// ආසන්නතම නිඛිලය `f32` වෙත ලබා දෙයි.
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    pub fn nearbyintf32(x: f32) -> f32;
    /// ආසන්නතම නිඛිලය `f64` වෙත ලබා දෙයි.
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    pub fn nearbyintf64(x: f64) -> f64;

    /// ආසන්නතම නිඛිලය `f32` වෙත ලබා දෙයි.ශුන්‍යයෙන් අඩක් දුරින් ඇති අවස්ථා වට කරයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// ආසන්නතම නිඛිලය `f64` වෙත ලබා දෙයි.ශුන්‍යයෙන් අඩක් දුරින් ඇති අවස්ථා වට කරයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය වේ
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// වීජීය නීති මත පදනම්ව ප්‍රශස්තිකරණයට ඉඩ දෙන පාවෙන එකතු කිරීම.
    /// යෙදවුම් සීමිත යැයි උපකල්පනය කළ හැකිය.
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// වීජීය නීති මත පදනම්ව ප්‍රශස්තිකරණයට ඉඩ සලසන පාවෙන අඩු කිරීම.
    /// යෙදවුම් සීමිත යැයි උපකල්පනය කළ හැකිය.
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// වීජීය නීති මත පදනම්ව ප්‍රශස්තිකරණයට ඉඩ දෙන පාවෙන ගුණ කිරීම.
    /// යෙදවුම් සීමිත යැයි උපකල්පනය කළ හැකිය.
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// වීජීය නීති මත පදනම්ව ප්‍රශස්තිකරණයට ඉඩ දෙන පාවෙන අංශය.
    /// යෙදවුම් සීමිත යැයි උපකල්පනය කළ හැකිය.
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// වීජීය නීති මත පදනම්ව ප්‍රශස්තිකරණයට ඉඩ දෙන පාවෙන ඉතිරිය.
    /// යෙදවුම් සීමිත යැයි උපකල්පනය කළ හැකිය.
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// LLVM හි fptoui/fptosi සමඟ පරිවර්තනය කරන්න, එමඟින් පරාසය ඉක්මවා යන අගයන් සඳහා undef නැවත ලබා දිය හැකිය
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// [`f32::to_int_unchecked`] සහ [`f64::to_int_unchecked`] ලෙස ස්ථාවර කර ඇත.
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// `T` නිඛිල වර්ගයක සකසා ඇති බිටු ගණන ලබා දෙයි
    ///
    /// මෙම අභ්‍යන්තරයේ ස්ථායී අනුවාදයන් `count_ones` ක්‍රමය හරහා පූර්ණ සංඛ්‍යා ප්‍රාථමික මත ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// `T` නිඛිල වර්ගයක ප්‍රමුඛ පෙළේ සැකසූ බිට් (zeroes) ගණන ලබා දෙයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදයන් `leading_zeros` ක්‍රමය හරහා පූර්ණ සංඛ්‍යා ප්‍රාථමික මත ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `0` අගය සහිත `x`, `T` හි බිට් පළල නැවත ලබා දෙනු ඇත.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// `ctlz` මෙන්, නමුත් `0` අගය සහිත `x` ලබා දුන් විට එය `undef` ආපසු ලබා දෙන බැවින් අමතර අනාරක්ෂිත වේ.
    ///
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// `T` නිඛිල වර්ගයක (zeroes) පසුපස ලුහුබඳින බිටු ගණන ලබා දෙයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදයන් `trailing_zeros` ක්‍රමය හරහා පූර්ණ සංඛ්‍යා ප්‍රාථමික මත ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `0` අගය සහිත `x`, `T` හි බිට් පළල නැවත ලබා දෙනු ඇත:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// `cttz` මෙන්, නමුත් `0` අගය සහිත `x` ලබා දුන් විට එය `undef` ආපසු ලබා දෙන බැවින් අමතර අනාරක්ෂිත වේ.
    ///
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// `T` නිඛිල වර්ගයක බයිට් ආපසු හරවයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදයන් `swap_bytes` ක්‍රමය හරහා පූර්ණ සංඛ්‍යා ප්‍රාථමික මත ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// `T` නිඛිල වර්ගයක බිටු ආපසු හරවයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදයන් `reverse_bits` ක්‍රමය හරහා පූර්ණ සංඛ්‍යා ප්‍රාථමික මත ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// පරීක්ෂා කරන ලද පූර්ණ සංඛ්‍යා එකතු කිරීම සිදු කරයි.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදයන් `overflowing_add` ක්‍රමය හරහා පූර්ණ සංඛ්‍යා ප්‍රාථමික මත ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// පරීක්ෂා කරන ලද පූර්ණ සංඛ්‍යා අඩු කිරීම සිදු කරයි
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදයන් `overflowing_sub` ක්‍රමය හරහා පූර්ණ සංඛ්‍යා ප්‍රාථමික මත ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// පරීක්ෂා කරන ලද පූර්ණ සංඛ්‍යා ගුණ කිරීම සිදු කරයි
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදයන් `overflowing_mul` ක්‍රමය හරහා පූර්ණ සංඛ්‍යා ප්‍රාථමික මත ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// නිශ්චිත බෙදීමක් සිදු කරයි, එහි ප්‍රති X ලයක් ලෙස `x % y != 0` හෝ `y == 0` හෝ `x == T::MIN && y == -1`
    ///
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// පරීක්ෂා නොකළ බෙදීමක් සිදු කරයි, එහි ප්‍රති X ලයක් ලෙස `y == 0` හෝ `x == T::MIN && y == -1`
    ///
    ///
    /// මෙම අභ්‍යන්තරය සඳහා ආරක්ෂිත එතුම `checked_div` ක්‍රමය හරහා පූර්ණ සංඛ්‍යා ප්‍රාථමික මත ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// `y == 0` හෝ `x == T::MIN && y == -1` විට නිර්වචනය නොකළ හැසිරීමක ප්‍රති un ලයක් ලෙස පරීක්ෂා නොකළ කොටසක ඉතිරි කොටස ලබා දෙයි
    ///
    ///
    /// `checked_rem` ක්‍රමය හරහා පූර්ණ සංඛ්‍යා ප්‍රාථමික මත මෙම සහජ සඳහා ආරක්ෂිත ආවරණ ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// පරීක්ෂා නොකළ වම් මාරුවක් සිදු කරයි, එහි ප්‍රති X ලයක් ලෙස `y < 0` හෝ `y >= N`, නිර්වචනය නොකළ හැසිරීමක් ඇති අතර, N යනු බිටු වල T හි පළල වේ.
    ///
    ///
    /// මෙම අභ්‍යන්තරය සඳහා ආරක්ෂිත එතුම `checked_shl` ක්‍රමය හරහා පූර්ණ සංඛ්‍යා ප්‍රාථමික මත ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// නිවැරදි නොකළ මාරුවක් සිදු කරයි, එහි ප්‍රති X ලයක් ලෙස `y < 0` හෝ `y >= N`, නිර්වචනය නොකළ හැසිරීමක් ඇති අතර, N යනු බිටු වල T හි පළල වේ.
    ///
    ///
    /// `checked_shr` ක්‍රමය හරහා පූර්ණ සංඛ්‍යා ප්‍රාථමික මත මෙම සහජ සඳහා ආරක්ෂිත ආවරණ ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// `x + y > T::MAX` හෝ `x + y < T::MIN` විට නිර්වචනය නොකළ හැසිරීමක ප්‍රති un ලයක් ලෙස, පරීක්ෂා නොකළ එකතු කිරීමක ප්‍රති result ලය ලබා දෙයි.
    ///
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// `x - y > T::MAX` හෝ `x - y < T::MIN` විට නිර්වචනය නොකළ හැසිරීමක ප්‍රති un ලයක් ලෙස, පරීක්ෂා නොකළ අඩුකිරීමේ ප්‍රති result ලය ලබා දෙයි.
    ///
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// `x *y > T::MAX` හෝ `x* y < T::MIN` විට නිර්වචනය නොකළ හැසිරීමක ප්‍රති un ලයක් ලෙස, පරීක්ෂා නොකළ ගුණනයක ප්‍රති result ලය ලබා දෙයි.
    ///
    ///
    /// මෙම සහජයට ස්ථාවර ප්‍රතිවිරෝධකයක් නොමැත.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// වමට භ්‍රමණය වේ.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදයන් `rotate_left` ක්‍රමය හරහා පූර්ණ සංඛ්‍යා ප්‍රාථමික මත ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// කාර්ය සාධනය දකුණට භ්‍රමණය වේ.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදයන් `rotate_right` ක්‍රමය හරහා පූර්ණ සංඛ්‍යා ප්‍රාථමික මත ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// ප්‍රතිලාභ (a + b) mod 2 <sup>N</sup>, මෙහි N යනු බිටු වල T හි පළල වේ.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදයන් `wrapping_add` ක්‍රමය හරහා පූර්ණ සංඛ්‍යා ප්‍රාථමික මත ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// ප්‍රතිලාභ (a, b) mod 2 <sup>N</sup>, මෙහි N යනු බිටු වල T හි පළල වේ.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදයන් `wrapping_sub` ක්‍රමය හරහා පූර්ණ සංඛ්‍යා ප්‍රාථමික මත ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// ප්‍රතිලාභ (a * b) mod 2 <sup>N</sup>, මෙහි N යනු බිටු වල T හි පළල වේ.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදයන් `wrapping_mul` ක්‍රමය හරහා පූර්ණ සංඛ්‍යා ප්‍රාථමික මත ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// `a + b` ගණනය කරයි, සංඛ්‍යාත්මක සීමාවන්ගෙන් සංතෘප්ත වේ.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදයන් `saturating_add` ක්‍රමය හරහා පූර්ණ සංඛ්‍යා ප්‍රාථමික මත ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// `a - b` ගණනය කරයි, සංඛ්‍යාත්මක සීමාවන්ගෙන් සංතෘප්ත වේ.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදයන් `saturating_sub` ක්‍රමය හරහා පූර්ණ සංඛ්‍යා ප්‍රාථමික මත ලබා ගත හැකිය.
    /// උදාහරණ වශයෙන්,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// 'v' හි ප්‍රභේදය සඳහා වෙනස් කොට සැලකීමේ අගය ලබා දෙයි;
    /// `T` හි කිසිදු වෙනස්කම් කිරීමක් නොමැති නම්, `0` ආපසු ලබා දේ.
    ///
    /// මෙම සහජයේ ස්ථායී අනුවාදය [`core::mem::discriminant`](crate::mem::discriminant) වේ.
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// `T` වාත්තු වර්ගයේ ප්‍රභේද ගණන `usize` වෙත ලබා දෙයි;
    /// `T` හි ප්‍රභේද නොමැති නම්, `0` ආපසු ලබා දේ.ජනාවාස නොවන ප්‍රභේද ගණනය කෙරේ.
    ///
    /// මෙම සහජයේ ස්ථායී කළ යුතු අනුවාදය [`mem::variant_count`] වේ.
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust හි "try catch" ව්‍යුහය `try_fn` ක්‍රියාකාරී දර්ශකය `data` දත්ත දර්ශකය සමඟ ක්‍රියාත්මක කරයි.
    ///
    /// තෙවන තර්කය යනු panic සිදුවුවහොත් එය හැඳින්වෙන ශ්‍රිතයකි.
    /// මෙම ශ්‍රිතය දත්ත දර්ශකය සහ දර්ශකය අල්ලා ගත් ඉලක්කගත ව්‍යතිරේක වස්තුව වෙත ගෙන යයි.
    ///
    /// වැඩි විස්තර සඳහා සම්පාදකයාගේ ප්‍රභවය මෙන්ම std හි ඇල්ලීම ක්‍රියාත්මක කිරීම බලන්න.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// LLVM අනුව `!nontemporal` වෙළඳසැලක් විමෝචනය කරයි (ඒවායේ ලියකියවිලි බලන්න).
    /// බොහෝ විට ස්ථාවර නොවනු ඇත.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// වැඩි විස්තර සඳහා `<*const T>::offset_from` හි ප්‍රලේඛනය බලන්න.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// වැඩි විස්තර සඳහා `<*const T>::guaranteed_eq` හි ප්‍රලේඛනය බලන්න.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// වැඩි විස්තර සඳහා `<*const T>::guaranteed_ne` හි ප්‍රලේඛනය බලන්න.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// සම්පාදනය කරන වේලාවට වෙන් කරන්න.ධාවන වේලාවට කැඳවිය යුතු නොවේ.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// සමහර කාර්යයන් මෙහි අර්ථ දක්වා ඇත්තේ ඒවා අහම්බෙන් මෙම මොඩියුලය තුළ ස්ථාවර ලෙස ලබා දී ඇති බැවිනි.
// <https://github.com/rust-lang/rust/issues/15702> බලන්න.
// (`transmute` ද මෙම ගණයට අයත් වේ, නමුත් `T` සහ `U` එකම ප්‍රමාණයේ දැයි පරීක්ෂා කිරීම නිසා එය ඔතා තැබිය නොහැක.)
//

/// X001 ට සාපේක්ෂව `ptr` නිසියාකාරව පෙළගස්වා ඇත්දැයි පරීක්ෂා කරයි.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// `src` සිට `dst` දක්වා `count *size_of::<T>()` බයිට් පිටපත් කරයි.ප්‍රභවය සහ ගමනාන්තය* අතිච්ඡාදනය නොවිය යුතුය.
///
/// අතිච්ඡාදනය විය හැකි මතක කලාප සඳහා, ඒ වෙනුවට [`copy`] භාවිතා කරන්න.
///
/// `copy_nonoverlapping` අර්ථ නිරූපණය C හි [`memcpy`] ට සමාන වේ, නමුත් තර්ක අනුපිළිවෙල මාරු කර ඇත.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// පහත සඳහන් කොන්දේසි කිසිවක් උල්ලං are නය වී ඇත්නම් හැසිරීම නිර්වචනය නොකෙරේ:
///
/// * `src` `count * size_of::<T>()` බයිට් කියවීම සඳහා [valid] විය යුතුය.
///
/// * `dst` `count * size_of::<T>()` බයිට් ලිවීම සඳහා [valid] විය යුතුය.
///
/// * `src` සහ `dst` යන දෙකම නිසි ලෙස පෙළ ගැස්විය යුතුය.
///
/// * මතකයේ කලාපය `src` වලින් ආරම්භ වන අතර එහි ප්‍රමාණය ගණනය කෙරේ *
///   size_of: :<T>() `dst` සිට ඇරඹෙන මතක කලාපයේ එකම ප්‍රමාණයෙන් බයිට් * අතිච්ඡාදනය නොවිය යුතුය.
///
/// [`read`] මෙන්, `copy_nonoverlapping` `T` හි බිට්වේස් පිටපතක් නිර්මාණය කරයි, `T` යනු [`Copy`] ද යන්න නොසලකා.
/// `T` [`Copy`] නොවේ නම්, `*src` වලින් ආරම්භ වන කලාපයේ සහ `* dst` වලින් ආරම්භ වන කලාපයේ අගයන් * දෙකම භාවිතා කිරීමෙන් [violate memory safety][read-ownership] විය හැකිය.
///
///
/// Effectively ලදායි ලෙස පිටපත් කළ ප්‍රමාණය වුවද (`ගණන් * ප්‍රමාණය_ of: : '<T>()`) `0` වේ, දර්ශකයන් NULL නොවන අතර නිසි ලෙස පෙළගස්වා තිබිය යුතුය.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// [`Vec::append`] අතින් ක්‍රියාත්මක කරන්න:
///
/// ```
/// use std::ptr;
///
/// /// `src` හි සියලුම අංග `dst` වෙත ගෙන යන අතර `src` හිස්ව පවතී.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // `dst` හි සියලුම `src` රඳවා තබා ගැනීමට ප්‍රමාණවත් ධාරිතාවක් ඇති බවට සහතික වන්න.
///     dst.reserve(src_len);
///
///     unsafe {
///         // `Vec` කිසි විටෙකත් `isize::MAX` බයිට් වලට වඩා වෙන් නොකරන බැවින් ඕෆ්සෙට් සඳහා වන ඇමතුම සැමවිටම ආරක්ෂිත වේ.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // `src` එහි අන්තර්ගතය අත නොතබන්න.
///         // panics වෙතින් තවත් යමක් පහළ වුවහොත් ගැටළු වළක්වා ගැනීම සඳහා අපි මෙය පළමුව කරන්නෙමු.
///         src.set_len(0);
///
///         // විකෘති යොමු කිරීම් අන්වර්ථ නොවන නිසා කලාප දෙක අතිච්ඡාදනය විය නොහැකි අතර වෙනස් vectors දෙකකට එකම මතකයක් තිබිය නොහැක.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // `dst` හි දැන් අන්තර්ගතය `src` හි ඇති බව දැනුම් දෙන්න.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: මෙම චෙක්පත් ක්‍රියාත්මක වන වේලාවේදී පමණක් සිදු කරන්න
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // කෝඩජන් බලපෑම කුඩා ලෙස තබා ගැනීමට කලබල නොවන්න.
        abort();
    }*/

    // ආරක්ෂාව: `copy_nonoverlapping` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව විය යුතුය
    // අමතන්නා විසින් තහවුරු කරන ලදි.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// `count *size_of::<T>()` සිට `dst` දක්වා `count* size_of::<T>()` බයිට් පිටපත් කරයි.ප්‍රභවය සහ ගමනාන්තය අතිච්ඡාදනය විය හැකිය.
///
/// ප්‍රභවය සහ ගමනාන්තය * කිසි විටෙකත් අතිච්ඡාදනය නොවන්නේ නම්, ඒ වෙනුවට [`copy_nonoverlapping`] භාවිතා කළ හැකිය.
///
/// `copy` අර්ථ නිරූපණය C හි [`memmove`] ට සමාන වේ, නමුත් තර්ක අනුපිළිවෙල මාරු කර ඇත.
/// පිටපත් කිරීම සිදුවන්නේ බයිට් `src` සිට තාවකාලික අරාවකට පිටපත් කර අරාව සිට `dst` දක්වා පිටපත් කිරීමෙනි.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// පහත සඳහන් කොන්දේසි කිසිවක් උල්ලං are නය වී ඇත්නම් හැසිරීම නිර්වචනය නොකෙරේ:
///
/// * `src` `count * size_of::<T>()` බයිට් කියවීම සඳහා [valid] විය යුතුය.
///
/// * `dst` `count * size_of::<T>()` බයිට් ලිවීම සඳහා [valid] විය යුතුය.
///
/// * `src` සහ `dst` යන දෙකම නිසි ලෙස පෙළ ගැස්විය යුතුය.
///
/// [`read`] මෙන්, `copy` `T` හි බිට්වේස් පිටපතක් නිර්මාණය කරයි, `T` යනු [`Copy`] ද යන්න නොසලකා.
/// `T` [`Copy`] නොවේ නම්, කලාපයේ අගයන් `*src` වලින් ආරම්භ වන අතර `* dst` වලින් ආරම්භ වන කලාපයට [violate memory safety][read-ownership] කළ හැකිය.
///
///
/// Effectively ලදායි ලෙස පිටපත් කළ ප්‍රමාණය වුවද (`ගණන් * ප්‍රමාණය_ of: : '<T>()`) `0` වේ, දර්ශකයන් NULL නොවන අතර නිසි ලෙස පෙළගස්වා තිබිය යුතුය.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// අනාරක්ෂිත බෆරයකින් Rust vector කාර්යක්ෂමව සාදන්න:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` එහි වර්ගය සහ ශුන්‍ය නොවන සඳහා නිවැරදිව පෙළ ගැස්විය යුතුය.
/// /// * `ptr` `T` වර්ගයේ `elts` පරස්පර මූලද්‍රව්‍ය කියවීම සඳහා වලංගු විය යුතුය.
/// /// * `T: Copy` හැර මෙම ශ්‍රිතය ඇමතීමෙන් පසුව එම මූලද්‍රව්‍ය භාවිතා නොකළ යුතුය.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // ආරක්ෂාව: අපගේ පූර්ව කොන්දේසිය මඟින් ප්‍රභවය පෙළගස්වා වලංගු බව සහතික කරයි,
///     // සහ `Vec::with_capacity` මඟින් ඒවා ලිවීමට අපට භාවිතා කළ හැකි ඉඩක් ඇති බව සහතික කරයි.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // ආරක්ෂාව: අපි මීට පෙර මෙම විශාල ධාරිතාවයෙන් එය නිර්මාණය කළෙමු.
///     // පෙර `copy` විසින් මෙම මූලද්‍රව්‍යයන් ආරම්භ කර ඇත.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: මෙම චෙක්පත් ක්‍රියාත්මක වන වේලාවේදී පමණක් සිදු කරන්න
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // කෝඩජන් බලපෑම කුඩා ලෙස තබා ගැනීමට කලබල නොවන්න.
        abort();
    }*/

    // ආරක්ෂාව: `copy` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව අමතන්නා විසින් තහවුරු කළ යුතුය.
    unsafe { copy(src, dst, count) }
}

/// `dst` සිට `val` දක්වා ඇරඹෙන `count * size_of::<T>()` බයිට් මතකය සකසයි.
///
/// `write_bytes` C හි [`memset`] ට සමාන නමුත් `count * size_of::<T>()` බයිට් `val` ලෙස සකසයි.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// පහත සඳහන් කොන්දේසි කිසිවක් උල්ලං are නය වී ඇත්නම් හැසිරීම නිර්වචනය නොකෙරේ:
///
/// * `dst` `count * size_of::<T>()` බයිට් ලිවීම සඳහා [valid] විය යුතුය.
///
/// * `dst` නිසි ලෙස පෙළ ගැස්විය යුතුය.
///
/// මීට අමතරව, ලබා දී ඇති මතක කලාපයට `count * size_of::<T>()` බයිට් ලිවීමෙන් වලංගු අගය `T` බවට ඇමතුම්කරු සහතික විය යුතුය.
/// `T` හි අවලංගු අගයක් අඩංගු `T` ලෙස ටයිප් කළ මතක කලාපයක් භාවිතා කිරීම නිර්වචනය නොකළ හැසිරීමකි.
///
/// Effectively ලදායි ලෙස පිටපත් කළ ප්‍රමාණය වුවද (`ගණන් * ප්‍රමාණය_ of: : '<T>()`) `0` වේ, දර්ශකය NULL නොවන අතර නිසි ලෙස පෙළගස්වා තිබිය යුතුය.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// මූලික භාවිතය:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// අවලංගු අගයක් නිර්මාණය කිරීම:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // `Box<T>` ශුන්‍ය දර්ශකයක් සමඟ නැවත ලිවීමෙන් පෙර පැවති අගය කාන්දු වේ.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // මෙම අවස්ථාවෙහිදී, `v` භාවිතා කිරීම හෝ අතහැර දැමීම නිර්වචනය නොකළ හැසිරීමට හේතු වේ.
/// // drop(v); // ERROR
///
/// // `v` "uses" පවා කාන්දු වීම, එබැවින් නිර්වචනය නොකළ හැසිරීමකි.
/// // mem::forget(v); // ERROR
///
/// // ඇත්ත වශයෙන්ම, මූලික වර්ගයේ පිරිසැලසුම් වෙනස්වීම් අනුව `v` අවලංගු වේ, එබැවින් *ස්පර්ශ කරන ඕනෑම* මෙහෙයුමක් නිර්වචනය නොකළ හැසිරීමකි.
/////
/// // v2 =v;//දෝෂයකි
///
/// unsafe {
///     // ඒ වෙනුවට වලංගු අගයක් තබමු
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // දැන් පෙට්ටිය හොඳයි
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // ආරක්ෂාව: `write_bytes` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව අමතන්නා විසින් තහවුරු කළ යුතුය.
    unsafe { write_bytes(dst, val, count) }
}