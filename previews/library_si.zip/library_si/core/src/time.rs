#![stable(feature = "duration_core", since = "1.25.0")]

//! තාවකාලික ප්‍රමාණකරණය.
//!
//! Example:
//!
//! ```
//! use std::time::Duration;
//!
//! let five_seconds = Duration::new(5, 0);
//! // ප්‍රකාශ දෙකම සමාන වේ
//! assert_eq!(Duration::new(5, 0), Duration::from_secs(5));
//! ```

use crate::fmt;
use crate::iter::Sum;
use crate::ops::{Add, AddAssign, Div, DivAssign, Mul, MulAssign, Sub, SubAssign};

const NANOS_PER_SEC: u32 = 1_000_000_000;
const NANOS_PER_MILLI: u32 = 1_000_000;
const NANOS_PER_MICRO: u32 = 1_000;
const MILLIS_PER_SEC: u64 = 1_000;
const MICROS_PER_SEC: u64 = 1_000_000;

/// සාමාන්‍යයෙන් පද්ධති කල් ඉකුත්වීම සඳහා භාවිතා කරන කාල පරාසයක් නිරූපණය කිරීමට `Duration` වර්ගයකි.
///
/// සෑම `Duration` එකක්ම තත්පර ගණනකින් සමන්විත වන අතර භාගික කොටසක් නැනෝ තත්පර වලින් නිරූපණය කෙරේ.
/// යටින් පවතින පද්ධතිය නැනෝ තත්පර මට්ටමේ නිරවද්‍යතාවයට සහය නොදක්වන්නේ නම්, පද්ධති කල් ඉකුත් වීමක් ඇති ඒපීඅයි සාමාන්‍යයෙන් නැනෝ තත්පර ගණන වට කරයි.
///
/// [`කාලසීමාව] [`Add`], [`Sub`], සහ අනෙකුත් [`ops`] traits ඇතුළුව බොහෝ පොදු traits ක්‍රියාත්මක කරයි.එය ශුන්‍ය දිග `Duration` ආපසු ලබා දීමෙන් [`Default`] ක්‍රියාත්මක කරයි.
///
/// [`ops`]: crate::ops
///
/// # Examples
///
/// ```
/// use std::time::Duration;
///
/// let five_seconds = Duration::new(5, 0);
/// let five_seconds_and_five_nanos = five_seconds + Duration::new(0, 5);
///
/// assert_eq!(five_seconds_and_five_nanos.as_secs(), 5);
/// assert_eq!(five_seconds_and_five_nanos.subsec_nanos(), 5);
///
/// let ten_millis = Duration::from_millis(10);
/// ```
///
/// # `Duration` අගයන් ආකෘතිකරණය කිරීම
///
/// `Duration` මිනිස් කියවීමේ හැකියාව සඳහා කාල පරාසයන් සංයුති කිරීමට විවිධ ක්‍රම ඇති බැවින් හිතාමතාම `Display` impl එකක් නොමැත.
/// `Duration` අගයෙහි සම්පූර්ණ නිරවද්‍යතාවය පෙන්වන `Debug` impl එකක් සපයයි.
///
/// `Debug` ප්‍රතිදානය මයික්‍රෝ තත්පර සඳහා ASCII නොවන "µs" උපසර්ගය භාවිතා කරයි.
/// ඔබේ වැඩසටහන් ප්‍රතිදානය පූර්ණ යුනිකෝඩ් අනුකූලතාව මත විශ්වාසය තැබිය නොහැකි සන්දර්භයන් තුළ දිස්විය හැකි නම්, ඔබට `Duration` වස්තු ඔබම සංයුති කිරීමට හෝ එසේ කිරීමට crate භාවිතා කිරීමට අවශ්‍ය විය හැකිය.
///
///
///
///
///
///
///
#[stable(feature = "duration", since = "1.3.0")]
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Default)]
pub struct Duration {
    secs: u64,
    nanos: u32, // සෑම විටම 0 <=නැනෝස් <NANOS_PER_SEC
}

impl Duration {
    /// තත්පරයක කාලසීමාව.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::SECOND, Duration::from_secs(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const SECOND: Duration = Duration::from_secs(1);

    /// මිලි තත්පරයක කාලසීමාව.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MILLISECOND, Duration::from_millis(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MILLISECOND: Duration = Duration::from_millis(1);

    /// එක් මයික්‍රෝ තත්පරයක කාලසීමාව.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MICROSECOND, Duration::from_micros(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MICROSECOND: Duration = Duration::from_micros(1);

    /// එක් නැනෝ තත්පරයක කාලසීමාව.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::NANOSECOND, Duration::from_nanos(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const NANOSECOND: Duration = Duration::from_nanos(1);

    /// ශුන්‍ය කාල සීමාවක්.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// let duration = Duration::ZERO;
    /// assert!(duration.is_zero());
    /// assert_eq!(duration.as_nanos(), 0);
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    pub const ZERO: Duration = Duration::from_nanos(0);

    /// උපරිම කාලය.
    ///
    /// එය දළ වශයෙන් අවුරුදු 584,942,417,355 ක කාලයකට සමාන වේ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MAX, Duration::new(u64::MAX, 1_000_000_000 - 1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MAX: Duration = Duration::new(u64::MAX, NANOS_PER_SEC - 1);

    /// නිශ්චිත තත්පර ගණන සහ අතිරේක නැනෝ තත්පර වලින් නව `Duration` නිර්මාණය කරයි.
    ///
    /// නැනෝ තත්පර ගණන බිලියනයකට වඩා වැඩි නම් (තත්පරයකින් නැනෝ තත්පර ගණන), එය ලබා දුන් තත්පරයට ගෙන යනු ඇත.
    ///
    ///
    /// # Panics
    ///
    /// නැනෝ තත්පර වලින් රැගෙන යාම තත්පර කවුන්ටරය ඉක්මවා ගියහොත් මෙම ඉදිකිරීම්කරු panic කරනු ඇත.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let five_seconds = Duration::new(5, 0);
    /// ```
    ///
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn new(secs: u64, nanos: u32) -> Duration {
        let secs = match secs.checked_add((nanos / NANOS_PER_SEC) as u64) {
            Some(secs) => secs,
            None => panic!("overflow in Duration::new"),
        };
        let nanos = nanos % NANOS_PER_SEC;
        Duration { secs, nanos }
    }

    /// සම්පූර්ණ තත්පර ගණනෙන් නව `Duration` නිර්මාණය කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_secs(5);
    ///
    /// assert_eq!(5, duration.as_secs());
    /// assert_eq!(0, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_secs(secs: u64) -> Duration {
        Duration { secs, nanos: 0 }
    }

    /// නිශ්චිත මිලි තත්පර ගණනෙන් නව `Duration` සාදයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(2569);
    ///
    /// assert_eq!(2, duration.as_secs());
    /// assert_eq!(569_000_000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_millis(millis: u64) -> Duration {
        Duration {
            secs: millis / MILLIS_PER_SEC,
            nanos: ((millis % MILLIS_PER_SEC) as u32) * NANOS_PER_MILLI,
        }
    }

    /// නිශ්චිත මයික්‍රෝ තත්පර සංඛ්‍යාවෙන් නව `Duration` සාදයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_000_002);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(2000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_from_micros", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_micros(micros: u64) -> Duration {
        Duration {
            secs: micros / MICROS_PER_SEC,
            nanos: ((micros % MICROS_PER_SEC) as u32) * NANOS_PER_MICRO,
        }
    }

    /// නිශ්චිත නැනෝ තත්පර සංඛ්‍යාවෙන් නව `Duration` සාදයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_nanos(1_000_000_123);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(123, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_nanos(nanos: u64) -> Duration {
        Duration {
            secs: nanos / (NANOS_PER_SEC as u64),
            nanos: (nanos % (NANOS_PER_SEC as u64)) as u32,
        }
    }

    /// මෙම `Duration` කාලය නොමැති නම් සත්‍ය වේ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert!(Duration::ZERO.is_zero());
    /// assert!(Duration::new(0, 0).is_zero());
    /// assert!(Duration::from_nanos(0).is_zero());
    /// assert!(Duration::from_secs(0).is_zero());
    ///
    /// assert!(!Duration::new(1, 1).is_zero());
    /// assert!(!Duration::from_nanos(1).is_zero());
    /// assert!(!Duration::from_secs(1).is_zero());
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    #[inline]
    pub const fn is_zero(&self) -> bool {
        self.secs == 0 && self.nanos == 0
    }

    /// මෙම `Duration` හි අඩංගු _whole_ තත්පර ගණන ලබා දෙයි.
    ///
    /// ආපසු ලබා දුන් අගයට කාල පරිච්ඡේදයේ භාගික (nanosecond) කොටස ඇතුළත් නොවේ, එය [`subsec_nanos`] භාවිතයෙන් ලබා ගත හැකිය.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_secs(), 5);
    /// ```
    ///
    /// `Duration` මගින් නිරූපණය වන මුළු තත්පර ගණන තීරණය කිරීම සඳහා, [`subsec_nanos`] සමඟ එක්ව `as_secs` භාවිතා කරන්න:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    ///
    /// assert_eq!(5.730023852,
    ///            duration.as_secs() as f64
    ///            + duration.subsec_nanos() as f64 * 1e-9);
    /// ```
    ///
    /// [`subsec_nanos`]: Duration::subsec_nanos
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn as_secs(&self) -> u64 {
        self.secs
    }

    /// මෙම `Duration` හි භාගික කොටස සම්පූර්ණ මිලි තත්පර වලින් ලබා දෙයි.
    ///
    /// මෙම ක්‍රමය මිලි තත්පර වලින් නිරූපණය වන විට කාලසීමාවේ දිග ** ලබා නොදේ.
    /// ආපසු ලබා දුන් අංකය සෑම විටම තත්පරයක භාගික කොටසක් නිරූපණය කරයි (එනම් එය දහසකට වඩා අඩුය).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5432);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_millis(), 432);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_millis(&self) -> u32 {
        self.nanos / NANOS_PER_MILLI
    }

    /// මෙම `Duration` හි භාගික කොටස සම්පූර්ණ මයික්‍රෝ තත්පර වලින් ලබා දෙයි.
    ///
    /// මෙම ක්‍රමය මයික්‍රෝ තත්පර වලින් නිරූපණය වන විට කාලසීමාවේ දිග ** ලබා නොදේ.
    /// ආපසු ලබා දුන් අංකය සෑම විටම තත්පරයක භාගික කොටසක් නියෝජනය කරයි (එනම් එය මිලියනයකට වඩා අඩුය).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_234_567);
    /// assert_eq!(duration.as_secs(), 1);
    /// assert_eq!(duration.subsec_micros(), 234_567);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_micros(&self) -> u32 {
        self.nanos / NANOS_PER_MICRO
    }

    /// මෙම `Duration` හි භාගික කොටස නැනෝ තත්පර වලින් ලබා දෙයි.
    ///
    /// මෙම ක්‍රමය නැනෝ තත්පර වලින් නිරූපණය වන විට කාලසීමාවේ දිග ** ලබා නොදේ.
    /// ආපසු ලබා දුන් අංකය සෑම විටම තත්පරයක භාගික කොටසක් නියෝජනය කරයි (එනම් එය බිලියනයකට වඩා අඩුය).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5010);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_nanos(), 10_000_000);
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn subsec_nanos(&self) -> u32 {
        self.nanos
    }

    /// මෙම `Duration` හි අඩංගු මුළු මිලි තත්පර ගණන ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_millis(), 5730);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_millis(&self) -> u128 {
        self.secs as u128 * MILLIS_PER_SEC as u128 + (self.nanos / NANOS_PER_MILLI) as u128
    }

    /// මෙම `Duration` හි අඩංගු මුළු මයික්‍රෝ තත්පර ගණන ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_micros(), 5730023);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_micros(&self) -> u128 {
        self.secs as u128 * MICROS_PER_SEC as u128 + (self.nanos / NANOS_PER_MICRO) as u128
    }

    /// මෙම `Duration` හි අඩංගු නැනෝ තත්පර ගණන ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_nanos(), 5730023852);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_nanos(&self) -> u128 {
        self.secs as u128 * NANOS_PER_SEC as u128 + self.nanos as u128
    }

    /// පරීක්ෂා කරන ලද `Duration` එකතු කිරීම.
    /// `self + other` ගණනය කරයි, පිටාර ගැලීමක් සිදුවුවහොත් [`None`] ආපසු එයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).checked_add(Duration::new(0, 1)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(1, 0).checked_add(Duration::new(u64::MAX, 0)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_add(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_add(rhs.secs) {
            let mut nanos = self.nanos + rhs.nanos;
            if nanos >= NANOS_PER_SEC {
                nanos -= NANOS_PER_SEC;
                if let Some(new_secs) = secs.checked_add(1) {
                    secs = new_secs;
                } else {
                    return None;
                }
            }
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// `Duration` එකතු කිරීම සංතෘප්ත කිරීම.
    /// `self + other` ගණනය කරයි, පිටාර ගැලීමක් සිදුවුවහොත් [`Duration::MAX`] ආපසු එයි.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).saturating_add(Duration::new(0, 1)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(1, 0).saturating_add(Duration::new(u64::MAX, 0)), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_add(self, rhs: Duration) -> Duration {
        match self.checked_add(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// පරීක්ෂා කරන ලද `Duration` අඩු කිරීම.
    /// `self - other` ගණනය කරයි, ප්‍රති result ලය negative ණාත්මක නම් හෝ පිටාර ගැලීමක් සිදුවී ඇත්නම් [`None`] ආපසු එයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).checked_sub(Duration::new(0, 0)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(0, 0).checked_sub(Duration::new(0, 1)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_sub(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_sub(rhs.secs) {
            let nanos = if self.nanos >= rhs.nanos {
                self.nanos - rhs.nanos
            } else {
                if let Some(sub_secs) = secs.checked_sub(1) {
                    secs = sub_secs;
                    self.nanos + NANOS_PER_SEC - rhs.nanos
                } else {
                    return None;
                }
            };
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// `Duration` අඩු කිරීම සංතෘප්ත කිරීම.
    /// `self - other` ගණනය කරයි, ප්‍රති result ලය negative ණාත්මක නම් හෝ පිටාර ගැලීමක් සිදුවී ඇත්නම් [`Duration::ZERO`] ආපසු එයි.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).saturating_sub(Duration::new(0, 0)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(0, 0).saturating_sub(Duration::new(0, 1)), Duration::ZERO);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_sub(self, rhs: Duration) -> Duration {
        match self.checked_sub(rhs) {
            Some(res) => res,
            None => Duration::ZERO,
        }
    }

    /// පරීක්ෂා කරන ලද `Duration` ගුණ කිරීම.
    /// `self * other` ගණනය කරයි, පිටාර ගැලීමක් සිදුවුවහොත් [`None`] ආපසු එයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).checked_mul(2), Some(Duration::new(1, 2)));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).checked_mul(2), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_mul(self, rhs: u32) -> Option<Duration> {
        // නැනෝ තත්පර u64 ලෙස ගුණ කරන්න, එයට එය පිටාර ගැලිය නොහැක.
        let total_nanos = self.nanos as u64 * rhs as u64;
        let extra_secs = total_nanos / (NANOS_PER_SEC as u64);
        let nanos = (total_nanos % (NANOS_PER_SEC as u64)) as u32;
        if let Some(s) = self.secs.checked_mul(rhs as u64) {
            if let Some(secs) = s.checked_add(extra_secs) {
                debug_assert!(nanos < NANOS_PER_SEC);
                return Some(Duration { secs, nanos });
            }
        }
        None
    }

    /// `Duration` ගුණ කිරීම සංතෘප්ත කිරීම.
    /// `self * other` ගණනය කරයි, පිටාර ගැලීමක් සිදුවුවහොත් [`Duration::MAX`] ආපසු එයි.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).saturating_mul(2), Duration::new(1, 2));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).saturating_mul(2), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_mul(self, rhs: u32) -> Duration {
        match self.checked_mul(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// පරීක්ෂා කරන ලද `Duration` අංශය.
    /// `self / other` ගණනය කරයි, `other == 0` නම් [`None`] ආපසු එයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(2, 0).checked_div(2), Some(Duration::new(1, 0)));
    /// assert_eq!(Duration::new(1, 0).checked_div(2), Some(Duration::new(0, 500_000_000)));
    /// assert_eq!(Duration::new(2, 0).checked_div(0), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_div(self, rhs: u32) -> Option<Duration> {
        if rhs != 0 {
            let secs = self.secs / (rhs as u64);
            let carry = self.secs - secs * (rhs as u64);
            let extra_nanos = carry * (NANOS_PER_SEC as u64) / (rhs as u64);
            let nanos = self.nanos / rhs + (extra_nanos as u32);
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// මෙම `Duration` හි අඩංගු තත්පර ගණන `f64` ලෙස ලබා දෙයි.
    /// ආපසු ලබා දුන් අගයට කාල පරිච්ඡේදයේ භාගික (nanosecond) කොටස ඇතුළත් වේ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f64(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f64(&self) -> f64 {
        (self.secs as f64) + (self.nanos as f64) / (NANOS_PER_SEC as f64)
    }

    /// මෙම `Duration` හි අඩංගු තත්පර ගණන `f32` ලෙස ලබා දෙයි.
    /// ආපසු ලබා දුන් අගයට කාල පරිච්ඡේදයේ භාගික (nanosecond) කොටස ඇතුළත් වේ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f32(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f32(&self) -> f32 {
        (self.secs as f32) + (self.nanos as f32) / (NANOS_PER_SEC as f32)
    }

    /// `f64` ලෙස නිරූපිත තත්පර ගණනෙන් නව `Duration` සාදයි.
    ///
    /// # Panics
    /// `secs` සීමිත, negative ණ හෝ `Duration` පිටාර ගැලීමක් නොමැති නම් මෙම ඉදිකිරීම්කරු panic කරනු ඇත.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f64(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f64(secs: f64) -> Duration {
        const MAX_NANOS_F64: f64 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f64;
        let nanos = secs * (NANOS_PER_SEC as f64);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F64 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// `f32` ලෙස නිරූපිත තත්පර ගණනෙන් නව `Duration` සාදයි.
    ///
    /// # Panics
    /// `secs` සීමිත, negative ණ හෝ `Duration` පිටාර ගැලීමක් නොමැති නම් මෙම ඉදිකිරීම්කරු panic කරනු ඇත.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f32(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f32(secs: f32) -> Duration {
        const MAX_NANOS_F32: f32 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f32;
        let nanos = secs * (NANOS_PER_SEC as f32);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F32 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// X001 මගින් `Duration` ගුණ කිරීම.
    /// # Panics
    /// ප්‍රති result ලය සීමිත, negative ණ හෝ `Duration` පිටාර ගැලීමක් නොමැති නම් මෙම ක්‍රමය panic වනු ඇත.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.mul_f64(3.14), Duration::new(8, 478_000_000));
    /// assert_eq!(dur.mul_f64(3.14e5), Duration::new(847_800, 0));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(rhs * self.as_secs_f64())
    }

    /// X001 මගින් `Duration` ගුණ කිරීම.
    /// # Panics
    /// ප්‍රති result ලය සීමිත, negative ණ හෝ `Duration` පිටාර ගැලීමක් නොමැති නම් මෙම ක්‍රමය panic වනු ඇත.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // වටකුරු දෝෂ හේතුවෙන් ප්‍රති result ලය 8.478 සහ 847800.0 වලට වඩා තරමක් වෙනස් බව සලකන්න
    /////
    /// assert_eq!(dur.mul_f32(3.14), Duration::new(8, 478_000_640));
    /// assert_eq!(dur.mul_f32(3.14e5), Duration::new(847799, 969_120_256));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(rhs * self.as_secs_f32())
    }

    /// `Duration` `f64` මගින් බෙදන්න.
    /// # Panics
    /// ප්‍රති result ලය සීමිත, negative ණ හෝ `Duration` පිටාර ගැලීමක් නොමැති නම් මෙම ක්‍රමය panic වනු ඇත.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.div_f64(3.14), Duration::new(0, 859_872_611));
    /// // කප්පාදු කිරීම වටකුරු නොව භාවිතා කරන බව සලකන්න
    /// assert_eq!(dur.div_f64(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(self.as_secs_f64() / rhs)
    }

    /// `Duration` `f32` මගින් බෙදන්න.
    /// # Panics
    /// ප්‍රති result ලය සීමිත, negative ණ හෝ `Duration` පිටාර ගැලීමක් නොමැති නම් මෙම ක්‍රමය panic වනු ඇත.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // වටකුරු දෝෂ හේතුවෙන් ප්‍රති result ලය 0.859_872_611 ට වඩා තරමක් වෙනස් බව සලකන්න
    /////
    /// assert_eq!(dur.div_f32(3.14), Duration::new(0, 859_872_576));
    /// // කප්පාදු කිරීම වටකුරු නොව භාවිතා කරන බව සලකන්න
    /// assert_eq!(dur.div_f32(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(self.as_secs_f32() / rhs)
    }

    /// `Duration` `Duration` මගින් බෙදන්න සහ `f64` ආපසු එවන්න.
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f64(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f64(self, rhs: Duration) -> f64 {
        self.as_secs_f64() / rhs.as_secs_f64()
    }

    /// `Duration` `Duration` මගින් බෙදන්න සහ `f32` ආපසු එවන්න.
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f32(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f32(self, rhs: Duration) -> f32 {
        self.as_secs_f32() / rhs.as_secs_f32()
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Add for Duration {
    type Output = Duration;

    fn add(self, rhs: Duration) -> Duration {
        self.checked_add(rhs).expect("overflow when adding durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl AddAssign for Duration {
    fn add_assign(&mut self, rhs: Duration) {
        *self = *self + rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Sub for Duration {
    type Output = Duration;

    fn sub(self, rhs: Duration) -> Duration {
        self.checked_sub(rhs).expect("overflow when subtracting durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl SubAssign for Duration {
    fn sub_assign(&mut self, rhs: Duration) {
        *self = *self - rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Mul<u32> for Duration {
    type Output = Duration;

    fn mul(self, rhs: u32) -> Duration {
        self.checked_mul(rhs).expect("overflow when multiplying duration by scalar")
    }
}

#[stable(feature = "symmetric_u32_duration_mul", since = "1.31.0")]
impl Mul<Duration> for u32 {
    type Output = Duration;

    fn mul(self, rhs: Duration) -> Duration {
        rhs * self
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl MulAssign<u32> for Duration {
    fn mul_assign(&mut self, rhs: u32) {
        *self = *self * rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Div<u32> for Duration {
    type Output = Duration;

    fn div(self, rhs: u32) -> Duration {
        self.checked_div(rhs).expect("divide by zero error when dividing duration by scalar")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl DivAssign<u32> for Duration {
    fn div_assign(&mut self, rhs: u32) {
        *self = *self / rhs;
    }
}

macro_rules! sum_durations {
    ($iter:expr) => {{
        let mut total_secs: u64 = 0;
        let mut total_nanos: u64 = 0;

        for entry in $iter {
            total_secs =
                total_secs.checked_add(entry.secs).expect("overflow in iter::sum over durations");
            total_nanos = match total_nanos.checked_add(entry.nanos as u64) {
                Some(n) => n,
                None => {
                    total_secs = total_secs
                        .checked_add(total_nanos / NANOS_PER_SEC as u64)
                        .expect("overflow in iter::sum over durations");
                    (total_nanos % NANOS_PER_SEC as u64) + entry.nanos as u64
                }
            };
        }
        total_secs = total_secs
            .checked_add(total_nanos / NANOS_PER_SEC as u64)
            .expect("overflow in iter::sum over durations");
        total_nanos = total_nanos % NANOS_PER_SEC as u64;
        Duration { secs: total_secs, nanos: total_nanos as u32 }
    }};
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl Sum for Duration {
    fn sum<I: Iterator<Item = Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl<'a> Sum<&'a Duration> for Duration {
    fn sum<I: Iterator<Item = &'a Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_debug_impl", since = "1.27.0")]
impl fmt::Debug for Duration {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        /// දශම අංකනයෙහි පාවෙන ලක්ෂ්‍ය අංකයක් ආකෘතිකරණය කරයි.
        ///
        /// අංකය `integer_part` සහ භාගික කොටසක් ලෙස දක්වා ඇත.
        /// භාගික කොටසෙහි වටිනාකම `fractional_part / divisor` වේ.
        /// එබැවින් `integer_part` =3, `fractional_part` =12 සහ `divisor` =100 නිරූපණය කරන්නේ `3.012` අංකයයි.
        /// පසුපස ශුන්‍යයන් මඟ හැරී ඇත.
        ///
        /// `divisor` 100_000_000 ට වඩා වැඩි නොවිය යුතුය.
        /// එය ද 10 ක බලයක් විය යුතුය, අනෙක් සියල්ල තේරුමක් නැත.
        /// `fractional_part` `10 * divisor` ට වඩා අඩු විය යුතුය!
        fn fmt_decimal(
            f: &mut fmt::Formatter<'_>,
            mut integer_part: u64,
            mut fractional_part: u32,
            mut divisor: u32,
        ) -> fmt::Result {
            // භාගික කොටස තාවකාලික බෆරයකට සංකේතනය කරන්න.
            // බෆරයට අවශ්‍ය වන්නේ මූලද්‍රව්‍ය 9 ක් පමණි, මන්ද `fractional_part` 10 ^ 9 ට වඩා කුඩා විය යුතුය.
            //
            // පහත කේතය සරල කිරීම සඳහා බෆරය '0' ඉලක්කම් වලින් පුරවා ඇත.
            let mut buf = [b'0'; 9];

            // ඊළඟ ඉලක්කම් මෙම ස්ථානයේ ලියා ඇත
            let mut pos = 0;

            // ශුන්‍ය නොවන ඉලක්කම් ඉතිරිව තිබියදී අපි බෆරයට ඉලක්කම් ලිවීම දිගටම කරගෙන යන අතර අපි තවමත් ප්‍රමාණවත් සංඛ්‍යා ලියා නැත.
            //
            while fractional_part > 0 && pos < f.precision().unwrap_or(9) {
                // බෆරයට නව ඉලක්කම් ලියන්න
                buf[pos] = b'0' + (fractional_part / divisor) as u8;

                fractional_part %= divisor;
                divisor /= 10;
                pos += 1;
            }

            // නිරවද්‍යතාව <9 නියම කර ඇත්නම්, බෆරයට ලියා නොමැති ශුන්‍ය නොවන ඉලක්කම් කිහිපයක් ඉතිරිව තිබිය හැක.
            // එවැනි අවස්ථාවක සාමාන්‍ය පාවෙන ලක්ෂ්‍ය අංක මුද්‍රණය කිරීමේ අර්ථ නිරූපණයට ගැලපෙන පරිදි අපි වටකුරු කිරීම සිදු කළ යුතුය.
            // කෙසේ වෙතත්, අප කළ යුත්තේ වැඩ කරන විට පමණි.
            // මෙය සිදු වන්නේ ඉතිරි අයගේ පළමු ඉලක්කම්>=5 නම්.
            //
            //
            if fractional_part > 0 && fractional_part >= divisor * 5 {
                // බෆරයේ අඩංගු අංකය වට කරන්න.
                // අපි බෆරය පසුපසට ගොස් රැගෙන යාම පිළිබඳ තොරතුරු තබා ගන්නෙමු.
                let mut rev_pos = pos;
                let mut carry = true;
                while carry && rev_pos > 0 {
                    rev_pos -= 1;

                    // බෆරයේ ඉලක්කම් '9' නොවේ නම්, අපට එය වැඩි කළ යුතු අතර එය නැවැත්විය හැකිය (අපට තවදුරටත් රැගෙන යා නොහැකි බැවින්).
                    // එසේ නොමැතිනම්, අපි එය '0' (overflow) ලෙස සකසා ඉදිරියට යන්නෙමු.
                    //
                    //
                    if buf[rev_pos] < b'9' {
                        buf[rev_pos] += 1;
                        carry = false;
                    } else {
                        buf[rev_pos] = b'0';
                    }
                }

                // අප සතුව තවමත් කැරි බිට් කට්ටලය තිබේ නම්, එයින් අදහස් වන්නේ අපි මුළු බෆරයම 0 ට සකසා ඇති අතර පූර්ණ සංඛ්‍යා කොටස වැඩි කළ යුතු බවයි.
                //
                //
                if carry {
                    integer_part += 1;
                }
            }

            // බෆරයේ අවසානය තීරණය කරන්න: නිරවද්‍යතාවය සකසා ඇත්නම්, අපි බෆරයේ සිට ඉලක්කම් තරම් ප්‍රමාණයක් භාවිතා කරමු (9 ට ආවරණය කර ඇත).
            // එය සකසා නොමැති නම්, අපි භාවිතා කරන්නේ අන්තිම ශුන්‍ය නොවන එක දක්වා පමණි.
            //
            let end = f.precision().map(|p| crate::cmp::min(p, 9)).unwrap_or(pos);

            // අප එක භාගික සංඛ්‍යාවක් විමෝචනය කර නොමැති අතර නිරවද්‍යතාවය ශුන්‍ය නොවන අගයකට සකසා නොමැති නම්, අපි දශම ලක්ෂ්‍යය මුද්‍රණය නොකරමු.
            //
            if end == 0 {
                write!(f, "{}", integer_part)
            } else {
                // ආරක්ෂාව: අපි ලියන්නේ ASCII ඉලක්කම් බෆරයට පමණි
                // '0' සමඟ ආරම්භ කර ඇති බැවින් වලංගු UTF8 අඩංගු වේ.
                let s = unsafe { crate::str::from_utf8_unchecked(&buf[..end]) };

                // පරිශීලකයා නිරවද්‍යතාව> 9 ඉල්ලා සිටියහොත්, අපි අවසානයේ පෑඩ් 0 ය.
                let w = f.precision().unwrap_or(pos);
                write!(f, "{}.{:0<width$}", integer_part, s, width = w)
            }
        }

        // ඉල්ලුවහොත් ප්‍රමුඛ '+' ලකුණ මුද්‍රණය කරන්න
        if f.sign_plus() {
            write!(f, "+")?;
        }

        if self.secs > 0 {
            fmt_decimal(f, self.secs, self.nanos, NANOS_PER_SEC / 10)?;
            f.write_str("s")
        } else if self.nanos >= NANOS_PER_MILLI {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MILLI) as u64,
                self.nanos % NANOS_PER_MILLI,
                NANOS_PER_MILLI / 10,
            )?;
            f.write_str("ms")
        } else if self.nanos >= NANOS_PER_MICRO {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MICRO) as u64,
                self.nanos % NANOS_PER_MICRO,
                NANOS_PER_MICRO / 10,
            )?;
            f.write_str("µs")
        } else {
            fmt_decimal(f, self.nanos as u64, 0, 1)?;
            f.write_str("ns")
        }
    }
}