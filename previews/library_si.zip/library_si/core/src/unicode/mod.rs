#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// `char` සහ `str` ක්‍රම වල යුනිකෝඩ් කොටස් පදනම් වූ [Unicode](http://www.unicode.org/) අනුවාදය.
///
/// යුනිකෝඩ් හි නව සංස්කරණ නිතිපතා නිකුත් කරන අතර පසුව යුනිකෝඩ් මත පදනම්ව සම්මත පුස්තකාලයේ ඇති සියලුම ක්‍රම යාවත්කාලීන වේ.
/// එබැවින් සමහර `char` සහ `str` ක්‍රම වල හැසිරීම සහ මෙම නියතයේ වටිනාකම කාලයත් සමඟ වෙනස් වේ.
/// මෙය * බිඳෙන වෙනසක් ලෙස නොසැලකේ.
///
/// අනුවාද අංකනය කිරීමේ ක්‍රමය [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) හි විස්තර කර ඇත.
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// Liballoc හි භාවිතය සඳහා, libstd හි නැවත අපනයනය නොකෙරේ.
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;