//! අර්ථවත් පෙරනිමි අගයන් ඇති වර්ග සඳහා `Default` trait.

#![stable(feature = "rust1", since = "1.0.0")]

/// වර්ගයකට ප්‍රයෝජනවත් පෙරනිමි අගයක් ලබා දීම සඳහා trait.
///
/// සමහර විට, ඔබට යම් ආකාරයක පෙරනිමි අගයක් වෙත ආපසු යාමට අවශ්‍ය වන අතර, එය කුමක් දැයි විශේෂයෙන් නොසලකන්න.
/// මෙය බොහෝ විට විකල්ප සමූහයක් අර්ථ දක්වන `struct`s සමඟ පැමිණේ:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// සමහර පෙරනිමි අගයන් අපට අර්ථ දැක්විය හැක්කේ කෙසේද?ඔබට `Default` භාවිතා කළ හැකිය:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// දැන්, ඔබට සියලු පෙරනිමි අගයන් ලැබේ.Rust විවිධ ප්‍රාථමික වර්ග සඳහා `Default` ක්‍රියාත්මක කරයි.
///
/// ඔබට විශේෂිත විකල්පයක් අභිබවා යාමට අවශ්‍ය නම්, නමුත් අනෙක් පෙරනිමි තවමත් රඳවා ගන්න:
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// සියලු වර්ගවල ක්ෂේත්‍ර `Default` ක්‍රියාත්මක කරන්නේ නම් මෙම trait `#[derive]` සමඟ භාවිතා කළ හැකිය.
/// `ව්‍යුත්පන්න` විට, එය එක් එක් ක්ෂේත්‍රයේ වර්ගය සඳහා පෙරනිමි අගය භාවිතා කරයි.
///
/// ## `Default` ක්‍රියාත්මක කරන්නේ කෙසේද?
///
/// පෙරනිමිය විය යුතු ඔබේ වර්ගයේ වටිනාකම ආපසු ලබා දෙන `default()` ක්‍රමය සඳහා ක්‍රියාත්මක කිරීමක් සපයන්න:
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// වර්ගයක් සඳහා "default value" ලබා දෙයි.
    ///
    /// පෙරනිමි අගයන් බොහෝ විට යම් ආකාරයක ආරම්භක අගයක්, අනන්‍යතා අගයක් හෝ පෙරනිමියක් ලෙස අර්ථවත් විය හැකි වෙනත් ඕනෑම දෙයක් වේ.
    ///
    ///
    /// # Examples
    ///
    /// සාදන ලද පෙරනිමි අගයන් භාවිතා කිරීම:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// ඔබේම දෑ සෑදීම:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// `Default` trait අනුව වර්ගයක පෙරනිමි අගය නැවත ලබා දෙන්න.
///
/// ආපසු පැමිණීමේ වර්ගය සන්දර්භයෙන් අනුමාන කෙරේ;මෙය `Default::default()` ට සමාන නමුත් ටයිප් කිරීමට කෙටි වේ.
///
/// උදාහරණ වශයෙන්:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// trait `Default` හි ආවේගයක් ජනනය කරන ව්‍යුත්පන්න සාර්ව.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }