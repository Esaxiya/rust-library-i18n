Panics වත්මන් නූල්.

මෙය වැඩසටහනක් වහාම අවසන් කිරීමට සහ වැඩසටහන අමතන්නාට ප්‍රතිපෝෂණය ලබා දීමට ඉඩ දෙයි.
`panic!` වැඩසටහනක් සොයාගත නොහැකි තත්වයට පැමිණි විට භාවිතා කළ යුතුය.

නිදර්ශන කේතයේ සහ පරීක්ෂණ වලදී කොන්දේසි තහවුරු කිරීමට හොඳම ක්‍රමය මෙම සාර්ව ය.
`panic!` [`Option`][ounwrap] සහ [`Result`][runwrap] එනමම් දෙකෙහිම `unwrap` ක්‍රමය සමඟ සමීපව බැඳී ඇත.
ක්‍රියාත්මක කිරීම් දෙකම `panic!` අමතන්නේ ඒවා [`None`] හෝ [`Err`] ප්‍රභේදවලට සකසා ඇති විටය.

`panic!()` භාවිතා කරන විට ඔබට [`format!`] සින්ටැක්ස් භාවිතයෙන් ගොඩනගා ඇති නූල් ගෙවීමක් නියම කළ හැකිය.
Panic ඇමතුම් Rust නූල් තුළට එන්නත් කිරීමේදී එම ගෙවීම භාවිතා වන අතර එමඟින් නූල් සම්පූර්ණයෙන්ම panic වෙත යොමු වේ.

සුපුරුදු `std` hook හි හැසිරීම, එනම්
panic ආයාචනය කිරීමෙන් පසු කෙලින්ම ක්‍රියාත්මක වන කේතය නම්, `panic!()` ඇමතුමේ file/line/column තොරතුරු සමඟ `stderr` වෙත පණිවිඩ පැටවීම මුද්‍රණය කිරීමයි.

ඔබට [`std::panic::set_hook()`] භාවිතා කරමින් panic hook අභිබවා යා හැකිය.
hook ඇතුළත panic එකක් `&dyn Any + Send` ලෙස ප්‍රවේශ විය හැකි අතර, එය සාමාන්‍ය `panic!()` ආයාචනා සඳහා `&str` හෝ `String` අඩංගු වේ.
වෙනත් වර්ගයක අගය සහිත panic වෙත, [`panic_any`] භාවිතා කළ හැකිය.

[`Result`] `panic!` මැක්‍රෝ භාවිතා කරනවාට වඩා දෝෂ වලින් ගොඩ ඒමට enum බොහෝ විට වඩා හොඳ විසඳුමකි.
බාහිර ප්‍රභවයන් වැනි වැරදි අගයන් භාවිතා කිරීමෙන් වැළකී සිටීමට මෙම සාර්ව භාවිතා කළ යුතුය.
දෝෂ හැසිරවීම පිළිබඳ සවිස්තර තොරතුරු [book] හි ඇත.

සම්පාදනය කිරීමේදී දෝෂ මතු කිරීම සඳහා සාර්ව [`compile_error!`] ද බලන්න.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# වත්මන් ක්‍රියාත්මක කිරීම

panics හි ප්‍රධාන නූල නම් එය ඔබගේ සියලු නූල් අවසන් කර `101` කේතය සමඟ ඔබේ වැඩසටහන අවසන් කරනු ඇත.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





