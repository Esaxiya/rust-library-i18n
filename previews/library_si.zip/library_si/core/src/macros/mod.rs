#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // අමතන්නාගේ සංස්කරණය අනුව `$crate::panic::panic_2015` හෝ `$crate::panic::panic_2021` දක්වා පුළුල් වේ.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// ප්‍රකාශන දෙකක් එකිනෙකට සමාන බව ප්‍රකාශ කරයි ([`PartialEq`] භාවිතා කරමින්).
///
/// panic හි, මෙම සාර්ව ප්‍රකාශනවල අගයන් ඒවායේ දෝශ නිරාකරණ නිරූපණයන් සමඟ මුද්‍රණය කරනු ඇත.
///
///
/// [`assert!`] මෙන්, මෙම සාර්වයට දෙවන ආකාරයක් ඇත, එහිදී අභිරුචි panic පණිවිඩයක් ලබා දිය හැකිය.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // පහත දැක්වෙන ප්‍රතිසංස්කරණ හිතාමතා ය.
                    // ඒවා නොමැතිව, අගයන් සංසන්දනය කිරීමට පෙර පවා ණය ගැනීම සඳහා තොග කට්ටලය ආරම්භ කරනු ලබන අතර එය සැලකිය යුතු ලෙස මන්දගාමී වීමට හේතු වේ.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // පහත දැක්වෙන ප්‍රතිසංස්කරණ හිතාමතා ය.
                    // ඒවා නොමැතිව, අගයන් සංසන්දනය කිරීමට පෙර පවා ණය ගැනීම සඳහා තොග කට්ටලය ආරම්භ කරනු ලබන අතර එය සැලකිය යුතු ලෙස මන්දගාමී වීමට හේතු වේ.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// ප්‍රකාශන දෙකක් එකිනෙකට සමාන නොවන බව ප්‍රකාශ කරයි ([`PartialEq`] භාවිතා කරමින්).
///
/// panic හි, මෙම සාර්ව ප්‍රකාශනවල අගයන් ඒවායේ දෝශ නිරාකරණ නිරූපණයන් සමඟ මුද්‍රණය කරනු ඇත.
///
///
/// [`assert!`] මෙන්, මෙම සාර්වයට දෙවන ආකාරයක් ඇත, එහිදී අභිරුචි panic පණිවිඩයක් ලබා දිය හැකිය.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // පහත දැක්වෙන ප්‍රතිසංස්කරණ හිතාමතා ය.
                    // ඒවා නොමැතිව, අගයන් සංසන්දනය කිරීමට පෙර පවා ණය ගැනීම සඳහා තොග කට්ටලය ආරම්භ කරනු ලබන අතර එය සැලකිය යුතු ලෙස මන්දගාමී වීමට හේතු වේ.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // පහත දැක්වෙන ප්‍රතිසංස්කරණ හිතාමතා ය.
                    // ඒවා නොමැතිව, අගයන් සංසන්දනය කිරීමට පෙර පවා ණය ගැනීම සඳහා තොග කට්ටලය ආරම්භ කරනු ලබන අතර එය සැලකිය යුතු ලෙස මන්දගාමී වීමට හේතු වේ.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// ධාවන වේලාවේදී බූලියන් ප්‍රකාශනයක් `true` බව ප්‍රකාශ කරයි.
///
/// සපයන ලද ප්‍රකාශනය ක්‍රියාත්මක වන වේලාවේදී `true` වෙත තක්සේරු කළ නොහැකි නම් මෙය [`panic!`] මැක්‍රෝව ක්‍රියාත්මක කරයි.
///
/// [`assert!`] මෙන්ම, මෙම සාර්වයටද දෙවන අනුවාදයක් ඇත, එහිදී අභිරුචි panic පණිවිඩයක් ලබා දිය හැකිය.
///
/// # Uses
///
/// [`assert!`] මෙන් නොව, `debug_assert!` ප්‍රකාශ සක්‍රීය කර ඇත්තේ පෙරනිමියෙන් ප්‍රශස්තිකරණය නොකළ ගොඩනැගිලිවල පමණි.
/// `-C debug-assertions` සම්පාදකයාට ලබා නොදුන්නේ නම් ප්‍රශස්තිකරණය කිරීම `debug_assert!` ප්‍රකාශ ක්‍රියාත්මක නොකරනු ඇත.
/// මෙය `debug_assert!` චෙක්පත් සඳහා ප්‍රයෝජනවත් වන අතර එය නිකුතුවක් සඳහා ඉදිරිපත් කිරීමට තරම් මිල අධික වන නමුත් සංවර්ධනයේදී ප්‍රයෝජනවත් විය හැකිය.
/// `debug_assert!` පුළුල් කිරීමේ ප්‍රති result ලය සෑම විටම පරීක්ෂා කර ඇත.
///
/// නොගැලපෙන ප්‍රකාශයක් නොගැලපෙන තත්වයක පවතින වැඩසටහනක් දිගටම පවත්වා ගෙන යාමට ඉඩ සලසයි, එය අනපේක්ෂිත ප්‍රතිවිපාක ඇති කළ හැකි නමුත් මෙය ආරක්ෂිත කේතයකින් පමණක් සිදුවන තාක් අනාරක්ෂිත බව හඳුන්වා නොදේ.
///
/// කෙසේ වෙතත්, ප්‍රකාශයන්ගේ කාර්ය සාධන පිරිවැය පොදුවේ මැනිය නොහැක.
/// මේ අනුව [`assert!`] `debug_assert!` සමඟ ප්‍රතිස්ථාපනය කිරීම දිරිමත් කරනු ලබන්නේ ගැඹුරු පැතිකඩකින් පසුව පමණක් වන අතර වඩා වැදගත් වන්නේ ආරක්ෂිත කේතයකින් පමණි!
///
/// # Examples
///
/// ```
/// // මෙම ප්‍රකාශයන් සඳහා වන panic පණිවිඩය ලබා දී ඇති ප්‍රකාශනයේ දැඩි අගයයි.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // ඉතා සරල ශ්‍රිතයක්
/// debug_assert!(some_expensive_computation());
///
/// // අභිරුචි පණිවිඩයක් සමඟ තහවුරු කරන්න
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// ප්‍රකාශන දෙකක් එකිනෙකට සමාන බව ප්‍රකාශ කරයි.
///
/// panic හි, මෙම සාර්ව ප්‍රකාශනවල අගයන් ඒවායේ දෝශ නිරාකරණ නිරූපණයන් සමඟ මුද්‍රණය කරනු ඇත.
///
/// [`assert_eq!`] මෙන් නොව, `debug_assert_eq!` ප්‍රකාශ සක්‍රීය කර ඇත්තේ පෙරනිමියෙන් ප්‍රශස්තිකරණය නොකළ ගොඩනැගිලිවල පමණි.
/// `-C debug-assertions` සම්පාදකයාට ලබා නොදුන්නේ නම් ප්‍රශස්තිකරණය කිරීම `debug_assert_eq!` ප්‍රකාශ ක්‍රියාත්මක නොකරනු ඇත.
/// මෙය `debug_assert_eq!` චෙක්පත් සඳහා ප්‍රයෝජනවත් වන අතර එය නිකුතුවක් සඳහා ඉදිරිපත් කිරීමට තරම් මිල අධික වන නමුත් සංවර්ධනයේදී ප්‍රයෝජනවත් විය හැකිය.
///
/// `debug_assert_eq!` පුළුල් කිරීමේ ප්‍රති result ලය සෑම විටම පරීක්ෂා කර ඇත.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// ප්‍රකාශන දෙකක් එකිනෙකට සමාන නොවන බව ප්‍රකාශ කරයි.
///
/// panic හි, මෙම සාර්ව ප්‍රකාශනවල අගයන් ඒවායේ දෝශ නිරාකරණ නිරූපණයන් සමඟ මුද්‍රණය කරනු ඇත.
///
/// [`assert_ne!`] මෙන් නොව, `debug_assert_ne!` ප්‍රකාශ සක්‍රීය කර ඇත්තේ පෙරනිමියෙන් ප්‍රශස්තිකරණය නොකළ ගොඩනැගිලිවල පමණි.
/// `-C debug-assertions` සම්පාදකයාට ලබා නොදුන්නේ නම් ප්‍රශස්තිකරණය කිරීම `debug_assert_ne!` ප්‍රකාශ ක්‍රියාත්මක නොකරනු ඇත.
/// මෙය `debug_assert_ne!` චෙක්පත් සඳහා ප්‍රයෝජනවත් වන අතර එය නිකුතුවක් සඳහා ඉදිරිපත් කිරීමට තරම් මිල අධික වන නමුත් සංවර්ධනයේදී ප්‍රයෝජනවත් විය හැකිය.
///
/// `debug_assert_ne!` පුළුල් කිරීමේ ප්‍රති result ලය සෑම විටම පරීක්ෂා කර ඇත.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// දී ඇති ප්‍රකාශනය දී ඇති ඕනෑම රටාවකට ගැලපේද යන්න ලබා දෙයි.
///
/// `match` ප්‍රකාශනයක දී මෙන්, රටාව විකල්ප වශයෙන් `if` අනුගමනය කළ හැකි අතර රටාවට බැඳී ඇති නම් වලට ප්‍රවේශය ඇති ආරක්ෂක ප්‍රකාශනයකි.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// ප්‍රති result ලයක් ලිවීම හෝ එහි දෝෂය ප්‍රචාරය කිරීම.
///
/// `try!` වෙනුවට `?` ක්‍රියාකරු එකතු කරන ලද අතර ඒ වෙනුවට භාවිතා කළ යුතුය.
/// තවද, `try` යනු Rust 2018 හි වෙන් කර ඇති වචනයකි, එබැවින් ඔබ එය භාවිතා කළ යුතු නම්, ඔබට [raw-identifier syntax][ris] භාවිතා කිරීමට අවශ්‍ය වනු ඇත: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` දී ඇති [`Result`] සමඟ ගැලපේ.`Ok` ප්‍රභේදය සම්බන්ධයෙන් නම්, ප්‍රකාශනයට ඔතා ඇති අගයේ අගය ඇත.
///
/// `Err` ප්‍රභේදය සම්බන්ධයෙන්, එය අභ්‍යන්තර දෝෂය ලබා ගනී.`try!` පසුව `From` භාවිතා කරමින් පරිවර්තනය සිදු කරයි.
/// මෙය විශේෂිත දෝෂ සහ වඩාත් සාමාන්‍ය ඒවා අතර ස්වයංක්‍රීය පරිවර්තනයක් සපයයි.
/// එහි ප්‍රති error ලයක් ලෙස ඇති වූ දෝෂය වහාම ආපසු ලබා දෙනු ලැබේ.
///
/// මුල් ප්‍රතිලාභ නිසා, `try!` භාවිතා කළ හැක්කේ [`Result`] ආපසු ලබා දෙන ශ්‍රිතවල පමණි.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // ඉක්මණින් ආපසු පැමිණීමේ දෝෂ සඳහා වඩාත් කැමති ක්‍රමය
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // ඉක්මණින් ආපසු පැමිණීමේ දෝෂ වල පෙර ක්‍රමය
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // මෙය සමාන වේ:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// ආකෘතිගත දත්ත බෆරයකට ලියයි.
///
/// මෙම සාර්ව 'writer', ආකෘති නූලක් සහ තර්ක ලැයිස්තුවක් පිළිගනී.
/// නිශ්චිත හැඩතල අනුව තර්ක සංයුති කර ප්‍රති result ලය ලේඛකයා වෙත ලබා දෙනු ඇත.
/// ලේඛකයා `write_fmt` ක්‍රමයක් සහිත ඕනෑම වටිනාකමක් විය හැකිය;සාමාන්‍යයෙන් මෙය පැමිණෙන්නේ [`fmt::Write`] හෝ [`io::Write`] trait ක්‍රියාත්මක කිරීමෙනි.
/// `write_fmt` ක්‍රමය මඟින් ලැබෙන ඕනෑම දෙයක් සාර්ව නැවත ලබා දෙයි;සාමාන්‍යයෙන් [`fmt::Result`], හෝ [`io::Result`].
///
/// ස්ට්‍රිං සින්ටැක්ස් පිළිබඳ වැඩි විස්තර සඳහා [`std::fmt`] බලන්න.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// මොඩියුලයකට `std::fmt::Write` සහ `std::io::Write` යන දෙකම ආනයනය කළ හැකි අතර වස්තු සාමාන්‍යයෙන් දෙකම ක්‍රියාත්මක නොවන බැවින් ක්‍රියාත්මක කරන වස්තු මත `write!` අමතන්න.
///
/// කෙසේ වෙතත්, මොඩියුලය සුදුසුකම් ලත් traits ආනයනය කළ යුතුය, එබැවින් ඔවුන්ගේ නම් ගැටෙන්නේ නැත:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt භාවිතා කරයි
///     write!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt භාවිතා කරයි
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: මෙම සාර්ව `no_std` සැකසුම් වලද භාවිතා කළ හැකිය.
/// `no_std` සැකසුමක දී සංරචක ක්‍රියාත්මක කිරීමේ විස්තර සඳහා ඔබ වගකිව යුතුය.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// නව රේඛාවක් එකතු කර ආකෘතිගත දත්ත බෆරයකට ලියන්න.
///
/// සියලුම වේදිකාවල, නව රේඛාව LINE FEED අක්ෂර (`\n`/`U+000A`) පමණක් වේ (අමතර CARRIAGE RETURN (`\r`/`U+000D`) නොමැත.
///
/// වැඩි විස්තර සඳහා [`write!`] බලන්න.නූල් සින්ටැක්ස් ආකෘතිය පිළිබඳ වැඩි විස්තර සඳහා, [`std::fmt`] බලන්න.
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// මොඩියුලයකට `std::fmt::Write` සහ `std::io::Write` යන දෙකම ආනයනය කළ හැකි අතර වස්තු සාමාන්‍යයෙන් දෙකම ක්‍රියාත්මක නොවන බැවින් ක්‍රියාත්මක කරන වස්තු මත `write!` අමතන්න.
/// කෙසේ වෙතත්, මොඩියුලය සුදුසුකම් ලත් traits ආනයනය කළ යුතුය, එබැවින් ඔවුන්ගේ නම් ගැටෙන්නේ නැත:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt භාවිතා කරයි
///     writeln!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt භාවිතා කරයි
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// ළඟා විය නොහැකි කේතය දක්වයි.
///
/// සමහර කේත වෙත ළඟා විය නොහැකි බව සම්පාදකයාට නිශ්චය කළ නොහැකි ඕනෑම වේලාවක මෙය ප්‍රයෝජනවත් වේ.උදාහරණ වශයෙන්:
///
/// * ආරක්ෂක කොන්දේසි සමඟ ආයුධ ගලපන්න.
/// * ගතිකව අවසන් වන ලූප.
/// * ගතිකව අවසන් කරන අනුකාරක.
///
/// කේතය වෙත ළඟා විය නොහැකි බව තීරණය කිරීම වැරදියි නම්, වැඩසටහන වහාම [`panic!`] සමඟ අවසන් වේ.
///
/// මෙම සාර්වයේ අනාරක්ෂිත ප්‍රතිවිරුද්ධ කොටස වන්නේ [`unreachable_unchecked`] ශ්‍රිතය වන අතර එමඟින් කේතය ළඟා වුවහොත් නිර්වචනය නොකළ හැසිරීමට හේතු වේ.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// මෙය සැමවිටම [`panic!`] වනු ඇත.
///
/// # Examples
///
/// ආයුධ ගැලපීම:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // අදහස් දැක්වුවහොත් දෝෂ සම්පාදනය කරන්න
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // x/3 හි දුප්පත්ම ක්‍රියාත්මක කිරීම් වලින් එකක්
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// "not implemented" පණිවිඩයක් සමඟ කලබල වීමෙන් ක්‍රියාත්මක නොකළ කේතයක් දක්වයි.
///
/// මෙය ඔබේ කේතය ටයිප්-චෙක් කිරීමට ඉඩ දෙයි, ඔබ trait මූලාකෘතියක් හෝ ක්‍රියාත්මක කරන්නේ නම් එය ප්‍රයෝජනවත් වේ, ඒ සියල්ල භාවිතා කිරීමට ඔබ සැලසුම් නොකරන බහු ක්‍රම අවශ්‍ය වේ.
///
/// `unimplemented!` සහ [`todo!`] අතර ඇති වෙනස නම් `todo!` පසුව ක්‍රියාකාරීත්වය ක්‍රියාත්මක කිරීමේ අභිප්‍රාය ප්‍රකාශ කරන අතර පණිවිඩය "not yet implemented" වන අතර `unimplemented!` එවැනි හිමිකම් පෑමක් නොකරයි.
/// එහි පණිවිඩය "not implemented" වේ.
/// සමහර IDEs ටෝඩෝ!
///
/// # Panics
///
/// මෙය සැමවිටම [`panic!`] වනු ඇත, මන්ද `unimplemented!` යනු ස්ථාවර, විශේෂිත පණිවිඩයක් සහිත `panic!` සඳහා කෙටිමං ය.
///
/// `panic!` මෙන්, මෙම සාර්වයට අභිරුචි අගයන් පෙන්වීම සඳහා දෙවන ආකාරයක් ඇත.
///
/// # Examples
///
/// අපට trait `Foo` ඇති බව පවසන්න:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// 'MyStruct' සඳහා `Foo` ක්‍රියාත්මක කිරීමට අපට අවශ්‍යය, නමුත් කිසියම් හේතුවක් නිසා එය `bar()` ශ්‍රිතය ක්‍රියාත්මක කිරීම පමණක් අර්ථවත් කරයි.
/// `baz()` අපගේ `Foo` ක්‍රියාත්මක කිරීමේදී `qux()` තවමත් නිර්වචනය කළ යුතුව ඇත, නමුත් අපගේ කේතය සම්පාදනය කිරීමට ඉඩ දීම සඳහා ඒවායේ අර්ථ දැක්වීම් වලදී අපට `unimplemented!` භාවිතා කළ හැකිය.
///
/// ක්‍රියාත්මක නොකළ ක්‍රමවේදයන් වෙත ළඟා වුවහොත් අපගේ වැඩසටහන ක්‍රියාත්මක වීම නැවැත්වීමට අපට තවමත් අවශ්‍යය.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // `baz` a `MyStruct` සඳහා එය තේරුමක් නැති නිසා අපට මෙහි කිසිදු තර්කනයක් නොමැත.
/////
///         // මෙය "thread 'main' panicked at 'not implemented'" දර්ශනය වේ.
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // අපට මෙහි යම් තර්කනයක් තිබේ, අපට ක්‍රියාත්මක නොකළ පණිවිඩයක් එක් කළ හැකිය!අපගේ අතපසු වීම පෙන්වීමට.
///         // මෙය පෙන්වනු ඇත: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// නිම නොකළ කේතය දක්වයි.
///
/// ඔබ මූලාකෘති ගත කරන්නේ නම් සහ ඔබේ කේත යතුරු ලියනය කිරීමට බලාපොරොත්තු වන්නේ නම් මෙය ප්‍රයෝජනවත් වේ.
///
/// [`unimplemented!`] සහ `todo!` අතර ඇති වෙනස නම් `todo!` පසුව ක්‍රියාකාරීත්වය ක්‍රියාත්මක කිරීමේ අභිප්‍රාය ප්‍රකාශ කරන අතර පණිවිඩය "not yet implemented" වන අතර `unimplemented!` එවැනි හිමිකම් පෑමක් නොකරයි.
/// එහි පණිවිඩය "not implemented" වේ.
/// සමහර IDEs ටෝඩෝ!
///
/// # Panics
///
/// මෙය සැමවිටම [`panic!`] වනු ඇත.
///
/// # Examples
///
/// සමහර ප්‍රගති කේත සඳහා උදාහරණයක් මෙන්න.අපට trait `Foo` ඇත:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// අපගේ එක් වර්ගයක `Foo` ක්‍රියාත්මක කිරීමට අපට අවශ්‍යය, නමුත් අපට අවශ්‍ය වන්නේ පළමුව `bar()` මත වැඩ කිරීමටය.අපගේ කේතය සම්පාදනය කිරීම සඳහා, අපට `baz()` ක්‍රියාත්මක කළ යුතුය, එබැවින් අපට `todo!` භාවිතා කළ හැකිය:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // ක්‍රියාත්මක කිරීම මෙතැනට යයි
///     }
///
///     fn baz(&self) {
///         // දැනට baz() ක්‍රියාත්මක කිරීම ගැන කරදර නොවෙමු
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // අපි baz() පවා භාවිතා නොකරමු, එබැවින් මෙය හොඳයි.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// සාදන ලද මැක්‍රෝස් වල අර්ථ දැක්වීම්.
///
/// සාර්ව ගුණාංග බොහොමයක් (ස්ථායිතාව, දෘශ්‍යතාව ආදිය) මෙහි ප්‍රභව කේතයෙන් ලබාගෙන ඇති අතර, පුළුල් කිරීමේ කාර්යයන් හැරුණු විට සාර්ව යෙදවුම් ප්‍රතිදානයන් බවට පරිවර්තනය කරයි, එම කාර්යයන් සම්පාදකයා විසින් සපයනු ලැබේ.
///
///
pub(crate) mod builtin {

    /// හමු වූ විට දී ඇති දෝෂ පණිවිඩය සමඟ සම්පාදනය අසමත් වීමට හේතු වේ.
    ///
    /// වැරදි තත්වයන් සඳහා වඩා හොඳ දෝෂ පණිවිඩ සැපයීම සඳහා crate විසින් කොන්දේසි සහිත සම්පාදන උපාය මාර්ගයක් භාවිතා කරන විට මෙම සාර්ව භාවිතා කළ යුතුය.
    ///
    /// එය [`panic!`] හි සම්පාදක මට්ටමේ ආකෘතියකි, නමුත් *ධාවන වේලාවට වඩා* සම්පාදනය * අතරතුර දෝෂයක් නිකුත් කරයි.
    ///
    /// # Examples
    ///
    /// එවැනි උදාහරණ දෙකක් වන්නේ මැක්‍රෝස් සහ `#[cfg]` පරිසරයන් ය.
    ///
    /// සාර්ව අවලංගු අගයන් සම්මත කළහොත් වඩා හොඳ සම්පාදක දෝෂයක් විමෝචනය කරන්න.
    /// අවසාන branch නොමැතිව, සම්පාදකයා තවමත් දෝෂයක් විමෝචනය කරයි, නමුත් දෝෂයේ පණිවිඩයේ වලංගු අගයන් දෙක සඳහන් නොවේ.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// විශේෂාංග ගණනාවකින් එකක් නොමැති නම් සම්පාදක දෝෂය විමෝචනය කරන්න.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// අනෙක් නූල් හැඩතල ගැන්වීමේ මැක්‍රෝස් සඳහා පරාමිතීන් සාදයි.
    ///
    /// සම්මත වූ සෑම අමතර තර්කයක් සඳහාම `{}` අඩංගු හැඩතල ගැන්වීමේ වචන මාලාවක් ගැනීමෙන් මෙම සාර්ව ක්‍රියා කරයි.
    /// `format_args!` ප්‍රතිදානය නූලක් ලෙස අර්ථ දැක්විය හැකි බව සහතික කිරීම සඳහා අතිරේක පරාමිතීන් සකස් කරන අතර තර්ක තනි වර්ගයකට කැනොනිකල් කරයි.
    /// [`Display`] trait ක්‍රියාත්මක කරන ඕනෑම අගයක් `format_args!` වෙත ලබා දිය හැකි අතර, ඕනෑම [`Debug`] ක්‍රියාත්මක කිරීමක් `{:?}` වෙත ආකෘතිකරණ දාමය තුළ ලබා දිය හැකිය.
    ///
    ///
    /// මෙම සාර්ව [`fmt::Arguments`] වර්ගයේ අගයක් නිපදවයි.ප්‍රයෝජනවත් නැවත හරවා යැවීම සඳහා මෙම අගය [`std::fmt`] තුළ ඇති මැක්‍රෝස් වෙත යැවිය හැකිය.
    /// අනෙකුත් සියලුම ආකෘතිකරණ මැක්‍රෝස් ([`ආකෘතිය!`], [`write!`], [`println!`], ආදිය) මේ හරහා ප්‍රොක්සි කර ඇත.
    /// `format_args!`, එහි ව්‍යුත්පන්න වූ මැක්‍රෝස් මෙන් නොව, ගොඩවල් වෙන් කිරීම වළක්වයි.
    ///
    /// පහත දැක්වෙන පරිදි `format_args!` සහ `Display` සන්දර්භය තුළ `format_args!` ආපසු ලබා දෙන [`fmt::Arguments`] අගය ඔබට භාවිතා කළ හැකිය.
    /// උදාහරණයෙන් දැක්වෙන්නේ `Debug` සහ `Display` ආකෘතිය එකම දෙයකට ය: `format_args!` හි අන්තර්සම්බන්ධිත ආකෘතිය.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// වැඩි විස්තර සඳහා, [`std::fmt`] හි ප්‍රලේඛනය බලන්න.
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// `format_args` ට සමාන නමුත් අවසානයේ නව රේඛාවක් එක් කරයි.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// සම්පාදක වේලාවේදී පරිසර විචල්‍යයක් පරීක්ෂා කරයි.
    ///
    /// මෙම සාර්ව සංයුක්ත වේලාවේ නම් කරන ලද පරිසර විචල්‍යයේ අගය දක්වා පුළුල් වන අතර එය `&'static str` වර්ගයේ ප්‍රකාශනයක් ලබා දෙයි.
    ///
    ///
    /// පරිසර විචල්‍යය නිර්වචනය කර නොමැති නම්, සම්පාදක දෝෂයක් විමෝචනය වේ.
    /// සම්පාදක දෝෂයක් විමෝචනය නොකිරීමට, ඒ වෙනුවට [`option_env!`] මැක්‍රෝ භාවිතා කරන්න.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// දෙවන පරාමිතිය ලෙස නූලක් යැවීමෙන් ඔබට දෝෂ පණිවිඩය රිසිකරණය කළ හැකිය:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// `documentation` පරිසර විචල්‍යය නිර්වචනය කර නොමැති නම්, ඔබට පහත දෝෂය ලැබෙනු ඇත:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// සම්පාදනය කරන අවස්ථාවේ දී පරිසර විචල්‍යයක් විකල්ප වශයෙන් පරීක්ෂා කරයි.
    ///
    /// සම්පාදිත වේලාවේ නම් කරන ලද පරිසර විචල්‍යය තිබේ නම්, මෙය `Option<&'static str>` වර්ගයේ ප්‍රකාශනයක් දක්වා විහිදෙන අතර එහි අගය පරිසර විචල්‍යයේ වටිනාකමෙන් `Some` වේ.
    /// පරිසර විචල්‍යය නොමැති නම්, මෙය `None` දක්වා පුළුල් වේ.
    /// මෙම වර්ගය පිළිබඳ වැඩි විස්තර සඳහා [`Option<T>`][Option] බලන්න.
    ///
    /// පරිසර විචල්‍යය තිබේද නැද්ද යන්න නොසලකා මෙම සාර්ව භාවිතා කරන විට සම්පාදක කාල දෝෂයක් කිසි විටෙකත් විමෝචනය නොවේ.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// හඳුනාගැනීම් එක් හඳුනාගැනීමක් සමඟ සංයුක්ත කරයි.
    ///
    /// මෙම සාර්ව කොමා මඟින් වෙන් කරන ලද හඳුනාගැනීම් ගණනක් ගෙන ඒවා සියල්ලම එකකට සම්බන්ධ කර ප්‍රකාශනයක් ලබා දෙමින් නව හඳුනාගැනීමක් වේ.
    /// සනීපාරක්ෂාව නිසා මෙම සාර්වයට දේශීය විචල්‍යයන් ග්‍රහණය කරගත නොහැකි වන බව සලකන්න.
    /// එසේම, සාමාන්‍ය රීතියක් ලෙස, මැක්‍රෝස් සඳහා අවසර දී ඇත්තේ අයිතමය, ප්‍රකාශය හෝ ප්‍රකාශන ස්ථානය තුළ පමණි.
    /// එයින් අදහස් වන්නේ පවතින විචල්‍යයන්, කාර්යයන් හෝ මොඩියුල ආදිය යොමු කිරීම සඳහා ඔබ මෙම සාර්ව භාවිතා කරන අතරම, ඔබට එය සමඟ නව එකක් අර්ථ දැක්විය නොහැක.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (නව, විනෝදජනක, නම) { }//මේ ආකාරයෙන් භාවිතා කළ නොහැක!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// වචනාර්ථය ස්ථිතික නූල් පෙත්තක් බවට සංයුක්ත කරයි.
    ///
    /// මෙම සාර්ව කොමා වලින් වෙන් කරන ලද සාහිත්‍යකරුවන් ගණනක් ගෙන, `&'static str` වර්ගයේ ප්‍රකාශනයක් ලබා දෙන අතර එමඟින් වමේ සිට දකුණට සමපාත වන සියලුම සාහිත්‍යකරුවන් නියෝජනය වේ.
    ///
    ///
    /// සමෝධානික වීම සඳහා පූර්ණ හා පාවෙන ලක්ෂ්‍ය වචනාර්ථය තදින් බැඳී ඇත.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// එය ආයාචනා කළ රේඛා අංකයට පුළුල් වේ.
    ///
    /// [`column!`] සහ [`file!`] සමඟ, මෙම මැක්‍රෝස් මඟින් ප්‍රභවය තුළ ඇති ස්ථානය පිළිබඳ සංවර්ධකයින් සඳහා නිදොස් කිරීමේ තොරතුරු සපයයි.
    ///
    /// පුළුල් කරන ලද ප්‍රකාශනයේ `u32` වර්ගය ඇති අතර එය 1 මත පදනම් වේ, එබැවින් සෑම ගොනුවකම පළමු පේළිය 1 දක්වාත්, දෙවන සිට 2 දක්වාත් ඇගයීමට ලක් කෙරේ.
    /// මෙය පොදු සම්පාදකයින්ගේ හෝ ජනප්‍රිය සංස්කාරකවරුන්ගේ වැරදි පණිවිඩ වලට අනුකූල වේ.
    /// ආපසු ලබා දුන් රේඛාව `line!` ආයාචනයේ රේඛාව *අවශ්‍ය නොවේ*, නමුත් `line!` මැක්‍රෝ හි ආයාචනයට තුඩු දෙන පළමු සාර්ව ආයාචනයයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// එය ආයාචනා කළ තීරු අංකයට පුළුල් වේ.
    ///
    /// [`line!`] සහ [`file!`] සමඟ, මෙම මැක්‍රෝස් මඟින් ප්‍රභවය තුළ ඇති ස්ථානය පිළිබඳ සංවර්ධකයින් සඳහා නිදොස් කිරීමේ තොරතුරු සපයයි.
    ///
    /// පුළුල් කරන ලද ප්‍රකාශනයේ `u32` වර්ගය ඇති අතර එය 1 මත පදනම් වේ, එබැවින් සෑම පේළියකම පළමු තීරුව 1 දක්වාත්, දෙවන සිට 2 දක්වාත් ඇගයීමට ලක් කෙරේ.
    /// මෙය පොදු සම්පාදකයින්ගේ හෝ ජනප්‍රිය සංස්කාරකවරුන්ගේ වැරදි පණිවිඩ වලට අනුකූල වේ.
    /// ආපසු ලබා දුන් තීරුව `column!` ආයාචනයේ රේඛාව *අවශ්‍ය නොවේ*, නමුත් `column!` මැක්‍රෝ හි ආයාචනයට තුඩු දෙන පළමු සාර්ව ආයාචනයයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// එය ආයාචනා කළ ගොනු නාමයට පුළුල් වේ.
    ///
    /// [`line!`] සහ [`column!`] සමඟ, මෙම මැක්‍රෝස් මඟින් ප්‍රභවය තුළ ඇති ස්ථානය පිළිබඳ සංවර්ධකයින් සඳහා නිදොස් කිරීමේ තොරතුරු සපයයි.
    ///
    /// පුළුල් කරන ලද ප්‍රකාශනයේ `&'static str` වර්ගය ඇත, ආපසු ලබා දුන් ගොනුව යනු `file!` මැක්‍රෝගේ ආයාචනය නොවේ, නමුත් `file!` මැක්‍රෝ හි ආයාචනයට තුඩු දෙන පළමු සාර්ව ආයාචනයයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// එහි තර්ක දැඩි කරයි.
    ///
    /// මෙම සාර්ව `&'static str` වර්ගයේ ප්‍රකාශනයක් ලබා දෙනු ඇත, එය සාර්වයට ලබා දුන් සියලුම tokens හි දැඩි කිරීම වේ.
    /// සාර්ව ආයාචනයේ වාක්‍ය ඛණ්ඩය මත කිසිදු සීමාවක් නොමැත.
    ///
    /// tokens ආදානයේ පුළුල් ප්‍රති results ල future හි වෙනස් විය හැකි බව සලකන්න.ඔබ ප්‍රතිදානය මත රඳා සිටින්නේ නම් ඔබ ප්‍රවේශම් විය යුතුය.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// UTF-8 කේතනය කළ ගොනුවක් නූලක් ලෙස ඇතුළත් වේ.
    ///
    /// ගොනුව වත්මන් ගොනුවට සාපේක්ෂව පිහිටා ඇත (මොඩියුල සොයා ගන්නා ආකාරය හා සමානව).
    /// සපයන ලද මාර්ගය සම්පාදනය කරන වේලාවේදී වේදිකාවට විශේෂිත ආකාරයකින් අර්ථ නිරූපණය කෙරේ.
    /// උදාහරණයක් ලෙස, Windows බැක්ස්ලෑෂ් අඩංගු Windows මාර්ගයක් සහිත ආයාචනයක් Unix මත නිවැරදිව සම්පාදනය නොවේ.
    ///
    ///
    /// මෙම සාර්ව ගොනුවේ අන්තර්ගතය වන `&'static str` වර්ගයේ ප්‍රකාශනයක් ලබා දෙනු ඇත.
    ///
    /// # Examples
    ///
    /// පහත සඳහන් අන්තර්ගතයන් සහිත එකම නාමාවලියෙහි ගොනු දෙකක් ඇතැයි උපකල්පනය කරන්න:
    ///
    /// ගොනුව 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// ගොනුව 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 'main.rs' සම්පාදනය කර එහි ප්‍රති b ලයක් ලෙස ද්විමය ධාවනය කිරීමෙන් "adiós" මුද්‍රණය වේ.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// බයිට් අරාවකට යොමු කිරීමක් ලෙස ගොනුවක් ඇතුළත් වේ.
    ///
    /// ගොනුව වත්මන් ගොනුවට සාපේක්ෂව පිහිටා ඇත (මොඩියුල සොයා ගන්නා ආකාරය හා සමානව).
    /// සපයන ලද මාර්ගය සම්පාදනය කරන වේලාවේදී වේදිකාවට විශේෂිත ආකාරයකින් අර්ථ නිරූපණය කෙරේ.
    /// උදාහරණයක් ලෙස, Windows බැක්ස්ලෑෂ් අඩංගු Windows මාර්ගයක් සහිත ආයාචනයක් Unix මත නිවැරදිව සම්පාදනය නොවේ.
    ///
    ///
    /// මෙම සාර්ව ගොනුවේ අන්තර්ගතය වන `&'static [u8; N]` වර්ගයේ ප්‍රකාශනයක් ලබා දෙනු ඇත.
    ///
    /// # Examples
    ///
    /// පහත සඳහන් අන්තර්ගතයන් සහිත එකම නාමාවලියෙහි ගොනු දෙකක් ඇතැයි උපකල්පනය කරන්න:
    ///
    /// ගොනුව 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// ගොනුව 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 'main.rs' සම්පාදනය කර එහි ප්‍රති b ලයක් ලෙස ද්විමය ධාවනය කිරීමෙන් "adiós" මුද්‍රණය වේ.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// වත්මන් මොඩියුල මාර්ගය නිරූපණය කරන නූලකට විහිදේ.
    ///
    /// වත්මන් මොඩියුල මාර්ගය crate root දක්වා දිවෙන මොඩියුලවල ධූරාවලිය ලෙස සිතිය හැකිය.
    /// ආපසු එන මාර්ගයේ පළමු අංගය වන්නේ දැනට සම්පාදනය කර ඇති crate හි නමයි.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// සම්පාදක වේලාවේදී වින්‍යාස ධජ වල බූලියන් සංයෝජන ඇගයීමට ලක් කරයි.
    ///
    /// `#[cfg]` ගුණාංගයට අමතරව, වින්‍යාස ධජ වල බූලියන් ප්‍රකාශන ඇගයීමට ඉඩ දීම සඳහා මෙම සාර්වය සපයා ඇත.
    /// මෙය නිතරම අඩු අනුපිටපත් කේතයකට යොමු කරයි.
    ///
    /// මෙම සාර්වයට ලබා දී ඇති වාක්‍ය ඛණ්ඩය [`cfg`] ගුණාංගයට සමාන වාක්‍ය ඛණ්ඩයකි.
    ///
    /// `cfg!`, `#[cfg]` මෙන් නොව, කිසිදු කේතයක් ඉවත් නොකරන අතර සත්‍ය හෝ අසත්‍ය ලෙස පමණක් ඇගයීමට ලක් කරයි.
    /// නිදසුනක් ලෙස, `cfg!` තක්සේරු කරන්නේ කුමක් වුවත්, if/else ප්‍රකාශනයක ඇති සියලුම කොටස් වලංගු විය යුතුය.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// සන්දර්භය අනුව ගොනුවක් ප්‍රකාශනයක් හෝ අයිතමයක් ලෙස විග්‍රහ කරයි.
    ///
    /// ගොනුව වත්මන් ගොනුවට සාපේක්ෂව පිහිටා ඇත (මොඩියුල සොයා ගන්නා ආකාරය හා සමානව).සපයන ලද මාර්ගය සම්පාදනය කරන වේලාවේදී වේදිකාවට විශේෂිත ආකාරයකින් අර්ථ නිරූපණය කෙරේ.
    /// උදාහරණයක් ලෙස, Windows බැක්ස්ලෑෂ් අඩංගු Windows මාර්ගයක් සහිත ආයාචනයක් Unix මත නිවැරදිව සම්පාදනය නොවේ.
    ///
    /// මෙම සාර්ව භාවිතා කිරීම බොහෝ විට නරක අදහසකි, මන්ද ගොනුව ප්‍රකාශනයක් ලෙස විග්‍රහ කර ඇත්නම් එය අවට කේතයේ අපිරිසිදු ලෙස තැන්පත් වනු ඇත.
    /// වර්තමාන ගොනුවේ එකම නමක් ඇති විචල්‍යයන් හෝ ශ්‍රිත තිබේ නම් ගොනුව අපේක්ෂා කළ දෙයට වඩා විචල්‍ය හෝ ශ්‍රිත වෙනස් වීමට මෙය හේතු විය හැක.
    ///
    ///
    /// # Examples
    ///
    /// පහත සඳහන් අන්තර්ගතයන් සහිත එකම නාමාවලියෙහි ගොනු දෙකක් ඇතැයි උපකල්පනය කරන්න:
    ///
    /// ගොනුව 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// ගොනුව 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs' සම්පාදනය කර එහි ප්‍රති b ලයක් ලෙස ද්විමය ධාවනය කිරීමෙන් "🙈🙊🙉🙈🙊🙉" මුද්‍රණය වේ.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ධාවන වේලාවේදී බූලියන් ප්‍රකාශනයක් `true` බව ප්‍රකාශ කරයි.
    ///
    /// සපයන ලද ප්‍රකාශනය ක්‍රියාත්මක වන වේලාවේදී `true` වෙත තක්සේරු කළ නොහැකි නම් මෙය [`panic!`] මැක්‍රෝව ක්‍රියාත්මක කරයි.
    ///
    /// # Uses
    ///
    /// නිදොස් කිරීම් සහ මුදා හැරීම් යන දෙකෙහිම ප්‍රකාශ සෑම විටම පරීක්ෂා කරනු ලබන අතර එය අක්‍රිය කළ නොහැක.
    /// පෙරනිමියෙන් මුදා හැරීම් වලදී සක්‍රීය කර නොමැති ප්‍රකාශ සඳහා [`debug_assert!`] බලන්න.
    ///
    /// අනාරක්ෂිත කේතය `assert!` මත රඳා පැවතිය හැකි අතර එය උල්ලං if නය වුවහොත් අනාරක්ෂිතභාවයට පත්විය හැකිය.
    ///
    /// `assert!` හි වෙනත් භාවිත අවස්ථා අතරට ආරක්ෂිත කේත තුළ ධාවන කාල ආක්‍රමණ පරීක්ෂා කිරීම සහ බලාත්මක කිරීම ඇතුළත් වේ (ඒවා උල්ලං violation නය වීමෙන් අනාරක්ෂිත බවක් ඇති නොවේ).
    ///
    ///
    /// # අභිරුචි පණිවිඩ
    ///
    /// මෙම සාර්වයට දෙවන ආකෘතියක් ඇත, එහිදී අභිරුචි panic පණිවිඩයක් ආකෘතිකරණය සඳහා තර්ක සමඟ හෝ නැතිව සැපයිය හැකිය.
    /// මෙම පෝරමය සඳහා සින්ටැක්ස් සඳහා [`std::fmt`] බලන්න.
    /// ආකෘති තර්ක ලෙස භාවිතා කරන ප්‍රකාශන ඇගයීමට ලක් කරන්නේ ප්‍රකාශය අසමත් වුවහොත් පමණි.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // මෙම ප්‍රකාශයන් සඳහා වන panic පණිවිඩය ලබා දී ඇති ප්‍රකාශනයේ දැඩි අගයයි.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // ඉතා සරල ශ්‍රිතයක්
    ///
    /// assert!(some_computation());
    ///
    /// // අභිරුචි පණිවිඩයක් සමඟ තහවුරු කරන්න
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// පේළිගත එකලස් කිරීම.
    ///
    /// භාවිතය සඳහා [unstable book] කියවන්න.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// එල්එල්වීඑම් විලාසිතාවේ පේළිගත එකලස් කිරීම.
    ///
    /// භාවිතය සඳහා [unstable book] කියවන්න.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// මොඩියුල මට්ටමේ පේළිගත එකලස් කිරීම.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// මුද්‍රණ tokens සම්මත නිමැවුමට සම්මත කළේය.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// වෙනත් මැක්‍රෝ නිදොස් කිරීම සඳහා භාවිතා කරන ලුහුබැඳීමේ ක්‍රියාකාරිත්වය සක්‍රිය හෝ අක්‍රීය කරයි.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// ව්‍යුත්පන්න මැක්‍රෝස් යෙදීම සඳහා භාවිතා කරන සාර්ව ගුණාංග.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// ශ්‍රිතයක් ඒකක පරීක්ෂණයකට හැරවීම සඳහා සාර්ව ආරෝපණය කර ඇත.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// ශ්‍රිතයක් මිණුම් ලකුණක් බවට පත් කිරීම සඳහා සාර්ව ආරෝපණය කර ඇත.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// `#[test]` සහ `#[bench]` මැක්‍රෝස් ක්‍රියාත්මක කිරීමේ විස්තරයක්.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// ගෝලීය විබෙදන්නෙකු ලෙස ලියාපදිංචි කිරීම සඳහා ස්ථිතිකයකට ආරෝපිත සාර්ව යොදන්න.
    ///
    /// [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html) ද බලන්න.
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// සම්මත කරන ලද මාර්ගයට ප්‍රවේශ විය හැකි නම් එය යොදන අයිතමය තබාගෙන එය වෙනත් ආකාරයකින් ඉවත් කරයි.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// එය යොදන කේත කැබැල්ලේ ඇති සියලුම `#[cfg]` සහ `#[cfg_attr]` ගුණාංග පුළුල් කරයි.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// `rustc` සම්පාදකයාගේ අස්ථායී ක්‍රියාත්මක කිරීමේ විස්තර භාවිතා නොකරන්න.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// `rustc` සම්පාදකයාගේ අස්ථායී ක්‍රියාත්මක කිරීමේ විස්තර භාවිතා නොකරන්න.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}