//! ASCII නූල් සහ අක්ෂර මත මෙහෙයුම්.
//!
//! Rust හි බොහෝ සංගීත මෙහෙයුම් UTF-8 නූල් මත ක්‍රියා කරයි.
//! කෙසේ වෙතත්, ඇතැම් විට නිශ්චිත මෙහෙයුමක් සඳහා ASCII අක්ෂර කට්ටලය පමණක් සලකා බැලීම වඩාත් අර්ථවත් කරයි.
//!
//! [`escape_default`] ශ්‍රිතය දී ඇති අක්ෂරයෙන් ගැලවී ගිය අනුවාදයක බයිට් වලට වඩා අනුකාරකයක් සපයයි.
//!
//!

#![stable(feature = "core_ascii", since = "1.26.0")]

use crate::fmt;
use crate::iter::FusedIterator;
use crate::ops::Range;
use crate::str::from_utf8_unchecked;

/// බයිට් එකක පැන ගිය අනුවාදය හරහා අනුකාරකය.
///
/// මෙම `struct` නිර්මාණය කර ඇත්තේ [`escape_default`] ශ්‍රිතයෙනි.
/// වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct EscapeDefault {
    range: Range<usize>,
    data: [u8; 4],
}

/// `u8` හි ගැලවී ගිය අනුවාදයක් නිපදවන iterator එකක් ලබා දෙයි.
///
/// C ++ 11 සහ ඒ හා සමාන C-පවුල් භාෂා ඇතුළුව විවිධ භාෂාවලින් නීත්‍යානුකූල වන සාහිත්‍යකරුවන් බිහිකිරීමේ නැඹුරුවක් සහිතව පෙරනිමිය තෝරා ගනු ලැබේ.
/// නිශ්චිත නීති:
///
/// * ටැබ් එක `\t` ලෙස ගැලවී ඇත.
/// * ප්‍රවාහනය නැවත පැමිණීම `\r` ලෙස ගැලවී ඇත.
/// * රේඛීය සංග්‍රහය `\n` ලෙස ගැලවී ඇත.
/// * තනි උපුටා දැක්වීම `\'` ලෙස ගැලවී ඇත.
/// * ද්විත්ව උපුටා දැක්වීම `\"` ලෙස ගැලවී ඇත.
/// * බැක්ස්ලෑෂ් `\\` ලෙස ගැලවී ඇත.
/// * 'මුද්‍රණය කළ හැකි ASCII' පරාසයේ `0x20` .. `0x7e` ඇතුළත් ඕනෑම අක්ෂරයක් ගැලවී නැත.
/// * වෙනත් ඕනෑම අක්ෂරයකට '\xNN' ආකෘතියේ හෙක්ස් ගැලවී යා හැකිය.
/// * මෙම ශ්‍රිතය මඟින් යුනිකෝඩ් ගැලවීම කිසි විටෙකත් ජනනය නොවේ.
///
/// # Examples
///
/// ```
/// use std::ascii;
///
/// let escaped = ascii::escape_default(b'0').next().unwrap();
/// assert_eq!(b'0', escaped);
///
/// let mut escaped = ascii::escape_default(b'\t');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b't', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\r');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'r', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\n');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'n', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\'');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'\'', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'"');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'"', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\\');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'\\', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\x9d');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'x', escaped.next().unwrap());
/// assert_eq!(b'9', escaped.next().unwrap());
/// assert_eq!(b'd', escaped.next().unwrap());
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn escape_default(c: u8) -> EscapeDefault {
    let (data, len) = match c {
        b'\t' => ([b'\\', b't', 0, 0], 2),
        b'\r' => ([b'\\', b'r', 0, 0], 2),
        b'\n' => ([b'\\', b'n', 0, 0], 2),
        b'\\' => ([b'\\', b'\\', 0, 0], 2),
        b'\'' => ([b'\\', b'\'', 0, 0], 2),
        b'"' => ([b'\\', b'"', 0, 0], 2),
        b'\x20'..=b'\x7e' => ([c, 0, 0, 0], 1),
        _ => ([b'\\', b'x', hexify(c >> 4), hexify(c & 0xf)], 4),
    };

    return EscapeDefault { range: 0..len, data };

    fn hexify(b: u8) -> u8 {
        match b {
            0..=9 => b'0' + b,
            _ => b'a' + b - 10,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Iterator for EscapeDefault {
    type Item = u8;
    fn next(&mut self) -> Option<u8> {
        self.range.next().map(|i| self.data[i])
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.range.size_hint()
    }
    fn last(mut self) -> Option<u8> {
        self.next_back()
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl DoubleEndedIterator for EscapeDefault {
    fn next_back(&mut self) -> Option<u8> {
        self.range.next_back().map(|i| self.data[i])
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ExactSizeIterator for EscapeDefault {}
#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for EscapeDefault {}

#[stable(feature = "ascii_escape_display", since = "1.39.0")]
impl fmt::Display for EscapeDefault {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // සුරක්ෂිතභාවය: හරි නිසා `escape_default` වලංගු utf-8 දත්ත පමණක් නිර්මාණය කර ඇත
        f.write_str(unsafe { from_utf8_unchecked(&self.data[self.range.clone()]) })
    }
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for EscapeDefault {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("EscapeDefault { .. }")
    }
}