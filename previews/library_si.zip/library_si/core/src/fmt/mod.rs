//! නූල් ආකෘතිකරණය සහ මුද්‍රණය සඳහා උපයෝගිතා.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// `Formatter::align` විසින් ආපසු ලබා දිය හැකි පෙළගැස්වීම්
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// අන්තර්ගතය වමට පෙළ ගැස්විය යුතු බවට ඇඟවීම.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// අන්තර්ගතය නිවැරදිව පෙළ ගැස්විය යුතු බවට ඇඟවීම.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// අන්තර්ගතය මධ්‍යගතව පෙළගැස්විය යුතු බවට ඇඟවීම.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// ආකෘතිකරණ ක්‍රම මඟින් ආපසු ලබා දුන් වර්ගය.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// පණිවිඩයක් ප්‍රවාහයකට සංයුති කිරීමෙන් ආපසු ලබා දෙන දෝෂ වර්ගය.
///
/// දෝෂයක් සිදුවීම හැර වෙනත් දෝෂයක් සම්ප්‍රේෂණය කිරීමට මෙම වර්ගය සහාය නොදක්වයි.
/// ඕනෑම අමතර තොරතුරු වෙනත් ආකාරයකින් සම්ප්‍රේෂණය කිරීමට කටයුතු කළ යුතුය.
///
/// මතක තබා ගත යුතු වැදගත් කරුණක් නම්, `fmt::Error` වර්ගය [`std::io::Error`] හෝ [`std::error::Error`] සමඟ පටලවා නොගත යුතු අතර, එය ඔබට විෂය පථයටද තිබිය හැකිය.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// යුනිකෝඩ් පිළිගන්නා බෆර හෝ ධාරාවන්ට ලිවීම හෝ ආකෘතිකරණය කිරීම සඳහා trait.
///
/// මෙම trait යූටීඑෆ්-8-කේතනය කළ දත්ත පමණක් පිළිගන්නා අතර එය [flushable] නොවේ.
/// ඔබට අවශ්‍ය වන්නේ යුනිකෝඩ් පිළිගැනීමට සහ ඔබට ෆ්ලෂ් කිරීම අවශ්‍ය නොවේ නම්, ඔබ මෙම trait ක්‍රියාත්මක කළ යුතුය;
/// නැතිනම් ඔබ [`std::io::Write`] ක්‍රියාත්මක කළ යුතුය.
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// මෙම ලේඛකයාට නූල් පෙත්තක් ලියමින්, ලිවීම සාර්ථකද යන්න නැවත ලබා දෙයි.
    ///
    /// මෙම ක්‍රමය සාර්ථක විය හැක්කේ සම්පූර්ණ නූල් පෙත්ත සාර්ථකව ලියා ඇත්නම් පමණක් වන අතර, සියලු දත්ත ලියා හෝ දෝෂයක් සිදුවන තුරු මෙම ක්‍රමය නැවත නොඑනු ඇත.
    ///
    ///
    /// # Errors
    ///
    /// මෙම ශ්‍රිතය [`Error`] දෝෂයක් මත උදාහරණයක් ලබා දෙනු ඇත.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// මෙම ලේඛකයාට [`char`] ලියයි, ලිවීම සාර්ථකද යන්න නැවත ලබා දෙයි.
    ///
    /// තනි [`char`] බයිට් එකකට වඩා කේතනය කළ හැකිය.
    /// මෙම ක්‍රමය සාර්ථක විය හැක්කේ සම්පූර්ණ බයිට් අනුක්‍රමය සාර්ථකව ලියා ඇත්නම් පමණක් වන අතර, සියලු දත්ත ලියා හෝ දෝෂයක් සිදුවන තුරු මෙම ක්‍රමය නැවත නොඑනු ඇත.
    ///
    ///
    /// # Errors
    ///
    /// මෙම ශ්‍රිතය [`Error`] දෝෂයක් මත උදාහරණයක් ලබා දෙනු ඇත.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// මෙම trait ක්‍රියාත්මක කරන්නන් සමඟ [`write!`] මැක්‍රෝ භාවිතය සඳහා මැලියම්.
    ///
    /// මෙම ක්‍රමය සාමාන්‍යයෙන් අතින් කළ යුතු නොවේ, ඒ වෙනුවට [`write!`] සාර්ව හරහා ය.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// ආකෘතිකරණය සඳහා වින්‍යාසය.
///
/// `Formatter` ආකෘතිකරණයට අදාළ විවිධ විකල්ප නියෝජනය කරයි.
/// පරිශීලකයින් කෙලින්ම `ආකෘතිය 'සාදන්නේ නැත;[`Debug`] සහ [`Display`] වැනි traits හි සියලුම ආකෘතිකරණයේ `fmt` ක්‍රමයට එකක් සඳහා විකෘති යොමු කිරීමක් ලබා දෙනු ලැබේ.
///
///
/// `Formatter` සමඟ අන්තර් ක්‍රියා කිරීමට, හැඩතල ගැන්වීමට අදාළ විවිධ විකල්ප වෙනස් කිරීමට ඔබ විවිධ ක්‍රම අමතනු ඇත.
/// උදාහරණ සඳහා, කරුණාකර පහත `Formatter` හි අර්ථ දක්වා ඇති ක්‍රමවල ප්‍රලේඛනය බලන්න.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// තර්කය අත්‍යවශ්‍යයෙන්ම `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result` ට සමාන ප්‍රශස්තකරණය කරන ලද අර්ධ වශයෙන් යෙදවුම් ආකෘතිකරණ ශ්‍රිතයකි.

extern "C" {
    type Opaque;
}

/// මෙම ව්‍යුහය නිරූපණය කරන්නේ එක්ස්ප්‍රින්ට් පවුල විසින් ගනු ලබන සාමාන්‍ය "argument" ය.දී ඇති අගය සංයුති කිරීමේ ශ්‍රිතයක් එහි අඩංගු වේ.
/// සම්පාදනය කරන වේලාවේදී ශ්‍රිතය හා අගය නිවැරදි වර්ග ඇති බව සහතික කර ඇති අතර, පසුව මෙම ව්‍යුහය එක් වර්ගයකට තර්ක කැනොනිකල්කරණය සඳහා යොදා ගනී.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// ආකෘතිකරණ යටිතල ව්‍යුහයේ indices/counts හා සම්බන්ධිත ශ්‍රිත දර්ශකය සඳහා මෙය තනි ස්ථාවර අගයක් සහතික කරයි.
//
// වර්තමාන LLVM IR දක්වා පහත හෙලීම සමඟ ශ්‍රිතයන් සැමවිටම නම් නොකල_අඩ්ර් ලෙස ටැග් කර ඇති බැවින් අර්ථ දක්වා ඇති ශ්‍රිතයක් නිවැරදි නොවන බව සලකන්න, එබැවින් ඒවායේ ලිපිනය LLVM ට වැදගත් නොවන අතර as_usize cast වැරදි ලෙස සම්පාදනය කළ හැකිය.
//
// ප්‍රායෝගිකව, අපි කිසි විටෙකත් භාවිතා නොකරන දත්ත අඩංගු as_usize ලෙස හඳුන්වන්නේ නැත (ආකෘතිකරණ තර්කවල ස්ථිතික උත්පාදනය පිළිබඳ කාරණයක් ලෙස), එබැවින් මෙය හුදෙක් අතිරේක පරීක්ෂාවකි.
//
// අපට මූලික වශයෙන් අවශ්‍ය වන්නේ `USIZE_MARKER` හි ශ්‍රිත දර්ශකයට `&usize` ඔවුන්ගේ පළමු තර්කය ලෙස සලකන ශ්‍රිතයන්ට *පමණක්* අනුරූප ලිපිනයක් ඇති බව සහතික කිරීමයි.
// සම්මත කර ඇති යොමුවකින් අපට ආරක්ෂිතව භාවිතයක් සූදානම් කළ හැකි බවත්, මෙම ලිපිනය භාවිතයට නොගන්නා ක්‍රියාකාරීත්වයකට යොමු නොවන බවත් මෙහි ඇති read_volatile සහතික කරයි.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // ආරක්ෂාව: ptr යනු යොමු දැක්වීමකි
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // ආරක්ෂාව: `mem::transmute(x)` ආරක්ෂිත නිසා
        //     1. `&'b T` එය ආරම්භ වූ ආයු කාලය `'b` සමඟ තබා ගනී (අසීමිත ආයු කාලයක් නොතිබීමට)
        //     2.
        //     `&'b T` සහ `&'b Opaque` ට එකම මතක පිරිසැලසුමක් ඇත (`T` `Sized` වන විට, මෙහි ඇති පරිදි) `fn(&T, &mut Formatter<'_>) -> Result` සහ `fn(&Opaque, &mut Formatter<'_>) -> Result` එකම ABI ඇති බැවින් `mem::transmute(f)` ආරක්ෂිත වේ (`T` `Sized` පවතින තාක් කල්)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // සුරක්ෂිතභාවය: `formatter` ක්ෂේත්‍රය සකසා ඇත්තේ USIZE_MARKER නම් පමණි
            // අගය භාවිතා කිරීමකි, එබැවින් මෙය ආරක්ෂිත වේ
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// ධජ XMX ආකෘතියෙන් ලබා ගත හැකිය
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// Format_args! () සාර්ව භාවිතා කරන විට, මෙම ශ්‍රිතය තර්ක ව්‍යුහය ජනනය කිරීමට යොදා ගනී.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// ප්‍රමිතියෙන් තොර හැඩතල ගැන්වීමේ පරාමිතීන් නියම කිරීමට මෙම ශ්‍රිතය භාවිතා කරයි.
    /// වලංගු තර්ක ව්‍යුහයක් තැනීම සඳහා `pieces` අරාව අවම වශයෙන් `fmt` තරම් දිගු විය යුතුය.
    /// එසේම, `fmt` තුළ ඇති ඕනෑම `Count`, `CountIsParam` හෝ `CountIsNextParam` යනු `argumentusize` සමඟ සාදන ලද තර්කයක් වෙත යොමු විය යුතුය.
    ///
    /// කෙසේ වෙතත්, එසේ කිරීමට අපොහොසත් වීම අනාරක්ෂිත බවක් ඇති නොකරයි, නමුත් අවලංගුය නොසලකා හරිනු ඇත.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// ආකෘතිගත කළ පෙළෙහි දිග ඇස්තමේන්තු කරයි.
    ///
    /// `format!` භාවිතා කරන විට ආරම්භක `String` ධාරිතාව සැකසීම සඳහා මෙය භාවිතා කිරීමට අදහස් කෙරේ.
    /// Note: මෙය පහළ හෝ ඉහළ මායිම නොවේ.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // ආකෘති පත්‍රය තර්කයක් සමඟ ආරම්භ වන්නේ නම්, කැබලි වල දිග සැලකිය යුතු නම් මිස කිසිවක් පූර්ව වෙන් නොකරන්න.
            //
            //
            0
        } else {
            // සමහර තර්ක ඇත, එබැවින් ඕනෑම අමතර තල්ලුවක් මඟින් නූල නැවත වෙන් කරනු ලැබේ.
            //
            // එය වළක්වා ගැනීම සඳහා, අපි මෙහි ධාරිතාව "pre-doubling" වේ.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// මෙම ව්‍යුහය නිරූපණය කරන්නේ ආකෘති නූලක ආරක්ෂිතව සැකසූ අනුවාදයක් සහ එහි තර්ක ය.
/// ආරක්ෂිතව මෙය කළ නොහැකි බැවින් මෙය ධාවන වේලාවේදී උත්පාදනය කළ නොහැක, එබැවින් ඉදිකිරීම්කරුවන් ලබා නොදෙන අතර වෙනස් කිරීම වැළැක්වීම සඳහා ක්ෂේත්‍ර පුද්ගලික වේ.
///
///
/// [`format_args!`] සාර්ව මෙම ව්‍යුහයේ නිදසුනක් ආරක්ෂිතව නිර්මාණය කරයි.
/// [`write()`] සහ [`format()`] ශ්‍රිත භාවිතා කිරීම ආරක්ෂිතව සිදු කළ හැකි වන පරිදි මැක්‍රෝ සංයුති වේලාවේදී ආකෘති මාලාව වලංගු කරයි.
///
/// පහත දැක්වෙන පරිදි [`format_args!`] සහ `Display` සන්දර්භය තුළ [`format_args!`] ආපසු ලබා දෙන `Arguments<'a>` භාවිතා කළ හැකිය.
/// උදාහරණයෙන් දැක්වෙන්නේ `Debug` සහ `Display` ආකෘතිය එකම දෙයකට ය: `format_args!` හි අන්තර්සම්බන්ධිත ආකෘතිය.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // මුද්‍රණය කිරීම සඳහා නූල් කෑලි ආකෘතිකරණය කරන්න.
    pieces: &'a [&'static str],

    // සියලුම පිරිවිතර පෙරනිමි නම් ("{}{}" හි මෙන්) ස්ථාන දරණ පිරිවිතර, හෝ `None`.
    fmt: Option<&'a [rt::v1::Argument]>,

    // නූල් කැබලි සමඟ අන්තර් සම්බන්ධ වීමට අන්තර් මැදිහත්වීම සඳහා ගතික තර්ක.
    // (සෑම තර්කයක්ම නූල් කැබැල්ලකට පෙර වේ.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// ආකෘතිකරණය කිරීමට තර්ක නොමැති නම්, ආකෘතිගත කරන ලද නූල ලබා ගන්න.
    ///
    /// වඩාත්ම සුළු කාරණයේදී වෙන් කිරීම වළක්වා ගැනීමට මෙය භාවිතා කළ හැකිය.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` ක්‍රමලේඛකයා මුහුණ දෙන, නිදොස් කිරීමේ සන්දර්භය තුළ ප්‍රතිදානය සංයුති කළ යුතුය.
///
/// පොදුවේ ගත් කල, ඔබ කළ යුත්තේ `derive` `Debug` ක්‍රියාත්මක කිරීමකි.
///
/// `#?` විකල්ප ආකෘති පිරිවිතර සමඟ භාවිතා කරන විට, ප්‍රතිදානය ලස්සනට මුද්‍රණය වේ.
///
/// ආකෘති පිළිබඳ වැඩි විස්තර සඳහා, [the module-level documentation][module] බලන්න.
///
/// [module]: ../../std/fmt/index.html
///
/// සියලුම ක්ෂේත්‍ර `Debug` ක්‍රියාත්මක කරන්නේ නම් මෙම trait `#[derive]` සමඟ භාවිතා කළ හැකිය.
/// ව්‍යුහයන් සඳහා `ව්‍යුත්පන්න කළ විට, එය `struct`, පසුව `{`, පසුව කොමා වලින් වෙන් කරන ලද එක් එක් ක්ෂේත්‍රයේ නම සහ `Debug` අගය, පසුව `}` යන නම භාවිතා කරයි.
/// `Enum` සඳහා, එය ප්‍රභේදයේ නම භාවිතා කරනු ඇති අතර, අදාළ නම්, `(`, ඉන්පසු ක්ෂේත්‍රවල `Debug` අගයන්, පසුව `)`.
///
/// # Stability
///
/// ව්‍යුත්පන්න කළ `Debug` ආකෘති ස්ථායී නොවන අතර future Rust අනුවාද සමඟ වෙනස් විය හැකිය.
/// මීට අමතරව, සම්මත පුස්තකාලය (`libstd`, `libcore`, `liballoc`, ආදිය) විසින් සපයන ලද `Debug` ක්‍රියාත්මක කිරීම් ස්ථායී නොවන අතර future Rust අනුවාද සමඟද වෙනස් විය හැකිය.
///
///
/// # Examples
///
/// ක්‍රියාත්මක කිරීම:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// අතින් ක්‍රියාත්මක කිරීම:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// [`debug_struct`] වැනි අතින් ක්‍රියාත්මක කිරීම සඳහා ඔබට උදව් කිරීමට [`Formatter`] ව්‍යුහයේ උපකාරක ක්‍රම ගණනාවක් තිබේ.
///
/// `Debug` `derive` හෝ [`Formatter`] හි දෝශ නිරාකරණ API භාවිතා කරමින් ක්‍රියාත්මක කිරීම විකල්ප ධජය භාවිතයෙන් ලස්සන මුද්‍රණයට සහාය වේ: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// `#?` සමඟ ලස්සන මුද්‍රණය:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// දී ඇති ආකෘතිය භාවිතා කරමින් අගය ආකෘතිකරණය කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// trait `Debug` නොමැතිව prelude වෙතින් සාර්ව `Debug` නැවත අපනයනය කිරීම සඳහා වෙනම මොඩියුලය.
pub(crate) mod macros {
    /// trait `Debug` හි ආවේගයක් ජනනය කරන ව්‍යුත්පන්න සාර්ව.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// හිස් ආකෘතියක් සඳහා trait ආකෘතිය, `{}`.
///
/// `Display` [`Debug`] ට සමාන වේ, නමුත් `Display` යනු පරිශීලකයා මුහුණ දෙන ප්‍රතිදානය සඳහා වන අතර එය ව්‍යුත්පන්න කළ නොහැක.
///
///
/// ආකෘති පිළිබඳ වැඩි විස්තර සඳහා, [the module-level documentation][module] බලන්න.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// වර්ගයක් මත `Display` ක්‍රියාත්මක කිරීම:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// දී ඇති ආකෘතිය භාවිතා කරමින් අගය ආකෘතිකරණය කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// `Octal` trait එහි ප්‍රතිදානය base-8 හි අංකයක් ලෙස සංයුති කළ යුතුය.
///
/// ප්‍රාථමික අත්සන් කළ පූර්ණ සංඛ්‍යා සඳහා (`i8` සිට `i128`, සහ `isize`), negative ණ අගයන් දෙකේ අනුපූරක නිරූපණය ලෙස සංයුති වේ.
///
///
/// විකල්ප ධජය වන `#`, ප්‍රතිදානය ඉදිරිපිට `0o` එක් කරයි.
///
/// ආකෘති පිළිබඳ වැඩි විස්තර සඳහා, [the module-level documentation][module] බලන්න.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` සමඟ මූලික භාවිතය:
///
/// ```
/// let x = 42; // 42 යනු අෂ්ටකයේ '52' වේ
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// වර්ගයක් මත `Octal` ක්‍රියාත්මක කිරීම:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // i32 ක්‍රියාත්මක කිරීමට නියෝජිතයා
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// දී ඇති ආකෘතිය භාවිතා කරමින් අගය ආකෘතිකරණය කරයි.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// `Binary` trait එහි ප්‍රතිදානය ද්විමය වශයෙන් අංකයක් ලෙස සංයුති කළ යුතුය.
///
/// ප්‍රාථමික අත්සන් කළ පූර්ණ සංඛ්‍යා සඳහා ([`i8`] සිට [`i128`], සහ [`isize`]), negative ණ අගයන් දෙකේ අනුපූරක නිරූපණය ලෙස සංයුති වේ.
///
///
/// විකල්ප ධජය වන `#`, ප්‍රතිදානය ඉදිරිපිට `0b` එක් කරයි.
///
/// ආකෘති පිළිබඳ වැඩි විස්තර සඳහා, [the module-level documentation][module] බලන්න.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// [`i32`] සමඟ මූලික භාවිතය:
///
/// ```
/// let x = 42; // 42 යනු ද්විමය වශයෙන් '101010' වේ
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// වර්ගයක් මත `Binary` ක්‍රියාත්මක කිරීම:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // i32 ක්‍රියාත්මක කිරීමට නියෝජිතයා
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// දී ඇති ආකෘතිය භාවිතා කරමින් අගය ආකෘතිකරණය කරයි.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// `LowerHex` trait එහි ප්‍රතිදානය හෙක්සැඩිසිමල් අංකයක් ලෙස සංයුති කළ යුතු අතර `a` සිට `f` දක්වා කුඩා අකුරින්.
///
/// ප්‍රාථමික අත්සන් කළ පූර්ණ සංඛ්‍යා සඳහා (`i8` සිට `i128`, සහ `isize`), negative ණ අගයන් දෙකේ අනුපූරක නිරූපණය ලෙස සංයුති වේ.
///
///
/// විකල්ප ධජය වන `#`, ප්‍රතිදානය ඉදිරිපිට `0x` එක් කරයි.
///
/// ආකෘති පිළිබඳ වැඩි විස්තර සඳහා, [the module-level documentation][module] බලන්න.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` සමඟ මූලික භාවිතය:
///
/// ```
/// let x = 42; // 42 යනු හෙක්ස් හි '2a' වේ
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// වර්ගයක් මත `LowerHex` ක්‍රියාත්මක කිරීම:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // i32 ක්‍රියාත්මක කිරීමට නියෝජිතයා
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// දී ඇති ආකෘතිය භාවිතා කරමින් අගය ආකෘතිකරණය කරයි.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` trait එහි ප්‍රතිදානය ෂඩාස්රාකාරයේ සංඛ්‍යාවක් ලෙස සංයුති කළ යුතු අතර `A` සිට `F` දක්වා ඉහළ අකුරින්.
///
/// ප්‍රාථමික අත්සන් කළ පූර්ණ සංඛ්‍යා සඳහා (`i8` සිට `i128`, සහ `isize`), negative ණ අගයන් දෙකේ අනුපූරක නිරූපණය ලෙස සංයුති වේ.
///
///
/// විකල්ප ධජය වන `#`, ප්‍රතිදානය ඉදිරිපිට `0x` එක් කරයි.
///
/// ආකෘති පිළිබඳ වැඩි විස්තර සඳහා, [the module-level documentation][module] බලන්න.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` සමඟ මූලික භාවිතය:
///
/// ```
/// let x = 42; // 42 යනු හෙක්ස් හි '2A' වේ
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// වර්ගයක් මත `UpperHex` ක්‍රියාත්මක කිරීම:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // i32 ක්‍රියාත්මක කිරීමට නියෝජිතයා
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// දී ඇති ආකෘතිය භාවිතා කරමින් අගය ආකෘතිකරණය කරයි.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` trait එහි ප්‍රතිදානය මතක ස්ථානයක් ලෙස සංයුති කළ යුතුය.
/// මෙය සාමාන්‍යයෙන් ෂඩාස්රාකාර ලෙස ඉදිරිපත් කෙරේ.
///
/// ආකෘති පිළිබඳ වැඩි විස්තර සඳහා, [the module-level documentation][module] බලන්න.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `&i32` සමඟ මූලික භාවිතය:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // මෙය '0x7f06092ac6d0' වැනි දෙයක් නිපදවයි
/// ```
///
/// වර්ගයක් මත `Pointer` ක්‍රියාත්මක කිරීම:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // අපට භාවිතා කළ හැකි පොයින්ටරය ක්‍රියාත්මක කරන `*const T` බවට පරිවර්තනය කිරීමට `as` භාවිතා කරන්න
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// දී ඇති ආකෘතිය භාවිතා කරමින් අගය ආකෘතිකරණය කරයි.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// `LowerExp` trait එහි ප්‍රතිදානය විද්‍යාත්මක අංකනයෙන් කුඩා අක්ෂර `e` සමඟ සංයුති කළ යුතුය.
///
/// ආකෘති පිළිබඳ වැඩි විස්තර සඳහා, [the module-level documentation][module] බලන්න.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` සමඟ මූලික භාවිතය:
///
/// ```
/// let x = 42.0; // 42.0 විද්‍යාත්මක අංකනයෙහි '4.2e1' වේ
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// වර්ගයක් මත `LowerExp` ක්‍රියාත්මක කිරීම:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // f64 ක්‍රියාත්මක කිරීම සඳහා නියෝජිතයා
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// දී ඇති ආකෘතිය භාවිතා කරමින් අගය ආකෘතිකරණය කරයි.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// `UpperExp` trait එහි ප්‍රතිදානය විද්‍යාත්මක අංකනයකින් ඉහළ අක්ෂර `E` සමඟ සංයුති කළ යුතුය.
///
/// ආකෘති පිළිබඳ වැඩි විස්තර සඳහා, [the module-level documentation][module] බලන්න.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` සමඟ මූලික භාවිතය:
///
/// ```
/// let x = 42.0; // 42.0 විද්‍යාත්මක අංකනයෙහි '4.2E1' වේ
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// වර්ගයක් මත `UpperExp` ක්‍රියාත්මක කිරීම:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // f64 ක්‍රියාත්මක කිරීම සඳහා නියෝජිතයා
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// දී ඇති ආකෘතිය භාවිතා කරමින් අගය ආකෘතිකරණය කරයි.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `write` ශ්‍රිතය ප්‍රතිදාන ප්‍රවාහයක් ගන්නා අතර `format_args!` සාර්ව සමඟ පූර්ව සම්පාදනය කළ හැකි `Arguments` ව්‍යුහයක් ගනී.
///
///
/// ලබා දී ඇති ප්‍රතිදාන ප්‍රවාහයට නිශ්චිත හැඩතල අනුව තර්ක සංයුති කෙරේ.
///
/// # Examples
///
/// මූලික භාවිතය:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// [`write!`] භාවිතා කිරීම වඩාත් සුදුසු බව කරුණාවෙන් සලකන්න.උදාහරණයක්:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // සියලුම තර්ක සඳහා අපට පෙරනිමි ආකෘතිකරණ පරාමිතීන් භාවිතා කළ හැකිය.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // සෑම පිරිවිතරයකටම අනුරූප තර්කයක් ඇත.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // ආරක්ෂාව: arg සහ args.args එකම තර්ක වලින් පැමිණේ,
                // එමඟින් දර්ශක සෑම විටම සීමාවන් තුළ පවතින බව සහතික කරයි.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // ඉතිරිව ඇත්තේ එක් පසුපස නූල් කැබැල්ලක් පමණි.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // ආරක්ෂාව: තර්ක සහ තර්ක එකම තර්ක වලින් පැමිණේ,
    // එමඟින් දර්ශක සෑම විටම සීමාවන් තුළ පවතින බව සහතික කරයි.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // නිවැරදි තර්කය උපුටා ගන්න
    debug_assert!(arg.position < args.len());
    // ආරක්ෂාව: තර්ක සහ තර්ක එකම තර්ක වලින් පැමිණේ,
    // එහි දර්ශකය සැමවිටම සීමාවන් තුළ පවතින බව සහතික කරයි.
    let value = unsafe { args.get_unchecked(arg.position) };

    // ඉන්පසු ඇත්ත වශයෙන්ම මුද්‍රණ කිහිපයක් කරන්න
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // ආරක්ෂාව: cnt සහ args පැමිණෙන්නේ එකම තර්ක වලින්,
            // මෙම දර්ශකය සැමවිටම සීමාවන් තුළ පවතින බව සහතික කරයි.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// යම් දෙයක් අවසන් වූ පසු පෑඩ් කිරීම.`Formatter::padding` විසින් ආපසු ලබා දෙන ලදි.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// මෙම පෝස්ට් පෑඩින් ලියන්න.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // අපට මෙය වෙනස් කිරීමට අවශ්‍යයි
            buf: wrap(self.buf),

            // මේවා ආරක්ෂා කරන්න
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // සියලුම හැඩතල ගැන්වීම් traits භාවිතා කළ හැකි තර්ක විතර්ක සැකසීම සහ සැකසීම සඳහා භාවිතා කරන උපකාරක ක්‍රම.
    //

    /// දැනටමත් str එකකට විමෝචනය කර ඇති පූර්ණ සංඛ්‍යාවක් සඳහා නිවැරදි පෑඩින් කිරීම සිදු කරයි.
    /// මෙම ක්‍රමය මඟින් එකතු කරනු ලබන පූර්ණ සංඛ්‍යා සඳහා ලකුණ str * අඩංගු නොවිය යුතුය.
    ///
    /// # Arguments
    ///
    /// * is_nonnegative, මුල් නිඛිලය ධනාත්මක හෝ ශුන්‍යද යන්න.
    /// * උපසර්ගය, '#' අක්ෂරය (Alternate) ලබා දී ඇත්නම්, අංකයට ඉදිරියෙන් තැබිය යුතු උපසර්ගය මෙයයි.
    ///
    /// * buf, අංකය සංයුති කර ඇති බයිට් අරාව
    ///
    /// මෙම ශ්‍රිතය සපයා ඇති ධජ මෙන්ම අවම පළලද නිවැරදිව ගණනය කරනු ඇත.
    /// එය නිරවද්යතාව සැලකිල්ලට නොගනී.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // අපි සංඛ්‍යා ප්‍රතිදානයෙන් "-" ඉවත් කළ යුතුයි.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // ලකුණ තිබේ නම් එය ලියයි, පසුව එය ඉල්ලා සිටියේ නම් උපසර්ගය ලියයි
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // `width` ක්ෂේත්‍රය මෙම අවස්ථාවෙහිදී `min-width` පරාමිතියකට වඩා වැඩිය.
        match self.width {
            // අවම දිග අවශ්‍යතා නොමැති නම් අපට බයිට් ලිවිය හැකිය.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // අප අවම පළල ඉක්මවා ඇත්දැයි පරීක්ෂා කරන්න, එසේ නම් අපට බයිට් ලිවිය හැකිය.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // පිරවුම් අක්ෂරය ශුන්‍ය නම් ලකුණ සහ උපසර්ගය පෑඩින් කිරීමට පෙර යයි
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // එසේ නොමැති නම්, ලකුණ සහ උපසර්ගය පෑඩින් පසු යයි
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// මෙම ශ්‍රිතය නූල් පෙත්තක් ගෙන නිශ්චිත හැඩතල ගැන්වීමේ කොඩි යෙදීමෙන් පසු එය අභ්‍යන්තර බෆරයට විමෝචනය කරයි.
    /// සාමාන්‍ය නූල් සඳහා හඳුනාගත් කොඩි:
    ///
    /// * පළල, විමෝචනය කළ යුතු දේවල අවම පළල
    /// * fill/align - සපයන ලද නූල් පෑඩ් කිරීමට අවශ්‍ය නම් විමෝචනය කළ යුත්තේ කුමක්ද සහ එය විමෝචනය කරන්නේ කොතැනද
    /// * නිරවද්‍යතාවය, විමෝචනය කළ හැකි උපරිම දිග, මෙම දිගට වඩා දිගු නම් නූල කපා දමනු ලැබේ
    ///
    /// මෙම ශ්‍රිතය `flag` පරාමිතීන් නොසලකා හැරීම විශේෂත්වයකි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // ඉදිරියෙන් වේගවත් මාවතක් ඇති බවට වග බලා ගන්න
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // `precision` ක්ෂේත්‍රය හැඩතල ගැන්වීම සඳහා `max-width` ලෙස අර්ථ දැක්විය හැකිය.
        //
        let s = if let Some(max) = self.precision {
            // අපගේ නූල නිරවද්‍යතාවයට වඩා දිගු නම්, අපට කප්පාදු කළ යුතුය.
            // කෙසේ වෙතත් `fill`, `width` සහ `align` වැනි අනෙකුත් ධජ සෑම විටම ක්‍රියා කළ යුතුය.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // මෙහි LLVM හට `..i` panic `&s[..i]` නොවන බව ඔප්පු කළ නොහැක, නමුත් එයට panic කළ නොහැකි බව අපි දනිමු.
                // `unsafe` වළක්වා ගැනීමට `get` + `unwrap_or` භාවිතා කරන්න, එසේ නොමැතිනම් මෙහි panic හා සම්බන්ධ කේත කිසිවක් විමෝචනය නොකරන්න.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // `width` ක්ෂේත්‍රය මෙම අවස්ථාවෙහිදී `min-width` පරාමිතියකට වඩා වැඩිය.
        match self.width {
            // අපි උපරිම දිගට යටත්ව, සහ අවම දිග අවශ්‍යතා නොමැති නම්, අපට නූල විමෝචනය කළ හැකිය
            //
            None => self.buf.write_str(s),
            // අප උපරිම පළලට වඩා අඩු නම්, අප අවම පළලට වඩා වැඩි දැයි පරීක්ෂා කරන්න, එසේ නම් එය නූල විමෝචනය කිරීම තරම් පහසු ය.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // අපි උපරිම හා අවම පළල යන දෙකටම යටත් නම්, අවම පළල නිශ්චිත නූලෙන් පුරවන්න.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// පෙර-පෑඩින් ලියන්න සහ ලිඛිත පශ්චාත්-පෑඩින් නැවත ලබා දෙන්න.
    /// පෑඩ් කරන දේට පසුව පශ්චාත්-පැඩින් ලිවීම සහතික කිරීම සඳහා අමතන්නන් වගකිව යුතුය.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// ආකෘතිගත කළ කොටස් ගෙන පෑඩින් යෙදීම.
    /// `self.precision` නොසලකා හැරිය හැකි වන පරිදි, අමතන්නා දැනටමත් අවශ්‍ය නිරවද්‍යතාවයෙන් කොටස් ලබා දී ඇතැයි උපකල්පනය කරයි.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // සං-ා-දැනුවත් ශුන්‍ය පෑඩින් සඳහා, අපි පළමුව ලකුණ විදහා දක්වමින් මුල සිටම කිසිදු සලකුණක් නොමැති ලෙස හැසිරෙමු.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // ලකුණක් සෑම විටම පළමු තැනට යයි
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // ආකෘතිගත කළ කොටස් වලින් ලකුණ ඉවත් කරන්න
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // ඉතිරි කොටස් සාමාන්‍ය පෑඩින් කිරීමේ ක්‍රියාවලිය හරහා ගමන් කරයි.
            let len = formatted.len();
            let ret = if width <= len {
                // පෑඩින් නැත
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // මෙය පොදු අවස්ථාව වන අතර අපි කෙටිමඟක් ගනිමු
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // ආරක්ෂාව: මෙය `flt2dec::Part::Num` සහ `flt2dec::Part::Copy` සඳහා භාවිතා කරයි.
            // සෑම වර්‍ග `c` `b'0'` සහ `b'9'` අතර ඇති බැවින් `flt2dec::Part::Num` සඳහා භාවිතා කිරීම ආරක්ෂිත වේ, එයින් අදහස් වන්නේ `s` වලංගු UTF-8 වේ.
            // `buf` සරල ASCII විය යුතු බැවින් `flt2dec::Part::Copy(buf)` සඳහා භාවිතා කිරීම ප්‍රායෝගිකව ආරක්ෂිත වේ, නමුත් `buf` සඳහා `buf` සඳහා නරක අගයක් `flt2dec::to_shortest_str` වෙත යමෙකුට ලබා දිය හැකිය, එය පොදු කාර්යයක් බැවින්.
            //
            // FIXME: මෙය UB වලට හේතු විය හැකිද යන්න තීරණය කරන්න.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // ශුන්‍ය 64 යි
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// මෙම ආකෘතියේ අඩංගු යටි බෆරයට දත්ත කිහිපයක් ලියයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // මෙය සමාන වේ:
    ///         // ලියන්න! (ආකෘතිය, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// මෙම අවස්ථාව සඳහා ආකෘතිගත තොරතුරු කිහිපයක් ලියයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// ආකෘතිකරණය සඳහා කොඩි
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// පෙළගැස්වීමක් ඇති සෑම අවස්ථාවකම 'fill' ලෙස භාවිතා කරන අක්‍ෂරය.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // අපි ">" සමඟ දකුණට පෙළගැස්වීම සකස් කරමු.
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// කුමන ආකාරයේ පෙළගැස්වීමක් ඉල්ලා ඇත්දැයි දැක්වෙන ධජය.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// ප්‍රතිදානය විය යුතු විකල්ප වශයෙන් නියම කරන ලද පූර්ණ සංඛ්‍යා පළල.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // අපට පළලක් ලැබුනේ නම්, අපි එය භාවිතා කරමු
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // නැතිනම් අපි විශේෂ දෙයක් කරන්නේ නැහැ
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// සංඛ්‍යාත්මක වර්ග සඳහා විකල්ප වශයෙන් නිශ්චිතව දක්වා ඇති නිරවද්‍යතාවය.
    /// විකල්පයක් ලෙස, නූල් වර්ග සඳහා උපරිම පළල.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // අපට නිරවද්‍යතාවයක් ලැබුනේ නම්, අපි එය භාවිතා කරමු.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // නැතිනම් අපි 2 ට පෙරනිමිය.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// `+` ධජය නියම කර ඇත්දැයි තීරණය කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// `-` ධජය නියම කර ඇත්දැයි තීරණය කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // ඔබට us ණ ලකුණක් අවශ්‍යද?එකක් ගන්න!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// `#` ධජය නියම කර ඇත්දැයි තීරණය කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// `0` ධජය නියම කර ඇත්දැයි තීරණය කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // අපි ආකෘතිකරුගේ විකල්ප නොසලකා හරිමු.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: මෙම ධජ දෙක සඳහා අපට අවශ්‍ය පොදු API තීරණය කරන්න.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// ව්‍යුහයන් සඳහා [`fmt::Debug`] ක්‍රියාත්මක කිරීම සඳහා සහාය වීම සඳහා නිර්මාණය කර ඇති [`DebugStruct`] සාදන්නෙකු නිර්මාණය කරයි.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// ද්විත්ව ව්‍යුහයන් සඳහා `fmt::Debug` ක්‍රියාත්මක කිරීම සඳහා සහාය වීම සඳහා නිර්මාණය කර ඇති `DebugTuple` තනන්නෙකු නිර්මාණය කරයි.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// ලැයිස්තු වැනි ව්‍යුහයන් සඳහා `fmt::Debug` ක්‍රියාත්මක කිරීම සඳහා සහාය වීම සඳහා නිර්මාණය කර ඇති `DebugList` තනන්නෙකු නිර්මාණය කරයි.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// කට්ටල වැනි ව්‍යුහයන් සඳහා `fmt::Debug` ක්‍රියාත්මක කිරීම් නිර්මාණය කිරීමට සහාය වීම සඳහා නිර්මාණය කර ඇති `DebugSet` සාදන්නෙකු නිර්මාණය කරයි.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// මෙම වඩාත් සංකීර්ණ උදාහරණයේ දී, අපි ගැලපුම් ආයුධ ලැයිස්තුවක් තැනීම සඳහා [`format_args!`] සහ `.debug_set()` භාවිතා කරමු:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// සිතියම් වැනි ව්‍යුහයන් සඳහා `fmt::Debug` ක්‍රියාත්මක කිරීම සඳහා සහාය වීම සඳහා නිර්මාණය කර ඇති `DebugMap` සාදන්නෙකු නිර්මාණය කරයි.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// මූලික හැඩතල ගැන්වීම traits ක්‍රියාත්මක කිරීම

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // වර්‍ගයෙන් ගැලවීමට අවශ්‍ය නම්, මෙතෙක් බැක්ලොග් ෆ්ලෂ් කර ලියන්න, නැතිනම් මඟ හරින්න
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // විකල්ප ධජය දැනටමත් ලෝවර්හෙක්ස් විසින් විශේෂ ලෙස සලකනු ලැබේ-එය 0x සමඟ උපසර්ගය කළ යුතුද යන්න දක්වයි.
        // අපි එය භාවිතා කරන්නේ ශුන්‍ය විස්තාරණය කළ යුතුද නැද්ද යන්න සොයා බැලීමටය, පසුව උපසර්ගය ලබා ගැනීම සඳහා කොන්දේසි විරහිතව එය සකසන්න.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// විවිධ මූලික වර්ග සඳහා Display/Debug ක්‍රියාත්මක කිරීම

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // RefCell විකෘති ලෙස ණයට ගෙන ඇති බැවින් අපට මෙහි වටිනාකම දෙස බැලිය නොහැක.
                // ඒ වෙනුවට ස්ථාන දරන්නෙකු පෙන්වන්න.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// පරීක්ෂණ මෙහි පැමිණෙනු ඇතැයි ඔබ අපේක්ෂා කළේ නම්, ඒ වෙනුවට core/tests/fmt.rs ගොනුව දෙස බලන්න, මෙහි ඇති සියලුම rt::Piece ව්‍යුහයන් නිර්මාණය කිරීමට වඩා පහසුය.
//
// ප්‍රතිපාදන අවශ්‍ය අය සඳහා crate වෙන් කිරීමෙහි පරීක්ෂණ ද ඇත.