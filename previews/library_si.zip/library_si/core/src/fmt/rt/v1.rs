//! මෙය ifmt විසින් භාවිතා කරන අභ්‍යන්තර මොඩියුලයකි!ධාවන කාලය.මෙම ව්‍යුහයන් ස්ථිතික අරා වලට විමෝචනය කරනුයේ නියමිත වේලාවට පෙර ආකෘති නූල් සකස් කිරීම සඳහා ය.
//!
//! මෙම නිර්වචන ඒවායේ `ct` සමානකම් වලට සමාන ය, නමුත් මේවා සංඛ්‍යාත්මකව වෙන් කළ හැකි අතර ධාවන කාලය සඳහා තරමක් ප්‍රශස්ත කර ඇත.
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// ආකෘතිකරණ නියෝගයක කොටසක් ලෙස ඉල්ලිය හැකි පෙළගැස්වීම්.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// අන්තර්ගතය වමට පෙළ ගැස්විය යුතු බවට ඇඟවීම.
    Left,
    /// අන්තර්ගතය නිවැරදිව පෙළ ගැස්විය යුතු බවට ඇඟවීම.
    Right,
    /// අන්තර්ගතය මධ්‍යගතව පෙළගැස්විය යුතු බවට ඇඟවීම.
    Center,
    /// පෙළගැස්වීමක් ඉල්ලා සිටියේ නැත.
    Unknown,
}

/// [width](https://doc.rust-lang.org/std/fmt/#width) සහ [precision](https://doc.rust-lang.org/std/fmt/#precision) පිරිවිතර භාවිතා කරයි.
#[derive(Copy, Clone)]
pub enum Count {
    /// වචනානුසාරයෙන් සඳහන් කර ඇති අගය ගබඩා කරයි
    Is(usize),
    /// `$` සහ `*` සින්ටැක්ස් භාවිතයෙන් නියම කර ඇති අතර, දර්ශකය `args` බවට ගබඩා කරයි
    Param(usize),
    /// විශේෂයෙන් දක්වා නැති
    Implied,
}