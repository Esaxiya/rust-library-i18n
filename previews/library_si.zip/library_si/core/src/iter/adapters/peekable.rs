use crate::iter::{adapters::SourceIter, FusedIterator, InPlaceIterable, TrustedLen};
use crate::ops::Try;

/// `peek()` සහිත අනුකාරකයක් ඊළඟ අංගයට විකල්ප යොමු කිරීමක් ලබා දෙයි.
///
///
/// මෙම `struct` [`Iterator`] හි [`peekable`] ක්‍රමය මඟින් නිර්මාණය කර ඇත.
/// වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
///
/// [`peekable`]: Iterator::peekable
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Peekable<I: Iterator> {
    iter: I,
    /// කිසිවක් නොතිබුණද, බැලූ බැල්මට මතක තබා ගන්න.
    peeked: Option<Option<I::Item>>,
}

impl<I: Iterator> Peekable<I> {
    pub(in crate::iter) fn new(iter: I) -> Peekable<I> {
        Peekable { iter, peeked: None }
    }
}

// `.peek()` ක්‍රමයේ කිසිවක් දැක නැතිනම් පීකබල් මතක තබා ගත යුතුය.
// එය `.peek() බව සහතික කරයි;.peek();` හෝ `.peek();.next();` දියුණුවේ එක් වරක් පමණි.
// මෙය තනිවම අනුකාරකය විලයනය නොකරයි.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> Iterator for Peekable<I> {
    type Item = I::Item;

    #[inline]
    fn next(&mut self) -> Option<I::Item> {
        match self.peeked.take() {
            Some(v) => v,
            None => self.iter.next(),
        }
    }

    #[inline]
    #[rustc_inherit_overflow_checks]
    fn count(mut self) -> usize {
        match self.peeked.take() {
            Some(None) => 0,
            Some(Some(_)) => 1 + self.iter.count(),
            None => self.iter.count(),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        match self.peeked.take() {
            Some(None) => None,
            Some(v @ Some(_)) if n == 0 => v,
            Some(Some(_)) => self.iter.nth(n - 1),
            None => self.iter.nth(n),
        }
    }

    #[inline]
    fn last(mut self) -> Option<I::Item> {
        let peek_opt = match self.peeked.take() {
            Some(None) => return None,
            Some(v) => v,
            None => None,
        };
        self.iter.last().or(peek_opt)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let peek_len = match self.peeked {
            Some(None) => return (0, Some(0)),
            Some(Some(_)) => 1,
            None => 0,
        };
        let (lo, hi) = self.iter.size_hint();
        let lo = lo.saturating_add(peek_len);
        let hi = match hi {
            Some(x) => x.checked_add(peek_len),
            None => None,
        };
        (lo, hi)
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let acc = match self.peeked.take() {
            Some(None) => return try { init },
            Some(Some(v)) => f(init, v)?,
            None => init,
        };
        self.iter.try_fold(acc, f)
    }

    #[inline]
    fn fold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let acc = match self.peeked {
            Some(None) => return init,
            Some(Some(v)) => fold(init, v),
            None => init,
        };
        self.iter.fold(acc, fold)
    }
}

#[stable(feature = "double_ended_peek_iterator", since = "1.38.0")]
impl<I> DoubleEndedIterator for Peekable<I>
where
    I: DoubleEndedIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        match self.peeked.as_mut() {
            Some(v @ Some(_)) => self.iter.next_back().or_else(|| v.take()),
            Some(None) => None,
            None => self.iter.next_back(),
        }
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        match self.peeked.take() {
            Some(None) => try { init },
            Some(Some(v)) => match self.iter.try_rfold(init, &mut f).into_result() {
                Ok(acc) => f(acc, v),
                Err(e) => {
                    self.peeked = Some(Some(v));
                    Try::from_error(e)
                }
            },
            None => self.iter.try_rfold(init, f),
        }
    }

    #[inline]
    fn rfold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        match self.peeked {
            Some(None) => init,
            Some(Some(v)) => {
                let acc = self.iter.rfold(init, &mut fold);
                fold(acc, v)
            }
            None => self.iter.rfold(init, fold),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator> ExactSizeIterator for Peekable<I> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator> FusedIterator for Peekable<I> {}

impl<I: Iterator> Peekable<I> {
    /// අනුකාරකය ඉදිරියට නොගෙන next() අගය වෙත යොමු කිරීමක් ලබා දෙයි.
    ///
    /// [`next`] මෙන්, වටිනාකමක් තිබේ නම්, එය `Some(T)` වලින් ඔතා ඇත.
    /// නමුත් නැවත කිරීම අවසන් නම්, `None` ආපසු ලබා දෙනු ලැබේ.
    ///
    /// [`next`]: Iterator::next
    ///
    /// `peek()` විසින් යොමු කිරීමක් ලබා දෙන නිසා සහ බොහෝ අනුකාරකයන් යොමු කිරීම් වලට වඩා පුනරාවර්තනය වන හෙයින්, ප්‍රතිලාභ අගය ද්විත්ව යොමු කිරීමක් වන ව්‍යාකූල තත්වයක් තිබිය හැකිය.
    /// පහත උදාහරණ වලින් ඔබට මෙම බලපෑම දැකිය හැකිය.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() අපට future වෙත බැලීමට ඉඩ දෙයි
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // අපි කිහිප වතාවක් `peek` කළත් iterator ඉදිරියට යන්නේ නැත
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // අනුකාරකය අවසන් වූ පසු `peek()` ද වේ
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&mut self) -> Option<&I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_ref()
    }

    /// අනුකාරකය ඉදිරියට නොගොස් next() අගය වෙත විකෘති යොමු කිරීමක් ලබා දෙයි.
    ///
    /// [`next`] මෙන්, වටිනාකමක් තිබේ නම්, එය `Some(T)` වලින් ඔතා ඇත.
    /// නමුත් නැවත කිරීම අවසන් නම්, `None` ආපසු ලබා දෙනු ලැබේ.
    ///
    /// `peek_mut()` විසින් යොමු කිරීමක් ලබා දෙන නිසා සහ බොහෝ අනුකාරකයන් යොමු කිරීම් වලට වඩා පුනරාවර්තනය වන හෙයින්, ප්‍රතිලාභ අගය ද්විත්ව යොමු කිරීමක් වන ව්‍යාකූල තත්වයක් තිබිය හැකිය.
    /// පහත උදාහරණ වලින් ඔබට මෙම බලපෑම දැකිය හැකිය.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// #![feature(peekable_peek_mut)]
    /// let mut iter = [1, 2, 3].iter().peekable();
    ///
    /// // `peek()` සමඟ මෙන්, අපට iterator ඉදිරියට නොගොස් future වෙතට පිවිසිය හැකිය.
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // අනුකාරකය දෙස බලා විකෘති යොමුව පිටුපස අගය සකසන්න.
    /// if let Some(p) = iter.peek_mut() {
    ///     assert_eq!(*p, &2);
    ///     *p = &5;
    /// }
    ///
    /// // අනුකාරකය අඛණ්ඩව පවතින විට අප තැබූ අගය නැවත දිස් වේ.
    /// assert_eq!(iter.collect::<Vec<_>>(), vec![&5, &3]);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "peekable_peek_mut", issue = "78302")]
    pub fn peek_mut(&mut self) -> Option<&mut I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_mut()
    }

    /// කොන්දේසියක් සත්‍ය නම් මෙම අනුකාරකයේ ඊළඟ අගය පරිභෝජනය කර ආපසු එවන්න.
    /// මෙම iterator හි ඊළඟ අගය සඳහා `func` `true` ආපසු ලබා දෙන්නේ නම්, එය පරිභෝජනය කර ආපසු එවන්න.
    /// එසේ නොමැතිනම්, `None` ආපසු එවන්න.
    /// # Examples
    /// අංක 0 ට සමාන නම් එය පරිභෝජනය කරන්න.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // අනුකාරකයේ පළමු අයිතමය 0;එය පරිභෝජනය කරන්න.
    /// assert_eq!(iter.next_if(|&x| x == 0), Some(0));
    /// // ආපසු ලබා දුන් ඊළඟ අයිතමය දැන් 1 වේ, එබැවින් `consume` `false` නැවත ලබා දෙනු ඇත.
    /// assert_eq!(iter.next_if(|&x| x == 0), None);
    /// // `next_if` `expected` ට සමාන නොවන්නේ නම් ඊළඟ අයිතමයේ වටිනාකම ඉතිරි කරයි.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    ///
    /// 10 ට අඩු ඕනෑම අංකයක් පරිභෝජනය කරන්න.
    ///
    /// ```
    /// let mut iter = (1..20).peekable();
    /// // 10 ට අඩු සියලුම සංඛ්‍යා පරිභෝජනය කරන්න
    /// while iter.next_if(|&x| x < 10).is_some() {}
    /// // ආපසු ලබා දෙන ඊළඟ අගය 10 කි
    /// assert_eq!(iter.next(), Some(10));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if(&mut self, func: impl FnOnce(&I::Item) -> bool) -> Option<I::Item> {
        match self.next() {
            Some(matched) if func(&matched) => Some(matched),
            other => {
                // අපි `self.next()` ලෙස හැඳින්වූ බැවින්, අපි `self.peeked` පරිභෝජනය කළෙමු.
                assert!(self.peeked.is_none());
                self.peeked = Some(other);
                None
            }
        }
    }

    /// ඊළඟ අයිතමය `expected` ට සමාන නම් පරිභෝජනය කර ආපසු එවන්න.
    /// # Example
    /// අංක 0 ට සමාන නම් එය පරිභෝජනය කරන්න.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // අනුකාරකයේ පළමු අයිතමය 0;එය පරිභෝජනය කරන්න.
    /// assert_eq!(iter.next_if_eq(&0), Some(0));
    /// // ආපසු ලබා දුන් ඊළඟ අයිතමය දැන් 1 වේ, එබැවින් `consume` `false` නැවත ලබා දෙනු ඇත.
    /// assert_eq!(iter.next_if_eq(&0), None);
    /// // `next_if_eq` `expected` ට සමාන නොවන්නේ නම් ඊළඟ අයිතමයේ වටිනාකම ඉතිරි කරයි.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if_eq<T>(&mut self, expected: &T) -> Option<I::Item>
    where
        T: ?Sized,
        I::Item: PartialEq<T>,
    {
        self.next_if(|next| next == expected)
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I> TrustedLen for Peekable<I> where I: TrustedLen {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S: Iterator, I: Iterator> SourceIter for Peekable<I>
where
    I: SourceIter<Source = S>,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // ආරක්ෂාව: අනාරක්ෂිත ශ්‍රිතය එකම අවශ්‍යතා සහිත අනාරක්ෂිත ක්‍රියාකාරිත්වයට යොමු කිරීම
        unsafe { SourceIter::as_inner(&mut self.iter) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I: InPlaceIterable> InPlaceIterable for Peekable<I> {}