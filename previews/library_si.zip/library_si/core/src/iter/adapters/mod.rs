use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// මෙම trait කොන්දේසි යටතේ අන්තර්ක්‍රියාකාරක-ඇඩැප්ටර නල මාර්ගයක ප්‍රභව වේදිකාවට සංක්‍රාන්ති ප්‍රවේශය සපයයි
/// * iterator ප්‍රභවය `S` විසින්ම `SourceIter<Source = S>` ක්‍රියාත්මක කරයි
/// * ප්‍රභවය සහ නල මාර්ග පාරිභෝගිකයා අතර නල මාර්ගයේ එක් එක් ඇඩැප්ටරය සඳහා මෙම trait බලය පැවරීම ක්‍රියාත්මක වේ.
///
/// ප්‍රභවය අයිති අයිටරේටර් ව්‍යුහයක් වන විට (පොදුවේ `IntoIter` ලෙස හැඳින්වේ) [`FromIterator`] ක්‍රියාත්මක කිරීම විශේෂීකරණය කිරීමට හෝ ඉරේටරයක් අර්ධ වශයෙන් අවසන් වූ පසු ඉතිරි මූලද්‍රව්‍ය නැවත ලබා ගැනීමට මෙය ප්‍රයෝජනවත් වේ.
///
///
/// ක්‍රියාවට නැංවීම සඳහා නල මාර්ගයක අභ්‍යන්තර ප්‍රභවයට ප්‍රවේශය අවශ්‍ය නොවන බව සලකන්න.රාජ්‍ය අතරමැදි ඇඩැප්ටරයක් නල මාර්ගයේ කොටසක් උනන්දුවෙන් තක්සේරු කර එහි අභ්‍යන්තර ගබඩාව ප්‍රභවයක් ලෙස හෙළි කරයි.
///
/// trait අනාරක්ෂිත බැවින් ක්‍රියාත්මක කරන්නන් අමතර ආරක්‍ෂිත ගුණාංග ආරක්ෂා කළ යුතුය.
/// විස්තර සඳහා [`as_inner`] බලන්න.
///
/// # Examples
///
/// අර්ධ වශයෙන් පරිභෝජනය කරන ලද ප්‍රභවයක් ලබා ගැනීම:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// අනුකාරක නල මාර්ගයක ප්‍රභව අවධිය.
    type Source: Iterator;

    /// ඉරේටර නල මාර්ගයක ප්‍රභවය ලබා ගන්න.
    ///
    /// # Safety
    ///
    /// ඇමතුමකින් ආදේශ නොකරන්නේ නම්, ක්‍රියාත්මක කිරීම ඔවුන්ගේ ජීවිත කාලය සඳහා එකම විකෘති යොමු කිරීමක් ලබා දිය යුතුය.
    /// ඇමතුම්කරුවන්ට යොමු කිරීම ප්‍රතිස්ථාපනය කළ හැක්කේ ඔවුන් නැවත ක්‍රියා කිරීම නැවැත්වූ විට සහ ප්‍රභවය නිස්සාරණය කිරීමෙන් පසුව අනුකාරක නල මාර්ගය අතහැර දැමූ විට පමණි.
    ///
    /// මෙයින් අදහස් කරන්නේ iterator ඇඩැප්ටරයන්ට පුනරාවර්තනයේදී වෙනස් නොවන ප්‍රභවය මත විශ්වාසය තැබිය හැකි නමුත් ඒවායේ Drop ක්‍රියාත්මක කිරීමේදී එය මත විශ්වාසය තැබිය නොහැකි බවයි.
    ///
    /// මෙම ක්‍රමය ක්‍රියාත්මක කිරීම යන්නෙන් අදහස් කරන්නේ ඇඩැප්ටරයන් ඔවුන්ගේ ප්‍රභවයට පුද්ගලික ප්‍රවේශය පමණක් අත්හරින අතර ඒවා ලැබිය හැක්කේ ක්‍රම ග්‍රාහක වර්ග මත පදනම් වූ ඇපකර මත පමණි.
    /// සීමිත ප්‍රවේශයක් නොමැතිකම නිසා ඇඩැප්ටරයන් එහි අභ්‍යන්තරයට ප්‍රවේශය ඇති විටදී පවා ප්‍රභවයේ පොදු API ආරක්ෂා කළ යුතුය.
    ///
    /// ඇමතුම් කරුවන් අනෙක් අතට ප්‍රභවය එහි පොදු ඒපීඅයි සමඟ අනුකූල වන ඕනෑම තත්වයක පවතිනු ඇතැයි අපේක්ෂා කළ යුතුය.
    /// විශේෂයෙන් ඇඩැප්ටරයක් අවශ්‍ය ප්‍රමාණයට වඩා වැඩි මූලද්‍රව්‍ය ප්‍රමාණයක් පරිභෝජනය කර ඇත.
    ///
    /// මෙම අවශ්‍යතාවයන්හි සමස්ත ඉලක්කය වන්නේ නල මාර්ගයක් භාවිතා කිරීමට පාරිභෝගිකයාට ඉඩ දීමයි
    /// * නැවතීම නතර කිරීමෙන් පසු ප්‍රභවයේ ඉතිරිව ඇති ඕනෑම දෙයක්
    /// * පරිභෝජන අනුකාරකයක් ඉදිරියට ගෙන යාමෙන් භාවිතයට නොගත් මතකය
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// යටින් ඇති iterator `Result::Ok` අගයන් නිපදවන තාක් කල් ප්‍රතිදානය නිපදවන iterator ඇඩැප්ටරය.
///
///
/// දෝෂයක් ඇති වුවහොත්, අනුකාරකය නතර වී දෝෂය ගබඩා වේ.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// දී ඇති අනුකාරකය `Result<T, _>` වෙනුවට `T` ලබා දුන් ආකාරයට සකසන්න.
/// ඕනෑම දෝෂයක් අභ්‍යන්තර අනුකාරකය නවත්වන අතර සමස්ත ප්‍රති result ලය දෝෂයක් වනු ඇත.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}