use crate::cmp;
use crate::fmt::{self, Debug};
use crate::iter::{DoubleEndedIterator, ExactSizeIterator, FusedIterator, Iterator};
use crate::iter::{InPlaceIterable, SourceIter, TrustedLen};

/// එකවර තවත් අනුකාරක දෙකක් පුනරාවර්තනය කරන අනුකාරකයක්.
///
/// මෙම `struct` නිර්මාණය කර ඇත්තේ [`Iterator::zip`] විසිනි.
/// වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
#[derive(Clone)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Zip<A, B> {
    a: A,
    b: B,
    // දර්ශකය, ලෙන් සහ a_len භාවිතා කරන්නේ සිප් හි විශේෂිත අනුවාදය පමණි
    index: usize,
    len: usize,
    a_len: usize,
}
impl<A: Iterator, B: Iterator> Zip<A, B> {
    pub(in crate::iter) fn new(a: A, b: B) -> Zip<A, B> {
        ZipImpl::new(a, b)
    }
    fn super_nth(&mut self, mut n: usize) -> Option<(A::Item, B::Item)> {
        while let Some(x) = Iterator::next(self) {
            if n == 0 {
                return Some(x);
            }
            n -= 1;
        }
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> Iterator for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        ZipImpl::next(self)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        ZipImpl::size_hint(self)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        ZipImpl::nth(self, n)
    }

    #[inline]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        // ආරක්ෂාව: `ZipImpl::__iterator_get_unchecked` එකම ආරක්ෂාව ඇත
        // `Iterator::__iterator_get_unchecked` ලෙස අවශ්‍යතා.
        unsafe { ZipImpl::get_unchecked(self, idx) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> DoubleEndedIterator for Zip<A, B>
where
    A: DoubleEndedIterator + ExactSizeIterator,
    B: DoubleEndedIterator + ExactSizeIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)> {
        ZipImpl::next_back(self)
    }
}

// Zip විශේෂීකරණය trait
#[doc(hidden)]
trait ZipImpl<A, B> {
    type Item;
    fn new(a: A, b: B) -> Self;
    fn next(&mut self) -> Option<Self::Item>;
    fn size_hint(&self) -> (usize, Option<usize>);
    fn nth(&mut self, n: usize) -> Option<Self::Item>;
    fn next_back(&mut self) -> Option<Self::Item>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator;
    // මෙය `Iterator::__iterator_get_unchecked` හා සමාන ආරක්ෂණ අවශ්‍යතා ඇත
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item
    where
        Self: Iterator + TrustedRandomAccess;
}

// ජෙනරල් සිප් impl
#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);
    default fn new(a: A, b: B) -> Self {
        Zip {
            a,
            b,
            index: 0, // unused
            len: 0,   // unused
            a_len: 0, // unused
        }
    }

    #[inline]
    default fn next(&mut self) -> Option<(A::Item, B::Item)> {
        let x = self.a.next()?;
        let y = self.b.next()?;
        Some((x, y))
    }

    #[inline]
    default fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.super_nth(n)
    }

    #[inline]
    default fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        let a_sz = self.a.len();
        let b_sz = self.b.len();
        if a_sz != b_sz {
            // A, b සමාන දිගට සකසන්න
            if a_sz > b_sz {
                for _ in 0..a_sz - b_sz {
                    self.a.next_back();
                }
            } else {
                for _ in 0..b_sz - a_sz {
                    self.b.next_back();
                }
            }
        }
        match (self.a.next_back(), self.b.next_back()) {
            (Some(x), Some(y)) => Some((x, y)),
            (None, None) => None,
            _ => unreachable!(),
        }
    }

    #[inline]
    default fn size_hint(&self) -> (usize, Option<usize>) {
        let (a_lower, a_upper) = self.a.size_hint();
        let (b_lower, b_upper) = self.b.size_hint();

        let lower = cmp::min(a_lower, b_lower);

        let upper = match (a_upper, b_upper) {
            (Some(x), Some(y)) => Some(cmp::min(x, y)),
            (Some(x), None) => Some(x),
            (None, Some(y)) => Some(y),
            (None, None) => None,
        };

        (lower, upper)
    }

    default unsafe fn get_unchecked(&mut self, _idx: usize) -> <Self as Iterator>::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: TrustedRandomAccess + Iterator,
    B: TrustedRandomAccess + Iterator,
{
    fn new(a: A, b: B) -> Self {
        let a_len = a.size();
        let len = cmp::min(a_len, b.size());
        Zip { a, b, index: 0, len, a_len }
    }

    #[inline]
    fn next(&mut self) -> Option<(A::Item, B::Item)> {
        if self.index < self.len {
            let i = self.index;
            self.index += 1;
            // ආරක්ෂාව: `i` `self.len` ට වඩා කුඩා වන අතර එමඟින් `self.a.len()` සහ `self.b.len()` වලට වඩා කුඩා වේ
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else if A::MAY_HAVE_SIDE_EFFECT && self.index < self.a_len {
            let i = self.index;
            self.index += 1;
            self.len += 1;
            // මූලික ක්‍රියාත්මක කිරීමේ විභව අතුරු ආබාධ සමඟ ගැලපෙන්න ආරක්ෂාව: අපි දැන් පරීක්ෂා කළේ `i` <`self.a.len()`
            //
            unsafe {
                self.a.__iterator_get_unchecked(i);
            }
            None
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len - self.index;
        (len, Some(len))
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        let delta = cmp::min(n, self.len - self.index);
        let end = self.index + delta;
        while self.index < end {
            let i = self.index;
            self.index += 1;
            if A::MAY_HAVE_SIDE_EFFECT {
                // ආරක්ෂාව: `delta` ගණනය කිරීම සඳහා `cmp::min` භාවිතය
                // `end` `self.len` ට වඩා කුඩා හෝ සමාන බව සහතික කරයි, එබැවින් `i` ද `self.len` ට වඩා කුඩා වේ.
                //
                unsafe {
                    self.a.__iterator_get_unchecked(i);
                }
            }
            if B::MAY_HAVE_SIDE_EFFECT {
                // ආරක්ෂාව: ඉහත ආකාරයටම.
                unsafe {
                    self.b.__iterator_get_unchecked(i);
                }
            }
        }

        self.super_nth(n - delta)
    }

    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        if A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT {
            let sz_a = self.a.size();
            let sz_b = self.b.size();
            // A, b සමාන දිගට සකසන්න, `next_back` හි පළමු ඇමතුම පමණක් මෙය සිදු කරන බවට වග බලා ගන්න, එසේ නොමැතිනම් `get_unchecked()` ඇමතීමෙන් පසු `self.next_back()` වෙත ඇමතුම් සඳහා ඇති සීමාව අපි බිඳ දමමු.
            //
            //
            if sz_a != sz_b {
                let sz_a = self.a.size();
                if A::MAY_HAVE_SIDE_EFFECT && sz_a > self.len {
                    for _ in 0..sz_a - self.len {
                        self.a.next_back();
                    }
                    self.a_len = self.len;
                }
                let sz_b = self.b.size();
                if B::MAY_HAVE_SIDE_EFFECT && sz_b > self.len {
                    for _ in 0..sz_b - self.len {
                        self.b.next_back();
                    }
                }
            }
        }
        if self.index < self.len {
            self.len -= 1;
            self.a_len -= 1;
            let i = self.len;
            // ආරක්ෂාව: `i` පෙර පැවති `self.len` අගයට වඩා කුඩා වේ,
            // එය `self.a.len()` සහ `self.b.len()` ට වඩා කුඩා හෝ සමාන වේ
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else {
            None
        }
    }

    #[inline]
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item {
        let idx = self.index + idx;
        // ආරක්ෂාව: අමතන්නා `Iterator::__iterator_get_unchecked` සඳහා වන කොන්ත්‍රාත්තුව තහවුරු කළ යුතුය.
        //
        unsafe { (self.a.__iterator_get_unchecked(idx), self.b.__iterator_get_unchecked(idx)) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> ExactSizeIterator for Zip<A, B>
where
    A: ExactSizeIterator,
    B: ExactSizeIterator,
{
}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<A, B> TrustedRandomAccess for Zip<A, B>
where
    A: TrustedRandomAccess,
    B: TrustedRandomAccess,
{
    const MAY_HAVE_SIDE_EFFECT: bool = A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT;
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A, B> FusedIterator for Zip<A, B>
where
    A: FusedIterator,
    B: FusedIterator,
{
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, B> TrustedLen for Zip<A, B>
where
    A: TrustedLen,
    B: TrustedLen,
{
}

// නිස්සාරණය කළ හැකි "source" ලෙස සිප් පුනරාවර්තනයේ වම් පැත්ත අත්තනෝමතික ලෙස තෝරා ගනී, ඒ දෙකම උත්සාහ කිරීමට negative ණ trait bounds අවශ්‍ය වේ
//
#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S, A, B> SourceIter for Zip<A, B>
where
    A: SourceIter<Source = S>,
    B: Iterator,
    S: Iterator,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // ආරක්ෂාව: අනාරක්ෂිත ශ්‍රිතය එකම අවශ්‍යතා සහිත අනාරක්ෂිත ක්‍රියාකාරිත්වයට යොමු කිරීම
        unsafe { SourceIter::as_inner(&mut self.a) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
// අයිතමයට සීමා වේ: සිප් විශ්වාසදායක රැන්ඩම් ඇක්සස් භාවිතය සහ ප්‍රභවය අතහැර දැමීම අතර අන්තර්ක්‍රියා අපැහැදිලි බැවින් පිටපත් කරන්න.
//
// ප්‍රභවය තාර්කිකව දියුණු කර ඇති වාර ගණන ආපසු ලබා දෙන අතිරේක ක්‍රමයක් (next()) ඇමතීමෙන් තොරව ප්‍රභවයේ ඉතිරි කොටස නිසි ලෙස අතහැර දැමීමට අවශ්‍ය වනු ඇත.
//
//
unsafe impl<A: InPlaceIterable, B: Iterator> InPlaceIterable for Zip<A, B> where A::Item: Copy {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Debug, B: Debug> Debug for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        ZipFmt::fmt(self, f)
    }
}

trait ZipFmt<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result;
}

impl<A: Debug, B: Debug> ZipFmt<A, B> for Zip<A, B> {
    default fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Zip").field("a", &self.a).field("b", &self.b).finish()
    }
}

impl<A: Debug + TrustedRandomAccess, B: Debug + TrustedRandomAccess> ZipFmt<A, B> for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // අප එය නැවත ආරම්භ කිරීමට පටන් ගත් පසු ඒවා අමුතු, අනාරක්ෂිත විය හැකි යැයි පවසන බැවින්, අඩංගු අනුකාරක වෙත fmt ඇමතීම * ආරක්ෂිත නොවේ.
        //
        f.debug_struct("Zip").finish()
    }
}

/// අහඹු ලෙස ප්‍රවේශ විය හැකි අයිතමයක් කාර්යක්ෂමව
///
/// # Safety
///
/// Iterator හි `size_hint` ඇමතීමට හරියටම හා ලාභදායී විය යුතුය.
///
/// `size` අභිබවා නොයනු ඇත.
///
/// `<Self as Iterator>::__iterator_get_unchecked` පහත සඳහන් කොන්දේසි සපුරා ඇත්නම් ඇමතුමට ආරක්ෂිත විය යුතුය.
///
/// 1. `0 <= idx` සහ `idx < self.size()`.
/// 2. `self: !Clone` නම්, `get_unchecked` එකම දර්ශකය සමඟ `self` හි එක් වරකට වඩා කැඳවනු නොලැබේ.
/// 3. `self.get_unchecked(idx)` ඇමතීමෙන් පසුව `next_back` කැඳවනු ලබන්නේ බොහෝ විට `self.size() - idx - 1` වාරයක් පමණි.
/// 4. `get_unchecked` ඇමතීමෙන් පසුව, `self` හි පහත සඳහන් ක්‍රම පමණක් කැඳවනු ලැබේ:
///     * `std::clone::Clone::clone()`
///     * `std::iter::Iterator::size_hint()`
///     * `std::iter::Iterator::next_back()`
///     * `std::iter::Iterator::__iterator_get_unchecked()`
///     * `std::iter::TrustedRandomAccess::size()`
///
/// තවද, මෙම කොන්දේසි සපුරා ඇති හෙයින්, එය සහතික කළ යුතුය:
///
/// * එය `size_hint` වෙතින් ආපසු ලබා දුන් අගය වෙනස් නොකරයි
/// * අවශ්‍ය traits ක්‍රියාත්මක කර ඇතැයි උපකල්පනය කරමින් `get_unchecked` ඇමතීමෙන් පසු `self` හි ඉහත ලැයිස්තුගත කර ඇති ක්‍රම ඇමතීම ආරක්ෂිත විය යුතුය.
///
/// * `get_unchecked` ඇමතීමෙන් පසු `self` අතහැර දැමීමද ආරක්ෂිත විය යුතුය.
///
///
///
///
#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
#[rustc_specialization_trait]
pub unsafe trait TrustedRandomAccess: Sized {
    // පහසුව සඳහා ක්‍රමය.
    fn size(&self) -> usize
    where
        Self: Iterator,
    {
        self.size_hint().0
    }
    /// `true` iterator මූලද්‍රව්‍යයක් ලබා ගන්නේ නම් අතුරු ආබාධ ඇති විය හැකිය.
    /// අභ්‍යන්තර අනුකාරක සැලකිල්ලට ගැනීමට මතක තබා ගන්න.
    const MAY_HAVE_SIDE_EFFECT: bool;
}

/// `Iterator::__iterator_get_unchecked` මෙන්, නමුත් `U: TrustedRandomAccess` බව දැන ගැනීමට සම්පාදකයාට අවශ්‍ය නොවේ.
///
///
/// ## Safety
///
/// එකම අවශ්‍යතා `get_unchecked` කෙලින්ම අමතන්න.
#[doc(hidden)]
pub(in crate::iter::adapters) unsafe fn try_get_unchecked<I>(it: &mut I, idx: usize) -> I::Item
where
    I: Iterator,
{
    // ආරක්ෂාව: අමතන්නා `Iterator::__iterator_get_unchecked` සඳහා වන කොන්ත්‍රාත්තුව තහවුරු කළ යුතුය.
    //
    unsafe { it.try_get_unchecked(idx) }
}

unsafe trait SpecTrustedRandomAccess: Iterator {
    /// `Self: TrustedRandomAccess` නම්, `Iterator::__iterator_get_unchecked(self, index)` ඇමතීම ආරක්ෂිත විය යුතුය.
    ///
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item;
}

unsafe impl<I: Iterator> SpecTrustedRandomAccess for I {
    default unsafe fn try_get_unchecked(&mut self, _: usize) -> Self::Item {
        panic!("Should only be called on TrustedRandomAccess iterators");
    }
}

unsafe impl<I: Iterator + TrustedRandomAccess> SpecTrustedRandomAccess for I {
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item {
        // ආරක්ෂාව: අමතන්නා `Iterator::__iterator_get_unchecked` සඳහා වන කොන්ත්‍රාත්තුව තහවුරු කළ යුතුය.
        //
        unsafe { self.__iterator_get_unchecked(index) }
    }
}