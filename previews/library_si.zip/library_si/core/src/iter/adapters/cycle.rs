use crate::{iter::FusedIterator, ops::Try};

/// නිමක් නැතිව පුනරාවර්තනය වන අනුකාරකය.
///
/// මෙම `struct` [`Iterator`] හි [`cycle`] ක්‍රමය මඟින් නිර්මාණය කර ඇත.
/// වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // චක්‍රීය අනුකාරකය හිස් හෝ අනන්ත වේ
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // වත්මන් අනුකාරකය සම්පූර්ණයෙන්ම නැවත ක්‍රියාත්මක කරන්න.
        // `self.orig` නොමැති විටදී පවා `self.iter` හිස් විය හැකි බැවින් මෙය අවශ්‍ය වේ
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // සම්පූර්ණ චක්‍රයක් සම්පූර්ණ කරන්න, චක්‍රීය අනුකාරකය හිස්ද නැද්ද යන්න පිළිබඳව සොයා බැලීම.
        // අසීමිත පුඩුවක් වැළැක්වීම සඳහා හිස් අනුකාරකයක් තිබේ නම් අපි කලින් ආපසු යා යුතුය
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // `fold` අභිබවා යාමක් නැත, මන්ද `fold` `Cycle` සඳහා එතරම් තේරුමක් නැති නිසා අපට පෙරනිමියට වඩා හොඳ කිසිවක් කළ නොහැක.
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}