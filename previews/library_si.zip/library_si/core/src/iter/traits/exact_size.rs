/// එහි නිශ්චිත දිග දන්නා iterator.
///
/// බොහෝ [ඉතරේටර්] ඔවුන් කොපමණ වාරයක් පුනරාවර්තනය වේ දැයි නොදනී, නමුත් සමහරු එසේ කරති.
/// එය කොපමණ වාරයක් පුනරාවර්තනය කළ හැකිදැයි අනුකාරකයකු දන්නේ නම්, එම තොරතුරු සඳහා ප්‍රවේශය ලබා දීම ප්‍රයෝජනවත් වේ.
/// නිදසුනක් ලෙස, ඔබට පසුපසට නැවත යෙදීමට අවශ්‍ය නම්, හොඳ ආරම්භයක් වන්නේ අවසානය කොතැනදැයි දැන ගැනීමයි.
///
/// `ExactSizeIterator` ක්‍රියාත්මක කිරීමේදී, ඔබ [`Iterator`] ද ක්‍රියාත්මක කළ යුතුය.
/// එසේ කරන විට, [`Iterator::size_hint`]*ක්‍රියාත්මක කිරීම* නැවත ක්‍රියාකරුවාගේ ප්‍රමාණය නැවත ලබා දිය යුතුය.
///
/// [`len`] ක්‍රමයට පෙරනිමි ක්‍රියාත්මක කිරීමක් ඇත, එබැවින් ඔබ සාමාන්‍යයෙන් එය ක්‍රියාත්මක නොකළ යුතුය.
/// කෙසේ වෙතත්, ඔබට පෙරනිමියට වඩා ක්‍රියාකාරී කාර්ය සාධනයක් සැපයීමට හැකි වනු ඇත, එබැවින් මෙම අවස්ථාවේදී එය ඉක්මවා යාම අර්ථවත් කරයි.
///
///
/// මෙම trait ආරක්ෂිත trait බව සලකන්න. එනිසා ආපසු ලබා දුන් දිග නිවැරදි බවට *සහතික කළ නොහැකි* සහ * සහතික කළ නොහැක.
/// මෙයින් අදහස් කරන්නේ `unsafe` කේතය ** [`Iterator::size_hint`] හි නිරවද්‍යතාවය මත රඳා නොසිටිය යුතු බවයි.
/// අස්ථායී සහ අනාරක්ෂිත [`TrustedLen`](super::marker::TrustedLen) trait මෙම අමතර සහතිකය ලබා දෙයි.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// මූලික භාවිතය:
///
/// ```
/// // සීමිත පරාසයක් එය කොපමණ වාර ගණනක් පුනරාවර්තනය වේදැයි හරියටම දනී
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// [module-level docs] හි, අපි [`Iterator`] ක් ක්‍රියාත්මක කළෙමු, `Counter`.
/// ඒ සඳහා `ExactSizeIterator` ද ක්‍රියාත්මක කරමු:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // ඉතිරි පුනරාවර්තන ගණන අපට පහසුවෙන් ගණනය කළ හැකිය.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // දැන් අපට එය භාවිතා කළ හැකිය!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// අනුකාරකයේ නිශ්චිත දිග ලබා දෙයි.
    ///
    /// ක්‍රියාවට නැංවීම මඟින් [`None`] ආපසු පැමිණීමට පෙර, iterator විසින් [`Some(T)`] අගයට වඩා `len()` ගුණයක් නැවත ලබා දෙන බව සහතික කරයි.
    ///
    /// මෙම ක්‍රමයට පෙරනිමි ක්‍රියාත්මක කිරීමක් ඇත, එබැවින් ඔබ සාමාන්‍යයෙන් එය කෙලින්ම ක්‍රියාත්මක නොකළ යුතුය.
    /// කෙසේ වෙතත්, ඔබට වඩාත් කාර්යක්ෂම ක්‍රියාත්මක කිරීමක් සැපයිය හැකි නම්, ඔබට එය කළ හැකිය.
    /// උදාහරණයක් සඳහා [trait-level] ලියකියවිලි බලන්න.
    ///
    /// මෙම ශ්‍රිතයට [`Iterator::size_hint`] ශ්‍රිතයට සමාන ආරක්ෂණ සහතික ඇත.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// // සීමිත පරාසයක් එය කොපමණ වාර ගණනක් පුනරාවර්තනය වේදැයි හරියටම දනී
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: මෙම ප්‍රකාශය ඕනෑවට වඩා ආරක්ෂාකාරී වන නමුත් එය ආක්‍රමණිකයා පරීක්ෂා කරයි
        // trait මගින් සහතික කර ඇත.
        // මෙම trait rust-අභ්‍යන්තර නම්, අපට debug_assert භාවිතා කළ හැකිය;assert_eq!සියලුම Rust පරිශීලක ක්‍රියාත්මක කිරීම් ද පරීක්ෂා කරනු ඇත.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// අනුකාරකය හිස් නම් `true` ලබා දෙයි.
    ///
    /// මෙම ක්‍රමයට [`ExactSizeIterator::len()`] භාවිතා කර පෙරනිමි ක්‍රියාත්මක කිරීමක් ඇත, එබැවින් ඔබට එය ක්‍රියාත්මක කිරීමට අවශ්‍ය නොවේ.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}