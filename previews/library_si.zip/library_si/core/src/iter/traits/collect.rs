/// [`Iterator`] වෙතින් පරිවර්තනය.
///
/// වර්ගයක් සඳහා `FromIterator` ක්‍රියාත්මක කිරීමෙන්, එය අනුකාරකයකින් එය නිර්මාණය කරන්නේ කෙසේදැයි ඔබ අර්ථ දක්වයි.
/// යම් ආකාරයක එකතුවක් විස්තර කරන වර්ග සඳහා මෙය පොදු වේ.
///
/// [`FromIterator::from_iter()`] ඉතා කලාතුරකින් පැහැදිලිව හැඳින්වෙන අතර ඒ වෙනුවට [`Iterator::collect()`] ක්‍රමය හරහා භාවිතා වේ.
///
/// තවත් උදාහරණ සඳහා [`Iterator::collect()`]'s ප්‍රලේඛනය බලන්න.
///
/// මෙයද බලන්න: [`IntoIterator`].
///
/// # Examples
///
/// මූලික භාවිතය:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// ව්‍යංගයෙන් `FromIterator` භාවිතා කිරීමට [`Iterator::collect()`] භාවිතා කිරීම:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// ඔබේ වර්ගය සඳහා `FromIterator` ක්‍රියාත්මක කිරීම:
///
/// ```
/// use std::iter::FromIterator;
///
/// // නියැදි එකතුවක්, එය Vec ට වඩා එතීමකි<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // අපි එයට ක්‍රම කිහිපයක් ලබා දෙමු, එවිට අපට එකක් නිර්මාණය කර එයට දේවල් එකතු කළ හැකිය.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // අපි FromIterator ක්‍රියාත්මක කරන්නෙමු
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // දැන් අපට නව අනුකාරකයක් සෑදිය හැකිය ...
/// let iter = (0..5).into_iter();
///
/// // ... සහ එයින් MyCollection එකක් සාදන්න
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // වැඩ එකතු කරන්න!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// අනුකාරකයකින් අගයක් නිර්මාණය කරයි.
    ///
    /// වැඩි විස්තර සඳහා [module-level documentation] බලන්න.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// [`Iterator`] බවට පරිවර්තනය කිරීම.
///
/// වර්ගයක් සඳහා `IntoIterator` ක්‍රියාත්මක කිරීමෙන්, එය අනුකාරකයක් බවට පරිවර්තනය කරන්නේ කෙසේදැයි ඔබ අර්ථ දක්වයි.
/// යම් ආකාරයක එකතුවක් විස්තර කරන වර්ග සඳහා මෙය පොදු වේ.
///
/// `IntoIterator` ක්‍රියාත්මක කිරීමේ එක් වාසියක් නම් ඔබේ වර්ගය [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) වනු ඇත.
///
///
/// මෙයද බලන්න: [`FromIterator`].
///
/// # Examples
///
/// මූලික භාවිතය:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// ඔබේ වර්ගය සඳහා `IntoIterator` ක්‍රියාත්මක කිරීම:
///
/// ```
/// // නියැදි එකතුවක්, එය Vec ට වඩා එතීමකි<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // අපි එයට ක්‍රම කිහිපයක් ලබා දෙමු, එවිට අපට එකක් නිර්මාණය කර එයට දේවල් එකතු කළ හැකිය.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // අපි IntoIterator ක්‍රියාත්මක කරන්නෙමු
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // දැන් අපට නව එකතුවක් කළ හැකිය ...
/// let mut c = MyCollection::new();
///
/// // ... එයට දේවල් කිහිපයක් එකතු කරන්න ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... ඉන්පසු එය අනුකාරකයක් බවට පත් කරන්න:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// `IntoIterator` trait bound ලෙස භාවිතා කිරීම සාමාන්‍ය දෙයකි.මෙය ආදාන එකතු කිරීමේ වර්ගය වෙනස් කිරීමට ඉඩ දෙයි, එය තවමත් අනුකාරකයක් වන තාක් කල්.
/// සීමා කිරීමෙන් අමතර සීමාවන් නියම කළ හැකිය
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// නැවත නැවත යෙදෙන මූලද්‍රව්‍ය වර්ගය.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// අපි මෙය කුමන ආකාරයේ අනුකාරකයක් බවට පත් කරන්නේද?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// අගයකින් අනුකාරකයක් සාදයි.
    ///
    /// වැඩි විස්තර සඳහා [module-level documentation] බලන්න.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// අනුකාරකයේ අන්තර්ගතය සමඟ එකතුවක් දිගු කරන්න.
///
/// අනුකාරකයන් සාරධර්ම මාලාවක් නිපදවන අතර එකතු කිරීම් ද සාරධර්ම මාලාවක් ලෙස සිතිය හැකිය.
/// `Extend` trait මෙම පරතරය පියවන අතර, එම අනුකාරකයේ අන්තර්ගතය ඇතුළත් කිරීමෙන් එකතුවක් දීර් extend කිරීමට ඔබට ඉඩ සලසයි.
/// දැනටමත් පවතින යතුරක් සමඟ එකතුවක් දිගු කරන විට, එම ප්‍රවේශය යාවත්කාලීන වේ, හෝ සමාන යතුරු සහිත බහු ඇතුළත් කිරීම් වලට ඉඩ දෙන එකතු කිරීම් වලදී, එම ප්‍රවේශය ඇතුල් කරනු ලැබේ.
///
///
/// # Examples
///
/// මූලික භාවිතය:
///
/// ```
/// // ඔබට සමහර අක්ෂර සමඟ නූලක් දිගු කළ හැකිය:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// `Extend` ක්‍රියාත්මක කිරීම:
///
/// ```
/// // නියැදි එකතුවක්, එය Vec ට වඩා එතීමකි<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // අපි එයට ක්‍රම කිහිපයක් ලබා දෙමු, එවිට අපට එකක් නිර්මාණය කර එයට දේවල් එකතු කළ හැකිය.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // MyCollection හි i32s ලැයිස්තුවක් ඇති බැවින්, අපි i32 සඳහා Extend ක්‍රියාත්මක කරමු
/// impl Extend<i32> for MyCollection {
///
///     // කොන්ක්‍රීට් වර්ගයේ අත්සන සමඟ මෙය ටිකක් සරල ය: අපට i32s ලබා දෙන ඉටරේටරයක් බවට පත් කළ හැකි ඕනෑම දෙයක් දිගු කිරීම ලෙස හැඳින්විය හැකිය.
///     // MyCollection තුළට දැමීමට අපට i32s අවශ්‍ය නිසා.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // ක්‍රියාත්මක කිරීම ඉතා සරල ය: iterator හරහා ලූපය සහ add() එක් එක් මූලද්‍රව්‍යය අපටම වේ.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // අපගේ එකතුව තවත් අංක තුනකින් දීර් extend කරමු
/// c.extend(vec![1, 2, 3]);
///
/// // අපි මෙම මූලද්‍රව්‍යයන් අවසානයට එකතු කර ඇත්තෙමු
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// අනුකාරකයේ අන්තර්ගතය සමඟ එකතුවක් දිගු කරයි.
    ///
    /// මෙම trait සඳහා අවශ්‍ය එකම ක්‍රමය මෙය බැවින්, [trait-level] ලියකියවිලි වැඩි විස්තර අඩංගු වේ.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// // ඔබට සමහර අක්ෂර සමඟ නූලක් දිගු කළ හැකිය:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// හරියටම එක් අංගයක් සමඟ එකතුවක් දිගු කරයි.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// දී ඇති අතිරේක මූලද්‍රව්‍ය ගණන සඳහා එකතුවක ධාරිතාව සංචිත කිරීම.
    ///
    /// පෙරනිමි ක්‍රියාත්මක කිරීම කිසිවක් නොකරයි.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}