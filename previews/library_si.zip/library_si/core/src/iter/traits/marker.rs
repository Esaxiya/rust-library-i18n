/// වෙහෙසට පත්වන විට සෑම විටම `None` ලබා දෙන අනුකාරකයක්.
///
/// `None` නැවත ලබා දුන් විලයන iterator එකකට ඊළඟට ඇමතීමෙන් [`None`] නැවත ලබා දීමට සහතික වේ.
/// මෙම trait [`Iterator::fuse()`] ප්‍රශස්තිකරණයට ඉඩ සලසන බැවින් මේ ආකාරයට හැසිරෙන සියලුම ක්‍රියාකාරීන් විසින් ක්‍රියාත්මක කළ යුතුය.
///
///
/// Note: පොදුවේ ගත් කල, ඔබට විලයන අනුකාරකයක් අවශ්‍ය නම් සාමාන්‍ය සීමාවන් තුළ `FusedIterator` භාවිතා නොකළ යුතුය.
/// ඒ වෙනුවට, ඔබ නැවත ක්‍රියාකරුට [`Iterator::fuse()`] අමතන්න.
/// අනුකාරකය දැනටමත් විලයනය වී ඇත්නම්, අතිරේක [`Fuse`] එතීම කාර්ය සාධන ද .ුවමක් නොමැතිව විවෘත කිරීමක් වනු ඇත.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Size_hint භාවිතයෙන් නිවැරදි දිගක් වාර්තා කරන iterator.
///
/// අනුකාරකය ප්‍රමාණාත්මක ඉඟියක් වාර්තා කරයි, එය හරියටම (පහළ මායිම ඉහළ සීමාවට සමාන වේ), හෝ ඉහළ මායිම [`None`] වේ.
///
/// ඉහළ සීමාව [`None`] විය යුත්තේ සත්‍ය iterator දිග [`usize::MAX`] ට වඩා විශාල නම් පමණි.
/// එවැනි අවස්ථාවක, පහළ මායිම [`usize::MAX`] විය යුතුය, එහි ප්‍රති X ලයක් ලෙස `(usize::MAX, None)` හි [`Iterator::size_hint()`] වේ.
///
/// අනුකාරකය විසින් එය වාර්තා කළ මූලද්‍රව්‍ය ගණන හරියටම නිපදවිය යුතුය.
///
/// # Safety
///
/// මෙම trait ක්‍රියාත්මක කළ යුත්තේ කොන්ත්‍රාත්තුව තහවුරු කළ විට පමණි.
/// මෙම trait හි පාරිභෝගිකයින් [`Iterator::size_hint()`]’s ඉහළ මායිම පරීක්ෂා කළ යුතුය.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// කිසියම් අයිතමයක් නිපදවීමේදී එහි යටි [`SourceIter`] වෙතින් අවම වශයෙන් එක් මූලද්‍රව්‍යයක්වත් ගෙන ඇති බව අනුකාරකයෙකි.
///
/// අනුකාරකය ඉදිරියට ගෙන යන ඕනෑම ක්‍රමයක් ඇමතීම, උදා
/// [`next()`] හෝ [`try_fold()`], සෑම පියවරක් සඳහාම අවම වශයෙන් එක් අගයක් වත් අනුකාරකයේ යටින් පවතින ප්‍රභවයෙන් පිටතට ගෙන ගොස් ඇති අතර, ප්‍රභවයේ ව්‍යුහාත්මක බාධක එවැනි ඇතුළු කිරීමකට ඉඩ දෙනු ඇතැයි උපකල්පනය කරමින්, අනුකාරක දාමයේ ප්‍රති result ලය එහි ස්ථානයට ඇතුළත් කළ හැකිය.
///
/// වෙනත් වචන වලින් කිවහොත්, මෙම trait මඟින් දැක්වෙන්නේ ඉරේටර නල මාර්ගයක් තැනින් තැන එකතු කළ හැකි බවයි.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}