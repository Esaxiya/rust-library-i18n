use crate::ops::{ControlFlow, Try};

/// දෙපැත්තෙන්ම මූලද්‍රව්‍ය ලබා දිය හැකි අනුකාරකයක්.
///
/// `DoubleEndedIterator` ක්‍රියාත්මක කරන දෙයකට [`Iterator`] ක්‍රියාත්මක කරන දෙයකට වඩා එක් අමතර හැකියාවක් ඇත: පිටුපසින් මෙන්ම ඉදිරිපසින් ද අයිතමය ගැනීමට ඇති හැකියාව.
///
///
/// පසුපසට හා පසුපසට යන දෙකම එකම පරාසයක වැඩ කරන අතර ඒවා හරස් නොකරන්න: ඒවා මැදදී හමු වූ විට නැවතීම අවසන් වේ.
///
/// [`Iterator`] ප්‍රොටෝකෝලය හා සමාන ආකාරයකින්, `DoubleEndedIterator` විසින් [`next_back()`] වෙතින් [`None`] ආපසු ලබා දුන් පසු, එය නැවත ඇමතීමෙන් [`Some`] නැවත ලබා දිය හැකිය.
/// [`next()`] සහ [`next_back()`] මේ සඳහා එකිනෙකට හුවමාරු වේ.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// මූලික භාවිතය:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// අනුකාරකයේ කෙළවරේ සිට මූලද්‍රව්‍යයක් ඉවත් කර ආපසු ලබා දේ.
    ///
    /// තවත් මූලද්රව්ය නොමැති විට `None` ලබා දෙයි.
    ///
    /// [trait-level] ලියකියවිලි වැඩි විස්තර අඩංගු වේ.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// `DoubleEndedIterator` හි ක්‍රම මඟින් ලබා දෙන මූලද්‍රව්‍ය [Iterator`] ගේ ක්‍රම මගින් ලබා දෙන ඒවාට වඩා වෙනස් විය හැකිය:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// `n` මූලද්‍රව්‍ය මඟින් පිටුපස සිට අනුකාරකය ඉදිරියට ගෙන යයි.
    ///
    /// `advance_back_by` යනු [`advance_by`] හි ප්‍රතිලෝම අනුවාදයයි.මෙම ක්‍රමය [`None`] හමු වන තෙක් [`next_back`] මූලද්‍රව්‍ය පිටුපස සිට [`next_back`] ඇමතීමෙන් `n` මූලද්‍රව්‍යයන් උනන්දුවෙන් මඟ හරිනු ඇත.
    ///
    /// `advance_back_by(n)` `n` මූලද්‍රව්‍ය මගින් iterator සාර්ථකව ඉදිරියට ගියහොත් [`Ok(())`] හෝ [`None`] හමු වුවහොත් [`Err(k)`], එහිදී `k` යනු මූලද්‍රව්‍ය ඉවර වීමට පෙර iterator විසින් දියුණු කරන ලද මූලද්‍රව්‍ය ගණන වේ (එනම්
    /// අනුකාරකයේ දිග).
    /// `k` සෑම විටම `n` ට වඩා අඩු බව සලකන්න.
    ///
    /// `advance_back_by(0)` ඇමතීමෙන් කිසිදු මූලද්‍රව්‍යයක් පරිභෝජනය නොකරන අතර සෑම විටම [`Ok(())`] ආපසු ලබා දේ.
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // `&3` පමණක් මඟ හැරුණි
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// අනුකාරකයේ කෙළවරේ සිට `n` මූලද්‍රව්‍යය ලබා දෙයි.
    ///
    /// මෙය අත්‍යවශ්‍යයෙන්ම [`Iterator::nth()`] හි ආපසු හරවන ලද අනුවාදය වේ.
    /// බොහෝ සුචිගත කිරීමේ මෙහෙයුම් මෙන්, ගණනය ආරම්භ වන්නේ ශුන්‍යයෙන් වන අතර, එබැවින් `nth_back(0)` පළමු අගය අවසානයේ සිට, `nth_back(1)` දෙවැන්න සහ යනාදිය ලබා දෙයි.
    ///
    ///
    /// ආපසු එන මූලද්‍රව්‍යය ඇතුළුව අවසානය සහ ආපසු එන මූලද්‍රව්‍යය අතර ඇති සියලුම මූලද්‍රව්‍ය පරිභෝජනය කරන බව සලකන්න.
    /// `nth_back(0)` එකම අනුකාරකයට කිහිප වතාවක් ඇමතීමෙන් විවිධ මූලද්‍රව්‍ය නැවත ලැබෙනු ඇති බව මින් අදහස් වේ.
    ///
    /// `nth_back()` `n` iterator හි දිගට වඩා වැඩි හෝ සමාන නම් [`None`] නැවත ලබා දෙනු ඇත.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// `nth_back()` කිහිප වතාවක් ඇමතීමෙන් iterator පෙරළා නොගනී:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// `n + 1` ට වඩා අඩු මූලද්‍රව්‍ය තිබේ නම් `None` නැවත ලබා දීම:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// මෙය [`Iterator::try_fold()`] හි ප්‍රතිලෝම අනුවාදය වේ: එය අනුකාරකයේ පිටුපස සිට ආරම්භ වන මූලද්‍රව්‍ය ගනී.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // එය කෙටි පරිපථයක් බැවින් ඉතිරි මූලද්‍රව්‍ය තවමත් අනුකාරකය හරහා ලබා ගත හැකිය.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// පිටුපස සිට ඇරඹෙන, ඒකකයෙහි මූලද්‍රව්‍ය තනි, අවසාන අගයකට අඩු කරන iterator ක්‍රමයක්.
    ///
    /// මෙය [`Iterator::fold()`] හි ප්‍රතිලෝම අනුවාදය වේ: එය අනුකාරකයේ පිටුපස සිට ආරම්භ වන මූලද්‍රව්‍ය ගනී.
    ///
    /// `rfold()` තර්ක දෙකක් ගනී: ආරම්භක අගය, සහ තර්ක දෙකක් සහිත වසා දැමීම: 'accumulator' සහ මූලද්‍රව්‍යයකි.
    /// වසා දැමීම මඟින් ඊළඟ පුනරාවර්තනය සඳහා සමුච්චයකරුවාට තිබිය යුතු අගය ලබා දෙයි.
    ///
    /// ආරම්භක අගය යනු පළමු ඇමතුමේ සමුච්චයකරුවාට ඇති අගයයි.
    ///
    /// අනුකාරකයේ සෑම මූලද්‍රව්‍යයක් සඳහාම මෙම වසා දැමීම යෙදීමෙන් පසුව, `rfold()` සමුච්චය නැවත ලබා දෙයි.
    ///
    /// මෙම මෙහෙයුම සමහර විට 'reduce' හෝ 'inject' ලෙස හැඳින්වේ.
    ///
    /// ඔබට යමක් එකතුවක් ඇති විට එය නැවීම ප්‍රයෝජනවත් වන අතර එයින් තනි වටිනාකමක් නිපදවීමට අවශ්‍ය වේ.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // a හි සියලුම මූලද්‍රව්‍යයන්ගේ එකතුව
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// මෙම උදාහරණය ආරම්භක අගයකින් ආරම්භ කර එක් එක් මූලද්‍රව්‍යයන් පිටුපස සිට ඉදිරිපස දක්වා ඉදිරියට ගෙන යයි:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// පුරෝකථනයක් තෘප්තිමත් කරන පිටුපස සිට අනුකාරකයේ මූලද්‍රව්‍යයක් සෙවීම.
    ///
    /// `rfind()` `true` හෝ `false` ආපසු ලබා දෙන වසා දැමීමක් ගනී.
    /// එය අවසානයේ සිට ඇරඹෙන එක් එක් මූලද්‍රව්‍යයට මෙම වසා දැමීම අදාළ වන අතර, ඔවුන්ගෙන් කිසිවෙකු `true` ආපසු ලබා දෙන්නේ නම්, `rfind()` [`Some(element)`] ආපසු ලබා දෙයි.
    /// ඔවුන් සියල්ලම `false` ආපසු ලබා දෙන්නේ නම්, එය [`None`] ආපසු ලබා දෙයි.
    ///
    /// `rfind()` කෙටි පරිපථයකි;වෙනත් වචන වලින් කිවහොත්, වසා දැමීම `true` ආපසු පැමිණි විගස එය සැකසීම නවත්වනු ඇත.
    ///
    /// `rfind()` යොමු කිරීමක් ගන්නා නිසාත්, බොහෝ අනුකාරකයන් යොමු කිරීම් වලට වඩා පුනරාවර්තනය වන නිසාත්, මෙය තර්කය ද්විත්ව යොමු කිරීමක් වන ව්‍යාකූල තත්වයකට මඟ පාදයි.
    ///
    /// `&&x` සමඟ පහත උදාහරණ වලින් ඔබට මෙම බලපෑම දැකිය හැකිය.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// පළමු `true` හි නතර වීම:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // තවත් මූලද්‍රව්‍යයන් ඇති බැවින් අපට තවමත් `iter` භාවිතා කළ හැකිය.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}