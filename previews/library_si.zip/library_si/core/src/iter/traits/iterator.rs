// ign-tidy-filelength මෙම ගොනුව සම්පූර්ණයෙන්ම පාහේ `Iterator` හි අර්ථ දැක්වීමෙන් සමන්විත වේ.
// අපට එය බහු ගොනු වලට බෙදිය නොහැක.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// අනුකාරක සමඟ කටයුතු කිරීම සඳහා අතුරු මුහුණතක්.
///
/// trait හි ප්‍රධාන අනුකාරකය මෙයයි.
/// සාමාන්‍යයෙන් iterator සංකල්පය පිළිබඳ වැඩි විස්තර සඳහා කරුණාකර [module-level documentation] බලන්න.
/// විශේෂයෙන්, ඔබට [implement `Iterator`][impl] කරන්නේ කෙසේදැයි දැන ගැනීමට අවශ්‍ය විය හැකිය.
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// නැවත නැවත යෙදෙන මූලද්‍රව්‍ය වර්ගය.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// අනුකාරකය ඉදිරියට ගෙන ඊළඟ අගය ලබා දෙයි.
    ///
    /// පුනරාවර්තනය අවසන් වූ විට [`None`] ලබා දෙයි.
    /// තනි පුනරාවර්තක ක්‍රියාවට නැංවීම නැවත ආරම්භ කිරීම සඳහා තෝරා ගත හැකි අතර, එබැවින් `next()` නැවත ඇමතීමෙන් යම් අවස්ථාවක දී [`Some(Item)`] නැවත ලබා දීමට පටන් ගත හැකිය.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // next() වෙත ඇමතුමක් ඊළඟ අගය ලබා දෙයි ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... ඉන්පසු කිසිවක් අවසන් වූ පසු කිසිවක් නැත.
    /// assert_eq!(None, iter.next());
    ///
    /// // තවත් ඇමතුම් `None` නැවත ලබා දිය හැකිය.මෙන්න, ඔවුන් සෑම විටම එසේ කරනු ඇත.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// අනුකාරකයේ ඉතිරි දිගෙහි සීමාවන් ලබා දෙයි.
    ///
    /// නිශ්චිතවම, `size_hint()` පළමු මූලද්‍රව්‍යය පහළ මායිම වන අතර දෙවන මූලද්‍රව්‍යය ඉහළ මායිම වේ.
    ///
    /// ආපසු ලබා දෙන ටුපල් හි දෙවන භාගය [`විකල්පය]] <<` [`භාවිතා කරන්න]]`> `වේ.
    /// මෙහි [`None`] යන්නෙන් අදහස් කරන්නේ එක්කෝ ඉහළ මායිමක් නොමැති බව හෝ ඉහළ මායිම [`usize`] ට වඩා විශාල බවයි.
    ///
    /// # ක්‍රියාත්මක කිරීමේ සටහන්
    ///
    /// අනුකාරක ක්‍රියාත්මක කිරීම මඟින් ප්‍රකාශිත මූලද්‍රව්‍ය ගණන ලබා දෙන බව බලාත්මක නොවේ.දෝෂ සහිත අනුකාරකයක් පහළ මායිමට වඩා අඩු හෝ මූලද්‍රව්‍යවල ඉහළ සීමාවට වඩා වැඩි yield ලදාවක් ලබා දිය හැකිය.
    ///
    /// `size_hint()` මූලික වශයෙන් අදහස් කරන්නේ අනුකාරකයේ මූලද්‍රව්‍ය සඳහා ඉඩ වෙන් කිරීම වැනි ප්‍රශස්තිකරණය සඳහා භාවිතා කිරීමට ය, නමුත් උදා: විශ්වාස නොකළ යුතුය, අනාරක්ෂිත කේතයේ මායිම් චෙක්පත් මඟහරින්න.
    /// `size_hint()` වැරදි ලෙස ක්‍රියාත්මක කිරීම මතක ආරක්ෂණ උල්ලං to නයන්ට තුඩු නොදිය යුතුය.
    ///
    /// එයින් කියැවෙන්නේ ක්‍රියාත්මක කිරීම නිවැරදි තක්සේරුවක් සැපයිය යුතු අතර එසේ නොවුවහොත් එය trait හි ප්‍රොටෝකෝලය උල්ලං be නය කිරීමක් වනු ඇති බවයි.
    ///
    /// පෙරනිමි ක්‍රියාත්මක කිරීම මඟින් `(0,` [`කිසිවක් නැත]]`) `ඕනෑම ක්‍රියාකාරකයෙකුට නිවැරදි වේ.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// වඩාත් සංකීර්ණ උදාහරණයක්:
    ///
    /// ```
    /// // ඉරට්ටේ සංඛ්‍යා ශුන්‍යයේ සිට දහය දක්වා.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // අපි ශුන්‍යයේ සිට දස ගුණයක් දක්වා පුනරාවර්තනය විය හැකිය.
    /// // filter() ක්‍රියාත්මක නොකර එය හරියටම පහක් බව දැන සිටීම.
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // chain() සමඟ තවත් අංක පහක් එකතු කරමු
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // දැන් සීමාවන් දෙකම පහකින් වැඩි කර ඇත
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// ඉහළ සීමාවක් සඳහා `None` නැවත ලබා දීම:
    ///
    /// ```
    /// // අසීමිත පුනරාවර්තකයට ඉහළ මායිමක් නොමැති අතර හැකි උපරිම පහළ සීමාව ඇත
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// අනුකාරකය පරිභෝජනය කරයි, පුනරාවර්තන ගණන ගණනය කර එය ආපසු ලබා දේ.
    ///
    /// මෙම ක්‍රමය [`None`] හමු වන තෙක් [`next`] නැවත නැවත අමතනු ඇත, එය [`Some`] දුටු වාර ගණන නැවත ලබා දෙයි.
    /// අනුකාරකයට කිසිදු මූලද්‍රව්‍යයක් නොතිබුණද අවම වශයෙන් එක් වරක්වත් [`next`] ඇමතිය යුතු බව සලකන්න.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # පිටාර ගැලීමේ හැසිරීම
    ///
    /// මෙම ක්‍රමය පිටාර ගැලීම් වලින් ආරක්ෂා නොවේ, එබැවින් [`usize::MAX`] ට වඩා වැඩි මූලද්‍රව්‍යයක් සහිත ඉරේටරයක මූලද්‍රව්‍ය ගණනය කිරීම වැරදි ප්‍රති result ලයක් හෝ panics නිපදවයි.
    ///
    /// නිදොස් කිරීමේ ප්‍රකාශයන් සක්‍රීය කර ඇත්නම්, panic සහතික කෙරේ.
    ///
    /// # Panics
    ///
    /// අනුකාරකයට [`usize::MAX`] මූලද්‍රව්‍යවලට වඩා තිබේ නම් මෙම ශ්‍රිතය panic විය හැකිය.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// අවසාන මූලද්‍රව්‍යය නැවත ලබා දෙමින් අනුකාරකය පරිභෝජනය කරයි.
    ///
    /// මෙම ක්‍රමය [`None`] ආපසු ලබා දෙන තෙක් iterator ඇගයීමට ලක් කරයි.
    /// එසේ කරන අතරතුර, එය වත්මන් මූලද්‍රව්‍යය නිරීක්ෂණය කරයි.
    /// [`None`] ආපසු ලබා දුන් පසු, `last()` එය දුටු අවසන් අංගය නැවත ලබා දෙනු ඇත.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// `n` මූලද්‍රව්‍ය මගින් අනුකාරකය ඉදිරියට ගෙන යයි.
    ///
    /// මෙම ක්‍රමය [`None`] හමු වන තුරු [`next`] දක්වා `n` ඇමතීමෙන් `n` මූලද්‍රව්‍යයන් උනන්දුවෙන් මඟ හරිනු ඇත.
    ///
    /// `advance_by(n)` `n` මූලද්‍රව්‍ය මගින් iterator සාර්ථකව ඉදිරියට ගියහොත් [`Ok(())`][Ok] හෝ [`None`] හමු වුවහොත් [`Err(k)`][Err], එහිදී `k` යනු මූලද්‍රව්‍ය ඉවර වීමට පෙර iterator විසින් දියුණු කරන ලද මූලද්‍රව්‍ය ගණන වේ (එනම්
    /// අනුකාරකයේ දිග).
    /// `k` සෑම විටම `n` ට වඩා අඩු බව සලකන්න.
    ///
    /// `advance_by(0)` ඇමතීමෙන් කිසිදු මූලද්‍රව්‍යයක් පරිභෝජනය නොකරන අතර සෑම විටම [`Ok(())`][Ok] ආපසු ලබා දේ.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // `&4` පමණක් මඟ හැරුණි
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// අනුකාරකයේ `n` මූලද්‍රව්‍යය ලබා දෙයි.
    ///
    /// බොහෝ සුචිගත කිරීමේ මෙහෙයුම් වලදී මෙන්, ගණනය ආරම්භ වන්නේ ශුන්‍යයෙන් වන අතර, එබැවින් `nth(0)` පළමු අගය, `nth(1)` දෙවන අගය සහ යනාදිය ලබා දෙයි.
    ///
    /// සියලුම පූර්ව මූලද්‍රව්‍ය මෙන්ම ආපසු ලබා දුන් මූලද්‍රව්‍යය අනුකාරකයෙන් පරිභෝජනය කරන බව සලකන්න.
    /// එයින් අදහස් වන්නේ පෙර මූලද්‍රව්‍ය ඉවතලනු ඇති අතර, එකම අනුකාරකයේ `nth(0)` ඇමතීමෙන් විවිධ මූලද්‍රව්‍ය නැවත ලැබෙනු ඇති බවයි.
    ///
    ///
    /// `nth()` `n` iterator හි දිගට වඩා වැඩි හෝ සමාන නම් [`None`] නැවත ලබා දෙනු ඇත.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// `nth()` කිහිප වතාවක් ඇමතීමෙන් iterator පෙරළා නොගනී:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// `n + 1` ට වඩා අඩු මූලද්‍රව්‍ය තිබේ නම් `None` නැවත ලබා දීම:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// එකම ස්ථානයකින් ආරම්භ වන අනුකාරකයක් සාදයි, නමුත් එක් එක් පුනරාවර්තනයේදී දී ඇති ප්‍රමාණය අනුව පියවර තබයි.
    ///
    /// සටහන 1: ලබා දී ඇති පියවර නොසලකා, අනුකාරකයේ පළමු අංගය සෑම විටම ආපසු ලබා දෙනු ඇත.
    ///
    /// සටහන 2: නොසලකා හරින ලද මූලද්‍රව්‍ය ඇද ගන්නා වේලාව නියම කර නැත.
    /// `StepBy` `next(), nth(step-1), nth(step-1),…` අනුක්‍රමය මෙන් හැසිරෙන නමුත් අනුක්‍රමය මෙන් හැසිරීමටද නිදහස ඇත
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// කාර්ය සාධන හේතූන් මත සමහර අනුකාරක සඳහා භාවිතා කරන මාර්ගය වෙනස් විය හැකිය.
    /// දෙවන ක්‍රමය මීට පෙර iterator ඉදිරියට ගෙන යන අතර තවත් අයිතම පරිභෝජනය කළ හැකිය.
    ///
    /// `advance_n_and_return_first` සමාන වේ:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// දී ඇති පියවර `0` නම් ක්‍රමය panic වේ.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// අනුකාරක දෙකක් ගෙන අනුපිළිවෙලින් දෙකටම වඩා නව අනුකාරකයක් සාදයි.
    ///
    /// `chain()` නව iterator එකක් නැවත ලබා දෙන අතර එය පළමුව පළමු iterator වෙතින් අගයන් ඉක්මවා නැවත දෙවන iterator වෙතින් අගයන් ඉක්මවා යයි.
    ///
    /// වෙනත් වචන වලින් කිවහොත්, එය දාමයක, අනුකාරක දෙකක් එකට සම්බන්ධ කරයි.🔗
    ///
    /// [`once`] තනි අගයක් වෙනත් ආකාරයේ පුනරාවර්තන දාමයකට අනුවර්තනය කිරීමට බහුලව භාවිතා වේ.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `chain()` සඳහා වන තර්කය [`IntoIterator`] භාවිතා කරන බැවින්, අපට [`Iterator`] පමණක් නොව [`Iterator`] බවට පරිවර්තනය කළ හැකි ඕනෑම දෙයක් සම්මත කළ හැකිය.
    /// උදාහරණයක් ලෙස, (`&[T]`) පෙති [`IntoIterator`] ක්‍රියාත්මක කරන අතර එමඟින් `chain()` වෙත කෙලින්ම යැවිය හැකිය:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ඔබ Windows API සමඟ වැඩ කරන්නේ නම්, ඔබට [`OsStr`] `Vec<u16>` බවට පරිවර්තනය කිරීමට අවශ්‍ය විය හැකිය:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// යුගලනයක තනි අනුකාරකයක් බවට අනුකාරක දෙකක් 'සිප්ස් අප්' කරන්න.
    ///
    /// `zip()` නව අනුකාරකයක් නැවත ලබා දෙන අතර එය තවත් අනුකාරක දෙකකට වඩා පුනරාවර්තනය වේ, පළමු මූලද්‍රව්‍යය පළමු අනුකාරකයෙන් එන ටුපල් එකක් නැවත ලබා දෙයි, දෙවන මූලද්‍රව්‍යය දෙවන අනුකාරකයෙන් පැමිණේ.
    ///
    ///
    /// වෙනත් වචන වලින් කිවහොත්, එය පුනරාවර්තන දෙකක් එකට, එකකට සිප් කරයි.
    ///
    /// එක්කෝ iterator විසින් [`None`] ආපසු ලබා දෙන්නේ නම්, සිප් කළ iterator වෙතින් [`next`] [`None`] ආපසු ලබා දෙනු ඇත.
    /// පළමු iterator [`None`] ආපසු ලබා දෙන්නේ නම්, `zip` කෙටි පරිපථයක් වන අතර `next` දෙවන අනුකාරකයට කැඳවනු නොලැබේ.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` සඳහා වන තර්කය [`IntoIterator`] භාවිතා කරන බැවින්, අපට [`Iterator`] පමණක් නොව [`Iterator`] බවට පරිවර්තනය කළ හැකි ඕනෑම දෙයක් සම්මත කළ හැකිය.
    /// උදාහරණයක් ලෙස, (`&[T]`) පෙති [`IntoIterator`] ක්‍රියාත්මක කරන අතර එමඟින් `zip()` වෙත කෙලින්ම යැවිය හැකිය:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` බොහෝ විට භාවිතා කරනුයේ අසීමිත අනුකාරකයක් සීමිත එකකට සිප් කිරීමට ය.
    /// මෙය ක්‍රියාත්මක වන්නේ සීමිත අනුකාරකය අවසානයේ [`None`] ආපසු ලබා දෙන අතර සිපර් අවසන් වේ.`(0..)` සමඟ සිප් කිරීම [`enumerate`] මෙන් පෙනේ:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// මුල් අනුකාරකයේ යාබද අයිතම අතර `separator` පිටපතක් තබන නව අනුකාරකයක් සාදයි.
    ///
    /// `separator` [`Clone`] ක්‍රියාත්මක නොකරන්නේ නම් හෝ සෑම විටම ගණනය කිරීමට අවශ්‍ය නම්, [`intersperse_with`] භාවිතා කරන්න.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // `a` වෙතින් පළමු අංගය.
    /// assert_eq!(a.next(), Some(&100)); // බෙදුම්කරු.
    /// assert_eq!(a.next(), Some(&1));   // `a` වෙතින් ඊළඟ අංගය.
    /// assert_eq!(a.next(), Some(&100)); // බෙදුම්කරු.
    /// assert_eq!(a.next(), Some(&2));   // `a` වෙතින් අවසාන අංගය.
    /// assert_eq!(a.next(), None);       // අනුකාරකය අවසන්.
    /// ```
    ///
    /// `intersperse` පොදු අංගයක් භාවිතා කරමින් අනුකාරකයේ අයිතම සමඟ සම්බන්ධ වීමට ඉතා ප්‍රයෝජනවත් වේ:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// `separator` මගින් ජනනය කරන ලද අයිතමයක් මුල් අනුකාරකයේ යාබද අයිතම අතර ස්ථානගත කරන නව අනුකාරකයක් සාදයි.
    ///
    /// යටින් ඇති අනුකාරකයේ සිට යාබද අයිතම දෙකක් අතර අයිතමයක් තැබූ සෑම අවස්ථාවකම වසා දැමීම හරියටම හැඳින්වේ;
    /// නිශ්චිතවම, යටින් ඇති අනුකාරකය අයිතම දෙකකට වඩා අඩු අස්වැන්නක් ලබා දෙන්නේ නම් සහ අවසාන අයිතමය ලබා දීමෙන් පසුව වසා දැමීම කැඳවනු නොලැබේ.
    ///
    ///
    /// අනුකාරකයේ අයිතමය [`Clone`] ක්‍රියාත්මක කරන්නේ නම්, [`intersperse`] භාවිතා කිරීම පහසු විය හැකිය.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // `v` වෙතින් පළමු අංගය.
    /// assert_eq!(it.next(), Some(NotClone(99))); // බෙදුම්කරු.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // `v` වෙතින් ඊළඟ අංගය.
    /// assert_eq!(it.next(), Some(NotClone(99))); // බෙදුම්කරු.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // `v` වෙතින් අවසාන අංගය.
    /// assert_eq!(it.next(), None);               // අනුකාරකය අවසන්.
    /// ```
    ///
    /// `intersperse_with` බෙදුම්කරු ගණනය කළ යුතු අවස්ථාවන්හිදී භාවිතා කළ හැකිය:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // වසා දැමීම අයිතමයක් ජනනය කිරීම සඳහා එහි සන්දර්භය ණයට ගනී.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// වසා දැමීමක් ගෙන එක් එක් මූලද්‍රව්‍යය මත එම වසා දැමීම ලෙස හඳුන්වන අනුකාරකයක් සාදයි.
    ///
    /// `map()` එහි තර්කය මගින් එක් අනුකාරකයක් තවත් පරිවර්තනයක් බවට පරිවර්තනය කරයි:
    /// [`FnMut`] ක්‍රියාත්මක කරන දෙයක්.එය නව අනුකාරකයක් නිපදවන අතර එය මුල් අනුකාරකයේ එක් එක් මූලද්‍රව්‍ය මත මෙම වසා දැමීම ලෙස හැඳින්වේ.
    ///
    /// ඔබ වර්ග වලින් සිතීමට දක්ෂ නම්, ඔබට මේ ආකාරයට `map()` ගැන සිතිය හැකිය:
    /// ඔබට `A` වර්ගයේ මූලද්‍රව්‍ය ලබා දෙන iterator එකක් තිබේ නම් සහ ඔබට වෙනත් වර්ගයක `B` හි අනුකාරකයක් අවශ්‍ය නම්, ඔබට `map()` භාවිතා කළ හැකිය, එය වසා දැමීමෙන් පසු `A` ගෙන `B` ආපසු ලබා දේ.
    ///
    ///
    /// `map()` සංකල්පමය වශයෙන් [`for`] පුඩුවට සමාන වේ.කෙසේ වෙතත්, `map()` කම්මැලි බැවින්, ඔබ දැනටමත් වෙනත් අනුකාරක සමඟ වැඩ කරන විට එය වඩාත් සුදුසු වේ.
    /// ඔබ අතුරු ආබාධයක් සඳහා යම් ආකාරයක ලූපයක් කරන්නේ නම්, `map()` ට වඩා [`for`] භාවිතා කිරීම වඩාත් මුග්ධ ලෙස සැලකේ.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ඔබ යම් ආකාරයක අතුරු ආබාධයක් කරන්නේ නම්, [`for`] සිට `map()` දක්වා කැමති වන්න:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // මෙය නොකරන්න:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // එය කම්මැලි බැවින් එය ක්‍රියාත්මක නොකරනු ඇත.Rust මේ ගැන ඔබට අනතුරු අඟවයි.
    ///
    /// // ඒ වෙනුවට, භාවිතා කරන්න:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// අනුකාරකයේ එක් එක් මූලද්‍රව්‍යය වසා දැමීමක් ඉල්ලා සිටී.
    ///
    /// වසා දැමීමෙන් `break` සහ `continue` කළ නොහැකි වුවද මෙය iterator මත [`for`] පුඩුවක් භාවිතා කිරීමට සමාන වේ.
    /// සාමාන්‍යයෙන් `for` පුඩුවක් භාවිතා කිරීම වඩාත් මුග්ධ ය, නමුත් දිගු පුනරාවර්තක දාම අවසානයේ අයිතම සැකසීමේදී `for_each` වඩාත් පැහැදිලි විය හැකිය.
    ///
    /// සමහර අවස්ථාවලදී `for_each` ලූපයකට වඩා වේගවත් විය හැකිය, මන්ද එය `Chain` වැනි ඇඩැප්ටර වල අභ්‍යන්තර ක්‍රියාකාරීත්වය භාවිතා කරනු ඇත.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// එවැනි කුඩා උදාහරණයක් සඳහා, `for` පුඩුවක් වඩා පිරිසිදු විය හැකි නමුත් දිගු ක්‍රියාකාරීත්වයන් සහිත ක්‍රියාකාරී ශෛලියක් තබා ගැනීමට `for_each` වඩාත් සුදුසු වේ:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// මූලද්‍රව්‍යයක් ලබා දිය යුතුද යන්න තීරණය කිරීම සඳහා වසා දැමීමක් භාවිතා කරන අනුකාරකයක් සාදයි.
    ///
    /// මූලද්‍රව්‍යයක් ලබා දීමෙන් වසා දැමීම `true` හෝ `false` ආපසු ලබා දිය යුතුය.ආපසු ලබා දුන් අනුකාරකය මඟින් ලබා දෙන්නේ වසා දැමීම සත්‍ය වන මූලද්‍රව්‍ය පමණි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `filter()` වෙත සම්ප්‍රේෂණය කිරීම යොමු කිරීමක් ගන්නා නිසාත්, බොහෝ අනුකාරකයන් යොමු කිරීම් වලට වඩා පුනරාවර්තනය වන නිසාත්, මෙය වියවුල්සහගත තත්වයකට මඟ පාදයි, එහිදී වසා දැමීමේ වර්ගය ද්විත්ව යොමුවකි:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // දෙකක් අවශ්‍යයි!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// එකක් ඉවත් කිරීම සඳහා තර්කය මත විනාශ කිරීම භාවිතා කිරීම සාමාන්‍ය දෙයකි:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // දෙකම සහ *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// හෝ දෙකම:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // &s දෙකක්
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// මෙම ස්ථර වල.
    ///
    /// `iter.filter(f).next()` `iter.find(f)` ට සමාන බව සලකන්න.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// පෙරහන් සහ සිතියම් යන දෙකම අනුකාරකයක් සාදයි.
    ///
    /// ආපසු ලබා දුන් අනුකාරකය ලබා දෙන්නේ සැපයූ වසා දැමීම `Some(value)` ආපසු ලබා දෙන `අගය` පමණි.
    ///
    /// `filter_map` [`filter`] සහ [`map`] දාම වඩාත් සංක්ෂිප්ත කිරීමට භාවිතා කළ හැකිය.
    /// පහත උදාහරණයෙන් දැක්වෙන්නේ `map().filter().map()` තනි ඇමතුමකට `filter_map` වෙත කෙටි කළ හැකි ආකාරයයි.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// මෙන්න එකම උදාහරණය, නමුත් [`filter`] සහ [`map`] සමඟ:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// වත්මන් පුනරාවර්තන ගණන මෙන්ම ඊළඟ අගය ද ලබා දෙන අනුකාරකයක් සාදයි.
    ///
    /// පුනරාවර්තක ප්‍රතිලාභ `(i, val)` යුගල ලබා දෙයි, මෙහි `i` යනු වර්තමාන පුනරාවර්තන දර්ශකය වන අතර `val` යනු අනුකාරකය විසින් ආපසු ලබා දුන් අගයයි.
    ///
    ///
    /// `enumerate()` එහි ගණන [`usize`] ලෙස තබා ගනී.
    /// ඔබට වෙනත් ප්‍රමාණයේ පූර්ණ සංඛ්‍යාවක් මගින් ගණනය කිරීමට අවශ්‍ය නම්, [`zip`] ශ්‍රිතය සමාන ක්‍රියාකාරීත්වයක් සපයයි.
    ///
    /// # පිටාර ගැලීමේ හැසිරීම
    ///
    /// මෙම ක්‍රමය පිටාර ගැලීම් වලින් ආරක්ෂා නොවේ, එබැවින් [`usize::MAX`] මූලද්‍රව්‍යවලට වඩා ගණනය කිරීම වැරදි ප්‍රති result ලයක් හෝ panics නිපදවයි.
    /// නිදොස් කිරීමේ ප්‍රකාශයන් සක්‍රීය කර ඇත්නම්, panic සහතික කෙරේ.
    ///
    /// # Panics
    ///
    /// ආපසු එවිය යුතු දර්ශකය [`usize`] පිරී ඉතිරී ගියහොත් ආපසු ලබා දුන් අනුකාරකය panic විය හැකිය.
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// [`peek`] භාවිතා කර අනුකාරකයේ ඊළඟ මූලද්‍රව්‍යය පරිභෝජනය නොකර බැලීමට හැකි ඉරේටරයක් සාදයි.
    ///
    /// [`peek`] ක්‍රමයක් iterator වෙත එක් කරයි.වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
    ///
    /// [`peek`] පළමු වරට කැඳවූ විට යටින් ඇති iterator තවමත් දියුණු බව සලකන්න: ඊළඟ මූලද්‍රව්‍යය ලබා ගැනීම සඳහා, [`next`] යටි ඉරිටරේටරය මත කැඳවනු ලැබේ, එබැවින් ඕනෑම අතුරු ආබාධ (එනම්
    ///
    /// [`next`] ක්‍රමයේ ඊළඟ අගය ලබා ගැනීම හැර වෙනත් කිසිවක් සිදුවනු ඇත.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() අපට future වෙත බැලීමට ඉඩ දෙයි
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // අපට කිහිප වතාවක් peek() කළ හැකිය, අනුකාරකය ඉදිරියට නොයනු ඇත
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // අනුකාරකය අවසන් වූ පසු peek() ද වේ
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// පුරෝකථනයක් මත පදනම්ව [`මඟහරින්න]] මූලද්‍රව්‍යයක් සාදයි.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` වසා දැමීමක් තර්කයක් ලෙස ගනී.එය අනුකාරකයේ සෑම මූලද්‍රව්‍යයකම මෙම වසා දැමීම කැඳවනු ඇති අතර එය `false` ආපසු ලබා දෙන තෙක් මූලද්‍රව්‍ය නොසලකා හරිනු ඇත.
    ///
    /// `false` ආපසු ලබා දීමෙන් පසු, `skip_while()`'s කාර්යය අවසන් වී ඇති අතර ඉතිරි මූලද්‍රව්‍යයන් ලබා දෙනු ලැබේ.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `skip_while()` වෙත සම්ප්‍රේෂණය කිරීම යොමු කිරීමක් ගන්නා නිසාත්, බොහෝ අනුකාරකයන් යොමු කිරීම් වලට වඩා පුනරාවර්තනය වන නිසාත්, මෙය වියවුල්සහගත තත්වයකට මග පාදයි, එහිදී සංවෘත තර්කයේ වර්ගය ද්විත්ව යොමුවකි:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // දෙකක් අවශ්‍යයි!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ආරම්භක `false` පසු නතර කිරීම:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // මෙය අසත්‍යයක් වනු ඇත, අප සතුව දැනටමත් අසත්‍යයක් ඇති බැවින්, skip_while() තවදුරටත් භාවිතා නොවේ
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// පුරෝකථනයක් මත පදනම්ව මූලද්‍රව්‍ය ලබා දෙන අනුකාරකයක් සාදයි.
    ///
    /// `take_while()` වසා දැමීමක් තර්කයක් ලෙස ගනී.එය අනුකාරකයේ එක් එක් මූලද්‍රව්‍යය මත මෙම වසා දැමීම ලෙස හඳුන්වන අතර එය `true` ආපසු ලබා දෙන අතරතුර මූලද්‍රව්‍ය ලබා දෙයි.
    ///
    /// `false` ආපසු ලබා දීමෙන් පසු, `take_while()`'s කාර්යය අවසන් වී ඇති අතර ඉතිරි අංග නොසලකා හරිනු ලැබේ.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take_while()` වෙත සම්ප්‍රේෂණය කිරීම යොමු කිරීමක් ගන්නා නිසාත්, බොහෝ අනුකාරකයන් යොමු කිරීම් වලට වඩා පුනරාවර්තනය වන නිසාත්, මෙය වියවුල්සහගත තත්වයකට මඟ පාදයි, එහිදී වසා දැමීමේ වර්ගය ද්විත්ව යොමුවකි:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // දෙකක් අවශ්‍යයි!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ආරම්භක `false` පසු නතර කිරීම:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // අපට ශුන්‍යයට වඩා අඩු මූලද්‍රව්‍ය තිබේ, නමුත් අපට දැනටමත් අසත්‍යයක් ඇති බැවින් take_while() තවදුරටත් භාවිතා නොවේ
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take_while()` අගය ඇතුළත් කළ යුතුද නැද්ද යන්න සොයා බැලීමට අවශ්‍ය නිසා, පරිභෝජනය කරන අනුකාරක එය ඉවත් කර ඇති බව දකිනු ඇත:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` තවදුරටත් එහි නොමැත, මන්ද එය පරිභෝජනය කර ඇත්තේ නැවතීම නැවැත්විය යුතුද යන්න බැලීමටය, නමුත් එය නැවත ක්‍රියාකරු තුළට දමා නැත.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// පුරෝකථනය සහ සිතියම් මත පදනම්ව මූලද්‍රව්‍ය දෙකම ලබා දෙන අනුකාරකයක් සාදයි.
    ///
    /// `map_while()` වසා දැමීමක් තර්කයක් ලෙස ගනී.
    /// එය අනුකාරකයේ එක් එක් මූලද්‍රව්‍යය මත මෙම වසා දැමීම ලෙස හඳුන්වන අතර එය [`Some(_)`][`Some`] ආපසු ලබා දෙන අතරතුර මූලද්‍රව්‍ය ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// මෙන්න එකම උදාහරණය, නමුත් [`take_while`] සහ [`map`] සමඟ:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ආරම්භක [`None`] පසු නතර කිරීම:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // u32 (4, 5) ට ගැලපෙන තවත් මූලද්‍රව්‍ය අප සතුව ඇත, නමුත් `map_while` `-3` සඳහා `None` ආපසු ලබා දුන්නේය (`predicate` `None` ආපසු ලබා දුන් පරිදි) සහ `collect` පළමු `None` හමු වූ විට නතර වේ.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// `map_while()` අගය ඇතුළත් කළ යුතුද නැද්ද යන්න සොයා බැලීමට අවශ්‍ය නිසා, පරිභෝජනය කරන අනුකාරක එය ඉවත් කර ඇති බව දකිනු ඇත:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` තවදුරටත් එහි නොමැත, මන්ද එය පරිභෝජනය කර ඇත්තේ නැවතීම නැවැත්විය යුතුද යන්න බැලීමටය, නමුත් එය නැවත ක්‍රියාකරු තුළට දමා නැත.
    ///
    /// [`take_while`] මෙන් නොව මෙම අනුකාරකය ** විලයනය නොවන බව සලකන්න.
    /// පළමු [`None`] ආපසු ලබා දීමෙන් පසු මෙම අනුකාරකය නැවත පැමිණෙන්නේ කුමක් ද යන්න නිශ්චිතව දක්වා නැත.
    /// ඔබට විලයන අනුකාරකය අවශ්‍ය නම්, [`fuse`] භාවිතා කරන්න.
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// පළමු `n` මූලද්‍රව්‍ය මඟ හැරෙන අනුකාරකයක් සාදයි.
    ///
    /// ඒවා පරිභෝජනය කිරීමෙන් පසු ඉතිරි මූලද්රව්ය නිපදවනු ලැබේ.
    /// මෙම ක්‍රමය කෙලින්ම අභිබවා යනවා වෙනුවට `nth` ක්‍රමය අභිබවා යන්න.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// එහි පළමු `n` මූලද්‍රව්‍ය ලබා දෙන අනුකාරකයක් සාදයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` එය බොහෝ විට අසීමිත අනුකාරකයක් සමඟ භාවිතා කරයි, එය සීමිත කිරීමට:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `n` ට වඩා අඩු මූලද්‍රව්‍ය තිබේ නම්, `take` යටින් ඇති අනුකාරකයේ ප්‍රමාණයට සීමා වේ:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// [`fold`] ට සමාන iterator ඇඩැප්ටරයක් අභ්‍යන්තර තත්වය රඳවාගෙන නව iterator නිපදවයි.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` තර්ක දෙකක් ගනී: අභ්‍යන්තර තත්වය බීජ කරන ආරම්භක අගයක් සහ තර්ක දෙකක් සමඟ වසා දැමීම, පළමුවැන්න අභ්‍යන්තර තත්වය පිළිබඳ විකෘති යොමු කිරීමක් වන අතර දෙවැන්න අනුකාරක මූලද්‍රව්‍යය.
    ///
    /// වසා දැමීම මඟින් පුනරාවර්තන අතර තත්වය බෙදා ගැනීමට අභ්‍යන්තර තත්වයට පැවරිය හැකිය.
    ///
    /// පුනරාවර්තනයේදී, වසා දැමීම අනුකාරකයේ එක් එක් මූලද්‍රව්‍යයට යොදන අතර වසා දැමීමෙන් ලැබෙන ප්‍රතිලාභ අගය වන [`Option`], iterator මඟින් ලබා දෙනු ලැබේ.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // සෑම පුනරාවර්තනයක්ම, අපි මූලද්‍රව්‍යය මගින් තත්වය ගුණ කරමු
    ///     *state = *state * x;
    ///
    ///     // එහෙනම් අපි රාජ්‍යය ප්‍රතික්ෂේප කරනවා
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// සිතියම මෙන් ක්‍රියා කරන, නමුත් කැදැලි ව්‍යුහය සමතලා කරයි.
    ///
    /// [`map`] ඇඩැප්ටරය ඉතා ප්‍රයෝජනවත් වේ, නමුත් සංවෘත තර්කය මඟින් අගයන් නිපදවන විට පමණි.
    /// ඒ වෙනුවට එය අනුකාරකයක් නිපදවන්නේ නම්, අමතර පරාවර්තක තට්ටුවක් ඇත.
    /// `flat_map()` මෙම අමතර ස්ථරය තනිවම ඉවත් කරයි.
    ///
    /// ඔබට `flat_map(f)` [සිතියම] පිං හි අර්ථකථන සමාන යැයි සිතිය හැකිය, පසුව `map(f).flatten()` හි මෙන් [`සමතලා කරන්න].
    ///
    /// `flat_map()` ගැන සිතීමේ තවත් ක්‍රමයක්: [`සිතියම] වසා දැමීම එක් එක් මූලද්‍රව්‍යය සඳහා එක් අයිතමයක් ලබා දෙන අතර `flat_map()`'s වසා දැමීම එක් එක් මූලද්‍රව්‍ය සඳහා අනුකාරකයක් ලබා දෙයි.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() iterator නැවත ලබා දෙයි
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// කැදැලි ව්‍යුහය සමතලා කරන අනුකාරකයක් සාදයි.
    ///
    /// ඔබට iterators iterator හෝ iterator බවට පත් කළ හැකි දේවල් iterator ඇති විට මෙය ප්‍රයෝජනවත් වන අතර ඔබට එක් මට්ටමේ අවිනිශ්චිතතාවයක් ඉවත් කිරීමට අවශ්‍ය වේ.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// සිතියම්ගත කිරීම හා සමතලා කිරීම:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() iterator නැවත ලබා දෙයි
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// ඔබට මෙය [`flat_map()`] ප්‍රකාරව නැවත ලිවිය හැකිය, එය වඩාත් පැහැදිලිව අභිප්‍රාය ප්‍රකාශ කරන බැවින් මෙම අවස්ථාවේ දී වඩාත් සුදුසු වේ:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() iterator නැවත ලබා දෙයි
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// පැතලි කිරීම මඟින් වරකට එක් කැදැල්ලක් ඉවත් කරයි:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// මෙහිදී අපට පෙනෙන්නේ `flatten()` විසින් "deep" සමතලා කිරීමක් සිදු නොකරන බවයි.
    /// ඒ වෙනුවට, කැදැල්ල ඉවත් කරනු ලබන්නේ එක් මට්ටමක පමණි.එනම්, ඔබ `flatten()` ත්‍රිමාන අරාවක් නම්, ප්‍රති result ලය ද්විමාන මිස එක්-මාන නොවේ.
    /// ඒක මාන ව්‍යුහයක් ලබා ගැනීම සඳහා, ඔබ නැවත `flatten()` කළ යුතුය.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// පළමු [`None`] ට පසුව අවසන් වන iterator එකක් සාදයි.
    ///
    /// අනුකාරකයක් [`None`] ආපසු ලබා දුන් පසු, future ඇමතුම් නැවත [`Some(T)`] ලබා දිය හැකිය.
    /// `fuse()` [`None`] ලබා දීමෙන් පසු, එය සෑම විටම [`None`] සදහටම ලබා දෙන බව සහතික කරමින්, iterator අනුගත කරයි.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// // සමහරක් සහ කිසිවක් අතර ප්‍රත්‍යාවර්ත වන අනුකාරකයක්
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // එය ඉරට්ටේ නම්, Some(i32), වෙනත් කිසිවක් නැත
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // අපට දැක ගත හැකිය අපගේ අනුකාරකය නැවත නැවතත් ඉදිරියට යන බව
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // කෙසේ වෙතත්, අපි එය විලයනය කළ පසු ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // එය සෑම විටම පළමු වරට පසු `None` නැවත ලබා දෙනු ඇත.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// අනුකාරකයේ සෑම මූලද්‍රව්‍යයක් සමඟම යමක් සිදු කරයි.
    ///
    /// Iterator භාවිතා කරන විට, ඔබ බොහෝ විට ඒවා කිහිපයක් එකට සම්බන්ධ කරයි.
    /// එවැනි කේතයක් මත වැඩ කරන අතරතුර, නල මාර්ගයේ විවිධ කොටස් වල සිදුවන්නේ කුමක්දැයි පරීක්ෂා කිරීමට ඔබට අවශ්‍ය විය හැකිය.එය සිදු කිරීම සඳහා, `inspect()` වෙත ඇමතුමක් ඇතුළත් කරන්න.
    ///
    /// ඔබේ අවසාන කේතයේ පැවතීමට වඩා `inspect()` නිදොස් කිරීමේ මෙවලමක් ලෙස භාවිතා කිරීම වඩාත් සුලභ ය, නමුත් ඉවතලෑමට පෙර දෝෂ සටහන් කිරීමට අවශ්‍ය වූ විට යෙදුම් සමහර අවස්ථාවල එය ප්‍රයෝජනවත් වේ.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // මෙම අනුකාරක අනුක්‍රමය සංකීර්ණයි.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // සිදුවන්නේ කුමක්ද යන්න සොයා බැලීමට අපි inspect() ඇමතුම් කිහිපයක් එකතු කරමු
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// මෙය මුද්‍රණය කරනු ඇත:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// ඒවා ඉවත දැමීමට පෙර ලොග් වීම:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// මෙය මුද්‍රණය කරනු ඇත:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// එය පරිභෝජනය කරනවාට වඩා අනුකාරකයක් ණයට ගනී.
    ///
    /// මුල් අනුකාරකයේ හිමිකම රඳවා තබා ගනිමින් iterator ඇඩැප්ටර යෙදීමට ඉඩ දීමට මෙය ප්‍රයෝජනවත් වේ.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // අපි එය නැවත භාවිතා කිරීමට උත්සාහ කළහොත් එය ක්‍රියා නොකරනු ඇත.
    /// // පහත දැක්වෙන පේළිය "දෝෂය: ගෙන ගිය අගය භාවිතා කිරීම: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // අපි එය නැවත උත්සාහ කරමු
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // ඒ වෙනුවට, අපි .by_ref() එකකින් එකතු කරමු
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // දැන් මෙය හොඳයි:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// අනුකාරකයක් එකතුවක් බවට පරිවර්තනය කරයි.
    ///
    /// `collect()` නැවත කළ හැකි ඕනෑම දෙයක් ගෙන එය අදාළ එකතුවක් බවට පත් කළ හැකිය.
    /// මෙය සම්මත පුස්තකාලයේ වඩා බලවත් ක්‍රමවලින් එකක් වන අතර එය විවිධ සන්දර්භයන්හි භාවිතා වේ.
    ///
    /// `collect()` භාවිතා කරන වඩාත් මූලික රටාව වන්නේ එක් එකතුවක් තවත් එකතුවක් බවට පත් කිරීමයි.
    /// ඔබ එකතුවක් ගන්න, ඒ මත [`iter`] අමතන්න, පරිවර්තනයන් රාශියක් කරන්න, ඉන්පසු අවසානයේ `collect()`.
    ///
    /// `collect()` සාමාන්‍ය එකතු නොවන ආකාරයේ අවස්ථා ද නිර්මාණය කළ හැකිය.
    /// නිදසුනක් ලෙස, [`char`] වෙතින් [`String`] සෑදිය හැකි අතර, [`Result<T, E>`][`Result`] අයිතමවල අනුකාරකයක් `Result<Collection<T>, E>` වෙත එකතු කළ හැකිය.
    ///
    /// වැඩි විස්තර සඳහා පහත උදාහරණ බලන්න.
    ///
    /// `collect()` එතරම් සාමාන්‍ය බැවින් එය වර්ග අනුමාන කිරීම් සමඟ ගැටලු ඇති කළ හැකිය.
    /// එනිසා, `collect()` යනු 'turbofish' ලෙස ආදරයෙන් හඳුන්වන වාක්‍ය ඛණ්ඩය ඔබ දකින කිහිප වතාවක් එකකි: `::<>`.
    /// ඔබ එකතු කිරීමට උත්සාහ කරන්නේ කුමන එකතුවටද යන්න නිශ්චිතවම තේරුම් ගැනීමට මෙය අනුමාන ඇල්ගොරිතමයට උපකාරී වේ.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// අපට වම් පස `: Vec<i32>` අවශ්‍ය බව සලකන්න.මෙයට හේතුව අපට ඒ වෙනුවට [`VecDeque<T>`] එකතු කළ හැකි බැවිනි:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// `doubled` විවරණය කිරීම වෙනුවට 'turbofish' භාවිතා කිරීම:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// `collect()` ඔබ එකතු කරන දේ ගැන පමණක් සැලකිලිමත් වන නිසා, ඔබට තවමත් ටර්බෝෆිෂ් සමඟ අර්ධ ආකාරයේ ඉඟියක් වන `_` භාවිතා කළ හැකිය:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// [`String`] සෑදීම සඳහා `collect()` භාවිතා කිරීම:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// ඔබට [`ප්‍රති ult ල 'ලැයිස්තුවක් තිබේ නම්<T, E>`][` ප්‍රති ult ල], ඔබට `collect()` භාවිතා කර ඒවායින් කිසිවක් අසමත් වී ඇත්දැයි බැලීමට හැකිය:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // පළමු දෝෂය අපට ලබා දෙයි
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // අපට පිළිතුරු ලැයිස්තුව ලබා දෙයි
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// අනුකාරකයක් පරිභෝජනය කරයි, එයින් එකතු දෙකක් නිර්මාණය කරයි.
    ///
    /// `partition()` වෙත සම්මත කර ඇති පුරෝකථනයට `true`, හෝ `false` ආපසු ලබා දිය හැකිය.
    /// `partition()` යුගලයක් ලබා දෙයි, එය `true` ආපසු ලබා දුන් සියලුම මූලද්‍රව්‍යයන් සහ එය `false` ආපසු ලබා දුන් සියලුම මූලද්‍රව්‍යයන්.
    ///
    ///
    /// [`is_partitioned()`] සහ [`partition_in_place()`] ද බලන්න.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// ලබා දී ඇති පුරෝකථනයට අනුව මෙම අනුකාරකයේ මූලද්‍රව්‍ය *ස්ථානගත* නැවත සකසයි, එනම් `true` ආපසු ලබා දෙන සියල්ල `false` ආපසු ලබා දෙන සියල්ලට පෙර.
    ///
    /// සොයාගත් `true` මූලද්‍රව්‍ය ගණන ලබා දෙයි.
    ///
    /// කොටස් කරන ලද අයිතමවල සාපේක්ෂ අනුපිළිවෙල පවත්වා නොගනී.
    ///
    /// [`is_partitioned()`] සහ [`partition()`] ද බලන්න.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // සවස් යාමය සහ පරස්පරතාව අතර ස්ථානගත කිරීම
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: ගණන් කිරීම පිරී ඉතිරී යාම ගැන අප කරදර විය යුතුද?වඩා ඇති එකම ක්‍රමය
        // `usize::MAX` විකෘති යොමු කිරීම් ZST සමඟ ඇත, ඒවා කොටස් කිරීමට ප්‍රයෝජනවත් නොවේ ...

        // `Self` හි ජනකත්වය වළක්වා ගැනීම සඳහා මෙම වසා දැමීමේ "factory" කාර්යයන් පවතී.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // පළමු `false` නැවත නැවත සොයාගෙන අවසන් `true` සමඟ එය මාරු කරන්න.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// ලබා දී ඇති පුරෝකථනයට අනුව මෙම අනුකාරකයේ මූලද්‍රව්‍ය කොටස් කර ඇත්දැයි පරීක්ෂා කරයි, එනම් `true` ආපසු ලබා දෙන සියල්ලම `false` ආපසු ලබා දෙන සියල්ලට පෙර.
    ///
    ///
    /// [`partition()`] සහ [`partition_in_place()`] ද බලන්න.
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // සෑම අයිතමයක්ම `true` පරීක්‍ෂා කරයි, නැතහොත් පළමු වගන්තිය `false` හි නතර වන අතර ඉන් පසුව තවත් `true` අයිතම නොමැති බව අපි පරීක්ෂා කරමු.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// ශ්‍රිතයක් සාර්ථකව නැවත පැමිණෙන තාක් දුරට තනි, අවසාන අගයක් නිපදවන iterator ක්‍රමයක්.
    ///
    /// `try_fold()` තර්ක දෙකක් ගනී: ආරම්භක අගය, සහ තර්ක දෙකක් සහිත වසා දැමීම: 'accumulator' සහ මූලද්‍රව්‍යයකි.
    /// වසා දැමීම එක්කෝ සාර්ථකව නැවත පැමිණේ, සමුච්චයකරුවාට ඊළඟ ක්‍රියාවලිය සඳහා තිබිය යුතු අගය සමඟ, නැතහොත් එය අසාර්ථක වේ, දෝෂ අගයක් සමඟ වහාම ඇමතුම්කරු වෙත (short-circuiting) වෙත ප්‍රචාරණය වේ.
    ///
    ///
    /// ආරම්භක අගය යනු පළමු ඇමතුමෙහි සමුච්චයකරුවාට ඇති අගයයි.වසා දැමීම යෙදීමෙන් අනුකාරකයේ සෑම මූලද්‍රව්‍යයක්ම සාර්ථක වූවා නම්, `try_fold()` අවසාන සමුච්චය සාර්ථක ලෙස ලබා දෙයි.
    ///
    /// ඔබට යමක් එකතුවක් ඇති විට එය නැවීම ප්‍රයෝජනවත් වන අතර එයින් තනි වටිනාකමක් නිපදවීමට අවශ්‍ය වේ.
    ///
    /// # ක්‍රියාත්මක කරන්නන්ට සටහන
    ///
    /// වෙනත් (forward) ක්‍රම කිහිපයකම මෙය ප්‍රකාරව පෙරනිමි ක්‍රියාත්මක කිරීම් ඇත, එබැවින් පෙරනිමි `for` ලූප් ක්‍රියාත්මක කිරීමට වඩා හොඳ දෙයක් කළ හැකි නම් මෙය පැහැදිලිව ක්‍රියාත්මක කිරීමට උත්සාහ කරන්න.
    ///
    /// විශේෂයෙන්, මෙම ක්‍රියාකාරකය රචනා කර ඇති අභ්‍යන්තර කොටස් මත මෙම ඇමතුම `try_fold()` ලබා ගැනීමට උත්සාහ කරන්න.
    /// බහුවිධ ඇමතුම් අවශ්‍ය නම්, සමුච්චය අගය දම්වැල දැමීම සඳහා `?` ක්‍රියාකරුට පහසු විය හැකි නමුත්, එම මුල් ප්‍රතිලාභවලට පෙර තහවුරු කර ගත යුතු ඕනෑම වෙනස්කමක් ගැන පරෙස්සම් වන්න.
    /// මෙය `&mut self` ක්‍රමයකි, එබැවින් මෙහි දෝෂයක් ඇති වූ පසු නැවත ආරම්භ කිරීම අවශ්‍ය වේ.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // අරාවේ සියලුම මූලද්‍රව්‍යයන්ගේ පරික්ෂා කළ මුදල
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // මූලද්රව්ය 100 එකතු කිරීමේදී මෙම එකතුව පිරී ඉතිරී යයි
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // එය කෙටි පරිපථයක් බැවින් ඉතිරි මූලද්‍රව්‍ය තවමත් අනුකාරකය හරහා ලබා ගත හැකිය.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Iterator ක්‍රමයේ එක් එක් අයිතමයට වැරදිසහගත ශ්‍රිතයක් යෙදෙන අතර, පළමු දෝෂය නැවැත්වීම සහ එම දෝෂය නැවත ලබා දීම.
    ///
    ///
    /// මෙය [`for_each()`] හි වැරදිසහගත ස්වරූපය ලෙස හෝ [`try_fold()`] හි අස්ථායි අනුවාදය ලෙසද සිතිය හැකිය.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // එය කෙටි පරිපථයකි, එබැවින් ඉතිරි අයිතම තවමත් අනුකාරකයේ ඇත:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// මෙහෙයුමක් යෙදීමෙන් සෑම මූලද්‍රව්‍යයක්ම සමුච්චයක් බවට පත් කර අවසන් ප්‍රති .ලය ලබා දෙයි.
    ///
    /// `fold()` තර්ක දෙකක් ගනී: ආරම්භක අගය, සහ තර්ක දෙකක් සහිත වසා දැමීම: 'accumulator' සහ මූලද්‍රව්‍යයකි.
    /// වසා දැමීම මඟින් ඊළඟ පුනරාවර්තනය සඳහා සමුච්චයකරුවාට තිබිය යුතු අගය ලබා දෙයි.
    ///
    /// ආරම්භක අගය යනු පළමු ඇමතුමේ සමුච්චයකරුවාට ඇති අගයයි.
    ///
    /// අනුකාරකයේ සෑම මූලද්‍රව්‍යයක් සඳහාම මෙම වසා දැමීම යෙදීමෙන් පසුව, `fold()` සමුච්චය නැවත ලබා දෙයි.
    ///
    /// මෙම මෙහෙයුම සමහර විට 'reduce' හෝ 'inject' ලෙස හැඳින්වේ.
    ///
    /// ඔබට යමක් එකතුවක් ඇති විට එය නැවීම ප්‍රයෝජනවත් වන අතර එයින් තනි වටිනාකමක් නිපදවීමට අවශ්‍ය වේ.
    ///
    /// Note: `fold()`, සහ සමස්ත ක්‍රියාකාරීත්වය හරහා ගමන් කරන සමාන ක්‍රම, traits මත වුවද, අසීමිත iterator සඳහා අවසන් නොවනු ඇත, එහි ප්‍රති result ලය සීමිත කාලයකදී තීරණය කළ හැකිය.
    ///
    /// Note: සමුච්චකාරක වර්ගය සහ අයිතම වර්ගය සමාන නම්, පළමු අගය මූලික අගය ලෙස භාවිතා කිරීමට [`reduce()`] භාවිතා කළ හැකිය.
    ///
    /// # ක්‍රියාත්මක කරන්නන්ට සටහන
    ///
    /// වෙනත් (forward) ක්‍රම කිහිපයකම මෙය ප්‍රකාරව පෙරනිමි ක්‍රියාත්මක කිරීම් ඇත, එබැවින් පෙරනිමි `for` ලූප් ක්‍රියාත්මක කිරීමට වඩා හොඳ දෙයක් කළ හැකි නම් මෙය පැහැදිලිව ක්‍රියාත්මක කිරීමට උත්සාහ කරන්න.
    ///
    ///
    /// විශේෂයෙන්, මෙම ක්‍රියාකාරකය රචනා කර ඇති අභ්‍යන්තර කොටස් මත මෙම ඇමතුම `fold()` ලබා ගැනීමට උත්සාහ කරන්න.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // අරාවේ සියලුම මූලද්‍රව්‍යයන්ගේ එකතුව
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// මෙහි පුනරාවර්තනයේ සෑම පියවරක් හරහාම ගමන් කරමු:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// ඉතින්, අපේ අවසාන ප්‍රති result ලය, `6`.
    ///
    /// ප්‍රති ite ල ගොඩ නැගීම සඳහා දේවල් ලැයිස්තුවක් සහිත `for` පුඩුවක් භාවිතා කිරීම බොහෝ විට භාවිතා නොකරන පුද්ගලයින් සඳහා සාමාන්‍ය දෙයකි.ඒවා `fold()`s බවට පත් කළ හැකිය:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // ලූප් සඳහා:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // ඔවුන් එකම ය
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// අඩු කිරීමේ මෙහෙයුමක් නැවත නැවත යෙදීමෙන් මූලද්‍රව්‍ය තනි එකකට අඩු කරයි.
    ///
    /// අනුකාරකය හිස් නම්, [`None`] ආපසු ලබා දෙයි;එසේ නොමැතිනම්, අඩු කිරීමේ ප්‍රති result ලය ලබා දෙයි.
    ///
    /// අවම වශයෙන් එක් මූලද්‍රව්‍යයක් සහිත iterator සඳහා, මෙය ආරම්භක අගය ලෙස iterator හි පළමු මූලද්‍රව්‍යය සමඟ [`fold()`] ට සමාන වන අතර, පසුව එන සෑම මූලද්‍රව්‍යයක්ම එයට නැමෙයි.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// උපරිම අගය සොයා ගන්න:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// අනුකාරකයේ සෑම අංගයක්ම පුරෝකථනයකට ගැලපේ නම් පරීක්ෂණ.
    ///
    /// `all()` `true` හෝ `false` ආපසු ලබා දෙන වසා දැමීමක් ගනී.එය අනුකාරකයේ එක් එක් මූලද්‍රව්‍යයට මෙම වසා දැමීම අදාළ වන අතර, ඒවා සියල්ලම `true` ආපසු ලබා දෙන්නේ නම්, `all()` ද එසේමය.
    /// ඔවුන්ගෙන් කිසිවෙකු `false` ආපසු ලබා දෙන්නේ නම්, එය `false` ආපසු ලබා දෙයි.
    ///
    /// `all()` කෙටි පරිපථයකි;වෙනත් වචන වලින් කිවහොත්, එය `false` සොයාගත් විගස එය සැකසීම නවත්වනු ඇත, වෙනත් කුමක් සිදු වුවද, ප්‍රති result ලය `false` වනු ඇත.
    ///
    ///
    /// හිස් අනුකාරකයක් `true` ආපසු ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// පළමු `false` හි නතර වීම:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // තවත් මූලද්‍රව්‍යයන් ඇති බැවින් අපට තවමත් `iter` භාවිතා කළ හැකිය.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// අනුකාරකයේ කිසියම් අංගයක් පුරෝකථනයකට ගැලපේ නම් පරීක්ෂණ.
    ///
    /// `any()` `true` හෝ `false` ආපසු ලබා දෙන වසා දැමීමක් ගනී.එය අනුකාරකයේ එක් එක් මූලද්‍රව්‍යයට මෙම වසා දැමීම අදාළ වන අතර, ඔවුන්ගෙන් කිසිවෙකු `true` ආපසු එවන්නේ නම්, `any()` ද එසේ කරයි.
    /// ඔවුන් සියල්ලම `false` ආපසු ලබා දෙන්නේ නම්, එය `false` ආපසු ලබා දෙයි.
    ///
    /// `any()` කෙටි පරිපථයකි;වෙනත් වචන වලින් කිවහොත්, එය `true` සොයාගත් විගස එය සැකසීම නවත්වනු ඇත, වෙනත් කුමක් සිදු වුවද, ප්‍රති result ලය `true` වනු ඇත.
    ///
    ///
    /// හිස් අනුකාරකයක් `false` ආපසු ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// පළමු `true` හි නතර වීම:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // තවත් මූලද්‍රව්‍යයන් ඇති බැවින් අපට තවමත් `iter` භාවිතා කළ හැකිය.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// පුරෝකථනයක් තෘප්තිමත් කරන අනුකාරකයේ මූලද්‍රව්‍යයක් සෙවීම.
    ///
    /// `find()` `true` හෝ `false` ආපසු ලබා දෙන වසා දැමීමක් ගනී.
    /// එය අනුකාරකයේ එක් එක් මූලද්‍රව්‍යයට මෙම වසා දැමීම අදාළ වන අතර, ඔවුන්ගෙන් කිසිවෙකු `true` ආපසු ලබා දෙන්නේ නම්, `find()` [`Some(element)`] ආපසු ලබා දෙයි.
    /// ඔවුන් සියල්ලම `false` ආපසු ලබා දෙන්නේ නම්, එය [`None`] ආපසු ලබා දෙයි.
    ///
    /// `find()` කෙටි පරිපථයකි;වෙනත් වචන වලින් කිවහොත්, වසා දැමීම `true` ආපසු පැමිණි විගස එය සැකසීම නවත්වනු ඇත.
    ///
    /// `find()` යොමු කිරීමක් ගන්නා නිසාත්, බොහෝ අනුකාරකයන් යොමු කිරීම් වලට වඩා පුනරාවර්තනය වන නිසාත්, මෙය තර්කය ද්විත්ව යොමු කිරීමක් වන ව්‍යාකූල තත්වයකට මඟ පාදයි.
    ///
    /// `&&x` සමඟ පහත උදාහරණ වලින් ඔබට මෙම බලපෑම දැකිය හැකිය.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// පළමු `true` හි නතර වීම:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // තවත් මූලද්‍රව්‍යයන් ඇති බැවින් අපට තවමත් `iter` භාවිතා කළ හැකිය.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// `iter.find(f)` `iter.filter(f).next()` ට සමාන බව සලකන්න.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Iterator හි මූලද්‍රව්‍යයන්ට ක්‍රියාකාරීත්වය අදාළ වන අතර පළමු නොවන කිසිවක් නොලැබේ.
    ///
    ///
    /// `iter.find_map(f)` `iter.filter_map(f).next()` ට සමාන වේ.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Iterator හි මූලද්‍රව්‍යයන්ට ක්‍රියාකාරීත්වය අදාළ වන අතර පළමු සත්‍ය ප්‍රති result ලය හෝ පළමු දෝෂය ලබා දෙයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// අනුකාරකයේ මූලද්‍රව්‍යයක් සෙවීම, එහි දර්ශකය ආපසු ලබා දීම.
    ///
    /// `position()` `true` හෝ `false` ආපසු ලබා දෙන වසා දැමීමක් ගනී.
    /// එය අනුකාරකයේ එක් එක් මූලද්‍රව්‍යයට මෙම වසා දැමීම අදාළ වන අතර, ඔවුන්ගෙන් එක් අයෙකු `true` ආපසු ලබා දෙන්නේ නම්, `position()` [`Some(index)`] ආපසු ලබා දෙයි.
    /// ඔවුන් සියල්ලන්ම `false` ආපසු ලබා දෙන්නේ නම්, එය [`None`] ආපසු ලබා දෙයි.
    ///
    /// `position()` කෙටි පරිපථයකි;වෙනත් වචන වලින් කිවහොත්, එය `true` සොයාගත් වහාම එය සැකසීම නවත්වනු ඇත.
    ///
    /// # පිටාර ගැලීමේ හැසිරීම
    ///
    /// මෙම ක්‍රමය පිටාර ගැලීම් වලින් ආරක්ෂා නොවේ, එබැවින් [`usize::MAX`] නොගැලපෙන මූලද්‍රව්‍යයන් තිබේ නම්, එය වැරදි ප්‍රති result ලයක් හෝ panics නිපදවයි.
    ///
    /// නිදොස් කිරීමේ ප්‍රකාශයන් සක්‍රීය කර ඇත්නම්, panic සහතික කෙරේ.
    ///
    /// # Panics
    ///
    /// අනුකාරකයට `usize::MAX` ට නොගැලපෙන මූලද්‍රව්‍ය තිබේ නම් මෙම ශ්‍රිතය panic විය හැකිය.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// පළමු `true` හි නතර වීම:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // තවත් මූලද්‍රව්‍යයන් ඇති බැවින් අපට තවමත් `iter` භාවිතා කළ හැකිය.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // ආපසු ලබා දුන් දර්ශකය අනුකාරක තත්වය මත රඳා පවතී
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// දකුණේ සිට අනුකාරකයේ මූලද්‍රව්‍යයක් සෙවීම, එහි දර්ශකය ආපසු ලබා දීම.
    ///
    /// `rposition()` `true` හෝ `false` ආපසු ලබා දෙන වසා දැමීමක් ගනී.
    /// එය අවසානය සිට ඇරඹෙන iterator හි එක් එක් මූලද්‍රව්‍යයට මෙම වසා දැමීම අදාළ වන අතර, ඔවුන්ගෙන් එක් අයෙකු `true` ආපසු ලබා දෙන්නේ නම්, `rposition()` [`Some(index)`] ආපසු ලබා දෙයි.
    ///
    /// ඔවුන් සියල්ලන්ම `false` ආපසු ලබා දෙන්නේ නම්, එය [`None`] ආපසු ලබා දෙයි.
    ///
    /// `rposition()` කෙටි පරිපථයකි;වෙනත් වචන වලින් කිවහොත්, එය `true` සොයාගත් වහාම එය සැකසීම නවත්වනු ඇත.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// පළමු `true` හි නතර වීම:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // තවත් මූලද්‍රව්‍යයන් ඇති බැවින් අපට තවමත් `iter` භාවිතා කළ හැකිය.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // `ExactSizeIterator` යන්නෙන් ගම්‍ය වන්නේ මූලද්‍රව්‍ය ගණන `usize` ට ගැලපෙන බවයි.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// අනුකාරකයේ උපරිම මූලද්‍රව්‍යය ලබා දෙයි.
    ///
    /// මූලද්රව්ය කිහිපයක් සමානව උපරිම නම්, අවසාන මූලද්රව්යය ආපසු ලබා දෙනු ලැබේ.
    /// අනුකාරකය හිස් නම්, [`None`] ආපසු ලබා දෙනු ලැබේ.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// අනුකාරකයේ අවම මූලද්‍රව්‍යය ලබා දෙයි.
    ///
    /// මූලද්රව්ය කිහිපයක් සමානව අවම නම්, පළමු මූලද්රව්යය ආපසු ලබා දෙනු ලැබේ.
    /// අනුකාරකය හිස් නම්, [`None`] ආපසු ලබා දෙනු ලැබේ.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// නිශ්චිත ශ්‍රිතයෙන් උපරිම අගය ලබා දෙන මූලද්‍රව්‍යය ලබා දෙයි.
    ///
    ///
    /// මූලද්රව්ය කිහිපයක් සමානව උපරිම නම්, අවසාන මූලද්රව්යය ආපසු ලබා දෙනු ලැබේ.
    /// අනුකාරකය හිස් නම්, [`None`] ආපසු ලබා දෙනු ලැබේ.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// නිශ්චිත සංසන්දනාත්මක ශ්‍රිතයට සාපේක්ෂව උපරිම අගය ලබා දෙන මූලද්‍රව්‍යය ලබා දෙයි.
    ///
    ///
    /// මූලද්රව්ය කිහිපයක් සමානව උපරිම නම්, අවසාන මූලද්රව්යය ආපසු ලබා දෙනු ලැබේ.
    /// අනුකාරකය හිස් නම්, [`None`] ආපසු ලබා දෙනු ලැබේ.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// නිශ්චිත ශ්‍රිතයෙන් අවම අගයක් ලබා දෙන මූලද්‍රව්‍යය ලබා දෙයි.
    ///
    ///
    /// මූලද්රව්ය කිහිපයක් සමානව අවම නම්, පළමු මූලද්රව්යය ආපසු ලබා දෙනු ලැබේ.
    /// අනුකාරකය හිස් නම්, [`None`] ආපසු ලබා දෙනු ලැබේ.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// නිශ්චිත සංසන්දනාත්මක ශ්‍රිතයට සාපේක්ෂව අවම අගයක් ලබා දෙන මූලද්‍රව්‍යය ලබා දෙයි.
    ///
    ///
    /// මූලද්රව්ය කිහිපයක් සමානව අවම නම්, පළමු මූලද්රව්යය ආපසු ලබා දෙනු ලැබේ.
    /// අනුකාරකය හිස් නම්, [`None`] ආපසු ලබා දෙනු ලැබේ.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// අනුකාරකයේ දිශාව ආපසු හරවයි.
    ///
    /// සාමාන්‍යයෙන්, iterator වමේ සිට දකුණට නැවත ගමන් කරයි.
    /// `rev()` භාවිතා කිරීමෙන් පසුව, ඉරේටරයක් ඒ වෙනුවට දකුණේ සිට වමට නැවත ක්‍රියා කරයි.
    ///
    /// මෙය කළ හැක්කේ iterator හි අවසානයක් තිබේ නම් පමණි, එබැවින් `rev()` ක්‍රියා කරන්නේ [`DoubleEndedIterator`] මත පමණි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// යුගලවල අනුකාරකයක් බහාලුම් යුගලයක් බවට පරිවර්තනය කරයි.
    ///
    /// `unzip()` යුගලවල සම්පූර්ණ අනුකාරකයක් පරිභෝජනය කරයි, එකතු දෙකක් නිපදවයි: එකක් යුගලයේ වම් මූලද්‍රව්‍යයෙන් සහ එකක් නිවැරදි මූලද්‍රව්‍ය වලින්.
    ///
    ///
    /// මෙම ශ්‍රිතය යම් ආකාරයකින් [`zip`] හි ප්‍රතිවිරුද්ධයයි.
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// එහි සියලු අංග පිටපත් කරන අනුකාරකයක් සාදයි.
    ///
    /// ඔබට `&T` ට වඩා iterator ඇති විට මෙය ප්‍රයෝජනවත් වේ, නමුත් ඔබට `T` ට වඩා iterator අවශ්‍ය වේ.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // පිටපත් කිරීම .map(|&x| x) ට සමාන වේ
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// එහි සියලුම අංග [ක්ලෝන] කරන අනුකාරකයක් සාදයි.
    ///
    /// ඔබට `&T` ට වඩා iterator ඇති විට මෙය ප්‍රයෝජනවත් වේ, නමුත් ඔබට `T` ට වඩා iterator අවශ්‍ය වේ.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // ක්ලෝන යනු නිඛිල සඳහා .map(|&x| x) හා සමාන වේ
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// අනුකාරකය නිමක් නැතිව පුනරාවර්තනය කරයි.
    ///
    /// [`None`] හි නවත්වනවා වෙනුවට, iterator මුල සිටම නැවත ආරම්භ වේ.නැවත නැවත ක්‍රියාත්මක කිරීමෙන් පසුව, එය නැවත ආරම්භයේදීම ආරම්භ වේ.නැවතත්.
    /// නැවතත්.
    /// Forever.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// අනුකාරකයේ මූලද්‍රව්‍ය සාරාංශ කරයි.
    ///
    /// එක් එක් මූලද්රව්යය ගෙන, ඒවා එකට එකතු කර ප්රති .ලය ලබා දෙයි.
    ///
    /// හිස් අනුකාරකයක් මඟින් වර්ගයේ ශුන්‍ය අගය ලබා දෙයි.
    ///
    /// # Panics
    ///
    /// `sum()` අමතා ප්‍රාථමික නිඛිල වර්ගයක් නැවත ලබා දෙන විට, ගණනය කිරීම පිටාර ගැලීම සහ නිදොස් කිරීමේ ප්‍රකාශයන් සක්‍රීය කර ඇත්නම් මෙම ක්‍රමය panic වනු ඇත.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// සියළුම මූලද්‍රව්‍යයන් ගුණ කරමින් සමස්ත අනුකාරකයට වඩා වෙනස් වේ
    ///
    /// හිස් අනුකාරකයක් මඟින් වර්ගයේ එක් අගයක් ලබා දෙයි.
    ///
    /// # Panics
    ///
    /// `product()` අමතා ප්‍රාථමික නිඛිල වර්ගයක් නැවත ලබා දෙන විට, ගණනය කිරීම් පිටාර ගැලීම සහ නිදොස් කිරීමේ ප්‍රකාශයන් සක්‍රීය කර ඇත්නම් ක්‍රමය panic වේ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) මෙම [`Iterator`] හි මූලද්‍රව්‍ය තවත් එකක් සමඟ සංසන්දනය කරයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) මෙම [`Iterator`] හි මූලද්‍රව්‍ය නිශ්චිත සංසන්දනාත්මක ශ්‍රිතයට සාපේක්ෂව වෙනත් අය සමඟ සංසන්දනය කරයි.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) මෙම [`Iterator`] හි මූලද්‍රව්‍ය තවත් එකක් සමඟ සංසන්දනය කරයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) මෙම [`Iterator`] හි මූලද්‍රව්‍ය නිශ්චිත සංසන්දනාත්මක ශ්‍රිතයට සාපේක්ෂව වෙනත් අය සමඟ සංසන්දනය කරයි.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// මෙම [`Iterator`] හි මූලද්‍රව්‍යයන් වෙනත් මූලද්‍රව්‍යයකට සමාන දැයි තීරණය කරයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// නිශ්චිත සමානාත්මතා ශ්‍රිතයට සාපේක්ෂව මෙම [`Iterator`] හි මූලද්‍රව්‍ය වෙනත් මූලද්‍රව්‍යයකට සමාන දැයි තීරණය කරයි.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// මෙම [`Iterator`] හි මූලද්‍රව්‍ය වෙනත් එකකට සමාන නොවේද යන්න තීරණය කරයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// මෙම [`Iterator`] හි මූලද්‍රව්‍යයන් තවත් එකකට වඩා [lexicographically](Ord#lexicographical-comparison) අඩු දැයි තීරණය කරයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// මෙම [`Iterator`] හි මූලද්‍රව්‍ය [lexicographically](Ord#lexicographical-comparison) අඩු හෝ වෙනත් මූලද්‍රව්‍යයකට සමානද යන්න තීරණය කරයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// මෙම [`Iterator`] හි මූලද්‍රව්‍යයන් තවත් එකකට වඩා [lexicographically](Ord#lexicographical-comparison) වැඩි දැයි තීරණය කරයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// මෙම [`Iterator`] හි මූලද්‍රව්‍ය [lexicographically](Ord#lexicographical-comparison) වෙනත් මූලද්‍රව්‍යයකට වඩා වැඩි හෝ සමාන දැයි තීරණය කරයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// මෙම අනුකාරකයේ මූලද්‍රව්‍ය වර්ග කර තිබේදැයි පරීක්ෂා කරයි.
    ///
    /// එනම්, එක් එක් මූලද්‍රව්‍යය සඳහා `a` සහ එහි පහත දැක්වෙන මූලද්‍රව්‍ය `b` සඳහා, `a <= b` රඳවා තබා ගත යුතුය.අනුකාරකය හරියටම ශුන්‍ය හෝ එක් මූලද්‍රව්‍යයක් ලබා දෙන්නේ නම්, `true` ආපසු ලබා දෙනු ලැබේ.
    ///
    /// `Self::Item` යනු `PartialOrd` පමණක් නොව `Ord` නොවේ නම්, ඉහත අර්ථ දැක්වීම මඟින් ඇඟවෙන්නේ අඛණ්ඩ අයිතම දෙකක් සැසඳිය නොහැකි නම් මෙම ශ්‍රිතය `false` ලබා දෙන බවයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// දී ඇති සංසන්දක ශ්‍රිතය භාවිතයෙන් මෙම අනුකාරකයේ මූලද්‍රව්‍ය වර්ග කර තිබේදැයි පරීක්ෂා කරයි.
    ///
    /// `PartialOrd::partial_cmp` භාවිතා කරනවා වෙනුවට, මෙම ශ්‍රිතය මූලද්‍රව්‍ය දෙකක අනුපිළිවෙල තීරණය කිරීම සඳහා දී ඇති `compare` ශ්‍රිතය භාවිතා කරයි.
    /// ඒ හැර, එය [`is_sorted`] ට සමාන ය;වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// දී ඇති යතුරු නිස්සාරණ ශ්‍රිතය භාවිතයෙන් මෙම අනුකාරකයේ මූලද්‍රව්‍ය වර්ග කර තිබේදැයි පරීක්ෂා කරයි.
    ///
    /// අනුකාරකයේ මූලද්‍රව්‍යයන් කෙලින්ම සංසන්දනය කරනවා වෙනුවට, මෙම ශ්‍රිතය `f` විසින් තීරණය කරන පරිදි මූලද්‍රව්‍යවල යතුරු සංසන්දනය කරයි.
    /// ඒ හැර, එය [`is_sorted`] ට සමාන ය;වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// [TrustedRandomAccess] බලන්න
    // අසාමාන්‍ය නම නම් ක්‍රම විභේදනයෙහි නම ගැටීම වළක්වා ගැනීමයි #76479 බලන්න.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}