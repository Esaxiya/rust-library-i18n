use crate::iter::{FusedIterator, TrustedLen};

/// මූලද්‍රව්‍යයක් හරියටම එක් වරක් ලබා දෙන අනුකාරකයක් සාදයි.
///
/// තනි අගයක් [`chain()`] වෙනත් ආකාරයේ පුනරාවර්තනයකට අනුවර්තනය කිරීමට මෙය බහුලව භාවිතා වේ.
/// සමහර විට ඔබට සෑම දෙයක්ම පාහේ ආවරණය වන අනුකාරකයක් ඇත, නමුත් ඔබට අමතර විශේෂ අවස්ථාවක් අවශ්‍ය වේ.
/// සමහර විට ඔබට iterator මත ක්‍රියා කරන ශ්‍රිතයක් ඇත, නමුත් ඔබට අවශ්‍ය වන්නේ එක් අගයක් පමණි.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// මූලික භාවිතය:
///
/// ```
/// use std::iter;
///
/// // එකක් හුදකලා අංකයයි
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // එකක්, අපට ලැබෙන්නේ එපමණයි
/// assert_eq!(None, one.next());
/// ```
///
/// වෙනත් අනුකාරකයක් සමඟ දම්වැල බැඳීම.
/// `.foo` බහලුමේ සෑම ගොනුවක්ම නැවත සැකසීමට අපට අවශ්‍ය යැයි කියමු, නමුත් වින්‍යාස ගොනුවක්,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // අපට DirEntry-s හි අනුකාරකයේ සිට PathBufs හි අනුකාරකයක් බවට පරිවර්තනය කළ යුතුය, එබැවින් අපි සිතියම භාවිතා කරමු
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // දැන්, අපගේ වින්‍යාස ගොනුව සඳහා අපගේ අනුකාරකය
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // අනුකාරක දෙක එකට එක් විශාල අනුකාරකයකට සම්බන්ධ කරන්න
/// let files = dirs.chain(config);
///
/// // මෙය අපට .foo සහ .foorc හි ඇති සියලුම ගොනු ලබා දෙනු ඇත
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// මූලද්‍රව්‍යයක් එක් වරක් ලබා දෙන අනුකාරකය.
///
/// මෙම `struct` නිර්මාණය කර ඇත්තේ [`once()`] ශ්‍රිතයෙනි.වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}