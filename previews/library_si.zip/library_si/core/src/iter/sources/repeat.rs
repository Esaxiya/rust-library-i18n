use crate::iter::{FusedIterator, TrustedLen};

/// තනි මූලද්‍රව්‍යයක් නිමක් නැතිව පුනරාවර්තනය කරන නව අනුකාරකයක් සාදයි.
///
/// `repeat()` ශ්‍රිතය තනි අගයක් නැවත නැවතත් පුනරාවර්තනය කරයි.
///
/// `repeat()` වැනි අසීමිත iterator බොහෝ විට [`Iterator::take()`] වැනි ඇඩැප්ටර සමඟ භාවිතා කරනුයේ ඒවා සීමිත කිරීම සඳහා ය.
///
/// ඔබට අවශ්‍ය iterator හි මූලද්‍රව්‍ය වර්ගය `Clone` ක්‍රියාත්මක නොකරන්නේ නම් හෝ නැවත නැවත මූලද්‍රව්‍යය මතකයේ තබා ගැනීමට ඔබට අවශ්‍ය නැතිනම්, ඔබට ඒ වෙනුවට [`repeat_with()`] ශ්‍රිතය භාවිතා කළ හැකිය.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// මූලික භාවිතය:
///
/// ```
/// use std::iter;
///
/// // අංක 4 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // ඔව්, තවමත් හතරක්
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// [`Iterator::take()`] සමඟ සීමිතයි:
///
/// ```
/// use std::iter;
///
/// // ඒ අන්තිම උදාහරණය හතරේ පහර වැඩියි.අපි සතුව ඇත්තේ හතරේ පහර හතරක් පමණි.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... දැන් අපි ඉවරයි
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// මූලද්‍රව්‍යයක් නිමක් නැතිව පුනරාවර්තනය කරන අනුකාරකය.
///
/// මෙම `struct` නිර්මාණය කර ඇත්තේ [`repeat()`] ශ්‍රිතයෙනි.වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}