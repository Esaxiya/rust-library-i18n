use crate::fmt;

/// එක් එක් පුනරාවර්තනය මඟින් සපයන ලද වසා දැමීම `F: FnMut() -> Option<T>` ලෙස හඳුන්වන නව අනුකාරකයක් සාදයි.
///
/// විශේෂිත වර්ගයක් නිර්මාණය කිරීම සහ ඒ සඳහා [`Iterator`] trait ක්‍රියාත්මක කිරීම සඳහා වඩාත් වාචික වාක්‍ය ඛණ්ඩයක් භාවිතා නොකර ඕනෑම හැසිරීමක් සමඟ අභිරුචි අනුකාරකයක් නිර්මාණය කිරීමට මෙය ඉඩ දෙයි.
///
/// `FromFn` iterator වසා දැමීමේ හැසිරීම ගැන උපකල්පන නොකරන බවත්, එබැවින් ගතානුගතිකව [`FusedIterator`] ක්‍රියාත්මක නොකරන බවත්, [`Iterator::size_hint()`] එහි පෙරනිමි `(0, None)` වෙතින් අභිබවා යන බවත් සලකන්න.
///
///
/// වසා දැමීමෙන් නැවත නැවත හරහා තත්වය නිරීක්ෂණය කිරීමට ග්‍රහණයන් සහ එහි පරිසරය භාවිතා කළ හැකිය.Iterator භාවිතා කරන ආකාරය මත පදනම්ව, මෙය වසා දැමීමේදී [`move`] යතුරු පදය නියම කිරීම අවශ්‍ය වේ.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// [module-level documentation] වෙතින් කවුන්ටරය නැවත ක්‍රියාත්මක කරමු:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // අපේ ගණන වැඩි කරන්න.මේ නිසා තමයි අපි බිංදුවෙන් පටන් ගත්තේ.
///     count += 1;
///
///     // අපි ගණන් කිරීම අවසන් කර තිබේද නැද්ද යන්න පරීක්ෂා කරන්න.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// එක් එක් පුනරාවර්තනය මඟින් සපයන ලද වසා දැමීම `F: FnMut() -> Option<T>` ලෙස හඳුන්වන අනුකාරකයක්.
///
/// මෙම `struct` නිර්මාණය කර ඇත්තේ [`iter::from_fn()`] ශ්‍රිතයෙනි.
/// වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}