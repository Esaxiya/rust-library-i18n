use crate::iter::{FusedIterator, TrustedLen};

/// සපයන ලද වැසීමට ආයාචනා කිරීමෙන් කම්මැලි ලෙස හරියටම එක් වරක් වටිනාකමක් ජනනය කරන අනුකාරකයක් සාදයි.
///
/// තනි අගය උත්පාදක යන්ත්රය [`chain()`] වෙනත් ආකාරයේ පුනරාවර්තනයකට අනුවර්තනය කිරීමට මෙය බහුලව භාවිතා වේ.
/// සමහර විට ඔබට සෑම දෙයක්ම පාහේ ආවරණය වන අනුකාරකයක් ඇත, නමුත් ඔබට අමතර විශේෂ අවස්ථාවක් අවශ්‍ය වේ.
/// සමහර විට ඔබට iterator මත ක්‍රියා කරන ශ්‍රිතයක් ඇත, නමුත් ඔබට අවශ්‍ය වන්නේ එක් අගයක් පමණි.
///
/// [`once()`] මෙන් නොව, මෙම ශ්‍රිතය ඉල්ලීම මත කම්මැලි ලෙස උත්පාදනය කරයි.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// මූලික භාවිතය:
///
/// ```
/// use std::iter;
///
/// // එකක් හුදකලා අංකයයි
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // එකක්, අපට ලැබෙන්නේ එපමණයි
/// assert_eq!(None, one.next());
/// ```
///
/// වෙනත් අනුකාරකයක් සමඟ දම්වැල බැඳීම.
/// `.foo` බහලුමේ සෑම ගොනුවක්ම නැවත සැකසීමට අපට අවශ්‍ය යැයි කියමු, නමුත් වින්‍යාස ගොනුවක්,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // අපට DirEntry-s හි අනුකාරකයේ සිට PathBufs හි අනුකාරකයක් බවට පරිවර්තනය කළ යුතුය, එබැවින් අපි සිතියම භාවිතා කරමු
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // දැන්, අපගේ වින්‍යාස ගොනුව සඳහා අපගේ අනුකාරකය
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // අනුකාරක දෙක එකට එක් විශාල අනුකාරකයකට සම්බන්ධ කරන්න
/// let files = dirs.chain(config);
///
/// // මෙය අපට .foo සහ .foorc හි ඇති සියලුම ගොනු ලබා දෙනු ඇත
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// සපයන ලද වසා දැමීමේ `F: FnOnce() -> A` යෙදීමෙන් `A` වර්ගයේ තනි මූලද්‍රව්‍යයක් ලබා දෙන අනුකාරකයක්.
///
///
/// මෙම `struct` නිර්මාණය කර ඇත්තේ [`once_with()`] ශ්‍රිතයෙනි.
/// වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}