use crate::iter::{FusedIterator, TrustedLen};

/// සපයන ලද වසා දැමීම, පුනරාවර්තනය, යෙදීමෙන් `A` වර්ගයේ මූලද්‍රව්‍ය නිමක් නැතිව පුනරාවර්තනය වන නව අනුකාරකයක් සාදයි. `F: FnMut() -> A`.
///
/// `repeat_with()` ශ්‍රිතය පුනරාවර්තකය නැවත නැවතත් අමතයි.
///
/// `repeat_with()` වැනි අසීමිත iterator බොහෝ විට [`Iterator::take()`] වැනි ඇඩැප්ටර සමඟ භාවිතා කරනුයේ ඒවා සීමිත කිරීම සඳහා ය.
///
/// ඔබට අවශ්‍ය iterator හි මූලද්‍රව්‍ය වර්ගය [`Clone`] ක්‍රියාත්මක කරන්නේ නම් සහ ප්‍රභව මූලද්‍රව්‍යය මතකයේ තබා ගැනීම හරි නම්, ඔබ ඒ වෙනුවට [`repeat()`] ශ්‍රිතය භාවිතා කළ යුතුය.
///
///
/// `repeat_with()` විසින් නිපදවන iterator එකක් [`DoubleEndedIterator`] නොවේ.
/// [`DoubleEndedIterator`] ආපසු ලබා දීමට ඔබට `repeat_with()` අවශ්‍ය නම්, කරුණාකර ඔබේ භාවිත අවස්ථාව පැහැදිලි කරමින් GitHub ගැටලුවක් විවෘත කරන්න.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// මූලික භාවිතය:
///
/// ```
/// use std::iter;
///
/// // `Clone` නොවන හෝ මිල අධික බැවින් තවමත් මතකයේ රැඳී සිටීමට අකමැති වර්ගයක යම් වටිනාකමක් අප සතුව ඇතැයි උපකල්පනය කරමු:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // නිශ්චිත වටිනාකමක් සදහටම:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// විකෘතිය භාවිතා කිරීම සහ සීමිත වීම:
///
/// ```rust
/// use std::iter;
///
/// // ශුන්‍යයේ සිට තුන්වන බලය දෙක දක්වා:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... දැන් අපි ඉවරයි
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// සපයන ලද වසා දැමීමේ `F: FnMut() -> A` යෙදීමෙන් `A` වර්ගයේ මූලද්‍රව්‍ය නිමක් නැතිව පුනරාවර්තනය කරන අනුකාරකයක්.
///
///
/// මෙම `struct` නිර්මාණය කර ඇත්තේ [`repeat_with()`] ශ්‍රිතයෙනි.
/// වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}