//! සංයුක්ත බාහිර ක්‍රියාකාරීත්වය.
//!
//! ඔබ යම් ආකාරයක එකතුවක් සොයාගෙන ඇති අතර, එම එකතුවෙහි මූලද්‍රව්‍යයන් මත මෙහෙයුමක් කිරීමට අවශ්‍ය නම්, ඔබ ඉක්මනින් 'iterators' වෙත දිව යයි.
//! අයිඩරේටර්ස් විශාල වශයෙන් මුග්ධ Rust කේතයේ භාවිතා වේ, එබැවින් ඔවුන් සමඟ හුරු වීම වටී.
//!
//! වැඩි විස්තර කිරීමට පෙර, මෙම මොඩියුලය ව්‍යුහගත කර ඇති ආකාරය ගැන කතා කරමු:
//!
//! # Organization
//!
//! මෙම මොඩියුලය බොහෝ දුරට වර්ගය අනුව සංවිධානය වී ඇත:
//!
//! * [Traits] මූලික කොටස වේ: මෙම traits නිර්වචනය කරන්නේ කුමන ආකාරයේ අනුකාරක තිබේද සහ ඔබට ඒවා සමඟ කළ හැකි දේ.මෙම traits හි ක්‍රම මඟින් අමතර අධ්‍යයන කාලයක් යෙදවීම වටී.
//! * [Functions] මූලික අනුකාරක කිහිපයක් නිර්මාණය කිරීමට ප්‍රයෝජනවත් ක්‍රම කිහිපයක් සපයන්න.
//! * [Structs] බොහෝ විට මෙම මොඩියුලයේ traits හි විවිධ ක්‍රමවල ප්‍රතිලාභ වර්ග වේ.ඔබට සාමාන්‍යයෙන් `struct` ට වඩා `struct` නිර්මාණය කරන ක්‍රමය දෙස බැලීමට අවශ්‍ය වනු ඇත.
//! එයට හේතුව පිළිබඳ වැඩි විස්තර සඳහා, '[ක්‍රියාත්මක කිරීමේ අනුකාරකය](#ක්‍රියාත්මක කිරීම-අනුකාරකය)' බලන්න.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! ඒක තමයි!අපි අනුකාරක හාරමු.
//!
//! # Iterator
//!
//! මෙම මොඩියුලයේ හදවත සහ ආත්මය [`Iterator`] trait වේ.[`Iterator`] හි හරය මේ වගේ ය:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! අනුකාරකයට [`next`] ක්‍රමයක් ඇත, එය කැඳවූ විට [`විකල්පය]] ලබා දෙයි<Item>`.
//! [`next`] මූලද්‍රව්‍ය පවතින තාක් කල් [`Some(Item)`] නැවත ලබා දෙනු ඇති අතර, ඒවා සියල්ලම අවසන් වූ පසු, නැවත නැවත කිරීම අවසන් වූ බව දැක්වීමට `None` ආපසු එවනු ඇත.
//! තනි ක්‍රියාකාරකය නැවත නැවත ආරම්භ කිරීමට තෝරා ගත හැකි අතර, එබැවින් [`next`] නැවත ඇමතීම යම් අවස්ථාවක දී [`Some(Item)`] නැවත ලබා දීම ආරම්භ කිරීමට හෝ නොවීමට ඉඩ ඇත (නිදසුනක් ලෙස, [`TryIter`] බලන්න).
//!
//!
//! [`ඉටරේටර්] හි සම්පූර්ණ අර්ථ දැක්වීමට තවත් ක්‍රම ගණනාවක් ඇතුළත් වේ, නමුත් ඒවා පෙරනිමි ක්‍රම වන අතර එය [`next`] මත ගොඩනගා ඇති අතර එමඟින් ඔබ ඒවා නොමිලයේ ලබා ගනී.
//!
//! අනුකාරක ද සංයුක්ත වන අතර වඩාත් සංකීර්ණ සැකසුම් ආකාරයන් සිදු කිරීම සඳහා ඒවා එකට සම්බන්ධ කිරීම සාමාන්‍ය දෙයකි.වැඩි විස්තර සඳහා පහත [Adapters](#adapters) කොටස බලන්න.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # පුනරාවර්තනයේ ආකාර තුනකි
//!
//! එකතුවකින් අනුකාරක සෑදිය හැකි පොදු ක්‍රම තුනක් ඇත:
//!
//! * `iter()`, එය `&T` ඉක්මවා යයි.
//! * `iter_mut()`, එය `&mut T` ඉක්මවා යයි.
//! * `into_iter()`, එය `T` ඉක්මවා යයි.
//!
//! සම්මත පුස්තකාලයේ ඇති විවිධ දේ සුදුසු ස්ථාන තුනෙන් එකක් හෝ කිහිපයක් ක්‍රියාත්මක කළ හැකිය.
//!
//! # අනුකාරකය ක්‍රියාත්මක කිරීම
//!
//! ඔබේම අනුකාරකයක් සෑදීම සඳහා පියවර දෙකක් ඇතුළත් වේ: අනුකාරකයේ තත්වය රඳවා තබා ගැනීම සඳහා `struct` නිර්මාණය කිරීම, ඉන්පසු එම `struct` සඳහා [`Iterator`] ක්‍රියාත්මක කිරීම.
//! මෙම මොඩියුලය තුළ බොහෝ 'ව්‍යුහයන්' ඇත්තේ එබැවිනි: එක් එක් iterator සහ iterator ඇඩැප්ටරය සඳහා එකක් තිබේ.
//!
//! `1` සිට `5` දක්වා ගණන් කරන `Counter` නමින් අනුකාරකයක් සාදමු:
//!
//! ```
//! // පළමුව, struct:
//!
//! /// එක සිට පහ දක්වා ගණනය කරන අනුකාරකය
//! struct Counter {
//!     count: usize,
//! }
//!
//! // අපගේ ගණන එකකින් ආරම්භ කිරීමට අපට අවශ්‍යය, එබැවින් උදව් කිරීමට new() ක්‍රමයක් එකතු කරමු.
//! // මෙය තදින්ම අවශ්‍ය නොවේ, නමුත් පහසුය.
//! // අපි `count` බිංදුවෙන් ආරම්භ කරන බව සලකන්න, `next()`'s ක්‍රියාත්මක කිරීමේදී පහත දැක්වේ.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // ඉන්පසුව, අපි අපගේ `Counter` සඳහා `Iterator` ක්‍රියාත්මක කරමු:
//!
//! impl Iterator for Counter {
//!     // අපි උපයෝගී කරගනිමින් ගණනය කරන්නෙමු
//!     type Item = usize;
//!
//!     // next() අවශ්‍ය එකම ක්‍රමය වේ
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // අපේ ගණන වැඩි කරන්න.මේ නිසා තමයි අපි බිංදුවෙන් පටන් ගත්තේ.
//!         self.count += 1;
//!
//!         // අපි ගණන් කිරීම අවසන් කර තිබේද නැද්ද යන්න පරීක්ෂා කරන්න.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // දැන් අපට එය භාවිතා කළ හැකිය!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! මේ ආකාරයට [`next`] ඇමතීම නැවත නැවත සිදු වේ.Rust හි `None` වෙත ළඟා වන තුරු ඔබේ අනුකාරකයේ [`next`] ඇමතිය හැකි ඉදිකිරීමක් ඇත.ඊළඟට අපි යමු.
//!
//! `Iterator` අභ්‍යන්තරව `next` ලෙස හඳුන්වන `nth` සහ `fold` වැනි ක්‍රම පෙරනිමියෙන් ක්‍රියාත්මක කරන බව සලකන්න.
//! කෙසේ වෙතත්, `next` ඇමතීමෙන් තොරව වඩාත් කාර්යක්ෂමව ගණනය කළ හැකි නම්, `nth` සහ `fold` වැනි ක්‍රම අභිරුචි ලෙස ක්‍රියාත්මක කිරීම ලිවිය හැකිය.
//!
//! # `for` ලූප සහ `IntoIterator`
//!
//! Rust හි `for` loop syntax ඇත්ත වශයෙන්ම iterator සඳහා සීනි වේ.`for` සඳහා මූලික උදාහරණයක් මෙන්න:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! මෙය අංක 1 සිට 5 දක්වා සංඛ්‍යා මුද්‍රණය කරනු ඇත.නමුත් ඔබ මෙහි යමක් දකිනු ඇත: අපි කිසි විටෙකත් අපගේ vector වෙත කිසිවක් නොකියමු.ලබා දෙන්නේ කුමක්ද?
//!
//! යමක් අනුකාරකයක් බවට පරිවර්තනය කිරීම සඳහා සම්මත පුස්තකාලයේ trait ඇත: [`IntoIterator`].
//! මෙම trait හි එක් ක්‍රමයක් ඇත, [`into_iter`], එය [`IntoIterator`] ක්‍රියාත්මක කරන දෙය අනුකාරකයක් බවට පරිවර්තනය කරයි.
//! අපි නැවත එම `for` පුඩුවක් දෙස බලමු, සහ සම්පාදකයා එය පරිවර්තනය කරන්නේ කුමක් ද:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust මෙය සීනි කරයි:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! පළමුව, අපි අගය මත `into_iter()` අමතන්නෙමු.ඉන්පසුව, අපි නැවත පැමිණෙන iterator සමඟ ගැලපෙන අතර, `None` දකින තුරු [`next`] නැවත නැවතත් අමතන්න.
//! එම අවස්ථාවෙහිදී, අපි `break` ලූපයෙන් ඉවතට ගියෙමු.
//!
//! මෙහි තවත් සියුම් බිට් එකක් තිබේ: සම්මත පුස්තකාලයේ [`IntoIterator`] සිත්ගන්නාසුළු ලෙස ක්‍රියාත්මක කිරීම අඩංගු වේ:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! වෙනත් වචන වලින් කිවහොත්, සියළුම [ඉටරේටර්] විසින්ම නැවත පැමිණීමෙන් [`IntoIterator`] ක්‍රියාත්මක කරයි.මෙයින් කරුණු දෙකක් අදහස් වේ:
//!
//! 1. ඔබ [`Iterator`] ලියන්නේ නම්, ඔබට එය `for` පුඩුවක් සමඟ භාවිතා කළ හැකිය.
//! 2. ඔබ එකතුවක් නිර්මාණය කරන්නේ නම්, ඒ සඳහා [`IntoIterator`] ක්‍රියාත්මක කිරීමෙන් ඔබේ එකතුව `for` ලූපය සමඟ භාවිතා කිරීමට ඉඩ දෙනු ඇත.
//!
//! # යොමු දැක්වීමෙන් අනුකරණය කිරීම
//!
//! [`into_iter()`] අගය අනුව `self` ගන්නා බැවින්, එකතුවක් හරහා නැවත යෙදීම සඳහා `for` පුඩුවක් භාවිතා කිරීමෙන් එම එකතුව පරිභෝජනය කරයි.බොහෝ විට, එකතුවක් පරිභෝජනය නොකර නැවත කියවීමට ඔබට අවශ්‍ය විය හැකිය.
//! බොහෝ එකතු කිරීම් සාම්ප්‍රදායිකව පිළිවෙලින් `iter()` සහ `iter_mut()` ලෙස හැඳින්වෙන යොමු කිරීම් හරහා අනුකාරක සපයන ක්‍රම ඉදිරිපත් කරයි:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` තවමත් මෙම ශ්‍රිතයට අයත් වේ.
//! ```
//!
//! එකතු කිරීමේ වර්ගයක් වන `C` `iter()` ලබා දෙන්නේ නම්, එය සාමාන්‍යයෙන් `&C` සඳහා `IntoIterator` ද ක්‍රියාත්මක කරයි.
//! ඒ හා සමානව, `iter_mut()` ලබා දෙන `C` එකතුවක් සාමාන්‍යයෙන් `iter_mut()` වෙත පැවරීමෙන් `&mut C` සඳහා `IntoIterator` ක්‍රියාත්මක කරයි.මෙය පහසු කෙටිමං සක්‍රීය කරයි:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // `values.iter_mut()` හා සමානයි
//!     *x += 1;
//! }
//! for x in &values { // `values.iter()` හා සමානයි
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! බොහෝ එකතු කිරීම් `iter()` ලබා දෙන අතර, සියල්ලම `iter_mut()` ලබා නොදේ.
//! උදාහරණයක් ලෙස, [`HashSet<T>`] හෝ [`HashMap<K, V>`] හි යතුරු විකෘති කිරීමෙන් යතුරු හැෂ් වෙනස් වුවහොත් එකතුව නොගැලපෙන තත්වයකට පත් කළ හැකිය, එබැවින් මෙම එකතු කිරීම් ඉදිරිපත් කරන්නේ `iter()` පමණි.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! [`Iterator`] එකක් ගෙන තවත් [`Iterator`] ආපසු ලබා දෙන කාර්යයන් බොහෝ විට 'iterator adapters' ලෙස හැඳින්වේ, ඒවා 'ඇඩැප්ටරයේ' ආකාරයකි
//! pattern'.
//!
//! පොදු පුනරාවර්තක ඇඩැප්ටර වලට [`map`], [`take`], සහ [`filter`] ඇතුළත් වේ.
//! වැඩි විස්තර සඳහා, ඔවුන්ගේ ලියකියවිලි බලන්න.
//!
//! Iterator ඇඩැප්ටරය panics නම්, iterator නිශ්චිතව දක්වා නැති (නමුත් මතක ආරක්ෂිත) තත්වයක පවතිනු ඇත.
//! Rust හි අනුවාදයන් හරහා මෙම තත්වය එලෙසම පවතින බවට සහතිකයක් නොමැත, එබැවින් ඔබ භීතියට පත් වූ iterator විසින් ආපසු ලබා දුන් නිශ්චිත අගයන් මත විශ්වාසය තැබීමෙන් වැළකී සිටිය යුතුය.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! අනුකාරක (සහ iterator [adapters](#adapters))*කම්මැලි* වේ. මෙයින් අදහස් කරන්නේ iterator එකක් සෑදීමෙන් _do_ මුළුමනින්ම වෙනස් නොවන බවයි. ඔබ [`next`] අමතන තුරු කිසිවක් සිදු නොවේ.
//! සමහර විට එහි අතුරු ආබාධ සඳහා පමණක් අනුකාරකයක් නිර්මාණය කිරීමේදී මෙය ව්‍යාකූලත්වයට හේතු වේ.
//! නිදසුනක් ලෙස, [`map`] ක්‍රමය මඟින් එය නැවත කියවන සෑම මූලද්‍රව්‍යයක්ම වැසීමක් කරයි:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! මෙය කිසිදු අගයක් මුද්‍රණය නොකරනු ඇත, මන්ද අපි එය භාවිතා කරන්නාට වඩා iterator එකක් පමණක් නිර්මාණය කළෙමු.මේ ආකාරයේ හැසිරීම ගැන සම්පාදකයා අපට අනතුරු අඟවයි:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! එහි අතුරු ආබාධ සඳහා [`map`] ලිවීමට මුග්ධ ක්‍රමය වන්නේ `for` පුඩුවක් භාවිතා කිරීම හෝ [`for_each`] ක්‍රමය අමතන්න:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! අනුකාරකයක් ඇගයීමට තවත් පොදු ක්‍රමයක් නම් නව එකතුවක් නිෂ්පාදනය කිරීම සඳහා [`collect`] ක්‍රමය භාවිතා කිරීමයි.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! අනුභව කරන්නන් සීමිත විය යුතු නැත.නිදසුනක් ලෙස, විවෘත පරාසයක් යනු අසීමිත අනුකාරකයකි:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! අසීමිත iterator එකක් සීමිත එකක් බවට පත් කිරීම සඳහා [`take`] iterator ඇඩැප්ටරය භාවිතා කිරීම සාමාන්‍ය දෙයකි:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! මෙමඟින් `0` සිට `4` දක්වා අංක මුද්‍රණය කරනු ලැබේ.
//!
//! ගණිතමය වශයෙන් සීමිත කාලයකදී ප්‍රති result ලයක් තීරණය කළ හැකි වුවද, අසීමිත අනුකාරක ක්‍රම පිළිබඳ ක්‍රම අවසන් නොවන බව මතක තබා ගන්න.
//! නිශ්චිතවම, [`min`] වැනි ක්‍රම, පොදුවේ ගත් කල, අනුකාරකයේ සෑම මූලද්‍රව්‍යයක්ම ගමන් කිරීම අවශ්‍ය වන අතර, කිසිදු අනන්ත අනුකාරකයක් සඳහා සාර්ථකව ආපසු නොඑනු ඇත.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // අපොයි!අසීමිත පුඩුවක්!
//! // `ones.min()` අසීමිත පුඩුවක් ඇති කරයි, එබැවින් අපි මෙම ස්ථානයට ළඟා නොවෙමු!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;