use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// *අනුප්‍රාප්තිකයා* සහ *පූර්වගාමියා* මෙහෙයුම් පිළිබඳ සංකල්පයක් ඇති වස්තු.
///
/// *අනුප්‍රාප්තික* මෙහෙයුම වඩා සංසන්දනය කරන අගයන් දෙසට ගමන් කරයි.
/// *පූර්වගාමියා* මෙහෙයුම අඩු සංසන්දනය කරන අගයන් දෙසට ගමන් කරයි.
///
/// # Safety
///
/// මෙම trait `unsafe` වන බැවින් `unsafe trait TrustedLen` ක්‍රියාත්මක කිරීමේ ආරක්ෂාව සඳහා එය ක්‍රියාත්මක කිරීම නිවැරදි විය යුතු අතර මෙම trait භාවිතා කිරීමේ ප්‍රති results ල වෙනත් ආකාරයකින් `unsafe` කේතය මගින් විශ්වාස කළ හැකි අතර එය නිවැරදි වීමට සහ ලැයිස්තුගත බැඳීම් ඉටු කිරීමට හැකි වේ.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// `start` සිට `end` දක්වා ලබා ගැනීමට අවශ්‍ය *අනුප්‍රාප්තික* පියවර ගණන ලබා දෙයි.
    ///
    /// පියවර ගණන `usize` පිරී ඉතිරී ගියහොත් (හෝ අනන්තය, හෝ `end` කිසි විටෙකත් ළඟා නොවන්නේ නම්) `None` ලබා දෙයි.
    ///
    ///
    /// # Invariants
    ///
    /// ඕනෑම `a`, `b`, සහ `n` සඳහා:
    ///
    /// * `steps_between(&a, &b) == Some(n)` නම් සහ `Step::forward_checked(&a, n) == Some(b)` නම් පමණි
    /// * `steps_between(&a, &b) == Some(n)` නම් සහ `Step::backward_checked(&a, n) == Some(a)` නම් පමණි
    /// * `steps_between(&a, &b) == Some(n)` `a <= b` නම් පමණි
    ///   * සහසම්බන්ධය: `steps_between(&a, &b) == Some(0)` නම් සහ `a == b` නම් පමණි
    ///   * `a <= b` මගින් _not_ යන්නෙන් `steps_between(&a, &b) != None` අදහස් වන බව සලකන්න;
    ///     `b` වෙත යාමට `usize::MAX` පියවරකට වඩා අවශ්‍ය වන අවස්ථාව මෙයයි
    /// * `steps_between(&a, &b) == None` `a > b` නම්
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// `self` `count` වාරයේ *අනුප්‍රාප්තිකයා* ලබා ගැනීමෙන් ලබා ගත හැකි අගය ලබා දෙයි.
    ///
    /// මෙය `Self` මඟින් සහය දක්වන අගයන් පරාසය ඉක්මවා ගියහොත්, `None` ලබා දෙයි.
    ///
    /// # Invariants
    ///
    /// ඕනෑම `a`, `n`, සහ `m` සඳහා:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// `n + m` පිරී ඉතිරී නොයන ඕනෑම `a`, `n`, සහ `m` සඳහා:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// ඕනෑම `a` සහ `n` සඳහා:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// `self` `count` වාරයේ *අනුප්‍රාප්තිකයා* ලබා ගැනීමෙන් ලබා ගත හැකි අගය ලබා දෙයි.
    ///
    /// මෙය `Self` මඟින් සහය දක්වන අගයන් පරාසය ඉක්මවා ගියහොත්, මෙම ශ්‍රිතයට panic, එතුම හෝ සංතෘප්ත වීමට අවසර ඇත.
    ///
    /// යෝජිත හැසිරීම වන්නේ දෝශ නිරාකරණ සක්‍රීය කර ඇති විට panic වෙත වන අතර වෙනත් ආකාරයකින් එතීමට හෝ සංතෘප්ත කිරීමට ය.
    ///
    /// අනාරක්ෂිත කේතය පිටාර ගැලීමෙන් පසු හැසිරීමේ නිරවද්‍යතාවය මත රඳා නොසිටිය යුතුය.
    ///
    /// # Invariants
    ///
    /// පිටාර ගැලීමක් සිදු නොවන ඕනෑම `a`, `n`, සහ `m` සඳහා:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// පිටාර ගැලීමක් සිදු නොවන ඕනෑම `a` සහ `n` සඳහා:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// `self` `count` වාරයේ *අනුප්‍රාප්තිකයා* ලබා ගැනීමෙන් ලබා ගත හැකි අගය ලබා දෙයි.
    ///
    /// # Safety
    ///
    /// මෙම මෙහෙයුම සඳහා `Self` මඟින් සහය දක්වන අගයන් පරාසය පිටාර ගැලීම නිර්වචනය නොකළ හැසිරීමකි.
    /// මෙය පිටාර ගැලීමක් නොවන බවට ඔබට සහතික විය නොහැකි නම්, ඒ වෙනුවට `forward` හෝ `forward_checked` භාවිතා කරන්න.
    ///
    /// # Invariants
    ///
    /// ඕනෑම `a` සඳහා:
    ///
    /// * `b > a` වැනි `b` තිබේ නම්, `Step::forward_unchecked(a, 1)` ඇමතීම ආරක්ෂිත වේ
    /// * `steps_between(&a, &b) == Some(n)` වැනි `b`, `n` තිබේ නම්, ඕනෑම `m <= n` සඳහා `Step::forward_unchecked(a, m)` ඇමතීම ආරක්ෂිත වේ.
    ///
    ///
    /// පිටාර ගැලීමක් සිදු නොවන ඕනෑම `a` සහ `n` සඳහා:
    ///
    /// * `Step::forward_unchecked(a, n)` `Step::forward(a, n)` ට සමාන වේ
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// `self` `count` වාරයේ *පූර්වගාමියා* ගැනීමෙන් ලබා ගත හැකි අගය ලබා දෙයි.
    ///
    /// මෙය `Self` මඟින් සහය දක්වන අගයන් පරාසය ඉක්මවා ගියහොත්, `None` ලබා දෙයි.
    ///
    /// # Invariants
    ///
    /// ඕනෑම `a`, `n`, සහ `m` සඳහා:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// ඕනෑම `a` සහ `n` සඳහා:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// `self` `count` වාරයේ *පූර්වගාමියා* ගැනීමෙන් ලබා ගත හැකි අගය ලබා දෙයි.
    ///
    /// මෙය `Self` මඟින් සහය දක්වන අගයන් පරාසය ඉක්මවා ගියහොත්, මෙම ශ්‍රිතයට panic, එතුම හෝ සංතෘප්ත වීමට අවසර ඇත.
    ///
    /// යෝජිත හැසිරීම වන්නේ දෝශ නිරාකරණ සක්‍රීය කර ඇති විට panic වෙත වන අතර වෙනත් ආකාරයකින් එතීමට හෝ සංතෘප්ත කිරීමට ය.
    ///
    /// අනාරක්ෂිත කේතය පිටාර ගැලීමෙන් පසු හැසිරීමේ නිරවද්‍යතාවය මත රඳා නොසිටිය යුතුය.
    ///
    /// # Invariants
    ///
    /// පිටාර ගැලීමක් සිදු නොවන ඕනෑම `a`, `n`, සහ `m` සඳහා:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// පිටාර ගැලීමක් සිදු නොවන ඕනෑම `a` සහ `n` සඳහා:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// `self` `count` වාරයේ *පූර්වගාමියා* ගැනීමෙන් ලබා ගත හැකි අගය ලබා දෙයි.
    ///
    /// # Safety
    ///
    /// මෙම මෙහෙයුම සඳහා `Self` මඟින් සහය දක්වන අගයන් පරාසය පිටාර ගැලීම නිර්වචනය නොකළ හැසිරීමකි.
    /// මෙය පිටාර ගැලීමක් නොවන බවට ඔබට සහතික විය නොහැකි නම්, ඒ වෙනුවට `backward` හෝ `backward_checked` භාවිතා කරන්න.
    ///
    /// # Invariants
    ///
    /// ඕනෑම `a` සඳහා:
    ///
    /// * `b < a` වැනි `b` තිබේ නම්, `Step::backward_unchecked(a, 1)` ඇමතීම ආරක්ෂිත වේ
    /// * `steps_between(&b, &a) == Some(n)` වැනි `b`, `n` තිබේ නම්, ඕනෑම `m <= n` සඳහා `Step::backward_unchecked(a, m)` ඇමතීම ආරක්ෂිත වේ.
    ///
    ///
    /// පිටාර ගැලීමක් සිදු නොවන ඕනෑම `a` සහ `n` සඳහා:
    ///
    /// * `Step::backward_unchecked(a, n)` `Step::backward(a, n)` ට සමාන වේ
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// පූර්ණ සංඛ්‍යා සාහිත්‍යකරුවන් විවිධ වර්ග වලට නිරාකරණය වන නිසා මේවා තවමත් සාර්ව ජනනය වී ඇත.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // ආරක්ෂාව: අමතන්නාට `start + n` පිටාර ගැලීමක් සිදු නොවන බවට සහතික විය යුතුය.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // ආරක්ෂාව: අමතන්නාට `start - n` පිටාර ගැලීමක් සිදු නොවන බවට සහතික විය යුතුය.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // දෝශ නිරාකරණයේදී, පිටාර ගැලීම මත panic අවුලුවන්න.
            // මෙය මුදා හැරීම් වලදී සම්පූර්ණයෙන්ම ඉවත් කළ යුතුය.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // උදා: ගණිතය එතීමට ඉඩ දෙන්න `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // දෝශ නිරාකරණයේදී, පිටාර ගැලීම මත panic අවුලුවන්න.
            // මෙය මුදා හැරීම් වලදී සම්පූර්ණයෙන්ම ඉවත් කළ යුතුය.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // උදා: ගණිතය එතීමට ඉඩ දෙන්න `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // මෙය $u_narrower <=usize මත රඳා පවතී
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // n පරාසය ඉක්මවා ඇත්නම්, `unsigned_start + n` ද වැඩිය
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // n පරාසය ඉක්මවා ඇත්නම්, `unsigned_start - n` ද වැඩිය
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // මෙය $i_narrower <=usize මත රඳා පවතී
                        //
                        // සමස්ථානිකයට වාත්තු කිරීම පළල විස්තාරණය කරන නමුත් ලකුණ ආරක්ෂා කරයි.
                        // සමස්ථානික පරාසය තුළ නොගැලපෙන වෙනස ගණනය කිරීම සඳහා අයිසයිස් අවකාශයේ එතීමේ_සබ් භාවිතා කර භාවිතා කිරීමට වාත්තු කරන්න.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // i8 සඳහා 200 පරාසය ඉක්මවා ගියද, `Step::forward(-120_i8, 200) == Some(80_i8)` වැනි අවස්ථා එතීම.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // එකතු කිරීම පිරී ඉතිරී ගියේය
                            }
                        }
                        // N පරාසය ඉක්මවා ඇත්නම් උදා
                        // u8, i8 සඳහා වන මුළු පරාසයට වඩා එය විශාල වන බැවින් `any_i8 + n` අනිවාර්යයෙන්ම i8 පිටාර ගැලේ.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // i8 සඳහා 200 පරාසය ඉක්මවා ගියද, `Step::forward(-120_i8, 200) == Some(80_i8)` වැනි අවස්ථා එතීම.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // අඩු කිරීම පිරී ඉතිරී ගියේය
                            }
                        }
                        // N පරාසය ඉක්මවා ඇත්නම් උදා
                        // u8, i8 සඳහා වන මුළු පරාසයට වඩා එය විශාල වන බැවින් `any_i8 - n` අනිවාර්යයෙන්ම i8 පිටාර ගැලේ.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // වෙනස උදා: සඳහා විශාල නම්
                            // i128, එය බිටු අඩු ප්‍රමාණයක් භාවිතා කිරීමට ද විශාල වනු ඇත.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // ආරක්ෂාව: res යනු වලංගු යුනිකෝඩ් පරිමාණයකි
            // (0x110000 ට වඩා පහළින් සහ 0xD800..0xE000 හි නොවේ)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // ආරක්ෂාව: res යනු වලංගු යුනිකෝඩ් පරිමාණයකි
        // (0x110000 ට වඩා පහළින් සහ 0xD800..0xE000 හි නොවේ)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // ආරක්ෂාව: මෙය පිරී ඉතිරී නොයන බවට ඇමතුම්කරු සහතික විය යුතුය
        // වරහනක් සඳහා අගයන් පරාසය.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // ආරක්ෂාව: මෙය පිරී ඉතිරී නොයන බවට ඇමතුම්කරු සහතික විය යුතුය
            // වරහනක් සඳහා අගයන් පරාසය.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // ආරක්ෂාව: පෙර කොන්ත්රාත්තුව නිසා මෙය සහතික කෙරේ
        // වලංගු වරහනක් ලෙස අමතන්නා විසින්.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // ආරක්ෂාව: මෙය පිරී ඉතිරී නොයන බවට ඇමතුම්කරු සහතික විය යුතුය
        // වරහනක් සඳහා අගයන් පරාසය.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // ආරක්ෂාව: මෙය පිරී ඉතිරී නොයන බවට ඇමතුම්කරු සහතික විය යුතුය
            // වරහනක් සඳහා අගයන් පරාසය.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // ආරක්ෂාව: පෙර කොන්ත්රාත්තුව නිසා මෙය සහතික කෙරේ
        // වලංගු වරහනක් ලෙස අමතන්නා විසින්.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // ආරක්ෂාව: පූර්ව කොන්දේසිය පරීක්ෂා කර ඇත
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // ආරක්ෂාව: පූර්ව කොන්දේසිය පරීක්ෂා කර ඇත
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// මෙම මැක්‍රෝස් විවිධ පරාස වර්ග සඳහා `ExactSizeIterator` impls ජනනය කරයි.
//
// * `ExactSizeIterator::len` සෑම විටම නිශ්චිත `usize` ආපසු ලබා දීමට අවශ්‍ය වේ, එබැවින් කිසිදු පරාසයක් `usize::MAX` ට වඩා දිගු විය නොහැක.
//
// * `Range<_>` හි පූර්ණ සංඛ්‍යා වර්ග සඳහා මෙය `usize` ට වඩා පටු හෝ පළල වර්ග සඳහා වේ.
//   `RangeInclusive<_>` හි නිඛිල වර්ග සඳහා මෙය උදා: `usize` ට වඩා *තදින් පටු* වර්ග සඳහා වේ
//   `(0..=u64::MAX).len()` `u64::MAX + 1` වනු ඇත.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // ඉහත තර්කයට අනුව මේවා නොගැලපෙන නමුත් ඒවා ඉවත් කිරීම Rust 1.0.0 හි ස්ථාවර වූ බැවින් ඒවා වෙනස් කිරීමකි.
    // ඉතින් උදා
    // `(0..66_000_u32).len()` උදාහරණයක් ලෙස බිට් 16 වේදිකාවල දෝෂයක් හෝ අනතුරු ඇඟවීමකින් තොරව සම්පාදනය කරනු ඇත, නමුත් වැරදි ප්‍රති .ලයක් ලබා දීම දිගටම කරගෙන යන්න.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // ඉහත තර්කයට අනුව මේවා නොගැලපෙන නමුත් ඒවා ඉවත් කිරීම Rust 1.26.0 හි ස්ථාවර වූ බැවින් ඒවා වෙනස් කිරීමකි.
    // ඉතින් උදා
    // `(0..=u16::MAX).len()` උදාහරණයක් ලෙස බිට් 16 වේදිකාවල දෝෂයක් හෝ අනතුරු ඇඟවීමකින් තොරව සම්පාදනය කරනු ඇත, නමුත් වැරදි ප්‍රති .ලයක් ලබා දීම දිගටම කරගෙන යන්න.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // ආරක්ෂාව: පූර්ව කොන්දේසිය පරීක්ෂා කර ඇත
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // ආරක්ෂාව: පූර්ව කොන්දේසිය පරීක්ෂා කර ඇත
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // ආරක්ෂාව: පූර්ව කොන්දේසිය පරීක්ෂා කර ඇත
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // ආරක්ෂාව: පූර්ව කොන්දේසිය පරීක්ෂා කර ඇත
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // ආරක්ෂාව: පූර්ව කොන්දේසිය පරීක්ෂා කර ඇත
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // ආරක්ෂාව: පූර්ව කොන්දේසිය පරීක්ෂා කර ඇත
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}