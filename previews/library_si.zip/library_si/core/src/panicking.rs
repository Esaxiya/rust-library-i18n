//! ලිබ්කෝර් සඳහා Panic සහාය
//!
//! මූලික පුස්තකාලයට භීතිකාව නිර්වචනය කළ නොහැක, නමුත් එය භීතිකාව * ප්‍රකාශ කරයි.
//! මෙයින් අදහස් කරන්නේ libcore හි ඇති කාර්යයන් panic වෙත අවසර දී ඇති නමුත් එය ප්‍රයෝජනවත් වීමට උඩුමහලේ crate විසින් libcore භාවිතා කිරීම සඳහා භීතිය නිර්වචනය කළ යුතු බවයි.
//! භීතිකාව සඳහා වත්මන් අතුරු මුහුණත:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! මෙම අර්ථ දැක්වීම ඕනෑම සාමාන්‍ය පණිවිඩයක් සමඟ කලබල වීමට ඉඩ සලසයි, නමුත් එය `Box<Any>` අගයක් සමඟ අසමත් වීමට ඉඩ නොදේ.
//! (`PanicInfo` හි ඇත්තේ `&(dyn Any + Send)` ය, ඒ සඳහා අපි 'PanicInfo: : internal_constructor` හි ව්‍යාජ අගයක් පුරවන්නෙමු.) මෙයට හේතුව වන්නේ libcore වෙන් කිරීමට ඉඩ නොදීමයි.
//!
//!
//! මෙම මොඩියුලයේ තවත් භීතික කාර්යයන් කිහිපයක් අඩංගු වේ, නමුත් මේවා සම්පාදකයාට අවශ්‍ය ලාංඡන අයිතම පමණි.සියලුම panics මෙම එක් ශ්‍රිතයක් හරහා ක්‍රියාත්මක වේ.
//! සත්‍ය සංකේතය `#[panic_handler]` ගුණාංගය හරහා ප්‍රකාශයට පත් කෙරේ.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// ආකෘතිකරණය භාවිතා නොකරන විට ලිබ්කෝර්ගේ `panic!` මැක්‍රෝ යටින් ක්‍රියාත්මක කිරීම.
#[cold]
// ඇමතුම් අඩවි වල හැකිතාක් දුරට කේත පිපිරීම වළක්වා ගැනීම සඳහා panic_immediate_abort මිස කිසි විටෙකත් පේළි නොගන්න
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // පිටාර ගැලීම සහ අනෙකුත් `Assert` MIR ටර්මිනේටර් මත panic සඳහා කෝඩජන් අවශ්‍ය වේ
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // ප්‍රමාණය ඉහළින් අඩු කිරීම සඳහා format_args! ("{}", Expr) වෙනුවට Arguments::new_v1 භාවිතා කරන්න.
    // Format_args!එක්ස්ප්‍රෙක්ස් ලිවීමට මැක්‍රෝ විසින් ස්ට්‍රස් ඩිස්ප්ලේ trait භාවිතා කරයි, එය Formatter::pad ලෙස හැඳින්වේ, එය නූල් කප්පාදු කිරීම සහ පෑඩින් කිරීම සඳහා ඉඩ දිය යුතුය (මෙහි කිසිවක් භාවිතා නොකලද).
    //
    // Arguments::new_v1 භාවිතා කිරීමෙන් සම්පාදකයාට ප්‍රතිදාන ද්විමය වෙතින් Formatter::pad මඟ හැරිය හැකි අතර එය කිලෝබයිට් කිහිපයක් දක්වා ඉතිරි වේ.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // සංයුක්ත ඇගයීමට ලක් කළ panics සඳහා අවශ්‍ය වේ
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // OOB array/slice ප්‍රවේශය මත panic සඳහා කෝඩජන් අවශ්‍ය වේ
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// ආකෘතිකරණය භාවිතා කරන විට ලිබ්කෝර්ගේ `panic!` මැක්‍රෝ යටින් ක්‍රියාත්මක කිරීම.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // සටහන මෙම ශ්‍රිතය කිසි විටෙකත් FFI සීමාව ඉක්මවා නොයයි;එය Rust-to-Rust ඇමතුමක් වන අතර එය `#[panic_handler]` ශ්‍රිතයට නිරාකරණය වේ.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // ආරක්ෂාව: `panic_impl` ආරක්ෂිත Rust කේතයෙන් අර්ථ දක්වා ඇති අතර එම නිසා ඇමතීමට ආරක්ෂිත වේ.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// `assert_eq!` සහ `assert_ne!` මැක්‍රෝස් සඳහා අභ්‍යන්තර ක්‍රියාකාරිත්වය
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}