// ignore-tidy-filelength

//! පෙති කළමනාකරණය සහ හැසිරවීම.
//!
//! වැඩි විස්තර සඳහා [`std::slice`] බලන්න.
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// පිරිසිදු rust memchr ක්‍රියාත්මක කිරීම, rust-memchr වෙතින් ලබාගෙන ඇත
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// මෙම ශ්‍රිතය පොදු වන්නේ ඒකක පරීක්ෂණ ගොඩවල් සඳහා වෙනත් ක්‍රමයක් නොමැති නිසා පමණි.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// පෙත්තෙහි ඇති මූලද්රව්ය සංඛ්යාව ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // සුරක්ෂිතභාවය: දිග ශබ්දය අප භාවිතයක් ලෙස සම්ප්‍රේෂණය කරන නිසා (එය විය යුතුය)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // ආරක්ෂාව: `&[T]` සහ `FatPtr<T>` එකම පිරිසැලසුමක් ඇති නිසා මෙය ආරක්ෂිතයි.
            // මෙම සහතිකය ලබා දිය හැක්කේ `std` ට පමණි.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: එය ස්ථායී වන විට `crate::ptr::metadata(self)` සමඟ ප්‍රතිස්ථාපනය කරන්න.
            // මෙම ලිවීමේදී මෙය "Const-stable functions can only call other const-stable functions" දෝෂයක් ඇති කරයි.
            //

            // සුරක්ෂිතභාවය: * const T සිට `PtrRepr` සංගමයෙන් වටිනාකමට ප්‍රවේශ වීම ආරක්ෂිතයි
            // සහ PtrComponents<T>එකම මතක පිරිසැලසුම් ඇත.
            // මෙම සහතිකය ලබා දිය හැක්කේ std ට පමණි.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// පෙත්තෙහි දිග 0 ක් තිබේ නම් `true` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// පෙත්තෙහි පළමු අංගය හෝ `None` හිස් නම් එය ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// පෙත්තෙහි පළමු අංගයට විකෘති දර්ශකයක් හෝ හිස් නම් `None` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// පෙත්තෙහි පළමු හා ඉතිරි සියලුම මූලද්‍රව්‍ය හෝ `None` හිස් නම් එය ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// පෙත්තෙහි පළමු හා ඉතිරි සියලුම මූලද්‍රව්‍ය හෝ `None` හිස් නම් එය ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// පෙත්තෙහි අන්තිම සහ ඉතිරි සියලුම මූලද්‍රව්‍ය ලබා දෙයි, නැතහොත් `None` හිස් නම්.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// පෙත්තෙහි අන්තිම සහ ඉතිරි සියලුම මූලද්‍රව්‍ය ලබා දෙයි, නැතහොත් `None` හිස් නම්.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// පෙත්තෙහි අවසාන අංගය හෝ `None` හිස් නම් එය ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// පෙත්තෙහි ඇති අවසාන අයිතමයට විකෘති දර්ශකයක් ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// දර්ශකයේ වර්ගය මත පදනම්ව මූලද්‍රව්‍යයක් හෝ අනුග්‍රහයක් වෙත යොමු කිරීමක් ලබා දෙයි.
    ///
    /// - තනතුරක් ලබා දෙන්නේ නම්, එම ස්ථානයේ ඇති මූලද්‍රව්‍යයට යොමු කිරීමක් හෝ සීමාවන් ඉක්මවා ගියහොත් `None` යවයි.
    ///
    /// - පරාසයක් ලබා දෙන්නේ නම්, එම පරාසයට අනුරූපී අනුග්‍රහය ලබා දෙයි, නැතහොත් සීමාව ඉක්මවා ගියහොත් `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// දර්ශකයේ සීමාවෙන් ඔබ්බට ගියහොත්, දර්ශකයේ වර්ගය අනුව ([`get`] බලන්න) හෝ `None` මත පදනම්ව මූලද්‍රව්‍යයක් හෝ අනුග්‍රහයක් සඳහා විකෘති යොමු කිරීමක් ලබා දෙයි.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// සීමාවන් පරික්ෂා නොකර, මූලද්‍රව්‍යයක් හෝ උපසිරැසියක් වෙත යොමු කිරීමක් ලබා දෙයි.
    ///
    /// ආරක්ෂිත විකල්පයක් සඳහා [`get`] බලන්න.
    ///
    /// # Safety
    ///
    /// සීමාවෙන් පිටත දර්ශකයක් සමඟ මෙම ක්‍රමය ඇමතීම *[නිර්වචනය නොකළ හැසිරීම]* එහි ප්‍රති ing ලයක් ලෙස යොමුව භාවිතා නොකලද.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // ආරක්ෂාව: අමතන්නා `get_unchecked` සඳහා වන බොහෝ ආරක්ෂක අවශ්‍යතා සපුරාලිය යුතුය;
        // `self` ආරක්ෂිත යොමු කිරීමක් බැවින් පෙත්ත අවලංගු කළ හැකිය.
        // ආපසු ලබා දුන් දර්ශකය ආරක්ෂිත වන්නේ `SliceIndex` හි impls එය බව සහතික කළ යුතු බැවිනි.
        unsafe { &*index.get_unchecked(self) }
    }

    /// සීමාවන් පරික්ෂා කිරීමකින් තොරව, මූලද්‍රව්‍යයක් හෝ අනුග්‍රහයක් සඳහා විකෘති යොමු කිරීමක් ලබා දෙයි.
    ///
    /// ආරක්ෂිත විකල්පයක් සඳහා [`get_mut`] බලන්න.
    ///
    /// # Safety
    ///
    /// සීමාවෙන් පිටත දර්ශකයක් සමඟ මෙම ක්‍රමය ඇමතීම *[නිර්වචනය නොකළ හැසිරීම]* එහි ප්‍රති ing ලයක් ලෙස යොමුව භාවිතා නොකලද.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // ආරක්ෂාව: අමතන්නා `get_unchecked_mut` සඳහා ආරක්ෂක අවශ්‍යතා සපුරාලිය යුතුය;
        // `self` ආරක්ෂිත යොමු කිරීමක් බැවින් පෙත්ත අවලංගු කළ හැකිය.
        // ආපසු ලබා දුන් දර්ශකය ආරක්ෂිත වන්නේ `SliceIndex` හි impls එය බව සහතික කළ යුතු බැවිනි.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// පෙත්තෙහි බෆරයට අමු දර්ශකයක් ලබා දෙයි.
    ///
    /// පෙත්තක් මෙම ශ්‍රිතය නැවත ලබා දෙන දර්ශකය ඉක්මවා යන බව ඇමතුම්කරු සහතික කළ යුතුය, එසේ නොමැති නම් එය කුණු කසළ වෙත යොමු වේ.
    ///
    /// මෙම දර්ශකය හෝ එයින් ලබාගත් ඕනෑම දර්ශකයක් භාවිතා කරමින් (non-transitively) දර්ශකය පෙන්වන මතකය කිසි විටෙකත් (`UnsafeCell` ඇතුළත හැර) ලියා නොමැති බව අමතන්නා සහතික කළ යුතුය.
    /// ඔබට පෙත්තෙහි අන්තර්ගතය විකෘති කිරීමට අවශ්‍ය නම්, [`as_mut_ptr`] භාවිතා කරන්න.
    ///
    /// මෙම පෙත්තෙන් සඳහන් කර ඇති බහාලුම වෙනස් කිරීම මඟින් එහි බෆරය නැවත වෙන්කරවා ගැනීමට ඉඩ ඇති අතර එමඟින් එහි ඇති ඕනෑම දර්ශකයක් අවලංගු වේ.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// පෙත්තෙහි බෆරයට අනාරක්ෂිත විකෘති දර්ශකයක් ලබා දෙයි.
    ///
    /// පෙත්තක් මෙම ශ්‍රිතය නැවත ලබා දෙන දර්ශකය ඉක්මවා යන බව ඇමතුම්කරු සහතික කළ යුතුය, එසේ නොමැති නම් එය කුණු කසළ වෙත යොමු වේ.
    ///
    /// මෙම පෙත්තෙන් සඳහන් කර ඇති බහාලුම වෙනස් කිරීම මඟින් එහි බෆරය නැවත වෙන්කරවා ගැනීමට ඉඩ ඇති අතර එමඟින් එහි ඇති ඕනෑම දර්ශකයක් අවලංගු වේ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// පෙත්ත පුරා විහිදෙන අමු දර්ශක දෙක ලබා දෙයි.
    ///
    /// ආපසු එන පරාසය අඩක් විවෘතව ඇත, එයින් අදහස් කරන්නේ අවසාන දර්ශකය *එක් අතීතයක්* පෙත්තෙහි අවසාන අංගය බවයි.
    /// මේ ආකාරයට හිස් පෙත්තක් සමාන දර්ශක දෙකකින් නිරූපණය වන අතර, දර්ශක දෙක අතර වෙනස පෙත්තෙහි ප්‍රමාණය නියෝජනය කරයි.
    ///
    /// මෙම දර්ශක භාවිතා කිරීම පිළිබඳ අනතුරු ඇඟවීම් සඳහා [`as_ptr`] බලන්න.පෙත්තෙහි වලංගු මූලද්‍රව්‍යයක් වෙත යොමු නොවන බැවින් අවසාන දර්ශකය අමතර ප්‍රවේශම් වීමක් අවශ්‍ය වේ.
    ///
    /// C ++ හි බහුලව දක්නට ලැබෙන පරිදි, මතකයේ ඇති මූලද්‍රව්‍ය පරාසයක් වෙත යොමු කිරීම සඳහා දර්ශක දෙකක් භාවිතා කරන විදේශීය අතුරුමුහුණත් සමඟ අන්තර් ක්‍රියා කිරීමට මෙම ශ්‍රිතය ප්‍රයෝජනවත් වේ.
    ///
    ///
    /// මූලද්‍රව්‍යයකට දර්ශකයක් මෙම පෙත්තෙහි මූලද්‍රව්‍යයක් ගැන සඳහන් කරන්නේ දැයි පරීක්ෂා කිරීම ද ප්‍රයෝජනවත් වේ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // ආරක්ෂාව: මෙහි `add` ආරක්ෂිතයි, මන්ද:
        //
        //   - දර්ශක දෙකම එකම වස්තුවක කොටසකි, වස්තුව කෙළින්ම යොමු කිරීම ද ගණන් කරයි.
        //
        //   - මෙහි සඳහන් කර ඇති පරිදි පෙත්තෙහි ප්‍රමාණය isize::MAX බයිට් වලට වඩා විශාල නොවේ:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - පෙති ලිපින අවකාශයේ අවසානය පසුකර නොයන බැවින් සම්බන්ධ වීමට එතීමක් නොමැත.
        //
        // pointer::add හි ප්‍රලේඛනය බලන්න.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// පෙත්ත පුරා විහිදෙන අනාරක්ෂිත විකෘති දර්ශක දෙක ලබා දෙයි.
    ///
    /// ආපසු එන පරාසය අඩක් විවෘතව ඇත, එයින් අදහස් කරන්නේ අවසාන දර්ශකය *එක් අතීතයක්* පෙත්තෙහි අවසාන අංගය බවයි.
    /// මේ ආකාරයට හිස් පෙත්තක් සමාන දර්ශක දෙකකින් නිරූපණය වන අතර, දර්ශක දෙක අතර වෙනස පෙත්තෙහි ප්‍රමාණය නියෝජනය කරයි.
    ///
    /// මෙම දර්ශක භාවිතා කිරීම පිළිබඳ අනතුරු ඇඟවීම් සඳහා [`as_mut_ptr`] බලන්න.
    /// පෙත්තෙහි වලංගු මූලද්‍රව්‍යයක් වෙත යොමු නොවන බැවින් අවසාන දර්ශකය අමතර ප්‍රවේශම් වීමක් අවශ්‍ය වේ.
    ///
    /// C ++ හි බහුලව දක්නට ලැබෙන පරිදි, මතකයේ ඇති මූලද්‍රව්‍ය පරාසයක් වෙත යොමු කිරීම සඳහා දර්ශක දෙකක් භාවිතා කරන විදේශීය අතුරුමුහුණත් සමඟ අන්තර් ක්‍රියා කිරීමට මෙම ශ්‍රිතය ප්‍රයෝජනවත් වේ.
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // ආරක්ෂාව: මෙහි `add` ආරක්ෂිත වන්නේ මන්දැයි ඉහත as_ptr_range() බලන්න.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// පෙත්තෙහි මූලද්රව්ය දෙකක් මාරු කරයි.
    ///
    /// # Arguments
    ///
    /// * a, පළමු මූලද්‍රව්‍යයේ දර්ශකය
    /// * b, දෙවන මූලද්‍රව්‍යයේ දර්ශකය
    ///
    /// # Panics
    ///
    /// `a` හෝ `b` සීමාවෙන් පිටත නම් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // එක් vector වෙතින් විකෘති ණය දෙකක් ලබා ගත නොහැක, ඒ වෙනුවට අමු දර්ශක භාවිතා කරන්න.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // ආරක්ෂාව: `pa` සහ `pb` නිර්මාණය කර ඇත්තේ ආරක්ෂිත විකෘති යොමු කිරීම් වලින් සහ යොමු කිරීමෙනි
        // පෙත්තෙහි ඇති මූලද්‍රව්‍ය වලට වලංගු වන අතර ඒවා වලංගු හා පෙළගැස්වීමට සහතික වේ.
        // `a` සහ `b` පිටුපස ඇති මූලද්‍රව්‍යයන්ට ප්‍රවේශ වීම පරීක්ෂා කර ඇති අතර සීමාව ඉක්මවා යන විට panic වනු ඇත.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// පෙත්තෙහි මූලද්‍රව්‍ය අනුපිළිවෙල ප්‍රතිස්ථාපනය කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // ඉතා කුඩා වර්ග සඳහා, සාමාන්‍ය මාර්ගයේ ඇති සියලුම තනි කියවීම් දුර්වල ලෙස ක්‍රියා කරයි.
        // විශාල කැබැල්ලක් පටවා ලේඛනයක් ආපසු හැරවීමෙන් කාර්යක්ෂම නොබැඳි load/store ලබා දී අපට වඩා හොඳින් කළ හැකිය.
        //

        // නොබැඳි කියවීම් කාර්යක්ෂමද යන්න අපට වඩා හොඳින් දන්නා බැවින් (උදාහරණයක් ලෙස විවිධ ARM අනුවාදයන් අතර වෙනස් වන බැවින්) සහ හොඳම කැබලි ප්‍රමාණය කුමක් දැයි LLVM ඉතා මැනවින් දනී.
        // අවාසනාවකට මෙන්, LLVM 4.0 (2017-05) වන විට එය ලූපය මුදා හරිනු ඇත, එබැවින් අප මෙය කළ යුතුය.
        // (උපකල්පනය: ප්‍රතිලෝම කරදරකාරී වන්නේ පැති එකිනෙකට වෙනස් ලෙස පෙළගැස්විය හැකි බැවිනි-දිග අමුතු වූ විට වනු ඇත-එබැවින් මැද හා පූර්ණ ලෙස පෙලගැසී ඇති සිම්ඩ් භාවිතා කිරීමට පෙර හා පසු විකාශන ක්‍රමයක් නොමැත.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // U8s පරිහරණය කිරීමේදී ආපසු හැරවීමට llvm.bswap සහජයෙන්ම භාවිතා කරන්න
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // ආරක්ෂාව: මෙහි පරීක්ෂා කිරීමට කරුණු කිහිපයක් තිබේ:
                //
                // - ඉහත cfg පරීක්ෂාව හේතුවෙන් `chunk` 4 හෝ 8 බව සලකන්න.එබැවින් `chunk - 1` ධනාත්මක වේ.
                // - ලූප් චෙක්පත සහතික වන පරිදි `i` දර්ශකය සමඟ සුචිගත කිරීම හොඳයි
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - `ln - i - chunk = ln - (i + chunk)` දර්ශකය සමඟ සුචිගත කිරීම හොඳයි:
                //   - `i + chunk > 0` සුළුපටු සත්‍යයකි.
                //   - ලූප් චෙක්පත් සහතික කරයි:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, එබැවින් අඩු කිරීම ගලා එන්නේ නැත.
                // - `read_unaligned` සහ `write_unaligned` ඇමතුම් හොඳයි:
                //   - `pa` `i` දර්ශකය වෙත යොමු වන අතර එහිදී `i < ln / 2 - (chunk - 1)` (ඉහත බලන්න) සහ `pb` දර්ශක `ln - i - chunk` වෙත යොමු වේ, එබැවින් දෙකම `self` අවසානයට වඩා අවම වශයෙන් `chunk` බොහෝ බයිට් දුරින් පිහිටා ඇත.
                //
                //   - ඕනෑම ආරම්භක මතකයක් වලංගු `usize` වේ.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // u32 හි u16s ආපසු හැරවීමට භ්‍රමණය-16-භාවිතා කරන්න
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // ආරක්ෂාව: නොබැඳි u32 `i + 1 < ln` නම් `i` වෙතින් කියවිය හැකිය
                // (සහ පැහැදිලිවම `i < ln`), මන්ද සෑම මූලද්‍රව්‍යයක්ම බයිට් 2 ක් වන අතර අපි 4 කියවමු.
                //
                // `i + chunk - 1 < ln / 2` # තත්වය අතර
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // එය දිග 2 ට බෙදූ ප්‍රමාණයට වඩා අඩු බැවින් එය සීමාවන්ගෙන් යුක්ත විය යුතුය.
                //
                // `0 < i + chunk <= ln` කොන්දේසිය සැමවිටම ගරු කරන බවත්, `pb` දර්ශකය ආරක්ෂිතව භාවිතා කළ හැකි බවත් මෙයින් අදහස් වේ.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // ආරක්ෂාව: `i` පෙත්තෙහි දිගෙන් අඩකට වඩා අඩුය
            // `i` සහ `ln - i - 1` වෙත ප්‍රවේශ වීම ආරක්ෂිතයි (`i` 0 සිට ආරම්භ වන අතර `ln / 2 - 1` ට වඩා ඉදිරියට නොයනු ඇත).
            // එහි ප්‍රති ing ලයක් ලෙස `pa` සහ `pb` දර්ශක වලංගු හා පෙළගස්වා ඇති අතර ඒවා කියවා ලිවිය හැකිය.
            //
            //
            unsafe {
                // ආරක්ෂිත හුවමාරුවේ සීමාවන් පරීක්ෂා කිරීම වළක්වා ගැනීම සඳහා අනාරක්ෂිත හුවමාරුව.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// පෙත්තට උඩින් ඉරේටරයක් ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// එක් එක් අගය වෙනස් කිරීමට ඉඩ දෙන අනුකාරකයක් ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// `size` දිගින් යුත් windows දිගට වඩා නැවත ක්‍රියාකරවන්නෙකු ලබා දෙයි.
    /// windows අතිච්ඡාදනය.
    /// පෙත්ත `size` ට වඩා කෙටි නම්, iterator කිසිදු අගයක් ලබා නොදේ.
    ///
    /// # Panics
    ///
    /// `size` 0 නම් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// පෙත්ත `size` ට වඩා කෙටි නම්:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// පෙත්තක ආරම්භයේ සිට ඇරඹෙන පෙත්තක `chunk_size` මූලද්‍රව්‍යවලට වඩා වර්‍ගයක් නැවත ලබා දෙයි.
    ///
    /// කුට්ටි පෙති වන අතර ඒවා අතිච්ඡාදනය නොවේ.`chunk_size` පෙත්තෙහි දිග බෙදන්නේ නැත්නම්, අන්තිම කැබැල්ලේ දිග `chunk_size` නොතිබෙනු ඇත.
    ///
    /// සෑම විටම හරියටම `chunk_size` මූලද්‍රව්‍යවල කුට්ටි ආපසු ලබා දෙන මෙම iterator හි ප්‍රභේදයක් සඳහා [`chunks_exact`] බලන්න, සහ එකම iterator සඳහා [`rchunks`] නමුත් පෙත්ත අවසානයේ ආරම්භ වේ.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 නම් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// පෙත්තක ආරම්භයේ සිට ඇරඹෙන පෙත්තක `chunk_size` මූලද්‍රව්‍යවලට වඩා වර්‍ගයක් නැවත ලබා දෙයි.
    ///
    /// කුට්ටි විකෘති පෙති වන අතර ඒවා අතිච්ඡාදනය නොවේ.`chunk_size` පෙත්තෙහි දිග බෙදන්නේ නැත්නම්, අන්තිම කැබැල්ලේ දිග `chunk_size` නොතිබෙනු ඇත.
    ///
    /// සෑම විටම හරියටම `chunk_size` මූලද්‍රව්‍යවල කුට්ටි ආපසු ලබා දෙන මෙම iterator හි ප්‍රභේදයක් සඳහා [`chunks_exact_mut`] බලන්න, සහ එකම iterator සඳහා [`rchunks_mut`] නමුත් පෙත්ත අවසානයේ ආරම්භ වේ.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 නම් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// පෙත්තක ආරම්භයේ සිට ඇරඹෙන පෙත්තක `chunk_size` මූලද්‍රව්‍යවලට වඩා වර්‍ගයක් නැවත ලබා දෙයි.
    ///
    /// කුට්ටි පෙති වන අතර ඒවා අතිච්ඡාදනය නොවේ.
    /// `chunk_size` පෙත්තෙහි දිග බෙදන්නේ නැත්නම්, අවසාන `chunk_size-1` දක්වා වූ මූලද්‍රව්‍යයන් මඟ හරිනු ඇති අතර එය iterator හි `remainder` ශ්‍රිතයෙන් ලබා ගත හැකිය.
    ///
    ///
    /// සෑම කැබැල්ලකම හරියටම `chunk_size` මූලද්‍රව්‍යයන් ඇති හෙයින්, සම්පාදකයාට බොහෝ විට [`chunks`] වලට වඩා හොඳ ප්‍රති ing ල කේතය ප්‍රශස්තිකරණය කළ හැකිය.
    ///
    /// මෙම අනුකාරකයේ ප්‍රභේදයක් සඳහා [`chunks`] බලන්න, ඉතිරි කොටස කුඩා කැබැල්ලක් ලෙසද, [`rchunks_exact`] එකම අනුකාරකය සඳහාද ලබා දෙන නමුත් පෙත්ත අවසානයේ ආරම්භ වේ.
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 නම් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// පෙත්තක ආරම්භයේ සිට ඇරඹෙන පෙත්තක `chunk_size` මූලද්‍රව්‍යවලට වඩා වර්‍ගයක් නැවත ලබා දෙයි.
    ///
    /// කුට්ටි විකෘති පෙති වන අතර ඒවා අතිච්ඡාදනය නොවේ.
    /// `chunk_size` පෙත්තෙහි දිග බෙදන්නේ නැත්නම්, අවසාන `chunk_size-1` දක්වා වූ මූලද්‍රව්‍යයන් මඟ හරිනු ඇති අතර එය iterator හි `into_remainder` ශ්‍රිතයෙන් ලබා ගත හැකිය.
    ///
    ///
    /// සෑම කැබැල්ලකම හරියටම `chunk_size` මූලද්‍රව්‍යයන් ඇති හෙයින්, සම්පාදකයාට බොහෝ විට [`chunks_mut`] වලට වඩා හොඳ ප්‍රති ing ල කේතය ප්‍රශස්තිකරණය කළ හැකිය.
    ///
    /// මෙම අනුකාරකයේ ප්‍රභේදයක් සඳහා [`chunks_mut`] බලන්න, ඉතිරි කොටස කුඩා කැබැල්ලක් ලෙසද, [`rchunks_exact_mut`] එකම අනුකාරකය සඳහාද ලබා දෙන නමුත් පෙත්ත අවසානයේ ආරම්භ වේ.
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 නම් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// ඉතිරි කොටස නොමැති බව උපකල්පනය කරමින් පෙත්ත `N-මූලද්‍රව්‍ය අරා පෙත්තකට බෙදයි.
    ///
    ///
    /// # Safety
    ///
    /// මෙය හැඳින්විය හැක්කේ කවදාද යන්න පමණි
    /// - පෙත්ත හරියටම N-මූලද්‍රව්‍ය කුට්ටි (aka `self.len() % N == 0`)) ලෙස බෙදී යයි.
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // ආරක්ෂාව: 1-මූලද්‍රව්‍ය කුට්ටි කිසි විටෙකත් ඉතිරි නොවේ
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // ආරක්ෂාව: පෙති දිග (6) 3 ගුණනයකි
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // මේවා අසංවර වනු ඇත:
    /// // කුට්ටි වලට ඉඩ දෙන්න: &[[_;5]]= slice.as_chunks_unchecked()//පෙති දිග කුට්ටි 5 න් ගුණ කිරීමක් නොවේ:&[[_;0]]= slice.as_chunks_unchecked()//ශුන්‍ය දිග කුට්ටි කිසි විටෙකත් අවසර නැත
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // සුරක්ෂිතභාවය: අපගේ පූර්ව කොන්දේසිය මෙය හරියටම හැඳින්වීමට අවශ්‍ය දෙයයි
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // ආරක්ෂාව: අපි `new_len * N` මූලද්‍රව්‍ය පෙත්තක් දමමු
        // `new_len` පෙත්තක් බොහෝ `N` මූලද්‍රව්‍ය කුට්ටි.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// පෙත්ත ආරම්භයේ සිටම ඇරඹී, N-මූලද්‍රව්‍ය අරා පෙත්තකට බෙදන්න, සහ ඉතිරි කොටස පෙට්ටිය `N` ට වඩා තදින් අඩුය.
    ///
    ///
    /// # Panics
    ///
    /// `N` 0 නම් Panics. මෙම ක්‍රමය ස්ථාවර වීමට පෙර මෙම චෙක්පත සම්පාදක කාල දෝෂයකට වෙනස් වනු ඇත.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // ආරක්ෂාව: අපි දැනටමත් ශුන්‍යයට භීතියට පත්ව ඇති අතර ඉදිකිරීම් වලින් සහතික කර ඇත්තෙමු
        // උප කුලකයේ දිග එන්.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// පෙත්ත අවසානයේ දී ආරම්භ වන `N`-මූලද්‍රව්‍ය අරා පෙත්තකට බෙදන්න, සහ `N` ට වඩා තදින් අඩු දිගකින් යුත් පෙත්තක් බෙදන්න.
    ///
    ///
    /// # Panics
    ///
    /// `N` 0 නම් Panics. මෙම ක්‍රමය ස්ථාවර වීමට පෙර මෙම චෙක්පත සම්පාදක කාල දෝෂයකට වෙනස් වනු ඇත.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // ආරක්ෂාව: අපි දැනටමත් ශුන්‍යයට භීතියට පත්ව ඇති අතර ඉදිකිරීම් වලින් සහතික කර ඇත්තෙමු
        // උප කුලකයේ දිග එන්.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// පෙත්තක ආරම්භයේ සිට ඇරඹෙන පෙත්තක `N` මූලද්‍රව්‍යවලට වඩා වර්‍ගයක් නැවත ලබා දෙයි.
    ///
    /// කුට්ටි යනු අරාව යොමු කිරීම් වන අතර ඒවා අතිච්ඡාදනය නොවේ.
    /// `N` පෙත්තෙහි දිග බෙදන්නේ නැත්නම්, අවසාන `N-1` දක්වා වූ මූලද්‍රව්‍යයන් මඟ හරිනු ඇති අතර එය iterator හි `remainder` ශ්‍රිතයෙන් ලබා ගත හැකිය.
    ///
    ///
    /// මෙම ක්‍රමය [`chunks_exact`] ට සමාන සාමාන්‍ය ජනක වේ.
    ///
    /// # Panics
    ///
    /// `N` 0 නම් Panics. මෙම ක්‍රමය ස්ථාවර වීමට පෙර මෙම චෙක්පත සම්පාදක කාල දෝෂයකට වෙනස් වනු ඇත.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// ඉතිරි කොටස නොමැති බව උපකල්පනය කරමින් පෙත්ත `N-මූලද්‍රව්‍ය අරා පෙත්තකට බෙදයි.
    ///
    ///
    /// # Safety
    ///
    /// මෙය හැඳින්විය හැක්කේ කවදාද යන්න පමණි
    /// - පෙත්ත හරියටම N-මූලද්‍රව්‍ය කුට්ටි (aka `self.len() % N == 0`)) ලෙස බෙදී යයි.
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // ආරක්ෂාව: 1-මූලද්‍රව්‍ය කුට්ටි කිසි විටෙකත් ඉතිරි නොවේ
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // ආරක්ෂාව: පෙති දිග (6) 3 ගුණනයකි
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // මේවා අසංවර වනු ඇත:
    /// // කුට්ටි වලට ඉඩ දෙන්න: &[[_;5]]= slice.as_chunks_unchecked_mut()//පෙති දිග කුට්ටි 5 න් ගුණ කිරීමක් නොවේ:&[[_;0]]= slice.as_chunks_unchecked_mut()//ශුන්‍ය දිග කුට්ටි කිසි විටෙකත් අවසර නැත
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // සුරක්ෂිතභාවය: අපගේ පූර්ව කොන්දේසිය මෙය හරියටම හැඳින්වීමට අවශ්‍ය දෙයයි
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // ආරක්ෂාව: අපි `new_len * N` මූලද්‍රව්‍ය පෙත්තක් දමමු
        // `new_len` පෙත්තක් බොහෝ `N` මූලද්‍රව්‍ය කුට්ටි.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// පෙත්ත ආරම්භයේ සිටම ඇරඹී, N-මූලද්‍රව්‍ය අරා පෙත්තකට බෙදන්න, සහ ඉතිරි කොටස පෙට්ටිය `N` ට වඩා තදින් අඩුය.
    ///
    ///
    /// # Panics
    ///
    /// `N` 0 නම් Panics. මෙම ක්‍රමය ස්ථාවර වීමට පෙර මෙම චෙක්පත සම්පාදක කාල දෝෂයකට වෙනස් වනු ඇත.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // ආරක්ෂාව: අපි දැනටමත් ශුන්‍යයට භීතියට පත්ව ඇති අතර ඉදිකිරීම් වලින් සහතික කර ඇත්තෙමු
        // උප කුලකයේ දිග එන්.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// පෙත්ත අවසානයේ දී ආරම්භ වන `N`-මූලද්‍රව්‍ය අරා පෙත්තකට බෙදන්න, සහ `N` ට වඩා තදින් අඩු දිගකින් යුත් පෙත්තක් බෙදන්න.
    ///
    ///
    /// # Panics
    ///
    /// `N` 0 නම් Panics. මෙම ක්‍රමය ස්ථාවර වීමට පෙර මෙම චෙක්පත සම්පාදක කාල දෝෂයකට වෙනස් වනු ඇත.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // ආරක්ෂාව: අපි දැනටමත් ශුන්‍යයට භීතියට පත්ව ඇති අතර ඉදිකිරීම් වලින් සහතික කර ඇත්තෙමු
        // උප කුලකයේ දිග එන්.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// පෙත්තක ආරම්භයේ සිට ඇරඹෙන පෙත්තක `N` මූලද්‍රව්‍යවලට වඩා වර්‍ගයක් නැවත ලබා දෙයි.
    ///
    /// කුට්ටි විකෘති අරා යොමු වන අතර ඒවා අතිච්ඡාදනය නොවේ.
    /// `N` පෙත්තෙහි දිග බෙදන්නේ නැත්නම්, අවසාන `N-1` දක්වා වූ මූලද්‍රව්‍යයන් මඟ හරිනු ඇති අතර එය iterator හි `into_remainder` ශ්‍රිතයෙන් ලබා ගත හැකිය.
    ///
    ///
    /// මෙම ක්‍රමය [`chunks_exact_mut`] ට සමාන සාමාන්‍ය ජනක වේ.
    ///
    /// # Panics
    ///
    /// `N` 0 නම් Panics. මෙම ක්‍රමය ස්ථාවර වීමට පෙර මෙම චෙක්පත සම්පාදක කාල දෝෂයකට වෙනස් වනු ඇත.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// පෙත්තක ආරම්භයේ සිට ආරම්භ වන පෙත්තක `N` මූලද්‍රව්‍යවල windows අතිච්ඡාදනය කිරීම හරහා ඉරේටරයක් ලබා දෙයි.
    ///
    ///
    /// මෙය [`windows`] ට සමාන සාමාන්‍ය ජනක වේ.
    ///
    /// `N` පෙත්තෙහි ප්‍රමාණයට වඩා වැඩි නම්, එය windows ආපසු නොදෙනු ඇත.
    ///
    /// # Panics
    ///
    /// `N` 0 නම් Panics.
    /// මෙම ක්‍රමය ස්ථාවර වීමට පෙර මෙම චෙක්පත සම්පාදක කාල දෝෂයකට වෙනස් වනු ඇත.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// පෙත්තක අවසානයේ සිට ඇරඹෙන පෙත්තක `chunk_size` මූලද්‍රව්‍ය හරහා වර්‍ගයක් ලබා දෙයි.
    ///
    /// කුට්ටි පෙති වන අතර ඒවා අතිච්ඡාදනය නොවේ.`chunk_size` පෙත්තෙහි දිග බෙදන්නේ නැත්නම්, අන්තිම කැබැල්ලේ දිග `chunk_size` නොතිබෙනු ඇත.
    ///
    /// සෑම විටම හරියටම `chunk_size` මූලද්‍රව්‍යවල කුට්ටි ආපසු ලබා දෙන මෙම iterator හි ප්‍රභේදයක් සඳහා [`rchunks_exact`] බලන්න, සහ එකම iterator සඳහා [`chunks`] නමුත් පෙත්තක ආරම්භයේ සිට ආරම්භ කරන්න.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 නම් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// පෙත්තක අවසානයේ සිට ඇරඹෙන පෙත්තක `chunk_size` මූලද්‍රව්‍ය හරහා වර්‍ගයක් ලබා දෙයි.
    ///
    /// කුට්ටි විකෘති පෙති වන අතර ඒවා අතිච්ඡාදනය නොවේ.`chunk_size` පෙත්තෙහි දිග බෙදන්නේ නැත්නම්, අන්තිම කැබැල්ලේ දිග `chunk_size` නොතිබෙනු ඇත.
    ///
    /// සෑම විටම හරියටම `chunk_size` මූලද්‍රව්‍යවල කුට්ටි ආපසු ලබා දෙන මෙම iterator හි ප්‍රභේදයක් සඳහා [`rchunks_exact_mut`] බලන්න, සහ එකම iterator සඳහා [`chunks_mut`] නමුත් පෙත්තක ආරම්භයේ සිට ආරම්භ කරන්න.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 නම් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// පෙත්තක අවසානයේ සිට ඇරඹෙන පෙත්තක `chunk_size` මූලද්‍රව්‍ය හරහා වර්‍ගයක් ලබා දෙයි.
    ///
    /// කුට්ටි පෙති වන අතර ඒවා අතිච්ඡාදනය නොවේ.
    /// `chunk_size` පෙත්තෙහි දිග බෙදන්නේ නැත්නම්, අවසාන `chunk_size-1` දක්වා වූ මූලද්‍රව්‍යයන් මඟ හරිනු ඇති අතර එය iterator හි `remainder` ශ්‍රිතයෙන් ලබා ගත හැකිය.
    ///
    /// සෑම කැබැල්ලකම හරියටම `chunk_size` මූලද්‍රව්‍යයන් ඇති හෙයින්, සම්පාදකයාට බොහෝ විට [`chunks`] වලට වඩා හොඳ ප්‍රති ing ල කේතය ප්‍රශස්තිකරණය කළ හැකිය.
    ///
    /// මෙම අනුකාරකයේ ප්‍රභේදයක් සඳහා [`rchunks`] බලන්න, ඉතිරි කොටස කුඩා කැබැල්ලක් ලෙසද, [`chunks_exact`] එකම අනුකාරකය සඳහාද ලබා දෙන නමුත් පෙත්තක ආරම්භයේ සිට ආරම්භ කරන්න.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 නම් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// පෙත්තක අවසානයේ සිට ඇරඹෙන පෙත්තක `chunk_size` මූලද්‍රව්‍ය හරහා වර්‍ගයක් ලබා දෙයි.
    ///
    /// කුට්ටි විකෘති පෙති වන අතර ඒවා අතිච්ඡාදනය නොවේ.
    /// `chunk_size` පෙත්තෙහි දිග බෙදන්නේ නැත්නම්, අවසාන `chunk_size-1` දක්වා වූ මූලද්‍රව්‍යයන් මඟ හරිනු ඇති අතර එය iterator හි `into_remainder` ශ්‍රිතයෙන් ලබා ගත හැකිය.
    ///
    /// සෑම කැබැල්ලකම හරියටම `chunk_size` මූලද්‍රව්‍යයන් ඇති හෙයින්, සම්පාදකයාට බොහෝ විට [`chunks_mut`] වලට වඩා හොඳ ප්‍රති ing ල කේතය ප්‍රශස්තිකරණය කළ හැකිය.
    ///
    /// මෙම අනුකාරකයේ ප්‍රභේදයක් සඳහා [`rchunks_mut`] බලන්න, ඉතිරි කොටස කුඩා කැබැල්ලක් ලෙසද, [`chunks_exact_mut`] එකම අනුකාරකය සඳහාද ලබා දෙන නමුත් පෙත්තක ආරම්භයේ සිට ආරම්භ කරන්න.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 නම් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// මූලද්‍රව්‍ය වෙන් කිරීම සඳහා පුරෝකථනය භාවිතා කරමින් අතිච්ඡාදනය නොවන මූලද්‍රව්‍ය නිපදවන පෙත්තක් හරහා ඉරේටරයක් ලබා දෙයි.
    ///
    /// අනාවැකිය තමන් අනුගමනය කරන මූලද්‍රව්‍ය දෙකක් මත කැඳවනු ලැබේ, එයින් අදහස් වන්නේ ප්‍රක්ෂේපණය `slice[0]` සහ `slice[1]` සහ `slice[1]` සහ `slice[2]` සහ එසේ ය.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// වර්ග කළ උප කොටස් උපුටා ගැනීම සඳහා මෙම ක්‍රමය භාවිතා කළ හැකිය:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// මූලද්රව්ය වෙන් කිරීම සඳහා පුරෝකථනය භාවිතා කරමින් අතිච්ඡාදනය නොවන විකෘති මූලද්රව්ය නිපදවන පෙත්තක් හරහා ඉරේටරයක් ලබා දෙයි.
    ///
    /// අනාවැකිය තමන් අනුගමනය කරන මූලද්‍රව්‍ය දෙකක් මත කැඳවනු ලැබේ, එයින් අදහස් වන්නේ ප්‍රක්ෂේපණය `slice[0]` සහ `slice[1]` සහ `slice[1]` සහ `slice[2]` සහ එසේ ය.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// වර්ග කළ උප කොටස් උපුටා ගැනීම සඳහා මෙම ක්‍රමය භාවිතා කළ හැකිය:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// දර්ශකයක එක් පෙත්තක් දෙකට බෙදයි.
    ///
    /// පළමුවැන්නෙහි `[0, mid)` වෙතින් සියලු දර්ශක අඩංගු වේ (`mid` දර්ශකය හැර) සහ දෙවැන්න `[mid, len)` වෙතින් සියලුම දර්ශක අඩංගු වේ (`len` දර්ශකය හැර).
    ///
    ///
    /// # Panics
    ///
    /// `mid > len` නම් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // ආරක්ෂාව: `self` ඇතුළත `[ptr; mid]` සහ `[mid; len]` ඇත
        // `from_raw_parts_mut` හි අවශ්‍යතා සපුරාලයි.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// එක් විකෘති පෙත්තක් දර්ශකයකට දෙකට බෙදයි.
    ///
    /// පළමුවැන්නෙහි `[0, mid)` වෙතින් සියලු දර්ශක අඩංගු වේ (`mid` දර්ශකය හැර) සහ දෙවැන්න `[mid, len)` වෙතින් සියලුම දර්ශක අඩංගු වේ (`len` දර්ශකය හැර).
    ///
    ///
    /// # Panics
    ///
    /// `mid > len` නම් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // ආරක්ෂාව: `self` ඇතුළත `[ptr; mid]` සහ `[mid; len]` ඇත
        // `from_raw_parts_mut` හි අවශ්‍යතා සපුරාලයි.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// සීමාවන් පරීක්ෂා කිරීමකින් තොරව එක් පෙත්තක් දර්ශකයකට දෙකට බෙදයි.
    ///
    /// පළමුවැන්නෙහි `[0, mid)` වෙතින් සියලු දර්ශක අඩංගු වේ (`mid` දර්ශකය හැර) සහ දෙවැන්න `[mid, len)` වෙතින් සියලුම දර්ශක අඩංගු වේ (`len` දර්ශකය හැර).
    ///
    ///
    /// ආරක්ෂිත විකල්පයක් සඳහා [`split_at`] බලන්න.
    ///
    /// # Safety
    ///
    /// සීමාවෙන් පිටත දර්ශකයක් සමඟ මෙම ක්‍රමය ඇමතීම *[නිර්වචනය නොකළ හැසිරීම]* එහි ප්‍රති ing ලයක් ලෙස යොමුව භාවිතා නොකලද.අමතන්නාට `0 <= mid <= self.len()` බව සහතික කළ යුතුය.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // ආරක්ෂාව: අමතන්නාට එම `0 <= mid <= self.len()` පරීක්ෂා කළ යුතුය
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// සීමාවන් පරික්ෂා කිරීමකින් තොරව එක් විකෘති පෙත්තක් දර්ශකයකට දෙකට බෙදයි.
    ///
    /// පළමුවැන්නෙහි `[0, mid)` වෙතින් සියලු දර්ශක අඩංගු වේ (`mid` දර්ශකය හැර) සහ දෙවැන්න `[mid, len)` වෙතින් සියලුම දර්ශක අඩංගු වේ (`len` දර්ශකය හැර).
    ///
    ///
    /// ආරක්ෂිත විකල්පයක් සඳහා [`split_at_mut`] බලන්න.
    ///
    /// # Safety
    ///
    /// සීමාවෙන් පිටත දර්ශකයක් සමඟ මෙම ක්‍රමය ඇමතීම *[නිර්වචනය නොකළ හැසිරීම]* එහි ප්‍රති ing ලයක් ලෙස යොමුව භාවිතා නොකලද.අමතන්නාට `0 <= mid <= self.len()` බව සහතික කළ යුතුය.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // ආරක්ෂාව: අමතන්නාට එම `0 <= mid <= self.len()` පරීක්ෂා කළ යුතුය.
        //
        // `[ptr; mid]` සහ `[mid; len]` අතිච්ඡාදනය නොවන බැවින් විකෘති යොමු කිරීමක් නැවත ලබා දීම හොඳයි.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// `pred` හා ගැලපෙන මූලද්‍රව්‍ය වලින් වෙන් කරන ලද අනුකාරක හරහා අනුකාරකයක් ලබා දෙයි.
    /// ගැලපෙන මූලද්‍රව්‍යය උපලේඛනවල අඩංගු නොවේ.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// පළමු මූලද්‍රව්‍යය ගැලපෙන්නේ නම්, හිස් පෙත්තක් අනුකාරකය විසින් ආපසු ලබා දුන් පළමු අයිතමය වේ.
    /// ඒ හා සමානව, පෙත්තෙහි අවසාන මූලද්‍රව්‍යය ගැලපෙන්නේ නම්, හිස් පෙත්තක් අනුකාරකය විසින් ආපසු ලබා දුන් අවසාන අයිතමය වනු ඇත:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// ගැලපෙන මූලද්‍රව්‍ය දෙකක් කෙලින්ම යාබදව තිබේ නම්, ඒවා අතර හිස් පෙත්තක් තිබේ:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// `pred` හා ගැලපෙන මූලද්‍රව්‍ය වලින් වෙන් කරන ලද විකෘති උප කොටස් හරහා නැවත ක්‍රියාකරවන්නෙකු ලබා දෙයි.
    /// ගැලපෙන මූලද්‍රව්‍යය උපලේඛනවල අඩංගු නොවේ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// `pred` හා ගැලපෙන මූලද්‍රව්‍ය වලින් වෙන් කරන ලද අනුකාරක හරහා අනුකාරකයක් ලබා දෙයි.
    /// ගැලපෙන මූලද්‍රව්‍යය පෙර උපසිරැසිය අවසානයේ ටර්මිනේටරයක් ලෙස අඩංගු වේ.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// පෙත්තෙහි අවසාන මූලද්‍රව්‍යය ගැලපෙන්නේ නම්, එම මූලද්‍රව්‍යය පෙර පෙත්තෙහි අවසානය ලෙස සැලකේ.
    ///
    /// එම පෙත්ත අනුකාරකය විසින් ආපසු ලබා දුන් අවසාන අයිතමය වේ.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// `pred` හා ගැලපෙන මූලද්‍රව්‍ය වලින් වෙන් කරන ලද විකෘති උප කොටස් හරහා නැවත ක්‍රියාකරවන්නෙකු ලබා දෙයි.
    /// ගැලපෙන මූලද්‍රව්‍යය පෙර උපසිරැසියෙහි ටර්මිනේටරයක් ලෙස අඩංගු වේ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// `pred` ට ගැලපෙන මූලද්‍රව්‍යවලින් වෙන් කරන ලද අනුකාරක හරහා ඉරේටරයක් ලබා දෙයි, පෙත්ත අවසානයේ සිට ආරම්භ වී පසුපසට වැඩ කරයි.
    /// ගැලපෙන මූලද්‍රව්‍යය උපලේඛනවල අඩංගු නොවේ.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `split()` හා සමානව, පළමු හෝ අවසාන මූලද්‍රව්‍යය ගැලපෙන්නේ නම්, හිස් පෙත්තක් iterator විසින් ආපසු ලබා දෙන පළමු (හෝ අවසාන) අයිතමය වේ.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// `pred` හා සැසඳෙන මූලද්‍රව්‍යවලින් වෙන් කරන ලද විකෘති උප කොටස් හරහා ඉරේටරයක් ලබා දෙයි, පෙත්ත අවසානයේ අවසානයේ සිට පසුපසට වැඩ කරයි.
    /// ගැලපෙන මූලද්‍රව්‍යය උපලේඛනවල අඩංගු නොවේ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// `pred` ට ගැලපෙන මූලද්‍රව්‍යවලින් වෙන් කරන ලද අනුකාරක හරහා ඉරේටරයක් ලබා දෙයි, බොහෝ `n` අයිතම වෙත ආපසු යාමට සීමා වේ.
    /// ගැලපෙන මූලද්‍රව්‍යය උපලේඛනවල අඩංගු නොවේ.
    ///
    /// ආපසු ලබා දුන් අවසන් අංගය, ඇත්නම්, පෙත්තෙහි ඉතිරි කොටස අඩංගු වේ.
    ///
    /// # Examples
    ///
    /// ස්ලයිස් බෙදීම 3 න් බෙදිය හැකි සංඛ්‍යා වලින් එක් වරක් මුද්‍රණය කරන්න (එනම්, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// `pred` ට ගැලපෙන මූලද්‍රව්‍යවලින් වෙන් කරන ලද අනුකාරක හරහා ඉරේටරයක් ලබා දෙයි, බොහෝ `n` අයිතම වෙත ආපසු යාමට සීමා වේ.
    /// ගැලපෙන මූලද්‍රව්‍යය උපලේඛනවල අඩංගු නොවේ.
    ///
    /// ආපසු ලබා දුන් අවසන් අංගය, ඇත්නම්, පෙත්තෙහි ඉතිරි කොටස අඩංගු වේ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// බොහෝ `n` අයිතම වෙත නැවත පැමිණීමට සීමා වූ `pred` හා ගැලපෙන මූලද්‍රව්‍යවලින් වෙන් කරන ලද උපලේඛන හරහා අනුකාරකයක් ලබා දෙයි.
    /// මෙය පෙත්ත අවසානයේ දී ආරම්භ වන අතර පසුපසට ක්‍රියා කරයි.
    /// ගැලපෙන මූලද්‍රව්‍යය උපලේඛනවල අඩංගු නොවේ.
    ///
    /// ආපසු ලබා දුන් අවසන් අංගය, ඇත්නම්, පෙත්තෙහි ඉතිරි කොටස අඩංගු වේ.
    ///
    /// # Examples
    ///
    /// ස්ලයිස් බෙදීම එක් වරක් මුද්‍රණය කරන්න, අවසානයේ සිට 3 න් බෙදිය හැකි සංඛ්‍යා වලින් (එනම්, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// බොහෝ `n` අයිතම වෙත නැවත පැමිණීමට සීමා වූ `pred` හා ගැලපෙන මූලද්‍රව්‍යවලින් වෙන් කරන ලද උපලේඛන හරහා අනුකාරකයක් ලබා දෙයි.
    /// මෙය පෙත්ත අවසානයේ දී ආරම්භ වන අතර පසුපසට ක්‍රියා කරයි.
    /// ගැලපෙන මූලද්‍රව්‍යය උපලේඛනවල අඩංගු නොවේ.
    ///
    /// ආපසු ලබා දුන් අවසන් අංගය, ඇත්නම්, පෙත්තෙහි ඉතිරි කොටස අඩංගු වේ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// පෙත්තෙහි දී ඇති අගය සහිත මූලද්‍රව්‍යයක් තිබේ නම් `true` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// ඔබට `&T` නොමැති නම්, නමුත් `T: Borrow<U>` වැනි `&U` (උදා
    /// නූල්: ණයට ගන්න<str>`), ඔබට `iter().any` භාවිතා කළ හැකිය:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // `String` පෙත්තක්
    /// assert!(v.iter().any(|e| e == "hello")); // `&str` සමඟ සොයන්න
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// `needle` යනු පෙත්තෙහි උපසර්ගයක් නම් `true` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// `needle` හිස් පෙත්තක් නම් සෑම විටම `true` ආපසු ලබා දෙයි:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// `needle` යනු පෙත්තක උපසර්ගයක් නම් `true` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// `needle` හිස් පෙත්තක් නම් සෑම විටම `true` ආපසු ලබා දෙයි:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// ඉවත් කරන ලද උපසර්ගය සමඟ උපසිරැසියක් ලබා දෙයි.
    ///
    /// පෙත්ත `prefix` සමඟ ආරම්භ වන්නේ නම්, උපසර්ගය `Some` වලින් ඔතා උපසර්ගයෙන් පසුව ආපසු ලබා දේ.
    /// `prefix` හිස් නම්, මුල් පෙත්ත නැවත ලබා දෙන්න.
    ///
    /// පෙත්ත `prefix` සමඟ ආරම්භ නොවේ නම්, `None` ආපසු ලබා දේ.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // SlicePattern වඩාත් නවීන නම් මෙම ශ්‍රිතයට නැවත ලිවීම අවශ්‍ය වේ.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// ඉවත් කරන ලද උපසර්ගය සමඟ උපසිරැසියක් ලබා දෙයි.
    ///
    /// පෙත්ත `suffix` සමඟ අවසන් වුවහොත්, `Some` වලින් ඔතා ඇති උපසර්ගයට පෙර උප කුලකය නැවත ලබා දේ.
    /// `suffix` හිස් නම්, මුල් පෙත්ත නැවත ලබා දෙන්න.
    ///
    /// පෙත්ත `suffix` සමඟ අවසන් නොවේ නම්, `None` ආපසු ලබා දේ.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // SlicePattern වඩාත් නවීන නම් මෙම ශ්‍රිතයට නැවත ලිවීම අවශ්‍ය වේ.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// දී ඇති මූලද්‍රව්‍යයක් සඳහා ද්විමය මෙම වර්ග කළ පෙත්ත සොයයි.
    ///
    /// අගය සොයාගතහොත් ගැලපෙන මූලද්‍රව්‍යයේ දර්ශකය අඩංගු [`Result::Ok`] ආපසු ලබා දෙනු ලැබේ.
    /// බහුවිධ තරඟ තිබේ නම්, ඕනෑම තරඟයක් ආපසු ලබා දිය හැකිය.
    /// අගය සොයාගත නොහැකි නම්, වර්ග කළ අනුපිළිවෙල පවත්වා ගනිමින් ගැලපෙන මූලද්‍රව්‍යයක් ඇතුළු කළ හැකි දර්ශකය අඩංගු [`Result::Err`] ආපසු ලබා දෙනු ලැබේ.
    ///
    ///
    /// [`binary_search_by`], [`binary_search_by_key`], සහ [`partition_point`] ද බලන්න.
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// මූලද්රව්ය හතරකින් යුත් මාලාවක් බලයි.
    /// පළමුවැන්න අද්විතීය ලෙස තීරණය කරන ලද ස්ථානයක් සහිත ය;දෙවන හා තෙවන ඒවා හමු නොවේ;හතරවනුව `[1, 4]` හි ඕනෑම ස්ථානයකට ගැලපේ.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// වර්ග කළ අනුපිළිවෙලක් පවත්වා ගනිමින් ඔබට වර්ග කළ vector වෙත අයිතමයක් ඇතුළු කිරීමට අවශ්‍ය නම්:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// ද්විමය සංසන්දනාත්මක ශ්‍රිතයක් සමඟ මෙම වර්ග කළ පෙත්ත සොයයි.
    ///
    /// සංසන්දනාත්මක ශ්‍රිතය යටින් ඇති පෙත්තෙහි වර්ග කිරීමේ අනුපිළිවෙලට අනුරූප අනුපිළිවෙලක් ක්‍රියාත්මක කළ යුතු අතර, එහි තර්කය `Less`, `Equal` හෝ `Greater` අපේක්ෂිත ඉලක්කයද යන්න පෙන්වන ඇණවුම් කේතයක් ආපසු එවිය යුතුය.
    ///
    ///
    /// අගය සොයාගතහොත් ගැලපෙන මූලද්‍රව්‍යයේ දර්ශකය අඩංගු [`Result::Ok`] ආපසු ලබා දෙනු ලැබේ.බහුවිධ තරඟ තිබේ නම්, ඕනෑම තරඟයක් ආපසු ලබා දිය හැකිය.
    /// අගය සොයාගත නොහැකි නම්, වර්ග කළ අනුපිළිවෙල පවත්වා ගනිමින් ගැලපෙන මූලද්‍රව්‍යයක් ඇතුළු කළ හැකි දර්ශකය අඩංගු [`Result::Err`] ආපසු ලබා දෙනු ලැබේ.
    ///
    /// [`binary_search`], [`binary_search_by_key`], සහ [`partition_point`] ද බලන්න.
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// මූලද්රව්ය හතරකින් යුත් මාලාවක් බලයි.පළමුවැන්න අද්විතීය ලෙස තීරණය කරන ලද ස්ථානයක් සහිත ය;දෙවන හා තෙවන ඒවා හමු නොවේ;හතරවනුව `[1, 4]` හි ඕනෑම ස්ථානයකට ගැලපේ.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // ආරක්ෂාව: ඇමතුම පහත සඳහන් ආක්‍රමණ මගින් ආරක්‍ෂිත කර ඇත:
            // - `mid >= 0`
            // - `mid < size`: `mid` සීමිත වන්නේ `[left; right)` මායිමෙනි.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // අපි ගැලපීමට වඩා if/else පාලක ප්‍රවාහය භාවිතා කිරීමට හේතුව, ගැලපීම් සංසන්දනාත්මක මෙහෙයුම් නැවත සකස් කිරීම, එය පරිපූර්ණ සංවේදී වීමයි.
            //
            // මෙය u8 සඳහා x86 asm වේ: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// යතුරු නිස්සාරණ ශ්‍රිතයක් සමඟ ද්විමය මෙම වර්ග කළ පෙත්ත සොයයි.
    ///
    /// පෙත්ත යතුරෙන් වර්ග කර ඇති බව උපකල්පනය කරයි, උදාහරණයක් ලෙස [`sort_by_key`] සමඟ එකම යතුරු නිස්සාරණ ශ්‍රිතය භාවිතා කරයි.
    ///
    /// අගය සොයාගතහොත් ගැලපෙන මූලද්‍රව්‍යයේ දර්ශකය අඩංගු [`Result::Ok`] ආපසු ලබා දෙනු ලැබේ.
    /// බහුවිධ තරඟ තිබේ නම්, ඕනෑම තරඟයක් ආපසු ලබා දිය හැකිය.
    /// අගය සොයාගත නොහැකි නම්, වර්ග කළ අනුපිළිවෙල පවත්වා ගනිමින් ගැලපෙන මූලද්‍රව්‍යයක් ඇතුළු කළ හැකි දර්ශකය අඩංගු [`Result::Err`] ආපසු ලබා දෙනු ලැබේ.
    ///
    ///
    /// [`binary_search`], [`binary_search_by`], සහ [`partition_point`] ද බලන්න.
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// යුගල පෙත්තක මූලද්‍රව්‍ය හතරක ශ්‍රේණියක් ඒවායේ දෙවන මූලද්‍රව්‍ය අනුව වර්ග කර ඇත.
    /// පළමුවැන්න අද්විතීය ලෙස තීරණය කරන ලද ස්ථානයක් සහිත ය;දෙවන හා තෙවන ඒවා හමු නොවේ;හතරවනුව `[1, 4]` හි ඕනෑම ස්ථානයකට ගැලපේ.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // `slice::sort_by_key` crate `alloc` හි ඇති බැවින් Lint rustdoc::broken_intra_doc_links සඳහා අවසර දී ඇති අතර `core` තැනීමේදී තවමත් එය නොපවතී.
    //
    // crate: #74481.ප්‍රාථමිකයන් ලේඛනගත කර ඇත්තේ libstd (#73423) හි පමණක් බැවින් මෙය කිසි විටෙකත් ප්‍රායෝගිකව බිඳුණු සම්බන්ධතා ඇති නොකරයි.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// පෙත්ත වර්ග කරයි, නමුත් සමාන මූලද්‍රව්‍යයන්ගේ අනුපිළිවෙල ආරක්ෂා නොකරයි.
    ///
    /// මෙම වර්ග කිරීම අස්ථායි (එනම්, සමාන මූලද්‍රව්‍ය නැවත සකස් කළ හැක), ස්ථානයේ (එනම්, වෙන් නොකරයි), සහ *O*(*n*\*log(* n*)) නරකම අවස්ථාව.
    ///
    /// # වත්මන් ක්‍රියාත්මක කිරීම
    ///
    /// වර්තමාන ඇල්ගොරිතම පදනම් වී ඇත්තේ ඕර්සන් පීටර්ස් විසින් [pattern-defeating quicksort][pdqsort] මත වන අතර එය අහඹු ලෙස ක්වික්සෝර්ට් හි වේගවත් සාමාන්‍ය නඩුව හීප්සෝර්ට් හි වේගවත්ම නරකම අවස්ථාව සමඟ ඒකාබද්ධ කරන අතර ඇතැම් රටා සහිත පෙති මත රේඛීය වේලාවක් ලබා ගනී.
    /// පරිහානියට පත් අවස්ථාවන් වළක්වා ගැනීම සඳහා එය යම් අහඹුකරණයක් භාවිතා කරයි, නමුත් ස්ථාවර seed සමඟ සෑම විටම නිර්ණායක හැසිරීම් සපයයි.
    ///
    /// විශේෂ අවස්ථා කිහිපයකදී හැර, එය සාමාන්‍යයෙන් ස්ථාවර වර්ග කිරීමකට වඩා වේගවත් වේ, උදා: පෙත්ත සමාන්තරගත වර්ග කළ අනුක්‍රම කිහිපයකින් සමන්විත වන විට.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// පෙත්ත සංසන්දනාත්මක ශ්‍රිතයක් සමඟ වර්ග කරයි, නමුත් සමාන මූලද්‍රව්‍යයන්ගේ අනුපිළිවෙල ආරක්ෂා නොකරයි.
    ///
    /// මෙම වර්ග කිරීම අස්ථායි (එනම්, සමාන මූලද්‍රව්‍ය නැවත සකස් කළ හැක), ස්ථානයේ (එනම්, වෙන් නොකරයි), සහ *O*(*n*\*log(* n*)) නරකම අවස්ථාව.
    ///
    /// සංසන්දනාත්මක ශ්‍රිතය පෙත්තෙහි ඇති මූලද්‍රව්‍ය සඳහා සම්පූර්ණ අනුපිළිවෙලක් අර්ථ දැක්විය යුතුය.ඇණවුම සම්පුර්ණ නොවේ නම්, මූලද්‍රව්‍යවල අනුපිළිවෙල නිශ්චිතව දක්වා නැත.ඇණවුමක් නම් එය සම්පූර්ණ ඇණවුමකි (සියලුම `a`, `b` සහ `c` සඳහා):
    ///
    /// * සම්පුර්ණ සහ ප්‍රති-අසමමිතික: හරියටම `a < b`, `a == b` හෝ `a > b` වලින් එකක් සත්‍ය වන අතර
    /// * සංක්‍රාන්ති, `a < b` සහ `b < c` යන්නෙන් අදහස් කරන්නේ `a < c` යන්නයි.`==` සහ `>` යන දෙකටම සමාන විය යුතුය.
    ///
    /// උදාහරණයක් ලෙස, `NaN != NaN` [`Ord`] ක්‍රියාත්මක නොකරන අතර `NaN != NaN` නිසා, අපට පෙත්තෙහි `NaN` අඩංගු නොවන බව දැනගත් විට අපට `partial_cmp` අපගේ වර්ග කිරීමේ ශ්‍රිතය ලෙස භාවිතා කළ හැකිය.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # වත්මන් ක්‍රියාත්මක කිරීම
    ///
    /// වර්තමාන ඇල්ගොරිතම පදනම් වී ඇත්තේ ඕර්සන් පීටර්ස් විසින් [pattern-defeating quicksort][pdqsort] මත වන අතර එය අහඹු ලෙස ක්වික්සෝර්ට් හි වේගවත් සාමාන්‍ය නඩුව හීප්සෝර්ට් හි වේගවත්ම නරකම අවස්ථාව සමඟ ඒකාබද්ධ කරන අතර ඇතැම් රටා සහිත පෙති මත රේඛීය වේලාවක් ලබා ගනී.
    /// පරිහානියට පත් අවස්ථාවන් වළක්වා ගැනීම සඳහා එය යම් අහඹුකරණයක් භාවිතා කරයි, නමුත් ස්ථාවර seed සමඟ සෑම විටම නිර්ණායක හැසිරීම් සපයයි.
    ///
    /// විශේෂ අවස්ථා කිහිපයකදී හැර, එය සාමාන්‍යයෙන් ස්ථාවර වර්ග කිරීමකට වඩා වේගවත් වේ, උදා: පෙත්ත සමාන්තරගත වර්ග කළ අනුක්‍රම කිහිපයකින් සමන්විත වන විට.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // ප්‍රතිලෝම වර්ග කිරීම
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// යතුරු නිස්සාරණ ශ්‍රිතයක් සමඟ පෙත්ත වර්ග කරයි, නමුත් සමාන මූලද්‍රව්‍යයන්ගේ අනුපිළිවෙල ආරක්ෂා නොකරනු ඇත.
    ///
    /// මෙම වර්ග කිරීම අස්ථායි (එනම්, සමාන මූලද්‍රව්‍ය නැවත සකස් කළ හැක), ස්ථානයේ (එනම්, වෙන් නොකෙරේ), සහ *O*(m\* * n *\* log(*n*)) නරකම අවස්ථාව, මෙහි ප්‍රධාන ශ්‍රිතය *O*(*එම්*).
    ///
    /// # වත්මන් ක්‍රියාත්මක කිරීම
    ///
    /// වර්තමාන ඇල්ගොරිතම පදනම් වී ඇත්තේ ඕර්සන් පීටර්ස් විසින් [pattern-defeating quicksort][pdqsort] මත වන අතර එය අහඹු ලෙස ක්වික්සෝර්ට් හි වේගවත් සාමාන්‍ය නඩුව හීප්සෝර්ට් හි වේගවත්ම නරකම අවස්ථාව සමඟ ඒකාබද්ධ කරන අතර ඇතැම් රටා සහිත පෙති මත රේඛීය වේලාවක් ලබා ගනී.
    /// පරිහානියට පත් අවස්ථාවන් වළක්වා ගැනීම සඳහා එය යම් අහඹුකරණයක් භාවිතා කරයි, නමුත් ස්ථාවර seed සමඟ සෑම විටම නිර්ණායක හැසිරීම් සපයයි.
    ///
    /// එහි ප්‍රධාන ඇමතුම් ක්‍රමෝපාය නිසා, යතුරු ක්‍රියාකාරිත්වය මිල අධික වන අවස්ථාවන්හිදී [`sort_unstable_by_key`](#method.sort_unstable_by_key) [`sort_by_cached_key`](#method.sort_by_cached_key) ට වඩා මන්දගාමී වනු ඇත.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// `index` හි මූලද්‍රව්‍යය එහි අවසාන වර්ග කළ ස්ථානයේ ඇති පරිදි පෙත්ත නැවත සකසන්න.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// `index` හි මූලද්‍රව්‍යය එහි අවසාන වර්ග කළ ස්ථානයේ ඇති පරිදි සංසන්දනාත්මක ශ්‍රිතයක් සමඟ පෙත්ත නැවත සකසන්න.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// `index` හි මූලද්‍රව්‍යය එහි අවසාන වර්ග කළ ස්ථානයේ ඇති පරිදි යතුරු නිස්සාරණ ශ්‍රිතයක් සමඟ පෙත්ත නැවත සකසන්න.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// `index` හි මූලද්‍රව්‍යය එහි අවසාන වර්ග කළ ස්ථානයේ ඇති පරිදි පෙත්ත නැවත සකසන්න.
    ///
    /// මෙම ප්‍රතිසංවිධානයට `i < index` ස්ථානයේ ඇති ඕනෑම අගයක් `j > index` ස්ථානයක ඇති ඕනෑම අගයකට වඩා අඩු හෝ සමාන විය හැකි අතිරේක දේපලක් ඇත.
    /// මීට අමතරව, මෙම නැවත සකස් කිරීම අස්ථායි (එනම්
    /// ඕනෑම සමාන මූලද්‍රව්‍ය සංඛ්‍යාවක් `index` ස්ථානයේ, ස්ථානයේ (එනම්) අවසන් විය හැකිය
    /// වෙන් නොකරයි), සහ *O*(*n*) නරකම අවස්ථාව.
    /// මෙම කාර්යය වෙනත් පුස්තකාලවල "kth element" ලෙසද හැඳින්වේ.
    /// එය පහත දැක්වෙන අගයන්ගෙන් ත්‍රිත්වයක් ලබා දෙයි: දී ඇති දර්ශකයේ ඇති මූලද්‍රව්‍යයට වඩා අඩු සියලු මූලද්‍රව්‍ය, දී ඇති දර්ශකයේ අගය සහ දී ඇති දර්ශකයේ ඇති මූලද්‍රව්‍යයට වඩා වැඩි සියලු මූලද්‍රව්‍ය.
    ///
    ///
    /// # වත්මන් ක්‍රියාත්මක කිරීම
    ///
    /// වත්මන් ඇල්ගොරිතම පදනම් වී ඇත්තේ [`sort_unstable`] සඳහා භාවිතා කරන එකම ක්වික්සෝර්ට් ඇල්ගොරිතමයේ ක්ෂණික තේරීම් කොටස මත ය.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` විට Panics, එයින් අදහස් කරන්නේ හිස් පෙති මත සැමවිටම panics යන්නයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // මධ්යන්යය සොයා ගන්න
    /// v.select_nth_unstable(2);
    ///
    /// // නිශ්චිත දර්ශකය පිළිබඳව අප වර්ග කරන ආකාරය මත පදනම්ව, පෙත්ත පහත සඳහන් එකක් වනු ඇති බවට අපට සහතික වේ.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// `index` හි මූලද්‍රව්‍යය එහි අවසාන වර්ග කළ ස්ථානයේ ඇති පරිදි සංසන්දනාත්මක ශ්‍රිතයක් සමඟ පෙත්ත නැවත සකසන්න.
    ///
    /// මෙම ප්‍රතිසංවිධානයට `i < index` ස්ථානයේ ඇති ඕනෑම අගයක් සංසන්දනාත්මක ශ්‍රිතය භාවිතා කරමින් `j > index` ස්ථානයක ඇති ඕනෑම අගයකට වඩා අඩු හෝ සමාන විය හැකි අතිරේක දේපලක් ඇත.
    /// මීට අමතරව, මෙම ප්‍රතිසංවිධානය අස්ථායි (එනම් ඕනෑම සමාන මූලද්‍රව්‍ය ගණනක් `index` ස්ථානයෙන් අවසන් විය හැක), ස්ථානයේ (එනම් වෙන් නොකෙරේ) සහ *O*(*n*) නරකම අවස්ථාවකි.
    /// මෙම කාර්යය අනෙකුත් පුස්තකාලවල "kth element" ලෙසද හැඳින්වේ.
    /// එය පහත දැක්වෙන අගයන්ගෙන් ත්‍රිත්වයක් ලබා දෙයි: ලබා දී ඇති දර්ශකයේ ඇති මූලද්‍රව්‍යයට වඩා අඩු, ලබා දී ඇති දර්ශකයේ අගය, සහ ලබා දී ඇති සංසන්දනාත්මක ශ්‍රිතය භාවිතා කර දී ඇති දර්ශකයේ ඇති මූලද්‍රව්‍යයට වඩා වැඩි සියලු මූලද්‍රව්‍ය.
    ///
    ///
    /// # වත්මන් ක්‍රියාත්මක කිරීම
    ///
    /// වත්මන් ඇල්ගොරිතම පදනම් වී ඇත්තේ [`sort_unstable`] සඳහා භාවිතා කරන එකම ක්වික්සෝර්ට් ඇල්ගොරිතමයේ ක්ෂණික තේරීම් කොටස මත ය.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` විට Panics, එයින් අදහස් කරන්නේ හිස් පෙති මත සැමවිටම panics යන්නයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // පෙත්තක් බැසීමේ අනුපිළිවෙලට වර්ග කර ඇති ආකාරයට මධ්යන්යය සොයා ගන්න.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // නිශ්චිත දර්ශකය පිළිබඳව අප වර්ග කරන ආකාරය මත පදනම්ව, පෙත්ත පහත සඳහන් එකක් වනු ඇති බවට අපට සහතික වේ.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// `index` හි මූලද්‍රව්‍යය එහි අවසාන වර්ග කළ ස්ථානයේ ඇති පරිදි යතුරු නිස්සාරණ ශ්‍රිතයක් සමඟ පෙත්ත නැවත සකසන්න.
    ///
    /// යතුරු නැවත ලබා ගැනීමේ ශ්‍රිතය භාවිතා කරමින් `i < index` ස්ථානයේ ඇති ඕනෑම අගයක් `j > index` ස්ථානයේ ඇති ඕනෑම අගයකට වඩා අඩු හෝ සමාන විය හැකි අතිරේක දේපල මෙම නැවත සකස් කිරීමෙහි ඇත.
    /// මීට අමතරව, මෙම ප්‍රතිසංවිධානය අස්ථායි (එනම් ඕනෑම සමාන මූලද්‍රව්‍ය ගණනක් `index` ස්ථානයෙන් අවසන් විය හැක), ස්ථානයේ (එනම් වෙන් නොකෙරේ) සහ *O*(*n*) නරකම අවස්ථාවකි.
    /// මෙම කාර්යය අනෙකුත් පුස්තකාලවල "kth element" ලෙසද හැඳින්වේ.
    /// එය පහත දැක්වෙන අගයන්ගෙන් ත්‍රිත්වයක් ලබා දෙයි: ලබා දී ඇති යතුරු නිස්සාරණ ශ්‍රිතය භාවිතා කර දී ඇති දර්ශකයේ ඇති මූලද්‍රව්‍යයට වඩා අඩු, ලබා දී ඇති දර්ශකයේ අගය සහ ලබා දී ඇති දර්ශකයේ ඇති මූලද්‍රව්‍යයට වඩා වැඩි සියලුම මූලද්‍රව්‍ය.
    ///
    ///
    /// # වත්මන් ක්‍රියාත්මක කිරීම
    ///
    /// වත්මන් ඇල්ගොරිතම පදනම් වී ඇත්තේ [`sort_unstable`] සඳහා භාවිතා කරන එකම ක්වික්සෝර්ට් ඇල්ගොරිතමයේ ක්ෂණික තේරීම් කොටස මත ය.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` විට Panics, එයින් අදහස් කරන්නේ හිස් පෙති මත සැමවිටම panics යන්නයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // නිරපේක්ෂ අගයට අනුව අරාව වර්ග කර ඇති ආකාරයට මධ්යන්යය ආපසු එවන්න.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // නිශ්චිත දර්ශකය පිළිබඳව අප වර්ග කරන ආකාරය මත පදනම්ව, පෙත්ත පහත සඳහන් එකක් වනු ඇති බවට අපට සහතික වේ.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// [`PartialEq`] trait ක්‍රියාත්මක කිරීම අනුව අඛණ්ඩව නැවත නැවතත් සියලුම මූලද්‍රව්‍ය පෙත්තෙහි අවසානය දක්වා ගෙන යයි.
    ///
    ///
    /// පෙති දෙකක් ලබා දෙයි.පළමුවැන්නෙහි අඛණ්ඩ පුනරාවර්තන අංග නොමැත.
    /// දෙවැන්න නිශ්චිත අනුපිළිවෙලකින් සියලුම අනුපිටපත් අඩංගු නොවේ.
    ///
    /// පෙත්ත වර්ග කර ඇත්නම්, පළමු ආපසු ලබා දුන් පෙත්තෙහි අනුපිටපත් නොමැත.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// දී ඇති සමානාත්මතා සම්බන්ධතාවය තෘප්තිමත් කරමින් පෙත්තෙහි අවසානය දක්වා අඛණ්ඩ මූලද්‍රව්‍යයන්ගෙන් පළමුවැන්න හැර අනෙක් සියල්ල ගෙන යයි.
    ///
    /// පෙති දෙකක් ලබා දෙයි.පළමුවැන්නෙහි අඛණ්ඩ පුනරාවර්තන අංග නොමැත.
    /// දෙවැන්න නිශ්චිත අනුපිළිවෙලකින් සියලුම අනුපිටපත් අඩංගු නොවේ.
    ///
    /// `same_bucket` ශ්‍රිතය පෙත්තෙන් මූලද්‍රව්‍ය දෙකක් වෙත යොමු කර ඇති අතර මූලද්‍රව්‍ය සමාන ලෙස සැසඳේද යන්න තීරණය කළ යුතුය.
    /// පෙත්තෙහි ඇති අනුපිළිවෙලින් මූලද්‍රව්‍ය ප්‍රතිවිරුද්ධ අනුපිළිවෙලින් සම්මත වේ, එබැවින් `same_bucket(a, b)` `true` ආපසු ලබා දෙන්නේ නම්, පෙත්ත අවසානයේ `a` ගෙන යනු ලැබේ.
    ///
    ///
    /// පෙත්ත වර්ග කර ඇත්නම්, පළමු ආපසු ලබා දුන් පෙත්තෙහි අනුපිටපත් නොමැත.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // අපට `self` පිළිබඳ විකෘති සඳහනක් තිබුණද, අපට *අත්තනෝමතික* වෙනස්කම් කළ නොහැක.`same_bucket` ඇමතුම් වලට panic විය හැකිය, එබැවින් පෙත්ත සෑම විටම වලංගු තත්වයක පවතින බව අප විසින් සහතික කළ යුතුය.
        //
        // අප මෙය හසුරුවන ආකාරය වන්නේ swaps භාවිතා කිරීමෙනි;අපි සියලු මූලද්‍රව්‍යයන් මත නැවත ක්‍රියා කරමු, අප යන විට හුවමාරු කරගනිමින් අවසානයේ අප තබා ගැනීමට කැමති මූලද්‍රව්‍යයන් ඉදිරියෙන් සිටින අතර, අප ප්‍රතික්ෂේප කිරීමට බලාපොරොත්තු වන ඒවා පිටුපසින් ඇත.
        // එවිට අපට පෙත්ත බෙදිය හැකිය.
        // මෙම මෙහෙයුම තවමත් `O(n)` වේ.
        //
        // උදාහරණය: අපි ආරම්භ කරන්නේ `r` ඊළඟට නියෝජනය වන මෙම තත්වයෙන්
        // කියවන්න "සහ `w` ඊළඟ_රයිට්` නියෝජනය කරයි.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // ස්වයං [w-1] ට සාපේක්ෂව self[r] සංසන්දනය කිරීම, මෙය අනුපිටපතක් නොවේ, එබැවින් අපි self[r] සහ self[w] හුවමාරු කර ගනිමු (r==w ලෙස කිසිදු බලපෑමක් නැත) ඉන්පසු r සහ w යන දෙවර්ගයම වැඩි කර අපව අතහැර දමමු:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // ස්වයං [w-1] ට සාපේක්ෂව self[r] සංසන්දනය කිරීමේදී, මෙම අගය අනුපිටපතකි, එබැවින් අපි `r` වැඩි කරන නමුත් අනෙක් සියල්ල නොවෙනස්ව තබමු:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // ස්වයං [w-1] ට සාපේක්ෂව self[r] සංසන්දනය කිරීම, මෙය අනුපිටපතක් නොවේ, එබැවින් self[r] සහ self[w] හුවමාරු කර අත්තිකාරම් r සහ w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // අනුපිටපතක් නොවේ, නැවත කරන්න:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // අනුපිටපත, පෙත්තක advance r. End.W දී බෙදන්න.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // ආරක්ෂාව: `while` කොන්දේසිය `next_read` සහ `next_write` සහතික කරයි
        // `len` ට වඩා අඩු බැවින් `self` ඇතුළත වේ.
        // `prev_ptr_write` `ptr_write` ට පෙර එක් මූලද්‍රව්‍යයක් වෙත යොමු කරයි, නමුත් `next_write` 1 සිට ආරම්භ වේ, එබැවින් `prev_ptr_write` කිසි විටෙකත් 0 ට නොඅඩු වන අතර එය පෙත්ත තුළ ඇත.
        // මෙය `ptr_read`, `prev_ptr_write` සහ `ptr_write` අවලංගු කිරීම සහ `ptr.add(next_read)`, `ptr.add(next_write - 1)` සහ `prev_ptr_write.offset(1)` භාවිතා කිරීම සඳහා වන අවශ්‍යතා සපුරාලයි.
        //
        //
        // `next_write` බොහෝ විට එක් ලූපයකට එක් වරක් වැඩි කරනු ලැබේ. එහි අර්ථය මාරු කිරීමට අවශ්‍ය වූ විට කිසිදු මූලද්‍රව්‍යයක් මඟ නොහැරීමයි.
        //
        // `ptr_read` සහ `prev_ptr_write` කිසි විටෙකත් එකම මූලද්‍රව්‍යයට යොමු නොවේ.`&mut *ptr_read`, `&mut* prev_ptr_write` ආරක්ෂිත වීමට මෙය අවශ්‍ය වේ.
        // පැහැදිලි කිරීම සරලවම `next_read >= next_write` සැමවිටම සත්‍ය වන අතර මේ අනුව `next_read > next_write - 1` ද වේ.
        //
        //
        //
        //
        //
        unsafe {
            // අමු දර්ශක භාවිතා කිරීමෙන් සීමාවන් පරීක්ෂා කිරීමෙන් වළකින්න.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// එකම යතුරට නිරාකරණය කරන පෙත්තක අවසානයට අඛණ්ඩ මූලද්‍රව්‍යයන්ගෙන් පළමුවැන්න හැර අනෙක් සියල්ල ගෙන යයි.
    ///
    ///
    /// පෙති දෙකක් ලබා දෙයි.පළමුවැන්නෙහි අඛණ්ඩ පුනරාවර්තන අංග නොමැත.
    /// දෙවැන්න නිශ්චිත අනුපිළිවෙලකින් සියලුම අනුපිටපත් අඩංගු නොවේ.
    ///
    /// පෙත්ත වර්ග කර ඇත්නම්, පළමු ආපසු ලබා දුන් පෙත්තෙහි අනුපිටපත් නොමැත.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// පෙත්තෙහි පළමු `mid` මූලද්‍රව්‍ය අවසානය දක්වා ගමන් කරන අතර අවසාන `self.len() - mid` මූලද්‍රව්‍ය ඉදිරිපස දෙසට ගමන් කරයි.
    /// `rotate_left` ඇමතීමෙන් පසුව, කලින් `mid` දර්ශකයේ ඇති මූලද්‍රව්‍යය පෙත්තෙහි පළමු අංගය බවට පත්වේ.
    ///
    /// # Panics
    ///
    /// පෙත්තක දිගට වඩා `mid` වැඩි නම් මෙම ශ්‍රිතය panic වනු ඇත.`mid == self.len()` _not_ panic කරන අතර එය විවෘත භ්‍රමණය නොවන බව සලකන්න.
    ///
    /// # Complexity
    ///
    /// රේඛීය (`self.len()`) වේලාවෙන්) ගනී.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// උප කුලකයක් භ්‍රමණය කිරීම:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // ආරක්ෂාව: `[p.add(mid) - mid, p.add(mid) + k)` පරාසය ඉතා සුළුය
        // `ptr_rotate` ට අවශ්‍ය පරිදි කියවීම සහ ලිවීම සඳහා වලංගු වේ.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// පෙත්තෙහි පළමු `self.len() - k` මූලද්‍රව්‍ය අවසානය දක්වා ගමන් කරන අතර අවසාන `k` මූලද්‍රව්‍ය ඉදිරිපස දෙසට ගමන් කරයි.
    /// `rotate_right` ඇමතීමෙන් පසුව, කලින් `self.len() - k` දර්ශකයේ ඇති මූලද්‍රව්‍යය පෙත්තෙහි පළමු අංගය බවට පත්වේ.
    ///
    /// # Panics
    ///
    /// පෙත්තක දිගට වඩා `k` වැඩි නම් මෙම ශ්‍රිතය panic වනු ඇත.`k == self.len()` _not_ panic කරන අතර එය විවෘත භ්‍රමණය නොවන බව සලකන්න.
    ///
    /// # Complexity
    ///
    /// රේඛීය (`self.len()`) වේලාවෙන්) ගනී.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// උප කුලකයක් කරකවන්න:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // ආරක්ෂාව: `[p.add(mid) - mid, p.add(mid) + k)` පරාසය ඉතා සුළුය
        // `ptr_rotate` ට අවශ්‍ය පරිදි කියවීම සහ ලිවීම සඳහා වලංගු වේ.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// `value` ක්ලෝන කිරීමෙන් මූලද්‍රව්‍ය සමඟ `self` පුරවයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// නැවත නැවත වසා දැමීමක් ඇමතීමෙන් ආපසු එන මූලද්‍රව්‍ය සමඟ `self` පුරවයි.
    ///
    /// මෙම ක්‍රමය නව අගයන් නිර්මාණය කිරීම සඳහා වසා දැමීමක් භාවිතා කරයි.ඔබ ලබා දී ඇති අගය [`Clone`] ට වඩා කැමති නම්, [`fill`] භාවිතා කරන්න.
    /// අගයන් උත්පාදනය කිරීම සඳහා ඔබට [`Default`] trait භාවිතා කිරීමට අවශ්‍ය නම්, ඔබට තර්කය ලෙස [`Default::default`] සමත් විය හැකිය.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// `src` සිට `self` දක්වා මූලද්‍රව්‍ය පිටපත් කරයි.
    ///
    /// `src` හි දිග `self` ට සමාන විය යුතුය.
    ///
    /// `T` විසින් `Copy` ක්‍රියාත්මක කරන්නේ නම්, එය [`copy_from_slice`] භාවිතා කිරීම වඩා ක්‍රියාකාරී විය හැකිය.
    ///
    /// # Panics
    ///
    /// පෙති දෙක එකිනෙකට වෙනස් දිගක් තිබේ නම් මෙම ශ්‍රිතය panic වනු ඇත.
    ///
    /// # Examples
    ///
    /// පෙත්තක සිට තවත් මූලද්‍රව්‍ය දෙකක් ක්ලෝන කිරීම:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // පෙති එකම දිග විය යුතු නිසා, අපි ප්‍රභව පෙත්ත මූලද්‍රව්‍ය හතරක සිට දෙකකට කපා දමමු.
    /// // අප මෙය නොකරන්නේ නම් එය panic වනු ඇත.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust බලාත්මක කරන්නේ එක් විෂය පථයක් තුළ නිශ්චිත දත්ත කැබැල්ලකට වෙනස් කළ නොහැකි යොමු කිරීම් සහිත එක් විකෘති යොමු කිරීමක් පමණක් තිබිය හැකි බවයි.
    /// මේ නිසා, එක් පෙත්තක් මත `clone_from_slice` භාවිතා කිරීමට උත්සාහ කිරීම සම්පාදනය අසාර්ථක වනු ඇත:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// මෙය වටා වැඩ කිරීම සඳහා, අපට පෙත්තකින් වෙනස් උප පෙති දෙකක් නිර්මාණය කිරීමට [`split_at_mut`] භාවිතා කළ හැකිය:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// සියලුම අංග `src` සිට `self` දක්වා පිටපත් කරයි.
    ///
    /// `src` හි දිග `self` ට සමාන විය යුතුය.
    ///
    /// `T` `Copy` ක්‍රියාත්මක නොකරන්නේ නම්, [`clone_from_slice`] භාවිතා කරන්න.
    ///
    /// # Panics
    ///
    /// පෙති දෙක එකිනෙකට වෙනස් දිගක් තිබේ නම් මෙම ශ්‍රිතය panic වනු ඇත.
    ///
    /// # Examples
    ///
    /// පෙත්තක සිට තවත් මූලද්‍රව්‍ය දෙකක් පිටපත් කිරීම:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // පෙති එකම දිග විය යුතු නිසා, අපි ප්‍රභව පෙත්ත මූලද්‍රව්‍ය හතරක සිට දෙකකට කපා දමමු.
    /// // අප මෙය නොකරන්නේ නම් එය panic වනු ඇත.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust බලාත්මක කරන්නේ එක් විෂය පථයක් තුළ නිශ්චිත දත්ත කැබැල්ලකට වෙනස් කළ නොහැකි යොමු කිරීම් සහිත එක් විකෘති යොමු කිරීමක් පමණක් තිබිය හැකි බවයි.
    /// මේ නිසා, එක් පෙත්තක් මත `copy_from_slice` භාවිතා කිරීමට උත්සාහ කිරීම සම්පාදනය අසාර්ථක වනු ඇත:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// මෙය වටා වැඩ කිරීම සඳහා, අපට පෙත්තකින් වෙනස් උප පෙති දෙකක් නිර්මාණය කිරීමට [`split_at_mut`] භාවිතා කළ හැකිය:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // panic කේත මාර්ගය ඇමතුම් වෙබ් අඩවිය අවහිර නොකිරීමට සීතල ශ්‍රිතයක් තුළට දමා ඇත.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // ආරක්ෂාව: `self` අර්ථ දැක්වීම අනුව `self.len()` මූලද්‍රව්‍ය සඳහා වලංගු වන අතර `src` විය
        // එකම දිගක් තිබේදැයි පරීක්ෂා කර ඇත.
        // විකෘති යොමු කිරීම් සුවිශේෂී බැවින් පෙති අතිච්ඡාදනය විය නොහැක.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// පෙත්තක එක් කොටසක සිට තවත් කොටසකට මූලද්‍රව්‍ය පිටපත් කරයි.
    ///
    /// `src` යනු පිටපත් කිරීමට `self` තුළ ඇති පරාසයයි.
    /// `dest` යනු පිටපත් කිරීම සඳහා `self` තුළ ඇති පරාසයේ ආරම්භක දර්ශකය වන අතර එය `src` ට සමාන දිගකින් යුක්ත වේ.
    /// පරාස දෙක අතිච්ඡාදනය විය හැකිය.
    /// පරාස දෙකේ කෙළවර `self.len()` ට වඩා අඩු හෝ සමාන විය යුතුය.
    ///
    /// # Panics
    ///
    /// පරාසය පෙත්තක අවසානය ඉක්මවා ගියහොත් හෝ ආරම්භයට පෙර `src` අවසානය නම් මෙම ශ්‍රිතය panic වේ.
    ///
    ///
    /// # Examples
    ///
    /// පෙත්තක් තුළ බයිට් හතරක් පිටපත් කිරීම:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // ආරක්ෂාව: `ptr::copy` සඳහා වන කොන්දේසි සියල්ල ඉහත පරීක්ෂා කර ඇත,
        // `ptr::add` සඳහා ඇති ඒවා මෙන්.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// `self` හි ඇති සියලුම අංග `other` සමඟ මාරු කරන්න.
    ///
    /// `other` හි දිග `self` ට සමාන විය යුතුය.
    ///
    /// # Panics
    ///
    /// පෙති දෙක එකිනෙකට වෙනස් දිගක් තිබේ නම් මෙම ශ්‍රිතය panic වනු ඇත.
    ///
    /// # Example
    ///
    /// පෙති හරහා මූලද්රව්ය දෙකක් මාරු කිරීම:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust බලාත්මක කරන්නේ නිශ්චිත විෂය පථයක් තුළ එක් දත්ත කැබැල්ලකට එක් විකෘති යොමු කිරීමක් පමණක් තිබිය හැකි බවයි.
    ///
    /// මේ නිසා, එක් පෙත්තක් මත `swap_with_slice` භාවිතා කිරීමට උත්සාහ කිරීම සම්පාදනය අසාර්ථක වනු ඇත:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// මේ සඳහා වැඩ කිරීම සඳහා, අපට පෙත්තකින් වෙනස් විකෘති උප පෙති දෙකක් නිර්මාණය කිරීමට [`split_at_mut`] භාවිතා කළ හැකිය:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // ආරක්ෂාව: `self` අර්ථ දැක්වීම අනුව `self.len()` මූලද්‍රව්‍ය සඳහා වලංගු වන අතර `src` විය
        // එකම දිගක් තිබේදැයි පරීක්ෂා කර ඇත.
        // විකෘති යොමු කිරීම් සුවිශේෂී බැවින් පෙති අතිච්ඡාදනය විය නොහැක.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// `align_to{,_mut}` සඳහා මැද හා පසුපස පෙත්තෙහි දිග ගණනය කිරීමේ කාර්යය.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // අපි `rest` ගැන කුමක් කරන්නෙමුද යන්න අපට හඳුනාගත හැකි වන්නේ අවම යූ ටී ගණනට දැමිය හැකි යූ යූ වලින් කොපමණ සංඛ්‍යාවක්ද යන්නයි.
        //
        // එවැනි එක් එක් "multiple" සඳහා අපට කොපමණ ටී ප්‍රමාණයක් අවශ්‍යද?
        //
        // උදාහරණයක් ලෙස T=u8 U=u16 සලකා බලන්න.එවිට අපට 1 U 2 Ts වලට දැමිය හැකිය.සරල.
        // දැන්, උදාහරණයක් ලෙස size_of: :<T>=16, size_of::<U>=24.</u>
        // `rest` පෙත්තෙහි සෑම Ts 3 ක් වෙනුවට අපට 2 ක් තැබිය හැකිය.
        // ටිකක් සංකීර්ණයි.
        //
        // මෙය ගණනය කිරීමේ සූත්‍රය:
        //
        // අප= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // පුළුල් කිරීම සහ සරල කිරීම:
        //
        // අප=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // වාසනාවකට මෙන් මේ සියල්ල නිරන්තරයෙන් ඇගයීමට ලක්ව ඇති හෙයින් ... මෙහි කාර්යසාධනය වැදගත් නොවේ!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // පුනරාවර්තන ස්ටයින්ගේ ඇල්ගොරිතමය අප තවමත් මෙම `const fn` සෑදිය යුතුය (සහ අප එසේ කරන්නේ නම් පුනරාවර්තන ඇල්ගොරිතම වෙත ආපසු යන්න) මන්ද මේ සියල්ල සංවර්‍ධනය කිරීම සඳහා llvm මත යැපීම…හොඳයි, එය මට අපහසුතාවයක් ගෙන දේ.
            //
            //

            // ආරක්ෂාව: `a` සහ `b` ශුන්‍ය නොවන අගයන් ලෙස පරීක්ෂා කරනු ලැබේ.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // 2 හි සියලු සාධක b වෙතින් ඉවත් කරන්න
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // ආරක්ෂාව: `b` ශුන්‍ය නොවන බව පරීක්ෂා කරනු ලැබේ.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // මෙම දැනුමෙන් සන්නද්ධව, අපට ගැලපෙන කොපමණ යූ යූ සොයා ගත හැකිය!
        let us_len = self.len() / ts * us;
        // පසුපස පෙත්තෙහි කොපමණ ටී ප්‍රමාණයක් පවතිනු ඇත්ද!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// පෙත්ත වෙනත් වර්ගයක පෙත්තකට සම්ප්‍රේෂණය කරන්න, වර්ග පෙළගැස්වීම පවත්වා ගෙන යන බව සහතික කරන්න.
    ///
    /// මෙම ක්‍රමය පෙත්ත එකිනෙකට වෙනස් පෙති තුනකට බෙදා ඇත: උපසර්ගය, නිවැරදිව පෙලගැසී ඇති නව වර්ගයක මැද පෙත්ත සහ උපසර්ගය පෙත්ත.
    /// මෙම ක්‍රමය මඟින් මැද පෙත්තක් ලබා දී ඇති වර්ගයට සහ ආදාන පෙත්තකට හැකි උපරිම දිග බවට පත් කළ හැකි නමුත් ඔබේ ඇල්ගොරිතමයේ ක්‍රියාකාරිත්වය පමණක් රඳා පැවතිය යුත්තේ එහි නිරවද්‍යතාවය මත නොවේ.
    ///
    /// සියලු ආදාන දත්ත උපසර්ගය හෝ උපසර්ගය පෙත්තක් ලෙස ආපසු ලබා දීමට අවසර ඇත.
    ///
    /// ආදාන මූලද්‍රව්‍යය `T` හෝ ප්‍රතිදාන මූලද්‍රව්‍යය `U` ශුන්‍ය ප්‍රමාණයේ වන විට මෙම ක්‍රමයට කිසිදු අරමුණක් නොමැති අතර කිසිවක් බෙදීමෙන් තොරව මුල් පෙත්ත නැවත ලබා දෙනු ඇත.
    ///
    /// # Safety
    ///
    /// මෙම ක්‍රමය අත්‍යාවශ්‍යයෙන්ම ආපසු ලබා දුන් මැද පෙත්තෙහි ඇති මූලද්‍රව්‍යයන්ට සාපේක්ෂව `transmute` වේ, එබැවින් `transmute::<T, U>` සම්බන්ධ සියලු සුපුරුදු අවවාද ද මෙහි අදාළ වේ.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // මෙම ශ්‍රිතයෙන් වැඩි ප්‍රමාණයක් නියත ඇගයීමට ලක් කෙරෙන බව සලකන්න.
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // ZSTs විශේෂයෙන් හසුරුවන්න, එනම්-ඒවා කිසිසේත් හසුරුවන්න එපා.
            return (self, &[], &[]);
        }

        // පළමුව, අපි පළමු හා 2 වන පෙත්ත අතර බෙදී යන්නේ කුමන අවස්ථාවේදීදැයි සොයා බලන්න.
        // ptr.align_offset සමඟ පහසුය.
        let ptr = self.as_ptr();
        // ආරක්ෂාව: සවිස්තරාත්මක ආරක්‍ෂිත අදහස් දැක්වීම සඳහා `align_to_mut` ක්‍රමය බලන්න.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // ආරක්ෂාව: දැන් `rest` අනිවාර්යයෙන්ම පෙළගස්වා ඇත, එබැවින් පහත `from_raw_parts` හරි,
            // අපට `T` ආරක්ෂිතව `U` වෙත සම්ප්‍රේෂණය කළ හැකි බව අමතන්නා සහතික කරයි.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// පෙත්ත වෙනත් වර්ගයක පෙත්තකට සම්ප්‍රේෂණය කරන්න, වර්ග පෙළගැස්වීම පවත්වා ගෙන යන බව සහතික කරන්න.
    ///
    /// මෙම ක්‍රමය පෙත්ත එකිනෙකට වෙනස් පෙති තුනකට බෙදා ඇත: උපසර්ගය, නිවැරදිව පෙලගැසී ඇති නව වර්ගයක මැද පෙත්ත සහ උපසර්ගය පෙත්ත.
    /// මෙම ක්‍රමය මඟින් මැද පෙත්තක් ලබා දී ඇති වර්ගයට සහ ආදාන පෙත්තකට හැකි උපරිම දිග බවට පත් කළ හැකි නමුත් ඔබේ ඇල්ගොරිතමයේ ක්‍රියාකාරිත්වය පමණක් රඳා පැවතිය යුත්තේ එහි නිරවද්‍යතාවය මත නොවේ.
    ///
    /// සියලු ආදාන දත්ත උපසර්ගය හෝ උපසර්ගය පෙත්තක් ලෙස ආපසු ලබා දීමට අවසර ඇත.
    ///
    /// ආදාන මූලද්‍රව්‍යය `T` හෝ ප්‍රතිදාන මූලද්‍රව්‍යය `U` ශුන්‍ය ප්‍රමාණයේ වන විට මෙම ක්‍රමයට කිසිදු අරමුණක් නොමැති අතර කිසිවක් බෙදීමෙන් තොරව මුල් පෙත්ත නැවත ලබා දෙනු ඇත.
    ///
    /// # Safety
    ///
    /// මෙම ක්‍රමය අත්‍යාවශ්‍යයෙන්ම ආපසු ලබා දුන් මැද පෙත්තෙහි ඇති මූලද්‍රව්‍යයන්ට සාපේක්ෂව `transmute` වේ, එබැවින් `transmute::<T, U>` සම්බන්ධ සියලු සුපුරුදු අවවාද ද මෙහි අදාළ වේ.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // මෙම ශ්‍රිතයෙන් වැඩි ප්‍රමාණයක් නියත ඇගයීමට ලක් කෙරෙන බව සලකන්න.
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // ZSTs විශේෂයෙන් හසුරුවන්න, එනම්-ඒවා කිසිසේත් හසුරුවන්න එපා.
            return (self, &mut [], &mut []);
        }

        // පළමුව, අපි පළමු හා 2 වන පෙත්ත අතර බෙදී යන්නේ කුමන අවස්ථාවේදීදැයි සොයා බලන්න.
        // ptr.align_offset සමඟ පහසුය.
        let ptr = self.as_ptr();
        // ආරක්ෂාව: මෙහිදී අපි සහතික කරන්නේ යූ සඳහා පෙළගස්වන දර්ශක යූ සඳහා භාවිතා කරන බවයි
        // ඉතිරි ක්‍රමය.මෙය සිදු කරනුයේ යූ ඉලක්ක කරගත් පෙළගැස්මක් සමඟ දර්ශකයක්&[T] වෙත යොමු කිරීමෙනි.
        // `crate::ptr::align_offset` නිවැරදිව පෙලගැසී ඇති සහ වලංගු දර්ශකයක් වන `ptr` (එය `self` වෙත යොමු වීමකින් පැමිණේ) සහ ප්‍රමාණයෙන් දෙකක බලයක් සහිත (එය U සඳහා වන පෙළගැස්මෙන් එන බැවින්) එහි ආරක්ෂිත බාධක තෘප්තිමත් කරයි.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // මෙයින් පසු අපට නැවත `rest` භාවිතා කළ නොහැක, එය එහි අන්වර්ථ `mut_ptr` අවලංගු කරයි!ආරක්ෂාව: `align_to` සඳහා අදහස් බලන්න.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// මෙම පෙත්තෙහි මූලද්රව්ය වර්ග කර තිබේදැයි පරීක්ෂා කරයි.
    ///
    /// එනම්, එක් එක් මූලද්‍රව්‍යය සඳහා `a` සහ එහි පහත දැක්වෙන මූලද්‍රව්‍ය `b` සඳහා, `a <= b` රඳවා තබා ගත යුතුය.පෙත්ත හරියටම ශුන්‍ය හෝ එක් මූලද්‍රව්‍යයක් ලබා දෙන්නේ නම්, `true` ආපසු ලබා දෙනු ලැබේ.
    ///
    /// `Self::Item` යනු `PartialOrd` පමණක් නොව `Ord` නොවේ නම්, ඉහත අර්ථ දැක්වීම මඟින් ඇඟවෙන්නේ අඛණ්ඩ අයිතම දෙකක් සැසඳිය නොහැකි නම් මෙම ශ්‍රිතය `false` ලබා දෙන බවයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// ලබා දී ඇති සංසන්දනාත්මක ශ්‍රිතය භාවිතයෙන් මෙම පෙත්තෙහි මූලද්‍රව්‍ය වර්ග කර තිබේදැයි පරීක්ෂා කරයි.
    ///
    /// `PartialOrd::partial_cmp` භාවිතා කරනවා වෙනුවට, මෙම ශ්‍රිතය මූලද්‍රව්‍ය දෙකක අනුපිළිවෙල තීරණය කිරීම සඳහා දී ඇති `compare` ශ්‍රිතය භාවිතා කරයි.
    /// ඒ හැර, එය [`is_sorted`] ට සමාන ය;වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// දී ඇති යතුරු නිස්සාරණ ශ්‍රිතය භාවිතයෙන් මෙම පෙත්තෙහි මූලද්‍රව්‍ය වර්ග කර තිබේදැයි පරීක්ෂා කරයි.
    ///
    /// පෙත්තෙහි මූලද්‍රව්‍ය කෙලින්ම සංසන්දනය කරනවා වෙනුවට, මෙම ශ්‍රිතය `f` විසින් තීරණය කරන පරිදි මූලද්‍රව්‍යවල යතුරු සංසන්දනය කරයි.
    /// ඒ හැර, එය [`is_sorted`] ට සමාන ය;වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// ලබා දී ඇති පුරෝකථනයට අනුව කොටස් ලක්ෂ්‍යයේ දර්ශකය ලබා දෙයි (දෙවන කොටසේ පළමු මූලද්‍රව්‍යයේ දර්ශකය).
    ///
    /// පෙත්ත ලබා දී ඇති පුරෝකථනයට අනුව කොටස් කිරීමට උපකල්පනය කෙරේ.
    /// මෙයින් අදහස් කරන්නේ, පුරෝකථනය කළ ප්‍රතිලාභ සත්‍ය වන සියලුම මූලද්‍රව්‍යයන් පෙත්ත ආරම්භයේදීම වන අතර, පුරෝකථනය කළ ප්‍රතිලාභ සාවද්‍ය වන සියලු මූලද්‍රව්‍යයන් අවසානයේ ඇති බවයි.
    ///
    /// උදාහරණයක් ලෙස, [7, 15, 3, 5, 4, 12, 6] යනු පුරෝකථනය කරන ලද x% 2!=0 යටතේ කොටස් කර ඇත (සියලු අමුතු සංඛ්‍යා ආරම්භයේ දී ඇත, සියල්ල අවසානයේ පවා).
    ///
    /// මෙම පෙත්ත කොටස් කර නොමැති නම්, ආපසු ලබා දුන් ප්‍රති result ලය නිශ්චිත හා අර්ථ විරහිත ය, මන්ද මෙම ක්‍රමය එක්තරා ආකාරයක ද්විමය සෙවීමක් සිදු කරයි.
    ///
    /// [`binary_search`], [`binary_search_by`], සහ [`binary_search_by_key`] ද බලන්න.
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // ආරක්ෂාව: `left < right` විට, `left <= mid < right`.
            // එබැවින් `left` සෑම විටම වැඩි වන අතර `right` සෑම විටම අඩු වන අතර, ඒ දෙකෙන් එකක් තෝරා ගනු ලැබේ.අවස්ථා දෙකේදීම `left <= right` සෑහීමකට පත්වේ.එබැවින් පියවරක් තුළ `left < right` නම්, ඊළඟ පියවරේදී `left <= right` සෑහීමකට පත්වේ.
            //
            // එබැවින් `left != right` පවතින තාක් කල්, `0 <= left < right <= len` සෑහීමකට පත්වන අතර මෙම නඩුවේ `0 <= mid < len` ද සෑහීමකට පත්වේ.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: අපි පැහැදිලිවම එකම දිගට ඒවා කපා දැමිය යුතුයි
        // සීමාවන් පරික්ෂා කිරීම ප්‍රශස්තකරණයට පහසු කිරීම සඳහා.
        // නමුත් එය මත විශ්වාසය තැබිය නොහැකි බැවින් අපට T: Copy සඳහා විශේෂ specialized තාවයක් ඇත.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// හිස් පෙත්තක් සාදයි.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// විකෘති හිස් පෙත්තක් සාදයි.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// පෙති වල රටා, දැනට භාවිතා කරන්නේ `strip_prefix` සහ `strip_suffix` පමණි.
/// future ලක්ෂ්‍යයකදී, අපි `core::str::Pattern` (ලිවීමේදී `str` ට සීමා කර ඇති) පෙති වලට සාමාන්‍යකරණය කිරීමට බලාපොරොත්තු වෙමු, එවිට මෙම trait ප්‍රතිස්ථාපනය හෝ අහෝසි කරනු ඇත.
///
pub trait SlicePattern {
    /// පෙත්තෙහි මූලද්‍රව්‍ය වර්ගය ගැලපේ.
    type Item;

    /// දැනට, `SlicePattern` පාරිභෝගිකයින්ට පෙත්තක් අවශ්ය වේ.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}