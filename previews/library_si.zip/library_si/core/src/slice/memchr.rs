// rust-memchr වෙතින් ලබාගත් මුල් ක්‍රියාත්මක කිරීම.
// ප්‍රකාශන හිමිකම 2015 ඇන්ඩ rew ගැලන්ට්, බ්ලස් සහ නිකොලස් කොච්

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// කප්පාදු කිරීම භාවිතා කරන්න.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// `x` හි කිසියම් ශුන්‍ය බයිට් එකක් තිබේ නම් `true` ලබා දෙයි.
///
/// *කාරණා පරිගණකයෙන්*, ජේ. ආර්න්ඩ්:
///
/// `අදහස වන්නේ එක් එක් බයිට් වලින් එකක් අඩු කර ණය ලබා ගැනීම වඩාත් වැදගත් වන පරිදි බයිට් සෙවීමයි.
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// `text` හි බයිට් `x` හා ගැලපෙන පළමු දර්ශකය ලබා දෙයි.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // කුඩා පෙති සඳහා වේගවත් මාවත
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // වරකට `usize` වචන දෙකක් කියවීමෙන් තනි බයිට් අගයක් පරිලෝකනය කරන්න.
    //
    // `text` කොටස් තුනකට බෙදන්න
    // - පෙළෙහි පළමු වචනය පෙළගස්වන ලිපිනයට පෙර, නොබැඳි ආරම්භක කොටස
    // - ශරීරය, වරකට වචන 2 කින් පරිලෝකනය කරන්න
    // - අන්තිම කොටස, <2 වචන ප්‍රමාණය

    // පෙලගැසී ඇති මායිම දක්වා සොයන්න
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // පෙළෙහි සිරුර සොයන්න
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // ආරක්ෂාව: කාලයාගේ ඇවෑමෙන් අවම වශයෙන් 2 * usize_bytes දුරක් සහතික කෙරේ
        // ඕෆ්සෙට් සහ පෙත්තෙහි අවසානය අතර.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // ගැලපෙන බයිට් එකක් තිබේ නම් බිඳ දමන්න
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // ශරීර ලූපය නතර වූ ස්ථානයෙන් පසු බයිට් එක සොයා ගන්න.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// `text` හි බයිට් `x` හා ගැලපෙන අවසාන දර්ශකය ලබා දෙයි.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // වරකට `usize` වචන දෙකක් කියවීමෙන් තනි බයිට් අගයක් පරිලෝකනය කරන්න.
    //
    // `text` කොටස් තුනකට බෙදන්න:
    // - නොබැඳි වලිගය, පෙළෙහි අවසාන වචනය පෙළගස්වා ඇති ලිපිනයට පසුව,
    // - ශරීරය, වරකට වචන 2 කින් පරිලෝකනය කරනු ලැබේ,
    // - ඉතිරිව ඇති පළමු බයිට්, <2 වචන ප්‍රමාණය.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // අපි මෙය හඳුන්වන්නේ උපසර්ගයේ දිග සහ උපසර්ගය ලබා ගැනීම සඳහා පමණි.
        // මැද අපි සෑම විටම එකවර කුට්ටි දෙකක් සකස් කරමු.
        // ආරක්ෂාව: `align_to` විසින් හසුරුවන ප්‍රමාණයේ වෙනස්කම් හැර `[u8]` සිට `[usize]` වෙත සම්ප්‍රේෂණය කිරීම ආරක්ෂිත වේ.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // පෙළෙහි සිරුර සොයන්න, අපි min_aligned_offset තරණය නොකරන බවට වග බලා ගන්න.
    // ඕෆ්සෙට් සෑම විටම පෙලගැසී ඇත, එබැවින් `>` පරීක්ෂා කිරීම පමණක් ප්‍රමාණවත් වන අතර පිටාර ගැලීම වළක්වයි.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // ආරක්ෂාව: ඕෆ්සෙට් ආරම්භ වන්නේ ලෙන්, suffix.len() ට වඩා වැඩි වන තාක් කල් ය
        // min_aligned_offset (prefix.len()) ඉතිරි දුර අවම වශයෙන් 2 * chunk_bytes වේ.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // ගැලපෙන බයිට් එකක් තිබේ නම් කඩන්න.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // ශරීර ලූපය නැවැත්වීමට පෙර බයිට් එක සොයා ගන්න.
    text[..offset].iter().rposition(|elt| *elt == x)
}