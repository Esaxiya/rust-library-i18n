//! පෙති අනුකාරක භාවිතා කරන මැක්‍රෝස්.

// Is_empty සහ len ආදානය කිරීම විශාල කාර්ය සාධන වෙනසක් ඇති කරයි
macro_rules! is_empty {
    // අපි ZST iterator එකක දිග සංකේතනය කරන ආකාරය, මෙය ZST සහ ZST නොවන දෙකටම ක්‍රියා කරයි.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// සමහර සීමාවන් පරීක්ෂා කිරීමෙන් (`position` බලන්න), අපි තරමක් අනපේක්ෂිත ආකාරයකින් දිග ගණනය කරමු.
// (`කෝඩ්ජන්/ස්ලයිස්-පිහිටුම්-මායිම්-චෙක් 'මගින් පරීක්ෂා කර ඇත.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // අප සමහර විට අනාරක්ෂිත කොටසක භාවිතා වේ

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // මෙම _cannot_ `unchecked_sub` භාවිතා කරන්නේ අප දිගු ZST පෙති අනුකාරකවල දිග නිරූපණය කිරීම සඳහා එතීම මත රඳා පවතින බැවිනි.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // `start <= end`, එබැවින් `offset_from` ට වඩා හොඳින් කළ හැකි බව අපි දනිමු.
            // සුදුසු කොඩි මෙහි සැකසීමෙන් අපට එල්එල්වීඑම් වෙත මෙය පැවසිය හැකිය, එය සීමා මායිම් ඉවත් කිරීමට උපකාරී වේ.
            // ආරක්ෂාව: වෙනස් නොවන වර්ගය අනුව, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // එල්එල්වීඑම් වෙත පැවසීමෙන්, දර්ශකයන් වර්ගයේ ප්‍රමාණයෙන් නිශ්චිත ගුණයකින් වෙන්ව ඇති අතර, එයට `(end - start) < size` වෙනුවට `len() == 0` සිට `start == end` දක්වා ප්‍රශස්තිකරණය කළ හැකිය.
            //
            // ආරක්ෂාව: ආක්‍රමණ වර්ගය අනුව, දර්ශකයන් පෙළගස්වා ඇත
            //         ඒවා අතර ඇති දුර දර්ශක ප්‍රමාණයේ ගුණයක් විය යුතුය
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// `Iter` සහ `IterMut` iterator වල හවුල් අර්ථ දැක්වීම
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // පළමු මූලද්‍රව්‍යය නැවත ලබා දෙන අතර අනුකාරකයේ ආරම්භය 1 කින් ඉදිරියට ගෙන යයි.
        // ආනත ශ්‍රිතයකට සාපේක්ෂව කාර්ය සාධනය වැඩි දියුණු කරයි.
        // අනුකාරකය හිස් නොවිය යුතුය.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // අන්තිම මූලද්‍රව්‍යය නැවත ලබා දෙන අතර අනුකාරකයේ අවසානය 1 කින් පසුපසට ගෙන යයි.
        // ආනත ශ්‍රිතයකට සාපේක්ෂව කාර්ය සාධනය වැඩි දියුණු කරයි.
        // අනුකාරකය හිස් නොවිය යුතුය.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // T යනු ZST එකක් වන විට, iterator හි අවසානය `n` මගින් පසුපසට ගෙන යාමෙන් iterator හැකිලී යයි.
        // `n` `self.len()` නොඉක්මවිය යුතුය.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // අනුකාරකයෙන් පෙත්තක් සෑදීම සඳහා උපකාරක ක්‍රියාකාරිත්වය.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // සුරක්ෂිතතාව: ඉරේටරය නිර්මාණය කර ඇත්තේ දර්ශකයක් සහිත පෙත්තකිනි
                // `self.ptr` සහ දිග `len!(self)`.
                // `from_raw_parts` සඳහා වන සියලුම අවශ්‍යතා සපුරා ඇති බවට මෙය සහතික වේ.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // `offset` මූලද්‍රව්‍ය මඟින් iterator හි ආරම්භය ඉදිරියට ගෙනයාම සඳහා උපකාරක ක්‍රියාකාරිත්වය, පැරණි ආරම්භය නැවත ලබා දීම.
            //
            // අනාරක්ෂිත නිසා ඕෆ්සෙට් `self.len()` නොඉක්මවිය යුතුය.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // ආරක්ෂාව: අමතන්නා `offset` `self.len()` නොඉක්මවන බවට සහතික කරයි,
                    // එබැවින් මෙම නව දර්ශකය `self` තුළ ඇති අතර එය ශුන්‍ය නොවන බවට සහතික වේ.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // `offset` මූලද්‍රව්‍ය මගින් iterator හි අවසානය පසුපසට ගෙනයාම සඳහා උපකාරක ක්‍රියාකාරිත්වය, නව අවසානය නැවත ලබා දීම.
            //
            // අනාරක්ෂිත නිසා ඕෆ්සෙට් `self.len()` නොඉක්මවිය යුතුය.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // ආරක්ෂාව: අමතන්නා `offset` `self.len()` නොඉක්මවන බවට සහතික කරයි,
                    // එය `isize` පිටාර ගැලීම සහතික කර ඇත.
                    // එසේම, එහි ප්‍රති point ලයක් ලෙස දර්ශකය `slice` හි සීමාවන්ගෙන් යුක්ත වන අතර එය `offset` සඳහා වන අනෙකුත් අවශ්‍යතා සපුරාලයි.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // පෙති සමඟ ක්‍රියාත්මක කළ හැකි නමුත් මෙය සීමාවන් පරීක්ෂා කිරීම වළක්වයි

                // ආරක්ෂාව: පෙත්තක ආරම්භක දර්ශකයේ සිට `assume` ඇමතුම් ආරක්ෂිතයි
                // ශුන්‍ය නොවන විය යුතු අතර, ZST නොවන පෙති වලට ද ශුන්‍ය නොවන අන්ත දර්ශකයක් තිබිය යුතුය.
                // `next_unchecked!` වෙත කෙරෙන ඇමතුම ආරක්ෂිත බැවින් අපි මුලින්ම iterator හිස් දැයි පරීක්ෂා කරන්නෙමු.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // මෙම අනුකාරකය දැන් හිස් ය.
                    if mem::size_of::<T>() == 0 {
                        // `ptr` කිසි විටෙකත් 0 නොවිය හැකි නමුත් `end` විය හැකිය (එතීම නිසා).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // ආරක්ෂාව: T යනු ZST නොවේ නම් අවසානය 0 විය නොහැක, මන්ද ptr 0 නොවන අතර අවසානය>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // ආරක්ෂාව: අපි සීමාව ඉක්මවා යමු.`post_inc_start` ZST සඳහා පවා නිවැරදි දේ කරයි.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // `try_fold` භාවිතා කරන සුපුරුදු ක්‍රියාත්මක කිරීම අපි අභිබවා යන්නෙමු, මන්ද මෙම සරල ක්‍රියාත්මක කිරීම මඟින් අඩු LLVM IR ජනනය කරන අතර එය සම්පාදනය කිරීමට වේගවත් වේ.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // `try_fold` භාවිතා කරන සුපුරුදු ක්‍රියාත්මක කිරීම අපි අභිබවා යන්නෙමු, මන්ද මෙම සරල ක්‍රියාත්මක කිරීම මඟින් අඩු LLVM IR ජනනය කරන අතර එය සම්පාදනය කිරීමට වේගවත් වේ.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // `try_fold` භාවිතා කරන සුපුරුදු ක්‍රියාත්මක කිරීම අපි අභිබවා යන්නෙමු, මන්ද මෙම සරල ක්‍රියාත්මක කිරීම මඟින් අඩු LLVM IR ජනනය කරන අතර එය සම්පාදනය කිරීමට වේගවත් වේ.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // `try_fold` භාවිතා කරන සුපුරුදු ක්‍රියාත්මක කිරීම අපි අභිබවා යන්නෙමු, මන්ද මෙම සරල ක්‍රියාත්මක කිරීම මඟින් අඩු LLVM IR ජනනය කරන අතර එය සම්පාදනය කිරීමට වේගවත් වේ.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // `try_fold` භාවිතා කරන සුපුරුදු ක්‍රියාත්මක කිරීම අපි අභිබවා යන්නෙමු, මන්ද මෙම සරල ක්‍රියාත්මක කිරීම මඟින් අඩු LLVM IR ජනනය කරන අතර එය සම්පාදනය කිරීමට වේගවත් වේ.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // `try_fold` භාවිතා කරන සුපුරුදු ක්‍රියාත්මක කිරීම අපි අභිබවා යන්නෙමු, මන්ද මෙම සරල ක්‍රියාත්මක කිරීම මඟින් අඩු LLVM IR ජනනය කරන අතර එය සම්පාදනය කිරීමට වේගවත් වේ.
            // එසේම, `assume` විසින් සීමාවන් පරීක්ෂා කිරීම වළක්වයි.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // ආරක්ෂාව: ලූප ආක්‍රමණිකයා විසින් අපට සීමාව ඉක්මවා යන බවට සහතික වී ඇත:
                        // `i >= n`, `self.next()` `None` ආපසු ලබා දෙන විට සහ ලූපය කැඩී යයි.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // `try_fold` භාවිතා කරන සුපුරුදු ක්‍රියාත්මක කිරීම අපි අභිබවා යන්නෙමු, මන්ද මෙම සරල ක්‍රියාත්මක කිරීම මඟින් අඩු LLVM IR ජනනය කරන අතර එය සම්පාදනය කිරීමට වේගවත් වේ.
            // එසේම, `assume` විසින් සීමාවන් පරීක්ෂා කිරීම වළක්වයි.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // ආරක්ෂාව: `i` `n` සිට ආරම්භ වන බැවින් `n` ට වඩා අඩු විය යුතුය
                        // සහ අඩු වෙමින් පවතී.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // ආරක්ෂාව: අමතන්නා විසින් `i` සීමාව ඉක්මවා ඇති බවට සහතික විය යුතුය
                // යටින් පවතින පෙත්තක් වන බැවින් `i` හට `isize` පිටාර ගැලිය නොහැකි අතර ආපසු ලබා දුන් යොමු කිරීම් පෙත්තෙහි මූලද්‍රව්‍යයක් වෙත යොමු වන බවට සහතික වන අතර එමඟින් වලංගු බවට සහතික වේ.
                //
                // නැවත කිසි දිනෙක එකම දර්ශකයක් සමඟ අප කැඳවනු නොලබන බවටත්, මෙම උපසිරැසියට ප්‍රවේශ වන වෙනත් ක්‍රම කැඳවනු නොලබන බවටත් ඇමතුම්කරු සහතික වන බව සලකන්න, එබැවින් ආපසු යොමු කිරීම විකෘති වීම සඳහා වලංගු වේ
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // පෙති සමඟ ක්‍රියාත්මක කළ හැකි නමුත් මෙය සීමාවන් පරීක්ෂා කිරීම වළක්වයි

                // ආරක්ෂාව: පෙත්තක ආරම්භක දර්ශකය ශුන්‍ය නොවන බැවින් `assume` ඇමතුම් ආරක්ෂිතයි,
                // සහ ZST නොවන පෙති වලට ශුන්‍ය නොවන අන්ත දර්ශකයක් ද තිබිය යුතුය.
                // `next_back_unchecked!` වෙත කෙරෙන ඇමතුම ආරක්ෂිත බැවින් අපි මුලින්ම iterator හිස් දැයි පරීක්ෂා කරන්නෙමු.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // මෙම අනුකාරකය දැන් හිස් ය.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // ආරක්ෂාව: අපි සීමාව ඉක්මවා යමු.`pre_dec_end` ZST සඳහා පවා නිවැරදි දේ කරයි.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}