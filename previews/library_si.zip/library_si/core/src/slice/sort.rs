//! පෙති වර්ග කිරීම
//!
//! මෙම මොඩියුලයේ ඕර්සන් පීටර්ස්ගේ රටාව පරාජය කරන ක්වික්සෝර්ට් මත පදනම් වූ වර්ග කිරීමේ ඇල්ගොරිතමයක් අඩංගු වේ. <https://github.com/orlp/pdqsort>
//!
//!
//! අස්ථායී වර්ග කිරීම ලිබ්කෝර් සමඟ අනුකූල වේ, මන්ද එය අපගේ ස්ථාවර වර්ග කිරීමේ ක්‍රියාවලිය මෙන් නොව මතකය වෙන් නොකරයි.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// අතහැර දැමූ විට, `src` සිට `dest` දක්වා පිටපත්.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // ආරක්ෂාව: මෙය උපකාරක පන්තියකි.
        //          නිරවද්‍යතාවය සඳහා කරුණාකර එහි භාවිතය වෙත යොමු වන්න.
        //          එනම්, `ptr::copy_nonoverlapping` අවශ්‍ය පරිදි `src` සහ `dst` අතිච්ඡාදනය නොවන බවට යමෙක් සහතික විය යුතුය.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// විශාල හෝ සමාන මූලද්‍රව්‍යයක් හමු වන තෙක් පළමු මූලද්‍රව්‍යය දකුණට මාරු කරයි.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // ආරක්ෂාව: පහත දැක්වෙන අනාරක්ෂිත මෙහෙයුම් වලට සීමිත පරීක්ෂාවකින් තොරව සුචිගත කිරීම ඇතුළත් වේ (`get_unchecked` සහ `get_unchecked_mut`)
    // සහ මතකය (`ptr::copy_nonoverlapping`) පිටපත් කිරීම.
    //
    // ඒ.සුචිගත කිරීම:
    //  1. අපි අරාවෙහි විශාලත්වය>=2 වෙත පරික්ෂා කළෙමු.
    //  2. අප විසින් කරනු ලබන සියලුම සුචිගත කිරීම් සෑම විටම {0 <= index < len} අතර වේ.
    //
    // බී.මතක පිටපත් කිරීම
    //  1. වලංගු බවට සහතික කර ඇති යොමු කිරීම් සඳහා අපි දර්ශකයන් ලබා ගනිමු.
    //  2. පෙත්තෙහි වෙනස දර්ශක වෙත අපි දර්ශක ලබා ගන්නා බැවින් ඒවාට අතිච්ඡාදනය විය නොහැක.
    //     එනම්, `i` සහ `i-1`.
    //  3. පෙත්ත නිසි ලෙස පෙළගස්වා ඇත්නම්, මූලද්රව්ය නිසි ලෙස පෙලගැසී ඇත.
    //     පෙත්ත නිසි ලෙස පෙලගැසී ඇති බවට වග බලා ගැනීම ඇමතුම්කරුගේ වගකීම වේ.
    //
    // වැඩි විස්තර සඳහා පහත අදහස් බලන්න.
    unsafe {
        // පළමු මූලද්රව්ය දෙක අක්‍රීය නම් ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // පළමු අංගය කොටස් වෙන් කළ විචල්‍යයකට කියවන්න.
            // පහත දැක්වෙන සංසන්දනාත්මක මෙහෙයුමක් නම් panics, `hole` අතහැර දමා ස්වයංක්‍රීයව මූලද්‍රව්‍යය නැවත පෙත්තට ලියයි.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // `I`-මූලද්‍රව්‍යය එක් ස්ථානයකට වමට ගෙනයන්න, එවිට කුහරය දකුණට මාරු කරන්න.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` පහත වැටෙන අතර එමඟින් `v` හි ඉතිරි සිදුරට `tmp` පිටපත් කරයි.
        }
    }
}

/// කුඩා හෝ සමාන මූලද්‍රව්‍යයක් හමු වන තුරු අවසාන මූලද්‍රව්‍යය වමට හරවන්න.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // ආරක්ෂාව: පහත දැක්වෙන අනාරක්ෂිත මෙහෙයුම් වලට සීමිත පරීක්ෂාවකින් තොරව සුචිගත කිරීම ඇතුළත් වේ (`get_unchecked` සහ `get_unchecked_mut`)
    // සහ මතකය (`ptr::copy_nonoverlapping`) පිටපත් කිරීම.
    //
    // ඒ.සුචිගත කිරීම:
    //  1. අපි අරාවෙහි විශාලත්වය>=2 වෙත පරික්ෂා කළෙමු.
    //  2. අප විසින් කරනු ලබන සියලුම සුචිගත කිරීම් සෑම විටම `0 <= index < len-1` අතර වේ.
    //
    // බී.මතක පිටපත් කිරීම
    //  1. වලංගු බවට සහතික කර ඇති යොමු කිරීම් සඳහා අපි දර්ශකයන් ලබා ගනිමු.
    //  2. පෙත්තෙහි වෙනස දර්ශක වෙත අපි දර්ශක ලබා ගන්නා බැවින් ඒවාට අතිච්ඡාදනය විය නොහැක.
    //     එනම්, `i` සහ `i+1`.
    //  3. පෙත්ත නිසි ලෙස පෙළගස්වා ඇත්නම්, මූලද්රව්ය නිසි ලෙස පෙලගැසී ඇත.
    //     පෙත්ත නිසි ලෙස පෙලගැසී ඇති බවට වග බලා ගැනීම ඇමතුම්කරුගේ වගකීම වේ.
    //
    // වැඩි විස්තර සඳහා පහත අදහස් බලන්න.
    unsafe {
        // අවසාන මූලද්රව්ය දෙක අක්‍රීය නම් ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // අන්තිම අංගය තොග වෙන් කළ විචල්‍යයකට කියවන්න.
            // පහත දැක්වෙන සංසන්දනාත්මක මෙහෙයුමක් නම් panics, `hole` අතහැර දමා ස්වයංක්‍රීයව මූලද්‍රව්‍යය නැවත පෙත්තට ලියයි.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // `I`-මූලද්‍රව්‍යය එක් තැනකට දකුණට ගෙනයන්න, එවිට කුහරය වමට හරවන්න.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` පහත වැටෙන අතර එමඟින් `v` හි ඉතිරි සිදුරට `tmp` පිටපත් කරයි.
        }
    }
}

/// යල්පැනගිය මූලද්‍රව්‍ය කිහිපයක් වටා මාරු කිරීමෙන් පෙත්තක් අර්ධ වශයෙන් වර්ග කරයි.
///
/// පෙත්ත අවසානයේ දී වර්ග කර ඇත්නම් `true` ලබා දෙයි.මෙම ශ්‍රිතය *O*(*n*) නරකම අවස්ථාවකි.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // මාරු කළ හැකි යාබද අක්‍රීය යුගල උපරිම ගණන.
    const MAX_STEPS: usize = 5;
    // පෙත්ත මෙයට වඩා කෙටි නම්, කිසිදු අංගයක් මාරු නොකරන්න.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // ආරක්ෂාව: අපි දැනටමත් පැහැදිලිවම `i < len` සමඟ බැඳී ඇති පරීක්ෂාව සිදු කර ඇත්තෙමු.
        // අපගේ සියලු පසු සුචිගත කිරීම් `0 <= index < len` පරාසය තුළ පමණි
        unsafe {
            // යාබද අක්‍රීය මූලද්‍රව්‍ය ඊළඟ යුගලය සොයා ගන්න.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // අපි ඉවරද?
        if i == len {
            return true;
        }

        // කාර්ය සාධන පිරිවැයක් ඇති කෙටි අරා මත මූලද්‍රව්‍ය මාරු නොකරන්න.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // සොයාගත් මූලද්‍රව්‍ය යුගලය මාරු කරන්න.මෙය ඔවුන්ව නිවැරදි පිළිවෙලට තබයි.
        v.swap(i - 1, i);

        // කුඩා මූලද්රව්යය වමට මාරු කරන්න.
        shift_tail(&mut v[..i], is_less);
        // විශාල මූලද්‍රව්‍යය දකුණට හරවන්න.
        shift_head(&mut v[i..], is_less);
    }

    // සීමිත පියවර ගණනකින් පෙත්ත වර්ග කිරීමට කළමනාකරණය කළේ නැත.
    false
}

/// ඇතුළත් කිරීමේ වර්ග කිරීම භාවිතා කරමින් පෙත්තක් වර්ග කරයි, එය *O*(*n*^ 2) නරකම අවස්ථාවකි.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// *O*(*n*\*log(* n*)) නරකම අවස්ථාව සහතික කරන හෙප්සෝර්ට් භාවිතා කරමින් `v` වර්ග කරන්න.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // මෙම ද්විමය සංචය වෙනස් නොවන `parent >= child` වලට ගරු කරයි.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // `node` හි දරුවන්:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // වඩා විශාල දරුවා තෝරන්න.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // ආක්‍රමණිකයා `node` හි තිබේ නම් නවත්වන්න.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // විශාල දරුවා සමඟ `node` මාරු කරන්න, එක් පියවරක් පහළට ගෙනයන්න.
            v.swap(node, greater);
            node = greater;
        }
    };

    // රේඛීය වේලාවට ගොඩවල් සාදන්න.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // සංචයෙන් උපරිම මූලද්‍රව්‍ය පොප් කරන්න.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// `v` කොටස් `pivot` ට වඩා කුඩා මූලද්‍රව්‍යවලට, ඉන්පසු `pivot` ට වඩා වැඩි හෝ සමාන මූලද්‍රව්‍යයන්.
///
///
/// `pivot` ට වඩා කුඩා මූලද්‍රව්‍ය ගණන ලබා දෙයි.
///
/// අතු බෙදීමේ මෙහෙයුම්වල පිරිවැය අවම කිරීම සඳහා කොටස් කිරීම වාරණයෙන් සිදු කෙරේ.
/// මෙම අදහස [BlockQuicksort][pdf] කඩදාසි වල ඉදිරිපත් කර ඇත.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // සාමාන්‍ය කොටසක ඇති මූලද්‍රව්‍ය ගණන.
    const BLOCK: usize = 128;

    // කොටස් කිරීමේ ඇල්ගොරිතම සම්පූර්ණ වන තෙක් පහත පියවරයන් පුනරාවර්තනය කරයි:
    //
    // 1. හැරීමට වඩා විශාල හෝ සමාන මූලද්‍රව්‍ය හඳුනා ගැනීම සඳහා වම් පැත්තෙන් බ්ලොක් එකක් සොයා ගන්න.
    // 2. හැරීමට වඩා කුඩා මූලද්‍රව්‍ය හඳුනා ගැනීමට දකුණු පැත්තෙන් බ්ලොක් එකක් සොයා ගන්න.
    // 3. හඳුනාගත් මූලද්රව්ය වම් සහ දකුණු පැත්ත අතර හුවමාරු කරන්න.
    //
    // මූලද්රව්ය සමූහයක් සඳහා අපි පහත විචල්යයන් තබා ගනිමු:
    //
    // 1. `block` - බ්ලොක් එකේ මූලද්රව්ය සංඛ්යාව.
    // 2. `start` - `offsets` අරාව තුළට දර්ශකය ආරම්භ කරන්න.
    // 3. `end` - `offsets` අරාව තුළට දර්ශකය අවසන් කරන්න.
    // 4. `ඕෆ්සෙට්ස්, බ්ලොක් තුළ ඇති අක්‍රීය මූලද්‍රව්‍යයන්ගේ දර්ශක.

    // වම් පැත්තේ වත්මන් කොටස (`l` සිට `l.add(block_l)`) දක්වා).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // දකුණු පැත්තේ වත්මන් කොටස (`r.sub(block_r)` to `r`) සිට.
    // ආරක්ෂාව: .add() සඳහා වන ලියකියවිලි වල විශේෂයෙන් සඳහන් වන්නේ `vec.as_ptr().add(vec.len())` සැමවිටම ආරක්ෂිත බවයි
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: අපට VLAs ලැබුණු විට, `min(v.len(), 2 * BLOCK) දිගක් නිර්මාණය කිරීමට උත්සාහ කරන්න
    // `BLOCK` දිග ස්ථාවර ප්‍රමාණයේ අරා දෙකකට වඩා.VLAs වඩා හැඹිලි-කාර්යක්ෂම විය හැකිය.

    // `l` (inclusive) සහ `r` (exclusive) යන දර්ශකයන් අතර ඇති මූලද්‍රව්‍ය ගණන ලබා දෙයි.
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // `l` සහ `r` ඉතා කිට්ටු වන විට කොටස් කිරීම මඟින් කොටස් කිරීම මඟින් අප සිදු කරනු ලැබේ.
        // ඉන්පසු ඉතිරිව ඇති මූලද්‍රව්‍ය අතර කොටස් කිරීම සඳහා අපි පැච්-අප් වැඩ කිහිපයක් කරන්නෙමු.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // ඉතිරි මූලද්රව්ය සංඛ්යාව (තවමත් හැරීම සමඟ සැසඳේ නැත).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // වම් සහ දකුණු කොටස අවහිර නොවන පරිදි බ්ලොක් ප්‍රමාණ සකසන්න, නමුත් ඉතිරි පරතරය ආවරණය වන පරිදි පරිපූර්ණ ලෙස පෙළගස්වන්න.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // වම් පැත්තෙන් `block_l` මූලද්‍රව්‍ය සොයා ගන්න.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // ආරක්ෂාව: පහත අනාරක්ෂිත මෙහෙයුම් වලට `offset` භාවිතය සම්බන්ධ වේ.
                //         ශ්‍රිතයට අවශ්‍ය කොන්දේසි අනුව, අපි ඒවා තෘප්තිමත් කරන්නේ:
                //         1. `offsets_l` යනු වෙන් කරන ලද වස්තුවක් ලෙස සැලකේ.
                //         2. `is_less` ශ්‍රිතය `bool` ලබා දෙයි.
                //            `bool` වාත්තු කිරීම කිසි විටෙකත් `isize` පිටාර ගැලෙන්නේ නැත.
                //         3. `block_l` `<= BLOCK` වනු ඇති බවට අපි සහතික වී සිටිමු.
                //            ප්ලස්, `end_l` මුලින් `offsets_` හි ආරම්භක දර්ශකයට සකසා ඇති අතර එය තොගයේ ප්‍රකාශයට පත් කරන ලදි.
                //            මේ අනුව, නරකම අවස්ථාවකදී පවා (`is_less` හි සියලු ආයාචනා අසත්‍යය) අප අවසානය පසු කරන්නේ බයිට් 1 ක් පමණක් බව අපි දනිමු.
                //        මෙහි ඇති තවත් අනාරක්ෂිත මෙහෙයුමක් වන්නේ `elem` අවලංගු කිරීමයි.
                //        කෙසේ වෙතත්, `elem` මුලින් සෑම විටම වලංගු වන පෙත්ත සඳහා ආරම්භක දර්ශකය විය.
                unsafe {
                    // ශාඛා රහිත සංසන්දනය.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // දකුණු පැත්තේ සිට `block_r` මූලද්‍රව්‍ය සොයා ගන්න.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // ආරක්ෂාව: පහත අනාරක්ෂිත මෙහෙයුම් වලට `offset` භාවිතය සම්බන්ධ වේ.
                //         ශ්‍රිතයට අවශ්‍ය කොන්දේසි අනුව, අපි ඒවා තෘප්තිමත් කරන්නේ:
                //         1. `offsets_r` යනු වෙන් කරන ලද වස්තුවක් ලෙස සැලකේ.
                //         2. `is_less` ශ්‍රිතය `bool` ලබා දෙයි.
                //            `bool` වාත්තු කිරීම කිසි විටෙකත් `isize` පිටාර ගැලෙන්නේ නැත.
                //         3. `block_r` `<= BLOCK` වනු ඇති බවට අපි සහතික වී සිටිමු.
                //            ප්ලස්, `end_r` මුලින් `offsets_` හි ආරම්භක දර්ශකයට සකසා ඇති අතර එය තොගයේ ප්‍රකාශයට පත් කරන ලදි.
                //            මේ අනුව, නරකම අවස්ථාවකදී පවා (`is_less` හි සියලු ආයාචනා සත්‍ය වේ) අපි අවසානය පසු කරන්නේ බයිට් 1 ක් පමණක් බව අපි දනිමු.
                //        මෙහි ඇති තවත් අනාරක්ෂිත මෙහෙයුමක් වන්නේ `elem` අවලංගු කිරීමයි.
                //        කෙසේ වෙතත්, `elem` මුලදී `1 *sizeof(T)` අවසානය පසු කර ඇති අතර අපි එය ප්‍රවේශ වීමට පෙර `1* sizeof(T)` කින් අඩු කරමු.
                //        ප්ලස්, `block_r` `BLOCK` ට වඩා අඩු බව තහවුරු කර ඇති අතර `elem` බොහෝ විට පෙත්තෙහි ආරම්භයට යොමු වේ.
                unsafe {
                    // ශාඛා රහිත සංසන්දනය.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // වම් සහ දකුණු පස අතර හුවමාරු වීමට අවශ්‍ය නොවන මූලද්‍රව්‍ය ගණන.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // එකල එක් යුගලයක් මාරු කරනවා වෙනුවට, චක්‍රීය ප්‍රේරණයක් සිදු කිරීම වඩා කාර්යක්ෂම වේ.
            // මෙය හුවමාරුවට තදින්ම සමාන නොවේ, නමුත් අඩු මතක ක්‍රියාකාරිත්වයන් භාවිතා කරමින් සමාන ප්‍රති result ලයක් ලබා දෙයි.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // වම් කොටසෙහි ඇති සියලුම අක්‍රීය මූලද්‍රව්‍ය ගෙන යන ලදී.ඊළඟ බ්ලොක් එකට යන්න.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // දකුණු කොටසේ ඇති සියලුම අක්‍රීය මූලද්‍රව්‍ය ගෙන යන ලදි.පෙර කොටස වෙත ගෙන යන්න.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // දැන් ඉතිරිව ඇත්තේ චලනය කළ යුතු අක්‍රීය මූලද්‍රව්‍ය සහිත එක් කොටසක (වමේ හෝ දකුණේ) ය.
    // එවැනි ඉතිරිව ඇති මූලද්රව්ය හුදෙක් ඒවායේ කොටස තුළ අවසානය දක්වා මාරු කළ හැකිය.
    //

    if start_l < end_l {
        // වම් කොටස ඉතිරිව ඇත.
        // එහි ඉතිරිව ඇති යල්පැන ගිය අංග දකුණු දකුණට ගෙන යන්න.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // දකුණු කොටස ඉතිරිව ඇත.
        // එහි ඉතිරිව ඇති අක්‍රීය මූලද්‍රව්‍ය වම් පැත්තට ගෙන යන්න.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // වෙන කරන්න දෙයක් නැහැ, අපි ඉවරයි.
        width(v.as_mut_ptr(), l)
    }
}

/// `v` කොටස් `v[pivot]` ට වඩා කුඩා මූලද්‍රව්‍යවලට, ඉන්පසු `v[pivot]` ට වඩා වැඩි හෝ සමාන මූලද්‍රව්‍යයන්.
///
///
/// ටුපල් එකක් ලබා දෙයි:
///
/// 1. `v[pivot]` ට වඩා කුඩා මූලද්‍රව්‍ය ගණන.
/// 2. `v` දැනටමත් කොටස් කර තිබුනේ නම් ඇත්ත.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // පෙත්තක් ආරම්භයේදී හැරීම තබන්න.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Pivot එක කාර්යක්ෂමතාව සඳහා වෙන් කළ විචල්‍යයකට කියවන්න.
        // පහත දැක්වෙන සංසන්දනාත්මක මෙහෙයුමක් නම් panics, හැරීම ස්වයංක්‍රීයව නැවත පෙත්තට ලියා ඇත.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // අක්‍රීය මූලද්‍රව්‍යයන්ගේ පළමු යුගලය සොයා ගන්න.
        let mut l = 0;
        let mut r = v.len();

        // ආරක්ෂාව: පහත දැක්වෙන අනාරක්‍ෂිතතාවයට අරාව සුචිගත කිරීම ඇතුළත් වේ.
        // පළමු එක සඳහා: අපි දැනටමත් මෙහි සීමාවන් `l < r` සමඟ පරීක්ෂා කර බලමු.
        // දෙවැන්න සඳහා: අප සතුව මුලින් `l == 0` සහ `r == v.len()` ඇති අතර සෑම සුචිගත කිරීමේ ක්‍රියාවලියකදීම අපි `l < r` පරීක්‍ෂා කළෙමු.
        //                     මෙතැන් සිට අපි දන්නවා `r` අවම වශයෙන් `r == l` විය යුතු අතර එය පළමු එකෙන් වලංගු බව පෙන්වන ලදී.
        unsafe {
            // හැරීමට වඩා වැඩි හෝ සමාන පළමු මූලද්‍රව්‍යය සොයා ගන්න.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // හැරීමේ කුඩා අංගය කුඩා කරන්න.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` විෂය පථයෙන් බැහැරව හැරීම (එය තොගයෙන් වෙන් කරන ලද විචල්‍යයකි) එය මුලින් තිබූ පෙත්තට නැවත ලියයි.
        // ආරක්ෂාව සහතික කිරීමේදී මෙම පියවර ඉතා වැදගත් වේ!
        //
    };

    // කොටස් දෙක අතර හැරීම යොමු කරන්න.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// `v` කොටස් `v[pivot]` ට සමාන මූලද්‍රව්‍යවලට පසුව `v[pivot]` ට වඩා වැඩි මූලද්‍රව්‍යයන්.
///
/// හැරීමට සමාන මූලද්‍රව්‍ය ගණන ලබා දෙයි.
/// `v` හි හැරීමට වඩා කුඩා මූලද්‍රව්‍ය අඩංගු නොවන බව උපකල්පනය කෙරේ.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // පෙත්තක් ආරම්භයේදී හැරීම තබන්න.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Pivot එක කාර්යක්ෂමතාව සඳහා වෙන් කළ විචල්‍යයකට කියවන්න.
    // පහත දැක්වෙන සංසන්දනාත්මක මෙහෙයුමක් නම් panics, හැරීම ස්වයංක්‍රීයව නැවත පෙත්තට ලියා ඇත.
    // ආරක්ෂාව: මෙහි දර්ශකය වලංගු වන්නේ එය පෙත්තකට යොමු කිරීමකින් ලබා ගත් බැවිනි.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // දැන් පෙත්ත කොටස් කරන්න.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // ආරක්ෂාව: පහත දැක්වෙන අනාරක්‍ෂිතතාවයට අරාව සුචිගත කිරීම ඇතුළත් වේ.
        // පළමු එක සඳහා: අපි දැනටමත් මෙහි සීමාවන් `l < r` සමඟ පරීක්ෂා කර බලමු.
        // දෙවැන්න සඳහා: අප සතුව මුලින් `l == 0` සහ `r == v.len()` ඇති අතර සෑම සුචිගත කිරීමේ ක්‍රියාවලියකදීම අපි `l < r` පරීක්‍ෂා කළෙමු.
        //                     මෙතැන් සිට අපි දන්නවා `r` අවම වශයෙන් `r == l` විය යුතු අතර එය පළමු එකෙන් වලංගු බව පෙන්වන ලදී.
        unsafe {
            // හැරීමට වඩා විශාල පළමු අංගය සොයා ගන්න.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // හැරීමට සමාන අවසාන අංගය සොයා ගන්න.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // අපි ඉවරද?
            if l >= r {
                break;
            }

            // සොයා නොගත් මූලද්‍රව්‍ය යුගල මාරු කරන්න.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // හැරීමට සමාන `l` මූලද්‍රව්‍ය අපට හමු විය.හැරීම සඳහා ගිණුමට 1 ක් එක් කරන්න.
    l + 1

    // `_pivot_guard` විෂය පථයෙන් බැහැරව හැරීම (එය තොගයෙන් වෙන් කරන ලද විචල්‍යයකි) එය මුලින් තිබූ පෙත්තට නැවත ලියයි.
    // ආරක්ෂාව සහතික කිරීමේදී මෙම පියවර ඉතා වැදගත් වේ!
}

/// ක්වික්සෝර්ට් හි අසමතුලිත කොටස් ඇතිවීමට හේතු විය හැකි රටා බිඳ දැමීමේ උත්සාහයක දී සමහර අංග වටා විසිරී යයි.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // ජෝර්ජ් මාසැග්ලියා විසින් "Xorshift RNGs" කඩදාසි වලින් ව්‍යාජ සංඛ්‍යා උත්පාදක යන්ත්රය.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // අහඹු සංඛ්‍යා මොඩියුලය ගන්න.
        // `len` `isize::MAX` ට වඩා වැඩි නොවන නිසා අංකය `usize` ට ගැලපේ.
        let modulus = len.next_power_of_two();

        // සමහර හැරවුම් අපේක්ෂකයින් මෙම දර්ශකයට ආසන්නයේ සිටී.අපි ඒවා අහඹු ලෙස කරමු.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // අහඹු අංක මොඩියුලෝ `len` ජනනය කරන්න.
            // කෙසේ වෙතත්, මිල අධික මෙහෙයුම් වලක්වා ගැනීම සඳහා අපි පළමුව එය මොඩියුලෝ දෙකක බලයක් ගෙන, පසුව එය `[0, len - 1]` පරාසයට ගැලපෙන තෙක් `len` කින් අඩු කරන්නෙමු.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` `2 * len` ට වඩා අඩු බව සහතික කර ඇත.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// පෙත්තක් දැනටමත් වර්ග කර ඇත්නම් `v` හි හැරීමක් තෝරාගෙන දර්ශකය සහ `true` ලබා දෙයි.
///
/// `v` හි මූලද්‍රව්‍ය ක්‍රියාවලියේදී නැවත සකස් කළ හැකිය.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // මධ්යන්ය-මධ්යන්ය ක්රමය තෝරා ගැනීමට අවම දිග.
    // කෙටි පෙති සරල මධ්‍ය-තුනේ ක්‍රමය භාවිතා කරයි.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // මෙම ශ්‍රිතයේ සිදු කළ හැකි උපරිම හුවමාරු සංඛ්‍යාවක්.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // අපි හැරීමක් තෝරා ගැනීමට යන දර්ශක තුනක් අසල.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // දර්ශක වර්ග කිරීමේදී අපි සිදු කිරීමට යන මුළු හුවමාරු ගණන ගණනය කරයි.
    let mut swaps = 0;

    if len >= 8 {
        // `v[a] <= v[b]` සඳහා දර්ශක මාරු කරයි.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // `v[a] <= v[b] <= v[c]` සඳහා දර්ශක මාරු කරයි.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // `v[a - 1], v[a], v[a + 1]` හි මධ්‍යන්‍යය සොයාගෙන දර්ශකය `a` වෙත ගබඩා කරයි.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // `a`, `b`, සහ `c` අසල්වැසි ප්‍රදේශවල මධ්‍යධරයන් සොයා ගන්න.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // `a`, `b`, සහ `c` අතර මධ්‍යය සොයා ගන්න.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // උපරිම හුවමාරුව සිදු කරන ලදී.
        // පෙත්ත බැසයාම හෝ බොහෝ දුරට බැසයාම විය හැකි බැවින් ආපසු හැරවීම එය වේගයෙන් වර්ග කිරීමට උපකාරී වේ.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// `v` වර්ග නැවත නැවත වර්ග කරයි.
///
/// පෙත්තෙහි මුල් අරාවෙහි පූර්වගාමියා සිටියේ නම්, එය `pred` ලෙස දක්වා ඇත.
///
/// `limit` යනු `heapsort` වෙත මාරුවීමට පෙර අවසර ලත් අසමතුලිත කොටස් ගණන වේ.
/// බිංදුව නම්, මෙම ශ්‍රිතය වහාම heapsort වෙත මාරු වේ.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // මෙම දිග දක්වා පෙති ඇතුළු කිරීමේ වර්ග කිරීම මඟින් වර්ග කරනු ලැබේ.
    const MAX_INSERTION: usize = 20;

    // අවසාන කොටස සාධාරණ ලෙස සමතුලිත වූයේ නම් ඇත්ත.
    let mut was_balanced = true;
    // අන්තිම කොටස් කිරීම මූලද්‍රව්‍ය මාරු නොකළේ නම් ඇත්ත (පෙත්ත දැනටමත් කොටස් කර ඇත).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // ඇතුළු කිරීමේ වර්ග කිරීම භාවිතයෙන් ඉතා කෙටි පෙති වර්ග කරනු ලැබේ.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // බොහෝ නරක හැරීම් තේරීම් සිදු කර ඇත්නම්, `O(n * log(n))` නරකම අවස්ථාව සහතික කිරීම සඳහා නැවත ගොඩවල් වෙත වැටෙන්න.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // අවසාන කොටස් කිරීම අසමතුලිත නම්, අවට ඇති සමහර මූලද්‍රව්‍ය මාරු කිරීමෙන් පෙත්තෙහි රටා බිඳීමට උත්සාහ කරන්න.
        // අපි බලාපොරොත්තු වෙනවා අපි මෙවර වඩා හොඳ හැරීමක් තෝරා ගනිමු.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // හැරීම තෝරන්න සහ පෙත්ත දැනටමත් වර්ග කර තිබේදැයි අනුමාන කිරීමට උත්සාහ කරන්න.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // අවසාන කොටස් කිරීම නිසි ලෙස සමතුලිත වූ අතර මූලද්‍රව්‍ය මාරු නොකළේ නම් සහ හැරීම් තේරීම පුරෝකථනය කරන්නේ නම් පෙත්ත දැනටමත් වර්ග කර ඇත ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // යල්පැනගිය අංග කිහිපයක් හඳුනාගෙන ඒවා නිවැරදි ස්ථාන වෙත මාරු කිරීමට උත්සාහ කරන්න.
            // පෙත්ත සම්පූර්ණයෙන් වර්ග කිරීම අවසන් වුවහොත්, අපි ඉවරයි.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // තෝරාගත් හැරීම පූර්වගාමියාට සමාන නම්, එය පෙත්තෙහි ඇති කුඩාම අංගය වේ.
        // පෙත්තට සමාන මූලද්‍රව්‍යවලට සහ හැරීමට වඩා විශාල මූලද්‍රව්‍යවලට බෙදන්න.
        // පෙත්තෙහි බොහෝ අනුපිටපත් අඩංගු වන විට මෙම නඩුව සාමාන්‍යයෙන් පහර දෙනු ලැබේ.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // හැරීමට වඩා විශාල මූලද්‍රව්‍ය වර්ග කිරීම දිගටම කරගෙන යන්න.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // පෙත්ත කොටස් කරන්න.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // පෙත්ත `left`, `pivot` සහ `right` වලට බෙදන්න.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // කෙටි පුනරාවර්තන ඇමතුම් ගණන අවම කිරීම සහ අඩු ඉඩ ප්‍රමාණයක් පරිභෝජනය කිරීම සඳහා පමණක් කෙටි පැත්තට යොමු වන්න.
        // ඉන්පසු දිගු පැත්තෙන් ඉදිරියට යන්න (මෙය වලිග පුනරාවර්තනයට සමානය).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// *O*(*n*\*log(* n*)) නරකම අවස්ථාව වන රටා පරාජය කරන ක්වික්සෝර්ට් භාවිතා කරමින් `v` වර්ග කරන්න.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // වර්ග කිරීම ශුන්‍ය ප්‍රමාණයේ අර්ථවත් හැසිරීමක් නොමැත.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // අසමතුලිත කොටස් ගණන `floor(log2(len)) + 1` දක්වා සීමා කරන්න.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // මෙම දිග දක්වා පෙති සඳහා ඒවා සරලව වර්ග කිරීම වේගවත් වේ.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // හැරීමක් තෝරන්න
        let (pivot, _) = choose_pivot(v, is_less);

        // තෝරාගත් හැරීම පූර්වගාමියාට සමාන නම්, එය පෙත්තෙහි ඇති කුඩාම අංගය වේ.
        // පෙත්තට සමාන මූලද්‍රව්‍යවලට සහ හැරීමට වඩා විශාල මූලද්‍රව්‍යවලට බෙදන්න.
        // පෙත්තෙහි බොහෝ අනුපිටපත් අඩංගු වන විට මෙම නඩුව සාමාන්‍යයෙන් පහර දෙනු ලැබේ.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // අපි අපේ දර්ශකය සමත් වී ඇත්නම්, අපි හොඳයි.
                if mid > index {
                    return;
                }

                // එසේ නොමැතිනම්, හැරීමට වඩා විශාල මූලද්‍රව්‍ය වර්ග කිරීම දිගටම කරගෙන යන්න.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // පෙත්ත `left`, `pivot` සහ `right` වලට බෙදන්න.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // මැද==දර්ශකය නම්, අපි අවසන් කර ඇත්තේ partition() විසින් මැදට පසුව ඇති සියලුම මූලද්‍රව්‍යයන් මැදට වඩා වැඩි හෝ සමාන බව සහතික කර ඇති බැවිනි.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // වර්ග කිරීම ශුන්‍ය ප්‍රමාණයේ අර්ථවත් හැසිරීමක් නොමැත.කිසිවක් නොකරන්න.
    } else if index == v.len() - 1 {
        // උපරිම මූලද්‍රව්‍යය සොයාගෙන අරාවේ අවසාන ස්ථානයේ තබන්න.
        // V මෙහි හිස් නොවිය යුතු බව අප දන්නා බැවින් අපට මෙහි `unwrap()` භාවිතා කිරීමට නිදහස තිබේ.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // මිනි මූලද්‍රව්‍යය සොයාගෙන අරාවෙහි පළමු ස්ථානයේ තබන්න.
        // V මෙහි හිස් නොවිය යුතු බව අප දන්නා බැවින් අපට මෙහි `unwrap()` භාවිතා කිරීමට නිදහස තිබේ.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}