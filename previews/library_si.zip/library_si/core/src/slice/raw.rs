//! `&[T]` සහ `&mut [T]` නිර්මාණය කිරීම සඳහා නිදහස් කාර්යයන්.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// දර්ශකයකින් සහ දිගකින් පෙත්තක් සාදයි.
///
/// `len` තර්කය යනු **මූලද්‍රව්‍ය ගණන** මිස බයිට් ගණන නොවේ.
///
/// # Safety
///
/// පහත සඳහන් කොන්දේසි කිසිවක් උල්ලං are නය වී ඇත්නම් හැසිරීම නිර්වචනය නොකෙරේ:
///
/// * `data` `len * mem::size_of::<T>()` බොහෝ බයිට් සඳහා කියවීම සඳහා [valid] විය යුතු අතර එය නිසි ලෙස පෙළගස්වා තිබිය යුතුය.මෙයින් විශේෂයෙන් අදහස් කරන්නේ:
///
///     * මෙම පෙත්තෙහි සම්පූර්ණ මතක පරාසය එක් වෙන් කළ වස්තුවක් තුළ අඩංගු විය යුතුය!
///       පෙති කිසි විටෙකත් වෙන් කරන ලද බහු වස්තු හරහා විහිදිය නොහැක.මෙය වැරදියට සැලකිල්ලට නොගන්නා උදාහරණයක් සඳහා [below](#incorrect-usage) බලන්න.
///     * `data` ශුන්‍ය දිග පෙති සඳහා පවා ශුන්‍ය නොවන හා පෙලගැසී තිබිය යුතුය.
///     මෙයට එක් හේතුවක් නම්, එනුම් පිරිසැලසුම් ප්‍රශස්තිකරණය වෙනත් දත්ත වලින් වෙන්කර හඳුනා ගැනීම සඳහා යොමු කිරීම් (ඕනෑම දිගක පෙති ද ඇතුළුව) පෙළගැස්වීම සහ ශුන්‍ය නොවන ඒවා මත රඳා පැවතීමයි.
///     [`NonNull::dangling()`] භාවිතා කරමින් ශුන්‍ය දිග පෙති සඳහා `data` ලෙස භාවිතා කළ හැකි දර්ශකයක් ඔබට ලබා ගත හැකිය.
///
/// * `data` `T` වර්ගයේ නිසි ලෙස ආරම්භක අගයන් `len` වෙත යොමු කළ යුතුය.
///
/// * ආපසු ලබා දුන් පෙත්තක් මඟින් සඳහන් කරන ලද මතකය `UnsafeCell` ඇතුළත හැර, `'a` ජීවිත කාලය සඳහා විකෘති නොකළ යුතුය.
///
/// * පෙත්තෙහි මුළු ප්‍රමාණය `len * mem::size_of::<T>()` `isize::MAX` ට වඩා විශාල නොවිය යුතුය.
///   [`pointer::offset`] හි ආරක්‍ෂිත ලියකියවිලි බලන්න.
///
/// # Caveat
///
/// ආපසු ලබා දුන් පෙත්ත සඳහා ආයු කාලය එහි භාවිතයෙන් අනුමාන කෙරේ.
/// අහම්බෙන් අනිසි ලෙස භාවිතා කිරීම වැළැක්වීම සඳහා, සන්දර්භය තුළ ජීවිත කාලය සුරක්‍ෂිත වන ඕනෑම මූලාශ්‍රයක් සමඟ සම්බන්ධ කිරීමට යෝජනා කෙරේ, එනම්, පෙත්තක් සඳහා ධාරක වටිනාකමේ ආයු කාලය ගත කරන සහායක ශ්‍රිතයක් සැපයීම හෝ පැහැදිලි විවරණය කිරීමෙනි.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // තනි මූලද්රව්යයක් සඳහා පෙත්තක් ප්රකාශ කරන්න
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### වැරදි භාවිතය
///
/// පහත දැක්වෙන `join_slices` ශ්‍රිතය **අසංවර** is වේ
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // ඉහත ප්‍රකාශය `fst` සහ `snd` එකිනෙකට පරස්පර බව සහතික කරයි, නමුත් ඒවා තවමත් _different allocated objects_ තුළ අඩංගු විය හැකිය, එම අවස්ථාවේ දී මෙම පෙත්තක් නිර්මාණය කිරීම නිර්වචනය නොකළ හැසිරීමකි.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` සහ `b` වෙනස් වෙන් කරන ලද වස්තු වේ ...
///     let a = 42;
///     let b = 27;
///     // ... කෙසේ වෙතත් ඒවා මතකයේ පරස්පර ලෙස තැබිය හැකිය: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // ආරක්ෂාව: අමතන්නා `from_raw_parts` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// විකෘති පෙත්තක් ආපසු ලබා දීම හැර, [`from_raw_parts`] හා සමාන ක්‍රියාකාරීත්වයක් සිදු කරයි.
///
/// # Safety
///
/// පහත සඳහන් කොන්දේසි කිසිවක් උල්ලං are නය වී ඇත්නම් හැසිරීම නිර්වචනය නොකෙරේ:
///
/// * `data` බොහෝ බයිට් සඳහා `len * mem::size_of::<T>()` කියවීම සහ ලිවීම යන දෙකම සඳහා [valid] විය යුතු අතර එය නිසි ලෙස පෙළගස්වා තිබිය යුතුය.මෙයින් විශේෂයෙන් අදහස් කරන්නේ:
///
///     * මෙම පෙත්තෙහි සම්පූර්ණ මතක පරාසය එක් වෙන් කළ වස්තුවක් තුළ අඩංගු විය යුතුය!
///       පෙති කිසි විටෙකත් වෙන් කරන ලද බහු වස්තු හරහා විහිදිය නොහැක.
///     * `data` ශුන්‍ය දිග පෙති සඳහා පවා ශුන්‍ය නොවන හා පෙලගැසී තිබිය යුතුය.
///     මෙයට එක් හේතුවක් නම්, එනුම් පිරිසැලසුම් ප්‍රශස්තිකරණය වෙනත් දත්ත වලින් වෙන්කර හඳුනා ගැනීම සඳහා යොමු කිරීම් (ඕනෑම දිගක පෙති ද ඇතුළුව) පෙළගැස්වීම සහ ශුන්‍ය නොවන ඒවා මත රඳා පැවතීමයි.
///
///     [`NonNull::dangling()`] භාවිතා කරමින් ශුන්‍ය දිග පෙති සඳහා `data` ලෙස භාවිතා කළ හැකි දර්ශකයක් ඔබට ලබා ගත හැකිය.
///
/// * `data` `T` වර්ගයේ නිසි ලෙස ආරම්භක අගයන් `len` වෙත යොමු කළ යුතුය.
///
/// * ආපසු ලබා දුන් පෙත්තක් මඟින් සඳහන් කර ඇති මතකය `'a` ජීවිත කාලය සඳහා වෙනත් කිසිදු දර්ශකයක් හරහා (ප්‍රතිලාභ අගයෙන් උපුටා නොගත්) ප්‍රවේශ නොවිය යුතුය.
///   කියවීම සහ ලිවීම යන දෙකම තහනම්ය.
///
/// * පෙත්තෙහි මුළු ප්‍රමාණය `len * mem::size_of::<T>()` `isize::MAX` ට වඩා විශාල නොවිය යුතුය.
///   [`pointer::offset`] හි ආරක්‍ෂිත ලියකියවිලි බලන්න.
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // ආරක්ෂාව: අමතන්නා `from_raw_parts_mut` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// ටී වෙත යොමු කිරීම දිග 1 පෙත්තක් බවට පරිවර්තනය කරයි (පිටපත් නොකර).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// ටී වෙත යොමු කිරීම දිග 1 පෙත්තක් බවට පරිවර්තනය කරයි (පිටපත් නොකර).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}