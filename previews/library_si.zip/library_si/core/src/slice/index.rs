//! `[T]` සඳහා ක්‍රියාත්මක කිරීම සුචිගත කිරීම.

use crate::ops;
use crate::ptr;

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, I> ops::Index<I> for [T]
where
    I: SliceIndex<[T]>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, I> ops::IndexMut<I> for [T]
where
    I: SliceIndex<[T]>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn slice_start_index_len_fail(index: usize, len: usize) -> ! {
    panic!("range start index {} out of range for slice of length {}", index, len);
}

#[inline(never)]
#[cold]
#[track_caller]
fn slice_end_index_len_fail(index: usize, len: usize) -> ! {
    panic!("range end index {} out of range for slice of length {}", index, len);
}

#[inline(never)]
#[cold]
#[track_caller]
fn slice_index_order_fail(index: usize, end: usize) -> ! {
    panic!("slice index starts at {} but ends at {}", index, end);
}

#[inline(never)]
#[cold]
#[track_caller]
fn slice_start_index_overflow_fail() -> ! {
    panic!("attempted to index slice from after maximum usize");
}

#[inline(never)]
#[cold]
#[track_caller]
fn slice_end_index_overflow_fail() -> ! {
    panic!("attempted to index slice up to maximum usize");
}

mod private_slice_index {
    use super::ops;
    #[stable(feature = "slice_get_slice", since = "1.28.0")]
    pub trait Sealed {}

    #[stable(feature = "slice_get_slice", since = "1.28.0")]
    impl Sealed for usize {}
    #[stable(feature = "slice_get_slice", since = "1.28.0")]
    impl Sealed for ops::Range<usize> {}
    #[stable(feature = "slice_get_slice", since = "1.28.0")]
    impl Sealed for ops::RangeTo<usize> {}
    #[stable(feature = "slice_get_slice", since = "1.28.0")]
    impl Sealed for ops::RangeFrom<usize> {}
    #[stable(feature = "slice_get_slice", since = "1.28.0")]
    impl Sealed for ops::RangeFull {}
    #[stable(feature = "slice_get_slice", since = "1.28.0")]
    impl Sealed for ops::RangeInclusive<usize> {}
    #[stable(feature = "slice_get_slice", since = "1.28.0")]
    impl Sealed for ops::RangeToInclusive<usize> {}
}

/// සුචිගත කිරීමේ මෙහෙයුම් සඳහා trait සහායකයෙක් භාවිතා කරයි.
///
/// මෙම trait ක්‍රියාත්මක කිරීම සඳහා promise කළ යුතු අතර `get_(mut_)unchecked` සඳහා වන තර්කය ආරක්ෂිත යොමු කිරීමක් නම් ප්‍රති the ලය ද එසේමය.
///
#[stable(feature = "slice_get_slice", since = "1.28.0")]
#[rustc_on_unimplemented(
    on(T = "str", label = "string indices are ranges of `usize`",),
    on(
        all(any(T = "str", T = "&str", T = "std::string::String"), _Self = "{integer}"),
        note = "you can use `.chars().nth()` or `.bytes().nth()`\n\
                for more information, see chapter 8 in The Book: \
                <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{T}` cannot be indexed by `{Self}`",
    label = "slice indices are of type `usize` or ranges of `usize`"
)]
pub unsafe trait SliceIndex<T: ?Sized>: private_slice_index::Sealed {
    /// නිමැවුම් වර්ගය ක්‍රම මගින් ආපසු ලබා දෙන ලදි.
    #[stable(feature = "slice_get_slice", since = "1.28.0")]
    type Output: ?Sized;

    /// සීමාවන් තිබේ නම්, මෙම ස්ථානයේ ප්‍රතිදානය සඳහා හවුල් යොමු කිරීමක් ලබා දෙයි.
    ///
    #[unstable(feature = "slice_index_methods", issue = "none")]
    fn get(self, slice: &T) -> Option<&Self::Output>;

    /// සීමාවන්හි නම්, මෙම ස්ථානයේ ප්‍රතිදානය පිළිබඳ විකෘති යොමු කිරීමක් ලබා දෙයි.
    ///
    #[unstable(feature = "slice_index_methods", issue = "none")]
    fn get_mut(self, slice: &mut T) -> Option<&mut Self::Output>;

    /// සීමාවන් පරික්ෂා කිරීමකින් තොරව මෙම ස්ථානයේ ප්‍රතිදානය පිළිබඳ හවුල් සඳහනක් ලබා දෙයි.
    /// සීමාවෙන් පිටත දර්ශකයක් හෝ අන්තරාදායක `slice` දර්ශකයක් සමඟ මෙම ක්‍රමය ඇමතීම *[නිර්වචනය නොකළ හැසිරීම]* ප්‍රති ing ලයක් ලෙස යොමු කිරීම භාවිතා නොකලද.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    #[unstable(feature = "slice_index_methods", issue = "none")]
    unsafe fn get_unchecked(self, slice: *const T) -> *const Self::Output;

    /// කිසිදු සීමාවකින් තොරව මෙම ස්ථානයේ ප්‍රතිදානය පිළිබඳ විකෘති යොමු කිරීමක් ලබා දෙයි.
    /// සීමාවෙන් පිටත දර්ශකයක් හෝ අන්තරාදායක `slice` දර්ශකයක් සමඟ මෙම ක්‍රමය ඇමතීම *[නිර්වචනය නොකළ හැසිරීම]* ප්‍රති ing ලයක් ලෙස යොමු කිරීම භාවිතා නොකලද.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    #[unstable(feature = "slice_index_methods", issue = "none")]
    unsafe fn get_unchecked_mut(self, slice: *mut T) -> *mut Self::Output;

    /// මෙම ස්ථානයේ ප්‍රතිදානය පිළිබඳ හවුල් සඳහනක් ලබා දෙයි, සීමාවෙන් පිටත නම් කලබල වේ.
    ///
    #[unstable(feature = "slice_index_methods", issue = "none")]
    #[track_caller]
    fn index(self, slice: &T) -> &Self::Output;

    /// මෙම ස්ථානයේ ප්‍රතිදානය පිළිබඳ විකෘති යොමු කිරීමක් ලබා දෙයි, සීමාවන් ඉක්මවා ගියහොත් කලබල වේ.
    ///
    #[unstable(feature = "slice_index_methods", issue = "none")]
    #[track_caller]
    fn index_mut(self, slice: &mut T) -> &mut Self::Output;
}

#[stable(feature = "slice_get_slice_impls", since = "1.15.0")]
unsafe impl<T> SliceIndex<[T]> for usize {
    type Output = T;

    #[inline]
    fn get(self, slice: &[T]) -> Option<&T> {
        // ආරක්ෂාව: `self` සීමාව ඉක්මවා ඇත්දැයි පරීක්ෂා කරනු ලැබේ.
        if self < slice.len() { unsafe { Some(&*self.get_unchecked(slice)) } } else { None }
    }

    #[inline]
    fn get_mut(self, slice: &mut [T]) -> Option<&mut T> {
        // ආරක්ෂාව: `self` සීමාව ඉක්මවා ඇත්දැයි පරීක්ෂා කරනු ලැබේ.
        if self < slice.len() { unsafe { Some(&mut *self.get_unchecked_mut(slice)) } } else { None }
    }

    #[inline]
    unsafe fn get_unchecked(self, slice: *const [T]) -> *const T {
        // ආරක්ෂාව: අමතන්නා `slice` අනතුරක් නොවන බවට සහතික කරයි, එබැවින් එය
        // `isize::MAX` ට වඩා දිගු විය නොහැක.
        // `self` `slice` හි මායිම්වල පවතින බවට ඔවුන් සහතික වන බැවින් `self` හට `isize` පිටාර ගැලිය නොහැක, එබැවින් `add` වෙත ඇමතුම ආරක්ෂිත වේ.
        //
        unsafe { slice.as_ptr().add(self) }
    }

    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut [T]) -> *mut T {
        // ආරක්ෂාව: ඉහත `get_unchecked` සඳහා අදහස් බලන්න.
        unsafe { slice.as_mut_ptr().add(self) }
    }

    #[inline]
    fn index(self, slice: &[T]) -> &T {
        // සැ.යු, සහජ සුචිගත කිරීම භාවිතා කරන්න
        &(*slice)[self]
    }

    #[inline]
    fn index_mut(self, slice: &mut [T]) -> &mut T {
        // සැ.යු, සහජ සුචිගත කිරීම භාවිතා කරන්න
        &mut (*slice)[self]
    }
}

#[stable(feature = "slice_get_slice_impls", since = "1.15.0")]
unsafe impl<T> SliceIndex<[T]> for ops::Range<usize> {
    type Output = [T];

    #[inline]
    fn get(self, slice: &[T]) -> Option<&[T]> {
        if self.start > self.end || self.end > slice.len() {
            None
        } else {
            // ආරක්ෂාව: `self` වලංගු දැයි පරීක්ෂා කර ඇති අතර ඉහත සීමාවන් ඇත.
            unsafe { Some(&*self.get_unchecked(slice)) }
        }
    }

    #[inline]
    fn get_mut(self, slice: &mut [T]) -> Option<&mut [T]> {
        if self.start > self.end || self.end > slice.len() {
            None
        } else {
            // ආරක්ෂාව: `self` වලංගු දැයි පරීක්ෂා කර ඇති අතර ඉහත සීමාවන් ඇත.
            unsafe { Some(&mut *self.get_unchecked_mut(slice)) }
        }
    }

    #[inline]
    unsafe fn get_unchecked(self, slice: *const [T]) -> *const [T] {
        // ආරක්ෂාව: අමතන්නා `slice` අනතුරක් නොවන බවට සහතික කරයි, එබැවින් එය
        // `isize::MAX` ට වඩා දිගු විය නොහැක.
        // `self` `slice` හි මායිම්වල පවතින බවට ඔවුන් සහතික වන බැවින් `self` හට `isize` පිටාර ගැලිය නොහැක, එබැවින් `add` වෙත ඇමතුම ආරක්ෂිත වේ.
        //
        unsafe { ptr::slice_from_raw_parts(slice.as_ptr().add(self.start), self.end - self.start) }
    }

    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut [T]) -> *mut [T] {
        // ආරක්ෂාව: ඉහත `get_unchecked` සඳහා අදහස් බලන්න.
        unsafe {
            ptr::slice_from_raw_parts_mut(slice.as_mut_ptr().add(self.start), self.end - self.start)
        }
    }

    #[inline]
    fn index(self, slice: &[T]) -> &[T] {
        if self.start > self.end {
            slice_index_order_fail(self.start, self.end);
        } else if self.end > slice.len() {
            slice_end_index_len_fail(self.end, slice.len());
        }
        // ආරක්ෂාව: `self` වලංගු දැයි පරීක්ෂා කර ඇති අතර ඉහත සීමාවන් ඇත.
        unsafe { &*self.get_unchecked(slice) }
    }

    #[inline]
    fn index_mut(self, slice: &mut [T]) -> &mut [T] {
        if self.start > self.end {
            slice_index_order_fail(self.start, self.end);
        } else if self.end > slice.len() {
            slice_end_index_len_fail(self.end, slice.len());
        }
        // ආරක්ෂාව: `self` වලංගු දැයි පරීක්ෂා කර ඇති අතර ඉහත සීමාවන් ඇත.
        unsafe { &mut *self.get_unchecked_mut(slice) }
    }
}

#[stable(feature = "slice_get_slice_impls", since = "1.15.0")]
unsafe impl<T> SliceIndex<[T]> for ops::RangeTo<usize> {
    type Output = [T];

    #[inline]
    fn get(self, slice: &[T]) -> Option<&[T]> {
        (0..self.end).get(slice)
    }

    #[inline]
    fn get_mut(self, slice: &mut [T]) -> Option<&mut [T]> {
        (0..self.end).get_mut(slice)
    }

    #[inline]
    unsafe fn get_unchecked(self, slice: *const [T]) -> *const [T] {
        // ආරක්ෂාව: අමතන්නාට `get_unchecked` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය.
        unsafe { (0..self.end).get_unchecked(slice) }
    }

    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut [T]) -> *mut [T] {
        // ආරක්ෂාව: අමතන්නාට `get_unchecked_mut` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය.
        unsafe { (0..self.end).get_unchecked_mut(slice) }
    }

    #[inline]
    fn index(self, slice: &[T]) -> &[T] {
        (0..self.end).index(slice)
    }

    #[inline]
    fn index_mut(self, slice: &mut [T]) -> &mut [T] {
        (0..self.end).index_mut(slice)
    }
}

#[stable(feature = "slice_get_slice_impls", since = "1.15.0")]
unsafe impl<T> SliceIndex<[T]> for ops::RangeFrom<usize> {
    type Output = [T];

    #[inline]
    fn get(self, slice: &[T]) -> Option<&[T]> {
        (self.start..slice.len()).get(slice)
    }

    #[inline]
    fn get_mut(self, slice: &mut [T]) -> Option<&mut [T]> {
        (self.start..slice.len()).get_mut(slice)
    }

    #[inline]
    unsafe fn get_unchecked(self, slice: *const [T]) -> *const [T] {
        // ආරක්ෂාව: අමතන්නාට `get_unchecked` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය.
        unsafe { (self.start..slice.len()).get_unchecked(slice) }
    }

    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut [T]) -> *mut [T] {
        // ආරක්ෂාව: අමතන්නාට `get_unchecked_mut` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය.
        unsafe { (self.start..slice.len()).get_unchecked_mut(slice) }
    }

    #[inline]
    fn index(self, slice: &[T]) -> &[T] {
        if self.start > slice.len() {
            slice_start_index_len_fail(self.start, slice.len());
        }
        // ආරක්ෂාව: `self` වලංගු දැයි පරීක්ෂා කර ඇති අතර ඉහත සීමාවන් ඇත.
        unsafe { &*self.get_unchecked(slice) }
    }

    #[inline]
    fn index_mut(self, slice: &mut [T]) -> &mut [T] {
        if self.start > slice.len() {
            slice_start_index_len_fail(self.start, slice.len());
        }
        // ආරක්ෂාව: `self` වලංගු දැයි පරීක්ෂා කර ඇති අතර ඉහත සීමාවන් ඇත.
        unsafe { &mut *self.get_unchecked_mut(slice) }
    }
}

#[stable(feature = "slice_get_slice_impls", since = "1.15.0")]
unsafe impl<T> SliceIndex<[T]> for ops::RangeFull {
    type Output = [T];

    #[inline]
    fn get(self, slice: &[T]) -> Option<&[T]> {
        Some(slice)
    }

    #[inline]
    fn get_mut(self, slice: &mut [T]) -> Option<&mut [T]> {
        Some(slice)
    }

    #[inline]
    unsafe fn get_unchecked(self, slice: *const [T]) -> *const [T] {
        slice
    }

    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut [T]) -> *mut [T] {
        slice
    }

    #[inline]
    fn index(self, slice: &[T]) -> &[T] {
        slice
    }

    #[inline]
    fn index_mut(self, slice: &mut [T]) -> &mut [T] {
        slice
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl<T> SliceIndex<[T]> for ops::RangeInclusive<usize> {
    type Output = [T];

    #[inline]
    fn get(self, slice: &[T]) -> Option<&[T]> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }

    #[inline]
    fn get_mut(self, slice: &mut [T]) -> Option<&mut [T]> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }

    #[inline]
    unsafe fn get_unchecked(self, slice: *const [T]) -> *const [T] {
        // ආරක්ෂාව: අමතන්නාට `get_unchecked` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }

    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut [T]) -> *mut [T] {
        // ආරක්ෂාව: අමතන්නාට `get_unchecked_mut` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }

    #[inline]
    fn index(self, slice: &[T]) -> &[T] {
        if *self.end() == usize::MAX {
            slice_end_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }

    #[inline]
    fn index_mut(self, slice: &mut [T]) -> &mut [T] {
        if *self.end() == usize::MAX {
            slice_end_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl<T> SliceIndex<[T]> for ops::RangeToInclusive<usize> {
    type Output = [T];

    #[inline]
    fn get(self, slice: &[T]) -> Option<&[T]> {
        (0..=self.end).get(slice)
    }

    #[inline]
    fn get_mut(self, slice: &mut [T]) -> Option<&mut [T]> {
        (0..=self.end).get_mut(slice)
    }

    #[inline]
    unsafe fn get_unchecked(self, slice: *const [T]) -> *const [T] {
        // ආරක්ෂාව: අමතන්නාට `get_unchecked` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය.
        unsafe { (0..=self.end).get_unchecked(slice) }
    }

    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut [T]) -> *mut [T] {
        // ආරක්ෂාව: අමතන්නාට `get_unchecked_mut` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය.
        unsafe { (0..=self.end).get_unchecked_mut(slice) }
    }

    #[inline]
    fn index(self, slice: &[T]) -> &[T] {
        (0..=self.end).index(slice)
    }

    #[inline]
    fn index_mut(self, slice: &mut [T]) -> &mut [T] {
        (0..=self.end).index_mut(slice)
    }
}

/// පරාසයක සීමාවන් පරීක්ෂා කිරීම සිදු කරයි.
///
/// මෙම ක්‍රමය පෙති සඳහා [`Index::index`] ට සමාන වේ, නමුත් එය `range` ට සමාන [`Range`] ලබා දෙයි.
/// ඕනෑම පරාසයක් `start` සහ `end` අගයන් බවට පත් කිරීමට ඔබට මෙම ක්‍රමය භාවිතා කළ හැකිය.
///
/// `bounds` මායිම් පරික්ෂා කිරීම සඳහා භාවිතා කළ යුතු පෙත්තෙහි පරාසය වේ.
/// එය පෙත්තක දිගින් අවසන් වන [`RangeTo`] පරාසයක් විය යුතුය.
///
/// ආපසු ලබා දුන් [`Range`], ලබා දී ඇති පරාසය සහිත පෙති සඳහා [`slice::get_unchecked`] සහ [`slice::get_unchecked_mut`] වෙත යැවීම ආරක්ෂිතයි.
///
///
/// [`Range`]: ops::Range
/// [`RangeTo`]: ops::RangeTo
/// [`slice::get_unchecked`]: slice::get_unchecked
/// [`slice::get_unchecked_mut`]: slice::get_unchecked_mut
///
/// # Panics
///
/// 0Panics නම් `range` සීමාවෙන් පිටත නම්.
///
/// # Examples
///
/// ```
/// #![feature(slice_range)]
///
/// use std::slice;
///
/// let v = [10, 40, 30];
/// assert_eq!(1..2, slice::range(1..2, ..v.len()));
/// assert_eq!(0..2, slice::range(..2, ..v.len()));
/// assert_eq!(1..3, slice::range(1.., ..v.len()));
/// ```
///
/// 0Panics විට [`Index::index`] panic:
///
/// ```should_panic
/// #![feature(slice_range)]
///
/// use std::slice;
///
/// slice::range(2..1, ..3);
/// ```
///
/// ```should_panic
/// #![feature(slice_range)]
///
/// use std::slice;
///
/// slice::range(1..4, ..3);
/// ```
///
/// ```should_panic
/// #![feature(slice_range)]
///
/// use std::slice;
///
/// slice::range(1..=usize::MAX, ..3);
/// ```
///
/// [`Index::index`]: ops::Index::index
///
#[track_caller]
#[unstable(feature = "slice_range", issue = "76393")]
pub fn range<R>(range: R, bounds: ops::RangeTo<usize>) -> ops::Range<usize>
where
    R: ops::RangeBounds<usize>,
{
    let len = bounds.end;

    let start: ops::Bound<&usize> = range.start_bound();
    let start = match start {
        ops::Bound::Included(&start) => start,
        ops::Bound::Excluded(start) => {
            start.checked_add(1).unwrap_or_else(|| slice_start_index_overflow_fail())
        }
        ops::Bound::Unbounded => 0,
    };

    let end: ops::Bound<&usize> = range.end_bound();
    let end = match end {
        ops::Bound::Included(end) => {
            end.checked_add(1).unwrap_or_else(|| slice_end_index_overflow_fail())
        }
        ops::Bound::Excluded(&end) => end,
        ops::Bound::Unbounded => len,
    };

    if start > end {
        slice_index_order_fail(start, end);
    }
    if end > len {
        slice_end_index_len_fail(end, len);
    }

    ops::Range { start, end }
}