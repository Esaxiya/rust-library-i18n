//! `[T]` සඳහා traits සංසන්දනය කරන්න.

use crate::cmp;
use crate::cmp::Ordering::{self, Greater, Less};
use crate::mem;

use super::from_raw_parts;
use super::memchr;

extern "C" {
    /// ඇමතුම් ක්‍රියාත්මක කිරීම memcmp සපයයි.
    ///
    /// u8 ලෙස දත්ත අර්ථ නිරූපණය කරයි.
    ///
    /// 0 ට සමාන, <0 ට වඩා අඩු සහ> 0 ට වඩා වැඩි.
    ///
    // FIXME(#32610): ආපසු පැමිණීමේ වර්ගය c_int විය යුතුය
    fn memcmp(s1: *const u8, s2: *const u8, n: usize) -> i32;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> PartialEq<[B]> for [A]
where
    A: PartialEq<B>,
{
    fn eq(&self, other: &[B]) -> bool {
        SlicePartialEq::equal(self, other)
    }

    fn ne(&self, other: &[B]) -> bool {
        SlicePartialEq::not_equal(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for [T] {}

/// vectors [lexicographically](Ord#lexicographical-comparison) සංසන්දනය ක්‍රියාත්මක කරයි.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for [T] {
    fn cmp(&self, other: &[T]) -> Ordering {
        SliceOrd::compare(self, other)
    }
}

/// vectors [lexicographically](Ord#lexicographical-comparison) සංසන්දනය ක්‍රියාත්මක කරයි.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for [T] {
    fn partial_cmp(&self, other: &[T]) -> Option<Ordering> {
        SlicePartialOrd::partial_compare(self, other)
    }
}

#[doc(hidden)]
// පෙත්තෙහි PartialEq විශේෂීකරණය සඳහා අතරමැදි trait
trait SlicePartialEq<B> {
    fn equal(&self, other: &[B]) -> bool;

    fn not_equal(&self, other: &[B]) -> bool {
        !self.equal(other)
    }
}

// සාමාන්‍ය පෙති සමානාත්මතාවය
impl<A, B> SlicePartialEq<B> for [A]
where
    A: PartialEq<B>,
{
    default fn equal(&self, other: &[B]) -> bool {
        if self.len() != other.len() {
            return false;
        }

        self.iter().zip(other.iter()).all(|(x, y)| x == y)
    }
}

// වර්ග වලට ඉඩ දෙන විට බයිට්වේස් සමානාත්මතාවය සඳහා memcmp භාවිතා කරන්න
impl<A, B> SlicePartialEq<B> for [A]
where
    A: BytewiseEquality<B>,
{
    fn equal(&self, other: &[B]) -> bool {
        if self.len() != other.len() {
            return false;
        }

        // ආරක්ෂාව: `self` සහ `other` යොමු කිරීම් වන අතර එමඟින් වලංගු බවට සහතික වේ.
        // පෙති දෙක ඉහත ප්‍රමාණයෙන් සමාන දැයි පරීක්ෂා කර ඇත.
        unsafe {
            let size = mem::size_of_val(self);
            memcmp(self.as_ptr() as *const u8, other.as_ptr() as *const u8, size) == 0
        }
    }
}

#[doc(hidden)]
// පෙත්තෙහි අර්ධ ඕර්ඩ් විශේෂීකරණය සඳහා අතරමැදි trait
trait SlicePartialOrd: Sized {
    fn partial_compare(left: &[Self], right: &[Self]) -> Option<Ordering>;
}

impl<A: PartialOrd> SlicePartialOrd for A {
    default fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        let l = cmp::min(left.len(), right.len());

        // සම්පාදකයා තුළ සීමිත චෙක්පත් ඉවත් කිරීම සක්‍රීය කිරීම සඳහා ලූප් පුනරාවර්තන පරාසයට පෙති කපන්න
        //
        let lhs = &left[..l];
        let rhs = &right[..l];

        for i in 0..l {
            match lhs[i].partial_cmp(&rhs[i]) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }

        left.len().partial_cmp(&right.len())
    }
}

// මෙය අප ලබා ගැනීමට කැමති ආවේගයයි.අවාසනාවට එය ශබ්දයක් නොවේ.
// `partial_ord_slice.rs` බලන්න.
/*
impl<A> SlicePartialOrd for A
where
    A: Ord,
{
    default fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        Some(SliceOrd::compare(left, right))
    }
}
*/

impl<A: AlwaysApplicableOrd> SlicePartialOrd for A {
    fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        Some(SliceOrd::compare(left, right))
    }
}

#[rustc_specialization_trait]
trait AlwaysApplicableOrd: SliceOrd + Ord {}

macro_rules! always_applicable_ord {
    ($([$($p:tt)*] $t:ty,)*) => {
        $(impl<$($p)*> AlwaysApplicableOrd for $t {})*
    }
}

always_applicable_ord! {
    [] u8, [] u16, [] u32, [] u64, [] u128, [] usize,
    [] i8, [] i16, [] i32, [] i64, [] i128, [] isize,
    [] bool, [] char,
    [T: ?Sized] *const T, [T: ?Sized] *mut T,
    [T: AlwaysApplicableOrd] &T,
    [T: AlwaysApplicableOrd] &mut T,
    [T: AlwaysApplicableOrd] Option<T>,
}

#[doc(hidden)]
// පෙත්තක ඇණවුම විශේෂීකරණය කිරීම සඳහා අතරමැදි trait
trait SliceOrd: Sized {
    fn compare(left: &[Self], right: &[Self]) -> Ordering;
}

impl<A: Ord> SliceOrd for A {
    default fn compare(left: &[Self], right: &[Self]) -> Ordering {
        let l = cmp::min(left.len(), right.len());

        // සම්පාදකයා තුළ සීමිත චෙක්පත් ඉවත් කිරීම සක්‍රීය කිරීම සඳහා ලූප් පුනරාවර්තන පරාසයට පෙති කපන්න
        //
        let lhs = &left[..l];
        let rhs = &right[..l];

        for i in 0..l {
            match lhs[i].cmp(&rhs[i]) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }

        left.len().cmp(&right.len())
    }
}

// memcmp ශබ්දකෝෂ විද්‍යාත්මකව අත්සන් නොකළ බයිට් අනුක්‍රමයක් සංසන්දනය කරයි.
// මෙය අපට [u8] සඳහා අවශ්‍ය අනුපිළිවෙලට ගැලපේ, නමුත් වෙනත් කිසිවක් නැත ([i8] පවා නොවේ).
impl SliceOrd for u8 {
    #[inline]
    fn compare(left: &[Self], right: &[Self]) -> Ordering {
        let order =
            // ආරක්ෂාව: `left` සහ `right` යොමු කිරීම් වන අතර එමඟින් වලංගු බවට සහතික වේ.
            // එම කාල පරාසය තුළ කියවීම් සඳහා කලාප දෙකම වලංගු බව සහතික කරන අවම දිග දෙකේම අපි භාවිතා කරමු.
            //
            unsafe { memcmp(left.as_ptr(), right.as_ptr(), cmp::min(left.len(), right.len())) };
        if order == 0 {
            left.len().cmp(&right.len())
        } else if order < 0 {
            Less
        } else {
            Greater
        }
    }
}

// `Eq` ක්‍රමයක් තිබුණද `Eq` හි විශේෂීකරණය වීමට ඉඩ දීම.
#[rustc_unsafe_specialization_marker]
trait MarkerEq<T>: PartialEq<T> {}

impl<T: Eq> MarkerEq<T> for T {}

#[doc(hidden)]
/// Trait ඒවායේ සමානාත්මතාවය සඳහා සංසන්දනය කළ හැකි වර්ග සඳහා ක්‍රියාත්මක කර ඇත
///
#[rustc_specialization_trait]
trait BytewiseEquality<T>: MarkerEq<T> + Copy {}

macro_rules! impl_marker_for {
    ($traitname:ident, $($ty:ty)*) => {
        $(
            impl $traitname<$ty> for $ty { }
        )*
    }
}

impl_marker_for!(BytewiseEquality,
                 u8 i8 u16 i16 u32 i32 u64 i64 u128 i128 usize isize char bool);

pub(super) trait SliceContains: Sized {
    fn slice_contains(&self, x: &[Self]) -> bool;
}

impl<T> SliceContains for T
where
    T: PartialEq,
{
    default fn slice_contains(&self, x: &[Self]) -> bool {
        x.iter().any(|y| *y == *self)
    }
}

impl SliceContains for u8 {
    #[inline]
    fn slice_contains(&self, x: &[Self]) -> bool {
        memchr::memchr(*self, x).is_some()
    }
}

impl SliceContains for i8 {
    #[inline]
    fn slice_contains(&self, x: &[Self]) -> bool {
        let byte = *self as u8;
        // ආරක්ෂාව: `i8` සහ `u8` එකම මතක පිරිසැලසුමක් ඇති අතර එමඟින් `x.as_ptr()` වාත්තු කරයි
        // `*const u8` ආරක්ෂිත බැවින්.
        // `x.as_ptr()` යොමු කිරීමකින් එන අතර එමඟින් `x.len()` පෙත්තෙහි දිග කියවීම සඳහා වලංගු බවට සහතික වන අතර එය `isize::MAX` ට වඩා විශාල විය නොහැක.
        // ආපසු ලබා දුන් පෙත්ත කිසි විටෙකත් විකෘති නොවේ.
        let bytes: &[u8] = unsafe { from_raw_parts(x.as_ptr() as *const u8, x.len()) };
        memchr::memchr(byte, bytes).is_some()
    }
}