// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// `[mid-left, mid+right)` පරාසය භ්‍රමණය වන පරිදි `mid` හි මූලද්‍රව්‍යය පළමු මූලද්‍රව්‍යය බවට පත්වේ.සමානව, පරාසය `left` මූලද්‍රව්‍ය වමට හෝ `right` මූලද්‍රව්‍ය දකුණට කරකවයි.
///
/// # Safety
///
/// නිශ්චිත පරාසය කියවීම සහ ලිවීම සඳහා වලංගු විය යුතුය.
///
/// # Algorithm
///
/// ඇල්ගොරිතම 1 `left + right` හි කුඩා අගයන් සඳහා හෝ විශාල `T` සඳහා භාවිතා කරයි.
/// එක් මූලද්‍රව්‍යයක් එක් වරකට `mid - left` සිට ආරම්භ වන අතර `right` පියවර මොඩියුලෝ `left + right` මගින් ඉදිරියට යනු ඇත, එනම් එක් තාවකාලික කාලයක් පමණක් අවශ්‍ය වේ.
/// අවසානයේදී, අපි නැවත `mid - left` වෙත පැමිණෙමු.
/// කෙසේ වෙතත්, `gcd(left + right, right)` 1 නොවේ නම්, ඉහත පියවර මූලද්‍රව්‍ය ඉක්මවා ගියේය.
/// උදාහරණ වශයෙන්:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// වාසනාවකට මෙන්, අවසන් කරන ලද මූලද්‍රව්‍ය අතර මඟ හැරුණු මූලද්‍රව්‍ය ගණන සැමවිටම සමාන වේ, එබැවින් අපට අපගේ ආරම්භක ස්ථානය මඟ හැර තවත් වට ගණනක් කළ හැකිය (මුළු වට ගණන `gcd(left + right, right)` value) වේ.
///
/// අවසාන ප්‍රති result ලය වන්නේ සියලුම මූලද්‍රව්‍යයන් එක් වරක් පමණක් අවසන් කිරීමයි.
///
/// `left + right` විශාල නම් ඇල්ගොරිතම 2 භාවිතා වන නමුත් `min(left, right)` කුඩා බෆරයකට සවි කිරීමට තරම් කුඩා වේ.
/// `min(left, right)` මූලද්‍රව්‍ය බෆරයට පිටපත් කරනු ලැබේ, `memmove` අනෙක් ඒවාට යොදන අතර බෆරයේ ඇති ඒවා නැවත ආරම්භ වූ ස්ථානයට ප්‍රතිවිරුද්ධ පැත්තේ සිදුරට ගෙන යනු ලැබේ.
///
/// `left + right` ප්‍රමාණවත් තරම් විශාල වූ පසු දෛශිකකරණය කළ හැකි ඇල්ගොරිතම ඉහත ඒවා ඉක්මවා යයි.
/// ඇල්ගොරිතම 1 දෛශිකකරණය කළ හැකි අතර එකවර බොහෝ වටයන් සිදු කරයි, නමුත් `left + right` අති විශාල වන තෙක් සාමාන්‍යයෙන් වට කිහිපයක් අඩු වන අතර තනි වටයක නරකම අවස්ථාව සැමවිටම පවතී.
/// ඒ වෙනුවට, ඇල්ගොරිතම 3 කුඩා භ්‍රමණ ගැටලුවක් ඉතිරි වන තෙක් `min(left, right)` මූලද්‍රව්‍ය නැවත නැවත මාරු කිරීම භාවිතා කරයි.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// `left < right` විට හුවමාරුව වමේ සිට සිදු වේ.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. මෙම අවස්ථා පරික්ෂා නොකළහොත් පහත ඇල්ගොරිතම අසමත් විය හැකිය
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // ඇල්ගොරිතම 1 මයික්‍රොබෙන්ච්මාර්ක්ස් පෙන්නුම් කරන්නේ අහඹු මාරුවීම් සඳහා සාමාන්‍ය කාර්ය සාධනය `left + right == 32` පමණ වන තෙක් වඩා හොඳ බවයි, නමුත් නරකම අවස්ථාව 16 ක් පමණ බිඳී යයි.
            // 24 මැද බිම ලෙස තෝරා ගන්නා ලදී.
            // `T` හි ප්‍රමාණය 4 `usize` ට වඩා විශාල නම්, මෙම ඇල්ගොරිතම වෙනත් ඇල්ගොරිතමයන් අභිබවා යයි.
            //
            //
            let x = unsafe { mid.sub(left) };
            // පළමු වටයේ ආරම්භය
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` `gcd(left + right, right)` ගණනය කිරීමෙන් අතින් සොයාගත හැකිය, නමුත් එක් ලූපයක් කිරීම වේගවත් වන අතර එය gcd අතුරු ආබාධයක් ලෙස ගණනය කරයි, ඉන්පසු ඉතිරි කොටස කරන්න
            //
            //
            let mut gcd = right;
            // මිණුම් සලකුණු වලින් හෙළි වන්නේ එක් තාවකාලික වරක් කියවීම, පසුපසට පිටපත් කිරීම සහ අවසානයේ එම තාවකාලික ලිවීම වෙනුවට තාවකාලික ස්ථාන මාරු කිරීම වේගවත් බවය.
            // මෙයට හේතුව තාවකාලික හුවමාරු කිරීම හෝ ප්‍රතිස්ථාපනය කිරීම දෙකක් කළමනාකරණය කිරීමට අවශ්‍ය නොවී ලූපයේ එක් මතක ලිපිනයක් පමණක් භාවිතා කිරීමයි.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // `i` වර්ධක කර එය සීමාවෙන් පිටත දැයි පරීක්ෂා කරනවා වෙනුවට, `i` ඊළඟ වර්ධකයේ සීමාවෙන් පිටත යන්නේ දැයි අපි පරීක්ෂා කරමු.
                // මෙය දර්ශක හෝ `usize` එතීම වළක්වයි.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // පළමු වටයේ අවසානය
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // `left + right >= 15` නම් මෙම කොන්දේසිය මෙහි තිබිය යුතුය
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // කැබැල්ල තවත් වටයකින් අවසන් කරන්න
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` ශුන්‍ය ප්‍රමාණයේ වර්ගයක් නොවේ, එබැවින් එහි ප්‍රමාණයෙන් බෙදීම සුදුසුය.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // ඇල්ගොරිතම 2 මෙහි `[T; 0]` යනු මෙය T සඳහා නිසි ලෙස පෙළ ගැසී ඇති බව සහතික කිරීමයි
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // ඇල්ගොරිතම 3 මෙම ඇල්ගොරිතමයේ අවසාන හුවමාරුව කොතැනදැයි සොයා ගැනීම හා මෙම ඇල්ගොරිතම වැනි යාබද කුට්ටි මාරු කිරීම වෙනුවට අන්තිම කැබැල්ල භාවිතා කිරීම හුවමාරු කර ගැනීමේ විකල්ප ක්‍රමයක් ඇත, නමුත් මෙම ක්‍රමය තවමත් වේගවත්ය.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // ඇල්ගොරිතම 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}