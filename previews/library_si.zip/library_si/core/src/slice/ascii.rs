//! ASCII `[u8]` හි මෙහෙයුම්.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// මෙම පෙත්තෙහි ඇති සියලුම බයිට් ASCII පරාසය තුළ තිබේදැයි පරීක්ෂා කරයි.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// පෙති දෙකක් ASCII සිද්ධි-සංවේදී නොවන ගැලපීමක් දැයි පරීක්ෂා කරයි.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` හා සමානයි, නමුත් තාවකාලික වෙන් කිරීම සහ පිටපත් කිරීමකින් තොරව.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// මෙම පෙත්ත එහි ASCII ඉහළ අකුරට සමාන ස්ථානයකට පරිවර්තනය කරයි.
    ///
    /// ASCII අක්ෂර 'a' සිට 'z' දක්වා 'A' සිට 'Z' දක්වා සිතියම් ගත කර ඇත, නමුත් ASCII නොවන අකුරු නොවෙනස්ව පවතී.
    ///
    /// පවතින අගය වෙනස් නොකර නව ඉහළ අගයක් ලබා දීමට, [`to_ascii_uppercase`] භාවිතා කරන්න.
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// මෙම පෙත්ත එහි ASCII කුඩා අකුරට සමාන ස්ථානයකට පරිවර්තනය කරයි.
    ///
    /// ASCII අක්ෂර 'A' සිට 'Z' දක්වා 'a' සිට 'z' දක්වා සිතියම් ගත කර ඇත, නමුත් ASCII නොවන අකුරු නොවෙනස්ව පවතී.
    ///
    /// පවතින අගය වෙනස් නොකර නව අඩු අගයක් ලබා දීමට, [`to_ascii_lowercase`] භාවිතා කරන්න.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// `v` යන වචනයේ කිසියම් බයිට් එකක් nonascii (>=128) නම් `true` ලබා දෙයි.
/// `../str/mod.rs` වෙතින් Snarfed, එය utf8 වලංගුකරණයට සමාන දෙයක් කරයි.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// ප්‍රශස්තිකරණය කරන ලද ASCII පරීක්ෂණය මඟින් බයිට්-ඒ-ටයිම් මෙහෙයුම් වෙනුවට (හැකි විට) භාවිතයට ගත හැකි මෙහෙයුම් භාවිතා කරනු ඇත.
///
/// අප මෙහි භාවිතා කරන ඇල්ගොරිතම ඉතා සරල ය.`s` ඉතා කෙටි නම්, අපි එක් එක් බයිටය පරීක්ෂා කර බලා එය කරන්නෙමු.එසේ නොමැති නම්:
///
/// - නොබැඳි බරක් සමඟ පළමු වචනය කියවන්න.
/// - දර්ශකය පෙළගස්වන්න, පෙළගස්වන ලද බර සමඟ අවසානය දක්වා වචන කියවන්න.
/// - නොබැඳි බරක් සමඟ `s` වෙතින් අවසන් `usize` කියවන්න.
///
/// මෙම ඕනෑම බරක් `contains_nonascii` (above) සත්‍ය වන යමක් නිපදවන්නේ නම්, පිළිතුර අසත්‍ය බව අපි දනිමු.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // වරින් වර ක්‍රියාත්මක කිරීම යන වචනයෙන් අප කිසිවක් ලබා නොගන්නේ නම්, නැවත පරිමාණ පුඩුවක් වෙතට වැටෙන්න.
    //
    // `usize` සඳහා `size_of::<usize>()` ප්‍රමාණවත් පෙළගැස්මක් නොමැති ගෘහ නිර්මාණ සඳහාද අපි මෙය කරන්නෙමු, මන්ද එය අමුතු edge නඩුවකි.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // අපි සැමවිටම කියවන්නේ නොබැඳි පළමු වචනයයි, එයින් අදහස් වන්නේ `align_offset` යන්නයි
    // 0, පෙළගස්වන ලද කියවීම සඳහා අපි නැවතත් එම අගය කියවමු.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // ආරක්ෂාව: අපි ඉහත `len < USIZE_SIZE` සත්‍යාපනය කරමු.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // අපි මෙය තරමක් පරික්‍ෂා කර බැලුවෙමු.
    // `offset_to_aligned` යනු `align_offset` හෝ `USIZE_SIZE` බව සලකන්න, දෙකම ඉහත පැහැදිලිව පරීක්ෂා කර ඇත.
    //
    debug_assert!(offset_to_aligned <= len);

    // SAFETY: word_ptr යනු කියවීමට අප භාවිතා කරන (නිසි ලෙස පෙළගස්වා ඇති) ptr භාවිතා කිරීමයි
    // පෙත්තෙහි මැද කොටස.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` යනු ලූප් එන්ඩ් චෙක්පත් සඳහා භාවිතා කරන `word_ptr` හි බයිට් දර්ශකයයි.
    let mut byte_pos = offset_to_aligned;

    // මානසික ආතතිය පෙළගැස්වීම පිළිබඳව පරීක්ෂා කරන්න, මන්ද අපි නොබැඳි බර පොකුරක් කිරීමට සූදානම්ව සිටිමු.
    // ප්‍රායෝගිකව මෙය `align_offset` හි දෝෂයක් වළක්වා ගත නොහැකි විය යුතුය.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // වලිගය සෑම විටම එක් `usize` බව සහතික කර ගැනීම සඳහා, අවසාන පෙළගැස්වූ වචනය තනිවම වලිග පරීක්ෂාවෙන් පසුව බැහැර කර අවසන් පෙළගැස්වූ වචනය දක්වා කියවන්න, අමතර branch `byte_pos == len` දක්වා.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // කියවීම සීමා රහිත දැයි සනීපාරක්ෂාව පරීක්ෂා කරන්න
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // `byte_pos` පිළිබඳ අපගේ උපකල්පන දරයි.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // ආරක්ෂාව: `word_ptr` නිසියාකාරව පෙලගැසී ඇති බව අපි දනිමු
        // `align_offset`), සහ `word_ptr` සහ අවසානය අතර අපට ප්‍රමාණවත් තරම් බයිට් ඇති බව අපි දනිමු
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // ආරක්ෂාව: අපි දන්නවා `byte_pos <= len - USIZE_SIZE`, ඒ කියන්නේ
        // මෙම `add` පසු, `word_ptr` බොහෝ දුරට එක්-අතීතයක් වනු ඇත.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // එක් `usize` එකක් පමණක් ඉතිරිව ඇති බව තහවුරු කර ගැනීම සඳහා සනීපාරක්ෂක පරීක්ෂාව.
    // මෙය අපගේ ලූප තත්ත්වය මගින් සහතික කළ යුතුය.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // ආරක්ෂාව: මෙය ආරම්භයේදීම අප විසින් පරීක්ෂා කරන `len >= USIZE_SIZE` මත රඳා පවතී.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}