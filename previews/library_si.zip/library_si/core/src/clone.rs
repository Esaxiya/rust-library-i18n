//! 'ව්‍යංගයෙන් පිටපත් කළ නොහැකි' වර්ග සඳහා `Clone` trait.
//!
//! Rust හි, සමහර සරල වර්ග "implicitly copyable" වන අතර ඔබ ඒවා පවරන විට හෝ ඒවා තර්ක ලෙස සම්මත කළ විට, ලබන්නාට පිටපතක් ලැබෙනු ඇත, එහි මුල් අගය ඉතිරි වේ.
//! මෙම වර්ග වලට පිටපත් කිරීම සඳහා ප්‍රතිපාදන අවශ්‍ය නොවන අතර අවසන් යන්ත්‍ර නොමැත (එනම්, ඒවා සතුව පෙට්ටි අඩංගු නොවේ හෝ [`Drop`] ක්‍රියාත්මක කරයි), එබැවින් සම්පාදකයා ඒවා ලාභදායී හා පිටපත් කිරීමට ආරක්ෂිත යැයි සලකයි.
//!
//! [`Clone`] trait සම්මුතිය ක්‍රියාත්මක කිරීමෙන් සහ [`clone`] ක්‍රමය ඇමතීමෙන් වෙනත් වර්ග සඳහා පිටපත් පැහැදිලිව කළ යුතුය.
//!
//! [`clone`]: Clone::clone
//!
//! මූලික භාවිත උදාහරණය:
//!
//! ```
//! let s = String::new(); // නූල් වර්ගය ක්ලෝනය ක්‍රියාත්මක කරයි
//! let copy = s.clone(); // ඒ නිසා අපට එය ක්ලෝන කළ හැකිය
//! ```
//!
//! trait ක්ලෝන් පහසුවෙන් ක්‍රියාත්මක කිරීම සඳහා, ඔබට `#[derive(Clone)]` ද භාවිතා කළ හැකිය.උදාහරණයක්:
//!
//! ```
//! #[derive(Clone)] // අපි මෝෆියස් ව්‍යුහයට trait ක්ලෝනය එකතු කරමු
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // දැන් අපට එය ක්ලෝන කළ හැකිය!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// වස්තුවක් පැහැදිලිව අනුපිටපත් කිරීමේ හැකියාව සඳහා පොදු trait.
///
/// එම [`Copy`] හි [`Copy`] හි වෙනස ව්‍යංගයෙන් හා අතිශයින්ම මිල අඩු වන අතර `Clone` සෑම විටම පැහැදිලිව පෙනෙන අතර මිල අධික විය හැකිය.
/// මෙම ලක්ෂණ බලාත්මක කිරීම සඳහා, Rust ඔබට [`Copy`] නැවත ක්‍රියාත්මක කිරීමට ඉඩ නොදේ, නමුත් ඔබට `Clone` යලි ක්‍රියාත්මක කර අත්තනෝමතික කේත ක්‍රියාත්මක කළ හැකිය.
///
/// `Clone` [`Copy`] ට වඩා සාමාන්‍ය බැවින් ඔබට ඕනෑම දෙයක් ස්වයංක්‍රීයව [`Copy`] `Clone` විය හැකිය.
///
/// ## Derivable
///
/// සියලුම ක්ෂේත්‍ර `Clone` නම් මෙම trait `#[derive]` සමඟ භාවිතා කළ හැකිය.එක් එක් ක්ෂේත්‍රය මත [`Clone`] ඇමතුම් [`clone`] ක්‍රියාත්මක කිරීම.
///
/// [`clone`]: Clone::clone
///
/// සාමාන්‍ය ව්‍යුහයක් සඳහා, `#[derive]` සාමාන්‍ය පරාමිතීන් මත බැඳී ඇති `Clone` එකතු කිරීමෙන් කොන්දේසි සහිතව `Clone` ක්‍රියාත්මක කරයි.
///
/// ```
/// // `derive` කියවීම සඳහා ක්ලෝන ක්‍රියාත්මක කරයි<T>ටී ක්ලෝන විට.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## `Clone` ක්‍රියාත්මක කරන්නේ කෙසේද?
///
/// [`Copy`] වර්ග වලට `Clone` හි සුළු ක්‍රියාවලියක් තිබිය යුතුය.වඩාත් විධිමත් ලෙස:
/// `T: Copy`, `x: T`, සහ `y: &T` නම්, `let x = y.clone();` යනු `let x = *y;` ට සමාන වේ.
/// අතින් ක්‍රියාත්මක කිරීම මෙම වෙනස්වීම තහවුරු කිරීමට ප්‍රවේශම් විය යුතුය;කෙසේ වෙතත්, මතක ආරක්ෂාව සහතික කිරීම සඳහා අනාරක්ෂිත කේතය එය මත රඳා නොසිටිය යුතුය.
///
/// ශ්‍රිත දර්ශකයක් දරණ සාමාන්‍ය ව්‍යුහයකි.මෙම අවස්ථාවෙහිදී, `Clone` ක්‍රියාත්මක කිරීම `ව්‍යුත්පන්න කළ නොහැකි නමුත් එය ක්‍රියාත්මක කළ හැක්කේ:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## අතිරේක ක්රියාත්මක කරන්නන්
///
/// [implementors listed below][impls] ට අමතරව, පහත දැක්වෙන වර්ග ද `Clone` ක්‍රියාත්මක කරයි:
///
/// * ක්‍රියාකාරී අයිතම වර්ග (එනම්, එක් එක් ශ්‍රිතය සඳහා අර්ථ දක්වා ඇති විශේෂිත වර්ග)
/// * ක්‍රියාකාරී දර්ශක වර්ග (උදා: `fn() -> i32`)
/// * අයිතම වර්ගය `Clone` (උදා: `[i32; 123456]`) ද ක්‍රියාත්මක කරන්නේ නම්, සියලු ප්‍රමාණ සඳහා අරා වර්ග
/// * එක් එක් සංරචකය `Clone` (උදා: `()`, `(i32, bool)`) ද ක්‍රියාත්මක කරන්නේ නම් ටුපල් වර්ග
/// * සංවෘත වර්ග, ඒවා පරිසරයෙන් කිසිදු වටිනාකමක් ලබා නොගන්නේ නම් හෝ අල්ලා ගන්නා ලද සියලුම අගයන් `Clone` ක්‍රියාත්මක කරන්නේ නම්.
///   හවුල් යොමු කිරීම මඟින් ග්‍රහණය කරගත් විචල්‍යයන් සැමවිටම ක්‍රියාත්මක වන්නේ `Clone` (යොමු කිරීම සිදු නොවුනත්) වන අතර විකෘති යොමු මඟින් ග්‍රහණය කරගත් විචල්‍යයන් කිසි විටෙකත් `Clone` ක්‍රියාත්මක නොකරයි.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// වටිනාකමේ පිටපතක් ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str ක්ලෝන ක්‍රියාත්මක කරයි
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// `source` වෙතින් පිටපත් පැවරීම සිදු කරයි.
    ///
    /// `a.clone_from(&b)` ක්‍රියාකාරීත්වයේ `a = b.clone()` ට සමාන වේ, නමුත් අනවශ්‍ය ප්‍රතිපාදන වළක්වා ගැනීම සඳහා `a` හි සම්පත් නැවත භාවිතා කිරීම සඳහා අභිබවා යා හැකිය.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// trait `Clone` හි ආවේගයක් ජනනය කරන ව්‍යුත්පන්න සාර්ව.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): වර්ගයක සෑම අංගයක්ම ක්ලෝන හෝ පිටපත් ක්‍රියාත්මක කරන බව ප්‍රකාශ කිරීම සඳහා මෙම ව්‍යුහයන් තනිකරම#[ව්‍යුත්පන්න] භාවිතා කරයි.
//
//
// මෙම ව්‍යුහයන් කිසි විටෙක පරිශීලක කේතයේ නොපෙන්විය යුතුය.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// ප්‍රාථමික වර්ග සඳහා `Clone` ක්‍රියාත්මක කිරීම.
///
/// Rust හි විස්තර කළ නොහැකි ක්‍රියාත්මක කිරීම් `traits::SelectionContext::copy_clone_conditions()` හි `rustc_trait_selection` හි ක්‍රියාත්මක වේ.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// බෙදාගත් යොමු කිරීම් ක්ලෝන කළ හැකි නමුත් විකෘති යොමු කිරීම් *කළ නොහැක*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// බෙදාගත් යොමු කිරීම් ක්ලෝන කළ හැකි නමුත් විකෘති යොමු කිරීම් *කළ නොහැක*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}