//! වර්ග අතර පරිවර්තනය සඳහා Traits.
//!
//! මෙම මොඩියුලයේ ඇති traits එක් වර්ගයක සිට තවත් වර්ගයකට පරිවර්තනය කිරීමට ක්‍රමයක් සපයයි.
//! සෑම trait වෙනස් අරමුණක් ඉටු කරයි:
//!
//! - ලාභ යොමු-යොමු-යොමු පරිවර්තනය සඳහා [`AsRef`] trait ක්‍රියාත්මක කරන්න
//! - ලාභ විකෘති සිට විකෘති පරිවර්තනය සඳහා [`AsMut`] trait ක්‍රියාත්මක කරන්න
//! - වටිනාකමින් වටිනාකමින් යුත් පරිවර්තන පරිභෝජනය සඳහා [`From`] trait ක්‍රියාත්මක කරන්න
//! - වත්මන් crate වලින් පිටත වර්ග වලට වටිනාකමින් වටිනාකමින් යුත් පරිවර්තන පරිභෝජනය සඳහා [`Into`] trait ක්‍රියාත්මක කරන්න
//! - [`TryFrom`] සහ [`TryInto`] traits හැසිරෙන්නේ [`From`] සහ [`Into`] ලෙස වන නමුත් පරිවර්තනය අසමත් වූ විට ක්‍රියාත්මක කළ යුතුය.
//!
//! මෙම මොඩියුලයේ ඇති traits බොහෝ විට trait bounds ලෙස සාමාන්‍ය කාර්යයන් සඳහා භාවිතා කරයි, එනම් විවිධ වර්ගවල තර්ක සඳහා සහය දක්වයි.උදාහරණ සඳහා එක් එක් trait හි ප්‍රලේඛනය බලන්න.
//!
//! පුස්තකාල කතුවරයෙකු ලෙස, ඔබ සැමවිටම [`Into<U>`][`Into`] හෝ [`TryInto<U>`][`TryInto`] වෙනුවට [`From<T>`][`From`] හෝ [`TryFrom<T>`][`TryFrom`] ක්‍රියාත්මක කිරීමට වැඩි කැමැත්තක් දැක්විය යුතුය. [`From`] සහ [`TryFrom`] වැඩි නම්යශීලී බවක් ලබා දෙන අතර සම්මත පුස්තකාලයේ හිස් ක්‍රියාත්මක කිරීමක් නිසා ස්තූතියි.
//! Rust 1.41 ට පෙර අනුවාදයක් ඉලක්ක කරන විට, වත්මන් crate වලින් පිටත වර්ගයකට පරිවර්තනය කිරීමේදී [`Into`] හෝ [`TryInto`] කෙලින්ම ක්‍රියාත්මක කිරීම අවශ්‍ය විය හැකිය.
//!
//! # සාමාන්‍ය ක්‍රියාත්මක කිරීම්
//!
//! - [`AsRef`] සහ අභ්‍යන්තර වර්ගය යොමු කිරීමක් නම් [`AsMut`] ස්වයංක්‍රීයව විරූපණය
//! - [`සිට`]`<U>සඳහා ටී` යන්නෙන් ගම්‍ය වන්නේ [`තුළට`]`</u><T><U>යූ සඳහා</u>
//! - [`ට්‍රයිෆ්‍රොම්`]`<U>සඳහා ටී` යන්නෙන් ගම්‍ය වන්නේ [`ට්‍රයිඉන්ටෝ`]`</u><T><U>යූ සඳහා</u>
//! - [`From`] සහ [`Into`] ප්‍රත්‍යාවර්තක වන අතර එයින් අදහස් කරන්නේ සියලුම වර්ගයන්ට `into` සහ `from` තමන් විසින්ම කළ හැකි බවයි
//!
//! භාවිත උදාහරණ සඳහා එක් එක් trait බලන්න.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// අනන්‍යතා ශ්‍රිතය.
///
/// මෙම කාර්යය පිළිබඳව සටහන් කළ යුතු කරුණු දෙකක් වැදගත් ය:
///
/// - එය සැමවිටම `|x| x` වැනි වසා දැමීමකට සමාන නොවේ, මන්ද වසා දැමීම `x` වෙනත් වර්ගයකට බල කරයි.
///
/// - එය `x` ආදානය ශ්‍රිතයට ගෙන යයි.
///
/// ආදානය ආපසු ලබා දෙන ශ්‍රිතයක් තිබීම අමුතු දෙයක් ලෙස පෙනුනද, රසවත් භාවිතයන් කිහිපයක් තිබේ.
///
///
/// # Examples
///
/// වෙනත්, සිත්ගන්නාසුළු, කාර්යයන් අනුපිළිවෙලින් කිසිවක් කිරීමට `identity` භාවිතා කිරීම:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // එකක් එකතු කිරීම සිත්ගන්නා සුළු කාර්යයක් බව මවාපාමු.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// `identity` කොන්දේසි සහිතව "do nothing" පාදක නඩුවක් ලෙස භාවිතා කිරීම:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // තවත් රසවත් දේවල් කරන්න ...
///
/// let _results = do_stuff(42);
/// ```
///
/// `Option<T>` හි අනුකාරකයේ `Some` ප්‍රභේද තබා ගැනීමට `identity` භාවිතා කිරීම:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// ලාභ යොමු-යොමු-යොමු පරිවර්තනයක් කිරීමට භාවිතා කරයි.
///
/// මෙම trait විකෘති යොමු කිරීම් අතර පරිවර්තනය සඳහා භාවිතා කරන [`AsMut`] ට සමාන වේ.
/// ඔබට මිල අධික පරිවර්තනයක් කිරීමට අවශ්‍ය නම් `&T` වර්ගය සමඟ [`From`] ක්‍රියාත්මක කිරීම හෝ අභිරුචි ශ්‍රිතයක් ලිවීම වඩා හොඳය.
///
/// `AsRef` [`Borrow`] හා සමාන අත්සනක් ඇත, නමුත් [`Borrow`] අංශ කිහිපයකින් වෙනස් වේ:
///
/// - `AsRef` මෙන් නොව, [`Borrow`] හි ඕනෑම `T` සඳහා බ්ලැන්කට් impl එකක් ඇති අතර එය යොමු කිරීමක් හෝ අගයක් පිළිගැනීමට භාවිතා කළ හැකිය.
/// - [`Borrow`] ණයට ගත් වටිනාකම සඳහා [`Hash`], [`Eq`] සහ [`Ord`] ද අයිති වටිනාකමට සමාන විය යුතුය.
/// මේ හේතුව නිසා, ඔබට ව්‍යුහයක එක් ක්ෂේත්‍රයක් පමණක් ණයට ගැනීමට අවශ්‍ය නම් ඔබට `AsRef` ක්‍රියාත්මක කළ හැකි නමුත් [`Borrow`] නොවේ.
///
/// **Note: මෙම trait අසමත් නොවිය යුතුය **.පරිවර්තනය අසමත් විය හැකි නම්, [`Option<T>`] හෝ [`Result<T, E>`] ආපසු ලබා දෙන විශේෂිත ක්‍රමයක් භාවිතා කරන්න.
///
/// # සාමාන්‍ය ක්‍රියාත්මක කිරීම්
///
/// - `AsRef` අභ්‍යන්තර වර්ගය යොමු කිරීමක් හෝ විකෘති යොමු කිරීමක් නම් ස්වයංක්‍රීය විරූපණයන් (උදා: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// trait bounds භාවිතා කිරීමෙන් විවිධ වර්ගවල තර්ක නිශ්චිත වර්ගයේ `T` බවට පරිවර්තනය කළ හැකි තාක් කල් අපට පිළිගත හැකිය.
///
/// උදාහරණයක් ලෙස: `AsRef<str>` ගතවන සාමාන්‍ය ශ්‍රිතයක් නිර්මාණය කිරීමෙන්, [`&str`] බවට තර්කයක් ලෙස පරිවර්තනය කළ හැකි සියලු යොමු පිළිගැනීමට අපට අවශ්‍ය බව අපි ප්‍රකාශ කරමු.
/// [`String`] සහ [`&str`] යන දෙකම `AsRef<str>` ක්‍රියාත්මක කරන බැවින් අපට ආදාන පරාමිතිය ලෙස පිළිගත හැකිය.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// පරිවර්තනය සිදු කරයි.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// ලාභ විකෘති-සිට-විකෘති යොමු පරිවර්තනයක් කිරීමට භාවිතා කරයි.
///
/// මෙම trait [`AsRef`] ට සමාන නමුත් විකෘති යොමු කිරීම් අතර පරිවර්තනය සඳහා භාවිතා කරයි.
/// ඔබට මිල අධික පරිවර්තනයක් කිරීමට අවශ්‍ය නම් `&mut T` වර්ගය සමඟ [`From`] ක්‍රියාත්මක කිරීම හෝ අභිරුචි ශ්‍රිතයක් ලිවීම වඩා හොඳය.
///
/// **Note: මෙම trait අසමත් නොවිය යුතුය **.පරිවර්තනය අසමත් විය හැකි නම්, [`Option<T>`] හෝ [`Result<T, E>`] ආපසු ලබා දෙන විශේෂිත ක්‍රමයක් භාවිතා කරන්න.
///
/// # සාමාන්‍ය ක්‍රියාත්මක කිරීම්
///
/// - `AsMut` අභ්‍යන්තර වර්ගය විකෘති යොමු කිරීමක් නම් ස්වයංක්‍රීය විරූපණයන් (උදා: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// සාමාන්‍ය ශ්‍රිතයක් සඳහා `AsMut` trait bound ලෙස භාවිතා කිරීමෙන් අපට `&mut T` වර්ගයට පරිවර්තනය කළ හැකි සියලුම විකෘති යොමු කිරීම් පිළිගත හැකිය.
/// [`Box<T>`] විසින් `AsMut<T>` ක්‍රියාත්මක කරන නිසා අපට `add_one` ශ්‍රිතයක් ලිවිය හැකි අතර එය `&mut u64` බවට පරිවර්තනය කළ හැකි සියලුම තර්ක ගෙන යයි.
/// [`Box<T>`] `AsMut<T>` ක්‍රියාත්මක කරන නිසා, `add_one` `&mut Box<u64>` වර්ගයේ තර්ක ද පිළිගනී:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// පරිවර්තනය සිදු කරයි.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// ආදාන අගය පරිභෝජනය කරන අගය-සිට-අගය පරිවර්තනය.[`From`] හි ප්රතිවිරුද්ධයයි.
///
/// යමෙක් [`Into`] ක්‍රියාත්මක කිරීමෙන් වැළකී [`From`] ක්‍රියාත්මක කළ යුතුය.
/// [`From`] ස්වයංක්‍රීයව ක්‍රියාත්මක කිරීම මඟින් සම්මත පුස්තකාලයේ බ්ලැන්කට් ක්‍රියාත්මක කිරීමට ස්තූතිවන්ත වන පරිදි [`Into`] ක්‍රියාත්මක කිරීමක් ලබා දේ.
///
/// [`Into`] පමණක් ක්‍රියාත්මක කරන වර්ග ද භාවිතා කළ හැකි බව සහතික කිරීම සඳහා සාමාන්‍ය ශ්‍රිතයක් මත trait bounds නියම කිරීමේදී [`Into`] ට වඩා [`Into`] භාවිතා කිරීමට කැමති වන්න.
///
/// **Note: මෙම trait අසමත් නොවිය යුතුය **.පරිවර්තනය අසමත් විය හැකි නම්, [`TryInto`] භාවිතා කරන්න.
///
/// # සාමාන්‍ය ක්‍රියාත්මක කිරීම්
///
/// - [`සිට`]`<T>U` යන්නෙන් අදහස් කරන්නේ `Into<U> for T` ය
/// - [`Into`] ප්‍රත්‍යාවර්තක වේ, එයින් අදහස් වන්නේ `Into<T> for T` ක්‍රියාත්මක වන බවයි
///
/// # Rust හි පැරණි අනුවාද වල බාහිර වර්ග වලට පරිවර්තනය කිරීම සඳහා [`Into`] ක්‍රියාත්මක කිරීම
///
/// Rust 1.41 ට පෙර, ගමනාන්ත වර්ගය වත්මන් crate හි කොටසක් නොවේ නම් ඔබට [`From`] කෙලින්ම ක්‍රියාත්මක කළ නොහැක.
/// උදාහරණයක් ලෙස, මෙම කේතය ගන්න:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Rust හි අනාථ නීති රීති මඳක් දැඩි බැවින් මෙය පැරණි භාෂාවේ අනුවාදයන් සම්පාදනය කිරීමට අසමත් වනු ඇත.
/// මෙය මඟ හැරීම සඳහා, ඔබට කෙලින්ම [`Into`] ක්‍රියාත්මක කළ හැකිය:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// [`Into`] විසින් [`From`] ක්‍රියාත්මක කිරීමක් ලබා නොදෙන බව වටහා ගැනීම වැදගත්ය ([`From`] [`Into`] සමඟ කරන ආකාරයට).
/// එබැවින්, ඔබ සැමවිටම [`From`] ක්‍රියාත්මක කිරීමට උත්සාහ කළ යුතු අතර [`From`] ක්‍රියාත්මක කළ නොහැකි නම් නැවත [`Into`] වෙත වැටෙන්න.
///
/// # Examples
///
/// [`String`] ක්‍රියාත්මක කරයි [`තුළට`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// නිශ්චිත වර්ගයේ `T` බවට පරිවර්තනය කළ හැකි සියලු තර්ක ලබා ගැනීමට අපට සාමාන්‍ය ශ්‍රිතයක් අවශ්‍ය බව ප්‍රකාශ කිරීම සඳහා, අපට [`Into`] හි trait bound භාවිතා කළ හැකිය.<T>`.
///
/// උදාහරණයක් ලෙස: `is_hello` ශ්‍රිතය [`Vec`]`<`[`u8`] `>` බවට පරිවර්තනය කළ හැකි සියලුම තර්ක ගනී.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// පරිවර්තනය සිදු කරයි.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// ආදාන අගය පරිභෝජනය කරන අතරතුර වටිනාකමට වටිනාකම් පරිවර්තනය කිරීමට භාවිතා කරයි.එය [`Into`] හි පරස්පරතාවයි.
///
/// `From` ට වඩා `From` ක්‍රියාත්මක කිරීමට යමෙක් නිතරම කැමති විය යුතුය. මන්දයත් `From` ස්වයංක්‍රීයව ක්‍රියාත්මක කිරීම මඟින් සම්මත පුස්තකාලයේ බ්ලැන්කට් ක්‍රියාත්මක කිරීමට ස්තූතිවන්ත වන පරිදි [`Into`] ක්‍රියාත්මක කිරීමකි.
///
///
/// Rust 1.41 ට පෙර අනුවාදයක් ඉලක්ක කර වර්තමාන crate වලින් පිටත වර්ගයකට පරිවර්තනය කිරීමේදී පමණක් [`Into`] ක්‍රියාත්මක කරන්න.
/// `From` Rust හි අනාථ නීතිරීති නිසා පෙර සංස්කරණ වලදී මෙම ආකාරයේ පරිවර්තනයන් කිරීමට නොහැකි විය.
/// වැඩි විස්තර සඳහා [`Into`] බලන්න.
///
/// සාමාන්‍ය ශ්‍රිතයක් මත trait bounds නියම කිරීමේදී `From` භාවිතා කිරීමට වඩා [`Into`] භාවිතා කිරීමට කැමති වන්න.
/// මේ ආකාරයෙන්, [`Into`] කෙලින්ම ක්‍රියාත්මක කරන වර්ග තර්ක ලෙසද භාවිතා කළ හැකිය.
///
/// දෝෂ හැසිරවීමේදී `From` ද ඉතා ප්‍රයෝජනවත් වේ.අසමත් විය හැකි ශ්‍රිතයක් ගොඩනඟන විට, ආපසු එන වර්ගය සාමාන්‍යයෙන් `Result<T, E>` ආකාරයෙන් වනු ඇත.
/// `From` trait මඟින් දෝෂ හැසිරවීම සරල කරයි, එක් දෝෂ වර්ගයක් නැවත ඇතුළත් කිරීමට ශ්‍රිතයකට ඉඩ දීමෙන් බහු දෝෂ වර්ග ඇතුළත් වේ.වැඩි විස්තර සඳහා "Examples" කොටස සහ [the book][book] බලන්න.
///
/// **Note: මෙම trait අසමත් නොවිය යුතුය **.පරිවර්තනය අසමත් විය හැකි නම්, [`TryFrom`] භාවිතා කරන්න.
///
/// # සාමාන්‍ය ක්‍රියාත්මක කිරීම්
///
/// - `From<T> for U` T`<U>සඳහා</u> [`තුළට`] අදහස් <U>කරයි</u>
/// - `From` ප්‍රත්‍යාවර්තක වේ, එයින් අදහස් වන්නේ `From<T> for T` ක්‍රියාත්මක වන බවයි
///
/// # Examples
///
/// [`String`] `From<&str>` ක්‍රියාත්මක කරයි:
///
/// `&str` සිට නූල් දක්වා පැහැදිලි පරිවර්තනයක් පහත පරිදි සිදු කෙරේ:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// දෝෂ හැසිරවීමේදී බොහෝ විට ඔබේම දෝෂ වර්ගය සඳහා `From` ක්‍රියාත්මක කිරීම ප්‍රයෝජනවත් වේ.
/// යටින් පවතින දෝෂ වර්ගයන් අපගේ අභිරුචි දෝෂ වර්ගයට පරිවර්තනය කිරීමෙන් යටින් පවතින දෝෂ වර්ගය සංවර්‍ධනය කරයි, මූලික හේතුව පිළිබඳ තොරතුරු අහිමි නොවී අපට තනි දෝෂ වර්ගයක් ආපසු ලබා දිය හැකිය.
/// '?' ක්‍රියාකරු ස්වයංක්‍රීයව `Into<CliError>::into` ඇමතීමෙන් යටින් පවතින දෝෂ වර්ගය අපගේ අභිරුචි දෝෂ වර්ගයට පරිවර්තනය කරයි, එය `From` ක්‍රියාත්මක කිරීමේදී ස්වයංක්‍රීයව සපයනු ලැබේ.
/// ඉන්පසු සම්පාදකයා විසින් `Into` ක්‍රියාත්මක කළ යුත්තේ කුමන අනුක්‍රමයද යන්න අනුමාන කරයි.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// පරිවර්තනය සිදු කරයි.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// `self` පරිභෝජනය කිරීමට උත්සාහ කළ පරිවර්තනයක්, එය මිල අධික හෝ නොවිය හැකිය.
///
/// පුස්තකාල කතුවරුන් සාමාන්‍යයෙන් මෙම trait සෘජුවම ක්‍රියාත්මක නොකළ යුතු අතර, සම්මත පුස්තකාලයේ බ්ලැන්කට් ක්‍රියාත්මක කිරීමකට ස්තුතිවන්ත වන [`TryFrom`] trait ක්‍රියාත්මක කිරීමට වැඩි කැමැත්තක් දැක්විය යුතුය.
/// මේ පිළිබඳ වැඩි විස්තර සඳහා, [`Into`] සඳහා වන ලියකියවිලි බලන්න.
///
/// # `TryInto` ක්‍රියාත්මක කිරීම
///
/// මෙය [`Into`] ක්‍රියාත්මක කිරීමේදී සමාන සීමාවන් හා තර්ක විතර්ක වලින් පීඩා විඳිති, විස්තර සඳහා එහි බලන්න.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// පරිවර්තන දෝෂයක් ඇති වූ විට වර්ගය නැවත ලැබුණි.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// පරිවර්තනය සිදු කරයි.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// සමහර තත්වයන් යටතේ පාලිත ආකාරයකින් අසමත් විය හැකි සරල හා ආරක්ෂිත ආකාරයේ පරිවර්තනයන්.එය [`TryInto`] හි පරස්පරතාවයි.
///
/// ඔබ සුළු වශයෙන් සාර්ථක විය හැකි නමුත් විශේෂ හැසිරවීමක් අවශ්‍ය වන ආකාරයේ පරිවර්තනයක් කරන විට මෙය ප්‍රයෝජනවත් වේ.
/// උදාහරණයක් ලෙස, [`From`] trait භාවිතා කරමින් [`i64`] [`i32`] බවට පරිවර්තනය කිරීමට ක්‍රමයක් නොමැත, මන්ද [`i64`] හි [`i32`] නිරූපණය කළ නොහැකි අගයක් අඩංගු විය හැකි බැවින් පරිවර්තනයට දත්ත අහිමි වනු ඇත.
///
/// මෙය හසුරුවනු ලබන්නේ [`i64`] [`i32`] ට කප්පාදු කිරීමෙනි (මූලික වශයෙන් [`i64`] හි අගය මොඩියුලෝ [`i32::MAX`] ලබා දීම) හෝ හුදෙක් [`i32::MAX`] ආපසු යැවීමෙන් හෝ වෙනත් ක්‍රමයකින්.
/// [`From`] trait පරිපූර්ණ පරිවර්තනයන් සඳහා අදහස් කර ඇති අතර, එබැවින් `TryFrom` trait වර්ගීකරණ පරිවර්තනයක් නරක අතට හැරෙන විට ක්‍රමලේඛකයාට දන්වන අතර එය හැසිරවිය යුතු ආකාරය තීරණය කිරීමට ඔවුන්ට ඉඩ දෙයි.
///
/// # සාමාන්‍ය ක්‍රියාත්මක කිරීම්
///
/// - `TryFrom<T> for U` T <U>සඳහා</u> [`උත්සාහ කරන්න]] යන්නෙන් ගම්‍ය වේ
/// - [`try_from`] ප්‍රත්‍යාවර්තක වේ, එයින් අදහස් වන්නේ `TryFrom<T> for T` ක්‍රියාත්මක කර ඇති අතර එය අසාර්ථක විය නොහැක-`T` වර්ගයේ අගය මත `T::try_from()` ඇමතීම සඳහා සම්බන්ධිත `Error` වර්ගය [`Infallible`] වේ.
/// [`!`] වර්ගය ස්ථාවර වූ විට [`Infallible`] සහ [`!`] සමාන වේ.
///
/// `TryFrom<T>` පහත පරිදි ක්‍රියාත්මක කළ හැකිය:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// විස්තර කර ඇති පරිදි, [`i32`] විසින් `ට්‍රයිෆ්‍රොම් <` [`i64`]`>`ක්‍රියාත්මක කරයි:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // නිශ්ශබ්දව `big_number` කප්පාදු කරයි, කාරණයෙන් පසුව කප්පාදු කිරීම හඳුනා ගැනීම සහ හැසිරවීම අවශ්‍ය වේ.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // `big_number` `i32` එකකට ගැලපෙන තරමට විශාල බැවින් දෝෂයක් ලබා දෙයි.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // `Ok(3)` ලබා දෙයි.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// පරිවර්තන දෝෂයක් ඇති වූ විට වර්ගය නැවත ලැබුණි.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// පරිවර්තනය සිදු කරයි.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// සාමාන්‍ය IMPLS
////////////////////////////////////////////////////////////////////////////////

// සෝපාන අවසන් වන විට&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// &mut ට වඩා සෝපානයක් ලෙස
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): &/&mut සඳහා ඉහත සඳහන් impls පහත සඳහන් වඩාත් පොදු එකක් සමඟ ආදේශ කරන්න:
// // ඩෙරෙෆ්ට උඩින් ඔසවන විට
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U :? ප්‍රමාණය> <U>D {fn as_ref(&self) සඳහා AsRef-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut &mut ඉක්මවා යයි
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): &mut සඳහා ඉහත impl එක පහත දැක්වෙන වඩාත් පොදු එකක් සමඟ ආදේශ කරන්න:
// // AsMut ඩෙරෙෆ්මූට් හරහා ඔසවයි
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U :? ප්‍රමාණය> <U>D {fn as_mut(&mut self) සඳහා AsMut-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// සිට ගම්‍ය වේ
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// සිට (සහ ඒ අනුව) ප්‍රත්‍යාවර්තක වේ
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **ස්ථායිතා සටහන:** මෙම impl තවමත් නොපවතී, නමුත් අපි එය future තුළ එක් කිරීමට "reserving space" වේ.
/// විස්තර සඳහා [rust-lang/rust#64715][#64715] බලන්න.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): ඒ වෙනුවට ප්‍රතිපත්තිමය විසඳුමක් කරන්න.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// ට්‍රයි ෆ්‍රොම් යන්නෙන් අදහස් කරන්නේ ට්‍රයිඉන්ටෝ ය
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// වැරදිසහගත පරිවර්තනයන් ජනාවාස නොවූ දෝෂ වර්ගයක් සහිත වැරදි පරිවර්තනයන්ට අර්ථ නිරූපණයට සමාන වේ.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS කොන්ක්‍රීට් කරන්න
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// දෝෂ සහිත දෝෂ වර්ගය
////////////////////////////////////////////////////////////////////////////////

/// කිසි විටෙකත් සිදුවිය නොහැකි දෝෂ සඳහා දෝෂ වර්ගය.
///
/// මෙම එනමයට ප්‍රභේදයක් නොමැති බැවින් මෙම වර්ගයේ අගයක් කිසි විටෙකත් පැවතිය නොහැක.
/// [`Result`] භාවිතා කරන සහ දෝෂ වර්ගය පරාමිතිකරණය කරන සාමාන්‍ය API සඳහා මෙය ප්‍රයෝජනවත් විය හැකිය, ප්‍රති result ලය සැමවිටම [`Ok`] බව දැක්වීමට.
///
/// උදාහරණයක් ලෙස, [`TryFrom`] trait ([`Result`] ආපසු ලබා දෙන පරිවර්තනය) ප්‍රතිලෝම [`Into`] ක්‍රියාත්මක කිරීමක් පවතින සෑම වර්ගයකටම බ්ලැන්කට් ක්‍රියාත්මක කිරීමක් ඇත.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future අනුකූලතාව
///
/// මෙම enum ට [the `!`“never”type][never] හා සමාන භූමිකාවක් ඇත, එය Rust හි මෙම අනුවාදයේ අස්ථායි.
/// `!` ස්ථාවර වූ විට, අපි `Infallible` වර්ගයේ අන්වර්ථයක් බවට පත් කිරීමට අදහස් කරමු:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …අවසානයේදී `Infallible` අතහැර දමන්න.
///
/// කෙසේ වෙතත්, `!` සම්පුර්ණ වර්ගයක් ලෙස ස්ථාවර කිරීමට පෙර `!` සින්ටැක්ස් භාවිතා කළ හැකි එක් අවස්ථාවක් තිබේ: ශ්‍රිතයක ආපසු පැමිණීමේ වර්ගයේ ස්ථානයේ.
/// නිශ්චිතවම, වෙනස් ශ්‍රිත දර්ශක වර්ග දෙකක් සඳහා ක්‍රියාත්මක කළ හැකිය:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// `Infallible` enum වීමත් සමඟ මෙම කේතය වලංගු වේ.
/// කෙසේ වෙතත්, `Infallible` ever type සඳහා අන්වර්ථයක් බවට පත් වූ විට, මෙම impl දෙක අතිච්ඡාදනය වීමට පටන් ගන්නා අතර එම නිසා භාෂාවේ trait සහසම්බන්ධතා නීති මගින් එය තහනම් කරනු ලැබේ.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}