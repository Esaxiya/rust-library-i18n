//! `f64` ද්විත්ව නිරවද්‍යතාවයෙන් යුත් පාවෙන ලක්ෂ්‍ය වර්ගයට විශේෂිත වූ නියතයන්.
//!
//! *[See also the `f64` primitive type][f64].*
//!
//! ගණිතමය වශයෙන් සැලකිය යුතු සංඛ්‍යාවක් `consts` උප මොඩියුලයේ දක්වා ඇත.
//!
//! මෙම මොඩියුලය තුළ කෙලින්ම අර්ථ දක්වා ඇති නියතයන් සඳහා (`consts` උප මොඩියුලයේ අර්ථ දක්වා ඇති පරිදි), නව කේතය වෙනුවට `f64` වර්ගය මත කෙලින්ම අර්ථ දක්වා ඇති සම්බන්ධිත නියතයන් භාවිතා කළ යුතුය.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// `f64` හි අභ්‍යන්තර නිරූපණයේ රේඩික්ස් හෝ පදනම.
/// ඒ වෙනුවට [`f64::RADIX`] භාවිතා කරන්න.
///
/// # Examples
///
/// ```rust
/// // අතහැර දැමූ මාර්ගය
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f64::RADIX;
///
/// // අපේක්ෂිත මාර්ගය
/// let r = f64::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f64`")]
pub const RADIX: u32 = f64::RADIX;

/// 2 වන පාදයේ සැලකිය යුතු ඉලක්කම් ගණන.
/// ඒ වෙනුවට [`f64::MANTISSA_DIGITS`] භාවිතා කරන්න.
///
/// # Examples
///
/// ```rust
/// // අතහැර දැමූ මාර්ගය
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::MANTISSA_DIGITS;
///
/// // අපේක්ෂිත මාර්ගය
/// let d = f64::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f64`"
)]
pub const MANTISSA_DIGITS: u32 = f64::MANTISSA_DIGITS;

/// 10 වන පාදයේ සැලකිය යුතු ඉලක්කම් ගණන.
/// ඒ වෙනුවට [`f64::DIGITS`] භාවිතා කරන්න.
///
/// # Examples
///
/// ```rust
/// // අතහැර දැමූ මාර්ගය
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::DIGITS;
///
/// // අපේක්ෂිත මාර්ගය
/// let d = f64::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f64`")]
pub const DIGITS: u32 = f64::DIGITS;

/// [Machine epsilon] `f64` සඳහා අගය.
/// ඒ වෙනුවට [`f64::EPSILON`] භාවිතා කරන්න.
///
/// `1.0` සහ ඊළඟ විශාල නියෝජනය කළ හැකි අංකය අතර වෙනස මෙයයි.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // අතහැර දැමූ මාර්ගය
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f64::EPSILON;
///
/// // අපේක්ෂිත මාර්ගය
/// let e = f64::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f64`"
)]
pub const EPSILON: f64 = f64::EPSILON;

/// කුඩාම සීමිත `f64` අගය.
/// ඒ වෙනුවට [`f64::MIN`] භාවිතා කරන්න.
///
/// # Examples
///
/// ```rust
/// // අතහැර දැමූ මාර්ගය
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN;
///
/// // අපේක්ෂිත මාර්ගය
/// let min = f64::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f64`")]
pub const MIN: f64 = f64::MIN;

/// කුඩාම ධනාත්මක සාමාන්‍ය `f64` අගය.
/// ඒ වෙනුවට [`f64::MIN_POSITIVE`] භාවිතා කරන්න.
///
/// # Examples
///
/// ```rust
/// // අතහැර දැමූ මාර්ගය
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_POSITIVE;
///
/// // අපේක්ෂිත මාර්ගය
/// let min = f64::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f64`"
)]
pub const MIN_POSITIVE: f64 = f64::MIN_POSITIVE;

/// විශාලතම සීමිත `f64` අගය.
/// ඒ වෙනුවට [`f64::MAX`] භාවිතා කරන්න.
///
/// # Examples
///
/// ```rust
/// // අතහැර දැමූ මාර්ගය
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX;
///
/// // අපේක්ෂිත මාර්ගය
/// let max = f64::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f64`")]
pub const MAX: f64 = f64::MAX;

/// 2 on ාතයක අවම සාමාන්‍ය බලයට වඩා විශාල එකක්.
/// ඒ වෙනුවට [`f64::MIN_EXP`] භාවිතා කරන්න.
///
/// # Examples
///
/// ```rust
/// // අතහැර දැමූ මාර්ගය
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_EXP;
///
/// // අපේක්ෂිත මාර්ගය
/// let min = f64::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f64`"
)]
pub const MIN_EXP: i32 = f64::MIN_EXP;

/// On ාත 2 ක උපරිම බලය.
/// ඒ වෙනුවට [`f64::MAX_EXP`] භාවිතා කරන්න.
///
/// # Examples
///
/// ```rust
/// // අතහැර දැමූ මාර්ගය
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_EXP;
///
/// // අපේක්ෂිත මාර්ගය
/// let max = f64::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f64`"
)]
pub const MAX_EXP: i32 = f64::MAX_EXP;

/// On ාත 10 ක අවම සාමාන්‍ය බලය.
/// ඒ වෙනුවට [`f64::MIN_10_EXP`] භාවිතා කරන්න.
///
/// # Examples
///
/// ```rust
/// // අතහැර දැමූ මාර්ගය
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_10_EXP;
///
/// // අපේක්ෂිත මාර්ගය
/// let min = f64::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f64`"
)]
pub const MIN_10_EXP: i32 = f64::MIN_10_EXP;

/// On ාත 10 ක උපරිම බලය.
/// ඒ වෙනුවට [`f64::MAX_10_EXP`] භාවිතා කරන්න.
///
/// # Examples
///
/// ```rust
/// // අතහැර දැමූ මාර්ගය
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_10_EXP;
///
/// // අපේක්ෂිත මාර්ගය
/// let max = f64::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f64`"
)]
pub const MAX_10_EXP: i32 = f64::MAX_10_EXP;

/// අංක (NaN) අංකයක් නොවේ.
/// ඒ වෙනුවට [`f64::NAN`] භාවිතා කරන්න.
///
/// # Examples
///
/// ```rust
/// // අතහැර දැමූ මාර්ගය
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f64::NAN;
///
/// // අපේක්ෂිත මාර්ගය
/// let nan = f64::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f64`")]
pub const NAN: f64 = f64::NAN;

/// අනන්තය (∞).
/// ඒ වෙනුවට [`f64::INFINITY`] භාවිතා කරන්න.
///
/// # Examples
///
/// ```rust
/// // අතහැර දැමූ මාර්ගය
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f64::INFINITY;
///
/// // අපේක්ෂිත මාර්ගය
/// let inf = f64::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f64`"
)]
pub const INFINITY: f64 = f64::INFINITY;

/// 00 ණ අනන්තය (−∞).
/// ඒ වෙනුවට [`f64::NEG_INFINITY`] භාවිතා කරන්න.
///
/// # Examples
///
/// ```rust
/// // අතහැර දැමූ මාර්ගය
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f64::NEG_INFINITY;
///
/// // අපේක්ෂිත මාර්ගය
/// let ninf = f64::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f64`"
)]
pub const NEG_INFINITY: f64 = f64::NEG_INFINITY;

/// මූලික ගණිත නියතයන්.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: cmath සිට ගණිතමය නියතයන් සමඟ ආදේශ කරන්න.

    /// ආකිමිඩීස් නියත (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f64 = 3.14159265358979323846264338327950288_f64;

    /// සම්පූර්ණ රවුම් නියතය (τ)
    ///
    /// 2π ට සමාන වේ.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f64 = 6.28318530717958647692528676655900577_f64;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f64 = 1.57079632679489661923132169163975144_f64;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f64 = 1.04719755119659774615421446109316763_f64;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f64 = 0.785398163397448309615660845819875721_f64;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f64 = 0.52359877559829887307710723054658381_f64;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f64 = 0.39269908169872415480783042290993786_f64;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f64 = 0.318309886183790671537767526745028724_f64;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f64 = 0.636619772367581343075535053490057448_f64;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f64 = 1.12837916709551257389615890312154517_f64;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f64 = 1.41421356237309504880168872420969808_f64;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f64 = 0.707106781186547524400844362104849039_f64;

    /// අයිලර්ගේ අංකය (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f64 = 2.71828182845904523536028747135266250_f64;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f64 = 3.32192809488736234787031942948939018_f64;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f64 = 1.44269504088896340735992468100189214_f64;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f64 = 0.301029995663981195213738894724493027_f64;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f64 = 0.434294481903251827651128918916605082_f64;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f64 = 0.693147180559945309417232121458176568_f64;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f64 = 2.30258509299404568401799145468436421_f64;
}

#[lang = "f64"]
#[cfg(not(test))]
impl f64 {
    /// `f64` හි අභ්‍යන්තර නිරූපණයේ රේඩික්ස් හෝ පදනම.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// 2 වන පාදයේ සැලකිය යුතු ඉලක්කම් ගණන.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 53;
    /// 10 වන පාදයේ සැලකිය යුතු ඉලක්කම් ගණන.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 15;

    /// [Machine epsilon] `f64` සඳහා අගය.
    ///
    /// `1.0` සහ ඊළඟ විශාල නියෝජනය කළ හැකි අංකය අතර වෙනස මෙයයි.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f64 = 2.2204460492503131e-16_f64;

    /// කුඩාම සීමිත `f64` අගය.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f64 = -1.7976931348623157e+308_f64;
    /// කුඩාම ධනාත්මක සාමාන්‍ය `f64` අගය.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f64 = 2.2250738585072014e-308_f64;
    /// විශාලතම සීමිත `f64` අගය.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f64 = 1.7976931348623157e+308_f64;

    /// 2 on ාතයක අවම සාමාන්‍ය බලයට වඩා විශාල එකක්.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -1021;
    /// On ාත 2 ක උපරිම බලය.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 1024;

    /// On ාත 10 ක අවම සාමාන්‍ය බලය.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -307;
    /// On ාත 10 ක උපරිම බලය.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 308;

    /// අංක (NaN) අංකයක් නොවේ.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f64 = 0.0_f64 / 0.0_f64;
    /// අනන්තය (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f64 = 1.0_f64 / 0.0_f64;
    /// 00 ණ අනන්තය (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f64 = -1.0_f64 / 0.0_f64;

    /// මෙම අගය `NaN` නම් `true` ලබා දෙයි.
    ///
    /// ```
    /// let nan = f64::NAN;
    /// let f = 7.0_f64;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): අතේ ගෙන යා හැකි බව නිසා `abs` ප්‍රසිද්ධියේ ලිබ්කෝර් හි නොමැත, එබැවින් මෙම ක්‍රියාත්මක කිරීම අභ්‍යන්තරව පුද්ගලික භාවිතය සඳහා වේ.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f64 {
        f64::from_bits(self.to_bits() & 0x7fff_ffff_ffff_ffff)
    }

    /// මෙම අගය ධනාත්මක අනන්තය හෝ negative ණ අනන්තය නම් `true` සහ වෙනත් ආකාරයකින් `false` ලබා දෙයි.
    ///
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf = f64::INFINITY;
    /// let neg_inf = f64::NEG_INFINITY;
    /// let nan = f64::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// මෙම අංකය අනන්ත හෝ `NaN` නොවේ නම් `true` ලබා දෙයි.
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf: f64 = f64::INFINITY;
    /// let neg_inf: f64 = f64::NEG_INFINITY;
    /// let nan: f64 = f64::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // NaN වෙන වෙනම හැසිරවීමේ අවශ්‍යතාවයක් නොමැත: ස්වයං NaN නම්, සංසන්දනය සත්‍ය නොවේ, හරියටම අපේක්ෂිත පරිදි.
        //
        self.abs_private() < Self::INFINITY
    }

    /// අංකය [subnormal] නම් `true` ලබා දෙයි.
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308_f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0_f64;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f64::NAN.is_subnormal());
    /// assert!(!f64::INFINITY.is_subnormal());
    /// // `0` සහ `min` අතර අගයන් උප සාමාන්‍ය වේ.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// අංකය ශුන්‍ය, අනන්ත, [subnormal], හෝ `NaN` නොවේ නම් `true` ලබා දෙයි.
    ///
    ///
    /// ```
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0f64;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f64::NAN.is_normal());
    /// assert!(!f64::INFINITY.is_normal());
    /// // `0` සහ `min` අතර අගයන් උප සාමාන්‍ය වේ.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// අංකයේ පාවෙන ලක්ෂ්‍ය කාණ්ඩය ලබා දෙයි.
    /// එක් දේපලක් පමණක් පරීක්ෂා කිරීමට යන්නේ නම්, ඒ වෙනුවට නිශ්චිත පුරෝකථනය භාවිතා කිරීම සාමාන්‍යයෙන් වේගවත් වේ.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f64;
    /// let inf = f64::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u64 = 0x7ff0000000000000;
        const MAN_MASK: u64 = 0x000fffffffffffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// `+0.0`, ධනාත්මක සං sign ා බිට් සහ ධනාත්මක අනන්තය සහිත 'NaN` ඇතුළු `self` ට ධනාත්මක ලකුණක් තිබේ නම් `true` ලබා දෙයි.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_positive")]
    #[inline]
    #[doc(hidden)]
    pub fn is_positive(self) -> bool {
        self.is_sign_positive()
    }

    /// `self` හි X ණ ලකුණක් තිබේ නම්, `-0.0`, Na ණ සං sign ා බිට් සහ Na ණ අනන්තය සහිත NaN ගේ නම් `true` ලබා දෙයි.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        self.to_bits() & 0x8000_0000_0000_0000 != 0
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_negative")]
    #[inline]
    #[doc(hidden)]
    pub fn is_negative(self) -> bool {
        self.is_sign_negative()
    }

    /// අංකයක පරස්පර (inverse) ගනී, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f64;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f64 {
        1.0 / self
    }

    /// රේඩියන්ස් අංශක බවට පරිවර්තනය කරයි.
    ///
    /// ```
    /// let angle = std::f64::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_degrees(self) -> f64 {
        // 180/of හි සත්‍ය වටිනාකමට සාපේක්ෂව මෙහි බෙදීම නිවැරදිව වටකුරු කර ඇත.
        // (මෙය f32 ට වඩා වෙනස් වේ, නිවැරදිව වටකුරු ප්‍රති result ලයක් සහතික කිරීම සඳහා නියතයක් භාවිතා කළ යුතුය.)
        //
        self * (180.0f64 / consts::PI)
    }

    /// උපාධි රේඩියන බවට පරිවර්තනය කරයි.
    ///
    /// ```
    /// let angle = 180.0_f64;
    ///
    /// let abs_difference = (angle.to_radians() - std::f64::consts::PI).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_radians(self) -> f64 {
        let value: f64 = consts::PI;
        self * (value / 180.0)
    }

    /// ඉලක්කම් දෙකේ උපරිමය ලබා දෙයි.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// එක් තර්කයක් NaN නම්, අනෙක් තර්කය නැවත ලබා දෙනු ලැබේ.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f64) -> f64 {
        intrinsics::maxnumf64(self, other)
    }

    /// ඉලක්කම් දෙකේ අවම අගය ලබා දෙයි.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// එක් තර්කයක් NaN නම්, අනෙක් තර්කය නැවත ලබා දෙනු ලැබේ.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f64) -> f64 {
        intrinsics::minnumf64(self, other)
    }

    /// අගය සීමිත බවත් එම වර්ගයට ගැලපෙන බවත් උපකල්පනය කරමින් ශුන්‍ය දෙසට ගමන් කර ඕනෑම ප්‍රාථමික නිඛිල වර්ගයකට පරිවර්තනය වේ.
    ///
    ///
    /// ```
    /// let value = 4.6_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// වටිනාකම කළ යුත්තේ:
    ///
    /// * `NaN` නොවිය යුතුය
    /// * අනන්ත නොවන්න
    /// * එහි භාගික කොටස කපා දැමීමෙන් පසු ආපසු එන වර්ගයේ `Int` හි නිරූපණය කරන්න
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // ආරක්ෂාව: අමතන්නා `FloatToInt::to_int_unchecked` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// `u64` වෙත අමු සම්ප්‍රේෂණය.
    ///
    /// මෙය දැනට සියලුම වේදිකා වල `transmute::<f64, u64>(self)` ට සමාන වේ.
    ///
    /// මෙම මෙහෙයුමේ අතේ ගෙන යා හැකි ආකාරය පිළිබඳ යම් සාකච්ඡාවක් සඳහා `from_bits` බලන්න (කිසිදු ගැටළුවක් නොමැත).
    ///
    /// මෙම ශ්‍රිතය `as` වාත්තුකරණයට වඩා වෙනස් බව සලකන්න, එය *සංඛ්‍යාත්මක* අගය ආරක්ෂා කිරීමට උත්සාහ කරන අතර එය බිටුස් අගය නොවේ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((1f64).to_bits() != 1f64 as u64); // to_bits() වාත්තු කිරීමක් නොවේ!
    /// assert_eq!((12.5f64).to_bits(), 0x4029000000000000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u64 {
        // ආරක්ෂාව: `u64` යනු පැරණි දත්ත සමුදායක් බැවින් අපට සෑම විටම එයට සම්ප්‍රේෂණය කළ හැකිය
        unsafe { mem::transmute(self) }
    }

    /// `u64` වෙතින් අමු සම්ප්‍රේෂණය.
    ///
    /// මෙය දැනට සියලුම වේදිකා වල `transmute::<u64, f64>(v)` ට සමාන වේ.
    /// හේතු දෙකක් නිසා මෙය ඇදහිය නොහැකි තරම් අතේ ගෙන යා හැකි බව පෙනේ:
    ///
    /// * සියලුම ආධාරක වේදිකාවල පාවෙන සහ ඉන්ටස් එකම අන්තරායක් ඇත.
    /// * IEEE-754 ඉතා නිවැරදිව පාවෙන බිට් පිරිසැලසුම නියම කරයි.
    ///
    /// කෙසේ වෙතත් එක් අවවාදයක් ඇත: 2008 IEEE-754 අනුවාදයට පෙර, NaN සං sign ා බිට් අර්ථ නිරූපණය කරන්නේ කෙසේද යන්න සැබවින්ම නිශ්චිතව දක්වා නැත.
    /// බොහෝ වේදිකා (විශේෂයෙන් x86 සහ ARM) 2008 දී ප්‍රමිතිගත කළ අර්ථ නිරූපණය තෝරා ගත් නමුත් සමහර ඒවා (විශේෂයෙන් MIPS) නොවීය.
    /// මෙහි ප්‍රති As ලයක් වශයෙන්, MIPS හි ඇති සියලුම සං N ා NaNs x86 හි නිහ Na NaNs වන අතර අනෙක් අතට.
    ///
    /// සං sign ා-නෙස් හරස් වේදිකාව ආරක්ෂා කිරීමට උත්සාහ කරනවා වෙනුවට, මෙම ක්‍රියාවට නැංවීම නිශ්චිත බිටු ආරක්ෂා කිරීමට කැමැත්තක් දක්වයි.
    /// මෙයින් අදහස් කරන්නේ මෙම ක්‍රමයේ ප්‍රති result ලය ජාලය හරහා x86 යන්ත්‍රයකින් MIPS එකකට යවනු ලැබුවද NaNs හි කේතනය කර ඇති ඕනෑම ගෙවීමක් සුරැකෙනු ඇති බවයි.
    ///
    ///
    /// මෙම ක්‍රමයේ ප්‍රති results ල හසුරුවන්නේ ඒවා නිපදවූ එකම ගෘහ නිර්මාණ ශිල්පය මගින් නම්, එහා මෙහා ගෙන යා හැකි සැලකිල්ලක් නොමැත.
    ///
    /// ආදානය NaN නොවේ නම්, එහා මෙහා ගෙන යා හැකි සැලකිල්ලක් නොමැත.
    ///
    /// ඔබ සං sign ා-නෙස් (බොහෝ දුරට ඉඩ) ගැන සැලකිලිමත් නොවන්නේ නම්, එහා මෙහා ගෙන යා හැකි සැලකිල්ලක් නොමැත.
    ///
    /// මෙම ශ්‍රිතය `as` වාත්තුකරණයට වඩා වෙනස් බව සලකන්න, එය *සංඛ්‍යාත්මක* අගය ආරක්ෂා කිරීමට උත්සාහ කරන අතර එය බිටුස් අගය නොවේ.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f64::from_bits(0x4029000000000000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u64) -> Self {
        // ආරක්ෂාව: `u64` යනු පැරණි දත්ත සමුදායක් බැවින් අපට සෑම විටම එයින් සම්ප්‍රේෂණය කළ හැකිය
        // එයින් පෙනෙන්නේ sNaN සමඟ ඇති ආරක්‍ෂිත ගැටලු අධික ලෙස පිපිරී ඇති බවයි!හුරේ!
        unsafe { mem::transmute(v) }
    }

    /// බිග්-එන්ඩියන් (network) බයිට් අනුපිළිවෙලින් බයිට් අරාවක් ලෙස මෙම පාවෙන ලක්ෂ්‍ය අංකයේ මතක නිරූපණය නැවත ලබා දෙන්න.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_be_bytes();
    /// assert_eq!(bytes, [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 8] {
        self.to_bits().to_be_bytes()
    }

    /// මෙම පාවෙන ලක්ෂ්‍ය අංකයේ මතක නිරූපණය කුඩා-එන්ඩියන් බයිට් අනුපිළිවෙලින් බයිට් අරා ලෙස ආපසු එවන්න.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 8] {
        self.to_bits().to_le_bytes()
    }

    /// ස්වදේශික බයිට් අනුපිළිවෙලින් බයිට් අරාවක් ලෙස මෙම පාවෙන ලක්ෂ්‍ය අංකයේ මතක නිරූපණය නැවත ලබා දෙන්න.
    ///
    /// ඉලක්කගත වේදිකාවේ ස්වදේශීය එන්ඩියනස් භාවිතා වන බැවින්, අතේ ගෙන යා හැකි කේතය සුදුසු පරිදි [`to_be_bytes`] හෝ [`to_le_bytes`] භාවිතා කළ යුතුය.
    ///
    ///
    /// [`to_be_bytes`]: f64::to_be_bytes
    /// [`to_le_bytes`]: f64::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 8] {
        self.to_bits().to_ne_bytes()
    }

    /// ස්වදේශික බයිට් අනුපිළිවෙලින් බයිට් අරාවක් ලෙස මෙම පාවෙන ලක්ෂ්‍ය අංකයේ මතක නිරූපණය නැවත ලබා දෙන්න.
    ///
    ///
    /// [`to_ne_bytes`] හැකි සෑම විටම මෙයට වඩා කැමති විය යුතුය.
    ///
    /// [`to_ne_bytes`]: f64::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f64;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 8] {
        // ආරක්ෂාව: `f64` යනු පැරණි දත්ත සමුදායක් බැවින් අපට සෑම විටම එයට සම්ප්‍රේෂණය කළ හැකිය
        unsafe { &*(self as *const Self as *const _) }
    }

    /// විශාල එන්ඩියන් බයිට් අරා ලෙස එහි නිරූපණයෙන් පාවෙන ලක්ෂ්‍ය අගයක් සාදන්න.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_be_bytes([0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_be_bytes(bytes))
    }

    /// කුඩා එන්ඩියන් බයිට් අරා ලෙස එහි නිරූපණයෙන් පාවෙන ලක්ෂ්‍ය අගයක් සාදන්න.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_le_bytes([0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_le_bytes(bytes))
    }

    /// ස්වදේශීය එන්ඩියන් බයිට් අරා ලෙස එහි නිරූපණයෙන් පාවෙන ලක්ෂ්‍ය අගයක් සාදන්න.
    ///
    /// ඉලක්කගත වේදිකාවේ ස්වදේශීය එන්ඩියනස් භාවිතා වන බැවින්, අතේ ගෙන යා හැකි කේතයට සුදුසු පරිදි [`from_be_bytes`] හෝ [`from_le_bytes`] භාවිතා කිරීමට අවශ්‍ය වේ.
    ///
    ///
    /// [`from_be_bytes`]: f64::from_be_bytes
    /// [`from_le_bytes`]: f64::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_ne_bytes(bytes))
    }

    /// ස්වයං සහ වෙනත් අගයන් අතර ඇණවුමක් ලබා දෙයි.
    /// පාවෙන ලක්ෂ්‍ය සංඛ්‍යා අතර සම්මත අර්ධ සංසන්දනය මෙන් නොව, මෙම සංසන්දනය සෑම විටම IEEE 754 (2008 සංශෝධන) පාවෙන ලක්ෂ්‍ය ප්‍රමිතියේ අර්ථ දක්වා ඇති පරිදි සමස්ත ඕර්ඩර් අනාවැකි අනුව අනුපිළිවෙලක් නිපදවයි.
    /// අගයන් පහත අනුපිළිවෙලට ඇණවුම් කර ඇත:
    /// - නිශ්ශබ්ද නිහ Na NaN
    /// - N ණාත්මක සං sign ා NaN
    /// - සෘණ අනන්තය
    /// - සෘණ අංක
    /// - Sub ණ උප අසාමාන්‍ය සංඛ්‍යා
    /// - සෘණ ශුන්‍යය
    /// - ධනාත්මක ශුන්‍යය
    /// - ධනාත්මක උප අසාමාන්‍ය සංඛ්‍යා
    /// - ධනාත්මක අංක
    /// - ධනාත්මක අනන්තය
    /// - ධනාත්මක සං aling ා NaN
    /// - ධනාත්මක නිහ quiet NaN
    ///
    /// මෙම ශ්‍රිතය සෑම විටම `f64` හි [`PartialOrd`] සහ [`PartialEq`] ක්‍රියාත්මක කිරීම් සමඟ එකඟ නොවන බව සලකන්න.විශේෂයෙන්, ඔවුන් negative ණාත්මක හා ධනාත්මක ශුන්‍යය සමාන යැයි සලකන අතර `total_cmp` එසේ නොවේ.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f64,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f64::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f64::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f64::INFINITY, f64::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i64;
        let mut right = other.to_bits() as i64;

        // නිෂේධනීය අවස්ථාවන්හිදී, දෙදෙනෙකුගේ අනුපූරක සංඛ්‍යා ලෙස සමාන පිරිසැලසුමක් ලබා ගැනීම සඳහා ලකුණ හැර අනෙක් සියලුම බිටු පෙරළන්න
        //
        // මෙය ක්‍රියාත්මක වන්නේ ඇයි?IEEE 754 පාවෙන ක්ෂේත්‍ර තුනකින් සමන්විත වේ:
        // සං bit ා බිට්, on ාතීය සහ මැන්ටිස්සා.සමස්තයක් ලෙස on ාතීය හා මැන්ටිස්සා ක්‍ෂේත්‍ර සමූහයට ඒවායේ බිටුස් අනුපිළිවෙල විශාලත්වය අර්ථ දක්වා ඇති සංඛ්‍යාත්මක විශාලත්වයට සමාන වේ.
        // විශාලත්වය සාමාන්‍යයෙන් NaN අගයන් මත අර්ථ දක්වා නැත, නමුත් IEEE 754 totalOrder විසින් NaN අගයන් ද අර්ථ දක්වයි.මෙය ලේඛ ලේඛනයේ විස්තර කර ඇති අනුපිළිවෙලට මග පාදයි.
        // කෙසේ වෙතත්, විශාලත්වය නිරූපණය negative ණ හා ධනාත්මක සංඛ්‍යා සඳහා සමාන වේ-සං bit ා බිට් පමණක් වෙනස් වේ.
        // අත්සන් කළ නිඛිල ලෙස පාවෙන පහසුවෙන් සංසන්දනය කිරීම සඳහා, negative ණ සංඛ්‍යා වලදී අපි on ාතීය සහ මැන්ටිස්සා බිටු පෙරළා දැමිය යුතුය.
        // අපි effectively ලදායී ලෙස අංක "two's complement" ආකෘතියට පරිවර්තනය කරමු.
        //
        // පෙරළීම සිදු කිරීම සඳහා, අපි එයට එරෙහිව වෙස් මුහුණක් සහ XOR සාදන්නෙමු.
        // Negative ණ-අත්සන් කළ අගයන්ගෙන් අපි "all-ones except for the sign bit" ආවරණයක් ශාඛා රහිතව ගණනය කරමු: දකුණට මාරුවීමේ සං sign ාව පූර්ණ සංඛ්‍යා විස්තාරණය කරයි, එබැවින් අපි සං 0 ා බිටු සහිත වෙස්මුහුණ "fill" කර, පසුව තවත් ශුන්‍ය බිට් එකක් තල්ලු කිරීම සඳහා අත්සන් නොකළ බවට පරිවර්තනය කරමු.
        //
        // ධනාත්මක අගයන් මත, වෙස්මුහුණ සියල්ලම ශුන්‍ය වේ, එබැවින් එය විවෘත නොවේ.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 63) as u64) >> 1) as i64;
        right ^= (((right >> 63) as u64) >> 1) as i64;

        left.cmp(&right)
    }

    /// NaN නොවේ නම් අගය යම් කාල පරතරයකට සීමා කරන්න.
    ///
    /// `self` `max` ට වඩා වැඩි නම් `max` ද, `self` `min` ට වඩා අඩු නම් `min` ද ලබා දෙයි.
    /// එසේ නොමැතිනම් මෙය `self` ආපසු ලබා දෙයි.
    ///
    /// ආරම්භක අගය NaN නම් මෙම ශ්‍රිතය NaN නැවත ලබා දෙන බව සලකන්න.
    ///
    /// # Panics
    ///
    /// Panics නම් `min > max`, `min` NaN, හෝ `max` NaN වේ.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f64).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f64).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f64).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f64::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f64, max: f64) -> f64 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}