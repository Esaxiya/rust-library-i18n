//! On ාතීය තක්සේරුකරු.

/// `10^(k_0-1) < mant * 2^exp <= 10^(k_0+1)` වැනි `k_0` සොයා ගනී.
///
/// මෙය දළ වශයෙන් `k = ceil(log_10 (mant * 2^exp))` සඳහා භාවිතා කරයි;
/// සත්‍ය `k` යනු `k_0` හෝ `k_0+1` වේ.
#[doc(hidden)]
pub fn estimate_scaling_factor(mant: u64, exp: i16) -> i16 {
    // 2 ^ (nbits-1) <mant <=2 ^ nbits නම් mant> 0
    let nbits = 64 - (mant - 1).leading_zeros() as i64;
    // 1292913986= floor(2^32 * log_10 2) එබැවින් මෙය සැමවිටම අවතක්සේරු කරයි (හෝ හරියටම), නමුත් බොහෝ නොවේ.
    //
    (((nbits + exp as i64) * 1292913986) >> 32) as i16
}