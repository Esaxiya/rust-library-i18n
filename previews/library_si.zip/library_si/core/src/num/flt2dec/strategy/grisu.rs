//! Grisu3 ඇල්ගොරිතමයේ Rust අනුවර්තනය "පාවෙන ලක්ෂ්‍ය අංක මුද්‍රණය කිරීම ඉක්මණින් හා නිවැරදිව පූර්ණ සංඛ්‍යා සමඟ" [^ 1].
//! එය පෙර සැකසූ වගුවේ 1KB පමණ භාවිතා කරන අතර අනෙක් අතට බොහෝ යෙදවුම් සඳහා එය ඉතා ඉක්මන් වේ.
//!
//! [^1]: Florian ලොයිට්ෂ්.2010. පාවෙන ලක්ෂ්‍ය අංක ඉක්මනින් මුද්‍රණය කිරීම සහ
//!   පූර්ණ සංඛ්‍යා සමඟ නිවැරදිව.සිග්ලන් නැත.45, 6 (2010 ජූනි), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// තාර්කිකත්වය සඳහා `format_shortest_opt` හි අදහස් බලන්න.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// `x > 0` ලබා දී, `10^k <= x < 10^(k+1)` වැනි `(k, 10^k)` ලබා දෙයි.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// ග්‍රිසු සඳහා කෙටිම මාදිලිය ක්‍රියාත්මක කිරීම.
///
/// එය වෙනත් ආකාරයකින් නිරවද්‍ය නිරූපණයක් ලබා දෙන විට එය `None` ලබා දෙයි.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // අපට අවම වශයෙන් බිටු තුනක්වත් අවශ්‍ය වේ

    // හවුල් on ාතයක් සමඟ සාමාන්‍යකරණය කළ අගයන් සමඟ ආරම්භ කරන්න
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // `ALPHA <= minusk + plus.e + 64 <= GAMMA` වැනි ඕනෑම `cached = 10^minusk` සොයා ගන්න.
    // `plus` සාමාන්‍යකරණය වී ඇති බැවින්, මෙයින් අදහස් කරන්නේ `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // අපගේ තේරීම් `ALPHA` සහ `GAMMA` අනුව, මෙය `plus * cached` `[4, 2^32)` බවට පත් කරයි.
    //
    // `GAMMA - ALPHA` උපරිම කිරීම පැහැදිලිවම යෝග්‍ය වේ, එවිට අපට 10 හැඹිලි බලයන් අවශ්‍ය නොවේ, නමුත් සලකා බැලිය යුතු කරුණු කිහිපයක් තිබේ:
    //
    //
    // 1. අපට මිල අධික බෙදීමක් අවශ්‍ය බැවින් `floor(plus * cached)` `u32` තුළ තබා ගැනීමට අපට අවශ්‍යය.
    //    (මෙය සැබවින්ම වළක්වා ගත නොහැක, ඉතිරිය නිරවද්‍යතාව තක්සේරු කිරීම සඳහා අවශ්‍ය වේ.)
    // 2.
    // `floor(plus * cached)` හි ඉතිරි කොටස නැවත නැවත 10 කින් ගුණ කළ විට එය පිටාර ගැලීම නොකළ යුතුය.
    //
    // පළමුවැන්න `64 + GAMMA <= 32` ලබා දෙන අතර දෙවැන්න `10 * 2^-ALPHA <= 2^64` ලබා දෙයි;
    // -60 සහ -32 යනු මෙම සීමාව සහිත උපරිම පරාසය වන අතර V8 ද ඒවා භාවිතා කරයි.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // පරිමාණ fps.මෙය 1 ulp හි උපරිම දෝෂය ලබා දෙයි (ප්‍රමේය 5.1 වෙතින් සනාථ වේ).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-සත්‍ය පරාසය us ණ
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // `minus` ට ඉහළින්, `v` සහ `plus` යනු *ප්‍රමාණාත්මක* ආසන්න කිරීම් (දෝෂ <1 ulp) වේ.
    // දෝෂය ධනාත්මක හෝ negative ණාත්මක බව අප නොදන්නා බැවින්, අපි සමාන පරතරයන් දෙකක් භාවිතා කරන අතර උපරිම දෝෂ 2 ක් ඇත.
    //
    // "unsafe region" යනු අප මුලින් ජනනය කරන ලිබරල් පරතරයකි.
    // "safe region" යනු අප පිළිගන්නා සම්ප්‍රදායික පරතරයකි.
    // අපි අනාරක්ෂිත කලාපය තුළ නිවැරදි repr සමඟ ආරම්භ කර ආරක්ෂිත කලාපය තුළ ඇති `v` වෙත ආසන්නතම repr සොයා ගැනීමට උත්සාහ කරමු.
    // අපට නොහැකි නම්, අපි අත්හරිමු.
    //
    let plus1 = plus.f + 1;
    // plus0 = plus.f, 1;//පැහැදිලි කිරීම සඳහා පමණක් minus0 = minus.f + 1;//පැහැදිලි කිරීම සඳහා පමණි
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // හවුල් on ාතයක්

    // `plus1` සමෝධානික හා භාගික කොටස් වලට බෙදන්න.
    // හැඹිලි බලය `plus < 2^32` සහතික කරන බැවින් සහ නිරවද්‍යතාව නිසා සාමාන්‍යකරණය කරන ලද `plus.f` සෑම විටම `2^64 - 2^4` ට වඩා අඩු බැවින් සමෝධානික කොටස් u32 වලට ගැලපෙන බවට සහතික වේ.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // විශාලතම `10^max_kappa` `plus1` ට නොඅඩු ගණනය කරන්න (මේ අනුව `plus1 < 10^(max_kappa+1)`).
    // මෙය පහළ `kappa` හි ඉහළ සීමාවකි.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // 6.2 ප්‍රමේයය: `k` යනු විශාලතම පූර්ණ සංඛ්‍යා වේ නම්
    // `0 <= y mod 10^k <= y - x`,              එවිට `V = floor(y / 10^k) * 10^k` යනු `[x, y]` හි වන අතර එම පරාසය තුළ ඇති කෙටිම නිරූපණයන්ගෙන් (සැලකිය යුතු ඉලක්කම් අවම සංඛ්‍යාවක් සහිතව).
    //
    //
    // 6.2 ප්‍රමේයයට අනුව `(minus1, plus1)` අතර ඉලක්කම් දිග `kappa` සොයා ගන්න.
    // `y mod 10^k < y - x` අවශ්‍ය වීමෙන් `x` බැහැර කිරීම සඳහා 6.2 ප්‍රමේයය භාවිතා කළ හැකිය.
    // (උදා: `x` =32000, `y` =32777; `kappa` =2 සිට `y mod 10 ^ 3=777 <y, x=777`.) ඇල්ගොරිතම `y` බැහැර කිරීම සඳහා පසුකාලීන සත්‍යාපන අවධිය මත රඳා පවතී.
    //
    let delta1 = plus1 - minus1;
    // usize ලෙස delta1int=(delta1>> e) ඉඩ දෙන්න;//පැහැදිලි කිරීම සඳහා පමණි
    let delta1frac = delta1 & ((1 << e) - 1);

    // එක් එක් පියවරේදී නිරවද්‍යතාවය පරීක්ෂා කරන අතරම, සමෝධානික කොටස් ඉදිරිපත් කරන්න.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // ඉලක්කම් තවම විදහා දැක්විය නොහැක
    loop {
        // `plus1 >= 10^kappa` ආක්‍රමණ ලෙස අපට සෑම විටම අවම වශයෙන් එක් ඉලක්කම් වත් ඉදිරිපත් කිරීමට ඇත:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (එය `remainder = plus1int % 10^(kappa+1)` අනුගමනය කරයි)
        //
        //

        // `remainder` `10^kappa` මගින් බෙදන්න.දෙකම `2^-e` මගින් පරිමාණය කර ඇත.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ කප්පා) * 2 ^ ඊ
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; අපි නිවැරදි `kappa` සොයාගෙන ඇත.
            let ten_kappa = (ten_kappa as u64) << e; // පරිමාණය 10 ^ කප්පා හවුල් on ාතකය වෙත ආපසු යන්න
            return round_and_weed(
                // ආරක්ෂාව: අපි ඉහත මතකය ආරම්භ කළෙමු.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // අපි සියලු අනුකලනය කළ විට ලූපය බිඳ දමන්න.
        // නිශ්චිත ඉලක්කම් සංඛ්‍යාව `max_kappa + 1` ලෙස `plus1 < 10^(max_kappa+1)` වේ.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // ආක්‍රමණ ප්‍රතිස්ථාපනය කරන්න
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // එක් එක් පියවරේදී නිරවද්‍යතාවය පරීක්ෂා කරන අතරතුර භාගික කොටස් ඉදිරිපත් කරන්න.
    // බෙදීම් වල නිරවද්‍යතාවය නැති වන බැවින් මෙවර අපි නැවත නැවත ගුණ කිරීම මත රඳා සිටිමු.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // `m = max_kappa + 1` (සමෝධානික කොටසේ ඉලක්කම්#) ඇති ආක්‍රමණ බිඳ දැමීමට පෙර අප විසින් පරීක්ෂා කර ඇති පරිදි ඊළඟ ඉලක්කම් වැදගත් විය යුතුය.
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // පිටාර ගැලෙන්නේ නැත, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // `remainder` `10^kappa` මගින් බෙදන්න.
        // දෙකම `2^e / 10^kappa` මගින් පරිමාණය කර ඇත, එබැවින් දෙවැන්න මෙහි ගම්‍ය වේ.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // ව්‍යංග බෙදුම්කරු
            return round_and_weed(
                // ආරක්ෂාව: අපි ඉහත මතකය ආරම්භ කළෙමු.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // ආක්‍රමණ ප්‍රතිස්ථාපනය කරන්න
        kappa -= 1;
        remainder = r;
    }

    // අපි `plus1` හි සියලු වැදගත් ඉලක්කම් ජනනය කර ඇත්තෙමු, නමුත් එය ප්‍රශස්ත එකක් දැයි විශ්වාස නැත.
    // උදාහරණයක් ලෙස, `minus1` 3.14153 ... සහ `plus1` 3.14158 ... නම්, 3.14154 සිට 3.14158 දක්වා වෙනස් කෙටිම නිරූපණයන් 5 ක් ඇත, නමුත් අපට ඇත්තේ විශාලතම එක පමණි.
    // අපට අවසාන ඉලක්කම් අනුපිළිවෙලින් අඩු කළ යුතු අතර මෙය ප්‍රශස්ත repr ද යන්න පරීක්ෂා කළ යුතුය.
    // අපේක්ෂකයින් 9 දෙනෙකු (..1 සිට ..9 දක්වා) සිටින බැවින් මෙය තරමක් ඉක්මන් වේ.("rounding" අදියර)
    //
    // මෙම "optimal" repr ඇත්ත වශයෙන්ම ulp පරාසයන් තුළ තිබේදැයි ශ්‍රිතය පරික්ෂා කරයි, එසේම, වටකුරු දෝෂය හේතුවෙන් "second-to-optimal" repr සැබවින්ම ප්‍රශස්ත විය හැකිය.
    // මෙම අවස්ථා දෙකේදීම මෙය `None` ලබා දෙයි.
    // ("weeding" අදියර)
    //
    // මෙහි ඇති සියලුම තර්ක පොදු (නමුත් ව්‍යංග) `k` අගය මගින් පරිමාණය කර ඇත, එබැවින්:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (තවද, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (තවද, පෙර ආක්‍රමණ වලින් `threshold > plus1v`)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // 1.5 ulps තුළ `v` (සැබවින්ම `plus1 - v`) සඳහා ආසන්න අගයන් දෙකක් නිපදවන්න.
        // එහි ප්‍රති ing ලයක් ලෙස නිරූපණය දෙකටම ආසන්නතම නිරූපණය විය යුතුය.
        //
        // overflow/underflow වළක්වා ගැනීම සඳහා `plus1` සම්බන්ධයෙන් ගණනය කිරීම් සිදුකරන බැවින් මෙහි `plus1 - v` භාවිතා වේ (එබැවින් හුවමාරු වූ බවක් පෙනේ).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // අවසාන ඉලක්කම් අඩු කර `v + 1 ulp` වෙත ආසන්නතම නිරූපණය නතර කරන්න.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // අපි දළ වශයෙන් `w(n)` ඉලක්කම් සමඟ වැඩ කරන්නෙමු, එය මුලින් `plus1 - plus1 % 10^kappa` ට සමාන වේ.ලූප් බොඩි `n` වාරයක් ධාවනය කිරීමෙන් පසු, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // අපි චෙක්පත් සරල කිරීම සඳහා `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (මේ අනුව `ඉතිරි= plus1w(0)`) 'සකසා ඇත්තෙමු.
            // `plus1w(n)` සෑම විටම වැඩි වන බව සලකන්න.
            //
            // අවසන් කිරීමට අපට කොන්දේසි තුනක් තිබේ.ඒවායින් ඕනෑම එකක් ඉදිරියට යාමට නොහැකි වනු ඇත, නමුත් අපට අවම වශයෙන් එක් වලංගු නිරූපණයක්වත් `v + 1 ulp` ට කෙසේ හෝ සමීප වේ.
            // සංක්ෂිප්තතාව සඳහා අපි ඒවා TC1 ලෙස TC3 හරහා දක්වන්නෙමු.
            //
            // TC1: `w(n) <= v + 1 ulp`, එනම්, මෙය ආසන්නතම එකක් විය හැකි අවසාන repr ය.
            // මෙය `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up` ට සමාන වේ.
            // TC2 සමඟ සංයෝජනය වී ඇති අතර (එය `w(n+1)` is valid) දැයි පරික්ෂා කරයි, මෙය `plus1w(n)` ගණනය කිරීමේදී සිදුවිය හැකි පිටාර ගැලීම වළක්වයි.
            //
            // TC2: `w(n+1) < minus1`, එනම්, ඊළඟ repr අනිවාර්යයෙන්ම `v` දක්වා රවුම් නොවේ.
            // මෙය `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold` ට සමාන වේ.
            // වම් අත පිටාර ගැලිය හැකිය, නමුත් අපි `threshold > plus1v` දනිමු, එබැවින් TC1 අසත්‍ය නම්, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` සහ අපට ඒ වෙනුවට `threshold - plus1w(n) < 10^kappa` දැයි ආරක්ෂිතව පරීක්ෂා කළ හැකිය.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, එනම්, ඊළඟ repr වේ
            // වත්මන් repr ට වඩා `v + 1 ulp` ට සමීප නොවේ.
            // `z(n) = plus1v_up - plus1w(n)` ලබා දී ඇති විට මෙය `abs(z(n)) <= abs(z(n+1))` බවට පත්වේ.TC1 අසත්‍ය යැයි උපකල්පනය කරමින්, අපට `z(n) > 0` ඇත.සලකා බැලිය යුතු අවස්ථා දෙකක් තිබේ:
            //
            // - `z(n+1) >= 0`: TC3 `z(n) <= z(n+1)` බවට පත්වන විට.
            // `plus1w(n)` වැඩි වන විට, `z(n)` අඩු විය යුතු අතර මෙය පැහැදිලිවම අසත්‍යයකි.
            // - `z(n+1) < 0` විට:
            //   - TC3a: පූර්ව කොන්දේසිය `plus1v_up < plus1w(n) + 10^kappa` වේ.TC2 අසත්‍ය යැයි උපකල්පනය කිරීමෙන් `threshold >= plus1w(n) + 10^kappa` පිටාර ගැලිය නොහැක.
            //   - TC3b: TC3 `z(n) <= -z(n+1)` බවට පත්වේ, එනම්, `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   නිෂේධනය කරන ලද TC1, `plus1v_up > plus1w(n)` ලබා දෙයි, එබැවින් TC3a සමඟ සංයෝජනය වන විට එය පිටාර ගැලීමට හෝ පිටාර ගැලීමට නොහැකිය.
            //
            // එහි ප්‍රති, ලයක් වශයෙන්, අපි `TC1 || TC2 || (TC3a && TC3b)` විට නතර කළ යුතුයි.පහත දැක්වෙන්නේ එහි ප්‍රතිලෝමයට සමාන වේ, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // කෙටිම repr එක `0` සමඟ අවසන් කළ නොහැක
                plus1w += ten_kappa;
            }
        }

        // මෙම නිරූපණය `v - 1 ulp` ට ආසන්නතම නිරූපණය ද යන්න පරීක්ෂා කරන්න.
        //
        // මෙය හුදෙක් `v + 1 ulp` සඳහා අවසන් වන කොන්දේසි වලට සමාන වන අතර, සියලු `plus1v_up` වෙනුවට `plus1v_down` වෙනුවට ආදේශ වේ.
        // පිටාර ගැලීම් විශ්ලේෂණය සමානව පවතී.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // දැන් අපට `plus1` සහ `minus1` අතර `v` ට ආසන්නතම නිරූපණය ඇත.
        // මෙය ඉතා ලිබරල් ය, එබැවින් අපි `plus0` සහ `minus0` අතර නොවන ඕනෑම `w(n)` ප්‍රතික්ෂේප කරමු, එනම් `plus1 - plus1w(n) <= minus0` හෝ `plus1 - plus1w(n) >= plus0`.
        // අපි `threshold = plus1 - minus1` සහ `plus1 - plus0 = minus0 - minus1 = 2 ulp` යන කරුණු භාවිතා කරමු.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// ඩ්‍රැගන් ෆෝල්බැක් සමඟ ග්‍රිසු සඳහා කෙටිම මාදිලිය ක්‍රියාත්මක කිරීම.
///
/// මෙය බොහෝ අවස්ථාවන් සඳහා භාවිතා කළ යුතුය.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // ආරක්ෂාව: ණය පරීක්‍ෂක අපට `buf` භාවිතා කිරීමට ඉඩ දීමට තරම් බුද්ධිමත් නොවේ
    // දෙවන branch හි, එබැවින් අපි මෙහි ජීවිත කාලය සෝදන්නෙමු.
    // නමුත් අපි `buf` නැවත භාවිතා කරන්නේ `format_shortest_opt` `None` ආපසු ලබා දුන්නේ නම් පමණි.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// ග්‍රිසු සඳහා නිශ්චිත හා ස්ථාවර මාදිලිය ක්‍රියාත්මක කිරීම.
///
/// එය වෙනත් ආකාරයකින් නිරවද්‍ය නිරූපණයක් ලබා දෙන විට එය `None` ලබා දෙයි.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // අපට අවම වශයෙන් බිටු තුනක්වත් අවශ්‍ය වේ
    assert!(!buf.is_empty());

    // සාමාන්‍යකරණය කර `v` පරිමාණය කරන්න.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // `v` සමෝධානික හා භාගික කොටස් වලට බෙදන්න.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // පැරණි `v` සහ නව `v` (`10^-k` විසින් පරිමාණය කර ඇත) <1 ulp (ප්‍රමේය 5.1) හි දෝෂයක් ඇත.
    // දෝෂය ධනාත්මක හෝ negative ණාත්මක බව අප නොදන්නා හෙයින්, අපි ආසන්න වශයෙන් ආසන්න වශයෙන් දෙකක් පරතරයකින් භාවිතා කරන අතර උපරිම දෝෂ 2 ක් ඇත (කෙටිම අවස්ථාව හා සමාන වේ).
    //
    //
    // ඉලක්කය වන්නේ `v - 1 ulp` සහ `v + 1 ulp` යන දෙකටම පොදු වන හරියටම වටකුරු ඉලක්කම් මාලාවක් සොයා ගැනීමයි, එවිට අපට උපරිම විශ්වාසයක් ඇත.
    // මෙය කළ නොහැකි නම්, `v` සඳහා නිවැරදි ප්‍රතිදානය කුමක්දැයි අපි නොදනිමු, එබැවින් අපි අතහැර දමා ආපසු යමු.
    //
    // `err` මෙහි `1 ulp * 2^e` ලෙස අර්ථ දක්වා ඇත (`vfrac` හි ulp ට සමාන වේ), සහ `v` පරිමාණයට ලක් වූ සෑම අවස්ථාවකම අපි එය පරිමාණය කරන්නෙමු.
    //
    //
    //
    let mut err = 1;

    // විශාලතම `10^max_kappa` `v` ට නොඅඩු ගණනය කරන්න (මේ අනුව `v < 10^(max_kappa+1)`).
    // මෙය පහළ `kappa` හි ඉහළ සීමාවකි.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // අප අවසන් ඉලක්කම් සීමාව සමඟ වැඩ කරන්නේ නම්, ද්විත්ව වටය වළක්වා ගැනීම සඳහා සත්‍ය විදැහුම්කරණයට පෙර බෆරය කෙටි කළ යුතුය.
    //
    // වටයෑම සිදු වූ විට අපි නැවත බෆරය විශාල කර ගත යුතු බව සලකන්න!
    let len = if exp <= limit {
        // අපොයි, අපට *එක* ඉලක්කම් පවා නිපදවිය නොහැක.
        // අපට 9.5 වැනි දෙයක් ලැබී ඇති අතර එය 10 දක්වා වට කර ඇති විට මෙය කළ හැකිය.
        //
        // ප්‍රතිපත්තිමය වශයෙන් අපට වහාම හිස් බෆරයකින් `possibly_round` අමතන්න, නමුත් `max_ten_kappa << e` 10 කින් පරිමාණය කිරීමෙන් පිටාර ගැලීම සිදුවිය හැකිය.
        //
        // මේ අනුව අප මෙහි අලස වන අතර දෝෂ පරාසය 10 කින් වැඩි කරයි.
        // මෙය ව්‍යාජ negative ණාත්මක අනුපාතය වැඩි කරනු ඇත, නමුත් ඉතා සුළු වශයෙන් *ඉතා* සුළු වශයෙන් පමණි;
        // එය සැලකිය යුතු කරුණක් වන්නේ මැන්ටිස්සා බිටු 60 ට වඩා විශාල වූ විට පමණි.
        //
        // ආරක්ෂාව: `len=0`, එබැවින් මෙම මතකය ආරම්භ කිරීමේ වගකීම ඉතා සුළුය.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // අනුකලනය කළ කොටස්.
    // දෝෂය මුළුමනින්ම භාගික වේ, එබැවින් අපට එය මෙම කොටසේ පරීක්ෂා කිරීමට අවශ්‍ය නොවේ.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // ඉලක්කම් තවම විදහා දැක්විය නොහැක
    loop {
        // ආක්‍රමණ සිදුකිරීමට අපට සෑම විටම අවම වශයෙන් එක් ඉලක්කම් ඇත:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (එය `remainder = vint % 10^(kappa+1)` අනුගමනය කරයි)
        //
        //

        // `remainder` `10^kappa` මගින් බෙදන්න.දෙකම `2^-e` මගින් පරිමාණය කර ඇත.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // බෆරය පිරී තිබේද?වටකුරු පාස් එක ඉතිරි කොටස සමඟ ධාවනය කරන්න.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ කප්පා) * 2 ^ ඊ
            // ආරක්ෂාව: අපි `len` බොහෝ බයිට් ආරම්භ කර ඇත්තෙමු.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // අපි සියලු අනුකලනය කළ විට ලූපය බිඳ දමන්න.
        // නිශ්චිත ඉලක්කම් සංඛ්‍යාව `max_kappa + 1` ලෙස `plus1 < 10^(max_kappa+1)` වේ.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // ආක්‍රමණ ප්‍රතිස්ථාපනය කරන්න
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // භාගික කොටස් විදැහුම් කරන්න.
    //
    // ප්‍රතිපත්තිමය වශයෙන් අපට අවසන් වරට පවතින ඉලක්කම් දක්වා ඉදිරියට ගොස් නිරවද්‍යතාව පරීක්ෂා කළ හැකිය.
    // අවාසනාවට අපි සීමිත ප්‍රමාණයේ පූර්ණ සංඛ්‍යා සමඟ වැඩ කරමින් සිටිමු, එබැවින් පිටාර ගැලීම හඳුනා ගැනීමට අපට යම් නිර්ණායකයක් අවශ්‍ය වේ.
    // V8 `remainder > err` භාවිතා කරයි, `v - 1 ulp` සහ `v` හි පළමු `i` සැලකිය යුතු ඉලක්කම් වෙනස් වන විට එය අසත්‍ය වේ.
    // කෙසේ වෙතත් මෙය වෙනත් ආකාරයකින් වලංගු ආදානය ප්‍රතික්ෂේප කරයි.
    //
    // පසුකාලීන අවධියේ නිවැරදි පිටාර ගැලීම් හඳුනාගැනීමක් ඇති බැවින් අපි ඒ වෙනුවට දැඩි නිර්ණායක භාවිතා කරමු:
    // `err` `10^kappa / 2` ඉක්මවා යන තෙක් අපි ඉදිරියට යමු, එවිට `v - 1 ulp` සහ `v + 1 ulp` අතර පරාසය නිසැකවම වටකුරු නිරූපණ දෙකක් හෝ වැඩි ගණනක් අඩංගු වේ.
    //
    // මෙය `possibly_round` වෙතින් පළමු සැසඳීම් දෙකට සමාන වේ.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // `m = max_kappa + 1` (සමෝධානික කොටසේ ඉලක්කම්#):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // පිටාර ගැලෙන්නේ නැත, `2^e * 10 < 2^64`
        err *= 10; // පිටාර ගැලෙන්නේ නැත, `err * 10 < 2^e * 5 < 2^64`

        // `remainder` `10^kappa` මගින් බෙදන්න.
        // දෙකම `2^e / 10^kappa` මගින් පරිමාණය කර ඇත, එබැවින් දෙවැන්න මෙහි ගම්‍ය වේ.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // බෆරය පිරී තිබේද?වටකුරු පාස් එක ඉතිරි කොටස සමඟ ධාවනය කරන්න.
        if i == len {
            // ආරක්ෂාව: අපි `len` බොහෝ බයිට් ආරම්භ කර ඇත්තෙමු.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // ආක්‍රමණ ප්‍රතිස්ථාපනය කරන්න
        remainder = r;
    }

    // තවදුරටත් ගණනය කිරීම නිෂ් less ල ය (`possibly_round` අනිවාර්යයෙන්ම අසමත් වේ), එබැවින් අපි අත්හරිමු.
    return None;

    // අපි ඉල්ලූ සියලුම `v` ඉලක්කම් උත්පාදනය කර ඇති අතර එය `v - 1 ulp` හි අනුරූප ඉලක්කම් වලට සමාන විය යුතුය.
    // දැන් අපි පරික්ෂා කරන්නේ `v - 1 ulp` සහ `v + 1 ulp` යන දෙකම බෙදාගන්නා අද්විතීය නිරූපණයක් තිබේද;මෙය ජනනය කරන ලද ඉලක්කම් වලට සමාන විය හැකිය, නැතහොත් එම ඉලක්කම්වල වටකුරු අනුවාදයට සමාන විය හැකිය.
    //
    // පරාසයේ එකම දිගක බහුවිධ නිරූපණයන් තිබේ නම්, අපට සහතික විය නොහැකි අතර ඒ වෙනුවට `None` ආපසු එවිය යුතුය.
    //
    // මෙහි ඇති සියලුම තර්ක පොදු (නමුත් ව්‍යංග) `k` අගය මගින් පරිමාණය කර ඇත, එබැවින්:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // ආරක්ෂාව: `buf` හි පළමු `len` බයිට් ආරම්භ කළ යුතුය.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (යොමුව සඳහා, තිත් රේඛාව මඟින් ලබා දී ඇති ඉලක්කම් සංඛ්‍යාවේ නිරූපණයන් සඳහා නිශ්චිත අගය දක්වයි.)
        //
        //
        // දෝෂය ඉතා විශාල බැවින් `v - 1 ulp` සහ `v + 1 ulp` අතර අවම වශයෙන් නිරූපණයන් තුනක්වත් තිබිය හැකිය.
        // අපට නිවැරදි දේ තීරණය කළ නොහැක.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // ඇත්ත වශයෙන්ම, විය හැකි නිරූපණයන් දෙකක් හඳුන්වා දීමට 1/2 ulp ප්‍රමාණවත් වේ.
        // (අපට `v - 1 ulp` සහ `v + 1 ulp` යන දෙකටම අද්විතීය නිරූපණයක් අවශ්‍ය බව මතක තබා ගන්න.) මෙය පළමු චෙක්පතෙන් `ulp < ten_kappa` ලෙස පිටාර ගැලෙන්නේ නැත.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ කප්පා---------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // `v + 1 ulp` වටකුරු-පහළ නිරූපණයට වඩා සමීප නම් (එය දැනටමත් `buf` හි ඇත), එවිට අපට ආරක්ෂිතව ආපසු යා හැකිය.
        // `v - 1 ulp` * වත්මන් නිරූපණයට වඩා අඩු විය හැකි බව සලකන්න, නමුත් `1 ulp < 10^kappa / 2` ලෙස මෙම තත්වය ප්‍රමාණවත් වේ:
        // `v - 1 ulp` සහ වර්තමාන නිරූපණය අතර දුර `10^kappa / 2` නොඉක්මවිය යුතුය.
        //
        // තත්වය `remainder + ulp < 10^kappa / 2` ට සමාන වේ.
        // මෙය පහසුවෙන් පිටාර ගැලිය හැකි බැවින්, පළමුව `remainder < 10^kappa / 2` දැයි පරීක්ෂා කරන්න.
        // අපි දැනටමත් `ulp < 10^kappa / 2` බව තහවුරු කර ඇත්තෙමු, එබැවින් `10^kappa` සියල්ල පිරී ඉතිරී නොයන තාක් කල්, දෙවන චෙක්පත හොඳයි.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // ආරක්ෂාව: අපගේ අමතන්නා එම මතකය ආරම්භ කළේය.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------ඉතිරි------> |:
        //   :                          |   :
        //   : <---------10 ^ කප්පා--------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // අනෙක් අතට, `v - 1 ulp` වටකුරු නිරූපණයට වඩා සමීප නම්, අප වටකර ආපසු යා යුතුය.
        // එකම හේතුව නිසා අපට `v + 1 ulp` පරික්ෂා කිරීම අවශ්‍ය නොවේ.
        //
        // තත්වය `remainder - ulp >= 10^kappa / 2` ට සමාන වේ.
        // නැවතත් අපි පළමුව පරීක්ෂා කරන්නේ `remainder > ulp` (මෙය `remainder >= ulp` නොවන බව සලකන්න, `10^kappa` කිසි විටෙකත් ශුන්‍ය නොවන බැවින්).
        //
        // `remainder - ulp <= 10^kappa` ද සැලකිල්ලට ගන්න, එබැවින් දෙවන චෙක්පත පිටාර ගැලෙන්නේ නැත.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // ආරක්ෂාව: අපගේ අමතන්නා එම මතකය ආරම්භ කර තිබිය යුතුය.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // ස්ථාවර නිරවද්‍යතාවය අපෙන් ඉල්ලා සිටින විට පමණක් අතිරේක ඉලක්කම් එක් කරන්න.
                // මුල් බෆරය හිස් නම්, අතිරේක ඉලක්කම් එකතු කළ හැක්කේ `exp == limit` (edge නඩුව) විට පමණක් බව අප විසින් පරීක්ෂා කළ යුතුය.
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // ආරක්ෂාව: අපි සහ අපගේ අමතන්නා එම මතකය ආරම්භ කළෙමු.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // එසේ නොමැතිනම් අපට විනාශයක් ඇති වේ (එනම්, `v - 1 ulp` සහ `v + 1 ulp` අතර සමහර අගයන් වටකුරු වන අතර අනෙක් ඒවා වටකුරු වේ) සහ අත්හරින්න.
        //
        None
    }
}

/// ඩ්‍රැගන් වැටීම සමඟ ග්‍රිසු සඳහා නිශ්චිත හා ස්ථාවර මාදිලිය ක්‍රියාත්මක කිරීම.
///
/// මෙය බොහෝ අවස්ථාවන් සඳහා භාවිතා කළ යුතුය.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // ආරක්ෂාව: ණය පරීක්‍ෂක අපට `buf` භාවිතා කිරීමට ඉඩ දීමට තරම් බුද්ධිමත් නොවේ
    // දෙවන branch හි, එබැවින් අපි මෙහි ජීවිත කාලය සෝදන්නෙමු.
    // නමුත් අපි `buf` නැවත භාවිතා කරන්නේ `format_exact_opt` `None` ආපසු ලබා දුන්නේ නම් පමණි.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}