//! `පාවෙන ලක්ෂ්‍ය අංක ඉක්මනින් හා නිවැරදිව මුද්‍රණය කිරීම` හි රූප සටහන 3 හි පාහේ සෘජු (නමුත් තරමක් ප්‍රශස්ත) Rust පරිවර්තනය [^ 1].
//!
//!
//! [^1]: Burger, ආර්.ජී. සහ ඩිබ්විග්, ආර්.කේ. 1996. පාවෙන ලක්ෂ්‍ය අංක මුද්‍රණය කිරීම
//!   ඉක්මනින් හා නිවැරදිව.සිග්ලන් නැත.31, 5 (1996 මැයි), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// 10 for (2 ^ n) සඳහා සංඛ්‍යාංකයේ පූර්ව ගණනය කළ අරා
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// `x < 16 * scale` විට පමණක් භාවිතා කළ හැකිය;`scaleN` `scale.mul_small(N)` විය යුතුය
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// ඩ්‍රැගන් සඳහා කෙටිම මාදිලිය ක්‍රියාත්මක කිරීම.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // ආකෘතිකරණය සඳහා `v` අංකය පහත පරිදි වේ:
    // - `mant * 2^exp` ට සමාන;
    // - මුල් වර්ගයේ `(mant - 2 *minus)* 2^exp` ට පෙර;සහ
    // - මුල් වර්ගයේ `(mant + 2 *plus)* 2^exp` අනුගමනය කරයි.
    //
    // පැහැදිලිවම, `minus` සහ `plus` ශුන්‍ය විය නොහැක.(අනන්තය සඳහා, අපි පරාසයෙන් බැහැර අගයන් භාවිතා කරමු.) අවම වශයෙන් එක් ඉලක්කයක් වත් ජනනය වේ යැයි අපි උපකල්පනය කරමු, එනම් `mant` ද ශුන්‍ය විය නොහැක.
    //
    // `low = (mant - minus)*2^exp` සහ `high = (mant + plus)* 2^exp` අතර ඇති ඕනෑම අංකයක් මෙම නිශ්චිත පාවෙන ලක්ෂ්‍ය අංකයට අනුරූප වන බවත්, මුල් මැන්ටිස්සා (එනම්, `!mant_was_odd`) වූ විට සීමාවන් ඇතුළත් වන බවත් මෙයින් අදහස් වේ.
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` `if d.inclusive {a <= b} else {a < b}` වේ
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // `10^(k_0-1) < high <= 10^(k_0+1)` තෘප්තිමත් වන මුල් යෙදවුම් වලින් `k_0` තක්සේරු කරන්න.
    // තදින් බැඳී ඇති `k` තෘප්තිමත් `10^(k-1) < high <= 10^k` පසුව ගණනය කෙරේ.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // `{mant, plus, minus} * 2^exp` භාගික ස්වරූපයට පරිවර්තනය කරන්න:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // `mant` `10^k` මගින් බෙදන්න.දැන් `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // `mant + plus > scale` (හෝ `>=`) විට සවි කිරීම.
    // අපි ඇත්ත වශයෙන්ම `scale` වෙනස් කරන්නේ නැත, ඒ වෙනුවට අපට ආරම්භක ගුණ කිරීම මඟ හැරිය හැක.
    // දැන් `scale < mant + plus <= scale * 10` සහ අපි ඉලක්කම් උත්පාදනය කිරීමට සූදානම්.
    //
    // `scale - plus < mant < scale` විට `d[0]` * ශුන්‍ය විය හැකි බව සලකන්න.
    // මෙම අවස්ථාවේ දී වටකුරු තත්වය (පහළ `up`) වහාම ක්‍රියාත්මක වේ.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // `scale` 10 කින් පරිමාණයට සමාන වේ
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // ඉලක්කම් උත්පාදනය සඳහා හැඹිලි `(2, 4, 8) * scale`.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // `d[0..n-1]` යනු මෙතෙක් ජනනය කරන ලද ඉලක්කම් වන ආක්‍රමණ:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (මේ අනුව `mant / scale < 10`) `d[i..j]` යනු `d [i] * 10 ^ (ji) + සඳහා කෙටිමං වේ ...
        // + d [j-1] * 10 + d[j]`.

        // එක් ඉලක්කම් ජනනය කරන්න: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // මෙය නවීකරණය කරන ලද ඩ්‍රැගන් ඇල්ගොරිතම පිළිබඳ සරල විස්තරයකි.
        // බොහෝ අතරමැදි ව්‍යුත්පන්නයන් සහ සම්පූර්ණ තර්ක පහසුව සඳහා අතහැර දමා ඇත.
        //
        // අප විසින් `n` යාවත්කාලීන කර ඇති පරිදි වෙනස් කළ ආක්‍රමණ සමඟ ආරම්භ කරන්න:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // `d[0..n-1]` යනු `low` සහ `high` අතර කෙටිම නිරූපණය යැයි උපකල්පනය කරන්න, එනම්, `d[0..n-1]` පහත සඳහන් දෙකම තෘප්තිමත් කරයි, නමුත් `d[0..n-2]` එසේ නොවේ:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (ද්විභාෂාව: ඉලක්කම් වටය `v` දක්වා);සහ
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (අවසාන ඉලක්කම් නිවැරදි ය).
        //
        // දෙවන කොන්දේසිය `2 * mant <= scale` වෙත සරල කරයි.
        // `mant`, `low` සහ `high` අනුව වෙනස්වීම් විසඳීම පළමු කොන්දේසියෙහි සරල අනුවාදයක් ලබා දෙයි: `-plus < mant < minus`.
        // `-plus < 0 <= mant` සිට, අපට `mant < minus` සහ `2 * mant <= scale` විට නිවැරදි කෙටිම නිරූපණය ඇත.
        // (මුල් මැන්ටිස්සා ඉරට්ටේ ඇති විට කලින් `mant <= minus` බවට පත්වේ.)
        //
        // දෙවැන්න නොපවතින විට (`2 * mant> පරිමාණය`), අපට අවසාන ඉලක්කම් වැඩි කළ යුතුය.
        // එම තත්වය යථා තත්වයට පත් කිරීම සඳහා මෙය ප්‍රමාණවත් වේ: ඉලක්කම් පරම්පරාව `0 <= v / 10^(k-n) - d[0..n-1] < 1` සහතික කරන බව අපි දැනටමත් දනිමු.
        // මෙම අවස්ථාවේ දී, පළමු කොන්දේසිය `-plus < mant - scale < minus` බවට පත්වේ.
        // පරම්පරාවෙන් පසු `mant < scale` සිට, අපට `scale < mant + plus` ඇත.
        // (නැවතත්, මුල් මැන්ටිස්සා ඉරට්ටේ වන විට මෙය `scale <= mant + plus` බවට පත්වේ.)
        //
        // කෙටියෙන්:
        // - `mant < minus` (හෝ `<=`) වන විට `down` නැවැත්වීම සහ වට කිරීම (ඉලක්කම් එලෙසම තබා ගන්න).
        // - `scale < mant + plus` (හෝ `<=`) වන විට නවත්වන්න සහ වට කරන්න (අවසාන ඉලක්කම් වැඩි කරන්න).
        // - වෙනත් ආකාරයකින් උත්පාදනය කරන්න.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // අපට කෙටිම නිරූපණය ඇත, වටය වෙත යන්න

        // ආක්‍රමණ නැවත පිහිටුවන්න.
        // මෙමඟින් ඇල්ගොරිතම සැමවිටම අවසන් වේ: `minus` සහ `plus` සෑම විටම වැඩි වේ, නමුත් `mant` ක්ලිප් මොඩියුලය `scale` වන අතර `scale` සවි කර ඇත.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // වටකුරු කිරීම සිදුවන්නේ i) වටකුරු කිරීමේ කොන්දේසිය පමණක් අවුලුවන විට හෝ ii) කොන්දේසි දෙකම අවුලුවන ලද අතර ටයි පටිය කැඩීමට වැඩි කැමැත්තක් දක්වයි.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // වටකුරු කිරීම දිග වෙනස් කරන්නේ නම්, on ාතකය ද වෙනස් විය යුතුය.
        // මෙම තත්වය තෘප්තිමත් කිරීම ඉතා අසීරු බව පෙනේ (සමහර විට කළ නොහැකි), නමුත් අපි මෙහි ආරක්ෂිතව හා ස්ථාවරව සිටිමු.
        //
        // ආරක්ෂාව: අපි ඉහත මතකය ආරම්භ කළෙමු.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // ආරක්ෂාව: අපි ඉහත මතකය ආරම්භ කළෙමු.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// ඩ්‍රැගන් සඳහා නිශ්චිත හා ස්ථාවර මාදිලියේ ක්‍රියාත්මක කිරීම.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // `10^(k_0-1) < v <= 10^(k_0+1)` තෘප්තිමත් වන මුල් යෙදවුම් වලින් `k_0` තක්සේරු කරන්න.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // `mant` `10^k` මගින් බෙදන්න.දැන් `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // `mant + plus >= scale` වන විට සවි කිරීම, එහිදී `plus / scale = 10^-buf.len() / 2`.
    // ස්ථාවර ප්‍රමාණයේ බිග්නම් තබා ගැනීම සඳහා, අපි ඇත්ත වශයෙන්ම `mant + floor(plus) >= scale` භාවිතා කරමු.
    // අපි ඇත්ත වශයෙන්ම `scale` වෙනස් කරන්නේ නැත, ඒ වෙනුවට අපට ආරම්භක ගුණ කිරීම මඟ හැරිය හැක.
    // නැවතත් කෙටිම ඇල්ගොරිතම සමඟ, `d[0]` ශුන්‍ය විය හැකි නමුත් අවසානයේ එය වටකුරු වනු ඇත.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // `scale` 10 කින් පරිමාණයට සමාන වේ
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // අප අවසන් ඉලක්කම් සීමාව සමඟ වැඩ කරන්නේ නම්, ද්විත්ව වටය වළක්වා ගැනීම සඳහා සත්‍ය විදැහුම්කරණයට පෙර බෆරය කෙටි කළ යුතුය.
    //
    // වටයෑම සිදු වූ විට අපි නැවත බෆරය විශාල කර ගත යුතු බව සලකන්න!
    let mut len = if k < limit {
        // අපොයි, අපට *එක* ඉලක්කම් පවා නිපදවිය නොහැක.
        // අපට 9.5 වැනි දෙයක් ලැබී ඇති අතර එය 10 දක්වා වට කර ඇති විට මෙය කළ හැකිය.
        // `k == limit` සිදු වන විට සිදු වන වටකුරු නඩුව හැරුණු විට අපි හිස් බෆරයක් ආපසු එවන්නෙමු.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // ඉලක්කම් උත්පාදනය සඳහා හැඹිලි `(2, 4, 8) * scale`.
        // (මෙය මිල අධික විය හැකිය, එබැවින් බෆරය හිස් වූ විට ඒවා ගණනය නොකරන්න.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // පහත දැක්වෙන ඉලක්කම් සියල්ලම ශුන්‍ය වේ, අපි මෙහි නතර වන්නේ * වටකුරු කිරීමට උත්සාහ නොකරන්න!ඒ වෙනුවට, ඉතිරි ඉලක්කම් පුරවන්න.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // ආරක්ෂාව: අපි ඉහත මතකය ආරම්භ කළෙමු.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // පහත දැක්වෙන ඉලක්කම් හරියටම 5000 ක් නම් අපි ඉලක්කම් මැද නතර වුවහොත් වටයන්න ..., පෙර ඉලක්කම් පරීක්ෂා කර ඉරට්ටේ සිට වටය දක්වා උත්සාහ කරන්න (එනම්, පෙර ඉලක්කම් ඉරට්ටේ ඇති විට වටය වළක්වා ගන්න).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // ආරක්ෂාව: `buf[len-1]` ආරම්භ කර ඇත.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // වටකුරු කිරීම දිග වෙනස් කරන්නේ නම්, on ාතකය ද වෙනස් විය යුතුය.
        // නමුත් අපට නිශ්චිත ඉලක්කම් සංඛ්‍යාවක් ඉල්ලා ඇත, එබැවින් බෆරය වෙනස් නොකරන්න ...
        // ආරක්ෂාව: අපි ඉහත මතකය ආරම්භ කළෙමු.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... ඒ වෙනුවට ස්ථාවර නිරවද්‍යතාවය අපෙන් ඉල්ලා නොමැති නම්.
            // මුල් බෆරය හිස් නම්, අතිරේක ඉලක්කම් එකතු කළ හැක්කේ `k == limit` (edge නඩුව) විට පමණක් බව අප විසින් පරීක්ෂා කළ යුතුය.
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // ආරක්ෂාව: අපි ඉහත මතකය ආරම්භ කළෙමු.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}