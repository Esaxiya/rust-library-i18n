//! පාවෙන ලක්ෂ්‍ය අගය තනි කොටස් සහ දෝෂ පරාස වලට විකේතනය කරයි.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// විකේතනය නොකළ අත්සන් කළ සීමිත අගය, එනම්:
///
/// - මුල් අගය `mant * 2^exp` ට සමාන වේ.
///
/// - `(mant - minus)*2^exp` සිට `(mant + plus)* 2^exp` දක්වා ඕනෑම අංකයක් මුල් අගයට රවුම් වනු ඇත.
/// පරාසය ඇතුළත් වන්නේ `inclusive` `true` වූ විට පමණි.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// පරිමාණය කළ මැන්ටිස්සා.
    pub mant: u64,
    /// පහළ දෝෂ පරාසය.
    pub minus: u64,
    /// ඉහළ දෝෂ පරාසය.
    pub plus: u64,
    /// 2 වන පාදයේ බෙදාගත් on ාතකය.
    pub exp: i16,
    /// දෝෂ පරාසය ඇතුළත් වන විට ඇත්ත.
    ///
    /// IEEE 754 හි, මුල් මැන්ටිස්සා ඉරට්ටේ සිටියදී මෙය සත්‍ය වේ.
    pub inclusive: bool,
}

/// විකේතනය නොකළ අත්සන් කළ අගය.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// අනන්තය, ධනාත්මක හෝ .ණාත්මක ය.
    Infinite,
    /// ශුන්‍ය, ධනාත්මක හෝ .ණාත්මක වේ.
    Zero,
    /// තවදුරටත් විකේතනය කළ ක්ෂේත්‍ර සහිත සීමිත සංඛ්‍යා.
    Finite(Decoded),
}

/// පාවෙන ලක්ෂ්‍ය වර්ගයක් වන අතර එය විකේතනය කළ හැකිය.
pub trait DecodableFloat: RawFloat + Copy {
    /// අවම ධනාත්මක සාමාන්‍ය අගය.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// ලබා දී ඇති පාවෙන ලක්ෂ්‍ය අංකයෙන් ලකුණක් (negative ණාත්මක වන විට සත්‍ය) සහ `FullDecoded` අගය ලබා දෙයි.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // අසල්වැසියන්: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode සෑම විටම on ාතකය ආරක්ෂා කරයි, එබැවින් මැන්ටිස්සා උප සාමාන්‍යයන් සඳහා පරිමාණය කර ඇත.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // අසල්වැසියන්: (උපරිම, exp, 1)-(අවම, exp)-(අවම + 1, exp)
                // එහිදී maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // අසල්වැසියන්: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}