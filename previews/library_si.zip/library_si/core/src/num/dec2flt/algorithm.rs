//! කඩදාසි වලින් විවිධ ඇල්ගොරිතම.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Fp හි වැදගත් සහ බිටු ගණන
const P: u32 = 64;

// අපි *සියලු* on ාතකයන් සඳහා හොඳම ඇස්තමේන්තුව ගබඩා කර තබන්නෙමු, එබැවින් විචල්ය "h" සහ ඊට සම්බන්ධ කොන්දේසි මඟ හැරිය හැක.
// මෙය කිලෝබයිට් යුවළක් සඳහා කාර්ය සාධනය වෙළඳාම් කරයි.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// බොහෝ ගෘහ නිර්මාණ ශිල්පයෙහි, පාවෙන ලක්ෂ්‍ය මෙහෙයුම් වල පැහැදිලි බිට් ප්‍රමාණයක් ඇත, එබැවින් ගණනය කිරීමේ නිරවද්‍යතාවය එක් එක් මෙහෙයුම් පදනම මත තීරණය වේ.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// x86 හි, SSE/SSE2 දිගු ලබා ගත නොහැකි නම්, පාවෙන මෙහෙයුම් සඳහා x87 FPU භාවිතා වේ.
// x87 FPU පෙරනිමියෙන් බිටු 80 ක නිරවද්‍යතාවයකින් ක්‍රියාත්මක වන අතර එයින් අදහස් වන්නේ මෙහෙයුම් බිටු 80 ක් දක්වා විහිදෙන අතර අගයන් අවසානයේ නිරූපණය වන විට ද්විත්ව වටයක් සිදු වන බවයි.
//
// 32/64 බිට් පාවෙන අගයන්.මෙය මඟහරවා ගැනීම සඳහා, FPU පාලන වචනය සැකසිය හැකි අතර එමඟින් ගණනය කිරීම් අපේක්ෂිත නිරවද්‍යතාවයෙන් සිදු කෙරේ.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// FPU පාලන වචනයේ මුල් අගය ආරක්ෂා කිරීම සඳහා භාවිතා කරන ව්‍යුහයක් වන අතර එමඟින් ව්‍යුහය අතහැර දැමූ විට එය යථා තත්වයට පත් කළ හැකිය.
    ///
    ///
    /// x87 FPU යනු බිටු 16 ක ලේඛනයක් වන අතර එහි ක්ෂේත්‍ර පහත පරිදි වේ:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// සියලුම ක්ෂේත්‍ර සඳහා වන ලියකියවිලි IA-32 ගෘහ නිර්මාණ මෘදුකාංග සංවර්ධකයාගේ අත්පොතෙහි (වෙළුම 1) ඇත.
    ///
    /// පහත දැක්වෙන කේතයට අදාළ වන එකම ක්ෂේත්‍රය වන්නේ PC, නිරවද්‍යතා පාලනයයි.
    /// මෙම ක්ෂේත්‍රය FPU විසින් සිදු කරනු ලබන මෙහෙයුම් වල නිරවද්‍යතාවය තීරණය කරයි.
    /// එය පහත පරිදි සැකසිය හැකිය:
    ///  - 0b00, තනි නිරවද්‍යතාව, එනම් 32-බිටු
    ///  - 0b10, ද්විත්ව නිරවද්‍යතාව, එනම් 64-බිටු
    ///  - 0b11, ද්විත්ව විස්තාරණ නිරවද්‍යතාව, එනම් බිටු 80 (පෙරනිමි තත්වය) 0b01 අගය වෙන් කර ඇති අතර එය භාවිතා නොකළ යුතුය.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // ආරක්ෂාව: නිවැරදිව වැඩ කිරීමට හැකිවන පරිදි `fldcw` උපදෙස් විගණනය කර ඇත
        // ඕනෑම `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: LLVM 8 සහ LLVM 9 සඳහා සහය දැක්වීමට අපි ATT සින්ටැක්ස් භාවිතා කරමු.
                options(att_syntax, nostack),
            )
        }
    }

    /// FPU හි නිරවද්‍යතා ක්ෂේත්‍රය `T` ලෙස සකසා `FPUControlWord` ලබා දෙයි.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // `T` සඳහා සුදුසු නිරවද්‍යතා පාලන ක්ෂේත්‍රය සඳහා අගය ගණනය කරන්න.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // බිටු 32 යි
            8 => 0x0200, // බිටු 64 යි
            _ => 0x0300, // පෙරනිමිය, බිටු 80 යි
        };

        // `FPUControlWord` ව්‍යුහය අතහැර දැමූ විට පසුව එය යථා තත්වයට පත් කිරීම සඳහා පාලක වචනයේ මුල් වටිනාකම ලබා ගන්න ආරක්ෂිතයි: ඕනෑම `u16` සමඟ නිවැරදිව වැඩ කිරීමට හැකිවන පරිදි `fnstcw` උපදෙස් විගණනය කර ඇත.
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: LLVM 8 සහ LLVM 9 සඳහා සහය දැක්වීමට අපි ATT සින්ටැක්ස් භාවිතා කරමු.
                options(att_syntax, nostack),
            )
        }

        // පාලක වචනය අපේක්ෂිත නිරවද්‍යතාවයට සකසන්න.
        // මෙය සාක්ෂාත් කරගනු ලබන්නේ පැරණි නිරවද්‍යතාව (බිටු 8 සහ 9, 0x300) සඟවා එය ඉහත ගණනය කළ නිරවද්‍ය ධජය සමඟ ප්‍රතිස්ථාපනය කිරීමෙනි.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// යන්ත්‍ර ප්‍රමාණයේ පූර්ණ සංඛ්‍යා සහ පාවෙන භාවිතා කරමින් බෙලරොෆොන්හි වේගවත් මාර්ගය.
///
/// මෙය වෙනම ශ්‍රිතයකට නිස්සාරණය කර ඇති අතර එමඟින් එය බිග්නම් සෑදීමට පෙර උත්සාහ කළ හැකිය.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // අපි නිශ්චිත අගය අවසානයට ආසන්න MAX_SIG සමඟ සංසන්දනය කරමු, මෙය ඉක්මන්, ලාභ ප්‍රතික්ෂේප කිරීමකි (තවද ඉතිරි කේතය පිටාර ගැලීම ගැන කරදර වීමෙන් නිදහස් කරයි).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // වේගවත් මාවත තීරණාත්මකව රඳා පවතින්නේ කිසිදු අතරමැදි වටයකින් තොරව අංක ගණිතය නිවැරදි බිටු ගණනකට රවුම් කිරීම මත ය.
    // x86 හි (SSE හෝ SSE2 නොමැතිව) මේ සඳහා x87 FPU තොගයේ නිරවද්‍යතාවය වෙනස් කිරීම අවශ්‍ය වන අතර එමඟින් එය කෙලින්ම 64/32 බිට් වෙත රවුම් වේ.
    // `set_precision` ශ්‍රිතය ගෝලීය තත්වය වෙනස් කිරීමෙන් (x87 FPU හි පාලන වචනය වැනි) සැකසීමට අවශ්‍ය ගෘහ නිර්මාණ ශිල්පය පිළිබඳ නිරවද්‍යතාව සැකසීමට සැලකිලිමත් වේ.
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // ඊ <0 නඩුව අනෙක් branch වෙත නැමිය නොහැක.
    // P ණාත්මක බලයන් ද්විමය තුළ භාගික කොටසක් පුනරාවර්තනය වන අතර ඒවා වටකුරු වන අතර එය අවසාන ප්‍රති .ලයේ සැබෑ (සහ ඉඳහිට සැලකිය යුතු!) දෝෂ ඇති කරයි.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// ඇල්ගොරිතම බෙලරොෆොන් යනු සුළු නොවන සංඛ්‍යා විශ්ලේෂණයන් විසින් යුක්ති සහගත කරන සුළු කේතයකි.
///
/// එය බිට් 64 ක වැදගත්කමක් ඇති පාවෙන තට්ටුවකට ``f`` වට කර `10^e` හි හොඳම දළ වශයෙන් ගුණ කරයි (එකම පාවෙන ලක්ෂ්‍ය ආකෘතියෙන්).නිවැරදි ප්‍රති .ලය ලබා ගැනීමට මෙය බොහෝ විට ප්‍රමාණවත් වේ.
/// කෙසේ වෙතත්, ප්‍රති result ලය යාබද (ordinary) පාවෙන දෙකක් අතර අඩකට ආසන්න වන විට, ආසන්න වශයෙන් දෙකක් ගුණ කිරීමෙන් සංයුක්ත වටකුරු දෝෂය යන්නෙන් අදහස් වන්නේ ප්‍රති result ලය බිටු කිහිපයකින් අක්‍රිය විය හැකි බවයි.
/// මෙය සිදු වූ විට, ක්‍රියාකාරී ඇල්ගොරිතම R මඟින් දේවල් නිවැරදි කරයි.
///
/// අතින් රැලි සහිත "close to halfway" කඩදාසි වල සංඛ්‍යාත්මක විශ්ලේෂණය මඟින් නිවැරදිව සකසා ඇත.
/// ක්ලින්ගර්ගේ වචන වලින්:
///
/// > බෑවුම, අවම වශයෙන් සැලකිය යුතු බිට් ඒකක වලින් ප්‍රකාශිත වන අතර එය දෝෂයට ඇතුළත් වේ
/// > f * 10 ^ e ට ආසන්න වශයෙන් පාවෙන ලක්ෂ්‍ය ගණනය කිරීමේදී එකතු වේ.(බෑවුමයි
/// > සත්‍ය දෝෂයට බැඳී නැත, නමුත් ආසන්න වශයෙන් z සහ
/// > p බිටු වැදගත්කම භාවිතා කළ හැකි හොඳම දළ විශ්ලේෂණය.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // abs(e) <log5(2^N) අවස්ථා fast_path() හි ඇත
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // බිටු n ට රවුම් වන විට වෙනසක් කිරීමට බෑවුම විශාලද?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// `f * 10^e` හි පාවෙන ලක්ෂ්‍ය දළ විශ්ලේෂණය වැඩි දියුණු කරන පුනරාවර්තන ඇල්ගොරිතම.
///
/// සෑම පුනරාවර්තනයකටම අවසාන ස්ථානයේ එක් ඒකකයක් සමීප වන අතර, ඇත්ත වශයෙන්ම `z0` පවා මෘදු ලෙස අක්‍රිය වුවහොත් අභිසාරී වීමට බොහෝ කාලයක් ගතවේ.
/// වාසනාවකට මෙන්, බෙලරොෆොන් සඳහා පසුබෑමක් ලෙස භාවිතා කරන විට, ආරම්භක දළ විශ්ලේෂණය බොහෝ විට එක් යූඑල්පී විසින් අක්‍රිය කරනු ලැබේ.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // `x / y` හරියටම `(f *10^e) / (m* 2^k)` වන `x`, `y` යන ධන නිඛිල සොයා ගන්න.
        // මෙය `e` සහ `k` සං signs ා සමඟ කටයුතු කිරීමෙන් වැළකී සිටිනවා පමණක් නොව, සංඛ්‍යා කුඩා කිරීම සඳහා `10^e` සහ `2^k` සඳහා පොදු දෙකක බලයද අපි ඉවත් කරමු.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // මෙය ටිකක් අමුතු ලෙස ලියා ඇත්තේ අපගේ බිග්නම් negative ණ සංඛ්‍යා සඳහා සහය නොදක්වන නිසා අපි නිරපේක්ෂ වටිනාකම + සං sign ා තොරතුරු භාවිතා කරමු.
        // M_digits සමඟ ගුණ කිරීම පිටාර ගැලිය නොහැක.
        // `x` හෝ `y` අපට පිටාර ගැලීම ගැන කරදර විය යුතු තරම් විශාල නම්, ඒවාද විශාල බැවින් `make_ratio` භාගය 2 ^ 64 හෝ ඊට වැඩි සාධකයකින් අඩු කර ඇත.
        //
        //
        let (d2, d_negative) = if x >= y {
            // තවත් x අවශ්‍ය නැත, clone() එකක් ඉතිරි කරන්න.
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // තවමත් y අවශ්‍යයි, පිටපතක් සාදන්න.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// `x = f` සහ `y = m` ලබා දී ඇති පරිදි `f` සුපුරුදු පරිදි ආදාන දශම සංඛ්‍යා නිරූපණය කරන අතර `m` යනු පාවෙන ලක්ෂ්‍ය දළ විශ්ලේෂණයක වැදගත්කම වන අතර, `x / y` අනුපාතය `(f *10^e) / (m* 2^k)` ට සමාන කරන්න, දෙකේ බලයෙන් අඩු විය හැක.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, හැර අපි භාග දෙකක බලයකින් භාගය අඩු කරමු.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m එයට පිටාර ගැලිය නොහැක්කේ එයට ධනාත්මක `e` සහ X ණ `k` අවශ්‍ය වන නිසාය, එය සිදුවිය හැක්කේ 1 ට ඉතා ආසන්න අගයන් සඳහා පමණි, එයින් අදහස් වන්නේ `e` සහ `k` සාපේක්ෂව ඉතා කුඩා වනු ඇති බවයි.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k මෙය පිටාර ගැලිය නොහැක, ඉහත බලන්න.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), යළිත් දෙකක පොදු බලයකින් අඩු කරයි.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// සංකල්පමය වශයෙන්, ඇල්ගොරිතම එම් යනු දශමයක් පාවෙන බවට පරිවර්තනය කිරීමේ සරලම ක්‍රමයයි.
///
/// අපි `f * 10^e` ට සමාන අනුපාතයක් සාදන්නෙමු, පසුව එය වලංගු පාවෙන වැදගත්කමක් ලබා දෙන තෙක් දෙකක බලයක් විසි කරමු.
/// ද්විමය on ාතීය `k` යනු අප සංඛ්‍යාංකය හෝ හරය දෙකින් ගුණ කළ වාර ගණනයි, එනම් සෑම විටම `f *10^e` `(u / v)* 2^k` ට සමාන වේ.
/// අප වැදගත්කම සොයාගෙන ඇති විට, අපට අවශ්‍ය වන්නේ කොට් division ාශයේ ඉතිරි කොටස පරීක්ෂා කිරීමෙන් පමණි.
///
///
/// `quick_start()` හි විස්තර කර ඇති ප්‍රශස්තිකරණය සමඟ වුවද මෙම ඇල්ගොරිතමය ඉතා මන්දගාමී වේ.
/// කෙසේ වෙතත්, පිටාර ගැලීම, පිටාර ගැලීම සහ අසාමාන්‍ය ප්‍රති .ල සඳහා අනුවර්තනය වීම සරලම ඇල්ගොරිතම වේ.
/// බෙලරොෆොන් සහ ඇල්ගොරිතම ආර් අධික වූ විට මෙම ක්‍රියාත්මක කිරීම භාර ගනී.
/// පිටාර ගැලීම සහ පිටාර ගැලීම හඳුනා ගැනීම පහසුය: අනුපාතය තවමත් පරාසයක වැදගත්කමක් නැති නමුත් minimum/maximum on ාතකය වෙත ළඟා වී ඇත.
/// පිටාර ගැලීමකදී, අපි හුදෙක් අනන්තය නැවත ලබා දෙන්නෙමු.
///
/// පිටාර ගැලීම සහ උපසිරැසි හැසිරවීම උපක්‍රමශීලී ය.
/// එක් විශාල ගැටළුවක් නම්, අවම on ාතයක් සමඟ, වැදගත්කමක් සඳහා අනුපාතය තවමත් විශාල විය හැකිය.
/// විස්තර සඳහා underflow() බලන්න.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME හැකි ප්‍රශස්තිකරණය: big_to_fp සාමාන්‍යකරණය කරන්න එවිට අපට fp_to_float(big_to_fp(u)) ට සමාන ප්‍රමාණයක් මෙහි කළ හැකිය, ද්විත්ව වටයකින් තොරව පමණි.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // අපි අවම on ාතයේ නතර විය යුතුයි, අපි `k < T::MIN_EXP_INT` තෙක් බලා සිටියහොත්, අපි සාධක දෙකකින් ඉවත් වනු ඇත.
            // අවාසනාවට මෙයින් අදහස් වන්නේ අවම on ාතයක් සහිත සාමාන්‍ය සංඛ්‍යා විශේෂ කළ යුතු බවයි.
            // FIXME වඩාත් අලංකාර සූත්‍රයක් සොයා ගනී, නමුත් එය ඇත්ත වශයෙන්ම නිවැරදි බව තහවුරු කර ගැනීම සඳහා `tiny-pow10` පරීක්ෂණය ධාවනය කරන්න!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// බිට් දිග පරීක්ෂා කිරීමෙන් බොහෝ ඇල්ගොරිතම එම් පුනරාවර්තනයන් මඟ හරින්න.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // බිට් දිග යනු පාදක ල ar ු ගණකයේ ඇස්තමේන්තුවක් වන අතර log(u / v) = log(u), log(v).
    // ඇස්තමේන්තුව උපරිම වශයෙන් 1 කින් අක්‍රිය කර ඇත, නමුත් සෑම විටම අඩු තක්සේරුවක් ඇත, එබැවින් log(u) සහ log(v) හි දෝෂය එකම ලකුණක් වන අතර අවලංගු වේ (දෙකම විශාල නම්).
    // එබැවින් log(u / v) සඳහා වන දෝෂය බොහෝ දුරට එකකි.
    // ඉලක්ක අනුපාතය යනු u/v පරාසයේ වැදගත්කමක් ඇති ස්ථානයකි.මේ අනුව අපගේ අවසන් කිරීමේ තත්වය log2(u / v) යනු වැදගත් හා බිටු වන plus/minus වේ.
    // FIXME දෙවන බිට් දෙස බැලීමෙන් ඇස්තමේන්තුව වැඩිදියුණු කළ හැකි අතර තවත් බෙදීම් වළක්වා ගත හැකිය.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // යටින් ගලායාම හෝ අසාමාන්‍යය.එය ප්‍රධාන කාර්යයට තබන්න.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // පිටාර ගැලීම.එය ප්‍රධාන කාර්යයට තබන්න.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // අනුපාතය අවම on ාතයක් සහිත පරාසයක වැදගත්කමක් නොවන අතර, එබැවින් අපට අතිරික්ත බිටු වට කර on ාතකය ඒ අනුව සකස් කළ යුතුය.
    // සැබෑ වටිනාකම දැන් පෙනේ:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q ටන්ක.(රීම් මගින් නිරූපණය කෙරේ)
    //
    // එමනිසා, වටකුරු බිටු වන විට!= 0.5 ULP, ඔවුන් තනිවම වටය තීරණය කරයි.
    // ඒවා සමාන වන අතර ඉතිරිය ශුන්‍ය නොවන විට, අගය තවමත් වටකුරු කළ යුතුය.
    // වටකුරු ඕෆ් බිටු 1/2 සහ ඉතිරි කොටස ශුන්‍ය වන විට පමණක් අපට අර්ධ-ඒකාකාර තත්වයක් ඇත.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// සාමාන්‍ය වටයේ සිට ඉර දක්වා, කොට් division ාශයක ඉතිරි කොටස මත පදනම්ව වටයෑමෙන් අපැහැදිලි වේ.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}