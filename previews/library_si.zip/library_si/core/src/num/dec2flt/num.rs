//! ක්‍රම බවට හැරවීමට වැඩි තේරුමක් නැති බිග්නම් සඳහා උපයෝගිතා කාර්යයන්.

// FIXME මෙම මොඩියුලයේ නම ටිකක් අවාසනාවන්ත ය, මන්ද අනෙක් මොඩියුලයන් ද `core::num` ආනයනය කරයි.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// `ones_place` ට වඩා අඩු වැදගත්කමක් ඇති සියළුම බිටු කප්පාදු කිරීම සාපේක්ෂ දෝෂයක් 0.5 ULP ට වඩා අඩු, සමාන හෝ වැඩි ද යන්න හඳුන්වා දෙයි.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // ඉතිරිව ඇති සියලුම බිටු ශුන්‍ය නම්, එය= 0.5 යූඑල්පී, එසේ නොමැතිනම්> 0.5 තවත් බිටු නොමැති නම් (අඩ_බිට්==0), පහත දැක්වෙන දේ නිවැරදිව සමාන වේ.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// දශම සංඛ්‍යා පමණක් අඩංගු ASCII නූලක් `u64` බවට පරිවර්තනය කරයි.
///
/// පිටාර ගැලීම හෝ අවලංගු අක්ෂර සඳහා චෙක්පත් සිදු නොකරයි, එබැවින් අමතන්නා ප්‍රවේශම් නොවන්නේ නම්, ප්‍රති result ලය ව්‍යාජ වන අතර panic (එය `unsafe` නොවනු ඇත).
/// මීට අමතරව, හිස් නූල් බිංදුව ලෙස සලකනු ලැබේ.
/// මෙම ශ්‍රිතය පවතින්නේ එයට හේතුවෙනි
///
/// 1. `&[u8]` හි `FromStr` භාවිතා කිරීම සඳහා `from_utf8_unchecked` අවශ්‍ය වේ, එය නරක ය, සහ
/// 2. `integral.parse()` සහ `fractional.parse()` හි ප්‍රති results ල එකට එකතු කිරීම මෙම සමස්ත කාර්යයට වඩා සංකීර්ණ ය.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// ASCII ඉලක්කම් මාලාවක් බිග්නම් බවට පරිවර්තනය කරයි.
///
/// `from_str_unchecked` මෙන්, මෙම ශ්‍රිතය ඉලක්කම් නොවන ඒවා ඉවත් කිරීම සඳහා විග්‍රහකය මත රඳා පවතී.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// බිග්නම් 64 බිටු නිඛිලයකට ලිවීම.Panics අංකය විශාල නම්.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// බිටු පරාසයක් උපුටා ගනී.

/// දර්ශකය 0 අවම සැලකිය යුතු බිට් වන අතර පරාසය සුපුරුදු පරිදි අඩක් විවෘතව පවතී.
/// ආපසු එන වර්ගයට ගැළපෙන ප්‍රමාණයට වඩා වැඩි බිටු ප්‍රමාණයක් උකහා ගැනීමට Panics ඉල්ලුවහොත්.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}