//! දශම නූල් IEEE 754 ද්විමය පාවෙන ලක්ෂ්‍ය අංක බවට පරිවර්තනය කිරීම.
//!
//! # ගැටළු ප්රකාශය
//!
//! අපට `12.34e56` වැනි දශම නූලක් ලබා දී ඇත.
//! මෙම නූල සමෝධානික (`12`), භාගික (`34`) සහ on ාතීය (`56`) කොටස් වලින් සමන්විත වේ.සියලුම කොටස් අත්‍යවශ්‍ය නොවන අතර අතුරුදහන් වූ විට ශුන්‍ය ලෙස අර්ථ දැක්වේ.
//!
//! අපි සොයන්නේ දශම නූල් වල නිශ්චිත අගයට ආසන්නතම IEEE 754 පාවෙන ලක්ෂ්‍ය අංකයයි.
//! බොහෝ දශම නූල්වල පාදක දෙකේ අවසන් නිරූපණයන් නොමැති බව කවුරුත් දන්නා කරුණකි, එබැවින් අපි අවසාන ස්ථානයේ 0.5 ඒකක වෙත ගමන් කරමු (වෙනත් වචන වලින් කිවහොත් මෙන්ම හැකි තරම්).
//! බැඳීම්, දශම අගයන් අඛණ්ඩව පාවෙන දෙකක් අතර අඩක් දුරින්, අර්ධ-ඉරට්ටේ උපාය මාර්ගයෙන් විසඳනු ලැබේ, එය බැංකුකරුවන්ගේ වටය ලෙසද හැඳින්වේ.
//!
//! ක්‍රියාත්මක කිරීමේ සංකීර්ණතාව සහ ගත් CPU චක්‍ර අනුව මෙය තරමක් දුෂ්කර බව අමුතුවෙන් කිව යුතු නැත.
//!
//! # Implementation
//!
//! පළමුව, අපි සං .ා නොසලකා හරිමු.නැතහොත්, පරිවර්තන ක්‍රියාවලියේ ආරම්භයේදීම අපි එය ඉවත් කර අවසානයේදීම නැවත යොදන්නෙමු.
//! IEEE පාවෙන ශුන්‍යය වටා සමමිතික බැවින් සියලුම edge අවස්ථා වලදී මෙය නිවැරදි වේ, එකක් නොසලකා හැරීම පළමු බිට් එක පෙරළයි.
//!
//! එවිට අපි on ාතකය සකස් කිරීමෙන් දශම ලක්ෂ්‍යය ඉවත් කරමු: සංකල්පමය වශයෙන්, `12.34e56` `1234e54` බවට හැරේ, එය අපි විස්තර කරන්නේ ධනාත්මක පූර්ණ සංඛ්‍යාවක් `f = 1234` සහ පූර්ණ සංඛ්‍යා `e = 54` සමඟ ය.
//! `(f, e)` නිරූපණය විග්‍රහ කිරීමේ අදියර පසුකර ඇති සියලුම කේත භාවිතා කරයි.
//!
//! යන්ත්‍ර සූත්‍ර පූර්ණ සංඛ්‍යා සහ කුඩා, ස්ථාවර ප්‍රමාණයේ පාවෙන ලක්ෂ්‍ය සංඛ්‍යා භාවිතා කරමින් ක්‍රමානුකූලව වඩා සාමාන්‍ය හා මිල අධික විශේෂ අවස්ථා දාමයක් අපි උත්සාහ කරමු (පළමු `f32`/`f64`, පසුව බිට් 64 වැදගත්කමක් ඇති වර්ගයක්, `Fp`).
//!
//! මේ සියල්ල අසමත් වූ විට, අපි උණ්ඩය සපාගෙන සරල නමුත් ඉතා මන්දගාමී ඇල්ගොරිතමයක් වෙත යොමු වන අතර එය `f * 10^e` සම්පුර්ණයෙන්ම ගණනය කිරීම හා හොඳම දළ විශ්ලේෂණය සඳහා ක්‍රියාකාරී සෙවුමක් සිදු කිරීම ඇතුළත් වේ.
//!
//! මූලික වශයෙන්, මෙම මොඩියුලය සහ එහි දරුවන් විස්තර කර ඇති ඇල්ගොරිතම ක්‍රියාත්මක කරයි:
//! "How to Read Floating Point Numbers Accurately" විලියම් ඩී.
//! ක්ලින්ජර්, මාර්ගගතව ඇත: <http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.45.4152>
//!
//! ඊට අමතරව, කඩදාසි වල භාවිතා වන නමුත් Rust හි (හෝ අවම වශයෙන් හරයෙන්) ලබා ගත නොහැකි උපකාරක කාර්යයන් රාශියක් ඇත.
//! පිටාර ගැලීම සහ පිටාර ගැලීම හැසිරවීමේ අවශ්‍යතාවය සහ අසාමාන්‍ය සංඛ්‍යා හැසිරවීමට ඇති ආශාව අපගේ අනුවාදය අතිරේකව සංකීර්ණ වේ.
//! බෙලරොෆොන් සහ ඇල්ගොරිතම ආර් පිටාර ගැලීම, උප අසාමාන්‍යතා සහ පිටාර ගැලීම් සමඟ ගැටලු ඇත.
//! යෙදවුම් තීරණාත්මක කලාපයට පැමිණීමට පෙර අපි සාම්ප්‍රදායිකව ඇල්ගොරිතම එම් (කඩදාසි 8 වන කොටසේ විස්තර කර ඇති වෙනස් කිරීම් සමඟ) වෙත මාරු වෙමු.
//!
//! අවධානය යොමු කළ යුතු තවත් අංගයක් වන්නේ ``RawFloat`` trait, එමඟින් සියලු කාර්යයන් පාහේ පරාමිතිකරණය කර ඇත.`f64` වෙත විග්‍රහ කර ප්‍රති result ලය `f32` වෙත දැමීම ප්‍රමාණවත් යැයි කෙනෙකුට සිතිය හැකිය.
//! අවාසනාවට මෙය අප ජීවත් වන ලෝකය නොවන අතර, මූලික දෙකේ හෝ අඩක් හෝ ඊටත් වඩා වටකුරු භාවිතා කිරීම මෙයට කිසිදු සම්බන්ධයක් නැත.
//!
//! උදාහරණයක් ලෙස `d2` සහ `d4` වර්ග දෙකක් දශම සංඛ්‍යා දෙකක් සහ දශම ඉලක්කම් හතරක් සහිත දශම වර්ගයක් නියෝජනය කරන අතර "0.01499" ආදානය ලෙස ගන්න.අපි අර්ධ-වටකුරු භාවිතා කරමු.
//! කෙලින්ම දශම සංඛ්‍යා දෙකකට යාම `0.01` ලබා දෙයි, නමුත් අපි පළමුව ඉලක්කම් හතරක් දක්වා වට කළහොත්, අපට `0.0150` ලැබෙනු ඇත, එය `0.02` දක්වා වටකුරු වේ.
//! 0.5 යූඑල්පී නිරවද්‍යතාවය ඔබට අවශ්‍ය නම්, සෑම දෙයක්ම සම්පූර්ණ නිරවද්‍යතාවයෙන් හා වටයකින් *හරියටම එක් වරක්, අවසානයේදී* කළ යුතුය, සියලු කප්පාදු කළ බිටු එකවර සලකා බැලීමෙන්.
//!
//! FIXME: සමහර කේත අනුපිටපත් කිරීම අවශ්‍ය වුවද, සමහර විට කේතයේ කොටස් අඩු කේත අනුපිටපත් වන පරිදි මාරු කළ හැකිය.
//! ඇල්ගොරිතමයේ විශාල කොටස් ප්‍රතිදාන සඳහා පාවෙන වර්ගයට වඩා ස්වාධීන වේ, නැතහොත් අවශ්‍ය වන්නේ නියත කිහිපයකට පමණි, ඒවා පරාමිතීන් ලෙස සම්මත කළ හැකිය.
//!
//! # Other
//!
//! පරිවර්තනය *කිසි විටෙකත්* panic නොවිය යුතුය.
//! කේතයේ ප්‍රකාශ සහ පැහැදිලි panics ඇත, නමුත් ඒවා කිසි විටෙකත් අවුලුවාලිය යුතු අතර අභ්‍යන්තර සනීපාරක්ෂක පරීක්ෂාවන් ලෙස පමණක් ක්‍රියා කරයි.ඕනෑම panics දෝෂයක් ලෙස සැලකිය යුතුය.
//!
//! ඒකක පරීක්ෂණ ඇති නමුත් ඒවා නිවැරදි බව සහතික කිරීම සඳහා දුක්ඛිත ලෙස ප්‍රමාණවත් නොවේ, ඒවා ආවරණය කළ හැකි වැරදි වලින් සුළු ප්‍රතිශතයක් පමණි.
//! 0Python ස්ක්‍රිප්ටයක් ලෙස `src/etc/test-float-parse` නාමාවලියෙහි වඩාත් පුළුල් පරීක්ෂණ පිහිටා ඇත.
//!
//! පූර්ණ සංඛ්‍යා පිටාර ගැලීම පිළිබඳ සටහනක්: මෙම ගොනුවේ බොහෝ කොටස් දශම on ාත `e` සමඟ අංක ගණිතය සිදු කරයි.
//! මූලික වශයෙන්, අපි දශම ලක්ෂ්‍යය වටා මාරු කරමු: පළමු දශම අංකයට පෙර, අවසාන දශම අංකයට පසුව සහ එසේ ය.නොසැලකිලිමත් ලෙස කළහොත් මෙය පිටාර ගැලිය හැකිය.
//! "sufficient" යන්නෙන් අදහස් කරන්නේ "such that the exponent +/- the number of decimal digits fits into a 64 bit integer" යන්නෙන් ප්‍රමාණවත් තරම් කුඩා on ාතකයන් පමණක් ලබා දීම සඳහා අපි විග්‍රහ කරන උප මොඩියුලය මත රඳා සිටිමු.
//! විශාල on ාතකයන් පිළිගනු ලැබේ, නමුත් අපි ඔවුන් සමඟ ගණිතය කරන්නේ නැත, ඒවා වහාම {positive,negative} {zero,infinity} බවට පරිවර්තනය වේ.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::num::digits_to_big;
use self::parse::{parse_decimal, Decimal, ParseResult, Sign};
use self::rawfp::RawFloat;

mod algorithm;
mod num;
mod table;
// මේ දෙදෙනාටම ඔවුන්ගේම පරීක්ෂණ තිබේ.
pub mod parse;
pub mod rawfp;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// 10 වන පාදයේ ඇති නූලක් පාවෙන බවට පරිවර්තනය කරයි.
            /// විකල්ප දශම on ාතයක් පිළිගනී.
            ///
            /// මෙම ශ්‍රිතය වැනි නූල් පිළිගනී
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', හෝ ඒ හා සමානව, '2.5e10'
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', හෝ, සමානව, '0.5'
            /// * 'inf', '-inf', 'NaN'
            ///
            /// සුදු අවකාශය මෙහෙයවීම සහ පසුපස යාම දෝෂයක් නියෝජනය කරයි.
            ///
            /// # Grammar
            ///
            /// පහත දැක්වෙන [EBNF] ව්‍යාකරණයට අනුකූල වන සියලුම නූල්වල ප්‍රති X ලයක් ලෙස [`Ok`] ආපසු ලැබෙනු ඇත:
            ///
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'NaN' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= [eE] Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # දන්නා දෝෂ
            ///
            /// සමහර අවස්ථාවන්හිදී, වලංගු පාවීමක් නිර්මාණය කළ යුතු සමහර නූල් වෙනුවට දෝෂයක් ඇතිවේ.
            /// විස්තර සඳහා [issue #31407] බලන්න.
            ///
            /// [issue #31407]: https://github.com/rust-lang/rust/issues/31407
            ///
            /// # Arguments
            ///
            /// * src, නූලක්
            ///
            /// # ප්‍රතිලාභ අගය
            ///
            /// `Err(ParseFloatError)` නූල වලංගු අංකයක් නියෝජනය නොකළේ නම්.
            /// එසේ නොමැතිනම්, `Ok(n)` එහිදී `n` යනු `src` මගින් නිරූපණය වන පාවෙන ලක්ෂ්‍ය අංකය වේ.
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// පාවෙන විග්‍රහ කිරීමේදී ආපසු ලබා දිය හැකි දෝෂයකි.
///
/// මෙම දෝෂය [`f32`] සහ [`f64`] සඳහා [`FromStr`] ක්‍රියාත්මක කිරීම සඳහා දෝෂ වර්ගය ලෙස භාවිතා කරයි.
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {}", e);
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// ඉතිරිය පරීක්ෂා කිරීම හෝ වලංගු කිරීමකින් තොරව දශම නූලක් ලකුණට බෙදන්න.
fn extract_sign(s: &str) -> (Sign, &str) {
    match s.as_bytes()[0] {
        b'+' => (Sign::Positive, &s[1..]),
        b'-' => (Sign::Negative, &s[1..]),
        // නූල අවලංගු නම්, අපි කිසි විටෙකත් ලකුණ භාවිතා නොකරන්නෙමු, එබැවින් අපට මෙහි වලංගු කිරීම අවශ්‍ය නොවේ.
        _ => (Sign::Positive, s),
    }
}

/// දශම නූලක් පාවෙන ලක්ෂ්‍ය අංකයක් බවට පරිවර්තනය කරයි.
fn dec2flt<T: RawFloat>(s: &str) -> Result<T, ParseFloatError> {
    if s.is_empty() {
        return Err(pfe_empty());
    }
    let (sign, s) = extract_sign(s);
    let flt = match parse_decimal(s) {
        ParseResult::Valid(decimal) => convert(decimal)?,
        ParseResult::ShortcutToInf => T::INFINITY,
        ParseResult::ShortcutToZero => T::ZERO,
        ParseResult::Invalid => match s {
            "inf" => T::INFINITY,
            "NaN" => T::NAN,
            _ => {
                return Err(pfe_invalid());
            }
        },
    };

    match sign {
        Sign::Positive => Ok(flt),
        Sign::Negative => Ok(-flt),
    }
}

/// දශමයේ සිට පාවෙන පරිවර්තනය සඳහා වන ප්‍රධාන වැඩමුළුව: සියලු පෙර සැකසුම් සකස් කර සත්‍ය පරිවර්තනය කළ යුත්තේ කුමන ඇල්ගොරිතමදැයි සොයා බලන්න.
///
fn convert<T: RawFloat>(mut decimal: Decimal<'_>) -> Result<T, ParseFloatError> {
    simplify(&mut decimal);
    if let Some(x) = trivial_cases(&decimal) {
        return Ok(x);
    }
    // Remove/shift දශම ලක්ෂයෙන් පිටත.
    let e = decimal.exp - decimal.fractional.len() as i64;
    if let Some(x) = algorithm::fast_path(decimal.integral, decimal.fractional, e) {
        return Ok(x);
    }
    // Big32x40 බිටු 1280 කට සීමා වන අතර එය දශම සංඛ්‍යා 385 කට පරිවර්තනය වේ.
    // අපි මෙය ඉක්මවා ගියහොත්, අපි බිඳ වැටෙනු ඇත, එබැවින් අපි සමීප වීමට පෙර දෝෂය (10 ^ 10 ඇතුළත).
    let upper_bound = bound_intermediate_digits(&decimal, e);
    if upper_bound > 375 {
        return Err(pfe_invalid());
    }
    let f = digits_to_big(decimal.integral, decimal.fractional);

    // දැන් on ාතකය නිසැකවම බිට් 16 ට ගැලපේ, එය ප්‍රධාන ඇල්ගොරිතම පුරා භාවිතා වේ.
    let e = e as i16;
    // FIXME මෙම සීමාවන් තරමක් ගතානුගතික ය.
    // බෙලරොෆොන් හි අසාර්ථක ප්‍රකාරයන් වඩාත් ප්‍රවේශමෙන් විශ්ලේෂණය කිරීමෙන් විශාල අවස්ථාවන් සඳහා එය භාවිතා කිරීමට ඉඩ ලබා දේ.
    let exponent_in_range = table::MIN_E <= e && e <= table::MAX_E;
    let value_in_range = upper_bound <= T::MAX_NORMAL_DIGITS as u64;
    if exponent_in_range && value_in_range {
        Ok(algorithm::bellerophon(&f, e))
    } else {
        Ok(algorithm::algorithm_m(&f, e))
    }
}

// ලියා ඇති පරිදි, මෙය නරක ලෙස ප්‍රශස්තිකරණය කරයි (#27130 බලන්න, එය කේතයේ පැරණි අනුවාදයක් ගැන සඳහන් වුවද).
// `inline(always)` ඒ සඳහා වන විසඳුමකි.
// සමස්තයක් ලෙස ඇමතුම් අඩවි දෙකක් පමණක් ඇති අතර එය කේත ප්‍රමාණය නරක අතට හැරෙන්නේ නැත.

/// On ාතකය වෙනස් කිරීම අවශ්‍ය වූ විට පවා හැකි සෑම විටම ශුන්‍ය තීරු ඉවත් කරන්න
#[inline(always)]
fn simplify(decimal: &mut Decimal<'_>) {
    let is_zero = &|&&d: &&u8| -> bool { d == b'0' };
    // මෙම ශුන්‍යයන් කැපීමෙන් කිසිවක් වෙනස් නොවන නමුත් වේගවත් මාවත (<ඉලක්කම් 15) සක්‍රීය කළ හැකිය.
    let leading_zeros = decimal.integral.iter().take_while(is_zero).count();
    decimal.integral = &decimal.integral[leading_zeros..];
    let trailing_zeros = decimal.fractional.iter().rev().take_while(is_zero).count();
    let end = decimal.fractional.len() - trailing_zeros;
    decimal.fractional = &decimal.fractional[..end];
    // 0.0 ... x සහ x ... 0.0 ආකෘතියේ සංඛ්‍යා සරල කරන්න, on ාතකය ඒ අනුව සකස් කරන්න.
    // මෙය සැමවිටම ජයග්‍රහණයක් නොවිය හැකිය (සමහර විට වේගවත් සංඛ්‍යා මාර්ගයෙන් සමහර සංඛ්‍යා තල්ලු කරයි), නමුත් එය අනෙක් කොටස් සැලකිය යුතු ලෙස සරල කරයි (විශේෂයෙන්, වටිනාකමේ විශාලත්වය ආසන්න වශයෙන්).
    //
    if decimal.integral.is_empty() {
        let leading_zeros = decimal.fractional.iter().take_while(is_zero).count();
        decimal.fractional = &decimal.fractional[leading_zeros..];
        decimal.exp -= leading_zeros as i64;
    } else if decimal.fractional.is_empty() {
        let trailing_zeros = decimal.integral.iter().rev().take_while(is_zero).count();
        let end = decimal.integral.len() - trailing_zeros;
        decimal.integral = &decimal.integral[..end];
        decimal.exp += trailing_zeros as i64;
    }
}

/// දී ඇති දශමයේ වැඩ කරන විට ඇල්ගොරිතම ආර් සහ ඇල්ගොරිතම එම් ගණනය කරනු ලබන විශාලතම අගයේ (log10) ප්‍රමාණයට ඉක්මන්-අපිරිසිදු ඉහළ මායිමක් ලබා දෙයි.
///
fn bound_intermediate_digits(decimal: &Decimal<'_>, e: i64) -> u64 {
    // අප සඳහා අතිශයින්ම ආදාන පෙරහන් කරන trivial_cases() සහ පාර්සර් වලට ස්තූතිවන්ත වෙමින් මෙහි පිටාර ගැලීම ගැන අපි ඕනෑවට වඩා කරදර විය යුතු නැත.
    //
    let f_len: u64 = decimal.integral.len() as u64 + decimal.fractional.len() as u64;
    if e >= 0 {
        // E>=0 නඩුවේදී, ඇල්ගොරිතම දෙකම `f * 10^e` පමණ ගණනය කරයි.
        // ඇල්ගොරිතම R මේ සමඟ සංකීර්ණ ගණනය කිරීම් සිදු කරයි, නමුත් ඉහළ සීමාව සඳහා එය නොසලකා හැරිය හැකි බැවින් එය පෙර භාගය අඩු කරයි, එබැවින් අපට එහි බෆර ඕනෑ තරම් තිබේ.
        //
        f_len + (e as u64)
    } else {
        // ඊ <0 නම්, ඇල්ගොරිතම ආර් දළ වශයෙන් එකම දේ කරයි, නමුත් ඇල්ගොරිතම එම් වෙනස් වේ:
        // `f << k / 10^e` යනු පරාසයේ වැදගත්කමක් ඇති ධනාත්මක සංඛ්‍යාවක් k සොයා ගැනීමට එය උත්සාහ කරයි.
        // මෙහි ප්‍රති result ලය වනුයේ `2^53 *f* 10^e` <`10^17 *f* 10^e` පමණ වේ.
        // මෙය අවුලුවන එක් ආදානය 0.33 ... 33 (375 x 3) වේ.
        f_len + e.unsigned_abs() + 17
    }
}

/// දශම සංඛ්‍යා දෙස නොබලා පැහැදිලි පිටාර ගැලීම් සහ පිටාර ගැලීම් හඳුනා ගනී.
fn trivial_cases<T: RawFloat>(decimal: &Decimal<'_>) -> Option<T> {
    // ශුන්‍ය වූ නමුත් ඒවා simplify() මගින් ඉවත් කරන ලදී
    if decimal.integral.is_empty() && decimal.fractional.is_empty() {
        return Some(T::ZERO);
    }
    // මෙය ceil(log10(the real value)) හි ගොරහැඩි දළ විශ්ලේෂණයකි.
    // ආදාන දිග ඉතා කුඩා බැවින් (අවම වශයෙන් 2 ^ 64 හා සසඳන විට) මෙහි පිටාර ගැලීම ගැන අපි ඕනෑවට වඩා කරදර විය යුතු නැත. සහ නිරපේක්ෂ අගය 10 ^ 18 ට වඩා වැඩි on ාතකයන් දැනටමත් හසුරුවයි (එය තවමත් 10 ^ 19 කෙටි 2 ^ 64 හි).
    //
    //
    let max_place = decimal.exp + decimal.integral.len() as i64;
    if max_place > T::INF_CUTOFF {
        return Some(T::INFINITY);
    } else if max_place < T::ZERO_CUTOFF {
        return Some(T::ZERO);
    }
    None
}