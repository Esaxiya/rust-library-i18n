//! පෝරමයේ දශම නූලක් වලංගු කිරීම සහ දිරාපත් වීම:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! වෙනත් වචන වලින් කිවහොත්, ව්‍යතිරේක දෙකක් සහිත සම්මත පාවෙන ලක්ෂ්‍ය සින්ටැක්ස්: කිසිදු සලකුණක් සහ "inf" සහ "NaN" හැසිරවීමක් නොමැත.මේවා හසුරුවනු ලබන්නේ (super::dec2flt) ධාවක ශ්‍රිතයෙනි.
//!
//! වලංගු යෙදවුම් හඳුනා ගැනීම සාපේක්ෂව පහසු වුවද, මෙම මොඩියුලය අසංඛ්‍යාත අවලංගු වෙනස්කම් ප්‍රතික්ෂේප කළ යුතු අතර, කිසි විටෙකත් panic නොවිය යුතු අතර අනෙක් මොඩියුලයන් panic (හෝ පිටාර ගැලීම) මත රඳා නොපවතින බවට බොහෝ චෙක්පත් සිදු කරයි.
//!
//! තත්වය වඩාත් නරක අතට හැරවීම සඳහා, ආදානය හරහා එක වරකින් සිදුවන සියල්ල.
//! එබැවින්, ඕනෑම දෙයක් වෙනස් කිරීමේදී ප්‍රවේශම් වන්න, අනෙක් මොඩියුල සමඟ දෙවරක් පරීක්ෂා කරන්න.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// දශම නූලක සිත්ගන්නාසුලු කොටස්.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// දශම on ාතකය, දශම සංඛ්‍යා 18 ට වඩා අඩු බව සහතික කර ඇත.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// ආදාන නූල වලංගු පාවෙන ලක්ෂ්‍ය අංකයක් දැයි පරීක්ෂා කර, එසේ නම්, එහි අනුකලනය, භාගික කොටස සහ එහි on ාතකය සොයා ගන්න.
/// සං .ා හසුරුවන්නේ නැත.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // 'e' ට පෙර ඉලක්කම් නොමැත
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // ලක්ෂ්‍යයට පෙර හෝ පසුව අපට අවම වශයෙන් තනි ඉලක්කම් අවශ්‍ය වේ.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // භාගික කොටස පසු කුණු පසුපස
            }
        }
        _ => Invalid, // පළමු ඉලක්කම් නූල් පසු කුණු පසුපස
    }
}

/// පළමු ඉලක්කම් නොවන අක්‍ෂරය දක්වා දශම සංඛ්‍යා කපා දමයි.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// On ාතීය නිස්සාරණය සහ දෝෂ පරීක්ෂා කිරීම.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // On ාතයෙන් පසු කුණු පසුපස
    }
    if number.is_empty() {
        return Invalid; // හිස් on ාතයක්
    }
    // මෙම අවස්ථාවෙහිදී, අපට නිසැකවම වලංගු ඉලක්කම් මාලාවක් තිබේ.`i64` එකකට දැමීමට එය දිගු විය හැකි නමුත් එය එතරම් විශාල නම් ආදානය නිසැකවම ශුන්‍ය හෝ අනන්තය වේ.
    // දශම සංඛ්‍යා වල සෑම ශුන්‍යයක්ම on ාතයට +/-1 මගින් පමණක් ගැලපෙන බැවින්, exp=10 ^ 18 දී, ආදාන දුරස්ථව සීමිත වීමට ආසන්න වීමට ශුන්‍යයේ එක්ස්බයිට් (!) 17 ක් විය යුතුය.
    //
    // මෙය හරියටම අප විසින් සපුරාලිය යුතු භාවිත අවස්ථාවක් නොවේ.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}