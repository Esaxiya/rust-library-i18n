//! ධනාත්මක අයිඊඊඊ 754 පාවෙන මත බිට් ෆිඩ්ලිං.සෘණ සංඛ්‍යා එසේ නොවන අතර ඒවා හැසිරවිය යුතු නොවේ.
//! සාමාන්‍ය පාවෙන ලක්ෂ්‍ය සංඛ්‍යා වලට කැනොනිකල් නිරූපණයක් (frac, exp) ඇත, එනම් අගය 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)), N යනු බිටු ගණන වේ.
//!
//! උපසිරැසි තරමක් වෙනස් හා අමුතු ය, නමුත් එකම මූලධර්මය අදාළ වේ.
//!
//! කෙසේ වෙතත්, මෙහිදී අපි ඒවා f ධනාත්මක (sig, k) ලෙස නිරූපණය කරමු, එනම් අගය f *
//! 2 <sup>ඊ</sup> ."hidden bit" පැහැදිළි කිරීමට අමතරව, මෙය ඊනියා මැන්ටිස්සා මාරුව මගින් on ාතකය වෙනස් කරයි.
//!
//! වෙනත් ක්‍රමයක් තබන්න, සාමාන්‍යයෙන් පාවෙන දේ (1) ලෙස ලියා ඇති නමුත් මෙහි ඒවා (2) ලෙස ලියා ඇත:
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! අපි (1)**භාගික නිරූපණය** සහ (2)**සමෝධානික නිරූපණය** ලෙස හඳුන්වමු.
//!
//! මෙම මොඩියුලයේ බොහෝ කාර්යයන් හසුරුවන්නේ සාමාන්‍ය සංඛ්‍යා පමණි.Dec2flt චර්යාවන් ඉතා කුඩා හා ඉතා විශාල සංඛ්‍යාවක් සඳහා විශ්වීයව නිවැරදි මන්දගාමී මාවත (ඇල්ගොරිතම M) ගතානුගතිකව ගනී.
//! එම ඇල්ගොරිතමයට අවශ්‍ය වන්නේ next_float() පමණි.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// `f32` සහ `f64` සඳහා වන සියලුම පරිවර්තන කේත මූලික වශයෙන් අනුපිටපත් නොකිරීමට trait සහායකය.
///
/// මෙය අවශ්‍ය වන්නේ මන්දැයි දෙමාපිය මොඩියුලයේ ලේඛනය බලන්න.
///
/// **කිසි විටෙකත්** වෙනත් වර්ග සඳහා ක්‍රියාත්මක නොකළ යුතුද නැතහොත් dec2flt මොඩියුලයෙන් පිටත භාවිතා කළ යුතුද?
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// `to_bits` සහ `from_bits` භාවිතා කරන වර්ගය.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// නිඛිලයකට අමු සම්ප්‍රේෂණය සිදු කරයි.
    fn to_bits(self) -> Self::Bits;

    /// නිඛිලයකින් අමු සම්ප්‍රේෂණය සිදු කරයි.
    fn from_bits(v: Self::Bits) -> Self;

    /// මෙම අංකය අයත් වන කාණ්ඩය ලබා දෙයි.
    fn classify(self) -> FpCategory;

    /// මැන්ටිස්සා, on ාතීය සහ පූර්ණ සංඛ්‍යා ලෙස අත්සන් කරයි.
    fn integer_decode(self) -> (u64, i16, i8);

    /// පාවෙන විකේතනය කරයි.
    fn unpack(self) -> Unpacked;

    /// හරියටම නිරූපණය කළ හැකි කුඩා නිඛිලයකින් විකාශනය වේ.
    /// Panic නිඛිලය නිරූපණය කළ නොහැකි නම්, මෙම මොඩියුලයේ අනෙක් කේතය කිසි විටෙකත් එසේ වීමට ඉඩ නොතබයි.
    fn from_int(x: u64) -> Self;

    /// පෙර ගණනය කළ වගුවකින් 10 <sup>ඊ</sup> අගය ලබා ගනී.
    /// `e >= CEIL_LOG5_OF_MAX_SIG` සඳහා Panics.
    fn short_fast_pow10(e: usize) -> Self;

    /// නම කියන දේ.
    /// අභ්‍යන්තර විද්‍යාව හසුරුවා ගැනීමට සහ එල්එල්වීඑම් නිරන්තරයෙන් එය නැමෙනු ඇතැයි අපේක්ෂා කරනවාට වඩා දෘඩ කේත කිරීම පහසුය.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // පිටාර ගැලීමක් හෝ බිංදුවක් හෝ නිෂ්පාදනය කළ නොහැකි යෙදවුම්වල දශම සංඛ්‍යා වලට ගතානුගතික බැඳීමක්
    /// subnormals.බොහෝ විට සාමාන්‍ය සාමාන්‍ය අගයෙහි දශම on ාතකය, එබැවින් නම.
    const MAX_NORMAL_DIGITS: usize;

    /// වඩාත්ම වැදගත් දශම සංඛ්‍යාංකයට වඩා වැඩි ස්ථාන අගයක් ඇති විට, එම සංඛ්‍යාව නිසැකවම අනන්තය දක්වා වටයනු ලැබේ.
    ///
    const INF_CUTOFF: i64;

    /// වඩාත්ම වැදගත් දශම සංඛ්‍යාංකයට වඩා අඩු අගයක් ඇති විට, එම සංඛ්‍යාව නිසැකවම ශුන්‍යයට වටයනු ලැබේ.
    ///
    const ZERO_CUTOFF: i64;

    /// On ාතයේ බිටු ගණන.
    const EXP_BITS: u8;

    /// සැඟවුණු බිට් ද ඇතුළුව * වැදගත්කමේ බිටු ගණන.
    const SIG_BITS: u8;

    /// සැඟවුණු බිට් හැර * වැදගත්කමේ බිටු ගණන.
    const EXPLICIT_SIG_BITS: u8;

    /// භාගික නිරූපණයෙහි උපරිම නෛතික on ාතකය.
    const MAX_EXP: i16;

    /// උපසිරැසි හැරුණු විට භාගික නිරූපණයෙහි අවම නෛතික on ාතකය.
    const MIN_EXP: i16;

    /// `MAX_EXP` සමෝධානික නිරූපණය සඳහා, එනම්, මාරුව යොදනු ලැබේ.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` කේතනය කර ඇත (එනම්, ඕෆ්සෙට් නැඹුරුව සමඟ)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` සමෝධානික නිරූපණය සඳහා, එනම්, මාරුව යොදනු ලැබේ.
    const MIN_EXP_INT: i16;

    /// සමෝධානික නිරූපණයේ උපරිම සාමාන්‍යකරණය කළ වැදගත්කම.
    const MAX_SIG: u64;

    /// සමෝධානික නිරූපණයේ අවම සාමාන්‍යකරණය කළ වැදගත්කම.
    const MIN_SIG: u64;
}

// බොහෝ දුරට #34344 සඳහා වන ක්‍රියාමාර්ගයකි.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// මැන්ටිස්සා, on ාතීය සහ පූර්ණ සංඛ්‍යා ලෙස අත්සන් කරයි.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // On ාතීය නැඹුරුව + මැන්ටිස්සා මාරුව
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // සියලුම වේදිකාවල `as` නිවැරදිව රවුම් වේද යන්න rkruppe අවිනිශ්චිතය.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// මැන්ටිස්සා, on ාතීය සහ පූර්ණ සංඛ්‍යා ලෙස අත්සන් කරයි.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // On ාතීය නැඹුරුව + මැන්ටිස්සා මාරුව
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // සියලුම වේදිකාවල `as` නිවැරදිව රවුම් වේද යන්න rkruppe අවිනිශ්චිතය.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// `Fp` ආසන්නතම යන්ත්‍ර පාවෙන වර්ගයට පරිවර්තනය කරයි.
/// අසාමාන්‍ය ප්‍රති .ල හසුරුවන්නේ නැත.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 64 බිට්, එබැවින් xe ට මැන්ටිස්සා මාරුව 63 ක් ඇත
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// 64-බිට් වැදගත්කම සහ T::SIG_BITS බිටු වලට අර්ධ-ඉරට්ටේ සිට වට කරන්න.
/// On ාතීය පිටාර ගැලීම් හසුරුවන්නේ නැත.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // මැන්ටිස්සා මාරුව සකසන්න
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// සාමාන්‍යකරණය කළ සංඛ්‍යා සඳහා `RawFloat::unpack()` ප්‍රතිලෝම කරන්න.
/// සාමාන්‍යකරණය කරන ලද සංඛ්‍යා සඳහා වැදගත්කම හෝ on ාතයක් වලංගු නොවේ නම් Panics.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // සැඟවුණු බිට් ඉවත් කරන්න
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // On ාතීය නැඹුරුව සහ මැන්ටිස්සා මාරුව සඳහා on ාතකය සකසන්න
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // 0 ("+") හි සං sign ා බිට් තබන්න, අපගේ අංක සියල්ලම ධනාත්මක වේ
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// උපස්ථරයක් සාදන්න.0 ක මන්තිස්සයකට ඉඩ දී ශුන්‍යය සාදයි.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // සංකේතාත්මක on ාතයක් 0, සං bit ා බිට් 0, එබැවින් අපට බිටු නැවත අර්ථ දැක්විය යුතුය.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// එෆ්පී සමඟ බිග්නම් දළ වශයෙන්.0.5 ULP තුළ අර්ධ-ඉරට්ටේ සහිත වට.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // `start` දර්ශකයට පෙර අපි සියලු බිටු කපා දැමුවෙමු, එනම්, අපි `start` ප්‍රමාණයකින් right ලදායි ලෙස මාරුවෙමු, එබැවින් මෙය අපට අවශ්‍ය on ාතකය ද වේ.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // කපා දැමූ බිටු මත පදනම්ව (half-to-even) වටය.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// විශාලතම පාවෙන ලක්ෂ්‍ය අංකය තර්කයට වඩා තදින් කුඩා වේ.
/// උප අසාමාන්‍ය, ශුන්‍ය හෝ on ාතීය පිටාර ගැලීම් හසුරුවන්නේ නැත.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// තර්කයට වඩා තදින් කුඩාම පාවෙන ලක්ෂ්‍ය අංකය සොයා ගන්න.
// මෙම මෙහෙයුම සංතෘප්ත වේ, එනම් next_float(inf) ==inf.
// මෙම මොඩියුලයේ බොහෝ කේත මෙන් නොව, මෙම ශ්‍රිතය ශුන්‍යය, උප අසාමාන්‍යතා සහ අනන්තය හසුරුවයි.
// කෙසේ වෙතත්, මෙහි ඇති අනෙකුත් සියලුම කේත මෙන්, එය NaN සහ negative ණ සංඛ්‍යා සමඟ කටයුතු නොකරයි.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // මෙය සත්‍ය වීමට තරම් හොඳ නැති බව පෙනේ, නමුත් එය ක්‍රියාත්මක වේ.
        // 0.0 සියලු ශුන්‍ය වචනය ලෙස කේතනය කර ඇත.උපසිරැසි 0x000m ... m මෙහි m යනු mantissa වේ.
        // විශේෂයෙන් කුඩාම උප සාමාන්‍යය 0x0 ... 01 වන අතර විශාලතම 0x000F ... F.
        // කුඩාම සාමාන්‍ය අංකය 0x0010 ... 0, එබැවින් මෙම කෙළවරේ නඩුවද ක්‍රියාත්මක වේ.
        // වර්ධකය මැන්ටිස්සා පිටාර ගැලුවහොත්, කැරි බිට් අපට අවශ්‍ය පරිදි on ාතකය වැඩි කරන අතර මැන්ටිස්සා බිටු ශුන්‍ය වේ.
        // සැඟවුණු බිට් සම්මුතිය නිසා, මෙයද අපට අවශ්‍ය දේමයි!
        // අවසාන වශයෙන්, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}