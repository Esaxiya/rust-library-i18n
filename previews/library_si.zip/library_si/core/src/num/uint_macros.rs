macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// මෙම නිඛිල වර්ගය මගින් නිරූපණය කළ හැකි කුඩාම අගය.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// මෙම නිඛිල වර්ගය මගින් නිරූපණය කළ හැකි විශාලතම අගය.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// මෙම නිඛිල වර්ගයේ ප්‍රමාණය බිටු වලින්.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// දී ඇති පාදමක ඇති නූල් පෙත්තක් පූර්ණ සංඛ්‍යාවක් බවට පරිවර්තනය කරයි.
        ///
        /// මෙම නූල ඉලක්කම් වලින් පසුව විකල්ප `+` ලකුණක් වනු ඇතැයි අපේක්ෂා කෙරේ.
        ///
        /// සුදු අවකාශය මෙහෙයවීම සහ පසුපස යාම දෝෂයක් නියෝජනය කරයි.
        /// ඉලක්කම් යනු `radix` මත පදනම්ව මෙම අක්ෂරවල උප කුලකයකි:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// `radix` 2 සිට 36 දක්වා පරාසයක නොමැති නම් මෙම ශ්‍රිතය panics වේ.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// `self` හි ද්විමය නිරූපණයෙහි ඇති සංඛ්‍යාව ලබා දෙයි.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// `self` හි ද්විමය නිරූපණයේ ඇති ශුන්‍ය ගණන ලබා දෙයි.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// `self` හි ද්විමය නිරූපණයේ ප්‍රමුඛ ශුන්‍ය ගණන ලබා දෙයි.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// `self` හි ද්විමය නිරූපණය තුළ පසුපස ශුන්‍ය ගණන ලබා දෙයි.
        ///
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// `self` හි ද්විමය නිරූපණයෙහි ප්‍රමුඛයන් ගණන ලබා දෙයි.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// `self` හි ද්විමය නිරූපණය තුළ පසුපස සිටින අයගේ සංඛ්‍යාව ලබා දෙයි.
        ///
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// `n` හි නිශ්චිත ප්‍රමාණයකින් බිටු වමට මාරු කරයි, එහි ප්‍රති ing ලයක් ලෙස ඇති වූ නිඛිලයේ අවසානයට කප්පාදු කළ බිටු ඔතා.
        ///
        ///
        /// මෙය `<<` මාරුවීමේ ක්‍රියාකරුගේ එකම මෙහෙයුම නොවන බව කරුණාවෙන් සලකන්න!
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// නිශ්චිත ප්‍රමාණයක් වන `n` මගින් බිටු දකුණට මාරු කරයි, එහි ප්‍රති ing ලයක් ලෙස ඇති වූ පූර්ණ සංඛ්‍යාවේ ආරම්භයට කප්පාදු කළ බිටු ඔතා.
        ///
        ///
        /// මෙය `>>` මාරුවීමේ ක්‍රියාකරුගේ එකම මෙහෙයුම නොවන බව කරුණාවෙන් සලකන්න!
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// නිඛිලයේ බයිට් අනුපිළිවෙල ආපසු හරවයි.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// m= n.swap_bytes() ඉඩ දෙන්න;
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// නිඛිලයේ බිටු අනුපිළිවෙල ආපසු හරවයි.
        /// අවම වශයෙන් සැලකිය යුතු බිට් වඩාත්ම වැදගත් බිට් බවට පත්වේ, දෙවන අවම-වැදගත් බිට් දෙවන වඩාත් වැදගත් බිට් බවට පත්වේ.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// m= n.reverse_bits() ඉඩ දෙන්න;
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// විශාල එන්ඩියන් සිට ඉලක්කයේ අවසානය දක්වා පූර්ණ සංඛ්‍යාවක් පරිවර්තනය කරයි.
        ///
        /// විශාල එන්ඩියන් මත මෙය විකල්පයක් නොවේ.
        /// කුඩා එන්ඩියන් මත බයිට් මාරු කරනු ලැබේ.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// cfg නම්! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } else {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// කුඩා එන්ඩියන් සිට ඉලක්කයේ අවසානය දක්වා පූර්ණ සංඛ්‍යාවක් පරිවර්තනය කරයි.
        ///
        /// කුඩා එන්ඩියන් මත මෙය විකල්පයක් නොවේ.
        /// විශාල එන්ඩියන් මත බයිට් මාරු කරනු ලැබේ.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// cfg නම්! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } else {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// `self` ඉලක්කයේ එන්ඩියනස් සිට විශාල එන්ඩියන් බවට පරිවර්තනය කරයි.
        ///
        /// විශාල එන්ඩියන් මත මෙය විකල්පයක් නොවේ.
        /// කුඩා එන්ඩියන් මත බයිට් මාරු කරනු ලැබේ.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// cfg නම්! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// X else { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // නැත්නම් විය යුතුද?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// `self` ඉලක්කයේ එන්ඩියනස් සිට කුඩා එන්ඩියන් බවට පරිවර්තනය කරයි.
        ///
        /// කුඩා එන්ඩියන් මත මෙය විකල්පයක් නොවේ.
        /// විශාල එන්ඩියන් මත බයිට් මාරු කරනු ලැබේ.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// cfg නම්! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// X else { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// පරීක්ෂා කරන ලද පූර්ණ සංඛ්‍යා එකතු කිරීම.
        /// `self + rhs` ගණනය කරයි, පිටාර ගැලීමක් සිදුවුවහොත් `None` ආපසු එයි.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// පරීක්ෂා නොකළ පූර්ණ සංඛ්‍යා එකතු කිරීම.පිටාර ගැලීම සිදුවිය නොහැකි යැයි උපකල්පනය කරමින් `self + rhs` ගණනය කරයි.
        /// මෙහි ප්‍රති results ලය වන්නේ නිර්වචනය නොකළ හැසිරීමයි
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // ආරක්ෂාව: අමතන්නා `unchecked_add` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// පරීක්ෂා කරන ලද පූර්ණ සංඛ්‍යා අඩු කිරීම.
        /// `self - rhs` ගණනය කරයි, පිටාර ගැලීමක් සිදුවුවහොත් `None` ආපසු එයි.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// පරීක්ෂා නොකළ පූර්ණ සංඛ්‍යා අඩු කිරීම.පිටාර ගැලීම සිදුවිය නොහැකි යැයි උපකල්පනය කරමින් `self - rhs` ගණනය කරයි.
        /// මෙහි ප්‍රති results ලය වන්නේ නිර්වචනය නොකළ හැසිරීමයි
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // ආරක්ෂාව: අමතන්නා `unchecked_sub` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// පරීක්ෂා කරන ලද පූර්ණ සංඛ්‍යා ගුණනය.
        /// `self * rhs` ගණනය කරයි, පිටාර ගැලීමක් සිදුවුවහොත් `None` ආපසු එයි.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// පරීක්ෂා නොකළ පූර්ණ සංඛ්‍යා ගුණනය.පිටාර ගැලීම සිදුවිය නොහැකි යැයි උපකල්පනය කරමින් `self * rhs` ගණනය කරයි.
        /// මෙහි ප්‍රති results ලය වන්නේ නිර්වචනය නොකළ හැසිරීමයි
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // ආරක්ෂාව: අමතන්නා `unchecked_mul` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// පූර්ණ සංඛ්‍යා බෙදීම පරීක්ෂා කර ඇත.
        /// `self / rhs` ගණනය කරයි, `rhs == 0` නම් `None` ආපසු එයි.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // ආරක්ෂාව: ශුන්‍යයෙන් බෙදීම ඉහත පරීක්ෂා කර ඇති අතර අත්සන් නොකළ වර්ග වලට වෙනත් කිසිවක් නොමැත
                // බෙදීම සඳහා අසමත් වීමේ මාතයන්
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// යුක්ලීඩියානු අංශය පරීක්ෂා කර ඇත.
        /// `self.div_euclid(rhs)` ගණනය කරයි, `rhs == 0` නම් `None` ආපසු එයි.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// පරීක්ෂා කරන ලද පූර්ණ සංඛ්‍යා ඉතිරිය.
        /// `self % rhs` ගණනය කරයි, `rhs == 0` නම් `None` ආපසු එයි.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // ආරක්ෂාව: ශුන්‍යයෙන් බෙදීම ඉහත පරීක්ෂා කර ඇති අතර අත්සන් නොකළ වර්ග වලට වෙනත් කිසිවක් නොමැත
                // බෙදීම සඳහා අසමත් වීමේ මාතයන්
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// පරීක්ෂා කළ යුක්ලීඩියානු මොඩියුලය.
        /// `self.rem_euclid(rhs)` ගණනය කරයි, `rhs == 0` නම් `None` ආපසු එයි.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// ප්‍රතික්ෂේප කිරීම පරීක්ෂා කර ඇත.`-self` ගණනය කරයි, `ස්වයං==හැර `None` ආපසු එයි
        /// 0`.
        ///
        /// ඕනෑම ධනාත්මක නිඛිලයක් නිෂේධනය කිරීම පිටාර ගලන බව සලකන්න.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// පරීක්ෂා කළ මාරුව වමට.
        /// `self << rhs` ගණනය කරයි, `rhs` `self` හි බිටු ගණනට වඩා විශාල හෝ සමාන නම් `None` ආපසු එයි.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// මාරුව දකුණට පරීක්ෂා කර ඇත.
        /// `self >> rhs` ගණනය කරයි, `rhs` `self` හි බිටු ගණනට වඩා විශාල හෝ සමාන නම් `None` ආපසු එයි.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// On ාතීයකරණය පරීක්ෂා කර ඇත.
        /// `self.pow(exp)` ගණනය කරයි, පිටාර ගැලීමක් සිදුවුවහොත් `None` ආපසු එයි.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // exp!=0 සිට, අවසානයේ exp 1 විය යුතුය.
            // On ාතයේ අවසාන කොටස සමඟ වෙන වෙනම කටයුතු කරන්න, මන්දයත් පසුව පාදම වර්ග කිරීම අවශ්‍ය නොවන අතර අනවශ්‍ය පිටාර ගැලීමක් සිදුවිය හැකිය.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// පූර්ණ සංඛ්‍යා එකතු කිරීම සංතෘප්ත කිරීම.
        /// `self + rhs` ගණනය කරයි, පිටාර ගැලීම වෙනුවට සංඛ්‍යාත්මක සීමාවන්හි සංතෘප්ත වේ.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// පූර්ණ සංඛ්‍යා අඩු කිරීම සංතෘප්ත කිරීම.
        /// `self - rhs` ගණනය කරයි, පිටාර ගැලීම වෙනුවට සංඛ්‍යාත්මක සීමාවන්හි සංතෘප්ත වේ.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// පූර්ණ සංඛ්‍යා ගුණ කිරීම සංතෘප්ත කිරීම.
        /// `self * rhs` ගණනය කරයි, පිටාර ගැලීම වෙනුවට සංඛ්‍යාත්මක සීමාවන්හි සංතෘප්ත වේ.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// පූර්ණ සංඛ්‍යා on ාතීයකරණය සංතෘප්ත කිරීම.
        /// `self.pow(exp)` ගණනය කරයි, පිටාර ගැලීම වෙනුවට සංඛ්‍යාත්මක සීමාවන්හි සංතෘප්ත වේ.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// (modular) එකතු කිරීම.
        /// `self + rhs` ගණනය කරයි, වර්ගයේ මායිම වටා එතීම.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// (modular) අඩු කිරීම.
        /// `self - rhs` ගණනය කරයි, වර්ගයේ මායිම වටා එතීම.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// (modular) ගුණ කිරීම.
        /// `self * rhs` ගණනය කරයි, වර්ගයේ මායිම වටා එතීම.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// මෙම උදාහරණය පූර්ණ සංඛ්‍යා වර්ග අතර බෙදාගෙන ඇති බව කරුණාවෙන් සලකන්න.
        /// `u8` මෙහි භාවිතා කරන්නේ ඇයිද යන්න පැහැදිලි කරයි.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// (modular) අංශය ඔතා.`self / rhs` ගණනය කරයි.
        /// අත්සන් නොකළ වර්ග මත ඔතා බෙදීම සාමාන්‍ය බෙදීමකි.
        /// එතීම කිසි විටෙකත් සිදුවිය නොහැක.
        /// මෙම ශ්‍රිතය පවතී, එවිට සියලු මෙහෙයුම් එතීමේ මෙහෙයුම් වලදී ගණනය කෙරේ.
        ///
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// යුක්ලීඩියානු අංශය ඔතා.`self.div_euclid(rhs)` ගණනය කරයි.
        /// අත්සන් නොකළ වර්ග මත ඔතා බෙදීම සාමාන්‍ය බෙදීමකි.
        /// එතීම කිසි විටෙකත් සිදුවිය නොහැක.
        /// මෙම ශ්‍රිතය පවතී, එවිට සියලු මෙහෙයුම් එතීමේ මෙහෙයුම් වලදී ගණනය කෙරේ.
        /// ධනාත්මක නිඛිල සඳහා, බෙදීමේ සියලු පොදු අර්ථ දැක්වීම් සමාන බැවින් මෙය හරියටම `self.wrapping_div(rhs)` ට සමාන වේ.
        ///
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// (modular) ඉතිරිය ඔතා.`self % rhs` ගණනය කරයි.
        /// අත්සන් නොකළ වර්ගවල ඉතිරිව ඇති ගණනය කිරීම සාමාන්‍ය ඉතිරි ගණනය කිරීම පමණි.
        ///
        /// එතීම කිසි විටෙකත් සිදුවිය නොහැක.
        /// මෙම ශ්‍රිතය පවතී, එවිට සියලු මෙහෙයුම් එතීමේ මෙහෙයුම් වලදී ගණනය කෙරේ.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// යුක්ලීඩියානු මොඩියුලය ඔතා.`self.rem_euclid(rhs)` ගණනය කරයි.
        /// අත්සන් නොකළ වර්ග මත ඔතා ඇති මොඩියුලෝ ගණනය කිරීම සාමාන්‍ය ඉතිරි ගණනය කිරීම පමණි.
        /// එතීම කිසි විටෙකත් සිදුවිය නොහැක.
        /// මෙම ශ්‍රිතය පවතී, එවිට සියලු මෙහෙයුම් එතීමේ මෙහෙයුම් වලදී ගණනය කෙරේ.
        /// ධනාත්මක නිඛිල සඳහා, බෙදීමේ සියලු පොදු අර්ථ දැක්වීම් සමාන බැවින් මෙය හරියටම `self.wrapping_rem(rhs)` ට සමාන වේ.
        ///
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// (modular) නිෂේධනය කිරීම.
        /// `-self` ගණනය කරයි, වර්ගයේ මායිම වටා එතීම.
        ///
        /// අත්සන් නොකළ වර්ගවල negative ණ සමානකම් නොමැති බැවින් මෙම ශ්‍රිතයේ සියලුම යෙදුම් එතී යනු ඇත (`-0` හැර).
        /// අනුරූප අත්සන් කළ වර්ගයේ උපරිමයට වඩා කුඩා අගයන් සඳහා ප්‍රති result ලය අනුරූප අත්සන් කළ අගයට වාත්තු කිරීම හා සමාන වේ.
        ///
        /// ඕනෑම විශාල අගයක් `MAX + 1 - (val - MAX - 1)` ට සමාන වන අතර `MAX` යනු අත්සන් කරන ලද වර්ගයේ උපරිමය වේ.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// මෙම උදාහරණය පූර්ණ සංඛ්‍යා වර්ග අතර බෙදාගෙන ඇති බව කරුණාවෙන් සලකන්න.
        /// `i8` මෙහි භාවිතා කරන්නේ ඇයිද යන්න පැහැදිලි කරයි.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-free bitwise shift-left;
        /// අස්වැන්න `self << mask(rhs)`, එහිදී `mask` විසින් `rhs` හි ඕනෑම ඉහළ ඇණවුම් බිටු ඉවත් කරයි, එමඟින් මාරුව වර්ගයේ බිට්විත් ඉක්මවා යයි.
        ///
        /// මෙය භ්‍රමණය වන වමට සමාන නොවන බව සලකන්න;එහා මෙහා ගෙන යාමේ වම්පසෙහි ආර්එච්එස් වර්ගයේ පරාසයට සීමා වේ, එල්එච්එස් වෙතින් මාරු කරන ලද බිටු අනෙක් කෙළවරට ආපසු ගෙන ඒමට වඩා.
        /// ප්‍රාථමික නිඛිල වර්ග සියල්ලම [`rotate_left`](Self::rotate_left) ශ්‍රිතයක් ක්‍රියාත්මක කරයි, එය ඔබට අවශ්‍ය දේ විය හැකිය.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // සුරක්ෂිතභාවය: වර්ගයෙහි බිට්සයිස් මගින් වෙස්මුහුණු කිරීම අප මාරු නොවන බව සහතික කරයි
            // සීමාවෙන් පිටත
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-free bitwise shift-right;
        /// අස්වැන්න `self >> mask(rhs)`, එහිදී `mask` විසින් `rhs` හි ඕනෑම ඉහළ ඇණවුම් බිටු ඉවත් කරයි, එමඟින් මාරුව වර්ගයේ බිට්විත් ඉක්මවා යයි.
        ///
        /// මෙය භ්‍රමණය වන දකුණට සමාන නොවන බව සලකන්න;එතීෙම් මාරුව-දකුණේ ආර්එච්එස්, එල්එච්එස් වෙතින් මාරු කරන ලද බිටු අනෙක් කෙළවරට ආපසු ගෙන ඒමට වඩා, වර්ගයේ පරාසයට සීමා වේ.
        /// ප්‍රාථමික නිඛිල වර්ග සියල්ලම [`rotate_right`](Self::rotate_right) ශ්‍රිතයක් ක්‍රියාත්මක කරයි, එය ඔබට අවශ්‍ය දේ විය හැකිය.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // සුරක්ෂිතභාවය: වර්ගයෙහි බිට්සයිස් මගින් වෙස්මුහුණු කිරීම අප මාරු නොවන බව සහතික කරයි
            // සීමාවෙන් පිටත
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// (modular) on ාතීය කිරීම.
        /// `self.pow(exp)` ගණනය කරයි, වර්ගයේ මායිම වටා එතීම.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // exp!=0 සිට, අවසානයේ exp 1 විය යුතුය.
            // On ාතයේ අවසාන කොටස සමඟ වෙන වෙනම කටයුතු කරන්න, මන්දයත් පසුව පාදම වර්ග කිරීම අවශ්‍ය නොවන අතර අනවශ්‍ය පිටාර ගැලීමක් සිදුවිය හැකිය.
            //
            //
            acc.wrapping_mul(base)
        }

        /// `self` + `rhs` ගණනය කරයි
        ///
        /// අංක ගණිත පිටාර ගැලීමක් සිදුවන්නේද යන්න දැක්වෙන බූලියන් සමඟ එකතු කිරීමේ ටුපල් එකක් ලබා දෙයි.
        /// පිටාර ගැලීමක් සිදුවන්නට තිබුනේ නම් ඔතා ඇති අගය ආපසු ලබා දෙනු ලැබේ.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self`, `rhs` ගණනය කරයි
        ///
        /// ගණිත පිටාර ගැලීමක් සිදුවන්නේද යන්න දක්වමින් බූලියන් සමඟ අඩුකිරීමේ ටුපල් එකක් ලබා දෙයි.
        /// පිටාර ගැලීමක් සිදුවන්නට තිබුනේ නම් ඔතා ඇති අගය ආපසු ලබා දෙනු ලැබේ.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` සහ `rhs` ගුණ කිරීම ගණනය කරයි.
        ///
        /// අංක ගණිත පිටාර ගැලීමක් සිදුවන්නේද යන්න දක්වමින් බූලියන් සමඟ ගුණ කිරීමේ ටුපල් එකක් ලබා දෙයි.
        /// පිටාර ගැලීමක් සිදුවන්නට තිබුනේ නම් ඔතා ඇති අගය ආපසු ලබා දෙනු ලැබේ.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// මෙම උදාහරණය පූර්ණ සංඛ්‍යා වර්ග අතර බෙදාගෙන ඇති බව කරුණාවෙන් සලකන්න.
        /// `u32` මෙහි භාවිතා කරන්නේ ඇයිද යන්න පැහැදිලි කරයි.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` `rhs` මගින් බෙදූ විට බෙදුම්කරු ගණනය කරයි.
        ///
        /// අංක ගණිත පිටාර ගැලීමක් සිදුවන්නේද යන්න දක්වමින් බූලියන් සමඟ බෙදුම්කරුගේ ටුපල් එකක් ලබා දෙයි.
        /// අත්සන් නොකළ පූර්ණ සංඛ්‍යා සඳහා පිටාර ගැලීම කිසි විටෙකත් සිදු නොවන බව සලකන්න, එබැවින් දෙවන අගය සෑම විටම `false` වේ.
        ///
        /// # Panics
        ///
        /// `rhs` 0 නම් මෙම ශ්‍රිතය panic වනු ඇත.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// යුක්ලීඩියානු අංශය `self.div_euclid(rhs)` හි ප්‍රමාණය ගණනය කරයි.
        ///
        /// අංක ගණිත පිටාර ගැලීමක් සිදුවන්නේද යන්න දක්වමින් බූලියන් සමඟ බෙදුම්කරුගේ ටුපල් එකක් ලබා දෙයි.
        /// අත්සන් නොකළ පූර්ණ සංඛ්‍යා සඳහා පිටාර ගැලීම කිසි විටෙකත් සිදු නොවන බව සලකන්න, එබැවින් දෙවන අගය සෑම විටම `false` වේ.
        /// ධනාත්මක නිඛිල සඳහා, බෙදීමේ සියලු පොදු අර්ථ දැක්වීම් සමාන බැවින් මෙය හරියටම `self.overflowing_div(rhs)` ට සමාන වේ.
        ///
        ///
        /// # Panics
        ///
        /// `rhs` 0 නම් මෙම ශ්‍රිතය panic වනු ඇත.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// `self` `rhs` මගින් බෙදූ විට ඉතිරි කොටස ගණනය කරයි.
        ///
        /// අංක ගණිත පිටාර ගැලීමක් සිදුවන්නේද යන්න දක්වමින් බූලියන් සමඟ බෙදීමෙන් පසු ඉතිරි කොටස නැවත ලබා දෙයි.
        /// අත්සන් නොකළ පූර්ණ සංඛ්‍යා සඳහා පිටාර ගැලීම කිසි විටෙකත් සිදු නොවන බව සලකන්න, එබැවින් දෙවන අගය සෑම විටම `false` වේ.
        ///
        /// # Panics
        ///
        /// `rhs` 0 නම් මෙම ශ්‍රිතය panic වනු ඇත.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// ඉතිරි `self.rem_euclid(rhs)` යුක්ලීඩියානු බෙදීම අනුව ගණනය කරයි.
        ///
        /// අංක ගණිත පිටාර ගැලීමක් සිදුවන්නේද යන්න දක්වමින් බූලියන් සමඟ බෙදීමෙන් පසු මොඩියුලයේ ටුපල් එකක් ලබා දෙයි.
        /// අත්සන් නොකළ පූර්ණ සංඛ්‍යා සඳහා පිටාර ගැලීම කිසි විටෙකත් සිදු නොවන බව සලකන්න, එබැවින් දෙවන අගය සෑම විටම `false` වේ.
        /// ධනාත්මක නිඛිල සඳහා, බෙදීමේ සියලු පොදු අර්ථ දැක්වීම් සමාන බැවින්, මෙම මෙහෙයුම හරියටම `self.overflowing_rem(rhs)` ට සමාන වේ.
        ///
        ///
        /// # Panics
        ///
        /// `rhs` 0 නම් මෙම ශ්‍රිතය panic වනු ඇත.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// පිරී ඉතිරී යන ආකාරයෙන් ස්වයං Neg ණාත්මක වේ.
        ///
        /// මෙම අත්සන් නොකළ අගය ප්‍රතික්ෂේප කිරීම නිරූපණය කරන අගය නැවත ලබා දීම සඳහා එතීමේ මෙහෙයුම් භාවිතා කරමින් `!self + 1` ලබා දෙයි.
        /// ධනාත්මක අත්සන් නොකළ අගයන් සඳහා පිටාර ගැලීම සැමවිටම සිදුවන බව සලකන්න, නමුත් 0 නොසලකා හැරීම පිටාර ගැලෙන්නේ නැත.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// `rhs` බිටු මගින් ස්වයං වම්පස මාරු කරයි.
        ///
        /// මාරුවීමේ අගය බිටු ගණනට වඩා විශාල හෝ සමාන දැයි අඟවන බූලියන් සමඟ මාරු කළ ස්වයං අනුවාදයේ ටුපල් එකක් ලබා දෙයි.
        /// මාරුවීමේ අගය ඉතා විශාල නම්, අගය (N-1) ආවරණ කර ඇති අතර එහිදී N යනු බිටු ගණන වන අතර මෙම අගය මාරුව සිදු කිරීමට යොදා ගනී.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// `rhs` බිටු මගින් ස්වයං අයිතිය මාරු කරයි.
        ///
        /// මාරුවීමේ අගය බිටු ගණනට වඩා විශාල හෝ සමාන දැයි අඟවන බූලියන් සමඟ මාරු කළ ස්වයං අනුවාදයේ ටුපල් එකක් ලබා දෙයි.
        /// මාරුවීමේ අගය ඉතා විශාල නම්, අගය (N-1) ආවරණ කර ඇති අතර එහිදී N යනු බිටු ගණන වන අතර මෙම අගය මාරුව සිදු කිරීමට යොදා ගනී.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// වර්ග කිරීම මගින් on ාතීයකරණය භාවිතා කරමින් `exp` හි බලයට ස්වයංව ඔසවයි.
        ///
        /// පිටාර ගැලීමක් සිදුවී ඇත්දැයි දක්වමින් bool සමඟ on ාතීය නූලක් ලබා දෙයි.
        ///
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, සත්‍ය));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // පිටාර ගැලීමේ_මුල් ප්‍රති results ල ගබඩා කිරීම සඳහා ඉඩ සීරීමට.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // exp!=0 සිට, අවසානයේ exp 1 විය යුතුය.
            // On ාතයේ අවසාන කොටස සමඟ වෙන වෙනම කටයුතු කරන්න, මන්දයත් පසුව පාදම වර්ග කිරීම අවශ්‍ය නොවන අතර අනවශ්‍ය පිටාර ගැලීමක් සිදුවිය හැකිය.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// වර්ග කිරීම මගින් on ාතීයකරණය භාවිතා කරමින් `exp` හි බලයට ස්වයංව ඔසවයි.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // exp!=0 සිට, අවසානයේ exp 1 විය යුතුය.
            // On ාතයේ අවසාන කොටස සමඟ වෙන වෙනම කටයුතු කරන්න, මන්දයත් පසුව පාදම වර්ග කිරීම අවශ්‍ය නොවන අතර අනවශ්‍ය පිටාර ගැලීමක් සිදුවිය හැකිය.
            //
            //
            acc * base
        }

        /// යුක්ලීඩියානු බෙදීම සිදු කරයි.
        ///
        /// ධනාත්මක නිඛිල සඳහා, බෙදීමේ සියලු පොදු අර්ථ දැක්වීම් සමාන බැවින් මෙය හරියටම `self / rhs` ට සමාන වේ.
        ///
        ///
        /// # Panics
        ///
        /// `rhs` 0 නම් මෙම ශ්‍රිතය panic වනු ඇත.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// `self (mod rhs)` හි අවම ඉතිරිය ගණනය කරයි.
        ///
        /// ධනාත්මක නිඛිල සඳහා, බෙදීමේ සියලු පොදු අර්ථ දැක්වීම් සමාන බැවින් මෙය හරියටම `self % rhs` ට සමාන වේ.
        ///
        ///
        /// # Panics
        ///
        /// `rhs` 0 නම් මෙම ශ්‍රිතය panic වනු ඇත.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// සමහර `k` සඳහා `self == 2^k` නම් පමණක් `true` ලබා දෙයි.
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // ඊලඟ බලයට වඩා අඩු එකක් ලබා දෙයි.
        // (8u8 සඳහා ඊළඟ දෙකක බලය 8u8 වන අතර 6u8 සඳහා එය 8u8 වේ)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // මෙම ක්‍රමයට පිටාර ගැලිය නොහැක, `next_power_of_two` පිටාර ගැලීම් අවස්ථා වලදී එය ඒ වෙනුවට වර්ගයේ උපරිම අගය නැවත ලබා දෙන අතර 0 සඳහා 0 ආපසු ලබා දිය හැකිය.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // ආරක්ෂාව: `p > 0` නිසා එයට සම්පූර්ණයෙන්ම ප්‍රමුඛ ශුන්‍යයන්ගෙන් සමන්විත විය නොහැක.
            // ඒ කියන්නේ මාරුව සැමවිටම සීමාව ඉක්මවා යන අතර තර්කය ශුන්‍ය නොවන විට සමහර සකසනයන්ට (ඉන්ටෙල් පෙර-හැස්වෙල් වැනි) වඩා කාර්යක්ෂම ctlz සහජ හැකියාවක් ඇත.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// `self` ට වඩා විශාල හෝ සමාන දෙකක කුඩාම බලය ලබා දෙයි.
        ///
        /// ප්‍රතිලාභ අගය පිටාර ගැලීමේදී (එනම්, `uN` වර්ගය සඳහා `self > (1 << (N-1))`), එය දෝශ නිරාකරණ ප්‍රකාරයේදී panics වන අතර ප්‍රතිලාභ අගය මුදා හැරීමේ ප්‍රකාරයේදී 0 ට ඔතා ඇත (ක්‍රමයට 0 ආපසු ලබා දිය හැකි එකම අවස්ථාව).
        ///
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// `n` ට වඩා විශාල හෝ සමාන දෙකක කුඩාම බලය ලබා දෙයි.
        /// දෙකක ඊළඟ බලය වර්ගයේ උපරිම අගයට වඩා වැඩි නම්, `None` ආපසු ලබා දෙනු ලැබේ, එසේ නොමැතිනම් දෙදෙනෙකුගේ බලය `Some` වලින් ඔතා ඇත.
        ///
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// `n` ට වඩා විශාල හෝ සමාන දෙකක කුඩාම බලය ලබා දෙයි.
        /// දෙකක ඊළඟ බලය වර්ගයේ උපරිම අගයට වඩා වැඩි නම්, ප්‍රතිලාභ අගය `0` වෙත ඔතා ඇත.
        ///
        ///
        /// # Examples
        ///
        /// මූලික භාවිතය:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// බිග්-එන්ඩියන් (network) බයිට් අනුපිළිවෙලින් බයිට් අරාවක් ලෙස මෙම නිඛිලයේ මතක නිරූපණය නැවත ලබා දෙන්න.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// කුඩා සංඛ්‍යාත්මක බයිට් අනුපිළිවෙලින් බයිට් අරාවක් ලෙස මෙම නිඛිලයේ මතක නිරූපණය නැවත ලබා දෙන්න.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// ස්වදේශීය බයිට් අනුපිළිවෙලින් බයිට් අරාවක් ලෙස මෙම නිඛිලයේ මතක නිරූපණය නැවත ලබා දෙන්න.
        ///
        /// ඉලක්කගත වේදිකාවේ ස්වදේශීය එන්ඩියනස් භාවිතා වන බැවින්, අතේ ගෙන යා හැකි කේතය සුදුසු පරිදි [`to_be_bytes`] හෝ [`to_le_bytes`] භාවිතා කළ යුතුය.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     බයිට්, cfg නම්! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } else {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // සුරක්ෂිතභාවය: පූර්ණ ශබ්දය පරණ දත්ත සමුදායන් වන බැවින් අපට සැමවිටම හැකි වේ
        // ඒවා බයිට් අරා වලට සම්ප්‍රේෂණය කරන්න
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // සුරක්ෂිතතාව: නිඛිල යනු පැරණි දත්ත සමුදායන් වන බැවින් අපට ඒවා සැමවිටම සම්ප්‍රේෂණය කළ හැකිය
            // බයිට් වල අරා
            unsafe { mem::transmute(self) }
        }

        /// ස්වදේශීය බයිට් අනුපිළිවෙලින් බයිට් අරාවක් ලෙස මෙම නිඛිලයේ මතක නිරූපණය නැවත ලබා දෙන්න.
        ///
        ///
        /// [`to_ne_bytes`] හැකි සෑම විටම මෙයට වඩා කැමති විය යුතුය.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// බයිට් වලට ඉඩ දෙන්න= num.as_ne_bytes();
        /// assert_eq!(
        ///     බයිට්, cfg නම්! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } else {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // සුරක්ෂිතතාව: නිඛිල යනු පැරණි දත්ත සමුදායන් වන බැවින් අපට ඒවා සැමවිටම සම්ප්‍රේෂණය කළ හැකිය
            // බයිට් වල අරා
            unsafe { &*(self as *const Self as *const _) }
        }

        /// විශාල එන්ඩියන් බයිට් අරා ලෙස එහි නිරූපණයෙන් ස්වදේශීය එන්ඩියන් පූර්ණ සංඛ්‍යා අගයක් සාදන්න.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto භාවිතා කරන්න;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ආදාන=විවේකය;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// කුඩා එන්ඩියන් බයිට් අරා ලෙස එහි නිරූපණයෙන් ස්වදේශීය එන්ඩියන් පූර්ණ සංඛ්‍යා අගයක් සාදන්න.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto භාවිතා කරන්න;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ආදාන=විවේකය;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// ස්වදේශීය එන්ඩියන්ස් හි බයිට් අරා ලෙස එහි මතක නිරූපණයෙන් ස්වදේශීය එන්ඩියන් පූර්ණ සංඛ්‍යා අගයක් සාදන්න.
        ///
        /// ඉලක්කගත වේදිකාවේ ස්වදේශීය එන්ඩියනස් භාවිතා වන බැවින්, අතේ ගෙන යා හැකි කේතයට සුදුසු පරිදි [`from_be_bytes`] හෝ [`from_le_bytes`] භාවිතා කිරීමට අවශ්‍ය වේ.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } else {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto භාවිතා කරන්න;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ආදාන=විවේකය;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // සුරක්ෂිතභාවය: පූර්ණ ශබ්දය පරණ දත්ත සමුදායන් වන බැවින් අපට සැමවිටම හැකි වේ
        // ඔවුන්ට සම්ප්‍රේෂණය කරන්න
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // ආරක්ෂාව: නිඛිල යනු පැරණි දත්ත සමුදායන් වන බැවින් අපට ඒවා සැමවිටම සම්ප්‍රේෂණය කළ හැකිය
            unsafe { mem::transmute(bytes) }
        }

        /// නව කේතය භාවිතා කිරීමට කැමැත්තක් දැක්විය යුතුය
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// මෙම නිඛිල වර්ගය මගින් නිරූපණය කළ හැකි කුඩාම අගය ලබා දෙයි.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// නව කේතය භාවිතා කිරීමට කැමැත්තක් දැක්විය යුතුය
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// මෙම නිඛිල වර්ගය මගින් නිරූපණය කළ හැකි විශාලතම අගය ලබා දෙයි.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}