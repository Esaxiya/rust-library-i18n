//! 128-බිට් අත්සන් කළ පූර්ණ සංඛ්‍යා වර්ගය සඳහා නියතයන්.
//!
//! *[See also the `i128` primitive type][i128].*
//!
//! නව කේතය ආශ්‍රිත නියතයන් සෘජුවම ප්‍රාථමික වර්ගයට භාවිතා කළ යුතුය.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i128`"
)]

int_module! { i128, #[stable(feature = "i128", since="1.26.0")] }