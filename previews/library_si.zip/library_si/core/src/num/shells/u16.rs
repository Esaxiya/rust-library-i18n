//! 16-බිට් අත්සන් නොකළ පූර්ණ සංඛ්‍යා වර්ගය සඳහා නියතයන්.
//!
//! *[See also the `u16` primitive type][u16].*
//!
//! නව කේතය ආශ්‍රිත නියතයන් සෘජුවම ප්‍රාථමික වර්ගයට භාවිතා කළ යුතුය.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u16`"
)]

int_module! { u16 }