//! සමෝධානික වර්ග බවට පරිවර්තනය කිරීම සඳහා දෝෂ වර්ග.

use crate::convert::Infallible;
use crate::fmt;

/// පරීක්ෂා කරන ලද අනුකලනය වර්ගයේ පරිවර්තනය අසමත් වූ විට දෝෂ වර්ගය නැවත ලැබුණි.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // `Infallible` `!` අන්වර්ථයක් බවට පත්වන විට ඉහත `From<Infallible> for TryFromIntError` වැනි කේතය දිගටම ක්‍රියාත්මක වන බවට වග බලා ගැනීමට බල කිරීමට වඩා ගැලපෙන්න.
        //
        //
        match never {}
    }
}

/// පූර්ණ සංඛ්‍යාවක් විග්‍රහ කිරීමේදී ආපසු ලබා දිය හැකි දෝෂයකි.
///
/// මෙම දෝෂය [`i8::from_str_radix`] වැනි ප්‍රාථමික පූර්ණ සංඛ්‍යා වර්ගවල `from_str_radix()` ශ්‍රිත සඳහා දෝෂ වර්ගය ලෙස භාවිතා කරයි.
///
/// # විභව හේතු
///
/// වෙනත් හේතූන් අතර, සම්මත ආදානයෙන් ලබා ගත් විට, උදාසීන සුදු අවකාශය ප්‍රමුඛ හෝ පසුපසින් ඇති නිසා `ParseIntError` විසි කළ හැකිය.
///
/// [`str::trim()`] ක්‍රමය භාවිතා කිරීමෙන් විග්‍රහ කිරීමට පෙර කිසිදු හිස් අවකාශයක් ඉතිරි නොවන බව සහතික කරයි.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// පූර්ණ සංඛ්‍යාවක් විග්‍රහ කිරීම අසමත් වීමට හේතු විය හැකි විවිධ වර්ගයේ දෝෂ ගබඩා කිරීමට එනූම්.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// විග්‍රහ කරන ලද අගය හිස් ය.
    ///
    /// වෙනත් හේතු අතර, හිස් නූලක් විග්‍රහ කිරීමේදී මෙම ප්‍රභේදය ඉදිකරනු ලැබේ.
    Empty,
    /// එහි සන්දර්භය තුළ අවලංගු ඉලක්කම් අඩංගු වේ.
    ///
    /// වෙනත් හේතූන් අතර, ASCII නොවන වර්‍ගයක් අඩංගු නූලක් විග්‍රහ කිරීමේදී මෙම ප්‍රභේදය සාදනු ලැබේ.
    ///
    /// `+` හෝ `-` නූලක් තුළ තනිවම හෝ අංකයක් මැද අස්ථානගත වූ විටද මෙම ප්‍රභේදය සාදනු ලැබේ.
    ///
    ///
    InvalidDigit,
    /// ඉලක්ක නිඛිල වර්ගයේ ගබඩා කිරීමට පූර්ණ සංඛ්‍යාව වැඩිය.
    PosOverflow,
    /// ඉලක්ක නිඛිල වර්ගයේ ගබඩා කිරීමට පූර්ණ සංඛ්‍යාව ඉතා කුඩාය.
    NegOverflow,
    /// වටිනාකම ශුන්‍ය විය
    ///
    /// විග්‍රහ කරන නූලට ශුන්‍ය අගයක් ඇති විට මෙම ප්‍රභේදය විමෝචනය වන අතර එය ශුන්‍ය නොවන වර්ග සඳහා නීති විරෝධී වේ.
    ///
    Zero,
}

impl ParseIntError {
    /// පූර්ණ සංඛ්‍යාවක් අසමත් වීමට සවිස්තරාත්මක හේතුව ප්‍රතිදානය කරයි.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}