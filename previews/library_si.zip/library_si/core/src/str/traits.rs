//! `str` සඳහා Trait ක්‍රියාත්මක කිරීම.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// නූල් අනුපිළිවෙල ක්‍රියාත්මක කරයි.
///
/// නූල් ඒවායේ බයිට් අගයන් අනුව [lexicographically](Ord#lexicographical-comparison) ඇණවුම් කර ඇත.
/// මෙය කේත ප්‍රස්ථාරවල ඇති ස්ථාන මත පදනම්ව යුනිකෝඩ් කේත ලකුණු ඇණවුම් කරයි.
/// මෙය "alphabetical" අනුපිළිවෙලට සමාන නොවේ, එය භාෂාව සහ ප්‍රදේශය අනුව වෙනස් වේ.
/// සංස්කෘතිකමය වශයෙන් පිළිගත් ප්‍රමිතීන්ට අනුව නූල් වර්ග කිරීම සඳහා `str` වර්ගයේ විෂය පථයට පිටින් ඇති ස්ථානීය විශේෂිත දත්ත අවශ්‍ය වේ.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// නූල් මත සංසන්දනාත්මක මෙහෙයුම් ක්‍රියාත්මක කරයි.
///
/// නූල් [lexicographically](Ord#lexicographical-comparison) ඒවායේ බයිට් අගයන් සමඟ සැසඳේ.
/// මෙය කේත ප්‍රස්ථාරවල ඇති ස්ථාන මත පදනම්ව යුනිකෝඩ් කේත ලකුණු සංසන්දනය කරයි.
/// මෙය "alphabetical" අනුපිළිවෙලට සමාන නොවේ, එය භාෂාව සහ ප්‍රදේශය අනුව වෙනස් වේ.
/// සංස්කෘතිකමය වශයෙන් පිළිගත් ප්‍රමිතීන්ට අනුව නූල් සංසන්දනය කිරීම සඳහා `str` වර්ගයේ විෂය පථයට පිටින් ඇති ස්ථානීය විශේෂිත දත්ත අවශ්‍ය වේ.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// සින්ටැක්ස් `&self[..]` හෝ `&mut self[..]` සමඟ උපස්ථර පෙති කැපීම ක්‍රියාත්මක කරයි.
///
/// සම්පූර්ණ නූලෙන් පෙත්තක් ලබා දෙයි, එනම්, `&self` හෝ `&mut self` ලබා දෙයි.`සහ ස්වයං [0] ට සමාන වේ.
/// len] `හෝ`&mut self [0 ..
/// len]`.
/// වෙනත් සුචිගත කිරීමේ මෙහෙයුම් මෙන් නොව, මෙය කිසි විටෙකත් panic විය නොහැක.
///
/// මෙම මෙහෙයුම *O*(1) වේ.
///
/// 1.20.0 ට පෙර, `Index` සහ `IndexMut` සෘජුවම ක්‍රියාත්මක කිරීම මගින් මෙම සුචිගත කිරීමේ මෙහෙයුම් සඳහා තවමත් සහාය ලබා දී ඇත.
///
/// `&self[0 .. len]` හෝ `&mut self[0 .. len]` ට සමාන වේ.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// සින්ටැක්ස් `&self[begin .. end]` හෝ `&mut self[begin .. end]` සමඟ උපස්ථර පෙති කැපීම ක්‍රියාත්මක කරයි.
///
/// ලබා දුන් නූල් පෙත්තක් බයිට් පරාසය වෙතින් ලබා දෙයි [`ආරම්භය`, `end`).
///
/// මෙම මෙහෙයුම *O*(1) වේ.
///
/// 1.20.0 ට පෙර, `Index` සහ `IndexMut` සෘජුවම ක්‍රියාත්මක කිරීම මගින් මෙම සුචිගත කිරීමේ මෙහෙයුම් සඳහා තවමත් සහාය ලබා දී ඇත.
///
/// # Panics
///
/// Panics නම් `begin` හෝ `end` අක්ෂරයක ආරම්භක බයිට් ඕෆ්සෙට් වෙත යොමු නොවන්නේ නම් (`is_char_boundary` විසින් අර්ථ දක්වා ඇති පරිදි), `begin > end` නම්, හෝ `end > len` නම්.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // මේවා panic:
/// // බයිට් 2 `ö` තුළ පවතී:
/// // &s [2 ..3];
///
/// // බයිට් 8 `老`&s තුළ පිහිටා ඇත [1 ..
/// // 8];
///
/// // බයිට් 100 නූලෙන් පිටත ය [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // ආරක්ෂාව: `start` සහ `end` වර්‍ග මායිමක තිබේදැයි පරීක්ෂා කර ඇත,
            // අපි ආරක්ෂිත යොමුවකින් ගමන් කරන්නෙමු, එබැවින් ප්‍රතිලාභ අගය ද එකක් වනු ඇත.
            // අපි වර්‍ග මායිම් ද පරීක්ෂා කළෙමු, එබැවින් මෙය වලංගු UTF-8 වේ.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // ආරක්ෂාව: `start` සහ `end` වර්‍ග මායිමක තිබේදැයි පරීක්ෂා කර බලන්න.
            // `slice` වෙතින් අපට එය ලැබී ඇති නිසා දර්ශකය අද්විතීය බව අපි දනිමු.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // සුරක්ෂිතභාවය: අමතන්නා `self` `slice` සීමාවෙන් බව සහතික කරයි
        // එය `add` සඳහා වන සියලුම කොන්දේසි සපුරාලයි.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // ආරක්ෂාව: `get_unchecked` සඳහා අදහස් බලන්න.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary මඟින් දර්ශකය [0, .len()] හි XL1X නැවත භාවිතා කළ නොහැක, එන්එල්එල් කරදර නිසා
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // ආරක්ෂාව: `start` සහ `end` වර්‍ග මායිමක තිබේදැයි පරීක්ෂා කර ඇත,
            // අපි ආරක්ෂිත යොමුවකින් ගමන් කරන්නෙමු, එබැවින් ප්‍රතිලාභ අගය ද එකක් වනු ඇත.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// සින්ටැක්ස් `&self[.. end]` හෝ `&mut self[.. end]` සමඟ උපස්ථර පෙති කැපීම ක්‍රියාත්මක කරයි.
///
/// බයිට් පරාසය [`0`, `end`) වෙතින් දී ඇති නූල් පෙත්තක් ලබා දෙයි.
/// `&self[0 .. end]` හෝ `&mut self[0 .. end]` ට සමාන වේ.
///
/// මෙම මෙහෙයුම *O*(1) වේ.
///
/// 1.20.0 ට පෙර, `Index` සහ `IndexMut` සෘජුවම ක්‍රියාත්මක කිරීම මගින් මෙම සුචිගත කිරීමේ මෙහෙයුම් සඳහා තවමත් සහාය ලබා දී ඇත.
///
/// # Panics
///
/// Panics `end` අක්ෂරයක ආරම්භක බයිට් ඕෆ්සෙට් වෙත යොමු නොකරන්නේ නම් (`is_char_boundary` විසින් අර්ථ දක්වා ඇති පරිදි), හෝ `end > len` නම්.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // ආරක්ෂාව: `end` වර්‍ග මායිමක තිබේදැයි පරීක්ෂා කර ඇත,
            // අපි ආරක්ෂිත යොමුවකින් ගමන් කරන්නෙමු, එබැවින් ප්‍රතිලාභ අගය ද එකක් වනු ඇත.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // ආරක්ෂාව: `end` වර්‍ග මායිමක තිබේදැයි පරීක්ෂා කර ඇත,
            // අපි ආරක්ෂිත යොමුවකින් ගමන් කරන්නෙමු, එබැවින් ප්‍රතිලාභ අගය ද එකක් වනු ඇත.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // ආරක්ෂාව: `end` වර්‍ග මායිමක තිබේදැයි පරීක්ෂා කර ඇත,
            // අපි ආරක්ෂිත යොමුවකින් ගමන් කරන්නෙමු, එබැවින් ප්‍රතිලාභ අගය ද එකක් වනු ඇත.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// සින්ටැක්ස් `&self[begin ..]` හෝ `&mut self[begin ..]` සමඟ උපස්ථර පෙති කැපීම ක්‍රියාත්මක කරයි.
///
/// ලබා දී ඇති නූල් පෙත්තක් බයිට් පරාසය වෙතින් ලබා දෙයි [`ආරම්භය`, `len`).`සහ ස්වයං [සමාන ..
/// len] `හෝ`&mut ස්වයං [ආරම්භ කරන්න ..
/// len]`.
///
/// මෙම මෙහෙයුම *O*(1) වේ.
///
/// 1.20.0 ට පෙර, `Index` සහ `IndexMut` සෘජුවම ක්‍රියාත්මක කිරීම මගින් මෙම සුචිගත කිරීමේ මෙහෙයුම් සඳහා තවමත් සහාය ලබා දී ඇත.
///
/// # Panics
///
/// Panics `begin` අක්ෂරයක ආරම්භක බයිට් ඕෆ්සෙට් වෙත යොමු නොකරන්නේ නම් (`is_char_boundary` විසින් අර්ථ දක්වා ඇති පරිදි), හෝ `begin > len` නම්.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // ආරක්ෂාව: `start` වර්‍ග මායිමක තිබේදැයි පරීක්ෂා කර ඇත,
            // අපි ආරක්ෂිත යොමුවකින් ගමන් කරන්නෙමු, එබැවින් ප්‍රතිලාභ අගය ද එකක් වනු ඇත.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // ආරක්ෂාව: `start` වර්‍ග මායිමක තිබේදැයි පරීක්ෂා කර ඇත,
            // අපි ආරක්ෂිත යොමුවකින් ගමන් කරන්නෙමු, එබැවින් ප්‍රතිලාභ අගය ද එකක් වනු ඇත.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // සුරක්ෂිතභාවය: අමතන්නා `self` `slice` සීමාවෙන් බව සහතික කරයි
        // එය `add` සඳහා වන සියලුම කොන්දේසි සපුරාලයි.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // ආරක්ෂාව: `get_unchecked` ට සමාන වේ.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // ආරක්ෂාව: `start` වර්‍ග මායිමක තිබේදැයි පරීක්ෂා කර ඇත,
            // අපි ආරක්ෂිත යොමුවකින් ගමන් කරන්නෙමු, එබැවින් ප්‍රතිලාභ අගය ද එකක් වනු ඇත.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// සින්ටැක්ස් `&self[begin ..= end]` හෝ `&mut self[begin ..= end]` සමඟ උපස්ථර පෙති කැපීම ක්‍රියාත්මක කරයි.
///
/// [`begin`, `end`] බයිට් පරාසය වෙතින් දී ඇති නූල් පෙත්තක් ලබා දෙයි.`end` සඳහා `usize` සඳහා උපරිම අගය තිබේ නම් හැර, `&self [begin .. end + 1]` හෝ `&mut self[begin .. end + 1]` ට සමාන වේ.
///
/// මෙම මෙහෙයුම *O*(1) වේ.
///
/// # Panics
///
/// `begin` අක්ෂරයක ආරම්භක බයිට් ඕෆ්සෙට් වෙත යොමු නොවන්නේ නම් (`is_char_boundary` විසින් අර්ථ දක්වා ඇති පරිදි), `end` අක්ෂරයක අවසන් බයිට් ඕෆ්සෙට් වෙත යොමු නොවන්නේ නම් (`end + 1` යනු ආරම්භක බයිට් ඕෆ්සෙට් එකක් හෝ `len` ට සමාන වේ), `begin > end` නම්, හෝ `end >= len` නම්.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // ආරක්ෂාව: අමතන්නා `get_unchecked` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // ආරක්ෂාව: අමතන්නා `get_unchecked_mut` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// සින්ටැක්ස් `&self[..= end]` හෝ `&mut self[..= end]` සමඟ උපස්ථර පෙති කැපීම ක්‍රියාත්මක කරයි.
///
/// [0, `end`] බයිට් පරාසය වෙතින් දී ඇති නූල් පෙත්තක් ලබා දෙයි.
/// `end` ට `usize` සඳහා උපරිම අගය තිබේ නම් හැර, `&self [0 .. end + 1]` ට සමාන වේ.
///
/// මෙම මෙහෙයුම *O*(1) වේ.
///
/// # Panics
///
/// `end` අක්ෂරයක අවසන් බයිට් ඕෆ්සෙට් වෙත යොමු නොවන්නේ නම් Panics (`end + 1` යනු `is_char_boundary` විසින් අර්ථ දක්වා ඇති පරිදි ආරම්භක බයිට් ඕෆ්සෙට් එකක් හෝ `len` ට සමාන වේ), හෝ `end >= len` නම්.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // ආරක්ෂාව: අමතන්නා `get_unchecked` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // ආරක්ෂාව: අමතන්නා `get_unchecked_mut` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// නූලකින් අගයක් විග්‍රහ කරන්න
///
/// [FromStr`හි [`from_str`] ක්‍රමය බොහෝ විට [`str`] ගේ [`parse`] ක්‍රමය හරහා ව්‍යංගයෙන් භාවිතා වේ.
/// උදාහරණ සඳහා [`විග්‍රහ කිරීම]] හි ප්‍රලේඛනය බලන්න.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` ජීවිත කාල පරාමිතියක් නොමැත, එබැවින් ඔබට විග්‍රහ කළ හැක්කේ ජීවිත කාල පරාමිතියක් අඩංගු නොවන වර්ග පමණි.
///
/// වෙනත් වචන වලින් කිවහොත්, ඔබට `FromStr` සමඟ `i32` විග්‍රහ කළ හැකිය, නමුත් `&i32` නොවේ.
/// ඔබට `i32` අඩංගු ව්‍යුහයක් විග්‍රහ කළ හැකිය, නමුත් `&i32` අඩංගු එකක් නොවේ.
///
/// # Examples
///
/// `Point` වර්ගය උදාහරණයක් ලෙස `FromStr` ක්‍රියාත්මක කිරීම:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// විග්‍රහ කිරීමෙන් ආපසු ලබා ගත හැකි සම්බන්ධිත දෝෂය.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// මෙම වර්ගයේ අගයක් ආපසු ලබා දීම සඳහා `s` නූලක් විග්‍රහ කරයි.
    ///
    /// විග්‍රහ කිරීම සාර්ථක වුවහොත්, [`Ok`] තුළ ඇති අගය නැවත ලබා දෙන්න, එසේ නොමැතිනම් නූල වැරදි ලෙස හැඩගස්වා ඇති විට [`Err`] ඇතුළත විශේෂිත දෝෂයක් ලබා දෙන්න.
    /// trait ක්‍රියාත්මක කිරීම සඳහා දෝෂ වර්ගය විශේෂිත වේ.
    ///
    /// # Examples
    ///
    /// [`i32`] සමඟ මූලික භාවිතය, `FromStr` ක්‍රියාත්මක කරන වර්ගයකි:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// නූලකින් `bool` විග්‍රහ කරන්න.
    ///
    /// `Result<bool, ParseBoolError>` ields ලදාවක් ලබා දෙයි, මන්ද `s` ඇත්ත වශයෙන්ම විග්‍රහ කළ හැකි හෝ නොවිය හැකිය.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// බොහෝ අවස්ථාවලදී, `str` හි `.parse()` ක්‍රමය වඩාත් සුදුසු බව සලකන්න.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}