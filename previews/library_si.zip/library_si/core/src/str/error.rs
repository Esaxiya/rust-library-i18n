//! utf8 දෝෂ වර්ගය අර්ථ දක්වයි.

use crate::fmt;

/// [`u8`] අනුක්‍රමයක් නූලක් ලෙස අර්ථ දැක්වීමට උත්සාහ කිරීමේදී සිදුවිය හැකි දෝෂ.
///
/// එනිසා, `from_utf8` පවුල [`String`] සහ [`&str`] යන දෙවර්ගයේම කාර්යයන් සහ ක්‍රම මෙම දෝෂය භාවිතා කරයි.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// ගොඩවල් මතකය වෙන් නොකර `String::from_utf8_lossy` ට සමාන ක්‍රියාකාරීත්වයක් නිර්මාණය කිරීමට මෙම දෝෂ වර්ගයේ ක්‍රම භාවිතා කළ හැකිය:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// වලංගු UTF-8 සත්‍යාපනය කළ දක්වා ඇති නූලෙහි දර්ශකය ලබා දෙයි.
    ///
    /// `from_utf8(&input[..index])` විසින් `Ok(_)` ආපසු ලබා දෙන උපරිම දර්ශකය එයයි.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::str;
    ///
    /// // vector හි අවලංගු බයිට් කිහිපයක්
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 Utf8Error එකක් ලබා දෙයි
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // දෙවන බයිට් මෙහි වලංගු නොවේ
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// අසමත් වීම පිළිබඳ වැඩි විස්තර සපයයි:
    ///
    /// * `None`: ආදානයේ අවසානය අනපේක්ෂිත ලෙස ළඟා විය.
    ///   `self.valid_up_to()` ආදානයේ අවසානයේ සිට බයිට් 1 සිට 3 දක්වා වේ.
    ///   බයිට් ප්‍රවාහයක් (ගොනුවක් හෝ ජාල සොකට් වැනි) වැඩි වැඩියෙන් විකේතනය කරන්නේ නම්, මෙය වලංගු `char` විය හැකි අතර UTF-8 බයිට් අනුක්‍රමය බහු කුට්ටි විහිදේ.
    ///
    ///
    /// * `Some(len)`: අනපේක්ෂිත බයිට් එකක් හමු විය.
    ///   සපයන ලද දිග යනු `valid_up_to()` විසින් ලබා දී ඇති දර්ශකයෙන් ආරම්භ වන අවලංගු බයිට් අනුක්‍රමයයි.
    ///   අක්‍රීය විකේතනයකදී එම අනුක්‍රමයෙන් පසුව ([`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] ඇතුළු කිරීමෙන් පසුව) විකේතනය නැවත ආරම්භ කළ යුතුය.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// [`from_str`] භාවිතා කරමින් `bool` විග්‍රහ කිරීමේදී දෝෂයක් ඇතිවිය
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}