//! බයිට් පෙත්තෙන් `str` නිර්මාණය කිරීමේ ක්‍රම.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// බයිට් පෙත්තක් නූල් පෙත්තක් බවට පරිවර්තනය කරයි.
///
/// නූල් පෙත්තක් ([`&str`]) බයිට් ([`u8`]) වලින් සාදා ඇති අතර බයිට් පෙත්තක් ([`&[u8]`][byteslice]) බයිට් වලින් සාදා ඇත, එබැවින් මෙම ශ්‍රිතය දෙක අතර පරිවර්තනය වේ.
/// සියලුම බයිට් පෙති වලංගු නූල් පෙති නොවේ, කෙසේ වෙතත්: [`&str`] ට වලංගු UTF-8 අවශ්‍ය වේ.
/// `from_utf8()` බයිට් වලංගු UTF-8 බව තහවුරු කර ගැනීම සඳහා පරික්ෂා කර, පසුව පරිවර්තනය කරයි.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// බයිට් පෙත්ත වලංගු UTF-8 බව ඔබට විශ්වාස නම්, සහ වලංගු චෙක්පතට ඉහළින් යාමට ඔබට අවශ්‍ය නැතිනම්, මෙම ශ්‍රිතයේ අනාරක්ෂිත අනුවාදයක් ඇත, [`from_utf8_unchecked`], එකම හැසිරීමක් ඇති නමුත් චෙක්පත මඟ හැරේ.
///
///
/// ඔබට `&str` වෙනුවට `String` අවශ්‍ය නම්, [`String::from_utf8`][string] සලකා බලන්න.
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// ඔබට `[u8; N]` තොගයක් වෙන් කළ හැකි නිසාත්, ඔබට එයින් [`&[u8]`][byteslice] ගත හැකි නිසාත්, මෙම ශ්‍රිතය සිරස් වෙන් කළ නූලක් ලබා ගත හැකි එක් ක්‍රමයකි.පහත උදාහරණ කොටසේ මේ සඳහා උදාහරණයක් තිබේ.
///
/// [byteslice]: slice
///
/// # Errors
///
/// සපයන ලද පෙත්ත UTF-8 නොවන්නේ මන්ද යන්න පිළිබඳ විස්තරයක් සහිත පෙත්තක් UTF-8 නොවේ නම් `Err` ලබා දෙයි.
///
/// # Examples
///
/// මූලික භාවිතය:
///
/// ```
/// use std::str;
///
/// // vector හි සමහර බයිට්
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // මෙම බයිට් වලංගු බව අපි දනිමු, එබැවින් `unwrap()` භාවිතා කරන්න.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// වැරදි බයිට්:
///
/// ```
/// use std::str;
///
/// // vector හි අවලංගු බයිට් කිහිපයක්
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// ආපසු ලබා දිය හැකි දෝෂ පිළිබඳ වැඩි විස්තර සඳහා [`Utf8Error`] සඳහා ලියකියවිලි බලන්න.
///
/// "stack allocated string":
///
/// ```
/// use std::str;
///
/// // සමහර බයිට්, සිරස් වෙන් කළ අරාවකින්
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // මෙම බයිට් වලංගු බව අපි දනිමු, එබැවින් `unwrap()` භාවිතා කරන්න.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // ආරක්ෂාව: වලංගු කිරීම පමණක් ක්‍රියාත්මක විය.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// විකෘති බයිට් පෙත්තක් විකෘති නූල් පෙත්තක් බවට පරිවර්තනය කරයි.
///
/// # Examples
///
/// මූලික භාවිතය:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" විකෘති vector ලෙස
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // මෙම බයිට් වලංගු බව අප දන්නා බැවින් අපට `unwrap()` භාවිතා කළ හැකිය
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// වැරදි බයිට්:
///
/// ```
/// use std::str;
///
/// // විකෘති vector හි සමහර අවලංගු බයිට්
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// ආපසු ලබා දිය හැකි දෝෂ පිළිබඳ වැඩි විස්තර සඳහා [`Utf8Error`] සඳහා ලියකියවිලි බලන්න.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // ආරක්ෂාව: වලංගු කිරීම පමණක් ක්‍රියාත්මක විය.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// නූල් වලංගු UTF-8 අඩංගු දැයි පරීක්ෂා නොකර බයිට් පෙත්තක් නූල් පෙත්තක් බවට පරිවර්තනය කරයි.
///
/// වැඩි විස්තර සඳහා ආරක්ෂිත අනුවාදය වන [`from_utf8`] බලන්න.
///
/// # Safety
///
/// මෙම ශ්‍රිතය අනාරක්ෂිත වන්නේ එයට ලබා දුන් බයිට් වලංගු UTF-8 දැයි පරික්ෂා නොකරන බැවිනි.
/// මෙම අවහිරතා උල්ලං is නය වී ඇත්නම්, නිර්වචනය නොකළ හැසිරීමේ ප්‍රති results ල වනුයේ Rust හි ඉතිරි කොටස් [`&str`] වලංගු UTF-8 යැයි උපකල්පනය කරන බැවිනි.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// මූලික භාවිතය:
///
/// ```
/// use std::str;
///
/// // vector හි සමහර බයිට්
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // ආරක්ෂාව: ඇමතුම්කරු `v` බයිට් වලංගු UTF-8 බවට සහතික විය යුතුය.
    // එකම පිරිසැලසුමක් ඇති `&str` සහ `&[u8]` මත ද රඳා පවතී.
    unsafe { mem::transmute(v) }
}

/// නූල වල වලංගු UTF-8 අඩංගු දැයි පරීක්ෂා නොකර බයිට් පෙත්තක් නූල් පෙත්තක් බවට පරිවර්තනය කරයි;විකෘති අනුවාදය.
///
///
/// වැඩි විස්තර සඳහා වෙනස් කළ නොහැකි අනුවාදය, [`from_utf8_unchecked()`] බලන්න.
///
/// # Examples
///
/// මූලික භාවිතය:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // ආරක්ෂාව: ඇමතුම්කරු `v` බයිට් බවට සහතික විය යුතුය
    // වලංගු UTF-8 වේ, එබැවින් `*mut str` වෙත වාත්තු කිරීම ආරක්ෂිත වේ.
    // එසේම, දර්ශක විරූපණය ආරක්ෂිත වන්නේ එම දර්ශකය ලිවීම සඳහා වලංගු බව සහතික කර ඇති යොමු කිරීමකින් වන බැවිනි.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}