//! නූල් හැසිරවීම.
//!
//! වැඩි විස්තර සඳහා, [`std::str`] මොඩියුලය බලන්න.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. සීමාවෙන් පිටත
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. ආරම්භය <=අවසානය
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. අක්ෂර මායිම
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // චරිතය සොයා ගන්න
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` ලෙන් හා වර්‍ග මායිමට වඩා අඩු විය යුතුය
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// `self` හි දිග ලබා දෙයි.
    ///
    /// මෙම දිග බයිට් වලින් මිස [චාර්] හෝ ග්‍රැෆීම් වලින් නොවේ.
    /// වෙනත් වචන වලින් කිවහොත්, එය නූල් වල දිග ලෙස මිනිසෙකු සලකන දේ නොවිය හැකිය.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // විසිතුරු එෆ්!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// `self` හි දිග ශුන්‍ය බයිට් තිබේ නම් `true` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// UTF-8 කේත ලක්ෂ්‍ය අනුපිළිවෙලක හෝ නූලෙහි අවසානයෙහි පළමු බයිටය `දර්ශක`-බයිට් බව පරීක්ෂා කරයි.
    ///
    ///
    /// නූලෙහි ආරම්භය සහ අවසානය (`දර්ශකය== self.len()`) මායිම් ලෙස සලකන විට.
    ///
    /// `index` `self.len()` ට වඩා වැඩි නම් `false` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // `老` ආරම්භය
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // `ö` හි දෙවන බයිට්
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // `老` හි තුන්වන බයිට්
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 සහ ලෙන් සෑම විටම හරි.
        // චෙක්පත පහසුවෙන් ප්‍රශස්තිකරණය කිරීමට සහ එම අවස්ථාව සඳහා කියවීමේ වචන දත්ත මඟ හැරීමට හැකි වන පරිදි 0 සඳහා පැහැදිලිව පරීක්ෂා කරන්න.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // මෙය බිට් මැජික් වලට සමානයි: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// නූල් පෙත්තක් බයිට් පෙත්තක් බවට පරිවර්තනය කරයි.
    /// බයිට් පෙත්ත නැවත නූල් පෙත්තක් බවට පරිවර්තනය කිරීම සඳහා, [`from_utf8`] ශ්‍රිතය භාවිතා කරන්න.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // සුරක්ෂිතභාවය: එකම සැකැස්ම සමඟ අපි වර්ග දෙකක් සම්ප්‍රේෂණය කරන නිසා නිරන්තර ශබ්දය
        unsafe { mem::transmute(self) }
    }

    /// විකෘති නූල් පෙත්තක් විකෘති බයිට් පෙත්තක් බවට පරිවර්තනය කරයි.
    ///
    /// # Safety
    ///
    /// ණය ගැනීම අවසන් වීමට පෙර සහ යටින් ඇති `str` භාවිතා කිරීමට පෙර පෙත්තෙහි අන්තර්ගතය වලංගු UTF-8 බව අමතන්නා සහතික කළ යුතුය.
    ///
    ///
    /// `str` අන්තර්ගතය වලංගු නොවන `str` භාවිතා කිරීම නිර්වචනය නොකළ හැසිරීමකි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // ආරක්ෂාව: `str` සිට `&str` සිට `&[u8]` දක්වා වාත්තු කිරීම ආරක්ෂිතයි
        // `&[u8]` හා සමාන පිරිසැලසුමක් ඇත (මෙම සහතිකය ලබා දිය හැක්කේ libstd ට පමණි).
        // පොයින්ටර් විරූපණය ආරක්ෂිත වන්නේ එය විකෘති යොමු කිරීමකින් වන බැවින් එය ලිවීම සඳහා වලංගු බව සහතික කර ඇත.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// නූල් පෙත්තක් අමු දර්ශකයකට පරිවර්තනය කරයි.
    ///
    /// නූල් පෙති බයිට් පෙත්තක් බැවින් අමු දර්ශකය [`u8`] වෙත යොමු කරයි.
    /// මෙම දර්ශකය නූල් පෙත්තක පළමු බයිටයට යොමු වේ.
    ///
    /// ආපසු එවූ දර්ශකය කිසි විටෙකත් ලියා නොමැති බව අමතන්නා සහතික කළ යුතුය.
    /// ඔබට නූල් පෙත්තෙහි අන්තර්ගතය විකෘති කිරීමට අවශ්‍ය නම්, [`as_mut_ptr`] භාවිතා කරන්න.
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// විකෘති නූල් පෙත්තක් අමු දර්ශකයකට පරිවර්තනය කරයි.
    ///
    /// නූල් පෙති බයිට් පෙත්තක් බැවින් අමු දර්ශකය [`u8`] වෙත යොමු කරයි.
    /// මෙම දර්ශකය නූල් පෙත්තක පළමු බයිටයට යොමු වේ.
    ///
    /// නූල් පෙත්ත වලංගු UTF-8 ලෙස පවතින ආකාරයට පමණක් වෙනස් වන බවට වග බලා ගැනීම ඔබේ වගකීමකි.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// `str` හි උප කුලකයක් ලබා දෙයි.
    ///
    /// `str` සුචිගත කිරීම සඳහා කලබල නොවන විකල්පය මෙයයි.
    /// සමාන සුචිගත කිරීමේ ක්‍රියාවලිය panic වන සෑම අවස්ථාවකම [`None`] ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // දර්ශක UTF-8 අනුක්‍රමික මායිම්වල නොවේ
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // සීමාවෙන් පිටත
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// `str` හි විකෘති උපසිරැසියක් ලබා දෙයි.
    ///
    /// `str` සුචිගත කිරීම සඳහා කලබල නොවන විකල්පය මෙයයි.
    /// සමාන සුචිගත කිරීමේ ක්‍රියාවලිය panic වන සෑම අවස්ථාවකම [`None`] ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // නිවැරදි දිග
    /// assert!(v.get_mut(0..5).is_some());
    /// // සීමාවෙන් පිටත
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// `str` හි පරීක්ෂා නොකළ උපසිරැසියක් ලබා දෙයි.
    ///
    /// `str` සුචිගත කිරීම සඳහා තෝරා නොගත් විකල්පය මෙයයි.
    ///
    /// # Safety
    ///
    /// මෙම පූර්ව කොන්දේසි තෘප්තිමත් වීමට මෙම ශ්‍රිතයේ අමතන්නන් වගකිව යුතුය:
    ///
    /// * ආරම්භක දර්ශකය අවසන් දර්ශකය නොඉක්මවිය යුතුය;
    /// * දර්ශක මුල් පෙත්තෙහි සීමාවන් තුළ තිබිය යුතුය;
    /// * දර්ශක UTF-8 අනුක්‍රමික මායිම් මත තිබිය යුතුය.
    ///
    /// එය අසමත් වුවහොත්, ආපසු ලබා දුන් නූල් පෙත්තෙහි අවලංගු මතකයක් සඳහන් කිරීමට හෝ `str` වර්ගය මගින් සන්නිවේදනය කරන ලද ආක්‍රමණ උල්ලං late නය කිරීමට ඉඩ ඇත.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // ආරක්ෂාව: අමතන්නා `get_unchecked` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය;
        // `self` ආරක්ෂිත යොමු කිරීමක් බැවින් පෙත්ත අවලංගු කළ හැකිය.
        // ආපසු ලබා දුන් දර්ශකය ආරක්ෂිත වන්නේ `SliceIndex` හි impls එය බව සහතික කළ යුතු බැවිනි.
        unsafe { &*i.get_unchecked(self) }
    }

    /// `str` හි විකෘති, පරීක්ෂා නොකළ උපසිරැසියක් ලබා දෙයි.
    ///
    /// `str` සුචිගත කිරීම සඳහා තෝරා නොගත් විකල්පය මෙයයි.
    ///
    /// # Safety
    ///
    /// මෙම පූර්ව කොන්දේසි තෘප්තිමත් වීමට මෙම ශ්‍රිතයේ අමතන්නන් වගකිව යුතුය:
    ///
    /// * ආරම්භක දර්ශකය අවසන් දර්ශකය නොඉක්මවිය යුතුය;
    /// * දර්ශක මුල් පෙත්තෙහි සීමාවන් තුළ තිබිය යුතුය;
    /// * දර්ශක UTF-8 අනුක්‍රමික මායිම් මත තිබිය යුතුය.
    ///
    /// එය අසමත් වුවහොත්, ආපසු ලබා දුන් නූල් පෙත්තෙහි අවලංගු මතකයක් සඳහන් කිරීමට හෝ `str` වර්ගය මගින් සන්නිවේදනය කරන ලද ආක්‍රමණ උල්ලං late නය කිරීමට ඉඩ ඇත.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // ආරක්ෂාව: අමතන්නා `get_unchecked_mut` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය;
        // `self` ආරක්ෂිත යොමු කිරීමක් බැවින් පෙත්ත අවලංගු කළ හැකිය.
        // ආපසු ලබා දුන් දර්ශකය ආරක්ෂිත වන්නේ `SliceIndex` හි impls එය බව සහතික කළ යුතු බැවිනි.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// ආරක්ෂිත චෙක්පත් මඟ හැර වෙනත් නූල් පෙත්තකින් නූල් පෙත්තක් සාදයි.
    ///
    /// මෙය සාමාන්‍යයෙන් නිර්දේශ නොකරයි, ප්‍රවේශමෙන් භාවිතා කරන්න!ආරක්ෂිත විකල්පයක් සඳහා [`str`] සහ [`Index`] බලන්න.
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// මෙම නව පෙත්ත `begin` ඇතුළුව `begin` සිට `end` දක්වා වන නමුත් `end` හැර.
    ///
    /// ඒ වෙනුවට විකෘති නූල් පෙත්තක් ලබා ගැනීමට, [`slice_mut_unchecked`] ක්‍රමය බලන්න.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// පූර්ව කොන්දේසි තුනක් සෑහීමකට පත්වීමට මෙම ශ්‍රිතයේ අමතන්නන් වගකිව යුතුය:
    ///
    /// * `begin` `end` නොඉක්මවිය යුතුය.
    /// * `begin` සහ `end` නූල් පෙත්ත තුළ බයිට් ස්ථාන විය යුතුය.
    /// * `begin` සහ `end` UTF-8 අනුක්‍රමික මායිම් මත පිහිටා තිබිය යුතුය.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // ආරක්ෂාව: අමතන්නා `get_unchecked` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය;
        // `self` ආරක්ෂිත යොමු කිරීමක් බැවින් පෙත්ත අවලංගු කළ හැකිය.
        // ආපසු ලබා දුන් දර්ශකය ආරක්ෂිත වන්නේ `SliceIndex` හි impls එය බව සහතික කළ යුතු බැවිනි.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// ආරක්ෂිත චෙක්පත් මඟ හැර වෙනත් නූල් පෙත්තකින් නූල් පෙත්තක් සාදයි.
    /// මෙය සාමාන්‍යයෙන් නිර්දේශ නොකරයි, ප්‍රවේශමෙන් භාවිතා කරන්න!ආරක්ෂිත විකල්පයක් සඳහා [`str`] සහ [`IndexMut`] බලන්න.
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// මෙම නව පෙත්ත `begin` ඇතුළුව `begin` සිට `end` දක්වා වන නමුත් `end` හැර.
    ///
    /// ඒ වෙනුවට වෙනස් කළ නොහැකි නූල් පෙත්තක් ලබා ගැනීමට, [`slice_unchecked`] ක්‍රමය බලන්න.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// පූර්ව කොන්දේසි තුනක් සෑහීමකට පත්වීමට මෙම ශ්‍රිතයේ අමතන්නන් වගකිව යුතුය:
    ///
    /// * `begin` `end` නොඉක්මවිය යුතුය.
    /// * `begin` සහ `end` නූල් පෙත්ත තුළ බයිට් ස්ථාන විය යුතුය.
    /// * `begin` සහ `end` UTF-8 අනුක්‍රමික මායිම් මත පිහිටා තිබිය යුතුය.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // ආරක්ෂාව: අමතන්නා `get_unchecked_mut` සඳහා වන ආරක්ෂක කොන්ත්‍රාත්තුව පිළිගත යුතුය;
        // `self` ආරක්ෂිත යොමු කිරීමක් බැවින් පෙත්ත අවලංගු කළ හැකිය.
        // ආපසු ලබා දුන් දර්ශකය ආරක්ෂිත වන්නේ `SliceIndex` හි impls එය බව සහතික කළ යුතු බැවිනි.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// දර්ශකයක එක් නූල් පෙත්තක් දෙකට බෙදන්න.
    ///
    /// `mid` යන තර්කය නූල් ආරම්භයේ සිටම බයිට් ඕෆ්සෙට් එකක් විය යුතුය.
    /// එය UTF-8 කේත ලක්ෂ්‍යයක මායිමේ ද තිබිය යුතුය.
    ///
    /// ආපසු ලබා දුන් පෙති දෙක නූල් පෙත්තක ආරම්භයේ සිට `mid` දක්වාත්, `mid` සිට නූල් පෙත්තෙහි අවසානය දක්වාත් ගමන් කරයි.
    ///
    /// ඒ වෙනුවට විකෘති නූල් පෙති ලබා ගැනීමට, [`split_at_mut`] ක්‍රමය බලන්න.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// 0Panics, `mid` යනු UTF-8 කේත ලක්ෂ්‍ය මායිමක නොමැති නම්, හෝ එය නූල් පෙත්තක අවසාන කේත ලක්ෂ්‍යයේ අවසානය පසු කර ඇත්නම්.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary පරික්ෂා කරන්නේ දර්ශකය [0, .len()]
        if self.is_char_boundary(mid) {
            // ආරක්ෂාව: `mid` වර්‍ග මායිමක තිබේදැයි පරීක්ෂා කර බලන්න.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// එක් විකෘති නූල් පෙත්තක් දර්ශකයකට දෙකට බෙදන්න.
    ///
    /// `mid` යන තර්කය නූල් ආරම්භයේ සිටම බයිට් ඕෆ්සෙට් එකක් විය යුතුය.
    /// එය UTF-8 කේත ලක්ෂ්‍යයක මායිමේ ද තිබිය යුතුය.
    ///
    /// ආපසු ලබා දුන් පෙති දෙක නූල් පෙත්තක ආරම්භයේ සිට `mid` දක්වාත්, `mid` සිට නූල් පෙත්තෙහි අවසානය දක්වාත් ගමන් කරයි.
    ///
    /// ඒ වෙනුවට වෙනස් කළ නොහැකි නූල් පෙති ලබා ගැනීමට, [`split_at`] ක්‍රමය බලන්න.
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// 0Panics, `mid` යනු UTF-8 කේත ලක්ෂ්‍ය මායිමක නොමැති නම්, හෝ එය නූල් පෙත්තක අවසාන කේත ලක්ෂ්‍යයේ අවසානය පසු කර ඇත්නම්.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary පරික්ෂා කරන්නේ දර්ශකය [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // ආරක්ෂාව: `mid` වර්‍ග මායිමක තිබේදැයි පරීක්ෂා කර බලන්න.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// නූල් පෙත්තක [`char`] හරහා ඉරේටරයක් ලබා දෙයි.
    ///
    /// නූල් පෙත්තක් වලංගු UTF-8 වලින් සමන්විත වන බැවින්, අපට [`char`] මගින් නූල් පෙත්තක් හරහා නැවත යෙදිය හැකිය.
    /// මෙම ක්‍රමය මඟින් එවැනි අනුකාරකයක් ලබා දෙයි.
    ///
    /// [`char`] යුනිකෝඩ් පරිමාණ අගයක් නියෝජනය කරන බව මතක තබා ගැනීම වැදගත් වන අතර 'character' යනු කුමක්ද යන්න පිළිබඳ ඔබේ අදහසට නොගැලපේ.
    ///
    /// ග්‍රැෆීම් පොකුරු වලට අනුරූප වීම ඔබට සැබවින්ම අවශ්‍ය දේ විය හැකිය.
    /// මෙම ක්‍රියාකාරීත්වය Rust හි සම්මත පුස්තකාලය මඟින් සපයනු නොලැබේ, ඒ වෙනුවට crates.io පරීක්ෂා කරන්න.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// මතක තබා ගන්න, [`char`] අක්ෂර පිළිබඳ ඔබේ බුද්ධියට නොගැලපේ:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // 'y̆' නොවේ
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// නූල් පෙත්තක [චාර්] සහ ඒවායේ පිහිටීම් වලට ඉහළින් අනුකාරකයක් ලබා දෙයි.
    ///
    /// නූල් පෙත්තක් වලංගු UTF-8 වලින් සමන්විත වන බැවින්, අපට [`char`] මගින් නූල් පෙත්තක් හරහා නැවත යෙදිය හැකිය.
    /// මෙම ක්‍රමය මඟින් මෙම [චාර්] දෙකෙහිම අනුකාරකයක් මෙන්ම ඒවායේ බයිට් ස්ථානද ලබා දෙයි.
    ///
    /// අනුකාරකය ටුපල් ලබා දෙයි.ස්ථානය පළමුවැන්න, [`char`] දෙවන ස්ථානයයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// මතක තබා ගන්න, [`char`] අක්ෂර පිළිබඳ ඔබේ බුද්ධියට නොගැලපේ:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // නොවේ (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // මෙහි 3 සටහන් කරන්න, අවසාන චරිතය බයිට් දෙකක් ගෙන ඇත
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// නූල් පෙත්තක බයිට් වලට වඩා අනුකාරකයක්.
    ///
    /// නූල් පෙත්තක් බයිට් අනුක්‍රමයකින් සමන්විත වන බැවින්, අපට බයිට් එකකින් නූල් පෙත්තක් හරහා නැවත යෙදිය හැකිය.
    /// මෙම ක්‍රමය මඟින් එවැනි අනුකාරකයක් ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// හිස් අවකාශයකින් නූල් පෙත්තක් බෙදයි.
    ///
    /// ආපසු එන ඉරේටරය මුල් හිස් පෙත්තෙහි උප පෙති වන ඕනෑම සුදු අවකාශයකින් වෙන් කරනු ලැබේ.
    ///
    ///
    /// 'Whitespace' යුනිකෝඩ් ව්‍යුත්පන්න මූලික දේපල `White_Space` හි නියමයන්ට අනුව අර්ථ දක්වා ඇත.
    /// ඔබට ඒ වෙනුවට ASCII හිස් අවකාශය මත බෙදීමට අවශ්‍ය නම්, [`split_ascii_whitespace`] භාවිතා කරන්න.
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// සියලු වර්ගවල සුදු අවකාශය සැලකේ:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// ASCII වයිට්ස්පේස් විසින් නූල් පෙත්තක් බෙදයි.
    ///
    /// ආපසු එන ඉරේටරය මුල් නූල් පෙත්තෙහි උප පෙති වන ASCII සුදු අවකාශයේ ඕනෑම ප්‍රමාණයකින් වෙන් කරනු ලැබේ.
    ///
    ///
    /// ඒ වෙනුවට යුනිකෝඩ් `Whitespace` මගින් බෙදීමට [`split_whitespace`] භාවිතා කරන්න.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// සියලු වර්ගවල ASCII සුදු අවකාශය සැලකේ:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// නූල් පෙති ලෙස නූලක රේඛාවලට ඉහලින් ඉරේටරයක්.
    ///
    /// රේඛා අවසන් වන්නේ නව රේඛීය (`\n`) හෝ (`\r\n`) රේඛීය සංග්‍රහයක් සහිත කරත්ත ආපසු යැවීමෙනි.
    ///
    /// අවසාන පේළියේ අවසානය අත්‍යවශ්‍ය නොවේ.
    /// අවසාන පේළියේ අවසානයකින් අවසන් වන නූලක් අවසන් රේඛා අවසානයකින් තොරව වෙනත් ආකාරයකින් සමාන රේඛාවක් ලබා දෙනු ඇත.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// අවසාන පේළියේ අවසානය අවශ්‍ය නොවේ:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// නූලක රේඛාවලට ඉහලින් අනුකාරකයක්.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// UTF-16 ලෙස කේතනය කර ඇති නූලට ඉහළින් `u16` හි අනුකාරකයක් ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// දී ඇති රටාව මෙම නූල් පෙත්තෙහි උප පෙත්තකට ගැලපෙන්නේ නම් `true` ලබා දෙයි.
    ///
    /// `false` එසේ නොවේ නම් එය ලබා දෙයි.
    ///
    /// [pattern] යනු `&str`, [`char`], [`char`] පෙත්තක් හෝ චරිතයක් ගැලපෙන්නේද යන්න තීරණය කරන ශ්‍රිතයක් හෝ වසා දැමීමක් විය හැකිය.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// දී ඇති රටාව මෙම නූල් පෙත්තෙහි උපසර්ගයකට ගැලපෙන්නේ නම් `true` ලබා දෙයි.
    ///
    /// `false` එසේ නොවේ නම් එය ලබා දෙයි.
    ///
    /// [pattern] යනු `&str`, [`char`], [`char`] පෙත්තක් හෝ චරිතයක් ගැලපෙන්නේද යන්න තීරණය කරන ශ්‍රිතයක් හෝ වසා දැමීමක් විය හැකිය.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// දී ඇති රටාව මෙම නූල් පෙත්තෙහි උපසර්ගයකට ගැලපෙන්නේ නම් `true` ලබා දෙයි.
    ///
    /// `false` එසේ නොවේ නම් එය ලබා දෙයි.
    ///
    /// [pattern] යනු `&str`, [`char`], [`char`] පෙත්තක් හෝ චරිතයක් ගැලපෙන්නේද යන්න තීරණය කරන ශ්‍රිතයක් හෝ වසා දැමීමක් විය හැකිය.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// රටාවට ගැළපෙන මෙම නූල් පෙත්තෙහි පළමු අක්‍ෂරයේ බයිට් දර්ශකය ලබා දෙයි.
    ///
    /// රටාව නොගැලපේ නම් [`None`] ලබා දෙයි.
    ///
    /// [pattern] යනු `&str`, [`char`], [`char`] පෙත්තක් හෝ චරිතයක් ගැලපෙන්නේද යන්න තීරණය කරන ශ්‍රිතයක් හෝ වසා දැමීමක් විය හැකිය.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// සරල රටා:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// ලක්ෂ්‍ය රහිත ශෛලිය සහ වසා දැමීම් භාවිතා කරමින් වඩාත් සංකීර්ණ රටා:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// රටාව සොයා නොගැනීම:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// මෙම නූල් පෙත්තෙහි රටාවේ දකුණු කෙළවරේ ගැලපීමේ පළමු අක්‍ෂරය සඳහා බයිට් දර්ශකය ලබා දෙයි.
    ///
    /// රටාව නොගැලපේ නම් [`None`] ලබා දෙයි.
    ///
    /// [pattern] යනු `&str`, [`char`], [`char`] පෙත්තක් හෝ චරිතයක් ගැලපෙන්නේද යන්න තීරණය කරන ශ්‍රිතයක් හෝ වසා දැමීමක් විය හැකිය.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// සරල රටා:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// වසා දැමීම් සමඟ වඩාත් සංකීර්ණ රටා:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// රටාව සොයා නොගැනීම:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// මෙම නූල් පෙත්තෙහි උපස්ථර වලට වඩා අනුකාරකයක්, රටාවකට ගැලපෙන අක්ෂර වලින් වෙන් කරනු ලැබේ.
    ///
    /// [pattern] යනු `&str`, [`char`], [`char`] පෙත්තක් හෝ චරිතයක් ගැලපෙන්නේද යන්න තීරණය කරන ශ්‍රිතයක් හෝ වසා දැමීමක් විය හැකිය.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # අනුකාරක හැසිරීම
    ///
    /// රටාව ප්‍රතිලෝම සෙවුමකට ඉඩ දෙන්නේ නම් සහ forward/reverse සෙවුම එකම මූලද්‍රව්‍යයන් ලබා දෙන්නේ නම් ආපසු ලබා දුන් අනුකාරකය [`DoubleEndedIterator`] වේ.
    /// මෙය සත්‍ය වේ, උදා: [`char`], නමුත් `&str` සඳහා නොවේ.
    ///
    /// රටාව ප්‍රතිලෝම සෙවුමකට ඉඩ දුන්නද එහි ප්‍රති results ල ඉදිරි සෙවුමකට වඩා වෙනස් විය හැකි නම්, [`rsplit`] ක්‍රමය භාවිතා කළ හැකිය.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// සරල රටා:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// රටාව අක්ෂර පෙත්තක් නම්, ඕනෑම අක්ෂරයක එක් එක් සිදුවීම මත බෙදන්න:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// වසා දැමීමක් භාවිතා කරමින් වඩාත් සංකීර්ණ රටාවක්:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// නූලක බහු පරස්පර බෙදුම්කරුවන් තිබේ නම්, ඔබ නිමැවුමේ හිස් නූල් වලින් අවසන් වනු ඇත:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// පරස්පර බෙදුම්කරුවන් හිස් නූලෙන් වෙන් කරනු ලැබේ.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// නූලක ආරම්භයේ හෝ අවසානයේ ඇති බෙදුම්කරුවන් හිස් නූල් වලින් අසල්වැසි වේ.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// හිස් නූල බෙදුම්කරුවෙකු ලෙස භාවිතා කරන විට, එය නූලෙහි සෑම අක්‍ෂරයක්ම, නූලෙහි ආරම්භය හා අවසානය සමඟ වෙන් කරයි.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// පරතරය බෙදුම්කරු ලෙස සුදු අවකාශය භාවිතා කරන විට පුදුම සහගත හැසිරීම් වලට තුඩු දිය හැකිය.මෙම කේතය නිවැරදි ය:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// එය _not_ ඔබට ලබා දෙයි:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// මෙම හැසිරීම සඳහා [`split_whitespace`] භාවිතා කරන්න.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// මෙම නූල් පෙත්තෙහි උපස්ථර වලට වඩා අනුකාරකයක්, රටාවකට ගැලපෙන අක්ෂර වලින් වෙන් කරනු ලැබේ.
    /// එම `split_inclusive` හි `split` විසින් නිපදවන iterator වෙතින් වෙනස් වේ, ගැලපෙන කොටස උපස්ථරයේ පර්යන්තය ලෙස තබයි.
    ///
    ///
    /// [pattern] යනු `&str`, [`char`], [`char`] පෙත්තක් හෝ චරිතයක් ගැලපෙන්නේද යන්න තීරණය කරන ශ්‍රිතයක් හෝ වසා දැමීමක් විය හැකිය.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// නූලෙහි අවසාන මූලද්‍රව්‍යය ගැලපෙන්නේ නම්, එම මූලද්‍රව්‍යය පූර්ව උපස්ථරයේ අවසානය ලෙස සැලකේ.
    /// එම උපස්ථරය iterator විසින් ආපසු ලබා දුන් අවසාන අයිතමය වේ.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// දී ඇති නූල් පෙත්තක උපස්ථර වලට වඩා අනුකාරකයක්, රටාවකට අනුරූප වන අක්‍ෂර වලින් වෙන් කොට ප්‍රතිලෝම අනුපිළිවෙලින් ලබා දේ.
    ///
    /// [pattern] යනු `&str`, [`char`], [`char`] පෙත්තක් හෝ චරිතයක් ගැලපෙන්නේද යන්න තීරණය කරන ශ්‍රිතයක් හෝ වසා දැමීමක් විය හැකිය.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # අනුකාරක හැසිරීම
    ///
    /// ආපසු ලබා දුන් අනුකාරකයට රටාව ප්‍රතිලෝම සෙවුමක් සඳහා සහාය විය යුතු අතර, forward/reverse සෙවුමක් එකම මූලද්‍රව්‍ය ලබා දෙන්නේ නම් එය [`DoubleEndedIterator`] වනු ඇත.
    ///
    ///
    /// ඉදිරිපස සිට නැවත ක්‍රියා කිරීම සඳහා, [`split`] ක්‍රමය භාවිතා කළ හැකිය.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// සරල රටා:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// වසා දැමීමක් භාවිතා කරමින් වඩාත් සංකීර්ණ රටාවක්:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// ලබා දී ඇති නූල් පෙත්තක උපස්ථර වලට වඩා අනුකාරකයක්, රටාවකට අනුරූප වන අක්ෂර වලින් වෙන් කරනු ලැබේ.
    ///
    /// [pattern] යනු `&str`, [`char`], [`char`] පෙත්තක් හෝ චරිතයක් ගැලපෙන්නේද යන්න තීරණය කරන ශ්‍රිතයක් හෝ වසා දැමීමක් විය හැකිය.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] ට සමාන වේ, පසුපස උපස්ථරය හිස් නම් මඟ හැරේ.
    ///
    /// [`split`]: str::split
    ///
    /// මෙම ක්‍රමය රටාවකින් _separated_ වෙනුවට _terminated_ වන නූල් දත්ත සඳහා භාවිතා කළ හැකිය.
    ///
    /// # අනුකාරක හැසිරීම
    ///
    /// රටාව ප්‍රතිලෝම සෙවුමකට ඉඩ දෙන්නේ නම් සහ forward/reverse සෙවුම එකම මූලද්‍රව්‍යයන් ලබා දෙන්නේ නම් ආපසු ලබා දුන් අනුකාරකය [`DoubleEndedIterator`] වේ.
    /// මෙය සත්‍ය වේ, උදා: [`char`], නමුත් `&str` සඳහා නොවේ.
    ///
    /// රටාව ප්‍රතිලෝම සෙවුමකට ඉඩ දුන්නද එහි ප්‍රති results ල ඉදිරි සෙවුමකට වඩා වෙනස් විය හැකි නම්, [`rsplit_terminator`] ක්‍රමය භාවිතා කළ හැකිය.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// `self` උපස්ථර වලට වඩා අනුකාරකයක්, රටාවකට අනුරූප වන අක්‍ෂර වලින් වෙන් කොට ප්‍රතිලෝම අනුපිළිවෙලින් ලබා දේ.
    ///
    /// [pattern] යනු `&str`, [`char`], [`char`] පෙත්තක් හෝ චරිතයක් ගැලපෙන්නේද යන්න තීරණය කරන ශ්‍රිතයක් හෝ වසා දැමීමක් විය හැකිය.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] ට සමාන වේ, පසුපස උපස්ථරය හිස් නම් මඟ හැරේ.
    ///
    /// [`split`]: str::split
    ///
    /// මෙම ක්‍රමය රටාවකින් _separated_ වෙනුවට _terminated_ වන නූල් දත්ත සඳහා භාවිතා කළ හැකිය.
    ///
    /// # අනුකාරක හැසිරීම
    ///
    /// ආපසු ලබා දුන් අනුකාරකයට රටාව ප්‍රතිලෝම සෙවුමකට සහය දැක්විය යුතු අතර forward/reverse සෙවුමක් එකම මූලද්‍රව්‍ය ලබා දෙන්නේ නම් එය දෙගුණයක් වනු ඇත.
    ///
    ///
    /// ඉදිරිපස සිට නැවත ක්‍රියා කිරීම සඳහා, [`split_terminator`] ක්‍රමය භාවිතා කළ හැකිය.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// ලබා දී ඇති නූල් පෙත්තෙහි උපස්ථර වලට වඩා අනුකාරකයක්, රටාවකින් වෙන් කොට, බොහෝ `n` අයිතම වෙත ආපසු යාමට සීමා කර ඇත.
    ///
    /// `n` උපස්ථර ආපසු ලබා දෙන්නේ නම්, අවසාන උපස්ථරයේ (`n` උපස්ථරය) ඉතිරි නූල අඩංගු වේ.
    ///
    /// [pattern] යනු `&str`, [`char`], [`char`] පෙත්තක් හෝ චරිතයක් ගැලපෙන්නේද යන්න තීරණය කරන ශ්‍රිතයක් හෝ වසා දැමීමක් විය හැකිය.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # අනුකාරක හැසිරීම
    ///
    /// ආපසු ලබා දුන් අනුකාරකය ද්විත්ව අවසානයක් නොවනු ඇත, මන්ද එය සහාය වීමට කාර්යක්ෂම නොවන බැවිනි.
    ///
    /// රටාව ප්‍රතිලෝම සෙවුමකට ඉඩ දෙන්නේ නම්, [`rsplitn`] ක්‍රමය භාවිතා කළ හැකිය.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// සරල රටා:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// වසා දැමීමක් භාවිතා කරමින් වඩාත් සංකීර්ණ රටාවක්:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// මෙම නූල් පෙත්තෙහි උපස්ථර වලට වඩා අනුකාරකයක්, රටාවකින් වෙන් කොට, නූල් කෙළවරේ සිට ආරම්භ කර, බොහෝ `n` අයිතම වෙත ආපසු යාමට සීමා වේ.
    ///
    ///
    /// `n` උපස්ථර ආපසු ලබා දෙන්නේ නම්, අවසාන උපස්ථරයේ (`n` උපස්ථරය) ඉතිරි නූල අඩංගු වේ.
    ///
    /// [pattern] යනු `&str`, [`char`], [`char`] පෙත්තක් හෝ චරිතයක් ගැලපෙන්නේද යන්න තීරණය කරන ශ්‍රිතයක් හෝ වසා දැමීමක් විය හැකිය.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # අනුකාරක හැසිරීම
    ///
    /// ආපසු ලබා දුන් අනුකාරකය ද්විත්ව අවසානයක් නොවනු ඇත, මන්ද එය සහාය වීමට කාර්යක්ෂම නොවන බැවිනි.
    ///
    /// ඉදිරිපස සිට බෙදීම සඳහා, [`splitn`] ක්රමය භාවිතා කළ හැකිය.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// සරල රටා:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// වසා දැමීමක් භාවිතා කරමින් වඩාත් සංකීර්ණ රටාවක්:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// නිශ්චිත පරිසීමකයේ පළමු සිදුවීම මත නූල බෙදී පරිසීමාවට පෙර උපසර්ගය සහ පරිසීමාවෙන් පසු උපසර්ගය ලබා දෙයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// නිශ්චිත පරිසීමකයේ අවසාන සිදුවීම මත නූල බෙදී පරිසීමාවට පෙර උපසර්ගය සහ පරිසීමාවෙන් පසු උපසර්ගය ලබා දෙයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// ලබා දී ඇති නූල් පෙත්ත තුළ රටාවක නොගැලපීම් ගැලපීම් පිළිබඳ අනුකාරකය.
    ///
    /// [pattern] යනු `&str`, [`char`], [`char`] පෙත්තක් හෝ චරිතයක් ගැලපෙන්නේද යන්න තීරණය කරන ශ්‍රිතයක් හෝ වසා දැමීමක් විය හැකිය.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # අනුකාරක හැසිරීම
    ///
    /// රටාව ප්‍රතිලෝම සෙවුමකට ඉඩ දෙන්නේ නම් සහ forward/reverse සෙවුම එකම මූලද්‍රව්‍යයන් ලබා දෙන්නේ නම් ආපසු ලබා දුන් අනුකාරකය [`DoubleEndedIterator`] වේ.
    /// මෙය සත්‍ය වේ, උදා: [`char`], නමුත් `&str` සඳහා නොවේ.
    ///
    /// රටාව ප්‍රතිලෝම සෙවුමකට ඉඩ දුන්නද එහි ප්‍රති results ල ඉදිරි සෙවුමකට වඩා වෙනස් විය හැකි නම්, [`rmatches`] ක්‍රමය භාවිතා කළ හැකිය.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// මෙම නූල් පෙත්ත තුළ ඇති රටාවක නොගැලපීම් ගැලපීම් පිළිබඳ අනුකාරකයක් ප්‍රතිලෝම අනුපිළිවෙලින් ලබා දේ.
    ///
    /// [pattern] යනු `&str`, [`char`], [`char`] පෙත්තක් හෝ චරිතයක් ගැලපෙන්නේද යන්න තීරණය කරන ශ්‍රිතයක් හෝ වසා දැමීමක් විය හැකිය.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # අනුකාරක හැසිරීම
    ///
    /// ආපසු ලබා දුන් අනුකාරකයට රටාව ප්‍රතිලෝම සෙවුමක් සඳහා සහාය විය යුතු අතර, forward/reverse සෙවුමක් එකම මූලද්‍රව්‍ය ලබා දෙන්නේ නම් එය [`DoubleEndedIterator`] වනු ඇත.
    ///
    ///
    /// ඉදිරිපස සිට නැවත ක්‍රියා කිරීම සඳහා, [`matches`] ක්‍රමය භාවිතා කළ හැකිය.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// මෙම නූල් පෙත්ත තුළ ඇති රටාවක නොගැලපීම් ගැලපීම් සහ තරගය ආරම්භ වන දර්ශකය පිළිබඳ අනුකාරකයක්.
    ///
    /// අතිච්ඡාදනය වන `self` තුළ ඇති `pat` තරඟ සඳහා, පළමු තරඟයට අනුරූප දර්ශක පමණක් ආපසු ලබා දෙනු ලැබේ.
    ///
    /// [pattern] යනු `&str`, [`char`], [`char`] පෙත්තක් හෝ චරිතයක් ගැලපෙන්නේද යන්න තීරණය කරන ශ්‍රිතයක් හෝ වසා දැමීමක් විය හැකිය.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # අනුකාරක හැසිරීම
    ///
    /// රටාව ප්‍රතිලෝම සෙවුමකට ඉඩ දෙන්නේ නම් සහ forward/reverse සෙවුම එකම මූලද්‍රව්‍යයන් ලබා දෙන්නේ නම් ආපසු ලබා දුන් අනුකාරකය [`DoubleEndedIterator`] වේ.
    /// මෙය සත්‍ය වේ, උදා: [`char`], නමුත් `&str` සඳහා නොවේ.
    ///
    /// රටාව ප්‍රතිලෝම සෙවුමකට ඉඩ දුන්නද එහි ප්‍රති results ල ඉදිරි සෙවුමකට වඩා වෙනස් විය හැකි නම්, [`rmatch_indices`] ක්‍රමය භාවිතා කළ හැකිය.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // පළමු `aba` පමණි
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// `self` තුළ රටාවක නොගැලපීම් ගැලපීම් පිළිබඳ අනුකාරකයක්, තරඟයේ දර්ශකය සමඟ ප්‍රතිලෝම අනුපිළිවෙලින් ලබා දී ඇත.
    ///
    /// අතිච්ඡාදනය වන `self` තුළ ඇති `pat` තරඟ සඳහා, අවසන් තරඟයට අනුරූප දර්ශක පමණක් ආපසු ලබා දෙනු ලැබේ.
    ///
    /// [pattern] යනු `&str`, [`char`], [`char`] පෙත්තක් හෝ චරිතයක් ගැලපෙන්නේද යන්න තීරණය කරන ශ්‍රිතයක් හෝ වසා දැමීමක් විය හැකිය.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # අනුකාරක හැසිරීම
    ///
    /// ආපසු ලබා දුන් අනුකාරකයට රටාව ප්‍රතිලෝම සෙවුමක් සඳහා සහාය විය යුතු අතර, forward/reverse සෙවුමක් එකම මූලද්‍රව්‍ය ලබා දෙන්නේ නම් එය [`DoubleEndedIterator`] වනු ඇත.
    ///
    ///
    /// ඉදිරිපස සිට නැවත ක්‍රියා කිරීම සඳහා, [`match_indices`] ක්‍රමය භාවිතා කළ හැකිය.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // අන්තිම `aba` පමණි
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// ප්‍රමුඛ හා පසුපස සුදු අවකාශය ඉවත් කර ඇති නූල් පෙත්තක් ලබා දෙයි.
    ///
    /// 'Whitespace' යුනිකෝඩ් ව්‍යුත්පන්න මූලික දේපල `White_Space` හි නියමයන්ට අනුව අර්ථ දක්වා ඇත.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// ප්‍රමුඛ සුදු අවකාශය ඉවත් කර ඇති නූල් පෙත්තක් ලබා දෙයි.
    ///
    /// 'Whitespace' යුනිකෝඩ් ව්‍යුත්පන්න මූලික දේපල `White_Space` හි නියමයන්ට අනුව අර්ථ දක්වා ඇත.
    ///
    /// # පෙළ දිශානතිය
    ///
    /// නූලක් යනු බයිට් අනුක්‍රමයකි.
    /// `start` මෙම සන්දර්භය තුළ එම බයිට් නූලෙහි පළමු ස්ථානය අදහස් වේ;ඉංග්‍රීසි හෝ රුසියානු වැනි වමේ සිට දකුණට, මෙය වම් පැත්ත වන අතර, අරාබි හෝ හෙබ්‍රෙව් වැනි දකුණේ සිට වමට, මෙය දකුණු පැත්ත වනු ඇත.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// ඉවත් කරන ලද හිස් අවකාශය සහිත නූල් පෙත්තක් ලබා දෙයි.
    ///
    /// 'Whitespace' යුනිකෝඩ් ව්‍යුත්පන්න මූලික දේපල `White_Space` හි නියමයන්ට අනුව අර්ථ දක්වා ඇත.
    ///
    /// # පෙළ දිශානතිය
    ///
    /// නූලක් යනු බයිට් අනුක්‍රමයකි.
    /// `end` මෙම සන්දර්භය තුළ එම බයිට් නූලෙහි අවසාන පිහිටීම අදහස් වේ;ඉංග්‍රීසි හෝ රුසියානු වැනි වමේ සිට දකුණට, මෙය දකුණු පැත්ත වන අතර, අරාබි හෝ හෙබ්‍රෙව් වැනි දකුණේ සිට වමට භාෂාවන් සඳහා මෙය වම් පැත්ත වනු ඇත.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// ප්‍රමුඛ සුදු අවකාශය ඉවත් කර ඇති නූල් පෙත්තක් ලබා දෙයි.
    ///
    /// 'Whitespace' යුනිකෝඩ් ව්‍යුත්පන්න මූලික දේපල `White_Space` හි නියමයන්ට අනුව අර්ථ දක්වා ඇත.
    ///
    /// # පෙළ දිශානතිය
    ///
    /// නූලක් යනු බයිට් අනුක්‍රමයකි.
    /// 'Left' මෙම සන්දර්භය තුළ එම බයිට් නූලෙහි පළමු ස්ථානය අදහස් වේ;අරාබි හෝ හෙබ්‍රෙව් වැනි භාෂාවක් සඳහා 'වමේ සිට දකුණට' වඩා 'දකුණේ සිට වමට' නම්, මෙය වමේ නොව _right_ පැත්ත වනු ඇත.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// ඉවත් කරන ලද හිස් අවකාශය සහිත නූල් පෙත්තක් ලබා දෙයි.
    ///
    /// 'Whitespace' යුනිකෝඩ් ව්‍යුත්පන්න මූලික දේපල `White_Space` හි නියමයන්ට අනුව අර්ථ දක්වා ඇත.
    ///
    /// # පෙළ දිශානතිය
    ///
    /// නූලක් යනු බයිට් අනුක්‍රමයකි.
    /// 'Right' මෙම සන්දර්භය තුළ එම බයිට් නූලෙහි අවසාන පිහිටීම අදහස් වේ;අරාබි හෝ හෙබ්‍රෙව් වැනි භාෂාවක් සඳහා 'වමේ සිට දකුණට' වඩා 'දකුණේ සිට වමට' නම්, මෙය _left_ පැත්ත මිස දකුණ නොවේ.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// නැවත නැවත ඉවත් කරන ලද රටාවකට ගැලපෙන සියලුම උපසර්ග සහ උපසර්ග සහිත නූල් පෙත්තක් ලබා දෙයි.
    ///
    /// [pattern] යනු [`char`], [`char`] පෙත්තක් හෝ චරිතයක් ගැලපෙන්නේද යන්න තීරණය කරන ශ්‍රිතයක් හෝ වසා දැමීමක් විය හැකිය.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// සරල රටා:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// වසා දැමීමක් භාවිතා කරමින් වඩාත් සංකීර්ණ රටාවක්:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // කලින් දන්නා තරගය මතක තබා ගන්න, එය පහත නම් නිවැරදි කරන්න
            // අවසාන තරගය වෙනස් ය
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // ආරක්ෂාව: `Searcher` වලංගු දර්ශක ආපසු ලබා දෙන බව දන්නා කරුණකි.
        unsafe { self.get_unchecked(i..j) }
    }

    /// නැවත නැවත ඉවත් කරන ලද රටාවකට ගැලපෙන සියලුම උපසර්ග සමඟ නූල් පෙත්තක් ලබා දෙයි.
    ///
    /// [pattern] යනු `&str`, [`char`], [`char`] පෙත්තක් හෝ චරිතයක් ගැලපෙන්නේද යන්න තීරණය කරන ශ්‍රිතයක් හෝ වසා දැමීමක් විය හැකිය.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # පෙළ දිශානතිය
    ///
    /// නූලක් යනු බයිට් අනුක්‍රමයකි.
    /// `start` මෙම සන්දර්භය තුළ එම බයිට් නූලෙහි පළමු ස්ථානය අදහස් වේ;ඉංග්‍රීසි හෝ රුසියානු වැනි වමේ සිට දකුණට, මෙය වම් පැත්ත වන අතර, අරාබි හෝ හෙබ්‍රෙව් වැනි දකුණේ සිට වමට, මෙය දකුණු පැත්ත වනු ඇත.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // ආරක්ෂාව: `Searcher` වලංගු දර්ශක ආපසු ලබා දෙන බව දන්නා කරුණකි.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// ඉවත් කරන ලද උපසර්ගය සමඟ නූල් පෙත්තක් ලබා දෙයි.
    ///
    /// නූල `prefix` රටාවෙන් ආරම්භ වන්නේ නම්, උපසර්ගයෙන් පසු උපස්ථරය `Some` වලින් ඔතා.
    /// `trim_start_matches` මෙන් නොව, මෙම ක්‍රමය හරියටම එක් වරක් උපසර්ගය ඉවත් කරයි.
    ///
    /// නූල `prefix` සමඟ ආරම්භ නොවන්නේ නම්, `None` ලබා දෙයි.
    ///
    /// [pattern] යනු `&str`, [`char`], [`char`] පෙත්තක් හෝ චරිතයක් ගැලපෙන්නේද යන්න තීරණය කරන ශ්‍රිතයක් හෝ වසා දැමීමක් විය හැකිය.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// ඉවත් කරන ලද උපසර්ගය සමඟ නූල් පෙත්තක් ලබා දෙයි.
    ///
    /// `suffix` රටාව සමඟ නූල අවසන් වන්නේ නම්, උපසර්ගයට පෙර උපස්ථරය `Some` වලින් ඔතා.
    /// `trim_end_matches` මෙන් නොව, මෙම ක්‍රමය හරියටම එක් වරක් උපසර්ගය ඉවත් කරයි.
    ///
    /// `suffix` සමඟ නූල අවසන් නොවන්නේ නම්, `None` ආපසු ලබා දේ.
    ///
    /// [pattern] යනු `&str`, [`char`], [`char`] පෙත්තක් හෝ චරිතයක් ගැලපෙන්නේද යන්න තීරණය කරන ශ්‍රිතයක් හෝ වසා දැමීමක් විය හැකිය.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// නැවත නැවත ඉවත් කරන ලද රටාවකට ගැලපෙන සියලුම උපසර්ග සහිත නූල් පෙත්තක් ලබා දෙයි.
    ///
    /// [pattern] යනු `&str`, [`char`], [`char`] පෙත්තක් හෝ චරිතයක් ගැලපෙන්නේද යන්න තීරණය කරන ශ්‍රිතයක් හෝ වසා දැමීමක් විය හැකිය.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # පෙළ දිශානතිය
    ///
    /// නූලක් යනු බයිට් අනුක්‍රමයකි.
    /// `end` මෙම සන්දර්භය තුළ එම බයිට් නූලෙහි අවසාන පිහිටීම අදහස් වේ;ඉංග්‍රීසි හෝ රුසියානු වැනි වමේ සිට දකුණට, මෙය දකුණු පැත්ත වන අතර, අරාබි හෝ හෙබ්‍රෙව් වැනි දකුණේ සිට වමට භාෂාවන් සඳහා මෙය වම් පැත්ත වනු ඇත.
    ///
    ///
    /// # Examples
    ///
    /// සරල රටා:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// වසා දැමීමක් භාවිතා කරමින් වඩාත් සංකීර්ණ රටාවක්:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // ආරක්ෂාව: `Searcher` වලංගු දර්ශක ආපසු ලබා දෙන බව දන්නා කරුණකි.
        unsafe { self.get_unchecked(0..j) }
    }

    /// නැවත නැවත ඉවත් කරන ලද රටාවකට ගැලපෙන සියලුම උපසර්ග සමඟ නූල් පෙත්තක් ලබා දෙයි.
    ///
    /// [pattern] යනු `&str`, [`char`], [`char`] පෙත්තක් හෝ චරිතයක් ගැලපෙන්නේද යන්න තීරණය කරන ශ්‍රිතයක් හෝ වසා දැමීමක් විය හැකිය.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # පෙළ දිශානතිය
    ///
    /// නූලක් යනු බයිට් අනුක්‍රමයකි.
    /// 'Left' මෙම සන්දර්භය තුළ එම බයිට් නූලෙහි පළමු ස්ථානය අදහස් වේ;අරාබි හෝ හෙබ්‍රෙව් වැනි භාෂාවක් සඳහා 'වමේ සිට දකුණට' වඩා 'දකුණේ සිට වමට' නම්, මෙය වමේ නොව _right_ පැත්ත වනු ඇත.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// නැවත නැවත ඉවත් කරන ලද රටාවකට ගැලපෙන සියලුම උපසර්ග සහිත නූල් පෙත්තක් ලබා දෙයි.
    ///
    /// [pattern] යනු `&str`, [`char`], [`char`] පෙත්තක් හෝ චරිතයක් ගැලපෙන්නේද යන්න තීරණය කරන ශ්‍රිතයක් හෝ වසා දැමීමක් විය හැකිය.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # පෙළ දිශානතිය
    ///
    /// නූලක් යනු බයිට් අනුක්‍රමයකි.
    /// 'Right' මෙම සන්දර්භය තුළ එම බයිට් නූලෙහි අවසාන පිහිටීම අදහස් වේ;අරාබි හෝ හෙබ්‍රෙව් වැනි භාෂාවක් සඳහා 'වමේ සිට දකුණට' වඩා 'දකුණේ සිට වමට' නම්, මෙය _left_ පැත්ත මිස දකුණ නොවේ.
    ///
    ///
    /// # Examples
    ///
    /// සරල රටා:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// වසා දැමීමක් භාවිතා කරමින් වඩාත් සංකීර්ණ රටාවක්:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// මෙම නූල් පෙත්ත වෙනත් වර්ගයකට විග්‍රහ කරයි.
    ///
    /// `parse` එතරම් සාමාන්‍ය බැවින් එය වර්ග අනුමාන කිරීම් සමඟ ගැටලු ඇති කළ හැකිය.
    /// එනිසා, `parse` යනු 'turbofish' ලෙස ආදරයෙන් හඳුන්වන වාක්‍ය ඛණ්ඩය ඔබ දකින කිහිප වතාවක් එකකි: `::<>`.
    ///
    /// ඔබ අනුමාන කිරීමට උත්සාහ කරන්නේ කුමන වර්ගයටද යන්න නිශ්චිතවම තේරුම් ගැනීමට මෙය අනුමාන ඇල්ගොරිතමයට උපකාරී වේ.
    ///
    /// `parse` [`FromStr`] trait ක්‍රියාත්මක කරන ඕනෑම වර්ගයකට විග්‍රහ කළ හැකිය.
    ///

    /// # Errors
    ///
    /// මෙම නූල් පෙත්ත අපේක්ෂිත වර්ගයට විග්‍රහ කිරීමට නොහැකි නම් [`Err`] නැවත ලබා දෙනු ඇත.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// `four` විවරණය කිරීම වෙනුවට 'turbofish' භාවිතා කිරීම:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// විග්‍රහ කිරීමට අපොහොසත් වීම:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// මෙම නූලෙහි ඇති සියලුම අක්ෂර ASCII පරාසය තුළ තිබේදැයි පරීක්ෂා කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // අපට මෙහි එක් එක් බයිටය අක්‍ෂර ලෙස සැලකිය හැකිය: සියලුම බහු බයිට් අක්ෂර ආරම්භ වන්නේ ඇස්කයි පරාසය තුළ නොමැති බයිට් එකකිනි, එබැවින් අපි දැනටමත් එහි නතර වෙමු.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// නූල් දෙකක් ASCII සිද්ධි-සංවේදී නොවන ගැලපීමක් දැයි පරීක්ෂා කරයි.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` හා සමානයි, නමුත් තාවකාලික වෙන් කිරීම සහ පිටපත් කිරීමකින් තොරව.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// මෙම නූල එහි ASCII ඉහළ අකුරට සමාන ස්ථානයකට පරිවර්තනය කරයි.
    ///
    /// ASCII අක්ෂර 'a' සිට 'z' දක්වා 'A' සිට 'Z' දක්වා සිතියම් ගත කර ඇත, නමුත් ASCII නොවන අකුරු නොවෙනස්ව පවතී.
    ///
    /// පවතින අගය වෙනස් නොකර නව ඉහළ අගයක් ලබා දීමට, [`to_ascii_uppercase()`] භාවිතා කරන්න.
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // ආරක්ෂාව: අපි එකම පිරිසැලසුමක් සහිතව වර්ග දෙකක් සම්ප්‍රේෂණය කරන නිසා ආරක්ෂිතයි.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// මෙම නූල එහි ASCII කුඩා අකුරට සමාන ස්ථානයකට පරිවර්තනය කරයි.
    ///
    /// ASCII අක්ෂර 'A' සිට 'Z' දක්වා 'a' සිට 'z' දක්වා සිතියම් ගත කර ඇත, නමුත් ASCII නොවන අකුරු නොවෙනස්ව පවතී.
    ///
    /// පවතින අගය වෙනස් නොකර නව අඩු අගයක් ලබා දීමට, [`to_ascii_lowercase()`] භාවිතා කරන්න.
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // ආරක්ෂාව: අපි එකම පිරිසැලසුමක් සහිතව වර්ග දෙකක් සම්ප්‍රේෂණය කරන නිසා ආරක්ෂිතයි.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// `self` හි එක් එක් වර්‍ගයෙන් [`char::escape_debug`] සමඟ ගැලවී යන ඉරේටරයක් ආපසු එවන්න.
    ///
    ///
    /// Note: නූල ආරම්භ වන විස්තාරණ ග්‍රැෆේම් කේත ලක්ෂ්‍ය පමණක් ගැලවී යනු ඇත.
    ///
    /// # Examples
    ///
    /// අනුකාරකයක් ලෙස:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` කෙලින්ම භාවිතා කිරීම:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// දෙකම සමාන වේ:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// `to_string` භාවිතා කිරීම:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// `self` හි එක් එක් වර්‍ගයෙන් [`char::escape_default`] සමඟ ගැලවී යන ඉරේටරයක් ආපසු එවන්න.
    ///
    ///
    /// # Examples
    ///
    /// අනුකාරකයක් ලෙස:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` කෙලින්ම භාවිතා කිරීම:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// දෙකම සමාන වේ:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// `to_string` භාවිතා කිරීම:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// `self` හි එක් එක් වර්‍ගයෙන් [`char::escape_unicode`] සමඟ ගැලවී යන ඉරේටරයක් ආපසු එවන්න.
    ///
    ///
    /// # Examples
    ///
    /// අනුකාරකයක් ලෙස:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` කෙලින්ම භාවිතා කිරීම:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// දෙකම සමාන වේ:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// `to_string` භාවිතා කිරීම:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// හිස් str එකක් සාදයි
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// හිස් විකෘති str එකක් සාදයි
    #[inline]
    fn default() -> Self {
        // ආරක්ෂාව: හිස් නූල වලංගු UTF-8 වේ.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// නම් කළ හැකි, ක්ලෝන කළ හැකි fn වර්ගයකි
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // ආරක්ෂාව: ආරක්ෂිත නොවේ
        unsafe { from_utf8_unchecked(bytes) }
    };
}