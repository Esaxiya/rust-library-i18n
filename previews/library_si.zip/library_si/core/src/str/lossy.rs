use crate::char;
use crate::fmt::{self, Write};
use crate::mem;

use super::from_utf8_unchecked;
use super::validations::utf8_char_width;

/// නැතිවූ UTF-8 නූල්.
#[unstable(feature = "str_internals", issue = "none")]
pub struct Utf8Lossy {
    bytes: [u8],
}

impl Utf8Lossy {
    pub fn from_str(s: &str) -> &Utf8Lossy {
        Utf8Lossy::from_bytes(s.as_bytes())
    }

    pub fn from_bytes(bytes: &[u8]) -> &Utf8Lossy {
        // ආරක්ෂාව: දෙකම එකම මතක පිරිසැලසුමක් භාවිතා කරන අතර UTF-8 නිරවද්‍යතාවය අවශ්‍ය නොවේ.
        unsafe { mem::transmute(bytes) }
    }

    pub fn chunks(&self) -> Utf8LossyChunksIter<'_> {
        Utf8LossyChunksIter { source: &self.bytes }
    }
}

/// පාඩු සහිත UTF-8 නූලට වඩා අනුකාරකය
#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_debug_implementations)]
pub struct Utf8LossyChunksIter<'a> {
    source: &'a [u8],
}

#[unstable(feature = "str_internals", issue = "none")]
#[derive(PartialEq, Eq, Debug)]
pub struct Utf8LossyChunk<'a> {
    /// වලංගු අක්ෂර අනුක්‍රමය.
    /// කැඩුණු UTF-8 අක්ෂර අතර හිස් විය හැකිය.
    pub valid: &'a str,
    /// තනි කැඩුණු වරහන්, කිසිවක් නොමැති නම් හිස්.
    /// හිස් iff iterator අයිතමය අන්තිමයි.
    pub broken: &'a [u8],
}

impl<'a> Iterator for Utf8LossyChunksIter<'a> {
    type Item = Utf8LossyChunk<'a>;

    fn next(&mut self) -> Option<Utf8LossyChunk<'a>> {
        if self.source.is_empty() {
            return None;
        }

        const TAG_CONT_U8: u8 = 128;
        fn safe_get(xs: &[u8], i: usize) -> u8 {
            *xs.get(i).unwrap_or(&0)
        }

        let mut i = 0;
        while i < self.source.len() {
            let i_ = i;

            // ආරක්ෂාව: `i` `0` වලින් ආරම්භ වන අතර එය `self.source.len()` ට වඩා අඩුය, සහ
            // පමණක් වැඩි වේ, එබැවින් `0 <= i < self.source.len()`.
            let byte = unsafe { *self.source.get_unchecked(i) };
            i += 1;

            if byte < 128 {
            } else {
                let w = utf8_char_width(byte);

                macro_rules! error {
                    () => {{
                        // ආරක්ෂාව: ප්‍රභවය වලංගු UTF-8 බව අපි `i` දක්වා පරීක්ෂා කර ඇත්තෙමු.
                        unsafe {
                            let r = Utf8LossyChunk {
                                valid: from_utf8_unchecked(&self.source[0..i_]),
                                broken: &self.source[i_..i],
                            };
                            self.source = &self.source[i..];
                            return Some(r);
                        }
                    }};
                }

                match w {
                    2 => {
                        if safe_get(self.source, i) & 192 != TAG_CONT_U8 {
                            error!();
                        }
                        i += 1;
                    }
                    3 => {
                        match (byte, safe_get(self.source, i)) {
                            (0xE0, 0xA0..=0xBF) => (),
                            (0xE1..=0xEC, 0x80..=0xBF) => (),
                            (0xED, 0x80..=0x9F) => (),
                            (0xEE..=0xEF, 0x80..=0xBF) => (),
                            _ => {
                                error!();
                            }
                        }
                        i += 1;
                        if safe_get(self.source, i) & 192 != TAG_CONT_U8 {
                            error!();
                        }
                        i += 1;
                    }
                    4 => {
                        match (byte, safe_get(self.source, i)) {
                            (0xF0, 0x90..=0xBF) => (),
                            (0xF1..=0xF3, 0x80..=0xBF) => (),
                            (0xF4, 0x80..=0x8F) => (),
                            _ => {
                                error!();
                            }
                        }
                        i += 1;
                        if safe_get(self.source, i) & 192 != TAG_CONT_U8 {
                            error!();
                        }
                        i += 1;
                        if safe_get(self.source, i) & 192 != TAG_CONT_U8 {
                            error!();
                        }
                        i += 1;
                    }
                    _ => {
                        error!();
                    }
                }
            }
        }

        let r = Utf8LossyChunk {
            // ආරක්ෂාව: සම්පූර්ණ ප්‍රභවය වලංගු UTF-8 බව අපි පරීක්ෂා කර ඇත්තෙමු.
            valid: unsafe { from_utf8_unchecked(self.source) },
            broken: &[],
        };
        self.source = &[];
        Some(r)
    }
}

impl fmt::Display for Utf8Lossy {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // අපි හිස් නූලක් නම් අපගේ අනුකාරකය ඇත්ත වශයෙන්ම කිසිවක් ලබා නොදෙනු ඇත, එබැවින් ආකෘතිකරණය අතින් සිදු කරන්න
        //
        if self.bytes.is_empty() {
            return "".fmt(f);
        }

        for Utf8LossyChunk { valid, broken } in self.chunks() {
            // අපි මුළු කැබැල්ලම වලංගු නූලක් ලෙස සාර්ථකව විකේතනය කළහොත් අපට සෘජුවම හැඩතල ගැන්වීමක් කළ හැකි අතර හැකි නම් විවිධ හැඩතල ගැන්වීමේ කොඩි වලට ගරු කරනු ඇත.
            //
            //
            if valid.len() == self.bytes.len() {
                assert!(broken.is_empty());
                return valid.fmt(f);
            }

            f.write_str(valid)?;
            if !broken.is_empty() {
                f.write_char(char::REPLACEMENT_CHARACTER)?;
            }
        }
        Ok(())
    }
}

impl fmt::Debug for Utf8Lossy {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_char('"')?;

        for Utf8LossyChunk { valid, broken } in self.chunks() {
            // වලංගු කොටස.
            // මෙන්න අපි UTF-8 නැවත අර්ධ වශයෙන් විග්‍රහ කරමු.
            {
                let mut from = 0;
                for (i, c) in valid.char_indices() {
                    let esc = c.escape_debug();
                    // වර්‍ගයෙන් ගැලවීමට අවශ්‍ය නම්, මෙතෙක් බැක්ලොග් ෆ්ලෂ් කර ලියන්න, නැතිනම් මඟ හරින්න
                    if esc.len() != 1 {
                        f.write_str(&valid[from..i])?;
                        for c in esc {
                            f.write_char(c)?;
                        }
                        from = i + c.len_utf8();
                    }
                }
                f.write_str(&valid[from..])?;
            }

            // හෙක්ස් ගැලවීම ලෙස නූල් කැඩුණු කොටස්.
            for &b in broken {
                write!(f, "\\x{:02x}", b)?;
            }
        }

        f.write_char('"')
    }
}