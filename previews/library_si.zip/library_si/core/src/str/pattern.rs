//! රටාව API.
//!
//! රටා API මඟින් නූල් හරහා සෙවීමේදී විවිධ රටා වර්ග භාවිතා කිරීම සඳහා සාමාන්‍ය යාන්ත්‍රණයක් සපයයි.
//!
//! වැඩි විස්තර සඳහා, traits [`Pattern`], [`Searcher`], [`ReverseSearcher`], සහ [`DoubleEndedSearcher`] බලන්න.
//!
//! මෙම API අස්ථායී වුවද, එය [`str`] වර්ගයේ ස්ථාවර API හරහා නිරාවරණය වේ.
//!
//! # Examples
//!
//! [`Pattern`] යනු [`&str`][`str`], [`char`], [`char`] පෙති, සහ `FnMut(char) -> bool` ක්‍රියාත්මක කරන කාර්යයන් සහ වසා දැමීම් සඳහා ස්ථාවර API හි [implemented][pattern-impls] වේ.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // වරහන් රටාව
//! assert_eq!(s.find('n'), Some(2));
//! // අක්ෂර රටා පෙත්තක්
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // වසා දැමීමේ රටාව
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// නූල් රටාවක්.
///
/// `Pattern<'a>` ප්‍රකාශ කරන්නේ ක්‍රියාත්මක කිරීමේ වර්ගය [`&'a str`][str] හි සෙවීම සඳහා නූල් රටාවක් ලෙස භාවිතා කළ හැකි බවයි.
///
/// නිදසුනක් ලෙස, `'a'` සහ `"aa"` යන දෙකම `"baaaab"` නූලෙහි `1` දර්ශකයට ගැලපෙන රටා වේ.
///
/// trait විසින්ම සම්බන්ධිත [`Searcher`] වර්ගයක් සඳහා තනන්නෙකු ලෙස ක්‍රියා කරයි, එමඟින් රටාවක සිදුවීම් සොයා ගැනීමේ සැබෑ කාර්යය ඉටු කරයි.
///
///
/// රටාවේ වර්ගය අනුව, [`str::find`] සහ [`str::contains`] වැනි ක්‍රම වල හැසිරීම වෙනස් විය හැකිය.
/// පහත දැක්වෙන වගුවේ එම හැසිරීම් කිහිපයක් විස්තර කෙරේ.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// මෙම රටාව සඳහා ආශ්‍රිත සෙවුම්කරු
    type Searcher: Searcher<'a>;

    /// සෙවීම සඳහා `self` සහ `haystack` වෙතින් සම්බන්ධිත සෙවුම්කරු සාදයි.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// රටාව පිදුරු මල්ලේ ඕනෑම තැනකට ගැලපේදැයි පරීක්ෂා කරයි
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// පිදුරු මල්ලේ ඉදිරිපස රටාව ගැලපේදැයි පරීක්ෂා කරයි
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// පිදුරු මල්ලේ පිටුපස රටාව ගැලපේදැයි පරීක්ෂා කරයි
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// ගැලපෙන්නේ නම්, පිදුරු මඩුවේ ඉදිරිපස සිට රටාව ඉවත් කරයි.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // ආරක්ෂාව: `Searcher` වලංගු දර්ශක ආපසු ලබා දෙන බව දන්නා කරුණකි.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// ගැලපෙන්නේ නම්, පිදුරු මල්ලේ පිටුපස සිට රටාව ඉවත් කරයි.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // ආරක්ෂාව: `Searcher` වලංගු දර්ශක ආපසු ලබා දෙන බව දන්නා කරුණකි.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// [`Searcher::next()`] හෝ [`ReverseSearcher::next_back()`] ඇමතීමේ ප්‍රති ult ලය.
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// `haystack[a..b]` හි රටාවේ ගැලපීමක් සොයාගෙන ඇති බව ප්‍රකාශ කරයි.
    ///
    Match(usize, usize),
    /// `haystack[a..b]` රටාවේ ගැලපීමක් ලෙස ප්‍රතික්ෂේප කර ඇති බව ප්‍රකාශ කරයි.
    ///
    /// තරඟ දෙකක් අතර එක් `Reject` ට වඩා තිබිය හැකි බව සලකන්න, ඒවා එකකට ඒකාබද්ධ කිරීමේ අවශ්‍යතාවයක් නොමැත.
    ///
    ///
    Reject(usize, usize),
    /// පිදුරු මල්ලේ සෑම බයිටයක්ම සංචාරය කර ඇති බව ප්‍රකාශ කරයි.
    ///
    Done,
}

/// නූල් රටාවක් සඳහා සෙවුම්කරුවෙක්.
///
/// මෙම trait නූලක ඉදිරිපස (left) සිට ආරම්භ වන රටාවක අතිච්ඡාදනය නොවන ගැලපීම් සෙවීමේ ක්‍රම සපයයි.
///
/// එය ක්‍රියාත්මක වන්නේ [`Pattern`] trait හි සම්බන්ධිත `Searcher` වර්ග මගිනි.
///
/// trait අනාරක්ෂිත ලෙස සලකුණු කර ඇත්තේ [`next()`][Searcher::next] ක්‍රම මඟින් ආපසු ලබා දෙන දර්ශක පිදුරු මල්ලේ වලංගු utf8 මායිම් මත තැබිය යුතු බැවිනි.
/// මෙම trait හි පාරිභෝගිකයින්ට අමතර ධාවන කාල පරීක්ෂාවකින් තොරව පිදුරු කැබැල්ල කැපීමට හැකි වේ.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// සෙවිය යුතු යටි තලය සඳහා Getter
    ///
    /// සෑම විටම එකම [`&str`][str] නැවත ලබා දෙනු ඇත.
    fn haystack(&self) -> &'a str;

    /// ඊළඟ සෙවුම් පියවර ඉදිරිපස සිට ආරම්භ කරයි.
    ///
    /// - `haystack[a..b]` රටාවට ගැලපෙන්නේ නම් [`Match(a, b)`][SearchStep::Match] ලබා දෙයි.
    /// - `haystack[a..b]` රටාවට නොගැලපේ නම් අර්ධ වශයෙන් පවා [`Reject(a, b)`][SearchStep::Reject] ලබා දෙයි.
    /// - පිදුරු මල්ලේ සෑම බයිටයක්ම සංචාරය කර ඇත්නම් [`Done`][SearchStep::Done] ලබා දෙයි.
    ///
    /// [`Done`][SearchStep::Done] දක්වා වූ [`Match`][SearchStep::Match] සහ [`Reject`][SearchStep::Reject] අගයන්හි ප්‍රවාහයට යාබද, අතිච්ඡාදනය නොවන, මුළු පිදුරු මුව ආවරණය කරන, සහ utf8 මායිම් මත තැබිය හැකි දර්ශක පරාසයන් අඩංගු වේ.
    ///
    ///
    /// [`Match`][SearchStep::Match] ප්‍රති result ලයට සම්පූර්ණ ගැලපෙන රටාව අඩංගු විය යුතුය, කෙසේ වෙතත් [`Reject`][SearchStep::Reject] ප්‍රති results ල අත්තනෝමතික ලෙස යාබද බොහෝ කොටස් වලට බෙදිය හැකිය.පරාස දෙකෙහිම ශුන්‍ය දිග තිබිය හැක.
    ///
    /// උදාහරණයක් ලෙස, `"aaa"` රටාව සහ පිදුරු `"cbaaaaab"` රටාව මඟින් ධාරාව නිපදවිය හැකිය
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// ඊළඟ [`Match`][SearchStep::Match] ප්‍රති .ලය සොයා ගනී.[`next()`][Searcher::next] බලන්න.
    ///
    /// [`next()`][Searcher::next] මෙන් නොව, මෙහි සහ [`next_reject`][Searcher::next_reject] හි ආපසු එන පරාසයන් අතිච්ඡාදනය වන බවට සහතිකයක් නොමැත.
    /// මෙය `(start_match, end_match)` නැවත ලබා දෙනු ඇත, එහිදී start_match යනු තරගය ආරම්භ වන ස්ථානයේ දර්ශකය වන අතර end_match යනු තරගය අවසන් වීමෙන් පසු දර්ශකය වේ.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// ඊළඟ [`Reject`][SearchStep::Reject] ප්‍රති .ලය සොයා ගනී.[`next()`][Searcher::next] සහ [`next_match()`][Searcher::next_match] බලන්න.
    ///
    /// [`next()`][Searcher::next] මෙන් නොව, මෙහි සහ [`next_match`][Searcher::next_match] හි ආපසු එන පරාසයන් අතිච්ඡාදනය වන බවට සහතිකයක් නොමැත.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// නූල් රටාවක් සඳහා ප්‍රතිලෝම සෙවුම් යන්ත්‍රයකි.
///
/// මෙම trait නූලක (right) පිටුපස සිට ආරම්භ වන රටාවක අතිච්ඡාදනය නොවන ගැලපීම් සෙවීමේ ක්‍රම සපයයි.
///
/// රටාව පිටුපස සිට සෙවීම සඳහා සහය දක්වන්නේ නම් එය [`Pattern`] trait හි සම්බන්ධිත [`Searcher`] වර්ග විසින් ක්‍රියාත්මක කරනු ඇත.
///
///
/// මෙම trait විසින් ආපසු ලබා දෙන දර්ශක පරාසයන් ඉදිරි සෙවුමේ ප්‍රතිලෝමව හරියටම ගැලපීමට අවශ්‍ය නොවේ.
///
/// මෙම trait අනාරක්ෂිත ලෙස සලකුණු කර ඇති හේතුව නිසා, ඔවුන් මව් trait [`Searcher`] බලන්න.
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// පිටුපස සිට ආරම්භ වන ඊළඟ සෙවුම් පියවර සිදු කරයි.
    ///
    /// - `haystack[a..b]` රටාවට ගැලපෙන්නේ නම් [`Match(a, b)`][SearchStep::Match] ලබා දෙයි.
    /// - `haystack[a..b]` රටාවට නොගැලපේ නම් අර්ධ වශයෙන් පවා [`Reject(a, b)`][SearchStep::Reject] ලබා දෙයි.
    /// - පිදුරු මල්ලේ සෑම බයිටයක්ම සංචාරය කර ඇත්නම් [`Done`][SearchStep::Done] ලබා දෙයි
    ///
    /// [`Done`][SearchStep::Done] දක්වා වූ [`Match`][SearchStep::Match] සහ [`Reject`][SearchStep::Reject] අගයන්හි ප්‍රවාහයට යාබද, අතිච්ඡාදනය නොවන, මුළු පිදුරු මුව ආවරණය කරන, සහ utf8 මායිම් මත තැබිය හැකි දර්ශක පරාසයන් අඩංගු වේ.
    ///
    ///
    /// [`Match`][SearchStep::Match] ප්‍රති result ලයට සම්පූර්ණ ගැලපෙන රටාව අඩංගු විය යුතුය, කෙසේ වෙතත් [`Reject`][SearchStep::Reject] ප්‍රති results ල අත්තනෝමතික ලෙස යාබද බොහෝ කොටස් වලට බෙදිය හැකිය.පරාස දෙකෙහිම ශුන්‍ය දිග තිබිය හැක.
    ///
    /// උදාහරණයක් ලෙස, `"aaa"` සහ පිදුරු `"cbaaaaab"` රටාව මඟින් `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// ඊළඟ [`Match`][SearchStep::Match] ප්‍රති .ලය සොයා ගනී.
    /// [`next_back()`][ReverseSearcher::next_back] බලන්න.
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// ඊළඟ [`Reject`][SearchStep::Reject] ප්‍රති .ලය සොයා ගනී.
    /// [`next_back()`][ReverseSearcher::next_back] බලන්න.
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// [`DoubleEndedIterator`] ක්‍රියාත්මක කිරීම සඳහා [`ReverseSearcher`] භාවිතා කළ හැකි බව ප්‍රකාශ කිරීමට trait සලකුණු කිරීම.
///
/// මේ සඳහා, [`Searcher`] සහ [`ReverseSearcher`] හි impl මෙම කොන්දේසි අනුගමනය කළ යුතුය:
///
/// - `next()` හි සියලුම ප්‍රති results ල ප්‍රතිලෝම අනුපිළිවෙලින් `next_back()` හි ප්‍රති results ල වලට සමාන විය යුතුය.
/// - `next()` සහ `next_back()` අගය පරාසයක කෙළවර දෙක ලෙස හැසිරීමට අවශ්‍යය, එනම් ඒවාට "walk past each other" කළ නොහැක.
///
/// # Examples
///
/// `char::Searcher` `DoubleEndedSearcher` යනු [`char`] සෙවීම සඳහා අවශ්‍ය වන්නේ වරකට එකක් දෙස බැලීම පමණි, එය දෙපැත්තෙන්ම එක හා සමානව ක්‍රියා කරයි.
///
/// `(&str)::Searcher` `DoubleEndedSearcher` නොවේ, මන්ද පිදුරු `"aaa"` හි `"aa"` රටාව `"[aa]a"` හෝ `"a[aa]"` ලෙස ගැලපෙන අතර එය සෙවූයේ කුමන පැත්තේද යන්න මතය.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// වරහන් සඳහා Impl
/////////////////////////////////////////////////////////////////////////////

/// `<char as Pattern<'a>>::Searcher` සඳහා ආශ්‍රිත වර්ගය.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // ආරක්ෂිත ආක්‍රමණ: `finger`/`finger_back` වලංගු utf8 බයිට් දර්ශකයක් විය යුතුය `haystack` මෙම ආක්‍රමණ * * ඊළඟ_මැච් සහ ඊළඟ_මැච්_බැක් තුළ * බිඳ දැමිය හැකිය, කෙසේ වෙතත් ඒවා වලංගු කේත ලක්ෂ්‍ය මායිම් මත ඇඟිලි වලින් පිටවිය යුතුය.
    //
    //
    /// `finger` ඉදිරි සෙවුමේ වත්මන් බයිට් දර්ශකය වේ.
    /// එහි දර්ශකයේ බයිට් වලට පෙර එය පවතින බව සිතන්න, එනම්
    /// `haystack[finger]` ඉදිරි සෙවීමේදී අප විසින් පරීක්ෂා කළ යුතු පෙත්තක පළමු බයිටය වේ
    ///
    finger: usize,
    /// `finger_back` යනු ප්‍රතිලෝම සෙවුමේ වත්මන් බයිට් දර්ශකයයි.
    /// එහි දර්ශකයේ බයිට් එකෙන් පසුව එය පවතින බව සිතන්න, එනම්
    /// පිදුරු මඩුව [ඇඟිල්ල_බැක්, 1] යනු ඉදිරි සෙවීමේදී අප විසින් පරීක්ෂා කළ යුතු පෙත්තෙහි අවසාන බයිටයයි (එබැවින් next_back()) ඇමතීමේදී පරීක්ෂා කළ යුතු පළමු බයිටය.
    ///
    finger_back: usize,
    /// සොයන චරිතය
    needle: char,

    // ආරක්ෂිත වෙනස් කිරීම: `utf8_size` 5 ට වඩා අඩු විය යුතුය
    /// utf8 හි කේතනය කරන විට `needle` බයිට් ගණන ගනී.
    utf8_size: usize,
    /// `needle` හි utf8 කේතනය කළ පිටපතක්
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // ආරක්ෂාව: `get_unchecked` හි 1-4 ආරක්ෂාව සහතික කරයි
        // 1. `self.finger` සහ `self.finger_back` යුනිකෝඩ් මායිම් මත තබා ඇත (මෙය වෙනස් නොවේ)
        // 2. `self.finger >= 0` එය 0 සිට ආරම්භ වන අතර වැඩි වේ
        // 3. `self.finger < self.finger_back` නැතිනම් `iter` වර්‍ගය `SearchStep::Done` නැවත ලබා දෙනු ඇත
        // 4.
        // `self.finger` පිදුරු මල්ලේ අවසානයට පෙර පැමිණෙන්නේ `self.finger_back` අවසානයේ ආරම්භ වන අතර අඩු වන බැවිනි
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // utf-8 ලෙස නැවත කේතනය නොකර වත්මන් අක්‍ෂරයේ බයිට් ඕෆ්සෙට් එක් කරන්න
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // අන්තිම චරිතය සොයාගත් පසු පිදුරු මඩුව ලබා ගන්න
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // utf8 කේතනය කරන ලද ඉඳිකටුවේ අවසාන බයිට් එක සුරක්ෂිතයි: අපට `utf8_size < 5` හි වෙනස්කමක් ඇත
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // අළුත් ඇඟිල්ල යනු අප සොයාගත් බයිට් වල දර්ශකයයි, ප්ලස් වන්, අපි චරිතයේ අවසාන බයිටය මතක තබා ගත් බැවින්.
                //
                // මෙය සැමවිටම අපට UTF8 මායිමකට ඇඟිල්ලක් නොදෙන බව සලකන්න.
                // අප අපගේ චරිතය * සොයා නොගත්තේ නම්, අපි 3-බයිට් හෝ 4-බයිට් අක්ෂරයක අවසාන නොවන බයිට් වලට සුචිගත කර ඇත.
                // Value (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` වැනි අක්ෂරයක් තෙවනුව සෙවීමේදී සෑම විටම දෙවන බයිටය සොයා ගැනීමට අපට හැකි නිසා අපට ඊළඟ වලංගු ආරම්භක බයිටයට යා නොහැක.
                //
                //
                // කෙසේ වෙතත්, මෙය සම්පූර්ණයෙන්ම හරි.
                // self.finger යනු UTF8 මායිමක ඇති බවට අප සතුව ඇති අතර, මෙම ක්‍රමය මෙම ක්‍රමය තුළ රඳා නොපවතී (එය CharSearcher::next()) මත රඳා පවතී.
                //
                // අපි මෙම ක්‍රමයෙන් ඉවත් වන්නේ අපි නූල් කෙළවරට ළඟා වූ විට හෝ අපට යමක් සොයාගතහොත් පමණි.අප යමක් සොයාගත් විට `finger` UTF8 සීමාවකට සකසනු ඇත.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // කිසිවක් සොයාගත නොහැකි විය, පිටවන්න
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // සෙවුම් trait වෙතින් පෙරනිමි ක්‍රියාත්මක කිරීම භාවිතා කිරීමට next_reject ට ඉඩ දෙන්න
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // ආරක්ෂාව: ඉහත next() සඳහා වන අදහස බලන්න
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // utf-8 ලෙස නැවත කේතනය නොකර වත්මන් අක්‍ෂරයේ බයිට් ඕෆ්සෙට් අඩු කරන්න
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // අවසන් වරට සෙවූ අක්ෂර ඇතුළත් නොව පිදුරු මඩුව ලබා ගන්න
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // utf8 කේතනය කරන ලද ඉඳිකටුවේ අවසාන බයිට් එක සුරක්ෂිතයි: අපට `utf8_size < 5` හි වෙනස්කමක් ඇත
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // අපි self.finger විසින් ඕෆ්සෙට් කරන ලද පෙත්තක් සෙව්වෙමු, මුල් දර්ශකය නැවත ලබා ගැනීමට self.finger එක් කරන්න
                //
                let index = self.finger + index;
                // memrchr අප සොයා ගැනීමට කැමති බයිට් වල දර්ශකය නැවත ලබා දෙනු ඇත.
                // ASCII අක්ෂරයක නම්, ඇත්ත වශයෙන්ම මෙය අපගේ නව ඇඟිල්ල විය යුතු යැයි අපි ප්‍රාර්ථනා කළෙමු (ප්‍රතිලෝම පුනරාවර්තනයේ ආදර්ශයේ "after" සොයාගත් වරහන).
                //
                // බහු බයිට් අක්ෂර සඳහා අප සතුව ASCII ට වඩා වැඩි බයිට් ගණනක් තිබිය යුතුය
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // අක්ෂර සොයා ගැනීමට පෙර ඇඟිල්ල ගෙනයන්න (එනම්, එහි ආරම්භක දර්ශකයේ)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // අපට මෙහි ඇඟිලි_බැක්=දර්ශකය, ප්‍රමාණය + 1 භාවිතා කළ නොහැක.
                // වෙනස් ප්‍රමාණයේ අක්ෂරයක (හෝ වෙනත් අක්ෂරයක මැද බයිට්) අවසාන වර්‍ගය අපට හමු වූවා නම්, අපට ඇඟිල්ල_බොක්ස් `index` දක්වා පහළට තල්ලු කළ යුතුය.
                // මේ හා සමානව `finger_back` හට තවදුරටත් මායිමක සිටීමට හැකියාවක් නැත, නමුත් මෙය හරි, අප මෙම ශ්‍රිතයෙන් පිටවන්නේ සීමාවකින් හෝ පිදුරු මල්ල මුළුමනින්ම සෙවූ විට පමණි.
                //
                //
                // Next_match මෙන් නොව utf-8 හි නැවත නැවත බයිට් පිළිබඳ ගැටළුවක් නොමැත, මන්ද අප අන්තිම බයිටය සොයන නිසා, අපට සොයා ගත හැකි වූයේ ආපසු හැරවීමේදී සෙවීමේදී පමණි.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // කිසිවක් සොයාගත නොහැකි විය, පිටවන්න
                return None;
            }
        }
    }

    // සෙවුම් trait වෙතින් පෙරනිමි ක්‍රියාත්මක කිරීම භාවිතා කිරීමට next_reject_back ට ඉඩ දෙන්න
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// දී ඇති [`char`] ට සමාන අක්ෂර සඳහා සෙවීම්.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// MultiCharEq එතීම සඳහා Impl
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // වත්මන් වර්‍ගයේ දිග සොයා ගැනීම සඳහා අභ්‍යන්තර බයිට් පෙති අනුකාරකයේ දිග සසඳා බලන්න
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // වත්මන් වර්‍ගයේ දිග සොයා ගැනීම සඳහා අභ්‍යන්තර බයිට් පෙති අනුකාරකයේ දිග සසඳා බලන්න
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// සඳහා [[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: අර්ථයේ නොපැහැදිලි නිසා වෙනස් කිරීම/ඉවත් කිරීම.

/// `<&[char] as Pattern<'a>>::Searcher` සඳහා ආශ්‍රිත වර්ගය.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// පෙත්තෙහි ඇති ඕනෑම [වර්‍ගයකට] සමාන අක්ෂර සඳහා සෙවීම්.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// F: FnMut(char)-> bool සඳහා Impl
/////////////////////////////////////////////////////////////////////////////

/// `<F as Pattern<'a>>::Searcher` සඳහා ආශ්‍රිත වර්ගය.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// ලබා දී ඇති පුරෝකථනයට ගැලපෙන [char] සඳහා සෙවීම්.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// &&str සඳහා ආයාචනය කරන්න
/////////////////////////////////////////////////////////////////////////////

/// `&str` impl වෙත නියෝජිතයින්.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// &str සඳහා Impl
/////////////////////////////////////////////////////////////////////////////

/// වෙන් නොකරන උපස්ථර සෙවීම.
///
/// එක් එක් අක්ෂර මායිමේ හිස් තරග නැවත ලබා දීමෙන් `""` රටාව හසුරුවනු ඇත.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// පිදුරු මල්ලේ ඉදිරිපස රටාව ගැලපේදැයි පරීක්ෂා කරයි.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// ගැලපෙන්නේ නම්, පිදුරු මඩුවේ ඉදිරිපස සිට රටාව ඉවත් කරයි.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // ආරක්ෂාව: උපසර්ගය පවතින බව තහවුරු කර ඇත.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// පිදුරු මල්ලේ පිටුපස රටාව ගැලපේදැයි පරීක්ෂා කරයි.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// ගැලපෙන්නේ නම්, පිදුරු මල්ලේ පිටුපස සිට රටාව ඉවත් කරයි.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // ආරක්ෂාව: උපසර්ගය පවතින බව තහවුරු කර ඇත.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// ද්වි මාර්ග උපස්ථර සෙවුම්කරු
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// `<&str as Pattern<'a>>::Searcher` සඳහා ආශ්‍රිත වර්ගය.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // හිස් ඉඳිකටුවක් සෑම වර්‍ගයක්ම ප්‍රතික්ෂේප කරන අතර ඒවා අතර ඇති සෑම හිස් නූලකටම ගැලපේ
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher විසින් වලංගු *ගැලපීම්* දර්ශක නිපදවන අතර එය නිවැරදි ගැලපීම් පවතින තාක් කල් සහ පිදුරු සහ ඉඳිකටුවක් වලංගු වේ UTF-8 *ඇල්ගොරිතමයෙන් ප්‍රතික්ෂේප කිරීම* ඕනෑම දර්ශකයකට වැටිය හැකි නමුත් අපි ඒවා අතින් ඊළඟ අක්ෂර සීමාවට ගෙන යන්නෙමු. , එවිට ඒවා utf-8 ආරක්ෂිත වේ.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // ඊළඟ වර්‍ග සීමාවට යන්න
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // මෙම අවස්ථා දෙක වෙන වෙනම විශේෂීකරණය කිරීමට සම්පාදකයා දිරිමත් කිරීම සඳහා `true` සහ `false` නඩු ලියන්න.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // ඊළඟ වර්‍ග සීමාවට යන්න
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // `next_match` වැනි `true` සහ `false` ලියන්න
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// ද්වි-මාර්ග උපස්ථර සෙවුම් ඇල්ගොරිතමයේ අභ්‍යන්තර තත්වය.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// විවේචනාත්මක සාධකකරණ දර්ශකය
    crit_pos: usize,
    /// ආපසු හැරවූ ඉඳිකටුවක් සඳහා තීරණාත්මක සාධකකරණ දර්ශකය
    crit_pos_back: usize,
    period: usize,
    /// `byteset` දිගුවක් (ද්වි මාර්ග ඇල්ගොරිතමයේ කොටසක් නොවේ);
    /// එය 64-බිට් "fingerprint" වන අතර සෑම කට්ටලයක්ම `j` ඉඳිකටුවේ ඇති (බයිට් සහ 63)==j ට අනුරූප වේ.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// අපි දැනටමත් ගැලපෙන ඉඳිකටුවට දර්ශකය
    memory: usize,
    /// අපි දැනටමත් ගැලපෙන ඉඳිකටුවට දර්ශකය
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // මෙහි සිදුවන්නේ කුමක්ද යන්න පිළිබඳව විශේෂයෙන් කියවිය හැකි පැහැදිලි කිරීමක් ක්‍රොචෙමෝර් සහ රයිටර්ගේ "Text Algorithms", ch 13 පොතේ සොයාගත හැකිය.
        // X හි "Algorithm CP" සඳහා කේතය විශේෂයෙන් බලන්න.
        // 323.
        //
        // සිදුවෙමින් පවතින්නේ අපට ඉඳිකටුවේ තීරණාත්මක සාධක සාධක (u, v) ඇති අතර, ඔබ&v [.. කාල පරිච්ඡේදයේ] උපසර්ගයක්ද යන්න තීරණය කිරීමට අපට අවශ්‍යය.
        // එය එසේ නම්, අපි "Algorithm CP1" භාවිතා කරමු.
        // එසේ නොමැතිනම් අපි "Algorithm CP2" භාවිතා කරමු, එය ඉඳිකටුවේ කාල සීමාව විශාල වන විට ප්‍රශස්ත වේ.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // කෙටි කාල නඩුව-කාල සීමාව හරියටම ගණනය කරනුයේ ආපසු හරවන ලද ඉඳිකටුවක් සඳහා වෙනම තීරණාත්මක සාධක සාධකයක් x=u 'v' එහිදී | v '|<period(x).
            //
            // මෙය දැනටමත් දන්නා කාල පරිච්ඡේදය අනුව වේගවත් වේ.
            // X= "acba" වැනි නඩුවක් හරියටම ඉදිරියට ඉදිරියට යා හැකි බව සලකන්න (විවේචන_පෝස්=1, කාල=3) දළ වශයෙන් ආපසු හැරවීමේ කාලපරිච්ඡේදය සමඟ සාධකය සාදනු ලැබේ (විවේචන_පෝස්=2, කාල=2).
            // අපි දී ඇති ප්‍රතිලෝම සාධකකරණය භාවිතා කරන නමුත් නිශ්චිත කාල සීමාව තබා ගනිමු.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // දිගු කාල නඩුව-අපට සත්‍ය කාල පරිච්ඡේදයට ආසන්න අගයක් ඇති අතර කටපාඩම් කිරීම භාවිතා නොකරන්න.
            //
            //
            // පහළ මායිම් max(|u|, |v|) + 1 අනුව කාල සීමාව ආසන්න කරන්න.
            // ඉදිරි හා ප්‍රතිලෝම සෙවීම් සඳහා භාවිතා කිරීමට තීරණාත්මක සාධකකරණය කාර්යක්ෂම වේ.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // කාල සීමාව දිගු බව දැක්වීමට ව්‍යාජ අගය
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // ද්වි-මාර්ගයේ එක් ප්‍රධාන අදහසක් නම්, අපි ඉඳිකටුවක් කොටස් දෙකකට (u, v) සාධක කර, වමේ සිට දකුණට පරිලෝකනය කිරීමෙන් පිදුරු මල්ලේ v සොයා ගැනීමට උත්සාහ කිරීමයි.
    // V ගැලපෙන්නේ නම්, අපි දකුණට වමට පරිලෝකනය කිරීමෙන් ඔබට ගැලපීමට උත්සාහ කරමු.
    // නොගැලපීමක් හමු වූ විට අපට කොපමණ දුරක් පැනිය හැකිද යන්න පදනම් වී ඇත්තේ (u, v) ඉඳිකටුවක් සඳහා තීරණාත්මක සාධකයකි.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` `self.position` එහි කර්සරය ලෙස භාවිතා කරයි
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // පෙති අයිසයිස් පරාසයෙන් මායිම් වී ඇතැයි උපකල්පනය කළහොත් අපට ස්ථානයෙහි සෙවීමට ඉඩක් තිබේදැයි පරීක්ෂා කරන්න + ඉඳිකටු_ලස්ට් පිටාර ගැලිය නොහැක.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // අපගේ උපස්ථරයට සම්බන්ධ නැති විශාල කොටස් ඉක්මනින් මඟ හරින්න
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // ඉඳිකටුවේ දකුණු කොටස ගැලපේදැයි බලන්න
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // ඉඳිකටුවේ වම් කොටස ගැලපේදැයි බලන්න
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // අපි තරඟයක් සොයාගෙන ඇත!
            let match_pos = self.position;

            // Note: අතිච්ඡාදනය වන ගැලපීම් සඳහා needle.len() වෙනුවට self.period එක් කරන්න
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // අතිච්ඡාදනය වන තරඟ සඳහා needle.len(), self.period ලෙස සකසා ඇත
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // `next()` හි අදහස් අනුගමනය කරයි.
    //
    // period(x) = period(reverse(x)) සහ local_period(u, v) = local_period(reverse(v), reverse(u)) සමඟ අර්ථ දැක්වීම් සමමිතික වේ, එබැවින් (u, v) තීරණාත්මක සාධකකරණයක් නම්, (reverse(v), reverse(u)).
    //
    //
    // ප්‍රතිලෝම නඩුව සඳහා අපි x=u 'v' (ක්ෂේත්‍ර `crit_pos_back`) විවේචනාත්මක සාධකකරණයක් ගණනය කර ඇත්තෙමු.අපට අවශ්‍යයි | u |ඉදිරි නඩුව සඳහා <period(x) සහ ඒ අනුව | v '|ආපසු හැරවීම සඳහා <period(x).
    //
    // පිදුරු මල්ල හරහා ප්‍රතිලෝමව සෙවීම සඳහා, අපි ආපසු හරවන ලද ඉඳිකටුවක් සහිත ප්‍රතිලෝම පිදුරු මල්ලක් හරහා ඉදිරියට යමු, පළමුව u හා පසුව v 'ගැලපේ.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` `self.end` එහි කර්සරය ලෙස භාවිතා කරයි-එවිට `next()` සහ `next_back()` ස්වාධීන වේ.
        //
        let old_end = self.end;
        'search: loop {
            // අපට අවසානයේ සෙවීමට ඉඩක් ඇත්දැයි පරීක්ෂා කරන්න, වැඩි ඉඩක් නොමැති විට needle.len() එතෙර වනු ඇත, නමුත් පෙති දිග සීමාවන් නිසා එය කිසි විටෙකත් පිදුරු මල්ලේ දිගට ඔතා තැබිය නොහැක.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // අපගේ උපස්ථරයට සම්බන්ධ නැති විශාල කොටස් ඉක්මනින් මඟ හරින්න
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // ඉඳිකටුවේ වම් කොටස ගැලපේදැයි බලන්න
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // ඉඳිකටුවේ දකුණු කොටස ගැලපේදැයි බලන්න
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // අපි තරඟයක් සොයාගෙන ඇත!
            let match_pos = self.end - needle.len();
            // Note: අතිච්ඡාදනය වන ගැලපීම් සඳහා needle.len() වෙනුවට උප self.period
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // `arr` හි උපරිම උපසර්ගය ගණනය කරන්න.
    //
    // උපරිම උපසර්ගය යනු `arr` හි විය හැකි විවේචනාත්මක සාධකකරණයකි (u, v).
    //
    // ප්‍රතිලාභ (`i`, `p`), එහිදී `i` යනු v හි ආරම්භක දර්ශකය වන අතර `p` යනු v කාල පරිච්ඡේදයයි.
    //
    // `order_greater` ශබ්දකෝෂ අනුපිළිවෙල `<` හෝ `>` ද යන්න තීරණය කරයි.
    // ඇණවුම් දෙකම ගණනය කළ යුතුය-විශාලතම `i` සමඟ ඇණවුම් කිරීම තීරණාත්මක සාධකකරණයක් ලබා දෙයි.
    //
    //
    // දිගු කාලීන අවස්ථා සඳහා, එහි ප්‍රති period ලයක් වශයෙන් ඇති කාල සීමාව හරියටම නොවේ (එය ඉතා කෙටි ය).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // පුවත්පතේ i ට අනුරූප වේ
        let mut right = 1; // කඩදාසි වල j ට අනුරූප වේ
        let mut offset = 0; // කඩදාසි වල k ට අනුරූප වේ, නමුත් 0 සිට ආරම්භ වේ
        // 0 මත පදනම් වූ සුචිගත කිරීම ගැලපීමට.
        let mut period = 1; // පුවත්පතේ p ට අනුරූප වේ

        while let Some(&a) = arr.get(right + offset) {
            // `left` `right` විට අභ්‍යන්තරයට පැමිණේ.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // උපසර්ගය කුඩා වන අතර කාල සීමාව මේ දක්වා සම්පූර්ණ උපසර්ගය වේ.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // වත්මන් කාල පරිච්ඡේදය පුනරාවර්තනය කිරීම තුළින් අත්තිකාරම්.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // උපසර්ගය විශාලයි, වත්මන් ස්ථානයෙන් ආරම්භ කරන්න.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // `arr` හි ප්‍රතිලෝමයේ උපරිම උපසර්ගය ගණනය කරන්න.
    //
    // උපරිම උපසර්ගය යනු `arr` හි විය හැකි විවේචනාත්මක සාධකකරණයකි (u ', v').
    //
    // `i` ආපසු එන්නේ `i` යනු පිටුපස සිට v 'හි ආරම්භක දර්ශකයයි;
    // `known_period` කාල පරිච්ඡේදයක් ළඟා වූ වහාම ආපසු පැමිණේ.
    //
    // `order_greater` ශබ්දකෝෂ අනුපිළිවෙල `<` හෝ `>` ද යන්න තීරණය කරයි.
    // ඇණවුම් දෙකම ගණනය කළ යුතුය-විශාලතම `i` සමඟ ඇණවුම් කිරීම තීරණාත්මක සාධකකරණයක් ලබා දෙයි.
    //
    //
    // දිගු කාලීන අවස්ථා සඳහා, එහි ප්‍රති period ලයක් වශයෙන් ඇති කාල සීමාව හරියටම නොවේ (එය ඉතා කෙටි ය).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // පුවත්පතේ i ට අනුරූප වේ
        let mut right = 1; // කඩදාසි වල j ට අනුරූප වේ
        let mut offset = 0; // කඩදාසි වල k ට අනුරූප වේ, නමුත් 0 සිට ආරම්භ වේ
        // 0 මත පදනම් වූ සුචිගත කිරීම ගැලපීමට.
        let mut period = 1; // පුවත්පතේ p ට අනුරූප වේ
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // උපසර්ගය කුඩා වන අතර කාල සීමාව මේ දක්වා සම්පූර්ණ උපසර්ගය වේ.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // වත්මන් කාල පරිච්ඡේදය පුනරාවර්තනය කිරීම තුළින් අත්තිකාරම්.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // උපසර්ගය විශාලයි, වත්මන් ස්ථානයෙන් ආරම්භ කරන්න.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy මඟින් ඇල්ගොරිතමයට හැකි ඉක්මනින් ගැලපීම් නොවන දේ මඟ හැරීමට හෝ සාපේක්ෂව ඉක්මණින් ප්‍රතික්ෂේප කිරීම් විමෝචනය වන ආකාරයකින් වැඩ කිරීමට ඉඩ දෙයි.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// හැකි ඉක්මනින් පරතරයන් ගැලපීමට මඟ හරින්න
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// විමෝචන නිතිපතා
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}