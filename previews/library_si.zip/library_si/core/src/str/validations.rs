//! UTF-8 වලංගුකරණයට අදාළ මෙහෙයුම්.

use crate::mem;

use super::Utf8Error;

/// පළමු බයිටය සඳහා ආරම්භක කේත ලක්ෂ්‍ය සමුච්චය ලබා දෙයි.
/// පළමු බයිටය විශේෂයි, පළල 2 සඳහා පහළ බිටු 5 ක්, පළල 3 සඳහා බිටු 4 ක් සහ පළල 4 සඳහා බිටු 3 ක් පමණි.
///
#[inline]
fn utf8_first_byte(byte: u8, width: u32) -> u32 {
    (byte & (0x7F >> width)) as u32
}

/// අඛණ්ඩ බයිට් `byte` සමඟ යාවත්කාලීන කරන ලද `ch` හි අගය ලබා දෙයි.
#[inline]
fn utf8_acc_cont_byte(ch: u32, byte: u8) -> u32 {
    (ch << 6) | (byte & CONT_MASK) as u32
}

/// බයිට් එක UTF-8 අඛණ්ඩ බයිට් එකක් දැයි පරීක්ෂා කරයි (එනම්, බිටු `10` සමඟ ආරම්භ වේ).
///
#[inline]
pub(super) fn utf8_is_cont_byte(byte: u8) -> bool {
    (byte & !CONT_MASK) == TAG_CONT_U8
}

#[inline]
fn unwrap_or_0(opt: Option<&u8>) -> u8 {
    match opt {
        Some(&byte) => byte,
        None => 0,
    }
}

/// බයිට් ඉරේටරයකින් ඊළඟ කේත ලක්ෂ්‍යය කියවයි (යූටීඑෆ්-8 වැනි කේතන ක්‍රමයක් උපකල්පනය කරයි).
///
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn next_code_point<'a, I: Iterator<Item = &'a u8>>(bytes: &mut I) -> Option<u32> {
    // විකේතනය UTF-8
    let x = *bytes.next()?;
    if x < 128 {
        return Some(x as u32);
    }

    // බහු බයිට් නඩුව පහත දැක්වෙන්නේ බයිට් සංයෝජනයෙන් විකේතනය: [[[x y] z] w]
    //
    // NOTE: කාර්ය සාධනය මෙහි නිශ්චිත සූත්‍රයට සංවේදී වේ
    let init = utf8_first_byte(x, 2);
    let y = unwrap_or_0(bytes.next());
    let mut ch = utf8_acc_cont_byte(init, y);
    if x >= 0xE0 {
        // [[x y z] නඩුව
        // 0xE0 හි 5 වන බිට් .. 0xEF සෑම විටම පැහැදිලි ය, එබැවින් `init` තවමත් වලංගු වේ
        let z = unwrap_or_0(bytes.next());
        let y_z = utf8_acc_cont_byte((y & CONT_MASK) as u32, z);
        ch = init << 12 | y_z;
        if x >= 0xF0 {
            // [x y z w] නඩුව භාවිතා කරන්නේ `init` හි පහළ බිටු 3 ක් පමණි
            //
            let w = unwrap_or_0(bytes.next());
            ch = (init & 7) << 18 | utf8_acc_cont_byte(y_z, w);
        }
    }

    Some(ch)
}

/// බයිට් ඉරේටරයක අවසාන කේත ලක්ෂ්‍යය කියවයි (යූටීඑෆ්-8 වැනි කේතන ක්‍රමයක් උපකල්පනය කරයි).
///
#[inline]
pub(super) fn next_code_point_reverse<'a, I>(bytes: &mut I) -> Option<u32>
where
    I: DoubleEndedIterator<Item = &'a u8>,
{
    // විකේතනය UTF-8
    let w = match *bytes.next_back()? {
        next_byte if next_byte < 128 => return Some(next_byte as u32),
        back_byte => back_byte,
    };

    // මල්ටිබයිට් නඩුව පහත දැක්වෙන්නේ බයිට් සංයෝජනයෙන් විකේතනය: [x [y [z w]]]
    //
    let mut ch;
    let z = unwrap_or_0(bytes.next_back());
    ch = utf8_first_byte(z, 2);
    if utf8_is_cont_byte(z) {
        let y = unwrap_or_0(bytes.next_back());
        ch = utf8_first_byte(y, 3);
        if utf8_is_cont_byte(y) {
            let x = unwrap_or_0(bytes.next_back());
            ch = utf8_first_byte(x, 4);
            ch = utf8_acc_cont_byte(ch, y);
        }
        ch = utf8_acc_cont_byte(ch, z);
    }
    ch = utf8_acc_cont_byte(ch, w);

    Some(ch)
}

// u64 භාවිතයට ගැලපෙන පරිදි කප්පාදු කිරීම භාවිතා කරන්න
const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;

/// `x` යන වචනයේ කිසියම් බයිට් එකක් nonascii (>=128) නම් `true` ලබා දෙයි.
#[inline]
fn contains_nonascii(x: usize) -> bool {
    (x & NONASCII_MASK) != 0
}

/// `v` හරහා ගමන් කරන්නේ එය වලංගු UTF-8 අනුක්‍රමයක්ද, එම අවස්ථාවේදී `Ok(())` ආපසු ලබා දීමද, හෝ එය අවලංගු නම්, `Err(err)`.
///
#[inline(always)]
pub(super) fn run_utf8_validation(v: &[u8]) -> Result<(), Utf8Error> {
    let mut index = 0;
    let len = v.len();

    let usize_bytes = mem::size_of::<usize>();
    let ascii_block_size = 2 * usize_bytes;
    let blocks_end = if len >= ascii_block_size { len - ascii_block_size + 1 } else { 0 };
    let align = v.as_ptr().align_offset(usize_bytes);

    while index < len {
        let old_offset = index;
        macro_rules! err {
            ($error_len: expr) => {
                return Err(Utf8Error { valid_up_to: old_offset, error_len: $error_len })
            };
        }

        macro_rules! next {
            () => {{
                index += 1;
                // අපට දත්ත අවශ්‍ය විය, නමුත් කිසිවක් නොතිබුණි: දෝෂයකි!
                if index >= len {
                    err!(None)
                }
                v[index]
            }};
        }

        let first = v[index];
        if first >= 128 {
            let w = UTF8_CHAR_WIDTH[first as usize];
            // ද්වි-බයිට් කේතීකරණය කේත ලක්ෂ්‍ය සඳහා\u {0080} සිට\u {07ff} පළමු C2 80 අන්තිම DF BF
            // 3-බයිට් කේතීකරණය කේත ලක්ෂ්‍ය සඳහා වේ\u {0800} සිට\u {ffff} පළමු E0 A0 80 අන්තිම EF BF BF අන්‍යාගමික කේත ලක්ෂ්‍ය හැර\u {d800} සිට\u {dfff} ED A0 80 සිට ED BF BF
            // 4-බයිට් කේතීකරණය කේත ලක්ෂ්‍ය සඳහා\u {1000} 0 සිට\u {10ff} ff පළමු F0 90 80 80 අවසන් F4 8F BF BF
            //
            // RFC වෙතින් UTF-8 සින්ටැක්ස් භාවිතා කරන්න
            //
            // https://tools.ietf.org/html/rfc3629
            // UTF8-1=% x00-7F UTF8-2=% xC2-DF UTF8-වලිගය UTF8-3= %xE0% xA0-BF UTF8-වලිගය/% xE1-EC 2( UTF8-tail )/%xED% x80-9F UTF8-වලිගය/% xEE-EF 2( UTF8-tail ) UTF8-4= %xF0% x90-BF 2( UTF8-tail )/% xF1-F3 3( UTF8-tail )/%xF4% x80-8F 2( UTF8-tail )
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            match w {
                2 => {
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(1))
                    }
                }
                3 => {
                    match (first, next!()) {
                        (0xE0, 0xA0..=0xBF)
                        | (0xE1..=0xEC, 0x80..=0xBF)
                        | (0xED, 0x80..=0x9F)
                        | (0xEE..=0xEF, 0x80..=0xBF) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                }
                4 => {
                    match (first, next!()) {
                        (0xF0, 0x90..=0xBF) | (0xF1..=0xF3, 0x80..=0xBF) | (0xF4, 0x80..=0x8F) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(3))
                    }
                }
                _ => err!(Some(1)),
            }
            index += 1;
        } else {
            // Ascii නඩුව, ඉක්මනින් ඉදිරියට යාමට උත්සාහ කරන්න.
            // දර්ශකය පෙළගස්වා ඇති විට, අසයි නොවන බයිට් එකක් අඩංගු වචනයක් සොයා ගන්නා තෙක් එක් පුනරාවර්තනයකට දත්ත වචන 2 ක් කියවන්න.
            //
            if align != usize::MAX && align.wrapping_sub(index) % usize_bytes == 0 {
                let ptr = v.as_ptr();
                while index < blocks_end {
                    // ආරක්ෂාව: `align - index` සහ `ascii_block_size` බැවින්
                    // `usize_bytes`, `block = ptr.add(index)` හි ගුණකය සැමවිටම `usize` සමඟ පෙලගැසී ඇති බැවින් `block` සහ `block.offset(1)` යන දෙවර්ගයම විරූපණය කිරීම ආරක්ෂිත වේ.
                    //
                    //
                    unsafe {
                        let block = ptr.add(index) as *const usize;
                        // nonascii බයිට් එකක් තිබේ නම් බිඳ දමන්න
                        let zu = contains_nonascii(*block);
                        let zv = contains_nonascii(*block.offset(1));
                        if zu | zv {
                            break;
                        }
                    }
                    index += ascii_block_size;
                }
                // වචනමය ලූපය නතර වූ ස්ථානයේ සිට පියවර තබන්න
                while index < len && v[index] < 128 {
                    index += 1;
                }
            } else {
                index += 1;
            }
        }
    }

    Ok(())
}

// https://tools.ietf.org/html/rfc3629
static UTF8_CHAR_WIDTH: [u8; 256] = [
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x1F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x3F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x5F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x7F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0x9F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0xBF
    0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, // 0xDF
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, // 0xEF
    4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0xFF
];

/// පළමු බයිටයක් ලබා දී, මෙම UTF-8 අක්ෂරයේ බයිට් කීයක් තිබේද යන්න තීරණය කරයි.
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn utf8_char_width(b: u8) -> usize {
    UTF8_CHAR_WIDTH[b as usize] as usize
}

/// අඛණ්ඩ බයිටයක අගය බිටු වල ආවරණ.
const CONT_MASK: u8 = 0b0011_1111;
/// අඛණ්ඩ බයිටයක ටැග් බිටු වල අගය (ටැග් මාස්ක් !CONT_MASK වේ).
const TAG_CONT_U8: u8 = 0b1000_0000;

// `&str` දිගට `max` ට සමාන වන අතර එය කපා දැමුවේ නම් `true` ආපසු එවන්න, සහ නව str.
//
pub(super) fn truncate_to_char_boundary(s: &str, mut max: usize) -> (bool, &str) {
    if max >= s.len() {
        (false, s)
    } else {
        while !s.is_char_boundary(max) {
            max -= 1;
        }
        (true, &s[..max])
    }
}