#![feature(no_core)]
#![no_core]

// මෙම crate අවශ්‍ය වන්නේ මන්ද යන්න සඳහා rustc-std-workspace-core බලන්න.

// Liballoc හි වෙන් කළ මොඩියුලය සමඟ ගැටීම වළක්වා ගැනීම සඳහා crate ලෙස නම් කරන්න.
extern crate alloc as foo;

pub use foo::*;