# `rustc-std-workspace-core` crate

මෙම crate යනු දිලිසෙන සහ හිස් crate වන අතර එය හුදෙක් `libcore` මත රඳා පවතින අතර එහි සියලුම අන්තර්ගතයන් නැවත අපනයනය කරයි.
crate යනු crates.io සිට crates මත යැපීමට සම්මත පුස්තකාලය සවිබල ගැන්වීමේ හරයයි

crates.io හි Crates, සම්මත පුස්තකාලය රඳා පවතින්නේ crates.io වෙතින් `rustc-std-workspace-core` crate මත යැපීමේ අවශ්‍යතාවය මත වන අතර එය හිස් ය.

මෙම ගබඩාවේ මෙම crate වෙත එය අභිබවා යාමට අපි `[patch]` භාවිතා කරමු.
මෙහි ප්‍රති As ලයක් වශයෙන්, crates.io හි crates මෙම ගබඩාවේ අර්ථ දක්වා ඇති අනුවාදය වන edge සිට `libcore` දක්වා පරායත්තතාවයක් ලබා ගනී.
Cargo විසින් crates සාර්ථකව ගොඩනංවන බව සහතික කිරීම සඳහා සියලු පරායත්තතා දාර ඇද ගත යුතුය!

සෑම දෙයක්ම නිවැරදිව ක්‍රියා කිරීම සඳහා crates.io හි crates මෙම crate මත `core` යන නම මත රඳා පැවතිය යුතු බව සලකන්න.ඔවුන්ට භාවිතා කළ හැකි දේ කිරීමට:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

`package` යතුර භාවිතා කිරීමෙන් crate `core` ලෙස නම් කර ඇත, එයින් අදහස් වන්නේ එය පෙනෙනු ඇති බවයි

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

Cargo විසින් සම්පාදකයාට ආයාචනා කරන විට, සම්පාදකයා විසින් එන්නත් කරන ලද ව්‍යාජ `extern crate core` නියෝගය තෘප්තිමත් කරයි.




