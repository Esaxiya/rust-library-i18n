# `rustc-std-workspace-std` crate

`rustc-std-workspace-core` crate සඳහා ප්‍රලේඛනය බලන්න.