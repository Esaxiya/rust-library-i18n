//! `compiler-rt` පුස්තකාලයේ පැතිකඩ කොටස සම්පාදනය කරයි.
//!
//! වැඩි විස්තර සඳහා libcompiler_builtins crate සඳහා build.rs බලන්න.

use std::env;
use std::path::Path;

fn main() {
    let target = env::var("TARGET").expect("TARGET was not set");
    let cfg = &mut cc::Build::new();

    // FIXME: `rerun-if-changed` විධානයන් දැනට විමෝචනය වී නොමැති අතර ගොඩනැගීමේ පිටපත
    // මෙම ප්‍රභව ලිපිගොනු වල වෙනස්කම් හෝ ඒවාට ඇතුළත් කර ඇති ශීර්ෂයන් නැවත ක්‍රියාත්මක නොවේ.
    let mut profile_sources = vec![
        "GCDAProfiling.c",
        "InstrProfiling.c",
        "InstrProfilingBuffer.c",
        "InstrProfilingFile.c",
        "InstrProfilingMerge.c",
        "InstrProfilingMergeFile.c",
        "InstrProfilingNameVar.c",
        "InstrProfilingPlatformDarwin.c",
        "InstrProfilingPlatformFuchsia.c",
        "InstrProfilingPlatformLinux.c",
        "InstrProfilingPlatformOther.c",
        "InstrProfilingPlatformWindows.c",
        "InstrProfilingUtil.c",
        "InstrProfilingValue.c",
        "InstrProfilingVersionVar.c",
        "InstrProfilingWriter.c",
        // මෙම ගොනුව LLVM 10 හි නම් කරන ලදී.
        "InstrProfilingRuntime.cc",
        "InstrProfilingRuntime.cpp",
        // මෙම ලිපිගොනු LLVM 11 හි එකතු කරන ලදී.
        "InstrProfilingInternal.c",
        "InstrProfilingBiasVar.c",
    ];

    if target.contains("msvc") {
        // MSVC හි අමතර පුස්තකාල ඇද නොගන්න
        cfg.flag("/Zl");
        profile_sources.push("WindowsMMap.c");
        cfg.define("strdup", Some("_strdup"));
        cfg.define("open", Some("_open"));
        cfg.define("fdopen", Some("_fdopen"));
        cfg.define("getpid", Some("_getpid"));
        cfg.define("fileno", Some("_fileno"));
    } else {
        // gcc හි විවිධ අංග අක්‍රිය කරන්න සහ බොහෝ විට දැනටමත් සම්පාදක-rt හි ගොඩනැගීමේ පද්ධතිය පිටපත් කිරීම
        //
        cfg.flag("-fno-builtin");
        cfg.flag("-fomit-frame-pointer");
        cfg.define("VISIBILITY_HIDDEN", None);
        if !target.contains("windows") {
            cfg.flag("-fvisibility=hidden");
            cfg.define("COMPILER_RT_HAS_UNAME", Some("1"));
        } else {
            profile_sources.push("WindowsMMap.c");
        }
    }

    // අප විසින් මෙය ගොඩනඟන යුනික්ස් fnctl() ලබා ගත හැකි යැයි උපකල්පනය කරන්න
    if env::var_os("CARGO_CFG_UNIX").is_some() {
        cfg.define("COMPILER_RT_HAS_FCNTL_LCK", Some("1"));
    }

    // COMPILER_RT_HAS_ATOMICS සැකසීමට කවදාද යන්න සඳහා මෙය හොඳ ur ෂධයක් විය යුතුය
    //
    if env::var_os("CARGO_CFG_TARGET_HAS_ATOMIC")
        .map(|features| features.to_string_lossy().to_lowercase().contains("ptr"))
        .unwrap_or(false)
    {
        cfg.define("COMPILER_RT_HAS_ATOMICS", Some("1"));
    }

    // අප ධාවනය කිරීමට යන්නේ නම් මෙය පැවතිය යුතු බව සලකන්න (එසේ නොමැතිනම් අපි ප්‍රොෆයිලර් බිල්ඩින් කිසිසේත් ගොඩනඟන්නේ නැත).
    //
    let root = Path::new("../../src/llvm-project/compiler-rt");

    let src_root = root.join("lib").join("profile");
    for src in profile_sources {
        let path = src_root.join(src);
        if path.exists() {
            cfg.file(path);
        }
    }

    cfg.include(root.join("include"));
    cfg.warnings(false);
    cfg.compile("profiler-rt");
}