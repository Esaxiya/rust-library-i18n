//! `#[assert_instr]` සාර්ව ක්‍රියාත්මක කිරීම
//!
//! `stdarch` crate පරික්ෂා කිරීමේදී මෙම සාර්ව භාවිතා වන අතර, එම ක්‍රියාකාරකම්වල ඇත්ත වශයෙන්ම අප ඒවා අඩංගු යැයි අපේක්ෂා කරන උපදෙස් අඩංගු බව තහවුරු කර ගැනීම සඳහා පරීක්ෂණ අවස්ථා උත්පාදනය කිරීමට භාවිතා කරයි.
//!
//! මෙහි ක්‍රියාපටිපාටියේ සාර්ව සාපේක්ෂව සරල ය, එය හුදෙක් `#[test]` ශ්‍රිතයක් මුල් token ප්‍රවාහයට එකතු කරන අතර එමඟින් එම ශ්‍රිතයට අදාළ උපදෙස් අඩංගු බව තහවුරු කරයි.
//!
//!
//!
//!

extern crate proc_macro;
extern crate proc_macro2;
#[macro_use]
extern crate quote;
extern crate syn;

use proc_macro2::TokenStream;
use quote::ToTokens;

#[proc_macro_attribute]
pub fn assert_instr(
    attr: proc_macro::TokenStream,
    item: proc_macro::TokenStream,
) -> proc_macro::TokenStream {
    let invoc = match syn::parse::<Invoc>(attr) {
        Ok(s) => s,
        Err(e) => return e.to_compile_error().into(),
    };
    let item = match syn::parse::<syn::Item>(item) {
        Ok(s) => s,
        Err(e) => return e.to_compile_error().into(),
    };
    let func = match item {
        syn::Item::Fn(ref f) => f,
        _ => panic!("must be attached to a function"),
    };

    let instr = &invoc.instr;
    let name = &func.sig.ident;

    // Avx සක්‍රීය කර ඇති x86 ඉලක්ක සඳහා assert_instr අක්‍රීය කරන්න, එමඟින් LLVM අප විසින් පරීක්‍ෂා කරන විවිධ අභ්‍යන්තරයන් ජනනය කරයි.
    //
    //
    let disable_assert_instr = std::env::var("STDARCH_DISABLE_ASSERT_INSTR").is_ok();

    // උපදෙස් පරීක්ෂණ අක්‍රීය කර ඇත්නම් මෙම ෂිම් එක කිසිසේත් විමෝචනය කිරීමෙන් වළකින්න, අපගේ ගුණාංගය නොමැතිව මුල් අයිතමය ආපසු එවන්න.
    //
    if !cfg!(optimized) || disable_assert_instr {
        return (quote! { #item }).into();
    }

    let instr_str = instr
        .replace('.', "_")
        .replace('/', "_")
        .replace(':', "_")
        .replace(char::is_whitespace, "");
    let assert_name = syn::Ident::new(&format!("assert_{}_{}", name, instr_str), name.span());
    // මෙම නම පසුව විසුරුවා හැරීමේදී අපට සොයා ගැනීමට තරම් අද්විතීය විය යුතුය:
    let shim_name = syn::Ident::new(
        &format!("stdarch_test_shim_{}_{}", name, instr_str),
        name.span(),
    );
    let mut inputs = Vec::new();
    let mut input_vals = Vec::new();
    let ret = &func.sig.output;
    for arg in func.sig.inputs.iter() {
        let capture = match *arg {
            syn::FnArg::Typed(ref c) => c,
            ref v => panic!(
                "arguments must not have patterns: `{:?}`",
                v.clone().into_token_stream()
            ),
        };
        let ident = match *capture.pat {
            syn::Pat::Ident(ref i) => &i.ident,
            _ => panic!("must have bare arguments"),
        };
        if let Some(&(_, ref tokens)) = invoc.args.iter().find(|a| *ident == a.0) {
            input_vals.push(quote! { #tokens });
        } else {
            inputs.push(capture);
            input_vals.push(quote! { #ident });
        }
    }

    let attrs = func
        .attrs
        .iter()
        .filter(|attr| {
            attr.path
                .segments
                .first()
                .expect("attr.path.segments.first() failed")
                .ident
                .to_string()
                .starts_with("target")
        })
        .collect::<Vec<_>>();
    let attrs = Append(&attrs);

    // පෙරනිමියෙන් Unix (මම හිතන්නේ?) හි සිදු වන දේ මෙන්, රෙජිස්ටර් වල සිම්ඩ් අගයන් පසු කරන Windows හි ABI භාවිතා කරන්න.
    //
    let abi = if cfg!(windows) {
        syn::LitStr::new("vectorcall", proc_macro2::Span::call_site())
    } else {
        syn::LitStr::new("C", proc_macro2::Span::call_site())
    };
    let shim_name_str = format!("{}{}", shim_name, assert_name);
    let to_test = quote! {
        #attrs
        #[no_mangle]
        #[inline(never)]
        pub unsafe extern #abi fn #shim_name(#(#inputs),*) #ret {
            // ප්‍රශස්තිකරණය කරන ලද මාදිලියේ සම්පාදකයා පෙරනිමියෙන් "mergefunc" නමින් පාස් එකක් ධාවනය කරයි, එහිදී එය සමාන පෙනුමක් ඇති කාර්යයන් ඒකාබද්ධ කරයි.
            // සමහර අභ්‍යන්තරිකයන් සමාන කේතයක් නිපදවන අතර ඒවා එකට බැඳී ඇත, එයින් අදහස් වන්නේ එකක් තවත් තැනකට පනින බවයි.
            // මෙම ශ්‍රිතය විසුරුවා හැරීම පිළිබඳ අපගේ පරීක්ෂාව අවුල් කරන අතර අපි ඒ සඳහා විශාල රසිකයෙක් නොවෙමු.
            //
            // මෙම මුරපදය වලක්වා ගැනීම සහ කාර්යයන් ඒකාබද්ධ වීම වැළැක්වීම සඳහා අපි කේතයන් ප්‍රකාරව ඉතා තදින් බැඳී ඇති නමුත් කේත නැවීම වැළැක්වීම සඳහා අද්විතීය වේ.
            //
            //
            // Wasm32 හි මෙය දැන් වළක්වා ඇත, මෙම කාර්යයන් පේළිගත කර නොමැති නිසා අපගේ පරීක්ෂණ බිඳ දමයි.
            // කෙසේ වෙතත් wasm32 සමඟ ඒකාබද්ධ වීමට තරම් ක්‍රියාකාරීත්වය සමාන නොවේ.
            // මෙම දෝෂය rust-lang/rust#74320 හි නිරීක්ෂණය කර ඇත.
            //
            //
            //
            //
            //
            //
            //
            #[cfg(not(target_arch = "wasm32"))]
            ::stdarch_test::_DONT_DEDUP.store(
                std::mem::transmute(#shim_name_str.as_bytes().as_ptr()),
                std::sync::atomic::Ordering::Relaxed,
            );
            #name(#(#input_vals),*)
        }
    };

    let tokens: TokenStream = quote! {
        #[test]
        #[allow(non_snake_case)]
        fn #assert_name() {
            #to_test

            ::stdarch_test::assert(#shim_name as usize,
                                   stringify!(#shim_name),
                                   #instr);
        }
    };

    let tokens: TokenStream = quote! {
        #item
        #tokens
    };
    tokens.into()
}

struct Invoc {
    instr: String,
    args: Vec<(syn::Ident, syn::Expr)>,
}

impl syn::parse::Parse for Invoc {
    fn parse(input: syn::parse::ParseStream) -> syn::Result<Self> {
        use syn::{ext::IdentExt, Token};

        let mut instr = String::new();
        while !input.is_empty() {
            if input.parse::<Token![,]>().is_ok() {
                break;
            }
            if let Ok(ident) = syn::Ident::parse_any(input) {
                instr.push_str(&ident.to_string());
                continue;
            }
            if input.parse::<Token![.]>().is_ok() {
                instr.push('.');
                continue;
            }
            if let Ok(s) = input.parse::<syn::LitStr>() {
                instr.push_str(&s.value());
                continue;
            }
            println!("{:?}", input.cursor().token_stream());
            return Err(input.error("expected an instruction"));
        }
        if instr.is_empty() {
            return Err(input.error("expected an instruction before comma"));
        }
        let mut args = Vec::new();
        while !input.is_empty() {
            let name = input.parse::<syn::Ident>()?;
            input.parse::<Token![=]>()?;
            let expr = input.parse::<syn::Expr>()?;
            args.push((name, expr));

            if input.parse::<Token![,]>().is_err() {
                if !input.is_empty() {
                    return Err(input.error("extra tokens at end"));
                }
                break;
            }
        }
        Ok(Self { instr, args })
    }
}

struct Append<T>(T);

impl<T> quote::ToTokens for Append<T>
where
    T: Clone + IntoIterator,
    T::Item: quote::ToTokens,
{
    fn to_tokens(&self, tokens: &mut proc_macro2::TokenStream) {
        for item in self.0.clone() {
            item.to_tokens(tokens);
        }
    }
}