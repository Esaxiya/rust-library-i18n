#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// [`prefetch`](fn._prefetch.html) බලන්න.
pub const _PREFETCH_READ: i32 = 0;

/// [`prefetch`](fn._prefetch.html) බලන්න.
pub const _PREFETCH_WRITE: i32 = 1;

/// [`prefetch`](fn._prefetch.html) බලන්න.
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// [`prefetch`](fn._prefetch.html) බලන්න.
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// [`prefetch`](fn._prefetch.html) බලන්න.
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// [`prefetch`](fn._prefetch.html) බලන්න.
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// දී ඇති `rw` සහ `locality` භාවිතා කරමින් `p` ලිපිනය අඩංගු හැඹිලි රේඛාව ලබා ගන්න.
///
/// `rw` එකක් විය යුතුය:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): උපසර්ගය කියවීම සඳහා සූදානම් වෙමින් පවතී.
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): පූර්විකාව ලිවීමට සූදානම් වෙමින් සිටී.
///
/// `locality` එකක් විය යුතුය:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): එක් වරක් පමණක් භාවිතා කරන දත්ත සඳහා ප්‍රවාහය හෝ තාවකාලික නොවන පෙරවදන.
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): 3 වන මට්ටමේ හැඹිලියට ලබා ගන්න.
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): 2 වන මට්ටමේ හැඹිලියට ලබා ගන්න.
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): පළමු මට්ටමේ හැඹිලියට පිවිසෙන්න.
///
/// නිශ්චිත ලිපිනයකින් මතක ප්‍රවේශයට ආසන්න future හි සිදුවිය හැකි බවට පෙර සැකසුම් මතක උපදෙස් මතක පද්ධතියට සං signal ා කරයි.
/// මතක පද්ධතියට ප්‍රතිචාර දැක්විය හැක්කේ ඒවා සිදු වූ විට මතක ප්‍රවේශය වේගවත් කිරීමට අපේක්‍ෂා කරන ක්‍රියාමාර්ග ගැනීමෙන් ය. එනම්, නිශ්චිත ලිපිනය හැඹිලි එකකට හෝ වැඩි ගණනකට පූර්ව පැටවීම වැනි ය.
///
/// මෙම සං als ා ඉඟි පමණක් බැවින්, කිසියම් CPU එකකට ඕනෑම හෝ සියලු පෙර සැකසුම් උපදෙස් NOP ලෙස සැලකීම වලංගු වේ.
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // අපි `cache type` =1 (දත්ත හැඹිලිය) සමඟ `llvm.prefetch` සහජයෙන්ම භාවිතා කරමු.
    // `rw` සහ `strategy` ක්‍රියාකාරී පරාමිතීන් මත පදනම් වේ.
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}