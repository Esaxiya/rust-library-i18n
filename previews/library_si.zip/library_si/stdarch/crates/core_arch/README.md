`core::arch` - Rust හි මූලික පුස්තකාල ගෘහ නිර්මාණ ශිල්පය-විශේෂිත අභ්‍යන්තරය
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` මොඩියුලය ගෘහ නිර්මාණ ශිල්පය මත රඳා පවතින සහජ (උදා: SIMD) ක්‍රියාත්මක කරයි.

# Usage 

`core::arch` `libcore` හි කොටසක් ලෙස ලබා ගත හැකි අතර එය `libstd` විසින් නැවත අපනයනය කරනු ලැබේ.මෙම crate හරහා වඩා `core::arch` හෝ `std::arch` හරහා එය භාවිතා කිරීමට කැමති වන්න.
අස්ථායී විශේෂාංග බොහෝ විට රාත්‍රී Rust හි `feature(stdsimd)` හරහා ලබා ගත හැකිය.

මෙම crate හරහා `core::arch` භාවිතා කිරීම සඳහා රාත්‍රී Rust අවශ්‍ය වන අතර එය බොහෝ විට කැඩී යා හැක.මෙම crate හරහා ඔබ එය භාවිතා කිරීම ගැන සලකා බැලිය යුතු එකම අවස්ථා:

* ඔබට `core::arch` නැවත සම්පාදනය කිරීමට අවශ්‍ය නම්, උදා: `libcore`/`libstd` සඳහා සක්‍රීය කර නොමැති විශේෂිත ඉලක්ක-විශේෂාංග සබල කර ඇත.
Note: සම්මත නොවන ඉලක්කයක් සඳහා ඔබට එය නැවත සම්පාදනය කිරීමට අවශ්‍ය නම්, කරුණාකර මෙම crate භාවිතා කරනවා වෙනුවට `xargo` භාවිතා කර `libcore`/`libstd` නැවත සම්පාදනය කිරීමට කැමති වන්න.
  
* අස්ථායී Rust විශේෂාංග පිටුපස පවා නොතිබිය හැකි සමහර විශේෂාංග භාවිතා කිරීම.අපි මේවා අවම මට්ටමක තබා ගැනීමට උත්සාහ කරමු.
ඔබට මෙම විශේෂාංග සමහරක් භාවිතා කිරීමට අවශ්‍ය නම්, කරුණාකර ප්‍රශ්නයක් විවෘත කරන්න එවිට අපට රාත්‍රී Rust තුළ ඒවා නිරාවරණය කළ හැකි අතර ඔබට ඒවා එතැන් සිට භාවිතා කළ හැකිය.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` මූලික වශයෙන් බෙදා හරිනු ලබන්නේ MIT බලපත්‍රය සහ Apache බලපත්‍රය (2.0 අනුවාදය) යන කොන්දේසි යටතේ වන අතර විවිධ බීඑස්ඩී වැනි බලපත්‍ර වලින් ආවරණය වන කොටස් ඇත.

වැඩි විස්තර සඳහා LICENSE-APACHE, සහ LICENSE-MIT බලන්න.

# Contribution

ඔබ වෙනත් ආකාරයකින් පැහැදිලිව ප්‍රකාශ නොකරන්නේ නම්, Apache-2.0 බලපත්‍රයේ අර්ථ දක්වා ඇති පරිදි ඔබ විසින් `core_arch` ඇතුළත් කිරීම සඳහා හිතාමතාම ඉදිරිපත් කරන ලද ඕනෑම දායකත්වයක් අතිරේක නියමයන් හෝ කොන්දේසි නොමැතිව ඉහත පරිදි ද්විත්ව බලපත්‍ර ලබා දෙනු ලැබේ.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












