# Stdarch සඳහා දායක වීම

`stdarch` crate දායක මුදල් භාර ගැනීමට වඩා වැඩි ය!පළමුවෙන්ම ඔබට බොහෝ විට ගබඩාව පරීක්ෂා කර බලා ඔබ වෙනුවෙන් පරීක්ෂණ සමත් වන බවට වග බලා ගන්න:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

`rustup` යනු `rustup` භාවිතා කරන ඉලක්ක ත්‍රිත්වය වන අතර, උදා: `x86_x64-unknown-linux-gnu` (පෙර `nightly-` හෝ ඊට සමාන කිසිවක් නොමැතිව).
මෙම ගබඩාවට Rust හි රාත්‍රී නාලිකාව අවශ්‍ය බව මතක තබා ගන්න!
ඉහත පරීක්ෂණ සඳහා ඇත්ත වශයෙන්ම රාත්‍රී rust ඔබේ පද්ධතියේ පෙරනිමිය විය යුතුය, එය `rustup default nightly` (සහ ආපසු හැරවීමට `rustup default stable`) භාවිතා කිරීම සැකසීමට.

ඉහත පියවර කිසිවක් ක්‍රියාත්මක නොවන්නේ නම්, [please let us know][new]!

ඊළඟට ඔබට උදව් කිරීමට [find an issue][issues] කළ හැකිය, අපි විශේෂයෙන් උදව් උපකාර කළ හැකි [`help wanted`][help] සහ [`impl-period`][impl] ටැග් කිහිපයක් තෝරාගෙන ඇත්තෙමු. 
ඔබ [#40][vendor] ගැන වඩාත් උනන්දු විය හැකිය, x86 හි සියලුම විකුණුම්කරුවන්ගේ සහජ හැකියාවන් ක්‍රියාත්මක කරයි.එම ගැටළුව ආරම්භ කළ යුත්තේ කොතැනින්ද යන්න පිළිබඳ හොඳ කරුණු කිහිපයක් තිබේ!

ඔබට සාමාන්‍ය ප්‍රශ්න ඇත්නම් [join us on gitter][gitter] වෙත නිදහස්ව සිටින්න.@බර්න්ට් සුෂි හෝ@alexcrichton ප්‍රශ්න සමඟ සම්බන්ධ වීමට නිදහස් වන්න.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Stdarch අභ්‍යන්තරයට උදාහරණ ලියන්නේ කෙසේද

ලබා දී ඇති අභ්‍යන්තරය නිසියාකාරව වැඩ කිරීමට සක්‍රීය කළ යුතු විශේෂාංග කිහිපයක් ඇති අතර උදාහරණය ක්‍රියාත්මක කළ යුත්තේ `cargo test --doc` මඟින් විශේෂාංගය CPU මඟින් සහය දක්වන විට පමණි.

එහි ප්‍රති As ලයක් ලෙස, `rustdoc` මඟින් ජනනය කරන සුපුරුදු `fn main` ක්‍රියා නොකරනු ඇත (බොහෝ අවස්ථාවලදී).
ඔබගේ උදාහරණය අපේක්ෂිත පරිදි ක්‍රියාත්මක වන බව සහතික කිරීම සඳහා පහත සඳහන් දෑ මාර්ගෝපදේශයක් ලෙස සලකා බලන්න.

```rust
/// # // උදාහරණය පමණක් බව සහතික කිරීමට අපට cfg_target_feature අවශ්‍ය වේ
/// # // CPU විශේෂාංගයට සහය දක්වන විට `cargo test --doc` මඟින් ධාවනය වේ
/// # #![feature(cfg_target_feature)]
/// # // සහජයෙන්ම වැඩ කිරීමට අපට target_feature අවශ්‍යයි
/// # #![feature(target_feature)]
/// #
/// # // rustdoc පෙරනිමියෙන් `extern crate stdarch` භාවිතා කරයි, නමුත් අපට එය අවශ්‍ය වේ
/// # // `#[macro_use]`
/// # # [macro_use] බාහිර crate stdarch;
/// #
/// # // සැබෑ ප්රධාන කාර්යය
/// # fn main() {
/// #     // `<target feature>` සහය දක්වන්නේ නම් පමණක් මෙය ක්‍රියාත්මක කරන්න
/// #     cfg_feature_enabled නම්! ("<target feature>"){
/// #         // `worker` ශ්‍රිතයක් සාදන්න, එය ක්‍රියාත්මක වන්නේ ඉලක්ක ලක්ෂණය නම් පමණි
/// #         // සහාය දක්වන අතර ඔබේ සේවකයා සඳහා `target_feature` සක්‍රීය කර ඇති බව සහතික කරන්න
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         අනාරක්ෂිත fn worker() {
/// // ඔබේ උදාහරණය මෙහි ලියන්න.විශේෂාංග විශේෂිත අභ්‍යන්තරයන් මෙහි ක්‍රියාත්මක වේ!වල් යන්න!
///
/// #         }
///
/// #         අනාරක්ෂිත { worker(); }
/// #     }
/// # }
```

ඉහත සමහර සින්ටැක්ස් හුරුපුරුදු නැතිනම්, [Rust Book] හි [Documentation as tests] කොටස `rustdoc` සින්ටැක්ස් ඉතා හොඳින් විස්තර කරයි.
සෑම විටම මෙන්, [join us on gitter][gitter] වෙත නිදහස්ව සිටින්න, ඔබ කිසියම් ස්නැග් එකක් ගැසුවේ දැයි අපෙන් විමසන්න, සහ `stdarch` හි ප්‍රලේඛනය වැඩි දියුණු කිරීමට උදව් කිරීම ගැන ස්තූතියි!

# විකල්ප පරීක්ෂණ උපදෙස්

පරීක්ෂණ ක්‍රියාත්මක කිරීම සඳහා ඔබ `ci/run.sh` භාවිතා කිරීම සාමාන්‍යයෙන් නිර්දේශ කෙරේ.
කෙසේ වෙතත් මෙය ඔබට ප්‍රයෝජනවත් නොවනු ඇත, උදා: ඔබ Windows හි සිටී නම්.

එවැනි අවස්ථාවකදී කේත උත්පාදනය පරීක්ෂා කිරීම සඳහා ඔබට නැවත `cargo +nightly test` සහ `cargo +nightly test --release -p core_arch` ධාවනය කළ හැකිය.
මේවාට රාත්‍රී මෙවලම් කට්ටලය ස්ථාපනය කිරීමට අවශ්‍ය වන අතර `rustc` සඳහා ඔබේ ඉලක්ක ත්‍රිත්වය සහ එහි CPU ගැන දැන ගැනීමට අවශ්‍ය බව සලකන්න.
විශේෂයෙන් ඔබ `ci/run.sh` සඳහා `TARGET` පරිසර විචල්‍යය සැකසිය යුතුය.
ඊට අමතරව ඉලක්ක ලක්ෂණ දැක්වීමට ඔබට `RUSTCFLAGS` (`C` අවශ්‍යයි) සැකසිය යුතුය, උදා `RUSTCFLAGS="-C -target-features=+avx2"`.
ඔබගේ වර්තමාන CPU ට සාපේක්ෂව ඔබ "just" සංවර්ධනය කරන්නේ නම් ඔබට `-C -target-cpu=native` ද සැකසිය හැකිය.

ඔබ මෙම විකල්ප උපදෙස් භාවිතා කරන විට, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], උදා
විසුරුවා හරින තැනැත්තා ඒවා වෙනස් ලෙස නම් කර ඇති නිසා උපදෙස් උත්පාදනය කිරීමේ පරීක්ෂණ අසාර්ථක විය හැකිය, උදා
එය හැසිරුණද `aesenc` උපදෙස් වෙනුවට `vaesenc` ජනනය කළ හැකිය.
මෙම උපදෙස් සාමාන්‍යයෙන් සිදු කිරීමට වඩා අඩු පරීක්ෂණ සිදු කරයි, එබැවින් ඔබ අවසානයේ ඉල්ලීමක් කරන විට මෙහි ආවරණය නොවන පරීක්ෂණ සඳහා සමහර දෝෂ පෙන්වනු ඇතැයි පුදුම නොවන්න.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






