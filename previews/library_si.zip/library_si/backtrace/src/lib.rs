//! ධාවන වේලාවේදී පසුබිමක් ලබා ගැනීම සඳහා පුස්තකාලයක්
//!
//! මෙම පුස්තකාලය සම්මත පුස්තකාලයේ `RUST_BACKTRACE=1` සහය අතිරේකව ක්‍රියාත්මක කිරීම සඳහා ක්‍රමලේඛනගතව ධාවන වේලාවේදී පසුපෙළක් ලබා ගැනීමට ඉඩ සලසයි.
//! මෙම පුස්තකාලය මඟින් ජනනය කරන ලද පසුබිම් විග්‍රහ කිරීම අවශ්‍ය නොවේ, උදාහරණයක් ලෙස, බැකෙන්ඩ් ක්‍රියාවට නැංවීමේ බහු ක්‍රියාකාරිත්වය.
//!
//! # Usage
//!
//! පළමුව, මෙය ඔබගේ Cargo.toml වෙත එක් කරන්න
//!
//! ```toml
//! [dependencies]
//! backtrace = "0.3"
//! ```
//!
//! Next:
//!
//! ```
//! fn main() {
//! # // මෙහි අනාරක්ෂිත බැවින් no_std හි පරීක්ෂණය සමත් වේ.
//! # #[cfg(feature = "std")] {
//!     backtrace::trace(|frame| {
//!         let ip = frame.ip();
//!         let symbol_address = frame.symbol_address();
//!
//!         // මෙම උපදෙස් දර්ශකය සංකේත නාමයකට විසඳන්න
//!         backtrace::resolve_frame(frame, |symbol| {
//!             if let Some(name) = symbol.name() {
//!                 // ...
//!             }
//!             if let Some(filename) = symbol.filename() {
//!                 // ...
//!             }
//!         });
//!
//!         true // ඊළඟ රාමුවට යන්න
//!     });
//! }
//! # }
//! ```
//!
//!
//!

#![doc(html_root_url = "https://docs.rs/backtrace")]
#![deny(missing_docs)]
#![no_std]
#![cfg_attr(
    all(feature = "std", target_env = "sgx", target_vendor = "fortanix"),
    feature(sgx_platform)
)]
#![warn(rust_2018_idioms)]
// අපි libstd හි කොටසක් ලෙස ගොඩනඟන විට, මෙම crate ගසෙන් පිටත සංවර්ධනය කර ඇති බැවින් සියලු අනතුරු ඇඟවීම් අදාළ නොවන බැවින් ඒවා නිහ silence කරන්න.
//
#![cfg_attr(backtrace_in_libstd, allow(warnings))]
#![cfg_attr(not(feature = "std"), allow(dead_code))]

#[cfg(feature = "std")]
#[macro_use]
extern crate std;

// මෙය දැන් භාවිතා කරනුයේ ගිම්ලි සඳහා පමණි, එය සමහර වේදිකා වල පමණක් භාවිතා වේ, එබැවින් එය වෙනත් වින්‍යාසයන්හි භාවිතා නොකරන්නේ නම් කරදර නොවන්න.
//
#[allow(unused_extern_crates)]
extern crate alloc;

pub use self::backtrace::{trace_unsynchronized, Frame};
mod backtrace;

pub use self::symbolize::resolve_frame_unsynchronized;
pub use self::symbolize::{resolve_unsynchronized, Symbol, SymbolName};
mod symbolize;

pub use self::types::BytesOrWideString;
mod types;

#[cfg(feature = "std")]
pub use self::symbolize::clear_symbol_cache;

mod print;
pub use print::{BacktraceFmt, BacktraceFrameFmt, PrintFmt};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        pub use self::backtrace::trace;
        pub use self::symbolize::{resolve, resolve_frame};
        pub use self::capture::{Backtrace, BacktraceFrame, BacktraceSymbol};
        mod capture;
    }
}

#[allow(dead_code)]
struct Bomb {
    enabled: bool,
}

#[allow(dead_code)]
impl Drop for Bomb {
    fn drop(&mut self) {
        if self.enabled {
            panic!("cannot panic during the backtrace function");
        }
    }
}

#[allow(dead_code)]
#[cfg(feature = "std")]
mod lock {
    use std::boxed::Box;
    use std::cell::Cell;
    use std::sync::{Mutex, MutexGuard, Once};

    pub struct LockGuard(Option<MutexGuard<'static, ()>>);

    static mut LOCK: *mut Mutex<()> = 0 as *mut _;
    static INIT: Once = Once::new();
    thread_local!(static LOCK_HELD: Cell<bool> = Cell::new(false));

    impl Drop for LockGuard {
        fn drop(&mut self) {
            if self.0.is_some() {
                LOCK_HELD.with(|slot| {
                    assert!(slot.get());
                    slot.set(false);
                });
            }
        }
    }

    pub fn lock() -> LockGuard {
        if LOCK_HELD.with(|l| l.get()) {
            return LockGuard(None);
        }
        LOCK_HELD.with(|s| s.set(true));
        unsafe {
            INIT.call_once(|| {
                LOCK = Box::into_raw(Box::new(Mutex::new(())));
            });
            LockGuard(Some((*LOCK).lock().unwrap()))
        }
    }
}

#[cfg(all(windows, not(target_vendor = "uwp")))]
mod dbghelp;
#[cfg(windows)]
mod windows;