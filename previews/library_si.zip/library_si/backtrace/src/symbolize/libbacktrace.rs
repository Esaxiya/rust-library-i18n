//! ලිබ්බැක්ට්‍රේස් හි DWARF-විග්‍රහ කිරීමේ කේතය භාවිතා කරමින් සංකේතකරණ උපාය.
//!
//! සාමාන්‍යයෙන් gcc සමඟ බෙදා හරින ලද libbacktrace C පුස්තකාලය, පසුපෙළක් ජනනය කිරීමට පමණක් නොව (අපි ඇත්ත වශයෙන්ම භාවිතා නොකරන) පසුබිම් සංකේතය සංකේතවත් කිරීමට සහ පේළිගත කළ රාමු සහ වොට්නොට් වැනි දේවල් පිළිබඳ වාමන නිදොස් කිරීමේ තොරතුරු හැසිරවීමටද සහාය වේ.
//!
//!
//! මෙහි විවිධාකාර උත්සුකයන් නිසා මෙය සාපේක්ෂව සංකීර්ණ වේ, නමුත් මූලික අදහස නම්:
//!
//! * පළමුව අපි `backtrace_syminfo` අමතන්නෙමු.අපට හැකි නම් මෙය ගතික සංකේත වගුවෙන් සංකේත තොරතුරු ලබා ගනී.
//! * ඊළඟට අපි `backtrace_pcinfo` අමතන්නෙමු.මෙය නිදොස් කිරීමේ වගු තිබේ නම් ඒවා විග්‍රහ කරන අතර පේළිගත රාමු, ගොනු නාම, රේඛා අංක ආදිය පිළිබඳ තොරතුරු ලබා ගැනීමට අපට ඉඩ දෙයි.
//!
//! වාමන වගු ලිබ්බැක්ට්‍රේස් තුළට ගෙන ඒම පිළිබඳ බොහෝ උපක්‍රම තිබේ, නමුත් එය ලෝකයේ අවසානය නොවන අතර පහත කියවීමේදී එය පැහැදිලි වේ.
//!
//! MSVC නොවන සහ OSX නොවන වේදිකා සඳහා පෙරනිමි සංකේතකරණ උපාය මෙයයි.Libstd හි මෙය OSX සඳහා පෙරනිමි උපාය වේ.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // හැකි නම්, ඩෙබගින්ෆෝ වෙතින් එන `function` නමට වැඩි කැමැත්තක් දක්වන්න. සාමාන්‍යයෙන් පේළිගත රාමු සඳහා වඩාත් නිවැරදි විය හැකිය.
                // එය නොපවතින නමුත් `symname` හි නිශ්චිතව දක්වා ඇති සංකේත වගු නාමයට වැටෙන්න.
                //
                // සමහර විට `function` ට තරමක් අඩු නිරවද්‍යතාවයක් දැනිය හැකි බව සලකන්න, උදාහරණයක් ලෙස X002 හි `try<i32,closure>` isntead ලෙස ලැයිස්තු ගත කර ඇත.
                //
                // එයට හේතුව සැබවින්ම පැහැදිලි නැත, නමුත් සමස්තයක් ලෙස `function` නම වඩාත් නිවැරදි බව පෙනේ.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // දැනට කිසිවක් නොකරන්න
}

/// X001 වෙත යොමු කරන ලද `data` දර්ශකයේ වර්ගය
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // අපි විසඳීමට පටන් ගත් විට `backtrace_syminfo` වෙතින් මෙම ඇමතුම ලබා ගත් පසු අපි තවදුරටත් `backtrace_pcinfo` අමතන්නෙමු.
    // `backtrace_pcinfo` ශ්‍රිතය මඟින් දෝශ නිරාකරණ තොරතුරු විමසනු ඇති අතර file/line තොරතුරු නැවත ලබා ගැනීම මෙන්ම පේළිගත කළ රාමු වැනි දේ කිරීමට උත්සාහ කරයි.
    // නිදොස් කිරීමේ තොරතුරු නොමැති නම් `backtrace_pcinfo` අසමත් විය හැකි හෝ බොහෝ දේ කළ නොහැකි බව සලකන්න, එබැවින් එය සිදුවුවහොත් `syminfo_cb` වෙතින් අවම වශයෙන් එක් සංකේතයක් සමඟ නැවත ඇමතුම ලබා ගැනීමට අපට විශ්වාසයි.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// X001 වෙත යොමු කරන ලද `data` දර්ශකයේ වර්ගය
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Libbacktrace API මගින් රාජ්‍යයක් නිර්මාණය කිරීමට සහාය වන නමුත් එය රාජ්‍යයක් විනාශ කිරීමට සහාය නොදක්වයි.
// මා පෞද්ගලිකව මෙය සලකන්නේ රාජ්‍යයක් නිර්මාණය කිරීමට අදහස් කර සදාකාලිකව ජීවත් වීමට අදහස් කිරීම සඳහා ය.
//
// මෙම තත්වය පිරිසිදු කරන at_exit() හසුරුවන්නෙකු ලියාපදිංචි කිරීමට මම කැමතියි, නමුත් libbacktrace ඒ සඳහා ක්‍රමයක් සපයන්නේ නැත.
//
// මෙම අවහිරතා සමඟ, මෙම ශ්‍රිතයට සංඛ්‍යාත්මකව හැඹිලි තත්වයක් ඇති අතර මෙය ඉල්ලූ පළමු අවස්ථාව ගණනය කෙරේ.
//
// සියල්ල පසුපසට ගැනීම අනුක්‍රමිකව සිදුවන බව මතක තබා ගන්න (එක් ගෝලීය අගුලක්).
//
// මෙහි සමමුහුර්තතාවයේ lack නතාවයට හේතුව `resolve` බාහිරව සමමුහුර්ත වීමේ අවශ්‍යතාවයයි.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // ලිබ්බැක්ට්‍රේස් හි නූල් ආරක්‍ෂිත හැකියාවන් අප සැමවිටම සමමුහුර්ත ආකාරයකින් හඳුන්වන බැවින් එය භාවිතා නොකරන්න.
        //
        0,
        error_cb,
        ptr::null_mut(), // අමතර දත්ත නොමැත
    );

    return STATE;

    // ලිබ්බැක්ට්‍රේස් ක්‍රියාත්මක වීමට නම් දැනට ක්‍රියාත්මක කළ හැකි DWARF නිදොස් කිරීමේ තොරතුරු සොයාගත යුතු බව සලකන්න.එය සාමාන්‍යයෙන් එසේ කරන්නේ ඒවාට සීමා නොවී යාන්ත්‍රණ ගණනාවක් හරහා ය:
    //
    // * /proc/self/exe සහාය දක්වන වේදිකාවල
    // * රාජ්යය නිර්මාණය කිරීමේදී ගොනු නාමය පැහැදිලිවම සම්මත විය
    //
    // ලිබ්බැක්ට්‍රේස් පුස්තකාලය සී කේතයේ විශාල වාට්ටුවකි.මෙය ස්වාභාවිකවම අදහස් කරන්නේ එය මතක ආරක්ෂණ දුර්වලතා ඇති බවයි, විශේෂයෙන් විකෘති නිදොස්කරණය හැසිරවීමේදී.
    // ලිබ්ස්ට් d තිහාසිකව මේවායින් බොහොමයක් තිබේ.
    //
    // /proc/self/exe භාවිතා කරන්නේ නම් අපට සාමාන්‍යයෙන් මේවා නොසලකා හැරිය හැක්කේ libbacktrace "mostly correct" යැයි උපකල්පනය කරන අතර "attempted to be correct" වාමන නිදොස් කිරීමේ තොරතුරු සමඟ අමුතු දේවල් නොකරයි.
    //
    //
    // කෙසේ වෙතත්, අපි ගොනු නාමයකින් සමත් වුවහොත්, සමහර වේදිකාවල (බීඑස්ඩී වැනි) අනිෂ්ට නළුවෙකුට අත්තනෝමතික ගොනුවක් එම ස්ථානයේ තැබීමට ඉඩ ඇත.
    // මෙයින් අදහස් කරන්නේ අපි ගොනු නාමයක් ගැන libbacktrace ට පැවසුවහොත් එය අත්තනෝමතික ගොනුවක් භාවිතා කිරීම විය හැකි අතර සමහර විට segfaults ඇතිවිය හැකි බවයි.
    // අපි කිසිවක් ලිබ්බැක්ට්‍රේස් වෙත නොකියන්නේ නම් එය /proc/self/exe වැනි මාර්ග වලට සහය නොදක්වන වේදිකාවල කිසිවක් නොකරනු ඇත!
    //
    // ගොනු නාමයකින් * නොපැමිණීමට අපි හැකි තරම් උත්සාහ කළත්, /proc/self/exe සඳහා කිසිසේත් සහාය නොදක්වන වේදිකාවල අප සිටිය යුතුය.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // ඉතා මැනවින් අපි `std::env::current_exe` භාවිතා කරන බව සලකන්න, නමුත් අපට මෙහි `std` අවශ්‍ය නොවේ.
            //
            // වත්මන් ක්‍රියාත්මක කළ හැකි මාර්ගය ස්ථිතික ප්‍රදේශයකට පැටවීමට `_NSGetExecutablePath` භාවිතා කරන්න (එය ඉතා කුඩා නම් අත්හරින්න).
            //
            //
            // දූෂිත විධායකයන් මත මිය නොයන ලෙස අපි මෙහි බරපතල ලෙස විශ්වාස කරන බව සලකන්න, නමුත් එය නිසැකවම ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows ගොනු විවෘත කිරීමේ ක්‍රමයක් ඇත, එය විවෘත කළ පසු එය මකා දැමිය නොහැක.
            // එය පොදුවේ අපට අවශ්‍ය වන්නේ අප විසින් ලිබ්බැක්ට්‍රේස් වෙත භාර දීමෙන් පසු අපගේ ක්‍රියාත්මක කළ හැකි දේ අප යටින් වෙනස් නොවන බවට සහතික කර ගැනීමට අවශ්‍ය නිසාය, අත්තනෝමතික දත්ත ලිබ්බැක්ට්‍රේස් වෙත යැවීමේ හැකියාව අඩු කරයි (එය වැරදි ලෙස හැසිරවිය හැක).
            //
            //
            // අපගේ ප්‍රතිරූපයට යම් ආකාරයක අගුලක් ලබා ගැනීමට උත්සාහ කිරීම සඳහා අපි මෙහි ටිකක් නැටුමක් කරන බැවින්:
            //
            // * වත්මන් ක්‍රියාවලියට හසුරුවන්න, එහි ගොනු නාමය පටවන්න.
            // * නිවැරදි කොඩි සහිත ගොනුවක් එම ගොනු නාමයට විවෘත කරන්න.
            // * වත්මන් ක්‍රියාවලියේ ගොනු නාමය නැවත පූරණය කරන්න, එය සමාන බව සහතික කර ගන්න
            //
            // න්‍යායාත්මකව අප සමත් වූ විට අපගේ ක්‍රියාවලියේ ගොනුව විවෘත වී ඇති අතර එය වෙනස් නොවන බවට අපට සහතිකයි.FWIW මෙයින් පොකුරක් lib තිහාසිකව libstd වෙතින් පිටපත් කර ඇත, එබැවින් සිදුවෙමින් පවතින දේ පිළිබඳ මගේ හොඳම අර්ථ නිරූපණය මෙයයි.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // මෙය ස්ථිතික මතකයේ රැඳී ඇති බැවින් අපට එය ආපසු ලබා දිය හැකිය ..
                static mut BUF: [i8; N] = [0; N];
                // ... මෙය තාවකාලික බැවින් තොගයේ ජීවත් වේ
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // හිතාමතාම මෙහි `handle` කාන්දු වීම නිසා එය විවෘතව තිබීම මෙම ගොනු නාමයේ ඇති අපගේ අගුල ආරක්ෂා කළ යුතුය.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // අපට අවලංගු කරන ලද පෙත්තක් ආපසු ලබා දීමට අවශ්‍යය, එබැවින් සියල්ල පුරවා එය මුළු දිගට සමාන නම් එය අසාර්ථකත්වයට සමාන කරන්න.
                //
                //
                // එසේ නොමැතිනම් සාර්ථකත්වය ආපසු ලබා දෙන විට නුල් බයිට් පෙත්තට ඇතුළත් කර ඇති බවට වග බලා ගන්න.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // පසුපෙළ දෝෂ දැනට අගල යට අතුගා දමා ඇත
    let state = init_state();
    if state.is_null() {
        return;
    }

    // `backtrace_syminfo` API අමතන්න (කේතය කියවීමෙන්) හරියටම එක් වරක් `syminfo_cb` අමතන්න (නැතහොත් දෝෂයක් සමඟ අසමත් විය හැක).
    // අපි පසුව `syminfo_cb` තුළ තවත් බොහෝ දේ හසුරුවන්නෙමු.
    //
    // ද්විමය තුළ නිදොස් කිරීමේ තොරතුරු නොමැති වුවද සංකේත නාම සොයා ගැනීම සඳහා `syminfo` සංකේත වගුව විමසන බැවින් අපි මෙය කරන බව සලකන්න.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}