// දැන් භාවිතා කර ඇත්තේ Linux හි පමණි, එබැවින් වෙනත් තැනක මළ කේත වලට ඉඩ දෙන්න
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// බයිට් බෆර් සඳහා සරල ක්‍රීඩා පිටියක්.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// නිශ්චිත ප්‍රමාණයේ බෆරයක් වෙන් කර ඒ සඳහා විකෘති යොමු කිරීමක් ලබා දෙයි.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // සුරක්ෂිතභාවය: විකෘති කළ හැකි එකම කාර්යය මෙයයි
        // `self.buffers` වෙත යොමු කිරීම.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // ආරක්ෂාව: අපි කිසි විටෙකත් `self.buffers` වෙතින් මූලද්‍රව්‍ය ඉවත් නොකරන්නෙමු
        // ඕනෑම බෆරයක ඇති දත්ත වලට `self` පවතින තාක් කල් ජීවත් වේ.
        &mut buffers[i]
    }
}