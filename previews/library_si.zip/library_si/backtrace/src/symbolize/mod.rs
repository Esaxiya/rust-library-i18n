use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// සංකේතයක් වෙත ලිපිනයක් නිරාකරණය කර, සංකේතය නිශ්චිත වසා දැමීම වෙත යොමු කරන්න.
///
/// මෙම ශ්‍රිතය මඟින් දේශීය සංකේත වගුව, ගතික සංකේත වගුව හෝ DWARF නිදොස් කිරීමේ තොරතුරු (සක්‍රිය ක්‍රියාත්මක කිරීම මත පදනම්ව) වැනි ක්ෂේත්‍රවල දී ලබා දෙන ලිපිනය සොයා බලනු ඇත.
///
///
/// විභේදනය සිදු කළ නොහැකි නම් වසා දැමීම කැඳවිය නොහැකි අතර, ආදාන ශ්‍රිතවලදී එය එක් වරකට වඩා හැඳින්විය හැක.
///
/// ලබා දෙන සංකේත මඟින් නිශ්චිත `addr` හි ක්‍රියාත්මක කිරීම නිරූපණය කරයි, එම ලිපිනය සඳහා file/line යුගල ආපසු ලබා දෙයි (තිබේ නම්).
///
/// ඔබ සතුව `Frame` තිබේ නම් මෙය වෙනුවට `resolve_frame` ශ්‍රිතය භාවිතා කිරීම රෙකමදාරු කරනු ලැබේ.
///
/// # අවශ්‍ය අංග
///
/// මෙම ශ්‍රිතයට `backtrace` crate හි `std` විශේෂාංගය සක්‍රීය කිරීම අවශ්‍ය වන අතර `std` විශේෂාංගය පෙරනිමියෙන් සක්‍රීය කර ඇත.
///
/// # Panics
///
/// මෙම ශ්‍රිතය කිසි විටෙකත් panic කිරීමට උත්සාහ නොකරයි, නමුත් `cb` විසින් panics ලබා දුන්නේ නම් සමහර වේදිකා මඟින් ක්‍රියාවලිය නවතා දැමීමට ද්විත්ව panic බල කරනු ඇත.
/// සමහර වේදිකා සී පුස්තකාලයක් භාවිතා කරන අතර එය අභ්‍යන්තරව ඇමතුම් ලබා ගත නොහැකි වන අතර එමඟින් `cb` වෙතින් භීතියට පත්වීම ක්‍රියාවලිය නවතා දැමිය හැකිය.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // ඉහළ රාමුව දෙස පමණක් බලන්න
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// කලින් අල්ලා ගත් රාමුවක් සංකේතයකට විසඳා, සංකේතය නිශ්චිත වසා දැමීම වෙත යොමු කරන්න.
///
/// මෙම ෆන්ක්ටින් `resolve` හා සමාන කාර්යයක් ඉටු කරයි, එය ලිපිනයක් වෙනුවට තර්කයක් ලෙස `Frame` ගනී.
/// උදාහරණ ලෙස පේළිගත කිරීම් සමහර වේදිකා ක්‍රියාත්මක කිරීමට වඩාත් නිවැරදි සංකේත තොරතුරු හෝ පේළි රාමු පිළිබඳ තොරතුරු සැපයීමට මෙය ඉඩ දෙයි.
///
/// ඔබට හැකි නම් මෙය භාවිතා කිරීම රෙකමදාරු කරනු ලැබේ.
///
/// # අවශ්‍ය අංග
///
/// මෙම ශ්‍රිතයට `backtrace` crate හි `std` විශේෂාංගය සක්‍රීය කිරීම අවශ්‍ය වන අතර `std` විශේෂාංගය පෙරනිමියෙන් සක්‍රීය කර ඇත.
///
/// # Panics
///
/// මෙම ශ්‍රිතය කිසි විටෙකත් panic කිරීමට උත්සාහ නොකරයි, නමුත් `cb` විසින් panics ලබා දුන්නේ නම් සමහර වේදිකා මඟින් ක්‍රියාවලිය නවතා දැමීමට ද්විත්ව panic බල කරනු ඇත.
/// සමහර වේදිකා සී පුස්තකාලයක් භාවිතා කරන අතර එය අභ්‍යන්තරව ඇමතුම් ලබා ගත නොහැකි වන අතර එමඟින් `cb` වෙතින් භීතියට පත්වීම ක්‍රියාවලිය නවතා දැමිය හැකිය.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // ඉහළ රාමුව දෙස පමණක් බලන්න
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// සිරස් රාමු වලින් ලැබෙන IP අගයන් සාමාන්‍යයෙන් (always?) උපදෙස් වේ *ඇමතුමෙන් පසුව* නියම තොග හෝඩුවාව.
// මෙය සංකේතවත් කිරීමෙන් filename/line අංකය ඉදිරියෙන් එකක් විය හැකි අතර එය ශ්‍රිතයේ අවසානයට ආසන්න නම් එය අවලංගු වේ.
//
// මෙය සෑම වේදිකාවකම මූලික වශයෙන් සැමවිටම පවතින බව පෙනේ, එබැවින් අපි සෑම විටම විසඳුමක් ලබා දෙන අයිපී එකකින් අඩු කර එය නැවත ඇමතුම වෙනුවට පෙර ඇමතුම් උපදෙස් වෙත විසඳා ගනිමු.
//
//
// ඉතා මැනවින් අපි මෙය නොකරමු.
// ඉතා මැනවින් අපට මෙහි `resolve` API ඇමතුම්කරුවන් විසින් -1 අතින් සිදු කිරීමට අවශ්‍ය වන අතර ඔවුන්ට අවශ්‍ය වන්නේ *පෙර* උපදෙස් සඳහා ස්ථාන තොරතුරු මිස ධාරාව නොවේ.
// ඇත්ත වශයෙන්ම අපි ඊළඟ උපදෙස් හෝ වර්තමාන ලිපිනය නම් `Frame` ද නිරාවරණය කරමු.
//
// දැන් මෙය ඉතා වැදගත් කාරණයක් වුවද අපි අභ්‍යන්තරව සෑම විටම අඩු කරන්නෙමු.
// පාරිභෝගිකයින් දිගටම වැඩ කරමින් හොඳ ප්‍රති results ල ලබා ගත යුතුය, එබැවින් අප ප්‍රමාණවත් විය යුතුය.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// `resolve` හා සමානයි, එය සමමුහුර්ත නොවූ බැවින් අනාරක්ෂිතයි.
///
/// මෙම ශ්‍රිතයට සමමුහුර්ත කිරීමේ සහතික නොමැත, නමුත් මෙම crate හි `std` විශේෂාංගය සම්පාදනය නොකළ විට ලබා ගත හැකිය.
/// වැඩි ලේඛන සහ උදාහරණ සඳහා `resolve` ශ්‍රිතය බලන්න.
///
/// # Panics
///
/// `cb` භීතිකාව පිළිබඳ අවවාද සඳහා `resolve` පිළිබඳ තොරතුරු බලන්න.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// `resolve_frame` හා සමානයි, එය සමමුහුර්ත නොවූ බැවින් අනාරක්ෂිතයි.
///
/// මෙම ශ්‍රිතයට සමමුහුර්ත කිරීමේ සහතික නොමැත, නමුත් මෙම crate හි `std` විශේෂාංගය සම්පාදනය නොකළ විට ලබා ගත හැකිය.
/// වැඩි ලේඛන සහ උදාහරණ සඳහා `resolve_frame` ශ්‍රිතය බලන්න.
///
/// # Panics
///
/// `cb` භීතිකාව පිළිබඳ අවවාද සඳහා `resolve_frame` පිළිබඳ තොරතුරු බලන්න.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// ගොනුවක සංකේතයක විභේදනය නිරූපණය කරන trait.
///
/// මෙම trait, `backtrace::resolve` ශ්‍රිතයට ලබා දී ඇති වසා දැමීම සඳහා trait වස්තුවක් ලෙස ලබා දෙන අතර, එය පිටුපසින් ක්‍රියාත්මක කරන්නේ කුමක් දැයි නොදන්නා බැවින් එය මුලුමනින්ම පාහේ යවනු ලැබේ.
///
///
/// සංකේතයකට ශ්‍රිතයක් පිළිබඳ සන්දර්භීය තොරතුරු ලබා දිය හැකිය, උදාහරණයක් ලෙස නම, ගොනු නාමය, රේඛා අංකය, නිවැරදි ලිපිනය යනාදිය.
/// සෑම තොරතුරක්ම සෑම විටම සංකේතයකින් ලබා ගත නොහැක, කෙසේ වෙතත්, සියලු ක්‍රම `Option` ආපසු ලබා දේ.
///
///
pub struct Symbol {
    // TODO: මෙම ජීවිත කාලය බැඳී අවසානයේදී `Symbol` දක්වා පැවතිය යුතුය,
    // නමුත් එය දැනට කැපී පෙනෙන වෙනසක්.
    // දැන් මෙය ආරක්ෂිත වන්නේ `Symbol` කිසි විටෙකත් යොමු කිරීමකින් පමණක් ලබා දී ඇති අතර එය ක්ලෝන කළ නොහැකි බැවිනි.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// මෙම ශ්‍රිතයේ නම ලබා දෙයි.
    ///
    /// සංකේත නාමය පිළිබඳ විවිධ ගුණාංග විමසීමට ආපසු ලබා දුන් ව්‍යුහය භාවිතා කළ හැකිය:
    ///
    ///
    /// * `Display` ක්‍රියාත්මක කිරීම මඟින් විරූපණය කළ සංකේතය මුද්‍රණය කෙරේ.
    /// * සංකේතයේ අමු `str` අගයට ප්‍රවේශ විය හැකිය (එය වලංගු utf-8 නම්).
    /// * සංකේත නාමය සඳහා අමු බයිට් වලට ප්‍රවේශ විය හැකිය.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// මෙම ශ්‍රිතයේ ආරම්භක ලිපිනය ලබා දෙයි.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// අමු ගොනු නාමය පෙත්තක් ලෙස ලබා දෙයි.
    /// මෙය ප්‍රධාන වශයෙන් `no_std` පරිසර සඳහා ප්‍රයෝජනවත් වේ.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// මෙම සංකේතය දැනට ක්‍රියාත්මක වන ස්ථානය සඳහා තීරු අංකය ලබා දෙයි.
    ///
    /// දැනට මෙහි වටිනාකමක් ලබා දෙන්නේ ගිම්ලි පමණක් වන අතර එසේ වුවද `filename` විසින් `Some` ආපසු ලබා දෙන්නේ නම් පමණක් වන අතර එමඟින් එය සමාන අවවාදයන්ට යටත් වේ.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// මෙම සංකේතය දැනට ක්‍රියාත්මක වන ස්ථානය සඳහා රේඛා අංකය ලබා දෙයි.
    ///
    /// `filename` `Some` ආපසු ලබා දෙන්නේ නම් මෙම ප්‍රතිලාභ අගය සාමාන්‍යයෙන් `Some` වන අතර එමඟින් සමාන අවවාද වලට යටත් වේ.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// මෙම ශ්‍රිතය අර්ථ දක්වා ඇති ගොනු නාමය ලබා දෙයි.
    ///
    /// මෙය දැනට ලබා ගත හැක්කේ libbacktrace හෝ gimli භාවිතා කරන විට පමණි (උදා
    /// unix වෙනත් වේදිකා) සහ ද්විමය දෝශ නිරාකරණයේදී සම්පාදනය කළ විට.
    /// මෙම කොන්දේසි කිසිවක් සපුරා නොමැති නම් මෙය `None` නැවත ලබා දෙනු ඇත.
    ///
    /// # අවශ්‍ය අංග
    ///
    /// මෙම ශ්‍රිතයට `backtrace` crate හි `std` විශේෂාංගය සක්‍රීය කිරීම අවශ්‍ය වන අතර `std` විශේෂාංගය පෙරනිමියෙන් සක්‍රීය කර ඇත.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Rust ලෙස අඹරන ලද සංකේතය විග්‍රහ කිරීම අසමත් වුවහොත් සමහර විට විග්‍රහ කරන ලද C++ සංකේතයක් විය හැකිය.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // මෙම ශුන්‍ය ප්‍රමාණය තබා ගැනීමට වග බලා ගන්න, එවිට `cpp_demangle` විශේෂාංගය අක්‍රිය වූ විට කිසිදු පිරිවැයක් නොමැත.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// අබලන් වූ නම, අමු බයිට්, අමු නූල් ආදිය සඳහා ergonomic ප්රවේශයන් සැපයීම සඳහා සංකේත නාමයක් වටා එතීම.
///
// `cpp_demangle` විශේෂාංගය සක්‍රිය කර නොමැති විට මළ කේතයට ඉඩ දෙන්න.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// අමු යටින් පවතින බයිට් වලින් නව සංකේත නාමයක් සාදයි.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// සංකේතය වලංගු utf-8 නම් අමු (mangled) සංකේත නාමය `str` ලෙස ලබා දෙයි.
    ///
    /// විරූපණය කළ අනුවාදය ඔබට අවශ්‍ය නම් `Display` ක්‍රියාත්මක කිරීම භාවිතා කරන්න.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// අමු සංකේත නාමය බයිට් ලැයිස්තුවක් ලෙස ලබා දෙයි
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // විරූපණය කළ සංකේතය ඇත්ත වශයෙන්ම වලංගු නොවේ නම් මෙය මුද්‍රණය කළ හැකිය, එබැවින් මෙහි දෝෂය පිටතින් ප්‍රචාරය නොකිරීමෙන් එය මනාව හසුරුවන්න.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// ලිපින සංකේතවත් කිරීමට භාවිතා කළ හැඹිලි මතකය නැවත ලබා ගැනීමට උත්සාහ කිරීම.
///
/// මෙම ක්‍රමය මඟින් ගෝලීයව හෝ වෙනත් ආකාරයකින් හැඹිලිගත කර ඇති ඕනෑම ගෝලීය දත්ත ව්‍යුහයක් මුදා හැරීමට උත්සාහ කරනු ඇත.
///
///
/// # Caveats
///
/// මෙම ශ්‍රිතය සැමවිටම පවතින අතර එය බොහෝ ක්‍රියාත්මක කිරීම් වලදී කිසිවක් නොකරයි.
/// Dbghelp හෝ libbacktrace වැනි පුස්තකාල මගින් රාජ්‍යය අවලංගු කිරීමට සහ වෙන් කළ මතකය කළමනාකරණය කිරීමට පහසුකම් සපයන්නේ නැත.
/// දැනට මෙම crate හි `gimli-symbolize` විශේෂාංගය මෙම ශ්‍රිතයට යම් බලපෑමක් ඇති එකම ලක්ෂණයයි.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}