//! crates.io හි `gimli` crate භාවිතා කරමින් සංකේතකරණය සඳහා සහාය
//!
//! Rust සඳහා පෙරනිමි සංකේතකරණ ක්‍රියාත්මක කිරීම මෙයයි.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // ස්ථිතික ජීවිත කාලය යනු ස්වයං-යොමුකිරීමේ ව්‍යුහයන් සඳහා සහය නොලැබීම වළක්වාලීමකි.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // සංකේත `map` සහ `stash` පමණක් ණයට ගත යුතු බැවින් අපි ස්ථිතික ජීවිත කාලය බවට පරිවර්තනය කරන්න.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Windows හි ස්වදේශීය පුස්තකාල පූරණය කිරීම සඳහා, මෙහි ඇති විවිධ උපාය මාර්ග සඳහා rust-lang/rust#71060 පිළිබඳ යම් සාකච්ඡාවක් බලන්න.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW පුස්තකාල දැනට ASLR (rust-lang/rust#16514) සඳහා සහය නොදක්වයි, නමුත් DLLs තවමත් ලිපින අවකාශයේ වෙනත් ස්ථානයකට ගෙන යා හැකිය.
            // මෙම පුස්තකාලය එහි "image base" හි පටවා ඇති පරිදි, නිදොස් කිරීමේ තොරතුරු වල ලිපින සියල්ලම සමාන වන බව පෙනේ, එය එහි COFF ගොනු ශීර්ෂයන්හි ක්ෂේත්‍රයකි.
            // Deubininfo ලැයිස්තුගත කර ඇති බව පෙනෙන බැවින් අපි සංකේත වගුව විග්‍රහ කර ලිපිනයන් ගබඩා කර ඇති අතර පුස්තකාලය "image base" හි පටවා ඇති ආකාරයට ය.
            //
            // කෙසේ වෙතත්, පුස්තකාලය "image base" හි පටවනු නොලැබේ.
            // (අනුමාන වශයෙන් වෙනත් දෙයක් එහි පටවනු ලැබිය හැකිද?) `bias` ක්ෂේත්‍රය ක්‍රියාත්මක වන්නේ මෙහිද, මෙහි `bias` හි වටිනාකම අප විසින් සොයාගත යුතුය.අවාසනාවට, පටවන ලද මොඩියුලයකින් මෙය ලබා ගන්නේ කෙසේද යන්න පැහැදිලි නැත.
            // කෙසේ වෙතත්, අප සතුව ඇත්තේ සත්‍ය පැටවුම් ලිපිනය (`modBaseAddr`) ය.
            //
            // දැන් අපි ගොනුව එම්එම්ඒපී, ගොනු ශීර්ෂ තොරතුරු කියවා, පසුව එම්එම්ඒපී අතහරින්න.මෙය නාස්තියකි, මන්ද අපි පසුව එම්එම්ඒපී නැවත විවෘත කරනු ඇත, නමුත් මෙය දැනට ප්‍රමාණවත් ලෙස ක්‍රියා කළ යුතුය.
            //
            // අපට `image_base` (අපේක්ෂිත පැටවුම් ස්ථානය) සහ `base_addr` (සත්‍ය පැටවුම් ස්ථානය) ලැබීමෙන් පසු අපට `bias` (සත්‍ය හා අපේක්ෂිත අතර වෙනස) පිරවිය හැකි අතර ඉන්පසු එක් එක් කොටසේ ප්‍රකාශිත ලිපිනය `image_base` වේ.
            //
            //
            // දැන් පෙනී යන්නේ ELF/MachO මෙන් නොව අපට එක් පුස්තකාලයකට එක් අංශයක් සමඟ කළ හැකි බවයි.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS මැක්-ඕ ගොනු ආකෘතිය භාවිතා කරන අතර යෙදුමේ කොටසක් වන ස්වදේශීය පුස්තකාල ලැයිස්තුවක් පූරණය කිරීම සඳහා ඩයිඑල්ඩී-විශේෂිත ඒපීඅයි භාවිතා කරයි.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // මෙම පුස්තකාලයේ නම පූරණය කළ යුතු ස්ථානයට අනුරූප වන නම ලබා ගන්න.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // මෙම පුස්තකාලයේ අනුරූප ශීර්ෂය පුරවා `object` වෙත සියලු පැටවුම් විධාන විග්‍රහ කිරීමට අපට මෙහි සියලුම කොටස් හඳුනාගත හැකිය.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // කොටස් සොයා ගැනීම සහ අප සොයාගත් කොටස් සඳහා දන්නා ප්‍රදේශ ලියාපදිංචි කිරීම.
            // පසුකාලීනව සැකසීම සඳහා අමතර තොරතුරු පෙළ සටහන් කරන්න, පහත අදහස් බලන්න.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // මෙම පුස්තකාලය සඳහා "slide" තීරණය කරන්න, එය මතක වස්තු පටවා ඇති ස්ථානය සොයා ගැනීමට අප භාවිතා කරන නැඹුරුවයි.
            // මෙය ටිකක් අමුතු ගණනය කිරීමක් වන අතර වනාන්තරයේ දේවල් කිහිපයක් උත්සාහ කිරීමෙන් හා ඇලෙන සුළු දේ දැකීමේ ප්‍රති result ලයකි.
            //
            // සාමාන්‍ය අදහස නම්, `bias` සහ කොටසක `stated_virtual_memory_address` යනු සත්‍ය ලිපින අවකාශයේ කොටස වාසය කරන ස්ථානය වීමයි.
            // අප විශ්වාසය තබන අනෙක් කාරණය නම් සංකේත වගුවේ සහ නිදොස් කිරීමේ තොරතුරු සොයා බැලීමේ දර්ශකය `bias` ට us ණ වන සැබෑ ලිපිනයයි.
            //
            // කෙසේ වෙතත්, පද්ධති පටවා ඇති පුස්තකාල සඳහා මෙම ගණනය කිරීම් වැරදිය.කෙසේ වෙතත්, ස්වදේශීය ක්‍රියාත්මක කළ හැකි අය සඳහා එය නිවැරදි බව පෙනේ.
            // එල්එල්ඩීබී ප්‍රභවයෙන් යම් තර්කනයක් ඔසවා තැබීමේදී එහි පළමු `__TEXT` කොටස සඳහා විශේෂ ආවරණයක් ඇත.
            // මෙය ඇති විට කුමන හේතුවක් නිසා හෝ සංකේත වගුව පුස්තකාලය සඳහා vmaddr විනිවිදකයට සාපේක්ෂ බව පෙනේ.
            // එය * නොමැති නම් සංකේත වගුව vmaddr විනිවිදකයට හා කොටසේ ප්‍රකාශිත ලිපිනයට සාපේක්ෂව වේ.
            //
            // මෙම තත්වය හසුරුවා ගැනීම සඳහා අපි ලිපිගොනු ඕෆ්සෙට් ශුන්‍යයේදී පෙළ කොටසක් සොයා නොගත්තොත් පළමු පෙළ කොටස්වල ප්‍රකාශිත ලිපිනය අනුව අපි නැඹුරුව වැඩි කරන අතර ප්‍රකාශිත ලිපිනයන් සියල්ලම එම ප්‍රමාණයෙන් අඩු කරමු.
            //
            // පුස්තකාලයේ පක්ෂග්‍රාහී ප්‍රමාණයට සාපේක්ෂව සංකේත වගුව සෑම විටම දිස් වේ.
            // සංකේත වගුව හරහා සංකේතවත් කිරීම සඳහා මෙය නිවැරදි ප්‍රති results ල ඇති බව පෙනේ.
            //
            // අවංකවම මෙය නිවැරදිද නැතිනම් මෙය කරන්නේ කෙසේදැයි ඇඟවිය යුතු වෙනත් යමක් තිබේදැයි මට සම්පූර්ණයෙන්ම විශ්වාස නැත.
            // දැනට මෙය (?) ප්‍රමාණවත් තරම් ක්‍රියා කරන බවක් පෙනෙන්නට තිබුණත්, අවශ්‍ය නම් කාලයත් සමඟ මෙය වෙනස් කිරීමට අපට හැකි විය යුතුය.
            //
            // වැඩි විස්තර සඳහා #318 බලන්න
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // වෙනත් Unix (උදා
        // ලිනක්ස්) වේදිකා වස්තු ගොනු ආකෘතියක් ලෙස ELF භාවිතා කරන අතර සාමාන්‍යයෙන් දේශීය පුස්තකාල පූරණය කිරීම සඳහා `dl_iterate_phdr` නමින් API ක්‍රියාත්මක කරයි.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` වලංගු දර්ශකයන් විය යුතුය.
        // `vec` `std::Vec` සඳහා වලංගු දර්ශකයක් විය යුතුය.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 නිදොස් කිරීමේ තොරතුරු ස්වදේශීයව සහාය නොදක්වයි, නමුත් ගොඩ නැගීමේ පද්ධතිය මඟින් නිදොස් කිරීමේ තොරතුරු `romfs:/debug_info.elf` මාර්ගයේ ස්ථානගත කරනු ඇත.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // අනෙක් සෑම දෙයක්ම ELF භාවිතා කළ යුතුය, නමුත් දේශීය පුස්තකාල පූරණය කරන්නේ කෙසේදැයි නොදනී.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// පටවා ඇති සියලුම දන්නා හවුල් පුස්තකාල.
    libraries: Vec<Library>,

    /// අප විසින් විග්‍රහ කරන ලද වාමන තොරතුරු රඳවා ගන්නා සිතියම් හැඹිලිය.
    ///
    /// මෙම ලැයිස්තුවේ සම්පූර්ණ ආයු කාලය සඳහා ස්ථාවර ධාරිතාවක් ඇති අතර එය කිසි විටෙකත් වැඩි නොවේ.
    /// එක් එක් යුගලයේ `usize` මූලද්‍රව්‍යය `libraries` ට ඉහළින් ඇති දර්ශකයක් වන අතර එහිදී `usize::max_value()` වත්මන් ක්‍රියාත්මක කළ හැකි ය.
    ///
    /// `Mapping` යනු අනුරූප විග්‍රහ කළ වාමන තොරතුරු ය.
    ///
    /// මෙය මූලික වශයෙන් LRU හැඹිලියක් බව සලකන්න. අපි ලිපින සංකේතවත් කරන විට අපි මෙහි දේවල් මාරු කරන්නෙමු.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// මෙම පුස්තකාලයේ කොටස් මතකයට පටවා ඇති අතර ඒවා පටවා ඇති ස්ථානය.
    segments: Vec<LibrarySegment>,
    /// මෙම පුස්තකාලයේ "bias", සාමාන්‍යයෙන් එය මතකය තුළට පටවනු ලැබේ.
    /// ඛණ්ඩය පටවා ඇති සත්‍ය අථත්‍ය මතක ලිපිනය ලබා ගැනීම සඳහා මෙම අගය එක් එක් කොටසෙහි ප්‍රකාශිත ලිපිනයට එකතු කරනු ලැබේ.
    /// මීට අමතරව මෙම නැඹුරුව සැබෑ අතථ්‍ය මතක ලිපිනවල සිට දර්ශකය දක්වා debuginfo සහ සංකේත වගුවට අඩු කරනු ලැබේ.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// වස්තු ගොනුවේ මෙම කොටසේ ප්‍රකාශිත ලිපිනය.
    /// මෙය සැබවින්ම කොටස පටවා ඇති ස්ථානය නොවේ, නමුත් මෙම ලිපිනය සහ අඩංගු පුස්තකාලයේ `bias` එය සොයා ගත හැකි ස්ථානයයි.
    ///
    stated_virtual_memory_address: usize,
    /// මතකයේ ths කොටසේ ප්‍රමාණය.
    len: usize,
}

// අනාරක්ෂිත බැවින් මෙය බාහිරව සමමුහුර්ත කිරීමට අවශ්‍ය වේ
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // අනාරක්ෂිත බැවින් මෙය බාහිරව සමමුහුර්ත කිරීමට අවශ්‍ය වේ
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // නිදොස් කිරීමේ තොරතුරු සිතියම්ගත කිරීම සඳහා ඉතා කුඩා, ඉතා සරල LRU හැඹිලියක්.
        //
        // බොහෝ හවුල් පුස්තකාල අතර සාමාන්‍ය තොගය නොගැලපෙන බැවින් පහර අනුපාතය ඉතා ඉහළ විය යුතුය.
        //
        // `addr2line::Context` ව්‍යුහයන් නිර්මාණය කිරීම සඳහා මිල අධිකය.
        // එහි පිරිවැය පසුකාලීන `locate` විමසුම් මගින් ක්‍රමක්ෂය වනු ඇතැයි අපේක්ෂා කරන අතර එමඟින් හොඳ වේගයක් ලබා ගැනීම සඳහා `addr2line: : සන්දර්භය 'සෑදීමේදී ගොඩනඟන ලද ව්‍යුහයන් උත්තේජනය කරයි.
        //
        // අපට මෙම හැඹිලිය නොතිබුනේ නම්, එම ක්‍රමක්ෂය කිසි විටෙකත් සිදු නොවනු ඇති අතර, පසුපෙළ සංකේතවත් කිරීම ssssllllooooowwww වේ.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // පළමුවෙන්ම, මෙම `lib` හි `addr` (නැවත ස්ථානගත කිරීම හැසිරවීම) අඩංගු කිසියම් අංශයක් තිබේදැයි පරීක්ෂා කරන්න.මෙම චෙක්පත සමත් වුවහොත් අපට පහතින් ඉදිරියට ගොස් ලිපිනය පරිවර්තනය කළ හැකිය.
                //
                // පිටාර ගැලීම් වළක්වා ගැනීම සඳහා අපි මෙහි `wrapping_add` භාවිතා කරන බව සලකන්න.SVMA + නැඹුරුව ගණනය කිරීම පිටාර ගැලීම වනයේ දක්නට ලැබේ.
                // එය සිදුවන්නේ තරමක් අමුතු බවක් පෙනේ, නමුත් අභ්‍යවකාශයට යොමු වීමට ඉඩ ඇති හෙයින් එම කොටස් නොසලකා හැරීම හැරෙන්නට අපට ඒ ගැන කළ හැකි විශාල මුදලක් නොමැත.
                //
                // මෙය මුලින් පැමිණියේ rust-lang/backtrace-rs#329 වලින්.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // දැන් අපි දන්නවා `lib` හි `addr` අඩංගු වන අතර, ප්‍රකාශිත වෛරටල් මතක ලිපිනය සොයා ගැනීමට අපට පක්ෂග්‍රාහීව කටයුතු කළ හැකිය.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // වෙනස් නොවන: මෙම කොන්දේසිය ඉක්මණින් ආපසු නොගෙන සම්පූර්ණ වූ පසු
        // දෝෂයකින්, මෙම මාර්ගය සඳහා හැඹිලි ප්‍රවේශය දර්ශක 0 හි ඇත.

        if let Some(idx) = idx {
            // සිතියම්ගත කිරීම දැනටමත් හැඹිලියේ ඇති විට, එය ඉදිරිපස දෙසට ගෙන යන්න.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // සිතියම්ගත කිරීම හැඹිලියේ නොමැති විට, නව සිතියමක් සාදන්න, එය හැඹිලියේ ඉදිරිපස කොටස තුළට ඇතුළු කරන්න, අවශ්‍ය නම් පැරණිතම හැඹිලි ප්‍රවේශය ඉවත් කරන්න.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // `'static` ජීවිත කාලය කාන්දු නොකරන්න, එය අපට පමණක් සීමා වී ඇති බවට වග බලා ගන්න
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // අවාසනාවකට අපට මෙහි අවශ්‍ය බැවින් `sym` හි ආයු කාලය `'static` දක්වා දීර් කරන්න, නමුත් එය කවදාවත් යොමු කිරීමක් ලෙස පිටතට යන්නේ ඒ නිසා මෙම රාමුවෙන් ඔබ්බට කිසිදු සඳහනක් නොකඩවා පැවතිය යුතුය.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // අවසාන වශයෙන්, හැඹිලි සිතියම්කරණයක් ලබා ගන්න හෝ මෙම ගොනුව සඳහා නව සිතියමක් සාදන්න, මෙම ලිපිනය සඳහා file/line/name සොයා ගැනීමට DWARF තොරතුරු ඇගයීමට ලක් කරන්න.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// මෙම සංකේතය සඳහා රාමු තොරතුරු සොයා ගැනීමට අපට හැකි වූ අතර, `addr2line` හි රාමුවට අභ්‍යන්තරව සියලු අමිහිරි විස්තර ඇත.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// නිදොස් කිරීමේ තොරතුරු සොයාගත නොහැකි විය, නමුත් අපට එය ක්‍රියාත්මක කළ හැකි සංකේත වගුවේ හමු විය.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}