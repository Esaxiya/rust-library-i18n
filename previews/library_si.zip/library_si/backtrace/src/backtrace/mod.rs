use core::ffi::c_void;
use core::fmt;

/// වත්මන් ඇමතුම්-තොගය පරීක්ෂා කරමින්, සියලු ක්‍රියාකාරී රාමු තොග හෝඩුවාවක් ගණනය කිරීම සඳහා සපයා ඇති වසා දැමීම වෙත යොමු කරයි.
///
/// වැඩසටහනක් සඳහා තොග හෝඩුවාවන් ගණනය කිරීමේදී මෙම කාර්යය මෙම පුස්තකාලයේ කාර්ය සාධනය වේ.ලබා දී ඇති වසා දැමීම `cb` යනු `Frame` හි උදාහරණ වන අතර එමඟින් එම ඇමතුම් රාමුව පිළිබඳ තොරතුරු නිරූපණය වේ.
/// වසා දැමීම ඉහළ-පහළ මෝස්තරයකින් රාමු ලබා දෙනු ලැබේ (වඩාත් මෑතකදී ශ්‍රිත ලෙස හැඳින්වේ).
///
/// වසා දැමීමේ ප්‍රතිලාභ අගය බැක්ට්‍රේස් දිගටම පැවතිය යුතුද යන්න පෙන්නුම් කරයි.`false` හි ප්‍රතිලාභ අගය පසුපෙළ අවසන් කර වහාම ආපසු එනු ඇත.
///
/// `Frame` අත්පත් කර ගත් පසු ඔබට `backtrace::resolve` අමතන්න `ip` (උපදෙස් දර්ශකය) හෝ සංකේත ලිපිනය `Symbol` බවට පරිවර්තනය කිරීම සඳහා නම සහ/හෝ ගොනු නාමය/රේඛා අංකය ඉගෙන ගත හැකිය.
///
///
/// මෙය සාපේක්ෂව පහත් මට්ටමේ ශ්‍රිතයක් බව සලකන්න. උදාහරණයක් ලෙස පසුකාලීනව පරීක්ෂා කිරීම සඳහා පසුපෙළක් අල්ලා ගැනීමට ඔබ කැමති නම්, `Backtrace` වර්ගය වඩාත් යෝග්‍ය වේ.
///
/// # අවශ්‍ය අංග
///
/// මෙම ශ්‍රිතයට `backtrace` crate හි `std` විශේෂාංගය සක්‍රීය කිරීම අවශ්‍ය වන අතර `std` විශේෂාංගය පෙරනිමියෙන් සක්‍රීය කර ඇත.
///
/// # Panics
///
/// මෙම ශ්‍රිතය කිසි විටෙකත් panic කිරීමට උත්සාහ නොකරයි, නමුත් `cb` විසින් panics ලබා දුන්නේ නම් සමහර වේදිකා මඟින් ක්‍රියාවලිය නවතා දැමීමට ද්විත්ව panic බල කරනු ඇත.
/// සමහර වේදිකා සී පුස්තකාලයක් භාවිතා කරන අතර එය අභ්‍යන්තරව ඇමතුම් ලබා ගත නොහැකි වන අතර එමඟින් `cb` වෙතින් භීතියට පත්වීම ක්‍රියාවලිය නවතා දැමිය හැකිය.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // පසුපෙළ දිගටම කරගෙන යන්න
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// `trace` හා සමානයි, එය සමමුහුර්ත නොවූ බැවින් අනාරක්ෂිතයි.
///
/// මෙම ශ්‍රිතයට සමමුහුර්ත කිරීමේ සහතික නොමැත, නමුත් මෙම crate හි `std` විශේෂාංගය සම්පාදනය නොකළ විට ලබා ගත හැකිය.
/// තවත් ලියකියවිලි සහ උදාහරණ සඳහා `trace` ශ්‍රිතය බලන්න.
///
/// # Panics
///
/// `cb` භීතිකාව පිළිබඳ අවවාද සඳහා `trace` පිළිබඳ තොරතුරු බලන්න.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// මෙම crate හි `trace` ශ්‍රිතයට යටත් වූ බැක්ට්‍රේස් එකක එක් රාමුවක් නියෝජනය කරන trait.
///
/// ලුහුබැඳීමේ ශ්‍රිතය වැසීමෙන් රාමු ලැබෙනු ඇති අතර, ක්‍රියාත්මක වන තෙක් යටින් ක්‍රියාත්මක කිරීම සැමවිටම නොදන්නා බැවින් රාමුව මුලුමනින්ම පාහේ යවනු ලැබේ.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// මෙම රාමුවේ වත්මන් උපදෙස් දර්ශකය ලබා දෙයි.
    ///
    /// මෙය සාමාන්‍යයෙන් රාමුව තුළ ක්‍රියාත්මක කිරීමට ඊළඟ උපදෙස් වේ, නමුත් සියලු ක්‍රියාත්මක කිරීම් මෙය 100% නිරවද්‍යතාවයෙන් ලැයිස්තුගත නොකරයි (නමුත් එය සාමාන්‍යයෙන් ඉතා ආසන්නයි).
    ///
    ///
    /// සංකේත නාමයක් බවට පත් කිරීම සඳහා මෙම අගය `backtrace::resolve` වෙත යැවීම රෙකමදාරු කරනු ලැබේ.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// මෙම රාමුවේ වත්මන් සිරස් දර්ශකය ලබා දෙයි.
    ///
    /// මෙම රාමුව සඳහා බැකෙන්ඩරයකට තොග දර්ශකය නැවත ලබා ගත නොහැකි වූ විට, ශුන්‍ය දර්ශකයක් ආපසු ලබා දෙනු ලැබේ.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// මෙම ශ්‍රිතයේ රාමුවේ ආරම්භක සංකේත ලිපිනය ලබා දෙයි.
    ///
    /// මෙය `ip` විසින් ආපසු හරවන ලද උපදෙස් දර්ශකය ශ්‍රිතයේ ආරම්භයට පෙරළා එම අගය ලබා දෙයි.
    ///
    /// කෙසේ වෙතත්, සමහර අවස්ථාවලදී, පසුබිම් මඟින් මෙම ශ්‍රිතයෙන් `ip` ආපසු ලබා දෙනු ඇත.
    ///
    /// ඉහත දක්වා ඇති `ip` හි `backtrace::resolve` අසමත් වුවහොත් ආපසු ලබා දුන් අගය සමහර විට භාවිතා කළ හැකිය.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// රාමුවට අයත් මොඩියුලයේ මූලික ලිපිනය ලබා දෙයි.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // සත්කාරක වේදිකාවට වඩා මිරි ප්‍රමුඛතාවය ලබා ගැනීම සහතික කිරීම සඳහා මෙය පළමුව පැමිණිය යුතුය
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // සංකේතවත් කරන්නේ dbghelp හි පමණි
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}