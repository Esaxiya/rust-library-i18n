//! Windows හි dbghelp බන්ධන කළමනාකරණයට සහාය වීමට මොඩියුලයක්
//!
//! Windows හි පසුබිම් (අවම වශයෙන් MSVC සඳහා) බොහෝ දුරට බලගන්වන්නේ `dbghelp.dll` සහ එහි අඩංගු විවිධ කාර්යයන් මගිනි.
//! මෙම කාර්යයන් දැනට `dbghelp.dll` වෙත සංඛ්‍යාත්මකව සම්බන්ධ කරනවාට වඩා *ගතිකව* පටවා ඇත.
//! මෙය දැනට සම්මත පුස්තකාලය විසින් සිදු කරනු ලැබේ (න්‍යාය අනුව එය අවශ්‍ය වේ), නමුත් පසුබිම් සාමාන්‍යයෙන් විකල්පයක් බැවින් පුස්තකාලයක ස්ථිතික ඩීඑල් පරායත්තතාව අඩු කිරීමට උපකාරී වේ.
//!
//! `dbghelp.dll` සෑම විටම පාහේ Windows මත සාර්ථකව පටවනු ලැබේ.
//!
//! අපි මේ සියලු සහය ගතිකව පටවන බැවින් අපට ඇත්ත වශයෙන්ම `winapi` හි අමු නිර්වචන භාවිතා කළ නොහැකි බව සලකන්න, නමුත් අපට අවශ්‍ය වන්නේ ශ්‍රිත දර්ශක වර්ග අප විසින්ම නිර්වචනය කර එය භාවිතා කිරීමයි.
//! විනපි අනුපිටපත් කිරීමේ ව්‍යාපාරයේ නියැලීමට අපට ඇත්ත වශයෙන්ම අවශ්‍ය නැත, එබැවින් අපට Cargo විශේෂාංගයක් ඇත `verify-winapi`, එය සියලු බන්ධන විනපි වලට ගැලපෙන බවත් මෙම අංගය සීඅයි මත සක්‍රීය කර ඇති බවත් සහතික කරයි.
//!
//! අවසාන වශයෙන්, `dbghelp.dll` සඳහා වන ඩීඑල්එල් කිසි විටෙකත් මුදා හරිනු නොලබන බව ඔබ මෙහි සටහන් කරනු ඇත.
//! චින්තනය නම් අපට එය ගෝලීයව හැඹිලිගත කර API වෙත ලැබෙන ඇමතුම් අතර භාවිතා කර මිල අධික loads/unloads වළක්වා ගත හැකිය.
//! මෙය කාන්දුවීම් අනාවරක සඳහා ගැටළුවක් නම් හෝ එවැනි දෙයක් අපට එහි ගිය විට පාලම තරණය කළ හැකිය.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// `SymGetOptions` සහ `SymSetOptions` වටා වැඩ කිරීම විනාපි තුළම නොතිබීම.
// එසේ නොමැතිනම් මෙය භාවිතා කරනුයේ අපි විනාපි වලට එරෙහිව දෙවරක් පරීක්ෂා කරන විට පමණි.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // විනපි හි තවමත් අර්ථ දක්වා නැත
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // මෙය විනාපි වලින් අර්ථ දක්වා ඇත, නමුත් එය වැරදියි (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // විනපි හි තවමත් අර්ථ දක්වා නැත
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// මෙම සාර්ව භාවිතා කරනුයේ අප පැටවිය හැකි සියලුම ක්‍රියාකාරී ලක්ෂ්‍යයන් අභ්‍යන්තරව අඩංගු වන `Dbghelp` ව්‍යුහයක් නිර්වචනය කිරීමට ය.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// `dbghelp.dll` සඳහා පටවන ලද ඩීඑල්එල්
            dll: HMODULE,

            // අප භාවිතා කළ හැකි එක් එක් ශ්‍රිතය සඳහා එක් එක් ශ්‍රිත දර්ශකය
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // මුලදී අපි ඩීඑල්එල් පටවා නැත
            dll: 0 as *mut _,
            // ආරම්භක සියලු කාර්යයන් ගතිකව පැටවිය යුතු යැයි පැවසීමට ශුන්‍යයට සකසා ඇත.
            //
            $($name: 0,)*
        };

        // එක් එක් ශ්‍රිත වර්ගය සඳහා පහසුව යතුරු ලියනය කිරීම.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// `dbghelp.dll` විවෘත කිරීමට උත්සාහ කරයි.
            /// `LoadLibraryW` අසමත් වුවහොත් එය ක්‍රියා කරන්නේ නම් හෝ දෝෂයක් තිබේ නම් සාර්ථකත්වය ලබා දෙයි.
            ///
            /// පුස්තකාලය දැනටමත් පටවා ඇත්නම් Panics.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // අපි භාවිතා කිරීමට කැමති එක් එක් ක්‍රමයේ ක්‍රියාකාරිත්වය.
            // එය අමතන විට එක්කෝ හැඹිලි ශ්‍රිත දර්ශකය කියවනු ඇත, නැතහොත් එය පටවා පැටවූ අගය නැවත ලබා දෙනු ඇත.
            // පැටවීම සාර්ථක බව තහවුරු කර ඇත.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Dbghelp කාර්යයන් යොමු කිරීම සඳහා පිරිසිදු කිරීමේ අගුල් භාවිතා කිරීමට පහසු ප්‍රොක්සිය.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// මෙම crate වෙතින් `dbghelp` API කාර්යයන් වෙත ප්‍රවේශ වීමට අවශ්‍ය සියලු සහාය ආරම්භ කරන්න.
///
///
/// මෙම ශ්‍රිතය **ආරක්ෂිත** බව සලකන්න, එයට අභ්‍යන්තරව එහි සමමුහුර්තතාවයක් ඇත.
/// මෙම ශ්‍රිතය කිහිප වතාවක් පුනරාවර්තනය ලෙස හැඳින්වීම ආරක්ෂිත බව සලකන්න.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // අප කළ යුතු පළමු දෙය නම් මෙම ශ්‍රිතය සමමුහුර්ත කිරීමයි.මෙය වෙනත් නූල් වලින් සමගාමීව හෝ එක් නූල් තුළ පුනරාවර්තන ලෙස හැඳින්විය හැක.
        // එය ඊට වඩා උපක්‍රමශීලී බව සලකන්න, මන්ද අප මෙහි භාවිතා කරන දේ වන `dbghelp`, * ද මෙම ක්‍රියාවලියේදී අනෙක් සියලුම අමතන්නන් සමඟ `dbghelp` වෙත සමමුහුර්ත කළ යුතුය.
        //
        // සාමාන්‍යයෙන් එකම ක්‍රියාවලිය තුළ `dbghelp` වෙත බොහෝ ඇමතුම් නොලැබෙන අතර එයට ප්‍රවේශ වන්නේ අප පමණක් යැයි අපට ආරක්ෂිතව උපකල්පනය කළ හැකිය.
        // කෙසේ වෙතත්, අප ගැන කනස්සල්ලට පත්විය යුතු එක් ප්‍රාථමික වෙනත් පරිශීලකයෙකු සිටී, නමුත් අප උත්ප‍්‍රාසාත්මක ලෙස, නමුත් සම්මත පුස්තකාලයේ.
        // Rust සම්මත පුස්තකාලය බැක්ට්‍රේස් සහාය සඳහා මෙම crate මත රඳා පවතින අතර මෙම crate crates.io මත ද පවතී.
        // මෙයින් අදහස් කරන්නේ සම්මත පුස්තකාලය panic පසුබිමක් මුද්‍රණය කරන්නේ නම් එය crates.io වෙතින් එන මෙම crate සමඟ තරඟ කළ හැකි අතර එමඟින් segfaults ඇතිවිය හැකි බවයි.
        //
        // මෙම සමමුහුර්තකරණ ගැටළුව විසඳීම සඳහා අපි මෙහි වින්ඩෝස් විශේෂිත උපක්‍රමයක් භාවිතා කරමු (එය සමමුහුර්තකරණය පිළිබඳ වින්ඩෝස් විශේෂිත සීමාවක් වේ).
        // මෙම ඇමතුම ආරක්ෂා කිරීම සඳහා අපි *සැසි-දේශීය* mutex නමින් නිර්මාණය කරමු.
        // මෙහි අභිප්‍රාය වන්නේ සම්මත පුස්තකාලය සහ මෙම crate මෙහි සමමුහුර්ත කිරීම සඳහා Rust මට්ටමේ API බෙදා ගත යුතු නැති නමුත් තිරය පිටුපස ක්‍රියා කර ඒවා එකිනෙකා සමඟ සමමුහුර්ත වන බවට වග බලා ගැනීමයි.
        //
        // මේ ආකාරයෙන් මෙම කාර්යය සම්මත පුස්තකාලය හරහා හෝ crates.io හරහා කැඳවූ විට එකම mutex ලබා ගන්නා බවට අපට සහතික විය හැකිය.
        //
        // ඉතින් මේ සියල්ලෙන් කියැවෙන්නේ අප මෙහි කරන පළමු දෙය වන්නේ අපි පරමාණුකව `HANDLE` නිර්මාණය කිරීමයි, එය Windows හි නම් කරන ලද mutex ය.
        // මෙම ශ්‍රිතය විශේෂයෙන් බෙදාගන්නා වෙනත් නූල් සමඟ අපි ටිකක් සමමුහුර්ත කරන අතර මෙම ශ්‍රිතයේ එක් අවස්ථාවකට එක් හසුරුවක් පමණක් නිර්මාණය කර ඇති බව සහතික කරමු.
        // හසුරුව ගෝලීයව ගබඩා කළ පසු එය කිසි විටෙකත් වසා නොමැති බව සලකන්න.
        //
        // අපි ඇත්ත වශයෙන්ම අගුලට ගිය පසු අපි එය අත්පත් කර ගනිමු, තවද අප විසින් භාර දෙන අපගේ `Init` හසුරුව අවසානයේ එය අතහැර දැමීමට වගකිව යුතුය.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // හරි, පියු!දැන් අපි සියල්ලෝම ආරක්ෂිතව සමමුහුර්ත කර ඇති නිසා, ඇත්ත වශයෙන්ම සියල්ල සැකසීමට පටන් ගනිමු.
        // පළමුවෙන්ම මෙම ක්‍රියාවලියේදී `dbghelp.dll` සැබවින්ම පටවා ඇති බව සහතික කළ යුතුය.
        // ස්ථිතික යැපීමක් වළක්වා ගැනීම සඳහා අපි මෙය ගතිකව කරන්නෙමු.
        // මෙය histor තිහාසිකව සිදු කර ඇත්තේ අමුතු සම්බන්ධක ගැටළු විසඳීම සඳහා වන අතර ද්විමය තව ටිකක් අතේ ගෙන යා හැකි ය. මෙය බොහෝ දුරට නිදොස් කිරීමේ උපයෝගීතාවයක් වන හෙයිනි.
        //
        //
        // අපි `dbghelp.dll` විවෘත කළ පසු එහි ආරම්භක කාර්යයන් කිහිපයක් ඇමතිය යුතුය, එය වඩාත් විස්තරාත්මකව පහතින්.
        // අපි මෙය කරන්නේ එක් වරක් පමණි, නමුත් අපට ගෝලීය බූලියන් ලැබී ඇත්තේ අප තවම ඉවරද නැද්ද යන්න දක්වයි.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // `SYMOPT_DEFERRED_LOADS` ධජය සකසා ඇති බවට සහතික වන්න, මන්ද මේ පිළිබඳව MSVC හි ලියකියවිලි වලට අනුව: "This is the fastest, most efficient way to use the symbol handler.", එබැවින් අපි එය කරමු!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // MSVC සමඟ සංකේත ආරම්භ කරන්න.මෙය අසාර්ථක විය හැකි බව සලකන්න, නමුත් අපි එය නොසලකා හරිමු.
        // මේ සඳහා පෙර කලාව ටොන් ගණනක් නොමැත, නමුත් එල්එල්වීඑම් අභ්‍යන්තරව මෙහි ප්‍රතිලාභ වටිනාකම නොසලකා හරින බවක් පෙනෙන්නට ඇති අතර එල්එල්වීඑම් හි සනීපාරක්ෂක පුස්තකාලයක් මෙය අසමත් වුව ද එය දිගු කාලීනව නොසලකා හැරියහොත් බිය උපදවන අනතුරු ඇඟවීමක් මුද්‍රණය කරයි.
        //
        //
        // Rust සඳහා මෙය බොහෝ දේ ඉදිරිපත් වන එක් කරුණක් නම් සම්මත පුස්තකාලය සහ crates.io හි මෙම crate යන දෙකම `SymInitializeW` සඳහා තරඟ කිරීමට අවශ්‍ය වීමයි.
        // සම්මත පුස්තකාලයට histor තිහාසිකව අවශ්‍ය වූයේ බොහෝ විට පිරිසිදු කිරීම ආරම්භ කිරීමට ය, නමුත් දැන් එය මෙම crate භාවිතා කරන බැවින් එයින් අදහස් කරන්නේ යමෙකු මුලින් ආරම්භයට පැමිණෙනු ඇති අතර අනෙකා එම ආරම්භය ලබා ගනී.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}