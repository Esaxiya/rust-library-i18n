//! වේදිකාව මත යැපෙන වර්ග.

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// වේදිකාවක ස්වාධීන නිරූපණයකි.
/// `std` සක්‍රීය කර ඇති විට වැඩ කරන විට `std` වර්ග සඳහා පරිවර්තන සැපයීම සඳහා පහසුව සඳහා ක්‍රම නිර්දේශ කරනු ලැබේ.
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// පෙත්තක්, සාමාන්‍යයෙන් Unix වේදිකාවල සපයනු ලැබේ.
    Bytes(&'a [u8]),
    /// පුළුල් නූල් සාමාන්‍යයෙන් Windows වෙතින්.
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// පාඩු `Cow<str>` බවට පරිවර්තනය වේ, `Bytes` වලංගු නොවන UTF-8 හෝ `BytesOrWideString` `Wide` නම් වෙන් කරනු ලැබේ.
    ///
    /// # අවශ්‍ය අංග
    ///
    /// මෙම ශ්‍රිතයට `backtrace` crate හි `std` විශේෂාංගය සක්‍රීය කිරීම අවශ්‍ය වන අතර `std` විශේෂාංගය පෙරනිමියෙන් සක්‍රීය කර ඇත.
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// `BytesOrWideString` හි `Path` නිරූපණයක් සපයයි.
    ///
    /// # අවශ්‍ය අංග
    ///
    /// මෙම ශ්‍රිතයට `backtrace` crate හි `std` විශේෂාංගය සක්‍රීය කිරීම අවශ්‍ය වන අතර `std` විශේෂාංගය පෙරනිමියෙන් සක්‍රීය කර ඇත.
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}