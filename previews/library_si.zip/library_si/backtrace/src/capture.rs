use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// අයිති සහ ස්වයං අන්තර්ගත පසුබිමක් නියෝජනය කිරීම.
///
/// මෙම ව්‍යුහය මඟින් වැඩසටහනක විවිධ ස්ථානවල බැක්ට්‍රේස් ග්‍රහණය කර ගත හැකි අතර පසුව එකල බැක්ට්‍රේස් එක කුමක්දැයි පරීක්ෂා කිරීමට භාවිතා කළ හැකිය.
///
///
/// `Backtrace` එහි `Debug` ක්‍රියාත්මක කිරීම හරහා පසුපෙළ මුද්‍රණය කිරීමට සහාය වේ.
///
/// # අවශ්‍ය අංග
///
/// මෙම ශ්‍රිතයට `backtrace` crate හි `std` විශේෂාංගය සක්‍රීය කිරීම අවශ්‍ය වන අතර `std` විශේෂාංගය පෙරනිමියෙන් සක්‍රීය කර ඇත.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // මෙහි රාමු තොගයේ ඉහළ සිට පහළට ලැයිස්තුගත කර ඇත
    frames: Vec<BacktraceFrame>,
    // `Backtrace::new` සහ `backtrace::trace` වැනි රාමු මඟ හැර, පසුපෙළේ සත්‍ය ආරම්භය යැයි අප විශ්වාස කරන දර්ශකය.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// පසුබිමක රාමුවක ග්‍රහණය කරගත් අනුවාදය.
///
/// මෙම වර්ගය `Backtrace::frames` වෙතින් ලැයිස්තුවක් ලෙස ආපසු ලබා දෙන අතර අල්ලා ගත් පසුබිමක එක් සිරස් රාමුවක් නියෝජනය කරයි.
///
/// # අවශ්‍ය අංග
///
/// මෙම ශ්‍රිතයට `backtrace` crate හි `std` විශේෂාංගය සක්‍රීය කිරීම අවශ්‍ය වන අතර `std` විශේෂාංගය පෙරනිමියෙන් සක්‍රීය කර ඇත.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// පසුබිමක සංකේතයක ග්‍රහණය කරගත් අනුවාදය.
///
/// මෙම වර්ගය `BacktraceFrame::symbols` වෙතින් ලැයිස්තුවක් ලෙස ආපසු ලබා දෙන අතර පසුබිමක සංකේතයක් සඳහා පාර-දත්ත නිරූපණය කරයි.
///
/// # අවශ්‍ය අංග
///
/// මෙම ශ්‍රිතයට `backtrace` crate හි `std` විශේෂාංගය සක්‍රීය කිරීම අවශ්‍ය වන අතර `std` විශේෂාංගය පෙරනිමියෙන් සක්‍රීය කර ඇත.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// මෙම ශ්‍රිතයේ ඇමතුම් අඩවියේ බැක්ට්‍රේස් එකක් ග්‍රහණය කරගනිමින්, හිමිකමක් නිරූපණය කරයි.
    ///
    /// Rust හි පසුබිමක් වස්තුවක් ලෙස නිරූපණය කිරීම සඳහා මෙම ශ්‍රිතය ප්‍රයෝජනවත් වේ.මෙම ආපසු ලබා දුන් අගය නූල් හරහා යවා වෙනත් තැනක මුද්‍රණය කළ හැකි අතර, මෙම අගයේ අරමුණ මුළුමනින්ම ස්වයං අන්තර්ගත වීමයි.
    ///
    /// සමහර වේදිකාවල සම්පූර්ණ පසුබිමක් ලබාගෙන එය විසඳීම අතිශයින්ම මිල අධික විය හැකි බව සලකන්න.
    /// ඔබගේ යෙදුම සඳහා පිරිවැය ඕනෑවට වඩා වැඩි නම්, ඒ වෙනුවට `Backtrace::new_unresolved()` භාවිතා කිරීම රෙකමදාරු කරනු ලබන අතර එය සංකේත විභේදන පියවර මඟහරියි (සාමාන්‍යයෙන් දීර් long තම කාලය ගතවේ) එය පසු දිනකට කල් දැමීමට ඉඩ දෙයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # අවශ්‍ය අංග
    ///
    /// මෙම ශ්‍රිතයට `backtrace` crate හි `std` විශේෂාංගය සක්‍රීය කිරීම අවශ්‍ය වන අතර `std` විශේෂාංගය පෙරනිමියෙන් සක්‍රීය කර ඇත.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // ඉවත් කිරීමට මෙහි රාමුවක් ඇති බවට වග බලා ගැනීමට අවශ්‍යයි
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// `new` හා සමාන වන අතර මෙය කිසිදු සංකේතයක් නිරාකරණය නොකරන බව හැර, මෙය හුදෙක් පසුතලය ලිපින ලැයිස්තුවක් ලෙස ග්‍රහණය කරයි.
    ///
    /// පසුකාලීනව `resolve` ශ්‍රිතය මෙම පසුබිමේ සංකේත කියවිය හැකි නම් වලට නිරාකරණය කිරීම සඳහා කැඳවිය හැකිය.
    /// මෙම ශ්‍රිතය පවතින්නේ විභේදන ක්‍රියාවලියට ඇතැම් විට සැලකිය යුතු කාලයක් ගත විය හැකි අතර ඕනෑම එක් පසුබිමක් මුද්‍රණය කළ හැක්කේ කලාතුරකිනි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // සංකේත නම් නොමැත
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // සංකේත නම් දැන් ඇත
    /// ```
    ///
    /// # අවශ්‍ය අංග
    ///
    /// මෙම ශ්‍රිතයට `backtrace` crate හි `std` විශේෂාංගය සක්‍රීය කිරීම අවශ්‍ය වන අතර `std` විශේෂාංගය පෙරනිමියෙන් සක්‍රීය කර ඇත.
    ///
    ///
    ///
    #[inline(never)] // ඉවත් කිරීමට මෙහි රාමුවක් ඇති බවට වග බලා ගැනීමට අවශ්‍යයි
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// මෙම පසුබිම අල්ලා ගත් අවස්ථාවේ සිට රාමු ලබා දෙයි.
    ///
    /// මෙම පෙත්තෙහි පළමු පිවිසුම `Backtrace::new` ශ්‍රිතය විය හැකි අතර අවසාන රාමුව මෙම නූල් හෝ ප්‍රධාන ශ්‍රිතය ආරම්භ වූ ආකාරය ගැන විය හැකිය.
    ///
    ///
    /// # අවශ්‍ය අංග
    ///
    /// මෙම ශ්‍රිතයට `backtrace` crate හි `std` විශේෂාංගය සක්‍රීය කිරීම අවශ්‍ය වන අතර `std` විශේෂාංගය පෙරනිමියෙන් සක්‍රීය කර ඇත.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// මෙම පසුපෙළ `new_unresolved` වෙතින් නිර්මාණය කර ඇත්නම්, මෙම ශ්‍රිතය පසුපස කොටසේ ඇති සියලුම ලිපින ඒවායේ සංකේතාත්මක නම් වලට විසඳනු ඇත.
    ///
    ///
    /// මෙම පසුබිම කලින් විසඳා ඇත්නම් හෝ `new` හරහා නිර්මාණය කර ඇත්නම්, මෙම ශ්‍රිතය කිසිවක් නොකරයි.
    ///
    /// # අවශ්‍ය අංග
    ///
    /// මෙම ශ්‍රිතයට `backtrace` crate හි `std` විශේෂාංගය සක්‍රීය කිරීම අවශ්‍ය වන අතර `std` විශේෂාංගය පෙරනිමියෙන් සක්‍රීය කර ඇත.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// `Frame::ip` හා සමානයි
    ///
    /// # අවශ්‍ය අංග
    ///
    /// මෙම ශ්‍රිතයට `backtrace` crate හි `std` විශේෂාංගය සක්‍රීය කිරීම අවශ්‍ය වන අතර `std` විශේෂාංගය පෙරනිමියෙන් සක්‍රීය කර ඇත.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// `Frame::symbol_address` හා සමානයි
    ///
    /// # අවශ්‍ය අංග
    ///
    /// මෙම ශ්‍රිතයට `backtrace` crate හි `std` විශේෂාංගය සක්‍රීය කිරීම අවශ්‍ය වන අතර `std` විශේෂාංගය පෙරනිමියෙන් සක්‍රීය කර ඇත.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// `Frame::module_base_address` හා සමානයි
    ///
    /// # අවශ්‍ය අංග
    ///
    /// මෙම ශ්‍රිතයට `backtrace` crate හි `std` විශේෂාංගය සක්‍රීය කිරීම අවශ්‍ය වන අතර `std` විශේෂාංගය පෙරනිමියෙන් සක්‍රීය කර ඇත.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// මෙම රාමුවට අනුරූප වන සංකේත ලැයිස්තුව ලබා දෙයි.
    ///
    /// සාමාන්‍යයෙන් ඇත්තේ එක් රාමුවකට එක් සංකේතයක් පමණි, නමුත් සමහර විට ශ්‍රිත ගණනාවක් එක් රාමුවකට නැඹුරු වුවහොත් බහු සංකේත නැවත ලැබෙනු ඇත.
    /// ලැයිස්තුගත කර ඇති පළමු සංකේතය "innermost function" වන අතර අවසාන සංකේතය පිටත කෙළවර (අවසාන අමතන්නා) වේ.
    ///
    /// මෙම රාමුව නොවිසඳුනු පසුබිමකින් පැමිණියේ නම් මෙය හිස් ලැයිස්තුවක් ලබා දෙන බව සලකන්න.
    ///
    /// # අවශ්‍ය අංග
    ///
    /// මෙම ශ්‍රිතයට `backtrace` crate හි `std` විශේෂාංගය සක්‍රීය කිරීම අවශ්‍ය වන අතර `std` විශේෂාංගය පෙරනිමියෙන් සක්‍රීය කර ඇත.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// `Symbol::name` හා සමානයි
    ///
    /// # අවශ්‍ය අංග
    ///
    /// මෙම ශ්‍රිතයට `backtrace` crate හි `std` විශේෂාංගය සක්‍රීය කිරීම අවශ්‍ය වන අතර `std` විශේෂාංගය පෙරනිමියෙන් සක්‍රීය කර ඇත.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// `Symbol::addr` හා සමානයි
    ///
    /// # අවශ්‍ය අංග
    ///
    /// මෙම ශ්‍රිතයට `backtrace` crate හි `std` විශේෂාංගය සක්‍රීය කිරීම අවශ්‍ය වන අතර `std` විශේෂාංගය පෙරනිමියෙන් සක්‍රීය කර ඇත.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// `Symbol::filename` හා සමානයි
    ///
    /// # අවශ්‍ය අංග
    ///
    /// මෙම ශ්‍රිතයට `backtrace` crate හි `std` විශේෂාංගය සක්‍රීය කිරීම අවශ්‍ය වන අතර `std` විශේෂාංගය පෙරනිමියෙන් සක්‍රීය කර ඇත.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// `Symbol::lineno` හා සමානයි
    ///
    /// # අවශ්‍ය අංග
    ///
    /// මෙම ශ්‍රිතයට `backtrace` crate හි `std` විශේෂාංගය සක්‍රීය කිරීම අවශ්‍ය වන අතර `std` විශේෂාංගය පෙරනිමියෙන් සක්‍රීය කර ඇත.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// `Symbol::colno` හා සමානයි
    ///
    /// # අවශ්‍ය අංග
    ///
    /// මෙම ශ්‍රිතයට `backtrace` crate හි `std` විශේෂාංගය සක්‍රීය කිරීම අවශ්‍ය වන අතර `std` විශේෂාංගය පෙරනිමියෙන් සක්‍රීය කර ඇත.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // මාර්ග මුද්‍රණය කිරීමේදී අපි cwd පවතින්නේ නම් එය ඉවත් කිරීමට උත්සාහ කරමු, එසේ නොමැති නම් අපි මාර්ගය මුද්‍රණය කරන්නෙමු.
        // අප මෙය කරන්නේ කෙටි ආකෘතිය සඳහා පමණක් බව සලකන්න, මන්ද එය පිරී තිබේ නම් අපට සියල්ල මුද්‍රණය කිරීමට අවශ්‍ය වනු ඇත.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}