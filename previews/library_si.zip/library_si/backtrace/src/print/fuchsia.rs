use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr ඇමතුමක් ලබා ගන්නා අතර එමඟින් ක්‍රියාවලියට සම්බන්ධ කර ඇති සෑම DSO සඳහාම dl_phdr_info දර්ශකයක් ලැබෙනු ඇත.
    // dl_iterate_phdr ද ගතික සම්බන්ධකය ආරම්භයේ සිට අවසානය දක්වා අගුලු දමා ඇති බව සහතික කරයි.
    // ඇමතුම ආපසු ශුන්‍ය නොවන අගයක් ලබා දෙන්නේ නම් නැවත නැවත කිරීම අවසන් වේ.
    // 'data' සෑම ඇමතුමකම ඇමතුමට තුන්වන තර්කය ලෙස සම්මත වේ.
    // 'size' dl_phdr_info හි ප්‍රමාණය ලබා දෙයි.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// අපට බිල්ඩ් හැඳුනුම්පත සහ මූලික වැඩසටහන් ශීර්ෂ දත්ත විග්‍රහ කිරීමට අවශ්‍ය වන අතර එයින් අදහස් කරන්නේ අපට ඊඑල්එෆ් පිරිවිතරයෙන් ටිකක් අවශ්‍ය බවයි.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// දැන් අපට ෆුචියා හි වත්මන් ගතික සම්බන්ධකය භාවිතා කරන dl_phdr_info වර්ගයේ ව්‍යුහය නැවත නැවත කිරීමට සිදුවේ.
// ක්‍රෝමියම් සතුව මෙම ABI මායිම මෙන්ම ක්‍රෑෂ් පෑඩ් ද ඇත.
// අවසානයේදී අපි මෙම අවස්ථා elf-search භාවිතා කිරීම සඳහා ගෙනයාමට කැමතියි, නමුත් අපට එය SDK හි සැපයිය යුතු අතර එය තවමත් සිදු කර නොමැත.
//
// මේ අනුව, අපි (සහ ඔවුන්) ෆුචියා ලිබ්සී සමඟ තදින් සම්බන්ධ වන මෙම ක්‍රමය භාවිතා කිරීම නිසා හිර වී සිටිමු.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // E_phoff සහ e_phnum වලංගු දැයි පරීක්ෂා කිරීමට අපට ක්‍රමයක් නොමැත.
    // කෙසේ වෙතත් libc අපට මෙය සහතික කළ යුතුය, එබැවින් මෙහි පෙත්තක් සෑදීම ආරක්ෂිත වේ.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr ඉලක්කගත ගෘහ නිර්මාණ ශිල්පයේ අවසානයෙහි 64-bit ELF වැඩසටහන් ශීර්ෂයක් නියෝජනය කරයි.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr වලංගු ELF වැඩසටහන් ශීර්ෂයක් සහ එහි අන්තර්ගතය නියෝජනය කරයි.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // P_addr හෝ p_memsz වලංගු දැයි පරීක්ෂා කිරීමට අපට ක්‍රමයක් නොමැත.
    // ෆුචියා හි ලිබ්සී විසින් පළමුව සටහන් විග්‍රහ කරයි, කෙසේ වෙතත් මෙහි සිටීම නිසා මෙම ශීර්ෂ වලංගු විය යුතුය.
    //
    // NoteIter යටින් පවතින දත්ත වලංගු වීමට අවශ්‍ය නොවන නමුත් එයට සීමාවන් වලංගු විය යුතුය.
    // මෙහි දී අපට මෙය සිදුවිය හැකි බව libc විසින් සහතික කර ඇති බව අපි විශ්වාස කරමු.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// හැඳුනුම්පත් තැනීම සඳහා සටහන් වර්ගය.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr ඉලක්කයේ අවසානයෙහි ELF සටහන් ශීර්ෂයක් නියෝජනය කරයි.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// සටහන ELF සටහනක් නියෝජනය කරයි (ශීර්ෂකය + අන්තර්ගතය).
// නම u8 පෙත්තක් ලෙස ඉතිරිව ඇත්තේ එය සැමවිටම අහෝසි නොවන නිසා සහ rust මඟින් බයිට් කෙසේ හෝ ගැලපේදැයි පරීක්ෂා කිරීමට තරම් පහසු වන බැවිනි.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// නෝට්ඉටර් ඔබට නෝට්ටුවක් හරහා ආරක්ෂිතව නැවත යෙදීමට ඉඩ දෙයි.
// දෝෂයක් ඇති වූ වහාම හෝ තවත් සටහන් නොමැති විට එය අවසන් වේ.
// ඔබ අවලංගු දත්ත හරහා නැවත කියන්නේ නම් එය සටහන් කිසිවක් සොයාගත නොහැකි ලෙස ක්‍රියා කරයි.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // ලබා දී ඇති දර්ශකය සහ ප්‍රමාණය මඟින් කියවිය හැකි වලංගු බයිට් පරාසයක් දක්වයි.
    // මෙම බයිට් වල අන්තර්ගතය ඕනෑම දෙයක් විය හැකි නමුත් මෙය ආරක්ෂිත වීමට පරාසය වලංගු විය යුතුය.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to 'x' 2 ට බලයක් යැයි උපකල්පනය කරමින් 'x' 'to'-byte පෙළගැස්මට පෙළගස්වයි.
// මෙය (x + to, 1) සහ -to භාවිතා කරන C/C ++ ELF විග්‍රහ කිරීමේ කේතයේ සම්මත රටාවක් අනුගමනය කරයි.
// Rust ඔබට භාවිතා කිරීම ප්‍රතික්ෂේප කිරීමට ඉඩ නොදේ, එබැවින් මම භාවිතා කරමි
// එය ප්‍රතිනිර්මාණය කිරීම සඳහා 2 හි අනුපූරක පරිවර්තනය.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 පෙත්තෙන් අංක බයිට් පරිභෝජනය කරයි (තිබේ නම්) සහ අවසාන පෙත්ත නිසි ලෙස පෙලගැසී ඇති බව සහතික කරයි.
// ඉල්ලුම් කරන ලද බයිට් ගණන ඉතා විශාල නම් හෝ දැනට ඉතිරිව ඇති බයිට් ප්‍රමාණවත් නොවීම නිසා පෙත්ත යථා තත්වයට පත් කළ නොහැකි නම්, කිසිවක් ආපසු නොදෙන අතර පෙත්ත වෙනස් කර නොමැත.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// මෙම ශ්‍රිතයට සැබෑ වෙනස්වීම් නොමැත, සමහර විට ඇමතුම්කරු විසින් 'bytes' ක්‍රියාකාරීත්වය සඳහා පෙළ ගැස්විය යුතුය (සහ සමහර ගෘහ නිර්මාණ වල නිරවද්‍යතාව) හැරෙන්නට.
// Elf_Nhdr ක්ෂේත්‍රවල අගයන් විකාර විය හැකි නමුත් මෙම ශ්‍රිතය එවැනි දෙයක් සහතික නොකරයි.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // ප්‍රමාණවත් ඉඩක් ඇති තාක් කල් මෙය ආරක්ෂිත වන අතර ඉහත ප්‍රකාශයේ නම් මෙය අනාරක්ෂිත නොවිය යුතු බව අපි තහවුරු කළෙමු.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Sice_of: :<Elf_Nhdr>() සෑම විටම බයිට් 4 ක් පෙළගස්වා ඇත.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // අපි අවසානයට පැමිණ ඇත්දැයි පරීක්ෂා කරන්න.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // අපි nhdr එකක් සම්ප්‍රේෂණය කරන නමුත් එහි ප්‍රති struct ලයක් ලෙස ඇති වන ව්‍යුහය අපි ප්‍රවේශමෙන් සලකා බලමු.
        // අපි namesz හෝ descsz විශ්වාස නොකරන අතර වර්ගය මත පදනම්ව අපි අනාරක්ෂිත තීරණ ගන්නේ නැත.
        //
        // ඒ නිසා අපි සම්පූර්ණ කුණු කසළ ඉවත් කළත් අපි තවමත් ආරක්ෂිත විය යුතුයි.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// ඛණ්ඩයක් ක්‍රියාත්මක කළ හැකි බව දක්වයි.
const PERM_X: u32 = 0b00000001;
/// කොටසක් ලිවිය හැකි බව දක්වයි.
const PERM_W: u32 = 0b00000010;
/// කොටසක් කියවිය හැකි බව දක්වයි.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// ධාවන වේලාවේදී ELF අංශයක් නියෝජනය කරයි.
struct Segment {
    /// මෙම කොටසේ අන්තර්ගතයේ ධාවන අථත්‍ය ලිපිනය ලබා දෙයි.
    addr: usize,
    /// මෙම කොටසේ අන්තර්ගතයේ මතක ප්‍රමාණය ලබා දෙයි.
    size: usize,
    /// ELF ගොනුව සමඟ මෙම කොටසේ මොඩියුලය අතථ්‍ය ලිපිනය ලබා දෙයි.
    mod_rel_addr: usize,
    /// ELF ගොනුවේ ඇති අවසර ලබා දෙයි.
    /// කෙසේ වෙතත් මෙම අවසරයන් අනිවාර්යයෙන්ම ධාවන වේලාවේ පවතින අවසරයන් නොවේ.
    flags: Perm,
}

/// ඩී.එස්.ඕ වෙතින් එක් අංශයක් හරහා නැවත කියවීමට ඉඩ දෙන්න.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// ELF DSO (ගතික හවුල් වස්තුව) නියෝජනය කරයි.
/// මෙම වර්ගය එහි පිටපතක් සෑදීමට වඩා සත්‍ය ඩීඑස්ඕ තුළ ගබඩා කර ඇති දත්ත සඳහන් කරයි.
struct Dso<'a> {
    /// නම හිස් වුවද ගතික සම්බන්ධකය සෑම විටම අපට නමක් ලබා දෙයි.
    /// ප්‍රධාන ක්‍රියාත්මක කළ හැකි අවස්ථාවකදී මෙම නම හිස් වනු ඇත.
    /// හවුල් වස්තුවක නම් එය soname වේ (DT_SONAME බලන්න).
    name: &'a str,
    /// ෆුචියා හි සෑම ද්විමයකම පාහේ හැඳුනුම්පත් ඇති නමුත් මෙය දැඩි අවශ්‍යතාවයක් නොවේ.
    /// බිල්ඩ්_අයිඩී නොමැති නම් ඩීඑස්ඕ තොරතුරු සැබෑ ඊඑල්එෆ් ගොනුවක් සමඟ ගැලපීමට ක්‍රමයක් නොමැත, එබැවින් සෑම ඩීඑස්ඕ එකකටම එකක් තිබිය යුතුය.
    ///
    /// බිල්ඩ්_අයිඩී නොමැතිව ඩීඑස්ඕ නොසලකා හරිනු ලැබේ.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// මෙම ඩී.එස්.ඕ හි කොටස් වලට අනුකාරකයක් ලබා දෙයි.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// මෙම දෝෂයන් එක් එක් DSO පිළිබඳ තොරතුරු විග්‍රහ කිරීමේදී මතු වන ගැටළු සංකේතවත් කරයි.
///
enum Error {
    /// NameError යන්නෙන් අදහස් කරන්නේ සී ස්ටයිල් නූල් rust නූලක් බවට පරිවර්තනය කිරීමේදී දෝෂයක් ඇති වූ බවයි.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError යන්නෙන් අදහස් කරන්නේ අපට බිල්ඩ් හැඳුනුම්පතක් හමු නොවූ බවයි.
    /// මෙය විය හැක්කේ ඩී.එස්.ඕ සතුව බිල්ඩ් හැඳුනුම්පතක් නොමැති නිසා හෝ බිල්ඩ් හැඳුනුම්පත අඩංගු කොටස අක්‍රීය වූ නිසා විය හැකිය.
    ///
    BuildIDError,
}

/// ගතික සම්බන්ධකය මඟින් ක්‍රියාවලියට සම්බන්ධ කර ඇති එක් එක් DSO සඳහා 'dso' හෝ 'error' අමතන්න.
///
///
/// # Arguments
///
/// * `visitor` - Foreach DSO නමින් හැඳින්වෙන ආහාර ගැනීමේ ක්‍රමයක් ඇති DsoPrinter.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr info.name වලංගු ස්ථානයකට යොමු වන බව සහතික කරයි.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// මෙම ශ්‍රිතය ඩීඑස්ඕ හි අඩංගු සියලුම තොරතුරු සඳහා ෆුචියා සංකේතකාරක සලකුණු මුද්‍රණය කරයි.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}