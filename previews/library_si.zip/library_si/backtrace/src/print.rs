#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// පසුපෙළ සඳහා ආකෘතිකරණය.
///
/// බැක්ට්‍රේස් එක පැමිණෙන්නේ කොතැනින්ද යන්න නොසලකා බැක්ට්‍රේස් මුද්‍රණය කිරීමට මෙම වර්ගය භාවිතා කළ හැකිය.
/// ඔබ සතුව `Backtrace` වර්ගයක් තිබේ නම් එහි `Debug` ක්‍රියාත්මක කිරීම දැනටමත් මෙම මුද්‍රණ ආකෘතිය භාවිතා කරයි.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// අපට මුද්‍රණය කළ හැකි මුද්‍රණ ශෛලීන්
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// අදාළ තොරතුරු පමණක් අඩංගු වන ටර්සර් පසුබිමක් මුද්‍රණය කරයි
    Short,
    /// හැකි සෑම තොරතුරක්ම අඩංගු පසුබිමක් මුද්‍රණය කරයි
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// නව `BacktraceFmt` සාදන්න, එය සපයා ඇති `fmt` වෙත ප්‍රතිදානය ලියනු ඇත.
    ///
    /// `format` තර්කය මඟින් බැක්ට්‍රේස් මුද්‍රණය කරන විලාසය පාලනය කරනු ඇති අතර, `print_path` තර්කය ගොනු නාමවල `BytesOrWideString` අවස්ථා මුද්‍රණය කිරීමට යොදා ගනී.
    /// මෙම වර්ගයම ගොනු නාම මුද්‍රණය කිරීමක් නොකරයි, නමුත් එසේ කිරීමට මෙම ඇමතුම අවශ්‍ය වේ.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// පසුපෙළ මුද්‍රණය කිරීමට පෙරවදනක් මුද්‍රණය කරයි.
    ///
    /// පසුපෙළ පසුකාලීනව සම්පුර්ණයෙන්ම සංකේතවත් කිරීම සඳහා මෙය සමහර වේදිකාවල අවශ්‍ය වේ, එසේ නොමැතිනම් මෙය `BacktraceFmt` නිර්මාණය කිරීමෙන් පසු ඔබ අමතන පළමු ක්‍රමය විය යුතුය.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// පසුගාමී නිමැවුමට රාමුවක් එක් කරයි.
    ///
    /// මෙම කැපවීම මඟින් රාමුවක් මුද්‍රණය කිරීම සඳහා භාවිතා කළ හැකි `BacktraceFrameFmt` හි RAII නිදසුනක් ලබා දෙන අතර විනාශයේදී එය රාමු කවුන්ටරය වැඩි කරයි.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// බැක්ට්‍රේස් ප්‍රතිදානය සම්පූර්ණ කරයි.
    ///
    /// මෙය දැනට විකල්පයක් නොවන නමුත් පසුගාමී ආකෘති සමඟ future අනුකූලතාව සඳහා එකතු කර ඇත.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // future එකතු කිරීම් සඳහා ඉඩ ලබා දීම සඳහා මෙම hook ද ඇතුළුව දැනට කිසිදු විකල්පයක් නොමැත.
        Ok(())
    }
}

/// බැක්ට්රේස් එක රාමුවක් සඳහා ආකෘතිකරණය.
///
/// මෙම වර්ගය නිර්මාණය කර ඇත්තේ `BacktraceFmt::frame` ශ්‍රිතයෙනි.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// මෙම රාමු ආකෘතිය සමඟ `BacktraceFrame` මුද්‍රණය කරයි.
    ///
    /// මෙය `BacktraceFrame` තුළ ඇති සියලුම `BacktraceSymbol` අවස්ථා පුනරාවර්තනය කරයි.
    ///
    /// # අවශ්‍ය අංග
    ///
    /// මෙම ශ්‍රිතයට `backtrace` crate හි `std` විශේෂාංගය සක්‍රීය කිරීම අවශ්‍ය වන අතර `std` විශේෂාංගය පෙරනිමියෙන් සක්‍රීය කර ඇත.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// `BacktraceFrame` තුළ `BacktraceSymbol` මුද්‍රණය කරයි.
    ///
    /// # අවශ්‍ය අංග
    ///
    /// මෙම ශ්‍රිතයට `backtrace` crate හි `std` විශේෂාංගය සක්‍රීය කිරීම අවශ්‍ය වන අතර `std` විශේෂාංගය පෙරනිමියෙන් සක්‍රීය කර ඇත.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: අපි කිසිවක් මුද්‍රණය කිරීම අවසන් නොකිරීම මෙය හොඳ දෙයක් නොවේ
            // utf8 නොවන ගොනු නාම සමඟ.
            // ස්තුතිවන්ත වන්න සෑම දෙයක්ම පාහේ utf8 බැවින් මෙය එතරම් නරක නොවිය යුතුය.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// සාමාන්‍යයෙන් මෙම crate හි අමු ඇමතුම් ලබා ගැනීමේදී අමු සොයාගත් `Frame` සහ `Symbol` මුද්‍රණය කරයි.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// පසුගාමී නිමැවුමට අමු රාමුවක් එක් කරයි.
    ///
    /// මෙම ක්‍රමය, පෙර පැවති ක්‍රමයට වඩා වෙනස්ව, විවිධ ස්ථාන වලින් ප්‍රභවයන් වේ නම් අමු තර්ක ගනී.
    /// මෙය එක් රාමුවක් සඳහා කිහිප වතාවක් හැඳින්විය හැකි බව සලකන්න.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// තීරු තොරතුරු ඇතුළුව පසුගාමී නිමැවුමට අමු රාමුවක් එක් කරයි.
    ///
    /// මෙම ක්‍රමය පෙර මෙන්, විවිධ තර්ක වලින් විවිධ ප්‍රභවයන්ගෙන් ප්‍රභවයක් වේ නම් අමු තර්ක ගනී.
    /// මෙය එක් රාමුවක් සඳහා කිහිප වතාවක් හැඳින්විය හැකි බව සලකන්න.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // ක්‍රියාවලියක් තුළ සංකේතවත් කිරීමට ෆුචියාට නොහැකි බැවින් එයට විශේෂ ආකෘතියක් ඇති අතර එය පසුව සංකේතවත් කිරීමට භාවිතා කළ හැකිය.
        // ලිපිනයන් අපේම ආකෘතියෙන් මුද්‍රණය කරනවා වෙනුවට මුද්‍රණය කරන්න.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // "null" රාමු මුද්‍රණය කිරීමට අවශ්‍ය නැත, එයින් මූලික වශයෙන් අදහස් කරන්නේ පද්ධති පසුපෙළ සුපිරි දුරක් සොයා ගැනීමට ටිකක් උනන්දු වූ බවයි.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Sgx එන්ක්ලේව් හි TCB ප්‍රමාණය අඩු කිරීම සඳහා, සංකේත විභේදන ක්‍රියාකාරිත්වය ක්‍රියාත්මක කිරීමට අපට අවශ්‍ය නැත.
        // ඒ වෙනුවට, අපට මෙහි ලිපිනයේ ඕෆ්සෙට් එක මුද්‍රණය කළ හැකිය, පසුව එය නිවැරදි ක්‍රියාකාරිත්වය සඳහා සිතියම් ගත කළ හැකිය.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // රාමුවේ දර්ශකය මෙන්ම රාමුවේ විකල්ප උපදෙස් දර්ශකයද මුද්‍රණය කරන්න.
        // අපි මෙම රාමුවේ පළමු සංකේතයෙන් ඔබ්බට ගියත් සුදුසු සුදු අවකාශයක් මුද්‍රණය කළත්.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // ඊළඟට සංකේත නාමය ලියන්න, අපි සම්පූර්ණ පසුබිමක් නම් වැඩි විස්තර සඳහා විකල්ප හැඩතල ගැන්වීම භාවිතා කරන්න.
        // මෙන්න අපි නමක් නැති සංකේත ද හසුරුවන්නෙමු,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // අවසාන වශයෙන්, filename/line අංකය තිබේ නම් ඒවා මුද්‍රණය කරන්න.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line සංකේත නාමය යටතේ රේඛාවල මුද්‍රණය කර ඇත, එබැවින් අපව නිවැරදිව පෙළගැස්වීමට සුදුසු සුදු අවකාශයක් මුද්‍රණය කරන්න.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // ගොනු නාමය මුද්‍රණය කර අපගේ පේළි අංකය මුද්‍රණය කිරීම සඳහා අපගේ අභ්‍යන්තර ඇමතුම් ලබා දෙන්න.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // තිබේ නම් තීරු අංකය එක් කරන්න.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // අපි සැලකිලිමත් වන්නේ රාමුවක පළමු සංකේතය ගැන පමණි
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}