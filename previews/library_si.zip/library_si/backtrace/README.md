# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Rust සඳහා ධාවන වේලාවේ පසුබිම් ලබා ගැනීම සඳහා පුස්තකාලයක්.
මෙම පුස්තකාලය සමඟ වැඩ කිරීමට ක්‍රමලේඛ අතුරු මුහුණතක් ලබා දීමෙන් සම්මත පුස්තකාලයේ සහාය වැඩි දියුණු කිරීම අරමුණු කරයි, නමුත් එය libstd හි panics වැනි වර්තමාන පසුබිම පහසුවෙන් මුද්‍රණය කිරීමට ද සහාය වේ.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

පසුපෙළක් හසු කර ගැනීමට සහ පසුකාලීනව එය සමඟ ගනුදෙනු කිරීම කල් දැමීමට, ඔබට ඉහළ මට්ටමේ `Backtrace` වර්ගය භාවිතා කළ හැකිය.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

කෙසේ වෙතත්, සත්‍ය ලුහුබැඳීමේ ක්‍රියාකාරිත්වයට වැඩි අමු ප්‍රවේශයක් ලබා ගැනීමට ඔබ කැමති නම්, ඔබට `trace` සහ `resolve` ශ්‍රිත සෘජුවම භාවිතා කළ හැකිය.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // මෙම උපදෙස් දර්ශකය සංකේත නාමයකට විසඳන්න
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // ඊළඟ රාමුවට යන්න
    });
}
```

# License

මෙම ව්‍යාපෘතිය දෙකටම බලපත්‍ර ලබා දී ඇත

 * Apache බලපත්‍රය, අනුවාදය 2.0, ([LICENSE-APACHE](LICENSE-APACHE) හෝ http://www.apache.org/licenses/LICENSE-2.0)
 * MIT බලපත්‍රය ([LICENSE-MIT](LICENSE-MIT) හෝ http://opensource.org/licenses/MIT)

ඔබේ විකල්පය අනුව.

### Contribution

ඔබ වෙනත් ආකාරයකින් පැහැදිලිව ප්‍රකාශ නොකරන්නේ නම්, Apache-2.0 බලපත්‍රයේ අර්ථ දක්වා ඇති පරිදි, ඔබ විසින් පසුගාමී-ආර්එස් ඇතුළත් කිරීම සඳහා හිතාමතාම ඉදිරිපත් කරන ලද ඕනෑම දායකත්වයක් අතිරේක නියමයන් හෝ කොන්දේසි නොමැතිව ඉහත පරිදි ද්විත්ව බලපත්‍ර ලබා දෙනු ලැබේ.







