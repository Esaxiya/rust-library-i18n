use backtrace::Backtrace;

// මෙම පරීක්ෂණය ක්‍රියාත්මක වන්නේ සංකේතයක ආරම්භක ලිපිනය වාර්තා කරන රාමු සඳහා වැඩ කරන `symbol_address` ශ්‍රිතයක් ඇති වේදිකාවල පමණි.
// එහි ප්‍රති result ලයක් ලෙස එය සක්‍රීය කර ඇත්තේ වේදිකා කිහිපයක පමණි.
//
const ENABLED: bool = cfg!(all(
    // Windows සැබවින්ම පරික්ෂා කර නොමැති අතර OSX ඇත්ත වශයෙන්ම කොටු රාමුවක් සොයා ගැනීමට සහාය නොදක්වයි, එබැවින් මෙය අක්‍රීය කරන්න
    //
    target_os = "linux",
    // ARM හි සංවෘත ශ්‍රිතය සොයාගැනීමේදී හුදෙක් ip නැවත ලබා දෙයි.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}