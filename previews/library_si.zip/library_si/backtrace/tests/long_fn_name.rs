use backtrace::Backtrace;

// අක්ෂර 50 මොඩියුලයේ නම
mod _234567890_234567890_234567890_234567890_234567890 {
    // අක්ෂර 50 ක ව්‍යුහාත්මක නම
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// දිගු ක්‍රියාකාරී නම් (MAX_SYM_NAME, 1) අක්ෂරවලට කපා දැමිය යුතුය.
// gnu සියළුම රාමු සඳහා "<no info>" මුද්‍රණය කරන බැවින් msvc සඳහා පමණක් මෙම පරීක්ෂණය ක්‍රියාත්මක කරන්න.
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // ව්‍යුහාත්මක නාමයේ පුනරාවර්තන 10 ක්, එබැවින් පූර්ණ සුදුසුකම් ලත් ශ්‍රිත නාමය අවම වශයෙන් 10 *(50 + 50)* 2=අක්ෂර 2000 ක් දිග වේ.
    //
    // එය ඇත්ත වශයෙන්ම දිගු බැවින් එයට `::`, `<>` සහ වත්මන් මොඩියුලයේ නමද ඇතුළත් වේ
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}