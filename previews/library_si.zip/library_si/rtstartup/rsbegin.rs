// rsbegin.o සහ rsend.o යනු ඊනියා "compiler runtime startup objects" ය.
// සම්පාදක ධාවන කාලය නිවැරදිව ආරම්භ කිරීම සඳහා අවශ්‍ය කේත ඒවායේ අඩංගු වේ.
//
// ක්‍රියාත්මක කළ හැකි හෝ ඩයිලිබ් රූපයක් සම්බන්ධ වූ විට, සියලු පරිශීලක කේත සහ පුස්තකාල මෙම වස්තු ලිපිගොනු දෙක අතර "sandwiched" වේ, එබැවින් rsbegin.o වෙතින් කේත හෝ දත්ත රූපයේ අදාළ අංශවල පළමු තැනට පත්වන අතර rsend.o වෙතින් කේතය සහ දත්ත අවසාන ඒවා බවට පත්වේ.
// මෙම ආචරණය කොටසේ ආරම්භයේ හෝ අවසානයේ සංකේත ස්ථානගත කිරීමට මෙන්ම අවශ්‍ය ශීර්ෂ හෝ පාදක ඇතුළත් කිරීමට භාවිතා කළ හැකිය.
//
// සත්‍ය මොඩියුලය ඇතුළත් කිරීමේ ස්ථානය සී ධාවන කාල ආරම්භක වස්තුවෙහි (සාමාන්‍යයෙන් `crtX.o` ලෙස හැඳින්වේ) පිහිටා ඇති බව සලකන්න, එය පසුව වෙනත් ධාවන කාල සංරචකවල ආරම්භක ඇමතුම් ලබා ගනී (තවත් විශේෂ රූප අංශයක් හරහා ලියාපදිංචි කර ඇත).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // තොග රාමුවේ ආරම්භය සලකුණු තොරතුරු කොටස වෙන් කරන්න
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // නොදැනුවත්වම අභ්‍යන්තර පොත් තැබීම සඳහා සීරීමට ඉඩ.
    // මෙය 00 GCC/unsind-dw2-fde.h හි `struct object` ලෙස අර්ථ දක්වා ඇත.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // තොරතුරු ඉවත් කරන්න registration/deregistration චර්යාවන්.
    // Libpanic_unwind හි ලේඛන බලන්න.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // මොඩියුල ආරම්භය පිළිබඳ නොවරදින තොරතුරු ලියාපදිංචි කරන්න
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // වසා දැමීමේදී ලියාපදිංචි නොවන්න
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-විශේෂිත init/uninit දෛනික ලියාපදිංචිය
    pub mod mingw_init {
        // MinGW හි ආරම්භක වස්තු (crt0.o/dllcrt0.o) ආරම්භක සහ පිටවීමේදී .ctors සහ .dtors අංශවල ගෝලීය ඉදිකිරීම්කරුවන්ට ආයාචනා කරනු ඇත.
        // ඩීඑල්එල් සම්බන්ධයෙන් ගත් කල, ඩීඑල්එල් පටවා බෑම සිදු කරන විට මෙය සිදු කෙරේ.
        //
        // සම්බන්ධක විසින් කොටස් වර්ග කරනු ඇත, එමඟින් අපගේ ඇමතුම් ආපසු ලැයිස්තුවේ පිහිටා ඇති බව සහතික කරයි.
        // ඉදිකිරීම්කරුවන් ප්‍රතිලෝම අනුපිළිවෙලින් ක්‍රියාත්මක වන හෙයින්, අපගේ ඇමතුම් ආපසු ලබා දෙන පළමු හා අවසාන ඒවා බව මෙය සහතික කරයි.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: සී ආරම්භක ඇමතුම්
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C අවසන් කිරීමේ ඇමතුම්
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}