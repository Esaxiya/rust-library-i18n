//! යුනිකෝඩ් නූල් පෙති.
//!
//! *[See also the `str` primitive type](str).*
//!
//! `&str` වර්ගය ප්‍රධාන නූල් වර්ග දෙකෙන් එකක් වන අතර අනෙක `String` වේ.
//! එහි `String` සහකරු මෙන් නොව, එහි අන්තර්ගතය ණයට ගනු ලැබේ.
//!
//! # මූලික භාවිතය
//!
//! `&str` වර්ගයේ මූලික වචන ප්‍රකාශයක්:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! මෙහිදී අපි වචන මාලාවක් ප්‍රකාශයට පත් කර ඇත්තෙමු.
//! සංගීත සාහිත්‍යකරුවන්ට ස්ථිතික ජීවිත කාලයක් ඇත, එයින් අදහස් වන්නේ `hello_world` නූල සමස්ත වැඩසටහනේ කාලසීමාව සඳහා වලංගු බවට සහතික වී ඇති බවයි.
//!
//! `Hello_world` හි ජීවිත කාලයද අපට පැහැදිලිව සඳහන් කළ හැකිය:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// මෙම මොඩියුලයේ බොහෝ භාවිතයන් භාවිතා කරනුයේ පරීක්ෂණ වින්‍යාසය තුළ පමණි.
// ඒවා නිවැරදි කිරීමට වඩා භාවිතයට නොගත්_සම්පූර්ණ අනතුරු ඇඟවීම ක්‍රියා විරහිත කිරීම වඩා පිරිසිදු ය.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `Concat<str>` හි `str` මෙහි අර්ථවත් නොවේ.
/// trait හි මෙම වර්ගයේ පරාමිතිය පවතින්නේ තවත් impl සක්‍රීය කිරීම සඳහා පමණි.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // දෘ c කේත සහිත ප්‍රමාණයේ ලූප වඩා වේගයෙන් ධාවනය වන අතර කුඩා බෙදුම්කරු දිග සහිත අවස්ථා විශේෂීකරණය කරන්න
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // අත්තනෝමතික ශුන්‍ය නොවන ප්‍රමාණයේ පසුබෑම
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Vec දෙකටම ක්‍රියාත්මක වන ප්‍රශස්ත සම්බන්ධක ක්‍රියාත්මක කිරීම<T>(T: Copy) සහ String's internal vec දැනට (2018-05-13) වර්ගයේ අනුමාන කිරීම් සහ විශේෂීකරණය සහිත දෝෂයක් ඇත (#36262 නිකුතුව බලන්න) මේ හේතුව නිසා SliceConcat<T>T සඳහා විශේෂිත නොවේ: පිටපත් කිරීම සහ ස්ලයිස්කොන්කැට්<str>මෙම ශ්‍රිතයේ එකම පරිශීලකයා වේ.
// එය සවි කර ඇති කාලය සඳහා එය ඉතිරි වේ.
//
// String-join සඳහා සීමාවන් S: ණය<str>සහ Vec-join Borrow <[T]> [T] සහ str දෙකම impR AsRef <[T]> සමහර ටී සඳහා
// => s.borrow().as_ref() අපි හැම විටම පෙති ඇත
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // පළමු පෙත්ත ඊට පෙර බෙදුම්කරුවෙකු නොමැති එකම එකයි
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // `len` ගණනය කිරීම පිරී ඉතිරී ගියහොත් එක්වූ Vec හි සම්පූර්ණ මුළු දිග ගණනය කරන්න, අපි panic කරන්නෙමු, කෙසේ හෝ අපට මතක ශක්තිය නැති වී යනු ඇති අතර ඉතිරි ශ්‍රිතයට ආරක්ෂාව සඳහා පූර්ව වෙන් කළ මුළු Vec අවශ්‍ය වේ
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // ආරම්භ නොකළ බෆරයක් සකස් කරන්න
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // පිටපත් බෙදුම්කරු සහ පෙති මායිම් රහිතව චෙක්පත් මඟින් කුඩා බෙදුම්කරුවන් සඳහා දෘ c කේත සහිත ඕෆ්සෙට් සහිත ලූප ජනනය කරයි (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // අමුතු ණය ක්‍රියාවට නැංවීම මඟින් දිග ගණනය කිරීම සහ සත්‍ය පිටපත සඳහා විවිධ පෙති ලබා දිය හැකිය.
        //
        // අපි ආරම්භක නොවන බයිට් අමතන්නාට නිරාවරණය නොකිරීමට වග බලා ගන්න.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// නූල් පෙති සඳහා ක්‍රම.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// `Box<str>` පිටපත් කිරීම හෝ වෙන් කිරීමකින් තොරව `Box<[u8]>` බවට පරිවර්තනය කරයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// රටාවක සියලුම ගැලපීම් වෙනත් නූලකින් ආදේශ කරයි.
    ///
    /// `replace` නව [`String`] නිර්මාණය කරන අතර, මෙම නූලෙන් දත්ත ඒ තුළට පිටපත් කරයි.
    /// එසේ කරන අතර, එය රටාවක ගැලපීම් සොයා ගැනීමට උත්සාහ කරයි.
    /// එය කිසියම් දෙයක් සොයාගත හොත්, එය ඒවා වෙනුවට ආදේශන නූල් පෙත්තක් ආදේශ කරයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// රටාව නොගැලපෙන විට:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// රටාවක පළමු N තරඟ වෙනත් නූලකින් ආදේශ කරයි.
    ///
    /// `replacen` නව [`String`] නිර්මාණය කරන අතර, මෙම නූලෙන් දත්ත ඒ තුළට පිටපත් කරයි.
    /// එසේ කරන අතර, එය රටාවක ගැලපීම් සොයා ගැනීමට උත්සාහ කරයි.
    /// එය කිසියම් දෙයක් සොයාගත හොත්, එය බොහෝ විට `count` වේලාවන්හි ආදේශන නූල් පෙත්තක් සමඟ ඒවා ප්‍රතිස්ථාපනය කරයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// රටාව නොගැලපෙන විට:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // නැවත වෙන් කිරීමේ කාලය අඩු කිරීමට බලාපොරොත්තු වෙමු
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// නව [`String`] ලෙස මෙම නූල් පෙත්තට සමාන කුඩා අකුරු ලබා දෙයි.
    ///
    /// 'Lowercase' යුනිකෝඩ් ව්‍යුත්පන්න මූලික දේපල `Lowercase` හි නියමයන්ට අනුව අර්ථ දක්වා ඇත.
    ///
    /// නඩුව වෙනස් කිරීමේදී සමහර අක්ෂර බහු අක්ෂර වලට විස්තාරණය විය හැකි බැවින්, මෙම ශ්‍රිතය තැනින් තැන පරාමිතිය වෙනස් කිරීම වෙනුවට [`String`] ලබා දෙයි.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// සිග්මා සමඟ උපායශීලී උදාහරණයක්:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // නමුත් වචනයක් අවසානයේ එය ς, not නොවේ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// නඩුවකින් තොරව භාෂා වෙනස් නොවේ:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // වචනයක් අවසානයේ සිතියම් ගත කිරීම හැර except වෙත Σ සිතියම් ගත කරයි.
                // `SpecialCasing.txt` හි ඇති එකම කොන්දේසි සහිත (contextual) නමුත් භාෂාවෙන් ස්වාධීන සිතියම්කරණය මෙයයි, එබැවින් සාමාන්‍ය "condition" යාන්ත්‍රණයක් තිබීමට වඩා එය තදින් කේත කරන්න.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // `Final_Sigma` අර්ථ දැක්වීම සඳහා.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// නව [`String`] ලෙස මෙම නූල් පෙත්තට සමාන ලොකු අකුරක් ලබා දෙයි.
    ///
    /// 'Uppercase' යුනිකෝඩ් ව්‍යුත්පන්න මූලික දේපල `Uppercase` හි නියමයන්ට අනුව අර්ථ දක්වා ඇත.
    ///
    /// නඩුව වෙනස් කිරීමේදී සමහර අක්ෂර බහු අක්ෂර වලට විස්තාරණය විය හැකි බැවින්, මෙම ශ්‍රිතය තැනින් තැන පරාමිතිය වෙනස් කිරීම වෙනුවට [`String`] ලබා දෙයි.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// නඩුවකින් තොරව ස්ක්‍රිප්ට් වෙනස් නොවේ:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// එක් අක්ෂරයක් බහුවිධ විය හැකිය:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// [`Box<str>`] පිටපත් කිරීම හෝ වෙන් කිරීමකින් තොරව [`String`] බවට පරිවර්තනය කරයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// `n` වාරයක් පුනරාවර්තනය කිරීමෙන් නව [`String`] නිර්මාණය කරයි.
    ///
    /// # Panics
    ///
    /// ධාරිතාව පිරී ඉතිරී ගියහොත් මෙම ශ්‍රිතය panic වනු ඇත.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// පිටාර ගැලීම මත panic:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// සෑම අක්ෂරයක්ම එහි ASCII ඉහළ අකුරට සමාන ලෙස සිතියම් ගත කර ඇති මෙම නූලෙහි පිටපතක් ලබා දෙයි.
    ///
    ///
    /// ASCII අක්ෂර 'a' සිට 'z' දක්වා 'A' සිට 'Z' දක්වා සිතියම් ගත කර ඇත, නමුත් ASCII නොවන අකුරු නොවෙනස්ව පවතී.
    ///
    /// ස්ථානයෙහි අගය ඉහළ අගයක් ගැනීමට, [`make_ascii_uppercase`] භාවිතා කරන්න.
    ///
    /// ASCII නොවන අක්ෂර වලට අමතරව ASCII අක්ෂර විශාල කිරීමට, [`to_uppercase`] භාවිතා කරන්න.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() UTF-8 ආක්‍රමණ ආරක්ෂා කරයි.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// සෑම අක්ෂරයක්ම එහි ASCII කුඩා අකුරට සමාන ලෙස සිතියම් ගත කර ඇති මෙම නූලෙහි පිටපතක් ලබා දෙයි.
    ///
    ///
    /// ASCII අක්ෂර 'A' සිට 'Z' දක්වා 'a' සිට 'z' දක්වා සිතියම් ගත කර ඇත, නමුත් ASCII නොවන අකුරු නොවෙනස්ව පවතී.
    ///
    /// ස්ථානයෙහි අගය අඩු කිරීමට, [`make_ascii_lowercase`] භාවිතා කරන්න.
    ///
    /// ASCII නොවන අක්ෂර වලට අමතරව ASCII අක්ෂර කුඩා කිරීමට, [`to_lowercase`] භාවිතා කරන්න.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() UTF-8 ආක්‍රමණ ආරක්ෂා කරයි.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// නූල් වලංගු UTF-8 අඩංගු දැයි පරීක්ෂා නොකර කොටු කළ බයිට් පෙත්තක් කොටු කළ නූල් පෙත්තක් බවට පරිවර්තනය කරයි.
///
///
/// # Examples
///
/// මූලික භාවිතය:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}