#![stable(feature = "rust1", since = "1.0.0")]

//! නූල්-ආරක්ෂිත යොමු-ගණන් කිරීමේ දර්ශක.
//!
//! වැඩි විස්තර සඳහා [`Arc<T>`][Arc] ප්‍රලේඛනය බලන්න.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// `Arc` වෙත යොමු කළ හැකි යොමු ප්‍රමාණයන්හි මෘදු සීමාවක්.
///
/// මෙම සීමාවට ඉහළින් යාමෙන් ඔබේ වැඩසටහන _exactly_ `MAX_REFCOUNT + 1` යොමුවලින් අහෝසි වේ.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer මතක වැටවල් සඳහා සහය නොදක්වයි.
// චාප/දුර්වල ක්‍රියාත්මක කිරීමේදී ව්‍යාජ ධනාත්මක වාර්තා වළක්වා ගැනීම සඳහා සමමුහුර්තකරණය සඳහා පරමාණුක පැටවුම් භාවිතා කරන්න.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// නූල්-ආරක්ෂිත යොමු-ගණන් කිරීමේ දර්ශකය.'Arc' යනු 'පරමාණුක යොමු ගණන් කිරීම' යන්නයි.
///
/// `Arc<T>` වර්ගය ගොඩවල වෙන් කර ඇති `T` වර්ගයේ වටිනාකමක හවුල් හිමිකම සපයයි.`Arc` හි [`clone`][clone] ආයාචනා කිරීම නව `Arc` නිදසුනක් නිපදවන අතර, එය යොමු අගය වැඩි කරන අතරම `Arc` ප්‍රභවය ලෙස ගොඩවල් මත වෙන් කිරීම පෙන්නුම් කරයි.
/// දී ඇති ප්‍රතිපාදන සඳහා අවසාන `Arc` දර්ශකය විනාශ වූ විට, එම ප්‍රතිපාදන තුළ ගබඩා කර ඇති අගය (බොහෝ විට "inner value" ලෙස හැඳින්වේ) ද පහත වැටේ.
///
/// Rust හි හවුල් යොමු කිරීම් පෙරනිමියෙන් විකෘතියට ඉඩ නොදේ, සහ `Arc` ද ව්‍යතිරේකයක් නොවේ: ඔබට සාමාන්‍යයෙන් `Arc` තුළ ඇති දෙයක් ගැන විකෘති යොමු කිරීමක් ලබා ගත නොහැක.ඔබට `Arc` හරහා විකෘති වීමට අවශ්‍ය නම්, [`Mutex`][mutex], [`RwLock`][rwlock], හෝ [`Atomic`][atomic] වර්ග වලින් එකක් භාවිතා කරන්න.
///
/// ## නූල් ආරක්ෂාව
///
/// [`Rc<T>`] මෙන් නොව, `Arc<T>` එහි විමර්ශන ගණනය කිරීම සඳහා පරමාණුක මෙහෙයුම් භාවිතා කරයි.මෙයින් අදහස් කරන්නේ එය නූල් ආරක්ෂිත බවයි.අවාසිය නම් සාමාන්‍ය මතක ප්‍රවේශයන්ට වඩා පරමාණුක මෙහෙයුම් මිල අධික වීමයි.ඔබ නූල් අතර යොමු-ගණන් කළ ප්‍රතිපාදන බෙදා නොගන්නේ නම්, පහළ පොදු කාර්ය සඳහා [`Rc<T>`] භාවිතා කිරීම සලකා බලන්න.
/// [`Rc<T>`] ආරක්ෂිත පෙරනිමියකි, මන්දයත් සම්පාදකයා විසින් නූල් අතර [`Rc<T>`] යැවීමට දරන ඕනෑම උත්සාහයක් අල්ලා ගනු ඇත.
/// කෙසේ වෙතත්, පුස්තකාල පාරිභෝගිකයින්ට වඩාත් නම්‍යශීලී බවක් ලබා දීම සඳහා පුස්තකාලයක් `Arc<T>` තෝරා ගත හැකිය.
///
/// `Arc<T>` `T` [`Send`] සහ [`Sync`] ක්‍රියාත්මක කරන තාක් කල් [`Send`] සහ [`Sync`] ක්‍රියාත්මක කරනු ඇත.
/// නූල්-ආරක්ෂිත නොවන ආකාරයේ `T` වර්ගයක් `Arc<T>` තුළ තැබිය නොහැක්කේ ඇයි?මුලදී මෙය තරමක් ප්‍රති-බුද්ධිමත් විය හැකිය: සියල්ලට පසු, `Arc<T>` නූල් ආරක්ෂාව පිළිබඳ කාරණය නොවේද?ප්රධාන දෙය මෙයයි: `Arc<T>` එකම දත්තවල බහු හිමිකාරිත්වයක් තිබීම නූල් ආරක්ෂිත කරයි, නමුත් එය එහි දත්ත වලට නූල් ආරක්ෂාව එක් නොකරයි.
///
/// `චාප <` [`RefCell 'සලකා බලන්න<T>`]`>`.
/// [`RefCell<T>`] [`Sync`] නොවේ, සහ `Arc<T>` සෑම විටම [`Send`] නම්, `චාප <` [`RefCell<T>`]`>`එසේම වනු ඇත.
/// නමුත් එවිට අපට ගැටලුවක් ඇත:
/// [`RefCell<T>`] නූල් ආරක්ෂිත නොවේ;එය පරමාණුක නොවන මෙහෙයුම් භාවිතා කරමින් ණයට ගැනීමේ ගණන නිරීක්ෂණය කරයි.
///
/// අවසානයේදී, මෙයින් අදහස් කරන්නේ ඔබට `Arc<T>` කිසියම් ආකාරයක [`std::sync`] වර්ගයක් සමඟ සම්බන්ධ කිරීමට අවශ්‍ය විය හැකි බවයි, සාමාන්‍යයෙන් [`Mutex<T>`][mutex].
///
/// ## `Weak` සමඟ චක්‍ර බිඳීම
///
/// [`downgrade`][downgrade] ක්‍රමය අයිති නොවන [`Weak`] දර්ශකයක් නිර්මාණය කිරීමට භාවිතා කළ හැකිය.[`Weak`] දර්ශකයක් `Arc` වෙත [උත්ශ්‍රේණිගත කිරීම] විය හැකිය, නමුත් වෙන් කිරීම තුළ ගබඩා කර ඇති අගය දැනටමත් අතහැර දමා ඇත්නම් මෙය [`None`] ආපසු ලබා දෙනු ඇත.
/// වෙනත් වචන වලින් කිවහොත්, `Weak` දර්ශකයන් වෙන් කිරීම තුළ ඇති වටිනාකම සජීවීව තබා නොගනී;කෙසේ වෙතත්, ඔවුන් වෙන් කිරීම (වටිනාකම සඳහා ආධාරක ගබඩාව) පණපිටින් තබා ගනී.
///
/// `Arc` පොයින්ටර් අතර චක්‍රයක් කිසි විටෙකත් අවලංගු නොවේ.
/// මෙම හේතුව නිසා, [`Weak`] චක්ර බිඳ දැමීමට භාවිතා කරයි.නිදසුනක් ලෙස, ගසකට මව් නෝඩ් සිට ළමයින් දක්වා ශක්තිමත් `Arc` දර්ශක තිබිය හැකි අතර, [`Weak`] පොයින්ටර් දරුවන්ගේ සිට ඔවුන්ගේ දෙමාපියන් වෙත ආපසු යා හැකිය.
///
/// # ක්ලෝන යොමු කිරීම්
///
/// [`Arc<T>`][Arc] සහ [`Weak<T>`][Weak] සඳහා ක්‍රියාත්මක කර ඇති `Clone` trait භාවිතා කරමින් දැනට පවතින යොමු-ගණනය කළ දර්ශකයකින් නව යොමු කිරීමක් සිදු කෙරේ.
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // පහත සින්ටැක්ස් දෙක සමාන වේ.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b, සහ foo යන සියල්ලම එකම මතක ස්ථානයට යොමු වන චාප වේ
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` `T` වෙත ස්වයංක්‍රීයව විරූපණය වේ ([`Deref`][deref] trait හරහා), එබැවින් ඔබට `Arc<T>` වර්ගයේ අගය මත `T` ක්‍රම අමතන්න.`T` ක්‍රම සමඟ නාම ගැටුම් වලක්වා ගැනීම සඳහා, `Arc<T>` හි ක්‍රමවේදයන්ම සම්බන්ධිත කාර්යයන් වේ, එය [fully qualified syntax] භාවිතා කිරීම ලෙස හැඳින්වේ:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// චාප<T>`Clone` වැනි traits ක්‍රියාත්මක කිරීම පූර්ණ සුදුසුකම් ලත් සින්ටැක්ස් භාවිතයෙන් ද හැඳින්විය හැකිය.
/// සමහර අය සම්පුර්ණ සුදුසුකම් ලත් සින්ටැක්ස් භාවිතා කිරීමට කැමැත්තක් දක්වන අතර අනෙක් අය ක්‍රම-ඇමතුම් සින්ටැක්ස් භාවිතා කිරීමට කැමැත්තක් දක්වයි.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // ක්‍රමය-ඇමතුම් සින්ටැක්ස්
/// let arc2 = arc.clone();
/// // සම්පුර්ණ සුදුසුකම් ලත් සින්ටැක්ස්
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] `T` වෙත ස්වයංක්‍රීයව විරූපණය නොකෙරේ, මන්ද අභ්‍යන්තර අගය දැනටමත් අතහැර දමා ඇති බැවිනි.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// නූල් අතර වෙනස් කළ නොහැකි දත්ත කිහිපයක් බෙදා ගැනීම:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// අපි ** මෙම පරීක්ෂණ මෙහි ධාවනය නොකරන බව සලකන්න.
// නූල් එකක් ප්‍රධාන නූලට වඩා ඉහළින් ගොස් එකවරම පිටව ගියහොත් windows තනන්නන් අතිශයින් අසතුටට පත්වේ (යම්කිසි අවහිරතා ඇති දෙයක්) එබැවින් අපි මෙම පරීක්ෂණ ක්‍රියාත්මක නොකිරීමෙන් මෙය සම්පූර්ණයෙන්ම වළක්වා ගනිමු.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// විකෘති [`AtomicUsize`] බෙදාගැනීම:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// පොදුවේ යොමු ගණනය කිරීම් සඳහා තවත් උදාහරණ සඳහා [`rc` documentation][rc_examples] බලන්න.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` යනු [`Arc`] හි අනුවාදයක් වන අතර එය කළමනාකරණ ප්‍රතිපාදන සඳහා හිමිකාරී නොවන සඳහනක් දරයි.
/// `Weak` දර්ශකයේ [`upgrade`] ඇමතීමෙන් ප්‍රතිපාදන ප්‍රවේශ කළ හැකි අතර, එය [`විකල්පය]]` <`[` චාප`]`<T>> `.
///
/// `Weak` යොමුව හිමිකාරිත්වය කෙරෙහි ගණන් නොගන්නා හෙයින්, එය වෙන් කිරීම තුළ ගබඩා කර ඇති වටිනාකම පහත වැටීම වලක්වනු නොලැබේ, සහ `Weak` විසින්ම තවමත් පවතින වටිනාකම පිළිබඳව කිසිදු සහතිකයක් ලබා නොදේ.
///
/// [`උත්ශ්‍රේණිගත කිරීමේදී] එය [`None`] ආපසු ලබා දිය හැක.
/// කෙසේ වෙතත්, `Weak` යොමු කිරීමක් * වෙන් කිරීමම (පසුබිම් ගබඩාව) අවලංගු කිරීම වළක්වන බව සලකන්න.
///
/// `Weak` දර්ශකය එහි අභ්‍යන්තර වටිනාකම පහත වැටීම වළක්වා නොගෙන [`Arc`] විසින් කළමනාකරණය කරන ලද ප්‍රතිපාදන පිළිබඳ තාවකාලික සඳහනක් තබා ගැනීම සඳහා ප්‍රයෝජනවත් වේ.
/// [`Arc`] පොයින්ටර් අතර රවුම් යොමු වීම වැළැක්වීම සඳහා ද මෙය භාවිතා වේ, මන්ද අන්‍යෝන්‍ය හිමිකාරීත්ව යොමු කිරීම් කිසි විටෙකත් [`Arc`] අතහැර දැමීමට ඉඩ නොදේ.
/// නිදසුනක් ලෙස, ගසකට මව් නෝඩ් සිට ළමයින් දක්වා ශක්තිමත් [`Arc`] පොයින්ටර්ස් තිබිය හැකි අතර, `Weak` පොයින්ටර්ස් දරුවන්ගේ සිට දෙමාපියන් වෙත ආපසු යා හැකිය.
///
/// `Weak` දර්ශකයක් ලබා ගත හැකි සාමාන්‍ය ක්‍රමය වන්නේ [`Arc::downgrade`] අමතන්න.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // මෙම වර්ගයේ ප්‍රමාණය එනුම් වල ප්‍රශස්තිකරණය කිරීමට ඉඩ දීම සඳහා මෙය `NonNull` වේ, නමුත් එය අනිවාර්යයෙන්ම වලංගු දර්ශකයක් නොවේ.
    //
    // `Weak::new` මෙය `usize::MAX` ලෙස සකසා ඇති අතර එමඟින් ගොඩවල් මත ඉඩ වෙන් කිරීමට අවශ්‍ය නොවේ.
    // RcBox හි අවම වශයෙන් 2 ක් වත් පෙළගැස්වීමක් ඇති නිසා සැබෑ දර්ශකයකට එය කිසි විටෙකත් ඇති වටිනාකමක් නොවේ.
    // මෙය කළ හැක්කේ `T: Sized` විට පමණි;unsized `T` කිසි විටෙකත් නොගැලපේ.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// මෙය ක්ෂේත්‍ර ප්‍රතිසංවිධානයට එරෙහිව repr(C) සිට future-සාධනයකි, එමඟින් සම්ප්‍රේෂණය කළ හැකි අභ්‍යන්තර වර්ගවල ආරක්ෂිත [into|from]_raw() වලට බාධා ඇති වේ.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // usize::MAX අගය තාවකාලිකව "locking" සඳහා සෙන්ඩිනල් ලෙස ක්‍රියා කරයි දුර්වල දර්ශකයන් යාවත්කාලීන කිරීමට හෝ ශක්තිමත් ඒවා පහත හෙලීමට;`make_mut` සහ `get_mut` හි තරඟ වළක්වා ගැනීමට මෙය භාවිතා කරයි.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// නව `Arc<T>` සාදයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // දුර්වල දර්ශක ගණන 1 ලෙස ආරම්භ කරන්න, එය සියලු ප්‍රබල දර්ශකයන් වන (kinda) සතුව ඇති දුර්වල දර්ශකය වේ, වැඩි විස්තර සඳහා std/rc.rs බලන්න
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// තමාටම දුර්වල යොමු කිරීමක් භාවිතා කරමින් නව `Arc<T>` සාදයි.
    /// මෙම ශ්‍රිතය නැවත පැමිණීමට පෙර දුර්වල යොමුව යාවත්කාලීන කිරීමට උත්සාහ කිරීමෙන් `None` අගයක් ලැබෙනු ඇත.
    /// කෙසේ වෙතත්, දුර්වල යොමුව නිදහසේ ක්ලෝන කර පසුව භාවිතා කිරීම සඳහා ගබඩා කළ හැකිය.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // "uninitialized" තත්වයේ අභ්‍යන්තරය තනි දුර්වල යොමුවකින් සාදන්න.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // දුර්වල දර්ශකයේ හිමිකම අපි අත් නොහැරීම වැදගත්ය, නැතහොත් `data_fn` නැවත පැමිණෙන විට මතකය නිදහස් වනු ඇත.
        // අපට ඇත්ත වශයෙන්ම හිමිකාරිත්වය ලබා දීමට අවශ්‍ය නම්, අපට අප වෙනුවෙන් අතිරේක දුර්වල දර්ශකයක් නිර්මාණය කළ හැකිය, නමුත් මෙය දුර්වල යොමු ගණන් කිරීම් සඳහා අතිරේක යාවත්කාලීන කිරීම් සිදු කරනු ඇති අතර එය වෙනත් ආකාරයකින් අවශ්‍ය නොවනු ඇත.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // දැන් අපට අභ්‍යන්තර අගය නිසියාකාරව ආරම්භ කර අපගේ දුර්වල යොමුව ශක්තිමත් යොමු කිරීමක් බවට පත් කළ හැකිය.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // දත්ත ක්ෂේත්‍රයට ඉහත ලිවීම ශුන්‍ය නොවන ප්‍රබල සංඛ්‍යාවක් නිරීක්ෂණය කරන ඕනෑම නූල් වලට දෘශ්‍යමාන විය යුතුය.
            // එබැවින් `Weak::upgrade` හි `compare_exchange_weak` සමඟ සමමුහුර්ත කිරීම සඳහා අපට අවම වශයෙන් "Release" ඇණවුමක් අවශ්‍ය වේ.
            //
            // "Acquire" ඇණවුම් කිරීම අවශ්‍ය නොවේ.
            // `data_fn` හි විය හැකි හැසිරීම් සලකා බැලීමේදී අපට අවශ්‍ය වන්නේ නවීකරණය කළ නොහැකි `Weak` වෙත යොමු කිරීමෙන් එය කළ හැකි දේ ගැන පමණි:
            //
            // - එයට `Weak`*ක්ලෝන* කළ හැකි අතර දුර්වල යොමු ගණන වැඩි කරයි.
            // - එමඟින් එම ක්ලෝන අතහැර දැමිය හැකි අතර, දුර්වල යොමු ගණන අඩු කරයි (නමුත් කිසි විටෙකත් ශුන්‍ය නොවේ).
            //
            // මෙම අතුරු ආබාධ අපට කිසිදු ආකාරයකින් බලපාන්නේ නැති අතර ආරක්ෂිත කේතයකින් පමණක් වෙනත් අතුරු ආබාධ ඇතිවිය නොහැක.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // ශක්තිමත් යොමු කිරීම් සාමූහිකව හවුල් දුර්වල යොමු කිරීමක් තිබිය යුතුය, එබැවින් අපගේ පැරණි දුර්වල යොමු කිරීම සඳහා විනාශ කරන්නා ධාවනය නොකරන්න.
        //
        mem::forget(weak);
        strong
    }

    /// ආරම්භ නොකළ අන්තර්ගතයන් සහිත නව `Arc` සාදයි.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // විලම්බිත ආරම්භය:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// මතකය `0` බයිට් වලින් පුරවා ඇති, ආරම්භ නොකළ අන්තර්ගතයන්ගෙන් නව `Arc` සාදයි.
    ///
    ///
    /// මෙම ක්‍රමයේ නිවැරදි හා වැරදි භාවිතය පිළිබඳ උදාහරණ සඳහා [`MaybeUninit::zeroed`][zeroed] බලන්න.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// නව `Pin<Arc<T>>` සාදයි.
    /// `T` විසින් `Unpin` ක්‍රියාත්මක නොකරන්නේ නම්, `data` මතකයේ සවි කර ඇති අතර ඒවා ගෙනයාමට නොහැකි වනු ඇත.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// නව `Arc<T>` සාදයි, වෙන් කිරීම අසමත් වුවහොත් දෝෂයක් නැවත ලබා දේ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // දුර්වල දර්ශක ගණන 1 ලෙස ආරම්භ කරන්න, එය සියලු ප්‍රබල දර්ශකයන් වන (kinda) සතුව ඇති දුර්වල දර්ශකය වේ, වැඩි විස්තර සඳහා std/rc.rs බලන්න
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// ආරම්භ නොකළ අන්තර්ගතයන් සහිත නව `Arc` සාදයි, ප්‍රතිපාදන අසමත් වුවහොත් දෝෂයක් නැවත ලබා දේ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // විලම්බිත ආරම්භය:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// මතකය `0` බයිට් වලින් පුරවා, වෙන් කිරීම අසමත් වුවහොත් දෝෂයක් නැවත ලබා දෙමින්, ආරම්භ නොකළ අන්තර්ගතයන් සහිත නව `Arc` සාදයි.
    ///
    ///
    /// මෙම ක්‍රමයේ නිවැරදි හා වැරදි භාවිතය පිළිබඳ උදාහරණ සඳහා [`MaybeUninit::zeroed`][zeroed] බලන්න.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// `Arc` හි හරියටම එක් ප්‍රබල සඳහනක් තිබේ නම්, අභ්‍යන්තර අගය ලබා දෙයි.
    ///
    /// එසේ නොමැතිනම්, සම්මත වූ `Arc` සමඟ [`Err`] ආපසු ලබා දෙනු ලැබේ.
    ///
    ///
    /// කැපී පෙනෙන දුර්වල යොමු කිරීම් තිබුණද මෙය සාර්ථක වනු ඇත.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // ව්‍යංග ශක්තිමත්-දුර්වල යොමුව පිරිසිදු කිරීම සඳහා දුර්වල දර්ශකයක් සාදන්න
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// ආරම්භ නොකළ අන්තර්ගතයන් සහිත නව පරමාණුක යොමු-ගණන් කළ පෙත්තක් සාදයි.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // විලම්බිත ආරම්භය:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// මතකය `0` බයිට් වලින් පුරවා ඇති, ආරම්භක නොවන අන්තර්ගතයන් සහිත නව පරමාණුක යොමු-ගණනය කළ පෙත්තක් සාදයි.
    ///
    ///
    /// මෙම ක්‍රමයේ නිවැරදි හා වැරදි භාවිතය පිළිබඳ උදාහරණ සඳහා [`MaybeUninit::zeroed`][zeroed] බලන්න.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// `Arc<T>` බවට පරිවර්තනය කරයි.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] මෙන්ම, අභ්‍යන්තර අගය සැබවින්ම ආරම්භක තත්වයක පවතින බව සහතික කිරීම ඇමතුම්කරුගේ ය.
    ///
    /// අන්තර්ගතය තවමත් සම්පූර්ණයෙන් ආරම්භ කර නොමැති විට මෙය ඇමතීම ක්ෂණිකව නිර්වචනය නොකළ හැසිරීමට හේතු වේ.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // විලම්බිත ආරම්භය:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// `Arc<[T]>` බවට පරිවර්තනය කරයි.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] මෙන්ම, අභ්‍යන්තර අගය සැබවින්ම ආරම්භක තත්වයක පවතින බව සහතික කිරීම ඇමතුම්කරුගේ ය.
    ///
    /// අන්තර්ගතය තවමත් සම්පූර්ණයෙන් ආරම්භ කර නොමැති විට මෙය ඇමතීම ක්ෂණිකව නිර්වචනය නොකළ හැසිරීමට හේතු වේ.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // විලම්බිත ආරම්භය:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// ඔතා ඇති දර්ශකය නැවත ලබා දෙමින් `Arc` පරිභෝජනය කරයි.
    ///
    /// මතක කාන්දු වීමක් වළක්වා ගැනීම සඳහා, දර්ශකය [`Arc::from_raw`] භාවිතා කර `Arc` බවට පරිවර්තනය කළ යුතුය.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// දත්ත සඳහා අමු දර්ශකයක් සපයයි.
    ///
    /// ගණන් කිරීම් කිසිදු ආකාරයකින් බලපාන්නේ නැති අතර `Arc` පරිභෝජනය නොකෙරේ.
    /// `Arc` හි ප්‍රබල ගණනය කිරීම් පවතින තාක් දුරට දර්ශකය වලංගු වේ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // ආරක්ෂාව: මෙය Deref::deref හෝ RcBoxPtr::inner හරහා යා නොහැක
        // උදා: raw/mut ප්‍රභවය රඳවා ගැනීමට මෙය අවශ්‍ය වේ
        // `get_mut` `from_raw` හරහා Rc යථා තත්ත්වයට පත් වූ පසු දර්ශකය හරහා ලිවිය හැකිය.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// අමු දර්ශකයකින් `Arc<T>` සාදයි.
    ///
    /// අමු දර්ශකය මීට පෙර [`Arc<U>::into_raw`][into_raw] වෙත ඇමතුමක් මඟින් ආපසු ලබා දී තිබිය යුතුය, එහිදී `U` ට `T` හා සමාන ප්‍රමාණයක් හා පෙළගැස්මක් තිබිය යුතුය.
    /// `U` `T` නම් මෙය සුළු වශයෙන් සත්‍ය වේ.
    /// `U` යනු `T` නොව එකම ප්‍රමාණය හා පෙළගැස්වීමක් තිබේ නම්, මෙය මූලික වශයෙන් විවිධ වර්ගවල යොමු සම්ප්‍රේෂණයකට සමාන බව සලකන්න.
    /// මෙම නඩුවේ අදාළ වන සීමාවන් පිළිබඳ වැඩි විස්තර සඳහා [`mem::transmute`][transmute] බලන්න.
    ///
    /// `from_raw` භාවිතා කරන්නාට `T` හි නිශ්චිත අගයක් පහත වැටෙන්නේ එක් වරක් පමණක් බව තහවුරු කර ගත යුතුය.
    ///
    /// මෙම ශ්‍රිතය අනාරක්ෂිත බැවින් නැවත ලබා දුන් `Arc<T>` කිසි විටෙකත් ප්‍රවේශ නොවූවත්, අනිසි භාවිතය මතකයේ අනාරක්ෂිතභාවයට හේතු විය හැක.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // කාන්දු වීම වැළැක්වීම සඳහා නැවත `Arc` වෙත පරිවර්තනය කරන්න.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Arc::from_raw(x_ptr)` වෙත තවදුරටත් ඇමතුම් මතකය අනාරක්ෂිත වේ.
    /// }
    ///
    /// // `x` ඉහත විෂය පථයෙන් බැහැර වූ විට මතකය නිදහස් විය, එබැවින් `x_ptr` දැන් අන්තරාදායකය!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // මුල් ArcInner සොයා ගැනීමට ඕෆ්සෙට් ආපසු හරවන්න.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// මෙම වෙන් කිරීම සඳහා නව [`Weak`] දර්ශකයක් සාදයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // අපි පහත CAS හි වටිනාකම පරික්ෂා කරන බැවින් මෙම ලිහිල් කිරීම හරි ය.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // දුර්වල කවුන්ටරය දැනට "locked" දැයි පරීක්ෂා කරන්න;එසේ නම්, කරකවන්න.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: මෙම කේතය දැනට පිටාර ගැලීමේ හැකියාව නොසලකා හරියි
            // usize::MAX බවට;පොදුවේ පිටාර ගැලීම සමඟ කටයුතු කිරීම සඳහා Rc සහ Arc යන දෙකම සකස් කළ යුතුය.
            //

            // Clone() මෙන් නොව, අපට මෙය `is_unique` වෙතින් එන ලිවීම සමඟ සමමුහුර්ත කිරීම සඳහා ඇක්වයිර් කියවීමක් විය යුතුය, එවිට එම ලිවීමට පෙර සිදුවීම් මෙම කියවීමට පෙර සිදු වේ.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // අප දුර්වල දුර්වලතාවයක් ඇති නොකරන බවට වග බලා ගන්න
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// මෙම වෙන් කිරීම සඳහා [`Weak`] දර්ශකයන් ගණන ලබා ගනී.
    ///
    /// # Safety
    ///
    /// මෙම ක්‍රමය තනිවම ආරක්ෂිතයි, නමුත් එය නිවැරදිව භාවිතා කිරීම සඳහා අමතර සැලකිල්ලක් අවශ්‍ය වේ.
    /// මෙම ක්‍රමය ඇමතීම සහ ප්‍රති .ලය මත ක්‍රියා කිරීම අතර විභවයක් ඇතුළුව ඕනෑම වේලාවක දුර්වල ගණනය වෙනස් කළ හැකිය.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // මෙම ප්‍රකාශය නිර්ණායක වන්නේ අප නූල් අතර `Arc` හෝ `Weak` බෙදා නොගත් බැවිනි.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // දුර්වල ගණන දැනට අගුළු දමා තිබේ නම්, අගුල ගැනීමට පෙර ගණනය කිරීමේ අගය 0 ක් විය.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// මෙම වෙන් කිරීම සඳහා ශක්තිමත් (`Arc`) දර්ශක ගණන ලබා ගනී.
    ///
    /// # Safety
    ///
    /// මෙම ක්‍රමය තනිවම ආරක්ෂිතයි, නමුත් එය නිවැරදිව භාවිතා කිරීම සඳහා අමතර සැලකිල්ලක් අවශ්‍ය වේ.
    /// මෙම ක්‍රමය ඇමතීම සහ ප්‍රති .ලය මත ක්‍රියා කිරීම අතර විභවයක් ඇතුළුව ඕනෑම වේලාවක ප්‍රබල ගණනය වෙනස් කළ හැකිය.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // අපි `Arc` නූල් අතර බෙදා නොගත් නිසා මෙම ප්‍රකාශය තීරණාත්මක ය.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// සපයන ලද දර්ශකය හා සම්බන්ධ `Arc<T>` හි ප්‍රබල යොමු ගණන එකකින් වැඩි කරයි.
    ///
    /// # Safety
    ///
    /// දර්ශකය `Arc::into_raw` හරහා ලබාගෙන තිබිය යුතු අතර ඊට සම්බන්ධ `Arc` උදාහරණය වලංගු විය යුතුය (එනම්
    /// මෙම ක්‍රමයේ කාලසීමාව සඳහා ප්‍රබල ගණන අවම වශයෙන් 1) විය යුතුය.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // අපි `Arc` නූල් අතර බෙදා නොගත් නිසා මෙම ප්‍රකාශය තීරණාත්මක ය.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // චාප රඳවා තබා ගන්න, නමුත් මැනුවල් ඩ්‍රොප් ඔතා නැවත ගණනය කිරීම ස්පර්ශ නොකරන්න
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // දැන් refcount වැඩි කරන්න, නමුත් නව refcount එක අතහරින්න එපා
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// සපයන ලද දර්ශකය හා සම්බන්ධ `Arc<T>` හි ප්‍රබල යොමු ගණන එකකින් අඩු කරයි.
    ///
    /// # Safety
    ///
    /// දර්ශකය `Arc::into_raw` හරහා ලබාගෙන තිබිය යුතු අතර ඊට සම්බන්ධ `Arc` උදාහරණය වලංගු විය යුතුය (එනම්
    /// ප්‍රබල ගණනය අවම වශයෙන් 1) විය යුතුය.
    /// අවසාන `Arc` සහ පසුබිම් ආචයනය මුදා හැරීමට මෙම ක්‍රමය භාවිතා කළ හැකි නමුත් අවසාන `Arc` මුදා හැරීමෙන් පසු ** ඇමතිය යුතු නොවේ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // අපි `Arc` නූල් අතර බෙදා නොගත් නිසා එම ප්‍රකාශයන් තීරණාත්මක ය.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // මෙම චාපය ජීවත්ව සිටියදී අභ්‍යන්තර දර්ශකය වලංගු බව අපට සහතික වී ඇති නිසා මෙම අනාරක්ෂිත භාවය හරි ය.
        // තවද, `ArcInner` ව්‍යුහය `Sync` බව අපි දනිමු, මන්ද අභ්‍යන්තර දත්ත `Sync` වන බැවින් අපි මෙම අන්තර්ගතයන් සඳහා වෙනස් කළ නොහැකි දර්ශකයක් ලබා දෙන්නෙමු.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // `drop` හි නොබැඳි කොටස.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // කොටු වෙන් කිරීම අප විසින්ම නිදහස් නොකළද, මේ අවස්ථාවේ දී දත්ත විනාශ කරන්න (අවට දුර්වල දර්ශක තවමත් තිබිය හැක).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // සියලු ශක්තිමත් යොමු කිරීම් සාමූහිකව තබා ඇති දුර්වල ref එක අතහරින්න
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// ආර්ක් දෙක එකම වෙන් කිරීමකට යොමු කරන්නේ නම් ([`ptr::eq`] ට සමාන නහරයක) `true` ලබා දෙයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// වටිනාකමට පිරිසැලසුම සපයා ඇති තැනක නොවිසඳුනු අභ්‍යන්තර අගයක් සඳහා ප්‍රමාණවත් ඉඩ ප්‍රමාණයක් සහිත `ArcInner<T>` වෙන් කරයි.
    ///
    /// `mem_to_arcinner` ශ්‍රිතය දත්ත දර්ශකය සමඟ කැඳවනු ලබන අතර `ArcInner<T>` සඳහා (මේදය විය හැකි) පොයින්ටරයක් ආපසු ලබා දිය යුතුය.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // දී ඇති අගය පිරිසැලසුම භාවිතා කර පිරිසැලසුම ගණනය කරන්න.
        // මීට පෙර, පිරිසැලසුම `&*(ptr as* const ArcInner<T>)` ප්‍රකාශනය මත ගණනය කරන ලද නමුත් මෙය වැරදි ලෙස සකසන ලද සඳහනක් නිර්මාණය කළේය (#54908 බලන්න).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// අගය පිරිසැලසුම සපයා ඇති තැනක නොවිසඳුනු අභ්‍යන්තර අගයක් සඳහා ප්‍රමාණවත් ඉඩක් සහිත `ArcInner<T>` වෙන් කරයි, වෙන් කිරීම අසමත් වුවහොත් දෝෂයක් නැවත ලබා දේ.
    ///
    ///
    /// `mem_to_arcinner` ශ්‍රිතය දත්ත දර්ශකය සමඟ කැඳවනු ලබන අතර `ArcInner<T>` සඳහා (මේදය විය හැකි) පොයින්ටරයක් ආපසු ලබා දිය යුතුය.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // දී ඇති අගය පිරිසැලසුම භාවිතා කර පිරිසැලසුම ගණනය කරන්න.
        // මීට පෙර, පිරිසැලසුම `&*(ptr as* const ArcInner<T>)` ප්‍රකාශනය මත ගණනය කරන ලද නමුත් මෙය වැරදි ලෙස සකසන ලද සඳහනක් නිර්මාණය කළේය (#54908 බලන්න).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // ArcInner ආරම්භ කරන්න
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// ප්‍රමාණ නොකළ අභ්‍යන්තර අගයක් සඳහා ප්‍රමාණවත් ඉඩ ප්‍රමාණයක් සහිත `ArcInner<T>` වෙන් කරයි.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // දී ඇති අගය භාවිතා කරමින් `ArcInner<T>` සඳහා වෙන් කරන්න.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // අගය බයිට් ලෙස පිටපත් කරන්න
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // ප්‍රතිපාදන එහි අන්තර්ගතය අතහැර නොගෙන නිදහස් කරන්න
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// දී ඇති දිග සමඟ `ArcInner<[T]>` වෙන් කරයි.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// පෙත්තෙන් මූලද්‍රව්‍ය අලුතින් වෙන් කරන ලද චාපයට පිටපත් කරන්න <\[T\]>
    ///
    /// අනාරක්ෂිත බැවින් ඇමතුම්කරු හිමිකාරිත්වය හෝ `T: Copy` බන්ධනය කළ යුතුය.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// එක්තරා ප්‍රමාණයකින් යුත් iterator එකකින් `Arc<[T]>` සාදයි.
    ///
    /// ප්‍රමාණය වැරදියි නම් හැසිරීම නිර්වචනය කර නැත.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // T මූලද්‍රව්‍ය ක්ලෝන කරන අතරතුර Panic ආරක්ෂකයා.
        // panic අවස්ථාවකදී, නව ArcInner වෙත ලියා ඇති මූලද්‍රව්‍ය අතහැර දමනු ලැබේ, පසුව මතකය නිදහස් වේ.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // පළමු අංගයට දර්ශකය
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // සියල්ල පැහැදිලිය.ආරක්ෂකයා අමතක කරන්න එවිට එය නව ආර්ක්ඉනර් නිදහස් නොකරයි.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` සඳහා භාවිතා කරන trait විශේෂීකරණය.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// `Arc` දර්ශකයේ ක්ලෝනයක් සාදයි.
    ///
    /// මෙය එකම වෙන් කිරීමකට තවත් දර්ශකයක් නිර්මාණය කරයි, ශක්තිමත් යොමු ගණන වැඩි කරයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // මුල් යොමු කිරීම පිළිබඳ දැනුම වෙනත් නූල් වැරදි ලෙස වස්තුව මකා දැමීම වළක්වන බැවින් ලිහිල් ඇණවුමක් භාවිතා කිරීම මෙහි හරි ය.
        //
        // [Boost documentation][1] හි විස්තර කර ඇති පරිදි, විමර්ශන කවුන්ටරය වැඩි කිරීම සැමවිටම memory_order_relaxed සමඟ කළ හැකිය: වස්තුවක් සඳහා නව යොමු කිරීම් සෑදිය හැක්කේ පවතින යොමු කිරීමකින් පමණක් වන අතර, පවතින යොමුව එක් නූල් එකකින් තවත් නූලකට යැවීමෙන් දැනටමත් අවශ්‍ය ඕනෑම සමමුහුර්තතාවයක් ලබා දිය යුතුය.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // කෙසේ වෙතත් යමෙකු 'මතක: : අමතක' චාප නම් අප විශාල මුදල් ආපසු ගෙවීම් වලින් ආරක්ෂා විය යුතුය.
        // අප මෙය නොකරන්නේ නම්, ගණනය පිරී ඉතිරී යා හැකි අතර පරිශීලකයින් නොමිලේ භාවිතා කරනු ඇත.
        // සමුද්දේශ ගණන එකවර වැඩි කරන නූල් බිලියන ~2 නොමැති බව උපකල්පනය කරමින් අපි `isize::MAX` වෙත සංතෘප්ත වෙමු.
        //
        // මෙම branch කිසි විටෙක යථාර්ථවාදී වැඩසටහනක දී ගනු නොලැබේ.
        //
        // එවැනි වැඩපිළිවෙලක් ඇදහිය නොහැකි තරම් පරිහානියට පත්ව ඇති හෙයින් අපි එය නවතා දමන්නෙමු.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// දී ඇති `Arc` වෙත විකෘති යොමු කිරීමක් කරයි.
    ///
    /// එකම වෙන් කිරීම සඳහා වෙනත් `Arc` හෝ [`Weak`] දර්ශකයන් තිබේ නම්, `make_mut` නව ප්‍රතිපාදනයක් නිර්මාණය කර අද්විතීය හිමිකාරිත්වය සහතික කිරීම සඳහා අභ්‍යන්තර අගය මත [`clone`][clone] ඉල්ලා සිටී.
    /// මෙය ක්ලෝන-ඔන්-ලිවීම ලෙසද හැඳින්වේ.
    ///
    /// මෙය [`Rc::make_mut`] හි හැසිරීමට වඩා වෙනස් වන අතර එය ඉතිරිව ඇති ඕනෑම `Weak` දර්ශකයන් විසුරුවා හරියි.
    ///
    /// [`get_mut`][get_mut] ද බලන්න, එය ක්ලෝනකරණයට වඩා අසමත් වනු ඇත.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // කිසිවක් ක්ලෝන කරන්නේ නැහැ
    /// let mut other_data = Arc::clone(&data); // අභ්‍යන්තර දත්ත ක්ලෝන නොකරනු ඇත
    /// *Arc::make_mut(&mut data) += 1;         // අභ්‍යන්තර දත්ත ක්ලෝන කරයි
    /// *Arc::make_mut(&mut data) += 1;         // කිසිවක් ක්ලෝන කරන්නේ නැහැ
    /// *Arc::make_mut(&mut other_data) *= 2;   // කිසිවක් ක්ලෝන කරන්නේ නැහැ
    ///
    /// // දැන් `data` සහ `other_data` විවිධ ප්‍රතිපාදන වෙත යොමු කරයි.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // අප ශක්තිමත් යොමු කිරීමක් සහ දුර්වල යොමු කිරීමක් යන බව සලකන්න.
        // මේ අනුව, අපගේ ප්‍රබල යොමු කිරීම පමණක් නිකුත් කිරීමෙන් මතකය අවලංගු වීමට හේතු නොවේ.
        //
        // X001 වෙත මුදා හැරීමට පෙර (එනම්, අඩු කිරීම්) සිදුවන `weak` වෙත කිසියම් ලිවීමක් අප දකින බව සහතික කිරීමට Acquire භාවිතා කරන්න.
        // අප දුර්වල සංඛ්‍යාවක් තබා ඇති හෙයින්, ආර්ක්ඉන්නර් ඉවත් කිරීමට කිසිදු අවස්ථාවක් නැත.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // තවත් ශක්තිමත් දර්ශකයක් පවතී, එබැවින් අපි ක්ලෝන කළ යුතුය.
            // ක්ලෝන කළ අගය කෙලින්ම ලිවීමට ඉඩ දීම සඳහා මතකය කලින් වෙන් කරන්න.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // ඉහත සඳහන් කර ඇති පරිදි සෑහීමකට පත්වීම ප්‍රමාණවත් වන්නේ මෙය මූලික වශයෙන් ප්‍රශස්තිකරණයක් වන බැවිනි: අප සැමවිටම ධාවනය වන්නේ දුර්වල දර්ශකයන් අතහැර දමමිනි.
            // නරකම දෙය නම්, අපි අනවශ්‍ය ලෙස නව චාපයක් වෙන් කිරීමයි.
            //

            // අපි අන්තිම ශක්තිමත් ref ඉවත් කළෙමු, නමුත් අතිරේක දුර්වල refs ඉතිරිව ඇත.
            // අපි අන්තර්ගතය නව චාපයකට ගෙන යන අතර අනෙක් දුර්වල යොමු අවලංගු කරන්නෙමු.
            //

            // `weak` කියවීම සඳහා usize::MAX (එනම් අගුළු දමා) ලබා දිය නොහැකි බව සලකන්න, මන්ද දුර්වල ගණන අගුළු දැමිය හැක්කේ ශක්තිමත් යොමු සහිත නූල් එකකින් පමණි.
            //
            //

            // අපේම ව්‍යාජ දුර්වල දර්ශකය ද්‍රව්‍යකරණය කරන්න, එවිට අවශ්‍ය පරිදි ආර්ක්ඉන්නර් පිරිසිදු කළ හැකිය.
            //
            let _weak = Weak { ptr: this.ptr };

            // දත්ත සොරකම් කළ හැකිය, ඉතිරිව ඇත්තේ දුර්වලයි
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // අපි දෙයාකාරයකම එකම සඳහන විය;ශක්තිමත් ref ගණන නැවත ඉහළට ඔසවන්න.
            //
            this.inner().strong.store(1, Release);
        }

        // `get_mut()` හා සමානවම, අනාරක්ෂිත භාවය හරි නිසා අපගේ යොමු කිරීම ආරම්භ කිරීමට අද්විතීය වූ නිසා හෝ අන්තර්ගතය ක්ලෝන කිරීමෙන් පසුව එකක් බවට පත්විය.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// එකම ප්‍රතිපාදන සඳහා වෙනත් `Arc` හෝ [`Weak`] දර්ශකයන් නොමැති නම්, ලබා දී ඇති `Arc` වෙත විකෘති යොමු කිරීමක් ලබා දෙයි.
    ///
    ///
    /// හවුල් වටිනාකමක් විකෘති කිරීම ආරක්ෂිත නොවන නිසා [`None`] වෙනත් ආකාරයකින් ලබා දෙයි.
    ///
    /// [`make_mut`][make_mut] ද බලන්න, වෙනත් දර්ශක ඇති විට අභ්‍යන්තර අගය [`clone`][clone] වනු ඇත.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // මෙම අනාරක්ෂිත භාවය කමක් නැත, මන්ද ආපසු එවූ දර්ශකය * වෙත නැවත එවනු ලබන එකම එකම දර්ශකය බව අපට සහතික වී ඇත.
            // මෙම අවස්ථාවෙහිදී අපගේ යොමු ගණන 1 ක් බව සහතික කර ඇති අතර, අපට චාප `mut` විය යුතුය, එබැවින් අපි අභ්‍යන්තර දත්ත වෙත ඇති එකම යොමු කිරීම නැවත ලබා දෙන්නෙමු.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// කිසිදු චෙක්පතකින් තොරව, ලබා දී ඇති `Arc` වෙත විකෘති යොමු කිරීමක් ලබා දෙයි.
    ///
    /// [`get_mut`] ද බලන්න, එය ආරක්ෂිත වන අතර සුදුසු චෙක්පත් සිදු කරයි.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// එකම ප්‍රතිපාදන සඳහා වෙනත් ඕනෑම `Arc` හෝ [`Weak`] දර්ශක ආපසු ලබා ගත් ණය මුදල සඳහා අවලංගු නොකළ යුතුය.
    ///
    /// එවැනි දර්ශකයන් නොමැති නම් මෙය ඉතා සුළු කාරණයකි, උදාහරණයක් ලෙස `Arc::new` පසු වහාම.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // "count" ක්ෂේත්‍ර ආවරණය වන පරිදි යොමු කිරීමක් * නොකිරීමට අපි වගබලා ගනිමු, මෙය යොමු ගණන් වලට සමගාමී ප්‍රවේශයක් සහිත අන්වර්ථයක් වනු ඇත (උදා.
        // `Weak` විසින්).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// යටින් පවතින දත්ත සඳහා අද්විතීය යොමු කිරීම (දුර්වල යොමු කිරීම් ඇතුළුව) මෙයද යන්න තීරණය කරන්න.
    ///
    ///
    /// මේ සඳහා දුර්වල ref ගණන අගුළු දැමීම අවශ්‍ය බව සලකන්න.
    fn is_unique(&mut self) -> bool {
        // අප එකම දුර්වල දර්ශක දරන්නා ලෙස පෙනේ නම් දුර්වල දර්ශක ගණන අගුළු දමන්න.
        //
        // මෙහි අත්පත් කර ගැනීමේ ලේබලය `weak` ගණනය කිරීම අඩු කිරීමට පෙර (විශේෂයෙන් `Weak::upgrade` හි) `strong` වෙත (විශේෂයෙන් `Weak::upgrade` හි) ඕනෑම ලිවීමක් සමඟ සම්බන්ධතාවයක් ඇති බව සහතික කරයි (මුදා හැරීම භාවිතා කරන `Weak::drop` හරහා).
        // යාවත්කාලීන කරන ලද දුර්වල ref කිසි විටෙකත් අතහැරියේ නැත්නම්, මෙහි ඇති CAS අසාර්ථක වනු ඇත, එබැවින් සමමුහුර්ත කිරීමට අපට අවශ්‍ය නැත.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // `drop` හි `strong` කවුන්ටරයේ අඩුවීම සමඟ සමමුහුර්ත කිරීම සඳහා මෙය `Acquire` විය යුතුය-අන්තිම සඳහන හැර වෙනත් ඕනෑම දෙයක් සිදුවන විට සිදුවන එකම ප්‍රවේශය.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // මෙහි මුදා හැරීමේ ලිපිය `downgrade` හි කියවීම සමඟ සමමුහුර්ත වන අතර, `strong` හි ඉහත කියවීම ලිවීමෙන් පසුව සිදුවීම වලක්වනු ඇත.
            //
            //
            self.inner().weak.store(1, Release); // අගුල නිදහස් කරන්න
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// `Arc` පහත වැටේ.
    ///
    /// මෙය ශක්තිමත් යොමු ගණන අඩු කරනු ඇත.
    /// ප්‍රබල යොමු ගණන ශුන්‍යයට ළඟා වුවහොත් අනෙක් යොමු කිරීම් (ඇත්නම්) [`Weak`] වේ, එබැවින් අපි අභ්‍යන්තර අගය `drop` කරන්නෙමු.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // කිසිවක් මුද්‍රණය නොකරයි
    /// drop(foo2);   // "dropped!" මුද්‍රණය කරයි
    /// ```
    #[inline]
    fn drop(&mut self) {
        // `fetch_sub` දැනටමත් පරමාණුක බැවින්, අපි වස්තුව මකා දැමීමට යන්නේ නම් මිස වෙනත් නූල් සමඟ සමමුහුර්ත කිරීම අවශ්‍ය නොවේ.
        // මෙම තර්කනයම පහත දැක්වෙන `fetch_sub` සිට `weak` ගණනය කිරීම සඳහා අදාළ වේ.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // දත්ත භාවිතය නැවත සකස් කිරීම සහ දත්ත මකා දැමීම වැළැක්වීම සඳහා මෙම වැට අවශ්‍ය වේ.
        // එය `Release` ලෙස සලකුණු කර ඇති නිසා, යොමු ගණන අඩුවීම මෙම `Acquire` වැට සමඟ සමමුහුර්ත වේ.
        // මෙයින් අදහස් කරන්නේ දත්ත ගණනය කිරීම අඩු කිරීමට පෙර සිදු වන අතර එය වැටට පෙර සිදු වන අතර එය දත්ත මකා දැමීමට පෙර සිදු වේ.
        //
        // [Boost documentation][1] හි විස්තර කර ඇති පරිදි,
        //
        // > එකකට වස්තුවට හැකි ඕනෑම ප්‍රවේශයක් බලාත්මක කිරීම වැදගත් ය
        // > නූල් (පවතින යොමුවකින්)*මකා දැමීමට පෙර* සිදු වේ
        // > වස්තුව වෙනත් ත්‍රෙඩ් එකක.මෙය සාක්ෂාත් කරගනු ලබන්නේ "release" ය
        // > යොමු කිරීමක් අතහැර දැමීමෙන් පසු ක්‍රියාත්මක වීම (වස්තුවට ඕනෑම ප්‍රවේශයක්
        // > මෙම සඳහන හරහා පැහැදිලිවම මීට පෙර සිදුවිය යුතුය), සහ අ
        // > "acquire" වස්තුව මකා දැමීමට පෙර ක්‍රියාත්මක වීම.
        //
        // විශේෂයෙන්, චාපයක අන්තර්ගතය සාමාන්‍යයෙන් වෙනස් කළ නොහැකි වුවද, මුටෙක්ස් වැනි දෙයකට අභ්‍යන්තර ලිවීම් තිබිය හැකිය<T>.
        // මියුටෙක්ස් මකාදැමීමේදී එය අත්පත් කර නොගන්නා හෙයින්, නූල් වලින් ලිවීම සඳහා එහි සමමුහුර්තකරණ තර්කනය මත විශ්වාසය තැබිය නොහැක. නූල් බී හි ධාවනය වන ඩිස්ට්‍රැක්ටරයකට දෘශ්‍යමාන වේ.
        //
        //
        // මෙහි ඇති ඇක්වයිර් වැට බොහෝ විට ඇක්වයිර් බරක් මගින් ප්‍රතිස්ථාපනය කළ හැකි අතර එය ඉහළ තරඟකාරී අවස්ථාවන්හි කාර්ය සාධනය වැඩි දියුණු කළ හැකිය.[2] බලන්න.
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Arc<dyn Any + Send + Sync>` කොන්ක්‍රීට් වර්ගයකට පහත හෙලීමට උත්සාහ කිරීම.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// කිසිදු මතකයක් වෙන් නොකර නව `Weak<T>` සාදයි.
    /// ප්‍රතිලාභ අගය මත [`upgrade`] ඇමතීම සැමවිටම [`None`] ලබා දෙයි.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// දත්ත ක්‍ෂේත්‍රය පිළිබඳ කිසිදු ප්‍රකාශයක් නොකර විමර්ශන ගණන් වලට ප්‍රවේශ වීමට උදව් කිරීමට උපකාරක වර්ගය.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// මෙම `Weak<T>` විසින් පෙන්වා ඇති `T` වස්තුවට අමු දර්ශකයක් ලබා දෙයි.
    ///
    /// දර්ශකය වලංගු වන්නේ ප්‍රබල යොමු කිහිපයක් තිබේ නම් පමණි.
    /// දර්ශකය අන්තරාදායක, නොබැඳි හෝ [`null`] වෙනත් ආකාරයකින් විය හැකිය.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // දෙකම එකම වස්තුවකට යොමු කරයි
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // මෙහි ඇති ප්‍රබලයන් එය පණපිටින් තබා ගනී, එබැවින් අපට තවමත් වස්තුවට ප්‍රවේශ විය හැකිය.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // නමුත් තවත් නැත.
    /// // අපට weak.as_ptr() කළ හැකිය, නමුත් දර්ශකයට ප්‍රවේශ වීම නිර්වචනය නොකළ හැසිරීමට හේතු වේ.
    /// // assert_eq! ("හෙලෝ", අනාරක්ෂිත {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // දර්ශකය අන්තරාදායක නම්, අපි කෙලින්ම සෙන්ඩිනල් එක ආපසු එවන්නෙමු.
            // ගෙවීම් භාරය අවම වශයෙන් ArcInner (usize) ලෙස පෙලගැසී ඇති බැවින් මෙය වලංගු ගෙවුම් ලිපිනයක් විය නොහැක.
            ptr as *const T
        } else {
            // ආරක්ෂාව: is_dangling වැරදියි නම්, දර්ශකය අවලංගු කළ හැකිය.
            // මෙම අවස්ථාවෙහිදී ගෙවීම් භාරය අතහැර දැමිය හැකි අතර, අප විසින් ප්‍රභවයන් පවත්වා ගත යුතුය, එබැවින් අමු දර්ශක හැසිරවීම භාවිතා කරන්න.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// `Weak<T>` පරිභෝජනය කර එය අමු දර්ශකයක් බවට පත් කරයි.
    ///
    /// මෙය දුර්වල දර්ශකය අමු දර්ශකයක් බවට පරිවර්තනය කරයි, තවමත් එක් දුර්වල යොමුවක හිමිකාරිත්වය ආරක්ෂා කරයි (මෙම ක්‍රියාවෙන් දුර්වල ගණන වෙනස් නොවේ).
    /// එය [`from_raw`] සමඟ `Weak<T>` වෙත ආපසු හැරවිය හැකිය.
    ///
    /// [`as_ptr`] හා සමානව දර්ශකයේ ඉලක්කයට ප්‍රවේශ වීමේ සීමාවන් ද අදාළ වේ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// කලින් [`into_raw`] විසින් නිර්මාණය කරන ලද අමු දර්ශකයක් නැවත `Weak<T>` බවට පරිවර්තනය කරයි.
    ///
    /// මෙය ආරක්ෂිතව ශක්තිමත් යොමු කිරීමක් ලබා ගැනීමට (පසුව [`upgrade`] ඇමතීමෙන්) හෝ `Weak<T>` අතහැර දැමීමෙන් දුර්වල ගණන ඉවත් කිරීමට භාවිතා කළ හැකිය.
    ///
    /// එය එක් දුර්වල යොමු කිරීමක හිමිකාරිත්වය ගනී ([`new`] විසින් නිර්මාණය කරන ලද දර්ශකයන් හැරුණු විට, මේවාට කිසිවක් අයිති නැති බැවින්; ක්‍රමය තවමත් ඒවා මත ක්‍රියාත්මක වේ).
    ///
    /// # Safety
    ///
    /// දර්ශකය [`into_raw`] වෙතින් ආරම්භ වී තිබිය යුතු අතර එහි විභව දුර්වල යොමුව තවමත් තිබිය යුතුය.
    ///
    /// මෙය ඇමතීමේදී ශක්තිමත් ගණන 0 ක් වීමට අවසර ඇත.
    /// එසේ වුවද, මෙය දැනට අමු දර්ශකයක් ලෙස නිරූපණය කර ඇති එක් දුර්වල යොමුවක හිමිකාරිත්වය ගනී (මෙම ක්‍රියාවෙන් දුර්වල ගණන වෙනස් නොවේ) එබැවින් එය [`into_raw`] වෙත පෙර ඇමතුමක් සමඟ යුගල කළ යුතුය.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // අන්තිම දුර්වල ගණන අඩු කරන්න.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // ආදාන දර්ශකය ව්‍යුත්පන්න කර ඇති ආකාරය පිළිබඳ සන්දර්භය සඳහා Weak::as_ptr බලන්න.

        let ptr = if is_dangling(ptr as *mut T) {
            // මෙය දුර්වල දුර්වලයකි.
            ptr as *mut ArcInner<T>
        } else {
            // එසේ නොමැතිනම්, දර්ශකය පැමිණියේ දුර්වල දුර්වලතාවයකින් බව අපට සහතිකයි.
            // සුරක්ෂිතභාවය: දත්ත_ ඕෆ්සෙට් ඇමතීම ආරක්ෂිතයි, ptr විසින් නියම (අතහැර දැමිය හැකි) ටී.
            let offset = unsafe { data_offset(ptr) };
            // මේ අනුව, අපි මුළු RcBox ලබා ගැනීම සඳහා ඕෆ්සෙට් ආපසු හරවන්නෙමු.
            // සුරක්ෂිතභාවය: දර්ශකය ආරම්භ වූයේ දුර්වලයෙකු වන බැවින් මෙම ඕෆ්සෙට් එක ආරක්ෂිතයි.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // ආරක්ෂාව: අපි දැන් මුල් දුර්වල දර්ශකය සොයාගෙන ඇත, එබැවින් දුර්වල නිර්මාණය කළ හැකිය.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// `Weak` දර්ශකය [`Arc`] දක්වා උත්ශ්‍රේණි කිරීමට උත්සාහ කිරීම, සාර්ථක නම් අභ්‍යන්තර අගය පහත වැටීම ප්‍රමාද කරයි.
    ///
    ///
    /// එතැන් සිට අභ්‍යන්තර අගය අතහැර දමා ඇත්නම් [`None`] ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // සියලු ශක්තිමත් දර්ශකයන් විනාශ කරන්න.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Get_add වෙනුවට ශක්තිමත් ගණන වැඩි කිරීම සඳහා අපි CAS පුඩුවක් භාවිතා කරමු, මන්ද මෙම ශ්‍රිතය කිසි විටෙකත් යොමු ගණන ශුන්‍යයේ සිට එකකට නොගත යුතුය.
        //
        //
        let inner = self.inner()?;

        // අපට නිරීක්ෂණය කළ හැකි 0 ලිවීමෙන් ක්ෂේත්‍රය ස්ථිර ශුන්‍ය තත්වයකට පත්වන හෙයින් (0 හි "stale" කියවීම හොඳයි), සහ වෙනත් ඕනෑම අගයක් පහත CAS හරහා තහවුරු වේ.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // අප මෙය කරන්නේ ඇයිද යන්න සඳහා `Arc::clone` හි අදහස් බලන්න (`mem::forget` සඳහා).
            if n > MAX_REFCOUNT {
                abort();
            }

            // නව රාජ්‍යය පිළිබඳව අපට කිසිදු අපේක්ෂාවක් නොමැති නිසා අසාර්ථක නඩුව සඳහා ලිහිල් කිරීම හොඳයි.
            // `Weak` යොමු කිරීම් දැනටමත් නිර්මාණය කිරීමෙන් පසු අභ්‍යන්තර අගය ආරම්භ කළ හැකි විට, සාර්ථක නඩුව `Arc::new_cyclic` සමඟ සමමුහුර්ත කිරීම සඳහා අත්පත් කර ගැනීම අවශ්‍ය වේ.
            // එවැනි අවස්ථාවකදී, පූර්ණ ආරම්භක අගය නිරීක්ෂණය කිරීමට අපි අපේක්ෂා කරමු.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // ඉහත ශූන්‍යය පරීක්ෂා කර ඇත
                Err(old) => n = old,
            }
        }
    }

    /// මෙම වෙන් කිරීම වෙත යොමු කරන ශක්තිමත් (`Arc`) දර්ශක ගණන ලබා ගනී.
    ///
    /// [`Weak::new`] භාවිතා කරමින් `self` නිර්මාණය කර ඇත්නම්, මෙය 0 නැවත ලබා දෙනු ඇත.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// මෙම වෙන් කිරීම වෙත යොමු වන `Weak` දර්ශක ගණන ආසන්න වශයෙන් ලබා ගනී.
    ///
    /// [`Weak::new`] භාවිතා කරමින් `self` නිර්මාණය කර ඇත්නම් හෝ ඉතිරිව ඇති ශක්තිමත් දර්ශකයන් නොමැති නම්, මෙය 0 නැවත ලබා දෙනු ඇත.
    ///
    /// # Accuracy
    ///
    /// ක්‍රියාත්මක කිරීමේ විස්තර හේතුවෙන්, වෙනත් නූල් ඕනෑම වෙන්කිරීමක් පෙන්වමින් ඕනෑම චාපයක් හෝ දුර්වල එකක් හසුරුවන විට ආපසු ලබා දුන් අගය දෙපැත්තකින් 1 කින් අක්‍රිය කළ හැකිය.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // දුර්වල ගණනය කියවීමෙන් පසු අවම වශයෙන් එක් ප්‍රබල දර්ශකයක්වත් ඇති බව අප නිරීක්ෂණය කළ හෙයින්, දුර්වල ගණනය කිරීම් නිරීක්ෂණය කරන විට ව්‍යංග දුර්වල යොමු කිරීම (ඕනෑම ප්‍රබල යොමු කිරීමක් ජීවමානව පවතින සෑම අවස්ථාවකම) තවමත් පවතින බව අපි දනිමු. එබැවින් එය ආරක්ෂිතව අඩු කළ හැකිය.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// දර්ශකය ගැටෙන විට සහ වෙන් කරන ලද `ArcInner` නොමැති විට `None` ලබා දෙයි, (එනම්, මෙම `Weak` `Weak::new` විසින් නිර්මාණය කරන විට).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // ක්ෂේත්‍රය සමගාමීව විකෘති විය හැකි බැවින්, "data" ක්ෂේත්‍රය ආවරණය වන පරිදි * යොමු නොකිරීමට අපි වගබලා ගනිමු (නිදසුනක් ලෙස, අවසාන `Arc` අතහැර දැමුවහොත්, දත්ත ක්ෂේත්‍රය තැනින් තැන වැටෙනු ඇත).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// දුර්වලයන් දෙදෙනා එකම වෙන් කිරීමකට ([`ptr::eq`] ට සමාන) යොමු කරන්නේ නම් හෝ දෙකම කිසිදු ප්‍රතිපාදනයක් වෙත යොමු නොකරන්නේ නම් (ඒවා `Weak::new()`) සමඟ නිර්මාණය කර ඇති නිසා) `true` ලබා දෙයි.
    ///
    ///
    /// # Notes
    ///
    /// මෙය දර්ශකයන් සංසන්දනය කරන බැවින් එයින් අදහස් වන්නේ `Weak::new()` එකිනෙකට සමාන වන බවයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` සංසන්දනය කිරීම.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// එකම වෙන් කිරීමකට යොමු වන `Weak` දර්ශකයේ ක්ලෝනයක් සාදයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // මෙය ලිහිල් වන්නේ මන්දැයි Arc::clone() හි අදහස් බලන්න.
        // දුර්වල ගණනය අගුළු දමා ඇත්තේ *වෙනත්* දුර්වල දර්ශක නොමැති තැන පමණක් බැවින් මෙය fetch_add (අගුල නොසලකා හැරීම) භාවිතා කළ හැකිය.
        //
        // (එබැවින් අපට මෙම කේතය එවැනි අවස්ථාවක ක්‍රියාත්මක කළ නොහැක).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // අප මෙය කරන්නේ ඇයිද යන්න සඳහා Arc::clone() හි අදහස් බලන්න (mem::forget සඳහා).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// මතකය වෙන් නොකර නව `Weak<T>` සාදයි.
    /// ප්‍රතිලාභ අගය මත [`upgrade`] ඇමතීම සැමවිටම [`None`] ලබා දෙයි.
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` දර්ශකය පහත වැටේ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // කිසිවක් මුද්‍රණය නොකරයි
    /// drop(foo);        // "dropped!" මුද්‍රණය කරයි
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // අප අන්තිම දුර්වල දර්ශකය බව සොයා ගන්නේ නම්, දත්ත මුළුමනින්ම අවලංගු කිරීමට කාලයයි.මතක ඇණවුම් ගැන Arc::drop() හි සාකච්ඡාව බලන්න
        //
        // මෙහි අගුලු දමා ඇති තත්වය පරීක්ෂා කිරීම අවශ්‍ය නොවේ, මන්ද දුර්වල ගණන අගුළු දැමිය හැක්කේ හරියටම එක් දුර්වල ref එකක් තිබුනේ නම් පමණි, එයින් අදහස් වන්නේ පහත වැටීම පසුව ක්‍රියාත්මක විය හැක්කේ ඉතිරි දුර්වල ref මත පමණක් වන අතර එය සිදුවිය හැක්කේ අගුල මුදා හැරීමෙන් පසුව පමණි.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// අපි මෙහි විශේෂීකරණය කරන්නේ `&T` හි වඩාත් පොදු ප්‍රශස්තිකරණයක් ලෙස නොවේ, මන්ද එය වෙනත් ආකාරයකින් සමානාත්මතා පරීක්ෂාවන් සඳහා පිරිවැයක් එකතු කරන බැවිනි.
/// අපි උපකල්පනය කරන්නේ ක්ලෝන කිරීමට මන්දගාමී වන සමානාත්මතාවය පරීක්ෂා කිරීම සඳහා බරක් වන විශාල අගයන් ගබඩා කිරීම සඳහා ආර්ක් භාවිතා කරන බවයි, එමඟින් මෙම පිරිවැය වඩාත් පහසුවෙන් ගෙවීමට සිදුවේ.
///
/// එය X&X ක්ලෝන දෙකක් තිබීමට වැඩි ඉඩක් ඇත, එය එකම අගයට යොමු කරයි, `&T` ට වඩා.
///
/// අපට මෙය කළ හැක්කේ `T: Eq` ලෙස `T: Eq` හිතාමතාම අක්‍රිය කළ හැකි විට පමණි.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// චාප දෙකක් සඳහා සමානාත්මතාවය.
    ///
    /// විවිධ වෙන්කිරීම්වල ගබඩා කර තිබුණද, ඒවායේ අභ්‍යන්තර අගයන් සමාන නම්, චාප දෙකක් සමාන වේ.
    ///
    /// `T` ද `Eq` (සමානාත්මතාවයේ ප්‍රත්‍යාවර්තකතාව අඟවයි) ක්‍රියාත්මක කරන්නේ නම්, එකම වෙන් කිරීමකට යොමු වන චාප දෙකක් සෑම විටම සමාන වේ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// චාප දෙකක් සඳහා අසමානතාවය.
    ///
    /// චාප දෙකක් ඒවායේ අභ්‍යන්තර අගයන් අසමාන නම් අසමාන වේ.
    ///
    /// `T` ද `Eq` (සමානාත්මතාවයේ ප්‍රත්‍යාවර්තකතාව අඟවයි) ක්‍රියාත්මක කරන්නේ නම්, එකම අගයට යොමු වන චාප දෙකක් කිසි විටෙක අසමාන නොවේ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// චාප දෙකක් සඳහා අර්ධ සංසන්දනය.
    ///
    /// මේ දෙක සංසන්දනය කරනුයේ ඒවායේ අභ්‍යන්තර අගයන් මත `partial_cmp()` ඇමතීමෙනි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// චාප දෙකක් සඳහා සැසඳීමට වඩා අඩුය.
    ///
    /// මේ දෙක සංසන්දනය කරනුයේ ඒවායේ අභ්‍යන්තර අගයන් මත `<` ඇමතීමෙනි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// චාප දෙකක් සඳහා සංසන්දනය 'අඩු හෝ සමාන'.
    ///
    /// මේ දෙක සංසන්දනය කරනුයේ ඒවායේ අභ්‍යන්තර අගයන් මත `<=` ඇමතීමෙනි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// චාප දෙකක් සඳහා සැසඳීමට වඩා විශාලයි.
    ///
    /// මේ දෙක සංසන්දනය කරනුයේ ඒවායේ අභ්‍යන්තර අගයන් මත `>` ඇමතීමෙනි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// චාප දෙකක් සඳහා සංසන්දනය 'වඩා විශාල හෝ සමාන'.
    ///
    /// මේ දෙක සංසන්දනය කරනුයේ ඒවායේ අභ්‍යන්තර අගයන් මත `>=` ඇමතීමෙනි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// චාප දෙකක් සඳහා සංසන්දනය.
    ///
    /// මේ දෙක සංසන්දනය කරනුයේ ඒවායේ අභ්‍යන්තර අගයන් මත `cmp()` ඇමතීමෙනි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// `T` සඳහා `Default` අගය සමඟ නව `Arc<T>` නිර්මාණය කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// යොමු ගණනය කළ පෙත්තක් වෙන් කර `v` හි අයිතම ක්ලෝන කිරීමෙන් එය පුරවන්න.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// යොමු ගණන් කළ `str` වෙන් කර `v` පිටපත් කරන්න.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// යොමු ගණන් කළ `str` වෙන් කර `v` පිටපත් කරන්න.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// කොටු කළ වස්තුවක් නව, යොමු-ගණනය කළ වෙන් කිරීමකට ගෙන යන්න.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// යොමු ගණන් කළ පෙත්තක් වෙන් කර `v` ගේ අයිතම ඒ තුළට ගෙන යන්න.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Vec හට එහි මතකය නිදහස් කිරීමට ඉඩ දෙන්න, නමුත් එහි අන්තර්ගතය විනාශ නොකරන්න
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// `Iterator` හි එක් එක් මූලද්රව්යය ගෙන එය `Arc<[T]>` වෙත එකතු කරයි.
    ///
    /// # කාර්ය සාධන ලක්ෂණ
    ///
    /// ## පොදු නඩුව
    ///
    /// පොදුවේ ගත් කල, `Arc<[T]>` වෙත එකතු කිරීම සිදු කරනු ලබන්නේ පළමුව `Vec<T>` වෙත එකතු කිරීමෙනි.එනම්, පහත සඳහන් කරුණු ලිවීමේදී:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// මෙය හැසිරෙන්නේ අප ලියා ඇති ආකාරයට ය:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // පළමු ප්‍රතිපාදන මාලාව මෙහි සිදු වේ.
    ///     .into(); // `Arc<[T]>` සඳහා දෙවන වෙන් කිරීම මෙහි සිදු වේ.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// මෙය `Vec<T>` ඉදිකිරීම සඳහා අවශ්‍ය තරම් වාර ගණනක් වෙන් කරනු ඇති අතර පසුව එය `Vec<T>` `Arc<[T]>` බවට හැරවීම සඳහා එක් වරක් වෙන් කරනු ඇත.
    ///
    ///
    /// ## දන්නා දිග අනුභව කරන්නන්
    ///
    /// ඔබේ `Iterator` `TrustedLen` ක්‍රියාත්මක කර නිශ්චිත ප්‍රමාණයෙන් යුක්ත වන විට, `Arc<[T]>` සඳහා තනි වෙන් කිරීමක් කරනු ලැබේ.උදාහරණ වශයෙන්:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // එක් වෙන් කිරීමක් පමණක් මෙහි සිදු වේ.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// `Arc<[T]>` වෙත එකතු කිරීම සඳහා භාවිතා කරන trait විශේෂීකරණය.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // `TrustedLen` iterator සඳහා තත්වය මෙයයි.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // සුරක්ෂිතභාවය: අනුකාරකයට නිශ්චිත දිගක් ඇති බවට අප සහතික විය යුතුය.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // සාමාන්‍ය ක්‍රියාත්මක කිරීම වෙත ආපසු යන්න.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// දර්ශකයක් පිටුපස ගෙවීම සඳහා `ArcInner` තුළ ඕෆ්සෙට් ලබා ගන්න.
///
/// # Safety
///
/// දර්ශකයේ පෙර වලංගු T අවස්ථාවක් වෙත යොමු විය යුතුය (සහ වලංගු පාර-දත්ත තිබිය යුතුය), නමුත් T අතහැර දැමීමට අවසර ඇත.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // ArcInner හි අවසානයට නොවිසඳුණු අගය පෙළගස්වන්න.
    // RcBox repr(C) බැවින් එය සැමවිටම මතකයේ අවසාන ක්ෂේත්‍රය වනු ඇත.
    // ආරක්ෂාව: කළ නොහැකි එකම වර්ගයේ පෙති, trait වස්තු,
    // සහ බාහිර වර්ගවල, align_of_val_raw හි අවශ්‍යතා සපුරාලීම සඳහා ආදාන ආරක්ෂණ අවශ්‍යතාවය දැනට ප්‍රමාණවත් වේ;මෙය std ට පිටතින් රඳා නොපවතින භාෂාවේ ක්‍රියාත්මක කිරීමේ විස්තරයකි.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}