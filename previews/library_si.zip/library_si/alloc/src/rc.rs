//! තනි-නූල් යොමු-ගණන් කිරීමේ දර්ශක.'Rc' යනු 'යොමු කිරීම' යන්නයි
//! Counted'.
//!
//! [`Rc<T>`][`Rc`] වර්ගය ගොඩවල වෙන් කර ඇති `T` වර්ගයේ වටිනාකමක හවුල් හිමිකම සපයයි.
//! [`Rc`] හි [`clone`][clone] ආයාචනය කිරීමෙන් ගොඩවල එකම වෙන් කිරීම සඳහා නව දර්ශකයක් නිපදවයි.
//! දී ඇති ප්‍රතිපාදන සඳහා අවසාන [`Rc`] දර්ශකය විනාශ වූ විට, එම ප්‍රතිපාදන තුළ ගබඩා කර ඇති අගය (බොහෝ විට "inner value" ලෙස හැඳින්වේ) ද පහත වැටේ.
//!
//! Rust හි හවුල් යොමු කිරීම් පෙරනිමියෙන් විකෘතියට ඉඩ නොදේ, සහ [`Rc`] ද ව්‍යතිරේකයක් නොවේ: ඔබට සාමාන්‍යයෙන් [`Rc`] තුළ ඇති දෙයක් ගැන විකෘති යොමු කිරීමක් ලබා ගත නොහැක.
//! ඔබට විකෘතිතාව අවශ්‍ය නම්, [`Rc`] තුළ [`Cell`] හෝ [`RefCell`] දමන්න;[an example of mutability inside an `Rc`][mutability] බලන්න.
//!
//! [`Rc`] පරමාණුක නොවන යොමු ගණන් කිරීම භාවිතා කරයි.
//! මෙයින් අදහස් කරන්නේ උඩිස් ඉතා අඩු නමුත් නූල් අතර [`Rc`] යැවිය නොහැකි අතර එහි ප්‍රති X ලයක් ලෙස [`Rc`] [`Send`][send] ක්‍රියාත්මක නොකරයි.
//! එහි ප්‍රති As ලයක් ලෙස, ඔබ නූල් අතර [`Rc`] යවන්නේ නැතිදැයි Rust සම්පාදකයා සම්පාදනය කරන වේලාවේදී * පරීක්ෂා කරයි.
//! ඔබට බහු-නූල්, පරමාණුක යොමු ගණන් කිරීම අවශ්‍ය නම්, [`sync::Arc`][arc] භාවිතා කරන්න.
//!
//! [`downgrade`][downgrade] ක්‍රමය අයිති නොවන [`Weak`] දර්ශකයක් නිර්මාණය කිරීමට භාවිතා කළ හැකිය.
//! [`Weak`] දර්ශකයක් [`Rc`] වෙත [උත්ශ්‍රේණිගත කිරීම] විය හැකිය, නමුත් වෙන් කිරීම තුළ ගබඩා කර ඇති අගය දැනටමත් අතහැර දමා ඇත්නම් මෙය [`None`] ආපසු ලබා දෙනු ඇත.
//! වෙනත් වචන වලින් කිවහොත්, `Weak` දර්ශකයන් වෙන් කිරීම තුළ ඇති වටිනාකම සජීවීව තබා නොගනී;කෙසේ වෙතත්, ඔවුන් වෙන් කිරීම (අභ්‍යන්තර වටිනාකම සඳහා ආධාරක ගබඩාව) පණපිටින් තබා ගනී.
//!
//! [`Rc`] පොයින්ටර් අතර චක්‍රයක් කිසි විටෙකත් අවලංගු නොවේ.
//! මෙම හේතුව නිසා, [`Weak`] චක්ර බිඳ දැමීමට භාවිතා කරයි.
//! නිදසුනක් ලෙස, ගසකට මව් නෝඩ් සිට ළමයින් දක්වා ශක්තිමත් [`Rc`] පොයින්ටර්ස් තිබිය හැකි අතර, [`Weak`] පොයින්ටර්ස් දරුවන්ගේ සිට දෙමාපියන් වෙත ආපසු යා හැකිය.
//!
//! `Rc<T>` `T` වෙත ස්වයංක්‍රීයව විරූපණය වේ ([`Deref`] trait හරහා), එබැවින් ඔබට [`Rc<T>`][`Rc`] වර්ගයේ අගය මත `T` ක්‍රම අමතන්න.
//! `T` ක්‍රම සමඟ නාම ගැටුම් වලක්වා ගැනීම සඳහා, [`Rc<T>`][`Rc`] හි ක්‍රමවේදයන්ම සම්බන්ධිත කාර්යයන් වේ.
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `ආර්.සී.<T>`Clone` වැනි traits ක්‍රියාත්මක කිරීම පූර්ණ සුදුසුකම් ලත් සින්ටැක්ස් භාවිතයෙන් ද හැඳින්විය හැකිය.
//! සමහර අය සම්පුර්ණ සුදුසුකම් ලත් සින්ටැක්ස් භාවිතා කිරීමට කැමැත්තක් දක්වන අතර අනෙක් අය ක්‍රම-ඇමතුම් සින්ටැක්ස් භාවිතා කිරීමට කැමැත්තක් දක්වයි.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // ක්‍රමය-ඇමතුම් සින්ටැක්ස්
//! let rc2 = rc.clone();
//! // සම්පුර්ණ සුදුසුකම් ලත් සින්ටැක්ස්
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] `T` වෙත ස්වයංක්‍රීයව විරූපණය නොකෙරේ, මන්ද අභ්‍යන්තර අගය දැනටමත් අතහැර දමා ඇති බැවිනි.
//!
//! # ක්ලෝන යොමු කිරීම්
//!
//! [`Rc<T>`][`Rc`] සහ [`Weak<T>`][`Weak`] සඳහා ක්‍රියාත්මක කර ඇති `Clone` trait භාවිතා කරමින් දැනට පවතින යොමු ගණන් කළ දර්ශකයක් ලෙස එකම වෙන් කිරීමකට නව යොමු කිරීමක් නිර්මාණය කිරීම සිදු කෙරේ.
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // පහත සින්ටැක්ස් දෙක සමාන වේ.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a සහ b යන දෙකම foo ලෙස එකම මතක ස්ථානයට යොමු කරයි.
//! ```
//!
//! `Rc::clone(&from)` සින්ටැක්ස් වඩාත් මුග්ධ වන්නේ එය කේතයේ අර්ථය වඩාත් පැහැදිලිව ගෙනහැර දක්වන බැවිනි.
//! ඉහත උදාහරණයේ දී, මෙම වාක්‍ය ඛණ්ඩය foo හි සමස්ත අන්තර්ගතය පිටපත් කරනවාට වඩා නව කේතයක් නිර්මාණය කරන බව දැකීම පහසු කරයි.
//!
//! # Examples
//!
//! දී ඇති `Owner` සමාගමට 'ගැජට්' කට්ටලයක් හිමිවන අවස්ථාවක් සලකා බලන්න.
//! අපගේ 'ගැජට්' ලක්ෂ්‍යය ඔවුන්ගේ `Owner` වෙත යොමු කිරීමට අපට අවශ්‍යය.අද්විතීය හිමිකාරිත්වයකින් අපට මෙය කළ නොහැක, මන්ද එක් ගැජට් එකකට වඩා එකම `Owner` ට අයත් විය හැකිය.
//! [`Rc`] බහු ගැජට් අතර `Owner` බෙදා ගැනීමට අපට ඉඩ සලසයි, තවද ඕනෑම `Gadget` ලක්ෂ්‍යයක් පවතින තාක් කල් `Owner` වෙන් කර තබන්න.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... වෙනත් ක්ෂේත්‍ර
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... වෙනත් ක්ෂේත්‍ර
//! }
//!
//! fn main() {
//!     // යොමු ගණන් කළ `Owner` සාදන්න.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // `gadget_owner` ට අයත් 'ගැජට්' සාදන්න.
//!     // `Rc<Owner>` ක්ලෝන කිරීම මඟින් එකම `Owner` වෙන් කිරීම සඳහා නව දර්ශකයක් ලබා දෙයි, එම ක්‍රියාවලියේදී විමර්ශන ගණන වැඩි කරයි.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // අපගේ දේශීය විචල්ය `gadget_owner` බැහැර කරන්න.
//!     drop(gadget_owner);
//!
//!     // `gadget_owner` අතහැර දැමුවද, අපට තවමත් 'ගැජට්' හි `Owner` හි නම මුද්‍රණය කළ හැකිය.
//!     // මෙයට හේතුව අප අතහැර ඇත්තේ එක් `Rc<Owner>` එකක් මිස එය පෙන්වා දෙන `Owner` නොවේ.
//!     // එකම `Owner` වෙන්කිරීමේදී වෙනත් `Rc<Owner>` යොමු කරන තාක් කල් එය සජීවීව පවතිනු ඇත.
//!     // `Rc<Owner>` ක්ෂේත්‍ර ප්‍රක්ෂේපණය ක්‍රියාත්මක වන්නේ `Rc<Owner>` ස්වයංක්‍රීයව `Owner` වෙත විරූපණය වන බැවිනි.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // ශ්‍රිතය අවසානයේ, `gadget1` සහ `gadget2` විනාශ වන අතර, ඒවා සමඟ අපගේ `Owner` වෙත අවසන් වරට ගණන් කරන ලද යොමු කිරීම්.
//!     // ගැජට් මිනිසා දැන් විනාශ වී ඇත.
//!     //
//! }
//! ```
//!
//! අපගේ අවශ්‍යතා වෙනස් වුවහොත් සහ අපට `Owner` සිට `Gadget` දක්වා ගමන් කිරීමට හැකියාව තිබිය යුතු නම්, අපි ගැටළු වලට මුහුණ දෙන්නෙමු.
//! `Owner` සිට `Gadget` දක්වා [`Rc`] දර්ශකයක් චක්‍රයක් හඳුන්වා දෙයි.
//! මෙයින් අදහස් කරන්නේ ඔවුන්ගේ යොමු ගණන් කිසි විටෙකත් 0 කරා ළඟා විය නොහැකි අතර ප්‍රතිපාදන කිසි විටෙකත් විනාශ නොවන බවයි:
//! මතක කාන්දුවක්.මෙය මඟහරවා ගැනීම සඳහා අපට [`Weak`] පොයින්ටර් භාවිතා කළ හැකිය.
//!
//! Rust ඇත්ත වශයෙන්ම මෙම ලූපය මුලින්ම නිපදවීම තරමක් අපහසු කරයි.එකිනෙකට යොමු වන අගයන් දෙකක් සමඟ අවසන් වීමට නම්, ඒවායින් එකක් විකෘති විය යුතුය.
//! මෙය දුෂ්කර වන්නේ [`Rc`] මතක ආරක්ෂාව ක්‍රියාත්මක කරන්නේ එය ඔතා ඇති වටිනාකමට හවුල් යොමු කිරීම් පමණක් කිරීමෙන් වන අතර මේවා සෘජු විකෘතියට ඉඩ නොදේ.
//! අප විසින් විකෘති කිරීමට බලාපොරොත්තු වන වටිනාකමින් කොටසක් [`RefCell`] වලින් ඔතා තැබිය යුතුය, එය *අභ්‍යන්තර විකෘතිතාව* සපයයි: හවුල් යොමුවකින් විකෘතිතාව ළඟා කර ගැනීමේ ක්‍රමයකි.
//! [`RefCell`] ක්‍රියාත්මක වන වේලාවේදී Rust හි ණය ගැනීමේ නීති ක්‍රියාත්මක කරයි.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... වෙනත් ක්ෂේත්‍ර
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... වෙනත් ක්ෂේත්‍ර
//! }
//!
//! fn main() {
//!     // යොමු ගණන් කළ `Owner` සාදන්න.
//!     // අපි 'ගැජට්' හි හිමිකරුගේ vector `RefCell` තුළ තබා ඇති බව සලකන්න, එවිට අපට එය හවුල් යොමු කිරීමක් හරහා විකෘති කළ හැකිය.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // පෙර මෙන් `gadget_owner` ට අයත් 'ගැජට්' සාදන්න.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // ඔවුන්ගේ `Owner` වෙත `ගැජට් 'එක් කරන්න.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` ගතික ණය මෙතැනින් අවසන් වේ.
//!     }
//!
//!     // අපගේ ගැජට් ගැන විස්තර කර ඒවායේ තොරතුරු මුද්‍රණය කරන්න.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` `Weak<Gadget>` වේ.
//!         // `Weak` දර්ශකයන්ට වෙන් කිරීම තවමත් පවතින බව සහතික කළ නොහැකි බැවින්, අපට `upgrade` අමතන්න, එය `Option<Rc<Gadget>>` ලබා දෙයි.
//!         //
//!         //
//!         // මෙම අවස්ථාවේ දී අපි දන්නවා වෙන් කිරීම තවමත් පවතින බව, එබැවින් අපි සරලවම `unwrap` `Option`.
//!         // වඩාත් සංකීර්ණ වැඩසටහනක දී, ඔබට `None` ප්‍රති .ලයක් සඳහා අලංකාර දෝෂ හැසිරවීමක් අවශ්‍ය විය හැකිය.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // ශ්‍රිතය අවසානයේ `gadget_owner`, `gadget1` සහ `gadget2` විනාශ වේ.
//!     // ගැජට් වලට දැන් ශක්තිමත් (`Rc`) දර්ශක නොමැත, එබැවින් ඒවා විනාශ වේ.
//!     // මෙය ගැජට් මෑන් පිළිබඳ යොමු ගණන ශුන්‍ය කරයි, එබැවින් ඔහු ද විනාශ වේ.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// මෙය ක්ෂේත්‍ර ප්‍රතිසංවිධානයට එරෙහිව repr(C) සිට future-සාධනයකි, එමඟින් සම්ප්‍රේෂණය කළ හැකි අභ්‍යන්තර වර්ගවල ආරක්ෂිත [into|from]_raw() වලට බාධා ඇති වේ.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// තනි-නූල් යොමු-ගණන් කිරීමේ දර්ශකය.'Rc' යනු 'යොමු කිරීම' යන්නයි
/// Counted'.
///
/// වැඩි විස්තර සඳහා [module-level documentation](./index.html) බලන්න.
///
/// `Rc` හි ආවේනික ක්‍රම සියල්ලම සම්බන්ධිත කාර්යයන් වන අතර එයින් අදහස් වන්නේ ඔබ ඒවා `value.get_mut()` වෙනුවට උදා: [`Rc::get_mut(&mut value)`][get_mut] ලෙස හැඳින්විය යුතු බවයි.
/// මෙය `T` අභ්‍යන්තර වර්ගයේ ක්‍රම සමඟ ගැටුම් වළක්වයි.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // මෙම අනාරක්ෂිත භාවය හරි, මන්ද මෙම ආර්සී ජීවතුන් අතර සිටියදී අභ්‍යන්තර දර්ශකය වලංගු බව අපට සහතිකයි.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// නව `Rc<T>` සාදයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // සියලු ප්‍රබල දර්ශකයන් සතු ව්‍යංග දුර්වල දර්ශකයක් ඇත, එමඟින් දුර්වල ඩිස්ට්‍රැක්ටරය කිසි විටෙකත් ප්‍රතිපාදන නිදහස් නොකරන බව සහතික කරයි.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// තමාටම දුර්වල යොමු කිරීමක් භාවිතා කරමින් නව `Rc<T>` සාදයි.
    /// මෙම ශ්‍රිතය නැවත පැමිණීමට පෙර දුර්වල යොමුව යාවත්කාලීන කිරීමට උත්සාහ කිරීමෙන් `None` අගයක් ලැබෙනු ඇත.
    ///
    /// කෙසේ වෙතත්, දුර්වල යොමුව නිදහසේ ක්ලෝන කර පසුව භාවිතා කිරීම සඳහා ගබඩා කළ හැකිය.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... තවත් ක්ෂේත්‍ර
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // "uninitialized" තත්වයේ අභ්‍යන්තරය තනි දුර්වල යොමුවකින් සාදන්න.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // දුර්වල දර්ශකයේ හිමිකම අපි අත් නොහැරීම වැදගත්ය, නැතහොත් `data_fn` නැවත පැමිණෙන විට මතකය නිදහස් වනු ඇත.
        // අපට ඇත්ත වශයෙන්ම හිමිකාරිත්වය ලබා දීමට අවශ්‍ය නම්, අපට අප වෙනුවෙන් අතිරේක දුර්වල දර්ශකයක් නිර්මාණය කළ හැකිය, නමුත් මෙය දුර්වල යොමු ගණන් කිරීම් සඳහා අතිරේක යාවත්කාලීන කිරීම් සිදු කරනු ඇති අතර එය වෙනත් ආකාරයකින් අවශ්‍ය නොවනු ඇත.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // ශක්තිමත් යොමු කිරීම් සාමූහිකව හවුල් දුර්වල යොමු කිරීමක් තිබිය යුතුය, එබැවින් අපගේ පැරණි දුර්වල යොමු කිරීම සඳහා විනාශ කරන්නා ධාවනය නොකරන්න.
        //
        mem::forget(weak);
        strong
    }

    /// ආරම්භ නොකළ අන්තර්ගතයන් සහිත නව `Rc` සාදයි.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // විලම්බිත ආරම්භය:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// මතකය `0` බයිට් වලින් පුරවා ඇති, ආරම්භ නොකළ අන්තර්ගතයන්ගෙන් නව `Rc` සාදයි.
    ///
    ///
    /// මෙම ක්‍රමයේ නිවැරදි හා වැරදි භාවිතය පිළිබඳ උදාහරණ සඳහා [`MaybeUninit::zeroed`][zeroed] බලන්න.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// නව `Rc<T>` සාදයි, ප්‍රතිපාදන අසමත් වුවහොත් දෝෂයක් නැවත ලබා දේ
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // සියලු ප්‍රබල දර්ශකයන් සතු ව්‍යංග දුර්වල දර්ශකයක් ඇත, එමඟින් දුර්වල ඩිස්ට්‍රැක්ටරය කිසි විටෙකත් ප්‍රතිපාදන නිදහස් නොකරන බව සහතික කරයි.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// ආරම්භ නොකළ අන්තර්ගතයන් සහිත නව `Rc` සාදයි, වෙන් කිරීම අසමත් වුවහොත් දෝෂයක් නැවත ලබා දේ
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // විලම්බිත ආරම්භය:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// මතකය `0` බයිට් වලින් පුරවා, වෙන් කිරීම අසමත් වුවහොත් දෝෂයක් නැවත ලබා දෙමින්, ආරම්භ නොකළ අන්තර්ගතයන් සහිත නව `Rc` සාදයි
    ///
    ///
    /// මෙම ක්‍රමයේ නිවැරදි හා වැරදි භාවිතය පිළිබඳ උදාහරණ සඳහා [`MaybeUninit::zeroed`][zeroed] බලන්න.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// නව `Pin<Rc<T>>` සාදයි.
    /// `T` විසින් `Unpin` ක්‍රියාත්මක නොකරන්නේ නම්, `value` මතකයේ සවි කර ඇති අතර ඒවා ගෙනයාමට නොහැකි වනු ඇත.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// `Rc` හි හරියටම එක් ප්‍රබල සඳහනක් තිබේ නම්, අභ්‍යන්තර අගය ලබා දෙයි.
    ///
    /// එසේ නොමැතිනම්, සම්මත වූ `Rc` සමඟ [`Err`] ආපසු ලබා දෙනු ලැබේ.
    ///
    ///
    /// කැපී පෙනෙන දුර්වල යොමු කිරීම් තිබුණද මෙය සාර්ථක වනු ඇත.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // අඩංගු වස්තුව පිටපත් කරන්න

                // ප්‍රබල ගණන අඩු කිරීමෙන් ඒවා ප්‍රවර්ධනය කළ නොහැකි බව දුර්වලයන්ට ඇඟවුම් කරන්න, ඉන්පසු ව්‍යාජ දුර්වලතා හසුරුවමින් බිංදු තර්කනය හසුරුවමින් ව්‍යාජ "strong weak" දර්ශකය ඉවත් කරන්න.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// ආරම්භ නොකළ අන්තර්ගතයන් සහිත නව යොමු-ගණන් කළ පෙත්තක් සාදයි.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // විලම්බිත ආරම්භය:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// මතකය `0` බයිට් වලින් පුරවා ඇති, ආරම්භක නොවන අන්තර්ගතයන් සහිත නව යොමු-ගණන් කළ පෙත්තක් සාදයි.
    ///
    ///
    /// මෙම ක්‍රමයේ නිවැරදි හා වැරදි භාවිතය පිළිබඳ උදාහරණ සඳහා [`MaybeUninit::zeroed`][zeroed] බලන්න.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// `Rc<T>` බවට පරිවර්තනය කරයි.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] මෙන්ම, අභ්‍යන්තර අගය සැබවින්ම ආරම්භක තත්වයක පවතින බව සහතික කිරීම ඇමතුම්කරුගේ ය.
    ///
    /// අන්තර්ගතය තවමත් සම්පූර්ණයෙන් ආරම්භ කර නොමැති විට මෙය ඇමතීම ක්ෂණිකව නිර්වචනය නොකළ හැසිරීමට හේතු වේ.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // විලම්බිත ආරම්භය:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// `Rc<[T]>` බවට පරිවර්තනය කරයි.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] මෙන්ම, අභ්‍යන්තර අගය සැබවින්ම ආරම්භක තත්වයක පවතින බව සහතික කිරීම ඇමතුම්කරුගේ ය.
    ///
    /// අන්තර්ගතය තවමත් සම්පූර්ණයෙන් ආරම්භ කර නොමැති විට මෙය ඇමතීම ක්ෂණිකව නිර්වචනය නොකළ හැසිරීමට හේතු වේ.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // විලම්බිත ආරම්භය:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// ඔතා ඇති දර්ශකය නැවත ලබා දෙමින් `Rc` පරිභෝජනය කරයි.
    ///
    /// මතක කාන්දු වීමක් වළක්වා ගැනීම සඳහා, දර්ශකය [`Rc::from_raw`][from_raw] භාවිතා කර `Rc` බවට පරිවර්තනය කළ යුතුය.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// දත්ත සඳහා අමු දර්ශකයක් සපයයි.
    ///
    /// ගණන් කිරීම් කිසිදු ආකාරයකින් බලපාන්නේ නැති අතර `Rc` පරිභෝජනය නොකෙරේ.
    /// `Rc` හි ප්‍රබල ගණනය කිරීම් පවතින තාක් දුරට දර්ශකය වලංගු වේ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // ආරක්ෂාව: මෙය Deref::deref හෝ Rc::inner හරහා යා නොහැක
        // උදා: raw/mut ප්‍රභවය රඳවා ගැනීමට මෙය අවශ්‍ය වේ
        // `get_mut` `from_raw` හරහා Rc යථා තත්ත්වයට පත් වූ පසු දර්ශකය හරහා ලිවිය හැකිය.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// අමු දර්ශකයකින් `Rc<T>` සාදයි.
    ///
    /// අමු දර්ශකය මීට පෙර [`Rc<U>::into_raw`][into_raw] වෙත ඇමතුමක් මඟින් ආපසු ලබා දී තිබිය යුතුය, එහිදී `U` ට `T` හා සමාන ප්‍රමාණයක් හා පෙළගැස්මක් තිබිය යුතුය.
    /// `U` `T` නම් මෙය සුළු වශයෙන් සත්‍ය වේ.
    /// `U` යනු `T` නොව එකම ප්‍රමාණය හා පෙළගැස්වීමක් තිබේ නම්, මෙය මූලික වශයෙන් විවිධ වර්ගවල යොමු සම්ප්‍රේෂණයකට සමාන බව සලකන්න.
    /// මෙම නඩුවේ අදාළ වන සීමාවන් පිළිබඳ වැඩි විස්තර සඳහා [`mem::transmute`][transmute] බලන්න.
    ///
    /// `from_raw` භාවිතා කරන්නාට `T` හි නිශ්චිත අගයක් පහත වැටෙන්නේ එක් වරක් පමණක් බව තහවුරු කර ගත යුතුය.
    ///
    /// මෙම ශ්‍රිතය අනාරක්ෂිත බැවින් නැවත ලබා දුන් `Rc<T>` කිසි විටෙකත් ප්‍රවේශ නොවූවත්, අනිසි භාවිතය මතකයේ අනාරක්ෂිතභාවයට හේතු විය හැක.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // කාන්දු වීම වැළැක්වීම සඳහා නැවත `Rc` වෙත පරිවර්තනය කරන්න.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Rc::from_raw(x_ptr)` වෙත තවදුරටත් ඇමතුම් මතකය අනාරක්ෂිත වේ.
    /// }
    ///
    /// // `x` ඉහත විෂය පථයෙන් බැහැර වූ විට මතකය නිදහස් විය, එබැවින් `x_ptr` දැන් අන්තරාදායකය!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // මුල් RcBox සොයා ගැනීමට ඕෆ්සෙට් ආපසු හරවන්න.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// මෙම වෙන් කිරීම සඳහා නව [`Weak`] දර්ශකයක් සාදයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // අප දුර්වල දුර්වලතාවයක් ඇති නොකරන බවට වග බලා ගන්න
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// මෙම වෙන් කිරීම සඳහා [`Weak`] දර්ශකයන් ගණන ලබා ගනී.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// මෙම වෙන් කිරීම සඳහා ශක්තිමත් (`Rc`) දර්ශක ගණන ලබා ගනී.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// මෙම වෙන් කිරීම සඳහා වෙනත් `Rc` හෝ [`Weak`] දර්ශක නොමැති නම් `true` ලබා දෙයි.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// එකම ප්‍රතිපාදන සඳහා වෙනත් `Rc` හෝ [`Weak`] දර්ශකයන් නොමැති නම්, ලබා දී ඇති `Rc` වෙත විකෘති යොමු කිරීමක් ලබා දෙයි.
    ///
    ///
    /// හවුල් වටිනාකමක් විකෘති කිරීම ආරක්ෂිත නොවන නිසා [`None`] වෙනත් ආකාරයකින් ලබා දෙයි.
    ///
    /// [`make_mut`][make_mut] ද බලන්න, වෙනත් දර්ශක ඇති විට අභ්‍යන්තර අගය [`clone`][clone] වනු ඇත.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// කිසිදු චෙක්පතකින් තොරව, ලබා දී ඇති `Rc` වෙත විකෘති යොමු කිරීමක් ලබා දෙයි.
    ///
    /// [`get_mut`] ද බලන්න, එය ආරක්ෂිත වන අතර සුදුසු චෙක්පත් සිදු කරයි.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// එකම ප්‍රතිපාදන සඳහා වෙනත් ඕනෑම `Rc` හෝ [`Weak`] දර්ශක ආපසු ලබා ගත් ණය මුදල සඳහා අවලංගු නොකළ යුතුය.
    ///
    /// එවැනි දර්ශකයන් නොමැති නම් මෙය ඉතා සුළු කාරණයකි, උදාහරණයක් ලෙස `Rc::new` පසු වහාම.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // "count" ක්ෂේත්‍ර ආවරණය වන පරිදි යොමු කිරීමක් * නොකිරීමට අපි වගබලා ගනිමු, මෙය යොමු ගණන් වලට ප්‍රවේශ වීම සමඟ ගැටෙන බැවින් (උදා.
        // `Weak` විසින්).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// `Rc`s දෙක එකම වෙන් කිරීමකට යොමු කරන්නේ නම් ([`ptr::eq`] ට සමාන නහරයක) `true` ලබා දෙයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// දී ඇති `Rc` වෙත විකෘති යොමු කිරීමක් කරයි.
    ///
    /// එකම වෙන් කිරීම සඳහා වෙනත් `Rc` දර්ශකයන් තිබේ නම්, අද්විතීය හිමිකාරිත්වය සහතික කිරීම සඳහා `make_mut` නව ප්‍රතිපාදනයක් සඳහා අභ්‍යන්තර අගය [`clone`] කරනු ඇත.
    /// මෙය ක්ලෝන-ඔන්-ලිවීම ලෙසද හැඳින්වේ.
    ///
    /// මෙම වෙන් කිරීම සඳහා වෙනත් `Rc` දර්ශකයන් නොමැති නම්, මෙම වෙන් කිරීම සඳහා [`Weak`] දර්ශකයන් විසුරුවා හරිනු ලැබේ.
    ///
    /// [`get_mut`] ද බලන්න, එය ක්ලෝනකරණයට වඩා අසමත් වනු ඇත.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // කිසිවක් ක්ලෝන කරන්නේ නැහැ
    /// let mut other_data = Rc::clone(&data);    // අභ්‍යන්තර දත්ත ක්ලෝන නොකරනු ඇත
    /// *Rc::make_mut(&mut data) += 1;        // අභ්‍යන්තර දත්ත ක්ලෝන කරයි
    /// *Rc::make_mut(&mut data) += 1;        // කිසිවක් ක්ලෝන කරන්නේ නැහැ
    /// *Rc::make_mut(&mut other_data) *= 2;  // කිසිවක් ක්ලෝන කරන්නේ නැහැ
    ///
    /// // දැන් `data` සහ `other_data` විවිධ ප්‍රතිපාදන වෙත යොමු කරයි.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] දර්ශකයන් විසුරුවා හරිනු ඇත:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // දත්ත ක්ලෝන කිරීමට අවශ්‍යයි, තවත් Rcs තිබේ.
            // ක්ලෝන කළ අගය කෙලින්ම ලිවීමට ඉඩ දීම සඳහා මතකය කලින් වෙන් කරන්න.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // දත්ත සොරකම් කළ හැකිය, ඉතිරිව ඇත්තේ දුර්වලයි
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // ව්‍යංග ශක්තිමත්-දුර්වල ref ඉවත් කරන්න (මෙහි ව්‍යාජ දුර්වලකමක් තැනීමට අවශ්‍ය නැත-වෙනත් දුර්වලයින්ට අප වෙනුවෙන් පිරිසිදු කළ හැකි බව අපි දනිමු)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // මෙම අනාරක්ෂිත භාවය කමක් නැත, මන්ද ආපසු එවූ දර්ශකය * වෙත නැවත එවනු ලබන එකම එකම දර්ශකය බව අපට සහතික වී ඇත.
        // මෙම අවස්ථාවෙහිදී අපගේ විමර්ශන ගණන 1 ක් බව සහතික කර ඇති අතර, අපට `Rc<T>` ම `mut` විය යුතුය, එබැවින් අපි ප්‍රතිපාදන වෙන් කළ හැකි එකම යොමු කිරීම නැවත ලබා දෙන්නෙමු.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Rc<dyn Any>` කොන්ක්‍රීට් වර්ගයකට පහත හෙලීමට උත්සාහ කිරීම.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// වටිනාකමට පිරිසැලසුම සපයා ඇති තැනක නොවිසඳුනු අභ්‍යන්තර අගයක් සඳහා ප්‍රමාණවත් ඉඩ ප්‍රමාණයක් සහිත `RcBox<T>` වෙන් කරයි.
    ///
    /// `mem_to_rcbox` ශ්‍රිතය දත්ත දර්ශකය සමඟ කැඳවනු ලබන අතර `RcBox<T>` සඳහා (මේදය විය හැකි) පොයින්ටරයක් ආපසු ලබා දිය යුතුය.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // දී ඇති අගය පිරිසැලසුම භාවිතා කර පිරිසැලසුම ගණනය කරන්න.
        // මීට පෙර, පිරිසැලසුම `&*(ptr as* const RcBox<T>)` ප්‍රකාශනය මත ගණනය කරන ලද නමුත් මෙය වැරදි ලෙස සකසන ලද යොමු කිරීමක් නිර්මාණය කළේය (#54908 බලන්න).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// අගය පිරිසැලසුම සපයා ඇති තැනක නොවිසඳුනු අභ්‍යන්තර අගයක් සඳහා ප්‍රමාණවත් ඉඩක් සහිත `RcBox<T>` වෙන් කරයි, වෙන් කිරීම අසමත් වුවහොත් දෝෂයක් නැවත ලබා දේ.
    ///
    ///
    /// `mem_to_rcbox` ශ්‍රිතය දත්ත දර්ශකය සමඟ කැඳවනු ලබන අතර `RcBox<T>` සඳහා (මේදය විය හැකි) පොයින්ටරයක් ආපසු ලබා දිය යුතුය.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // දී ඇති අගය පිරිසැලසුම භාවිතා කර පිරිසැලසුම ගණනය කරන්න.
        // මීට පෙර, පිරිසැලසුම `&*(ptr as* const RcBox<T>)` ප්‍රකාශනය මත ගණනය කරන ලද නමුත් මෙය වැරදි ලෙස සකසන ලද යොමු කිරීමක් නිර්මාණය කළේය (#54908 බලන්න).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // පිරිසැලසුම සඳහා වෙන් කරන්න.
        let ptr = allocate(layout)?;

        // RcBox ආරම්භ කරන්න
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// ප්‍රමාණ නොකළ අභ්‍යන්තර අගයක් සඳහා ප්‍රමාණවත් ඉඩ ප්‍රමාණයක් සහිත `RcBox<T>` වෙන් කරයි
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // දී ඇති අගය භාවිතා කරමින් `RcBox<T>` සඳහා වෙන් කරන්න.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // අගය බයිට් ලෙස පිටපත් කරන්න
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // ප්‍රතිපාදන එහි අන්තර්ගතය අතහැර නොගෙන නිදහස් කරන්න
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// දී ඇති දිග සමඟ `RcBox<[T]>` වෙන් කරයි.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// පෙත්තෙන් මූලද්‍රව්‍ය අලුතින් වෙන් කරන ලද Rc <\[T\]> වෙත පිටපත් කරන්න
    ///
    /// අනාරක්ෂිත බැවින් ඇමතුම්කරු හිමිකාරිත්වය හෝ `T: Copy` බන්ධනය කළ යුතුය
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// එක්තරා ප්‍රමාණයකින් යුත් iterator එකකින් `Rc<[T]>` සාදයි.
    ///
    /// ප්‍රමාණය වැරදියි නම් හැසිරීම නිර්වචනය කර නැත.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // T මූලද්‍රව්‍ය ක්ලෝන කරන අතරතුර Panic ආරක්ෂකයා.
        // panic අවස්ථාවකදී, නව RcBox වෙත ලියා ඇති මූලද්‍රව්‍ය අතහැර දමනු ඇත, පසුව මතකය නිදහස් වේ.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // පළමු අංගයට දර්ශකය
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // සියල්ල පැහැදිලිය.නව RcBox නිදහස් නොවන පරිදි ආරක්ෂකයා අමතක කරන්න.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` සඳහා භාවිතා කරන trait විශේෂීකරණය.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// `Rc` පහත වැටේ.
    ///
    /// මෙය ශක්තිමත් යොමු ගණන අඩු කරනු ඇත.
    /// ප්‍රබල යොමු ගණන ශුන්‍යයට ළඟා වුවහොත් අනෙක් යොමු කිරීම් (ඇත්නම්) [`Weak`] වේ, එබැවින් අපි අභ්‍යන්තර අගය `drop` කරන්නෙමු.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // කිසිවක් මුද්‍රණය නොකරයි
    /// drop(foo2);   // "dropped!" මුද්‍රණය කරයි
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // අඩංගු වස්තුව විනාශ කරන්න
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // දැන් අපි අන්තර්ගතය විනාශ කර ඇති ව්‍යංග "strong weak" දර්ශකය ඉවත් කරන්න.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// `Rc` දර්ශකයේ ක්ලෝනයක් සාදයි.
    ///
    /// මෙය එකම වෙන් කිරීමකට තවත් දර්ශකයක් නිර්මාණය කරයි, ශක්තිමත් යොමු ගණන වැඩි කරයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// `T` සඳහා `Default` අගය සමඟ නව `Rc<T>` නිර්මාණය කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// `Eq` ක්‍රමයක් තිබුණද `Eq` හි විශේෂීකරණය වීමට ඉඩ දීම.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// අපි මෙහි විශේෂීකරණය කරන්නේ `&T` හි වඩාත් පොදු ප්‍රශස්තිකරණයක් ලෙස නොවේ, මන්ද එය වෙනත් ආකාරයකින් සමානාත්මතා පරීක්ෂාවන් සඳහා පිරිවැයක් එකතු කරන බැවිනි.
/// ක්ලෝන කිරීමට මන්දගාමී වන නමුත් සමානාත්මතාවය පරීක්ෂා කිරීම සඳහා බරින් වැඩි විශාල අගයන් ගබඩා කිරීම සඳහා `Rc`s භාවිතා කරන බව අපි උපකල්පනය කරමු, මෙම පිරිවැය වඩාත් පහසුවෙන් ගෙවීමට හේතු වේ.
///
/// එය X&X ක්ලෝන දෙකක් තිබීමට වැඩි ඉඩක් ඇත, එය එකම අගයට යොමු කරයි, `&T` ට වඩා.
///
/// අපට මෙය කළ හැක්කේ `T: Eq` ලෙස `T: Eq` හිතාමතාම අක්‍රිය කළ හැකි විට පමණි.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// `Rc` දෙකක් සඳහා සමානාත්මතාවය.
    ///
    /// විවිධ ප්‍රතිපාදනවල ගබඩා කර තිබුණද, ඒවායේ අභ්‍යන්තර අගයන් සමාන නම්, Rcs දෙකක් සමාන වේ.
    ///
    /// `T` ද `Eq` (සමානාත්මතාවයේ ප්‍රත්‍යාවර්තකතාව ඇඟවුම් කරයි) ක්‍රියාත්මක කරන්නේ නම්, එකම වෙන් කිරීමකට යොමු වන `Rc` දෙකක් සැමවිටම සමාන වේ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// `Rc` දෙකක් සඳහා අසමානතාවය.
    ///
    /// Rc`s දෙකක් ඒවායේ අභ්‍යන්තර අගයන් අසමාන නම් අසමාන වේ.
    ///
    /// `T` ද `Eq` (සමානාත්මතාවයේ ප්‍රත්‍යාවර්තකතාව අඟවමින්) ක්‍රියාත්මක කරන්නේ නම්, එකම වෙන් කිරීමකට යොමු කරන `Rc` දෙකක් කිසි විටෙක අසමාන නොවේ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// `Rc` දෙකක් සඳහා අර්ධ සංසන්දනය.
    ///
    /// මේ දෙක සංසන්දනය කරනුයේ ඒවායේ අභ්‍යන්තර අගයන් මත `partial_cmp()` ඇමතීමෙනි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// `Rc` දෙකක් සඳහා සැසඳීමට වඩා අඩුය.
    ///
    /// මේ දෙක සංසන්දනය කරනුයේ ඒවායේ අභ්‍යන්තර අගයන් මත `<` ඇමතීමෙනි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 'Rc` දෙකක් සඳහා සංසන්දනය' අඩු හෝ සමාන '.
    ///
    /// මේ දෙක සංසන්දනය කරනුයේ ඒවායේ අභ්‍යන්තර අගයන් මත `<=` ඇමතීමෙනි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Rcs දෙකක් සඳහා සැසඳීමට වඩා විශාලයි.
    ///
    /// මේ දෙක සංසන්දනය කරනුයේ ඒවායේ අභ්‍යන්තර අගයන් මත `>` ඇමතීමෙනි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'Rc` දෙකක් සඳහා සංසන්දනය' වඩා විශාල හෝ සමාන '.
    ///
    /// මේ දෙක සංසන්දනය කරනුයේ ඒවායේ අභ්‍යන්තර අගයන් මත `>=` ඇමතීමෙනි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// `Rc` දෙකක් සඳහා සංසන්දනය.
    ///
    /// මේ දෙක සංසන්දනය කරනුයේ ඒවායේ අභ්‍යන්තර අගයන් මත `cmp()` ඇමතීමෙනි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// යොමු ගණනය කළ පෙත්තක් වෙන් කර `v` හි අයිතම ක්ලෝන කිරීමෙන් එය පුරවන්න.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// යොමු ගණන් කළ නූල් පෙත්තක් වෙන් කර එයට `v` පිටපත් කරන්න.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// යොමු ගණන් කළ නූල් පෙත්තක් වෙන් කර එයට `v` පිටපත් කරන්න.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// කොටු කළ වස්තුවක් නව, යොමු ගණන් කළ, වෙන් කිරීමකට ගෙන යන්න.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// යොමු ගණන් කළ පෙත්තක් වෙන් කර `v` ගේ අයිතම ඒ තුළට ගෙන යන්න.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Vec හට එහි මතකය නිදහස් කිරීමට ඉඩ දෙන්න, නමුත් එහි අන්තර්ගතය විනාශ නොකරන්න
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// `Iterator` හි එක් එක් මූලද්රව්යය ගෙන එය `Rc<[T]>` වෙත එකතු කරයි.
    ///
    /// # කාර්ය සාධන ලක්ෂණ
    ///
    /// ## පොදු නඩුව
    ///
    /// පොදුවේ ගත් කල, `Rc<[T]>` වෙත එකතු කිරීම සිදු කරනු ලබන්නේ පළමුව `Vec<T>` වෙත එකතු කිරීමෙනි.එනම්, පහත සඳහන් කරුණු ලිවීමේදී:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// මෙය හැසිරෙන්නේ අප ලියා ඇති ආකාරයට ය:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // පළමු ප්‍රතිපාදන මාලාව මෙහි සිදු වේ.
    ///     .into(); // `Rc<[T]>` සඳහා දෙවන වෙන් කිරීම මෙහි සිදු වේ.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// මෙය `Vec<T>` ඉදිකිරීම සඳහා අවශ්‍ය තරම් වාර ගණනක් වෙන් කරනු ඇති අතර පසුව එය `Vec<T>` `Rc<[T]>` බවට හැරවීම සඳහා එක් වරක් වෙන් කරනු ඇත.
    ///
    ///
    /// ## දන්නා දිග අනුභව කරන්නන්
    ///
    /// ඔබේ `Iterator` `TrustedLen` ක්‍රියාත්මක කර නිශ්චිත ප්‍රමාණයෙන් යුක්ත වන විට, `Rc<[T]>` සඳහා තනි වෙන් කිරීමක් කරනු ලැබේ.උදාහරණ වශයෙන්:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // එක් වෙන් කිරීමක් පමණක් මෙහි සිදු වේ.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// `Rc<[T]>` වෙත එකතු කිරීම සඳහා භාවිතා කරන trait විශේෂීකරණය.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // `TrustedLen` iterator සඳහා තත්වය මෙයයි.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // සුරක්ෂිතභාවය: අනුකාරකයට නිශ්චිත දිගක් ඇති බවට අප සහතික විය යුතුය.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // සාමාන්‍ය ක්‍රියාත්මක කිරීම වෙත ආපසු යන්න.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` යනු [`Rc`] හි අනුවාදයක් වන අතර එය කළමනාකරණ ප්‍රතිපාදන සඳහා හිමිකාරී නොවන සඳහනක් දරයි.`Weak` දර්ශකය මත [`upgrade`] ඇමතීමෙන් ප්‍රතිපාදන ප්‍රවේශ වේ, එය [`විකල්පය]] <<` [`Rc`]`<T>>`.
///
/// `Weak` යොමුව හිමිකාරිත්වය කෙරෙහි ගණන් නොගන්නා හෙයින්, එය වෙන් කිරීම තුළ ගබඩා කර ඇති වටිනාකම පහත වැටීම වලක්වනු නොලැබේ, සහ `Weak` විසින්ම තවමත් පවතින වටිනාකම පිළිබඳව කිසිදු සහතිකයක් ලබා නොදේ.
/// [`උත්ශ්‍රේණිගත කිරීමේදී] එය [`None`] ආපසු ලබා දිය හැක.
/// කෙසේ වෙතත්, `Weak` යොමු කිරීමක් * වෙන් කිරීමම (පසුබිම් ගබඩාව) අවලංගු කිරීම වළක්වන බව සලකන්න.
///
/// `Weak` දර්ශකය එහි අභ්‍යන්තර වටිනාකම පහත වැටීම වළක්වා නොගෙන [`Rc`] විසින් කළමනාකරණය කරන ලද ප්‍රතිපාදන පිළිබඳ තාවකාලික සඳහනක් තබා ගැනීම සඳහා ප්‍රයෝජනවත් වේ.
/// [`Rc`] පොයින්ටර් අතර රවුම් යොමු වීම වැළැක්වීම සඳහා ද මෙය භාවිතා වේ, මන්ද අන්‍යෝන්‍ය හිමිකාරීත්ව යොමු කිරීම් කිසි විටෙකත් [`Rc`] අතහැර දැමීමට ඉඩ නොදේ.
/// නිදසුනක් ලෙස, ගසකට මව් නෝඩ් සිට ළමයින් දක්වා ශක්තිමත් [`Rc`] පොයින්ටර්ස් තිබිය හැකි අතර, `Weak` පොයින්ටර්ස් දරුවන්ගේ සිට දෙමාපියන් වෙත ආපසු යා හැකිය.
///
/// `Weak` දර්ශකයක් ලබා ගත හැකි සාමාන්‍ය ක්‍රමය වන්නේ [`Rc::downgrade`] අමතන්න.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // මෙම වර්ගයේ ප්‍රමාණය එනුම් වල ප්‍රශස්තිකරණය කිරීමට ඉඩ දීම සඳහා මෙය `NonNull` වේ, නමුත් එය අනිවාර්යයෙන්ම වලංගු දර්ශකයක් නොවේ.
    //
    // `Weak::new` මෙය `usize::MAX` ලෙස සකසා ඇති අතර එමඟින් ගොඩවල් මත ඉඩ වෙන් කිරීමට අවශ්‍ය නොවේ.
    // RcBox හි අවම වශයෙන් 2 ක් වත් පෙළගැස්වීමක් ඇති නිසා සැබෑ දර්ශකයකට එය කිසි විටෙකත් ඇති වටිනාකමක් නොවේ.
    // මෙය කළ හැක්කේ `T: Sized` විට පමණි;unsized `T` කිසි විටෙකත් නොගැලපේ.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// කිසිදු මතකයක් වෙන් නොකර නව `Weak<T>` සාදයි.
    /// ප්‍රතිලාභ අගය මත [`upgrade`] ඇමතීම සැමවිටම [`None`] ලබා දෙයි.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// දත්ත ක්‍ෂේත්‍රය පිළිබඳ කිසිදු ප්‍රකාශයක් නොකර විමර්ශන ගණන් වලට ප්‍රවේශ වීමට උදව් කිරීමට උපකාරක වර්ගය.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// මෙම `Weak<T>` විසින් පෙන්වා ඇති `T` වස්තුවට අමු දර්ශකයක් ලබා දෙයි.
    ///
    /// දර්ශකය වලංගු වන්නේ ප්‍රබල යොමු කිහිපයක් තිබේ නම් පමණි.
    /// දර්ශකය අන්තරාදායක, නොබැඳි හෝ [`null`] වෙනත් ආකාරයකින් විය හැකිය.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // දෙකම එකම වස්තුවකට යොමු කරයි
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // මෙහි ඇති ප්‍රබලයන් එය පණපිටින් තබා ගනී, එබැවින් අපට තවමත් වස්තුවට ප්‍රවේශ විය හැකිය.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // නමුත් තවත් නැත.
    /// // අපට weak.as_ptr() කළ හැකිය, නමුත් දර්ශකයට ප්‍රවේශ වීම නිර්වචනය නොකළ හැසිරීමට හේතු වේ.
    /// // assert_eq! ("හෙලෝ", අනාරක්ෂිත {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // දර්ශකය අන්තරාදායක නම්, අපි කෙලින්ම සෙන්ඩිනල් එක ආපසු එවන්නෙමු.
            // ගෙවීම් භාරය අවම වශයෙන් RcBox (usize) ලෙස පෙලගැසී ඇති බැවින් මෙය වලංගු ගෙවුම් ලිපිනයක් විය නොහැක.
            ptr as *const T
        } else {
            // ආරක්ෂාව: is_dangling වැරදියි නම්, දර්ශකය අවලංගු කළ හැකිය.
            // මෙම අවස්ථාවෙහිදී ගෙවීම් භාරය අතහැර දැමිය හැකි අතර, අප විසින් ප්‍රභවයන් පවත්වා ගත යුතුය, එබැවින් අමු දර්ශක හැසිරවීම භාවිතා කරන්න.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// `Weak<T>` පරිභෝජනය කර එය අමු දර්ශකයක් බවට පත් කරයි.
    ///
    /// මෙය දුර්වල දර්ශකය අමු දර්ශකයක් බවට පරිවර්තනය කරයි, තවමත් එක් දුර්වල යොමුවක හිමිකාරිත්වය ආරක්ෂා කරයි (මෙම ක්‍රියාවෙන් දුර්වල ගණන වෙනස් නොවේ).
    /// එය [`from_raw`] සමඟ `Weak<T>` වෙත ආපසු හැරවිය හැකිය.
    ///
    /// [`as_ptr`] හා සමානව දර්ශකයේ ඉලක්කයට ප්‍රවේශ වීමේ සීමාවන් ද අදාළ වේ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// කලින් [`into_raw`] විසින් නිර්මාණය කරන ලද අමු දර්ශකයක් නැවත `Weak<T>` බවට පරිවර්තනය කරයි.
    ///
    /// මෙය ආරක්ෂිතව ශක්තිමත් යොමු කිරීමක් ලබා ගැනීමට (පසුව [`upgrade`] ඇමතීමෙන්) හෝ `Weak<T>` අතහැර දැමීමෙන් දුර්වල ගණන ඉවත් කිරීමට භාවිතා කළ හැකිය.
    ///
    /// එය එක් දුර්වල යොමු කිරීමක හිමිකාරිත්වය ගනී ([`new`] විසින් නිර්මාණය කරන ලද දර්ශකයන් හැරුණු විට, මේවාට කිසිවක් අයිති නැති බැවින්; ක්‍රමය තවමත් ඒවා මත ක්‍රියාත්මක වේ).
    ///
    /// # Safety
    ///
    /// දර්ශකය [`into_raw`] වෙතින් ආරම්භ වී තිබිය යුතු අතර එහි විභව දුර්වල යොමුව තවමත් තිබිය යුතුය.
    ///
    /// මෙය ඇමතීමේදී ශක්තිමත් ගණන 0 ක් වීමට අවසර ඇත.
    /// එසේ වුවද, මෙය දැනට අමු දර්ශකයක් ලෙස නිරූපණය කර ඇති එක් දුර්වල යොමුවක හිමිකාරිත්වය ගනී (මෙම ක්‍රියාවෙන් දුර්වල ගණන වෙනස් නොවේ) එබැවින් එය [`into_raw`] වෙත පෙර ඇමතුමක් සමඟ යුගල කළ යුතුය.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // අන්තිම දුර්වල ගණන අඩු කරන්න.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // ආදාන දර්ශකය ව්‍යුත්පන්න කර ඇති ආකාරය පිළිබඳ සන්දර්භය සඳහා Weak::as_ptr බලන්න.

        let ptr = if is_dangling(ptr as *mut T) {
            // මෙය දුර්වල දුර්වලයකි.
            ptr as *mut RcBox<T>
        } else {
            // එසේ නොමැතිනම්, දර්ශකය පැමිණියේ දුර්වල දුර්වලතාවයකින් බව අපට සහතිකයි.
            // සුරක්ෂිතභාවය: දත්ත_ ඕෆ්සෙට් ඇමතීම ආරක්ෂිතයි, ptr විසින් නියම (අතහැර දැමිය හැකි) ටී.
            let offset = unsafe { data_offset(ptr) };
            // මේ අනුව, අපි මුළු RcBox ලබා ගැනීම සඳහා ඕෆ්සෙට් ආපසු හරවන්නෙමු.
            // සුරක්ෂිතභාවය: දර්ශකය ආරම්භ වූයේ දුර්වලයෙකු වන බැවින් මෙම ඕෆ්සෙට් එක ආරක්ෂිතයි.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // ආරක්ෂාව: අපි දැන් මුල් දුර්වල දර්ශකය සොයාගෙන ඇත, එබැවින් දුර්වල නිර්මාණය කළ හැකිය.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// `Weak` දර්ශකය [`Rc`] දක්වා උත්ශ්‍රේණි කිරීමට උත්සාහ කිරීම, සාර්ථක නම් අභ්‍යන්තර අගය පහත වැටීම ප්‍රමාද කරයි.
    ///
    ///
    /// එතැන් සිට අභ්‍යන්තර අගය අතහැර දමා ඇත්නම් [`None`] ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // සියලු ශක්තිමත් දර්ශකයන් විනාශ කරන්න.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// මෙම වෙන් කිරීම වෙත යොමු කරන ශක්තිමත් (`Rc`) දර්ශක ගණන ලබා ගනී.
    ///
    /// [`Weak::new`] භාවිතා කරමින් `self` නිර්මාණය කර ඇත්නම්, මෙය 0 නැවත ලබා දෙනු ඇත.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// මෙම වෙන් කිරීම වෙත යොමු වන `Weak` දර්ශක ගණන ලබා ගනී.
    ///
    /// ශක්තිමත් දර්ශක කිසිවක් ඉතිරිව නොමැති නම්, මෙය ශුන්‍ය වේ.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // ව්‍යංග දුර්වල ptr අඩු කරන්න
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// දර්ශකය ගැටෙන විට සහ වෙන් කරන ලද `RcBox` නොමැති විට `None` ලබා දෙයි, (එනම්, මෙම `Weak` `Weak::new` විසින් නිර්මාණය කරන විට).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // ක්ෂේත්‍රය සමගාමීව විකෘති විය හැකි බැවින්, "data" ක්ෂේත්‍රය ආවරණය වන පරිදි * යොමු නොකිරීමට අපි වගබලා ගනිමු (නිදසුනක් ලෙස, අවසාන `Rc` අතහැර දැමුවහොත්, දත්ත ක්ෂේත්‍රය තැනින් තැන වැටෙනු ඇත).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// දුර්වලයන් දෙදෙනා එකම වෙන් කිරීමකට ([`ptr::eq`] ට සමාන) යොමු කරන්නේ නම් හෝ දෙකම කිසිදු ප්‍රතිපාදනයක් වෙත යොමු නොකරන්නේ නම් (ඒවා `Weak::new()`) සමඟ නිර්මාණය කර ඇති නිසා) `true` ලබා දෙයි.
    ///
    ///
    /// # Notes
    ///
    /// මෙය දර්ශකයන් සංසන්දනය කරන බැවින් එයින් අදහස් වන්නේ `Weak::new()` එකිනෙකට සමාන වන බවයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` සංසන්දනය කිරීම.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` දර්ශකය පහත වැටේ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // කිසිවක් මුද්‍රණය නොකරයි
    /// drop(foo);        // "dropped!" මුද්‍රණය කරයි
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // දුර්වල ගණන 1 න් ආරම්භ වන අතර එය ශුන්‍යයට යන්නේ සියලු ශක්තිමත් දර්ශකයන් අතුරුදහන් වී ඇත්නම් පමණි.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// එකම වෙන් කිරීමකට යොමු වන `Weak` දර්ශකයේ ක්ලෝනයක් සාදයි.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// නව `Weak<T>` එකක් සාදයි, එය ආරම්භ නොකර `T` සඳහා මතකය වෙන් කරයි.
    /// ප්‍රතිලාභ අගය මත [`upgrade`] ඇමතීම සැමවිටම [`None`] ලබා දෙයි.
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: mem::forget සමඟ ආරක්ෂිතව කටයුතු කිරීමට අපි මෙහි පරීක්ෂා කළෙමු.විශේෂයෙන්
// ඔබ mem::forget Rcs (හෝ දුර්වල නම්) නම්, නැවත ගණනය කිරීම පිරී ඉතිරී යා හැකි අතර, කැපී පෙනෙන Rcs (හෝ දුර්වල) පවතින අතර ඔබට වෙන් කිරීම නිදහස් කළ හැකිය.
//
// අප ගබ්සා කරන්නේ මෙය සිදුවන්නේ කුමක් ද යන්න ගැන අප නොසලකන පරිහානියට පත්වූ තත්වයක් වන හෙයිනි-කිසිදු සැබෑ වැඩසටහනක් මෙය අත්විඳිය යුතු නැත.
//
// Rust හි ඇත්ත වශයෙන්ම මේවා ක්ලෝන කිරීමට ඔබට අවශ්‍ය නොවන බැවින් මෙය නොසැලකිලිමත් ලෙස පොදු කාර්යයක් තිබිය යුතුය.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // වටිනාකම පහත වැටීම වෙනුවට පිටාර ගැලීම නතර කිරීමට අපට අවශ්‍යය.
        // මෙය හැඳින්වූ විට යොමු ගණන කිසි විටෙකත් ශුන්‍ය නොවේ;
        // එසේ වුවද, වෙනත් ආකාරයකින් මඟ හැරුණු ප්‍රශස්තිකරණයකදී එල්එල්වීඑම් ඉඟි කිරීම සඳහා අපි මෙහි ගබ්සා කිරීමක් ඇතුළත් කරමු.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // වටිනාකම පහත වැටීම වෙනුවට පිටාර ගැලීම නතර කිරීමට අපට අවශ්‍යය.
        // මෙය හැඳින්වූ විට යොමු ගණන කිසි විටෙකත් ශුන්‍ය නොවේ;
        // එසේ වුවද, වෙනත් ආකාරයකින් මඟ හැරුණු ප්‍රශස්තිකරණයකදී එල්එල්වීඑම් ඉඟි කිරීම සඳහා අපි මෙහි ගබ්සා කිරීමක් ඇතුළත් කරමු.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// දර්ශකයක් පිටුපස ගෙවීම සඳහා `RcBox` තුළ ඕෆ්සෙට් ලබා ගන්න.
///
/// # Safety
///
/// දර්ශකයේ පෙර වලංගු T අවස්ථාවක් වෙත යොමු විය යුතුය (සහ වලංගු පාර-දත්ත තිබිය යුතුය), නමුත් T අතහැර දැමීමට අවසර ඇත.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // RcBox හි අවසානයට නොගැලපෙන අගය පෙළගස්වන්න.
    // RcBox repr(C) බැවින් එය සැමවිටම මතකයේ අවසාන ක්ෂේත්‍රය වනු ඇත.
    // ආරක්ෂාව: කළ නොහැකි එකම වර්ගයේ පෙති, trait වස්තු,
    // සහ බාහිර වර්ගවල, align_of_val_raw හි අවශ්‍යතා සපුරාලීම සඳහා ආදාන ආරක්ෂණ අවශ්‍යතාවය දැනට ප්‍රමාණවත් වේ;මෙය std ට පිටතින් රඳා නොපවතින භාෂාවේ ක්‍රියාත්මක කිරීමේ විස්තරයකි.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}