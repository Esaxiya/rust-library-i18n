//! ද්විමය සංචයක් සමඟ ක්‍රියාත්මක කරන ප්‍රමුඛතා පෝලිම්.
//!
//! විශාලතම මූලද්රව්යය ඇතුල් කිරීම සහ පොපි කිරීම *O*(log(*n*)) කාල සංකීර්ණතාවයක් ඇත.
//! විශාලතම මූලද්රව්යය පරීක්ෂා කිරීම *O*(1) වේ.vector ද්විමය ගොඩකට පරිවර්තනය කිරීම තැනින් තැන කළ හැකි අතර *O*(*n*) සංකීර්ණතාවයක් ඇත.
//! ද්විමය සංචයක් තැනින් තැන වර්ග කළ vector බවට පරිවර්තනය කළ හැකි අතර, එය *O*(*n*\*log(* n*)) ස්ථානීය ගොඩවල් සඳහා භාවිතා කිරීමට ඉඩ දෙයි.
//!
//! # Examples
//!
//! මෙය [directed graph][dir_graph] හි [shortest path problem][sssp] විසඳීමට [Dijkstra's algorithm][dijkstra] ක්‍රියාත්මක කරන විශාල උදාහරණයකි.
//!
//! අභිරුචි වර්ග සමඟ [`BinaryHeap`] භාවිතා කරන්නේ කෙසේදැයි එය පෙන්වයි.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // ප්‍රමුඛතා පෝලිම `Ord` මත රඳා පවතී.
//! // trait පැහැදිලිවම ක්‍රියාත්මක කරන්න එවිට පෝලිම උපරිම ගොඩවල් වෙනුවට මිනි ගොඩක් බවට පත්වේ.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // අපි පිරිවැය මත ඇණවුම පෙරළන බව සැලකිල්ලට ගන්න.
//!         // අපි ස්ථාන සංසන්දනය කරන ටයි පටියක නම්, මෙම පියවර `PartialEq` සහ `Ord` ක්‍රියාත්මක කිරීම ස්ථාවර කිරීමට අවශ්‍ය වේ.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` ක්‍රියාත්මක කළ යුතුය.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // කෙටි නෝට්ටුවක් සඳහා සෑම නෝඩයක්ම `usize` ලෙස නිරූපණය කෙරේ.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // ඩිජ්ක්ස්ට්‍රා හි කෙටිම මාර්ග ඇල්ගොරිතම.
//!
//! // `start` වෙතින් ආරම්භ කර එක් එක් නෝඩයට දැනට පවතින කෙටිම දුර නිරීක්ෂණය කිරීමට `dist` භාවිතා කරන්න.අනුපිටපත් නෝඩ් පෝලිමේ තැබිය හැකි බැවින් මෙම ක්‍රියාත්මක කිරීම මතක-කාර්යක්ෂම නොවේ.
//! //
//! // එය සරල ලෙස ක්‍රියාත්මක කිරීම සඳහා සෙන්ඩිනල් අගයක් ලෙස `usize::MAX` භාවිතා කරයි.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [node]= `start` සිට `node` දක්වා වත්මන් කෙටිම දුර
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // අපි ඉන්නේ `start` වල, ශුන්‍ය පිරිවැයකින්
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // පළමු (min-heap) අඩු වියදම් නෝඩ් සහිත මායිම පරීක්ෂා කරන්න
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // විකල්පයක් ලෙස අපට කෙටිම මාර්ග සියල්ලම සොයා ගැනීමට හැකිවනු ඇත
//!         if position == goal { return Some(cost); }
//!
//!         // වැදගත් වන්නේ අප දැනටමත් වඩා හොඳ ක්‍රමයක් සොයාගෙන ඇති බැවිනි
//!         if cost > dist[position] { continue; }
//!
//!         // අපට ළඟා විය හැකි සෑම නෝඩයක් සඳහාම, මෙම නෝඩය හරහා අඩු පිරිවැයක් දරමින් අපට මාර්ගයක් සොයාගත හැකිදැයි බලන්න
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // එසේ නම්, එය මායිමට එකතු කර ඉදිරියට යන්න
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // ලිහිල් කිරීම, අපි දැන් වඩා හොඳ ක්‍රමයක් සොයාගෙන ඇත
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // ඉලක්කය කරා ළඟා විය නොහැක
//!     None
//! }
//!
//! fn main() {
//!     // මෙය අප භාවිතා කිරීමට යන සෘජු ප්‍රස්ථාරයයි.
//!     // නෝඩ් අංක විවිධ තත්වයන්ට අනුරූප වන අතර edge පඩි සංකේතවත් කරන්නේ එක් නෝඩයක සිට තවත් නෝඩයකට ගමන් කිරීමේ පිරිවැයයි.
//!     //
//!     // දාර එක්-මාර්ගයක් බව සලකන්න.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // ප්‍රස්ථාරය යාබද ලැයිස්තුවක් ලෙස නිරූපණය කර ඇති අතර, එක් එක් දර්ශකය, නෝඩ් අගයකට අනුරූපව, පිටතට යන දාර ලැයිස්තුවක් ඇත.
//!     // එහි කාර්යක්ෂමතාව සඳහා තෝරාගෙන ඇත.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // නෝඩ් 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // නෝඩ් 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // නෝඩ් 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // නෝඩ් 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // නෝඩ් 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// ද්විමය සංචයක් සමඟ ක්‍රියාත්මක කරන ප්‍රමුඛතා පෝලිම්.
///
/// මෙය උපරිම ගොඩකි.
///
/// `Ord` trait විසින් තීරණය කරනු ලබන පරිදි, වෙනත් ඕනෑම අයිතමයකට සාපේක්ෂව අයිතමයේ ඇණවුම වෙනස් වන පරිදි එය වෙනස් කිරීම තාර්කික දෝෂයකි.
///
/// මෙය සාමාන්‍යයෙන් කළ හැක්කේ `Cell`, `RefCell`, ගෝලීය තත්වය, I/O හෝ අනාරක්ෂිත කේතය හරහා පමණි.
/// එවැනි තාර්කික දෝෂයක ප්‍රති behavior ලයක් ලෙස හැසිරීම නිශ්චිතව දක්වා නැත, නමුත් නිර්වචනය නොකළ හැසිරීමට හේතු නොවේ.
/// මෙයට panics, වැරදි ප්‍රති results ල, ගබ්සා කිරීම්, මතක කාන්දු වීම සහ අවසන් නොකිරීම ඇතුළත් විය හැකිය.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // ටයිප් අනුමානය අපට පැහැදිලි ආකාරයේ අත්සනක් මඟ හැරීමට ඉඩ දෙයි (මෙම උදාහරණයේ `BinaryHeap<i32>` වනු ඇත).
/////
/// let mut heap = BinaryHeap::new();
///
/// // ගොඩවල ඊළඟ අයිතමය බැලීමට අපට පීක් භාවිතා කළ හැකිය.
/// // මෙම අවස්ථාවේ දී, එහි තවම අයිතම කිසිවක් නොමැත, එබැවින් අපට කිසිවක් නොලැබේ.
/// assert_eq!(heap.peek(), None);
///
/// // අපි ලකුණු කිහිපයක් එකතු කරමු ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // දැන් බැලූ බැල්මට ගොඩවල ඇති වැදගත්ම අයිතමය පෙන්වයි.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // අපට ගොඩක දිග පරීක්ෂා කළ හැකිය.
/// assert_eq!(heap.len(), 3);
///
/// // අහඹු අනුපිළිවෙලකට ආපසු ලබා දුන්නද, ගොඩවල ඇති අයිතම මත අපට නැවත කියවිය හැකිය.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // අපි ඒ වෙනුවට මෙම ලකුණු ලබා ගන්නේ නම්, ඒවා නැවත පිළිවෙලට පැමිණිය යුතුය.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // අපට ඉතිරිව ඇති ඕනෑම භාණ්ඩයක ගොඩවල් ඉවත් කළ හැකිය.
/// heap.clear();
///
/// // ගොඩවල් දැන් හිස් විය යුතුය.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// `BinaryHeap` මිනි ගොඩක් බවට පත් කිරීම සඳහා `std::cmp::Reverse` හෝ අභිරුචි `Ord` ක්‍රියාත්මක කිරීම භාවිතා කළ හැකිය.
/// මෙමඟින් `heap.pop()` විශාලතම අගය වෙනුවට කුඩාම අගය ලබා දෙයි.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // `Reverse` හි අගයන් ඔතා
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // අපි දැන් මෙම ලකුණු ලබා ගන්නේ නම්, ඒවා ආපසු හැරවිය යුතුය.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # කාල සංකීර්ණත්වය
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// `push` සඳහා වන වටිනාකම අපේක්ෂිත පිරිවැයකි;ක්‍රම ලේඛනය වඩාත් සවිස්තරාත්මක විශ්ලේෂණයක් ලබා දෙයි.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// `BinaryHeap` හි ඇති විශාලතම අයිතමය සඳහා විකෘති යොමු කිරීමක් ව්‍යුහය.
///
///
/// මෙම `struct` [`BinaryHeap`] හි [`peek_mut`] ක්‍රමය මඟින් නිර්මාණය කර ඇත.
/// වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // ආරක්ෂාව: පීක්මට් ක්ෂණික වන්නේ හිස් නොවන ගොඩවල් සඳහා පමණි.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // ආරක්ෂිතයි: පීක්මූට් ක්ෂණික වන්නේ හිස් නොවන ගොඩවල් සඳහා පමණි
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // ආරක්ෂිතයි: පීක්මූට් ක්ෂණික වන්නේ හිස් නොවන ගොඩවල් සඳහා පමණි
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// ගොඩ ගසා ඇති පීක් අගය ඉවත් කර එය නැවත ලබා දෙයි.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// හිස් `BinaryHeap<T>` සාදයි.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// හිස් `BinaryHeap` උපරිම ගොඩක් ලෙස සාදයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// නිශ්චිත ධාරිතාවක් සහිත හිස් `BinaryHeap` නිර්මාණය කරයි.
    /// මෙය `capacity` මූලද්‍රව්‍ය සඳහා ප්‍රමාණවත් මතකයක් පූර්ව වෙන් කර ඇති අතර එමඟින් `BinaryHeap` අවම වශයෙන් බොහෝ අගයන් අඩංගු වන තෙක් නැවත වෙන් කිරීම අවශ්‍ය නොවේ.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// ද්විමය සංචයේ ඇති විශාලතම අයිතමය සඳහා විකෘති යොමු කිරීමක් හෝ හිස් නම් `None` ලබා දෙයි.
    ///
    /// Note: `PeekMut` අගය කාන්දු වුවහොත්, ගොඩවල් නොගැලපෙන තත්වයක පැවතිය හැකිය.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # කාල සංකීර්ණත්වය
    ///
    /// අයිතමය වෙනස් කර ඇත්නම් නරකම කාල සංකීර්ණත්වය *O*(log(*n*)) වේ, එසේ නොමැති නම් එය *O*(1) වේ.
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// ද්විමය සංචයෙන් ශ්‍රේෂ් greatest තම අයිතමය ඉවත් කර එය ආපසු ලබා දෙයි, නැතහොත් `None` හිස් නම්.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # කාල සංකීර්ණත්වය
    ///
    /// *N* මූලද්‍රව්‍ය අඩංගු සංචයක් මත `pop` හි නරකම අවස්ථාව වන්නේ *O*(log(*n*)) ය.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // ආරක්ෂාව: !self.is_empty() යන්නෙන් අදහස් වන්නේ self.len()> 0 යන්නයි
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// අයිතමයක් ද්විමය ගොඩට තල්ලු කරයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # කාල සංකීර්ණත්වය
    ///
    /// `push` හි අපේක්ෂිත පිරිවැය, තල්ලු කළ හැකි මූලද්‍රව්‍යවල සෑම අනුපිළිවෙලකටම වඩා සාමාන්‍යය සහ ප්‍රමාණවත් තරම් තල්ලු කිරීම් *O*(1) වේ.
    ///
    /// කිසියම් වර්ගීකරණ රටාවකට දැනටමත් *නොමැති* මූලද්‍රව්‍ය තල්ලු කිරීමේදී මෙය වඩාත්ම අර්ථවත් පිරිවැය මෙට්‍රික් වේ.
    ///
    /// මූලද්‍රව්‍යයන් ප්‍රධාන වශයෙන් නඟින අනුපිළිවෙලට තල්ලු කරන්නේ නම් කාල සංකීර්ණත්වය පිරිහෙයි.
    /// නරකම අවස්ථාවෙහිදී, මූලද්‍රව්‍යයන් ආරෝහණ පිළිවෙලට තල්ලු කරනු ලබන අතර *n* මූලද්‍රව්‍ය අඩංගු සංචයකට එරෙහිව තල්ලු කිරීම සඳහා ක්‍රමක්ෂය පිරිවැය *O*(log(*n*)) වේ.
    ///
    /// `push` වෙත *තනි* ඇමතුමක නරකම අවස්ථාව වන්නේ *O*(*n*) ය.නරකම අවස්ථාව සිදුවන්නේ ධාරිතාව අවසන් වූ විට සහ ප්‍රමාණය වෙනස් කිරීම අවශ්‍ය වූ විටය.
    /// ප්‍රතිව්‍යුහගත කිරීමේ පිරිවැය පෙර සංඛ්‍යාලේඛනවල ක්‍රමක්ෂය කර ඇත.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // ආරක්ෂාව: අපි නව අයිතමයක් තල්ලු කළ බැවින් එයින් අදහස් වන්නේ එයයි
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// `BinaryHeap` පරිභෝජනය කර (ascending) අනුපිළිවෙලින් vector ලබා දෙයි.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // ආරක්ෂාව: `end` `self.len() - 1` සිට 1 දක්වා යයි (දෙකම ඇතුළත් වේ),
            //  එබැවින් එය සැමවිටම ප්‍රවේශ වීමට වලංගු දර්ශකයකි.
            //  දර්ශකය 0 (එනම් `ptr`) වෙත ප්‍රවේශ වීම ආරක්ෂිතයි
            //  1 <=end <self.len(), එයින් අදහස් වන්නේ self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // ආරක්ෂාව: `end` `self.len() - 1` සිට 1 දක්වා යයි (දෙකම ඇතුළත් වේ) එබැවින්:
            //  0 <1 <=end <= self.len(), 1 <self.len() එයින් අදහස් කරන්නේ 0 <end සහ end <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Sift_up සහ sift_down ක්‍රියාත්මක කිරීම මඟින් vector (මූලද්‍රව්‍යයක් සිදුරක් ඉතිරි කර) වලින් පිටතට ගෙනයාම, අනෙක් ඒවා දිගේ මාරුවීම සහ ඉවත් කළ මූලද්‍රව්‍යය සිදුරේ අවසාන ස්ථානයේ vector වෙත ගෙන යාම සඳහා අනාරක්ෂිත කොටස් භාවිතා කරයි.
    //
    // මෙය නිරූපණය කිරීම සඳහා `Hole` වර්ගය භාවිතා වන අතර, panic හි පවා එහි විෂය පථය අවසානයේ කුහරය නැවත පුරවා ඇති බවට වග බලා ගන්න.
    // සිදුරක් භාවිතා කිරීම හුවමාරුව භාවිතා කිරීමට සාපේක්ෂව නියත සාධකය අඩු කරයි.
    //
    //
    //
    //

    /// # Safety
    ///
    /// අමතන්නා `pos < self.len()` බවට සහතික විය යුතුය.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // `pos` හි අගය ඉවත් කර සිදුරක් සාදන්න.
        // ආරක්ෂාව: අමතන්නා <self.len() යැයි සහතික කරයි
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // ආරක්ෂාව: hole.pos()> ආරම්භය>=0, එයින් අදහස් වන්නේ hole.pos()> 0 යන්නයි
            //  hole.pos(), 1 ට ගලා යා නොහැක.
            //  මවුපිය <hole.pos() මෙය වලංගු දර්ශකයක් වන අතර මෙය සහතික කරයි!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // ආරක්ෂාව: ඉහත ආකාරයටම
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// `pos` හි මූලද්‍රව්‍යයක් ගෙන එය ගොඩින් පහළට ගෙනයන්න, එහි දරුවන් විශාල වේ.
    ///
    ///
    /// # Safety
    ///
    /// අමතන්නා `pos < end <= self.len()` බවට සහතික විය යුතුය.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // ආරක්ෂාව: අමතන්නා සහතික කරන්නේ pos <end <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // ලූප් ආක්‍රමණ: දරුවා==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // දරුවන් දෙදෙනාගේ වැඩිම දරුවන් සමඟ සසඳන්න සුරක්ෂිතභාවය: ළමයා <අවසානය, 1 <self.len() සහ ළමයා + 1 <අවසානය <= self.len(), එබැවින් ඒවා වලංගු දර්ශක වේ.
            //
            //  child==2 *hole.pos() + 1!= hole.pos() සහ දරුවා + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: T යනු ZST නම් 2 *hole.pos() + 1 හෝ 2* hole.pos() + 2 පිටාර ගැලිය හැකිය
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // අපි දැනටමත් පිළිවෙලට නම්, නවත්වන්න.
            // ආරක්ෂාව: දරුවා දැන් එක්කෝ මහලු දරුවා හෝ මහලු දරුවා + 1 ය
            //  දෙකම <self.len() සහ!= hole.pos() බව අපි දැනටමත් ඔප්පු කර ඇත්තෙමු
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // ආරක්ෂාව: ඉහත ආකාරයටම.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // ආරක්ෂාව: &&කෙටි පරිපථය, එයින් අදහස් වන්නේ
        //  දෙවන කොන්දේසිය දරුවා==අවසානය, 1 <self.len() බව දැනටමත් සත්‍යයකි.
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // ආරක්ෂාව: දරුවා වලංගු දර්ශකයක් බව දැනටමත් ඔප්පු කර ඇත
            //  child==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// අමතන්නා `pos < self.len()` බවට සහතික විය යුතුය.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // ආරක්ෂාව: pos <len අමතන්නා විසින් සහතික කරනු ලැබේ
        //  පැහැදිලිවම len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// `pos` හි මූලද්‍රව්‍යයක් ගෙන එය ගොඩින් පහළට ගෙනයන්න, ඉන්පසු එය එහි ස්ථානයට ඉහළට ඔසවන්න.
    ///
    ///
    /// Note: මූලද්රව්යය විශාල බව දැනගත් විට මෙය වේගවත් වේ/පහළට සමීප විය යුතුය.
    ///
    /// # Safety
    ///
    /// අමතන්නා `pos < self.len()` බවට සහතික විය යුතුය.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // ආරක්ෂාව: අමතන්නා <self.len() යැයි සහතික කරයි.
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // ලූප් ආක්‍රමණ: දරුවා==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // ආරක්ෂාව: දරුවා <අවසානය, 1 <self.len() සහ
            //  ළමයා + 1 <end <= self.len(), එබැවින් ඒවා වලංගු දර්ශක වේ.
            //  child==2 *hole.pos() + 1!= hole.pos() සහ දරුවා + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: T යනු ZST නම් 2 *hole.pos() + 1 හෝ 2* hole.pos() + 2 පිටාර ගැලිය හැකිය
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // ආරක්ෂාව: ඉහත ආකාරයටම
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // ආරක්ෂාව: ළමයා==අවසානය, 1 <self.len(), එබැවින් එය වලංගු දර්ශකයකි
            //  සහ දරුවා==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // ආරක්ෂාව: pos යනු කුහරයෙහි පිහිටීම වන අතර එය දැනටමත් ඔප්පු කර ඇත
        //  වලංගු දර්ශකයක් වීමට.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // ආරක්ෂාව: n self.len()/2 සිට ආරම්භ වී 0 දක්වා පහත වැටේ.
            //  විට ඇති එකම අවස්ථාව! (N <self.len()) යනු self.len() ==0 නම්, නමුත් එය ලූප තත්වයෙන් බැහැර කරනු ලැබේ.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// `other` හි සියලුම අංග `self` වෙත ගෙන යන අතර `other` හිස්ව පවතී.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` O(len1 + len2) මෙහෙයුම් සහ නරකම අවස්ථාවක 2 *(len1 + len2) සැසඳීම් කරන අතර `extend` O(len2* log(len1)) මෙහෙයුම් සහ 1 *len2* log_2(len1) සැසඳීම් නරකම අවස්ථාවෙහිදී len1>= len2 යැයි උපකල්පනය කරයි.
        // විශාල ගොඩවල් සඳහා, හරස්කඩ ලක්ෂ්‍යය තවදුරටත් මෙම තර්කය අනුගමනය නොකරන අතර එය ආනුභවිකව තීරණය කරන ලදී.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// ගොඩවල් අනුපිළිවෙලින් මූලද්‍රව්‍ය ලබා ගන්නා අනුකාරකයක් ලබා දෙයි.
    /// ලබාගත් මූලද්‍රව්‍ය මුල් සංචයෙන් ඉවත් කරනු ලැබේ.
    /// ගොඩවල් අනුපිළිවෙලෙහි ඉතිරි මූලද්රව්ය ඉවත් කරනු ලැබේ.
    ///
    /// Note:
    /// * `.drain_sorted()` *O*(*n*\*log(* n*)); `.drain()` ට වඩා මන්දගාමී වේ.
    ///   බොහෝ අවස්ථාවන් සඳහා ඔබ දෙවැන්න භාවිතා කළ යුතුය.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // ගොඩවල් අනුපිළිවෙලෙහි ඇති සියලුම අංග ඉවත් කරයි
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// පුරෝකථනය මඟින් නිශ්චිතව දක්වා ඇති මූලද්‍රව්‍ය පමණක් රඳවා ගනී.
    ///
    /// වෙනත් වචන වලින් කිවහොත්, `f(&e)` `false` ආපසු ලබා දෙන `e` හි සියලුම අංග ඉවත් කරන්න.
    /// මූලද්රව්ය වර්ගීකරණය නොකළ (සහ නිශ්චිතව දක්වා නැති) අනුපිළිවෙලට පැමිණේ.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // ඉරට්ටේ අංක පමණක් තබා ගන්න
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// vector හි ඇති සියලුම අගයන් අත්තනෝමතික අනුපිළිවෙලට පිවිසෙන අනුකාරකයක් ලබා දෙයි.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // 1, 2, 3, 4 අත්තනෝමතික ලෙස මුද්‍රණය කරන්න
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// ගොඩවල් අනුපිළිවෙලින් මූලද්‍රව්‍ය ලබා ගන්නා අනුකාරකයක් ලබා දෙයි.
    /// මෙම ක්රමය මුල් සංචය පරිභෝජනය කරයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// ද්විමය සංචයේ ඇති විශාලතම අයිතමය හෝ `None` හිස් නම් එය ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # කාල සංකීර්ණත්වය
    ///
    /// නරකම අවස්ථාවක පිරිවැය *O*(1) වේ.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// නැවත වෙන් කිරීමකින් තොරව ද්විමය සංචයට තබා ගත හැකි මූලද්‍රව්‍ය ගණන ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// දී ඇති `BinaryHeap` තුළ තවත් මූලද්‍රව්‍යයන් ඇතුළත් කිරීමට අවම ධාරිතාවය හරියටම `additional` සඳහා වෙන් කර ඇත.
    /// ධාරිතාව දැනටමත් ප්රමාණවත් නම් කිසිවක් නොකරයි.
    ///
    /// වෙන් කරන්නා එකතු කිරීමට ඉල්ලීමට වඩා වැඩි ඉඩක් ලබා දෙන බව සලකන්න.
    /// එබැවින් ධාරිතාවය අවම වශයෙන් රඳා පැවතිය නොහැක.
    /// future ඇතුළු කිරීම් අපේක්ෂා කරන්නේ නම් [`reserve`] ට වැඩි කැමැත්තක් දක්වන්න.
    ///
    /// # Panics
    ///
    /// නව ධාරිතාව `usize` ඉක්මවා ගියහොත් Panics.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// `BinaryHeap` තුළට ඇතුළු කිරීමට අවම වශයෙන් තවත් `additional` මූලද්‍රව්‍ය සඳහා සංචිත ධාරිතාව.
    /// නිරන්තරයෙන් නැවත ස්ථානගත කිරීම වළක්වා ගැනීම සඳහා එකතු කිරීමට වැඩි ඉඩක් වෙන් කළ හැකිය.
    ///
    /// # Panics
    ///
    /// නව ධාරිතාව `usize` ඉක්මවා ගියහොත් Panics.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// හැකි තරම් අමතර ධාරිතාවක් බැහැර කරයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// අඩු සීමාවක් සහිත ධාරිතාව ඉවතලයි.
    ///
    /// ධාරිතාව දිග හා සැපයූ වටිනාකම යන දෙකම තරම් අවම වශයෙන් පවතිනු ඇත.
    ///
    ///
    /// වත්මන් ධාරිතාව පහළ සීමාවට වඩා අඩු නම්, මෙය විකල්පයක් නොවේ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// `BinaryHeap` පරිභෝජනය කරන අතර යටින් පවතින vector අත්තනෝමතික ලෙස නැවත ලබා දෙයි.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // කිසියම් අනුපිළිවෙලකින් මුද්‍රණය කරනු ඇත
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// ද්විමය සංචයේ දිග ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// ද්විමය සංචය හිස් දැයි පරීක්ෂා කරයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// ද්විමය සංචය ඉවත් කරයි, ඉවත් කරන ලද මූලද්රව්ය වලට වඩා අනුකාරකයක් නැවත ලබා දෙයි.
    ///
    /// මූලද්රව්ය අත්තනෝමතික ලෙස ඉවත් කරනු ලැබේ.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// ද්විමය සංචයෙන් සියලු අයිතම දමයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// සිදුර නිරූපණය කරන්නේ පෙත්තක සිදුරක්, එනම් වලංගු අගයක් නැති දර්ශකයක් (එය ගෙන ගොස් හෝ අනුපිටපත් කළ නිසා).
///
/// බිංදුවකදී, මුලින් ඉවත් කළ අගය සමඟ සිදුරේ පිහිටීම පුරවා `Hole` පෙත්ත නැවත ලබා දෙනු ඇත.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// `pos` දර්ශකයේ නව `Hole` සාදන්න.
    ///
    /// අනාරක්ෂිත බැවින් pos දත්ත පෙත්ත තුළ තිබිය යුතුය.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // සුරක්ෂිතභාවය: පෙත්තක් ඇතුළත තිබිය යුතුය
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// ඉවත් කළ මූලද්රව්යයට යොමු කිරීමක් ලබා දෙයි.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// `index` හි මූලද්‍රව්‍යය වෙත යොමු කිරීමක් ලබා දෙයි.
    ///
    /// අනාරක්ෂිත බැවින් දර්ශකය දත්ත පෙත්තක් තුළ තිබිය යුතු අතර එය pos ට සමාන නොවිය යුතුය.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// සිදුර නව ස්ථානයකට ගෙන යන්න
    ///
    /// අනාරක්ෂිත බැවින් දර්ශකය දත්ත පෙත්තක් තුළ තිබිය යුතු අතර එය pos ට සමාන නොවිය යුතුය.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // නැවත කුහරය පුරවන්න
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// `BinaryHeap` හි මූලද්‍රව්‍යවලට වඩා අනුකාරකයක්.
///
/// මෙම `struct` නිර්මාණය කර ඇත්තේ [`BinaryHeap::iter()`] විසිනි.
/// වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) `#[derive(Clone)]` සඳහා පක්ෂව ඉවත් කරන්න
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// `BinaryHeap` හි මූලද්‍රව්‍යයන්ට වඩා හිමිකාරී අනුකාරකයක්.
///
/// මෙම `struct` නිර්මාණය කර ඇත්තේ [`BinaryHeap::into_iter()`] විසිනි (`IntoIterator` trait විසින් සපයනු ලැබේ).
/// වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// `BinaryHeap` හි මූලද්‍රව්‍යවලට වඩා ජලාපවහනය.
///
/// මෙම `struct` නිර්මාණය කර ඇත්තේ [`BinaryHeap::drain()`] විසිනි.
/// වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// `BinaryHeap` හි මූලද්‍රව්‍යවලට වඩා ජලාපවහනය.
///
/// මෙම `struct` නිර්මාණය කර ඇත්තේ [`BinaryHeap::drain_sorted()`] විසිනි.
/// වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// ගොඩවල් අනුපිළිවෙලින් ගොඩවල් මූලද්‍රව්‍ය ඉවත් කරයි.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// `Vec<T>` එකක් `BinaryHeap<T>` බවට පරිවර්තනය කරයි.
    ///
    /// මෙම පරිවර්තනය තැනින් තැන සිදුවන අතර *O*(*n*) කාල සංකීර්ණතාවයක් ඇත.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// `BinaryHeap<T>` එකක් `Vec<T>` බවට පරිවර්තනය කරයි.
    ///
    /// මෙම පරිවර්තනයට දත්ත චලනය හෝ වෙන් කිරීම අවශ්‍ය නොවන අතර නිරන්තර කාල සංකීර්ණත්වයක් ඇත.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// පරිභෝජන අනුකාරකයක් සාදයි, එනම්, එක් එක් අගය ද්විමය සංචයෙන් අත්තනෝමතික අනුපිළිවෙලින් පිටතට ගෙන යයි.
    /// මෙය ඇමතීමෙන් පසු ද්විමය සංචය භාවිතා කළ නොහැක.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // 1, 2, 3, 4 අත්තනෝමතික ලෙස මුද්‍රණය කරන්න
    /// for x in heap.into_iter() {
    ///     // x ට i32 වර්ගය ඇත, &i32 නොවේ
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}