use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// සියලු යතුරු-වටිනාකම් යුගල එක්රැස් කිරීමේ අනුකාරක දෙකක එකතුවෙන් එකතු කරයි, මඟ දිගේ `length` විචල්‍යයක් වැඩි කරයි.ඩ්‍රොප් හෑන්ඩ්ලර් කලබල වන විට කාන්දුවීමක් වළක්වා ගැනීමට ඇමතුමට පහසු වේ.
    ///
    /// පුනරාවර්තකයන් දෙකම එකම යතුරක් නිපදවන්නේ නම්, මෙම ක්‍රමය මඟින් යුගලය වම් ඉරේටරයෙන් පහතට ඇද දමා දකුණු ඉරේටරයෙන් යුගලය එකතු කරයි.
    ///
    /// `BTreeMap` වැනි ගස තදින් නඟින අනුපිළිවෙලකට ගෙන යාමට ඔබට අවශ්‍ය නම්, අනුකාරක දෙකම යතුරු තදින් නැගීමේ අනුපිළිවෙලින් නිපදවිය යුතුය, සෑම එකක්ම ගසෙහි ඇති සියලුම යතුරු වලට වඩා විශාලය.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // රේඛීය වේලාවට `left` සහ `right` වර්ග කළ අනුක්‍රමයකට ඒකාබද්ධ කිරීමට අපි සූදානම් වෙමු.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // මේ අතර, අපි රේඛීය වේලාවට වර්ග කළ අනුපිළිවෙලින් ගසක් සාදන්නෙමු.
        self.bulk_push(iter, length)
    }

    /// සියලුම යතුරු-වටිනාකම් යුගලය ගසෙහි කෙළවරට තල්ලු කරමින්, මඟ දිගේ `length` විචල්‍යයක් වැඩි කරයි.
    /// දෙවැන්න, ඉරේටරය කලබල වන විට කාන්දුවීමක් වළක්වා ගැනීමට ඇමතුමට පහසු කරයි.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // සියලුම යතුරු-වටිනාකම් යුගල හරහා අනුකරණය කරන්න, ඒවා නිවැරදි මට්ටමින් නෝඩ් වලට තල්ලු කරයි.
        for (key, value) in iter {
            // යතුරු පත්‍ර යුගලය වත්මන් පත්‍ර නෝඩයට තල්ලු කිරීමට උත්සාහ කරන්න.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // ඉඩක් ඉතිරිව නැත, ඉහළට ගොස් එහි තල්ලු කරන්න.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // අවකාශය ඉතිරිව ඇති නෝඩයක් හමු විය, මෙහි තල්ලු කරන්න.
                                open_node = parent;
                                break;
                            } else {
                                // නැවත ඉහළට යන්න.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // අපි ඉහළින්ම සිටිමු, නව මූල නෝඩයක් සාදා එහි තල්ලු කරන්න.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // යතුරු-අගය යුගලය සහ නව දකුණු උප කුලකය තල්ලු කරන්න.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // නැවතත් දකුණු කෙළවරට යන්න.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // අනුකාරක භීතිකාවන් ඉදිරියට ගියත් සිතියම මඟින් එකතු කරන ලද මූලද්‍රව්‍ය පහත වැටෙන බවට වග බලා ගැනීම සඳහා සෑම පුනරාවර්තනයක්ම වැඩි කරන්න.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// වර්ග කළ අනුපිළිවෙලවල් එකකට ඒකාබද්ධ කිරීම සඳහා අනුකාරකයක්
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// යතුරු දෙකක් සමාන නම්, යතුරු ප්‍රභව යුගලය නිවැරදි ප්‍රභවයෙන් ආපසු එවන්න.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}