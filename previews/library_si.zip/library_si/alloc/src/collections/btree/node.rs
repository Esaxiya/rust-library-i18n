// මෙය පරමාදර්ශය අනුගමනය කරමින් ක්‍රියාත්මක කිරීමේ උත්සාහයකි
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Rust හි ඇත්ත වශයෙන්ම යැපෙන වර්ග සහ බහුමාමක පුනරාවර්තන නොමැති බැවින්, අපි බොහෝ අනාරක්ෂිත බවින් යුතුව කරන්නෙමු.
//

// මෙම මොඩියුලයේ ප්‍රධාන පරමාර්ථය වන්නේ ගස සාමාන්‍ය (අමුතු හැඩයකින් යුක්ත නම්) බහාලුමක් ලෙස සැලකීමෙන් සහ B-Tree ආක්‍රමණ බොහෝමයක් සමඟ ගනුදෙනු කිරීමෙන් වැළකී සිටීමයි.
//
// එනිසා, මෙම මොඩියුලය මඟින් ප්‍රවේශයන් වර්ග කර තිබේද, කුමන නෝඩ් අඩුවෙන් විය හැකිද, නැතහොත් යටි පතුල් යන්නෙන් අදහස් කරන්නේද යන්න ගණන් ගන්නේ නැත.කෙසේ වෙතත්, අපි ආක්‍රමණ කිහිපයක් මත රඳා සිටිමු:
//
// - ගස්වල ඒකාකාර depth/height තිබිය යුතුය.මෙයින් අදහස් කරන්නේ දී ඇති නෝඩයක සිට පත්‍රයක් දක්වා පහළට යන සෑම මාර්ගයක්ම එකම දිගක් ඇති බවයි.
// - `n` දිග නෝඩයකට `n` යතුරු, `n` අගයන් සහ `n + 1` දාර ඇත.
//   මෙයින් ගම්‍ය වන්නේ හිස් නෝඩයක පවා අවම වශයෙන් එක් edge වත් ඇති බවයි.
//   පත්‍ර නෝඩයක් සඳහා, "having an edge" යන්නෙන් අදහස් කරන්නේ අපට නෝඩයේ ස්ථානයක් හඳුනාගත හැකි බැවින් පත්‍ර දාර හිස් වන අතර දත්ත නිරූපණයක් අවශ්‍ය නොවන බැවිනි.
// අභ්‍යන්තර නෝඩයක, edge දෙකම පිහිටීමක් හදුනා ගන්නා අතර ළමා නෝඩයකට දර්ශකයක් අඩංගු වේ.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// පත්‍ර නෝඩ් වල යටි නිරූපණය සහ අභ්‍යන්තර නෝඩ් නිරූපණය කිරීමේ කොටසක්.
struct LeafNode<K, V> {
    /// අපට අවශ්‍ය වන්නේ `K` සහ `V` වල සහසංයුජ වීමටයි.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// මෙම නෝඩයේ දර්ශකය මව් නෝඩයේ `edges` අරාව තුළට.
    /// `*node.parent.edges[node.parent_idx]` `node` හා සමාන විය යුතුය.
    /// මෙය ආරම්භ කිරීම සහතික කරනුයේ `parent` ශුන්‍ය නොවන විට පමණි.
    parent_idx: MaybeUninit<u16>,

    /// මෙම නෝඩ් ගබඩා කරන යතුරු සහ අගයන් ගණන.
    len: u16,

    /// නෝඩයේ සත්‍ය දත්ත ගබඩා කරන අරා.
    /// ආරම්භක සහ වලංගු වන්නේ එක් එක් අරාවෙහි පළමු `len` අංග පමණි.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// නව `LeafNode` තැනින් තැන ආරම්භ කරයි.
    unsafe fn init(this: *mut Self) {
        // සාමාන්‍ය ප්‍රතිපත්තියක් ලෙස, ක්ෂේත්‍ර විය හැකි නම් අපි ඒවා ආරම්භ නොකර තබන්නෙමු, මන්ද මෙය වල්ග්‍රින්ඩ් හි ලුහුබැඳීමට තරමක් වේගවත් හා පහසු විය යුතුය.
        //
        unsafe {
            // parent_idx, යතුරු, සහ වෑල් සියල්ලම සමහර විට යුනිනිට් වේ
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// නව කොටු කළ `LeafNode` නිර්මාණය කරයි.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// අභ්‍යන්තර නෝඩ් වල යටි නිරූපණය.'ලීෆ්නෝඩ්' හි මෙන්, ආරම්භක යතුරු සහ අගයන් අතහැර දැමීම වැළැක්වීම සඳහා මේවා බොක්ස්ඩ්නෝඩ් පිටුපස සැඟවිය යුතුය.
/// `InternalNode` වෙත වන ඕනෑම දර්ශකයක් සෘජුවම නෝඩයේ `LeafNode` කොටසට යොමු කළ හැකි අතර, කේතය කොළ සහ අභ්‍යන්තර නෝඩ් මත ක්‍රියා කිරීමට කේතයට ඉඩ සලසයි.
///
/// මෙම දේපල `repr(C)` භාවිතයෙන් සක්‍රීය කර ඇත.
///
#[repr(C)]
// gdb_providers.py ස්වයං විමර්ශනය සඳහා මෙම වර්ගයේ නම භාවිතා කරයි.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// මෙම නෝඩයේ දරුවන්ට දර්ශක.
    /// `len + 1` මේවා ආරම්භක හා වලංගු යැයි සලකනු ලැබේ, අවසානයට ආසන්නව හැර, ගස රඳවාගෙන ඇත්තේ `Dying` වර්ගයේ ණය වර්ගයක් හරහා වන අතර, මෙම දර්ශකයන්ගෙන් සමහරක් අන්තරාදායක වේ.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// නව කොටු කළ `InternalNode` නිර්මාණය කරයි.
    ///
    /// # Safety
    /// අභ්‍යන්තර නෝඩ් වල වෙනස්කමක් නම් ඔවුන්ට අවම වශයෙන් එක් ආරම්භක සහ වලංගු edge එකක් තිබීමයි.
    /// මෙම ශ්‍රිතය එවැනි edge සැකසෙන්නේ නැත.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // අපට අවශ්‍ය වන්නේ දත්ත ආරම්භ කිරීම පමණි;දාර සමහර විට යුනිනිට් වේ.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// කළමනාකරණය කළ, ශුන්‍ය නොවන දර්ශකයක් නෝඩයකට.මෙය එක්කෝ `LeafNode<K, V>` ට අයත් පොයින්ටරයක් හෝ `InternalNode<K, V>` වෙත අයත් දර්ශකයකි.
///
/// කෙසේ වෙතත්, `BoxedNode` හි ඇත්ත වශයෙන්ම අඩංගු වන්නේ කුමන වර්ගයේ නෝඩ් දෙකෙන්ද යන්න පිළිබඳ තොරතුරු අඩංගු නොවන අතර අර්ධ වශයෙන් මෙම තොරතුරු නොමැතිකම නිසා වෙනම වර්ගයක් නොවන අතර විනාශකාරකයක් නොමැත.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// අයිති ගසක මූල නෝඩය.
///
/// මෙය විනාශ කරන්නෙකු නොමැති බව සලකන්න, එය අතින් පිරිසිදු කළ යුතුය.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// මුලින් හිස් වූ එහි මූල නෝඩය සහිත නව හිමිකාරී ගසක් ලබා දෙයි.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` ශුන්‍ය නොවිය යුතුය.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// විකෘති ලෙස අයිති මූල නෝඩය ණයට ගනී.
    /// `reborrow_mut` මෙන් නොව, මෙය ආරක්ෂිත වන්නේ ප්‍රතිලාභ අගය මූල විනාශ කිරීමට භාවිතා කළ නොහැකි නිසා සහ ගස ගැන වෙනත් යොමු කිරීම් තිබිය නොහැකි බැවිනි.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// තරමක් විකෘති ලෙස අයිති මූල නෝඩය ණයට ගනී.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ආපසු හැරවීමට අවසර දෙන සහ විනාශකාරී ක්‍රම සහ වෙනත් දේ සපයන යොමු කිරීමකට ආපසු හැරවිය නොහැකි ලෙස සංක්‍රමණය වීම.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// පෙර මූල නෝඩයට යොමු කරමින් තනි edge සමඟ නව අභ්‍යන්තර නෝඩයක් එක් කරයි, එම නව නෝඩය රූට් නෝඩ් බවට පත් කර එය නැවත ලබා දෙන්න.
    /// මෙය උස 1 කින් වැඩි කරන අතර `pop_internal_level` හි ප්‍රතිවිරුද්ධයයි.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, අපි දැන් අභ්‍යන්තරව සිටින බව අපට අමතක වූවා හැර:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// අභ්‍යන්තර මූල නෝඩය ඉවත් කරයි, එහි පළමු දරුවා නව මූල නෝඩය ලෙස භාවිතා කරයි.
    /// මූල නෝඩයට ඇත්තේ එක් දරුවෙකු පමණක් සිටින විට පමණක් එය කැඳවීමට අදහස් කරන බැවින්, යතුරු, අගයන් සහ අනෙකුත් ළමයින් මත පිරිසිදු කිරීමක් සිදු නොකෙරේ.
    ///
    /// මෙය උස 1 කින් අඩු වන අතර `push_internal_level` හි ප්‍රතිවිරුද්ධයයි.
    ///
    /// `Root` වස්තුවට පමණක් ප්‍රවේශ වීමට අවශ්‍ය නමුත් මූල නෝඩයට නොවේ;
    /// එය මූල හසුරුව වෙත වෙනත් හැසිරවීම් හෝ යොමු කිරීම් අවලංගු නොකරයි.
    ///
    /// Panics අභ්‍යන්තර මට්ටමක් නොමැති නම්, එනම්, මූල නෝඩය පත්‍රයක් නම්.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // ආරක්ෂාව: අපි අභ්‍යන්තර යැයි කියා සිටියෙමු.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // ආරක්ෂාව: අපි `self` පමණක් ණයට ගත් අතර එහි ණය වර්ගය සුවිශේෂී වේ.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // ආරක්ෂාව: පළමු edge සෑම විටම ආරම්භ වේ.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` සෑම විටම `K` සහ `V` වල සහසංයුජ වේ, `BorrowType` `Mut` වුවද.
// මෙය තාක්‍ෂණිකව වැරදියි, නමුත් `NodeRef` හි අභ්‍යන්තර භාවිතය හේතුවෙන් කිසිදු අනාරක්‍ෂිතභාවයක් ඇතිවිය නොහැක, මන්ද අප `K` සහ `V` වලට වඩා සම්පූර්ණයෙන්ම ජනකව සිටිමු.
//
// කෙසේ වෙතත්, පොදු වර්ගයක් `NodeRef` ඔතා ඇති විට, එය නිවැරදි විචල්‍යතාවයක් ඇති බවට වග බලා ගන්න.
//
/// නෝඩයකට යොමු කිරීම.
///
/// මෙම වර්ගයට එය ක්‍රියා කරන ආකාරය පාලනය කරන පරාමිති ගණනාවක් ඇත:
/// - `BorrowType`: ණයට ගන්නා ආකාරය විස්තර කරන සහ ජීවිත කාලය පුරාම ගෙන යන ව්‍යාජ වර්ගයකි.
///    - මෙය `Immut<'a>` වන විට, `NodeRef` දළ වශයෙන් `&'a Node` මෙන් ක්‍රියා කරයි.
///    - මෙය `ValMut<'a>` වන විට, `NodeRef` යතුරු සහ ගස් ව්‍යුහයට සාපේක්ෂව දළ වශයෙන් `&'a Node` මෙන් ක්‍රියා කරයි, නමුත් ගස පුරා ඇති අගයන් පිළිබඳ බොහෝ විකෘති යොමු කිරීම් සහජීවනය සඳහා ඉඩ දෙයි.
///    - මෙය `Mut<'a>` වන විට, `NodeRef` දළ වශයෙන් `&'a mut Node` මෙන් ක්‍රියා කරයි, නමුත් ඇතුළු කිරීමේ ක්‍රම මඟින් විකෘති ලක්ෂ්‍යයක් අගයකට සහජීවනය සඳහා ඉඩ ලබා දේ.
///    - මෙය `Owned` වන විට, `NodeRef` දළ වශයෙන් `Box<Node>` මෙන් ක්‍රියා කරයි, නමුත් විනාශකාරකයක් නොමැති අතර එය අතින් පිරිසිදු කළ යුතුය.
///    - මෙය `Dying` වන විට, `NodeRef` තවමත් දළ වශයෙන් `Box<Node>` මෙන් ක්‍රියා කරයි, නමුත් ගස ටිකෙන් ටික විනාශ කිරීමට ක්‍රම ඇති අතර සාමාන්‍ය ක්‍රම, ඇමතීමට අනාරක්ෂිත යැයි සලකුණු කර නොමැති අතර, වැරදියට ඇමතුමක් ලබා දෙන්නේ නම් UB වෙත ආයාචනා කළ හැකිය.
///
///   ඕනෑම `NodeRef` ගස හරහා සැරිසැරීමට ඉඩ දෙන බැවින්, `BorrowType` effectively ලදායී ලෙස නෝඩ් එකට පමණක් නොව මුළු ගසටම අදාළ වේ.
/// - `K` සහ `V`: මේවා නෝඩ් වල ගබඩා කර ඇති යතුරු සහ අගයන් වේ.
/// - `Type`: මෙය `Leaf`, `Internal`, හෝ `LeafOrInternal` විය හැකිය.
/// මෙය `Leaf` වන විට, `NodeRef` පත්‍ර නෝඩයකට යොමු කරයි, මෙය `Internal` වන විට `NodeRef` අභ්‍යන්තර නෝඩයකට යොමු කරයි, මෙය `LeafOrInternal` වන විට `NodeRef` එක් වර්ගයක නෝඩයකට යොමු විය හැකිය.
///   `Type` `NodeRef` වලින් පිටත භාවිතා කරන විට `NodeType` ලෙස නම් කර ඇත.
///
/// `BorrowType` සහ `NodeType` යන දෙකම ස්ථිතික ආකාරයේ ආරක්ෂාව උපයෝගී කර ගැනීම සඳහා අප ක්‍රියාත්මක කරන ක්‍රම සීමා කරයි.එවැනි සීමාවන් අපට ක්‍රියාත්මක කළ හැකි ආකාරයට සීමාවන් තිබේ:
/// - එක් එක් වර්ග පරාමිතිය සඳහා, අපට ක්‍රමයක් නිර්වචනය කළ හැක්කේ සාමාන්‍යයෙන් හෝ එක් විශේෂිත වර්ගයක් සඳහා පමණි.
/// නිදසුනක් ලෙස, අපට `into_kv` වැනි ක්‍රමයක් සාමාන්‍යයෙන් සියලු `BorrowType` සඳහා හෝ එක් වරක් ජීවිත කාලය ගත කරන සියලු වර්ග සඳහා නිර්වචනය කළ නොහැක, මන්ද එය `&'a` යොමු කිරීම් නැවත ලබා දීමට අපට අවශ්‍ය නිසාය.
///   එබැවින්, අපි එය අර්ථ දක්වන්නේ අවම බලවත් `Immut<'a>` වර්ගයට පමණි.
/// - `Mut<'a>` සිට `Immut<'a>` දක්වා අපට බලහත්කාරය ලබා ගත නොහැක.
///   එබැවින්, `into_kv` වැනි ක්‍රමයකට ලඟාවීම සඳහා අපට වඩාත් ප්‍රබල `NodeRef` මත `reborrow` අමතන්න.
///
/// `NodeRef` හි ඇති සියලුම ක්‍රම යම් ආකාරයක යොමු කිරීමක් ලබා දෙයි,
/// - `self` අගය අනුව ගෙන, `BorrowType` විසින් ගෙන යන ජීවිත කාලය නැවත ලබා දෙන්න.
///   සමහර විට, එවැනි ක්රමයක් ඉල්ලා සිටීමට, අපි `reborrow_mut` අමතන්න.
/// - X001 විසින් ගෙන යන ආයු කාලය වෙනුවට `self` යොමු කරන්න, සහ (implicitly) එම යොමු ආයු කාලය නැවත ලබා දෙයි.
/// ඒ ආකාරයෙන්, ආපසු යොමු කරන ලද යොමුව භාවිතා කරන තාක් කල් `NodeRef` ණයට ගත් බව ණය පරීක්ෂකයා සහතික කරයි.
///   ඇතුළු කිරීමට සහාය වන ක්‍රම මෙම නියමය නැමෙන්නේ අමු දර්ශකයක්, එනම් ජීවිත කාලයකින් තොරව යොමු කිරීමෙනි.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// `Type` මගින් සම්පූර්ණයෙන් විස්තර කළ නොහැකි නෝඩයේ නියතයක් වන අතර, නෝඩ් එකම ගබඩා නොකරන බවට නෝඩ් සහ කොළ මට්ටම වෙන්ව ඇති මට්ටම් ගණන.
    /// අපට අවශ්‍ය වන්නේ මූල නෝඩයේ උස ගබඩා කිරීම පමණක් වන අතර අනෙක් සෑම නෝඩයකම උස එයින් ලබා ගනී.
    /// `Type` `Leaf` නම් ශුන්‍ය විය යුතු අතර `Type` `Internal` නම් ශුන්‍ය නොවේ.
    ///
    ///
    height: usize,
    /// පත්‍රයට හෝ අභ්‍යන්තර නෝඩයට දර්ශකය.
    /// `InternalNode` හි අර්ථ දැක්වීම මඟින් දර්ශකය ඕනෑම ආකාරයකින් වලංගු බව සහතික කරයි.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// `NodeRef::parent` ලෙස ඇසුරුම් කළ නෝඩ් යොමු කිරීමක් ඉවත් කරන්න.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// අභ්‍යන්තර නෝඩයක දත්ත නිරාවරණය කරයි.
    ///
    /// මෙම නෝඩයට වෙනත් යොමු කිරීම් අවලංගු නොකිරීමට අමු ptr එකක් ලබා දෙයි.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // ආරක්ෂාව: ස්ථිතික නෝඩ් වර්ගය `Internal` වේ.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// අභ්‍යන්තර නෝඩයක දත්ත වලට පමණක් ප්‍රවේශය ලබා ගනී.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// නෝඩයේ දිග සොයා ගනී.යතුරු හෝ අගයන් ගණන මෙයයි.
    /// දාර ගණන `len() + 1` වේ.
    /// ආරක්ෂිත වුවත්, මෙම ශ්‍රිතය ඇමතීමෙන් අනාරක්ෂිත කේතයක් නිර්මාණය කර ඇති විකෘති යොමු අවලංගු කිරීමේ අතුරු effect ලයක් ඇති බව සලකන්න.
    ///
    pub fn len(&self) -> usize {
        // තීරණාත්මක ලෙස, අපි මෙහි පිවිසෙන්නේ `len` ක්ෂේත්‍රයට පමණි.
        // BorrowType marker::ValMut නම්, අප අවලංගු නොකළ යුතු අගයන් පිළිබඳ කැපී පෙනෙන විකෘති යොමු කිරීම් තිබිය හැකිය.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// නෝඩ් සහ කොළ වෙන්ව ඇති මට්ටම් ගණන ලබා දෙයි.
    /// ශුන්‍ය උස යනු නෝඩය කොළයක් ම ය.
    /// ඔබ මුලට ඉහළින් ඇති ගස් පින්තාරු කරන්නේ නම්, අංකය පවසන්නේ කුමන උන්නතාංශයක නෝඩය දිස්වනවාද යන්නයි.
    /// ඔබ ඉහළින් කොළ ඇති ගස් පින්තාරු කරන්නේ නම්, අංකය පවසන්නේ ගස නෝඩයට ඉහළින් කොතරම් ඉහළට විහිදෙනවාද යන්නයි.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// එකම නෝඩයට තාවකාලිකව තවත් වෙනස් කළ නොහැකි සඳහනක් ගෙන යයි.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ඕනෑම පත්‍රයක හෝ අභ්‍යන්තර නෝඩයක පත්‍ර කොටස නිරාවරණය කරයි.
    ///
    /// මෙම නෝඩයට වෙනත් යොමු කිරීම් අවලංගු නොකිරීමට අමු ptr එකක් ලබා දෙයි.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // නෝඩ් අවම වශයෙන් ලීෆ්නෝඩ් කොටස සඳහා වලංගු විය යුතුය.
        // මෙය NodeRef වර්ගයේ සඳහනක් නොවේ, මන්ද එය අද්විතීයද, බෙදා ගත යුතුද යන්න අපි නොදනිමු.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// වත්මන් නෝඩයේ මවුපියන් සොයා ගනී.
    /// වත්මන් නෝඩයට ඇත්ත වශයෙන්ම මාපියෙකු සිටී නම් `Ok(handle)` ලබා දෙයි, එහිදී `handle` වත්මන් නෝඩයට යොමු කරන මවුපියන්ගේ edge වෙත යොමු කරයි.
    ///
    /// වත්මන් නෝඩයට මවුපියන් නොමැති නම් `Err(self)` ලබා දෙයි, මුල් `NodeRef` ආපසු ලබා දෙයි.
    ///
    /// ක්‍රමයේ නම ඔබ උපකල්පනය කරන්නේ ඉහළින් ඇති මූල නෝඩය සහිත ගස් පින්තාරු කිරීමයි.
    ///
    /// `edge.descend().ascend().unwrap()` සහ `node.ascend().unwrap().descend()` දෙකම සාර්ථක වූ පසු කිසිවක් නොකළ යුතුය.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // BrowType marker::ValMut නම්, අප අවලංගු නොකළ යුතු අගයන් සඳහා කැපී පෙනෙන විකෘති යොමු කිරීම් තිබිය හැකි බැවින් අපි නෝඩ් සඳහා අමු දර්ශක භාවිතා කළ යුතුය.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// `self` අක්‍රීය විය යුතු බව සලකන්න.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// `self` අක්‍රීය විය යුතු බව සලකන්න.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// වෙනස් කළ නොහැකි ගසක ඕනෑම පත්‍රයක හෝ අභ්‍යන්තර නෝඩයක පත්‍ර කොටස නිරාවරණය කරයි.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // ආරක්ෂාව: `Immut` ලෙස ණයට ගත් මෙම ගසෙහි විකෘති යොමු දැක්වීම් තිබිය නොහැක.
        unsafe { &*ptr }
    }

    /// නෝඩයේ ගබඩා කර ඇති යතුරු වෙත දර්ශනයක් ලබා ගනී.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// `ascend` ට සමානව, නෝඩයේ මව් නෝඩයට යොමු කිරීමක් ලැබෙනවා පමණක් නොව, ක්‍රියාවලියේ වත්මන් නෝඩ් එක ඉවත් කරයි.
    /// මෙය අනාරක්ෂිත බැවින් ඉවත් කර තිබියදීත් වත්මන් නෝඩයට ප්‍රවේශ විය හැකි බැවිනි.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// මෙම නෝඩය `Leaf` බව ස්ථිතික තොරතුරු සම්පාදකයාට අනාරක්ෂිත ලෙස ප්‍රකාශ කරයි.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// මෙම නෝඩය `Internal` බව ස්ථිතික තොරතුරු සම්පාදකයාට අනාරක්ෂිත ලෙස ප්‍රකාශ කරයි.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// එකම නෝඩයට තාවකාලිකව තවත් විකෘති යොමු කිරීමක් කරයි.මෙම ක්‍රමය ඉතා භයානක බැවින් පරිස්සම් වන්න, එය වහාම භයානක ලෙස නොපෙනෙන බැවින් දෙගුණයක්.
    ///
    /// විකෘති දර්ශකයන්ට ගස වටා ඕනෑම තැනක සැරිසැරීමට හැකි නිසා, ආපසු පැමිණි දර්ශකය පහසුවෙන් මුල් දර්ශකය එල්ලා තැබීමට, සීමාව ඉක්මවා හෝ ගොඩගැසී ඇති ණය නීති යටතේ අවලංගු කිරීමට භාවිතා කළ හැකිය.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) `NodeRef` වෙත තවත් වර්ගයක පරාමිතියක් එක් කිරීම සලකා බලන්න, එය නැවත සකස් කරන ලද දර්ශක මත සංචාලන ක්‍රම භාවිතය සීමා කරයි, මෙම අනාරක්ෂිත බව වළක්වයි.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ඕනෑම පත්‍රයක හෝ අභ්‍යන්තර නෝඩයක පත්‍ර කොටසට විශේෂ ප්‍රවේශයක් ලබා ගනී.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // ආරක්ෂාව: අපට සම්පූර්ණ නෝඩයටම ප්‍රවේශ විය හැකිය.
        unsafe { &mut *ptr }
    }

    /// ඕනෑම පත්‍රයක හෝ අභ්‍යන්තර නෝඩයක පත්‍ර කොටසට සුවිශේෂී ප්‍රවේශයක් ලබා දේ.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // ආරක්ෂාව: අපට සම්පූර්ණ නෝඩයටම ප්‍රවේශ විය හැකිය.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// යතුරු ගබඩා කරන ප්‍රදේශයේ මූලද්‍රව්‍යයකට සුවිශේෂී ප්‍රවේශයක් ලබා ගනී.
    ///
    /// # Safety
    /// `index` 0. .CAPACITY සීමාවෙන්
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // ආරක්ෂාව: අමතන්නාට ස්වයංක්‍රීයව තවත් ක්‍රම ඇමතීමට නොහැකි වනු ඇත
        // ණය ලබා ගැනීමේ ආයු කාලය සඳහා අපට අද්විතීය ප්‍රවේශයක් ඇති බැවින් යතුරු පෙති යොමු කිරීම අත්හරින තුරු.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// නෝඩයේ අගය ගබඩා කරන ප්‍රදේශයේ මූලද්‍රව්‍යයකට හෝ පෙත්තකට විශේෂ ප්‍රවේශයක් ලබා ගනී.
    ///
    /// # Safety
    /// `index` 0. .CAPACITY සීමාවෙන්
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // ආරක්ෂාව: අමතන්නාට ස්වයංක්‍රීයව තවත් ක්‍රම ඇමතීමට නොහැකි වනු ඇත
        // ණය ලබා ගැනීමේ ආයු කාලය සඳහා අපට අද්විතීය ප්‍රවේශයක් ඇති බැවින්, වටිනාකම් පෙති යොමු කිරීම අත්හරින තුරු.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// edge අන්තර්ගතයන් සඳහා නෝඩයේ ගබඩා ප්‍රදේශයේ මූලද්‍රව්‍යයකට හෝ පෙත්තකට විශේෂ ප්‍රවේශයක් ලබා ගනී.
    ///
    /// # Safety
    /// `index` 0. .CAPACITY + 1 සීමාවේ පවතී
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // ආරක්ෂාව: අමතන්නාට ස්වයංක්‍රීයව තවත් ක්‍රම ඇමතීමට නොහැකි වනු ඇත
        // ණය ලබා ගැනීමේ ආයු කාලය සඳහා අපට අද්විතීය ප්‍රවේශයක් ඇති බැවින් edge පෙති යොමු කිරීම අත්හරින තුරු.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - නෝඩයේ `idx` ආරම්භක මූලද්‍රව්‍යයන්ට වඩා තිබේ.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // අප උනන්දු වන්නේ එක් මූලද්‍රව්‍යයක් ගැන පමණක් වන අතර, වෙනත් මූලද්‍රව්‍යයන් පිළිබඳ කැපී පෙනෙන යොමු කිරීම් සමඟ අන්වර්ථ වීම වළක්වා ගැනීම සඳහා, විශේෂයෙන්, කලින් පුනරාවර්තන වලදී ඇමතුම්කරු වෙත ආපසු පැමිණි අය.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Rust නිකුතුව #74679 නිසා අපි විශාල නොකළ අරාව දර්ශකයන් වෙත බල කළ යුතුය.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// නෝඩයේ දිගට විශේෂ ප්‍රවේශයක් ලබා ගනී.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// නෝඩ් වෙත වෙනත් යොමු කිරීම් අවලංගු නොකර, එහි මව් edge වෙත නෝඩ් සබැඳිය සකසයි.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// එහි මව් edge වෙත මූල සම්බන්ධකය ඉවත් කරයි.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// යතුරු අගය යුගලයක් නෝඩයේ අවසානයට එක් කරයි.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// `range` විසින් ආපසු ලබා දෙන සෑම අයිතමයක්ම නෝඩ් සඳහා වලංගු edge දර්ශකයකි.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// යතුරු යුගලයක් සහ edge එකක් එම යුගලයේ දකුණට, නෝඩයේ අවසානයට එක් කරයි.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// නෝඩයක් `Internal` නෝඩයක්ද නැතිනම් `Leaf` නෝඩයක්ද යන්න පරීක්ෂා කරයි.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// විශේෂිත යතුරු-අගය යුගලයක් හෝ නෝඩයක් තුළ edge වෙත යොමු කිරීම.
/// `Node` පරාමිතිය `NodeRef` විය යුතු අතර, `Type` එක්කෝ `KV` විය හැකිය (යතුරු අගය යුගලයක හසුරුව සංකේතවත් කරයි) හෝ `Edge` (edge හි හසුරුව සංකේතවත් කරයි).
///
/// `Leaf` නෝඩ් වලට පවා `Edge` හැන්ඩ්ල්ස් තිබිය හැකි බව සලකන්න.
/// ළමා නෝඩයකට දර්ශකයක් නිරූපණය කරනවා වෙනුවට, මේවායින් දැක්වෙන්නේ යතුරු අගය යුගල අතර ළමා දර්ශකයන් යා හැකි අවකාශයන් ය.
/// නිදසුනක් ලෙස, දිග 2 ක් ඇති නෝඩයක, හැකි edge ස්ථාන 3 ක්, නෝඩයේ වමට එකක්, යුගල දෙක අතර එකක් සහ නෝඩයේ දකුණු පසින් එකක් තිබිය හැකිය.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// අපට `#[derive(Clone)]` හි පූර්ණ සාමාන්‍ය භාවය අවශ්‍ය නොවේ, මන්ද `Node` යනු `ක්ලෝන` කළ හැකි එකම අවස්ථාව වන්නේ එය වෙනස් කළ නොහැකි යොමු කිරීමක් වන අතර එබැවින් `Copy` ය.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// මෙම හසුරුව පෙන්වා දෙන edge හෝ යතුරු අගය යුගලයක් ඇති නෝඩය ලබා ගනී.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// නෝඩයේ මෙම හසුරුවෙහි පිහිටීම ලබා දෙයි.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// `node` හි යතුරු අගය යුගලයකට නව හසුරුව සාදයි.
    /// අනාරක්ෂිත බැවින් ඇමතුම්කරු `idx < node.len()` බව සහතික කළ යුතුය.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// PartialEq හි පොදු ක්‍රියාත්මක කිරීමක් විය හැකි නමුත් මෙම මොඩියුලයේ පමණක් භාවිතා වේ.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// එකම ස්ථානයක තාවකාලිකව තවත් වෙනස් කළ නොහැකි හසුරුවකින් පිටතට ගනී.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // අපගේ වර්ගය අප නොදන්නා නිසා අපට Handle::new_kv හෝ Handle::new_edge භාවිතා කළ නොහැක
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// හසුරුවන්නාගේ නෝඩය `Leaf` බව ස්ථිතික තොරතුරු සම්පාදකයාට අනාරක්ෂිත ලෙස ප්‍රකාශ කරයි.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// එකම ස්ථානයක තාවකාලිකව තවත් විකෘති හැසිරවීමක් සිදු කරයි.
    /// මෙම ක්‍රමය ඉතා භයානක බැවින් පරිස්සම් වන්න, එය වහාම භයානක ලෙස නොපෙනෙන බැවින් දෙගුණයක්.
    ///
    ///
    /// විස්තර සඳහා, `NodeRef::reborrow_mut` බලන්න.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // අපගේ වර්ගය අප නොදන්නා නිසා අපට Handle::new_kv හෝ Handle::new_edge භාවිතා කළ නොහැක
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// `node` හි edge වෙත නව හසුරුව නිර්මාණය කරයි.
    /// අනාරක්ෂිත බැවින් ඇමතුම්කරු `idx <= node.len()` බව සහතික කළ යුතුය.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// අපට ධාරිතාවයෙන් පිරුණු නෝඩයකට ඇතුළු කිරීමට අවශ්‍ය edge දර්ශකයක් ලබා දී ඇති විට, බෙදීම් ලක්ෂ්‍යයක සංවේදී KV දර්ශකය ගණනය කරයි.
///
/// භේද ලක්ෂ්‍යයේ පරමාර්ථය වන්නේ එහි යතුර සහ වටිනාකම මව් නෝඩයකින් අවසන් වීමයි;
/// බෙදීම් ලක්ෂ්‍යයේ වම්පස ඇති යතුරු, අගයන් සහ දාර වම් දරුවා බවට පත්වේ;
/// බෙදීම් ලක්ෂ්‍යයේ දකුණට යතුරු, අගයන් සහ දාර නිවැරදි දරුවා බවට පත්වේ.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust නිකුතුව #74834 මෙම සමමිතික නීති පැහැදිලි කිරීමට උත්සාහ කරයි.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// මෙම edge හි දකුණට සහ වමට යතුරු අගය යුගල අතර නව යතුරු-වටිනා යුගලයක් ඇතුළත් කරයි.
    /// මෙම ක්‍රමය උපකල්පනය කරන්නේ නව යුගලයට ගැළපෙන පරිදි ප්‍රමාණවත් ඉඩ ප්‍රමාණයක් නෝඩයේ ඇති බවයි.
    ///
    /// ආපසු ලබා දුන් දර්ශකය ඇතුළත් කළ අගයට යොමු කරයි.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// මෙම edge හි දකුණට සහ වමට යතුරු අගය යුගල අතර නව යතුරු-වටිනා යුගලයක් ඇතුළත් කරයි.
    /// ප්‍රමාණවත් ඉඩක් නොමැති නම් මෙම ක්‍රමය මඟින් නෝඩය බෙදී යයි.
    ///
    /// ආපසු ලබා දුන් දර්ශකය ඇතුළත් කළ අගයට යොමු කරයි.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// මෙම edge සම්බන්ධ කරන ළමා නෝඩයේ මව් දර්ශකය සහ දර්ශකය නිවැරදි කරයි.
    /// දාරවල අනුපිළිවෙල වෙනස් කර ඇති විට මෙය ප්‍රයෝජනවත් වේ,
    fn correct_parent_link(self) {
        // නෝඩයට වෙනත් යොමු කිරීම් අවලංගු නොකර බැක්පොයින්ටර් සාදන්න.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// මෙම edge සහ යතුරු අගය යුගලය අතර මෙම edge අතර දකුණට යන නව යතුරු-අගය යුගලයක් සහ edge ඇතුළත් කරයි.
    /// මෙම ක්‍රමය උපකල්පනය කරන්නේ නව යුගලයට ගැළපෙන පරිදි ප්‍රමාණවත් ඉඩ ප්‍රමාණයක් නෝඩයේ ඇති බවයි.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// මෙම edge සහ යතුරු අගය යුගලය අතර මෙම edge අතර දකුණට යන නව යතුරු-අගය යුගලයක් සහ edge ඇතුළත් කරයි.
    /// ප්‍රමාණවත් ඉඩක් නොමැති නම් මෙම ක්‍රමය මඟින් නෝඩය බෙදී යයි.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// මෙම edge හි දකුණට සහ වමට යතුරු අගය යුගල අතර නව යතුරු-වටිනා යුගලයක් ඇතුළත් කරයි.
    /// ප්‍රමාණවත් ඉඩක් නොමැති නම් මෙම ක්‍රමය මඟින් නෝඩය බෙදී යන අතර, මූලයට ළඟා වන තෙක් බෙදී ගිය කොටස පුනරාවර්තව මව් නෝඩයට ඇතුළු කිරීමට උත්සාහ කරයි.
    ///
    ///
    /// ආපසු ලබා දුන් ප්‍රති result ලය `Fit` නම්, එහි හසුරුවන නෝඩය මෙම edge හි නෝඩය හෝ මුතුන් මිත්තෙකු විය හැකිය.
    /// ආපසු ලබා දුන් ප්‍රති result ලය `Split` නම්, `left` ක්ෂේත්‍රය මූල නෝඩය වනු ඇත.
    /// ආපසු ලබා දුන් දර්ශකය ඇතුළත් කළ අගයට යොමු කරයි.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// මෙම edge විසින් පෙන්වා ඇති නෝඩය සොයා ගනී.
    ///
    /// ක්‍රමයේ නම ඔබ උපකල්පනය කරන්නේ ඉහළින් ඇති මූල නෝඩය සහිත ගස් පින්තාරු කිරීමයි.
    ///
    /// `edge.descend().ascend().unwrap()` සහ `node.ascend().unwrap().descend()` දෙකම සාර්ථක වූ පසු කිසිවක් නොකළ යුතුය.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // BrowType marker::ValMut නම්, අප අවලංගු නොකළ යුතු අගයන් සඳහා කැපී පෙනෙන විකෘති යොමු කිරීම් තිබිය හැකි බැවින් අපි නෝඩ් සඳහා අමු දර්ශක භාවිතා කළ යුතුය.
        // එම අගය පිටපත් කර ඇති නිසා උස ක්ෂේත්‍රයට ප්‍රවේශ වීමට කරදරයක් නැත.
        // නෝඩ් පොයින්ටරය විකෘති වූ පසු, අපි දාරවල අරාව වෙත යොමු කිරීමක් (Rust නිකුතුව #73987) වෙත ප්‍රවේශ වන අතර අරාව වෙත හෝ ඇතුළත වෙනත් යොමු කිරීම් අවලංගු කරන්න.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // අපට වෙනම යතුර සහ වටිනාකම් ක්‍රම ඇමතිය නොහැක, මන්ද දෙවැන්න ඇමතීමෙන් පළමුවැන්නා විසින් යොමු කරන ලද යොමු කිරීම අවලංගු වේ.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// KV හසුරුව යොමු කරන යතුර සහ අගය ප්‍රතිස්ථාපනය කරන්න.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// පත්‍ර දත්ත ගැන සැලකිලිමත් වීමෙන් විශේෂිත `NodeType` සඳහා `split` ක්‍රියාත්මක කිරීමට උපකාරී වේ.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// යටින් පවතින නෝඩය කොටස් තුනකට බෙදයි:
    ///
    /// - මෙම හසුරුවෙහි වම්පස ඇති යතුරු අගයන් යුගල පමණක් අඩංගු වන පරිදි නෝඩය කපා ඇත.
    /// - මෙම හසුරුව මගින් පෙන්වා ඇති යතුර සහ වටිනාකම උපුටා ගනු ලැබේ.
    /// - මෙම හසුරුවෙහි දකුණට ඇති සියලුම යතුරු අගය යුගල අලුතින් වෙන් කරන ලද නෝඩයකට දමා ඇත.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// මෙම හසුරුව මඟින් පෙන්වා ඇති යතුරු-අගය යුගලය ඉවත් කර යතුරු අගය යුගලය බිඳ වැටුණු edge සමඟ එය ආපසු ලබා දෙයි.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// යටින් පවතින නෝඩය කොටස් තුනකට බෙදයි:
    ///
    /// - මෙම හසුරුවෙහි වම්පස ඇති දාර සහ යතුරු අගය යුගල පමණක් අඩංගු වන පරිදි නෝඩය කපා ඇත.
    /// - මෙම හසුරුව මගින් පෙන්වා ඇති යතුර සහ වටිනාකම උපුටා ගනු ලැබේ.
    /// - මෙම හසුරුවෙහි දකුණට ඇති සියලුම දාර සහ යතුරු අගය යුගල අලුතින් වෙන් කරන ලද නෝඩයකට දමා ඇත.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// අභ්‍යන්තර යතුරු අගය යුගලයක් වටා සමතුලිත මෙහෙයුමක් ඇගයීම සහ සිදු කිරීම සඳහා සැසියක් නියෝජනය කරයි.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// කුඩා කාලයේ දී නෝඩය සම්බන්ධ වන තුලනය කිරීමේ සන්දර්භයක් තෝරා ගනී, මේ අනුව KV අතර වහාම වම් පැත්තට හෝ මව් නෝඩයේ දකුණට.
    /// දෙමව්පියන් නොමැති නම් `Err` ලබා දෙයි.
    /// මවුපියන් හිස් නම් Panics.
    ///
    /// ලබා දී ඇති නෝඩය කෙසේ හෝ අඩුවෙන් තිබේ නම් ප්‍රශස්ත වීමට වම් පැත්තට වැඩි කැමැත්තක් දක්වයි, මෙහි අර්ථය වන්නේ එහි වම් සහෝදරයාට වඩා සහ එහි දකුණු සහෝදරයාට වඩා අඩු මූලද්‍රව්‍යයන් ඇති බව පමණි.
    /// එවැනි අවස්ථාවකදී, වම් සහෝදරයා සමඟ ඒකාබද්ධ වීම වේගවත් වේ, මන්ද අපට අවශ්‍ය වන්නේ නෝඩයේ එන් මූලද්‍රව්‍ය පමණක් දකුණට මාරු කිරීම සහ ඉදිරියෙන් ඇති එන් මූලද්‍රව්‍යයන්ට වඩා චලනය කිරීම වෙනුවට ය.
    /// වම් සහෝදරයාගෙන් සොරකම් කිරීම ද සාමාන්‍යයෙන් වේගවත් ය, මන්ද අපට අවශ්‍ය වන්නේ අවම වශයෙන් N සහෝදරයාගේ මූලද්‍රව්‍යයන් වමට මාරු කිරීම වෙනුවට නෝඩයේ N මූලද්‍රව්‍ය දකුණට මාරු කිරීම පමණි.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// ඒකාබද්ධ කිරීම කළ හැකිද යන්න නැවත ලබා දෙයි, එනම්, මධ්‍යම කේවී යාබද ළමා නෝඩ් දෙකම සමඟ ඒකාබද්ධ කිරීමට ප්‍රමාණවත් ඉඩක් නෝඩයක තිබේද යන්න.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// ඒකාබද්ධ කිරීමක් සිදු කරන අතර නැවත පැමිණිය යුත්තේ කුමක් දැයි තීරණය කිරීමට වසා දැමීමට ඉඩ දෙයි.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // ආරක්ෂාව: ඒකාබද්ධ කරන ලද නෝඩ් වල උස උසට වඩා එකකි
                // මෙම edge හි නෝඩයේ, මේ අනුව බිංදුවට ඉහළින්, එබැවින් ඒවා අභ්‍යන්තර වේ.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// දෙමව්පියන්ගේ යතුරු-වටිනාකමේ යුගලය සහ යාබද ළමා නෝඩ් දෙකම වම් ළමා නෝඩයට ඒකාබද්ධ කර හැකිලී ඇති මව් නෝඩය නැවත ලබා දෙයි.
    ///
    ///
    /// අපි `.can_merge()` මිස Panics.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// දෙමව්පියන්ගේ යතුරු අගය යුගලය සහ යාබද ළමා නෝඩ් දෙකම වම් ළමා නෝඩයට ඒකාබද්ධ කර එම ළමා නෝඩය නැවත ලබා දෙයි.
    ///
    ///
    /// අපි `.can_merge()` මිස Panics.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// දෙමව්පියන්ගේ යතුරු-වටිනාකමේ යුගලය සහ යාබද ළමා නෝඩ් දෙකම වම් ළමා නෝඩයට ඒකාබද්ධ කර edge හසුරුව එම ළමා නෝඩයේ edge හසුරුවනු ලැබේ.
    ///
    ///
    /// අපි `.can_merge()` මිස Panics.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// යතුරු-වටිනාකමේ යුගලයක් වම් දරුවාගෙන් ඉවත් කර එය දෙමව්පියන්ගේ යතුරු-වටිනාකමේ ගබඩාවේ තබන අතර පරණ මව් යතුරු අගය යුගලය නිවැරදි දරුවා වෙතට තල්ලු කරයි.
    ///
    /// `track_right_edge_idx` විසින් නියම කරන ලද මුල් edge අවසන් වූ ස්ථානයට අනුරූපව නිවැරදි දරුවා තුළ edge වෙත හසුරුව ලබා දෙයි.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// යතුරු-වටිනාකමින් යුත් යුගලයක් දකුණු දරුවාගෙන් ඉවත් කර එය දෙමව්පියන්ගේ යතුරු-වටිනාකමේ ගබඩාවේ තබන අතර පරණ මව් යතුරු අගය යුගලය වම් දරුවා මතට තල්ලු කරයි.
    ///
    /// `track_left_edge_idx` විසින් නිශ්චිතව දක්වා ඇති වම් දරුවාගේ edge වෙත හසුරුව ලබා දෙයි, එය චලනය නොවීය.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// මෙය `steal_left` ට සමාන සොරකම් කරන නමුත් එකවර මූලද්‍රව්‍ය සොරකම් කරයි.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // අපි ආරක්ෂිතව සොරකම් කිරීමට වග බලා ගන්න.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // පත්‍ර දත්ත ගෙනයන්න.
            {
                // නිවැරදි දරුවා තුළ සොරකම් කරන ලද මූලද්රව්ය සඳහා ඉඩක් සකසන්න.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // මූලද්‍රව්‍ය වම් දරුවාගේ සිට දකුණට ගෙන යන්න.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // වම්-වඩාත්ම සොරකම් කළ යුගලය දෙමාපිය වෙත ගෙන යන්න.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // දෙමව්පියන්ගේ යතුරු වටිනාකම් යුගලය නිවැරදි දරුවා වෙත ගෙන යන්න.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // සොරකම් කළ දාර සඳහා ඉඩක් සකසන්න.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // දාර සොරකම් කරන්න.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// `bulk_steal_left` හි සමමිතික ක්ලෝනය.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // අපි ආරක්ෂිතව සොරකම් කිරීමට වග බලා ගන්න.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // පත්‍ර දත්ත ගෙනයන්න.
            {
                // නිවැරදිව සොරකම් කළ යුගලය දෙමාපිය වෙත ගෙන යන්න.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // දෙමව්පියන්ගේ යතුරු අගය යුගලය වම් දරුවා වෙත ගෙන යන්න.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // මූලද්‍රව්‍ය දකුණු දරුවාගේ සිට වමට ගෙන යන්න.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // සොරකම් කරන ලද මූලද්‍රව්‍ය භාවිතා කළ පරතරය පුරවන්න.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // දාර සොරකම් කරන්න.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // සොරකම් කරන ලද දාර තිබූ පරතරය පුරවන්න.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// මෙම නෝඩය `Leaf` නෝඩයක් බව තහවුරු කරන ඕනෑම ස්ථිතික තොරතුරු ඉවත් කරයි.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// මෙම නෝඩය `Internal` නෝඩයක් බව තහවුරු කරන ඕනෑම ස්ථිතික තොරතුරු ඉවත් කරයි.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// යටින් පවතින නෝඩය `Internal` නෝඩයක්ද නැතිනම් `Leaf` නෝඩයක්ද යන්න පරීක්ෂා කරයි.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// `self` පසු උපසර්ගය එක් නෝඩයකින් තවත් නෝඩ් එකකට ගෙන යන්න.`right` හිස් විය යුතුය.
    /// `right` හි පළමු edge නොවෙනස්ව පවතී.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// නෝඩ් එකක ධාරිතාවෙන් ඔබ්බට පුළුල් වීමට අවශ්‍ය වූ විට ඇතුළත් කිරීමේ ප්‍රති ult ලය.
pub struct SplitResult<'a, K, V, NodeType> {
    // `kv` හි වමට අයත් මූලද්‍රව්‍ය සහ දාර සහිත පවතින ගසෙහි වෙනස් කළ නෝඩ්.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // වෙනත් යතුරක් ඇතුළු කළ යුතු යතුර සහ අගය බෙදී යයි.
    pub kv: (K, V),
    // `kv` හි දකුණට අයත් මූලද්‍රව්‍ය සහ දාර සහිත හිමිකාරී, නොබැඳි, නව නෝඩයක්.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // මෙම ණය වර්ගයේ නෝඩ් යොමු කිරීම් ගසෙහි වෙනත් නෝඩ් වෙත ගමන් කිරීමට ඉඩ දෙන්නේද යන්න.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // ගමන් කිරීම අවශ්‍ය නොවේ, එය සිදුවන්නේ `borrow_mut` හි ප්‍රති result ලය භාවිතා කරමිනි.
        // ගමන් කිරීම අක්‍රීය කිරීමෙන් සහ මුල් සඳහා නව යොමු කිරීම් පමණක් නිර්මාණය කිරීමෙන්, `Owned` වර්ගයේ සෑම සඳහනක්ම මූල නෝඩයකට බව අපි දනිමු.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// ආරම්භක මූලද්‍රව්‍ය පෙත්තකට අගයක් ඇතුල් කර ඉන්පසු ආරම්භ නොකළ මූලද්‍රව්‍යයක්.
///
/// # Safety
/// පෙත්තෙහි `idx` මූලද්‍රව්‍යවලට වඩා ඇත.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// සියලු ආරම්භක මූලද්‍රව්‍ය පෙත්තකින් අගය ඉවත් කර ආපසු ලබා දෙන අතර, එක් ආරම්භක මූලද්‍රව්‍යයක් පසුපසින් යයි.
///
///
/// # Safety
/// පෙත්තෙහි `idx` මූලද්‍රව්‍යවලට වඩා ඇත.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// පෙත්තක ඇති මූලද්‍රව්‍ය `distance` ස්ථාන වමට මාරු කරයි.
///
/// # Safety
/// පෙත්තෙහි අවම වශයෙන් `distance` මූලද්රව්ය ඇත.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// පෙත්තක ඇති මූලද්‍රව්‍ය `distance` ස්ථාන දකුණට මාරු කරයි.
///
/// # Safety
/// පෙත්තෙහි අවම වශයෙන් `distance` මූලද්රව්ය ඇත.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// සියලු අගයන් ආරම්භක මූලද්‍රව්‍ය පෙත්තක සිට ආරම්භ නොකළ මූලද්‍රව්‍ය පෙත්තකට ගෙන යන අතර `src` සියල්ල ආරම්භ නොකළ ලෙස ඉතිරි වේ.
///
/// `dst.copy_from_slice(src)` වැනි ක්‍රියා කරන නමුත් `T` `Copy` වීමට අවශ්‍ය නොවේ.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;