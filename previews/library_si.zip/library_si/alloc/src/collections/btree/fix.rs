use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// සහෝදරයෙකු සමඟ ඒකාබද්ධ වීමෙන් හෝ සොරකම් කිරීමෙන් සමහරවිට යටි තට්ටුවක් ගබඩා කරයි.
    /// සාර්ථක නම්, නමුත් මව් නෝඩ් හැකිලීමේ පිරිවැය යටතේ, හැකිලෙන මව් නෝඩය නැවත ලබා දේ.
    /// නෝඩය හිස් මූලයක් නම් `Err` ලබා දෙයි.
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// යටි තලයක ඇති නෝඩයක් ගබඩා කර ඇති අතර, එමඟින් එහි මව් නෝඩ් හැකිලීමට හේතු වේ නම්, මවුපියන් නැවත නැවත ගබඩා කරයි.
    /// ගස සවි කර ඇත්නම් `true`, මූල නෝඩය හිස් වූ නිසා එය කළ නොහැකි නම් `false` ලබා දෙයි.
    ///
    /// හිස් මුතුන් මිත්තෙකු හමු වුවහොත් මුතුන් මිත්තන් දැනටමත් ඇතුල්වීමේදී සහ panics හි අඩුවෙන් සිටිනු ඇතැයි මෙම ක්‍රමය අපේක්ෂා නොකරයි.
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// මුදුනේ හිස් මට්ටම් ඉවත් කරයි, නමුත් මුළු ගසම හිස් නම් හිස් කොළයක් තබා ගනී.
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// ගසෙහි දකුණු මායිමේ ඇති යටි පතුල් තොග ගබඩා කිරීම හෝ ඒකාබද්ධ කිරීම.
    /// අනෙක් නෝඩ්, මූල හෝ දකුණු කෙළවරේ edge නොවන ඒවා දැනටමත් අවම වශයෙන් MIN_LEN මූලද්‍රව්‍යයන් තිබිය යුතුය.
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// `fix_right_border` හි සමමිතික ක්ලෝනය.
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// ගසෙහි දකුණු මායිමේ ඕනෑම යටි තට්ටුවක් ගබඩා කරන්න.
    /// අනෙක් නෝඩ්, මූල හෝ දකුණට edge නොවන ඒවා MIN_LEN මූලද්‍රව්‍ය සොරකම් කිරීමට සූදානම් විය යුතුය.
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // දකුණු-වඩාත්ම දරුවා අඩුවෙන් ඇත්දැයි පරීක්ෂා කරන්න.
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // අපි හොරකම් කරන්න ඕන.
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // තවත් පහළට යන්න.
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// නිවැරදි දරුවා අඩපණ නොවන බව උපකල්පනය කරමින් වම් දරුවා ගබඩා කර තබන අතර, තම දරුවන් අඩපණ නොවී ඒකාබද්ධ කිරීමට ඉඩ දීම සඳහා අමතර අංගයක් සපයයි.
    ///
    /// වම් දරුවා ආපසු ලබා දෙයි.
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` ඒකාබද්ධ කිරීම ඊළඟ මට්ටමින් සිදුවන්නේ නම් නැවත සකස් කිරීම වළක්වා ගැනීමට.
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// වම් දරුවා අඩුවෙන් නොසිටින බව උපකල්පනය කරමින් නිවැරදි දරුවා ගබඩා කර තබන අතර, තම දරුවන් අඩපණ නොවී ඒකාබද්ධ කිරීමට ඉඩ දීම සඳහා අමතර අංගයක් සපයයි.
    ///
    /// නිවැරදි දරුවා අවසන් වූ ඕනෑම තැනකට නැවත පැමිණේ.
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` ඒකාබද්ධ කිරීම ඊළඟ මට්ටමින් සිදුවන්නේ නම් නැවත සකස් කිරීම වළක්වා ගැනීමට.
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}