use core::borrow::Borrow;
use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, RangeBounds};
use core::ptr;

use super::borrow::DormantMutRef;
use super::navigate::LeafRange;
use super::node::{self, marker, ForceResult::*, Handle, NodeRef, Root};
use super::search::SearchResult::*;

mod entry;
pub use entry::{Entry, OccupiedEntry, OccupiedError, VacantEntry};
use Entry::*;

/// මූලයක් නොවන නෝඩ් වල අවම මූලද්‍රව්‍ය ගණන.
/// ක්‍රමවේදයන් තුළ අපට තාවකාලිකව අඩු මූලද්‍රව්‍ය තිබිය හැකිය.
pub(super) const MIN_LEN: usize = node::MIN_LEN_AFTER_SPLIT;

// `BTreeMap` හි ඇති ගසක් යනු `node` මොඩියුලයේ අතිරේක ආක්‍රමණ සහිත ගසක්:
// - යතුරු නැගීමේ අනුපිළිවෙලින් දිස්විය යුතුය (යතුරේ වර්ගය අනුව).
// - මූල නෝඩය අභ්‍යන්තර නම්, එහි අවම වශයෙන් 1 මූලද්‍රව්‍යයක්වත් තිබිය යුතුය.
// - සෑම මූල නොවන නෝඩයකම අවම වශයෙන් MIN_LEN අංග අඩංගු වේ.
//
// හිස් සිතියමක් මූල නෝඩයක් නොමැති වීමෙන් හෝ හිස් පත්‍රයක් වන මූල නෝඩයකින් නිරූපණය කළ හැකිය.
//

/// [B-Tree] මත පදනම් වූ සිතියමක්.
///
/// B-Trees නියෝජනය කරන්නේ හැඹිලි-කාර්යක්ෂමතාව සහ සෙවුමක සිදුකරන වැඩ ප්‍රමාණය අවම කිරීම අතර මූලික සම්මුතියකි.න්‍යායට අනුව, ද්විමය සෙවුම් ගසක් (BST) යනු වර්ග කළ සිතියමක් සඳහා ප්‍රශස්ත තේරීමකි, පරිපූර්ණ සමතුලිත BST මඟින් (log<sub>2</sub>n) මූලද්‍රව්‍යයක් සොයා ගැනීමට අවශ්‍ය න්‍යායාත්මක අවම සංසන්දනයන් සිදු කරයි.
/// කෙසේ වෙතත්, ප්‍රායෝගිකව මෙය සිදු කරන ආකාරය නවීන පරිගණක ගෘහ නිර්මාණ ශිල්පය සඳහා *ඉතා* අකාර්යක්ෂම වේ.
/// විශේෂයෙන්, සෑම මූලද්රව්යයක්ම තනි තනිව ගොඩවල් වෙන් කරන ලද නෝඩයේ ගබඩා කර ඇත.
/// මෙයින් අදහස් කරන්නේ සෑම ඇතුළත් කිරීමක්ම ගොඩවල් වෙන් කිරීමක් අවුලුවන අතර සෑම සංසන්දනයක්ම හැඹිලි-මිස් විය යුතු බවයි.
/// මේ දෙකම ප්‍රායෝගිකව කළ යුතු මිල අධික දේවල් බැවින්, අවම වශයෙන් BST උපායමාර්ගය නැවත සලකා බැලීමට අපට බල කෙරෙයි.
///
/// B-Tree ඒ වෙනුවට සෑම නෝඩයකම B-1 සිට 2B-1 මූලද්‍රව්‍ය පරස්පර අරාවෙහි අඩංගු වේ.මෙය කිරීමෙන්, අපි B සාධකය මගින් ප්‍රතිපාදන ගණන අඩු කර, සෙවුම් වල හැඹිලි කාර්යක්ෂමතාව වැඩි දියුණු කරමු.කෙසේ වෙතත්, මෙයින් අදහස් කරන්නේ සෙවීම් සඳහා සාමාන්‍යයෙන් *තවත්* සැසඳීම් කළ යුතු බවයි.
/// සැසඳීම්වල නිශ්චිත සංඛ්‍යාව භාවිතා කරන නෝඩ් සෙවුම් ක්‍රමෝපාය මත රඳා පවතී.ප්‍රශස්ත හැඹිලි කාර්යක්ෂමතාව සඳහා යමෙකුට නෝඩ් රේඛීයව සෙවිය හැකිය.ප්‍රශස්ත සැසඳීම් සඳහා යමෙකුට ද්විමය සෙවුම භාවිතයෙන් නෝඩය සෙවිය හැකිය.සම්මුතියක් ලෙස, එක් ද රේඛීය සෝදිසි මුලින් චෙක්පත් වලින් පමණක් බව මම සමහර තෝරා සඳහා සෑම i <sup>වන</sup> අංගයක් ඉටු විය.
///
/// වර්තමානයේදී, අපගේ ක්‍රියාත්මක කිරීම සරල රේඛීය සෙවීමක් සිදු කරයි.සංසන්දනය කිරීමට ලාභදායී මූලද්‍රව්‍යයන්ගේ *කුඩා* නෝඩ් වල මෙය විශිෂ්ට කාර්ය සාධනයක් සපයයි.කෙසේ වෙතත්, future හි B තේරීම සහ සමහර විට වෙනත් සාධක මත පදනම්ව ප්‍රශස්ත සෙවුම් ක්‍රමෝපාය තෝරා ගැනීම පිළිබඳව තවදුරටත් ගවේෂණය කිරීමට අපි කැමැත්තෙමු.රේඛීය සෙවුම භාවිතා කරමින්, අහඹු මූලද්‍රව්‍යයක් සෙවීම O(B * log(n)) සැසඳීම් සිදු කිරීමට අපේක්ෂා කරන අතර එය සාමාන්‍යයෙන් BST ට වඩා නරක ය.
///
/// කෙසේ වෙතත්, ප්රායෝගිකව, කාර්ය සාධනය විශිෂ්ටයි.
///
/// [`Ord`] trait විසින් තීරණය කරන පරිදි, යතුර වෙනත් ඕනෑම යතුරකට සාපේක්ෂව වෙනස් වන ආකාරයට යතුර වෙනස් කිරීම තර්කානුකූල දෝෂයකි.මෙය සාමාන්‍යයෙන් කළ හැක්කේ [`Cell`], [`RefCell`], ගෝලීය තත්වය, I/O හෝ අනාරක්ෂිත කේතය හරහා පමණි.
/// එවැනි තාර්කික දෝෂයක ප්‍රති behavior ලයක් ලෙස හැසිරීම නිශ්චිතව දක්වා නැත, නමුත් නිර්වචනය නොකළ හැසිරීමට හේතු නොවේ.මෙයට panics, වැරදි ප්‍රති results ල, ගබ්සා කිරීම්, මතක කාන්දු වීම සහ අවසන් නොකිරීම ඇතුළත් විය හැකිය.
///
/// [B-Tree]: https://en.wikipedia.org/wiki/B-tree
/// [`Cell`]: core::cell::Cell
/// [`RefCell`]: core::cell::RefCell
///
/// # Examples
///
/// ```
/// use std::collections::BTreeMap;
///
/// // ටයිප් අනුමානය අපට පැහැදිලි ආකාරයේ අත්සනක් මඟ හැරීමට ඉඩ දෙයි (මෙම උදාහරණයේ `BTreeMap<&str, &str>` වනු ඇත).
/////
/// let mut movie_reviews = BTreeMap::new();
///
/// // සමහර චිත්‍රපට සමාලෝචනය කරන්න.
/// movie_reviews.insert("Office Space",       "Deals with real issues in the workplace.");
/// movie_reviews.insert("Pulp Fiction",       "Masterpiece.");
/// movie_reviews.insert("The Godfather",      "Very enjoyable.");
/// movie_reviews.insert("The Blues Brothers", "Eye lyked it a lot.");
///
/// // විශේෂිත එකක් සඳහා පරීක්ෂා කරන්න.
/// if !movie_reviews.contains_key("Les Misérables") {
///     println!("We've got {} reviews, but Les Misérables ain't one.",
///              movie_reviews.len());
/// }
///
/// // අපොයි, මෙම සමාලෝචනයට අක්ෂර වින්‍යාස දෝෂ රාශියක් ඇත, එය මකා දමමු.
/// movie_reviews.remove("The Blues Brothers");
///
/// // සමහර යතුරු හා සම්බන්ධ අගයන් සොයා බලන්න.
/// let to_find = ["Up!", "Office Space"];
/// for movie in &to_find {
///     match movie_reviews.get(movie) {
///        Some(review) => println!("{}: {}", movie, review),
///        None => println!("{} is unreviewed.", movie)
///     }
/// }
///
/// // යතුරක් සඳහා වටිනාකම සොයා බලන්න (යතුර සොයාගත නොහැකි නම් panic වනු ඇත).
/// println!("Movie review: {}", movie_reviews["Office Space"]);
///
/// // සෑම දෙයක් ගැනම නැවත කියන්න.
/// for (movie, review) in &movie_reviews {
///     println!("{}: \"{}\"", movie, review);
/// }
/// ```
///
/// `BTreeMap` යතුරු සහ ඒවායේ අගයන් ලබා ගැනීම, සැකසීම, යාවත්කාලීන කිරීම සහ ඉවත් කිරීම වැනි වඩාත් සංකීර්ණ ක්‍රම සඳහා ඉඩ සලසන [`Entry API`] ද ක්‍රියාත්මක කරයි:
///
/// [`Entry API`]: BTreeMap::entry
///
/// ```
/// use std::collections::BTreeMap;
///
/// // ටයිප් අනුමානය අපට පැහැදිලි ආකාරයේ අත්සනක් මඟ හැරීමට ඉඩ දෙයි (මෙම උදාහරණයේ `BTreeMap<&str, u8>` වනු ඇත).
/////
/// let mut player_stats = BTreeMap::new();
///
/// fn random_stat_buff() -> u8 {
///     // ඇත්ත වශයෙන්ම මෙහි කිසියම් අහඹු අගයක් ආපසු ලබා දිය හැකිය, අපි දැන් යම් ස්ථාවර අගයක් ලබා දෙමු
/////
///     42
/// }
///
/// // යතුරක් ඇතුල් කරන්න එය දැනටමත් නොපවතී නම් පමණි
/// player_stats.entry("health").or_insert(100);
///
/// // නව අගයක් සපයන ශ්‍රිතයක් භාවිතා කරමින් යතුරක් ඇතුල් කරන්න, එය දැනටමත් නොපවතී නම් පමණි
/////
/// player_stats.entry("defence").or_insert_with(random_stat_buff);
///
/// // යතුර යාවත්කාලීන කරන්න, යතුර සකසා නොතිබීමට ඉඩ ඇත
/// let stat = player_stats.entry("attack").or_insert(100);
/// *stat += random_stat_buff();
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BTreeMap")]
pub struct BTreeMap<K, V> {
    root: Option<Root<K, V>>,
    length: usize,
}

#[stable(feature = "btree_drop", since = "1.7.0")]
unsafe impl<#[may_dangle] K, #[may_dangle] V> Drop for BTreeMap<K, V> {
    fn drop(&mut self) {
        if let Some(root) = self.root.take() {
            Dropper { front: root.into_dying().first_leaf_edge(), remaining_length: self.length };
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Clone, V: Clone> Clone for BTreeMap<K, V> {
    fn clone(&self) -> BTreeMap<K, V> {
        fn clone_subtree<'a, K: Clone, V: Clone>(
            node: NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal>,
        ) -> BTreeMap<K, V>
        where
            K: 'a,
            V: 'a,
        {
            match node.force() {
                Leaf(leaf) => {
                    let mut out_tree = BTreeMap { root: Some(Root::new()), length: 0 };

                    {
                        let root = out_tree.root.as_mut().unwrap(); // අපි දැන් ඔතා ඇති නිසා unrap සාර්ථක වේ
                        let mut out_node = match root.borrow_mut().force() {
                            Leaf(leaf) => leaf,
                            Internal(_) => unreachable!(),
                        };

                        let mut in_edge = leaf.first_edge();
                        while let Ok(kv) = in_edge.right_kv() {
                            let (k, v) = kv.into_kv();
                            in_edge = kv.right_edge();

                            out_node.push(k.clone(), v.clone());
                            out_tree.length += 1;
                        }
                    }

                    out_tree
                }
                Internal(internal) => {
                    let mut out_tree = clone_subtree(internal.first_edge().descend());

                    {
                        let out_root = BTreeMap::ensure_is_owned(&mut out_tree.root);
                        let mut out_node = out_root.push_internal_level();
                        let mut in_edge = internal.first_edge();
                        while let Ok(kv) = in_edge.right_kv() {
                            let (k, v) = kv.into_kv();
                            in_edge = kv.right_edge();

                            let k = (*k).clone();
                            let v = (*v).clone();
                            let subtree = clone_subtree(in_edge.descend());

                            // BTreeMap Drop ක්‍රියාත්මක කරන නිසා අපට උප කුලකය කෙලින්ම විනාශ කළ නොහැක
                            //
                            let (subroot, sublength) = unsafe {
                                let subtree = ManuallyDrop::new(subtree);
                                let root = ptr::read(&subtree.root);
                                let length = subtree.length;
                                (root, length)
                            };

                            out_node.push(k, v, subroot.unwrap_or_else(Root::new));
                            out_tree.length += 1 + sublength;
                        }
                    }

                    out_tree
                }
            }
        }

        if self.is_empty() {
            // ඉතා මැනවින් අපි මෙහි `BTreeMap::new` අමතන්නෙමු, නමුත් එයට `K:
            // මෙම ක්‍රමවේදය නොමැති ඕර්ඩ් අවහිරතා.
            BTreeMap { root: None, length: 0 }
        } else {
            clone_subtree(self.root.as_ref().unwrap().reborrow()) // හිස් නොවීම නිසා unrap සාර්ථක වේ
        }
    }
}

impl<K, Q: ?Sized> super::Recover<Q> for BTreeMap<K, ()>
where
    K: Borrow<Q> + Ord,
    Q: Ord,
{
    type Key = K;

    fn get(&self, key: &Q) -> Option<&K> {
        let root_node = self.root.as_ref()?.reborrow();
        match root_node.search_tree(key) {
            Found(handle) => Some(handle.into_kv().0),
            GoDown(_) => None,
        }
    }

    fn take(&mut self, key: &Q) -> Option<K> {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        match root_node.search_tree(key) {
            Found(handle) => {
                Some(OccupiedEntry { handle, dormant_map, _marker: PhantomData }.remove_kv().0)
            }
            GoDown(_) => None,
        }
    }

    fn replace(&mut self, key: K) -> Option<K> {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = Self::ensure_is_owned(&mut map.root).borrow_mut();
        match root_node.search_tree::<K>(&key) {
            Found(mut kv) => Some(mem::replace(kv.key_mut(), key)),
            GoDown(handle) => {
                VacantEntry { key, handle, dormant_map, _marker: PhantomData }.insert(());
                None
            }
        }
    }
}

/// `BTreeMap` හි ඇතුළත් කිරීම් වලට වඩා අනුකාරකයක්.
///
/// මෙම `struct` [`BTreeMap`] හි [`iter`] ක්‍රමය මඟින් නිර්මාණය කර ඇත.
/// වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
///
/// [`iter`]: BTreeMap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, K: 'a, V: 'a> {
    range: Range<'a, K, V>,
    length: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for Iter<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// `BTreeMap` හි ඇතුළත් කිරීම් වලට වඩා විකෘති iterator.
///
/// මෙම `struct` [`BTreeMap`] හි [`iter_mut`] ක්‍රමය මඟින් නිර්මාණය කර ඇත.
/// වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
///
/// [`iter_mut`]: BTreeMap::iter_mut
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, K: 'a, V: 'a> {
    range: RangeMut<'a, K, V>,
    length: usize,
}

/// `BTreeMap` හි ඇතුළත් කිරීම් වලට වඩා හිමිකාරී අනුකාරකයක්.
///
/// මෙම `struct` නිර්මාණය කර ඇත්තේ [`BTreeMap`] හි [`into_iter`] ක්‍රමයෙනි (`IntoIterator` trait විසින් සපයනු ලැබේ).
/// වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
///
/// [`into_iter`]: IntoIterator::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<K, V> {
    range: LeafRange<marker::Dying, K, V>,
    length: usize,
}

impl<K, V> IntoIter<K, V> {
    /// ඉතිරි අයිතමයන් පිළිබඳ යොමු දැක්වීම් නැවත ලබා දෙයි.
    #[inline]
    pub(super) fn iter(&self) -> Iter<'_, K, V> {
        let range = Range { inner: self.range.reborrow() };
        Iter { range: range, length: self.length }
    }
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for IntoIter<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

/// `IntoIter` හි සරල කරන ලද අනුවාදය ද්විත්ව අන්තයක් නොමැති අතර එක් අරමුණක් පමණක් ඇත: `IntoIter` හි ඉතිරි කොටස අතහැර දැමීම.
/// එබැවින් මුලින්ම `back` කොළ edge දෙස බැලීමෙන් තොරව සම්පූර්ණ ගසක් බිමට වැටීමටද එය සේවය කරයි.
///
struct Dropper<K, V> {
    front: Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge>,
    remaining_length: usize,
}

/// `BTreeMap` යතුරු මත ඉරේටරයක්.
///
/// මෙම `struct` [`BTreeMap`] හි [`keys`] ක්‍රමය මඟින් නිර්මාණය කර ඇත.
/// වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
///
/// [`keys`]: BTreeMap::keys
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Keys<'a, K: 'a, V: 'a> {
    inner: Iter<'a, K, V>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V> fmt::Debug for Keys<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// `BTreeMap` හි අගයන් ඉක්මවා ක්‍රියා කරන්නෙක්.
///
/// මෙම `struct` [`BTreeMap`] හි [`values`] ක්‍රමය මඟින් නිර්මාණය කර ඇත.
/// වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
///
/// [`values`]: BTreeMap::values
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Values<'a, K: 'a, V: 'a> {
    inner: Iter<'a, K, V>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K, V: fmt::Debug> fmt::Debug for Values<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// `BTreeMap` හි අගයන්ට වඩා විකෘති iterator.
///
/// මෙම `struct` [`BTreeMap`] හි [`values_mut`] ක්‍රමය මඟින් නිර්මාණය කර ඇත.
/// වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
///
/// [`values_mut`]: BTreeMap::values_mut
#[stable(feature = "map_values_mut", since = "1.10.0")]
pub struct ValuesMut<'a, K: 'a, V: 'a> {
    inner: IterMut<'a, K, V>,
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<K, V: fmt::Debug> fmt::Debug for ValuesMut<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.inner.iter().map(|(_, val)| val)).finish()
    }
}

/// `BTreeMap` යතුරු වලට ඉහළින් හිමිකාරීකාරකයක් ඇත.
///
/// මෙම `struct` [`BTreeMap`] හි [`into_keys`] ක්‍රමය මඟින් නිර්මාණය කර ඇත.
/// වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
///
/// [`into_keys`]: BTreeMap::into_keys
#[unstable(feature = "map_into_keys_values", issue = "75294")]
pub struct IntoKeys<K, V> {
    inner: IntoIter<K, V>,
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K: fmt::Debug, V> fmt::Debug for IntoKeys<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.inner.iter().map(|(key, _)| key)).finish()
    }
}

/// `BTreeMap` හි අගයන්ට වඩා හිමිකාරී අනුකාරකයක්.
///
/// මෙම `struct` [`BTreeMap`] හි [`into_values`] ක්‍රමය මඟින් නිර්මාණය කර ඇත.
/// වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
///
/// [`into_values`]: BTreeMap::into_values
#[unstable(feature = "map_into_keys_values", issue = "75294")]
pub struct IntoValues<K, V> {
    inner: IntoIter<K, V>,
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V: fmt::Debug> fmt::Debug for IntoValues<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.inner.iter().map(|(_, val)| val)).finish()
    }
}

/// `BTreeMap` හි උප පරාස පරාසයක ඇතුළත් කිරීම්.
///
/// මෙම `struct` [`BTreeMap`] හි [`range`] ක්‍රමය මඟින් නිර්මාණය කර ඇත.
/// වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
///
/// [`range`]: BTreeMap::range
#[stable(feature = "btree_range", since = "1.17.0")]
pub struct Range<'a, K: 'a, V: 'a> {
    inner: LeafRange<marker::Immut<'a>, K, V>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for Range<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// `BTreeMap` හි ඇතුළත් කිරීම් පරාසයක් හරහා විකෘති කළ හැකි අනුකාරකයක්.
///
/// මෙම `struct` [`BTreeMap`] හි [`range_mut`] ක්‍රමය මඟින් නිර්මාණය කර ඇත.
/// වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
///
/// [`range_mut`]: BTreeMap::range_mut
#[stable(feature = "btree_range", since = "1.17.0")]
pub struct RangeMut<'a, K: 'a, V: 'a> {
    inner: LeafRange<marker::ValMut<'a>, K, V>,

    // `K` සහ `V` වල වෙනස් නොවන්න
    _marker: PhantomData<&'a mut (K, V)>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for RangeMut<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let range = Range { inner: self.inner.reborrow() };
        f.debug_list().entries(range).finish()
    }
}

impl<K, V> BTreeMap<K, V> {
    /// නව හිස් `BTreeMap` සාදයි.
    ///
    /// කිසිවක් තනිවම වෙන් නොකරයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    ///
    /// // ඇතුළත් කිරීම් දැන් හිස් සිතියමට ඇතුළත් කළ හැකිය
    /// map.insert(1, "a");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_btree_new", issue = "71835")]
    pub const fn new() -> BTreeMap<K, V>
    where
        K: Ord,
    {
        BTreeMap { root: None, length: 0 }
    }

    /// සිතියම හිස් කරයි, සියලු අංග ඉවත් කරයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "a");
    /// a.clear();
    /// assert!(a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = BTreeMap { root: None, length: 0 };
    }

    /// යතුරට අනුරූප වන අගයට යොමු කිරීමක් ලබා දෙයි.
    ///
    /// යතුර සිතියමේ යතුරු වර්ගයේ ඕනෑම ණයට ගත් ආකාරයක් විය හැකිය, නමුත් ණයට ගත් පෝරමයේ ඇණවුම * යතුරු වර්ගයෙහි ඇණවුමට අනුරූප විය යුතුය.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.get(&1), Some(&"a"));
    /// assert_eq!(map.get(&2), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get<Q: ?Sized>(&self, key: &Q) -> Option<&V>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        match root_node.search_tree(key) {
            Found(handle) => Some(handle.into_kv().1),
            GoDown(_) => None,
        }
    }

    /// සැපයූ යතුරට අනුරූප යතුරු අග යුගලය ලබා දෙයි.
    ///
    /// සපයන ලද යතුර සිතියමේ යතුරු වර්ගයේ ඕනෑම ණයට ගත් ආකාරයක් විය හැකිය, නමුත් ණයට ගත් පෝරමයේ ඇණවුම * යතුරු වර්ගයෙහි ඇණවුමට අනුරූප විය යුතුය.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.get_key_value(&1), Some((&1, &"a")));
    /// assert_eq!(map.get_key_value(&2), None);
    /// ```
    #[stable(feature = "map_get_key_value", since = "1.40.0")]
    pub fn get_key_value<Q: ?Sized>(&self, k: &Q) -> Option<(&K, &V)>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        match root_node.search_tree(k) {
            Found(handle) => Some(handle.into_kv()),
            GoDown(_) => None,
        }
    }

    /// සිතියමේ පළමු යතුරු අගය යුගලය ලබා දෙයි.
    /// මෙම යුගලයේ යතුර සිතියමේ අවම යතුරයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// assert_eq!(map.first_key_value(), None);
    /// map.insert(1, "b");
    /// map.insert(2, "a");
    /// assert_eq!(map.first_key_value(), Some((&1, &"b")));
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn first_key_value(&self) -> Option<(&K, &V)>
    where
        K: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        root_node.first_leaf_edge().right_kv().ok().map(Handle::into_kv)
    }

    /// ස්ථානීය හැසිරවීම සඳහා සිතියමේ පළමු ප්‍රවේශය ලබා දෙයි.
    /// මෙම සටහනේ යතුර සිතියමේ අවම යතුරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// if let Some(mut entry) = map.first_entry() {
    ///     if *entry.key() > 0 {
    ///         entry.insert("first");
    ///     }
    /// }
    /// assert_eq!(*map.get(&1).unwrap(), "first");
    /// assert_eq!(*map.get(&2).unwrap(), "b");
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn first_entry(&mut self) -> Option<OccupiedEntry<'_, K, V>>
    where
        K: Ord,
    {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        let kv = root_node.first_leaf_edge().right_kv().ok()?;
        Some(OccupiedEntry { handle: kv.forget_node_type(), dormant_map, _marker: PhantomData })
    }

    /// සිතියමේ පළමු අංගය ඉවත් කර ආපසු ලබා දේ.
    /// මෙම මූලද්රව්යයේ යතුර සිතියමේ තිබූ අවම යතුරයි.
    ///
    /// # Examples
    ///
    /// එක් එක් පුනරාවර්තනය සඳහා භාවිතා කළ හැකි සිතියමක් තබා ගනිමින්, නඟින අනුපිළිවෙලින් මූලද්‍රව්‍ය බැහැර කිරීම.
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// while let Some((key, _val)) = map.pop_first() {
    ///     assert!(map.iter().all(|(k, _v)| *k > key));
    /// }
    /// assert!(map.is_empty());
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn pop_first(&mut self) -> Option<(K, V)>
    where
        K: Ord,
    {
        self.first_entry().map(|entry| entry.remove_entry())
    }

    /// සිතියමේ අවසාන යතුරු අගය යුගලය ලබා දෙයි.
    /// මෙම යුගලයේ යතුර සිතියමේ උපරිම යතුරයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "b");
    /// map.insert(2, "a");
    /// assert_eq!(map.last_key_value(), Some((&2, &"a")));
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn last_key_value(&self) -> Option<(&K, &V)>
    where
        K: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        root_node.last_leaf_edge().left_kv().ok().map(Handle::into_kv)
    }

    /// ස්ථානීය හැසිරවීම සඳහා සිතියමේ අවසාන ප්‍රවේශය ලබා දෙයි.
    /// මෙම ප්‍රවේශයේ යතුර සිතියමේ ඇති උපරිම යතුරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// if let Some(mut entry) = map.last_entry() {
    ///     if *entry.key() > 0 {
    ///         entry.insert("last");
    ///     }
    /// }
    /// assert_eq!(*map.get(&1).unwrap(), "a");
    /// assert_eq!(*map.get(&2).unwrap(), "last");
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn last_entry(&mut self) -> Option<OccupiedEntry<'_, K, V>>
    where
        K: Ord,
    {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        let kv = root_node.last_leaf_edge().left_kv().ok()?;
        Some(OccupiedEntry { handle: kv.forget_node_type(), dormant_map, _marker: PhantomData })
    }

    /// සිතියමේ අවසාන අංගය ඉවත් කර ආපසු ලබා දේ.
    /// මෙම මූලද්රව්යයේ යතුර සිතියමේ තිබූ උපරිම යතුරයි.
    ///
    /// # Examples
    ///
    /// එක් එක් පුනරාවර්තනය භාවිතා කළ හැකි සිතියමක් තබා ගනිමින්, බැසීමේ අනුපිළිවෙලින් මූලද්‍රව්‍ය බැහැර කිරීම.
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// while let Some((key, _val)) = map.pop_last() {
    ///     assert!(map.iter().all(|(k, _v)| *k < key));
    /// }
    /// assert!(map.is_empty());
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn pop_last(&mut self) -> Option<(K, V)>
    where
        K: Ord,
    {
        self.last_entry().map(|entry| entry.remove_entry())
    }

    /// නිශ්චිත යතුර සඳහා සිතියමේ අගයක් තිබේ නම් `true` ලබා දෙයි.
    ///
    /// යතුර සිතියමේ යතුරු වර්ගයේ ඕනෑම ණයට ගත් ආකාරයක් විය හැකිය, නමුත් ණයට ගත් පෝරමයේ ඇණවුම * යතුරු වර්ගයෙහි ඇණවුමට අනුරූප විය යුතුය.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.contains_key(&1), true);
    /// assert_eq!(map.contains_key(&2), false);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn contains_key<Q: ?Sized>(&self, key: &Q) -> bool
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        self.get(key).is_some()
    }

    /// යතුරට අනුරූප වන අගයට විකෘති යොමු කිරීමක් ලබා දෙයි.
    ///
    /// යතුර සිතියමේ යතුරු වර්ගයේ ඕනෑම ණයට ගත් ආකාරයක් විය හැකිය, නමුත් ණයට ගත් පෝරමයේ ඇණවුම * යතුරු වර්ගයෙහි ඇණවුමට අනුරූප විය යුතුය.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// if let Some(x) = map.get_mut(&1) {
    ///     *x = "b";
    /// }
    /// assert_eq!(map[&1], "b");
    /// ```
    // ක්‍රියාත්මක කිරීමේ සටහන් සඳහා `get` බලන්න, මෙය මූලික වශයෙන් මුට් එකතු කළ පිටපත්-පේස්ට් එකකි
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut<Q: ?Sized>(&mut self, key: &Q) -> Option<&mut V>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let root_node = self.root.as_mut()?.borrow_mut();
        match root_node.search_tree(key) {
            Found(handle) => Some(handle.into_val_mut()),
            GoDown(_) => None,
        }
    }

    /// යතුරු වටිනාකම් යුගලයක් සිතියමට ඇතුල් කරයි.
    ///
    /// සිතියමේ මෙම යතුර නොතිබුණි නම්, `None` ආපසු ලබා දෙනු ලැබේ.
    ///
    /// සිතියමේ මෙම යතුර තිබේ නම්, අගය යාවත්කාලීන වන අතර පැරණි අගය නැවත ලබා දෙනු ලැබේ.
    /// යතුර යාවත්කාලීන නොවේ;මෙය සමාන නොවී `==` විය හැකි වර්ග සඳහා වැදගත් වේ.
    ///
    /// වැඩි විස්තර සඳහා [module-level documentation] බලන්න.
    ///
    /// [module-level documentation]: index.html#insert-and-complex-keys
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// assert_eq!(map.insert(37, "a"), None);
    /// assert_eq!(map.is_empty(), false);
    ///
    /// map.insert(37, "b");
    /// assert_eq!(map.insert(37, "c"), Some("b"));
    /// assert_eq!(map[&37], "c");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, key: K, value: V) -> Option<V>
    where
        K: Ord,
    {
        match self.entry(key) {
            Occupied(mut entry) => Some(entry.insert(value)),
            Vacant(entry) => {
                entry.insert(value);
                None
            }
        }
    }

    /// යතුරු-වටිනා යුගලයක් සිතියමට ඇතුළු කිරීමට උත්සාහ කරන අතර, ඇතුල්වීමේ අගය වෙත විකෘති යොමු කිරීමක් ලබා දෙයි.
    ///
    /// සිතියමෙහි දැනටමත් මෙම යතුර තිබේ නම්, කිසිවක් යාවත්කාලීන නොකෙරෙන අතර වාඩිලාගෙන සිටින ප්‍රවේශය සහ වටිනාකම අඩංගු දෝෂයක් ආපසු ලබා දෙනු ලැබේ.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// #![feature(map_try_insert)]
    ///
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// assert_eq!(map.try_insert(37, "a").unwrap(), &"a");
    ///
    /// let err = map.try_insert(37, "b").unwrap_err();
    /// assert_eq!(err.entry.key(), &37);
    /// assert_eq!(err.entry.get(), &"a");
    /// assert_eq!(err.value, "b");
    /// ```
    ///
    #[unstable(feature = "map_try_insert", issue = "82766")]
    pub fn try_insert(&mut self, key: K, value: V) -> Result<&mut V, OccupiedError<'_, K, V>>
    where
        K: Ord,
    {
        match self.entry(key) {
            Occupied(entry) => Err(OccupiedError { entry, value }),
            Vacant(entry) => Ok(entry.insert(value)),
        }
    }

    /// සිතියමෙන් යතුරක් ඉවත් කරයි, යතුර කලින් සිතියමේ තිබුනේ නම් යතුරේ අගය නැවත ලබා දේ.
    ///
    /// යතුර සිතියමේ යතුරු වර්ගයේ ඕනෑම ණයට ගත් ආකාරයක් විය හැකිය, නමුත් ණයට ගත් පෝරමයේ ඇණවුම * යතුරු වර්ගයෙහි ඇණවුමට අනුරූප විය යුතුය.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.remove(&1), Some("a"));
    /// assert_eq!(map.remove(&1), None);
    /// ```
    ///
    #[doc(alias = "delete")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove<Q: ?Sized>(&mut self, key: &Q) -> Option<V>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        self.remove_entry(key).map(|(_, v)| v)
    }

    /// සිතියමෙන් යතුරක් ඉවත් කර, යතුර කලින් සිතියමේ තිබුනේ නම් ගබඩා කළ යතුර සහ වටිනාකම ආපසු ලබා දේ.
    ///
    /// යතුර සිතියමේ යතුරු වර්ගයේ ඕනෑම ණයට ගත් ආකාරයක් විය හැකිය, නමුත් ණයට ගත් පෝරමයේ ඇණවුම * යතුරු වර්ගයෙහි ඇණවුමට අනුරූප විය යුතුය.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.remove_entry(&1), Some((1, "a")));
    /// assert_eq!(map.remove_entry(&1), None);
    /// ```
    ///
    #[stable(feature = "btreemap_remove_entry", since = "1.45.0")]
    pub fn remove_entry<Q: ?Sized>(&mut self, key: &Q) -> Option<(K, V)>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        match root_node.search_tree(key) {
            Found(handle) => {
                Some(OccupiedEntry { handle, dormant_map, _marker: PhantomData }.remove_entry())
            }
            GoDown(_) => None,
        }
    }

    /// පුරෝකථනය මඟින් නිශ්චිතව දක්වා ඇති මූලද්‍රව්‍ය පමණක් රඳවා ගනී.
    ///
    /// වෙනත් වචන වලින් කිවහොත්, `f(&k, &mut v)` `false` ආපසු ලබා දෙන `(k, v)` යුගල ඉවත් කරන්න.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(btree_retain)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<i32, i32> = (0..8).map(|x| (x, x*10)).collect();
    /// // ඉරට්ටේ අංක සහිත මූලද්රව්ය පමණක් තබා ගන්න.
    /// map.retain(|&k, _| k % 2 == 0);
    /// assert!(map.into_iter().eq(vec![(0, 0), (2, 20), (4, 40), (6, 60)]));
    /// ```
    #[inline]
    #[unstable(feature = "btree_retain", issue = "79025")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        K: Ord,
        F: FnMut(&K, &mut V) -> bool,
    {
        self.drain_filter(|k, v| !f(k, v));
    }

    /// `other` සිට `Self` දක්වා සියලුම මූලද්‍රව්‍යයන් ගෙන යන අතර `other` හිස්ව පවතී.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "a");
    /// a.insert(2, "b");
    /// a.insert(3, "c");
    ///
    /// let mut b = BTreeMap::new();
    /// b.insert(3, "d");
    /// b.insert(4, "e");
    /// b.insert(5, "f");
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.len(), 5);
    /// assert_eq!(b.len(), 0);
    ///
    /// assert_eq!(a[&1], "a");
    /// assert_eq!(a[&2], "b");
    /// assert_eq!(a[&3], "d");
    /// assert_eq!(a[&4], "e");
    /// assert_eq!(a[&5], "f");
    /// ```
    #[stable(feature = "btree_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self)
    where
        K: Ord,
    {
        // අපට කිසියම් දෙයක් එකතු කළ යුතුද?
        if other.is_empty() {
            return;
        }

        // `self` හිස් නම් අපට `self` සහ `other` මාරු කළ හැකිය.
        if self.is_empty() {
            mem::swap(self, other);
            return;
        }

        let self_iter = mem::take(self).into_iter();
        let other_iter = mem::take(other).into_iter();
        let root = BTreeMap::ensure_is_owned(&mut self.root);
        root.append_from_sorted_iters(self_iter, other_iter, &mut self.length)
    }

    /// සිතියමේ ඇති උප-පරාසයක මූලද්රව්ය හරහා ද්වි-අන්ත ඉරේටරයක් සාදයි.
    /// සරලම ක්‍රමය නම් `min..max` පරාසය භාවිතා කිරීමයි, මේ අනුව `range(min..max)` මඟින් මිනිත්තු (inclusive) සිට උපරිම (exclusive) දක්වා මූලද්‍රව්‍ය ලබා දෙනු ඇත.
    /// පරාසය `(Bound<T>, Bound<T>)` ලෙසද ඇතුළත් කළ හැකිය, උදාහරණයක් ලෙස `range((Excluded(4), Included(10)))` මඟින් වමේ සිට දකුණට ඇතුළත් වන පරාසයක් 4 සිට 10 දක්වා ලබා දෙනු ඇත.
    ///
    ///
    /// # Panics
    ///
    /// `start > end` පරාසය නම් Panics.
    /// `start == end` පරාසය සහ සීමාවන් දෙකම `Excluded` නම් Panics.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    /// use std::ops::Bound::Included;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(3, "a");
    /// map.insert(5, "b");
    /// map.insert(8, "c");
    /// for (&key, &value) in map.range((Included(&4), Included(&8))) {
    ///     println!("{}: {}", key, value);
    /// }
    /// assert_eq!(Some((&5, &"b")), map.range(4..).next());
    /// ```
    ///
    ///
    #[stable(feature = "btree_range", since = "1.17.0")]
    pub fn range<T: ?Sized, R>(&self, range: R) -> Range<'_, K, V>
    where
        T: Ord,
        K: Borrow<T> + Ord,
        R: RangeBounds<T>,
    {
        if let Some(root) = &self.root {
            Range { inner: root.reborrow().range_search(range) }
        } else {
            Range { inner: LeafRange::none() }
        }
    }

    /// සිතියමේ ඇති උප-පරාසයේ මූලද්‍රව්‍යයන් හරහා විකෘති ද්වි-අන්ත අනුකාරකයක් සාදයි.
    /// සරලම ක්‍රමය නම් `min..max` පරාසය භාවිතා කිරීමයි, මේ අනුව `range(min..max)` මඟින් මිනිත්තු (inclusive) සිට උපරිම (exclusive) දක්වා මූලද්‍රව්‍ය ලබා දෙනු ඇත.
    /// පරාසය `(Bound<T>, Bound<T>)` ලෙසද ඇතුළත් කළ හැකිය, උදාහරණයක් ලෙස `range((Excluded(4), Included(10)))` මඟින් වමේ සිට දකුණට ඇතුළත් වන පරාසයක් 4 සිට 10 දක්වා ලබා දෙනු ඇත.
    ///
    ///
    /// # Panics
    ///
    /// `start > end` පරාසය නම් Panics.
    /// `start == end` පරාසය සහ සීමාවන් දෙකම `Excluded` නම් Panics.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<&str, i32> = ["Alice", "Bob", "Carol", "Cheryl"]
    ///     .iter()
    ///     .map(|&s| (s, 0))
    ///     .collect();
    /// for (_, balance) in map.range_mut("B".."Cheryl") {
    ///     *balance += 100;
    /// }
    /// for (name, balance) in &map {
    ///     println!("{} => {}", name, balance);
    /// }
    /// ```
    ///
    ///
    #[stable(feature = "btree_range", since = "1.17.0")]
    pub fn range_mut<T: ?Sized, R>(&mut self, range: R) -> RangeMut<'_, K, V>
    where
        T: Ord,
        K: Borrow<T> + Ord,
        R: RangeBounds<T>,
    {
        if let Some(root) = &mut self.root {
            RangeMut { inner: root.borrow_valmut().range_search(range), _marker: PhantomData }
        } else {
            RangeMut { inner: LeafRange::none(), _marker: PhantomData }
        }
    }

    /// ස්ථානීය හැසිරවීම සඳහා සිතියමේ දී ඇති යතුරේ අනුරූප ප්‍රවේශය ලබා ගනී.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut count: BTreeMap<&str, usize> = BTreeMap::new();
    ///
    /// // දෛශිකයේ ඇති අකුරු ගණන ගණනය කරන්න
    /// for x in vec!["a", "b", "a", "c", "a", "b"] {
    ///     *count.entry(x).or_insert(0) += 1;
    /// }
    ///
    /// assert_eq!(count["a"], 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn entry(&mut self, key: K) -> Entry<'_, K, V>
    where
        K: Ord,
    {
        // FIXME(@porglezomp) අප ඇතුළු නොකරන්නේ නම් වෙන් කිරීමෙන් වළකින්න
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = Self::ensure_is_owned(&mut map.root).borrow_mut();
        match root_node.search_tree(&key) {
            Found(handle) => Occupied(OccupiedEntry { handle, dormant_map, _marker: PhantomData }),
            GoDown(handle) => {
                Vacant(VacantEntry { key, handle, dormant_map, _marker: PhantomData })
            }
        }
    }

    /// දී ඇති යතුරේ එකතුව දෙකට බෙදයි.
    /// යතුර ඇතුළුව දී ඇති යතුරෙන් පසුව සියල්ල ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "a");
    /// a.insert(2, "b");
    /// a.insert(3, "c");
    /// a.insert(17, "d");
    /// a.insert(41, "e");
    ///
    /// let b = a.split_off(&3);
    ///
    /// assert_eq!(a.len(), 2);
    /// assert_eq!(b.len(), 3);
    ///
    /// assert_eq!(a[&1], "a");
    /// assert_eq!(a[&2], "b");
    ///
    /// assert_eq!(b[&3], "c");
    /// assert_eq!(b[&17], "d");
    /// assert_eq!(b[&41], "e");
    /// ```
    #[stable(feature = "btree_split_off", since = "1.11.0")]
    pub fn split_off<Q: ?Sized + Ord>(&mut self, key: &Q) -> Self
    where
        K: Borrow<Q> + Ord,
    {
        if self.is_empty() {
            return Self::new();
        }

        let total_num = self.len();
        let left_root = self.root.as_mut().unwrap(); // හිස් නොවීම නිසා unrap සාර්ථක වේ

        let right_root = left_root.split_off(key);

        let (new_left_len, right_len) = Root::calc_split_length(total_num, &left_root, &right_root);
        self.length = new_left_len;

        BTreeMap { root: Some(right_root), length: right_len }
    }

    /// යතුරු මූල අනුපිළිවෙලින් සියලුම මූලද්‍රව්‍ය (යතුරු-අගය යුගල) වෙත පිවිසෙන සහ මූලද්‍රව්‍යයක් ඉවත් කළ යුතුද යන්න තීරණය කිරීම සඳහා වසා දැමීමක් භාවිතා කරන අනුකාරකයක් සාදයි.
    /// වසා දැමීම `true` ආපසු ලබා දෙන්නේ නම්, මූලද්‍රව්‍යය සිතියමෙන් ඉවත් කර ලබා දෙනු ලැබේ.
    /// වසා දැමීම `false`, හෝ panics නැවත ලබා දෙන්නේ නම්, මූලද්‍රව්‍යය සිතියමෙහි පවතින අතර එය නොලැබේ.
    ///
    /// ඔබ එය තබා ගැනීමට හෝ ඉවත් කිරීමට තෝරා ගත්තද නොසලකා, වසා දැමීමේදී එක් එක් මූලද්‍රව්‍යයේ වටිනාකම විකෘති කිරීමට ද iterator ඔබට ඉඩ දෙයි.
    ///
    /// අනුකාරකය අර්ධ වශයෙන් පමණක් පරිභෝජනය කරන්නේ නම් හෝ කිසිසේත් පරිභෝජනය නොකෙරේ නම්, ඉතිරි සෑම මූලද්‍රව්‍යයක්ම තවමත් වසා දැමීමට යටත් වන අතර, එහි වටිනාකම වෙනස් විය හැකි අතර, `true` ආපසු ලබා දීමෙන් මූලද්‍රව්‍යය ඉවත් කර අතහැර දමනු ලැබේ.
    ///
    ///
    /// වසා දැමීමේදී panic සිදුවුවහොත් හෝ මූලද්‍රව්‍යයක් අතහැරීමේදී panic සිදුවුවහොත් හෝ `DrainFilter` අගය කාන්දු වුවහොත් තවත් මූලද්‍රව්‍ය කීයක් වසා දැමිය යුතුද යන්න නිශ්චිතව දක්වා නැත.
    ///
    /// # Examples
    ///
    /// සිතියම ඉරට්ටේ හා අමුතු යතුරු වලට බෙදීම, මුල් සිතියම නැවත භාවිතා කිරීම:
    ///
    /// ```
    /// #![feature(btree_drain_filter)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<i32, i32> = (0..8).map(|x| (x, x)).collect();
    /// let evens: BTreeMap<_, _> = map.drain_filter(|k, _v| k % 2 == 0).collect();
    /// let odds = map;
    /// assert_eq!(evens.keys().copied().collect::<Vec<_>>(), vec![0, 2, 4, 6]);
    /// assert_eq!(odds.keys().copied().collect::<Vec<_>>(), vec![1, 3, 5, 7]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "btree_drain_filter", issue = "70530")]
    pub fn drain_filter<F>(&mut self, pred: F) -> DrainFilter<'_, K, V, F>
    where
        K: Ord,
        F: FnMut(&K, &mut V) -> bool,
    {
        DrainFilter { pred, inner: self.drain_filter_inner() }
    }

    pub(super) fn drain_filter_inner(&mut self) -> DrainFilterInner<'_, K, V>
    where
        K: Ord,
    {
        if let Some(root) = self.root.as_mut() {
            let (root, dormant_root) = DormantMutRef::new(root);
            let front = root.borrow_mut().first_leaf_edge();
            DrainFilterInner {
                length: &mut self.length,
                dormant_root: Some(dormant_root),
                cur_leaf_edge: Some(front),
            }
        } else {
            DrainFilterInner { length: &mut self.length, dormant_root: None, cur_leaf_edge: None }
        }
    }

    /// සියලු යතුරු වර්ග කර අනුපිළිවෙලට පරිභෝජනය කරන අනුකාරකයක් සාදයි.
    /// මෙය ඇමතීමෙන් පසු සිතියම භාවිතා කළ නොහැක.
    /// Iterator මූලද්‍රව්‍ය වර්ගය `K` වේ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_into_keys_values)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(2, "b");
    /// a.insert(1, "a");
    ///
    /// let keys: Vec<i32> = a.into_keys().collect();
    /// assert_eq!(keys, [1, 2]);
    /// ```
    #[inline]
    #[unstable(feature = "map_into_keys_values", issue = "75294")]
    pub fn into_keys(self) -> IntoKeys<K, V> {
        IntoKeys { inner: self.into_iter() }
    }

    /// යතුර අනුව අනුපිළිවෙලින් සියලු අගයන් වෙත පරිභෝජනය කරන අනුකාරකයක් සාදයි.
    /// මෙය ඇමතීමෙන් පසු සිතියම භාවිතා කළ නොහැක.
    /// Iterator මූලද්‍රව්‍ය වර්ගය `V` වේ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_into_keys_values)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "hello");
    /// a.insert(2, "goodbye");
    ///
    /// let values: Vec<&str> = a.into_values().collect();
    /// assert_eq!(values, ["hello", "goodbye"]);
    /// ```
    #[inline]
    #[unstable(feature = "map_into_keys_values", issue = "75294")]
    pub fn into_values(self) -> IntoValues<K, V> {
        IntoValues { inner: self.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> IntoIterator for &'a BTreeMap<K, V> {
    type Item = (&'a K, &'a V);
    type IntoIter = Iter<'a, K, V>;

    fn into_iter(self) -> Iter<'a, K, V> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> Iterator for Iter<'a, K, V> {
    type Item = (&'a K, &'a V);

    fn next(&mut self) -> Option<(&'a K, &'a V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_unchecked() })
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.length, Some(self.length))
    }

    fn last(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Iter<'_, K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> DoubleEndedIterator for Iter<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_back_unchecked() })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for Iter<'_, K, V> {
    fn len(&self) -> usize {
        self.length
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Clone for Iter<'_, K, V> {
    fn clone(&self) -> Self {
        Iter { range: self.range.clone(), length: self.length }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> IntoIterator for &'a mut BTreeMap<K, V> {
    type Item = (&'a K, &'a mut V);
    type IntoIter = IterMut<'a, K, V>;

    fn into_iter(self) -> IterMut<'a, K, V> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> Iterator for IterMut<'a, K, V> {
    type Item = (&'a K, &'a mut V);

    fn next(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_unchecked() })
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.length, Some(self.length))
    }

    fn last(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> DoubleEndedIterator for IterMut<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_back_unchecked() })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for IterMut<'_, K, V> {
    fn len(&self) -> usize {
        self.length
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for IterMut<'_, K, V> {}

impl<'a, K, V> IterMut<'a, K, V> {
    /// ඉතිරි අයිතමයන් පිළිබඳ යොමු දැක්වීම් නැවත ලබා දෙයි.
    #[inline]
    pub(super) fn iter(&self) -> Iter<'_, K, V> {
        Iter { range: self.range.iter(), length: self.length }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> IntoIterator for BTreeMap<K, V> {
    type Item = (K, V);
    type IntoIter = IntoIter<K, V>;

    fn into_iter(self) -> IntoIter<K, V> {
        let mut me = ManuallyDrop::new(self);
        if let Some(root) = me.root.take() {
            let full_range = root.into_dying().full_range();

            IntoIter { range: full_range, length: me.length }
        } else {
            IntoIter { range: LeafRange::none(), length: 0 }
        }
    }
}

impl<K, V> Drop for Dropper<K, V> {
    fn drop(&mut self) {
        // විලයන නොවන අනුකාරකයක් ඉදිරියට ගෙනයාමට සමානය.
        fn next_or_end<K, V>(this: &mut Dropper<K, V>) -> Option<(K, V)> {
            if this.remaining_length == 0 {
                unsafe { ptr::read(&this.front).deallocating_end() }
                None
            } else {
                this.remaining_length -= 1;
                Some(unsafe { this.front.deallocating_next_unchecked() })
            }
        }

        struct DropGuard<'a, K, V>(&'a mut Dropper<K, V>);

        impl<'a, K, V> Drop for DropGuard<'a, K, V> {
            fn drop(&mut self) {
                // අපි පහත සිදු කරන එකම ලූපය දිගටම කරගෙන යන්න.
                // මෙය ක්‍රියාත්මක වන්නේ නොදැනුවත්වම පමණි, එබැවින් අපට මෙවර panics ගැන සැලකිලිමත් විය යුතු නැත (ඒවා ගබ්සා වනු ඇත).
                while let Some(_pair) = next_or_end(&mut self.0) {}
            }
        }

        while let Some(pair) = next_or_end(self) {
            let guard = DropGuard(self);
            drop(pair);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "btree_drop", since = "1.7.0")]
impl<K, V> Drop for IntoIter<K, V> {
    fn drop(&mut self) {
        if let Some(front) = self.range.front.take() {
            Dropper { front, remaining_length: self.length };
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Iterator for IntoIter<K, V> {
    type Item = (K, V);

    fn next(&mut self) -> Option<(K, V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.front.as_mut().unwrap().deallocating_next_unchecked() })
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.length, Some(self.length))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> DoubleEndedIterator for IntoIter<K, V> {
    fn next_back(&mut self) -> Option<(K, V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.back.as_mut().unwrap().deallocating_next_back_unchecked() })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for IntoIter<K, V> {
    fn len(&self) -> usize {
        self.length
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for IntoIter<K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> Iterator for Keys<'a, K, V> {
    type Item = &'a K;

    fn next(&mut self) -> Option<&'a K> {
        self.inner.next().map(|(k, _)| k)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<&'a K> {
        self.next_back()
    }

    fn min(mut self) -> Option<&'a K> {
        self.next()
    }

    fn max(mut self) -> Option<&'a K> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> DoubleEndedIterator for Keys<'a, K, V> {
    fn next_back(&mut self) -> Option<&'a K> {
        self.inner.next_back().map(|(k, _)| k)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for Keys<'_, K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Keys<'_, K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Clone for Keys<'_, K, V> {
    fn clone(&self) -> Self {
        Keys { inner: self.inner.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> Iterator for Values<'a, K, V> {
    type Item = &'a V;

    fn next(&mut self) -> Option<&'a V> {
        self.inner.next().map(|(_, v)| v)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<&'a V> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> DoubleEndedIterator for Values<'a, K, V> {
    fn next_back(&mut self) -> Option<&'a V> {
        self.inner.next_back().map(|(_, v)| v)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for Values<'_, K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Values<'_, K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Clone for Values<'_, K, V> {
    fn clone(&self) -> Self {
        Values { inner: self.inner.clone() }
    }
}

/// BTreeMap හි `drain_filter` ඇමතීමෙන් නිපදවන අනුකාරකයක්.
#[unstable(feature = "btree_drain_filter", issue = "70530")]
pub struct DrainFilter<'a, K, V, F>
where
    K: 'a,
    V: 'a,
    F: 'a + FnMut(&K, &mut V) -> bool,
{
    pred: F,
    inner: DrainFilterInner<'a, K, V>,
}
/// ඩ්‍රේන් ෆිල්ටර් ක්‍රියාත්මක කිරීමේදී බොහෝමයක් පුරෝකථනය කරන ලද වර්ගයට වඩා සාමාන්‍යය වන අතර එමඟින් BTreeSet::DrainFilter සඳහාද සේවය කරයි.
///
pub(super) struct DrainFilterInner<'a, K: 'a, V: 'a> {
    /// ණයට ගත් සිතියමේ දිග ක්ෂේත්‍රය වෙත යොමු කිරීම, සජීවීව යාවත්කාලීන කරන ලදි.
    length: &'a mut usize,
    /// ණයට ගත් සිතියමේ මූල ක්ෂේත්‍රය පිළිබඳ තැන්පත් කිරීම.
    /// ඩ්‍රොප් හෑන්ඩ්ලර්ට `take` වෙත ඉඩ දීම සඳහා `Option` වලින් ඔතා.
    dormant_root: Option<DormantMutRef<'a, Root<K, V>>>,
    /// ඊළඟ මූලද්‍රව්‍යය ආපසු ලබා දීමට පෙර edge පත්‍රයක් හෝ අවසාන පත්‍ර edge අඩංගු වේ.
    /// සිතියමට මූලයක් නොමැති නම්, පුනරාවර්තනය අවසාන පත්‍ර edge ඉක්මවා ගියහොත් හෝ පුරෝකථනය කළ විට panic සිදුවී ඇත්නම් හිස් වේ.
    ///
    cur_leaf_edge: Option<Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>>,
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> Drop for DrainFilter<'_, K, V, F>
where
    F: FnMut(&K, &mut V) -> bool,
{
    fn drop(&mut self) {
        self.for_each(drop);
    }
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> fmt::Debug for DrainFilter<'_, K, V, F>
where
    K: fmt::Debug,
    V: fmt::Debug,
    F: FnMut(&K, &mut V) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.inner.peek()).finish()
    }
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> Iterator for DrainFilter<'_, K, V, F>
where
    F: FnMut(&K, &mut V) -> bool,
{
    type Item = (K, V);

    fn next(&mut self) -> Option<(K, V)> {
        self.inner.next(&mut self.pred)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

impl<'a, K: 'a, V: 'a> DrainFilterInner<'a, K, V> {
    /// ඊළඟ අංගය පුරෝකථනය කිරීමට දෝශ නිරාකරණ ක්‍රියාත්මක කිරීමට ඉඩ දෙන්න.
    pub(super) fn peek(&self) -> Option<(&K, &V)> {
        let edge = self.cur_leaf_edge.as_ref()?;
        edge.reborrow().next_kv().ok().map(Handle::into_kv)
    }

    /// පුරෝකථනය අනුව සාමාන්‍ය `DrainFilter::next` ක්‍රමයක් ක්‍රියාත්මක කිරීම.
    pub(super) fn next<F>(&mut self, pred: &mut F) -> Option<(K, V)>
    where
        F: FnMut(&K, &mut V) -> bool,
    {
        while let Ok(mut kv) = self.cur_leaf_edge.take()?.next_kv() {
            let (k, v) = kv.kv_mut();
            if pred(k, v) {
                *self.length -= 1;
                let (kv, pos) = kv.remove_kv_tracking(|| {
                    // සුරක්ෂිතභාවය: අපි මුල ස්පර්ශ නොකරන ආකාරයෙන් ස්පර්ශ කරන්නෙමු
                    // ආපසු ලබා දුන් ස්ථානය අවලංගු කරන්න.
                    let root = unsafe { self.dormant_root.take().unwrap().awaken() };
                    root.pop_internal_level();
                    self.dormant_root = Some(DormantMutRef::new(root).1);
                });
                self.cur_leaf_edge = Some(pos);
                return Some(kv);
            }
            self.cur_leaf_edge = Some(kv.next_leaf_edge());
        }
        None
    }

    /// සාමාන්‍ය `DrainFilter::size_hint` ක්‍රමයක් ක්‍රියාත්මක කිරීම.
    pub(super) fn size_hint(&self) -> (usize, Option<usize>) {
        // බොහෝ btree iterator වල, `self.length` යනු තවම නැරඹිය යුතු මූලද්‍රව්‍ය ගණන වේ.
        // මෙන්න, එයට සංචාරය කළ අංග ඇතුළත් වන අතර පුරෝකථනය drain නොකිරීමට තීරණය කළේය.
        // මෙම ඉහළ සීමාව වඩාත් නිවැරදි කිරීම සඳහා අමතර ක්ෂේත්‍රයක් පවත්වා ගැනීම අවශ්‍ය වන අතර එය වටින්නේ නැත.
        //
        (0, Some(*self.length))
    }
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> FusedIterator for DrainFilter<'_, K, V, F> where F: FnMut(&K, &mut V) -> bool {}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> Iterator for Range<'a, K, V> {
    type Item = (&'a K, &'a V);

    fn next(&mut self) -> Option<(&'a K, &'a V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_unchecked() }) }
    }

    fn last(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<'a, K, V> Iterator for ValuesMut<'a, K, V> {
    type Item = &'a mut V;

    fn next(&mut self) -> Option<&'a mut V> {
        self.inner.next().map(|(_, v)| v)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<&'a mut V> {
        self.next_back()
    }
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<'a, K, V> DoubleEndedIterator for ValuesMut<'a, K, V> {
    fn next_back(&mut self) -> Option<&'a mut V> {
        self.inner.next_back().map(|(_, v)| v)
    }
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<K, V> ExactSizeIterator for ValuesMut<'_, K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for ValuesMut<'_, K, V> {}

impl<'a, K, V> Range<'a, K, V> {
    unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        unsafe { self.inner.front.as_mut().unwrap_unchecked().next_unchecked() }
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> Iterator for IntoKeys<K, V> {
    type Item = K;

    fn next(&mut self) -> Option<K> {
        self.inner.next().map(|(k, _)| k)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<K> {
        self.next_back()
    }

    fn min(mut self) -> Option<K> {
        self.next()
    }

    fn max(mut self) -> Option<K> {
        self.next_back()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> DoubleEndedIterator for IntoKeys<K, V> {
    fn next_back(&mut self) -> Option<K> {
        self.inner.next_back().map(|(k, _)| k)
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> ExactSizeIterator for IntoKeys<K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> FusedIterator for IntoKeys<K, V> {}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> Iterator for IntoValues<K, V> {
    type Item = V;

    fn next(&mut self) -> Option<V> {
        self.inner.next().map(|(_, v)| v)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<V> {
        self.next_back()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> DoubleEndedIterator for IntoValues<K, V> {
    fn next_back(&mut self) -> Option<V> {
        self.inner.next_back().map(|(_, v)| v)
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> ExactSizeIterator for IntoValues<K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> FusedIterator for IntoValues<K, V> {}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> DoubleEndedIterator for Range<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_back_unchecked() }) }
    }
}

impl<'a, K, V> Range<'a, K, V> {
    unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        unsafe { self.inner.back.as_mut().unwrap_unchecked().next_back_unchecked() }
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Range<'_, K, V> {}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<K, V> Clone for Range<'_, K, V> {
    fn clone(&self) -> Self {
        Range { inner: LeafRange { front: self.inner.front, back: self.inner.back } }
    }
}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> Iterator for RangeMut<'a, K, V> {
    type Item = (&'a K, &'a mut V);

    fn next(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_unchecked() }) }
    }

    fn last(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }
}

impl<'a, K, V> RangeMut<'a, K, V> {
    unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        unsafe { self.inner.front.as_mut().unwrap_unchecked().next_unchecked() }
    }

    /// ඉතිරි අයිතමයන් පිළිබඳ යොමු දැක්වීම් නැවත ලබා දෙයි.
    #[inline]
    pub(super) fn iter(&self) -> Range<'_, K, V> {
        Range { inner: self.inner.reborrow() }
    }
}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> DoubleEndedIterator for RangeMut<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_back_unchecked() }) }
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for RangeMut<'_, K, V> {}

impl<'a, K, V> RangeMut<'a, K, V> {
    unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        unsafe { self.inner.back.as_mut().unwrap_unchecked().next_back_unchecked() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V> FromIterator<(K, V)> for BTreeMap<K, V> {
    fn from_iter<T: IntoIterator<Item = (K, V)>>(iter: T) -> BTreeMap<K, V> {
        let mut map = BTreeMap::new();
        map.extend(iter);
        map
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V> Extend<(K, V)> for BTreeMap<K, V> {
    #[inline]
    fn extend<T: IntoIterator<Item = (K, V)>>(&mut self, iter: T) {
        iter.into_iter().for_each(move |(k, v)| {
            self.insert(k, v);
        });
    }

    #[inline]
    fn extend_one(&mut self, (k, v): (K, V)) {
        self.insert(k, v);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, K: Ord + Copy, V: Copy> Extend<(&'a K, &'a V)> for BTreeMap<K, V> {
    fn extend<I: IntoIterator<Item = (&'a K, &'a V)>>(&mut self, iter: I) {
        self.extend(iter.into_iter().map(|(&key, &value)| (key, value)));
    }

    #[inline]
    fn extend_one(&mut self, (&k, &v): (&'a K, &'a V)) {
        self.insert(k, v);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Hash, V: Hash> Hash for BTreeMap<K, V> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        for elt in self {
            elt.hash(state);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V> Default for BTreeMap<K, V> {
    /// හිස් `BTreeMap` සාදයි.
    fn default() -> BTreeMap<K, V> {
        BTreeMap::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: PartialEq, V: PartialEq> PartialEq for BTreeMap<K, V> {
    fn eq(&self, other: &BTreeMap<K, V>) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a == b)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Eq, V: Eq> Eq for BTreeMap<K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: PartialOrd, V: PartialOrd> PartialOrd for BTreeMap<K, V> {
    #[inline]
    fn partial_cmp(&self, other: &BTreeMap<K, V>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V: Ord> Ord for BTreeMap<K, V> {
    #[inline]
    fn cmp(&self, other: &BTreeMap<K, V>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Debug, V: Debug> Debug for BTreeMap<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_map().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, Q: ?Sized, V> Index<&Q> for BTreeMap<K, V>
where
    K: Borrow<Q> + Ord,
    Q: Ord,
{
    type Output = V;

    /// සැපයූ යතුරට අනුරූප වන අගයට යොමු කිරීමක් ලබා දෙයි.
    ///
    /// # Panics
    ///
    /// යතුර `BTreeMap` හි නොමැති නම් Panics.
    #[inline]
    fn index(&self, key: &Q) -> &V {
        self.get(key).expect("no entry found for key")
    }
}

impl<K, V> BTreeMap<K, V> {
    /// යතුර අනුව වර්ග කර ඇති සිතියමේ ඇතුළත් කිරීම් වලට අනුකාරකයක් ලබා ගනී.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(3, "c");
    /// map.insert(2, "b");
    /// map.insert(1, "a");
    ///
    /// for (key, value) in map.iter() {
    ///     println!("{}: {}", key, value);
    /// }
    ///
    /// let (first_key, first_value) = map.iter().next().unwrap();
    /// assert_eq!((*first_key, *first_value), (1, "a"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, K, V> {
        if let Some(root) = &self.root {
            let full_range = root.reborrow().full_range();

            Iter { range: Range { inner: full_range }, length: self.length }
        } else {
            Iter { range: Range { inner: LeafRange::none() }, length: 0 }
        }
    }

    /// යතුර අනුව වර්ග කර ඇති සිතියමේ ඇතුළත් කිරීම් වලට වඩා විකෘති අනුකාරකයක් ලබා ගනී.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert("a", 1);
    /// map.insert("b", 2);
    /// map.insert("c", 3);
    ///
    /// // යතුර "a" නොවේ නම් අගයට 10 ක් එක් කරන්න
    /// for (key, value) in map.iter_mut() {
    ///     if key != &"a" {
    ///         *value += 10;
    ///     }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, K, V> {
        if let Some(root) = &mut self.root {
            let full_range = root.borrow_valmut().full_range();

            IterMut {
                range: RangeMut { inner: full_range, _marker: PhantomData },
                length: self.length,
            }
        } else {
            IterMut {
                range: RangeMut { inner: LeafRange::none(), _marker: PhantomData },
                length: 0,
            }
        }
    }

    /// වර්ග කළ අනුපිළිවෙලින් සිතියමේ යතුරු හරහා අනුකාරකයක් ලබා ගනී.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(2, "b");
    /// a.insert(1, "a");
    ///
    /// let keys: Vec<_> = a.keys().cloned().collect();
    /// assert_eq!(keys, [1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn keys(&self) -> Keys<'_, K, V> {
        Keys { inner: self.iter() }
    }

    /// යතුර අනුව අනුපිළිවෙලින් සිතියමේ අගයන් ඉක්මවා අනුකාරකයක් ලබා ගනී.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "hello");
    /// a.insert(2, "goodbye");
    ///
    /// let values: Vec<&str> = a.values().cloned().collect();
    /// assert_eq!(values, ["hello", "goodbye"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn values(&self) -> Values<'_, K, V> {
        Values { inner: self.iter() }
    }

    /// යතුර අනුව අනුපිළිවෙලින් සිතියමේ අගයන්ට වඩා විකෘති අනුකාරකයක් ලබා ගනී.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, String::from("hello"));
    /// a.insert(2, String::from("goodbye"));
    ///
    /// for value in a.values_mut() {
    ///     value.push_str("!");
    /// }
    ///
    /// let values: Vec<String> = a.values().cloned().collect();
    /// assert_eq!(values, [String::from("hello!"),
    ///                     String::from("goodbye!")]);
    /// ```
    #[stable(feature = "map_values_mut", since = "1.10.0")]
    pub fn values_mut(&mut self) -> ValuesMut<'_, K, V> {
        ValuesMut { inner: self.iter_mut() }
    }

    /// සිතියමේ ඇති මූලද්‍රව්‍ය ගණන ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// assert_eq!(a.len(), 0);
    /// a.insert(1, "a");
    /// assert_eq!(a.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_btree_new", issue = "71835")]
    pub const fn len(&self) -> usize {
        self.length
    }

    /// සිතියමේ කිසිදු අංගයක් නොමැති නම් `true` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// assert!(a.is_empty());
    /// a.insert(1, "a");
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_btree_new", issue = "71835")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// මූල නෝඩය හිස් (non-allocated) මූල නෝඩය නම්, අපේම නෝඩය වෙන් කරන්න.
    /// සමස්ත BTreeMap ණයට ගැනීම වළක්වා ගැනීම සඳහා සම්බන්ධිත කාර්යයකි.
    fn ensure_is_owned(root: &mut Option<Root<K, V>>) -> &mut Root<K, V> {
        root.get_or_insert_with(Root::new)
    }
}

#[cfg(test)]
mod tests;