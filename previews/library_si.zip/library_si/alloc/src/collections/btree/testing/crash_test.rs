use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// විශේෂිත සිදුවීම් අධීක්ෂණය කරන බිඳ වැටීම් පරීක්ෂණ ව්‍යාජ අවස්ථා සඳහා සැලැස්මක්.
/// සමහර අවස්ථා panic වෙත වින්‍යාසගත කළ හැකිය.
/// සිදුවීම් `clone`, `drop` හෝ සමහර නිර්නාමික `query` වේ.
///
/// ක්‍රෑෂ් ටෙස්ට් ඩම්මි හඳුනාගෙන හැඳුනුම්පතක් මඟින් ඇණවුම් කර ඇති බැවින් ඒවා BTreeMap හි යතුරු ලෙස භාවිතා කළ හැකිය.
/// `Debug` trait හැරුණු විට හිතාමතාම ක්‍රියාත්මක කිරීම crate හි අර්ථ දක්වා ඇති කිසිවක් මත රඳා නොපවතී.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// බිඳ වැටීම් පරීක්ෂණ ව්‍යාජ මෝස්තරයක් නිර්මාණය කරයි.`id` නිදර්ශනවල අනුපිළිවෙල හා සමානාත්මතාවය තීරණය කරයි.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// එය අත්විඳින සිදුවීම් වාර්තා කරන සහ විකල්ප වශයෙන් panics බිඳ වැටෙන පරීක්ෂණ ව්‍යාජයක් නිර්මාණය කරයි.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// ව්‍යාජ අවස්ථා ක්ලෝන කර ඇති වාර ගණන නැවත ලබා දෙයි.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// ව්‍යාජ අවස්ථා කීයක් අතහැර දමා ඇත්දැයි නැවත ලබා දෙයි.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// ඔවුන්ගේ `query` සාමාජිකයාට ආරාධනා කර ඇති අවස්ථා ගණන කොපමණ දැයි ආපසු ලබා දෙයි.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// සමහර නිර්නාමික විමසුම්, එහි ප්‍රති result ලය දැනටමත් ලබා දී ඇත.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}