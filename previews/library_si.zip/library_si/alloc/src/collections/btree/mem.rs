use core::intrinsics;
use core::mem;
use core::ptr;

/// මෙමඟින් `v` අද්විතීය යොමුව පිටුපස ඇති අගය අදාළ ශ්‍රිතය ඇමතීමෙන් ප්‍රතිස්ථාපනය වේ.
///
///
/// `change` වසා දැමීමේදී panic සිදුවුවහොත්, සම්පූර්ණ ක්‍රියාවලියම අහෝසි වේ.
#[allow(dead_code)] // නිදර්ශනයක් ලෙස තබා future භාවිතය සඳහා
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// මෙය `v` අද්විතීය යොමුව පිටුපස ඇති අගය අදාළ ශ්‍රිතය ඇමතීමෙන් ප්‍රතිස්ථාපනය කරයි.
///
///
/// `change` වසා දැමීමේදී panic සිදුවුවහොත්, සම්පූර්ණ ක්‍රියාවලියම අහෝසි වේ.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}