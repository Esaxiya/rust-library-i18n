use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// `Bound::Included(T)` මෙන් සෙවීමට ඇතුළත් වන බැඳීමක්.
    Included(T),
    /// `Bound::Excluded(T)` මෙන් සෙවීමට පමණක් බැඳී ඇත.
    Excluded(T),
    /// `Bound::Unbounded` මෙන් කොන්දේසි විරහිතව බැඳී ඇති බැඳීමක්.
    AllIncluded,
    /// කොන්දේසි විරහිතව බැඳී ඇත.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// (උප) ගසක දී ඇති යතුරක් පුනරාවර්තව, නෝඩ් විසින් මෙහෙයවනු ලැබේ.
    /// ගැලපෙන KV හි හසුරුව සමඟ `Found` ලබා දෙයි.
    /// එසේ නොමැතිනම්, යතුර අයත් edge පත්‍රයේ හසුරුව සමඟ `GoDown` ආපසු එවයි.
    ///
    /// ප්‍රති 00 ලය අර්ථවත් වන්නේ ගස යතුරෙන් ඇණවුම් කළහොත් පමණි, `BTreeMap` හි ඇති ගස මෙන්.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// පරාසයේ පහළ සීමාවට ගැලපෙන edge ඉහළ සීමාවට ගැලපෙන edge ට වඩා වෙනස් වන ආසන්නතම නෝඩයට බැස යයි, එනම් පරාසයේ අවම වශයෙන් එක් යතුරක්වත් ඇති ආසන්නතම නෝඩය.
    ///
    ///
    /// සොයාගත හොත්, එම නෝඩය සමඟ `Ok` ආපසු ලබා දෙන්න, එහි ඇති edge දර්ශක යුගලය පරාසය සීමා කරයි, සහ ළමා නෝඩ් තුළ සෙවීම දිගටම කරගෙන යාම සඳහා අනුරූප මායිම් යුගලය, නෝඩය අභ්‍යන්තර නම්.
    ///
    /// සොයාගත නොහැකි නම්, මුළු පරාසයටම ගැලපෙන edge කොළ සහිත `Err` ආපසු එවන්න.
    ///
    /// ප්‍රති result ලය අර්ථවත් වන්නේ ගස යතුරෙන් ඇණවුම් කළහොත් පමණි.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // මෙම විචල්‍යයන් ඇතුළත් කිරීමෙන් වැළකී සිටිය යුතුය.
        // `range` විසින් වාර්තා කරන ලද සීමාවන් එලෙසම පවතින බව අපි උපකල්පනය කරමු, නමුත් (#81138) ඇමතුම් අතර විරුද්ධවාදී ක්‍රියාත්මක කිරීමක් වෙනස් විය හැකිය.
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// පරාසයක පහළ සීමාව සීමා කරන නෝඩයේ edge සොයා ගනී.
    /// `self` අභ්‍යන්තර නෝඩයක් නම්, ගැලපෙන ළමා නෝඩයේ සෙවීම දිගටම කරගෙන යාම සඳහා භාවිතා කළ යුතු පහළ සීමාව නැවත ලබා දේ.
    ///
    ///
    /// ප්‍රති result ලය අර්ථවත් වන්නේ ගස යතුරෙන් ඇණවුම් කළහොත් පමණි.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// ඉහළ මායිම සඳහා `find_lower_bound_edge` ක්ලෝනය.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// පුනරාවර්තනයකින් තොරව, නෝඩයේ දී ඇති යතුරක් සොයා ගනී.
    /// ගැලපෙන KV හි හසුරුව සමඟ `Found` ලබා දෙයි.
    /// එසේ නොමැතිනම්, යතුර සොයාගත හැකි (නෝඩය අභ්‍යන්තර නම්) හෝ යතුර ඇතුළු කළ හැකි edge හසුරුව සමඟ `GoDown` ආපසු එවයි.
    ///
    ///
    /// ප්‍රති 00 ලය අර්ථවත් වන්නේ ගස යතුරෙන් ඇණවුම් කළහොත් පමණි, `BTreeMap` හි ඇති ගස මෙන්.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// යතුර (හෝ ඊට සමාන) පවතින නෝඩයේ KV දර්ශකය හෝ යතුර අයත් edge දර්ශකය ලබා දෙයි.
    ///
    ///
    /// ප්‍රති 00 ලය අර්ථවත් වන්නේ ගස යතුරෙන් ඇණවුම් කළහොත් පමණි, `BTreeMap` හි ඇති ගස මෙන්.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// පරාසයක පහළ සීමාව සීමා කරන නෝඩයේ edge දර්ශකයක් සොයා ගනී.
    /// `self` අභ්‍යන්තර නෝඩයක් නම්, ගැලපෙන ළමා නෝඩයේ සෙවීම දිගටම කරගෙන යාම සඳහා භාවිතා කළ යුතු පහළ සීමාව නැවත ලබා දේ.
    ///
    ///
    /// ප්‍රති result ලය අර්ථවත් වන්නේ ගස යතුරෙන් ඇණවුම් කළහොත් පමණි.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// ඉහළ මායිම සඳහා `find_lower_bound_index` ක්ලෝනය.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}