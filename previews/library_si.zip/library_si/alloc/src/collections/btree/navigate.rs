use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// එකම පරාසයට සමාන තවත් වෙනස් කළ නොහැකි සමානකමක් තාවකාලිකව ලබා ගනී.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// ගසක නිශ්චිත පරාසයක් වෙන්කර දැක්වෙන පැහැදිලි පත්‍ර දාර සොයා ගනී.
    /// එකම හසුරුවකට විවිධ හැන්ඩ්ල් යුගලයක් හෝ හිස් විකල්ප යුගලයක් ලබා දෙයි.
    ///
    /// # Safety
    ///
    /// `BorrowType` යනු `Immut` නොවේ නම්, එකම KV වෙත දෙවරක් බැලීමට අනුපිටපත් හසුරුව භාවිතා නොකරන්න.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// `(root1.first_leaf_edge(), root2.last_leaf_edge())` ට සමාන නමුත් වඩා කාර්යක්ෂම වේ.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// ගසක නිශ්චිත පරාසයක් වෙන්කර ඇති පත්‍ර දාර යුගලය සොයා ගනී.
    ///
    /// ප්‍රති 00 ලය අර්ථවත් වන්නේ ගස යතුරෙන් ඇණවුම් කළහොත් පමණි, `BTreeMap` හි ඇති ගස මෙන්.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // ආරක්ෂාව: අපගේ ණය වර්ගය වෙනස් කළ නොහැක.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// මුළු ගසක්ම සීමා කරන කොළ දාර යුගලයක් සොයා ගනී.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// නිශ්චිත පරාසයක් සීමා කරන පත්‍ර දාර යුගලයකට අද්විතීය සඳහනක් බෙදයි.
    /// මෙහි ප්‍රති result ලය වන්නේ (some) විකෘතියට ඉඩ දෙන අද්විතීය නොවන යොමු කිරීම් වන අතර ඒවා ප්‍රවේශමෙන් භාවිතා කළ යුතුය.
    ///
    /// ප්‍රති 00 ලය අර්ථවත් වන්නේ ගස යතුරෙන් ඇණවුම් කළහොත් පමණි, `BTreeMap` හි ඇති ගස මෙන්.
    ///
    ///
    /// # Safety
    /// එකම කේ.වී. වෙත දෙවරක් බැලීමට අනුපිටපත් හසුරුව භාවිතා නොකරන්න.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// ගසෙහි සම්පූර්ණ පරාසය සීමා කරන පත්‍ර දාර යුගලයකට අද්විතීය සඳහනක් බෙදයි.
    /// ප්‍රති results ල විකෘති වීමට ඉඩ සලසන අද්විතීය නොවන යොමු කිරීම් (අගයන් පමණක්), එබැවින් ප්‍රවේශමෙන් භාවිතා කළ යුතුය.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // අපි මෙහි මූල නෝඩ් රීෆ් අනුපිටපත් කරන්නෙමු-අපි කිසි විටෙකත් එකම කේ.වී. වෙත දෙවරක් නොයන්නෙමු.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// ගසෙහි සම්පූර්ණ පරාසය සීමා කරන පත්‍ර දාර යුගලයකට අද්විතීය සඳහනක් බෙදයි.
    /// ප්‍රති results ල යනු අද්විතීය නොවන යොමු කිරීම් වන අතර එය විශාල වශයෙන් විනාශකාරී විකෘතියට ඉඩ සලසයි, එබැවින් එය ඉතා පරිස්සමින් භාවිතා කළ යුතුය.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // අපි මෙහි මූල නෝඩ් රීෆ් අනුපිටපත් කරමු-අපි කිසි විටෙකත් මූලයෙන් ලබාගත් යොමු අතිච්ඡාදනය වන ආකාරයට එයට පිවිසෙන්නේ නැත.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// edge හසුරුවකින් ලබා දී, [`Result::Ok`] හසුරුවකින් දකුණු පැත්තේ අසල්වැසි KV වෙත යවයි, එය එකම පත්‍ර නෝඩයක හෝ මුතුන් මිත්තන්ගේ නෝඩයක ඇත.
    ///
    /// edge පත්‍රය ගසෙහි අන්තිම එක නම්, මූල නෝඩය සමඟ [`Result::Err`] ආපසු ලබා දේ.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// edge හසුරුවකින් ලබා දී, [`Result::Ok`] හසුරුවකින් වම් පැත්තේ අසල්වැසි KV වෙත යවයි, එය එකම පත්‍ර නෝඩයක හෝ මුතුන් මිත්තන්ගේ නෝඩයක ඇත.
    ///
    /// edge පත්‍රය ගසෙහි පළමුවැන්න නම්, මූල නෝඩය සමඟ [`Result::Err`] ආපසු ලබා දේ.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// අභ්‍යන්තර edge හසුරුව ලබා දී, [`Result::Ok`] හසුරුවකින් දකුණු පැත්තේ අසල්වැසි KV වෙත යවයි, එය එකම අභ්‍යන්තර නෝඩයක හෝ මුතුන් මිත්තන්ගේ නෝඩයක ඇත.
    ///
    /// අභ්‍යන්තර edge යනු ගසෙහි අන්තිම එක නම්, මූල නෝඩය සමඟ [`Result::Err`] ආපසු ලබා දේ.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// edge හසුරුව මිය යන ගසකට ලබා දී, ඊළඟ පත්‍ර edge දකුණු පැත්තේ නැවත ලබා දෙයි, සහ යතුරු-වටිනාකමේ යුගලය එකම පත්‍ර නෝඩයක, මුතුන් මිත්තන්ගේ නෝඩයක හෝ නොපවතින.
    ///
    ///
    /// මෙම ක්‍රමය මඟින් ඕනෑම node(s) අවසානය කරා ළඟා වේ.
    /// මෙයින් ගම්‍ය වන්නේ තවත් යතුරු-වටිනාකම් යුගලයක් නොමැති නම්, ගසෙහි ඉතිරි කොටස අවලංගු වී ඇති අතර නැවත පැමිණීමට කිසිවක් ඉතිරි නොවන බවයි.
    ///
    /// # Safety
    /// ලබා දී ඇති edge මීට පෙර `deallocating_next_back` කවුන්ටරය විසින් ආපසු ලබා දී නොතිබිය යුතුය.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// edge හසුරුව මිය යන ගසකට ලබා දී, ඊළඟ කොළ edge වම් පැත්තට ලබා දෙයි, සහ යතුරු-වටිනාකමේ යුගලය එකම පත්‍ර නෝඩයක, මුතුන් මිත්තන්ගේ නෝඩයක හෝ නොපවතින.
    ///
    ///
    /// මෙම ක්‍රමය මඟින් ඕනෑම node(s) අවසානය කරා ළඟා වේ.
    /// මෙයින් ගම්‍ය වන්නේ තවත් යතුරු-වටිනාකම් යුගලයක් නොමැති නම්, ගසෙහි ඉතිරි කොටස අවලංගු වී ඇති අතර නැවත පැමිණීමට කිසිවක් ඉතිරි නොවන බවයි.
    ///
    /// # Safety
    /// ලබා දී ඇති edge මීට පෙර `deallocating_next` කවුන්ටරය විසින් ආපසු ලබා දී නොතිබිය යුතුය.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// පත්‍රයේ සිට මුල දක්වා නෝඩ් ගොඩවල් ඉවත් කරන්න.
    /// `deallocating_next` සහ `deallocating_next_back` ගස දෙපස නිබ්බල් කර ඇති අතර එකම edge ට පහර දුන් පසු ගසක ඉතිරි කොටස ඉවත් කිරීමට ඇති එකම ක්‍රමය මෙයයි.
    /// සියලු යතුරු සහ අගයන් ආපසු ලබා දුන් විට පමණක් එය කැඳවීමට අදහස් කරන බැවින්, කිසිදු යතුරු හෝ අගයක් මත පිරිසිදු කිරීමක් සිදු නොවේ.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// edge හසුරුව ඊළඟ පත්‍ර edge වෙත ගෙන යන අතර යතුර සහ අගය අතර යොමු කිරීම් ලබා දෙයි.
    ///
    ///
    /// # Safety
    /// ගමන් කළ දිශාවට තවත් කේ.වී. එකක් තිබිය යුතුය.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// edge හසුරුව පෙර පත්‍ර edge වෙත ගෙන යන අතර යතුර සහ අගය අතර යොමු කිරීම් ලබා දෙයි.
    ///
    ///
    /// # Safety
    /// ගමන් කළ දිශාවට තවත් කේ.වී. එකක් තිබිය යුතුය.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// edge හසුරුව ඊළඟ පත්‍ර edge වෙත ගෙන යන අතර යතුර සහ අගය අතර යොමු කිරීම් ලබා දෙයි.
    ///
    ///
    /// # Safety
    /// ගමන් කළ දිශාවට තවත් කේ.වී. එකක් තිබිය යුතුය.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // මිණුම් සලකුණු වලට අනුව මෙය අවසන් වරට කිරීම වේගවත් ය.
        kv.into_kv_valmut()
    }

    /// edge හසුරුව පෙර පත්‍රයට ගෙන යන අතර යතුර සහ අගය අතර යොමු දක්වයි.
    ///
    ///
    /// # Safety
    /// ගමන් කළ දිශාවට තවත් කේ.වී. එකක් තිබිය යුතුය.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // මිණුම් සලකුණු වලට අනුව මෙය අවසන් වරට කිරීම වේගවත් ය.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// edge හසුරුව ඊළඟ පත්‍රයට ගෙන යන edge යතුර සහ යතුර අතර අගය නැවත ලබා දෙයි, ඉතිරිව ඇති ඕනෑම නෝඩයක් අවලංගු කර අනුරූපී edge එහි මව් නෝඩ් ඩැන්ග්ලිං තුළ තබයි.
    ///
    /// # Safety
    /// - ගමන් කළ දිශාවට තවත් කේ.වී. එකක් තිබිය යුතුය.
    /// - ගස හරහා ගමන් කිරීම සඳහා භාවිතා කරන හසුරුවල කිසිදු පිටපතක් සඳහා KV මීට පෙර `next_back_unchecked` කවුන්ටරය විසින් ආපසු ලබා දී නොමැත.
    ///
    /// යාවත්කාලීන කළ හසුරුව සමඟ ඉදිරියට යා හැකි එකම ආරක්‍ෂිත ක්‍රමය වන්නේ එය සංසන්දනය කිරීම, අතහැර දැමීම, එහි ආරක්ෂිත කොන්දේසි වලට යටත්ව මෙම ක්‍රමය නැවත අමතන්න හෝ එහි ආරක්ෂක කොන්දේසි වලට යටත්ව `next_back_unchecked` කවුන්ටරය අමතන්න.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// edge හසුරුව පෙර පත්‍ර edge වෙත ගෙන යන අතර යතුර සහ අගය අතර නැවත ලබා දෙයි, ඉතිරිව ඇති ඕනෑම නෝඩයක් අවලංගු කරමින් අනුරූපී edge එහි මව් නෝඩ් ඩැන්ග්ලිං තුළ තබයි.
    ///
    /// # Safety
    /// - ගමන් කළ දිශාවට තවත් කේ.වී. එකක් තිබිය යුතුය.
    /// - ගස හරහා ගමන් කිරීම සඳහා භාවිතා කරන හසුරුවල කිසිදු පිටපතක් මත edge පත්‍රය මීට පෙර `next_unchecked` කවුන්ටරය විසින් ආපසු ලබා දී නොමැත.
    ///
    /// යාවත්කාලීන කළ හසුරුව සමඟ ඉදිරියට යා හැකි එකම ආරක්‍ෂිත ක්‍රමය වන්නේ එය සංසන්දනය කිරීම, අතහැර දැමීම, එහි ආරක්ෂිත කොන්දේසි වලට යටත්ව මෙම ක්‍රමය නැවත අමතන්න හෝ එහි ආරක්ෂක කොන්දේසි වලට යටත්ව `next_unchecked` කවුන්ටරය අමතන්න.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// වම් කෙළවරේ edge නෝඩ් එකක හෝ ඊට යටින් ලබා දෙයි, වෙනත් වචන වලින් කිවහොත්, ඉදිරියට ගමන් කිරීමේදී ඔබට මුලින්ම අවශ්‍ය edge (හෝ පසුපසට සැරිසැරීමේදී අවසාන වශයෙන්).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// දකුණු කෙළවරේ edge පත්‍රය නෝඩ් එකක හෝ ඊට යටින් ලබා දෙයි, වෙනත් වචන වලින් කිවහොත්, ඉදිරියට ගමන් කිරීමේදී ඔබට අවසාන වශයෙන් අවශ්‍ය edge (හෝ පළමුව පසුපසට සැරිසැරීමේදී).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// ආරෝහණ යතුරු අනුපිළිවෙලින් පත්‍ර නෝඩ් සහ අභ්‍යන්තර කේ.වී. වෙත පිවිසෙන අතර සමස්තයක් ලෙස අභ්‍යන්තර පළමු නෝඩ් ගැඹුරට පළමු අනුපිළිවෙලට පිවිසෙයි, එයින් අදහස් වන්නේ අභ්‍යන්තර නෝඩ් ඔවුන්ගේ තනි කේ.වී. සහ ළමා නෝඩ් වලට පෙර බවයි.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// (උප) ගසක ඇති මූලද්‍රව්‍ය ගණන ගණනය කරයි.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// ඉදිරි සංචලනය සඳහා KV ට ආසන්නතම edge පත්‍රය ලබා දෙයි.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// පසුගාමී සංචලනය සඳහා KV ට ආසන්නතම edge පත්‍රය ලබා දෙයි.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}