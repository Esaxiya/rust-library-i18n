use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef};

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    /// යතුරු-වටිනා යුගලයක් ගසෙන් ඉවත් කර, එම යුගලය මෙන්ම එම පෙර යුගලයට අනුරූප edge පත්‍රය ද ලබා දෙයි.
    /// මෙය අභ්‍යන්තරව ඇති මූල නෝඩයක් හිස් කළ හැකි අතර, ගස රඳවාගෙන සිටින සිතියමෙන් ඇමතුම්කරු පැමිණිය යුතුය.
    /// අමතන්නා සිතියමේ දිග අඩු කළ යුතුය.
    ///
    pub fn remove_kv_tracking<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        match self.force() {
            Leaf(node) => node.remove_leaf_kv(handle_emptied_internal_root),
            Internal(node) => node.remove_internal_kv(handle_emptied_internal_root),
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    fn remove_leaf_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let (old_kv, mut pos) = self.remove();
        let len = pos.reborrow().into_node().len();
        if len < MIN_LEN {
            let idx = pos.idx();
            // කොළයක ආසන්නතම දෙමව්පියන් සඳහා විශේෂිත නෝඩ් වර්ගයක් නොමැති නිසා අපට ළමා වර්ගය තාවකාලිකව අමතක කළ යුතුය.
            //
            let new_pos = match pos.into_node().forget_type().choose_parent_kv() {
                Ok(Left(left_parent_kv)) => {
                    debug_assert!(left_parent_kv.right_child_len() == MIN_LEN - 1);
                    if left_parent_kv.can_merge() {
                        left_parent_kv.merge_tracking_child_edge(Right(idx))
                    } else {
                        debug_assert!(left_parent_kv.left_child_len() > MIN_LEN);
                        left_parent_kv.steal_left(idx)
                    }
                }
                Ok(Right(right_parent_kv)) => {
                    debug_assert!(right_parent_kv.left_child_len() == MIN_LEN - 1);
                    if right_parent_kv.can_merge() {
                        right_parent_kv.merge_tracking_child_edge(Left(idx))
                    } else {
                        debug_assert!(right_parent_kv.right_child_len() > MIN_LEN);
                        right_parent_kv.steal_right(idx)
                    }
                }
                Err(pos) => unsafe { Handle::new_edge(pos, idx) },
            };
            // ආරක්ෂාව: `new_pos` යනු අප ආරම්භ කළ පත්‍රය හෝ සහෝදර සහෝදරියකි.
            pos = unsafe { new_pos.cast_to_leaf_unchecked() };

            // අප ඒකාබද්ධ කළහොත් පමණක්, දෙමව්පියන් (ඇත්නම්) හැකිලී ඇත, නමුත් පහත දැක්වෙන පියවර මඟ හැරීම වෙනත් ආකාරයකින් මිණුම් සලකුණු වලින් ගෙවන්නේ නැත.
            //
            // ආරක්ෂාව: අපි `pos` තිබෙන කොළ විනාශ කරන්න හෝ නැවත සකස් කරන්නේ නැහැ
            // තම මවුපියන් පුනරාවර්තනයෙන් හැසිරවීමෙන්;නරකම දෙය නම් අපි ආච්චිලා සීයලා හරහා දෙමව්පියන් විනාශ කිරීම හෝ නැවත සකස් කිරීම, එමඟින් පත්‍රයේ ඇති මවුපියන් සමඟ ඇති සම්බන්ධය වෙනස් කිරීමයි.
            //
            //
            //
            if let Ok(parent) = unsafe { pos.reborrow_mut() }.into_node().ascend() {
                if !parent.into_node().forget_type().fix_node_and_affected_ancestors() {
                    handle_emptied_internal_root();
                }
            }
        }
        (old_kv, pos)
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    fn remove_internal_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        // යාබද KV එකක් එහි කොළයෙන් ඉවත් කර ඉවත් කිරීමට අපෙන් ඉල්ලා සිටි මූලද්‍රව්‍යය වෙනුවට එය නැවත තබන්න.
        //
        // `choose_parent_kv` හි ලැයිස්තුගත කර ඇති හේතු සඳහා වම් යාබද KV ට වැඩි කැමැත්තක් දක්වන්න.
        let left_leaf_kv = self.left_edge().descend().last_leaf_edge().left_kv();
        let left_leaf_kv = unsafe { left_leaf_kv.ok().unwrap_unchecked() };
        let (left_kv, left_hole) = left_leaf_kv.remove_leaf_kv(handle_emptied_internal_root);

        // අභ්‍යන්තර නෝඩය සොරකම් කර හෝ ඒකාබද්ධ වී තිබිය හැක.
        // මුල් කේ.වී අවසන් වූයේ කොතැනදැයි සොයා ගැනීමට දකුණට ආපසු යන්න.
        let mut internal = unsafe { left_hole.next_kv().ok().unwrap_unchecked() };
        let old_kv = internal.replace_kv(left_kv.0, left_kv.1);
        let pos = internal.next_leaf_edge();
        (old_kv, pos)
    }
}