// `SetLenOnDrop` අගය විෂය පථයෙන් බැහැර වූ විට vec හි දිග සකසන්න.
//
// අදහස නම්: SetLenOnDrop හි දිග ක්ෂේත්‍රය දේශීය විචල්‍යයක් වන අතර එය Vec හි දත්ත දර්ශකය හරහා කිසිදු ගබඩාවක් සමඟ නොගැලපෙන බව ප්‍රශස්තකරණයට පෙනෙනු ඇත.
// මෙය අන්වර්ථ විශ්ලේෂණ නිකුතුව #32155 සඳහා වන විසඳුමකි
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}