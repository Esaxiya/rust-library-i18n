use core::ptr::{self};
use core::slice::{self};

// ස්ථානීය පුනරාවර්තනය සඳහා උපකාරක ව්‍යුහයක් වන අතර එය ගමනාන්ත පෙත්තක් පුනරාවර්තනය කරයි, එනම් හිස.
// ප්‍රභව පෙත්ත (වලිගය) IntoIter විසින් අතහැර දමනු ලැබේ.
pub(super) struct InPlaceDrop<T> {
    pub(super) inner: *mut T,
    pub(super) dst: *mut T,
}

impl<T> InPlaceDrop<T> {
    fn len(&self) -> usize {
        unsafe { self.dst.offset_from(self.inner) as usize }
    }
}

impl<T> Drop for InPlaceDrop<T> {
    #[inline]
    fn drop(&mut self) {
        unsafe {
            ptr::drop_in_place(slice::from_raw_parts_mut(self.inner, self.len()));
        }
    }
}