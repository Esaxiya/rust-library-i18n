use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Vec::from_iter සඳහා භාවිතා කරන trait විශේෂීකරණය
///
/// ## නියෝජිත ප්‍රස්ථාරය:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // පොදු සිද්ධියක් වන්නේ vector ශ්‍රිතයක් තුළට ගමන් කිරීම වහාම vector වෙත නැවත එකතු කිරීමයි.
        // IntoIter කිසිසේත් දියුණු කර නොමැති නම් අපට මෙය කෙටි පරිපථයක් කළ හැකිය.
        // එය දියුණු වූ විට අපට මතකය නැවත භාවිතා කර දත්ත ඉදිරිපස දෙසට ගෙන යා හැකිය.
        // නමුත් අප එසේ කරන්නේ සාමාන්‍ය ෆ්‍රොමිටරේටර් ක්‍රියාවට නැංවීම තුළින් එය නිර්මාණය කිරීමට වඩා එහි ප්‍රති V ලයක් ලෙස Vec හට භාවිතයට නොගත් ධාරිතාවක් නොමැති විට පමණි.
        //
        // Vec හි ප්‍රතිපාදන හැසිරීම හිතාමතාම නිශ්චිතව දක්වා නොමැති බැවින් එම සීමාව දැඩි ලෙස අවශ්‍ය නොවේ.
        // නමුත් එය ගතානුගතික තේරීමකි.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // extend() විසින් හිස් Vecs සඳහා spec_from වෙත පැවරෙන බැවින් spec_extend() වෙත පැවරිය යුතුය
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// මෙය `iterator.as_slice().to_vec()` භාවිතා කරයි, මන්දයත් spec_extend අවසාන ධාරිතාව + දිග ගැන තර්ක කිරීමට තවත් පියවර ගත යුතු අතර එමඟින් වැඩි වැඩ කොටසක් කළ යුතුය.
// `to_vec()` සෘජුවම නිවැරදි මුදල වෙන් කර එය හරියටම පුරවයි.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): cfg(test) සමඟ මෙම ක්‍රම නිර්වචනය සඳහා අවශ්‍ය වන සහජ `[T]::to_vec` ක්‍රමය ලබා ගත නොහැක.
    // ඒ වෙනුවට cfg(test) NB සමඟ පමණක් ඇති `slice::to_vec` ශ්‍රිතය භාවිතා කරන්න වැඩි විස්තර සඳහා slice.rs හි slice::hack මොඩියුලය බලන්න
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}