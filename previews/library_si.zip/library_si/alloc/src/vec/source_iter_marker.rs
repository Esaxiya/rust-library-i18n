use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// ප්‍රභව වෙන් කිරීම නැවත භාවිතා කරන අතරවාරයේ නල මාර්ගයක් Vec එකකට එකතු කිරීම සඳහා වූ විශේෂතා සලකුණ, එනම්
/// නල මාර්ගය ක්‍රියාත්මක කිරීම.
///
/// නැවත භාවිතා කිරීමට නියමිත ප්‍රතිපාදන වෙත ප්‍රවේශ වීම සඳහා විශේෂිත කාර්යය සඳහා SourceIter මව් trait අවශ්‍ය වේ.
/// නමුත් විශේෂීකරණය වලංගු වීමට එය ප්‍රමාණවත් නොවේ.
/// Impl හි අමතර සීමාවන් බලන්න.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-අභ්‍යන්තර SourceIter/InPlaceIterable traits ක්‍රියාත්මක කරනු ලබන්නේ ඇඩැප්ටරයේ දාමයන් පමණි <Adapter<Adapter<IntoIter>>> (සියල්ල core/std සතු).
// ඇඩැප්ටරය ක්‍රියාත්මක කිරීමේ අමතර සීමාවන් (`impl<I: Trait> Trait for Adapter<I>` වලින් ඔබ්බට) රඳා පවතින්නේ දැනටමත් traits විශේෂීකරණය ලෙස සලකුණු කර ඇති අනෙකුත් traits මත පමණි (පිටපත් කරන්න, විශ්වාසදායක රැන්ඩම් ඇක්සස්, ෆියුස්ඩ්ඉටරේටර්).
//
// I.e. සලකුණු කාරකය පරිශීලක සපයන වර්ගවල ආයු කාලය මත රඳා නොපවතී.තවත් විශේෂීකරණයන් කිහිපයක් දැනටමත් රඳා පවතින පිටපත් කුහරය මොඩියුලෝ කරන්න.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // trait bounds හරහා ප්‍රකාශ කළ නොහැකි අමතර අවශ්‍යතා.අපි ඒ වෙනුවට const eval මත රඳා සිටිමු:
        // අ) නැවත භාවිතා කිරීම සඳහා ප්‍රතිපාදන වෙන් නොකෙරෙන හෙයින් සහ අංක ගණිතය panic ආ) ඇලෝක් කොන්ත්‍රාත්තුවට අනුව ප්‍රමාණයේ ගැලපීම ඇ) ඇලෝක් කොන්ත්‍රාත්තුවට අනුව පෙළගැස්වීම් ගැලපේ.
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // වඩාත් සාමාන්‍ය ක්‍රියාත්මක කිරීම් වලට ආපසු යාම
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // එතැන් සිට උත්සාහ කරන්න
        // - එය සමහර අනුකාරක ඇඩැප්ටර සඳහා වඩා හොඳින් දෛශික කරයි
        // - බොහෝ අභ්‍යන්තර පුනරාවර්තන ක්‍රම මෙන් නොව, එය ගන්නේ &mut ස්වයං පමණි
        // - එය අපට ලිවීමේ දර්ශකය එහි අභ්‍යන්තරය හරහා නූල් කර අවසානයේ එය නැවත ලබා ගැනීමට ඉඩ දෙයි
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // පුනරාවර්තනය සාර්ථකයි, හිස අතහරින්න එපා
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // SourceIter කොන්ත්‍රාත්තුව අනුමත කර ඇත්දැයි පරීක්ෂා කරන්න: ඒවා එසේ නොවේ නම් අපි මේ දක්වා එය සිදු නොකරනු ඇත
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // InPlaceIterable කොන්ත්රාත්තුව පරීක්ෂා කරන්න.මෙය කළ හැකි වන්නේ අනුකාරකය ප්‍රභව දර්ශකය කිසිසේත් දියුණු කළහොත් පමණි.
        // එය TrustedRandomAccess හරහා පරීක්ෂා නොකළ ප්‍රවේශයක් භාවිතා කරන්නේ නම් ප්‍රභව දර්ශකය එහි ආරම්භක ස්ථානයේ රැඳෙනු ඇති අතර අපට එය යොමු කිරීමක් ලෙස භාවිතා කළ නොහැක
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // ඉතිරිව ඇති අගයන් ප්‍රභවයේ වලිගයට දමන්න, නමුත් ඉන්ටූඉටර් විෂය පථයෙන් බැහැර වූ විට panics පහත වැටේ නම් වෙන් කිරීම පහත වැටීම වළක්වන්න. එවිට අපි එකතු කළ ඕනෑම මූලද්‍රව්‍යයක් dst_buf වෙත කාන්දු වෙමු.
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // InPlaceIterable කොන්ත්‍රාත්තුව මෙහි නිශ්චිතවම සත්‍යාපනය කළ නොහැක, මන්ද try_fold හි ප්‍රභව දර්ශකය පිළිබඳ සුවිශේෂී සඳහනක් ඇති බැවින් අපට කළ හැක්කේ එය තවමත් පරාසයේ තිබේද යන්න පරීක්ෂා කිරීමයි.
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}