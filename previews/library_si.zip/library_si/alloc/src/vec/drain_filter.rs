use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// මූලද්‍රව්‍යයක් ඉවත් කළ යුතුද යන්න තීරණය කිරීම සඳහා වසා දැමීමක් භාවිතා කරන අනුකාරකය.
///
/// මෙම ව්‍යුහය නිර්මාණය කර ඇත්තේ [`Vec::drain_filter`] විසිනි.
/// වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// `next` වෙත ඊළඟ ඇමතුම මගින් පරීක්ෂා කරනු ලබන අයිතමයේ දර්ශකය.
    pub(super) idx: usize,
    /// මේ දක්වා (removed) ජලාපවහනය කර ඇති අයිතම ගණන.
    pub(super) del: usize,
    /// ජලාපවහනය කිරීමට පෙර `vec` හි මුල් දිග.
    pub(super) old_len: usize,
    /// පෙරහන් පරීක්ෂණය පුරෝකථනය කරයි.
    pub(super) pred: F,
    /// පෙරහන් පරීක්ෂණ අනාවැකියෙහි panic පෙන්වන ධජයක් සිදුවී ඇත.
    /// `DrainFilter` හි ඉතිරි කොටස පරිභෝජනය වැළැක්වීම සඳහා බිංදු ක්‍රියාත්මක කිරීමේ ඉඟියක් ලෙස මෙය භාවිතා කරයි.
    /// සැකසූ ඕනෑම අයිතමයක් `vec` හි පසුපසට හරවනු ලැබේ, නමුත් පෙරහන් අනාවැකිය මඟින් තවත් අයිතම අතහැර දමනු නොලැබේ.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// යටින් ඇති විබෙදන්නා වෙත යොමු කිරීමක් ලබා දෙයි.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // පුරෝකථනය කැඳවූ පසු * දර්ශකය යාවත්කාලීන කරන්න.
                // දර්ශකය කලින් යාවත්කාලීන කර panics පුරෝකථනය කළහොත්, මෙම දර්ශකයේ මූලද්‍රව්‍යය කාන්දු වේ.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // මෙය ඉතා අවුල් සහගත තත්වයක් වන අතර ඇත්ත වශයෙන්ම නිවැරදිව කළ යුතු දෙයක් නොමැත.
                        // අපට දිගින් දිගටම `pred` ක්‍රියාත්මක කිරීමට උත්සාහ කිරීමට අවශ්‍ය නැත, එබැවින් අපි සැකසූ සියලුම අංග පසුපසට හරවා ඒවා තවමත් පවතින බව දෛශිකයට පවසමු.
                        //
                        // පුරෝකථනයේ panic ට පෙර අවසන් වරට සාර්ථකව ජලය බැස යන අයිතමයේ දෙගුණයක් වැටීම වැළැක්වීම සඳහා පසු විපරම අවශ්‍ය වේ.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // පෙරහන් අනාවැකිය තවමත් භීතියට පත් නොවී ඇත්නම් ඉතිරිව ඇති මූලද්‍රව්‍ය පරිභෝජනය කිරීමට උත්සාහ කිරීම.
        // අප දැනටමත් භීතියට පත්වී ඇත්ද නැතහොත් මෙහි පරිභෝජනය panics වේවා ඉතිරිව ඇති ඕනෑම මූලද්‍රව්‍යයක් අපි ආපසු හරවන්නෙමු.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}