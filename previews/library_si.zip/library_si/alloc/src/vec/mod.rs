//! `Vec<T>` ලෙස ලියා ඇති ගොඩවල් වෙන් කළ අන්තර්ගතයන් සහිත පරස්පර වර්ධන කළ හැකි අරාව වර්ගයකි.
//!
//! Vectors සතුව `O(1)` සුචිගත කිරීම, ක්‍රමක්ෂය කළ `O(1)` තල්ලුව (අවසානය දක්වා) සහ `O(1)` පොප් (අවසානයේ සිට) ඇත.
//!
//!
//! Vectors ඔවුන් කිසි විටෙකත් `isize::MAX` බයිට් වලට වඩා වෙන් නොකරන බව සහතික කරයි.
//!
//! # Examples
//!
//! ඔබට පැහැදිලිවම [`Vec::new`] සමඟ [`Vec`] නිර්මාණය කළ හැකිය:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... හෝ [`vec!`] සාර්ව භාවිතා කිරීමෙන්:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // ශුන්‍ය දහයක්
//! ```
//!
//! ඔබට vector අවසානය දක්වා [`push`] අගයන් කළ හැකිය (අවශ්‍ය පරිදි vector වර්ධනය වේ):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! පොපිං අගයන් එකම ආකාරයකින් ක්‍රියා කරයි:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors ද සුචිගත කිරීම සඳහා සහය දක්වයි ([`Index`] සහ [`IndexMut`] traits හරහා):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// `Vec<T>` ලෙස ලියා 'vector' ලෙස උච්චාරණය කළ හැකි පරස්පර වර්ධන අරා වර්ගයකි.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// ආරම්භය වඩාත් පහසු කිරීම සඳහා [`vec!`] මැක්‍රෝ සපයනු ලැබේ:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// දී ඇති අගයක් සහිත `Vec<T>` හි එක් එක් මූලද්‍රව්‍යය ආරම්භ කිරීමට ද එයට හැකිය.
/// වෙනම පියවරයන්හි වෙන් කිරීම සහ ආරම්භ කිරීම සිදු කිරීමට වඩා මෙය කාර්යක්ෂම විය හැකිය, විශේෂයෙන් vector ශුන්‍යයක් ආරම්භ කිරීමේදී:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // පහත දැක්වෙන්නේ සමාන නමුත් මන්දගාමී විය හැකි ය:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// වැඩි විස්තර සඳහා, [Capacity and Reallocation](#capacity-and-reallocation) බලන්න.
///
/// කාර්යක්ෂම තොගයක් ලෙස `Vec<T>` භාවිතා කරන්න:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // 3, 2, 1 මුද්‍රණය කරයි
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// `Vec` වර්ගය දර්ශක අනුව අගයන් වෙත ප්‍රවේශ වීමට ඉඩ සලසයි, මන්ද එය [`Index`] trait ක්‍රියාත්මක කරයි.උදාහරණයක් වඩාත් පැහැදිලි වනු ඇත:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // එය '2' දර්ශනය වේ
/// ```
///
/// කෙසේ වෙතත් ප්‍රවේශම් වන්න: ඔබ `Vec` හි නොමැති දර්ශකයකට ප්‍රවේශ වීමට උත්සාහ කරන්නේ නම්, ඔබේ මෘදුකාංගය panic වනු ඇත!ඔබට මෙය කළ නොහැක:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// දර්ශකය `Vec` හි තිබේදැයි පරීක්ෂා කිරීමට ඔබට අවශ්‍ය නම් [`get`] සහ [`get_mut`] භාවිතා කරන්න.
///
/// # Slicing
///
/// `Vec` විකෘති විය හැකිය.අනෙක් අතට, පෙති කියවීමට පමණක් ඇති වස්තු වේ.
/// [slice][prim@slice] ලබා ගැනීමට, [`&`] භාවිතා කරන්න.උදාහරණයක්:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... එපමණයි!
/// // ඔබටත් මේ ආකාරයට කළ හැකිය:
/// let u: &[usize] = &v;
/// // හෝ මේ වගේ:
/// let u: &[_] = &v;
/// ```
///
/// Rust හි, ඔබට කියවීමේ ප්‍රවේශය ලබා දීමට අවශ්‍ය වූ විට පෙති vectors වෙනුවට තර්ක ලෙස සම්මත කිරීම සාමාන්‍ය දෙයකි.[`String`] සහ [`&str`] සඳහාද එයම වේ.
///
/// # ධාරිතාව සහ නැවත වෙන් කිරීම
///
/// vector හි ධාරිතාව යනු ඕනෑම future මූලද්‍රව්‍ය සඳහා වෙන් කර ඇති ඉඩ ප්‍රමාණය vector වෙත එකතු කරනු ලැබේ.මෙය vector හි *දිග* සමඟ පටලවා නොගත යුතු අතර, එය vector තුළ ඇති සත්‍ය මූලද්‍රව්‍ය ගණන නියම කරයි.
/// vector හි දිග එහි ධාරිතාව ඉක්මවා ගියහොත්, එහි ධාරිතාව ස්වයංක්‍රීයව වැඩි වනු ඇත, නමුත් එහි මූලද්‍රව්‍ය නැවත වෙන් කළ යුතුය.
///
/// උදාහරණයක් ලෙස, ධාරිතාව 10 සහ දිග 0 සහිත vector තවත් මූලද්‍රව්‍ය 10 ක් සඳහා ඉඩකඩ සහිත හිස් vector වේ.vector වෙත මූලද්‍රව්‍ය 10 ක් හෝ ඊට අඩු ප්‍රමාණයක් තල්ලු කිරීමෙන් එහි ධාරිතාව වෙනස් නොවේ.
/// කෙසේ වෙතත්, vector හි දිග 11 දක්වා වැඩි කළ හොත් එය නැවත ස්ථානගත කිරීමට සිදුවනු ඇත, එය මන්දගාමී විය හැකිය.මෙම හේතුව නිසා, හැකි සෑම විටම vector ලබා ගැනීමට අපේක්ෂා කරන ප්‍රමාණය නියම කිරීමට [`Vec::with_capacity`] භාවිතා කිරීම රෙකමදාරු කරනු ලැබේ.
///
/// # Guarantees
///
/// `Vec` එහි ඇදහිය නොහැකි තරම් මූලික ස්වභාවය නිසා එහි සැලසුම පිළිබඳව විශාල සහතිකයක් ලබා දෙයි.මෙය සාමාන්‍ය නඩුවේදී හැකි තරම් අඩු මට්ටමක පවතින බව සහතික කරන අතර අනාරක්ෂිත කේත මඟින් ප්‍රාථමික ආකාරවලින් නිවැරදිව හැසිරවිය හැකිය.මෙම ඇපකරයන් සුදුසුකම් නොලත් `Vec<T>` වෙත යොමු වන බව සලකන්න.
/// අතිරේක වර්ග පරාමිතීන් එකතු කර ඇත්නම් (උදා: අභිරුචි විබෙදන්නන්ට සහය දැක්වීම සඳහා), ඒවායේ පෙරනිමි ඉක්මවා යාමෙන් හැසිරීම වෙනස් විය හැකිය.
///
/// වඩාත් මූලික වශයෙන්, `Vec` යනු සෑම විටම (දර්ශකය, ධාරිතාව, දිග) ත්‍රිත්වයකි.තවත් නැත, අඩු නොවේ.මෙම ක්ෂේත්‍රවල අනුපිළිවෙල මුළුමනින්ම නිශ්චිතව දක්වා නොමැති අතර මේවා වෙනස් කිරීමට ඔබ සුදුසු ක්‍රම භාවිතා කළ යුතුය.
/// දර්ශකය කිසි විටෙකත් ශුන්‍ය නොවනු ඇත, එබැවින් මෙම වර්ගය ශුන්‍ය-දර්ශක-ප්‍රශස්තිකරණය කර ඇත.
///
/// කෙසේ වෙතත්, දර්ශකය ඇත්ත වශයෙන්ම වෙන් කළ මතකය වෙත යොමු නොවනු ඇත.
/// විශේෂයෙන්, ඔබ [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`] හරහා ධාරිතාව 0 සහිත `Vec` සාදන්නේ නම් හෝ හිස් Vec එකකට [`shrink_to_fit`] ඇමතීමෙන් එය මතකය වෙන් නොකරනු ඇත.ඒ හා සමානව, ඔබ `Vec` තුළ ශුන්‍ය ප්‍රමාණයේ වර්ග ගබඩා කරන්නේ නම්, එය ඔවුන් සඳහා ඉඩ වෙන් නොකරයි.
/// *මෙම අවස්ථාවේදී `Vec` හි [`capacity`] 0* වාර්තා නොකරන බව සලකන්න.
/// `Vec` වෙන් කරන්නේ නම් සහ [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// පොදුවේ ගත් කල, `Vec` හි ප්‍රතිපාදන විස්තර ඉතා සියුම් ය-ඔබ `Vec` භාවිතා කරමින් මතකය වෙන් කර වෙනත් දෙයක් සඳහා භාවිතා කිරීමට අදහස් කරන්නේ නම් (එක්කෝ අනාරක්ෂිත කේතයකට යැවීමට හෝ ඔබේම මතක ආධාරක එකතුවක් තැනීමට), වග බලා ගන්න `Vec` යථා තත්වයට පත් කිරීම සඳහා `from_raw_parts` භාවිතා කර එය අතහැර දැමීමෙන් මෙම මතකය අවලංගු කිරීමට.
///
/// `Vec`*ට* මතකය වෙන් කර ඇත්නම්, එය පෙන්වා දෙන මතකය ගොඩවල් මත වේ (විබෙදුම්කරු Rust විසින් අර්ථ දක්වා ඇති පරිදි පෙරනිමියෙන් භාවිතා කිරීමට වින්‍යාස කර ඇත), සහ එහි දර්ශකය [`len`] ආරම්භක, පරස්පර මූලද්‍රව්‍ය අනුපිළිවෙලට යොමු කරයි (ඔබ කුමක් කරයිද? ඔබ එය පෙත්තකට බල කළේ දැයි බලන්න), ඉන්පසු [`ධාරිතාව`],`[`ලෙන්]] තාර්කිකව ආරම්භ නොකළ, පරස්පර මූලද්‍රව්‍ය.
///
///
/// ධාරිතාව 4 සහිත `'a'` සහ `'b'` මූලද්‍රව්‍ය අඩංගු vector පහත පරිදි දෘශ්‍යමාන කළ හැකිය.ඉහළ කොටස `Vec` ව්‍යුහය වන අතර, එහි ගොඩවල්, දිග සහ ධාරිතාවය වෙන් කිරීමේදී ප්‍රධානියාට දර්ශකයක් අඩංගු වේ.
/// පහළම කොටස වන්නේ ගොඩවල් මත වෙන් කිරීම, පරස්පර මතක කොටසකි.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** නිරූපණය නොකෙරෙන මතකය නියෝජනය කරයි, [`MaybeUninit`] බලන්න.
/// - Note: ABI ස්ථායී නොවන අතර `Vec` එහි මතක සැකැස්ම පිළිබඳව කිසිදු සහතිකයක් ලබා නොදේ (ක්ෂේත්‍ර අනුපිළිවෙලද ඇතුළුව).
///
/// `Vec` හේතු දෙකක් නිසා මූලද්‍රව්‍ය තොගයේ ගබඩා කර ඇති "small optimization" කිසි විටෙකත් සිදු නොකරනු ඇත:
///
/// * අනාරක්ෂිත කේතයකට `Vec` නිවැරදිව හැසිරවීම වඩාත් අපහසු වනු ඇත.`Vec` හි අන්තර්ගතය ගෙන ගියහොත් පමණක් ස්ථාවර ලිපිනයක් නොතිබෙනු ඇති අතර, `Vec` ඇත්ත වශයෙන්ම මතකය වෙන් කර තිබේද යන්න තීරණය කිරීම වඩාත් අපහසු වනු ඇත.
///
/// * එය සාමාන්‍ය නඩුවට ද ize ුවම් කරනු ඇති අතර සෑම ප්‍රවේශයක් සඳහාම අතිරේක branch දරයි.
///
/// `Vec` සම්පූර්ණයෙන්ම හිස් වුවද, කිසි විටෙකත් ස්වයංක්‍රීයව හැකිලෙන්නේ නැත.අනවශ්‍ය ප්‍රතිපාදන හෝ බෙදා හැරීම් සිදු නොවන බවට මෙය සහතික කරයි.`Vec` හිස් කර නැවත එම [`len`] දක්වා පුරවා ගැනීමෙන් විබෙදන්නාට ඇමතුම් නොලැබේ.භාවිතයට නොගත් මතකය නිදහස් කිරීමට ඔබට අවශ්‍ය නම්, [`shrink_to_fit`] හෝ [`shrink_to`] භාවිතා කරන්න.
///
/// [`push`] සහ වාර්තා කරන ලද ධාරිතාව ප්‍රමාණවත් නම් [`insert`] කිසි විටෙකත් (නැවත) වෙන් නොකරනු ඇත.[`ලෙන්`]`==`[`ධාරිතාව`] නම් [`push`] සහ [`insert`] * වෙන් කරනු ඇත.එනම්, වාර්තා කරන ලද ධාරිතාව සම්පූර්ණයෙන්ම නිවැරදි වන අතර එය මත විශ්වාසය තැබිය හැකිය.අවශ්‍ය නම් `Vec` මගින් වෙන් කරන ලද මතකය අතින් නිදහස් කිරීමට පවා එය භාවිතා කළ හැකිය.
/// තොග ඇතුළත් කිරීමේ ක්‍රම * අවශ්‍ය නොවන විටදී පවා නැවත වෙන්කරවා ගත හැකිය.
///
/// `Vec` සම්පුර්ණ වූ විට හෝ [`reserve`] ලෙස හැඳින්වූ විට නැවත වෙන් කිරීමේදී නිශ්චිත වර්ධන උපාය මාර්ගයක් සහතික නොවේ.වර්තමාන උපායමාර්ගය මූලික වන අතර එය නියත නොවන වර්ධන සාධකයක් භාවිතා කිරීම යෝග්‍ය වේ.කුමන උපාය මාර්ගයක් භාවිතා කළත් ඇත්ත වශයෙන්ම *O*(1) ක්‍රමක්ෂය කළ [`push`] සහතික කරනු ඇත.
///
/// `vec![x; n]`, `vec![a, b, c, d]`, සහ [`Vec::with_capacity(n)`][`Vec::with_capacity`], සියල්ලම ඉල්ලූ ධාරිතාවයෙන් `Vec` නිපදවනු ඇත.
/// [`ලෙන්`]`==`[`ධාරිතාව`], ([`vec!`] මැක්‍රෝ සඳහා මෙන්ම), එවිට `Vec<T>` මූලද්‍රව්‍ය නැවත වෙන් කිරීම හෝ චලනය නොකොට [`Box<[T]>`][owned slice] වෙත සහ ඉන් පිටතට පරිවර්තනය කළ හැකිය.
///
/// `Vec` එයින් ඉවත් කරන ලද කිසිදු දත්තයක් නැවත ලියන්නේ නැත, නමුත් එය විශේෂයෙන් ආරක්ෂා නොකරනු ඇත.එහි ආරම්භක මතකය සීරීම් අවකාශය වන අතර එය අවශ්‍ය පරිදි භාවිතා කළ හැකිය.එය සාමාන්‍යයෙන් වඩාත් කාර්යක්ෂම හෝ වෙනත් ආකාරයකින් ක්‍රියාත්මක කිරීමට පහසු ඕනෑම දෙයක් කරනු ඇත.ආරක්ෂක අරමුණු සඳහා මකා දැමිය යුතු ඉවත් කළ දත්ත මත රඳා නොසිටින්න.
/// ඔබ `Vec` අතහැර දැමුවද, එහි බෆරය වෙනත් `Vec` විසින් නැවත භාවිතා කළ හැකිය.
/// ඔබ මුලින්ම 'Vec' මතකය ශුන්‍ය කළත්, එය සත්‍ය වශයෙන්ම සිදු නොවිය හැකි බැවින් මෙය ආරක්ෂා කළ යුතු අතුරු ආබාධයක් ලෙස ප්‍රශස්තකරණය නොසලකයි.
/// කෙසේ වෙතත්, අප කඩ නොකරන එක් අවස්ථාවක් තිබේ: කෙසේ වෙතත්, අතිරික්ත ධාරිතාවට ලිවීමට `unsafe` කේතය භාවිතා කිරීම, පසුව ගැලපෙන දිග වැඩි කිරීම සැමවිටම වලංගු වේ.
///
/// දැනට, `Vec` මූලද්රව්ය අතහැර දැමූ අනුපිළිවෙල සහතික නොකරයි.
/// ඇණවුම අතීතයේ වෙනස් වී ඇති අතර නැවත වෙනස් විය හැකිය.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// ආවේනික ක්‍රම
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// නව හිස් `Vec<T>` සාදයි.
    ///
    /// මූලද්‍රව්‍ය ඒ මතට තල්ලු වන තුරු vector වෙන් නොකරනු ඇත.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// නිශ්චිත ධාරිතාවයෙන් නව හිස් `Vec<T>` සාදයි.
    ///
    /// vector හට නැවත වෙන් කිරීමකින් තොරව හරියටම `capacity` මූලද්‍රව්‍ය රඳවා ගැනීමට හැකි වේ.
    /// `capacity` 0 නම්, vector වෙන් නොකරයි.
    ///
    /// ආපසු ලබා දුන් vector හි *ධාරිතාව* නියම කර තිබුණද, vector හි ශුන්‍ය *දිග* ඇති බව සැලකිල්ලට ගැනීම වැදගත්ය.
    ///
    /// දිග සහ ධාරිතාව අතර වෙනස පැහැදිලි කිරීම සඳහා,*[ධාරිතාව සහ නැවත වෙන් කිරීම]* බලන්න.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector හි වැඩි අයිතමයක් තිබුණද එහි කිසිදු අයිතමයක් නොමැත
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // මේ සියල්ල නැවත වෙන් කිරීමකින් තොරව සිදු කෙරේ ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... නමුත් මෙය vector නැවත ස්ථානගත කිරීමට හේතු වේ
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// වෙනත් vector හි අමු සංරචක වලින් කෙලින්ම `Vec<T>` සාදයි.
    ///
    /// # Safety
    ///
    /// පරීක්ෂා නොකරන ලද ආක්‍රමණ ගණන නිසා මෙය බෙහෙවින් අනාරක්ෂිත ය:
    ///
    /// * `ptr` මීට පෙර [`String`]/`Vec හරහා වෙන් කර තිබිය යුතුය<T>`(අවම වශයෙන්, එය එසේ නොවේ නම් එය බොහෝ දුරට වැරදියි).
    /// * `T` `ptr` වෙන් කර ඇති ප්‍රමාණයට සමාන ප්‍රමාණයක් හා පෙළගැස්මක් තිබිය යුතුය.
    ///   (අඩු තදබල පෙළගැස්මක් ඇති `T` ප්‍රමාණවත් නොවේ, මතකය වෙන් කර එකම පිරිසැලසුමක් සමඟ බෙදා හැරිය යුතුය යන [`dealloc`] අවශ්‍යතාව සපුරාලීම සඳහා පෙළගැස්ම සැබවින්ම සමාන විය යුතුය.)
    ///
    /// * `length` `capacity` ට වඩා අඩු හෝ සමාන විය යුතුය.
    /// * `capacity` දර්ශකය වෙන් කළ ධාරිතාව විය යුතුය.
    ///
    /// මේවා උල්ලං ting නය කිරීම මඟින් විබෙදන්නාගේ අභ්‍යන්තර දත්ත ව්‍යුහයන් දූෂණය කිරීම වැනි ගැටළු ඇති විය හැකිය.උදාහරණයක් ලෙස, `Vec<u8>` දිග `size_t` සහිත C `char` අරාවකට දර්ශකය සිට `Vec<u8>` සෑදීම ** ආරක්ෂිත නොවේ.
    /// `Vec<u16>` සහ එහි දිගින් එකක් සෑදීමද ආරක්ෂිත නොවේ, මන්දයත්, විබෙදන්නා පෙළගැස්ම ගැන සැලකිලිමත් වන අතර මෙම වර්ග දෙක එකිනෙකට වෙනස් පෙළගැස්වීම් ඇත.
    /// බෆරය පෙළගැස්වීම 2 (`u16` සඳහා) සමඟ වෙන් කර ඇත, නමුත් එය `Vec<u8>` බවට පත් කිරීමෙන් පසුව එය පෙළගැස්ම 1 සමඟ විස්ථාපනය වේ.
    ///
    /// `ptr` හි හිමිකාරිත්වය `Vec<T>` වෙත effectively ලදායී ලෙස මාරු කරනු ලබන අතර එමඟින් අවශ්‍ය පරිදි දර්ශකය විසින් පෙන්වා දෙන මතකයේ අන්තර්ගතය නැවත ස්ථානගත කිරීම, නැවත වෙන් කිරීම හෝ වෙනස් කිරීම සිදු කළ හැකිය.
    /// මෙම ශ්‍රිතය ඇමතීමෙන් පසුව වෙනත් කිසිවක් දර්ශකය භාවිතා නොකරන බවට සහතික වන්න.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME vec_into_raw_parts ස්ථාවර වූ විට මෙය යාවත්කාලීන කරන්න.
    ///     // `V` හි විනාශකාරකය ධාවනය කිරීම වලක්වන්න, එවිට අපට ප්‍රතිපාදන සම්පූර්ණයෙන් පාලනය කළ හැකිය.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // `v` පිළිබඳ විවිධ වැදගත් තොරතුරු අදින්න
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // මතකය 4, 5, 6 සමඟ නැවත ලියන්න
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // සියල්ල නැවත Vec එකකට දමන්න
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// නව හිස් `Vec<T, A>` සාදයි.
    ///
    /// මූලද්‍රව්‍ය ඒ මතට තල්ලු වන තුරු vector වෙන් නොකරනු ඇත.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// සපයා ඇති විබෙදන්නා සමඟ නිශ්චිත ධාරිතාවයෙන් නව හිස් `Vec<T, A>` සාදයි.
    ///
    /// vector හට නැවත වෙන් කිරීමකින් තොරව හරියටම `capacity` මූලද්‍රව්‍ය රඳවා ගැනීමට හැකි වේ.
    /// `capacity` 0 නම්, vector වෙන් නොකරයි.
    ///
    /// ආපසු ලබා දුන් vector හි *ධාරිතාව* නියම කර තිබුණද, vector හි ශුන්‍ය *දිග* ඇති බව සැලකිල්ලට ගැනීම වැදගත්ය.
    ///
    /// දිග සහ ධාරිතාව අතර වෙනස පැහැදිලි කිරීම සඳහා,*[ධාරිතාව සහ නැවත වෙන් කිරීම]* බලන්න.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector හි වැඩි අයිතමයක් තිබුණද එහි කිසිදු අයිතමයක් නොමැත
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // මේ සියල්ල නැවත වෙන් කිරීමකින් තොරව සිදු කෙරේ ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... නමුත් මෙය vector නැවත ස්ථානගත කිරීමට හේතු වේ
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// වෙනත් vector හි අමු සංරචක වලින් කෙලින්ම `Vec<T, A>` සාදයි.
    ///
    /// # Safety
    ///
    /// පරීක්ෂා නොකරන ලද ආක්‍රමණ ගණන නිසා මෙය බෙහෙවින් අනාරක්ෂිත ය:
    ///
    /// * `ptr` මීට පෙර [`String`]/`Vec හරහා වෙන් කර තිබිය යුතුය<T>`(අවම වශයෙන්, එය එසේ නොවේ නම් එය බොහෝ දුරට වැරදියි).
    /// * `T` `ptr` වෙන් කර ඇති ප්‍රමාණයට සමාන ප්‍රමාණයක් හා පෙළගැස්මක් තිබිය යුතුය.
    ///   (අඩු තදබල පෙළගැස්මක් ඇති `T` ප්‍රමාණවත් නොවේ, මතකය වෙන් කර එකම පිරිසැලසුමක් සමඟ බෙදා හැරිය යුතුය යන [`dealloc`] අවශ්‍යතාව සපුරාලීම සඳහා පෙළගැස්ම සැබවින්ම සමාන විය යුතුය.)
    ///
    /// * `length` `capacity` ට වඩා අඩු හෝ සමාන විය යුතුය.
    /// * `capacity` දර්ශකය වෙන් කළ ධාරිතාව විය යුතුය.
    ///
    /// මේවා උල්ලං ting නය කිරීම මඟින් විබෙදන්නාගේ අභ්‍යන්තර දත්ත ව්‍යුහයන් දූෂණය කිරීම වැනි ගැටළු ඇති විය හැකිය.උදාහරණයක් ලෙස, `Vec<u8>` දිග `size_t` සහිත C `char` අරාවකට දර්ශකය සිට `Vec<u8>` සෑදීම ** ආරක්ෂිත නොවේ.
    /// `Vec<u16>` සහ එහි දිගින් එකක් සෑදීමද ආරක්ෂිත නොවේ, මන්දයත්, විබෙදන්නා පෙළගැස්ම ගැන සැලකිලිමත් වන අතර මෙම වර්ග දෙක එකිනෙකට වෙනස් පෙළගැස්වීම් ඇත.
    /// බෆරය පෙළගැස්වීම 2 (`u16` සඳහා) සමඟ වෙන් කර ඇත, නමුත් එය `Vec<u8>` බවට පත් කිරීමෙන් පසුව එය පෙළගැස්ම 1 සමඟ විස්ථාපනය වේ.
    ///
    /// `ptr` හි හිමිකාරිත්වය `Vec<T>` වෙත effectively ලදායී ලෙස මාරු කරනු ලබන අතර එමඟින් අවශ්‍ය පරිදි දර්ශකය විසින් පෙන්වා දෙන මතකයේ අන්තර්ගතය නැවත ස්ථානගත කිරීම, නැවත වෙන් කිරීම හෝ වෙනස් කිරීම සිදු කළ හැකිය.
    /// මෙම ශ්‍රිතය ඇමතීමෙන් පසුව වෙනත් කිසිවක් දර්ශකය භාවිතා නොකරන බවට සහතික වන්න.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME vec_into_raw_parts ස්ථාවර වූ විට මෙය යාවත්කාලීන කරන්න.
    ///     // `V` හි විනාශකාරකය ධාවනය කිරීම වලක්වන්න, එවිට අපට ප්‍රතිපාදන සම්පූර්ණයෙන් පාලනය කළ හැකිය.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // `v` පිළිබඳ විවිධ වැදගත් තොරතුරු අදින්න
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // මතකය 4, 5, 6 සමඟ නැවත ලියන්න
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // සියල්ල නැවත Vec එකකට දමන්න
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// `Vec<T>` එහි අමු සංරචක වලට දිරාපත් කරයි.
    ///
    /// අමු දර්ශකය යටින් පවතින දත්ත, vector (මූලද්‍රව්‍ය වලින්) සහ දත්තවල වෙන් කළ ධාරිතාව (මූලද්‍රව්‍ය වලින්) ලබා දෙයි.
    /// මේවා [`from_raw_parts`] සඳහා වන තර්ක මෙන් එකම අනුපිළිවෙලෙහි ඇති තර්ක වේ.
    ///
    /// මෙම ශ්‍රිතය ඇමතීමෙන් පසුව, `Vec` විසින් කලින් කළමනාකරණය කරන ලද මතකය සඳහා අමතන්නා වගකිව යුතුය.
    /// මෙය කළ හැකි එකම ක්‍රමය වන්නේ අමු දර්ශකය, දිග සහ ධාරිතාව [`from_raw_parts`] ශ්‍රිතය සමඟ නැවත `Vec` බවට පරිවර්තනය කිරීම, විනාශ කරන්නාට පිරිසිදු කිරීම සිදු කිරීමට ඉඩ දීමයි.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // අමු දර්ශකය අනුකූල වර්ගයකට සම්ප්‍රේෂණය කිරීම වැනි සංරචකවල අපට දැන් වෙනස්කම් කළ හැකිය.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// `Vec<T>` එහි අමු සංරචක වලට දිරාපත් කරයි.
    ///
    /// අමු දර්ශකය යටින් පවතින දත්ත, vector (මූලද්‍රව්‍ය වලින්), දත්තවල වෙන් කළ ධාරිතාව (මූලද්‍රව්‍ය වලින්) සහ විබෙදන්නා වෙත යවයි.
    /// මේවා [`from_raw_parts_in`] සඳහා වන තර්ක මෙන් එකම අනුපිළිවෙලෙහි ඇති තර්ක වේ.
    ///
    /// මෙම ශ්‍රිතය ඇමතීමෙන් පසුව, `Vec` විසින් කලින් කළමනාකරණය කරන ලද මතකය සඳහා අමතන්නා වගකිව යුතුය.
    /// මෙය කළ හැකි එකම ක්‍රමය වන්නේ අමු දර්ශකය, දිග සහ ධාරිතාව [`from_raw_parts_in`] ශ්‍රිතය සමඟ නැවත `Vec` බවට පරිවර්තනය කිරීම, විනාශ කරන්නාට පිරිසිදු කිරීම සිදු කිරීමට ඉඩ දීමයි.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // අමු දර්ශකය අනුකූල වර්ගයකට සම්ප්‍රේෂණය කිරීම වැනි සංරචකවල අපට දැන් වෙනස්කම් කළ හැකිය.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// නැවත වෙන් කිරීමකින් තොරව vector රඳවා තබා ගත හැකි මූලද්‍රව්‍ය ගණන ලබා දෙයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// ලබා දී ඇති `Vec<T>` තුළ අවම වශයෙන් `additional` වැඩි මූලද්‍රව්‍යයක් ඇතුළත් කිරීමට සංචිත ධාරිතාව.
    /// නිරන්තරයෙන් නැවත ස්ථානගත කිරීම වළක්වා ගැනීම සඳහා එකතු කිරීමට වැඩි ඉඩක් වෙන් කළ හැකිය.
    /// `reserve` ඇමතීමෙන් පසු, ධාරිතාව `self.len() + additional` ට වඩා වැඩි හෝ සමාන වේ.
    /// ධාරිතාව දැනටමත් ප්රමාණවත් නම් කිසිවක් නොකරයි.
    ///
    /// # Panics
    ///
    /// නව ධාරිතාව `isize::MAX` බයිට් ඉක්මවන්නේ නම් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// දී ඇති `Vec<T>` තුළ තවත් මූලද්‍රව්‍යයන් ඇතුළත් කිරීමට අවම ධාරිතාවය හරියටම `additional` සඳහා වෙන් කර ඇත.
    ///
    /// `reserve_exact` ඇමතීමෙන් පසු, ධාරිතාව `self.len() + additional` ට වඩා වැඩි හෝ සමාන වේ.
    /// ධාරිතාව දැනටමත් ප්රමාණවත් නම් කිසිවක් නොකරයි.
    ///
    /// වෙන් කරන්නා එකතු කිරීමට ඉල්ලීමට වඩා වැඩි ඉඩක් ලබා දෙන බව සලකන්න.
    /// එබැවින් ධාරිතාවය අවම වශයෙන් රඳා පැවතිය නොහැක.
    /// future ඇතුළු කිරීම් අපේක්ෂා කරන්නේ නම් `reserve` ට වැඩි කැමැත්තක් දක්වන්න.
    ///
    /// # Panics
    ///
    /// නව ධාරිතාව `usize` ඉක්මවා ගියහොත් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// ලබා දී ඇති `Vec<T>` තුළ අවම වශයෙන් `additional` වැඩි මූලද්‍රව්‍යයක් ඇතුළත් කිරීමට ධාරිතාව වෙන් කර ගැනීමට උත්සාහ කරයි.
    /// නිරන්තරයෙන් නැවත ස්ථානගත කිරීම වළක්වා ගැනීම සඳහා එකතු කිරීමට වැඩි ඉඩක් වෙන් කළ හැකිය.
    /// `try_reserve` ඇමතීමෙන් පසු, ධාරිතාව `self.len() + additional` ට වඩා වැඩි හෝ සමාන වේ.
    /// ධාරිතාව දැනටමත් ප්රමාණවත් නම් කිසිවක් නොකරයි.
    ///
    /// # Errors
    ///
    /// ධාරිතාව පිටාර ගැලීම හෝ විබෙදන්නා අසමත් වීමක් වාර්තා කරන්නේ නම් දෝෂයක් නැවත ලබා දෙනු ලැබේ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // මතකය කලින් වෙන් කරවා ගන්න, අපට නොහැකි නම් පිටවීම
    ///     output.try_reserve(data.len())?;
    ///
    ///     // දැන් අපි දන්නවා අපේ සංකීර්ණ වැඩ මැද මෙය OOM කළ නොහැකි බව
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // ඉතා සංකීර්ණයි
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// දී ඇති `Vec<T>` තුළ හරියටම ඇතුළත් කළ යුතු `additional` මූලද්‍රව්‍ය සඳහා අවම ධාරිතාව වෙන් කර ගැනීමට උත්සාහ කරයි.
    /// `try_reserve_exact` ඇමතීමෙන් පසු, ධාරිතාව `Ok(())` නැවත ලබා දෙන්නේ නම් එය `self.len() + additional` ට වඩා වැඩි හෝ සමාන වේ.
    ///
    /// ධාරිතාව දැනටමත් ප්රමාණවත් නම් කිසිවක් නොකරයි.
    ///
    /// වෙන් කරන්නා එකතු කිරීමට ඉල්ලීමට වඩා වැඩි ඉඩක් ලබා දෙන බව සලකන්න.
    /// එබැවින් ධාරිතාවය අවම වශයෙන් රඳා පැවතිය නොහැක.
    /// future ඇතුළු කිරීම් අපේක්ෂා කරන්නේ නම් `reserve` ට වැඩි කැමැත්තක් දක්වන්න.
    ///
    /// # Errors
    ///
    /// ධාරිතාව පිටාර ගැලීම හෝ විබෙදන්නා අසමත් වීමක් වාර්තා කරන්නේ නම් දෝෂයක් නැවත ලබා දෙනු ලැබේ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // මතකය කලින් වෙන් කරවා ගන්න, අපට නොහැකි නම් පිටවීම
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // දැන් අපි දන්නවා අපේ සංකීර්ණ වැඩ මැද මෙය OOM කළ නොහැකි බව
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // ඉතා සංකීර්ණයි
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// vector හි ධාරිතාව හැකිතාක් හැකිලී යයි.
    ///
    /// එය දිගට හැකි තරම් පහළට වැටෙනු ඇත, නමුත් තවත් මූලද්‍රව්‍ය කිහිපයක් සඳහා ඉඩකඩ ඇති බව විබෙදන්නා විසින් vector වෙත දැනුම් දෙනු ඇත.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // ධාරිතාව කිසි විටෙකත් දිගට වඩා අඩු නොවන අතර ඒවා සමාන වන විට කළ යුතු කිසිවක් නැත, එබැවින් අපට `RawVec::shrink_to_fit` හි panic නඩුව වළක්වා ගත හැක්කේ එය වැඩි ධාරිතාවයකින් ඇමතීමෙන් පමණි.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// vector හි ධාරිතාව අඩු මායිමකින් හැකිලී යයි.
    ///
    /// ධාරිතාව දිග හා සැපයූ වටිනාකම යන දෙකම තරම් අවම වශයෙන් පවතිනු ඇත.
    ///
    ///
    /// වත්මන් ධාරිතාව පහළ සීමාවට වඩා අඩු නම්, මෙය විකල්පයක් නොවේ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// vector [`Box<[T]>`][owned slice] බවට පරිවර්තනය කරයි.
    ///
    /// මෙය ඕනෑම අතිරික්ත ධාරිතාවක් පහත හෙලන බව සලකන්න.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// ඕනෑම අතිරික්ත ධාරිතාවක් ඉවත් කරනු ලැබේ:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// vector කෙටි කරයි, පළමු `len` මූලද්‍රව්‍ය තබාගෙන ඉතිරිය අතහැර දමයි.
    ///
    /// `len` vector හි වත්මන් දිගට වඩා වැඩි නම්, මෙය කිසිදු බලපෑමක් ඇති නොකරයි.
    ///
    /// [`drain`] ක්‍රමයට `truncate` අනුකරණය කළ හැකි නමුත් අතිරික්ත මූලද්‍රව්‍ය අතහැර දැමීම වෙනුවට ආපසු ලබා දේ.
    ///
    ///
    /// මෙම ක්‍රමය vector හි වෙන් කළ ධාරිතාවට කිසිදු බලපෑමක් නොකරන බව සලකන්න.
    ///
    /// # Examples
    ///
    /// vector මූලද්‍රව්‍ය පහක් මූලද්‍රව්‍ය දෙකකට කපා දැමීම:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// `len` vector හි වත්මන් දිගට වඩා වැඩි වූ විට කිසිදු කප්පාදුවක් සිදු නොවේ:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// `len == 0` යනු [`clear`] ක්‍රමය ඇමතීමට සමාන වන විට කප්පාදු කිරීම.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // මෙය ආරක්ෂිත නිසා:
        //
        // * `drop_in_place` වෙත ලබා දුන් පෙත්ත වලංගු වේ;`len > self.len` නඩුව අවලංගු පෙත්තක් සෑදීම වළක්වයි, සහ
        // * `drop_in_place` ඇමතීමට පෙර vector හි `len` හැකිලී ඇත, එනම් `drop_in_place` එක් වරක් panic වෙත ගියහොත් කිසිදු අගයක් දෙවරක් පහත වැටෙන්නේ නැත (එය panics දෙවරක් නම්, වැඩසටහන අහෝසි වේ).
        //
        //
        //
        unsafe {
            // Note: මෙය හිතාමතාම මෙය `>` මිස `>=` නොවේ.
            //       එය `>=` වෙත වෙනස් කිරීම සමහර අවස්ථාවල negative ණාත්මක කාර්ය සාධන ඇඟවුම් ඇත.
            //       වැඩි විස්තර සඳහා #78884 බලන්න.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// මුළු vector අඩංගු පෙත්තක් උපුටා ගනී.
    ///
    /// `&s[..]` ට සමාන වේ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// සමස්ත vector හි විකෘති පෙත්තක් උපුටා ගනී.
    ///
    /// `&mut s[..]` ට සමාන වේ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// vector හි බෆරයට අමු දර්ශකයක් ලබා දෙයි.
    ///
    /// vector විසින් මෙම ශ්‍රිතය නැවත ලබා දෙන දර්ශකය ඉක්මවා යන බව ඇමතුම්කරු සහතික කළ යුතුය, එසේ නොමැති නම් එය කුණු කසළ වෙත යොමු වේ.
    /// vector වෙනස් කිරීම මඟින් එහි බෆරය නැවත ස්ථානගත කිරීමට හේතු විය හැකි අතර, එමඟින් ඕනෑම දර්ශකයක් අවලංගු වේ.
    ///
    /// මෙම දර්ශකය හෝ එයින් ලබාගත් ඕනෑම දර්ශකයක් භාවිතා කරමින් (non-transitively) දර්ශකය පෙන්වන මතකය කිසි විටෙකත් (`UnsafeCell` ඇතුළත හැර) ලියා නොමැති බව අමතන්නා සහතික කළ යුතුය.
    /// ඔබට පෙත්තෙහි අන්තර්ගතය විකෘති කිරීමට අවශ්‍ය නම්, [`as_mut_ptr`] භාවිතා කරන්න.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // `deref` හරහා යාම වළක්වා ගැනීම සඳහා අපි එකම නමේ පෙති ක්‍රමය සෙවනැල්ල කරන අතර එය අතරමැදි යොමු කිරීමක් නිර්මාණය කරයි.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// vector හි බෆරයට අනාරක්ෂිත විකෘති දර්ශකයක් ලබා දෙයි.
    ///
    /// vector විසින් මෙම ශ්‍රිතය නැවත ලබා දෙන දර්ශකය ඉක්මවා යන බව ඇමතුම්කරු සහතික කළ යුතුය, එසේ නොමැති නම් එය කුණු කසළ වෙත යොමු වේ.
    ///
    /// vector වෙනස් කිරීම මඟින් එහි බෆරය නැවත ස්ථානගත කිරීමට හේතු විය හැකි අතර, එමඟින් ඕනෑම දර්ශකයක් අවලංගු වේ.
    ///
    /// # Examples
    ///
    /// ```
    /// // මූලද්‍රව්‍ය 4 ක් සඳහා ප්‍රමාණවත් තරම් විශාල vector වෙන් කරන්න.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // අමු දර්ශක ලිවීම් හරහා මූලද්‍රව්‍ය ආරම්භ කරන්න, ඉන්පසු දිග සකසන්න.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // `deref_mut` හරහා යාම වළක්වා ගැනීම සඳහා අපි එකම නමේ පෙති ක්‍රමය සෙවනැල්ල කරන්නෙමු, එය අතරමැදි යොමු කිරීමක් නිර්මාණය කරයි.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// යටින් ඇති විබෙදන්නා වෙත යොමු කිරීමක් ලබා දෙයි.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// vector හි දිග `new_len` දක්වා බල කරයි.
    ///
    /// මෙය සාමාන්‍ය මට්ටමේ ආක්‍රමණ කිසිවක් නඩත්තු නොකරන පහත් මට්ටමේ මෙහෙයුමකි.
    /// සාමාන්‍යයෙන් vector හි දිග වෙනස් කිරීම සිදු කරනුයේ [`truncate`], [`resize`], [`extend`], හෝ [`clear`] වැනි ආරක්ෂිත මෙහෙයුම් වලින් එකක් භාවිතා කිරීමෙනි.
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` [`capacity()`] ට වඩා අඩු හෝ සමාන විය යුතුය.
    /// - `old_len..new_len` හි මූලද්‍රව්‍ය ආරම්භ කළ යුතුය.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// vector වෙනත් කේත සඳහා බෆරයක් ලෙස සේවය කරන අවස්ථාවන්ට, විශේෂයෙන් FFI හරහා මෙම ක්‍රමය ප්‍රයෝජනවත් වේ:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // මෙය ලේඛ ලේඛනයේ අවම ඇටසැකිල්ලක් පමණි;
    /// # // සැබෑ පුස්තකාලයක ආරම්භක ස්ථානයක් ලෙස මෙය භාවිතා නොකරන්න.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // FFI ක්‍රමයේ ලේඛනයට අනුව, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // ආරක්ෂාව: `deflateGetDictionary` `Z_OK` ආපසු ලබා දුන් විට, එය දරන්නේ:
    ///     // 1. `dict_length` මූලද්රව්ය ආරම්භ කරන ලදී.
    ///     // 2.
    ///     // `dict_length` <= (32_768) ධාරිතාව `set_len` ඇමතීමට ආරක්ෂිත කරයි.
    ///     unsafe {
    ///         // FFI ඇමතුම ලබා දෙන්න ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... සහ ආරම්භ කළ දෙයට දිග යාවත්කාලීන කරන්න.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// පහත දැක්වෙන උදාහරණය ශබ්දය වන අතර, `set_len` ඇමතුමට පෙර අභ්‍යන්තර vectors නිදහස් කර නොතිබූ බැවින් මතක කාන්දුවක් පවතී:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` කිසිදු හිස් මූලද්‍රව්‍යයක් ආරම්භ කිරීම අවශ්‍ය නොවේ.
    /// // 2. `0 <= capacity` සෑම විටම `capacity` ඕනෑම දෙයක් දරයි.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// සාමාන්‍යයෙන්, මෙහි දී යමෙක් [`clear`] වෙනුවට අන්තර්ගතය නිවැරදිව අතහැර දැමීමට භාවිතා කරන අතර එමඟින් මතකය කාන්දු නොවේ.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// vector වෙතින් මූලද්‍රව්‍යයක් ඉවත් කර එය නැවත ලබා දෙයි.
    ///
    /// ඉවත් කරන ලද මූලද්‍රව්‍යය vector හි අවසාන මූලද්‍රව්‍යය මගින් ප්‍රතිස්ථාපනය වේ.
    ///
    /// මෙය ඇණවුම් කිරීම ආරක්ෂා නොකරයි, නමුත් O(1) වේ.
    ///
    /// # Panics
    ///
    /// `index` සීමාවෙන් පිටත නම් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // අපි ස්වයං [දර්ශකය] අන්තිම මූලද්‍රව්‍යය සමඟ ප්‍රතිස්ථාපනය කරමු.
            // ඉහත සීමාවන් පරීක්ෂා කිරීම සාර්ථක වුවහොත් අවසාන අංගයක් තිබිය යුතු බව සලකන්න (එය ස්වයං [දර්ශකය] විය හැකිය).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// vector තුළ `index` ස්ථානයේ මූලද්‍රව්‍යයක් ඇතුල් කරයි, ඉන්පසු සියලු මූලද්‍රව්‍යයන් දකුණට මාරු කරයි.
    ///
    ///
    /// # Panics
    ///
    /// `index > len` නම් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // නව මූලද්රව්යය සඳහා අවකාශය
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // වැරදිසහගත නව අගය තැබිය යුතු ස්ථානය
            //
            {
                let p = self.as_mut_ptr().add(index);
                // අවකාශය සෑදීම සඳහා සියල්ල මාරු කරන්න.
                // (දර්ශකයේ` මූලද්‍රව්‍යය අඛණ්ඩව ස්ථාන දෙකකට අනුපිටපත් කිරීම.)
                ptr::copy(p, p.offset(1), len - index);
                // `දර්ශකයේ` මූලද්‍රව්‍යයේ පළමු පිටපත නැවත ලියමින් එය ලියන්න.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// vector තුළ `index` ස්ථානයේ ඇති මූලද්‍රව්‍යය ඉවත් කර ආපසු ලබා දෙයි, ඉන්පසු සියලු මූලද්‍රව්‍යයන් වමට මාරු කරයි.
    ///
    ///
    /// # Panics
    ///
    /// `index` සීමාවෙන් පිටත නම් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // අපි ගන්න තැන.
                let ptr = self.as_mut_ptr().add(index);
                // එකවරම vector හි ඇති අගයේ පිටපතක් අනාරක්ෂිතව තබා එය පිටපත් කරන්න.
                //
                ret = ptr::read(ptr);

                // එම ස්ථානය පිරවීම සඳහා සියල්ල පහළට මාරු කරන්න.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// පුරෝකථනය මඟින් නිශ්චිතව දක්වා ඇති මූලද්‍රව්‍ය පමණක් රඳවා ගනී.
    ///
    /// වෙනත් වචන වලින් කිවහොත්, `f(&e)` `false` ආපසු ලබා දෙන `e` හි සියලුම අංග ඉවත් කරන්න.
    /// මෙම ක්‍රමය ක්‍රියාත්මක වන අතර, සෑම මූලද්‍රව්‍යයක්ම මුල් අනුපිළිවෙලට හරියටම වරක් නැරඹීම සහ රඳවා ගත් මූලද්‍රව්‍යයන්ගේ අනුපිළිවෙල ආරක්ෂා කරයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// මූලද්‍රව්‍යයන් මුල් අනුපිළිවෙලට හරියටම වරක් පිවිසෙන හෙයින්, කුමන මූලද්‍රව්‍යයන් තබා ගත යුතුද යන්න තීරණය කිරීමට බාහිර තත්වය භාවිතා කළ හැකිය.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // පහත වැටීමේ ආරක්ෂකයා ක්‍රියාත්මක නොවන්නේ නම් ද්විත්ව බිංදුවෙන් වළකින්න.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-සැකසූ ලෙන්-> |^-පරීක්ෂා කිරීමට ඊළඟට
        //                  | <-මකා දැමූ cnt-> |
        //      | <-ඔරිජිනල්_ලෙන්-> |රඳවා තබා ගැනීම: ප්‍රතිලාභ පුරෝකථනය කරන මූලද්‍රව්‍ය සත්‍ය වේ.
        //
        // සිදුර: මූලද්‍රව්‍ය කට්ටලය ගෙන යන ලද හෝ අතහැර දැමූ.
        // පරීක්ෂා නොකළ: වලංගු නොවන සලකුණු.
        //
        // මූලද්‍රව්‍යයේ පුරෝකථනය හෝ `drop` භීතියට පත්වන විට මෙම බිංදු ආරක්ෂකයා කැඳවනු ලැබේ.
        // එය සිදුරු ආවරණය කිරීම සඳහා පරීක්ෂා නොකළ මූලද්‍රව්‍ය සහ `set_len` නිවැරදි දිගට මාරු කරයි.
        // පුරෝකථනය කරන විට සහ `drop` කිසි විටෙකත් කලබල නොවන විට, එය ප්‍රශස්තිකරණය වනු ඇත.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // ආරක්ෂාව: අප කිසි විටෙකත් ඒවා ස්පර්ශ නොකරන බැවින් පරීක්ෂා නොකළ අයිතම පසුපස යාම වලංගු විය යුතුය.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // ආරක්ෂාව: සිදුරු පිරවීමෙන් පසු, සියලු අයිතම එකිනෙකට පරස්පර මතකයේ ඇත.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // ආරක්ෂාව: පරීක්ෂා නොකළ අංගය වලංගු විය යුතුය.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // `drop_in_place` භීතියට පත්වුවහොත් ද්විත්ව පහත වැටීම වළක්වා ගැනීමට කල්තියාම ඉදිරියට යන්න.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // ආරක්ෂාව: පහත වැටුණු පසු අපි කිසි විටෙකත් මෙම මූලද්‍රව්‍යය ස්පර්ශ නොකරමු.
                unsafe { ptr::drop_in_place(cur) };
                // අපි දැනටමත් කවුන්ටරය දියුණු කළා.
                continue;
            }
            if g.deleted_cnt > 0 {
                // ආරක්ෂාව: `deleted_cnt`> 0, එබැවින් සිදුරු තව් වත්මන් මූලද්‍රව්‍යය සමඟ අතිච්ඡාදනය නොවිය යුතුය.
                // අපි චලනය සඳහා පිටපත භාවිතා කරන අතර නැවත කිසි විටෙකත් මෙම අංගය ස්පර්ශ නොකරන්න.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // සියලුම අයිතම සැකසෙනු ඇත.මෙය LLVM විසින් `set_len` වෙත ප්‍රශස්තිකරණය කළ හැකිය.
        drop(g);
    }

    /// එකම යතුරට නිරාකරණය කරන vector හි අඛණ්ඩ මූලද්‍රව්‍යයන් හැර අනෙක් සියල්ල ඉවත් කරයි.
    ///
    ///
    /// vector වර්ග කර ඇත්නම්, මෙය සියලු අනුපිටපත් ඉවත් කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// දී ඇති සමානාත්මතා සම්බන්ධතාවය තෘප්තිමත් කරන vector හි අඛණ්ඩ මූලද්‍රව්‍යයන් හැර අනෙක් සියල්ල ඉවත් කරයි.
    ///
    /// `same_bucket` ශ්‍රිතය vector හි මූලද්‍රව්‍ය දෙකක් වෙත යොමු කර ඇති අතර මූලද්‍රව්‍ය සමාන ලෙස සැසඳේද යන්න තීරණය කළ යුතුය.
    /// පෙත්තෙහි ඇති අනුපිළිවෙලින් මූලද්‍රව්‍ය ප්‍රතිවිරුද්ධ අනුපිළිවෙලින් සම්මත වේ, එබැවින් `same_bucket(a, b)` `true` ආපසු ලබා දෙන්නේ නම්, `a` ඉවත් කරනු ලැබේ.
    ///
    ///
    /// vector වර්ග කර ඇත්නම්, මෙය සියලු අනුපිටපත් ඉවත් කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// එකතුවක පිටුපසට මූලද්‍රව්‍යයක් එකතු කරයි.
    ///
    /// # Panics
    ///
    /// නව ධාරිතාව `isize::MAX` බයිට් ඉක්මවන්නේ නම් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // අපි> isize::MAX බයිට් වෙන් කළහොත් හෝ ශුන්‍ය ප්‍රමාණයේ වර්ග සඳහා දිග වර්ධකය පිරී ඉතිරී ගියහොත් මෙය panic හෝ නවතා දමනු ඇත.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// vector වෙතින් අවසාන අංගය ඉවත් කර එය ආපසු ලබා දෙයි, නැතහොත් [`None`] හිස් නම්.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// `other` හි සියලුම අංග `Self` වෙත ගෙන යන අතර `other` හිස්ව පවතී.
    ///
    /// # Panics
    ///
    /// vector හි ඇති මූලද්‍රව්‍ය ගණන `usize` පිටාර ගැලුවහොත් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// අනෙකුත් බෆරයෙන් `Self` වෙත මූලද්‍රව්‍ය එකතු කරයි.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// vector හි නිශ්චිත පරාසය ඉවත් කර ඉවත් කළ අයිතම ලබා දෙන ජලාපවහන අනුකාරකයක් සාදයි.
    ///
    /// Iterator ** අතහැර දැමූ විට, පරාසයේ ඇති සියලුම මූලද්‍රව්‍ය vector වෙතින් ඉවත් කරනු ලැබේ, iterator සම්පූර්ණයෙන්ම පරිභෝජනය නොකළද.
    /// Iterator ** පහත වැටී නොමැති නම් (උදාහරණයක් ලෙස [`mem::forget`] සමඟ), මූලද්‍රව්‍ය කීයක් ඉවත් කර ඇත්ද යන්න නිශ්චිතව දක්වා නැත.
    ///
    /// # Panics
    ///
    /// Panics ආරම්භක ලක්ෂ්‍යය අවසාන ලක්ෂ්‍යයට වඩා වැඩි නම් හෝ අවසාන ලක්ෂ්‍යය vector හි දිගට වඩා වැඩි නම්.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // සම්පූර්ණ පරාසයක් vector ඉවත් කරයි
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // මතක ආරක්ෂාව
        //
        // Drain ප්‍රථම වරට නිර්මාණය කළ විට, Drain හි ඩිස්ට්‍රැක්ටරය කිසි විටෙකත් ක්‍රියාත්මක නොවන්නේ නම්, ආරම්භක හෝ චලනය නොවන මූලද්‍රව්‍යයන් කිසිසේත් ප්‍රවේශ විය නොහැකි බව සහතික කිරීම සඳහා එය vector ප්‍රභවයේ දිග කෙටි කරයි.
        //
        //
        // Drain ඉවත් කිරීම සඳහා ptr::read අගයන් ඉවත් කරයි.
        // අවසන් වූ පසු, කුහරය ආවරණය කිරීම සඳහා දෛශිකයේ ඉතිරි වලිගය නැවත පිටපත් කරනු ලබන අතර vector දිග නව දිගට යථා තත්වයට පත් කෙරේ.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // Drain කාන්දු වුවහොත් ආරක්ෂිත වීමට self.vec දිග ආරම්භ කිරීමට සකසන්න
            self.set_len(start);
            // සමස්ත Drain iterator (&mut T වැනි) හි ණය ගැනීමේ හැසිරීම දැක්වීමට IterMut හි ණය භාවිතා කරන්න.
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// vector ඉවත් කරයි, සියලු අගයන් ඉවත් කරයි.
    ///
    /// මෙම ක්‍රමය vector හි වෙන් කළ ධාරිතාවට කිසිදු බලපෑමක් නොකරන බව සලකන්න.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// vector හි ඇති මූලද්‍රව්‍ය ගණන නැවත ලබා දෙයි, එහි 'length' ලෙසද හැඳින්වේ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// vector හි කිසිදු මූලද්‍රව්‍යයක් නොමැති නම් `true` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// දී ඇති දර්ශකයේ එකතු කිරීම දෙකට බෙදයි.
    ///
    /// `[at, len)` පරාසයේ ඇති මූලද්‍රව්‍ය අඩංගු අලුතින් වෙන් කරන ලද vector ලබා දෙයි.
    /// ඇමතුමෙන් පසුව, මුල් vector හි `[0, at)` මූලද්‍රව්‍ය අඩංගු වන අතර එහි පෙර ධාරිතාව නොවෙනස්ව පවතී.
    ///
    ///
    /// # Panics
    ///
    /// `at > len` නම් Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // නව vector හට මුල් බෆරය භාරගෙන පිටපත මඟ හැරිය හැක
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // අනාරක්ෂිත ලෙස `set_len` සහ `other` වෙත අයිතම පිටපත් කරන්න.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// `Vec` ස්ථානයෙහි ප්‍රමාණය වෙනස් කරයි, එවිට `len` `new_len` ට සමාන වේ.
    ///
    /// `new_len` `len` ට වඩා වැඩි නම්, `Vec` වෙනස මගින් විස්තාරණය වන අතර, එක් එක් අතිරේක තව් `f` වසා දැමීමේ ඇමතුමේ ප්‍රති result ලයෙන් පිරී ඇත.
    ///
    /// `f` වෙතින් ලැබෙන ප්‍රතිලාභ අගයන් `Vec` වලින් උත්පාදනය වූ අනුපිළිවෙලින් අවසන් වේ.
    ///
    /// `new_len` `len` ට වඩා අඩු නම්, `Vec` සරලව කපා ඇත.
    ///
    /// මෙම ක්‍රමය සෑම තල්ලුවකම නව අගයන් නිර්මාණය කිරීම සඳහා වසා දැමීමක් භාවිතා කරයි.ඔබ ලබා දී ඇති අගය [`Clone`] ට වඩා කැමති නම්, [`Vec::resize`] භාවිතා කරන්න.
    /// අගයන් උත්පාදනය කිරීම සඳහා ඔබට [`Default`] trait භාවිතා කිරීමට අවශ්‍ය නම්, ඔබට දෙවන තර්කය ලෙස [`Default::default`] සමත් විය හැකිය.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// `Vec` පරිභෝජනය හා කාන්දු වීම, අන්තර්ගතයට විකෘති යොමු කිරීමක් ලබා දීම, `&'a mut [T]`.
    /// `T` වර්ගය තෝරාගත් ජීවිත කාලය `'a` ඉක්මවා යා යුතු බව සලකන්න.
    /// වර්ගයට ස්ථිතික යොමු කිරීම් පමණක් තිබේ නම් හෝ කිසිවක් නොමැති නම් මෙය `'static` ලෙස තෝරා ගත හැකිය.
    ///
    /// කාන්දු වූ මතකය නැවත ලබා ගැනීමට ක්‍රමයක් නොමැති බව හැර, මෙම ශ්‍රිතය [`Box`] හි [`leak`][Box::leak] ශ්‍රිතයට සමාන වේ.
    ///
    ///
    /// වැඩසටහනේ ජීවිතයේ ඉතිරි කාලය සඳහා ජීවත්වන දත්ත සඳහා මෙම කාර්යය ප්‍රධාන වශයෙන් ප්‍රයෝජනවත් වේ.
    /// ආපසු යොමු කිරීම අතහැර දැමීම මතක කාන්දු වීමට හේතු වේ.
    ///
    /// # Examples
    ///
    /// සරල භාවිතය:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// vector හි ඉතිරි අමතර ධාරිතාව `MaybeUninit<T>` පෙත්තක් ලෙස ලබා දෙයි.
    ///
    /// ආපසු ලබා දුන් පෙත්ත vector දත්ත සමඟ පුරවා ගත හැකිය (උදා
    /// [`set_len`] ක්‍රමය භාවිතා කරමින් දත්ත ආරම්භක ලෙස සලකුණු කිරීමට පෙර) ගොනුවකින් කියවීමෙන්).
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // මූලද්රව්ය 10 ක් සඳහා ප්රමාණවත් තරම් විශාල vector වෙන් කරන්න.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // පළමු මූලද්රව්ය 3 පුරවන්න.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // vector හි පළමු අංග 3 ආරම්භ කර ඇති බව සලකුණු කරන්න.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // බෆරයට දර්ශක අවලංගු වීම වැළැක්වීම සඳහා මෙම ක්‍රමය `split_at_spare_mut` ප්‍රකාරව ක්‍රියාත්මක නොවේ.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// vector අන්තර්ගතය `T` පෙත්තක් ලෙසත්, vector හි ඉතිරි අමතර ධාරිතාව `MaybeUninit<T>` පෙත්තක් ලෙසත් ලබා දෙයි.
    ///
    /// ආපසු ලබා දුන් අමතර ධාරිතා පෙත්ත, [`set_len`] ක්‍රමය භාවිතයෙන් දත්ත ආරම්භක ලෙස සලකුණු කිරීමට පෙර vector දත්ත සමඟ පුරවා ගත හැකිය (උදා: ගොනුවකින් කියවීමෙන්).
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// මෙය පහත් මට්ටමේ API එකක් බව සලකන්න, එය ප්‍රශස්තිකරණ අරමුණු සඳහා ප්‍රවේශමෙන් භාවිතා කළ යුතුය.
    /// ඔබට `Vec` වෙත දත්ත එකතු කිරීමට අවශ්‍ය නම්, ඔබේ නිශ්චිත අවශ්‍යතා අනුව ඔබට [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] හෝ [`resize_with`] භාවිතා කළ හැකිය.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // මූලද්රව්ය 10 ක් සඳහා ප්රමාණවත් තරම් අමතර ඉඩක් වෙන් කරන්න.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // ඊළඟ මූලද්රව්ය 4 පුරවන්න.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // vector හි මූලද්‍රව්‍ය 4 ආරම්භ කර ඇති බව සලකුණු කරන්න.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - ලෙන් නොසලකා හරින අතර කිසි විටෙකත් වෙනස් නොවේ
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// ආරක්ෂාව: ආපසු පැමිණීම වෙනස් කිරීම .2 (&mut usize) `.set_len(_)` ඇමතීමට සමාන වේ.
    ///
    /// `extend_from_within` හි එකවර සියලුම වීක් කොටස් වලට අද්විතීය ප්‍රවේශයක් ලබා ගැනීමට මෙම ක්‍රමය භාවිතා කරයි.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` `len` මූලද්‍රව්‍ය සඳහා වලංගු බවට සහතික වේ
        // - `spare_ptr` එක් මූලද්‍රව්‍යයක් බෆරය පසුකරමින් යොමු කරයි, එබැවින් එය `initialized` සමඟ අතිච්ඡාදනය නොවේ
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// `Vec` ස්ථානයෙහි ප්‍රමාණය වෙනස් කරයි, එවිට `len` `new_len` ට සමාන වේ.
    ///
    /// `new_len` `len` ට වඩා වැඩි නම්, එක් එක් අතිරේක තව් `value` වලින් පුරවා ඇති `Vec` වෙනස මගින් විස්තාරණය වේ.
    ///
    /// `new_len` `len` ට වඩා අඩු නම්, `Vec` සරලව කපා ඇත.
    ///
    /// සම්මත අගය ක්ලෝන කිරීමට හැකිවන පරිදි [`Clone`] ක්‍රියාත්මක කිරීමට මෙම ක්‍රමයට `T` අවශ්‍ය වේ.
    /// ඔබට වැඩි නම්යතාවයක් අවශ්‍ය නම් (හෝ [`Clone`] වෙනුවට [`Default`] මත විශ්වාසය තැබීමට අවශ්‍ය නම්), [`Vec::resize_with`] භාවිතා කරන්න.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// පෙත්තක ඇති සියලුම අංග `Vec` වෙත ක්ලෝන කර එකතු කරයි.
    ///
    /// `other` පෙත්ත හරහා ඉරේටේට්ස්, එක් එක් මූලද්‍රව්‍යය ක්ලෝන කර පසුව මෙම `Vec` වෙත එකතු කරයි.
    /// `other` vector පිළිවෙලට ගමන් කරයි.
    ///
    /// පෙති සමඟ වැඩ කිරීම විශේෂිත වූවක් හැර මෙම ශ්‍රිතය [`extend`] ට සමාන බව සලකන්න.
    ///
    /// Rust විශේෂීකරණය ලැබුවහොත් සහ විට මෙම ශ්‍රිතය අවලංගු වනු ඇත (නමුත් තවමත් පවතී).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// `src` පරාසයේ සිට vector අවසානය දක්වා මූලද්‍රව්‍ය පිටපත් කරයි.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` ලබා දී ඇති පරාසය ස්වයං සුචිගත කිරීම සඳහා වලංගු බවට සහතික වේ
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// මෙම කේතය `extend_with_{element,default}` සාමාන්‍යකරණය කරයි.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// දී ඇති උත්පාදක යන්ත්රය භාවිතා කරමින් `n` අගයන් මගින් vector දිගු කරන්න.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // `ptr` හරහා self.set_len() හරහා self.set_len() හරහා ගබඩාව අවබෝධ කර නොගන්නා දෝෂය සමඟ කටයුතු කිරීමට SetLenOnDrop භාවිතා කරන්න.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // අන්තිම එක හැර අනෙක් සියලුම අංග ලියන්න
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // next() panics නඩුවේ සෑම පියවරකදීම දිග වැඩි කරන්න
                local_len.increment_len(1);
            }

            if n > 0 {
                // අනවශ්‍ය ලෙස ක්ලෝන කිරීමකින් තොරව අපට අවසාන අංගය කෙලින්ම ලිවිය හැකිය
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // විෂය පථය විසින් සකසන ලද ලෙන්
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// [`PartialEq`] trait ක්‍රියාත්මක කිරීම අනුව vector හි අඛණ්ඩව නැවත නැවතත් මූලද්‍රව්‍ය ඉවත් කරයි.
    ///
    ///
    /// vector වර්ග කර ඇත්නම්, මෙය සියලු අනුපිටපත් ඉවත් කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// අභ්යන්තර ක්රම සහ කාර්යයන්
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` වලංගු දර්ශකයක් විය යුතුය
    /// - `self.capacity() - self.len()` `>= src.len()` විය යුතුය
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - ලෙන් වැඩි වන්නේ මූලද්‍රව්‍ය ආරම්භ කිරීමෙන් පසුව පමණි
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - src වලංගු දර්ශකයක් බව අමතන්නා සහතික කරයි
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - මූලද්‍රව්‍යය `MaybeUninit::write` සමඟ ආරම්භ කරන ලදි, එබැවින් ලෙන් වැඩි කිරීම කමක් නැත
            // - කාන්දු වීම වැළැක්වීම සඳහා එක් එක් මූලද්‍රව්‍යයෙන් පසුව ලෙන් වැඩි වේ (#82533 නිකුතුව බලන්න)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - `src` වලංගු දර්ශකයක් බව අමතන්නා සහතික කරයි
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - දර්ශක දෙකම නිර්මාණය කර ඇත්තේ අද්විතීය පෙති යොමු කිරීම් වලින් (`&mut [_]`) එබැවින් ඒවා වලංගු වන අතර අතිච්ඡාදනය නොවේ.
            //
            // - මූලද්රව්ය නම්: පිටපත් කරන්න, එබැවින් මුල් අගයන් සමඟ කිසිවක් නොකර ඒවා පිටපත් කිරීම සුදුසුය
            // - `count` `source` හි කාචයට සමාන වේ, එබැවින් ප්‍රභවය `count` කියවීම් සඳහා වලංගු වේ
            // - `.reserve(count)` `spare.len() >= count` ලිවීම සඳහා අමතර කොටස් වලංගු බව සහතික කරයි
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - මූලද්රව්ය `copy_nonoverlapping` විසින් ආරම්භ කරන ලදී
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Vec සඳහා පොදු trait ක්‍රියාත්මක කිරීම
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): cfg(test) සමඟ මෙම ක්‍රම නිර්වචනය සඳහා අවශ්‍ය වන සහජ `[T]::to_vec` ක්‍රමය ලබා ගත නොහැක.
    // ඒ වෙනුවට cfg(test) NB සමඟ පමණක් ඇති `slice::to_vec` ශ්‍රිතය භාවිතා කරන්න වැඩි විස්තර සඳහා slice.rs හි slice::hack මොඩියුලය බලන්න
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // නැවත ලියනු නොලබන ඕනෑම දෙයක් අතහරින්න
        self.truncate(other.len());

        // self.len <= other.len ඉහත කප්පාදුව නිසා, මෙහි පෙති සෑම විටම සීමිතය.
        //
        let (init, tail) = other.split_at(self.len());

        // allocations/resources අඩංගු අගයන් නැවත භාවිතා කරන්න.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// පරිභෝජන අනුකාරකයක් සාදයි, එනම්, එක් එක් අගය vector වෙතින් පිටතට ගෙන යන (ආරම්භයේ සිට අවසානය දක්වා).
    /// මෙය ඇමතීමෙන් පසු vector භාවිතා කළ නොහැක.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s හි String වර්ගය ඇත, &String නොවේ
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // අයදුම් කිරීමට තවදුරටත් ප්‍රශස්තිකරණ නොමැති විට විවිධ SpecFrom/SpecExtend ක්‍රියාත්මක කිරීම් පවරන පත්‍ර ක්‍රමය
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // සාමාන්‍ය ක්‍රියාකාරකයකු සඳහා මෙය වේ.
        //
        // මෙම ශ්‍රිතය සදාචාරාත්මක සමාන විය යුතුය:
        //
        //      iterator හි අයිතමය සඳහා {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // අපට ලිපින අවකාශය වෙන් කිරීමට සිදුවනු ඇති බැවින් සැ.යු.
                self.set_len(len + 1);
            }
        }
    }

    /// vector හි නිශ්චිත පරාසය ලබා දී ඇති `replace_with` iterator සමඟ ප්‍රතිස්ථාපනය කර ඉවත් කරන ලද අයිතම ලබා දෙන භ්‍රමණය වන අනුකාරකයක් සාදයි.
    ///
    /// `replace_with` `range` ට සමාන දිගක් අවශ්‍ය නොවේ.
    ///
    /// `range` iterator අවසානය දක්වා පරිභෝජනය නොකළද ඉවත් කරනු ලැබේ.
    ///
    /// `Splice` අගය කාන්දු වුවහොත් vector වෙතින් මූලද්‍රව්‍ය කීයක් ඉවත් කරන්නේද යන්න නිශ්චිතව දක්වා නැත.
    ///
    /// ආදාන iterator `replace_with` පරිභෝජනය කරනු ලබන්නේ `Splice` අගය පහත වැටුණු විට පමණි.
    ///
    /// මෙය ප්‍රශස්ත නම්:
    ///
    /// * වලිගය (`range` පසු vector හි මූලද්‍රව්‍ය) හිස් ය,
    /// * හෝ `replace_with` මඟින් `පරාසයේ දිගට වඩා අඩු හෝ සමාන මූලද්‍රව්‍ය ලබා දෙයි
    /// * හෝ එහි `size_hint()` හි පහළ සීමාව හරියටම වේ.
    ///
    /// එසේ නොමැතිනම් තාවකාලික vector වෙන් කර ඇති අතර වලිගය දෙවරක් චලනය වේ.
    ///
    /// # Panics
    ///
    /// Panics ආරම්භක ලක්ෂ්‍යය අවසාන ලක්ෂ්‍යයට වඩා වැඩි නම් හෝ අවසාන ලක්ෂ්‍යය vector හි දිගට වඩා වැඩි නම්.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// මූලද්‍රව්‍යයක් ඉවත් කළ යුතුද යන්න තීරණය කිරීම සඳහා වසා දැමීමක් භාවිතා කරන අනුකාරකයක් සාදයි.
    ///
    /// වසා දැමීම සත්‍ය නම්, මූලද්‍රව්‍යය ඉවත් කර අස්වැන්න ලැබේ.
    /// වසා දැමීම වැරදියි නම්, මූලද්‍රව්‍යය vector හි පවතිනු ඇති අතර එය අනුකාරකය මඟින් ලබා නොදෙනු ඇත.
    ///
    /// මෙම ක්‍රමය භාවිතා කිරීම පහත කේතයට සමාන වේ:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // ඔබේ කේතය මෙහි ඇත
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// නමුත් `drain_filter` භාවිතා කිරීම පහසුය.
    /// `drain_filter` අරාවෙහි මූලද්‍රව්‍ය තොග වශයෙන් ආපසු හරවා යැවිය හැකි නිසා එය වඩාත් කාර්යක්ෂම වේ.
    ///
    /// පෙරහන් වැසීමේ සෑම අංගයක්ම විකෘති කිරීමට `drain_filter` ඔබට ඉඩ සලසයි, ඔබ එය තබා ගැනීමට හෝ ඉවත් කිරීමට තෝරා ගත්තද නොසලකා.
    ///
    ///
    /// # Examples
    ///
    /// මුල් වෙන් කිරීම නැවත භාවිතා කරමින් අරාව සවස් වරුවකට බෙදීම:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // අප කාන්දු වීම වළක්වා ගන්න (කාන්දු විස්තාරණය)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// මූලද්‍රව්‍යයන් Vec වෙත තල්ලු කිරීමට පෙර ඒවා යොමු කිරීම් වලින් පිටපත් කරන ක්‍රියාත්මක කිරීම පුළුල් කරන්න.
///
/// මෙම ක්‍රියාත්මක කිරීම ස්ලයිස් ඉරේටර සඳහා විශේෂිත වේ, එහිදී එය මුළු පෙත්තම එකවර එකතු කිරීමට [`copy_from_slice`] භාවිතා කරයි.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// vectors සංසන්දනය ක්‍රියාත්මක කරයි, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// vectors ඇණවුම් කිරීම ක්‍රියාත්මක කරයි, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // [T] සඳහා පහත වැටීම භාවිතා කරන්න vector හි මූලද්‍රව්‍ය දුර්වලම අවශ්‍ය වර්ගය ලෙස හැඳින්වීමට අමු පෙත්තක් භාවිතා කරන්න;
            //
            // සමහර අවස්ථාවල වලංගුභාවය පිළිබඳ ප්‍රශ්න මග හැරිය හැක
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec විසර්ජනය හසුරුවයි
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// හිස් `Vec<T>` සාදයි.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: පරීක්ෂණය libstd තුළට අදින අතර එය මෙහි දෝෂ ඇති කරයි
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: පරීක්ෂණය libstd තුළට අදින අතර එය මෙහි දෝෂ ඇති කරයි
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// `Vec<T>` හි සම්පූර්ණ අන්තර්ගතය අරාව ලෙස ලබා ගනී, එහි විශාලත්වය ඉල්ලූ අරාවෙහි ප්‍රමාණයට හරියටම ගැලපේ නම්.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// දිග නොගැලපේ නම්, ආදානය `Err` වලින් නැවත පැමිණේ:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// `Vec<T>` හි උපසර්ගයක් ලබා ගැනීම සමඟ ඔබ හොඳින් නම්, ඔබට පළමුව [`.truncate(N)`](Vec::truncate) අමතන්න.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // ආරක්ෂාව: `.set_len(0)` සෑම විටම ශබ්දයි.
        unsafe { vec.set_len(0) };

        // ආරක්ෂාව: `Vec` හි දර්ශකය සෑම විටම නිසි ලෙස පෙළගස්වා ඇත, සහ
        // අරාව සඳහා අවශ්‍ය පෙළගැස්ම අයිතම වලට සමාන වේ.
        // අප සතුව ප්‍රමාණවත් අයිතම තිබේදැයි අපි කලින් පරීක්ෂා කළෙමු.
        // `set_len` `Vec` ට පවසන පරිදි අයිතම දෙගුණයක් වැටෙන්නේ නැත.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}