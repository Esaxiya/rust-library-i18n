//! පරස්පර අනුක්‍රමයකට ගතික ප්‍රමාණයේ දර්ශනයක්, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! පෙති යනු දර්ශකයක් සහ දිගක් ලෙස නිරූපණය වන මතක කොටසකට දර්ශනයකි.
//!
//! ```
//! // Vec පෙත්තක් කැපීම
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // පෙත්තකට අරාව බල කිරීම
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! පෙති විකෘති හෝ බෙදා ඇත.
//! හවුල් පෙති වර්ගය `&[T]` වන අතර විකෘති පෙති වර්ගය `&mut [T]` වන අතර `T` මූලද්‍රව්‍ය වර්ගය නියෝජනය කරයි.
//! නිදසුනක් ලෙස, විකෘති පෙත්තක් පෙන්වා දෙන මතක කොටස ඔබට විකෘති කළ හැකිය:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! මෙම මොඩියුලයේ අඩංගු කරුණු කිහිපයක් මෙන්න:
//!
//! ## Structs
//!
//! පෙති සඳහා ප්‍රයෝජනවත් වන ව්‍යුහයන් කිහිපයක් ඇත, එනම් [`Iter`], පෙත්තක් හරහා නැවත ක්‍රියා කිරීම නිරූපණය කරයි.
//!
//! ## Trait ක්‍රියාත්මක කිරීම
//!
//! පෙති සඳහා පොදු traits ක්‍රියාත්මක කිරීම කිහිපයක් තිබේ.උදාහරණ කිහිපයක්:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], මූලද්‍රව්‍ය වර්ගය [`Eq`] හෝ [`Ord`] වන පෙති සඳහා.
//! * [`Hash`] - මූලද්‍රව්‍ය වර්ගය [`Hash`] වන පෙති සඳහා.
//!
//! ## Iteration
//!
//! පෙති `IntoIterator` ක්‍රියාත්මක කරයි.පෙත්ත මූලද්‍රව්‍ය වෙත යොමුව යොමු කරයි.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! විකෘති පෙත්ත මූලද්‍රව්‍යවලට විකෘති යොමු දක්වයි:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! මෙම අනුකාරකය පෙත්තෙහි මූලද්‍රව්‍යයන්ට විකෘති යොමු කිරීම් ලබා දෙයි, එබැවින් පෙත්තෙහි මූලද්‍රව්‍ය වර්ගය `i32` වන අතර, අනුකාරකයේ මූලද්‍රව්‍ය වර්ගය `&mut i32` වේ.
//!
//!
//! * [`.iter`] සහ [`.iter_mut`] යනු සුපුරුදු අනුකාරක නැවත ලබා දීමේ පැහැදිලි ක්‍රම වේ.
//! * [`.split`], [`.splitn`], [`.chunks`], [`.windows`] සහ තවත් බොහෝ දේ නැවත ලබා දෙන ක්‍රම වේ.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// මෙම මොඩියුලයේ බොහෝ භාවිතයන් භාවිතා කරනුයේ පරීක්ෂණ වින්‍යාසය තුළ පමණි.
// ඒවා නිවැරදි කිරීමට වඩා භාවිතයට නොගත්_සම්පූර්ණ අනතුරු ඇඟවීම ක්‍රියා විරහිත කිරීම වඩා පිරිසිදු ය.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// මූලික පෙති දිගු කිරීමේ ක්‍රම
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) NB පරීක්ෂා කිරීමේදී `vec!` මැක්‍රෝ ක්‍රියාත්මක කිරීම සඳහා අවශ්‍ය වේ, වැඩි විස්තර සඳහා මෙම ගොනුවේ `hack` මොඩියුලය බලන්න.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) NB පරීක්‍ෂා කිරීමේදී `Vec::clone` ක්‍රියාත්මක කිරීම සඳහා අවශ්‍ය වේ, වැඩි විස්තර සඳහා මෙම ගොනුවේ `hack` මොඩියුලය බලන්න.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): cfg(test) `impl [T]` ලබා ගත නොහැකි බැවින්, මෙම කාර්යයන් තුන ඇත්ත වශයෙන්ම `impl [T]` හි ඇති නමුත් `core::slice::SliceExt` හි නොවන ක්‍රම වේ, අපට මෙම කාර්යයන් `test_permutations` පරීක්ෂණය සඳහා සැපයිය යුතුය
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // මෙය බොහෝ දුරට `vec!` මැක්‍රෝ වල භාවිතා වන අතර පරිපූර්ණ ප්‍රතිගාමීත්වයට හේතු වන බැවින් අපි මේ සඳහා පේළිගත ගුණාංග එකතු නොකළ යුතුය.
    // සාකච්ඡා සහ පරිපූර්ණ ප්‍රති .ල සඳහා #71204 බලන්න.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // පහත දැක්වෙන ලූපය තුළ අයිතම ආරම්භක ලෙස සලකුණු කරන ලදි
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) මායිම් චෙක්පත් ඉවත් කිරීමට එල්එල්වීඑම් සඳහා අවශ්‍ය වන අතර සිප් වලට වඩා හොඳ කෝඩජන් ඇත.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec වෙන් කර ඇති අතර අවම වශයෙන් මෙම දිගට ඉහළින් ආරම්භ කරන ලදී.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // `s` ධාරිතාවයෙන් ඉහත වෙන් කර ඇති අතර, ptr::copy_to_non_overlapping හි `s.len()` වෙත ආරම්භ කරන්න.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// පෙත්ත වර්ග කරයි.
    ///
    /// මෙම වර්ග කිරීම ස්ථායී වේ (එනම්, සමාන මූලද්‍රව්‍ය නැවත සකස් නොකරයි) සහ *O*(*n*\*log(* n*)) නරකම අවස්ථාව.
    ///
    /// අදාළ වන විට, අස්ථායී වර්ග කිරීම වඩාත් සුදුසු වන්නේ එය සාමාන්‍යයෙන් ස්ථාවර වර්ගීකරණයට වඩා වේගවත් වන අතර එය සහායක මතකය වෙන් නොකරන බැවිනි.
    /// [`sort_unstable`](slice::sort_unstable) බලන්න.
    ///
    /// # වත්මන් ක්‍රියාත්මක කිරීම
    ///
    /// වර්තමාන ඇල්ගොරිතමය [timsort](https://en.wikipedia.org/wiki/Timsort) මගින් දේවානුභාවයෙන් අනුවර්තී, පුනරාවර්තන ඒකාබද්ධ කිරීමේ වර්ග කිරීමකි.
    /// පෙත්තක් ආසන්න වශයෙන් වර්ග කර ඇති අවස්ථා වලදී හෝ එකින් එක එකිනෙකට සම්බන්ධ වූ අනුපිළිවෙලවල් දෙකකින් හෝ වැඩි ගණනකින් සමන්විත වේ.
    ///
    ///
    /// එසේම, එය `self` ප්‍රමාණයෙන් අඩක් තාවකාලික ආචයනය වෙන් කරයි, නමුත් කෙටි පෙති සඳහා වෙන් නොකල ඇතුළු කිරීමේ වර්ගයක් භාවිතා කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// සංසන්දනාත්මක ශ්‍රිතයක් සමඟ පෙත්ත වර්ග කරයි.
    ///
    /// මෙම වර්ග කිරීම ස්ථායී වේ (එනම්, සමාන මූලද්‍රව්‍ය නැවත සකස් නොකරයි) සහ *O*(*n*\*log(* n*)) නරකම අවස්ථාව.
    ///
    /// සංසන්දනාත්මක ශ්‍රිතය පෙත්තෙහි ඇති මූලද්‍රව්‍ය සඳහා සම්පූර්ණ අනුපිළිවෙලක් අර්ථ දැක්විය යුතුය.ඇණවුම සම්පුර්ණ නොවේ නම්, මූලද්‍රව්‍යවල අනුපිළිවෙල නිශ්චිතව දක්වා නැත.
    /// ඇණවුමක් නම් එය සම්පූර්ණ ඇණවුමකි (සියලුම `a`, `b` සහ `c` සඳහා):
    ///
    /// * සම්පුර්ණ සහ ප්‍රති-අසමමිතික: හරියටම `a < b`, `a == b` හෝ `a > b` වලින් එකක් සත්‍ය වන අතර
    /// * සංක්‍රාන්ති, `a < b` සහ `b < c` යන්නෙන් අදහස් කරන්නේ `a < c` යන්නයි.`==` සහ `>` යන දෙකටම සමාන විය යුතුය.
    ///
    /// උදාහරණයක් ලෙස, `NaN != NaN` [`Ord`] ක්‍රියාත්මක නොකරන අතර `NaN != NaN` නිසා, අපට පෙත්තෙහි `NaN` අඩංගු නොවන බව දැනගත් විට අපට `partial_cmp` අපගේ වර්ග කිරීමේ ශ්‍රිතය ලෙස භාවිතා කළ හැකිය.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// අදාළ වන විට, අස්ථායී වර්ග කිරීම වඩාත් සුදුසු වන්නේ එය සාමාන්‍යයෙන් ස්ථාවර වර්ගීකරණයට වඩා වේගවත් වන අතර එය සහායක මතකය වෙන් නොකරන බැවිනි.
    /// [`sort_unstable_by`](slice::sort_unstable_by) බලන්න.
    ///
    /// # වත්මන් ක්‍රියාත්මක කිරීම
    ///
    /// වර්තමාන ඇල්ගොරිතමය [timsort](https://en.wikipedia.org/wiki/Timsort) මගින් දේවානුභාවයෙන් අනුවර්තී, පුනරාවර්තන ඒකාබද්ධ කිරීමේ වර්ග කිරීමකි.
    /// පෙත්තක් ආසන්න වශයෙන් වර්ග කර ඇති අවස්ථා වලදී හෝ එකින් එක එකිනෙකට සම්බන්ධ වූ අනුපිළිවෙලවල් දෙකකින් හෝ වැඩි ගණනකින් සමන්විත වේ.
    ///
    /// එසේම, එය `self` ප්‍රමාණයෙන් අඩක් තාවකාලික ආචයනය වෙන් කරයි, නමුත් කෙටි පෙති සඳහා වෙන් නොකල ඇතුළු කිරීමේ වර්ගයක් භාවිතා කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // ප්‍රතිලෝම වර්ග කිරීම
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// යතුරු නිස්සාරණ ශ්‍රිතයක් සමඟ පෙත්ත වර්ග කරයි.
    ///
    /// මෙම වර්ග කිරීම ස්ථායී වේ (එනම්, සමාන මූලද්‍රව්‍ය නැවත සකසන්නේ නැත) සහ *O*(*m*\* * n *\* log(*n*)) නරකම අවස්ථාව, මෙහි ප්‍රධාන ශ්‍රිතය *O*(*m*) වේ.
    ///
    /// මිල අධික යතුරු කාර්යයන් සඳහා (උදා
    /// සරල දේපල ප්‍රවේශයන් හෝ මූලික මෙහෙයුම් නොවන කාර්යයන්), මූලද්‍රව්‍ය යතුරු නැවත ගණනය නොකරන බැවින් [`sort_by_cached_key`](slice::sort_by_cached_key) සැලකිය යුතු වේගයකින් යුක්ත වේ.
    ///
    ///
    /// අදාළ වන විට, අස්ථායී වර්ග කිරීම වඩාත් සුදුසු වන්නේ එය සාමාන්‍යයෙන් ස්ථාවර වර්ගීකරණයට වඩා වේගවත් වන අතර එය සහායක මතකය වෙන් නොකරන බැවිනි.
    /// [`sort_unstable_by_key`](slice::sort_unstable_by_key) බලන්න.
    ///
    /// # වත්මන් ක්‍රියාත්මක කිරීම
    ///
    /// වර්තමාන ඇල්ගොරිතමය [timsort](https://en.wikipedia.org/wiki/Timsort) මගින් දේවානුභාවයෙන් අනුවර්තී, පුනරාවර්තන ඒකාබද්ධ කිරීමේ වර්ග කිරීමකි.
    /// පෙත්තක් ආසන්න වශයෙන් වර්ග කර ඇති අවස්ථා වලදී හෝ එකින් එක එකිනෙකට සම්බන්ධ වූ අනුපිළිවෙලවල් දෙකකින් හෝ වැඩි ගණනකින් සමන්විත වේ.
    ///
    /// එසේම, එය `self` ප්‍රමාණයෙන් අඩක් තාවකාලික ආචයනය වෙන් කරයි, නමුත් කෙටි පෙති සඳහා වෙන් නොකල ඇතුළු කිරීමේ වර්ගයක් භාවිතා කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// යතුරු නිස්සාරණ ශ්‍රිතයක් සමඟ පෙත්ත වර්ග කරයි.
    ///
    /// වර්ග කිරීම අතරතුර, යතුරු ශ්‍රිතය හැඳින්වෙන්නේ එක් මූලද්‍රව්‍යයකට එක් වරක් පමණි.
    ///
    /// මෙම වර්ග කිරීම ස්ථායී වේ (එනම්, සමාන මූලද්‍රව්‍ය නැවත සකසන්නේ නැත) සහ *O*(*m*\* * n *+* n *\* log(*n*)) නරකම අවස්ථාව, මෙහි ප්‍රධාන ශ්‍රිතය *O*(*m*) .
    ///
    /// සරල යතුරු කාර්යයන් සඳහා (උදා: දේපල ප්‍රවේශයන් හෝ මූලික මෙහෙයුම්), [`sort_by_key`](slice::sort_by_key) වේගවත් වීමට ඉඩ ඇත.
    ///
    /// # වත්මන් ක්‍රියාත්මක කිරීම
    ///
    /// වර්තමාන ඇල්ගොරිතම පදනම් වී ඇත්තේ ඕර්සන් පීටර්ස් විසින් [pattern-defeating quicksort][pdqsort] මත වන අතර එය අහඹු ලෙස ක්වික්සෝර්ට් හි වේගවත් සාමාන්‍ය නඩුව හීප්සෝර්ට් හි වේගවත්ම නරකම අවස්ථාව සමඟ ඒකාබද්ධ කරන අතර ඇතැම් රටා සහිත පෙති මත රේඛීය වේලාවක් ලබා ගනී.
    /// පරිහානියට පත් අවස්ථාවන් වළක්වා ගැනීම සඳහා එය යම් අහඹුකරණයක් භාවිතා කරයි, නමුත් ස්ථාවර seed සමඟ සෑම විටම නිර්ණායක හැසිරීම් සපයයි.
    ///
    /// නරකම අවස්ථාවෙහිදී, ඇල්ගොරිතමය පෙත්තක දිග `Vec<(K, usize)>` තුළ තාවකාලික ගබඩා වෙන් කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // වෙන් කිරීම අඩු කිරීම සඳහා හැකි තරම් කුඩාම වර්ගය අනුව අපගේ vector සුචිගත කිරීම සඳහා මැක්‍රෝ උදව් කරන්න.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // `indices` හි මූලද්‍රව්‍යයන් අද්විතීය වන අතර ඒවා සුචිගත කර ඇති බැවින් මුල් පෙත්ත සම්බන්ධයෙන් ඕනෑම ආකාරයක ස්ථාවර වේ.
                // අපි මෙහි `sort_unstable` භාවිතා කරන්නේ එයට අඩු මතක වෙන් කිරීමක් අවශ්‍ය වන බැවිනි.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// `self` නව `Vec` වෙත පිටපත් කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // මෙන්න, `s` සහ `x` ස්වාධීනව වෙනස් කළ හැකිය.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// විබෙදන්නෙකු සමඟ `self` නව `Vec` වෙත පිටපත් කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // මෙන්න, `s` සහ `x` ස්වාධීනව වෙනස් කළ හැකිය.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // සැ.යු, වැඩි විස්තර සඳහා මෙම ගොනුවේ `hack` මොඩියුලය බලන්න.
        hack::to_vec(self, alloc)
    }

    /// ක්ලෝන හෝ වෙන් කිරීමකින් තොරව `self` vector බවට පරිවර්තනය කරයි.
    ///
    /// එහි ප්‍රති ing ලයක් වශයෙන් vector `Vec හරහා නැවත කොටුවක් බවට පරිවර්තනය කළ හැකිය<T>`into_boxed_slice` ක්‍රමය.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` එය `x` බවට පරිවර්තනය කර ඇති නිසා තවදුරටත් භාවිතා කළ නොහැක.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // සැ.යු, වැඩි විස්තර සඳහා මෙම ගොනුවේ `hack` මොඩියුලය බලන්න.
        hack::into_vec(self)
    }

    /// පෙත්තක් `n` වාරයක් පුනරාවර්තනය කිරීමෙන් vector නිර්මාණය කරයි.
    ///
    /// # Panics
    ///
    /// ධාරිතාව පිරී ඉතිරී ගියහොත් මෙම ශ්‍රිතය panic වනු ඇත.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// පිටාර ගැලීම මත panic:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // `n` බිංදුවට වඩා විශාල නම් එය `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` ලෙස බෙදිය හැකිය.
        // `2^expn` යනු `n` හි වම්පස '1' බිට් මගින් නිරූපණය වන අංකය වන අතර `rem` යනු `n` හි ඉතිරි කොටසයි.
        //
        //

        // `set_len()` වෙත ප්‍රවේශ වීමට `Vec` භාවිතා කිරීම.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` `buf` `expn` වාරයක් දෙගුණ කිරීමෙන් පුනරාවර්තනය සිදු කෙරේ.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // `m > 0` නම්, වම් කෙළවරේ '1' දක්වා ඉතිරිව ඇති බිටු ඇත.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` `self.len() * n` ධාරිතාව ඇත.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) පුනරාවර්තනය සිදු කරනුයේ පළමු `rem` පුනරාවර්තන `buf` වෙතින් පිටපත් කිරීමෙනි.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // මෙය `2^expn > rem` සිට අතිච්ඡාදනය නොවේ.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` `buf.capacity()` (`= self.len() * n`)) ට සමාන වේ.
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// `T` පෙත්තක් `Self::Output` තනි අගයක් බවට පත් කරයි.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// `T` පෙත්තක් `Self::Output` තනි අගයකට සමතලා කර, එක් එක් අතර ලබා දී ඇති බෙදුම්කරු තබයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// `T` පෙත්තක් `Self::Output` තනි අගයකට සමතලා කර, එක් එක් අතර ලබා දී ඇති බෙදුම්කරු තබයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// මෙම පෙත්තෙහි පිටපතක් අඩංගු vector ලබා දෙයි, එහිදී සෑම බයිටයක්ම එහි ASCII ඉහළ අකුරට සමාන වේ.
    ///
    ///
    /// ASCII අක්ෂර 'a' සිට 'z' දක්වා 'A' සිට 'Z' දක්වා සිතියම් ගත කර ඇත, නමුත් ASCII නොවන අකුරු නොවෙනස්ව පවතී.
    ///
    /// ස්ථානයෙහි අගය ඉහළ අගයක් ගැනීමට, [`make_ascii_uppercase`] භාවිතා කරන්න.
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// මෙම පෙත්තෙහි පිටපතක් අඩංගු vector ලබා දෙයි, එහිදී සෑම බයිටයක්ම එහි ASCII කුඩා අකුරට සමාන වේ.
    ///
    ///
    /// ASCII අක්ෂර 'A' සිට 'Z' දක්වා 'a' සිට 'z' දක්වා සිතියම් ගත කර ඇත, නමුත් ASCII නොවන අකුරු නොවෙනස්ව පවතී.
    ///
    /// ස්ථානයෙහි අගය අඩු කිරීමට, [`make_ascii_lowercase`] භාවිතා කරන්න.
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// විශේෂිත දත්ත වලට වඩා පෙති සඳහා traits දිගු කිරීම
////////////////////////////////////////////////////////////////////////////////

/// [`[T]: : concat`](පෙත්ත::concat) සඳහා trait උදව් කරන්න.
///
/// Note: මෙම trait හි `Item` වර්ගයේ පරාමිතිය භාවිතා නොකෙරේ, නමුත් එය impls වඩාත් සාමාන්‍ය වීමට ඉඩ දෙයි.
/// එය නොමැතිව, අපට මෙම දෝෂය ලැබේ:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// මෙයට හේතුව, බහු `Borrow<[_]>` impls සහිත `V` වර්ග තිබිය හැකි නිසා, බහු `T` වර්ග අදාළ වේ:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// සංයුක්ත වීමෙන් පසු ඇතිවන වර්ගය
    type Output;

    /// [`[T]: : concat`](පෙත්ත::කොන්කට්) ක්‍රියාත්මක කිරීම
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// [`[T]: : join`](පෙත්ත::බැඳීම) සඳහා trait උදව් කරන්න
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// සංයුක්ත වීමෙන් පසු ඇතිවන වර්ගය
    type Output;

    /// [`[T]: : join`] ක්‍රියාත්මක කිරීම (පෙත්ත::බැඳීම)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// පෙති සඳහා සම්මත trait ක්‍රියාත්මක කිරීම
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // නැවත ලියනු නොලබන ඕනෑම දෙයක් ඉලක්කයට දමන්න
        target.truncate(self.len());

        // target.len <= self.len ඉහත කප්පාදුව නිසා, මෙහි පෙති සෑම විටම සීමිතය.
        //
        let (init, tail) = self.split_at(target.len());

        // allocations/resources අඩංගු අගයන් නැවත භාවිතා කරන්න.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// පූර්ව වර්ග කළ අනුක්‍රමය `v[1..]` වෙත `v[0]` ඇතුල් කරන්න එවිට මුළු `v[..]` වර්ගීකරණය වේ.
///
/// ඇතුළත් කිරීමේ වර්ග කිරීමේ අනුකලනය මෙයයි.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // මෙහි ඇතුළත් කිරීම ක්‍රියාත්මක කිරීමට ක්‍රම තුනක් තිබේ:
            //
            // 1. පළමුවැන්න එහි අවසාන ගමනාන්තයට පැමිණෙන තෙක් යාබද මූලද්‍රව්‍ය මාරු කරන්න.
            //    කෙසේ වෙතත්, මේ ආකාරයෙන් අපි අවශ්‍ය ප්‍රමාණයට වඩා දත්ත පිටපත් කරමු.
            //    මූලද්රව්ය විශාල ව්යුහයන් නම් (පිටපත් කිරීමට මිල අධික), මෙම ක්රමය මන්දගාමී වනු ඇත.
            //
            // 2. පළමු මූලද්රව්යය සඳහා සුදුසු ස්ථානය සොයා ගන්නා තෙක් අනුකරණය කරන්න.
            // ඉන්පසු එයට අනුබල දෙන මූලද්‍රව්‍ය මාරු කර ඒ සඳහා ඉඩකඩ සලසා අවසානයේ ඉතිරි සිදුරට දමන්න.
            // මෙය හොඳ ක්‍රමයකි.
            //
            // 3. පළමු අංගය තාවකාලික විචල්‍යයකට පිටපත් කරන්න.ඒ සඳහා සුදුසු ස්ථානය සොයා ගන්නා තෙක් අනුකරණය කරන්න.
            // අප ගමන් කරන විට, ගමන් කරන සෑම අංගයක්ම ඊට පෙර ඇති තව් එකට පිටපත් කරන්න.
            // අවසාන වශයෙන්, තාවකාලික විචල්‍යයෙන් දත්ත ඉතිරි කුහරයට පිටපත් කරන්න.
            // මෙම ක්රමය ඉතා හොඳයි.
            // මිණුම් සලකුණු 2 වන ක්‍රමයට වඩා තරමක් හොඳ කාර්ය සාධනයක් පෙන්නුම් කරයි.
            //
            // සියලුම ක්‍රම මිණුම් සලකුණු කර ඇති අතර 3 වන ක්‍රමය හොඳම ප්‍රති .ල පෙන්වයි.ඒ නිසා අපි එය තෝරා ගත්තා.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // ඇතුළත් කිරීමේ ක්‍රියාවලියේ අතරමැදි තත්වය සෑම විටම `hole` විසින් නිරීක්ෂණය කරනු ලැබේ, එය අරමුණු දෙකක් ඉටු කරයි:
            // 1. `is_less` හි panics වෙතින් `v` හි අඛණ්ඩතාව ආරක්ෂා කරයි.
            // 2. `v` හි ඉතිරි කුහරය අවසානයේ පුරවයි.
            //
            // Panic ආරක්ෂාව:
            //
            // ක්‍රියාවලිය අතරතුර ඕනෑම වේලාවක `is_less` panics නම්, `hole` පහත වැටී `v` හි සිදුර `tmp` සමඟ පුරවනු ඇත, එමඟින් `v` තවමත් මුලින් තබා ඇති සෑම වස්තුවක්ම හරියටම වරක් තබා ඇති බව සහතික කරයි.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` පහත වැටෙන අතර එමඟින් `v` හි ඉතිරි සිදුරට `tmp` පිටපත් කරයි.
        }
    }

    // අතහැර දැමූ විට, `src` සිට `dest` දක්වා පිටපත්.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// අඩු නොවන ධාවන `v[..mid]` සහ `v[mid..]`, `buf` භාවිතා කරමින් තාවකාලික ගබඩාවක් ලෙස ඒකාබද්ධ කර ප්‍රති result ලය `v[..]` වෙත ගබඩා කරයි.
///
/// # Safety
///
/// පෙති දෙක හිස් නොවන අතර `mid` මායිම් විය යුතුය.
/// කෙටි පෙත්තක පිටපතක් තබා ගැනීමට ස්වාරක්ෂක `buf` දිගු විය යුතුය.
/// එසේම, `T` ශුන්‍ය ප්‍රමාණයේ වර්ගයක් නොවිය යුතුය.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // ඒකාබද්ධ කිරීමේ ක්‍රියාවලිය මුලින්ම කෙටි ධාවන පථය `buf` වෙත පිටපත් කරයි.
    // ඉන්පසු එය අලුතින් පිටපත් කරන ලද ධාවන පථය සහ දිගු ඉදිරියට (හෝ පසුපසට) ලුහුබඳිනු ඇත, ඒවායේ ඊළඟ අවිධිමත් මූලද්‍රව්‍ය සංසන්දනය කර අඩු (හෝ වැඩි) එකක් `v` වෙත පිටපත් කරයි.
    //
    // කෙටි ධාවනය සම්පූර්ණයෙන්ම පරිභෝජනය කළ වහාම, ක්රියාවලිය සිදු කරනු ලැබේ.පළමුවෙන් වැඩි කාලයක් පරිභෝජනය කරන්නේ නම්, කෙටි ධාවනයේ ඉතිරිව ඇති ඕනෑම දෙයක් `v` හි ඉතිරි සිදුරට පිටපත් කළ යුතුය.
    //
    // ක්‍රියාවලියේ අතරමැදි තත්වය සෑම විටම `hole` විසින් නිරීක්ෂණය කරනු ලැබේ, එය අරමුණු දෙකක් ඉටු කරයි:
    // 1. `is_less` හි panics වෙතින් `v` හි අඛණ්ඩතාව ආරක්ෂා කරයි.
    // 2. දිගු ධාවනය පළමුව පරිභෝජනය කරන්නේ නම් `v` හි ඉතිරි කුහරය පුරවයි.
    //
    // Panic ආරක්ෂාව:
    //
    // ක්‍රියාවලිය අතරතුර ඕනෑම වේලාවක `is_less` panics නම්, `hole` පහත වැටී `v` හි සිදුර `buf` හි අවිධිමත් පරාසය සමඟ පුරවනු ඇත, එමඟින් `v` ආරම්භයේ දී සෑම වස්තුවක්ම හරියටම එකවර තබා ඇති බව සහතික කරයි.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // වම් ධාවනය කෙටි වේ.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // මුලදී, මෙම දර්ශකයන් ඔවුන්ගේ අරා වල ආරම්භය වෙත යොමු කරයි.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // අඩු පැත්ත පරිභෝජනය කරන්න.
            // සමාන නම්, ස්ථාවරත්වය පවත්වා ගැනීම සඳහා වම් ධාවනයට වැඩි කැමැත්තක් දක්වන්න.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // නිවැරදි ධාවනය කෙටි වේ.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // මුලදී, මෙම දර්ශකයන් ඔවුන්ගේ අරා වල කෙළවර පසු කරයි.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // වැඩි පැත්තක් පරිභෝජනය කරන්න.
            // සමාන නම්, ස්ථාවරත්වය පවත්වා ගැනීම සඳහා නිවැරදි ධාවනයට වැඩි කැමැත්තක් දක්වන්න.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // අවසාන වශයෙන්, `hole` පහත වැටේ.
    // කෙටි ධාවනය සම්පූර්ණයෙන් පරිභෝජනය නොකළේ නම්, එහි ඉතිරිව ඇති ඕනෑම දෙයක් දැන් `v` හි සිදුරට පිටපත් කරනු ලැබේ.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // අතහැර දැමූ විට, `start..end` පරාසය `dest..` වෙත පිටපත් කරයි.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` ශුන්‍ය ප්‍රමාණයේ වර්ගයක් නොවේ, එබැවින් එහි ප්‍රමාණයෙන් බෙදීම සුදුසුය.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// මෙම ඒකාබද්ධ කිරීමේ වර්ග කිරීම ටිම්සෝර්ට් වෙතින් අදහස් කිහිපයක් (නමුත් සියල්ලම නොවේ) ලබා ගනී, එය විස්තරාත්මකව [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt) විස්තර කර ඇත.
///
///
/// ඇල්ගොරිතම මගින් ස්වභාවික ලකුණු ලෙස හැඳින්වෙන තදින් බැසයාම සහ බැස නොයන පසු විපරම් හඳුනා ගනී.ඒකාබද්ධ කිරීමට තවම ඉතිරිව ඇති ලකුණු තොගයක් තිබේ.
/// අලුතින් සොයාගත් සෑම ධාවන පථයක්ම තොගයට තල්ලු කරනු ලැබේ, පසුව මෙම ආක්‍රමණ දෙක සෑහීමකට පත්වන තෙක් යාබද ලකුණු යුගල කිහිපයක් ඒකාබද්ධ කෙරේ:
///
/// 1. `1..runs.len()` හි සෑම `i` සඳහාම: `runs[i - 1].len > runs[i].len`
/// 2. `2..runs.len()` හි සෑම `i` සඳහාම: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// සම්පූර්ණ ධාවන කාලය *O*(*n*\*log(* n*)) නරකම අවස්ථාව බව ආක්‍රමණිකයන් සහතික කරයි.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // මෙම දිග දක්වා පෙති ඇතුළු කිරීමේ වර්ග කිරීම මඟින් වර්ග කරනු ලැබේ.
    const MAX_INSERTION: usize = 20;
    // අවම වශයෙන් මෙම බොහෝ මූලද්‍රව්‍යයන් විහිදුවාලීම සඳහා ඇතුළත් කිරීමේ වර්ග කිරීම මඟින් ඉතා කෙටි ලකුණු දිගු කරනු ලැබේ.
    const MIN_RUN: usize = 10;

    // වර්ග කිරීම ශුන්‍ය ප්‍රමාණයේ අර්ථවත් හැසිරීමක් නොමැත.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // වෙන් කිරීම් වලක්වා ගැනීම සඳහා කෙටි අරා ඇතුල් කිරීමේ වර්ග කිරීම මඟින් ස්ථානගත කරනු ලැබේ.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // සීරීම් මතකය ලෙස භාවිතා කිරීමට බෆරයක් වෙන් කරන්න.`is_less` panics නම් පිටපත් මත ධාවනය වන dtors අවදානමට ලක් නොකර `v` හි අන්තර්ගතයේ නොගැඹුරු පිටපත් එහි තබා ගත හැකිය.
    //
    // වර්ග කළ ලකුණු දෙකක් ඒකාබද්ධ කරන විට, මෙම බෆරය කෙටි ධාවනයේ පිටපතක් තබා ඇති අතර, එය සෑම විටම බොහෝ දුරට `len / 2` දිගකින් යුක්ත වේ.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // `v` හි ස්වාභාවික ධාවන හඳුනා ගැනීම සඳහා, අපි එය පසුපසට ගමන් කරමු.
    // එය අමුතු තීරණයක් සේ පෙනේ, නමුත් බොහෝ විට ඒකාබද්ධ වීම ප්‍රතිවිරුද්ධ දිශාවට (forwards) යන කාරණය සලකා බලන්න.
    // මිණුම් සලකුණු වලට අනුව, ඉදිරියට ඒකාබද්ධ කිරීම පසුපසට ඒකාබද්ධ වීමට වඩා තරමක් වේගවත් වේ.
    // නිගමනය කිරීම සඳහා, පසුපසට ගමන් කිරීමෙන් ලකුණු හඳුනා ගැනීම කාර්ය සාධනය වැඩි දියුණු කරයි.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // ඊළඟ ස්වාභාවික ධාවනය සොයාගෙන එය තදින් බැස යන්නේ නම් එය ආපසු හරවන්න.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // එය කෙටි නම් තවත් මූලද්‍රව්‍ය කිහිපයක් ධාවනයට ඇතුළු කරන්න.
        // ඇතුළත් කිරීමේ වර්ග කිරීම කෙටි අනුපිළිවෙලකට ඒකාබද්ධ කිරීමට වඩා වේගවත් වේ, එබැවින් මෙය කාර්ය සාධනය සැලකිය යුතු ලෙස වැඩි දියුණු කරයි.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // මෙම ධාවනය තොගයට තල්ලු කරන්න.
        runs.push(Run { start, len: end - start });
        end = start;

        // ආක්‍රමණිකයන් තෘප්තිමත් කිරීම සඳහා යාබද ධාවන යුගල කිහිපයක් ඒකාබද්ධ කරන්න.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // අවසාන වශයෙන්, හරියටම එක් ධාවනයක් තොගයේ තිබිය යුතුය.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // ලකුණු තොගය පරීක්ෂා කර ඒකාබද්ධ කිරීම සඳහා ඊළඟ ලකුණු යුගලය හඳුනා ගනී.
    // වඩාත් නිශ්චිතවම, `Some(r)` ආපසු ලබා දෙන්නේ නම්, එයින් අදහස් වන්නේ `runs[r]` සහ `runs[r + 1]` ඊළඟට ඒකාබද්ධ කළ යුතු බවයි.
    // ඇල්ගොරිතම ඒ වෙනුවට නව ධාවනයක් ගොඩනඟා ගත යුතු නම්, `None` ආපසු ලබා දෙනු ලැබේ.
    //
    // මෙහි විස්තර කර ඇති පරිදි, ටිම්සෝර්ට් එහි දෝෂ සහිත ක්‍රියාත්මක කිරීම් සඳහා කුප්‍රකට ය:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // කතාවේ සාරාංශය නම්: අපි තොගයේ ඉහළම ලකුණු හතරේ ආක්‍රමණ ක්‍රියාත්මක කළ යුතුය.
    // ඉහළම තිදෙනා මත ඒවා බලාත්මක කිරීම ප්‍රමාණවත් නොවේ, ආක්‍රමණිකයන් තවමත් තොගයේ ඇති සියලුම ලකුණු සඳහා රඳවා තබා ගනී.
    //
    // මෙම ශ්‍රිතය පළමු ලකුණු හතර සඳහා ආක්‍රමණ නිවැරදිව පරීක්ෂා කරයි.
    // මීට අමතරව, ඉහළ ලකුණු දර්ශකය 0 දර්ශකයෙන් ආරම්භ වුවහොත්, වර්ග කිරීම සම්පූර්ණ කිරීම සඳහා, තොගය සම්පුර්ණයෙන්ම බිඳ වැටෙන තෙක් එය ඒකාබද්ධ කිරීමේ මෙහෙයුමක් ඉල්ලා සිටියි.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}