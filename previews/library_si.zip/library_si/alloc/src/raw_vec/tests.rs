use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // තෙවන පාර්ශවීය විබෙදන්නන් සහ `RawVec` අතර ඒකාබද්ධතාවය පිළිබඳ පරීක්ෂණයක් ලිවීම ටිකක් උපක්‍රමශීලී ය, මන්ද `RawVec` API මඟින් වැරදි ලෙස වෙන් කළ හැකි ක්‍රම හෙළි නොකෙරේ, එබැවින් විබෙදුම්කරු අවසන් වූ විට කුමක් සිදුවේදැයි අපට පරීක්ෂා කළ නොහැක (panic හඳුනා ගැනීමට වඩා).
    //
    //
    // ඒ වෙනුවට, මෙය පරික්ෂා කරන්නේ `RawVec` ක්‍රම ගබඩාව වෙන් කර ඇති විට අවම වශයෙන් Allocator API හරහා යනවාද යන්නයි.
    //
    //
    //
    //
    //

    // වෙන්කිරීමේ උත්සාහයන් අසාර්ථක වීමට පෙර ස්ථාවර ඉන්ධන ප්‍රමාණයක් පරිභෝජනය කරන ගොළු විබෙදන්නෙකු.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (නැවත ස්ථානගත කිරීමකට හේතු වේ, මේ අනුව 50 + 150=ඉන්ධන ඒකක 200 ක් භාවිතා කරයි)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // පළමුව, `reserve` `reserve_exact` වැනි වෙන් කරයි.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 යනු 7 ට වඩා දෙගුණයකට වඩා වැඩිය, එබැවින් `reserve` `reserve_exact` මෙන් ක්‍රියා කළ යුතුය.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 යනු 12 න් අඩකටත් වඩා අඩු බැවින් `reserve` on ාතීය ලෙස වර්ධනය විය යුතුය.
        // මෙම පරීක්ෂණ වර්ධන සාධකය 2 වන විට නව ධාරිතාව 24 ක් වේ, කෙසේ වෙතත්, 1.5 හි වර්ධන සාධකය ද හරි ය.
        //
        // එබැවින් `>= 18` ස්ථීරව පවතී.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}