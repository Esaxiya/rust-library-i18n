#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// නව මතකයේ අන්තර්ගතය ආරම්භ කර නොමැත.
    Uninitialized,
    /// නව මතකය ශුන්‍ය වන බවට සහතික වේ.
    Zeroed,
}

/// සම්බන්ධ වී ඇති සියලුම මුලික සිද්ධීන් ගැන කරදර නොවී ගොඩබිම මත මතකයේ බෆරයක් වඩාත් කාර්යක්ෂමව වෙන් කිරීම, නැවත වෙන් කිරීම සහ ගනුදෙනු කිරීම සඳහා පහත් මට්ටමේ උපයෝගීතාවයක්.
///
/// Vec සහ VecDeque වැනි ඔබේම දත්ත ව්‍යුහයන් තැනීම සඳහා මෙම වර්ගය විශිෂ්ටයි.
/// විශේෂයෙන්:
///
/// * `Unique::dangling()` ශුන්‍ය ප්‍රමාණයේ වර්ග මත නිෂ්පාදනය කරයි.
/// * ශුන්‍ය දිග ප්‍රතිපාදන මත `Unique::dangling()` නිෂ්පාදනය කරයි.
/// * `Unique::dangling()` නිදහස් කිරීම වළක්වයි.
/// * ධාරිතා ගණනය කිරීම්වල සියලු පිටාර ගැලීම් අල්ලා ගනී (ඒවා "capacity overflow" panics වෙත ප්‍රවර්ධනය කරයි).
/// * isize::MAX බයිට් වලට වඩා වෙන් කරන 32-බිට් පද්ධති වලට එරෙහිව ආරක්ෂකයින්.
/// * ඔබේ දිග පිරී ඉතිරී යාමෙන් ආරක්ෂා වන්න.
/// * වැරදි වෙන් කිරීම් සඳහා `handle_alloc_error` අමතන්න.
/// * `ptr::Unique` අඩංගු වන අතර එමඟින් පරිශීලකයාට අදාළ සියලු ප්‍රතිලාභ ලබා දේ.
/// * ලබා ගත හැකි විශාලතම ධාරිතාව භාවිතා කිරීම සඳහා ප්‍රතිපාදකයාගෙන් ආපසු ලබා ගත් අතිරික්තය භාවිතා කරයි.
///
/// මෙම වර්ගය කෙසේ හෝ එය කළමනාකරණය කරන මතකය පරීක්ෂා නොකරයි.එය අතහැර දැමූ විට *එහි මතකය නිදහස් කරයි, නමුත් එය* එහි අන්තර්ගතය අතහැර දැමීමට උත්සාහ නොකරයි.
/// `RawVec` ඇතුළත ගබඩා කර ඇති * සත්‍ය දේ හැසිරවීම `RawVec` භාවිතා කරන්නා සතු ය.
///
/// ශුන්‍ය ප්‍රමාණයේ අතිරික්තය සැමවිටම අසීමිත බව සලකන්න, එබැවින් `capacity()` සෑම විටම `usize::MAX` ලබා දෙයි.
/// `capacity()` දිග ලබා නොදෙන බැවින් `Box<[T]>` සමඟ මෙම වර්ගය වටකුරු කිරීමේදී ඔබ ප්‍රවේශම් විය යුතු බව මින් අදහස් වේ.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): මෙය පවතින්නේ `#[unstable]` `const fn`s `min_const_fn` ට අනුකූල නොවිය යුතු නිසා ඒවා`min_const_fn` වලින්ද හැඳින්විය නොහැක.
    ///
    /// ඔබ `RawVec<T>::new` හෝ පරායත්තතා වෙනස් කරන්නේ නම්, කරුණාකර `min_const_fn` සැබවින්ම උල්ලං that නය වන කිසිවක් හඳුන්වා නොදීමට වග බලා ගන්න.
    ///
    /// NOTE: අපට මෙම අනවසරයෙන් වැළකී `min_const_fn` සමඟ අනුකූලතාවයක් අවශ්‍ය වන සමහර `#[rustc_force_min_const_fn]` ගුණාංග සමඟ අනුකූලතාව පරීක්ෂා කළ හැකි නමුත් `#[rustc_const_unstable(feature = "foo", issue = "01234")]` පවතින විට `foo` සක්‍රීය නොකරන `stable(...) const fn`/පරිශීලක කේතයෙන් එය ඇමතීමට අවශ්‍ය නොවේ.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// වෙන් කිරීමකින් තොරව කළ හැකි විශාලතම `RawVec` (පද්ධති ගොඩවල් මත) නිර්මාණය කරයි.
    /// `T` ධනාත්මක ප්‍රමාණයක් තිබේ නම්, මෙය `0` ධාරිතාව සහිත `RawVec` සාදයි.
    /// `T` ශුන්‍ය ප්‍රමාණයේ නම්, එය `usize::MAX` ධාරිතාව සහිත `RawVec` සාදයි.
    /// ප්‍රමාද වූ ප්‍රතිපාදන ක්‍රියාත්මක කිරීම සඳහා ප්‍රයෝජනවත් වේ.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// `[T; capacity]` සඳහා හරියටම ධාරිතාව සහ පෙළගැස්වීමේ අවශ්‍යතා සහිත `RawVec` (පද්ධති ගොඩවල් මත) නිර්මාණය කරයි.
    /// මෙය `capacity` `0` හෝ `T` ශුන්‍ය ප්‍රමාණයේ වන විට `RawVec::new` ඇමතීමට සමාන වේ.
    /// `T` ශුන්‍ය ප්‍රමාණයේ නම් මෙයින් අදහස් කරන්නේ ඔබ ඉල්ලූ ධාරිතාවයෙන් `RawVec` ලබා නොගන්නා බවයි.
    ///
    /// # Panics
    ///
    /// ඉල්ලූ ධාරිතාව `isize::MAX` බයිට් ඉක්මවා ඇත්නම් Panics.
    ///
    /// # Aborts
    ///
    /// OOM මත ගබ්සා කිරීම.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// `with_capacity` මෙන්, නමුත් බෆරය ශුන්‍ය වන බවට සහතික වේ.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// දර්ශකයක් සහ ධාරිතාවෙන් `RawVec` නැවත සකස් කරයි.
    ///
    /// # Safety
    ///
    /// `ptr` වෙන් කළ යුතුය (පද්ධති ගොඩවල් මත), සහ දී ඇති `capacity` සමඟ.
    /// ප්‍රමාණයේ වර්ග සඳහා `capacity` `isize::MAX` නොඉක්මවිය යුතුය.(බිට් 32 පද්ධති පිළිබඳ සැලකිලිමත් වීමක් පමණි).
    /// ZST vectors හි ධාරිතාව `usize::MAX` දක්වා තිබිය හැක.
    /// `ptr` සහ `capacity` පැමිණෙන්නේ `RawVec` වලින් නම්, මෙය සහතික කෙරේ.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // කුඩා Vecs ගොළු ය.වෙත යන්න:
    // - මූලද්‍රව්‍යයේ ප්‍රමාණය 1 නම්, ඕනෑම ගොඩවල් වෙන් කරන්නෙකු බයිට් 8 ට වඩා අඩු ඉල්ලීමක් අවම වශයෙන් බයිට් 8 ක් දක්වා වැඩි කිරීමට ඉඩ ඇත.
    //
    // - 4 මූලද්‍රව්‍ය මධ්‍යස්ථ ප්‍රමාණයේ නම් (<=1 KiB).
    // - 1 වෙනත් ආකාරයකින්, ඉතා කෙටි Vecs සඳහා වැඩි ඉඩක් නාස්ති නොකිරීමට.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// `new` මෙන්, නමුත් ආපසු ලබා දුන් `RawVec` සඳහා විබෙදුම්කරු තෝරාගැනීමේදී පරාමිතිකරණය කර ඇත.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` "unallocated" යන්නෙන් අදහස් වේ.ශුන්‍ය ප්‍රමාණයේ වර්ග නොසලකා හරිනු ලැබේ.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// `with_capacity` මෙන්, නමුත් ආපසු ලබා දුන් `RawVec` සඳහා විබෙදුම්කරු තෝරාගැනීමේදී පරාමිතිකරණය කර ඇත.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// `with_capacity_zeroed` මෙන්, නමුත් ආපසු ලබා දුන් `RawVec` සඳහා විබෙදුම්කරු තෝරාගැනීමේදී පරාමිතිකරණය කර ඇත.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// `Box<[T]>` එකක් `RawVec<T>` බවට පරිවර්තනය කරයි.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// නිශ්චිත `len` සමඟ මුළු බෆරය `Box<[MaybeUninit<T>]>` බවට පරිවර්තනය කරයි.
    ///
    /// මෙය සිදු කර ඇති ඕනෑම `cap` වෙනස්කම් නිවැරදිව ප්‍රතිනිර්මාණය කරන බව සලකන්න.(විස්තර සඳහා වර්ගය පිළිබඳ විස්තරය බලන්න.)
    ///
    /// # Safety
    ///
    /// * `len` මෑතකදී ඉල්ලූ ධාරිතාවට වඩා වැඩි හෝ සමාන විය යුතුය, සහ
    /// * `len` `self.capacity()` ට වඩා අඩු හෝ සමාන විය යුතුය.
    ///
    /// සටහන් කරන්න, ඉල්ලුම් කළ ධාරිතාව සහ `self.capacity()` එකිනෙකට වෙනස් විය හැකි බැවින්, විබෙදන්නෙකුට ඉල්ලුම් කළ ප්‍රමාණයට වඩා වැඩි මතක ප්‍රමාණයක් අවහිර කළ හැකිය.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // ආරක්ෂිත අවශ්‍යතාවයෙන් අඩක් සනීපාරක්ෂාව පරීක්ෂා කරන්න (අපට අනෙක් භාගය පරීක්ෂා කළ නොහැක).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // අපි මෙහි `unwrap_or_else` වළක්වා ගන්නේ එය ජනනය කරන LLVM IR ප්‍රමාණය අවහිර කරන බැවිනි.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// දර්ශකයක්, ධාරිතාවක් සහ විබෙදන්නෙකුගෙන් `RawVec` නැවත සකස් කරයි.
    ///
    /// # Safety
    ///
    /// `ptr` වෙන් කළ යුතුය (දී ඇති විබෙදන්නා `alloc` හරහා), සහ දී ඇති `capacity` සමඟ.
    /// ප්‍රමාණයේ වර්ග සඳහා `capacity` `isize::MAX` නොඉක්මවිය යුතුය.
    /// (බිට් 32 පද්ධති පිළිබඳ සැලකිලිමත් වීමක් පමණි).
    /// ZST vectors හි ධාරිතාව `usize::MAX` දක්වා තිබිය හැක.
    /// `ptr` සහ `capacity` `alloc` හරහා සාදන ලද `RawVec` වෙතින් පැමිණේ නම්, මෙය සහතික කෙරේ.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// ප්‍රතිපාදන ආරම්භයට අමු දර්ශකයක් ලබා ගනී.
    /// `capacity == 0` හෝ `T` ශුන්‍ය ප්‍රමාණයේ නම් මෙය `Unique::dangling()` බව සලකන්න.
    /// කලින් අවස්ථාවේ දී, ඔබ ප්රවේශම් විය යුතුය.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// වෙන් කිරීමේ ධාරිතාව ලබා ගනී.
    ///
    /// `T` ශුන්‍ය ප්‍රමාණයේ නම් මෙය සැමවිටම `usize::MAX` වනු ඇත.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// මෙම `RawVec` සඳහා පිටුබලය දෙන හවුල්කරු වෙත හවුල් සඳහනක් ලබා දෙයි.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // අප සතුව වෙන් කර ඇති මතක කොටසක් ඇත, එබැවින් අපගේ වර්තමාන පිරිසැලසුම ලබා ගැනීම සඳහා අපට ධාවන කාල චෙක්පත් මඟ හැරිය හැක.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// `len + additional` මූලද්‍රව්‍ය රඳවා තබා ගැනීමට අවම වශයෙන් ප්‍රමාණවත් ඉඩ ප්‍රමාණයක් බෆරයේ අඩංගු බව සහතික කරයි.
    /// එයට දැනටමත් ප්‍රමාණවත් ධාරිතාවක් නොමැති නම්, ක්‍රමක්ෂය ලබා ගැනීම සඳහා ප්‍රමාණවත් ඉඩ ප්‍රමාණයක් සහ සුව පහසු මන්දගාමී ඉඩක් නැවත වෙන්කර දෙනු ඇත *O*(1) හැසිරීම.
    ///
    /// panic වෙත අනවශ්‍ය ලෙස හේතු වන්නේ නම් මෙම හැසිරීම සීමා කරනු ඇත.
    ///
    /// `len` `self.capacity()` ඉක්මවා ගියහොත්, ඉල්ලූ අවකාශය සැබවින්ම වෙන් කිරීමට මෙය අසමත් විය හැකිය.
    /// මෙය සැබවින්ම අනාරක්ෂිත නොවේ, නමුත් මෙම ශ්‍රිතයේ හැසිරීම මත රඳා පවතින *ඔබ* ලියන අනාරක්ෂිත කේතය කැඩී යා හැක.
    ///
    /// `extend` වැනි තොග තල්ලු කිරීමේ මෙහෙයුමක් ක්‍රියාත්මක කිරීම සඳහා මෙය වඩාත් සුදුසු වේ.
    ///
    /// # Panics
    ///
    /// නව ධාරිතාව `isize::MAX` බයිට් ඉක්මවන්නේ නම් Panics.
    ///
    /// # Aborts
    ///
    /// OOM මත ගබ්සා කිරීම.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // කාචය `isize::MAX` ඉක්මවා ගියහොත් සංචිතය ගබ්සා වීමට හෝ භීතියට පත්වීමට ඉඩ ඇති බැවින් මෙය දැන් පරීක්ෂා කර බැලීම ආරක්ෂිත වේ.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// `reserve` හා සමානයි, නමුත් කලබල වීම හෝ ගබ්සා කිරීම වෙනුවට දෝෂ මත නැවත පැමිණේ.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// `len + additional` මූලද්‍රව්‍ය රඳවා තබා ගැනීමට අවම වශයෙන් ප්‍රමාණවත් ඉඩ ප්‍රමාණයක් බෆරයේ අඩංගු බව සහතික කරයි.
    /// එය දැනටමත් නොමැති නම්, අවශ්‍ය අවම මතක ප්‍රමාණය නැවත වෙන්කර දෙනු ඇත.
    /// සාමාන්‍යයෙන් මෙය අවශ්‍ය මතකයේ ප්‍රමාණයම වනු ඇත, නමුත් ප්‍රතිපත්තිමය වශයෙන්, අප ඉල්ලා සිටි ප්‍රමාණයට වඩා ආපසු ලබා දීමට ප්‍රතිපාදකයාට නිදහස තිබේ.
    ///
    ///
    /// `len` `self.capacity()` ඉක්මවා ගියහොත්, ඉල්ලූ අවකාශය සැබවින්ම වෙන් කිරීමට මෙය අසමත් විය හැකිය.
    /// මෙය සැබවින්ම අනාරක්ෂිත නොවේ, නමුත් මෙම ශ්‍රිතයේ හැසිරීම මත රඳා පවතින *ඔබ* ලියන අනාරක්ෂිත කේතය කැඩී යා හැක.
    ///
    /// # Panics
    ///
    /// නව ධාරිතාව `isize::MAX` බයිට් ඉක්මවන්නේ නම් Panics.
    ///
    /// # Aborts
    ///
    /// OOM මත ගබ්සා කිරීම.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// `reserve_exact` හා සමානයි, නමුත් කලබල වීම හෝ ගබ්සා කිරීම වෙනුවට දෝෂ මත නැවත පැමිණේ.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// වෙන් කිරීම නියමිත ප්‍රමාණයට අඩු කරයි.
    /// ලබා දී ඇති මුදල 0 නම්, ඇත්ත වශයෙන්ම සම්පූර්ණයෙන්ම ඉවත් වේ.
    ///
    /// # Panics
    ///
    /// ලබා දී ඇති මුදල වත්මන් ධාරිතාවට වඩා * විශාල නම් Panics.
    ///
    /// # Aborts
    ///
    /// OOM මත ගබ්සා කිරීම.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// අවශ්‍ය අමතර ධාරිතාව සපුරාලීම සඳහා බෆරය වර්ධනය වීමට අවශ්‍ය නම් නැවත පැමිණේ.
    /// `grow` ආදානය නොකර සංචිත ඇමතුම් ලබා ගැනීමට ප්‍රධාන වශයෙන් භාවිතා වේ.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // මෙම ක්‍රමය සාමාන්‍යයෙන් බොහෝ වාර ගණනක් ක්ෂණිකව ක්‍රියාත්මක වේ.එබැවින් අපට අවශ්‍ය වන්නේ එය හැකි තරම් කුඩා වීමට, සම්පාදනය කරන වේලාවන් වැඩි දියුණු කිරීමට ය.
    // නමුත් ජනනය කරන ලද කේතය වේගයෙන් ක්‍රියාත්මක කිරීම සඳහා එහි අන්තර්ගතය හැකි තරම් සංඛ්‍යානමය වශයෙන් ගණනය කිරීමට අපට අවශ්‍යය.
    // එමනිසා, මෙම ක්‍රමය ප්‍රවේශමෙන් ලියා ඇති බැවින් `T` මත රඳා පවතින සියලුම කේත ඒ තුළ ඇති අතර, හැකි තරම් `T` මත රඳා නොපවතින කේතයේ බොහෝමයක් `T` ට වඩා සාමාන්‍ය නොවන ක්‍රියාකාරකම් වල පවතී.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // ඇමතුම් සන්දර්භය මගින් මෙය සහතික කෙරේ.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // `elem_size` වන විට අපි `usize::MAX` ධාරිතාව නැවත ලබා දෙන බැවින්
            // 0, මෙහි පැමිණීම අනිවාර්යයෙන්ම අදහස් කරන්නේ `RawVec` අධික ලෙස පිරී ඇති බවයි.
            return Err(CapacityOverflow);
        }

        // කනගාටුවට කරුණක් නම්, මෙම චෙක්පත් සම්බන්ධයෙන් අපට සැබවින්ම කළ හැකි කිසිවක් නැත.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // මෙය on ාතීය වර්ධනයක් සහතික කරයි.
        // `cap <= isize::MAX` සහ `cap` වර්ගය `usize` නිසා දෙගුණ කිරීම පිටාර ගැලිය නොහැක.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` ට වඩා සාමාන්‍ය නොවේ.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // මෙම ක්‍රමයේ ඇති බාධක `grow_amortized` හි ඇති ඒවාට වඩා බොහෝ සෙයින් සමාන ය, නමුත් මෙම ක්‍රමය සාමාන්‍යයෙන් අඩු වාර ගණනක් ක්ෂණිකව සිදු කරනු ලැබේ.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // වර්ගය ප්‍රමාණය වන විට අපි `usize::MAX` ධාරිතාවයක් ආපසු ලබා දෙන බැවින්
            // 0, මෙහි පැමිණීම අනිවාර්යයෙන්ම අදහස් කරන්නේ `RawVec` අධික ලෙස පිරී ඇති බවයි.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` ට වඩා සාමාන්‍ය නොවේ.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// සම්පාදනය කරන වේලාවන් අවම කිරීම සඳහා මෙම කාර්යය `RawVec` වලින් පිටත වේ.වැඩි විස්තර සඳහා `RawVec::grow_amortized` ඉහත අදහස බලන්න.
// (`A` පරාමිතිය සැලකිය යුතු නොවේ, මන්ද ප්‍රායෝගිකව දක්නට ලැබෙන විවිධ `A` වර්ග ගණන `T` වර්ග සංඛ්‍යාවට වඩා බෙහෙවින් අඩුය.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // `RawVec::grow_*` ප්‍රමාණය අවම කිරීම සඳහා මෙහි දෝෂය පරීක්ෂා කරන්න.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // පෙළගැස්වීමේ සමානාත්මතාවය සඳහා විබෙදන්නා පරීක්ෂා කරයි
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// `RawVec`*සතු මතකය* එහි අන්තර්ගතය අතහැර දැමීමට උත්සාහ නොකර නිදහස් කරයි.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// සංචිත දෝෂ හැසිරවීම සඳහා කේන්ද්‍රීය කාර්යය.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// අපි පහත සඳහන් දෑ සහතික කළ යුතුයි:
// * අපි කවදාවත් `> isize::MAX` බයිට් ප්‍රමාණයේ වස්තු වෙන් නොකරමු.
// * අපි `usize::MAX` පිටාර ගැලන්නේ නැති අතර ඇත්ත වශයෙන්ම ඉතා සුළු ප්‍රමාණයක් වෙන් කරමු.
//
// 64-බිට් මත අපි පිටාර ගැලීම සඳහා පරීක්ෂා කළ යුතු බැවින් `> isize::MAX` බයිට් වෙන් කිරීමට උත්සාහ කිරීම නිසැකවම අසාර්ථක වනු ඇත.
// 32-බිට් සහ 16-බිට් මත අපි 4GB පරිශීලක අවකාශයේ භාවිතා කළ හැකි වේදිකාවක් මත ධාවනය වන විට මේ සඳහා අමතර ආරක්ෂාවක් එක් කළ යුතුය, උදා: PAE හෝ x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// ධාරිතාව පිටාර ගැලීම වාර්තා කිරීම සඳහා වගකිව යුතු එක් කේන්ද්‍රීය කාර්යයක්.
// මොඩියුලය පුරාම පොකුරක් වෙනුවට panics ඇති එකම ස්ථානයක් ඇති බැවින් මෙම panics හා සම්බන්ධ කේත උත්පාදනය අවම බව මෙය සහතික කරයි.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}