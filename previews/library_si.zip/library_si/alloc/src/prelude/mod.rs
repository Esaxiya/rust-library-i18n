//! Prelude වෙන් කිරීම
//!
//! මෙම මොඩියුලයේ පරමාර්ථය වන්නේ මොඩියුලවල ඉහළට ගෝලීය ආනයනයක් එකතු කිරීමෙන් `alloc` crate හි බහුලව භාවිතා වන භාණ්ඩ ආනයනය කිරීම අවම කිරීමයි:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;