#![stable(feature = "wake_trait", since = "1.51.0")]
//! අසමමුහුර්ත කාර්යයන් සමඟ වැඩ කිරීම සඳහා වර්ග සහ Traits.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// ක්රියාත්මක කරන්නෙකු මත කර්තව්‍යයක් අවදි කිරීම ක්රියාත්මක කිරීම.
///
/// මෙම trait [`Waker`] නිර්මාණය කිරීමට භාවිතා කළ හැකිය.
/// විධායකයෙකුට මෙම trait ක්‍රියාත්මක කිරීම නිර්වචනය කළ හැකි අතර, එම ක්‍රියාකරු මත ක්‍රියාත්මක වන කාර්යයන් වෙත යොමු කිරීම සඳහා වේකර් තැනීම සඳහා එය භාවිතා කරන්න.
///
/// මෙම trait යනු [`RawWaker`] ඉදිකිරීම සඳහා මතක ආරක්ෂිත සහ ergonomic විකල්පයකි.
/// කාර්යයක් අවදි කිරීමට භාවිතා කරන දත්ත [`Arc`] තුළ ගබඩා කර ඇති පොදු ක්‍රියාත්මක කිරීමේ සැලසුමට එය සහාය දක්වයි.
/// සමහර විධායකයින්ට (විශේෂයෙන් කාවැද්දූ පද්ධති සඳහා) මෙම API භාවිතා කළ නොහැක, එම නිසා [`RawWaker`] එම පද්ධති සඳහා විකල්පයක් ලෙස පවතී.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// මූලික `block_on` ශ්‍රිතයක් වන future ගෙන එය වර්තමාන නූල් මත සම්පූර්ණ කිරීමට ක්‍රියාත්මක වේ.
///
/// **Note:** මෙම උදාහරණය සරල බව සඳහා නිවැරදි බව වෙළඳාම් කරයි.
/// අවහිරතා වලක්වා ගැනීම සඳහා, නිෂ්පාදන මට්ටමේ ක්‍රියාත්මක කිරීම සඳහා `thread::unpark` වෙත අතරමැදි ඇමතුම් මෙන්ම කැදැලි ආයාචනා ද හැසිරවිය යුතුය.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// වත්මන් නූල් කැඳවූ විට අවදි වන වේකර් කෙනෙක්.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// වත්මන් ත්‍රෙඩ් එක සම්පූර්ණ කිරීමට future ධාවනය කරන්න.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // future පින් කරන්න එවිට එය ඡන්දය ප්‍රකාශ කළ හැකිය.
///     let mut fut = Box::pin(fut);
///
///     // future වෙත යැවීමට නව සන්දර්භයක් සාදන්න.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // සම්පුර්ණ කිරීමට future ධාවනය කරන්න.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// මෙම කාර්යය අවදි කරන්න.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// වෝකර් පරිභෝජනය නොකර මෙම කාර්යය අවදි කරන්න.
    ///
    /// විධායකය අවදි කිරීමට වඩා ලාභදායී ක්‍රමයක් සඳහා සහාය දක්වන්නේ නම්, එය මෙම ක්‍රමය ඉක්මවා යා යුතුය.
    /// පෙරනිමියෙන්, එය [`Arc`] ක්ලෝන කරන අතර ක්ලෝනයට [`wake`] අමතයි.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // ආරක්ෂාව: raw_waker ආරක්ෂිතව ගොඩනඟන බැවින් මෙය ආරක්ෂිතයි
        // ආර්ක් වෙතින් රාවෝකර්<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: RawWaker තැනීම සඳහා මෙම පුද්ගලික කාර්යය භාවිතා කරනු ලැබේ
// `From<Arc<W>> for Waker` හි ආරක්ෂාව නිවැරදි trait යැවීම මත රඳා නොපවතින බව සහතික කිරීම සඳහා මෙය `From<Arc<W>> for RawWaker` impl වෙත යොමු කිරීම, ඒ වෙනුවට impls දෙකම මෙම ශ්‍රිතය සෘජුව හා පැහැදිලිව අමතයි.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // එය ක්ලෝන කිරීම සඳහා චාපයේ යොමු ගණන වැඩි කරන්න.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // අගය අනුව අවදි වන්න, චාප Wake::wake ශ්‍රිතයට ගෙනයන්න
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // යොමු කිරීමෙන් අවදි වන්න, එය අතහැර දැමීම වලක්වා ගැනීම සඳහා වේකර් මැනුවල් ඩ්‍රොප් හි ඔතා
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // පහත වැටෙන විට චාපයේ යොමු ගණන අඩු කරන්න
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}