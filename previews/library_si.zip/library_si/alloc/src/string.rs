//! UTF-8-කේතනය කළ, වර්ධනය කළ හැකි නූලක්.
//!
//! මෙම මොඩියුලයේ [`String`] වර්ගය, නූල් බවට පරිවර්තනය කිරීම සඳහා [`ToString`] trait සහ [`String`] සමඟ වැඩ කිරීමෙන් ඇතිවිය හැකි දෝෂ වර්ග කිහිපයක් අඩංගු වේ.
//!
//!
//! # Examples
//!
//! වචනාර්ථයෙන් නව [`String`] නිර්මාණය කිරීමට විවිධ ක්‍රම තිබේ:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! සමගාමීව ඔබට දැනට පවතින එකකින් නව [`String`] නිර්මාණය කළ හැකිය
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! ඔබට වලංගු UTF-8 බයිට් වල vector තිබේ නම්, ඔබට එයින් [`String`] සෑදිය හැකිය.ඔබට ආපසු හැරවීමද කළ හැකිය.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // මෙම බයිට් වලංගු බව අපි දනිමු, එබැවින් අපි `unwrap()` භාවිතා කරමු.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// UTF-8-කේතනය කළ, වර්ධනය කළ හැකි නූලක්.
///
/// `String` වර්ගය යනු නූල් වල අන්තර්ගතයට වඩා හිමිකාරිත්වයක් ඇති වඩාත් පොදු නූල් වර්ගයයි.එහි ණයට ගත් සහකාරිය වන ප්‍රාථමික [`str`] සමඟ සමීප සම්බන්ධතාවයක් ඇත.
///
/// # Examples
///
/// ඔබට [`String::from`] සමඟ [a literal string][`str`] වෙතින් `String` නිර්මාණය කළ හැකිය:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// ඔබට [`push`] ක්‍රමය සමඟ `String` වෙත [`char`] එකතු කළ හැකි අතර [`push_str`] ක්‍රමය සමඟ [`&str`] එකතු කළ හැකිය:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// ඔබට UTF-8 බයිට් වල vector තිබේ නම්, ඔබට [`from_utf8`] ක්‍රමය සමඟ එයින් `String` නිර්මාණය කළ හැකිය:
///
/// ```
/// // vector හි සමහර බයිට්
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // මෙම බයිට් වලංගු බව අපි දනිමු, එබැවින් අපි `unwrap()` භාවිතා කරමු.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `String`s සැමවිටම වලංගු UTF-8 වේ.මෙයට ඇඟවුම් කිහිපයක් ඇත, ඉන් පළමුවැන්න නම් ඔබට යූටීඑෆ්-8 නොවන නූලක් අවශ්‍ය නම් [`OsString`] සලකා බලන්න.එය සමාන ය, නමුත් UTF-8 බාධාවකින් තොරව.දෙවන ඇඟවුම නම් ඔබට `String` වෙත සුචිගත කළ නොහැකි බවයි:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// සුචිගත කිරීම නියත-කාලීන මෙහෙයුමක් වීමට අදහස් කරයි, නමුත් UTF-8 කේතීකරණය අපට මෙය කිරීමට ඉඩ නොදේ.තවද, දර්ශකය නැවත පැමිණිය යුත්තේ කුමන ආකාරයේද යන්න පැහැදිලි නැත: බයිට්, කෝඩ්පොයින්ට් හෝ ග්‍රැපේම් පොකුරු.
/// [`bytes`] සහ [`chars`] ක්‍රම මඟින් පිළිවෙලින් පළමු දෙක හරහා නැවත ක්‍රියාකරවන්නන් යවනු ලැබේ.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String`s ක්‍රියාත්මක කිරීම [`Deref`] `<Target=str>`, එබැවින් සියලු ක්‍රමෝපායන් උරුම කර ගන්න.මීට අමතරව, මෙයින් අදහස් කරන්නේ ඔබට ඇම්පියර්සෑන්ඩ් (`&`) භාවිතා කරමින් [`&str`] ගන්නා ශ්‍රිතයකට `String` යැවිය හැකි බවයි:
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// මෙය `String` වෙතින් [`&str`] නිර්මාණය කර එය පසුකර යනු ඇත. මෙම පරිවර්තනය ඉතා මිල අඩු වන අතර, සාමාන්‍යයෙන්, යම් නිශ්චිත හේතුවක් නිසා `String` අවශ්‍ය නොවන්නේ නම්, කාර්යයන් [`&str`] තර්ක ලෙස පිළිගනු ඇත.
///
/// සමහර අවස්ථාවලදී X0Rust0Z හි [`Deref`] බලහත්කාරය ලෙස හැඳින්වෙන මෙම පරිවර්තනය කිරීමට ප්‍රමාණවත් තොරතුරු නොමැත.පහත උදාහරණයේ දී [`&'a str`][`&str`] නූලක් trait `TraitExample` ක්‍රියාත්මක කරන අතර `example_func` ශ්‍රිතය trait ක්‍රියාත්මක කරන ඕනෑම දෙයක් ගනී.
/// මෙම අවස්ථාවෙහිදී, Rust හට ව්‍යංග පරිවර්තන දෙකක් කිරීමට අවශ්‍ය වනු ඇත, Rust හට කිරීමට ක්‍රමයක් නොමැත.
/// එම හේතුව නිසා, පහත උදාහරණය සම්පාදනය නොකරනු ඇත.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// ඒ වෙනුවට ක්‍රියාත්මක වන විකල්ප දෙකක් තිබේ.පළමුවැන්න නම්, `example_func(&example_string);` රේඛාව `example_func(example_string.as_str());` ලෙස වෙනස් කිරීම, [`as_str()`] ක්‍රමය භාවිතා කරමින් නූල් අඩංගු නූල් පෙත්ත පැහැදිලිව උකහා ගැනීමයි.
/// දෙවන ක්‍රමය `example_func(&example_string);` සිට `example_func(&*example_string);` දක්වා වෙනස් කරයි.
/// මෙම අවස්ථාවේදී අපි `String` සිට [`str`][`&str`] දක්වා විරූපණය කරමින්, පසුව [`str`][`&str`] නැවත [`&str`] වෙත යොමු කරමු.
/// දෙවන ක්‍රමය වඩාත් මුග්ධ ය, කෙසේ වෙතත් දෙදෙනාම ව්‍යංග පරිවර්තනය කෙරෙහි විශ්වාසය තැබීමට වඩා පැහැදිලිවම පරිවර්තනය කිරීමට කටයුතු කරති.
///
/// # Representation
///
/// `String` සංරචක තුනකින් සෑදී ඇත: සමහර බයිට් වලට දර්ශකයක්, දිගක් සහ ධාරිතාවක්.දර්ශකය එහි දත්ත ගබඩා කිරීම සඳහා භාවිතා කරන අභ්‍යන්තර බෆරයක් `String` වෙත යොමු කරයි.දිග යනු දැනට බෆරයේ ගබඩා කර ඇති බයිට් ගණන වන අතර ධාරිතාව යනු බෆරයේ බෆරයේ ප්‍රමාණයයි.
///
/// එනිසා දිග සෑම විටම ධාරිතාවට වඩා අඩු හෝ සමාන වනු ඇත.
///
/// මෙම බෆරය සෑම විටම ගොඩවල් මත ගබඩා වේ.
///
/// [`as_ptr`], [`len`], සහ [`capacity`] ක්‍රම සමඟ ඔබට මේවා දෙස බැලිය හැකිය:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME vec_into_raw_parts ස්ථාවර වූ විට මෙය යාවත්කාලීන කරන්න.
/// // සංගීතයේ දත්ත ස්වයංක්‍රීයව වැටීම වළක්වන්න
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // කතාවට බයිට් දහනවයක් ඇත
/// assert_eq!(19, len);
///
/// // අපට ptr, len සහ ධාරිතාවෙන් පිටත සංගීත භාණ්ඩයක් නැවත ගොඩනගා ගත හැකිය.
/// // මේ සියල්ල අනාරක්‍ෂිත වන්නේ සංරචක වලංගු බවට වග බලා ගැනීම අපගේ වගකීම වන බැවිනි:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// `String` හි ප්‍රමාණවත් ධාරිතාවක් තිබේ නම්, එයට මූලද්‍රව්‍ය එකතු කිරීමෙන් නැවත වෙන් නොකෙරේ.උදාහරණයක් ලෙස, මෙම වැඩසටහන සලකා බලන්න:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// මෙය පහත සඳහන් දෑ ප්‍රතිදානය කරයි:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// මුලදී, අපට කිසිසේත් මතකයක් වෙන් කර නැත, නමුත් අපි නූලට එකතු වන විට, එය නිසි පරිදි එහි ධාරිතාව වැඩි කරයි.මුලින් නිවැරදි ධාරිතාව වෙන් කිරීම සඳහා අපි ඒ වෙනුවට [`with_capacity`] ක්‍රමය භාවිතා කරන්නේ නම්:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// අපි වෙනස් නිමැවුමකින් අවසන් කරමු:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// මෙන්න, ලූපය තුළ වැඩි මතකයක් වෙන් කිරීම අවශ්ය නොවේ.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// UTF-8 බයිට් vector වෙතින් `String` පරිවර්තනය කිරීමේදී සිදුවිය හැකි දෝෂ අගයක්.
///
/// මෙම වර්ගය [`String`] හි [`from_utf8`] ක්‍රමය සඳහා වන දෝෂ වර්ගයයි.
/// එය නැවත සැලසුම් කිරීම වළක්වා ගැනීම සඳහා නිර්මාණය කර ඇත: [`into_bytes`] ක්‍රමය මඟින් පරිවර්තන උත්සාහයේදී භාවිතා කළ vector බයිට් ආපසු ලබා දෙනු ඇත.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// [`std::str`] විසින් සපයන ලද [`Utf8Error`] වර්ගය නිරූපණය කරන්නේ [`u8`] පෙත්තක් [`&str`] බවට පරිවර්තනය කිරීමේදී සිදුවිය හැකි දෝෂයකි.
/// මෙම අර්ථයෙන් ගත් කල, එය `FromUtf8Error` ට ප්‍රතිසමයක් වන අතර, ඔබට `FromUtf8Error` වෙතින් [`utf8_error`] ක්‍රමය හරහා එකක් ලබා ගත හැකිය.
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// මූලික භාවිතය:
///
/// ```
/// // vector හි අවලංගු බයිට් කිහිපයක්
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// UTF-16 බයිට් පෙත්තකින් `String` පරිවර්තනය කිරීමේදී සිදුවිය හැකි දෝෂ අගයක්.
///
/// මෙම වර්ගය [`String`] හි [`from_utf16`] ක්‍රමය සඳහා වන දෝෂ වර්ගයයි.
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// මූලික භාවිතය:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// නව හිස් `String` නිර්මාණය කරයි.
    ///
    /// `String` හිස් බැවින්, මෙය කිසිදු ආරම්භක බෆරයක් වෙන් නොකරයි.මෙම ආරම්භක මෙහෙයුම ඉතා මිල අඩු බව එයින් අදහස් වන අතර, ඔබ දත්ත එකතු කරන විට එය පසුව අධික ලෙස වෙන් කිරීමට හේතු විය හැක.
    ///
    /// `String` කොපමණ දත්ත ප්‍රමාණයක් රඳවා තබා ගනීද යන්න පිළිබඳ අදහසක් ඔබට තිබේ නම්, අධික ලෙස නැවත වෙන් කිරීම වැළැක්වීම සඳහා [`with_capacity`] ක්‍රමය සලකා බලන්න.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// විශේෂිත ධාරිතාවක් සහිත නව හිස් `String` නිර්මාණය කරයි.
    ///
    /// `String`s හි දත්ත රඳවා තබා ගැනීමට අභ්‍යන්තර බෆරයක් ඇත.
    /// ධාරිතාව යනු එම බෆරයේ දිග වන අතර එය [`capacity`] ක්‍රමය සමඟ විමසිය හැකිය.
    /// මෙම ක්‍රමය හිස් `String` නිර්මාණය කරයි, නමුත් `capacity` බයිට් රඳවා තබා ගත හැකි ආරම්භක බෆරයක් සහිත එකක්.
    /// ඔබ `String` වෙත දත්ත පොකුරක් එකතු කරන විට මෙය ප්‍රයෝජනවත් වේ, එය කළ යුතු නැවත වෙන් කිරීම් ගණන අඩු කරයි.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// දී ඇති ධාරිතාව `0` නම්, කිසිදු ප්‍රතිපාදනයක් සිදු නොවන අතර මෙම ක්‍රමය [`new`] ක්‍රමයට සමාන වේ.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // වැඩි ගණනක් සඳහා ධාරිතාවක් තිබුණද, අක්ෂරයට අක්ෂර නොමැත
    /// assert_eq!(s.len(), 0);
    ///
    /// // මේ සියල්ල නැවත වෙන් කිරීමකින් තොරව සිදු කෙරේ ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... නමුත් මෙය නූල් නැවත ස්ථානගත කිරීමට හේතු වේ
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): cfg(test) සමඟ මෙම ක්‍රම නිර්වචනය සඳහා අවශ්‍ය වන සහජ `[T]::to_vec` ක්‍රමය ලබා ගත නොහැක.
    // පරීක්ෂණ කටයුතු සඳහා අපට මෙම ක්‍රමය අවශ්‍ය නොවන බැවින්, වැඩි විස්තර සඳහා NB slice.rs හි slice::hack මොඩියුලය බලන්න.
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// vector බයිට් `String` බවට පරිවර්තනය කරයි.
    ///
    /// ([`String`]) නූලක් ([`u8`]) බයිට් වලින් සාදා ඇති අතර vector බයිට් ([`Vec<u8>`]) බයිට් වලින් සාදා ඇත, එබැවින් මෙම ශ්‍රිතය දෙක අතර පරිවර්තනය වේ.
    /// සෑම බයිට් පෙති වලංගු වන්නේ `නූල්` ය, කෙසේ වෙතත්: `String` ට වලංගු UTF-8 අවශ්‍ය වේ.
    /// `from_utf8()` බයිට් වලංගු UTF-8 බව තහවුරු කර ගැනීම සඳහා පරික්ෂා කර, පසුව පරිවර්තනය කරයි.
    ///
    /// බයිට් පෙත්ත වලංගු UTF-8 බව ඔබට විශ්වාස නම්, සහ වලංගු චෙක්පතට ඉහළින් යාමට ඔබට අවශ්‍ය නැතිනම්, මෙම ශ්‍රිතයේ අනාරක්ෂිත අනුවාදයක් ඇත, [`from_utf8_unchecked`], එකම හැසිරීමක් ඇති නමුත් චෙක්පත මඟ හැරේ.
    ///
    ///
    /// මෙම ක්‍රමය කාර්යක්ෂමතාව වෙනුවෙන් vector පිටපත් නොකිරීමට වගබලා ගනී.
    ///
    /// ඔබට `String` වෙනුවට [`&str`] අවශ්‍ය නම්, [`str::from_utf8`] සලකා බලන්න.
    ///
    /// මෙම ක්‍රමයේ ප්‍රතිලෝම [`into_bytes`] වේ.
    ///
    /// # Errors
    ///
    /// සපයන ලද බයිට් UTF-8 නොවන්නේ මන්ද යන්න පිළිබඳ විස්තරයක් සහිත පෙත්තක් UTF-8 නොවේ නම් [`Err`] ලබා දෙයි.ඔබ ගෙන ගිය vector ද ඇතුළත් වේ.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// // vector හි සමහර බයිට්
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // මෙම බයිට් වලංගු බව අපි දනිමු, එබැවින් අපි `unwrap()` භාවිතා කරමු.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// වැරදි බයිට්:
    ///
    /// ```
    /// // vector හි අවලංගු බයිට් කිහිපයක්
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// මෙම දෝෂය සමඟ ඔබට කළ හැකි දේ පිළිබඳ වැඩි විස්තර සඳහා [`FromUtf8Error`] සඳහා ලියකියවිලි බලන්න.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// අවලංගු අක්ෂර ඇතුළුව බයිට් පෙත්තක් නූලකට පරිවර්තනය කරයි.
    ///
    /// නූල් ([`u8`]) බයිට් වලින් සාදා ඇති අතර ([`&[u8]`][byteslice]) බයිට් පෙත්තක් බයිට් වලින් සාදා ඇත, එබැවින් මෙම ශ්‍රිතය දෙක අතර පරිවර්තනය වේ.සියලුම බයිට් පෙති වලංගු නූල් නොවේ, කෙසේ වෙතත්: නූල් වලංගු UTF-8 විය යුතුය.
    /// මෙම පරිවර්තනය අතරතුර, `from_utf8_lossy()` ඕනෑම අවලංගු UTF-8 අනුක්‍රමයක් [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] සමඟ ප්‍රතිස්ථාපනය කරයි, එය මේ ආකාරයට පෙනේ:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// බයිට් පෙත්ත වලංගු UTF-8 බව ඔබට විශ්වාස නම්, සහ පරිවර්තනයේ පොදු පිරිවැය දැරීමට ඔබට අවශ්‍ය නැතිනම්, මෙම ශ්‍රිතයේ අනාරක්ෂිත අනුවාදයක් ඇත, [`from_utf8_unchecked`], එකම හැසිරීමක් ඇති නමුත් චෙක්පත් මඟ හැරේ.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// මෙම ශ්‍රිතය [`Cow<'a, str>`] ලබා දෙයි.අපගේ බයිට් පෙත්ත අවලංගු UTF-8 නම්, අපි ආදේශන අක්ෂර ඇතුළත් කළ යුතු අතර, එමඟින් නූල්වල ප්‍රමාණය වෙනස් වන අතර එබැවින් `String` අවශ්‍ය වේ.
    /// නමුත් එය දැනටමත් වලංගු UTF-8 නම්, අපට නව ප්‍රතිපාදනයක් අවශ්‍ය නොවේ.
    /// මෙම ප්‍රතිලාභ වර්ගය අපට අවස්ථා දෙකම හැසිරවීමට ඉඩ දෙයි.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// // vector හි සමහර බයිට්
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// වැරදි බයිට්:
    ///
    /// ```
    /// // සමහර අවලංගු බයිට්
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// UTF-16-කේතනය කරන ලද vector `v` `String` බවට විකේතනය කරන්න, `v` හි කිසියම් අවලංගු දත්තයක් තිබේ නම් [`Err`] ආපසු එවයි.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // එකතු කිරීම හරහා මෙය සිදු නොවේ: : <Result<_, _>> () කාර්ය සාධන හේතු සඳහා.
        // FIXME: #48994 වසා ඇති විට ශ්‍රිතය නැවත සරල කළ හැකිය.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// අවලංගු දත්ත [the replacement character (`U+FFFD`)][U+FFFD] සමඟ ප්‍රතිස්ථාපනය කරමින් UTF-16-කේතනය කරන ලද පෙත්තක් `v` `String` බවට විකේතනය කරන්න.
    ///
    /// X002 ආපසු ලබා දෙන [`from_utf8_lossy`] මෙන් නොව, `from_utf16_lossy` `String` ලබා දෙන බැවින් UTF-16 සිට UTF-8 පරිවර්තනයට මතක වෙන් කිරීමක් අවශ්‍ය වේ.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// `String` එහි අමු සංරචක වලට දිරාපත් කරයි.
    ///
    /// අමු දර්ශකය යටින් පවතින දත්ත, නූල් වල දිග (බයිට් වලින්) සහ දත්තවල වෙන් කළ ධාරිතාව (බයිට් වලින්) ලබා දෙයි.
    /// මේවා [`from_raw_parts`] සඳහා වන තර්ක මෙන් එකම අනුපිළිවෙලෙහි ඇති තර්ක වේ.
    ///
    /// මෙම ශ්‍රිතය ඇමතීමෙන් පසුව, `String` විසින් කලින් කළමනාකරණය කරන ලද මතකය සඳහා අමතන්නා වගකිව යුතුය.
    /// මෙය කළ හැකි එකම ක්‍රමය වන්නේ අමු දර්ශකය, දිග සහ ධාරිතාව [`from_raw_parts`] ශ්‍රිතය සමඟ නැවත `String` බවට පරිවර්තනය කිරීම, විනාශ කරන්නාට පිරිසිදු කිරීම සිදු කිරීමට ඉඩ දීමයි.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// දිග, ධාරිතාව සහ දර්ශකය වෙතින් නව `String` නිර්මාණය කරයි.
    ///
    /// # Safety
    ///
    /// පරීක්ෂා නොකරන ලද ආක්‍රමණ ගණන නිසා මෙය බෙහෙවින් අනාරක්ෂිත ය:
    ///
    /// * `buf` හි මතකය කලින් වෙන් කර තිබිය යුත්තේ සම්මත පුස්තකාලය භාවිතා කරන එකම විබෙදන්නා විසින් වන අතර අවශ්‍ය පෙළගැස්ම හරියටම 1 කි.
    /// * `length` `capacity` ට වඩා අඩු හෝ සමාන විය යුතුය.
    /// * `capacity` නිවැරදි අගය විය යුතුය.
    /// * `buf` හි පළමු `length` බයිට් වලංගු UTF-8 විය යුතුය.
    ///
    /// මේවා උල්ලං ting නය කිරීමෙන් විබෙදන්නාගේ අභ්‍යන්තර දත්ත ව්‍යුහයන් දූෂණය කිරීම වැනි ගැටළු ඇති විය හැකිය.
    ///
    /// `buf` හි හිමිකාරිත්වය `String` වෙත effectively ලදායී ලෙස මාරු කරනු ලබන අතර එමඟින් අවශ්‍ය පරිදි දර්ශකය විසින් පෙන්වා දෙන මතකයේ අන්තර්ගතය නැවත ස්ථානගත කිරීම, නැවත වෙන් කිරීම හෝ වෙනස් කිරීම සිදු කළ හැකිය.
    /// මෙම ශ්‍රිතය ඇමතීමෙන් පසුව වෙනත් කිසිවක් දර්ශකය භාවිතා නොකරන බවට සහතික වන්න.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME vec_into_raw_parts ස්ථාවර වූ විට මෙය යාවත්කාලීන කරන්න.
    ///     // සංගීතයේ දත්ත ස්වයංක්‍රීයව වැටීම වළක්වන්න
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// නූල වල වලංගු UTF-8 අඩංගු දැයි පරීක්ෂා නොකර vector බයිට් `String` බවට පරිවර්තනය කරයි.
    ///
    /// වැඩි විස්තර සඳහා ආරක්ෂිත අනුවාදය වන [`from_utf8`] බලන්න.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// මෙම ශ්‍රිතය අනාරක්ෂිත වන්නේ එයට ලබා දුන් බයිට් වලංගු UTF-8 දැයි පරික්ෂා නොකරන බැවිනි.
    /// මෙම සීමාව උල්ලං is නය වී ඇත්නම්, එය `String` හි future භාවිතා කරන්නන් සමඟ මතක අනාරක්ෂිත ගැටළු ඇති කළ හැකිය, අනෙක් සම්මත පුස්තකාලය උපකල්පනය කරන්නේ `String` වලංගු UTF-8 බවයි.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// // vector හි සමහර බයිට්
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// `String` බයිට් vector බවට පරිවර්තනය කරයි.
    ///
    /// මෙය `String` පරිභෝජනය කරයි, එබැවින් අපට එහි අන්තර්ගතය පිටපත් කිරීමට අවශ්‍ය නොවේ.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// සම්පූර්ණ `String` අඩංගු නූල් පෙත්තක් උපුටා ගනී.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// `String` විකෘති නූල් පෙත්තක් බවට පරිවර්තනය කරයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// මෙම `String` හි අවසානයට දී ඇති නූල් පෙත්තක් එකතු කරයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// මෙම `සංගීතයේ ධාරිතාව බයිට් වලින් ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// මෙම සංගීත භාණ්ඩයේ ධාරිතාව අවම වශයෙන් `additional` බයිට් එහි දිගට වඩා විශාල බව සහතික කරයි.
    ///
    /// නිරන්තරයෙන් නැවත ස්ථානගත කිරීම වැළැක්වීම සඳහා ධාරිතාව තෝරා ගන්නේ නම් `additional` බයිට් වලට වඩා වැඩි කළ හැකිය.
    ///
    ///
    /// ඔබට මෙම "at least" හැසිරීම අවශ්‍ය නැතිනම්, [`reserve_exact`] ක්‍රමය බලන්න.
    ///
    /// # Panics
    ///
    /// නව ධාරිතාව [`usize`] ඉක්මවා ගියහොත් Panics.
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// මෙය ඇත්ත වශයෙන්ම ධාරිතාව වැඩි නොකරනු ඇත:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s හි දිග 2 ක් සහ ධාරිතාව 10 කි
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // අපට දැනටමත් අමතර ධාරිතාව 8 ක් ඇති බැවින් මෙය අමතන්න ...
    /// s.reserve(8);
    ///
    /// // ... ඇත්ත වශයෙන්ම වැඩි නොවේ.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// මෙම `String` හි ධාරිතාව `additional` බයිට් එහි දිගට වඩා විශාල බව සහතික කරයි.
    ///
    /// ඔබ වෙන් කරන්නාට වඩා හොඳින් නොදන්නේ නම් [`reserve`] ක්‍රමය භාවිතා කිරීම ගැන සලකා බලන්න.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// නව ධාරිතාව `usize` ඉක්මවා ගියහොත් Panics.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// මෙය ඇත්ත වශයෙන්ම ධාරිතාව වැඩි නොකරනු ඇත:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s හි දිග 2 ක් සහ ධාරිතාව 10 කි
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // අපට දැනටමත් අමතර ධාරිතාව 8 ක් ඇති බැවින් මෙය අමතන්න ...
    /// s.reserve_exact(8);
    ///
    /// // ... ඇත්ත වශයෙන්ම වැඩි නොවේ.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// ලබා දී ඇති `String` තුළ අවම වශයෙන් `additional` වැඩි මූලද්‍රව්‍යයක් ඇතුළත් කිරීමට ධාරිතාව වෙන් කර ගැනීමට උත්සාහ කරයි.
    /// නිරන්තරයෙන් නැවත ස්ථානගත කිරීම වළක්වා ගැනීම සඳහා එකතු කිරීමට වැඩි ඉඩක් වෙන් කළ හැකිය.
    /// `reserve` ඇමතීමෙන් පසු, ධාරිතාව `self.len() + additional` ට වඩා වැඩි හෝ සමාන වේ.
    /// ධාරිතාව දැනටමත් ප්රමාණවත් නම් කිසිවක් නොකරයි.
    ///
    /// # Errors
    ///
    /// ධාරිතාව පිටාර ගැලීම හෝ විබෙදන්නා අසමත් වීමක් වාර්තා කරන්නේ නම් දෝෂයක් නැවත ලබා දෙනු ලැබේ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // මතකය කලින් වෙන් කරවා ගන්න, අපට නොහැකි නම් පිටවීම
    ///     output.try_reserve(data.len())?;
    ///
    ///     // දැන් අපි දන්නවා අපේ සංකීර්ණ වැඩ මැද මෙය OOM කළ නොහැකි බව
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// දී ඇති `String` හි ඇතුළත් කළ යුතු තවත් මූලද්‍රව්‍යයන් සඳහා හරියටම `additional` සඳහා අවම ධාරිතාව වෙන් කර ගැනීමට උත්සාහ කරයි.
    ///
    /// `reserve_exact` ඇමතීමෙන් පසු, ධාරිතාව `self.len() + additional` ට වඩා වැඩි හෝ සමාන වේ.
    /// ධාරිතාව දැනටමත් ප්රමාණවත් නම් කිසිවක් නොකරයි.
    ///
    /// වෙන් කරන්නා එකතු කිරීමට ඉල්ලීමට වඩා වැඩි ඉඩක් ලබා දෙන බව සලකන්න.
    /// එබැවින් ධාරිතාවය අවම වශයෙන් රඳා පැවතිය නොහැක.
    /// future ඇතුළු කිරීම් අපේක්ෂා කරන්නේ නම් `reserve` ට වැඩි කැමැත්තක් දක්වන්න.
    ///
    /// # Errors
    ///
    /// ධාරිතාව පිටාර ගැලීම හෝ විබෙදන්නා අසමත් වීමක් වාර්තා කරන්නේ නම් දෝෂයක් නැවත ලබා දෙනු ලැබේ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // මතකය කලින් වෙන් කරවා ගන්න, අපට නොහැකි නම් පිටවීම
    ///     output.try_reserve(data.len())?;
    ///
    ///     // දැන් අපි දන්නවා අපේ සංකීර්ණ වැඩ මැද මෙය OOM කළ නොහැකි බව
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// මෙම `String` හි දිගට ගැලපෙන පරිදි ධාරිතාව හැකිලී යයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// මෙම `String` හි ධාරිතාව අඩු මායිමකින් හැකිලී යයි.
    ///
    /// ධාරිතාව දිග හා සැපයූ වටිනාකම යන දෙකම තරම් අවම වශයෙන් පවතිනු ඇත.
    ///
    ///
    /// වත්මන් ධාරිතාව පහළ සීමාවට වඩා අඩු නම්, මෙය විකල්පයක් නොවේ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// මෙම `String` අවසානය දක්වා දී ඇති [`char`] එකතු කරයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// මෙම `String` හි අන්තර්ගතයේ බයිට් පෙත්තක් ලබා දෙයි.
    ///
    /// මෙම ක්‍රමයේ ප්‍රතිලෝම [`from_utf8`] වේ.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// මෙම `String` නිශ්චිත දිගට කෙටි කරයි.
    ///
    /// `new_len` නූල් වල වත්මන් දිගට වඩා වැඩි නම්, මෙය කිසිදු බලපෑමක් ඇති නොකරයි.
    ///
    ///
    /// මෙම ක්‍රමය නූල්වල වෙන් කළ ධාරිතාවයට කිසිදු බලපෑමක් නොකරන බව සලකන්න
    ///
    /// # Panics
    ///
    /// `new_len` [`char`] මායිමක නොසිටින්නේ නම් Panics.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// නූල් බෆරයෙන් අවසාන අක්‍ෂරය ඉවත් කර එය නැවත ලබා දෙයි.
    ///
    /// මෙම `String` හිස් නම් [`None`] ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// මෙම `String` වෙතින් [`char`] බයිට් ස්ථානයකින් ඉවත් කර එය ආපසු ලබා දේ.
    ///
    /// මෙය *O*(*n*) මෙහෙයුමක් වන බැවින් එයට බෆරයේ සෑම අංගයක්ම පිටපත් කිරීම අවශ්‍ය වේ.
    ///
    /// # Panics
    ///
    /// 0Panics, `idx` `String` හි දිගට වඩා විශාල හෝ සමාන නම් හෝ එය [`char`] මායිමක නොපවතින්නේ නම්.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// `String` හි `pat` රටාවේ සියලුම ගැලපීම් ඉවත් කරන්න.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// ගැලපීම් හඳුනාගෙන නැවත ක්‍රියාකාරීව ඉවත් කරනු ලැබේ, එබැවින් රටා අතිච්ඡාදනය වන අවස්ථා වලදී පළමු රටාව පමණක් ඉවත් කරනු ලැබේ:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // ආරක්ෂාව: ආරම්භය සහ අවසානය එක් එක් utf8 බයිට් මායිම් මත වේ
        // සෙවුම් ලේඛනය
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// පුරෝකථනය මඟින් නියම කර ඇති අක්ෂර පමණක් රඳවා ගනී.
    ///
    /// වෙනත් වචන වලින් කිවහොත්, `f(c)` `false` ආපසු ලබා දෙන `c` අක්ෂර ඉවත් කරන්න.
    /// මෙම ක්‍රමය ක්‍රියාත්මක වන අතර, සෑම අක්‍ෂරයක්ම මුල් අනුපිළිවෙලට හරියටම එක් වරක් නැරඹීම සහ රඳවා ගත් අක්ෂරවල අනුපිළිවෙල ආරක්ෂා කරයි.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// දර්ශකය වැනි බාහිර තත්වය නිරීක්ෂණය කිරීම සඳහා නිශ්චිත අනුපිළිවෙල ප්‍රයෝජනවත් විය හැකිය.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // ඊළඟ වර්‍ගයට idx යොමු කරන්න
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// මෙම `String` වෙත අක්ෂරයක් බයිට් ස්ථානයක ඇතුළත් කරයි.
    ///
    /// මෙය *O*(*n*) මෙහෙයුමක් බැවින් එයට බෆරයේ සෑම අංගයක්ම පිටපත් කිරීම අවශ්‍ය වේ.
    ///
    /// # Panics
    ///
    /// 0Panics, `idx` `String` හි දිගට වඩා විශාල නම් හෝ එය [`char`] මායිමක නොපවතී නම්.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// මෙම `String` වෙත බයිට් ස්ථානයක නූල් පෙත්තක් ඇතුල් කරයි.
    ///
    /// මෙය *O*(*n*) මෙහෙයුමක් බැවින් එයට බෆරයේ සෑම අංගයක්ම පිටපත් කිරීම අවශ්‍ය වේ.
    ///
    /// # Panics
    ///
    /// 0Panics, `idx` `String` හි දිගට වඩා විශාල නම් හෝ එය [`char`] මායිමක නොපවතී නම්.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// මෙම `String` හි අන්තර්ගතයට විකෘති යොමු කිරීමක් ලබා දෙයි.
    ///
    /// # Safety
    ///
    /// මෙම ශ්‍රිතය අනාරක්ෂිත වන්නේ එයට ලබා දුන් බයිට් වලංගු UTF-8 දැයි පරික්ෂා නොකරන බැවිනි.
    /// මෙම සීමාව උල්ලං is නය වී ඇත්නම්, එය `String` හි future භාවිතා කරන්නන් සමඟ මතක අනාරක්ෂිත ගැටළු ඇති කළ හැකිය, අනෙක් සම්මත පුස්තකාලය උපකල්පනය කරන්නේ `String` වලංගු UTF-8 බවයි.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// මෙම `String` හි දිග බයිට් වලින් ලබා දෙයි, [`char`] හෝ ග්‍රැෆීම් නොවේ.
    /// වෙනත් වචන වලින් කිවහොත්, එය නූල් වල දිග ලෙස මිනිසෙකු සලකන දේ නොවිය හැකිය.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// මෙම `String` හි දිග ශුන්‍යයක් තිබේ නම් `true` සහ වෙනත් ආකාරයකින් `false` ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// දී ඇති බයිට් දර්ශකයේ දී නූල දෙකට බෙදයි.
    ///
    /// අලුතින් වෙන් කරන ලද `String` ලබා දෙයි.
    /// `self` `[0, at)` බයිට් අඩංගු වන අතර ආපසු ලබා දුන් `String` හි බයිට් `[at, len)` අඩංගු වේ.
    /// `at` UTF-8 කේත ලක්ෂ්‍යයක මායිමේ විය යුතුය.
    ///
    /// `self` හි ධාරිතාව වෙනස් නොවන බව සලකන්න.
    ///
    /// # Panics
    ///
    /// 0Panics, `at` යනු `UTF-8` කේත ලක්ෂ්‍ය මායිමක නොමැති නම්, හෝ එය නූලෙහි අවසාන කේත ලක්ෂ්‍යයෙන් ඔබ්බට නම්.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// සියලුම අන්තර්ගතයන් ඉවත් කරමින් මෙම `String` කප්පාදු කරයි.
    ///
    /// මෙයින් අදහස් කරන්නේ `String` හි දිග ශුන්‍ය වන නමුත් එය එහි ධාරිතාව ස්පර්ශ නොකරන බවයි.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// `String` හි නිශ්චිත පරාසය ඉවත් කර ඉවත් කළ `chars` ලබා දෙන ජලාපවහන අනුකාරකයක් සාදයි.
    ///
    ///
    /// Note: ඉරේටරය අවසානය දක්වා පරිභෝජනය නොකළද මූලද්‍රව්‍ය පරාසය ඉවත් කරනු ලැබේ.
    ///
    /// # Panics
    ///
    /// ආරම්භක ස්ථානය හෝ අවසන් ලක්ෂ්‍යය [`char`] මායිමක නොපවතින්නේ නම් හෝ ඒවා සීමාවෙන් පිටත නම් Panics.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // නූලෙන් β තෙක් පරාසය ඉහළට ඉවත් කරන්න
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // සම්පූර්ණ පරාසයක් නූල ඉවත් කරයි
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // මතක ආරක්ෂාව
        //
        // Drain හි String අනුවාදයේ vector අනුවාදයේ මතක ආරක්ෂණ ගැටළු නොමැත.
        // දත්ත සරල බයිට් පමණි.
        // පරාසය ඉවත් කිරීම Drop හි සිදුවන නිසා, Drain iterator කාන්දු වී ඇත්නම්, ඉවත් කිරීම සිදු නොවේ.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // එකවර ණය දෙකක් ගන්න.
        // ඩ්‍රොප් හි, නැවත ක්‍රියා කිරීම අවසන් වන තුරු &mut සංගීතයට ප්‍රවේශ නොවනු ඇත.
        let self_ptr = self as *mut _;
        // ආරක්ෂාව: `slice::range` සහ `is_char_boundary` සුදුසු සීමාවන් පරීක්ෂා කරයි.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// නූලෙහි නිශ්චිත පරාසය ඉවත් කර එය ලබා දී ඇති නූල සමඟ ප්‍රතිස්ථාපනය කරයි.
    /// දී ඇති නූලට පරාසයට සමාන දිගක් අවශ්‍ය නොවේ.
    ///
    /// # Panics
    ///
    /// ආරම්භක ස්ථානය හෝ අවසන් ලක්ෂ්‍යය [`char`] මායිමක නොපවතින්නේ නම් හෝ ඒවා සීමාවෙන් පිටත නම් Panics.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // නූලෙන් β තෙක් පරාසය ඉහළට ආදේශ කරන්න
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // මතක ආරක්ෂාව
        //
        // Replace_range සතුව vector Splice එකක මතක ආරක්ෂණ ගැටළු නොමැත.
        // vector අනුවාදයේ.දත්ත සරල බයිට් පමණි.

        // අවවාදයයි: මෙම විචල්‍යය ඇතුලත් කිරීම අසීමිත (#81138) වනු ඇත
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // අවවාදයයි: මෙම විචල්‍යය ඇතුලත් කිරීම අසීමිත (#81138) වනු ඇත
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // `range` නැවත භාවිතා කිරීම අසීමිත වනු ඇත (#81138) `range` විසින් වාර්තා කරන ලද සීමාවන් එලෙසම පවතිනු ඇතැයි අපි උපකල්පනය කරමු, නමුත් ඇමතුම් අතර විරුද්ධවාදී ක්‍රියාත්මක කිරීමක් වෙනස් විය හැකිය
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// මෙම `String` [`කොටුව`]`<`[`str`] `>` බවට පරිවර්තනය කරයි.
    ///
    /// මෙය ඕනෑම අතිරික්ත ධාරිතාවක් පහත වැටෙනු ඇත.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// `String` බවට පරිවර්තනය කිරීමට උත්සාහ කළ [`u8`] බයිට් පෙත්තක් ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// // vector හි අවලංගු බයිට් කිහිපයක්
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// `String` බවට පරිවර්තනය කිරීමට උත්සාහ කළ බයිට් නැවත ලබා දෙයි.
    ///
    /// වෙන් කිරීම වළක්වා ගැනීම සඳහා මෙම ක්රමය ප්රවේශමෙන් ඉදිකර ඇත.
    /// එය දෝෂය පරිභෝජනය කරයි, බයිට් පිටතට ගෙන යාම, එවිට බයිට් වල පිටපතක් සෑදීම අවශ්‍ය නොවේ.
    ///
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// // vector හි අවලංගු බයිට් කිහිපයක්
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// පරිවර්තන අසාර්ථකත්වය පිළිබඳ වැඩි විස්තර ලබා ගැනීමට `Utf8Error` ලබා ගන්න.
    ///
    /// [`std::str`] විසින් සපයන ලද [`Utf8Error`] වර්ගය නිරූපණය කරන්නේ [`u8`] පෙත්තක් [`&str`] බවට පරිවර්තනය කිරීමේදී සිදුවිය හැකි දෝෂයකි.
    /// මෙම අර්ථයෙන් ගත් කල, එය `FromUtf8Error` සඳහා ප්‍රතිසමයක් වේ.
    /// එය භාවිතා කිරීම පිළිබඳ වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// // vector හි අවලංගු බයිට් කිහිපයක්
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // පළමු බයිටය මෙහි වලංගු නොවේ
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // අපි 'ස්ට්‍රිං' හරහා නැවත ක්‍රියා කරන නිසා, අපට අවම වශයෙන් එක් ප්‍රතිපාදනයක් වත් වළක්වා ගත හැකිය, පළමු නූල නැවත අනුකාරකයෙන් ලබාගෙන ඊට පසුව ඇති සියලුම නූල් එයට එකතු කිරීමෙන්.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // අපි CoWs හරහා නැවත ක්‍රියා කරන නිසා, අපට පළමු අයිතමය ලබා ගැනීමෙන් හා ඊට පසුව එන සියලුම අයිතම එකතු කිරීමෙන් (potentially) අවම වශයෙන් එක් වෙන් කිරීමක් වළක්වා ගත හැකිය.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// `&str` සඳහා impl වෙත පැවරෙන පහසුවකි.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// හිස් `String` සාදයි.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// නූල් දෙකක් සංයුක්ත කිරීම සඳහා `+` ක්‍රියාකරු ක්‍රියාත්මක කරයි.
///
/// මෙය වම් පස ඇති `String` පරිභෝජනය කරන අතර එහි බෆරය නැවත භාවිතා කරයි (අවශ්‍ය නම් එය වැඩීම).
/// මෙය සිදු කරනුයේ නව `String` වෙන් කිරීම සහ සෑම මෙහෙයුමකම සම්පූර්ණ අන්තර්ගතය පිටපත් කිරීම වළක්වා ගැනීම සඳහා වන අතර, එමඟින් *O*(*n*^ 2) ධාවන කාලය *n*-බයිට් නූලක් නැවත නැවත සංයුක්ත කිරීමෙන් ගොඩනඟයි.
///
///
/// දකුණු පස ඇති නූල ණයට ගනු ලැබේ;එහි අන්තර්ගතය ආපසු ලබා දුන් `String` වෙත පිටපත් කරනු ලැබේ.
///
/// # Examples
///
/// 'නූල්' දෙකක් සංයුක්ත කිරීම පළමුවැන්න අගය අනුව ගෙන දෙවැන්න ණයට ගනී:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` ගෙන යන අතර තවදුරටත් මෙහි භාවිතා කළ නොහැක.
/// ```
///
/// ඔබට පළමු `String` දිගටම භාවිතා කිරීමට අවශ්‍ය නම්, ඔබට එය ක්ලෝන කර ඒ වෙනුවට ක්ලෝනයට එකතු කළ හැකිය:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` තවමත් මෙහි වලංගු වේ.
/// ```
///
/// පළමුවැන්න `String` බවට පරිවර්තනය කිරීමෙන් `&str` පෙති සංයුක්ත කිරීම කළ හැකිය:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// `String` වෙත එකතු කිරීම සඳහා `+=` ක්‍රියාකරු ක්‍රියාත්මක කරයි.
///
/// මෙය [`push_str`][String::push_str] ක්‍රමයට සමාන හැසිරීමක් ඇත.
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// [`Infallible`] සඳහා අන්වර්ථයකි.
///
/// මෙම අන්වර්ථය පසුගාමී අනුකූලතාව සඳහා පවතින අතර අවසානයේදී එය ඉවත් කරනු ලැබේ.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// අගය `String` බවට පරිවර්තනය කිරීම සඳහා trait.
///
/// [`Display`] trait ක්‍රියාත්මක කරන ඕනෑම වර්ගයක් සඳහා මෙම trait ස්වයංක්‍රීයව ක්‍රියාත්මක වේ.
/// එනිසා `ToString` කෙලින්ම ක්‍රියාත්මක නොකළ යුතුය:
/// [`Display`] ඒ වෙනුවට ක්‍රියාත්මක කළ යුතු අතර ඔබට `ToString` ක්‍රියාත්මක කිරීම නොමිලේ ලැබේ.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// දී ඇති අගය `String` බවට පරිවර්තනය කරයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// මෙම ක්‍රියාවට නැංවීමේදී, `Display` ක්‍රියාත්මක කිරීම දෝෂයක් ලබා දෙන්නේ නම් `to_string` ක්‍රමය panics.
/// `fmt::Write for String` කිසි විටෙකත් දෝෂයක් ලබා නොදෙන බැවින් මෙය වැරදි `Display` ක්‍රියාත්මක කිරීමක් පෙන්නුම් කරයි.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // පොදු මාර්ගෝපදේශයක් වන්නේ සාමාන්‍ය කාර්යයන් නොබැඳීමයි.
    // කෙසේ වෙතත්, මෙම ක්‍රමයෙන් `#[inline]` ඉවත් කිරීම නොසැලකිලිමත් නොවන ප්‍රතිගාමීත්වයට හේතු වේ.
    // එය ඉවත් කිරීමට උත්සාහ කිරීමේ අවසාන උත්සාහය වන <https://github.com/rust-lang/rust/pull/74852> බලන්න.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// `&mut str` එකක් `String` බවට පරිවර්තනය කරයි.
    ///
    /// ප්රති result ලය ගොඩවල් මත වෙන් කරනු ලැබේ.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: පරීක්ෂණය libstd තුළට අදින අතර එය මෙහි දෝෂ ඇති කරයි
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// ලබා දී ඇති කොටු කළ `str` පෙත්ත `String` බවට පරිවර්තනය කරයි.
    /// `str` පෙත්ත අයිති බව සැලකිය යුතු ය.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// දී ඇති `String` අයිති කොටු කළ `str` පෙත්තක් බවට පරිවර්තනය කරයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// නූල් පෙත්තක් ණයට ගත් ප්‍රභේදයක් බවට පරිවර්තනය කරයි.
    /// ගොඩවල් වෙන් කිරීමක් සිදු නොකරන අතර, නූල් පිටපත් නොකෙරේ.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// නූලක් අයිති ප්‍රභේදයක් බවට පරිවර්තනය කරයි.
    /// ගොඩවල් වෙන් කිරීමක් සිදු නොකරන අතර, නූල් පිටපත් නොකෙරේ.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// නූල් යොමුව ණයට ගත් ප්‍රභේදයක් බවට පරිවර්තනය කරයි.
    /// ගොඩවල් වෙන් කිරීමක් සිදු නොකරන අතර, නූල් පිටපත් නොකෙරේ.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// දී ඇති `String`, `u8` වර්ගයේ අගයන් දරණ vector `Vec` බවට පරිවර්තනය කරයි.
    ///
    /// # Examples
    ///
    /// මූලික භාවිතය:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// `String` සඳහා ජලාපවහන අනුකාරකයක්.
///
/// [`String`] හි [`drain`] ක්‍රමය මඟින් මෙම ව්‍යුහය නිර්මාණය කර ඇත.
/// වැඩි විස්තර සඳහා එහි ප්‍රලේඛනය බලන්න.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// විනාශ කරන්නාගේ විකෘති නූලක් ලෙස භාවිතා කරනු ඇත
    string: *mut String,
    /// ඉවත් කිරීමට කොටස ආරම්භ කරන්න
    start: usize,
    /// ඉවත් කිරීමට කොටසක අවසානය
    end: usize,
    /// ඉවත් කිරීමට දැනට ඉතිරිව ඇති පරාසය
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Vec::drain භාවිතා කරන්න.
            // "Reaffirm" panic කේතය නැවත ඇතුළත් නොකිරීමට සීමාවන් පරීක්ෂා කරයි.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// මෙම අනුකාරකයේ ඉතිරි (උප) නූල පෙත්තක් ලෙස ලබා දෙයි.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: අසමතුලිතතාවය AsRef ස්ථාවර කිරීමේදී පහත සඳහන් වේ.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// `string_drain_as_str` ස්ථාවර කිරීමේදී අසහනය.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>Drain සඳහා <'a> {fn as_ref(&self)-> &str for සඳහා
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// Drain <'a> {fn as_ref(&self)-> සහ [u8] for සඳහා impl <' a> AsRef <[u8]>
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}