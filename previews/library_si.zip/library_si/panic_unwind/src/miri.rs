//! මිරි සඳහා panics ඉවත් කිරීම.
use alloc::boxed::Box;
use core::any::Any;

// මිරි එන්ජිම අප වෙනුවෙන් නොදැනුවත්ව ප්‍රචාරය කරන ගෙවීම් වර්ගය.
// දර්ශක ප්‍රමාණයේ විය යුතුය.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// නොදැනුවත්වම ආරම්භ කිරීම සඳහා මිරි විසින් සපයන ලද බාහිර ක්‍රියාකාරිත්වය.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // අපි `miri_start_panic` වෙත ගෙවන ගෙවීම හරියටම පහත `cleanup` හි ඇති තර්කය වනු ඇත.
    // ඒ නිසා අපි එය එක් වරක් කොටු කර ගන්නවා, දර්ශක ප්‍රමාණයේ යමක් ලබා ගැනීමට.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // යටින් පවතින `Box` නැවත ලබා ගන්න.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}