//! panics ක්‍රියාත්මක කිරීම
//!
//! මෙම crate යනු Rust හි panics ක්‍රියාත්මක කිරීමකි. මෙය සම්පාදනය කෙරෙන වේදිකාවේ "most native" ස්ටැක් නොවරදින යාන්ත්‍රණය භාවිතා කරයි.
//! මෙය අත්‍යවශ්‍යයෙන්ම දැනට බාල්දි තුනකට වර්ග කර ඇත:
//!
//! 1. MSVC ඉලක්ක `seh.rs` ගොනුවේ SEH භාවිතා කරයි.
//! 2. Emscripten `emcc.rs` ගොනුවේ C++ ව්‍යතිරේක භාවිතා කරයි.
//! 3. අනෙක් සියලුම ඉලක්ක `gcc.rs` ගොනුවේ libunwind/libgcc භාවිතා කරයි.
//!
//! එක් එක් ක්‍රියාත්මක කිරීම පිළිබඳ වැඩි ලියකියවිලි අදාළ මොඩියුලයෙන් සොයාගත හැකිය.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` මිරි සමඟ භාවිතා නොකෙරේ, එබැවින් නිහ silence අනතුරු ඇඟවීම්.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Rust ධාවන වේලාවේ ආරම්භක වස්තු මෙම සංකේත මත රඳා පවතී, එබැවින් ඒවා ප්‍රසිද්ධ කරන්න.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // නොදැනුවත්වම සහාය නොදක්වන ඉලක්ක.
        // - arch=wasm32
        // - os=කිසිවක් නැත ("bare metal" ඉලක්ක)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // මිරි ධාවන කාලය භාවිතා කරන්න.
        // rustc අපේක්ෂා කරන පරිදි, එතැන් සිට යම් යම් ලැන්ග් අයිතම නිර්වචනය කරනු ඇතැයි අපේක්ෂා කරන බැවින්, අප තවමත් සාමාන්‍ය සාමාන්‍ය ධාවන වේලාව පැටවිය යුතුය.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // නියම ධාවන කාලය භාවිතා කරන්න.
        use real_imp as imp;
    }
}

extern "C" {
    /// `catch_unwind` වලින් පිටත panic වස්තුවක් අතහැර දැමූ විට libstd හි හසුරුවන්නා හැඳින්වේ.
    ///
    fn __rust_drop_panic() -> !;

    /// විදේශීය ව්‍යතිරේකයක් හසු වූ විට libstd හි හසුරුවන්නා කැඳවනු ලැබේ.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// ව්‍යතිරේකයක් මතු කිරීම සඳහා වන පිවිසුම් ස්ථානය, වේදිකාව-විශේෂිත ක්‍රියාත්මක කිරීම සඳහා නියෝජිතයින් ය.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}