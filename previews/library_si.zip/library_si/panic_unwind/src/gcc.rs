//! libgcc/libunwind හි සහාය ඇතිව panics ක්‍රියාත්මක කිරීම (යම් ආකාරයකින්).
//!
//! ව්‍යතිරේක හැසිරවීම සහ තොග නොදැනීම පිළිබඳ පසුබිම සඳහා කරුණාකර "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) සහ එයින් සම්බන්ධිත ලේඛන බලන්න.
//! මේවා හොඳ කියවීම් ද වේ:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## කෙටි සාරාංශයක්
//!
//! ව්‍යතිරේකය හැසිරවීම අදියර දෙකකින් සිදු වේ: සෙවුම් අවධියක් සහ පිරිසිදු කිරීමේ අවධියක්.
//!
//! අදියර දෙකෙහිම, නොබැඳෙන තැනැත්තා වත්මන් ක්‍රියාවලියේ මොඩියුලවල කොටස් ඉවත් කර සිරස් රාමු ඉහළ සිට පහළට ගමන් කරයි (මෙහි "module" යන්නෙන් අදහස් කරන්නේ මෙහෙයුම් පද්ධතියේ මොඩියුලයක්, එනම් ක්‍රියාත්මක කළ හැකි හෝ ගතික පුස්තකාලයකි).
//!
//!
//! සෑම සිරස් රාමුවක් සඳහාම, එය සම්බන්ධිත "personality routine" සඳහා ආයාචනා කරයි, එහි ලිපිනය ද නොවරදින තොරතුරු කොටසේ ගබඩා කර ඇත.
//!
//! සෙවීමේ අවධියේදී, පෞරුෂ චර්යාවක කාර්යය වන්නේ ව්‍යතිරේක වස්තුව විසි කිරීම පරීක්ෂා කිරීම සහ එය එම සිරස් රාමුවට හසු විය යුතුද යන්න තීරණය කිරීමයි.හසුරුවන රාමුව හඳුනාගත් පසු, පිරිසිදු කිරීමේ අදියර ආරම්භ වේ.
//!
//! පිරිසිදු කිරීමේ අදියරේදී, නොදැනුවත්වම එක් එක් පෞරුෂ චර්යාව නැවත ක්‍රියාත්මක කරයි.
//! වත්මන් තොග රාමුව සඳහා කුමන පිරිසිදු කිරීමේ කේතය ක්‍රියාත්මක කළ යුතුද යන්න මෙවර එය තීරණය කරයි.එසේ නම්, පාලනය ක්‍රියාකාරී ශරීරයේ විශේෂ branch වෙත මාරු කරනු ලැබේ, "landing pad", එය විනාශ කරන්නන්ට ආරාධනා කරයි, මතකය නිදහස් කරයි.
//! ගොඩබෑමේ පෑඩ් එක අවසානයේ, පාලනය නැවත නොදැනුවත්ව හා නොදැනුවත්වම නැවත මාරු කරනු ලැබේ.
//!
//! හෑන්ඩ්ලර් රාමු මට්ටමට තොගය නිරුපද්‍රිත වූ පසු, නොනවතින නැවතුම් සහ අවසාන පෞරුෂ චර්යාව පාලනය අල්ලා ගැනීමේ කොටස වෙත මාරු කරයි.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Rust හි ව්‍යතිරේක පන්ති හඳුනාගැනුම.
// ව්‍යතිරේකය ඔවුන්ගේ ධාවන කාලය විසින් විසි කර තිබේද යන්න තීරණය කිරීම සඳහා මෙය පුද්ගල චර්යාවන් භාවිතා කරයි.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ R 0 RUST-වෙළෙන්දා, භාෂාව
    0x4d4f5a_00_52555354
}

// එක් එක් ගෘහ නිර්මාණ ශිල්පය සඳහා LLVM හි TargetLowering::getExceptionPointerRegister() සහ TargetLowering::getExceptionSelectorRegister() වෙතින් රෙජිස්ටර් අයිඩී ඉවත් කරන ලද අතර පසුව රෙජිස්ටර් අර්ථ දැක්වීමේ වගු හරහා DWARF රෙජිස්ටර් අංකවලට සිතියම් ගත කරන ලදි (සාමාන්‍යයෙන්<arch>RegisterInfo.td, "DwarfRegNum" සඳහා සොයන්න).
//
// http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register ද බලන්න.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// පහත කේතය GCC හි C සහ C++ පෞරුෂත්ව චර්යාවන් මත පදනම් වේ.යොමු කිරීම සඳහා, බලන්න:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM EHABI පෞරුෂ චර්යාව.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS ඒ වෙනුවට SjLj uninding භාවිතා කරන බැවින් පෙරනිමි පුරුද්ද භාවිතා කරයි.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // ARM හි පසුගාමී ස්ථාන==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // එවැනි අවස්ථාවන්හිදී අපට තොගය නොකඩවා නොකිරීමට අවශ්‍ය වේ, එසේ නොමැතිනම් අපගේ සියලු පසුපෙළ __rust_try වලින් අවසන් වේ
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // DWARF නොදැනුවත්වම උපකල්පනය කරන්නේ _Unwind_Context මඟින් ශ්‍රිතය සහ LSDA දර්ශක වැනි දේ ඇති බවයි, කෙසේ වෙතත් ARM EHABI ඒවා ව්‍යතිරේක වස්තුව තුළට දමයි.
            // සන්දර්භය දර්ශකය පමණක් ගන්නා _Unwind_GetLanguageSpecificData() වැනි ශ්‍රිතවල අත්සන් ආරක්ෂා කර ගැනීම සඳහා, GCC පෞරුෂත්ව චර්යාවන් ARM හි "scratch register" (r12) සඳහා වෙන් කර ඇති ස්ථානය භාවිතා කරමින් සන්දර්භය තුළ ව්‍යතිරේක_බොජෙක්ට් වෙත යොමු කරයි.
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... වඩාත් ප්‍රතිපත්තිගරුක ප්‍රවේශයක් වනුයේ අපගේ ලිබන්වින්ඩ් බන්ධනවල ARM හි _Unwind_Context පිළිබඳ පූර්ණ අර්ථ දැක්වීම සැපයීම සහ අවශ්‍ය දත්ත සෘජුවම එතැනින් ලබා ගැනීම, DWARF අනුකූලතා කාර්යයන් මඟ හැරීමයි.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // ව්‍යතිරේක වස්තුවේ බාධක හැඹිලියේ SP අගය යාවත්කාලීන කිරීම සඳහා EHABI හට පෞරුෂ චර්යාව අවශ්‍ය වේ.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // ARM EHABI හි නැවත පැමිණීමට පෙර තනි සිරස් රාමුවක් නොදැනීම සඳහා පෞරුෂ චර්යාව වගකිව යුතුය (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // libgcc වලින් අර්ථ දක්වා ඇත
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // සුපුරුදු පෞරුෂ චර්යාව, එය බොහෝ ඉලක්ක වෙත කෙලින්ම සහ වක්‍රව Windows x86_64 හි SEH හරහා භාවිතා කරයි.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // x86_64 MinGW ඉලක්ක වලදී, නොනවතින යාන්ත්‍රණය SEH වේ, කෙසේ වෙතත්, නොබැඳි හසුරුවන දත්ත (aka LSDA) GCC-අනුකූල කේතන ක්‍රමයක් භාවිතා කරයි.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // අපගේ බොහෝ ඉලක්ක සඳහා පෞරුෂ චර්යාව.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // ආපසු ලිපිනය ඇමතුම් උපදෙස් පසුකරමින් 1 බයිට් එකක් යොමු කරයි, එය එල්එස්ඩීඒ පරාසයේ වගුවේ ඊළඟ අයිපී පරාසය විය හැකිය.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// තොරතුරු ලියාපදිංචි කිරීම රාමු කරන්න
//
// සෑම මොඩියුලයකම රූපයේ රාමු රහිත තොරතුරු අංශයක් අඩංගු වේ (සාමාන්‍යයෙන් ".eh_frame").මොඩියුලයක් loaded/unloaded ක්‍රියාවලියට ඇතුළත් වූ විට, මෙම කොටසේ මතකයේ පිහිටීම පිළිබඳව නොදැනුවත්වම දැනුම් දිය යුතුය.එය සාක්ෂාත් කර ගැනීමේ ක්‍රම වේදිකාව අනුව වෙනස් වේ.
// සමහර (උදා.
//
//
// මෙම මොඩියුලය අපගේ තොරතුරු GCC ධාවන කාලය සමඟ ලියාපදිංචි කිරීම සඳහා rsbegin.rs වෙතින් යොමු කර ඇති සංකේත දෙකක් අර්ථ දක්වයි.
// තොග මුදා හැරීම ක්‍රියාත්මක කිරීම (දැනට) libgcc_eh වෙත කල් දමා ඇත, කෙසේ වෙතත් Rust crates මෙම Rust විශේෂිත ප්‍රවේශ ස්ථාන භාවිතා කරන්නේ ඕනෑම GCC ධාවන වේලාවක් සමඟ ඇති විය හැකි ගැටුම් වලක්වා ගැනීම සඳහා ය.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}