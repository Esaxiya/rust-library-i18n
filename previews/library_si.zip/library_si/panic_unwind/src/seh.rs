//! Windows SEH
//!
//! Windows හි (දැනට MSVC හි පමණි), පෙරනිමි ව්‍යතිරේක හැසිරවීමේ යාන්ත්‍රණය වන්නේ ව්‍යුහාත්මක ව්‍යතිරේක හැසිරවීම (SEH) ය.
//! මෙය සම්පාදක අභ්‍යන්තරය අනුව වාමන පාදක ව්‍යතිරේක හැසිරවීමට වඩා වෙනස් ය (උදා: වෙනත් unix වේදිකා භාවිතා කරන දේ), එබැවින් LHVM හට SEH සඳහා හොඳ අමතර සහයෝගයක් අවශ්‍ය වේ.
//!
//! කෙටියෙන් කිවහොත්, මෙහි සිදුවන්නේ:
//!
//! 1. `panic` ශ්‍රිතය සම්මත Windows ශ්‍රිතය `_CxxThrowException` ලෙස හඳුන්වන්නේ C++ -ව්‍යතිරේකයක් වැනි විසි කිරීමකි.
//! 2.
//! සම්පාදකයා විසින් ජනනය කරන ලද සියලුම ගොඩබෑමේ පෑඩ්, සීආර්ටී හි ශ්‍රිතයක් වන `__CxxFrameHandler3` පෞරුෂ ශ්‍රිතය භාවිතා කරයි, සහ Windows හි නොවරදින කේතය මෙම පෞරුෂ ශ්‍රිතය භාවිතා කර තොගයේ ඇති සියලුම පිරිසිදු කිරීමේ කේත ක්‍රියාත්මක කරයි.
//!
//! 3. `invoke` වෙත සියලු සම්පාදක ජනනය කරන ලද ඇමතුම් වලට `cleanuppad` LLVM උපදෙස් ලෙස ගොඩබෑමේ පෑඩ් කට්ටලයක් ඇති අතර එය පිරිසිදු කිරීමේ ක්‍රියාවලියේ ආරම්භය පෙන්නුම් කරයි.
//! පිරිසිදු කිරීමේ ක්‍රියාකාරකම් ක්‍රියාත්මක කිරීම සඳහා පෞරුෂය (පියවර 2 හි, CRT හි අර්ථ දක්වා ඇත).
//! 4. අවසානයේදී `try` අභ්‍යන්තරයේ (සම්පාදකයා විසින් ජනනය කරන ලද) "catch" කේතය ක්‍රියාත්මක වන අතර පාලනය Rust වෙත නැවත පැමිණිය යුතු බව පෙන්නුම් කරයි.
//! මෙය LLVM IR නියමයන් අනුව `catchswitch` ප්ලස් සහ `catchpad` උපදෙස් හරහා සිදු කෙරෙන අතර අවසානයේ සාමාන්‍ය පාලනය `catchret` උපදෙස් සමඟ වැඩසටහනට නැවත ලබා දේ.
//!
//! gcc මත පදනම් වූ ව්‍යතිරේක හැසිරවීමේ විශේෂිත වෙනස්කම් කිහිපයක් නම්:
//!
//! * Rust හි අභිරුචි පෞරුෂත්ව ක්‍රියාකාරිත්වයක් නොමැත, ඒ වෙනුවට *සැමවිටම*`__CxxFrameHandler3` වේ.ඊට අමතරව, අමතර පෙරහන් කිරීමක් සිදු නොකෙරේ, එබැවින් අපි විසි කරන ආකාරයේ පෙනුමක් ඇති ඕනෑම C++ ව්‍යතිරේකයක් අල්ලා ගනිමු.
//! Rust වෙත ව්‍යතිරේකයක් විසි කිරීම කෙසේ වෙතත් නිර්වචනය නොකළ හැසිරීමක් බව සලකන්න, එබැවින් මෙය හොඳින් විය යුතුය.
//! * නොදැනුවත්වම සීමාව හරහා සම්ප්‍රේෂණය කිරීමට අපට දත්ත කිහිපයක් තිබේ, විශේෂයෙන් `Box<dyn Any + Send>`.වාමන ව්‍යතිරේකයන් මෙන් මෙම දර්ශකයන් දෙක ව්‍යතිරේකයේම ගෙවීමක් ලෙස ගබඩා කර ඇත.
//! කෙසේ වෙතත්, MSVC හි, අමතර ගොඩවල් වෙන් කිරීමක් අවශ්‍ය නොවේ, මන්ද පෙරහන් කාර්යයන් ක්‍රියාත්මක වන අතරතුර ඇමතුම් තොගය ආරක්ෂා වේ.
//! මෙයින් අදහස් කරන්නේ දර්ශකයන් කෙලින්ම `_CxxThrowException` වෙත යවන අතර ඒවා පෙරහන් ශ්‍රිතයෙන් යථා තත්වයට පත් කර `try` අභ්‍යන්තරයේ සිරස් රාමුවට ලිවිය යුතු බවයි.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // මෙය විකල්පයක් විය යුතුය, මන්ද අප ව්‍යතිරේකය යොමු කිරීමෙන් අල්ලා ගන්නා අතර එහි විනාශ කරන්නා C++ ධාවන වේලාව මඟින් ක්‍රියාත්මක කරයි.
    // අපි කොටුව ව්‍යතිරේකයෙන් ඉවතට ගත් විට, කොටුව දෙවරක් වැටීමකින් තොරව එහි විනාශකරුවා ක්‍රියාත්මක කිරීම සඳහා අපි ව්‍යතිරේකය වලංගු තත්වයක තැබිය යුතුය.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// පළමුවෙන්ම, වර්ග අර්ථ දැක්වීම් සමූහයක්.මෙහි වේදිකා-විශේෂිත අමුතුකම් කිහිපයක් තිබේ, සහ බොහෝ දේ එල්එල්වීඑම් වෙතින් නිර්ලජ්ජිතව පිටපත් කර ඇත.මේ සියල්ලේ පරමාර්ථය වන්නේ පහත දැක්වෙන `panic` ශ්‍රිතය `_CxxThrowException` වෙත ඇමතුමක් මඟින් ක්‍රියාත්මක කිරීමයි.
//
// මෙම ශ්‍රිතය තර්ක දෙකක් ගනී.පළමුවැන්න අප පසුකර යන දත්ත වෙත යොමු කිරීමකි, මේ අවස්ථාවේ දී අපගේ trait වස්තුව වේ.සොයා ගැනීම පහසුය!කෙසේ වෙතත්, ඊළඟට වඩා සංකීර්ණ ය.
// මෙය `_ThrowInfo` ව්‍යුහයක් සඳහා වන දර්ශකයක් වන අතර, සාමාන්‍යයෙන් එය අරමුණු කර ඇත්තේ ව්‍යතිරේකය විසි කිරීම විස්තර කිරීමට ය.
//
// වර්තමානයේ මෙම වර්ගයේ [1] හි අර්ථ දැක්වීම ටිකක් කෙස් කළඹක් වන අතර ප්‍රධාන අමුතුකම (සහ සබැඳි ලිපියේ වෙනස) 32-බිටු මත දර්ශකයන් දර්ශකයන් වන නමුත් 64-බිට් මත දර්ශකයන් 32-බිට් ඕෆ්සෙට් ලෙස ප්‍රකාශ වේ `__ImageBase` සංකේතය.
//
// මෙය ප්‍රකාශ කිරීම සඳහා පහත මොඩියුලවල ඇති `ptr_t` සහ `ptr!` සාර්ව භාවිතා වේ.
//
// මේ ආකාරයේ ක්‍රියාකාරිත්වය සඳහා LLVM විමෝචනය කරන දේ වර්ග අර්ථ දැක්වීම්වල ප්‍රභවය ද සමීපව අනුගමනය කරයි.උදාහරණයක් ලෙස, ඔබ මෙම C++ කේතය MSVC මත සම්පාදනය කර LLVM IR විමෝචනය කරන්නේ නම්:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      void foo() { rust_panic a = {0, 1};
//          විසි කරන්න;}
//
// අත්‍යවශ්‍යයෙන්ම අපි අනුකරණය කිරීමට උත්සාහ කරන්නේ එයයි.පහත දැක්වෙන නියත අගයන් බොහොමයක් එල්එල්වීඑම් වෙතින් පිටපත් කරන ලදි,
//
// කෙසේ වෙතත්, මෙම ව්‍යුහයන් සියල්ලම සමාන ආකාරයකින් ඉදිකර ඇති අතර එය අපට තරමක් වාචික ය.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// මෙහි නම මැන්ග්ලිං නීති අපි හිතාමතාම නොසලකා හරින බව සලකන්න: `struct rust_panic` එකක් ප්‍රකාශ කිරීමෙන් C++ ට Rust panics අල්ලා ගැනීමට අවශ්‍ය නොවේ.
//
//
// වෙනස් කරන විට, වර්ගයේ නම නූල `compiler/rustc_codegen_llvm/src/intrinsic.rs` හි භාවිතා කළ ඒවාට හරියටම ගැලපෙන බවට වග බලා ගන්න.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // මෙහි ඇති ප්‍රමුඛ `\x01` බයිට් ඇත්ත වශයෙන්ම එල්එල්වීඑම් වෙත ඉන්ද්‍රජාලික සං signal ාවක් වන අතර එය `_` අක්ෂරයක් සමඟ උපසර්ගය වැනි වෙනත් මැන්ග්ලිං භාවිතා නොකරයි.
    //
    //
    // මෙම සංකේතය C++ හි `std::type_info` භාවිතා කරන vtable වේ.
    // `std::type_info` වර්ගයේ වස්තූන්, විස්තර කරන්නන්, මෙම වගුවට දර්ශකයක් ඇත.
    // වර්ගය විස්තර කරන්නන් ඉහත දක්වා ඇති C++ EH ව්‍යුහයන් මගින් යොමු කරනු ලැබේ.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// මෙම වර්ගයේ විස්තරය භාවිතා කරනුයේ ව්‍යතිරේකයක් විසි කිරීමේදී පමණි.
// ඇල්ලීමේ කොටස හසුරුවනු ලබන්නේ එහි ටයිප් ඩිස්ක්‍රිප්ටරය ජනනය කරන උත්සාහක අභ්‍යන්තරයෙනි.
//
// එම්එස්වීසී ධාවන කාලය දර්ශක සමානාත්මතාවයට වඩා ටයිප් ඩිස්ක්‍රිප්ටරයට ගැලපෙන පරිදි වර්ග නාමයේ වචන සංසන්දනය භාවිතා කරන බැවින් මෙය හොඳයි.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// C ++ කේතය ව්‍යතිරේකය ග්‍රහණය කර එය ප්‍රචාරය නොකර අතහැර දැමීමට තීරණය කරන්නේ නම් විනාශ කරන්නා භාවිතා කරයි.
// උත්සාහක අභ්‍යන්තරයේ ඇල්ලීමේ කොටස ව්‍යතිරේක වස්තුවේ පළමු වචනය 0 ලෙස සකසනු ඇත, එවිට එය විනාශ කරන්නා විසින් මඟ හරිනු ලැබේ.
//
// x86 Windows සුපුරුදු "C" ඇමතුම් සම්මුතිය වෙනුවට C++ සාමාජික කාර්යයන් සඳහා "thiscall" ඇමතුම් සම්මුතිය භාවිතා කරන බව සලකන්න.
//
// Exception_copy ශ්‍රිතය මෙහි ටිකක් විශේෂයි: එය try/catch බ්ලොක් එකක් යටතේ MSVC ධාවන වේලාව මඟින් ආයාචනා කරනු ලබන අතර අප මෙහි ජනනය කරන panic ව්‍යතිරේක පිටපතෙහි ප්‍රති as ලයක් ලෙස භාවිතා වේ.
//
// std::exception_ptr සමඟ ව්‍යතිරේකයන් ග්‍රහණය කර ගැනීමට මෙය C++ ධාවන වේලාව භාවිතා කරයි, අපට කොටුව නිසා එයට සහාය දිය නොහැක<dyn Any>ක්ලෝන කළ නොහැක.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException සම්පූර්ණයෙන්ම මෙම සිරස් රාමුව මත ක්‍රියාත්මක වන බැවින් `data` ගොඩට මාරු කිරීම අවශ්‍ය නොවේ.
    // අපි මෙම ශ්‍රිතයට ස්ටැක් පොයින්ටරයක් යවමු.
    //
    // මැනුවල් ඩ්‍රොප් මෙහි අවශ්‍ය වන්නේ නොදැනුවත්වම ව්‍යතිරේකය අතහැර දැමීමට අපට අවශ්‍ය නැති නිසාය.
    // ඒ වෙනුවට එය C++ ධාවන කාලයෙන් ආයාචනා කර ඇති ව්‍යතිරේක_ ක්ලීනප් මඟින් අතහැර දමනු ඇත.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // මෙය ... පුදුම සහගත බවක් පෙනෙන්නට ඇති අතර සාධාරණ ලෙස එසේ විය හැකිය.32-බිට් එම්එස්වීසී මත මෙම ව්‍යුහය අතර දර්ශක පමණක් වේ, දර්ශකයන්.
    // කෙසේ වෙතත්, 64-බිට් MSVC මත, ව්‍යුහයන් අතර දර්ශකයන් `__ImageBase` වෙතින් 32-බිට් ඕෆ්සෙට් ලෙස ප්‍රකාශ වේ.
    //
    // එහි ප්‍රති, ලයක් වශයෙන්, 32-බිට් එම්එස්වීසී මත අපට ඉහත සියලු ස්ථිතිකවල මෙම සියලු කරුණු ප්‍රකාශ කළ හැකිය.
    // 64-බිට් MSVC හි, අපට සංඛ්‍යා ලේඛනවල දර්ශකයන් අඩු කිරීම ප්‍රකාශ කිරීමට සිදුවනු ඇත, එය Rust දැනට ඉඩ නොදේ, එබැවින් අපට එය ඇත්ත වශයෙන්ම කළ නොහැක.
    //
    // ඊළඟ හොඳම දේ නම්, මෙම ව්‍යුහයන් ධාවන වේලාවේදී පිරවීමයි (භීතිකාව දැනටමත් "slow path" වේ).
    // එබැවින් මෙහි දී අපි මෙම සියලු දර්ශක ක්ෂේත්‍ර 32-බිටු නිඛිල ලෙස නැවත අර්ථකථනය කර අදාළ අගය ඒ තුළ ගබඩා කරමු (පරමාණුකව, සමගාමී panics සිදුවෙමින් පවතින බැවින්).
    //
    // තාක්ෂණික වශයෙන් ධාවන කාලය බොහෝ විට මෙම ක්ෂේත්‍ර පිළිබඳ නොගැලපෙන කියවීමක් කරනු ඇත, නමුත් න්‍යායිකව ඔවුන් කිසි විටෙකත් *වැරදි* අගය කියවන්නේ නැත, එබැවින් එය එතරම් නරක නොවිය යුතුය ...
    //
    // කෙසේ වෙතත්, සංඛ්‍යාලේඛනවල වැඩි ක්‍රියාකාරිත්වයක් ප්‍රකාශ කිරීමට හැකි වන තෙක් අපි මූලික වශයෙන් මෙවැනි දෙයක් කළ යුතුය (අපට කිසි විටෙකත් එය කළ නොහැකි වනු ඇත).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // මෙහි NULL ගෙවීමක් යනු __rust_try හි (...) අල්ලා ගැනීමෙන් අප මෙහි පැමිණි බවයි.
    // Rust නොවන විදේශීය ව්‍යතිරේකයක් හසු වූ විට මෙය සිදු වේ.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// මෙය සම්පාදකයාට පැවතීමට අවශ්‍ය වේ (උදා: එය ලාංඡන අයිතමයකි), නමුත් එය කිසි විටෙකත් සම්පාදකයා විසින් නොකියයි, මන්ද __C_specific_handler හෝ _except_handler3 යනු සැමවිටම භාවිතා වන පෞරුෂ ශ්‍රිතයයි.
//
// එබැවින් මෙය ගබ්සා කිරීමේ කඳක් පමණි.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}