//! DWARF-කේතනය කරන ලද දත්ත ප්‍රවාහ විග්‍රහ කිරීම සඳහා උපයෝගිතා.
//! <http://www.dwarfstd.org>, DWARF-4 ප්‍රමිතිය, 7 වන කොටස, "Data Representation" බලන්න
//!

// මෙම මොඩියුලය දැනට භාවිතා කරන්නේ x86_64-pc-windows-gnu පමණි, නමුත් ප්‍රතිගාමී වීම වළක්වා ගැනීම සඳහා අපි එය සෑම තැනකම සම්පාදනය කරමු.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // DWARF ධාරාවන් ඇසුරුම් කර ඇති බැවින් උදා: u32 බයිට් 4 ක මායිමකට නොගැලපේ.
    // දැඩි පෙළගැස්වීමේ අවශ්‍යතා ඇති වේදිකාවල මෙය ගැටළු ඇති කළ හැකිය.
    // "packed" ව්‍යුහයක දත්ත එතීමෙන්, අපි පසුපසට කියන්නේ "misalignment-safe" කේතය ජනනය කරන ලෙසයි.
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // ULEB128 සහ SLEB128 කේතීකරණ 7.6, "Variable Length Data" වගන්තියේ අර්ථ දක්වා ඇත.
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}