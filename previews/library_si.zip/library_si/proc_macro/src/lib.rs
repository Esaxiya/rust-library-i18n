//! නව මැක්‍රෝස් නිර්වචනය කිරීමේදී සාර්ව කතුවරුන් සඳහා ආධාරක පුස්තකාලයක්.
//!
//! සම්මත බෙදාහැරීම මඟින් සපයනු ලබන මෙම පුස්තකාලය, ක්‍රියාපටිපාටිය අනුව අර්ථ දක්වා ඇති සාර්ව අර්ථ දැක්වීම්වල අතුරු මුහුණත් තුළ පරිභෝජනය කරන වර්ග සපයයි, එනම් ක්‍රියාකාරී-වැනි මැක්‍රෝස් `#[proc_macro]`, සාර්ව ගුණාංග `#[proc_macro_attribute]` සහ අභිරුචි ව්‍යුත්පන්න ගුණාංග`#[proc_macro_derive]`.
//!
//!
//! වැඩි විස්තර සඳහා [the book] බලන්න.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// දැනට ක්‍රියාත්මක වන වැඩසටහනට proc_macro ප්‍රවේශ කර තිබේද යන්න තීරණය කරයි.
///
/// Proc_macro crate යනු කාර්ය පටිපාටික සාර්ව ක්‍රියාත්මක කිරීමේදී පමණක් භාවිතා කිරීමට අදහස් කරයි.මෙම crate panic හි ඇති සියලුම කාර්යයන්, ක්‍රියාපටිපාටියේ සාර්වයකට පිටතින් ආයාචනා කරන්නේ නම්, එනම් බිල්ඩ් ස්ක්‍රිප්ට් හෝ ඒකක පරීක්ෂණයක් හෝ සාමාන්‍ය Rust ද්විමය වැනි.
///
/// සාර්ව හා සාර්ව නොවන භාවිත අවස්ථා සඳහා සහය දැක්වීම සඳහා නිර්මාණය කර ඇති Rust පුස්තකාල සඳහා සලකා බැලීමේදී, proc_macro හි API භාවිතා කිරීමට අවශ්‍ය යටිතල පහසුකම් දැනට තිබේදැයි සොයා බැලීමට `proc_macro::is_available()` භීතියට පත් නොවන ක්‍රමයක් සපයයි.
/// කාර්ය පටිපාටික සාර්වයක ඇතුළත සිට ආයාචනා කළහොත් සත්‍ය වේ, වෙනත් ද්විමයයකින් ආයාචනා කළහොත් අසත්‍ය වේ.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// මෙම crate විසින් සපයන ලද ප්‍රධාන වර්ගය, tokens හි වියුක්ත ප්‍රවාහයක් නියෝජනය කරයි, හෝ වඩාත් නිශ්චිතවම, token ගස් අනුක්‍රමයකි.
/// මෙම වර්ගය එම token ගස් හරහා නැවත ක්‍රියා කිරීම සඳහා අතුරු මුහුණත් සපයන අතර අනෙක් අතට token ගස් ගණනාවක් එක් ප්‍රවාහයකට එකතු කරයි.
///
///
/// මෙය `#[proc_macro]`, `#[proc_macro_attribute]` සහ `#[proc_macro_derive]` අර්ථ දැක්වීම්වල ආදානය සහ ප්‍රතිදානය යන දෙකම වේ.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// දෝෂය `TokenStream::from_str` වෙතින් ආපසු ලැබුණි.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// token ගස් නොමැති හිස් `TokenStream` ලබා දෙයි.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// මෙම `TokenStream` හිස් දැයි පරීක්ෂා කරයි.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// tokens වෙත නූල බිඳ දැමීමට සහ tokens token ප්‍රවාහයකට විග්‍රහ කිරීමට උත්සාහ කරයි.
/// හේතු ගණනාවක් නිසා අසමත් විය හැකිය, නිදසුනක් ලෙස, සංගීතයේ අසමබර පරිසීමක හෝ අක්ෂර අඩංගු නොවේ නම්.
///
/// විග්‍රහ කරන ලද ප්‍රවාහයේ ඇති සියලුම tokens හට `Span::call_site()` පරතරයන් ලැබේ.
///
/// NOTE: සමහර දෝෂ `LexError` නැවත ලබා දීම වෙනුවට panics වලට හේතු විය හැක.මෙම දෝෂ පසුව 'ලෙක්ස් දෝෂය' ලෙස වෙනස් කිරීමේ අයිතිය අප සතුය.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// සැ.යු, පාලම `to_string` පමණක් සපයයි, එය මත පදනම්ව `fmt::Display` ක්‍රියාත්මක කරන්න (දෙක අතර සුපුරුදු සම්බන්ධතාවයේ ආපසු හැරවීම).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// `Delimiter::None` පරිසීමක සහ negative ණ සංඛ්‍යාත්මක වචනාර්ථයන් සහිත 'ටෝකන් ට්‍රී: : සමූහය' හැරෙන්නට, token ප්‍රවාහය එකම token ප්‍රවාහයට (මොඩියුලෝ පරතරයන්) ආපසු හැරවිය හැකි යැයි සිතිය හැකි නූලක් ලෙස මුද්‍රණය කරයි.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// නිදොස්කරණය සඳහා පහසු ආකාරයකින් token මුද්‍රණය කරයි.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// තනි token ගසක් අඩංගු token ප්‍රවාහයක් නිර්මාණය කරයි.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// token ගස් ගණනාවක් තනි ප්‍රවාහයකට එකතු කරයි.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// token ප්‍රවාහයන්හි "flattening" මෙහෙයුමක් මඟින් token ගස් බහු token ධාරාවන්ගෙන් එක් ප්‍රවාහයකට එකතු කරයි.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) හැකි උපරිම ලෙස ක්‍රියාත්මක කළ හැකි if/when භාවිතා කරන්න.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// ඉටරේටර් වැනි `TokenStream` වර්ගය සඳහා පොදු ක්‍රියාත්මක කිරීමේ තොරතුරු.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// `ටෝකන්ස්ට්රීම් 'හි' ටෝකන් ට්රී 'හි අනුකාරකය.
    /// පුනරාවර්තනය "shallow" වේ, උදා., අනුකාරකය වෙන් කරන ලද කණ්ඩායම් වලට නැවත යොමු නොවන අතර මුළු කණ්ඩායම්ම token ගස් ලෙස නැවත ලබා දෙයි.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` අත්තනෝමතික tokens පිළිගෙන ආදානය විස්තර කරන `TokenStream` දක්වා විහිදේ.
/// උදාහරණයක් ලෙස, `quote!(a + b)` මඟින් ප්‍රකාශනයක් නිපදවනු ඇත, එය ඇගයීමට ලක් කළ විට, `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Unquoting කිරීම `$` සමඟ සිදු කෙරෙන අතර, තනි ඊලඟ අනන්‍යතාවය නොකියවූ යෙදුම ලෙස ගෙන ක්‍රියා කරයි.
/// `$` උපුටා දැක්වීමට, `$$` භාවිතා කරන්න.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// සාර්ව පුළුල් කිරීමේ තොරතුරු සමඟ ප්‍රභව කේත කලාපයක්.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// `self` පරතරයේ දී දී ඇති `message` සමඟ නව `Diagnostic` සාදයි.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// සාර්ව අර්ථ දැක්වීමේ අඩවියේ විසඳන පරතරයක්.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// වර්තමාන කාර්ය පටිපාටික සාර්ව ආයාචනා කිරීමේ කාල සීමාව.
    /// මෙම කාල පරාසය සමඟ සාදන ලද හඳුනාගැනීම් සෘජුවම සාර්ව ඇමතුම් ස්ථානයේ (ඇමතුම් අඩවි සනීපාරක්ෂාව) ලියා ඇති ආකාරයට විසඳනු ඇති අතර සාර්ව ඇමතුම් අඩවියේ ඇති වෙනත් කේතයන් ද ඒවා වෙත යොමු විය හැකිය.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// `macro_rules` සනීපාරක්ෂාව නියෝජනය කරන පරතරයක්, සමහර විට සාර්ව අර්ථ දැක්වීමේ අඩවියේ (දේශීය විචල්‍යයන්, ලේබල, `$crate`) සහ සමහර විට සාර්ව ඇමතුම් අඩවියේ (අනෙක් සියල්ල) නිරාකරණය වේ.
    ///
    /// පරතරය පිහිටීම ඇමතුම් අඩවියෙන් ලබා ගනී.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// මෙම පරතරය පෙන්වා දෙන මුල් මූලාශ්‍ර ගොනුව.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// පෙර සාර්ව ව්‍යාප්තියේ tokens සඳහා වූ `Span`, ඇත්නම්, `self` ජනනය කරන ලදි.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// `self` ජනනය කරන ලද ප්‍රභව ප්‍රභව කේතය සඳහා පරතරය.
    /// මෙම `Span` වෙනත් සාර්ව පුළුල් කිරීම් වලින් ජනනය නොකළේ නම් ප්‍රතිලාභ අගය `*self` හා සමාන වේ.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// මෙම පරතරය සඳහා මූලාශ්‍ර ගොනුවේ ආරම්භක line/column ලබා ගනී.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// මෙම පරතරය සඳහා ප්‍රභව ගොනුවේ අවසන් line/column ලබා ගනී.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// `self` සහ `other` ඇතුළත් නව පරතරයක් නිර්මාණය කරයි.
    ///
    /// `self` සහ `other` විවිධ ලිපිගොනු වලින් නම් `None` ලබා දෙයි.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// `self` හා සමාන line/column තොරතුරු සහිත නව පරතරයක් නිර්මාණය කරයි, නමුත් එය `other` හි මෙන් සංකේත නිරාකරණය කරයි.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// `self` හා සමාන නාම විභේදන හැසිරීමක් සහිත නමුත් `other` හි line/column තොරතුරු සමඟ නව පරතරයක් නිර්මාණය කරයි.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// ඒවා සමාන දැයි බැලීමට පරතරයන් සමඟ සැසඳේ.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// පරතරය පිටුපස මූලාශ්‍ර පෙළ ලබා දෙයි.
    /// මෙය අවකාශයන් සහ අදහස් ඇතුළුව මුල් ප්‍රභව කේතය ආරක්ෂා කරයි.
    /// එය ප්‍රති result ලයක් ලබා දෙන්නේ පරතරය සැබෑ ප්‍රභව කේතයට අනුරූප වන්නේ නම් පමණි.
    ///
    /// Note: සාර්වයක නිරීක්ෂණය කළ හැකි ප්‍රති result ලය රඳා පැවතිය යුත්තේ tokens මත මිස මෙම මූලාශ්‍ර පා on ය මත නොවේ.
    ///
    /// මෙම ශ්‍රිතයේ ප්‍රති result ලය රෝග විනිශ්චය සඳහා පමණක් භාවිතා කිරීමට හොඳම උත්සාහයයි.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// නිදොස් කිරීම සඳහා පහසු ආකාරයකින් පරතරයක් මුද්‍රණය කරයි.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// `Span` හි ආරම්භය හෝ අවසානය නියෝජනය කරන රේඛා-තීරු යුගලයක්.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// (inclusive) පරතරය ආරම්භ වන හෝ අවසන් වන ප්‍රභව ගොනුවේ 1-සුචිගත රේඛාව.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// (inclusive) ආරම්භ වන හෝ අවසන් වන ප්‍රභව ගොනුවේ 0-සුචිගත තීරුව (UTF-8 අක්ෂර වලින්).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// දී ඇති `Span` හි ප්‍රභව ගොනුව.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// මෙම ප්‍රභව ගොනුවට මාර්ගය ලබා ගනී.
    ///
    /// ### Note
    /// මෙම `SourceFile` හා සම්බන්ධ කේත පරතරය ජනනය කළේ බාහිර සාර්වයක් වන මෙම සාර්ව, මෙය ගොනු පද්ධතියේ සත්‍ය මාර්ගයක් නොවිය හැකිය.
    /// පරීක්ෂා කිරීමට [`is_real`] භාවිතා කරන්න.
    ///
    /// `is_real` `true` ආපසු ලබා දුන්නද, විධාන රේඛාවේ `--remap-path-prefix` සම්මත වූයේ නම්, ලබා දී ඇති මාර්ගය සත්‍ය වශයෙන්ම වලංගු නොවනු ඇත.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// මෙම ප්‍රභව ගොනුව සැබෑ ප්‍රභව ගොනුවක් වන අතර බාහිර සාර්ව ප්‍රසාරණයකින් ජනනය නොවන්නේ නම් `true` ලබා දෙයි.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // අන්තර් අන්තර් පරාසයන් ක්‍රියාත්මක වන තෙක් මෙය අනවසරයෙන් සිදුවන අතර බාහිර සාර්ව වලින් ජනනය වන පරතරයන් සඳහා අපට සත්‍ය ප්‍රභව ලිපිගොනු තිබිය හැකිය.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// තනි token හෝ token ගස්වල වෙන් කරන ලද අනුක්‍රමයක් (උදා: `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// token ප්‍රවාහයක් වරහන් පරිසීමක වලින් වටවී ඇත.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// හඳුනාගැනීමක්.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// තනි විරාම ලකුණු (`+`, `,`, `$`, ආදිය).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// (`'a'`), string (`"hello"`), අංක (`2.3`), ආදිය.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// මෙම ගසෙහි පරතරය නැවත ලබා දෙන අතර, එහි අඩංගු token හි `span` ක්‍රමයට හෝ වෙන් කරන ලද ප්‍රවාහයකට අනුයුක්ත කරයි.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// *මෙම token* සඳහා පමණක් පරතරය වින්‍යාස කරයි.
    ///
    /// මෙම token `Group` නම් මෙම ක්‍රමය එක් එක් අභ්‍යන්තර tokens හි පරතරය වින්‍යාස නොකරනු ඇති බව සලකන්න, මෙය හුදෙක් එක් එක් ප්‍රභේදයේ `set_span` ක්‍රමයට පවරනු ඇත.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// නිදොස් කිරීම සඳහා පහසු ආකාරයකින් token ගස මුද්‍රණය කරයි.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // ව්‍යුත්පන්න නිදොස් කිරීමේ ව්‍යුහයේ මේ සෑම එකක්ම නමක් ඇත, එබැවින් අමතර පරාවර්තක තට්ටුවක් සමඟ කරදර නොවන්න
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// සැ.යු, පාලම `to_string` පමණක් සපයයි, එය මත පදනම්ව `fmt::Display` ක්‍රියාත්මක කරන්න (දෙක අතර සුපුරුදු සම්බන්ධතාවයේ ආපසු හැරවීම).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// `Delimiter::None` පරිසීමක සහ negative ණ සංඛ්‍යාත්මක වචනාර්ථයන් සහිත `ටෝකන්ට්‍රී: : සමූහය 'හැරෙන්නට, token ගස නැවත එකම token ගසකට (මොඩියුලෝ පරතරයන්) පරිවර්තනය කළ හැකි නූලක් ලෙස මුද්‍රණය කරයි.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// වෙන් කරන ලද token ප්‍රවාහයකි.
///
/// `Group` අභ්‍යන්තරව `TokenStream` අඩංගු වන අතර එය 'ඩෙලිමිටර්' වලින් වටවී ඇත.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// token ගස් අනුක්‍රමයක් වෙන් කරන ආකාරය විස්තර කරයි.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// නිදසුනක් ලෙස, "macro variable" `$var` වෙතින් එන tokens වටා දිස්වන ව්‍යංග පරිසීමකය.
    /// `$var` `1 + 2` වන `$var * 3` වැනි අවස්ථාවන්හිදී ක්‍රියාකරු ප්‍රමුඛතා ආරක්ෂා කර ගැනීම වැදගත්ය.
    /// ව්‍යංග පරිසීමකයෝ token ප්‍රවාහයක වට රවුමකින් නොනැසී පැවතිය හැකිය.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// දී ඇති පරිසීමකය සහ token ප්‍රවාහය සමඟ නව `Group` නිර්මාණය කරයි.
    ///
    /// මෙම ඉදිකිරීම්කරු මෙම කණ්ඩායම සඳහා පරතරය `Span::call_site()` ලෙස සකසනු ඇත.
    /// පරතරය වෙනස් කිරීම සඳහා ඔබට පහත `set_span` ක්‍රමය භාවිතා කළ හැකිය.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// මෙම `Group` හි පරිසීමකය ලබා දෙයි
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// මෙම `Group` හි වෙන් කර ඇති tokens හි `TokenStream` ලබා දෙයි.
    ///
    /// ආපසු ලබා දුන් token ප්‍රවාහයට ඉහත ආපසු හරවන ලද පරිසීමකය ඇතුළත් නොවන බව සලකන්න.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// මෙම token ප්‍රවාහයේ පරිසීමක සඳහා පරතරය ලබා දෙයි, මුළු `Group` පුරා විහිදේ.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// මෙම කණ්ඩායමේ ආරම්භක පරිමිතිය වෙත යොමු වන පරතරය ලබා දෙයි.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// මෙම කණ්ඩායමේ සංවෘත පරිමිතිය වෙත යොමු වන පරතරය ලබා දෙයි.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// මෙම `සමූහයේ පරිසීමක සඳහා පරතරය වින්‍යාස කරයි, නමුත් එහි අභ්‍යන්තර tokens නොවේ.
    ///
    /// මෙම ක්‍රමය මඟින් මෙම කණ්ඩායම විසින් විහිදෙන සියලුම අභ්‍යන්තර tokens හි පරතරය ** සැකසෙන්නේ නැත, නමුත් එය සකසනු ඇත්තේ tokens පරිසීමකයේ පරතරය `Group` මට්ටමින් පමණි.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// සැ.යු, පාලම `to_string` පමණක් සපයයි, එය මත පදනම්ව `fmt::Display` ක්‍රියාත්මක කරන්න (දෙක අතර සුපුරුදු සම්බන්ධතාවයේ ආපසු හැරවීම).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// `Delimiter::None` පරිසීමක සහිත `ටෝකන්ට්‍රී: : සමූහය 'හැරෙන්නට, කණ්ඩායම නැවත එකම කණ්ඩායමට (මොඩියුලෝ පරතරයන්) පරිවර්තනය කළ හැකි නූලක් ලෙස මුද්‍රණය කරයි.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` යනු `+`, `-` හෝ `#` වැනි තනි විරාම ලකුණු වේ.
///
/// `+=` වැනි බහු අක්ෂර ක්‍රියාකරුවන් `Punct` හි අවස්ථා දෙකක් ලෙස නිරූපණය කෙරේ.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// `Punct` එකක් වහාම වෙනත් `Punct` විසින් අනුගමනය කරන්නේද නැතහොත් වෙනත් token හෝ සුදු අවකාශයක් අනුගමනය කරන්නේද යන්න.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// උදා: `+` යනු `+ =`, `+ident` හෝ `+()` හි `Alone` වේ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// උදා: `+` යනු `+=` හෝ `'#` හි `Joint` වේ.
    /// මීට අමතරව, එක් උපුටා දැක්වීමක් `'` හඳුනාගැනීම් සමඟ සම්බන්ධ වී ජීවිත කාලය `'ident` සාදයි.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// දී ඇති අක්ෂරයෙන් සහ පරතරයෙන් නව `Punct` නිර්මාණය කරයි.
    /// `ch` තර්කය භාෂාවෙන් අවසර දී ඇති වලංගු විරාම ලකුණු අක්‍ෂරයක් විය යුතුය, එසේ නොමැති නම් ශ්‍රිතය panic වේ.
    ///
    /// ආපසු ලබා දුන් `Punct` හි පෙරනිමි `Span::call_site()` පරතරය ඇති අතර එය පහත දැක්වෙන `set_span` ක්‍රමය සමඟ තවදුරටත් වින්‍යාසගත කළ හැකිය.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// මෙම විරාම ලකුණු අක්‍ෂරයේ අගය `char` ලෙස ලබා දෙයි.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// මෙම විරාම ලකුණු අක්‍ෂරයේ පරතරය නැවත ලබා දෙයි, එය වහාම token ප්‍රවාහයේ තවත් `Punct` අනුගමනය කරන්නේද යන්න දක්වයි, එබැවින් ඒවා බහු අක්ෂර ක්‍රියාකරු (`Joint`) සමඟ ඒකාබද්ධ කළ හැකිය, නැතහොත් එය වෙනත් token හෝ වයිට්ස්පේස් (`Alone`) අනුගමනය කරයි, එබැවින් ක්‍රියාකරුට නිසැකවම තිබේ අවසන්.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// මෙම විරාම ලකුණු අක්‍ෂරය සඳහා පරතරය ලබා දෙයි.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// මෙම විරාම ලකුණු අක්‍ෂරය සඳහා පරතරය වින්‍යාස කරන්න.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// සැ.යු, පාලම `to_string` පමණක් සපයයි, එය මත පදනම්ව `fmt::Display` ක්‍රියාත්මක කරන්න (දෙක අතර සුපුරුදු සම්බන්ධතාවයේ ආපසු හැරවීම).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// විරාම ලකුණු අක්‍ෂරය අකුරු රහිතව නැවත එකම අක්ෂරයට පරිවර්තනය කළ හැකි නූලක් ලෙස මුද්‍රණය කරයි.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// හඳුනාගැනීමේ (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// දී ඇති `string` මෙන්ම නිශ්චිත `span` සමඟ නව `Ident` සාදයි.
    /// `string` තර්කය භාෂාවෙන් අවසර දී ඇති වලංගු හඳුනාගැනීමක් විය යුතුය (මූල පද ඇතුළුව, උදා: `self` හෝ `fn`).එසේ නොමැති නම්, ශ්‍රිතය panic වනු ඇත.
    ///
    /// දැනට rustc හි ඇති `span` මෙම අනන්‍යතාවය සඳහා සනීපාරක්ෂක තොරතුරු වින්‍යාස කරන බව සලකන්න.
    ///
    /// මෙම කාලය වන විට `Span::call_site()` පැහැදිලිවම "call-site" සනීපාරක්ෂාව සඳහා තෝරාගෙන ඇති අතර එයින් අදහස් වන්නේ මෙම පරතරය සමඟ නිර්මාණය කරන ලද හඳුනාගැනීම් සාර්ව ඇමතුම ඇති ස්ථානයේ කෙලින්ම ලියා ඇති ආකාරයටම විසඳනු ඇති අතර සාර්ව ඇමතුම් අඩවියේ ඇති වෙනත් කේත වෙත යොමු වීමට හැකි වනු ඇති බවයි. ඔවුන් ද එසේමය.
    ///
    ///
    /// `Span::def_site()` වැනි පසුකාලීන පරාසයන් "definition-site" සනීපාරක්ෂාව සඳහා තෝරා ගැනීමට ඉඩ සලසයි, එයින් අදහස් වන්නේ මෙම පරතරය සමඟ සාදන ලද හඳුනාගැනීම් සාර්ව අර්ථ දැක්වීමේ ස්ථානයේ දී විසඳනු ඇති අතර සාර්ව ඇමතුම් අඩවියේ ඇති වෙනත් කේත ඒවාට යොමු කිරීමට නොහැකි වනු ඇති බවයි.
    ///
    /// සනීපාරක්ෂාවේ වර්තමාන වැදගත්කම නිසා, මෙම ඉදිකිරීම්කරුට අනෙකුත් tokens මෙන් නොව, ඉදිකිරීම් වලදී `Span` නියම කිරීම අවශ්‍ය වේ.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// `Ident::new` ට සමාන නමුත් අමු හඳුනාගැනීමක් (`r#ident`) සාදයි.
    /// `string` තර්කය භාෂාව විසින් අවසර දී ඇති වලංගු හඳුනාගැනීමක් වේ (මූල පද ඇතුළුව, උදා: `fn`).
    /// මාර්ග කොටස්වල භාවිතා කළ හැකි මූල පද (උදා
    /// `self`, `සුපිරි`) සහය නොදක්වන අතර එය panic වලට හේතු වේ.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// මෙම `Ident` හි පරතරය ලබා දෙයි, [`to_string`](Self::to_string) විසින් ආපසු ලබා දුන් සම්පූර්ණ නූලම ඇතුළත් වේ.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// මෙම `Ident` හි පරතරය වින්‍යාස කරයි, සමහර විට එහි සනීපාරක්ෂක සන්දර්භය වෙනස් කරයි.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// සැ.යු, පාලම `to_string` පමණක් සපයයි, එය මත පදනම්ව `fmt::Display` ක්‍රියාත්මක කරන්න (දෙක අතර සුපුරුදු සම්බන්ධතාවයේ ආපසු හැරවීම).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// අනන්‍යතාවය නැවත එකම හඳුනාගැනීමක් බවට පරිවර්තනය කළ හැකි නූලක් ලෙස හඳුනා ගනී.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// වචනයේ පරිසමාප්ත අර්ථයෙන්ම (`"hello"`), බයිට් නූල් (`b"hello"`), අක්ෂර (`'a'`), බයිට් අක්ෂර (`b'a'`), උපසර්ගයක් සහිතව හෝ රහිතව පූර්ණ සංඛ්‍යාවක් හෝ පාවෙන ලක්ෂ්‍ය අංකයක් (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// `true` සහ `false` වැනි බූලියන් සාහිත්‍යකරුවන් මෙහි අයත් නොවේ, ඒවා 'අනන්‍යතා' ය.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// නිශ්චිත අගය සමඟ නව උපසර්ග සංඛ්‍යාවක් භාවිතා කරයි.
        ///
        /// මෙම ශ්‍රිතය `1u32` වැනි පූර්ණ සංඛ්‍යාවක් නිර්මාණය කරනු ඇත, එහිදී නියම කර ඇති පූර්ණ අගය token හි පළමු කොටස වන අතර අනුකලනය ද අවසානයේ දී ප්‍රමාණවත් වේ.
        /// Negative ණ සංඛ්‍යා වලින් සාදන ලද සාහිත්‍යකරුවන් `TokenStream` හෝ නූල් හරහා වට-චාරිකා නොනැසී පැවතිය හැකි අතර tokens (`-` සහ ධනාත්මක වචනාර්ථයෙන්) දෙකකට බෙදිය හැකිය.
        ///
        ///
        /// මෙම ක්‍රමය හරහා සාදන ලද සාහිත්‍යකරුවන්ට පෙරනිමියෙන් `Span::call_site()` පරතරය ඇති අතර එය පහත `set_span` ක්‍රමය සමඟ වින්‍යාසගත කළ හැකිය.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// නිශ්චිත අගය සමඟ නව නොගැලපෙන පූර්ණ සංඛ්‍යාවක් නිර්මාණය කරයි.
        ///
        /// මෙම ශ්‍රිතය `1` වැනි පූර්ණ සංඛ්‍යාවක් නිර්මාණය කරනු ඇත, එහිදී නියම කර ඇති පූර්ණ සංඛ්‍යා අගය token හි පළමු කොටස වේ.
        /// මෙම token හි කිසිදු උපසර්ගයක් නිශ්චිතව දක්වා නැත, එයින් අදහස් වන්නේ `Literal::i8_unsuffixed(1)` වැනි ආයාචනා `Literal::u32_unsuffixed(1)` ට සමාන බවයි.
        /// Negative ණ සංඛ්‍යා වලින් සාදන ලද සාහිත්‍යකරුවන් `TokenStream` හෝ නූල් හරහා රවුන්ට්රිප් නොනැසී පැවතිය හැකි අතර එය tokens (`-` සහ ධනාත්මක වචනාර්ථයෙන්) දෙකකට බෙදිය හැකිය.
        ///
        ///
        /// මෙම ක්‍රමය හරහා සාදන ලද සාහිත්‍යකරුවන්ට පෙරනිමියෙන් `Span::call_site()` පරතරය ඇති අතර එය පහත `set_span` ක්‍රමය සමඟ වින්‍යාසගත කළ හැකිය.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// නව නොගැලපෙන පාවෙන ලක්ෂ්‍යයක් නිර්මාණය කරයි.
    ///
    /// මෙම ඉදිකිරීම්කරු `Literal::i8_unsuffixed` වැනි ඒවාට සමාන වන අතර එහිදී පාවෙන අගය token වෙත කෙලින්ම විමෝචනය වන නමුත් කිසිදු උපසර්ගයක් භාවිතා නොකෙරේ, එබැවින් එය පසුව සම්පාදකයා තුළ `f64` ලෙස අනුමාන කළ හැකිය.
    ///
    /// Negative ණ සංඛ්‍යා වලින් සාදන ලද සාහිත්‍යකරුවන් `TokenStream` හෝ නූල් හරහා රවුන්ට්රිප් නොනැසී පැවතිය හැකි අතර එය tokens (`-` සහ ධනාත්මක වචනාර්ථයෙන්) දෙකකට බෙදිය හැකිය.
    ///
    /// # Panics
    ///
    /// මෙම ශ්‍රිතයට නිශ්චිත පාවෙන පරිමිතිය අවශ්‍ය වේ, උදාහරණයක් ලෙස එය අනන්තය හෝ NaN නම් මෙම ශ්‍රිතය panic වේ.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// නව උපසර්ගයක් සහිත පාවෙන ලක්ෂ්‍යයක් නිර්මාණය කරයි.
    ///
    /// මෙම ඉදිකිරීම්කරු `1.0f32` වැනි වචනාර්ථයක් නිර්මාණය කරනු ඇත, එහිදී නියම කර ඇති අගය token හි පූර්ව කොටස වන අතර `f32` යනු token හි උපසර්ගය වේ.
    /// මෙම token සෑම විටම සම්පාදකයේ `f32` ලෙස අනුමාන කෙරේ.
    /// Negative ණ සංඛ්‍යා වලින් සාදන ලද සාහිත්‍යකරුවන් `TokenStream` හෝ නූල් හරහා රවුන්ට්රිප් නොනැසී පැවතිය හැකි අතර එය tokens (`-` සහ ධනාත්මක වචනාර්ථයෙන්) දෙකකට බෙදිය හැකිය.
    ///
    ///
    /// # Panics
    ///
    /// මෙම ශ්‍රිතයට නිශ්චිත පාවෙන පරිමිතිය අවශ්‍ය වේ, උදාහරණයක් ලෙස එය අනන්තය හෝ NaN නම් මෙම ශ්‍රිතය panic වේ.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// නව නොගැලපෙන පාවෙන ලක්ෂ්‍යයක් නිර්මාණය කරයි.
    ///
    /// මෙම ඉදිකිරීම්කරු `Literal::i8_unsuffixed` වැනි ඒවාට සමාන වන අතර එහිදී පාවෙන අගය token වෙත කෙලින්ම විමෝචනය වන නමුත් කිසිදු උපසර්ගයක් භාවිතා නොකෙරේ, එබැවින් එය පසුව සම්පාදකයා තුළ `f64` ලෙස අනුමාන කළ හැකිය.
    ///
    /// Negative ණ සංඛ්‍යා වලින් සාදන ලද සාහිත්‍යකරුවන් `TokenStream` හෝ නූල් හරහා රවුන්ට්රිප් නොනැසී පැවතිය හැකි අතර එය tokens (`-` සහ ධනාත්මක වචනාර්ථයෙන්) දෙකකට බෙදිය හැකිය.
    ///
    /// # Panics
    ///
    /// මෙම ශ්‍රිතයට නිශ්චිත පාවෙන පරිමිතිය අවශ්‍ය වේ, උදාහරණයක් ලෙස එය අනන්තය හෝ NaN නම් මෙම ශ්‍රිතය panic වේ.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// නව උපසර්ගයක් සහිත පාවෙන ලක්ෂ්‍යයක් නිර්මාණය කරයි.
    ///
    /// මෙම ඉදිකිරීම්කරු `1.0f64` වැනි වචනාර්ථයක් නිර්මාණය කරනු ඇත, එහිදී නියම කර ඇති අගය token හි පූර්ව කොටස වන අතර `f64` යනු token හි උපසර්ගය වේ.
    /// මෙම token සෑම විටම සම්පාදකයේ `f64` ලෙස අනුමාන කෙරේ.
    /// Negative ණ සංඛ්‍යා වලින් සාදන ලද සාහිත්‍යකරුවන් `TokenStream` හෝ නූල් හරහා රවුන්ට්රිප් නොනැසී පැවතිය හැකි අතර එය tokens (`-` සහ ධනාත්මක වචනාර්ථයෙන්) දෙකකට බෙදිය හැකිය.
    ///
    ///
    /// # Panics
    ///
    /// මෙම ශ්‍රිතයට නිශ්චිත පාවෙන පරිමිතිය අවශ්‍ය වේ, උදාහරණයක් ලෙස එය අනන්තය හෝ NaN නම් මෙම ශ්‍රිතය panic වේ.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// නූල් වචනාර්ථයෙන්.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// චරිතය වචනාර්ථයෙන්.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// බයිට් නූල් වචනාර්ථයෙන්.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// මෙම වචනානුසාරයෙන් ආවරණය වන පරතරය ලබා දෙයි.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// මෙම වචනාර්ථය සඳහා සම්බන්ධිත පරතරය වින්‍යාස කරයි.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// `Span` පරාසය තුළ ඇති ප්‍රභව බයිට් පමණක් අඩංගු `self.span()` හි උප කුලකයක් වන `Span` ලබා දෙයි.
    /// කැපූ පරතරය `self` සීමාවෙන් පිටත නම් `None` ලබා දෙයි.
    ///
    // FIXME(SergioBenitez): බයිට් පරාසය ප්‍රභවයේ UTF-8 මායිමකින් ආරම්භ වී අවසන් වේදැයි පරීක්ෂා කරන්න.
    // එසේ නොමැතිනම්, මූලාශ්‍ර පෙළ මුද්‍රණය කරන විට panic වෙනත් තැනක සිදුවීමට ඉඩ ඇත.
    // FIXME(SergioBenitez): `self.span()` සැබවින්ම සිතියම් ගත කරන්නේ කුමක් දැයි පරිශීලකයාට දැන ගැනීමට ක්‍රමයක් නොමැත, එබැවින් මෙම ක්‍රමය දැනට හැඳින්විය හැක්කේ අන්ධ ලෙස පමණි.
    // උදාහරණයක් ලෙස, 'c' අක්ෂරය සඳහා `to_string()` "'\u{63}'" ලබා දෙයි;ප්‍රභව පා X ය 'c' ද නැතිනම් එය '\u{63}' ද යන්න පරිශීලකයාට දැන ගැනීමට ක්‍රමයක් නොමැත.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) `Option::cloned` ට සමාන දෙයක්, නමුත් `Bound<&T>` සඳහා.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// සැ.යු, පාලම `to_string` පමණක් සපයයි, එය මත පදනම්ව `fmt::Display` ක්‍රියාත්මක කරන්න (දෙක අතර සුපුරුදු සම්බන්ධතාවයේ ආපසු හැරවීම).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// අකුරු රහිතව නැවත එකම වචනාර්ථයට පරිවර්තනය කළ හැකි නූලක් ලෙස වචනාර්ථය මුද්‍රණය කරයි (පාවෙන ලක්ෂ්‍ය සාක්ෂරයන් සඳහා හැකි වටය හැර).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// පරිසර විචල්‍යයන් සඳහා ප්‍රවේශය.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// පරිසර විචල්‍යයක් ලබා ගෙන යැපුම් තොරතුරු ගොඩනැගීමට එය එක් කරන්න.
    /// සම්පාදකයා ක්‍රියාත්මක කරන බිල්ඩ් සිස්ටම් එක සම්පාදනය කිරීමේදී විචල්‍යයට ප්‍රවේශ වූ බව දැනගනු ඇති අතර එම විචල්‍යයේ අගය වෙනස් වූ විට නැවත ගොඩනැගීමට හැකි වේ.
    ///
    /// පරායත්තතා ලුහුබැඳීමට අමතරව මෙම ශ්‍රිතය සම්මත පුස්තකාලයෙන් `env::var` ට සමාන විය යුතුය, තර්කය UTF-8 විය යුතුය.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}