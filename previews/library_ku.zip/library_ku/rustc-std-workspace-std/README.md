# `rustc-std-workspace-std` crate

Belgekirinên ji bo `rustc-std-workspace-core` crate bibînin.