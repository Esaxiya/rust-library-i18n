//! Traits ji bo veguherînên di navbera celeb de.
//!
//! Di vê modulê de traits awayek vediguhêzîne ku ji celebek li celebek din veguherîne.
//! Her trait armancek cûda dike:
//!
//! - [`AsRef`] trait-ê ji bo veguherînên referansa-erzan-erzan bicîh bikin
//! - Ji bo veguherînên erzan-guhêrbar-guherbar [`AsMut`] trait bicîh bikin
//! - Ji bo vexwarinên veguherînên nirx-bi-nirxê [`From`] trait bicîh bikin
//! - [`Into`] trait ji bo vexwarinê veguheztinên nirx-bi-nirxê li celebên derveyî crate-ya heyî bicîh bikin
//! - [`TryFrom`] û [`TryInto`] traits mîna [`From`] û [`Into`] tevdigerin, lê dema ku veguherîn têk bibe divê were pêkanîn.
//!
//! Di vê modulê de traits ji bo fonksiyonên gelemperî bi gelemperî wekî trait bounds têne bikar anîn ku ji bo argumanên pir celeb têne piştgirî kirin.Ji bo mînakan belgeya her trait bibînin.
//!
//! Wekî nivîskarek pirtûkxaneyê, divê hûn her dem pêkanîna [`From<T>`][`From`] an [`TryFrom<T>`][`TryFrom`] li şûna [`Into<U>`][`Into`] an [`TryInto<U>`][`TryInto`] tercîh bikin, ji ber ku [`From`] û [`TryFrom`] nermbûnek mezintir peyda dikin û pêkanînên wekhev ên [`Into`] an [`TryInto`] belaş pêşkêşî dikin, bi saya pêkanîna betanî di pirtûkxaneya standard de.
//! Gava ku guhertoyek berî Rust 1.41 hedef digirin, dibe ku hewce be ku meriv [`Into`] an [`TryInto`] rasterast bicîh bike dema ku meriv veguherîne celebek derveyî crate-ya heyî.
//!
//! # Pêkanînên Giştî
//!
//! - [`AsRef`] û xweseriya [`AsMut`]-ê heke celebê hundurîn referansek be
//! - [`Ji`] `<U>ji bo T` tê wateya [`Di``]</u><T><U>ji bo U`</u>
//! - [`TryFrom`]`<U>ji bo T` tê wateya [`TryInto`]`</u><T><U>ji bo U`</u>
//! - [`From`] û [`Into`] refleksîf in, ku tê vê wateyê ku hemî celeb dikarin `into` xwe û `from` bi xwe jî bikin
//!
//! Ji bo nimûneyên karanînê her trait bibînin.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Fonksiyona nasnameyê.
///
/// Du tişt girîng in ku li ser vê fonksiyonê têne nîşankirin:
///
/// - Ew her gav ne wekhevî ye bi girtinek mîna `|x| x`, ji ber ku dibe ku dorpêç `x` bi rengek cûda bide zorê.
///
/// - Ew input `x` derbasî fonksiyonê dike.
///
/// Dibe ku fonksiyonek ku tenê inputê vedigerîne ecêb xuya dike, hin karanînên balkêş hene.
///
///
/// # Examples
///
/// `identity` bikar tînin da ku di rêzek fonksiyonên din, balkêş de tiştek nekin:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Ka em wusa bikin ku zêdekirina yekê fonksiyonek balkêş e.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Di rewşek de `identity` wekî rewşa bingeha "do nothing" bikar tînin:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Tiştên balkêştir bikin ...
///
/// let _results = do_stuff(42);
/// ```
///
/// `identity` bikar tînin da ku guhertoyên `Some` ên veberhênerê `Option<T>` bimînin:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Ji bo ku veguherînek referansa-referansa erzan pêk tê tê bikar anîn.
///
/// Ev trait dişibe [`AsMut`] ku ji bo veguheztina di navbera referansên guhêrbar de tê bikar anîn.
/// Heke hûn hewce ne ku veguherînek lêçûyî bikin çêtir e ku hûn [`From`] bi tîpa `&T` bicîh bikin an fonksiyonek xwerû binivîsin.
///
/// `AsRef` wekheviya [`Borrow`] heye, lê [`Borrow`] di çend aliyan de cuda ye:
///
/// - Berevajî `AsRef`, [`Borrow`] ji bo her `T` implanek betanî heye, û dikare were bikar anîn ku an referansek an nirxek qebûl bike.
/// - [`Borrow`] her weha hewce dike ku ji bo nirxa deynkirî [`Hash`], [`Eq`] û [`Ord`] ji yên nirxa xwedan re wekhev in.
/// Ji ber vê sedemê, heke hûn dixwazin tenê zeviyek yek a struct deyn bikin hûn dikarin `AsRef`, lê ne [`Borrow`] bicîh bînin.
///
/// **Note: Divê ev trait têk neçe **.Heke veguherîn dikare têk biçe, rêbazek xwerû bikar bînin ku [`Option<T>`] an [`Result<T, E>`] vedigerîne.
///
/// # Pêkanînên Giştî
///
/// - `AsRef` heke celebek hundurîn referansek an referansek guhêrbar be (mînak: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Bi karanîna trait bounds em dikarin argumanên ji celebên cihêreng bipejirînin heya ku ew bikaribin werin veguheztin bo celebê diyarkirî `T`.
///
/// Mînakî: Bi afirandina fonksiyonek gelemperî ku `AsRef<str>` digire em îfade dikin ku em dixwazin hemî referansên ku dikarin li [`&str`] werin veguheztin wekî arguman qebûl bikin.
/// Ji ber ku hem [`String`] hem jî [`&str`] `AsRef<str>` bicîh dikin em dikarin herduyan jî wekî argumana input qebûl bikin.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Veguherînê pêk tîne.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Ji bo ku veguherînek referansa guherbar-a-guherbar a erzan tê kirin.
///
/// Ev trait dişibe [`AsRef`] lê ji bo veguheztina navbera referansên guhêrbar tê bikar anîn.
/// Heke hûn hewce ne ku veguherînek lêçûyî bikin çêtir e ku hûn [`From`] bi tîpa `&mut T` bicîh bikin an fonksiyonek xwerû binivîsin.
///
/// **Note: Divê ev trait têk neçe **.Heke veguherîn dikare têk biçe, rêbazek xwerû bikar bînin ku [`Option<T>`] an [`Result<T, E>`] vedigerîne.
///
/// # Pêkanînên Giştî
///
/// - `AsMut` ger celebek hundurîn referansek guhêrbar be (mînak: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Ji bo fonksiyonek gelemperî `AsMut` wekî trait bound bikar tînin em dikarin hemî referansên guherbar ên ku dikarin werin veguheztin type `&mut T` qebûl bikin.
/// Ji ber ku [`Box<T>`] `AsMut<T>` bicîh tîne em dikarin fonksiyonek `add_one` binivîsin ku hemî argumanên ku dikarin werin veguheztin `&mut u64` bigire.
/// Ji ber ku [`Box<T>`] `AsMut<T>` bicîh tîne, `add_one` argumanên ji celebê `&mut Box<u64>` jî qebûl dike:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Veguherînê pêk tîne.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Guherînek nirx-bi-nirx ku nirxa navnîşê dixwe.Berevajî [`From`].
///
/// Divê meriv xwe ji pêkanîna [`Into`] dûr bixe û li şûna wê [`From`] bicîh bîne.
/// Pêkanîna [`From`] bixweber yek ji pêkanîna [`Into`] bi saya pêkanîna betanî di pirtûkxaneya standard de peyda dike.
///
/// Dema ku trait bounds-ê li ser fonksiyonek gelemperî diyar dikin bila [`Into`] ji [`From`]-ê bikar bînin tercîh bikin ku bicîh bikin ku celebên ku tenê [`Into`]-ê pêk tînin jî dikarin bikar bînin.
///
/// **Note: Divê ev trait têk neçe **.Ger veguherîn dikare têk biçe, [`TryInto`] bikar bînin.
///
/// # Pêkanînên Giştî
///
/// - [`Ji`]`<T>ji bo U` tê wateya `Into<U> for T`
/// - [`Into`] refleksîf e, ku tê vê wateyê ku `Into<T> for T` tê pêkanîn
///
/// # Pêkanîna [`Into`] ji bo veguherînan li celebên derveyî di guhertoyên kevn ên Rust de
///
/// Berî Rust 1.41, heke celebê hedefê ne beşek bû ji crate ya niha, wê hingê we nikaribû [`From`] rasterast bicîh bikira.
/// Mînakî, vê kodê bigirin:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Ev ê di guhertoyên kevnareyên zimên de berhev neke ji ber ku qaîdeyên sêwî yên Rust berê hinekî hişktir bûn.
/// Ji bo derbaskirina vê, hûn dikarin rasterast [`Into`] bicîh bikin:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Girîng e ku meriv fêhm bike ku [`Into`] pêkanîna [`From`] peyda nake (wekî [`From`] bi [`Into`] dike).
/// Ji ber vê yekê, divê hûn her dem hewl bidin ku [`From`] bicîh bikin û paşê ku [`From`] neyê bicîh kirin paşê vegerin [`Into`].
///
/// # Examples
///
/// [`String`] ["Into"] "<" ["Vec"] "<" ["u8"] ">>" bicîh dike: "
///
/// Ji bo ku em vebêjin ku em fonksiyonek gelemperî dixwazin ku hemî argumanên ku dikarin bi celebek diyarkirî `T` werin veguheztin bigire, em dikarin trait bound ya ["Into"] bikar bînin<T>`.
///
/// Mînakî: Fonksiyona `is_hello` hemî argumanên ku dikarin werin veguheztin ["Vec`]"<"["u8"]"> digire.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Veguherînê pêk tîne.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Dema ku nirxa inputê dixeritîne ji bo veguheztinên nirx-bi-nirxê tê bikar anîn.Ew beramberiya [`Into`] ye.
///
/// Pêdivî ye ku meriv her gav pêkanîna `From` li ser [`Into`] tercîh bike ji ber ku bicîhkirina `From` bixweber pêkanîna [`Into`] bi saya pêkanîna betanî di pirtûkxaneya standard de yek bi yek peyda dike.
///
///
/// [`Into`] tenê dema ku guhertoyek berî Rust 1.41 hedef digirin û veguherînin celebek derveyî crate ya heyî, bi cih bînin.
/// `From` ji ber qaîdeyên sêwî yê Rust nekaribû van guhertinan di guhertoyên berê de bike.
/// Ji bo bêtir agahdarî li [`Into`] binihêrin.
///
/// Dema ku trait bounds li ser fonksiyonek gelemperî diyar dikin, karanîna [`Into`] ji ya `From` tercîh bikin.
/// Bi vî rengî, cûreyên ku rasterast [`Into`] bicîh dikin dikarin wekî arguman jî werin bikar anîn.
///
/// `From` di heman demê de dema ku xebitandina xeletiyê dike pir bikêr e.Dema ku fonksiyonek ku bikaribe têk biçe ava dike, tîpa vegerîn dê bi gelemperî forma `Result<T, E>` be.
/// `From` trait kargêriya çewtiyê hêsan dike û bihêle ku fonksiyonek celebek çewtiyek yekane vegerîne ku gelek celebên çewtiyê vedigire.Ji bo bêtir agahdarî li beşa "Examples" û [the book][book] binêrin.
///
/// **Note: Divê ev trait têk neçe **.Ger veguherîn dikare têk biçe, [`TryFrom`] bikar bînin.
///
/// # Pêkanînên Giştî
///
/// - `From<T> for U` tê wateya [`Into`]`<U>ji bo T`</u>
/// - `From` refleksîf e, ku tê vê wateyê ku `From<T> for T` tê pêkanîn
///
/// # Examples
///
/// [`String`] `From<&str>` bicîh dike:
///
/// Zivirînek eşkere ji `&str` bo Têl bi vî rengî tête kirin:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Dema ku xebitandina çewtiyê pêk tîne, pir caran kêrhatî ye ku `From` ji bo celebê xeletiya xweya xwe bicîh bînin.
/// Bi veguhertina cûreyên xeletiya bingehîn li tîpa xweya xeleta xwerû ya ku celebê xeletiya bingehîn vedigire, em dikarin bêyî ku agahiya li ser sedemên bingehîn winda bikin, yek cûreyek çewtiyê vegerînin.
/// Operatorê '?' bi gazîkirina `Into<CliError>::into` ku dema bicîhkirina `From` bixweber tête peyda kirin, bixweber celebê xeletiya bingehîn bi tîpa meya xwerû veguherîne.
/// Hingê berhevkar diponijîne ka kîjan pêkanîna `Into` divê were bikar anîn.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Veguherînê pêk tîne.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Hewldanek veguherînek ku `self` dixwe, ku dibe ku biha nebe an nebe.
///
/// Divê nivîskarên pirtûkxaneyê bi gelemperî vê trait rasterast bicîh nekin, lê divê tercîh bikin ku [`TryFrom`] trait bicîh bikin, ku nermbûnek mezintir pêşkêşî dike û ji bo pêkanîna `TryInto` hevseng belaş pêşkêşî dike, bi saya pêkanîna perdeyek di pirtûkxaneya standard de.
/// Ji bo bêtir agahdarî li ser vê yekê, li belgekirina [`Into`] binihêrin.
///
/// # Pêkanîna `TryInto`
///
/// Vê heman astengî û ramanê wekî pêkanîna [`Into`] dikişîne, ji bo hûrguliyan li wir bibînin.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Cûre di bûyera çewtiyek veguherînê de vegeriya.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Veguherînê pêk tîne.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Veguherînên celebên sade û ewledar ku dibe ku di bin hin mercan de bi rengek kontrolkirî têk biçin.Ew beramberiya [`TryInto`] ye.
///
/// Ev kêrhatî ye dema ku hûn veguheztinek celebê dikin ku dibe ku bi rengek serfiraz bi ser bikeve lê di heman demê de dibe ku pêdivî bi karûbarek taybetî jî hebe.
/// Mînakî, çu rê tune ku meriv [`i64`] bi [`From`] trait bi [`i32`] veguherîne, ji ber ku dibe ku [`i64`] xwedî nirxek be ku [`i32`] nikare temsîl bike û ji ber vê yekê veguherîn dê daneyê winda bike.
///
/// Ev dibe ku bi qutkirina [`i64`] bi [`i32`] (di bingeh de dayîna modulê nirxa ["i64"] [`i32::MAX`]) an bi tenê vegerandina [`i32::MAX`], an jî bi rêbazek din.
/// [`From`] trait ji bo veguherînên bêkêmasî tête armanc kirin, ji ber vê yekê `TryFrom` trait bernameger agahdar dike dema ku veguherînek celeb dikare xerab bibe û bila wan biryar bide ka ew ê çawa birêve bibin.
///
/// # Pêkanînên Giştî
///
/// - `TryFrom<T> for U` tê wateya [`TryInto`]`<U>ji bo T`</u>
/// - [`try_from`] refleksîf e, ku tê vê wateyê ku `TryFrom<T> for T` tête cîbicîkirin û nikare têk biçe-tîpa têkildar `Error` ji bo gazîkirina `T::try_from()` li ser nirxek tîpa `T` [`Infallible`] e.
/// Dema ku celebê [`!`] were aram kirin dê [`Infallible`] û [`!`] wekhev be.
///
/// `TryFrom<T>` dikare wiha were pêkanîn:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Wekî ku hatî vegotin, [`i32`] `TryFrom <` ["i64"]">"bicîh dike:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Bi bêdengî `big_number` qut dike, hewce dike ku piştî rastiya darbestê were kifşkirin û rêve birin.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Xeletiyekê vedigire ji ber ku `big_number` pir mezin e ku di `i32` de cîh nebe.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // `Ok(3)` vedigire.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Cûre di bûyera çewtiyek veguherînê de vegeriya.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Veguherînê pêk tîne.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// NMPLAN GN GENERICK
////////////////////////////////////////////////////////////////////////////////

// Wekî ku hildikişe ser&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Wekî ku li ser &mut radibe
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): Lêkerên jorîn ji bo&/&mut bi yeka giştî ya jêrîn veguherînin:
// // Wekî ku li ser Derefê hiltîne
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Sized> AsRef <U>ji bo D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut li ser &mut radibe
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): Ji bo &mut têgeha jorîn bi ya gelemperî ya jêrîn veguherînin:
// // AsMut li ser DerefMut radibe
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Sized> AsMut <U>ji bo D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Ji têdigihîje Into
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Ji (û bi vî rengî Dûv re) refleksîf e
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Têbînî ya aramiyê:** Ev impl hîn tune, lê em "reserving space" in ku wê li future zêde dikin.
/// Ji bo hûragahiyan li [rust-lang/rust#64715][#64715] binêrin.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): li şûna xwe sererastkirinek prensîb bikin.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom tê wateya TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Veguherînên bêkêmasî ji hêla semantîkî ve bi veguherînên çewt ên bi tîpek çewtiya niştecîh re hevwate ne.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// BELA CONN BETON
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// TIPA ÇEWT YA ÇIMA
////////////////////////////////////////////////////////////////////////////////

/// Ji bo xeletiyên ku çu carî çênabin celebê çewtiyê.
///
/// Ji ber ku ev enum cûrbecûr tune, nirxek ji vî rengî çu carî bi rastî çênabe.
/// Ev dikare ji bo API-yên gelemperî ku [`Result`] bikar tînin û cureyê çewtiyê parametre dikin, bikêr be, da ku nîşan bide ku encam her gav [`Ok`] ye.
///
/// Mînakî, [`TryFrom`] trait (veguherînek ku [`Result`] vedigerîne) ji bo her cûreyê ku cîbicîkirina berevajî ya [`Into`] lê heye, pêkanîna perdeyek heye.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Lihevhatina Future
///
/// Vê enum eynî rola [the `!`“never”type][never] heye, ku di vê guhertoya Rust de nearam e.
/// Dema ku `!` were stabîlîzekirin, em plan dikin ku `Infallible` ji wê re celebek binavûdeng bikin:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Û di dawiyê de `Infallible` bêpar bikin.
///
/// Lêbelê yek dozek heye ku hevoksaziya `!` dikare were bikar anîn berî ku `!` wekî celebek têrker were stabîlîzekirin: di rewşa cureyê vegera fonksiyonê de.
/// Bi taybetî, pêkanînên mimkun e ku ji bo du cûreyên fonksiyonên cihêreng ên nîşangir:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Bi `Infallible` enumek e, ev kod derbasdar e.
/// Lêbelê dema ku `Infallible` ji never type re bibe navek, dê her du `impl` dest bi hevûdu bikin û ji ber vê yekê jî dê ji hêla qaîdeyên hevahengiya zimên trait ve neyên pejirandin.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}