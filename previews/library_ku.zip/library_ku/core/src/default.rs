//! `Default` trait ji bo celebên ku dibe ku xwediyê nirxên pêşkeftî yên watedar bin.

#![stable(feature = "rust1", since = "1.0.0")]

/// trait ji bo dayîna celebek nirxa xwerû ya kêrhatî.
///
/// Carcarinan, hûn dixwazin vegerin ser celebek nirxa xwerû, û ne xema we ne ku ew çi ye.
/// Ev gelek caran bi `struktura ku komek vebijarkan diyar dike tê:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// Em çawa dikarin hin nirxên pêşkeftî diyar bikin?Hûn dikarin `Default` bikar bînin:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// Naha, hûn hemî nirxên pêşdibistanê werdigirin.Rust ji bo cûrbecûr cûrbecûr prîmîtîfan `Default` bicîh dike.
///
/// Heke hûn dixwazin vebijarkek taybetî paşguh bikin, lê dîsa jî vebijarkên din biparêzin:
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// Heke hemî warên celebê `Default` bicîh bînin ev trait dikare bi `#[derive]` re were bikar anîn.
/// Dema ku `derkirin`d, ew ê ji bo her celebê zeviyê nirxa xwerû bikar bîne.
///
/// ## Ez çawa dikarim `Default` bicîh bikim?
///
/// Ji bo rêbaza `default()` pêkanînek peyda bikin ku nirxa celebê we vegerîne ku divê pêşdibistan be:
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// Ji bo celebek "default value" vedigerîne.
    ///
    /// Nirxên default bi gelemperî celebek nirxa destpêkê, nirxa nasnameyê, an jî tiştek din in ku dibe ku wekî pêşdîtinek watedar be.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna nirxên xwerû yên çêkirî:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// Xwe çêkirina xwe:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// Li gorî `Default` trait nirxa xwerû ya celebek vegerînin.
///
/// Tîpa ku vedigere ji kontekstê tête girtin;ev wekhevî `Default::default()` lê tîp kurttir e.
///
/// Bo nimûne:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// Makro hilberandin û hilberînek ji trait `Default`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }