//! Ji bo rêzikan îteratorê xwedan `IntoIter` diyar dike.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Xebatkarek [array]-ya nirx-nirx.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Ev rêzika ku em lê dubare dikin e.
    ///
    /// Hêmanên bi index `i` ku `alive.start <= i < alive.end` hêj nehatiye hilberandin û navnîşên rêzikê derbasdar in.
    /// Hêmanên ku bi nîşanên `i < alive.start` an `i >= alive.end` hene berê hatine hilberandin û divê êdî ew neyên destgirtin!Ew hêmanên mirî dibe ku di haletek bi tevahî uninitialized de bin!
    ///
    ///
    /// Ji ber vê yekê neguhêrbar ev in:
    /// - `data[alive]` zindî ye (ango hêmanên derbasdar tê de hene)
    /// - `data[..alive.start]` û `data[alive.end..]` mirî ne (ango hêman jixwe hatine xwendin û pêdivî ye ku êdî dest lê neyê girtin!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Hêmanên di `data` de ku hêj nehatine derxistin.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Li ser `array` ya dayî re iteratorek nû diafirîne.
    ///
    /// *Nîşe*: dibe ku piştî [`IntoIterator` is implemented for arrays][array-into-iter] ev rêbaza li future were betal kirin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Tîpa `value` li şûna `&i32`, li vir `i32` ye
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // EWLEH: : Transmute li vir bi rastî ewledar e.Belgeyên `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` misogerkirî ye ku xwedan heman mezinahî û hevsengî be
        // > wek `T`.
        //
        // Di belgeyan de ji rêzeyek `MaybeUninit<T>` bi komek `T` veguherînek jî tê nîşandan.
        //
        //
        // Bi vê yekê, ev destpêkirin neguhêzan têr dike.

        // FIXME(LukasKalbertodt): bi rastî `mem::transmute` li vir bikar bînin, gava ku ew bi generîkên const re dixebite:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Heya wê hingê, em dikarin `mem::transmute_copy` bikar bînin ku kopiyek bitwise wekî celebek cûda biafirînin, wê hingê `array` ji bîr bikin da ku neyê avêtin.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Perçeyek neguhêrbar a hemî hêmanên ku hêj nehatine hilberandin vedigerîne.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // EWLEH: Em dizanin ku hemî hêmanên di nav `alive` de bi rêkûpêk têne destpê kirin.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Perçeyek guhêrbar a hemî hêmanên ku hêj nehatiye derxistin vedigerîne.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // EWLEH: Em dizanin ku hemî hêmanên di nav `alive` de bi rêkûpêk têne destpê kirin.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Indeksa paşîn ji pêşê bistînin.
        //
        // Zêdekirina `alive.start` bi 1-ê di derheqê `alive` de neguhêrbar diparêze.
        // Lêbelê, ji ber vê guherînê, ji bo demek kurt, devera zindî ne `data[alive]`, lê `data[idx..alive.end]` ye.
        //
        self.alive.next().map(|idx| {
            // Hêmana ji rêzê bixwînin.
            // EWLEH: : `idx` navnîşek nav "alive" herêma berê ya
            // rêzî.Xwendina vê hêmanê tê vê wateyê ku `data[idx]` wekî mirî tête hesibandin (ango dest nede).
            // Ji ber ku `idx` destpêka devera zindî bû, devera zindî niha dîsa `data[alive]` e, û hemî neguhêzan vedigerîne.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Indeksa paşîn ji paş ve bistînin.
        //
        // Kêmkirina `alive.end` bi 1-ê di derheqê `alive` de neguhêrbar diparêze.
        // Lêbelê, ji ber vê guherînê, ji bo demek kurt, devera zindî ne `data[alive]`, lê `data[alive.start..=idx]` ye.
        //
        self.alive.next_back().map(|idx| {
            // Hêmana ji rêzê bixwînin.
            // EWLEH: : `idx` navnîşek nav "alive" herêma berê ya
            // rêzî.Xwendina vê hêmanê tê vê wateyê ku `data[idx]` wekî mirî tête hesibandin (ango dest nede).
            // Ji ber ku `idx` dawiya devera zindî bû, devera zindî nuha dîsa `data[alive]` e, û hemî neguhêzan vedigerîne.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // EWLEH: : Ev ewle ye: `as_mut_slice` tam bin-perçe vedigerîne
        // hêmanên ku hîn nehatine bar kirin û ku dimînin bêne avêtin.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Dê ji ber neguhêrbar `zindî 'tu carî binê binê. Destpê <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Iterator bi rastî dirêjahiya rast rapor dike.
// Hejmara hêmanên "alive" (ku dê hîn jî were hilberandin) dirêjahiya rêzeya `alive` e.
// Ev rêze di `next` an `next_back` de bi dirêjahî tê kêm kirin.
// Di wan rêbazan de her gav bi 1 tête kêm kirin, lê tenê heke `Some(_)` were vegerandin.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Nîşe, em ne hewce ne ku bi rasterast heman zindî ya rastîn hev bikin, ji ber vê yekê em dikarin tenê xilas bikin 0 bêyî ku `self` li ku ye.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Hemî hêmanên zindî klon bikin.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Di nav rêzek nû de klonek binivîsin, dûv re dora wê ya zindî nûve bikin.
            // Heke panics klon bike, em ê tiştên rast berê rast bavêjin.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Tenê hêmanên ku hîn nehatine rakirin çap bikin: em êdî nekarin xwe bigihînin hêmanên berdayî.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}