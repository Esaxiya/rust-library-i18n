//! `Clone` trait ji bo celebên ku nekarin 'bi zorê werin kopî kirin'.
//!
//! Di Rust de, hin celebên hêsan "implicitly copyable" in û gava ku hûn wan destnîşan dikin an wekî argumanan derbas dikin, wergir dê kopiyek bistîne, nirxa orjînal di cîh de bihêle.
//! Van celeb hewceyê dabeşkirinê ne ku werin kopîkirin û nerîtên wan ên dawîn tune ne (ango, ew qutiyên xwedan nîn in an [`Drop`] bicîh nakin), ji ber vê yekê berhevkar wan erzan û ewledar dibîne ku werin kopî kirin.
//!
//! Ji bo celebên din divê kopî bi zelalî bêne çêkirin, bi peymanê [`Clone`] trait tê pêkanîn û bang li rêbaza [`clone`] tê kirin.
//!
//! [`clone`]: Clone::clone
//!
//! Mînaka karanîna bingehîn:
//!
//! ```
//! let s = String::new(); // Tîpa string Clone bicîh dike
//! let copy = s.clone(); // ji ber vê yekê em dikarin wê klon bikin
//! ```
//!
//! Ji bo ku Clone trait bi hêsanî were bicîh kirin, hûn dikarin `#[derive(Clone)]` jî bikar bînin.Mînak:
//!
//! ```
//! #[derive(Clone)] // em Clone trait li Morpheus strukturel zêde dikin
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // û naha em dikarin wê klon bikin!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// trait-ya hevpar ji bo şiyana eşkerekirina dubarekirina tiştê.
///
/// Cûda ji [`Copy`] di wê [`Copy`] de nexşandî ye û pir erzan e, lê `Clone` her gav eşkere ye û dibe ku biha nebe an jî nebe.
/// Ji bo ku van taybetmendiyan were sepandin, Rust nahêle ku hûn [`Copy`] ji nû ve bikin, lê hûn dikarin `Clone` ji nû ve bicîh bikin û koda keyfî bi rêve bibin.
///
/// Ji ber ku `Clone` ji [`Copy`] gelemperîtir e, hûn dikarin bixweber bikin ku her tiştê [`Copy`] jî `Clone` be.
///
/// ## Derivable
///
/// Heke hemî zevî `Clone` bin ev trait dikare bi `#[derive]` re were bikar anîn.`Pêkanîna`d [`Clone`] li her qadê [`clone`] bang dike.
///
/// [`clone`]: Clone::clone
///
/// Ji bo sazûmanek gelemperî, `#[derive]` bi zêdekirina `Clone` ve girêdayî li ser pîvanên gelemperî `Clone` bi şertî bicîh dike.
///
/// ```
/// // `derive` ji bo Xwendinê Klone bicîh tîne<T>gava T Clone ye.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Ez çawa dikarim `Clone` bicîh bikim?
///
/// Pêdivî ye ku celebên ku [`Copy`] ne, bicîhkirina `Clone` ya sêalî hebe.Bi fermîtir:
/// heke `T: Copy`, `x: T`, û `y: &T`, wê hingê `let x = y.clone();` bi `let x = *y;` re hevseng e.
/// Pêdivî ye ku pêkanînên destan hay ji xwe hebin ku ev neguhêzbar bisekinin;lêbelê, pêdivî ye ku kodê ne ewle pê ewle nebe ku ewlehiya bîranînê misoger bike.
///
/// Mînakek sazûmanek gelemperî ye ku nîşanderê fonksiyonê digire.Di vê rewşê de, pêkanîna `Clone` nayê `derkirin`d, lê dikare wekî pêk were:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Pêkanînên pêvek
///
/// Ji bilî [implementors listed below][impls], celebên jêrîn jî `Clone` bicîh dikin:
///
/// * Celebên hêmanên fonksiyonê (ango, celebên cihêreng ên ji bo her fonksiyonê hatine diyarkirin)
/// * Cûreyên pointerê fonksiyonê (mînak, `fn() -> i32`)
/// * Heke celeb celeb `Clone` jî bicîh bike ji bo her mezinahiyan celebên rêzikan, mînakî `[i32; 123456]`
/// * Cûreyên duqolî, heke her pêkhateyek `Clone` jî bicîh bike (mînakî, `()`, `(i32, bool)`)
/// * Cûreyên girtinê, heke ew ji jîngehê re qîmetek nagirin an heke hemî nirxên wusa girtî `Clone` bixwe bicîh bînin.
///   Bala xwe bidinê ku guhêrbarên ku ji hêla referansa hevpar ve hatine girtin her gav `Clone` bicîh dikin (heke referans jî neke), lê guherbarên ku ji hêla referansa guhêrbar ve hatine girtin qet `Clone` bicîh nakin.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Kopiyek nirxê vedigire.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str Clone bicîh dike
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Ji `source`-ê kopî-peywirê pêk tîne.
    ///
    /// `a.clone_from(&b)` di karbidestiyê de wekhevî `a = b.clone()` e, lê dikare ji nû ve were bikar anîn da ku çavkaniyên `a` ji nû ve were bikar anîn da ku ji dabeşkirinên nehewce dûr bikeve.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Makro hilberandin û hilberînek ji trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): ev strut bi tenê ji hêla#[deriv] ve têne bikar anîn da ku bêje ku her pêkhateyek ji celebek Clone an Copy-ê pêk tîne.
//
//
// Pêdivî ye ku ev darîn qet di kodê bikarhêner de xuya nebin.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Pêkanînên `Clone` ji bo celebên prîmîtîf.
///
/// Pêkanînên ku di Rust de nayê vegotin di `traits::SelectionContext::copy_clone_conditions()` de di `rustc_trait_selection` de têne pêkanîn.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Çavkaniyên hevpar dikarin werin klon kirin, lê referansên guhêrbar *nekarin*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Çavkaniyên hevpar dikarin werin klon kirin, lê referansên guhêrbar *nekarin*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}