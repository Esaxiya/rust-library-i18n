//! Konteynerên guhêrbar ên hevpar.
//!
//! Ewlekariya bîranînê ya Rust li ser vê rêgezê bingeh digire: Tiştek `T` tê dayîn, tenê yek ji yên jêrîn heye gengaz e:
//!
//! - Hebûna çend referansên neguhêrbar (`&T`) li ser tiştê (ku wekî **aliasing** jî tê zanîn).
//! - Xwedî yek referansa guhêrbar (`&mut T`) ji tiştê re (ku wekî **mutabîlî** jî tê zanîn).
//!
//! Ev ji hêla berhevkar Rust ve tê sepandin.Lêbelê, rewş hene ku ev rêgez têra xwe nerm nine.Carcarinan pêdivî ye ku bi referansên pirjimar re hebek hebe û lêbelê wê mutale bike.
//!
//! Konteynerên guhêrbar ên parveker hene ku bila bihevrabûnek bi rengek kontrolkirî, heya hebûna aliasing jî hebe.[`Cell<T>`] û [`RefCell<T>`] dihêlin ku vê yekê bi rengek tek-têl bikin.
//! Lêbelê, ne `Cell<T>` ne jî `RefCell<T>` bi têl ewle ne (ew [`Sync`] bicîh nakin).
//! Heke hûn hewce ne ku di navbera pir mijaran de aliasing û mutasyonê bikin gengaz e ku hûn celebên [`Mutex<T>`], [`RwLock<T>`] an [`atomic`] bikar bînin.
//!
//! Nirxên celebên `Cell<T>` û `RefCell<T>` dikarin bi navgîniya referansên parvekirî werin guhertin (ango
//! celebê hevpar `&T`), lê pir celebên Rust tenê bi navnîşanên yekta (`&mut T`) têne guhartin.
//! Em dibêjin ku `Cell<T>` û `RefCell<T>` 'guhêrbariya hundurîn' peyda dikin, berevajî celebên tîpîk ên Rust ku 'guhêrîna mîratî' nîşan didin.
//!
//! Cûreyên şaneyê bi du tehm têne: `Cell<T>` û `RefCell<T>`.`Cell<T>` guhêrbariya hundurîn bi veguheztina nirxên li `Cell<T>` û derveyî re pêk tîne.
//! Ji bo ku referansan li şûna nirxan bikar bînin, divê meriv celebê `RefCell<T>` bikar bîne, berî mutasyonê qeflek nivîsandinê bistîne.`Cell<T>` rêbazên peyda kirin û nirxa navxweyî ya heyî diguherîne:
//!
//!  - Ji bo celebên ku [`Copy`] bicîh dikin, rêbaza [`get`](Cell::get) nirxa hundurîn a heyî vedigire.
//!  - Ji bo celebên ku [`Default`] bicîh dikin, rêbaza [`take`](Cell::take) nirxa navxweyî ya heyî bi [`Default::default()`] diguhezîne û nirxa şûnda vedigerîne.
//!  - Ji bo her cûreyê, rêbaza [`replace`](Cell::replace) şûna nirxê hundurê hundur digire û nirxa şûnda vedigerîne û rêbaza [`into_inner`](Cell::into_inner) `Cell<T>` dixwe û nirxa hundurîn jî vedigerîne.
//!  Wekî din, rêbaza [`set`](Cell::set) şûna nirxa hundurîn digire, nirxa şûnda dadikeve.
//!
//! `RefCell<T>` Jiyana Rust bikar tîne da ku 'deynkirina dînamîk', pêvajoyek ku meriv pê re bigihîje gihîneka demkî, taybetî, guhêrbar a nirxa hundurîn, bicîh bîne.
//! Borrows ji bo `RefCell`<T>`s têne şopandin 'di dema xebatê de, berevajî celebên referansa xwemalî ya Rust ku bi tevahî bi statîkî têne şopandin, di dema berhevkirinê de.
//! Ji ber ku deynên `RefCell<T>` dînamîk in mimkun e ku meriv hewil bide ku nirxek ku ji berê ve muttefîk deynkirî ye;dema ku ev diqewime wê di têl panic de encam bide.
//!
//! # Kengê mutabîliyeta hundurîn hilbijêrin
//!
//! Guhertina mîratî ya hevpar, ku divê yek gihîştina wê ya yekta hebe ku nirxek biguheze, yek ji wan hêmanên zimanê sereke ye ku Rust dike sedem ku bi xurtî li ser aliasing ya pointer bifikire, bi statîkî pêşî li çewtiyên hilweşînê bigire.
//! Ji ber wilo, guhêrbariya mîratî tê tercîh kirin, û guhêrîna hundurîn tiştek wekî çareya paşîn e.
//! Ji ber ku celebên şaneyê mutasyonê li cîhê ku dê nehêle lê qedexe be, carinan hene ku guherîna hundurîn guncan be, an jî *divê* jî were bikar anîn, mînak
//!
//! * Danasîna mutabîlîtiya 'inside' ya tiştek neguhêrbar
//! * Agahdariyên tetbîqkirinê yên rêbazên mentiqî-guhêrbar.
//! * Guhertinên pêkanînên [`Clone`].
//!
//! ## Danasîna mutabîlîtiya 'inside' ya tiştek neguhêrbar
//!
//! Gelek celebên nîşanderê jîr ên hevpar, di nav wan de [`Rc<T>`] û [`Arc<T>`], konteynerên ku dikarin werin klon kirin û di navbera gelek partiyan de were parve kirin peyda dikin.
//! Ji ber ku dibe ku nirxên tê de pirjimar-pirjimar bin, ew tenê bi `&`, ne `&mut`, dikarin werin deyn kirin.
//! Bêyî şaneyan dê ne mimkûn be ku meriv daneyên hundurê van nîşangirên zîrek mutate bike.
//!
//! Hingê pir gelemperî ye ku meriv `RefCell<T>` têxe hundurê cûreyên nîşanderê hevbeş da ku guherîn ji nû ve bide çêkirin:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Astengiyek nû biafirînin da ku qada deynê dînamîk sînor bikin
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Bala xwe bidinê ku heke me nehişta ku deynê berê yê cache-ê ji qadê derkeve wê hingê deynê paşê dê bibe sedema xelekek dînamîk panic.
//!     //
//!     // Ev xetera sereke ya karanîna `RefCell` e.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Zanibe ku ev mînak `Rc<T>` û ne `Arc<T>` bikar tîne.`RefCell<T>`s ji bo senaryoyên yek-têl in.Ger hûn di rewşek pir-têl de mutabaqata hevpar hewce bikin bila [`RwLock<T>`] an [`Mutex<T>`] bikar bînin.
//!
//! ## Agahdariyên tetbîqkirinê yên rêbazên mentiqî-guhêrbar
//!
//! Car carinan dibe ku bixwaze ku meriv di API-yê de eşkere neke ku mutasyonek "under the hood" diqewime.
//! Ev dibe ku ji ber ku bi mantiqî operasyon neguhêrbar e, lê mînak, caching zorê dide pêkanînê ku mutasyonê pêk bîne;an ji ber ku hûn hewce ne ku mutasyonê bikar bînin da ku rêbaza trait ya ku di destpêkê de ji bo girtina `&self` hate diyarkirin bicîh bînin.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Hesabkirina biha li vir diçe
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Guhertinên pêkanînên `Clone`
//!
//! Ev bi tenê bûyerek taybetî, lê hevpar a ya berê ye: ji bo operasyonên ku guherbar xuya dikin mutabîlîtê vedişêrin.
//! Tê payîn ku rêbaza [`clone`](Clone::clone) nirxa çavkaniyê naguheze, û tê îlan kirin ku `&self` digire, ne `&mut self`.
//! Ji ber vê yekê, her mutasyona ku di rêbaza `clone` de diqewime, divê celebên şaneyê bikar bîne.
//! Mînakî, [`Rc<T>`] hejmarên referansa xwe di nav `Cell<T>` de didomîne.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Cihek bîranîna guhêrbar.
///
/// # Examples
///
/// Di vê mînakê de, hûn dikarin bibînin ku `Cell<T>` mutasyonê di hundurê sazûmanek neguhêrbar de dihêle.
/// Bi gotinên din, ew "interior mutability" dihêle.
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ÇEWT: `my_struct` neguhêrbar e
/// // my_struct.regular_field =nirxa_nû;
///
/// // XEBAT: her çend `my_struct` neguhêrbar be jî, `special_field` `Cell` e,
/// // ku her dem dikare were guhartin
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Ji bo bêtir [module-level documentation](self) bibînin.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// `Cell<T>`, bi nirxa `Default` ji bo T. diafirîne.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// `Cell`-ya nû diafirîne ku tê de nirxa dayî ye.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Nirxa tê de destnîşan dike.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Nirxên du ellsaneyan diguheze.
    /// Cûdahiya bi `std::mem::swap` ev e ku ev fonksiyonê `&mut` referans hewce nake.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // EWLEH: : Ev ger ji têlên cihêreng were gazîkirin dibe ku ev xetere be, lê `Cell`
        // `!Sync` e ji ber vê yekê dê çênebe.
        // Ev jî dê ji ber ku `Cell` piştrast dike ku dê tiştek din li van her du `Hucreyan` neyê xuyang kirin, tu pûanan nederbasdar dike.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Nirxa tê de bi `val` re vediguhêze, û nirxa heyî ya berê vedigire.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // EWLEHIYA: Ev dikare ji pêşbaziyên danûstendinê re bibe sedema sedem ku heke ji xelekek veqetandî were bang kirin
        // lê `Cell` `!Sync` e ji ber vê yekê dê çênebe.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Nirxê vedigire.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Kopiyek nirxa tê de vedigere.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // EWLEHIYA: Ev dikare ji pêşbaziyên danûstendinê re bibe sedema sedem ku heke ji xelekek veqetandî were bang kirin
        // lê `Cell` `!Sync` e ji ber vê yekê dê çênebe.
        unsafe { *self.value.get() }
    }

    /// Nirxa tê de bi karanîna fonksiyonek nûve dike û nirxa nû vedigire.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Di vê şaneyê de pointerek xav vedigere ser daneyên bingehîn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Li ser daneyên bingehîn referansa guhêrbar vedigerîne.
    ///
    /// Ev bang `Cell` bihevguheztî (di dema berhevkirinê de) deyn dike ku ew garantî dike ku em xwediyê referansa tenê ne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `&Cell<T>` ji `&mut T` vedigerîne
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // EWLEH: : `&mut` gihîştina bêhempa misoger dike.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Nirxa şaneyê digire, `Default::default()` li şûna xwe dihêle.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// `&[Cell<T>]` ji `&Cell<[T]>` vedigerîne
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // EWLEHIY: : `Cell<T>` bi `T` re heman bîranînê heye.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Cihê bîranînek guhêrbar a bi qaîdeyên deyn dînamîk hatine kontrol kirin
///
/// Ji bo bêtir [module-level documentation](self) bibînin.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Çewtiyek ku ji hêla [`RefCell::try_borrow`] ve hatî vegerandin.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Çewtiyek ku ji hêla [`RefCell::try_borrow_mut`] ve hatî vegerandin.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Nirxên erênî hejmara `Ref` çalak nîşan dikin.Nirxên negatîf hejmara `RefMut` çalak nîşan dikin.
// Pirjimar `RefMut` dikare tenê di demekê de çalak be heke ew behsa pêkhateyên cihêreng, nevemirandî yên `RefCell` bikin (mînak, rêzikên cûda yên perçeyek).
//
// `Ref` û `RefMut` her du bi mezinahî du peyv in, û ji ber vê yekê dê hebe ku `Ref` an`RefMut` ya hebkî têr nebe ku nîvê rêza `usize` zêde bibe.
// Ji ber vê yekê, dibe ku `BorrowFlag` dê carî têr nebe an bifire.
// Lêbelê, ev ne garantî ye, ji ber ku bernameyek patholojîk dikare bi berdewamî biafirîne û dûv re mem::forget `Ref` an `RefMut` s.
// Ji ber vê yekê, pêdivî ye ku hemî kod bi zelalî ji bo zêdebûn û binavbûnê kontrol bikin da ku ji bêewlehiyê dûr bikevin, an jî bi kêmanî di bûyera ku zêdebûn an binavbûn çêdibe rast tevbigerin (mînak, BorrowRef::new binihêrin).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// `RefCell` nû ku `value` vedigire diafirîne.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// `RefCell` dixwe, nirxa pêçayî vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Ji ber ku vê fonksiyonê ji hêla nirxê ve `self` (`RefCell`) digire, berhevkar bi statîkî piştrast dike ku ew naha ne deynkirî ye.
        //
        self.value.into_inner()
    }

    /// Nirxa pêçayî bi nirxek nû veguherîne, nirxa kevn vedigerîne, bêyî ku yek jê deinitialize bike.
    ///
    ///
    /// Ev fonksiyon bi [`std::mem::replace`](../mem/fn.replace.html) re têkildar e.
    ///
    /// # Panics
    ///
    /// Heke hêjayî niha deyn e Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Nirxa pêçayî bi nirxek nû ya ku ji `f` hatî hesibandin şûnda dike, nirxa kevn vedigerîne, bêyî ku yek jê deinitialize bike.
    ///
    ///
    /// # Panics
    ///
    /// Heke hêjayî niha deyn e Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Nirxa pêçayî ya `self` bi nirxa pêçayî ya `other` veguherîne, bêyî ku yek jê deinitialize bike.
    ///
    ///
    /// Ev fonksiyon bi [`std::mem::swap`](../mem/fn.swap.html) re têkildar e.
    ///
    /// # Panics
    ///
    /// Panics heke di `RefCell`-an de hêjayî niha deyn e.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Nemaze nirxa pêçayî deyn dike.
    ///
    /// Deyn dom dike heya ku `Ref` vegeriyaye ji qada xwe derkeve.
    /// Di heman demê de gelek deynên neguhêrbar dikarin werin derxistin.
    ///
    /// # Panics
    ///
    /// Panics heke hêjayî niha muttebalek tê deyn kirin.
    /// Ji bo celebek ne-panîkî, [`try_borrow`](#method.try_borrow) bikar bînin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Mînakek panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Bêguman nirxa pêçandî deyn dike, ger ku hêjayî niha muttebale deyn e çewtiyek vedigere.
    ///
    ///
    /// Deyn dom dike heya ku `Ref` vegeriyaye ji qada xwe derkeve.
    /// Di heman demê de gelek deynên neguhêrbar dikarin werin derxistin.
    ///
    /// Ev guhertoya ne-panîkî ya [`borrow`](#method.borrow) ye.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // EWLEH: : `BorrowRef` piştrast dike ku tenê gihînek neguhêrbar heye
            // heya nirxê dema deyn kirin.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Bi guharî nirxa pêçayî deyn dike.
    ///
    /// Deyn heya ku `RefMut` vegeriyayî an jî hemî `RefMut` ê ku jê derketî ji qada derketinê dom dike.
    ///
    /// Dema ku ev deyn çalak e hêjayî nayê deyn kirin.
    ///
    /// # Panics
    ///
    /// Heke hêjayî niha deyn e Panics.
    /// Ji bo celebek ne-panîkî, [`try_borrow_mut`](#method.try_borrow_mut) bikar bînin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Mînakek panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Bi guhêrbar nirxa pêçayî deyn dike, ger ku nirx niha deyn e çewtiyek vedigerîne.
    ///
    ///
    /// Deyn heya ku `RefMut` vegeriyayî an jî hemî `RefMut` ê ku jê derketî ji qada derketinê dom dike.
    /// Dema ku ev deyn çalak e hêjayî nayê deyn kirin.
    ///
    /// Ev guhertoya ne-panîkî ya [`borrow_mut`](#method.borrow_mut) ye.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // BELAW: : `BorrowRef` gihîştina bêhempa garantî dike.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Di vê şaneyê de pointerek xav vedigere ser daneyên bingehîn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Li ser daneyên bingehîn referansa guhêrbar vedigerîne.
    ///
    /// Ev bang `RefCell` bihevguherîn (di dema berhevkirinê) deyn dike ji ber vê yekê ne hewceyê kontrolên dînamîkî ye.
    ///
    /// Lêbelê hişyar bimînin: ev rêbaz hêvî dike ku `self` guhêrbar be, ku bi gelemperî dema ku `RefCell` bikar tê ne wusa ye.
    ///
    /// Ger `self` guhêrbar nebe li şûna wê binihêrin rêbaza [`borrow_mut`].
    ///
    /// Di heman demê de, ji kerema xwe hay jê hebin ku ev rêbaz tenê ji bo mercên taybetî ye û bi gelemperî ne ya ku hûn dixwazin ne.
    /// Di rewşa gumanê de, li şûna [`borrow_mut`] bikar bînin.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Bandora cerdevanên leyiztin li ser deynê `RefCell` betal bikin.
    ///
    /// Ev bang dişibihe [`get_mut`] lê pisportir e.
    /// Ew ji bo misogerkirina tunebûna deyn `RefCell` bihevra deyn dike û dûv re dewleta ku deynên hevpar dişopîne ji nû ve vedigerîne.
    /// Vê girîng e ku heke hin deynên `Ref` an `RefMut` derketibin holê.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Bêguman nirxa pêçandî deyn dike, ger ku hêjayî niha muttebale deyn e çewtiyek vedigere.
    ///
    /// # Safety
    ///
    /// Berevajî `RefCell::borrow`, ev rêbaz ne ewle ye ji ber ku ew `Ref` venagerîne, bi vî awayî ala deyn bêpar dimîne.
    /// Bi mutabaqî deynkirina `RefCell` dema ku referansa ku bi vê rêbazê vegerî zindî ye tevgerek nediyarkirî ye.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // EWLEHIY check: Em kontrol dikin ku êdî kes bi çalakî nanivîse, lê wusa ye
            // berpirsiyariya gazîvan ji bo bicîh bikin ku kes nenivîsîne heya ku referansa vegeriyayî nema tê bikar anîn.
            // Di heman demê de, `self.value.get()` behsa nirxa xwedan `self` dike û bi vî rengî tête dabîn kirin ku ji bo jiyana `self` derbasdar be.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Nirxa pêçayî digire, `Default::default()` li şûna xwe bihêle.
    ///
    /// # Panics
    ///
    /// Heke hêjayî niha deyn e Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics heke hêjayî niha muttebalek tê deyn kirin.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// `RefCell<T>`, bi nirxa `Default` ji bo T. diafirîne.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics heke di `RefCell`-an de hêjayî niha deyn e.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics heke di `RefCell`-an de hêjayî niha deyn e.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics heke di `RefCell`-an de hêjayî niha deyn e.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics heke di `RefCell`-an de hêjayî niha deyn e.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics heke di `RefCell`-an de hêjayî niha deyn e.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics heke di `RefCell`-an de hêjayî niha deyn e.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics heke di `RefCell`-an de hêjayî niha deyn e.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Zêdekirina deyn dikare di van rewşan de bibe sedema nirxek nexwendin (<=0):
            // 1. Ew <0 bû, ango deynên nivîsandinê hene, ji ber vê yekê em ji ber qaîdeyên navnîşkirina navnîşa Rust em nikarin deynek xwendî bihêlin
            // 2.
            // Ew isize::MAX bû (mîqdara herî zêde ya deynên xwendinê) û ew diherike nav isize::MIN (mîqdara herî zêde ya deynên nivîsandinê) ji ber vê yekê em nikarin rê bidin deynek xwendinê ya din jî ji ber ku isize nikare ewqas deynên xwendî temsîl bike (ev tenê dibe ku hûn mem::forget ji mîqdara piçûk a domdar a `Ref`ê bêtir, ku ne pratîkek baş e)
            //
            //
            //
            //
            None
        } else {
            // Zêdekirina deyn dikare di van rewşan de bibe sedema nirxek xwendinê (> 0):
            // 1. Ew=0 bû, ango ne deyn bû, û em deynê xwendî yê yekem digirin
            // 2. Ew> 0 û <isize::MAX bû, ango
            // deynên xwendinê hebûn, û isize têra xwe mezin e ku dikare deynek xwendî ya din jî temsîl bike
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Ji ber ku ev Ref heye, em dizanin ala deyn deynek xwendinê ye.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Nehêlin kontra deyn li ser deynek nivîskî zêde bibe.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Navnîşek deynkirî ya li ser nirxek di qutika `RefCell` de pêça.
/// Cûreyek pêçayî ji bo nirxek neguhêzbar a ji `RefCell<T>`.
///
/// Ji bo bêtir [module-level documentation](self) bibînin.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// `Ref`-ê kopî dike.
    ///
    /// `RefCell` jixwe neguhêrbar deyn e, ji ber vê yekê nabe ku têk biçe.
    ///
    /// Ev fonksiyonek têkildar e ku pêdivî ye ku wekî `Ref::clone(...)` were bikar anîn.
    /// Pêkanîna `Clone` an rêbazek dê bi karanîna berfireh a `r.borrow().clone()` re têkildar bibe da ku naveroka `RefCell` klon bike.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Ji bo perçeyek daneya deynkirî `Ref` nû çêdike.
    ///
    /// `RefCell` jixwe neguhêrbar deyn e, ji ber vê yekê nabe ku têk biçe.
    ///
    /// Ev fonksiyonek têkildar e ku pêdivî ye ku wekî `Ref::map(...)` were bikar anîn.
    /// Rêbazek dê rêbazên bi heman navî li naveroka `RefCell` ya ku bi `Deref` ve tê bikar anîn têkeve.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Ji bo hêmanek vebijarkî ya daneya deyn `Ref`-ya nû çêdike.
    /// Ger dorpêç `None` vegere cerdevanê orjînal wekî `Err(..)` vedigere.
    ///
    /// `RefCell` jixwe neguhêrbar deyn e, ji ber vê yekê nabe ku têk biçe.
    ///
    /// Ev fonksiyonek têkildar e ku pêdivî ye ku wekî `Ref::filter_map(...)` were bikar anîn.
    /// Rêbazek dê rêbazên bi heman navî li naveroka `RefCell` ya ku bi `Deref` ve tê bikar anîn têkeve.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// `Ref`-ê ji bo pêkhateyên cihêreng ên daneyên deynkirî li gelek `Ref`ê dabeş dike.
    ///
    /// `RefCell` jixwe neguhêrbar deyn e, ji ber vê yekê nabe ku têk biçe.
    ///
    /// Ev fonksiyonek têkildar e ku pêdivî ye ku wekî `Ref::map_split(...)` were bikar anîn.
    /// Rêbazek dê rêbazên bi heman navî li naveroka `RefCell` ya ku bi `Deref` ve tê bikar anîn têkeve.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Bi navnîşek daneyên bingehîn veguherînin.
    ///
    /// `RefCell` ya bingehîn carî carî bi mutabet nayê deyn kirin û dê her dem ji berê de bêguhzîn deynkirî xuya bike.
    ///
    /// Ne fikra baş e ku ji hejmarek berdewam a referansan bêtir derkeve.
    /// `RefCell` dikare bêguhêrbar dîsa were deyn kirin heke tenê hejmarek piçûktir a lehçeyan bi tevahî çêbûbe.
    ///
    /// Ev fonksiyonek têkildar e ku pêdivî ye ku wekî `Ref::leak(...)` were bikar anîn.
    /// Rêbazek dê rêbazên bi heman navî li naveroka `RefCell` ya ku bi `Deref` ve tê bikar anîn têkeve.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Bi jibîrkirina vê Refê em piştrast dikin ku jimareka deynê di RefCell de di jiyana `'b` de nikare vegere UNUSED.
        // Ji nû ve sazkirina dewleta şopandina referansê hewce dike ku referansek yekta ya RefCell-a deynkirî hebe.
        // Ji şaneya xwerû bêtir referansên guherbar nayên afirandin.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Ji bo perçeyek daneya deynkirî `RefMut` nû çêdike, mînakî, variantek enum.
    ///
    /// `RefCell` jixwe bi muttefîk tê deyn kirin, ji ber vê yekê ev nikare têk biçe.
    ///
    /// Ev fonksiyonek têkildar e ku pêdivî ye ku wekî `RefMut::map(...)` were bikar anîn.
    /// Rêbazek dê rêbazên bi heman navî li naveroka `RefCell` ya ku bi `Deref` ve tê bikar anîn têkeve.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): rast-kontrolkirina deyn
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Ji bo pêkhateyek vebijarkî ya daneya deyn `RefMut`-ya nû çêdike.
    /// Ger dorpêç `None` vegere cerdevanê orjînal wekî `Err(..)` vedigere.
    ///
    /// `RefCell` jixwe bi muttefîk tê deyn kirin, ji ber vê yekê ev nikare têk biçe.
    ///
    /// Ev fonksiyonek têkildar e ku pêdivî ye ku wekî `RefMut::filter_map(...)` were bikar anîn.
    /// Rêbazek dê rêbazên bi heman navî li naveroka `RefCell` ya ku bi `Deref` ve tê bikar anîn têkeve.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): rast-kontrolkirina deyn
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // SAFETY: fonksiyon ji bo domdariya xwe referansek taybetî digire
        // banga wê bi navgîniya `orig`, û nîşanker tenê di hundurê banga fonksiyonê de-referans tête kirin ku qet nahêle ku referansa taybetî bireve.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // EWLEH: : wek jorîn.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Ji bo pêkhateyên cihêreng ên daneyên deynkirî `RefMut` di gelek `RefMut` ê de dabeş dike.
    ///
    /// `RefCell` ya bingehîn wê heya ku her du jî venegeriyan `RefMut` ji çarçovê de bi mutabetî deyn bimîne.
    ///
    /// `RefCell` jixwe bi muttefîk tê deyn kirin, ji ber vê yekê ev nikare têk biçe.
    ///
    /// Ev fonksiyonek têkildar e ku pêdivî ye ku wekî `RefMut::map_split(...)` were bikar anîn.
    /// Rêbazek dê rêbazên bi heman navî li naveroka `RefCell` ya ku bi `Deref` ve tê bikar anîn têkeve.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Di daneya bingehîn de veguherînin referansa guhêrbar.
    ///
    /// `RefCell` ya bingehîn ji nû ve nayê deyn kirin û dê her dem ji berê de bi muttefîkî deynkirî xuya bike, û referansa vegerandin dike tenê ya hundurîn.
    ///
    ///
    /// Ev fonksiyonek têkildar e ku pêdivî ye ku wekî `RefMut::leak(...)` were bikar anîn.
    /// Rêbazek dê rêbazên bi heman navî li naveroka `RefCell` ya ku bi `Deref` ve tê bikar anîn têkeve.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Em vê BorrowRefMut ji bîr dikin em piştrast dikin ku jimareya deynê di RefCell de di jiyana `'b` de nikare vegere UNUSED.
        // Ji nû ve sazkirina dewleta şopandina referansê hewce dike ku referansek yekta ya RefCell-a deynkirî hebe.
        // Di hundurê wê jiyanê de ji hucreya orîjînal bêtir referans çênabin, û deynê heyî ji bo jiyana mayî re dibe referansa tenê.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Berevajî BorrowRefMut::clone, ji nû re tê gotin ku destpêk çêbike
        // referansa guhêrbar, û ji ber vê yekê divê niha referansên heyî tune bin.
        // Ji ber vê yekê, dema ku klon rêjeya jimartina guhêrbar zêde dike, li vir em bi zelalî tenê destûrê didin ku ji UNUSED ber bi UNUSED ve biçin, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // `BorrowRefMut` klon dike.
    //
    // Ev tenê derbasdar e heke her `BorrowRefMut` were bikar anîn ku ji bo şopandina referansa guhêrbar a cihêreng, nevemirandina tiştê orîjînal.
    //
    // Ev ne di têgînek Klone de ye da ku kod viya bi nepenî bang neke.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Asteng bikin ku jimartinerê deynê binî.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Cûreyek pêçayî ji bo nirxek mutabîlî ya ji `RefCell<T>` deyn.
///
/// Ji bo bêtir [module-level documentation](self) bibînin.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Ya bingehîn primitive ji bo guherîna hundurîn li Rust.
///
/// Ger `&T` referansek we hebe, wê hingê bi gelemperî di Rust de berhevkar li gorî zanîna ku `&T` nîşana daneyên neguhêrbar dike, optimizasyonan pêk tîne.Guhertina wê daneyê, mînakî bi navgîniyek an bi veguheztina `&T` nav `&mut T`, tevgerek nediyarkirî tête hesibandin.
/// `UnsafeCell<T>` vebijarkên ji garantîya neguhêrbar a ji bo `&T`: referansek hevpar a `&UnsafeCell<T>` dikare daneyên ku têne guhertin nîşan bide.Ji vê re "interior mutability" tê gotin.
///
/// Hemî celebên din ên ku guhartina navxweyî dihêlin, wekî `Cell<T>` û `RefCell<T>`, navxweyî `UnsafeCell` bikar tînin da ku daneyên xwe pêça.
///
/// Zanibe ku tenê mîsogeriya neguhêrbar a ji bo çavkaniyên hevpar ji hêla `UnsafeCell` ve bandor dibe.Garantiya bêhempa ya ji bo referansên guherbar bê bandor e.Riya hiqûqî * tune ku meriv `&mut` bi aliasing peyda bike, ne bi `UnsafeCell<T>` jî.
///
/// `UnsafeCell` API bi xwe ji hêla teknîkî ve pir hêsan e: [`.get()`] nîşana xav a `*mut T` dide we naveroka wê.Heya ku _you_ wekî sêwiranerê abstraksiyonê ye ku wê pêşnûmeya rawe rast bikar tîne.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Rêzikên rastîn ên rastîn ên Rust hinekî diherikin, lê xalên sereke ne gengeşe ne:
///
/// - Ger hûn bi jiyanek `'a` re referansek ewledar biafirînin (an `&T` an `&mut T` referansek) ku ji hêla koda ewledar ve tête peyda kirin (mînakî, ji ber ku we ew vegerand), wê hingê divê hûn bi rengek ku ew bi referansa mayî re berevajî dibe bigihîjin daneyê. ya `'a`.
/// Mînakî, ev tê vê wateyê ku heke hûn `*mut T` ji `UnsafeCell<T>` bigirin û bavêjin `&T`, wê hingê divê daneyên di `T` de neguhêrbar bimînin (bêguman daneyên `UnsafeCell` yên di nav `T` de hatine dîtin, bê guman) heya ku temenê wê referansê xilas bibe.
/// Bi heman rengî, heke hûn referansek `&mut T` biafirînin ku ji bo koda ewledar tê weşandin, wê hingê divê hûn heya ku referans xilas nabe xwe bigihînin daneyên nav `UnsafeCell`.
///
/// - Di her demê de, divê hûn ji pêşbaziyên danûstendinê dûr bikevin.Heke pir têl gihîştine heman `UnsafeCell`-ê, wê hingê divê her nivîsîn bi têkiliyek guncan-pêşîn a bi hemî gihînên din re hebe (an jî atomî bikar bînin).
///
/// Ji bo arîkariya sêwirana guncan, senaryoyên jêrîn bi eşkere ji bo koda yek-têl qanûnî têne ragihandin:
///
/// 1. Çavkaniyek `&T` dikare ji bo koda ewlehiyê were serbestberdan û li wir ew dikare bi referansên din ên `&T` re jîndar be, lê ne bi `&mut T`
///
/// 2. Dibe ku referansek `&mut T` ji koda ewle re were weşandin bi şertê ku ne `&mut T` din ne jî `&T` bi hev re nebin.Divê `&mut T` her dem yekta be.
///
/// Bala xwe bidinê ku dema ku naveroka `&UnsafeCell<T>` mutasyon e (tevî ku referansên din ên `&UnsafeCell<T>` bi nasnav hucre ne) baş e (bi şertê ku hûn navên jorîn bi rengek din bicîh bikin), ew hîn tevgerek ne diyar e ku bi gelek navên `&mut UnsafeCell<T>` hebin.
/// Ango, `UnsafeCell` pêçek hatiye sêwirandin ku bi _shared_ accesses (_i.e._ re, bi navgîniya `&UnsafeCell<_>` re têkiliyek taybetî hebe);çaxê ku meriv bi _exclusive_ accesses (_e.g._ re, bi navgîniya `&mut UnsafeCell<_>` ve mijûl dibe, çu efsûnek tune ye: ne hucre û ne jî nirxa pêçayî ji bo domandina wê deynê `&mut` nabe aliyek.
///
/// Ev ji hêla gihîştina [`.get_mut()`] ve tê pêşandan, ku ew _safe_ getter ye ku `&mut T` dide.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Li vir mînakek nîşan dide ka meriv çawa naveroka `UnsafeCell<_>`-ê bi dengekî mutate dike tevî ku gelek çavkanî hene ku ji xaneyê dûr in:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Çavkaniyên pirjimar/parvekirî ji heman `x` re bigirin.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // EWLEH: : di nav vê çarçovê de ji bo naveroka `x` çu çavkanî tune,
///     // ji ber vê yekê ya me bi bandor bêhempa ye.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- deyn-+
///     *p1_exclusive += 27; // |
/// } // <---------- nikare ji vê xalê derbas bibe -------------------+
///
/// unsafe {
///     // EWLEH: : di vê çarçovê de kes çaverê nake ku bi taybetî bigihîje naverokên `x`,
///     // ji ber vê yekê em dikarin bi hev re gelek gihîştinên hevpar parve bikin.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Mînaka jêrîn vê rastiyê destnîşan dike ku gihîştina bi tenê ya `UnsafeCell<T>` tê wateya gihîştina bi tenê ya `T` ya wê:
///
/// ```rust
/// #![forbid(unsafe_code)] // bi gihîştinên taybetî,
///                         // `UnsafeCell` pêça no-op a zelal e, lewma li vir hewceyî `unsafe` nine.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Ji `x` re referansek bêhempa ya berhevkar-dema-kontrolkirî bistînin.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Bi referansek taybetî, em dikarin naverokê belaş mutate bikin.
/// *p_unique.get_mut() = 0;
/// // An, wekhev:
/// x = UnsafeCell::new(0);
///
/// // Dema ku em xwediyê nirxê bin, em dikarin naverokan belaş derxînin.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Mînakek nû ya `UnsafeCell` ava dike ku dê nirxa diyarkirî pêça.
    ///
    ///
    /// Hemî gihîştina nirxa hundirîn bi rêbazan `unsafe` e.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Nirxê vedigire.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Nîşanek guhêrbar digihîne nirxa pêçayî.
    ///
    /// Ev dikare ji her cûreyê re li nîşangirekê were avêtin.
    /// Dema ku `&mut T` tê avêtin, piştrast bikin ku gihiştin yekta ye (referansên çalak tune, guhêrbar an na), û piştrast bikin ku dema ku avêtin `&T` ti mutasyon an navnîşên guhêrbar tune.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Em tenê dikarin ji ber #[repr(transparent)] nîşangirê ji `UnsafeCell<T>` bavêjin `T`.
        // Ev statuya taybetî ya libstd bikar tîne, ji bo koda bikarhêner çu garantî tune ku ev ê di guhertoyên future ya berhevkar de bixebite!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Li ser daneyên bingehîn referansa guhêrbar vedigerîne.
    ///
    /// Ev bang `UnsafeCell` bihevguheztî (di dema berhevkirinê de) deyndarê me dike ku garantî dike ku em xwediyê tenê referansê ne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Nîşanek guhêrbar digihîne nirxa pêçayî.
    /// Cûdahiya [`get`] ev e ku ev fonksiyon pêşnumayek raweyê qebûl dike, ku bikêr e ku ji afirandina afirandina referansên demkî dûr bikeve.
    ///
    /// Encam dikare ji her cûreyê re li nîşangirekê were avêtin.
    /// Dema ku `&mut T` tê avêtin, piştrast bikin ku gihiştin yekta ye (referansên çalak tune, guhêrbar an na), û piştrast bikin ku dema ku avêtin `&T` ti mutasyon an navnîşên guhêrbar tune.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Destpêkirina gav bi gav a `UnsafeCell` `raw_get` hewce dike, ji ber ku bangkirina `get` dê hewce bike ku referansek daneyên uninitialized biafirîne:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Em tenê dikarin ji ber #[repr(transparent)] nîşangirê ji `UnsafeCell<T>` bavêjin `T`.
        // Ev statuya taybetî ya libstd bikar tîne, ji bo koda bikarhêner çu garantî tune ku ev ê di guhertoyên future ya berhevkar de bixebite!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// `UnsafeCell`, bi nirxa `Default` ji bo T. diafirîne.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}