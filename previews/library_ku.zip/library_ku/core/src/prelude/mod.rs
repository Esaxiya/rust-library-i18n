//! Libcore prelude
//!
//! Vê modulê ji bo bikarhênerên libcore-yê ku bi libstd-ê re jî nayên girêdan e.
//! Dema ku `#![no_std]` bi heman rengî wekî prelude-ya pirtûkxaneya standard tê bikar anîn ev modul ji hêla default ve tête tête kirin.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Guhertoya 2015-a prelude-ya bingehîn.
///
/// Ji bo bêtir [module-level documentation](self) bibînin.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Guhertoya 2018 ya bingehîn prelude.
///
/// Ji bo bêtir [module-level documentation](self) bibînin.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Guhertoya 2021 ya bingehîn prelude.
///
/// Ji bo bêtir [module-level documentation](self) bibînin.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Tiştên din zêde bikin.
}