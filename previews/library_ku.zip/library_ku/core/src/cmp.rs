//! Karmendî ji bo rêzkirin û berawirdkirinê.
//!
//! Di vê modulê de ji bo rêzkirin û berawirdkirina nirxan amûrên cûrbecûr hene.Bi kurtahî:
//!
//! * [`Eq`] û [`PartialEq`] traits ne ku dihêlin hûn bi rêzdarî, di navbera nirxan de wekheviya tevahî û qismî diyar bikin.
//! Pêkanîna wan operatorên `==` û `!=` zêde bar dike.
//! * [`Ord`] û [`PartialOrd`] traits ne ku dihêlin hûn rêzikên tevahî û qismî di navbera nirxan de, bi rêzê diyar bikin.
//!
//! Pêkanîna wan operatorên `<`, `<=`, `>`, û `>=` zêde bar dike.
//! * [`Ordering`] enumek e ku ji hêla fonksiyonên sereke yên [`Ord`] û [`PartialOrd`] ve vegeriyaye, û verastkirinek diyar dike.
//! * [`Reverse`] strukturek e ku dihêle hûn bi hêsanî rêzikek berevajî bikin.
//! * [`max`] û [`min`] fonksiyonên ku ji [`Ord`] ava dibin in û dihêlin hûn du nirxên herî zêde an kêmtirîn bibînin.
//!
//! Ji bo bêtir agahdariyê, belgeyên pêwendîdar ên her tiştê navnîşê bibînin.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait ji bo danberhevên wekheviyê yên ku [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation) in.
///
/// Ev trait destûrê dide wekheviya qismî, ji bo cûreyên ku têkiliya wan a wekheviya tevahî tune.
/// Mînakî, di hejmaran xala gerok `NaN != NaN` de, ji ber vê yekê celebên xalê gerok `PartialEq` bicîh dikin lê [`trait@Eq`] na.
///
/// Bi fermî, wekhevî divê (ji bo hemî `a`, `b`, `c` ji celeb `A`, `B`, `C`):
///
/// - **Simetrîk**: heke `A: PartialEq<B>` û `B: PartialEq<A>`, wê hingê **`a==b` tê wateya`b==a`**;û
///
/// - **Veguhêz**: heke `A: PartialEq<B>` û `B: PartialEq<C>` û `A:
///   PartialEq<C>`, hingê **` a==b`û `b == c` tê wateya`a==c`**.
///
/// Têbînî ku imployên `B: PartialEq<A>` (symmetric) û `A: PartialEq<C>` (transitive) ne mecbûr in ku hebin, lê ev hewceyên ku her ku hebe derbas dibin.
///
/// ## Derivable
///
/// Ev trait dikare bi `#[derive]` re were bikar anîn.Dema ku `li stendan` derdikeve`, du nimûneyên wekhev heke hemî zevî wekhev bin, û ne ku heke zeviyek ne wekhev bin ne yeksan in.Gava ku`li ser enumeyan digihîje`, her variant bi xwe re yeksan e û ne bi guherbarên din re ye.
///
/// ## Ez çawa dikarim `PartialEq` bicîh bikim?
///
/// `PartialEq` tenê pêdivî ye ku rêbaza [`eq`] were cîbicîkirin;[`ne`] bi mercê wê ve tête destnîşankirin.Her pêkanîna desta ya [`ne`]*divê* rêzê lê bigire ku [`eq`] berevajiyek hişk a [`ne`] e;ango, `!(a == b)` heke û tenê heke `a != b`.
///
/// Pêkanînên `PartialEq`, [`PartialOrd`], û [`Ord`]*divê* bi hev re li hev bikin.Hêsan e ku meriv bi xeletî hin traits derxîne û yên din jî bi destan bicîh bîne, bi neheqî li hev neke.
///
/// Ji bo navgînek ku du pirtûk wekî ISBN-ê hev digirin, tevî ku teşeyan ji hev cûda bin jî, ji bo navnîşek ku du pirtûk wekî yek pirtûk têne hesibandin pêkanînek mînakî:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Ez çawa dikarim du cûreyên cûda bidim ber hev?
///
/// Tîpa ku hûn dikarin pê re berawird bikin ji hêla parametreya type `PartialEq` ve tê kontrol kirin.
/// Mînakî, ka em koda xweya berê hinekî tevbigerin:
///
/// ```
/// // Derve pêk tîne<BookFormat>==<BookFormat>berawirdkirin
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Bicîanîn<Book>==<BookFormat>berawirdkirin
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Bicîanîn<BookFormat>==<Book>berawirdkirin
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// Bi guhertina `impl PartialEq for Book` bo `impl PartialEq<BookFormat> for Book`, em dihêlin ku `BookFormat` bi`Pirtûk` were berawird kirin.
///
/// Beramberîyek mîna ya li jor, ku hin warên strukturel paşguh dike, dikare xeternak be.Ew dikare bi hêsanî bibe sedema binpêkirinek nexwestî ya daxwazên ji bo têkiliyek wekheviya qismî.
/// Mînakî, heke me pêkanîna jorîn a `PartialEq<Book>` ji bo `BookFormat` biparêze û pêkanînek `PartialEq<Book>` ji bo `Book` (yan bi rêya `#[derive]` an jî bi rêka bicîhkirina desta ji mînaka yekem) lê zêde bikira, wê encam dê veguhêziyê binpê bike:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Vê rêbazê ji bo nirxên `self` û `other` wekhev ceribandin, û ji hêla `==` ve tê bikar anîn.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Vê rêbazê ji bo `!=` test dike.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// Makro hilberandin û hilberînek ji trait `PartialEq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait ji bo danberhevên wekheviyê yên ku [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation) in.
///
/// Ev tê vê wateyê, ku ji bilî `a == b` û `a != b` berevajiyên hişk in, divê wekhevî hebe (ji bo hemî `a`, `b` û `c`):
///
/// - reflexive: `a == a`;
/// - simetrîk: `a == b` tê wateya `b == a`;û
/// - gerguhêz: `a == b` û `b == c` tê wateya `a == c`.
///
/// Ev taybetmendî ji hêla berhevkar ve nayê kontrol kirin, û ji ber vê yekê `Eq` tê wateya [`PartialEq`], û rêbazên wê yên zêde tune.
///
/// ## Derivable
///
/// Ev trait dikare bi `#[derive]` re were bikar anîn.
/// Dema ku `derkirin`d, ji ber ku `Eq` rêbazên wê yên zêde tune, ew tenê ji berhevkar re agahdar dike ku ev ji têkiliya wekheviya qismî têkiliyek wekheviyê ye.
///
/// Têbînî ku stratejiya `derive` hewce dike ku hemî qadên `Eq` ne, ku her dem nayê xwestin.
///
/// ## Ez çawa dikarim `Eq` bicîh bikim?
///
/// Heke hûn nekarin stratejiya `derive` bikar bînin, diyar bikin ku celebê we `Eq` bicîh dike, ku rêbaz tune.
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // ev rêbaza hanê tenê ji hêla#[derkirin] ve tête bikar anîn da ku bêje ku her pêkhateyek ji celebek#[jêgirtin] xwe bicîh tîne, binesaziya jêder a heyî tê vê wateyê ku bêyî ku rêbazek li ser vê trait bikar neyne vê îdîayê dike hema hema ne gengaz e.
    //
    //
    // Pêwîst e ev ti carî bi destan neyê pêkanîn.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Makro hilberandin û hilberînek ji trait `Eq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: ev struktûr tenê ji hêla#[jêder] tê bikar anîn
// destnîşan bikin ku her pêkhateyek ji celebek Eq bicîh tîne.
//
// Pêwîst e ev struktura di kodê bikarhêner de qet xuya nebe.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Ordering` encama berhevdana di navbera du nirxan de ye.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// Rêzikek ku nirxek berawirdkirî ji yekê din kêmtir e.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// Rêzikek ku nirxek berawirdkirî bi yekê din re wekhev e.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// Rêzikek ku nirxek berawirdkirî ji ya din mezintir e.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Ger verastkirina guhertoya `Equal` e `true` vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Ger verastkirina guhertoya `Equal` ne be `true` vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Ger verastkirina guhertoya `Less` e `true` vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Ger verastkirina guhertoya `Greater` e `true` vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Ger verastkirina an guhertoya `Less` an `Equal` be `true` vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Ger verastkirina an guhertoya `Greater` an `Equal` be `true` vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// `Ordering` berevajî dike.
    ///
    /// * `Less` dibe `Greater`.
    /// * `Greater` dibe `Less`.
    /// * `Equal` dibe `Equal`.
    ///
    /// # Examples
    ///
    /// Reftara bingehîn:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Ev rêbaz dikare were bikar anîn ku ji berhevdanek berevajî bike:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // rêzê ji ya herî mezin heya ya herî biçûk rêz bikin.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Du rêzan zincîr dike.
    ///
    /// Dema ku ne `Equal` be vedigere `self`.Wekî din `other` vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Zencîran bi fonksiyona dayîn re rêzkirin.
    ///
    /// Dema ku ne `Equal` be vedigere `self`.
    /// Wekî din gazî `f` dike û encam vedigire.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// Struktorek arîkar ji bo rêzkirina berevajî.
///
/// Ev struktorek alîkariyek e ku bi fonksiyonên mîna [`Vec::sort_by_key`] tê bikar anîn û dikare were bikar anîn ku rêzek perçeyek mifteyê berevajî bike.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait ji bo celebên ku [total order](https://en.wikipedia.org/wiki/Total_order) ava dikin.
///
/// Biryarek heke ew fermanek tevahî ye (ji bo hemî `a`, `b` û `c`):
///
/// - tevde û asîmetrîkî: tam yek ji `a < b`, `a == b` an `a > b` rast e;û
/// - gerguhêz, `a < b` û `b < c` `a < c` îfade dike.Divê heman tişt ji bo `==` û `>` jî hebe.
///
/// ## Derivable
///
/// Ev trait dikare bi `#[derive]` re were bikar anîn.
/// Dema ku `stendin` d, ew ê rêziknameya [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) li ser bingeha rêzika danezanê ya ji jor-ber-jêrîn ve ji endamên damezrandinê re hilberîne.
///
/// Gava ku `li ser enuman digirin`, variant bi rêzika cûdakar a wan ji jor ve têne rêz kirin.
///
/// ## Berawirdkirina leksîkografî
///
/// Berawirdekirina leksiyografîk operasyonek bi taybetmendiyên jêrîn e:
///  - Du rêz li hêman bi hêman têne berhevdan.
///  - Yekem hêmana nelirêtiyê diyar dike ka kîjan rêzê bi leksîkografî ji ya din kêmtir an mezintir e.
///  - Ger yek rêzek pêşpirtikek ya yekê be, rêzeya kurtir bi ferhengsaziyê ji ya din kêmtir e.
///  - Heke du rêzikên xwedan hêmanên hevwate ne û bi heman dirêjahiyê ne, wê hingê rêzikên bi ferhengsaziyê wekhev in.
///  - Rêzekek vala bi ferhengnasî ji her rêza ne-vala kêmtir e.
///  - Du rêzikên vala bi ferhengsaziyê wekhev in.
///
/// ## Ez çawa dikarim `Ord` bicîh bikim?
///
/// `Ord` hewce dike ku celeb jî [`PartialOrd`] û [`Eq`] be (ku [`PartialEq`] hewce dike).
///
/// Wê hingê divê hûn ji bo [`cmp`] pêkanînek diyar bikin.Hûn dikarin fêr bibin ku hûn [`cmp`] li ser zeviyên celebê xwe bikar bînin.
///
/// Pêkanînên [`PartialEq`], [`PartialOrd`], û `Ord`*divê* bi hev re li hev bikin.
/// Ango, `a.cmp(b) == Ordering::Equal` heke û tenê heke ji bo hemî `a` û `b` `a == b` û `Some(a.cmp(b)) == a.partial_cmp(b)` be.
/// Hêsan e ku meriv bi xeletî hin traits derxîne û yên din jî bi destan bicîh bîne, bi neheqî li hev neke.
///
/// Li vir mînakek heye ku hûn dixwazin mirovan tenê li gorî dirêjbûnê, ji `id` û `name` paşguh bikin, rêz bikin:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Ev rêbaz di navbera `self` û `other` de [`Ordering`] vedigire.
    ///
    /// Bi peymanê, `self.cmp(&other)` heke rast be rêzkirina vederkirina `self <operator> other` li hev tîne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Herî zêde du nirxan dide ber hev û vedigerîne.
    ///
    /// Heke berhevdana wan wekhev diyar bike argumana duyemîn vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Kêmtirîn du nirxan dide ber hev û vedigerîne.
    ///
    /// Heke berhevdana wan wekhev diyar bike argumana yekem vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Nirxek bi navberek diyar ve bisînor bikin.
    ///
    /// Ger `self` ji `max` mezintir be, `max` jî vedigire, heke `self` ji `min` kêmtir e `min`.
    /// Wekî din ev vedigere `self`.
    ///
    /// # Panics
    ///
    /// Panics heke `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// Makro hilberandin û hilberînek ji trait `Ord`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait ji bo nirxên ku dikarin ji bo rêzikek rêzê bêne berawird kirin.
///
/// Divê berhevdan, ji bo hemî `a`, `b` û `c` têr bike:
///
/// - asîmetrî: heke `a < b` hingê `!(a > b)`, û hem jî `a > b` `!(a < b)` îfade dike;û
/// - guhêrbar: `a < b` û `b < c` `a < c` îfade dike.Divê heman tişt ji bo `==` û `>` jî hebe.
///
/// Bala xwe bidinê ku ev hewcedarî tê vê wateyê ku trait bixwe divê bi rengekî simetrîkî û gerguhêz were pêkanîn: heke `T: PartialOrd<U>` û `U: PartialOrd<V>` wê hingê `U: PartialOrd<T>` û `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// Ev trait dikare bi `#[derive]` re were bikar anîn.Gava ku `li stenokan` derdikeve`, ew ê rêziknameyek leksîkografî ya li ser bingeha rêzika danezanê ya ji jor-ber-jêr a endamên strukturel hilberîne.
/// Gava ku `li ser enuman digirin`, variant bi rêzika cûdakar a wan ji jor ve têne rêz kirin.
///
/// ## Ez çawa dikarim `PartialOrd` bicîh bikim?
///
/// `PartialOrd` tenê pêkanîna rêbaza [`partial_cmp`] hewce dike, bi yên din re ji pêkanînên pêşkeftî hatine afirandin.
///
/// Lêbelê ew gengaz dimîne ku yên din ji hev cûre ji bo cûreyên ku nîzamek tevahî tune bicîh bînin.
/// Mînakî, ji bo hejmarên xala gemarî, `NaN < 0 == false` û `NaN >= 0 == false` (cf.
/// IEEE 754-2008 beşa 5.11).
///
/// `PartialOrd` hewce dike ku tîpa we [`PartialEq`] be.
///
/// Pêkanînên [`PartialEq`], `PartialOrd`, û [`Ord`]*divê* bi hev re li hev bikin.
/// Hêsan e ku meriv bi xeletî hin traits derxîne û yên din jî bi destan bicîh bîne, bi neheqî li hev neke.
///
/// Ger celebê we [`Ord`] be, hûn dikarin bi karanîna [`cmp`] [`partial_cmp`] bicîh bikin:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// Di heman demê de dibe ku hûn fêr bibin ku hûn li ser zeviyên celebê xwe [`partial_cmp`] bikar bînin.
/// Li vir nimûneyek ji celebên `Person` ku qada `height` ya xalgir heye ku qada yekane ye ku ji bo rêzkirinê tê bikar anîn ev e:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Ger yek heb hebe ev rêbaz rêziknameyek di navbera nirxên `self` û `other` de vedigire.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Dema ku berhevdan ne gengaz e:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Vê rêbazê ji (ji bo `self` û `other`) kêmtir test dike û ji hêla kargêr `<` ve tê bikar anîn.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Vê rêbazê ji (ji bo `self` û `other`) kêmtir an wekhev test dike û ji hêla kargêr `<=` ve tê bikar anîn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Vê rêbazê ji (ji bo `self` û `other`) mezintir test dike û ji hêla kargêr `>` ve tê bikar anîn.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Vê rêbazê ji (ji bo `self` û `other`) mezintir an wekhev ceribandin û ji hêla kargêr `>=` ve tê bikar anîn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// Makro hilberandin û hilberînek ji trait `PartialOrd`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Kêmtirîn du nirxan dide ber hev û vedigerîne.
///
/// Heke berhevdana wan wekhev diyar bike argumana yekem vedigerîne.
///
/// Navxweyî bi navek din [`Ord::min`] bikar tîne.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Li gorî fonksiyona berawirdkirina diyarkirî herî kêm du nirxan vedigerîne.
///
/// Heke berhevdana wan wekhev diyar bike argumana yekem vedigerîne.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Hêmana ku ji fonksiyona diyarkirî nirxa herî kêm dide, vedigerîne.
///
/// Heke berhevdana wan wekhev diyar bike argumana yekem vedigerîne.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Herî zêde du nirxan dide ber hev û vedigerîne.
///
/// Heke berhevdana wan wekhev diyar bike argumana duyemîn vedigerîne.
///
/// Navxweyî bi navek din [`Ord::max`] bikar tîne.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Li gorî fonksiyona berhevdana diyarkirî herî zêde du nirxan vedigerîne.
///
/// Heke berhevdana wan wekhev diyar bike argumana duyemîn vedigerîne.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Hêmana ku ji fonksiyona diyarkirî nirxa herî zêde dide vedigerîne.
///
/// Heke berhevdana wan wekhev diyar bike argumana duyemîn vedigerîne.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// Pêkanîna PartialEq, Eq, PartialOrd û Ord ji bo celebên primitive
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // Emrê li vir girîng e ku ji bo civînek çêtirîn çêbibe.
                    // Ji bo bêtir agahdariyê li <https://github.com/rust-lang/rust/issues/63758> binihêrin.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // Castandina li i8 û veguheztina cûdahiya li Rêziknameyê kombûnek çêtir çêdike.
            //
            // Ji bo bêtir agahdariyê li <https://github.com/rust-lang/rust/issues/66780> binihêrin.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // EWLEH: bool wekî i8 0 an 1 vedigerîne, ji ber vê yekê cûdahî nikare tiştek din be
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &nîşanekan

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}