//! Di pirtûkxaneya standard de piştgiriya Panic.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// Damezrandinek agahdariya der barê panic de peyda dike.
///
/// `PanicInfo` avahî derbasê panic hook-ê ku ji hêla fonksiyona [`set_hook`] ve hatî saz kirin dibe.
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// Mîhenga ku bi panic ve girêdayî ye vedigerîne.
    ///
    /// Ev dê bi gelemperî, lê ne her dem, `&'static str` an [`String`] be.
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// Ger makroya `panic!` ji `core` crate (ne ji `std`) be bi têl formatkirinê û hin argumanên din ve hate bikar anîn, wê peyamê amade amade dike ku ji bo nimûne bi [`fmt::write`] were bikar anîn
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// Ger agahdarî hebe, li ser cîhê ku panic jê derketiye vedigerîne.
    ///
    /// Vê rêbazê niha dê her dem [`Some`] vegerîne, lê dibe ku ev di guhertoyên future de biguhere.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: Ger ev were guhertin ku carinan venegere Ne,
        // di std::panicking::default_hook û std::panicking::begin_panic_fmt de bi wê dozê re mijûl bibin.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: em nikarin downcast_ref bikar bînin: :<String>() vir
        // ji ber ku Têl di libcore de tune ye!
        // Dema ku `std::panic!` bi gelek argumanan tê vexwendin payload rêzeyek e, lê di wê rewşê de peyam jî heye.
        //

        self.location.fmt(formatter)
    }
}

/// Damezrandinek ku di derheqê cîhê panic de agahdarî vedigire.
///
/// Ev avahî ji hêla [`PanicInfo::location()`] ve tê afirandin.
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// Beramberî ji bo wekhevî û rêzkirinê di pel, rêz, paşê pêşanîya stûnê de têne çêkirin.
/// Pelên wekî têl têne berhevdan, ne `Path`, ku dikare bêhêvî be.
/// Ji bo bêtir gotûbêjan li belgeya ["Cih: : Pel"] binihêrin.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// Cihê çavkaniya bangkerê vê fonksiyonê vedigire.
    /// Ger bangdêrê wê fonksiyonê were şîrove kirin wê hingê dê cihê banga wê were vegerandin, û wusa jî li ser pêlika banga yekem di nav laşek fonksiyonek ne-şopandî de.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// [`Location`] ya ku jê re tê gotin vedigerîne.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// Ji nav pênaseya vê fonksiyonê [`Location`] vedigerîne.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // meşandina heman fonksiyona ne şopandî li cîhek cuda heman encamê dide me
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // xebitandina şopandin li cîhek cûda meşandin nirxek cûda hilberîne
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// Navê pelê çavkaniya ku panic jê ve hatî vedigerîne vedigerîne.
    ///
    /// # `&str`, ne `&Path`
    ///
    /// Navê vegerandî li ser pergala berhevkar rêgezek çavkaniyê vedibêje, lê ne rast e ku meriv vê yekê rasterast wekî `&Path` temsîl bike.
    /// Koda berhevkirî dibe ku ji pergala ku naverokê peyda dike li ser pergalek cûda bi pêkanîna `Path` cuda re bimeşîne û vê pirtûkxaneyê niha xwediyê celebek cûda "host path" nîne.
    ///
    /// Tevgerîna herî sosret dema ku pelê "the same" di pergala modulê de bi gelek rêyan ve tête peyda dibe (bi gelemperî taybetmendiya `#[path = "..."]` an mîna wê bikar tîne), ku dikare bibe sedema ku kodê yeksan xuya dike ku nirxên cihêreng ji vê fonksiyonê vegerîne.
    ///
    ///
    /// # Cross-compilation
    ///
    /// Dema ku platforma mêvandar û platforma armanc ji hev cûda dibin ev nirx ji bo derbasbûna `Path::new` an çêkerên mîna wê ne guncan e.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// Hejmara rêzika ku panic jê derketiye vedigerîne.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// Stûna ku panic jê derketiye vedigerîne.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// trait ya navxweyî ku ji hêla libstd ve tête bikar anîn da ku daneyên ji libstd derbasî `panic_unwind` û demên din ên panic bike.
/// Armanc ne ew e ku zû zû were aram kirin, bikar neynin.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// Xwedî naverok tevahî bibin.
    /// Tîpa vegerîn bi rastî `Box<dyn Any + Send>` e, lê em nekarin `Box` di libcore de bikar bînin.
    ///
    /// Piştî ku vê rêbazê bang kir, tenê hin nirxa default dummy di `self` de maye.
    /// Bangkirina vê rêbazê du caran, an gazî kirina `get` piştî bangkirina vê rêbazê, xeletiyek e.
    ///
    /// Nîqaş deyndar e ji ber ku panic dema xebitandinê (`__rust_start_panic`) tenê `dyn BoxMeUp` deyn distîne.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// Tenê naverokan deyn bikin.
    fn get(&mut self) -> &(dyn Any + Send);
}