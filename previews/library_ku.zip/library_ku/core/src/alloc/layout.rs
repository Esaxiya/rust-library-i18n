use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Dema ku ev fonksiyon li cîhek tê bikar anîn û pêkanîna wê dikare were rêz kirin, lê hewildanên berê yên wiya rustc hêdîtir dikir:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Rêzkirina blokek bîranînê.
///
/// Nimûneyek `Layout` rêziknameyek taybetî ya bîranînê vedibêje.
/// Hûn `Layout`-ê wekî pêvek ava dikin ku bidin dabeşker.
///
/// Hemî nexşeyan xwedan mezinahiyek têkildar û rêgezek du-hêz in.
///
/// (Bala xwe bidinê ku dirûtin * ne hewce ne ku xwediyê mezinahiya ne-sifir bin, her çend `GlobalAlloc` hewce dike ku hemî daxwazên bîranînê di mezinahiyê de ne-sifir bin.
/// Bangek divê an piştrast bike ku şert û mercên bi vî rengî pêk hatine, dabeşkerên taybetî yên bi daxwazên azadtir bikar bînin, an jî nermalava `Allocator`-a nermtir bikar bînin.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // mezinahiya bloka daxwazkirî ya bîranînê, bi byteyan tê pîvandin.
    size_: usize,

    // lihevnêzîkkirina bloka bîranînê ya daxwazkirî, bi byteyan tête pîvandin.
    // em piştrast dikin ku ev her gav hêz-ji-du ye, ji ber ku API-ya mîna `posix_memalign` jê re hewce dike û ew astengiyek maqûl e ku li ser avakerên Layout ferz bike.
    //
    //
    // (Lêbelê, em bi analogî `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.) hewce nakin
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// `Layout`-an ji `size` û `align`-a dayî ava dike, an heke yek ji mercên jêrîn pêk neyê `LayoutError` vedigerîne:
    ///
    /// * `align` divê ne sifir be,
    ///
    /// * `align` divê bibe hêzek du,
    ///
    /// * `size`, dema ku heya pirjimara herî nêz a `align` were dorpêç kirin, divê neherike (ango, nirxa dorpêçkirî divê ji `usize::MAX` kêmtir an jî wekhev be).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (hêza-duduyan align dike!=0.)

        // Mezinahiya dorpêçkirî ev e:
        //   size_rounded_up=(size + align, 1)&! (align, 1);
        //
        // Em ji jor ve dizanin ku align!=0.
        // Ger lêzêdekirin (align, 1) zêde nebe, wê hingê dorpêçkirin baş e.
        //
        // Berevajî vê,&-maskkirina bi! (Align, 1) dê tenê bit-ên nizm kêm bike.
        // Ji ber vê yekê heke zêdebûn bi mîqyasê re çêbibe,&-mask nikare têra xwe jêbike ku wê zêdebûnê betal bike.
        //
        //
        // Li jor tê vê wateyê ku venêrana ji bo zêdebûna berhevokê hem hewce û hem jî bes e.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // EWLEH: : mercên ji bo `from_size_align_unchecked` bûne
        // li jor hatî kontrol kirin.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Damezrandinek diafirîne, hemû kontrolan derbas dike.
    ///
    /// # Safety
    ///
    /// Ev fonksiyon ne ewle ye ji ber ku ew pêşmercên ji [`Layout::from_size_align`] piştrast nake.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // EWLEHIY: : divê bangker piştrast bike ku `align` ji sifirê mezintir e.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Mezinahiya herî kêm di byteyan de ji bo bloka bîranînê ya vê vehewandinê.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Ji bo bloka bîranînê ya vê çerxa rêzkirinê ya byte ya herî kêm.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// `Layout`-ê ji bo xwedîkirina nirxek ji celebê `T`-ê guncan çêdike.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // EWLEH: : align ji hêla Rust ve hatî garantîkirin ku bibe hêza du û
        // mezinahî + align combo garantî ye ku di navnîşana me de cîh bigire.
        // Wekî encamek çêkerê neçêkirî li vir bikar bînin da ku hûn têxin koda ku panics têra xwe baş neyê optim kirin.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Dabeşînek hilberandina salixdana tomarek ku dikare were bikar anîn da ku ji bo `T` (ku dibe trait an cûreyek din a nevekirî mîna perçeyek) were veqetandin.
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // EWLEH: : di `new` de aqil bibînin ka çima ev guhertoya ne ewle bikar tîne
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Dabeşînek hilberandina salixdana tomarek ku dikare were bikar anîn da ku ji bo `T` (ku dibe trait an cûreyek din a nevekirî mîna perçeyek) were veqetandin.
    ///
    /// # Safety
    ///
    /// Vê fonksiyonê tenê ewle ye ku meriv bang bike heke şertên jêrîn hebe:
    ///
    /// - Ger `T` `Sized` e, bangkirina vê fonksiyonê her gav ewle ye.
    /// - Ger dûvê bêserûber `T` e:
    ///     - [slice] be, wê hingê divê dirêjahiya dûvikê perçeyê jimareyek intialized be, û mezinahiya *tevahiya nirxê*(dirêjiya dûvikê dînamîk + pêşpirtika bi pîvana statîk) divê di `isize` de bicîh bibe.
    ///     - a [trait object], wê hingê beşa vtable ya nîşanker divê vtableyek derbasdar ji bo tîpa `T` ya ku bi hevrêziyek nevekêşandî hatî stendin nîşan bike, û divê mezinahiya *tevahiya nirxê*(dirêjahiya dûvê dînamîk + pêşpirtika bi pîvana statîk) di `isize` de cih bigire.
    ///
    ///     - an (unstable) [extern type], wê hingê ev fonksiyon her gav ewle ye ku meriv lê bigere, lê dibe ku panic an wekî din nirxek çewt vegerîne, ji ber ku teşeya celebê derveyî nayê zanîn.
    ///     Ev eynî tevgerî wekî [`Layout::for_value`] li ser referansek li dûvikek celebek derveyî ye.
    ///     - wekî din, bi kevneperestî nayê destûr kirin ku ji vê fonksiyonê re were gotin.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // EWLEH: em bi şertên pêşîn ên van fonksiyonan re derbasî bangker dibin
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // EWLEH: : di `new` de aqil bibînin ka çima ev guhertoya ne ewle bikar tîne
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `NonNull`-ya ku dangilî ye, lê ji bo vê Damezrandinê baş-rêzkirî diafirîne.
    ///
    /// Bala xwe bidinê ku dibe ku nirxa nîşangir potansiyelî pêşnumayek derbasdar temsîl bike, ku tê vê wateyê ku divê ev ne wekî nirxek sentîl a "not yet initialized" were bikar anîn.
    /// Cûreyên ku bi lalbûnek veqetandî ne, divê destpêkirina bi hin rêyên din bişopînin.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // EWLEH: : align garantî ye ku ne-sifir be
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Rêzikek danasîna tomarê diafirîne ku dikare nirxek ji heman xuyangê wekî `self` bigire, lê ew jî lihevnêzîk `align` (li byteyan tête pîvandin).
    ///
    ///
    /// Ger `self` jixwe rêzkirina destnîşankirî bicîh tîne, wê hingê `self` vedigere.
    ///
    /// Zanibe ku vê rêbazê ti pîvanek li mezinahiya giştî zêde nake, bêyî ku xuyangê vegerandî rêzek cûda hebe.
    /// Bi gotinên din, heke `K` mezinahiya 16 hebe, dê `K.align_to(32)`*hêj* xwediyê mezinahiya 16 be.
    ///
    /// Ger hevahengiya `self.size()` û `align` ya dayî mercên di [`Layout::from_size_align`] de hatine rêzkirin binpê dike xeletiyekê vedigire.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Mîqdara paddingê vedigerîne ku divê em piştî `self` têxin da ku piştrast bikin ku navnîşana jêrîn dê `align` têr bike (bi byteyan pîvandî).
    ///
    /// mînak, heke `self.size()` 9 be, wê hingê `self.padding_needed_for(4)` 3 vedigerîne, ji ber ku ew kêmtirîn hejmara baytên dagirtinê ye ku ji bo navnîşanek 4-rêzkirî hewce dike (bihesibînin ku bloka bîra ya têkildar di navnîşanek 4-rêzkirî de dest pê dike).
    ///
    ///
    /// Heke `align` ne hêza-du-ê be, nirxa vegera vê fonksiyonê tune.
    ///
    /// Zanibe ku kêrhatîbûna nirxa vegeriyayî hewce dike ku `align` ji rêzkirina navnîşana destpêkê ji bo tevahî bloka bîranînê ya veqetandî kêmtir an wekhev be.Yek awayek ku ji bo bicîhkirina vê astengiyê ev e ku `align <= self.align()` were misoger kirin.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Nirxa dorpêçkirî ev e:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // û paşê em cûdahiya paddingê vedigirin: `len_rounded_up - len`.
        //
        // Em li seranserê hejmarê modul bikar tînin:
        //
        // 1. align garantî ye ku bibe> 0, ji ber vê yekê align, 1 her dem derbasdar e.
        //
        // 2.
        // `len + align - 1` dikare herî zêde bi `align - 1` re biherike, ji ber vê yekê&-maska bi `!(align - 1)` re dê piştrast bike ku di rewşa zêdebûnê de, `len_rounded_up` bixwe 0 be.
        //
        //    Bi vî rengî padika ku vedigere, dema ku li `len` were zêdekirin, 0 dide, ku bi rengek bêhempa rêziknameya `align` têr dike.
        //
        // (Bê guman, hewildanên veqetandina blokên bîranînê yên ku mezinahî û padding wan bi awayê jorîn zêde dibin divê bibe sedem ku dabeşker çewtiyek derxîne.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Bi dorpêçkirina mezinahiya vê dîzaynê heya pirjimara lihevnêzîkirina dîzaynê rêzeyek diafirîne.
    ///
    ///
    /// Ev wekhev e ku encama `padding_needed_for` li mezinahiya dîzaynê lê zêde bike.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Ev nikare zêde bibe.Gotinên ji neguhêrêzê Layout:
        // > `size`, dema ku li dora pirjimara `align`-ê dorpêçkirî be,
        // > divê zêde neçe (ango, nirxa dorpêçkirî divê ji kêmtir be
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Dabeşek ji bo salixdana tomara `n` nimûneyên `self` diafirîne, bi mîqdarek guncan a padding di navbera her yekê de da ku bicîh bike ku ji her nimûneyê re mezinahî û rêzkirina xweya daxwazkirî tête dayîn.
    /// Li ser serfiraziyê, vedigere `(k, offs)` ku `k` nexşeya rêzikê ye û `offs` mesafe di navbera destpêka her hêmanê de rêzik e.
    ///
    /// Li ser zêdebûna arîtmetîkî, `LayoutError` vedigerîne.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Ev nikare zêde bibe.Gotinên ji neguhêrêzê Layout:
        // > `size`, dema ku li dora pirjimara `align`-ê dorpêçkirî be,
        // > divê zêde neçe (ango, nirxa dorpêçkirî divê ji kêmtir be
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // EWLEHIYA: self.align jixwe tê zanîn ku derbasdar e û distrib_size hatiye
        // padded berê.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Dabeşek diafirîne ku salixdana tomara `self` li pey `next` dişopîne, di nav de her tewra pêdivî jî heye da ku bicîh bikin ku `next` dê bi rêkûpêk were rastandin, lê *padîşahê paşîn* tune.
    ///
    /// Ji bo ku hûn bi dîmena nûnertiya C ya `repr(C)` re hev bigirin, divê hûn piştî ku rêzê bi hemî zeviyan re dirêj bikin, bangî `pad_to_align` bikin.
    /// (Çu rê tune ku meriv bi pêşnumaya pêşnumayê ya Rust ya `repr(Rust)`, as it is unspecified.) re hevber bike
    ///
    /// Bala xwe bidinê ku lihevnêzîkkirina dîzayna encamgirî dê herî zêde yên `self` û `next` be, da ku jihevrastkirina her du perçan misoger bibe.
    ///
    /// `Ok((k, offset))` vedigerîne, ku `k` nexşeya tomara lihevhatî ye û `offset` cîhê têkildar e, di byte de, ji destpêka `next` ya di hundurê tomara hevgirtî de bicîhkirî ye (bihesibînin ku tomar bixwe ji beşa 0 dest pê dike).
    ///
    ///
    /// Li ser zêdebûna arîtmetîkî, `LayoutError` vedigerîne.
    ///
    /// # Examples
    ///
    /// Ji bo verastkirina sazûmanek `#[repr(C)]` û paşmayên zeviyan ji pêşnumayên zeviyên wê hesab bikin:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Ji bîr mekin ku bi `pad_to_align` re biqedînin!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // test bike ku ew dixebite
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Dabeşek ji bo salixdana tomara `n` nimûneyên `self` diafirîne, di navbera her nimûneyê de bê paddank.
    ///
    /// Zanibe ku, berevajî `repeat`, `repeat_packed` garantî nake ku nimûneyên dubare yên `self` dê bi rêkûpêk werin rêz kirin, heke mînakek diyarkirî ya `self` bi rêkûpêk were rastandin.
    /// Bi gotinên din, heke rêziknameya ku ji hêla `repeat_packed` ve hatî vegerandin ji bo veqetandina rêzikekê tê bikar anîn, ew nayê garantîkirin ku hemî hêmanên array dê bi rêkûpêk werin rêz kirin.
    ///
    /// Li ser zêdebûna arîtmetîkî, `LayoutError` vedigerîne.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Dabeşek diafirîne ku salixdana tomara `self` li pey `next` dide û di navbera herduyan de bê pêvek tune.
    /// Ji ber ku çu pûçek nehatiye danîn, lihevnêzîkbûna `next` ne girîng e, û bi tevahî * li nav dîzaynê encamek nayê navandin.
    ///
    ///
    /// Li ser zêdebûna arîtmetîkî, `LayoutError` vedigerîne.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Dabeşek ji bo danasîna tomara `[T; n]` diafirîne.
    ///
    /// Li ser zêdebûna arîtmetîkî, `LayoutError` vedigerîne.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Parametreyên ku ji `Layout::from_size_align` an hin çêkerê dinê `Layout` re hatine dayîn astengên wê yên belgekirî têr nakin.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (ji me re ev pêdivî ye ji bo impl-ya jêr a Çewtiya trait)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}