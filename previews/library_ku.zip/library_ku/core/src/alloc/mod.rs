//! API-yên dabeşkirina bîranînê

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Çewtiya `AllocError` têkçûyînek dabeşkirinê nîşan dide ku dibe ku ji ber westandina çavkaniyê be an ji ber tiştek xelet be dema ku argumanên ketinê yên daneyî bi vê dabeşkerê re yek dike.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (ji me re ev pêdivî ye ji bo impl-ya jêr a Çewtiya trait)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Pêkanîna `Allocator` dikare blokên bêserûber ên daneyên ku bi [`Layout`][] hatine vegotin veqetîne, mezin bibe, biçîne, û veqetîne.
///
/// `Allocator` hatiye sêwirandin ku li ZSTs, referansan, an nîşangirên jîr bêne bicîh kirin ji ber ku xwedan veqetandek mîna `MyAlloc([u8; N])` nayê veguheztin, bêyî nûvekirina nîşangiran bi bîra veqetandî.
///
/// Berevajî [`GlobalAlloc`][], veqetandinên sifir-mezinahî di `Allocator` de têne destûr kirin.
/// Heke dabeşkerê bingehîn ev piştgirî nake (mîna jemalloc) an pêşnumayek null vedigerîne (mînakî `libc::malloc`), divê ev yek ji hêla pêkanînê ve were girtin.
///
/// ### Niha bîranîn veqetandî
///
/// Hin ji rêbazan hewce dike ku blokek bîranînê * niha bi rêya veqetandek were veqetandin.Ev tê vê wateyê ku:
///
/// * navnîşana destpêkê ji bo wê bloka bîranînê berê ji hêla [`allocate`], [`grow`], an [`shrink`] ve hatibû vegerandin, û
///
/// * bloka bîranînê paşê nehatiye veqetandin, ku blok an rasterast bi derbasbûna [`deallocate`] têne veqetandin an jî bi derbasbûna [`grow`] an [`shrink`] ku vedigere `Ok` têne guhertin.
///
/// Ger `grow` an `shrink` `Err` vegerandibe, nîşana derbazkirî derbasdar dimîne.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Bîranîn
///
/// Hin ji rêbazan hewce dike ku nexşeyek * blokek bîranînê lihevhatî be.
/// Wateya wateya wê ji bo vesazkirina "fit" a bloka bîranînê ye (an jî bi heman rengî, ji bo bloka bîranînê ya ji bo "fit" a vesazkirin) ev e ku divê mercên jêrîn hebe:
///
/// * Divê blok bi heman rêzkirinê wekî [`layout.align()`] were veqetandin, û
///
/// * [`layout.size()`] pêşkêşkirî divê di nav rêza `min ..= max` de be, ku:
///   - `min` mezinahiya dîzaynê ye ku herî dawî ji bo dabeşkirina blokê tê bikar anîn, û
///   - `max` mezinahiya rastîn a herî dawî ye ku ji [`allocate`], [`grow`], an [`shrink`] vegeriyaye.
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Astengên bîranînê yên ku ji dabeşker vegeriyane divê nîşana bîranîna derbasdar bidin û rastdariya xwe bidomînin heya ku mînak û hemî klonên wê werin derxistin,
///
/// * klonkirin an veguhastina dabeşker divê blokên bîranînê yên ku ji vê dabeşkerê hatine vegerandin bêserûber nebe.Dabeşkerê klonkirî divê mîna heman dabeşker tevbigere, û
///
/// * her pointer bi bloka bîranînê ku [*currently allocated*] e, dikare derbasî her rêbaza dabeşkerê ya din bibe.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Hewldanên ji bo veqetandina blokek bîranînê.
    ///
    /// Li ser serfiraziyê, vegera civînek [`NonNull<[u8]>`][NonNull] bi mîsogerî û misogerkirina mîsogeriya `layout`.
    ///
    /// Bloka ku vegeriya dibe ku ji `layout.size()` diyar kirî mezintir hebe, û dibe ku naveroka wê were destpêkirin an jî nebe.
    ///
    /// # Errors
    ///
    /// Vegerandina `Err` diyar dike ku yan bîranîn xilas bûye an `layout` bi mezinahiya dabeşker an astengiyên rêzkirinê re nabîne.
    ///
    /// Pêkanînên hanê têne şandin ku bila `Err` li ser westandina bîranînê li şûna panîk û kurtajê vegerin, lê ev ne hewceyek hişk e.
    /// (Bi taybetî: ev *qanûnî* ye ku meriv vê trait li ser pirtûkxaneyek dabeşkirina xwemalî ya binyadî bicîh bîne ku westîna bîrê radiwestîne.)
    ///
    /// Xerîdarên ku dixwazin di bersiva xeletiyek dabeşkirinê de hesibandinê kurt bikin, têne vexwendin ku bila fonksiyona [`handle_alloc_error`] bixwazin, ji dêvla ku rasterast `panic!` an wekî din bang bikin.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Mîna `allocate` tevdigere, lê di heman demê de misoger dike ku bîra vegerandî sifir-destpêkirî ye.
    ///
    /// # Errors
    ///
    /// Vegerandina `Err` diyar dike ku yan bîranîn xilas bûye an `layout` bi mezinahiya dabeşker an astengiyên rêzkirinê re nabîne.
    ///
    /// Pêkanînên hanê têne şandin ku bila `Err` li ser westandina bîranînê li şûna panîk û kurtajê vegerin, lê ev ne hewceyek hişk e.
    /// (Bi taybetî: ev *qanûnî* ye ku meriv vê trait li ser pirtûkxaneyek dabeşkirina xwemalî ya binyadî bicîh bîne ku westîna bîrê radiwestîne.)
    ///
    /// Xerîdarên ku dixwazin di bersiva xeletiyek dabeşkirinê de hesibandinê kurt bikin, têne vexwendin ku bila fonksiyona [`handle_alloc_error`] bixwazin, ji dêvla ku rasterast `panic!` an wekî din bang bikin.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // EWLEH: `alloc` blokek bîranîna derbasdar vedigerîne
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Bîra ku ji hêla `ptr` ve hatî referanskirin vedihewîne.
    ///
    /// # Safety
    ///
    /// * `ptr` Divê blokek bîranînê [*currently allocated*] bi navgîniya vê dabeşkerê diyar bike, û
    /// * `layout` divê [*fit*] wê bloka bîranînê.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Hewldanên dirêjkirina bloka bîranînê.
    ///
    /// [`NonNull<[u8]>`][NonNull]-ya nû vedigerîne ku nîşander û mezinahiya rastîn ya bîranîna veqetandî tê de ye.Nîşanek ji bo hilgirtina daneyên ku ji hêla `new_layout` ve hatî vegotin guncan e.
    /// Ji bo vê yekê pêk bîne, veqetîner dikare dabeşkirina ku ji hêla `ptr` ve hatî referans kirin ve dirêj bike da ku li pêşnûma nû bi cih bike.
    ///
    /// Ger ev `Ok` vegerîne, wê hingê xwedaniya bloka bîranînê ya ku ji hêla `ptr` ve hatî referanskirin li vê dabeşkerê hatiye veguheztin.
    /// Dibe ku bîranîn azad bûbe an nebe, û divê bêkêr were hesibandin heya ku ew bi rêya nirxê vegera vê rêbazê dîsa li gazî neyê veguhastin.
    ///
    /// Ger ev rêbaz `Err` vegerîne, wê hingê xwedaniya bloka bîranînê ji bo vê dabeşker nehatiye veguheztin, û naveroka bloka bîranînê nayê guhertin.
    ///
    /// # Safety
    ///
    /// * `ptr` divê bi riya vê dabeşkerê blokek bîra [*currently allocated*] nîşan bike.
    /// * `old_layout` divê [*fit*] wê bloka bîranînê (Nîqaşa `new_layout` hewce nake ku ew bi cî were.).
    /// * `new_layout.size()` divê ji `old_layout.size()` mezintir an wekhev be.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// `Err` vedigerîne heke nexşeya nû pîvana dabeşker û astengên lihevnêzîk ên dabeşker bicîh nayne, an jî ger mezinbûn bi rengek din têk biçe.
    ///
    /// Pêkanînên hanê têne şandin ku bila `Err` li ser westandina bîranînê li şûna panîk û kurtajê vegerin, lê ev ne hewceyek hişk e.
    /// (Bi taybetî: ev *qanûnî* ye ku meriv vê trait li ser pirtûkxaneyek dabeşkirina xwemalî ya binyadî bicîh bîne ku westîna bîrê radiwestîne.)
    ///
    /// Xerîdarên ku dixwazin di bersiva xeletiyek dabeşkirinê de hesibandinê kurt bikin, têne vexwendin ku bila fonksiyona [`handle_alloc_error`] bixwazin, ji dêvla ku rasterast `panic!` an wekî din bang bikin.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // EWLEH: ji ber ku divê `new_layout.size()` jê mezintir an wekhev be
        // `old_layout.size()`, hem dabeşkirina bîra kevn û hem jî ya nû ji bo xwendin û nivîsandina ji bo `old_layout.size()` byte derbasdar e.
        // Di heman demê de, ji ber ku dabeşkirina kevn hêj nehatiye veqetandin, ew nikare `new_ptr` li hev bike.
        // Ji ber vê yekê, banga `copy_nonoverlapping` ewledar e.
        // Divê peymana ewlehiyê ji bo `dealloc` ji hêla gazîvan ve were piştgirî kirin.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Mîna `grow` tevdigere, lê di heman demê de piştrast dike ku naveroka nû berî vegerînê sifir be.
    ///
    /// Dê bloka bîranînê piştî bangek serketî naveroka jêrîn hebe
    /// `grow_zeroed`:
    ///   * Bytes `0..old_layout.size()` ji dabeşkirina xwerû têne parastin.
    ///   * Li gorî pêkanîna dabeşker, Bytes `old_layout.size()..old_size` dê were parastin an sifirkirin.
    ///   `old_size` behsa mezinahiya bloka bîranînê ya berî banga `grow_zeroed` dike, ku dibe ku ji mezinahiya ku di destpêkê de dema ku hat veqetandin were xwestin, mezintir be.
    ///   * Bytes `old_size..new_size` sifir in.`new_size` behsa mezinahiya bloka bîranînê dike ku ji hêla banga `grow_zeroed` ve hatî vegerandin.
    ///
    /// # Safety
    ///
    /// * `ptr` divê bi riya vê dabeşkerê blokek bîra [*currently allocated*] nîşan bike.
    /// * `old_layout` divê [*fit*] wê bloka bîranînê (Nîqaşa `new_layout` hewce nake ku ew bi cî were.).
    /// * `new_layout.size()` divê ji `old_layout.size()` mezintir an wekhev be.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// `Err` vedigerîne heke nexşeya nû pîvana dabeşker û astengên lihevnêzîk ên dabeşker bicîh nayne, an jî ger mezinbûn bi rengek din têk biçe.
    ///
    /// Pêkanînên hanê têne şandin ku bila `Err` li ser westandina bîranînê li şûna panîk û kurtajê vegerin, lê ev ne hewceyek hişk e.
    /// (Bi taybetî: ev *qanûnî* ye ku meriv vê trait li ser pirtûkxaneyek dabeşkirina xwemalî ya binyadî bicîh bîne ku westîna bîrê radiwestîne.)
    ///
    /// Xerîdarên ku dixwazin di bersiva xeletiyek dabeşkirinê de hesibandinê kurt bikin, têne vexwendin ku bila fonksiyona [`handle_alloc_error`] bixwazin, ji dêvla ku rasterast `panic!` an wekî din bang bikin.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // EWLEH: ji ber ku divê `new_layout.size()` jê mezintir an wekhev be
        // `old_layout.size()`, hem dabeşkirina bîra kevn û hem jî ya nû ji bo xwendin û nivîsandina ji bo `old_layout.size()` byte derbasdar e.
        // Di heman demê de, ji ber ku dabeşkirina kevn hêj nehatiye veqetandin, ew nikare `new_ptr` li hev bike.
        // Ji ber vê yekê, banga `copy_nonoverlapping` ewledar e.
        // Divê peymana ewlehiyê ji bo `dealloc` ji hêla gazîvan ve were piştgirî kirin.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Hewldanên piçûkkirina bloka bîranînê.
    ///
    /// [`NonNull<[u8]>`][NonNull]-ya nû vedigerîne ku nîşander û mezinahiya rastîn ya bîranîna veqetandî tê de ye.Nîşanek ji bo hilgirtina daneyên ku ji hêla `new_layout` ve hatî vegotin guncan e.
    /// Ji bo pêkanîna vê, dabeşker dikare dabeşkirina ku ji hêla `ptr` ve hatî referans kirin ve biçûk bike da ku li pêşnûma nû were.
    ///
    /// Ger ev `Ok` vegerîne, wê hingê xwedaniya bloka bîranînê ya ku ji hêla `ptr` ve hatî referanskirin li vê dabeşkerê hatiye veguheztin.
    /// Dibe ku bîranîn azad bûbe an nebe, û divê bêkêr were hesibandin heya ku ew bi rêya nirxê vegera vê rêbazê dîsa li gazî neyê veguhastin.
    ///
    /// Ger ev rêbaz `Err` vegerîne, wê hingê xwedaniya bloka bîranînê ji bo vê dabeşker nehatiye veguheztin, û naveroka bloka bîranînê nayê guhertin.
    ///
    /// # Safety
    ///
    /// * `ptr` divê bi riya vê dabeşkerê blokek bîra [*currently allocated*] nîşan bike.
    /// * `old_layout` divê [*fit*] wê bloka bîranînê (Nîqaşa `new_layout` hewce nake ku ew bi cî were.).
    /// * `new_layout.size()` divê ji `old_layout.size()` piçûktir an wekhev be.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// `Err` vedigerîne ger nexşeya nû pîvana dabeşkerê û astengiyên lihevnekirinên dabeşkerê bicîh neyne, an heke şûnda şûnda têk biçe.
    ///
    /// Pêkanînên hanê têne şandin ku bila `Err` li ser westandina bîranînê li şûna panîk û kurtajê vegerin, lê ev ne hewceyek hişk e.
    /// (Bi taybetî: ev *qanûnî* ye ku meriv vê trait li ser pirtûkxaneyek dabeşkirina xwemalî ya binyadî bicîh bîne ku westîna bîrê radiwestîne.)
    ///
    /// Xerîdarên ku dixwazin di bersiva xeletiyek dabeşkirinê de hesibandinê kurt bikin, têne vexwendin ku bila fonksiyona [`handle_alloc_error`] bixwazin, ji dêvla ku rasterast `panic!` an wekî din bang bikin.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // EWLEH: ji ber ku `new_layout.size()` divê ji wê kêmtir an wekhev be
        // `old_layout.size()`, hem dabeşkirina bîra kevn û hem jî ya nû ji bo xwendin û nivîsandina ji bo `new_layout.size()` byte derbasdar e.
        // Di heman demê de, ji ber ku dabeşkirina kevn hêj nehatiye veqetandin, ew nikare `new_ptr` li hev bike.
        // Ji ber vê yekê, banga `copy_nonoverlapping` ewledar e.
        // Divê peymana ewlehiyê ji bo `dealloc` ji hêla gazîvan ve were piştgirî kirin.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Ji bo vê nimûneya `Allocator` adapterek "by reference" diafirîne.
    ///
    /// Vebijêrk vegeriyan jî `Allocator` bicîh dike û dê bi hêsanî vî deyn bike.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // EWLEH: : divê peymana ewlehiyê ji hêla bangker ve were pejirandin
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // EWLEH: : divê peymana ewlehiyê ji hêla bangker ve were pejirandin
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // EWLEH: : divê peymana ewlehiyê ji hêla bangker ve were pejirandin
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // EWLEH: : divê peymana ewlehiyê ji hêla bangker ve were pejirandin
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}