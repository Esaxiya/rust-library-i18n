use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Dabeşkerê bîranînê ku dikare wekî diyardeya pirtûkxaneya standard bi navgîniya taybetmendiya `#[global_allocator]` were tomar kirin.
///
/// Hin ji rêbazan hewce dike ku blokek bîranînê * niha bi rêya veqetandek were veqetandin.Ev tê vê wateyê ku:
///
/// * navnîşana destpêkê ya ji bo wê bloka bîranînê berê bi banga berê vegeriya metodek dabeşkirinê wekî `alloc`, û
///
/// * bloka bîranînê paşê nehatiye veqetandin, ku blok têne veqetandin an bi rêbaza veguhêzkirina wekî `dealloc` an jî bi rêbaza reallocation ku pointerek ne-null vedigere derbas dibe.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// `GlobalAlloc` trait ji ber gelek sedeman `unsafe` trait ye, û bicîhkeran divê piştrast bikin ku ew pabendî van peymanan in:
///
/// * Heke dabeşkerên cîhanî ji hev vebibin tevgerek ne diyar e.Dibe ku ev sînorkirin di future de were rakirin, lê naha panic ji van fonksiyonên yek dikare bibe sedema bêewlehiya bîranînê.
///
/// * `Layout` pirs û hesab bi giştî divê rast bin.Bangkerên vê trait dihêlin ku xwe bisipêrin peymanên ku li ser her rêbazê hatine diyar kirin, û pêdivî ye ku bicîhker peymanên weha rast bimînin.
///
/// * Dibe ku hûn li veberhênanên bi rastî diqewimin bisekinin, heke di çavkaniyê de veqetandinên heap eşkere hebin.
/// Optîmîzator dikare veqetandinên bê karanîn destnîşan bike ku ew dikare yan bi tevahî ji holê rabike an jî biçe ser stackê û ji ber vê yekê tu carî veqetandek bang nake.
/// Optîmîzator dikare bêtir bifikire ku dabeşkirin xelet e, ji ber vê yekê koda ku ji ber têkçûnên dabeşker têk diçû dibe ku nuha ji nişkê ve bixebite ji ber ku optimizer li dora hewceyê dabeşkirinê xebitî.
/// Bi taybetî, mînaka kodê jêrîn neheq e, bêyî ku veqetandek weya xwerû destûrê dide hejmartina çend veqetandinan çêbûye.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Bala xwe bidinê ku optimîzasyonên ku li jor behs kirin tenê çêtirîn optimîzasyona ku dikare were sepandin ne.Hûn dikarin bi gelemperî pişta xwe nedin veqetandinên heapê yên çêdibin heke ew bêne rakirin bêyî ku tevgera bernameyê were guhertin.
///   Ka dabeşkirin çêdibe an na ne beşek ji reftara bernameyê ye, heke ew dikare bi rêya dabeşkerê ku veqetandinê bi çapkirinê an jî bi bandorên dî bandorên wê hene bişopîne were kifş kirin.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Wekî ku ji hêla `layout` ve hatî diyarkirin ve bîranîn veqetînin.
    ///
    /// Nîşanek li bîra nû-veqetandî vedigerîne, an jî betal dike ku têkçûna dabeşkirinê nîşan bide.
    ///
    /// # Safety
    ///
    /// Ev fonksiyon ne ewle ye ji ber ku tevger nediyarkirî dikare encam bide heke bangker piştrast neke ku `layout` mezinahiya ne-sifir heye.
    ///
    /// (Dibe ku subtraits dirêjahî li ser tevgerê sînorên taybetîtir peyda bikin, mînakî, bersîva serlêdana dabeşkirina sifir-mezinahî navnîşanek sentînel an pêşnumayek null garantî bikin.)
    ///
    /// Astengiya bîranînê ya veqetandî dikare were destpêkirin an jî nebe.
    ///
    /// # Errors
    ///
    /// Vegerandina nîşangirek null diyar dike ku yan bîranîn xilas bûye an `layout` bi mezinahiya an dabeşkirina astengên vî dabeşker re nabîne.
    ///
    /// Pêkanînên hanê têne şandin ku ji şûnda betalkirina bîranînê pûç vegerin, lê ev ne hewceyek hişk e.
    /// (Bi taybetî: ev *qanûnî* ye ku meriv vê trait li ser pirtûkxaneyek dabeşkirina xwemalî ya binyadî bicîh bîne ku westîna bîrê radiwestîne.)
    ///
    /// Xerîdarên ku dixwazin di bersiva xeletiyek dabeşkirinê de hesibandinê kurt bikin, têne vexwendin ku bila fonksiyona [`handle_alloc_error`] bixwazin, ji dêvla ku rasterast `panic!` an wekî din bang bikin.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Bloka bîranînê ya li pêşekvanê `ptr`-ê bi `layout`-yê dayî ve vehewîne.
    ///
    /// # Safety
    ///
    /// Ev fonksiyon ne ewle ye ji ber ku tevger nediyarkirî dikare encam bide heke bangvan hemî jêrîn piştrast neke:
    ///
    ///
    /// * `ptr` Divê blokek bîranînê ya ku bi navgîniya vê dabeşkerê ve hatî veqetandin nîşan bike
    ///
    /// * `layout` Pêdivî ye ku heman dabeş be ku ji bo dabeşkirina wê bloka bîranînê hate bikar anîn.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Mîna `alloc` tevdigere, lê di heman demê de piştrast dike ku naverok berî vegerînê sifir têne saz kirin.
    ///
    /// # Safety
    ///
    /// Ev fonksiyon ji ber heman sedeman ku `alloc` e jî ne ewle ye.
    /// Lêbelê bloka bîranînê ya veqetandî tê mîsoger kirin ku dê were destpêkirin.
    ///
    /// # Errors
    ///
    /// Vegerandina nîşangirek null diyar dike ku yan bîranîn xilas bûye an `layout` pîvana dabeşker an astengiyên lihevkirinê rast nayê, her wekî `alloc`.
    ///
    /// Xerîdarên ku dixwazin di bersiva xeletiyek dabeşkirinê de hesibandinê kurt bikin, têne vexwendin ku bila fonksiyona [`handle_alloc_error`] bixwazin, ji dêvla ku rasterast `panic!` an wekî din bang bikin.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // EWLEHIY: : divê peymana ewlehiyê ya ji bo `alloc` ji hêla bangdêr ve were pejirandin.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // EWLEH: wekî dabeşkirin bi ser ket, herêm ji `ptr`
            // mezinahiya `size` ji bo nivîsandinê rastdar e.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Blokek bîranînê bi `new_size`-ya dayîn ve bişoxilînin an mezin bikin.
    /// Astengkirin ji hêla `ptr` nîşanker û `layout` ve hatî vegotin.
    ///
    /// Ger ev pointerek ne-null vegerîne, hingê xwedaniya bloka bîranînê ya ku ji hêla `ptr` ve hatî referans kirin li vê dabeşkerê hatiye veguheztin.
    /// Bîra hanê dibe ku were veqetandin, an jî nebe, û divê ew bêkêr bête hesibandin (heke bê guman ew dîsa bi nirxê vegera vê rêbazê dîsa vegeriya gazîvan).
    /// Astengiya bîranîna nû bi `layout` ve tê veqetandin, lê bi `size` bi `new_size` nûve dibe.
    /// Pêdivî ye ku ev nexşeya nû dema dealkirina bloka bîra nû ya bi `dealloc` were bikar anîn.
    /// The range `0..min(layout.size(), new_size) `ya bloka bîra nû garantî ye ku xwedan heman nirxên bloka orjînal e.
    ///
    /// Ger ev rêbaz vala vedigere, wê hingê xwedaniya bloka bîranînê ji bo vê dabeşker nehatiye veguheztin, û naveroka bloka bîranînê nayê guhertin.
    ///
    /// # Safety
    ///
    /// Ev fonksiyon ne ewle ye ji ber ku tevger nediyarkirî dikare encam bide heke bangvan hemî jêrîn piştrast neke:
    ///
    /// * `ptr` Divê niha bi navgîniya vê dabeşker were veqetandin,
    ///
    /// * `layout` Divê heman dabeş be ku ji bo dabeşkirina wê bloka bîranînê hate bikar anîn,
    ///
    /// * `new_size` divê ji sifirê mezintir be.
    ///
    /// * `new_size`, dema ku heya pirjimara `layout.align()`-ya herî nêz were dorpêç kirin, pêdivî ye ku neherike (ango, nirxa dorpêçkirî divê ji `usize::MAX` kêmtir be).
    ///
    /// (Dibe ku subtraits dirêjahî li ser tevgerê sînorên taybetîtir peyda bikin, mînakî, bersîva serlêdana dabeşkirina sifir-mezinahî navnîşanek sentînel an pêşnumayek null garantî bikin.)
    ///
    /// # Errors
    ///
    /// Heke nexşeya nû pîvan û astengiyên lihevnêzîk ên dabeşker li hev nake, an heke ji nû ve veqetandina cîh cîbicî nebe, vala vedigere.
    ///
    /// Pêkanîn têne şandin ku ji xilaskirina bîranînê şûna panîk û kurtajê pûç vegerin, lê ev ne hewceyek hişk e.
    /// (Bi taybetî: ev *qanûnî* ye ku meriv vê trait li ser pirtûkxaneyek dabeşkirina xwemalî ya binyadî bicîh bîne ku westîna bîrê radiwestîne.)
    ///
    /// Xerîdarên ku dixwazin di bersiva xeletiyek nûvekêşanê de hesabê kurt bikin, têne vexwendin ku bila fonksiyona [`handle_alloc_error`] bixwazin, ji dêvla ku rasterast `panic!` an wekî din bang bikin.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // EWLEHIY: : Divê bangker piştrast bike ku `new_size` zêde neherike.
        // `layout.align()` ji `Layout` tê û bi vî rengî garantî ye ku derbasdar e.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // EWLEHIY: : divê bangker piştrast bike ku `new_layout` ji sifirê mezintir e.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // SAFETY: bloka ku berê hatî veqetandin nikare bloka ku nû hatî veqetandin li hev bike.
            // Divê peymana ewlehiyê ji bo `dealloc` ji hêla gazîvan ve were piştgirî kirin.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}