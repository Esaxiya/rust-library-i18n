#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future hesabek asinkron nîşan dike.
///
/// A future nirxek e ku dibe ku hêj hejmartina xwe xilas nekiriye.
/// Bi vî rengî "asynchronous value" dihêle ku têlek dema ku ew li bendê ye ku nirx were peyda kirin, karê kêrhatî bidomîne.
///
///
/// # Rêbaza `poll`
///
/// Metoda bingehîn a future, `poll`,*hewl dide* ku future bi nirxek dawîn çareser bike.
/// Heke nirx ne amade be vê rêbazê nagire.
/// Di şûna wê de, dema ku gengaz be ku dîsa bi `rapirsînê` pêşveçûnek çêbibe, peywira heyî tê şiyarkirin.
/// `context` derbasî rêbaza `poll` dibe dikare [`Waker`] peyda bike, ku desteyek ji bo şiyarkirina karê heyî ye.
///
/// Gava ku hûn future bikar tînin, hûn ê bi gelemperî rasterast bangî `poll` nekin, lê li şûna wê nirxê `.await`.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Cureyê nirxê ku li ser qedandinê tê hilberandin.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Hewldana çareserkirina future bi nirxek paşîn, tomarkirina peywira heyî ji bo şiyarkirinê heke hêjayî hêj tune.
    ///
    /// # Nirxê vegerînin
    ///
    /// Ev fonksiyon vedigere:
    ///
    /// - [`Poll::Pending`] heke future hêj ne amade ye
    /// - [`Poll::Ready(val)`] bi `val` encama vê future heke ew bi serfirazî xilas bibe.
    ///
    /// Gava ku future xelas bû, pêdivî ye ku xerîdar wê careke din `poll` nekin.
    ///
    /// Gava ku future hêj ne amade be, `poll` `Poll::Pending` vedigerîne û klonek [`Waker`] ya ku ji [`Context`] ya niha hatî kopî kirin, vedigire.
    /// Vê [`Waker`] hingê şiyar dibe gava ku future dikare pêşve here.
    /// Mînakî, future li benda soketek ku were xwendin dê bangî `.clone()` li [`Waker`] bike û wê lê hiltîne.
    /// Dema ku sînyalek digihîje cîhek din ku nîşan dide ku soket tê xwendin, [`Waker::wake`] tê gazî kirin û erka socket future şiyar dibe.
    /// Gava ku wezîfeyek şiyar bû, divê ew ji nû ve hewl bide `poll` future, ku dibe ku nirxek dawîn hilberîne an nebe.
    ///
    /// Zanibe ku li ser gelek bangên bi `poll` re, tenê [`Waker`] ji [`Context`] derbasî banga herî paşîn dibe ku were plan kirin ku şiyarbûnê bistîne.
    ///
    /// # Taybetmendiyên demjimêrê
    ///
    /// Futures tenê *bêçare ne;divê ew bi* çalak * `rapirsîn` bêne rakirin da ku pêşkeftinê çêbikin, wate ku her gava ku karê heyî radibe, divê ew çalak li benda futures ku ew hîn jî pê eleqedar e ji nû ve`poll bike '.
    ///
    /// Fonksiyona `poll` di xelekek teng de bi berdewamî nayê gazîkirin-li şûna wê, tenê dema ku future diyar dike ku ew amade ye ku pêşveçûnê çêbike (bi bangkirina `wake()`).
    /// Heke hûn bi x0scallên `poll(2)` an `select(2)` yên li ser Unix agahdar in ew hêjayî gotinê ye ku futures bi gelemperî *pirsgirêkên*"all wakeups must poll all events"*êş* nakin;ew bêtir mîna `epoll(4)` in.
    ///
    /// Pêdivî ye ku pêkanîna `poll` hewce bike ku zû vegere, û nabe asteng.Zû vegerîn pêşî li girtina bêserûber xelekên an xelekên bûyerê digire.
    /// Ger pêşwext were zanîn ku dibe ku bangek ji bo `poll` demekê bi dawî bibe, divê kar ji bo hewalek têl (an tiştek mîna wê) were dakêşandin da ku `poll` zû vegere.
    ///
    /// # Panics
    ///
    /// Gava ku future xelas bû (`Ready` ji `poll` vegerand), bangkirina rêbaza `poll` ya wê dîsa dikare panic bike, heya hetayê bloke bike, an jî bibe sedema pirsgirêkên cûreyên din;`Future` trait li ser bandorên bangek wusa hewce nake.
    /// Lêbelê, ji ber ku rêbaza `poll` bi `unsafe` nehatiye nîşankirin, rêgezên adetî yên Rust derbasdar in: bang divê çu carî nebe sedema tevgera nediyarkirî (gendeliya bîranînê, karanîna çewt a fonksiyonên `unsafe`, an mîna wan), bêyî ku rewşa future hebe.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}