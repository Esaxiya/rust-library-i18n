use crate::future::Future;

/// Zivirîna nav `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Hilbera ku future dê li ser qedandinê hilberîne.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Em ê viya veguherînin kîjan celeb future?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Ji nirxek future diafirîne.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}