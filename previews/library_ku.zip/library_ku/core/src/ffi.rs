#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Karûbarên têkildarî girêdanên navnîşa (FFI) a fonksiyona biyanî.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// Gava ku wekî [pointer] tê bikar anîn hevsan bi tîpa X's `void` e.
///
/// Di aslê xwe de, `*const c_void` bi C's `const void*` û `*mut c_void` bi C's `void*` re hevseng e.
/// Got, ev *ne* eynî wekî tîpa vegera C ya `void` e, ku ew tîpa Rust ya `()` e.
///
/// Ji bo ku modela nîşangiran ji bo celebên nebaş ên di FFI de, heya ku `extern type` sabît nebe, tê pêşniyar kirin ku li dor arrayek byteyek vala zerfek newtype bikar bînin.
///
/// Ji bo hûragahiyan li [Nomicon] binêrin.
///
/// Meriv dikare `std::os::raw::c_void` bikar bîne heke ew bixwazin berhevkarê kevn Rust heya 1.1.0 piştgirî bikin.
/// Piştî Rust 1.30.0, ew bi vê pênaseyê ji nû ve hate hinardekirin.
/// Ji bo bêtir agahdarî, ji kerema xwe [RFC 2521] bixwînin.
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB, ji bo ku LLVM cureyê pêşnumaya valahiyê nas bike û ji hêla fonksiyonên dirêjkirinê yên mîna malloc() ve, hewce dike ku em wê wekî i8 * di LLVM bitcode de temsîl bikin.
// Enumê ku li vir tê bikar anîn vê yekê misoger dike û pêşî li karanîna çewt a "raw" digire tenê bi vebijarkên taybetî hene.
// Ji me re du variant hewce ne, ji ber ku berhevkar ji taybetmendiya repr gilî dike û wekî din û ji me re herî kêm variantek hewce dike ji ber ku wekî din enum dê niştecîh nebe û bi kêmanî dereferferenkirina nîşanên weha UB be.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// Pêkanîna bingehîn a `va_list`.
// Navê WIP e, ji bo naha `VaListImpl` bikar tîne.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // Di ser `'f` de neguhêrbar e, ji ber vê yekê her tiştê `VaListImpl<'f>` bi herêma fonksiyona ku tê de vegotî ve girêdayî ye
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 Pêkanîna ABI ya `va_list`.
/// Ji bo bêtir agahdarî li [AArch64 Procedure Call Standard] binêrin.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC Pêkanîna ABI ya `va_list`.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 Pêkanîna ABI ya `va_list`.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// Pêçek ji bo `va_list`
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// `VaListImpl` veguherînin `VaList` ku bi C's `va_list` re binaryo ye.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// `VaListImpl` veguherînin `VaList` ku bi C's `va_list` re binaryo ye.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// Pêdivî ye ku VaArgSafe trait di navrûyên giştî de were bikar anîn, lêbelê, pêdivî ye ku trait bixwe li derveyî vê modulê neyê bikar anîn.
// Destûrdayîna bikarhêneran ku ji bo celebek nû trait bicîh bikin (bi vî awayî dihêle ku va_arg ya xwerû li ser celebek nû were bikar anîn) dibe ku bibe sedema reftarek nediyarkirî.
//
// FIXME(dlrobertson): Ji bo ku VaArgSafe trait-ê di navgînek gelemperî de were bikar anîn lê di heman demê de bicîh bibe ku ew li cîhek din nayê bikar anîn, hewce ye ku trait di nav moduleke taybetî de gelemperî be.
// Gava ku RFC 2145 hate bicîh kirin vê yekê çêtir bikin.
//
//
//
//
mod sealed_trait {
    /// Trait ku dihêle ku celebên destûr bi [super::VaListImpl::arg] werin bikar anîn.
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Pêşve arg.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // EWLEHIY: : bangker divê peymana ewlehiyê ya `va_arg` biparêze.
        unsafe { va_arg(self) }
    }

    /// `va_list` li cîhê heyî kopî dike.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // EWLEHIY: : bangker divê peymana ewlehiyê ya `va_end` biparêze.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // EWLEH: em ji `MaybeUninit` re dinivîsin, bi vî rengî ew destpêdike û `assume_init` qanûnî ye
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: divê ev bang `va_end` bike, lê çu rêyek paqij tune
        // garantî bikin ku `drop` her gav dikeve nav bangvanê xwe, ji ber vê yekê `va_end` dê ji heman fonksiyonê wekî `va_copy` ya peywenddar rasterast were gazî kirin.
        // `man va_end` diyar dike ku C vê yekê hewce dike, û LLVM di bingeh de semantîka C dişopîne, ji ber vê yekê em hewce dikin ku `va_end` her gav ji heman fonksiyonê wekî `va_copy` were gazî kirin.
        //
        // Ji bo bêtir agahdarî, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // Ev ji bo nuha dixebite, ji ber ku `va_end` li ser hemî armancên heyî yên LLVM qedexe ye.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// Piştî destpêkirina `va_start` an `va_copy` arglist `ap` hilweşînin.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// Cihê niha yê arglist `src` li arglist `dst` kopî dike.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// Nîqaşek ji celebê `T` ji `va_list` `ap` bar dike û argumana `ap` nîşan dide zêde dike.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}