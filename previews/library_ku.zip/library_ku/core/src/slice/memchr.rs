// Pêkanîna eslî ji rust-memchr hatiye girtin.
// Copyright 2015 Andrew Gallant, bluss û Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Truncation bikar bînin.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// `true` vedigerîne heke `x` ti byteyek sifir hebe.
///
/// Ji *Matters Computational*, J. Arndt:
///
/// "Fikir ev e ku meriv ji yek ji bajaran yek derxîne û dûv re li bajaran bigere ku deyn hemî awayê herî girîng belav dibe
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Indeksa yekem a ku li byte `x` li `text` li hev tîne vedigerîne.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Ji bo pelikên piçûk riya zû
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Bi xwendina du bêjeyên `usize` di yek carekê de ji bo nirxek yek byte bikolin.
    //
    // `text` li sê beşan parçe bikin
    // - beşa destpêkê ya bêserûber, berî gotina yekem a navnîşkirî ya di nivîsarê de
    // - laş, di carekê de bi 2 bêjeyan şeh bikin
    // - beşa mayî ya paşîn, <2 mezinahiya peyvê

    // heya sînorek hevgirtî bigerin
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // li laşê nivîsê bigerin
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // EWLEH: : pêşgotina dema dûrahiya herî kêm 2 * bikarhêner_bytes garantî dike
        // di navbera veqetandin û dawiya perçeyê de.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // heke byteyek lihevhatinê hebe bişkînin
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Piştî xalê lapa laş sekinî bite.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Indeksa paşîn a ku li `text` byte `x` li hev tîne vedigerîne.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Bi xwendina du bêjeyên `usize` di yek carekê de ji bo nirxek yek byte bikolin.
    //
    // `text` li sê beşan dabeş bikin:
    // - dûvikê bêserûber, piştî peyva paşîn di navnîşanê de rêzkirî
    // - laş, ji hêla 2 peyvan ve di yek carekê de tê skenkirin,
    // - yekem byteyên mayî, <2 mezinahiya peyvê.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Em ji vê re dibêjin tenê ji bo bidestxistina dirêjahiya pêşgir û paşpirtikê.
        // Di navîn de em her gav bi yekcarî du kerpîçan pêvajo dikin.
        // EWLEHIY: : veguheztina `[u8]` bo `[usize]` ewle ye ji xeynî cûdahiyên mezinahiyê ku ji hêla `align_to` ve têne rêve kirin.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Li laşê nivîsê bigerin, bila em ji min_aligned_offset derbas nebin.
    // berdêl her gav lihevrastkirî ye, ji ber vê yekê tenê ceribandina `>` bes e û ji zêdebûna gengaz dûr dikeve.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // EWLEHIYA: berdêl li len, suffix.len() dest pê dike, heya ku ew ji wê mezintir be
        // min_align_offset (prefix.len()) mesafeya mayî bi kêmî ve 2 * chunk_bytes e.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Ger ku byteyek lihevhatinê hebe bişkînin.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Bîtê bibînin berî nuqteyê laça laş sekinî.
    text[..offset].iter().rposition(|elt| *elt == x)
}