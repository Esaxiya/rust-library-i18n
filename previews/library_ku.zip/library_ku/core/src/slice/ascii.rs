//! Operasyonên li ser ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Kontrol dike ku gelo hemî baytên di vê perçeyê de di nav ASCII de ne.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Kontrol dike ku du tebeqe hevberdariya ASCII-rewş-nazik e.
    ///
    /// Heman wekî `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, lê bêyî veqetandin û kopîkirina hemdeman.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Vê perçê di cîh de wekheviya xwe ya mezin ASCII vedigire.
    ///
    /// Nameyên ASCII 'a' bo 'z' bi 'A' bo 'Z' têne nexşekirin, lê tîpên ne-ASCII neguhêrîn.
    ///
    /// Ji bo ku bêyî guhertina ya heyî nirxek mezin nû vegerînin, [`to_ascii_uppercase`] bikar bînin.
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Vê perçê li ciyê wekheviya xweya piçûk a ASCII vedigire.
    ///
    /// Nameyên ASCII 'A' bo 'Z' bi 'a' bo 'z' têne nexşekirin, lê tîpên ne-ASCII neguhêrîn.
    ///
    /// Ji bo ku bêyî guhertina ya heyî, nirxek nû ya jêrîn vegerînin, [`to_ascii_lowercase`] bikar bînin.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Heke di peyva `v` de bytek hebe, ne-fas e `true` vedigerîne (>=128).
/// Ji `../str/mod.rs` snarfed kirin, ku ji bo pejirandina utf8 tiştek wusa dike.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Testa ASCII ya çêtirîn ku dê li şûna operasyonên byte-li-dem-yek (gava ku gengaz be) karûbarên karanîna-di-yek-dem bikar bînin.
///
/// Algorîtmaya ku em li vir bikar tînin pir hêsan e.Ger `s` pir kurt e, em tenê her baytekê kontrol dikin û pê re tê kirin.Wekî din:
///
/// - Gotarek yekem bi barkêşek bêkêmasî bixwînin.
/// - Nîqaşê rast bikin, bêjeyên paşîn heya dawî bi barkêşên lihevkirî bixwînin.
/// - Bi barkirina bêserûber `usize`-ya paşîn ji `s` bixwînin.
///
/// Heke ji van barkêşan tiştek ji bo ku `contains_nonascii` (above) rast vedigere tiştek hilberîne, wê hingê em dizanin ku bersiv derew e.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Heke em ê ji pêkanîna peyv-di-yek-dem de tiştek qezenc nekin, dîsa vegerin ser xelekek scalar.
    //
    // Em vê yekê jî ji bo avahîsazên ku `size_of::<usize>()` ji bo `usize` rêzkirin têr nake, dikin, ji ber ku ew doza edge ya xerîb e.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Em her gav bêjeya yekem bêserûber dixwînin, ku wateya wê `align_offset` e
    // 0, em ê dîsa ji bo xwendina rêzkirî heman nirxê bixwînin.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // EWLEH: Em li jorê `len < USIZE_SIZE` rast dikin.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Me ev li jor, hinekî bi dizî, kontrol kir.
    // Zanibe ku `offset_to_aligned` an `align_offset` an `USIZE_SIZE` e, her du jî bi zelalî li jor hatine kontrol kirin.
    //
    debug_assert!(offset_to_aligned <= len);

    // EWLEH: : word_ptr ptr-yê (bi rêkûpêk rêzkirî) bikar tîne ku em ji bo xwendina wê bikar tînin
    // beşa navîn a qurmê.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` nîşana byte ya `word_ptr` e, ku ji bo venêranên dawiya loopê tê bikar anîn.
    let mut byte_pos = offset_to_aligned;

    // Paranoia di derbarê rêzkirinê de kontrol dike, ji ber ku em ê komek barên bêserûber bikin.
    // Di pratîkê de divê ev ne gengaz be ku çewtiyek li `align_offset` asteng bike.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Bêjeyên paşîn bixwînin heya bêjeya rêzkirî ya paşîn, ji bil peyva rêzkirî ya paşîn ji hêla xwe ve ku paşê di kontrola dûvikê de bête kirin, da ku piştrast bikin ku dûvik herî zêde ji branch `byte_pos == len`-ya zêdeyî yek `usize` ye.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Baweriya hişmendiyê kontrol bikin ku xwendin di nav sînoran de ye
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // That ku ramanên me di derbarê `byte_pos` de digirin.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // EWLEH: Em dizanin `word_ptr` bi rêkûpêk li hev hatî ye (ji ber
        // `align_offset`), û em dizanin ku di navbera `word_ptr` û dawiyê de têra me byte hene
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // BELAW: : Em dizanin ku `byte_pos <= len - USIZE_SIZE`, ku tê vê wateyê
        // piştî vê `add`, `word_ptr` dê herî zêde yek-paş-paşîn be.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Kontrola hişmendiyê da ku bicîh bikin ku bi rastî tenê yek `usize` maye.
    // Divê ev ji hêla rewşa loopa me ve were garantîkirin.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // BELA: Ev xwe dispêre `len >= USIZE_SIZE`, ya ku em di destpêkê de kontrol dikin.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}