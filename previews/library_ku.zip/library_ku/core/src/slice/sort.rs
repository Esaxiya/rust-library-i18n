//! Rêzkirina perçe
//!
//! Vê modulê algorîtmayek rêzkirinê li ser bingeha quicksorta şikestina nimûneya Orson Peters heye, li weşandin: <https://github.com/orlp/pdqsort>
//!
//!
//! Dabeşandina bêîstîkrar bi libcore re lihevhatî ye ji ber ku ew bîra veqetîne, berevajî pêkanîna dabeşkirina aram a me.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Dema ku daket, ji `src` nav `dest` kopî dike.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // EWLEH: : Ev dersek alîkar e.
        //          Ji kerema xwe ji bo rastbûnê serî li karanîna wê bidin.
        //          Ango, divê meriv pê ewle be ku `src` û `dst` wek ku ji hêla `ptr::copy_nonoverlapping` ve hewce dike hev nagire.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Hêmana yekem ber bi rastê ve diguheze heya ku bi hêmanek mezintir an wekhev re rûbirû dibe.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // EWLEH: : Operasyonên ne ewledar ên jêrîn bi navnîşkirina bêyî kontrolê ve girêdayî ye (`get_unchecked` û `get_unchecked_mut`)
    // û kopîkirina bîra (`ptr::copy_nonoverlapping`).
    //
    // yek.Lêvegerîn:
    //  1. Me mezinahiya rêzikê>> 2 kontrol kir.
    //  2. Hemî navnîşkirina ku em ê bikin herî zêde her dem di navbera {0 <= index < len} de ye.
    //
    // bBîryarkirina kopî
    //  1. Em nîşanderên referansên ku garantî ne ku derbasdar in werdigirin.
    //  2. Ew nekarin li hev bikin ji ber ku em nîşankerên nîşanên cûdahiya qurmê bi dest dixin.
    //     Ango, `i` û `i-1`.
    //  3. Heke perçeyek bi rêkûpêk were rastandin, hêmanên bi rêkûpêk têne rêz kirin.
    //     Ew berpirsiyarê gazîvan e ku pê ewle bine ku dirûn bi rêkûpêk hatî rastandin.
    //
    // Ji bo bêtir agahdariyê li şîroveyên li jêr binêrin.
    unsafe {
        // Ger du hêmanên yekem ji rêzê ne ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Hêmana yekem di nav guhêrbarek dabeşkirî de bixwînin.
            // Ger çalakiyek berhevdana jêrîn panics, `hole` dê dakeve û bixweber hêmanê dîsa li pelê binivîse.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // `I`-yê hêmanê yek cîhî ber bi çepê ve bikişînin, bi vî rengî qulikê veguherînin rastê.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` dikeve û bi vî rengî `tmp` dixe nav qulika mayî ya `v`.
        }
    }
}

/// Hêmana paşîn ber bi çep ve diguheze heya ku bi hêmanek piçûktir an wekhev re rûbirû dibe.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // EWLEH: : Operasyonên ne ewledar ên jêrîn bi navnîşkirina bêyî kontrolê ve girêdayî ye (`get_unchecked` û `get_unchecked_mut`)
    // û kopîkirina bîra (`ptr::copy_nonoverlapping`).
    //
    // yek.Lêvegerîn:
    //  1. Me mezinahiya rêzikê>> 2 kontrol kir.
    //  2. Hemî navnîşkirina ku em ê bikin herî zêde her dem di navbera `0 <= index < len-1` de ye.
    //
    // bBîryarkirina kopî
    //  1. Em nîşanderên referansên ku garantî ne ku derbasdar in werdigirin.
    //  2. Ew nekarin li hev bikin ji ber ku em nîşankerên nîşanên cûdahiya qurmê bi dest dixin.
    //     Ango, `i` û `i+1`.
    //  3. Heke perçeyek bi rêkûpêk were rastandin, hêmanên bi rêkûpêk têne rêz kirin.
    //     Ew berpirsiyarê gazîvan e ku pê ewle bine ku dirûn bi rêkûpêk hatî rastandin.
    //
    // Ji bo bêtir agahdariyê li şîroveyên li jêr binêrin.
    unsafe {
        // Ger du hêmanên paşîn ji rêzê ne ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Hêmana paşîn di nav guhêrbarek dabeşkirî de bixwînin.
            // Ger çalakiyek berhevdana jêrîn panics, `hole` dê dakeve û bixweber hêmanê dîsa li pelê binivîse.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // `I`-yê hêmanê yek cîhî ber bi rastê ve bikişînin, bi vî rengî qulikê li çepê vediguhêzin.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` dikeve û bi vî rengî `tmp` dixe nav qulika mayî ya `v`.
        }
    }
}

/// Parçeyek bi veguheztina gelek hêmanên ji rêzê li derdorê rêz dike.
///
/// Ger pişk di dawiya dawîn de were rêzkirin `true` vedigerîne.Ev fonksiyon *O*(*n*) rewşa herî xirab e.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Hejmara herî zêde ya cotên derveyî rêzê yên cîran ku dê werin guhertin.
    const MAX_STEPS: usize = 5;
    // Heke perçeyek ji vê kurttir e, hêmanan neguherînin.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // EWLEH: Me berê bi zelalî kontrola bi `i < len` re kir.
        // Hemî navnîşkirina meya paşîn tenê di nav rêza `0 <= index < len` de ye
        unsafe {
            // Pêveka paşîn a hêmanên derveyî rêzê yên cîran bibînin.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Em qediyan?
        if i == len {
            return true;
        }

        // Hêmanên li ser rêzikên kurt neguherin, ku lêçûnek performansa wê heye.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Hevoka dîtinê ya hêmanan veguherînin.Ev wan bi rêkûpêk rast dike.
        v.swap(i - 1, i);

        // Hêmana piçûktir çepê veguherînin.
        shift_tail(&mut v[..i], is_less);
        // Hêmana mezintir veguherînin rastê.
        shift_head(&mut v[i..], is_less);
    }

    // Neçar ma ku rêzê di nav hejmarek bi sînor a gavên de rêz bike.
    false
}

/// Vebijarkek bi karanîna navnîşkirina navnîşê, ku *O*(*n*^ 2) rewşa herî xirab e, rêz dike.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// `v` bi karanîna heapsortê verast dike, ku *O*(*n*\*log(* n*))-rewşa herî xirab garantî dike).
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ev koma binary ji `parent >= child` ya neguhêzbar re rêz digire.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Zarokên `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Zarokê mezintir hilbijêrin.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Heke neheq li `node` bimîne bisekinin.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // `node` bi zarokê mezin re biguhezînin, gavek bavêjin xwarê, û siftkirinê bidomînin.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Di demek rêzikî de hep ava bikin.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Hêmanên herî zêde yên ji komikê pop.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Dabeşên `v` li hêmanên ji `pivot` piçûktir, li pey hêmanên ji `pivot` mezintir an jî wekhev.
///
///
/// Hejmara hêmanên ji `pivot` piçûktir vedigerîne.
///
/// Dabeşkirin ji bo kêmkirina lêçûna operasyonên şaxdan blok-by-blok tête kirin.
/// Ev raman di kaxezê [BlockQuicksort][pdf] de tête pêşkêş kirin.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Hejmarek hêmanên di blokek tîpîk de.
    const BLOCK: usize = 128;

    // Algorîtmaya dabeşkirinê heya qedandinê gavên jêrîn dubare dike:
    //
    // 1. Ji milê çepê blokek bişopînin da ku hêmanên ji pivotê mezintir an jî wekhev nas bikin.
    // 2. Ji milê rastê blokek bişopînin da ku hêmanên ji pîvokê piçûktir nas bikin.
    // 3. Hêmanên naskirî di navbera milê çep û rast de veguherînin.
    //
    // Em guherbarên jêrîn ji bo bloka hêmanan diparêzin:
    //
    // 1. `block` - Hejmara hêmanên di blokê de.
    // 2. `start` - Nîşanek li rêzeya `offsets` dest pê bike.
    // 3. `end` - Nîqaşa nav rêzika `offsets` biqedîne.
    // 4. `veqetandin, Nîşaneyên hêmanên ji rêzê yên di nav blokê de.

    // Bloka heyî ya li milê çepê (ji `l` heta `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Bloka heyî ya li milê rastê (ji `r.sub(block_r)` to `r`).
    // EWLEH: : Belgekirinên ji bo .add() bi taybetî behs dikin ku `vec.as_ptr().add(vec.len())` her gav ewle ye`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Gava ku em VLA-yê bistînin, li şûna yekê rêzek dirêjahiya `min(v.len(), 2 * BLOCK) `ê biceribînin
    // ji du rêzikên sabît ên bi dirêjahiya `BLOCK`.VLAs dibe ku bêtir kaş-karîger bin.

    // Hejmara hêmanên navbera nîşangirên `l` (inclusive) û `r` (exclusive) vedigerîne.
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Dema ku `l` û `r` pir nêz dibin em bi dabeşkirina blok-by-blok qediyan.
        // Wê hingê em ji bo ku hêmanên mayî yên di navberê de dabeş bikin hin xebatên patch-up dikin.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Hejmara hêmanên mayî (hîn jî bi pivotê re nayê qiyas kirin).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Mezinahiyên blokê sererast bikin da ku bloka çep û rast li hev negirin, lê ji bo ku valahiya mayî ya tevahî veşêrin bêkêmasî li hev werin.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Hêmanên `block_l` ji milê çepê bişopînin.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // EWLEH: : Operasyonên bêewlehî yên li jêr bi karanîna `offset` ve girêdayî ye.
                //         Li gorî mercên ku fonksiyonê hewce dike, em wan têr dikin ji ber ku:
                //         1. `offsets_l` stack-veqetandin e, û bi vî rengî wekî tiştê veqetandî veqetandî tête hesibandin.
                //         2. Fonksiyona `is_less` vedigere `bool`.
                //            `bool` avêtin dê tu carî `isize` zêde neke.
                //         3. Me garantî kir ku `block_l` dê `<= BLOCK` be.
                //            Zêdetir, `end_l` di destpêkê de nîşana destpêkê ya `offsets_` hate saz kirin ku li ser stackê hate ragihandin.
                //            Ji ber vê yekê, em dizanin ku di rewşa herî xirab de jî (hemî vexwendinên `is_less` derewîn vedigerin) em ê tenê herî zêde 1 bayt dawiya xwe derbas bikin.
                //        Operasyonek din a bêewlehî li vir dereferencing `elem` e.
                //        Lêbelê, `elem` di destpêkê de nîşana destpêkê ya perçeyê ku her gav derbasdar e bû.
                unsafe {
                    // Berawirdkirina bê şax
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Hêmanên `block_r` ji milê rast bişopînin.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // EWLEH: : Operasyonên bêewlehî yên li jêr bi karanîna `offset` ve girêdayî ye.
                //         Li gorî mercên ku fonksiyonê hewce dike, em wan têr dikin ji ber ku:
                //         1. `offsets_r` stack-veqetandin e, û bi vî rengî wekî tiştê veqetandî veqetandî tête hesibandin.
                //         2. Fonksiyona `is_less` vedigere `bool`.
                //            `bool` avêtin dê tu carî `isize` zêde neke.
                //         3. Me garantî kir ku `block_r` dê `<= BLOCK` be.
                //            Zêdetir, `end_r` di destpêkê de nîşana destpêkê ya `offsets_` hate saz kirin ku li ser stackê hate ragihandin.
                //            Ji ber vê yekê, em dizanin ku di rewşa herî xirab de jî (hemî vexwendinên `is_less` rast vedigerin) em ê tenê herî zêde 1 bayt dawiya xwe derbas bikin.
                //        Operasyonek din a bêewlehî li vir dereferencing `elem` e.
                //        Lêbelê, `elem` di destpêkê de dawiya `1 *sizeof(T)` bû û me berî ku bigihîje wê bi `1* sizeof(T)` kêm kir.
                //        Zêdetir, hate îdîakirin ku `block_r` ji `BLOCK` kêmtir e û ji ber vê yekê herî zêde `elem` dê serê perçeyê nîşan bike.
                unsafe {
                    // Berawirdkirina bê şax
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Hejmara hêmanên ji rêzê ku di navbera milê çep û rast de biguherin.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Di şûna veguheztina yek cot di wê demê de, ew çêtir e ku meriv permutasyonek çerx pêk bîne.
            // Ev ne zor bi pevguhertinê re hevwate ye, lê encamek wekhev bi karanîna karûbarên bîranînê kêmtir bikar tîne.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Hemî hêmanên derveyî rêzê di bloka çepê de hatin veguheztin.Veguhere bloka din.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Hemî hêmanên derveyî rêzê di bloka rast de hatin veguheztin.Biçe bloka berê.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Ya ku niha dimîne herî zêde yek blokek e (an çep an rast) bi hêmanên ji rêzê yên ku hewce ne ku werin veguheztin.
    // Hêmanên weha yên mayî bi hêsanî dikarin di nav bloka wan de heya dawiyê werin veguheztin.
    //

    if start_l < end_l {
        // Bloka çepê dimîne.
        // Hêmanên wê yên ji rêzê yên mayî ber bi rastê rast ve bar bikin.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Astengiya rast dimîne.
        // Hêmanên wê yên ji rêzê yên mayî ber bi çepê dûr ve bikişînin.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Tiştek din tune ku were kirin, em xelas bûn.
        width(v.as_mut_ptr(), l)
    }
}

/// Dabeşên `v` li hêmanên ji `v[pivot]` piçûktir, li pey hêmanên ji `v[pivot]` mezintir an jî wekhev.
///
///
/// Pirjimarek vedigerîne:
///
/// 1. Hejmara hêmanên ji `v[pivot]` piçûktir.
/// 2. Rast e ku `v` jixwe hate dabeş kirin.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Pivotê di destpêka perçeyê de bicîh bikin.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Ji bo bandorkeriyê pivotê di nav guhêrbarek dabeşkirî de bixwînin.
        // Ger çalakiyek berawirdkirina panics ya jêrîn, dê pivot bixweber di nav perçeyê de were nivîsandin.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Yekem yekem hêmanên ji rêzê bibînin.
        let mut l = 0;
        let mut r = v.len();

        // EWLEH: : Bêserûberiya li jêr rêzek rêzikek vedihewîne.
        // Ji bo ya yekem: Em jixwe li vir bi `l < r` kontrolkirina sînoran dikin.
        // Ji bo ya duyemîn: Di destpêkê de `l == 0` û `r == v.len()` hene û me li her xebata nîşankirinê ew `l < r` kontrol kir.
        //                     Ji vir em dizanin ku divê `r` herî kêm `r == l` be ku ji ya yekê re derbasdar hate nîşandin.
        unsafe {
            // Yekem yekem ji pivotê mezintir an wekhev bibînin.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Hêmana paşîn piçûktir ku pivot bibînin.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` ji çarçova wê derdikeve û pivotê (ku guhêrbarek dabeşkirî ye) paşde dinivîse nav perçeya ku ew di destpêkê de bû.
        // Vê gav di dabînkirina ewlehiyê de krîtîk e!
        //
    };

    // Pivot di navbera her du partîsiyonan de bicîh bikin.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Dabeşên `v` li hêmanên wekhevî `v[pivot]` li pey hêmanên ji `v[pivot]` mezintir.
///
/// Hejmara hêmanên bi pivotê vedigere vedigerîne.
/// Tê texmîn kirin ku `v` hêmanên ji pivotê piçûktir nagire nav xwe.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Pivotê di destpêka perçeyê de bicîh bikin.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Ji bo bandorkeriyê pivotê di nav guhêrbarek dabeşkirî de bixwînin.
    // Ger çalakiyek berawirdkirina panics ya jêrîn, dê pivot bixweber di nav perçeyê de were nivîsandin.
    // EWLEHIYA: Nîşanek li vir derbasdar e ji ber ku ji referansa li ser perçeyek tê stendin.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Naha parçe parçe bike.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // EWLEH: : Bêserûberiya li jêr rêzek rêzikek vedihewîne.
        // Ji bo ya yekem: Em jixwe li vir bi `l < r` kontrolkirina sînoran dikin.
        // Ji bo ya duyemîn: Di destpêkê de `l == 0` û `r == v.len()` hene û me li her xebata nîşankirinê ew `l < r` kontrol kir.
        //                     Ji vir em dizanin ku divê `r` herî kêm `r == l` be ku ji ya yekê re derbasdar hate nîşandin.
        unsafe {
            // Hêmana yekem ji pivotê mezintir bibînin.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Hêmana paşîn a hevber pivotê bibînin.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Em qediyan?
            if l >= r {
                break;
            }

            // Hevoka dîtinê ya hêmanên ji rêzê biguhezînin.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Me hêmanên `l` wekhev pivot dît.1-ê zêde bikin ku ji bo pivot-ê xwe hesab bikin.
    l + 1

    // `_pivot_guard` ji çarçova wê derdikeve û pivotê (ku guhêrbarek dabeşkirî ye) paşde dinivîse nav perçeya ku ew di destpêkê de bû.
    // Vê gav di dabînkirina ewlehiyê de krîtîk e!
}

/// Hin hêmanên li derdorê belav dike û hewl dide ku şêweyên ku dibe sedema partîsiyonên bêhevseng di quicksort de bişikîne.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Jeneratorê jimara Pseudorandom ji kaxeza "Xorshift RNGs" ya George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Vê hejmarê modulo hejmarên çawalêhato bigirin.
        // Hejmar dikeve nav `usize` ji ber ku `len` ji `isize::MAX` ne mezintir e.
        let modulus = len.next_power_of_two();

        // Hin namzetên pivot dê li nêzê vê navnîşê bin.Ka em wana rast bikin.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Modulokek jimareyek bêhemdî `len` hilberînin.
            // Lêbelê, ji bo ku dev ji operasyonên lêçûnê bernedin em pêşiyê wê du qewetê modulo digirin, û dûv re bi `len` kêm dibin heya ku dikeve nav rêza `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` tête garantîkirin ku ji `2 * len` kêmtir be.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Heke xirroşk îhtîmal e ku berê hatibe dabeşkirin di `v` de pivotek hilbijêre û index û `true` vedigerîne.
///
/// Di pêvajoyê de dibe ku hêmanên `v` ji nû ve werin rêzkirin.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Dirêjahiya hindiktirîn ku hûn rêbaza navîn-ya-navîn hilbijêrin.
    // Pelên kurttir metoda sade-navîn-a-sê bikar tînin.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Di vê fonksiyonê de jimara herî zêde ya swapên ku dikarin werin kirin.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Sê indekesên ku em ê nêzîkê wan pivotek hilbijêrin.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Hejmara tevahî ya swapên ku em ê li ber bicîhkirina dema rêzkirina indeksan dihejmêrin.
    let mut swaps = 0;

    if len >= 8 {
        // Swêban diguheze da ku `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Swêban diguheze da ku `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Navînî ya `v[a - 1], v[a], v[a + 1]` dibîne û indexê di `a` de tomar dike.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Li taxên `a`, `b`, û `c` mediyan bibînin.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Di nav `a`, `b`, û `c` de navîn bibînin.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Hejmara swapên herî zêde hate kirin.
        // Chanhtimal heye ku perçek berjêr be an jî piranî berjêr be, ji ber vê yekê berevajîkirin dê bibe alîkar ku ew zûtir rêz bike.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// `v` paşverû rêz dike.
///
/// Heke di rêzeya orîjînal de pêşek hebû, ew wekî `pred` tête diyar kirin.
///
/// `limit` berî ku hûn li `heapsort` veguherînin hejmara partîsiyonên bêhevseng ên destûrkirî ye.
/// Heke sifir be, ev fonksiyon dê tavilê veguhere heapsortê.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Pelên heta vê dirêjahiyê bi karanîna navnîşkirina dabeşkirinê têne rêz kirin.
    const MAX_INSERTION: usize = 20;

    // Rast e ku dabeşkirina paşîn bi maqûl hevseng bû.
    let mut was_balanced = true;
    // Rast e heke dabeşkirina paşîn hêmanan nezeliqîne (perçe jixwe hate dabeş kirin).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Pelên pir kurt bi karanîna navnîşê têne navnîş kirin.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Heke pir hilbijartinên pivotê yên xerab hatibin kirin, ji bo ku `O(n * log(n))` rewşa herî xirab garantî bikin, bi hêsanî vegerin ser heapsortê.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Heke dabeşkirina paşîn nehevseng bû, bi tevlihevkirina hin hêmanên li der ve qalibên şikestinê biceribînin.
        // Bi hêviya ku em vê carê pivotek çêtir hilbijêrin.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Pivotek hilbijêrin û biceribînin ka dabeş ji berê ve hatî rêzkirî ye.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Heke dabeşkirina paşîn bi hêjayî hevseng bû û hêmanan neqeliqand, û heke hilbijartina pivot pêşbînî bike ku perçe dibe ku ji berê ve hatibe dabeş kirin ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Ceribandina çend hêmanên ji rêzê biceribînin û veguheztina wan bo rewşên rast.
            // Ger qurm bi dawî were ku bi tevahî were dabeş kirin, em xelas bûne.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Heke pivotê bijartî bi ya pêşîn re wekhev be, wê hingê ew ê di hêlê de hêmana herî piçûk e.
        // Parçe parçe dike nav hêmanên wekhev û hêmanên ji pivotê mezintir.
        // Ev doz bi gelemperî dema ku perçe gelek hêmanên dubare tê de tê xistin.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Rêzkirina hêmanên ji pivotê mezintir bidomînin.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Parçe parçe kirin.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Parçeyê nav `left`, `pivot`, û `right` parve bikin.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Tenê ji bo ku hûn tevahî bangên paşde vegerînin kêm bikin û cîhê stakê kêmtir bixwin vegerin alîyê kurtir.
        // Hingê tenê bi aliyek dirêjtir ve berdewam bikin (ev dişibe vegera dûvikê ye).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// `v` bi karanîna quicksort-a-têkbirinê, ku *O*(*n*\*log(* n*)) rewşa herî xirab e) rêz dike.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Sortkirin li ser celebên sifir-sized tevgerek watedar nîne.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Hejmara dabeşên nehevsengkirî heya `floor(log2(len)) + 1` sînor bikin.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Ji bo pelikên heya vê dirêjahiyê hêsantir e ku meriv bi hêsanî wan rêz bike.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Pivotek hilbijêrin
        let (pivot, _) = choose_pivot(v, is_less);

        // Heke pivotê bijartî bi ya pêşîn re wekhev be, wê hingê ew ê di hêlê de hêmana herî piçûk e.
        // Parçe parçe dike nav hêmanên wekhev û hêmanên ji pivotê mezintir.
        // Ev doz bi gelemperî dema ku perçe gelek hêmanên dubare tê de tê xistin.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Ger me indexa xwe derbas kiribe, wê hingê em baş in.
                if mid > index {
                    return;
                }

                // Wekî din, rêzkirina hêmanên ji pivotê mezintir bidomînin.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Parçeyê nav `left`, `pivot`, û `right` parve bikin.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Heke navîn==index, wê hingê em xelas bûn, ji ber ku partition() garantî kir ku hemî hêmanên piştî nîvê ji nîvê mezintir an wekhev in.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Sortkirin li ser celebên sifir-sized tevgerek watedar nîne.Tiştek nekin.
    } else if index == v.len() - 1 {
        // Hêmana maxê bibînin û di pozîsyona paşîn a array de bicîh bikin.
        // Em li vir azad in ku `unwrap()` bikar bînin ji ber ku em dizanin v divê vala nebe.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Hêmana min bibînin û di pozîsyona yekem a array de bicîh bikin.
        // Em li vir azad in ku `unwrap()` bikar bînin ji ber ku em dizanin v divê vala nebe.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}