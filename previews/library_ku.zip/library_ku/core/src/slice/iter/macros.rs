//! Makroyên ku ji hêla dûbarekerên perçeyê ve têne bikar anîn.

// Navnîşkirin_vala ye û len cûdahiyek mezin a performansê dike
macro_rules! is_empty {
    // Awayê ku em dirêjahiya vebêjerê ZST şîfre dikin, ev hem ji bo ZST û ne-ZST dixebite.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Ji bo ku em ji hin kontrolên sînoran xilas bibin (li `position` binihêrin), em dirêjahiyê bi rengek hinekî çaverêkirî dihejmêrin.
// (Ji hêla `kodagen/pêl-pozîsyon-sînor-kontrol` ve hatî ceribandin.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // em carinan di nav blokek ne ewle de têne bikar anîn

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Ev _cannot_ `unchecked_sub` bikar tîne ji ber ku em bi pêça ve girêdayî ne ku dirêjahiya veberhênerên dirêj ên ZST-ê temsîl dikin.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Em dizanin ku `start <= end`, ji ber vê yekê dikare ji `offset_from` çêtir bike, ku hewce ye ku bi îmzekirî re têkilî dayne.
            // Bi danîna alayên guncan li vir em dikarin vê yekê ji LLVM re vebêjin, ku alîkariya wê dike ku venêranên sînoran derxîne.
            // EWLEH: Ji hêla celebê neguhêzbar ve, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Di heman demê de ji LLVM re vegotin ku nîşangir ji hêla pirjimarek rastîn a celebê veqetandî ne, ew dikare `len() == 0` li şûna `(end - start) < size` baştir bike `start == end`.
            //
            // EWLEH: Ji hêla tîpa neguhêzbar ve, nîşanker bi vî rengî têne rêz kirin
            //         mesafeya di navbêna wan de gerek pirjimara mezinahiya pointee be
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Danasîna hevpar a tekrarkerên `Iter` û `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Hêmana yekem vedigerîne û destpêka iteratorê bi 1-ê ber bi pêş ve dibe.
        // Li gorî fonksiyonek xêzkirî performansê pir baştir dike.
        // Pêdivî ye ku iterator vala nebe.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Hêmana paşîn vedigerîne û dawiya iteratorê bi 1-ê paşde vedigire.
        // Li gorî fonksiyonek xêzkirî performansê pir baştir dike.
        // Pêdivî ye ku iterator vala nebe.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Dema ku T ZST ye, bi veguheztina dawiya iteratorê bi paş ve bi `n`, iteratorê piçûk dike.
        // `n` divê ji `self.len()` derbas nebe.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Fonksiyona alîkar ji bo afirandina dirûvek ji iterator.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // SAFETY: iterator ji perçeyek bi pointer ve hate afirandin
                // `self.ptr` û dirêjî `len!(self)`.
                // Ev garantî dike ku hemî mercên pêşîn ên `from_raw_parts` têne bicîh kirin.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Fonksiyona alîkar ji bo veguheztina destpêka iteratorê ji hêla hêmanên `offset` ve, vegera destpêka kevn.
            //
            // Ne ewledar e ji ber ku pêdivî ye ku veqetandin ji `self.len()` derbas nebe.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // EWLEH: : bangker garantî dike ku `offset` ji `self.len()` derbas nabe,
                    // ji ber vê yekê ev pêşnumayê nû di hundurê `self` de ye û bi vî rengî garantî dibe ku ne-pûç be.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Fonksiyona alîkar ji bo veguheztina dawiya iteratorê ji hêla hêmanên `offset` ve paşve, vegera dawiya nû.
            //
            // Ne ewledar e ji ber ku pêdivî ye ku veqetandin ji `self.len()` derbas nebe.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // EWLEH: : bangker garantî dike ku `offset` ji `self.len()` derbas nabe,
                    // ku tête garantîkirin ku ji `isize`-ê re zêde nabe.
                    // Di heman demê de, nîşanderê encam di sînorên `slice` de ye, ku hewceyên din ên ji bo `offset` pêk tîne.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // dikare bi sliceyan were pêkanîn, lê ev ji venêrana sînoran dûr dikeve

                // EWLEH: : Bangên `assume` ji nîşanderê destpêkirina perçek ewle ne
                // Divê ne-null be, û perçeyên li ser ne-ZST-ê jî divê nîşanderê dawiya ne-null hebe.
                // Banga `next_unchecked!` ewledar e ji ber ku em kontrol dikin ka pêşiyê iterator vala ye an na.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Ev iterator niha vala ye.
                    if mem::size_of::<T>() == 0 {
                        // Em neçar in ku vî rengî bikin ji ber ku dibe ku `ptr` carî nebe 0, lê `end` dibe (ji ber pêçandinê).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // EWLEHIYA: end ne be 0 heke T ne ZST be ji ber ku ptr ne 0 ye û dawîn>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // EWLEH: : Em di nav sînoran de ne.`post_inc_start` ji bo ZSTs jî tiştê rast dike.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Em ji pêkanîna pêşkeftî, ya ku `try_fold` bikar tîne, paşguh bikin, ji ber ku ev pêkanîna hêsan LLVM IR kêmtir çêdike û berhevkirina zûtir e.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Em ji pêkanîna pêşkeftî, ya ku `try_fold` bikar tîne, paşguh bikin, ji ber ku ev pêkanîna hêsan LLVM IR kêmtir çêdike û berhevkirina zûtir e.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Em ji pêkanîna pêşkeftî, ya ku `try_fold` bikar tîne, paşguh bikin, ji ber ku ev pêkanîna hêsan LLVM IR kêmtir çêdike û berhevkirina zûtir e.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Em ji pêkanîna pêşkeftî, ya ku `try_fold` bikar tîne, paşguh bikin, ji ber ku ev pêkanîna hêsan LLVM IR kêmtir çêdike û berhevkirina zûtir e.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Em ji pêkanîna pêşkeftî, ya ku `try_fold` bikar tîne, paşguh bikin, ji ber ku ev pêkanîna hêsan LLVM IR kêmtir çêdike û berhevkirina zûtir e.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Em ji pêkanîna pêşkeftî, ya ku `try_fold` bikar tîne, paşguh bikin, ji ber ku ev pêkanîna hêsan LLVM IR kêmtir çêdike û berhevkirina zûtir e.
            // Her weha, `assume` ji venêrana sînoran dûr dikeve.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // EWLEHIYA: em garantî ne ku ji hêla xeletiya negirêdayî ve di nav sînoran de bin:
                        // dema `i >= n`, `self.next()` `None` vedigerîne û xelek davêje.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Em ji pêkanîna pêşkeftî, ya ku `try_fold` bikar tîne, paşguh bikin, ji ber ku ev pêkanîna hêsan LLVM IR kêmtir çêdike û berhevkirina zûtir e.
            // Her weha, `assume` ji venêrana sînoran dûr dikeve.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // EWLEH: : Divê `i` ji `n` kêmtir be ji ber ku li `n` dest pê dike
                        // û tenê kêm dibe.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // EWLEHIY: : divê bangker garantî bike ku `i` di sînoran de ye
                // pişka bingehîn, ji ber vê yekê `i` nikare `isize` zêde bike, û referansên vegerandin garantî ye ku ji hêmanek perçeyê re tê gotin û bi vî rengî tête derbasdar kirin.
                //
                // Di heman demê de not bikin ku bangvan jî garantî dike ku em carek din bi heman navnîşê nayên gazîkirin, û ku ji ti rêbazên din ên ku dê bigihîjin vê binkomê nayên gazîkirin, ji ber vê yekê ew ji bo referansa vegerî derbasdar e ku di rewşa
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // dikare bi sliceyan were pêkanîn, lê ev ji venêrana sînoran dûr dikeve

                // EWLEH: bangên `assume` ewledar in ji ber ku pêşnumayê destpêkirina perçeyek pêdivî ye ku pûç be,
                // û perçeyên li ser ne-ZST-ê jî pêdivî ye ku nîşana dawiya ne-null hebe.
                // Banga `next_back_unchecked!` ewledar e ji ber ku em kontrol dikin ka pêşiyê iterator vala ye an na.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Ev iterator niha vala ye.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // EWLEH: : Em di nav sînoran de ne.`pre_dec_end` ji bo ZSTs jî tiştê rast dike.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}