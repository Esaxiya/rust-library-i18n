// ignore-tidy-filelength

//! Birêvebirin û manîpulasyona slice.
//!
//! Ji bo bêtir agahdarî li [`std::slice`] binihêrin.
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Pêkanîna memureya safî rust, ji rust-memchr hatiye girtin
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Ev fonksiyon tenê gelemperî ye ji ber ku çu rêyek din tune ku heapsorta testê ya yekîneyê hebe.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Hejmara hêmanên di perçeyê de vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // EWLEH: dengê saxlem e ji ber ku em qada dirêjahiyê wekî karanînek veguherînin (ya ku ew pêdivî ye)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // EWLEH: : ev ewledar e ji ber ku `&[T]` û `FatPtr<T>` xwedan heman verastkirinê ne.
            // Tenê `std` dikare vê garantiyê bike.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Dema ku ew domdar-stabîl be, bi `crate::ptr::metadata(self)`-ê veguherînin.
            // Ji ber vê nivîsandinê ev dibe sedema xeletiyek "Const-stable functions can only call other const-stable functions".
            //

            // EWLEH: : Ji gihîştina nirxa ji yekîtiya `PtrRepr` ji ber ku * const T ewle ye
            // û PtrComponents<T>heman rêzikên bîranînê hene.
            // Tenê std dikare vê garantiyê bike.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Ger dirêjahiya 0 perçeyê `true` vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Hêmana yekem a perçeyê, an `None` ger vala be vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Nîşanek guhêrbar vedigere ser hêmana yekem a perçeyê, an heke V00X vala be `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Yekem û hemî hêmanên mayî yên perçeyê, an jî `None` ger vala be vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Yekem û hemî hêmanên mayî yên perçeyê, an jî `None` ger vala be vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Hêmanên paşîn û hemî yên mayî yên perçeyê, an jî `None` ger vala be vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Hêmanên paşîn û hemî yên mayî yên perçeyê, an jî `None` ger vala be vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Hêmana paşîn a perçeyê, an jî `None` heke vala be vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Nîşanek guhêrbar vedigerîne ser tişta dawî ya li perçeyê.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Li gorî celebê endeksê referansekê vedigerîne elementek an jêrîn.
    ///
    /// - Ger pozîsyonek were dayîn, referansek li hêmana li wê pozîsyonê an `None` ger ji sînor nebe vedigerîne.
    ///
    /// - Ger rêzek were dayîn, abona ku li gorî wê rêzê ye, an jî `None` heke ji sînor be, vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Li gorî celebê navnîşê vegerînek guhêrbar li hêmanek an jêrînek vedigerîne (heke hejmar derveyî sînoran be [`get`] binihêre) an `None`.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Bêyî ku kontrola sînoran bike, referansekê li hêmanek an jêrîn vedigerîne.
    ///
    /// Ji bo alternatîfek ewle [`get`] binihêrin.
    ///
    /// # Safety
    ///
    /// Bangkirina vê rêbazê bi navnîşek derveyî sînoran *[tevgera nediyarkirî]* e jî ku referansa encam neyê bikar anîn.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // EWLEH: Y::bangker divê pir hewceyên ewlehiyê yên `get_unchecked` biparêze;
        // perçe dereferencable ye ji ber ku `self` referansek ewledar e.
        // Nîşaneya vegeriyayî ewle ye ji ber ku impls of `SliceIndex` mecbûr in garantî bikin ku ew e.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Bêyî ku kontrola sînoran bike, referansa guherbar li hêmanek an jêrînek vedigerîne.
    ///
    /// Ji bo alternatîfek ewle [`get_mut`] binihêrin.
    ///
    /// # Safety
    ///
    /// Bangkirina vê rêbazê bi navnîşek derveyî sînoran *[tevgera nediyarkirî]* e jî ku referansa encam neyê bikar anîn.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // EWLEHIY: : bangker divê hewceyên ewlehiyê yên `get_unchecked_mut` biparêze;
        // perçe dereferencable ye ji ber ku `self` referansek ewledar e.
        // Nîşaneya vegeriyayî ewle ye ji ber ku impls of `SliceIndex` mecbûr in garantî bikin ku ew e.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Pointerek raweyî vedigerîne tampona perçeyê.
    ///
    /// Divê bangker pê ewle bine ku qurmê nîşanderê ku ev fonksiyon vedigere zindîtir e, an na ew ê dawî bibe û nîşana çopê bide.
    ///
    /// Her weha bangker divê piştrast bike ku bîra ku nîşana (non-transitively) nîşan dide qet neyê nivîsandin (ji xeynî hundurê `UnsafeCell`) bi karanîna vê pointer an jî nîşanderê ku jê tê der.
    /// Heke hûn hewce ne ku naveroka perçeyê mutas bikin, [`as_mut_ptr`] bikar bînin.
    ///
    /// Guhertina konteynirê ku ji hêla vê perçeyê ve hatî referans kirin dibe ku bibe sedem ku tampona wê ji nû ve were veqetandin, ku ev jî dê nîşanên wê nederbasdar be.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Nîşanek guhêrbar a ewledar vegerîne tampona perçeyê.
    ///
    /// Divê bangker pê ewle bine ku qurmê nîşanderê ku ev fonksiyon vedigere zindîtir e, an na ew ê dawî bibe û nîşana çopê bide.
    ///
    /// Guhertina konteynirê ku ji hêla vê perçeyê ve hatî referans kirin dibe ku bibe sedem ku tampona wê ji nû ve were veqetandin, ku ev jî dê nîşanên wê nederbasdar be.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Du nîşanên xav ên ku perçe perçe dikin vedigerîne.
    ///
    /// Rêjeya vegerandî nîv-vekirî ye, ku tê vê wateyê ku nîşangirê daviyê *yek berê* hêmana dawî ya qurmê nîşan dike.
    /// Bi vî rengî, perçek vala ji hêla du nîşanên wekhev ve tê temsîl kirin, û cûdahiya di navbera her du nîşangiran de mezinahiya perçeyê temsîl dike.
    ///
    /// Ji bo hişyariyên li ser karanîna van nîşangiran li [`as_ptr`] binêrin.Nîqaşa dawîn hewceyê hişyariyek zêde ye, ji ber ku ew li ser hêmanek derbasdar nîşan nade.
    ///
    /// Ev fonksiyon ji bo têkiliya bi navgîniyên biyanî yên ku du nîşangiran bikar tînin ku ji bo bîhnfirehiya hêmanên bîranînê bikar bînin, wekî ku di C++ de hevpar e, bikêr e.
    ///
    ///
    /// Dibe ku kêrhatî be ku hûn kontrol bikin gelo pêşnumayek hêmanê behsa hêmanek vê qurmê dike:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // BELAW: : Li vir `add` ewledar e, ji ber ku:
        //
        //   - Herdu nîşangir beşek ji yek tişti ne, ji ber ku nîşankirina rasterast ya borî jî jimartiye.
        //
        //   - Mezinahiya perçê ji isize::MAX byte qet mezintir nine, wekî ku li vir hatî diyar kirin:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Li dorpêçandî dorpêçandî tune, ji ber ku perçe dawiya qada navnîşanê naşewitînin.
        //
        // Belgekirinên pointer::add bibînin.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Du nîşanên guhêrbar ên ewledar ên ku perçe perçe dike vedigerîne.
    ///
    /// Rêjeya vegerandî nîv-vekirî ye, ku tê vê wateyê ku nîşangirê daviyê *yek berê* hêmana dawî ya qurmê nîşan dike.
    /// Bi vî rengî, perçek vala ji hêla du nîşanên wekhev ve tê temsîl kirin, û cûdahiya di navbera her du nîşangiran de mezinahiya perçeyê temsîl dike.
    ///
    /// Ji bo hişyariyên li ser karanîna van nîşangiran li [`as_mut_ptr`] binêrin.
    /// Nîqaşa dawîn hewceyê hişyariyek zêde ye, ji ber ku ew li ser hêmanek derbasdar nîşan nade.
    ///
    /// Ev fonksiyon ji bo têkiliya bi navgîniyên biyanî yên ku du nîşangiran bikar tînin ku ji bo bîhnfirehiya hêmanên bîranînê bikar bînin, wekî ku di C++ de hevpar e, bikêr e.
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // EWLET: Li jor as_ptr_range() binihêrin ka çima `add` li vir ewledar e.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Di hêlê de du hêmanan vedigire.
    ///
    /// # Arguments
    ///
    /// * a, Indeksa hêmana yekem
    /// * b, Indeksa hêmana duyemîn
    ///
    /// # Panics
    ///
    /// Panics heke `a` an `b` ji sînor dernekeve.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Nikarin du krediyên guhêrbar ji yek vector bistînin, ji ber vê yekê li şûna wan nîşangirên rawe bikar bînin.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // BELAW: : `pa` û `pb` ji referansên guhêrbar ên ewle hatine afirandin û referans dikin
        // ji hêmanên di perçeyê de û ji ber vê yekê têne garantîkirin ku derbasdar û rêzkirî ne.
        // Zanibe ku gihîştina hêmanên li pişt `a` û `b` tê kontrol kirin û dema ku ji sînor dernakeve dê panic be.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Rêza hêmanên di perçeyê de, di cîh de berevajî dike.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Ji bo celebên pir piçûk, hemî kes di rêwîtiya normal de dixwîne kêm xirab dike.
        // Em dikarin çêtir bikin, ji hêla load/store veneguhêzbar ve efektîv, bi barkirina perçek mezintir û vegerandina tomarek.
        //

        // Bi îdeal LLVM dê vê yekê ji bo me bike, ji ber ku ew ji me çêtir dizane ka xwendinên bêserûber karîger in (ji ber ku ew di navbera guhertoyên cuda yên ARM-ê de diguhere, ji bo nimûne) û mezinahiya perçeyê ya çêtirîn dê çi be.
        // Mixabin, ji hêla LLVM 4.0 (2017-05) ve ew tenê xelek vedike, ji ber vê yekê em hewce ne ku vê yekê bixwe bikin.
        // (Hîpotez: berevajî pirsgirêkdar e ji ber ku alî dikarin bi rengek hevûdu werin rêz kirin-dê bibe, dema ku dirêjahî xerîb be-ji ber vê yekê çu rê tune ku em pêş-û paşpirtikan biweşînin ku di navîn de SIMD-a bi tevahî bi kar bînin.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // llvm.bswap navxweyî bikar bînin ku u8-an di nav karanînê de paşde vegerînin
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // BELAW: Li vir gelek tişt hene ku werin kontrol kirin:
                //
                // - Zanibe ku `chunk` ji ber cfg kontrola li jor an 4 an 8 e.Ji ber vê yekê `chunk - 1` erênî ye.
                // - Sermasekirin bi navnîşa `i` re baş e lewra ku kontrola loopê garantî dike
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Navnîşkirina bi navnîşa `ln - i - chunk = ln - (i + chunk)` baş e:
                //   - `i + chunk > 0` trivial rast e.
                //   - Check loop garantî dike:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, bi vî awayî veqetandin ji binî venagere.
                // - Bangên `read_unaligned` û `write_unaligned` baş in:
                //   - `pa` xalên nîşana `i` li ku `i < ln / 2 - (chunk - 1)` (li jor binihêrin) û `pb` xalên nîşankirina `ln - i - chunk`, lewma her du jî bi kêmanî `chunk` gelek byte ji dawiya `self` dûr in.
                //
                //   - Bîra destpêkirî `usize` derbasdar e.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Rotary-by-16 bikar bînin da ku u16-an di u32 de berevajî bikin
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // EWLEH: : u32 a nevekirî eger `i + 1 < ln` ji `i` were xwendin
                // (û eşkere `i < ln`), ji ber ku her element 2 bayt e û em 4 dixwînin.
                //
                // `i + chunk - 1 < ln / 2` # while condition
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Ji ber ku ew ji dirêjahiya bi 2 parvekirî kêmtir e, wê hingê divê ew di nav sînoran de be.
                //
                // Ev di heman demê de tê vê wateyê ku rewşa `0 < i + chunk <= ln` her gav tê rêz kirin, piştrastkirin ku pêşnumaya `pb` dikare bi ewlehî were bikar anîn.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // EWLEH: : `i` ji nîvê dirêjahiya perçeyê kêmtir e lewma
            // gihîştina `i` û `ln - i - 1` ewledar e (`i` ji 0 dest pê dike û ji `ln / 2 - 1` wêdetir naçe).
            // Ji ber vê yekê nîşangirên `pa` û `pb` derbasdar û rêzkirî ne, û dikarin ji wan re werin xwendin û nivîsandin.
            //
            //
            unsafe {
                // Swapek ne ewle da ku li swapa ewledar venêrana sînoran.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Itteratorek li ser perçe vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Iteratorê vedigerîne ku destûrê dide guhertina her nirxê.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Iterator li ser hemî windows bi dirêjahiya `size` vedigerîne.
    /// windows li hev dikeve.
    /// Heke perçeyek ji `size` kurttir e, veberhêner tu nirxan venagerîne.
    ///
    /// # Panics
    ///
    /// Panics heke `size` 0 be.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Heke pel ji `size` kurttir e:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Carek îteratorek vedigerîne ser hêmanên `chunk_size` yên perçeyê, ji destpêka pelikê dest pê dike.
    ///
    /// Çeqel pişk in û li hev nakin.Ger `chunk_size` dirêjahiya perçeyê parve neke, wê hingê dê perçeyê paşîn dirêjahiya `chunk_size` tune.
    ///
    /// [`chunks_exact`] binihêrin ji bo guhertoyek vê iteratorê ku perçeyên her gav bi rastî hêmanên `chunk_size` vedigerîne, û [`rchunks`] jî ji bo heman iterator lê vedigere li dawiya perçeyê.
    ///
    ///
    /// # Panics
    ///
    /// Panics heke `chunk_size` 0 be.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Carek îteratorek vedigerîne ser hêmanên `chunk_size` yên perçeyê, ji destpêka pelikê dest pê dike.
    ///
    /// Dabeş perçeyên guhêrbar in, û li hev nakin.Ger `chunk_size` dirêjahiya perçeyê parve neke, wê hingê dê perçeyê paşîn dirêjahiya `chunk_size` tune.
    ///
    /// [`chunks_exact_mut`] binihêrin ji bo guhertoyek vê iteratorê ku perçeyên her gav bi rastî hêmanên `chunk_size` vedigerîne, û [`rchunks_mut`] jî ji bo heman iterator lê vedigere li dawiya perçeyê.
    ///
    ///
    /// # Panics
    ///
    /// Panics heke `chunk_size` 0 be.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Carek îteratorek vedigerîne ser hêmanên `chunk_size` yên perçeyê, ji destpêka pelikê dest pê dike.
    ///
    /// Çeqel pişk in û li hev nakin.
    /// Heke `chunk_size` dirêjahiya perçeyê parve neke, wê hingê hêmanên herî paşîn ê `chunk_size-1` dê werin jêbirin û ji fonksiyona `remainder` a iterator werin vegerandin.
    ///
    ///
    /// Ji ber ku her perçeyek xwedan hêmanên `chunk_size` e, berhevkar dikare timûtim koda encam ji ya [`chunks`] çêtir çêtir bike.
    ///
    /// [`chunks`] binihêrin ji bo guhertoyek vê iteratorê ku mayî jî wekî perçeyek piçûktir vedigerîne, û [`rchunks_exact`] ji bo heman iterator lê di dawiya perçeyê de dest pê dike.
    ///
    /// # Panics
    ///
    /// Panics heke `chunk_size` 0 be.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Carek îteratorek vedigerîne ser hêmanên `chunk_size` yên perçeyê, ji destpêka pelikê dest pê dike.
    ///
    /// Dabeş perçeyên guhêrbar in, û li hev nakin.
    /// Heke `chunk_size` dirêjahiya perçeyê parve neke, wê hingê hêmanên herî paşîn ê `chunk_size-1` dê werin jêbirin û ji fonksiyona `into_remainder` a iterator werin vegerandin.
    ///
    ///
    /// Ji ber ku her perçeyek xwedan hêmanên `chunk_size` e, berhevkar dikare timûtim koda encam ji ya [`chunks_mut`] çêtir çêtir bike.
    ///
    /// [`chunks_mut`] binihêrin ji bo guhertoyek vê iteratorê ku mayî jî wekî perçeyek piçûktir vedigerîne, û [`rchunks_exact_mut`] ji bo heman iterator lê di dawiya perçeyê de dest pê dike.
    ///
    /// # Panics
    ///
    /// Panics heke `chunk_size` 0 be.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Firçeyê li ser rêzika rêzikên `N`-êlêmêntê dabeş dike, bihesibînin ku mayînek tune.
    ///
    ///
    /// # Safety
    ///
    /// Dibe ku ev tenê dema ku were bang kirin
    /// - Firqeyek tam di nav deçikên hêmana `N` dabeş dibe (ango `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // EWLEHIY: : Dabeşên 1-êlêmêntî carî ne mayî ne
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // EWLEH: : Dirêjahiya perçê (6) pirjimara 3-ê ye
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Dê vana bê deng bin:
    /// // bila perçe bikin: &[[_;5]]= slice.as_chunks_unchecked()//Dirêjahiya perçeyê ne pirjimara 5 beşên bila ye:&[[_;0]]= slice.as_chunks_unchecked()//Cûreyên dirêjahiya sifir qet nahêlin
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // BELAW: : Pêşniyara me ya ku hewce ye ku meriv vê bang bike hewce ye
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // EWLEH: Me perçek hêmanên `new_len * N` avêt nav
        // perçeyek `new_len` gelek perçeyên hêmanên `N`.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Pelê li pariyek rêzikên `N`-êlêmêntê dabeş dike, ku di despêka perçeyê de dest pê dike, û perçeyek mayî bi dirêjahiya wê ji `N` kêmtir.
    ///
    ///
    /// # Panics
    ///
    /// Panics heke `N` 0. be ev venêran dê bi îhtîmaleke mezin bi xeletiyek dema berhevokê re biguheze berî ku ev rêbaz sabit bibe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // EWLEH: Me berê ji bo sifir panîk kir, û ji hêla avahiyê ve hate misoger kirin
        // ku dirêjahiya jêrzemînê pirjimara N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Pelê li pariyek rêzikên `N`-êlêmêntê dabeş dike, ku di dawiya perçeyê de dest pê dike, û perçek mayî bi dirêjahiya wê ji `N` kêmtir.
    ///
    ///
    /// # Panics
    ///
    /// Panics heke `N` 0. be ev venêran dê bi îhtîmaleke mezin bi xeletiyek dema berhevokê re biguheze berî ku ev rêbaz sabit bibe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // EWLEH: Me berê ji bo sifir panîk kir, û ji hêla avahiyê ve hate misoger kirin
        // ku dirêjahiya jêrzemînê pirjimara N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Carek îteratorek vedigerîne ser hêmanên `N` yên perçeyê, ji destpêka pelikê dest pê dike.
    ///
    /// Dabeş referansên array ne û li hev nakin.
    /// Heke `N` dirêjahiya perçeyê parve neke, wê hingê hêmanên herî paşîn ê `N-1` dê werin jêbirin û ji fonksiyona `remainder` a iterator werin vegerandin.
    ///
    ///
    /// Ev rêbaz hevkêşeya bingehîn a [`chunks_exact`] e.
    ///
    /// # Panics
    ///
    /// Panics heke `N` 0. be ev venêran dê bi îhtîmaleke mezin bi xeletiyek dema berhevokê re biguheze berî ku ev rêbaz sabit bibe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Firçeyê li ser rêzika rêzikên `N`-êlêmêntê dabeş dike, bihesibînin ku mayînek tune.
    ///
    ///
    /// # Safety
    ///
    /// Dibe ku ev tenê dema ku were bang kirin
    /// - Firqeyek tam di nav deçikên hêmana `N` dabeş dibe (ango `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // EWLEHIY: : Dabeşên 1-êlêmêntî carî ne mayî ne
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // EWLEH: : Dirêjahiya perçê (6) pirjimara 3-ê ye
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Dê vana bê deng bin:
    /// // bila perçe bikin: &[[_;5]]= slice.as_chunks_unchecked_mut()//Dirêjahiya perçeyê ne pirjimara 5 beşên bila ye:&[[_;0]]= slice.as_chunks_unchecked_mut()//Cûreyên dirêjahiya sifir qet nahêlin
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // BELAW: : Pêşniyara me ya ku hewce ye ku meriv vê bang bike hewce ye
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // EWLEH: Me perçek hêmanên `new_len * N` avêt nav
        // perçeyek `new_len` gelek perçeyên hêmanên `N`.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Pelê li pariyek rêzikên `N`-êlêmêntê dabeş dike, ku di despêka perçeyê de dest pê dike, û perçeyek mayî bi dirêjahiya wê ji `N` kêmtir.
    ///
    ///
    /// # Panics
    ///
    /// Panics heke `N` 0. be ev venêran dê bi îhtîmaleke mezin bi xeletiyek dema berhevokê re biguheze berî ku ev rêbaz sabit bibe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // EWLEH: Me berê ji bo sifir panîk kir, û ji hêla avahiyê ve hate misoger kirin
        // ku dirêjahiya jêrzemînê pirjimara N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Pelê li pariyek rêzikên `N`-êlêmêntê dabeş dike, ku di dawiya perçeyê de dest pê dike, û perçek mayî bi dirêjahiya wê ji `N` kêmtir.
    ///
    ///
    /// # Panics
    ///
    /// Panics heke `N` 0. be ev venêran dê bi îhtîmaleke mezin bi xeletiyek dema berhevokê re biguheze berî ku ev rêbaz sabit bibe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // EWLEH: Me berê ji bo sifir panîk kir, û ji hêla avahiyê ve hate misoger kirin
        // ku dirêjahiya jêrzemînê pirjimara N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Carek îteratorek vedigerîne ser hêmanên `N` yên perçeyê, ji destpêka pelikê dest pê dike.
    ///
    /// Dabeş referansên array yên guherbar in û li hev nakin.
    /// Heke `N` dirêjahiya perçeyê parve neke, wê hingê hêmanên herî paşîn ê `N-1` dê werin jêbirin û ji fonksiyona `into_remainder` a iterator werin vegerandin.
    ///
    ///
    /// Ev rêbaz hevkêşeya bingehîn a [`chunks_exact_mut`] e.
    ///
    /// # Panics
    ///
    /// Panics heke `N` 0. be ev venêran dê bi îhtîmaleke mezin bi xeletiyek dema berhevokê re biguheze berî ku ev rêbaz sabit bibe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Iterator li ser windows ya hêmanên `N` ya perçek li hevûdu vedigerîne, ji destpêka pelê dest pê dike.
    ///
    ///
    /// Ev hevkêşeya bingehîn a [`windows`] e.
    ///
    /// Ger `N` ji mezinahiya perçeyê mezintir be, ew ê windows venegerîne.
    ///
    /// # Panics
    ///
    /// Panics heke `N` 0 be.
    /// Ev venêran dê bi îhtîmalek mezin berî xeletiyek dema berhevokê were guhertin berî ku ev rêbaz sabît bibe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Carek îteratorek vedigerîne ser hêmanên `chunk_size` yên perçeyê, ku di dawiya perçeyê de dest pê dike.
    ///
    /// Çeqel pişk in û li hev nakin.Ger `chunk_size` dirêjahiya perçeyê parve neke, wê hingê dê perçeyê paşîn dirêjahiya `chunk_size` tune.
    ///
    /// [`rchunks_exact`] binihêrin ji bo guhertoyek vê iteratorê ku perçeyên her gav bi rastî hêmanên `chunk_size` vedigerîne, û [`chunks`] jî ji bo heman iterator lê vedigere di destpêka perçeyê de.
    ///
    ///
    /// # Panics
    ///
    /// Panics heke `chunk_size` 0 be.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Carek îteratorek vedigerîne ser hêmanên `chunk_size` yên perçeyê, ku di dawiya perçeyê de dest pê dike.
    ///
    /// Dabeş perçeyên guhêrbar in, û li hev nakin.Ger `chunk_size` dirêjahiya perçeyê parve neke, wê hingê dê perçeyê paşîn dirêjahiya `chunk_size` tune.
    ///
    /// [`rchunks_exact_mut`] binihêrin ji bo guhertoyek vê iteratorê ku perçeyên her gav bi rastî hêmanên `chunk_size` vedigerîne, û [`chunks_mut`] jî ji bo heman iterator lê vedigere di destpêka perçeyê de.
    ///
    ///
    /// # Panics
    ///
    /// Panics heke `chunk_size` 0 be.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Carek îteratorek vedigerîne ser hêmanên `chunk_size` yên perçeyê, ku di dawiya perçeyê de dest pê dike.
    ///
    /// Çeqel pişk in û li hev nakin.
    /// Heke `chunk_size` dirêjahiya perçeyê parve neke, wê hingê hêmanên herî paşîn ê `chunk_size-1` dê werin jêbirin û ji fonksiyona `remainder` a iterator werin vegerandin.
    ///
    /// Ji ber ku her perçeyek xwedan hêmanên `chunk_size` e, berhevkar dikare timûtim koda encam ji ya [`chunks`] çêtir çêtir bike.
    ///
    /// [`rchunks`] binihêrin ji bo guhertoyek vê iteratorê ku mayî jî wekî pişkek piçûktir vedigerîne, û [`chunks_exact`] ji bo heman iterator lê di destpêka pelikê de dest pê dike.
    ///
    ///
    /// # Panics
    ///
    /// Panics heke `chunk_size` 0 be.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Carek îteratorek vedigerîne ser hêmanên `chunk_size` yên perçeyê, ku di dawiya perçeyê de dest pê dike.
    ///
    /// Dabeş perçeyên guhêrbar in, û li hev nakin.
    /// Heke `chunk_size` dirêjahiya perçeyê parve neke, wê hingê hêmanên herî paşîn ê `chunk_size-1` dê werin jêbirin û ji fonksiyona `into_remainder` a iterator werin vegerandin.
    ///
    /// Ji ber ku her perçeyek xwedan hêmanên `chunk_size` e, berhevkar dikare timûtim koda encam ji ya [`chunks_mut`] çêtir çêtir bike.
    ///
    /// [`rchunks_mut`] binihêrin ji bo guhertoyek vê iteratorê ku mayî jî wekî pişkek piçûktir vedigerîne, û [`chunks_exact_mut`] ji bo heman iterator lê di destpêka pelikê de dest pê dike.
    ///
    ///
    /// # Panics
    ///
    /// Panics heke `chunk_size` 0 be.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Iterator li ser perçeyê vedigerîne ku hilberên ne-lihevhatî yên hêmanan bi kar tîne ji bo veqetandina wan.
    ///
    /// Pêşgir li du hêmanên li pey xwe tê vexwendin, ev tê vê wateyê ku pêşîn li `slice[0]` û `slice[1]` paşê li `slice[1]` û `slice[2]` û hwd.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ev rêbaz dikare were bikar anîn ku jêderkên dabeşkirî werin derxistin:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Iterator li ser perçeyê vedigerîne ku hilberên neguhurbar ên guherbar ên hêmanan bi kar tîne ji bo veqetandina wan.
    ///
    /// Pêşgir li du hêmanên li pey xwe tê vexwendin, ev tê vê wateyê ku pêşîn li `slice[0]` û `slice[1]` paşê li `slice[1]` û `slice[2]` û hwd.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ev rêbaz dikare were bikar anîn ku jêderkên dabeşkirî werin derxistin:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Li ser endeksekê perçeyekê dike du par.
    ///
    /// Ya yekem dê hemî nîşanên ji `[0, mid)` vehewîne (ji navnîşana `mid` xwe veqetîne) û ya duyemîn jî dê hemî nîşanekan ji `[mid, len)` vehewîne (ji navnîşana `len` bixwe ve nebe).
    ///
    ///
    /// # Panics
    ///
    /// Panics heke `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // EWLEH: : `[ptr; mid]` û `[mid; len]` di hundurê `self` de ne, ku
        // pêdiviyên `from_raw_parts_mut` pêk tîne.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Qertalek mutabilek li ser indexekî dabeş dike du.
    ///
    /// Ya yekem dê hemî nîşanên ji `[0, mid)` vehewîne (ji navnîşana `mid` xwe veqetîne) û ya duyemîn jî dê hemî nîşanekan ji `[mid, len)` vehewîne (ji navnîşana `len` bixwe ve nebe).
    ///
    ///
    /// # Panics
    ///
    /// Panics heke `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // EWLEH: : `[ptr; mid]` û `[mid; len]` di hundurê `self` de ne, ku
        // pêdiviyên `from_raw_parts_mut` pêk tîne.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Bêyî ku kontrola sînoran bike, li ser indexekî qatek dibe du parçe.
    ///
    /// Ya yekem dê hemî nîşanên ji `[0, mid)` vehewîne (ji navnîşana `mid` xwe veqetîne) û ya duyemîn jî dê hemî nîşanekan ji `[mid, len)` vehewîne (ji navnîşana `len` bixwe ve nebe).
    ///
    ///
    /// Ji bo alternatîfek ewle [`split_at`] binihêrin.
    ///
    /// # Safety
    ///
    /// Bangkirina vê rêbazê bi navnîşek derveyî sînoran *[tevgera nediyarkirî]* e jî ku referansa encam neyê bikar anîn.Bangker pêdivî ye ku `0 <= mid <= self.len()` piştrast bike.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // EWLEHIY: : Bangker divê `0 <= mid <= self.len()` kontrol bike
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Bêyî ku kontrola sînoran bike, perçeyek mutable li ser indexekî dabeş dike du.
    ///
    /// Ya yekem dê hemî nîşanên ji `[0, mid)` vehewîne (ji navnîşana `mid` xwe veqetîne) û ya duyemîn jî dê hemî nîşanekan ji `[mid, len)` vehewîne (ji navnîşana `len` bixwe ve nebe).
    ///
    ///
    /// Ji bo alternatîfek ewle [`split_at_mut`] binihêrin.
    ///
    /// # Safety
    ///
    /// Bangkirina vê rêbazê bi navnîşek derveyî sînoran *[tevgera nediyarkirî]* e jî ku referansa encam neyê bikar anîn.Bangker pêdivî ye ku `0 <= mid <= self.len()` piştrast bike.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // EWLEHIY: : Bangker divê `0 <= mid <= self.len()` kontrol bike.
        //
        // `[ptr; mid]` û `[mid; len]` li hev nayên, ji ber vê yekê vegera referansa guherbar baş e.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Itteratorek vedigerîne ser binkomên ku ji hêla hêmanên ku bi `pred` re li hev tên veqetandî veqetandî.
    /// Hêmana hevberkirî di bineşekan de nîn e.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ger hêmana yekem li hev were, dê perçek vala bibe yekem tiştê ku ji hêla dûbare vegeriyane.
    /// Bi heman awayî, heke hêmana paşîn a darbeyê li hev were, dê perçeyek vala bibe ya paşîn a ku ji hêla veberhêner ve hatî vegerandin:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Heke du hêmanên lihevkirî rasterast li tenişta hev bin, dê perçeyek vala di navbera wan de hebe:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Iterator li ser binavikên guhêrbar ên ku bi hêmanên ku bi `pred` re hevûdu veqetandî veqetandî vedigere.
    /// Hêmana hevberkirî di bineşekan de nîn e.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Itteratorek vedigerîne ser binkomên ku ji hêla hêmanên ku bi `pred` re li hev tên veqetandî veqetandî.
    /// Hêmana hevahengkirî di dawiya binkomê berê de wekî termînator tê de heye.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ger hêmana paşîn a paşîn were hevgirtin, ew ê hêman wekî bidawîbûna perçeya pêşîn were hesibandin.
    ///
    /// Ew perçe dê bibe ya paşîn a ku ji hêla veberhêner ve hatî vegerandin.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Iterator li ser binavikên guhêrbar ên ku bi hêmanên ku bi `pred` re hevûdu veqetandî veqetandî vedigere.
    /// Hêmana hevahengkirî di binavoka berê de wekî termînator tê de heye.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Ittatorek vedigerîne ser binkomên ku ji hêla hêmanên ku bi `pred` re hevûdu veqetandî veqetandî vedigere, ji dawiya perçeyê dest pê dike û paşde dixebite.
    /// Hêmana hevberkirî di bineşekan de nîn e.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Wekî `split()`, heke hêmana yekem an ya paşîn li hev were, dê perçeyek vala bibe ya yekem (an ya paşîn) ê ku ji hêla veberhênerê ve hatî vegerandin.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Ittatorek vedigerîne ser binavikên guhêrbar ên ku ji hêla hêmanên ku bi `pred` re hevûdu hatine veqetandin veqetandî ye, di dawiya perçeyê de dest pê dike û paşde dixebite.
    /// Hêmana hevberkirî di bineşekan de nîn e.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Itteratorek vedigerîne ser xalên jêrîn ên ku bi hêmanên ku bi `pred` re hevûdu veqetandî veqetandî, vedigere herî zêde tiştên `n`.
    /// Hêmana hevberkirî di bineşekan de nîn e.
    ///
    /// Hêmana paşîn a ku vegeriyaye, heke hebe, dê mayîna perçeyê tê de hebe.
    ///
    /// # Examples
    ///
    /// Dabeşa perçeyê carek bi jimarên ku bi 3 têne dabeş kirin (ango `[10, 40]`, `[20, 60, 50]`) çap bikin:
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Itteratorek vedigerîne ser xalên jêrîn ên ku bi hêmanên ku bi `pred` re hevûdu veqetandî veqetandî, vedigere herî zêde tiştên `n`.
    /// Hêmana hevberkirî di bineşekan de nîn e.
    ///
    /// Hêmana paşîn a ku vegeriyaye, heke hebe, dê mayîna perçeyê tê de hebe.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Itteratorek vedigerîne ser xalên jêrîn ên ji hêla hêmanên ku bi `pred` re têkildar in vedigere herî zêde tiştên `n`.
    /// Ev di dawiya perçeyê de dest pê dike û paşde dixebite.
    /// Hêmana hevberkirî di bineşekan de nîn e.
    ///
    /// Hêmana paşîn a ku vegeriyaye, heke hebe, dê mayîna perçeyê tê de hebe.
    ///
    /// # Examples
    ///
    /// Dabeşa perçeyê carekê çap bikin, ji dawiya wê ve dest pê bikin, bi hejmarên ku bi 3 têne dabeş kirin (ango, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Itteratorek vedigerîne ser xalên jêrîn ên ji hêla hêmanên ku bi `pred` re têkildar in vedigere herî zêde tiştên `n`.
    /// Ev di dawiya perçeyê de dest pê dike û paşde dixebite.
    /// Hêmana hevberkirî di bineşekan de nîn e.
    ///
    /// Hêmana paşîn a ku vegeriyaye, heke hebe, dê mayîna perçeyê tê de hebe.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Ger perçeyek hêmanek bi nirxê dayîn vedihewîne `true` vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Heke `&T`-ya we tune, lê tenê `&U`-a wusa `T: Borrow<U>`-an tune (mînakî
    /// `Têl: Deyn girtin<str>`), hûn dikarin `iter().any` bikar bînin:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // perçe `String`
    /// assert!(v.iter().any(|e| e == "hello")); // bi `&str` re bigerin
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// `true` vedigerîne heke `needle` pêşpirtika perçeyê ye.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Ger `needle` perçek vala ye her dem `true` vedigerîne:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Ger `needle` paşpirtika perçeyê ye `true` vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Ger `needle` perçek vala ye her dem `true` vedigerîne:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Bi pêşpirtika ku hatî rakirin fena jêrîn vedigerîne.
    ///
    /// Heke perçeyek bi `prefix` dest pê dike, piştî pêşpirtikê, di `Some` de pêçayî, subsal vedigerîne.
    /// Heke `prefix` vala ye, bi tenê qutîka xwerû vedigerîne.
    ///
    /// Heke perçeyek bi `prefix` dest pê neke, `None` vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Vê fonksiyonê dê hewce bike ku ji nû ve were nivîsandin heke û dema ku SlicePattern sofîstîketir bibe.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Bi paşpirtika ku hatî rakirin fena jêrîn vedigerîne.
    ///
    /// Heke perçeyek bi `suffix` bidawî bibe, subsaliya paşpirtika paşîn vedigerîne, di `Some` de pêça.
    /// Heke `suffix` vala ye, bi tenê qutîka xwerû vedigerîne.
    ///
    /// Ger perçeyek bi `suffix` neqede, `None` vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Vê fonksiyonê dê hewce bike ku ji nû ve were nivîsandin heke û dema ku SlicePattern sofîstîketir bibe.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Binary li vê perçê rêzkirî ji bo hêmanek diyarkirî digere.
    ///
    /// Heke nirx were dîtin wê hingê [`Result::Ok`] vedigere, tê de indexa hêmana lihevhatî heye.
    /// Ger pir maç hebin, wê hingê yek ji maçan dikare were vegerandin.
    /// Ger hêjayî neyê dîtin wê hingê [`Result::Err`] tê vegerandin, tê de index ku tê de hêmanek lihevhatî tê de tê de cih digire dema ku rêza rêzkirî diparêze.
    ///
    ///
    /// [`binary_search_by`], [`binary_search_by_key`], û [`partition_point`] jî bibînin.
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Li rêzeyek ji çar hêmanan digere.
    /// Ya yekem, bi helwestek taybetî ya diyarkirî tê dîtin;duyemîn û sêyemîn nayên dîtin;ya çaremîn dikare li `[1, 4]` bi her helwestê re têkeve.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Ger hûn bixwazin hêmanek têxin nav vector ya rêzkirî, dema ku rêza rêzê bidomînin:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Binary li vê perçê rêzkirî bi fonksiyonek berawirdî digere.
    ///
    /// Pêdivî ye ku fonksiyona berawirdkirinê fermanek li gorî rêza dabeşa binyata bingehîn bicîh bîne, kodek rêzê vegerîne ku nîşan dide ka argumana wê `Less`, `Equal` an `Greater` armanca xwestî ye.
    ///
    ///
    /// Heke nirx were dîtin wê hingê [`Result::Ok`] vedigere, tê de indexa hêmana lihevhatî heye.Ger pir maç hebin, wê hingê yek ji maçan dikare were vegerandin.
    /// Ger hêjayî neyê dîtin wê hingê [`Result::Err`] tê vegerandin, tê de index ku tê de hêmanek lihevhatî tê de tê de cih digire dema ku rêza rêzkirî diparêze.
    ///
    /// [`binary_search`], [`binary_search_by_key`], û [`partition_point`] jî bibînin.
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Li rêzeyek ji çar hêmanan digere.Ya yekem, bi helwestek taybetî ya diyarkirî tê dîtin;duyemîn û sêyemîn nayên dîtin;ya çaremîn dikare li `[1, 4]` bi her helwestê re têkeve hev.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // EWLEH: : bang ji hêla navnîşên jêrîn ve ewle tê çêkirin:
            // - `mid >= 0`
            // - `mid < size`: `mid` ji hêla `[left; right)` ve girêdayî ye.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Sedema ku em di şûna maçê de herikîna kontrolê ya if/else bikar tînin ji ber ku maçê operasyonên berawirdkirinê ji nû ve rêz dike, ku bêkêmasî ye.
            //
            // Ev x86 asm ji bo u8 e: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Binary li vê perçê rêzkirî bi fonksiyonek derxistina sereke digerin.
    ///
    /// Texmîn dike ku perçe ji hêla mifteyê ve hatî rêzkirin, mînakî bi [`sort_by_key`] re fonksiyona vekişînê ya mifteyê heman bikar tîne.
    ///
    /// Heke nirx were dîtin wê hingê [`Result::Ok`] vedigere, tê de indexa hêmana lihevhatî heye.
    /// Ger pir maç hebin, wê hingê yek ji maçan dikare were vegerandin.
    /// Ger hêjayî neyê dîtin wê hingê [`Result::Err`] tê vegerandin, tê de index ku tê de hêmanek lihevhatî tê de tê de cih digire dema ku rêza rêzkirî diparêze.
    ///
    ///
    /// [`binary_search`], [`binary_search_by`], û [`partition_point`] jî bibînin.
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Di rêzeyek çar hêmanan de li perçeyek cotan ku li gorî hêmanên wan ên duyemîn hatine rêzkirin digerin.
    /// Ya yekem, bi helwestek taybetî ya diyarkirî tê dîtin;duyemîn û sêyemîn nayên dîtin;ya çaremîn dikare li `[1, 4]` bi her helwestê re têkeve.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links wekî `slice::sort_by_key` di crate `alloc` de tête destûr kirin, û wekî wiya dema ku `core` ava dike hêj tune ye.
    //
    // Zencîreyên ber bi jêr crate: #74481.Ji ber ku prîmîtîf tenê di libstd (#73423) de têne belge kirin, ev di pratîkê de qet nabe sedema girêdanên şikestî.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Pelê rêz dike, lê dibe ku rêza hêmanên wekhev neparêze.
    ///
    /// Ev cûre nearam e (ango, dibe ku hêmanên wekhev ji nû ve rêz bike), di cîh de (ango, dabeş nake), û *O*(*n*\*log(* n*)) rewşa herî xirab.
    ///
    /// # Pêkanîna heyî
    ///
    /// Algorîtmaya heyî li ser bingeha [pattern-defeating quicksort][pdqsort] ji hêla Orson Peters ve hatî damezrandin, ku doza navînî ya bilez a quicksort-a randomîzekirî digel doza bilez ya herî xirab a heapsortê re dike yek, dema ku li ser pelikên bi hin qalibên demî rêzê digihîne hev.
    /// Ew hin randombûnê bikar tîne da ku ji dozên dejenerebûyî dûr bikeve, lê digel seed sabît ku her gav tevgera diyarker peyda bike.
    ///
    /// Ew bi gelemperî ji dabeşkirina stabîl zûtir e, ji bilî çend rewşên taybetî, mînakî, dema ku perçeyek ji çend rêzikên rêzkirî yên lihevhatî pêk tê.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Pelê bi fonksiyonek berawirdkirinê rêz dike, lê dibe ku rêza hêmanên wekhev neparêze.
    ///
    /// Ev cûre nearam e (ango, dibe ku hêmanên wekhev ji nû ve rêz bike), di cîh de (ango, dabeş nake), û *O*(*n*\*log(* n*)) rewşa herî xirab.
    ///
    /// Divê fonksiyona berawirdê ji bo hêmanên di perçeyê de rêzikek tevahî diyar bike.Heke rêzkirin tevde nebe, rêza hêmanan nayê diyar kirin.Biryarek heke ew fermanek tevahî ye (ji bo hemî `a`, `b` û `c`):
    ///
    /// * tevde û antîsîmmetrîk: tam yek ji `a < b`, `a == b` an `a > b` rast e, û
    /// * gerguhêz, `a < b` û `b < c` `a < c` îfade dike.Divê heman tişt ji bo `==` û `>` jî hebe.
    ///
    /// Mînakî, dema ku [`f64`] ji ber ku `NaN != NaN` [`Ord`] bicîh nayne, em dikarin `partial_cmp` wekî fonksiyona xweya rêvekirinê bikar bînin dema ku em zanibin qutik `NaN` nagire.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Pêkanîna heyî
    ///
    /// Algorîtmaya heyî li ser bingeha [pattern-defeating quicksort][pdqsort] ji hêla Orson Peters ve hatî damezrandin, ku doza navînî ya bilez a quicksort-a randomîzekirî digel doza bilez ya herî xirab a heapsortê re dike yek, dema ku li ser pelikên bi hin qalibên demî rêzê digihîne hev.
    /// Ew hin randombûnê bikar tîne da ku ji dozên dejenerebûyî dûr bikeve, lê digel seed sabît ku her gav tevgera diyarker peyda bike.
    ///
    /// Ew bi gelemperî ji dabeşkirina stabîl zûtir e, ji bilî çend rewşên taybetî, mînakî, dema ku perçeyek ji çend rêzikên rêzkirî yên lihevhatî pêk tê.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // berevajîkirina dabeşkirinê
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Pelê bi fonksiyonek derxistina kilît rêz dike, lê dibe ku rêza hêmanên wekhev neparêze.
    ///
    /// Ev cûre nearam e (ango, dibe ku hêmanên wekhev ji nû ve rêz bike), di cîh de (ango, dabeş nake), û *O*(m\* * n *\* log(*n*)) rewşa xirab, ku fonksiyona sereke *O* ye (*m*).
    ///
    /// # Pêkanîna heyî
    ///
    /// Algorîtmaya heyî li ser bingeha [pattern-defeating quicksort][pdqsort] ji hêla Orson Peters ve hatî damezrandin, ku doza navînî ya bilez a quicksort-a randomîzekirî digel doza bilez ya herî xirab a heapsortê re dike yek, dema ku li ser pelikên bi hin qalibên demî rêzê digihîne hev.
    /// Ew hin randombûnê bikar tîne da ku ji dozên dejenerebûyî dûr bikeve, lê digel seed sabît ku her gav tevgera diyarker peyda bike.
    ///
    /// Ji ber stratejiya gazîkirina kilîta xwe, dibe ku [`sort_unstable_by_key`](#method.sort_unstable_by_key) di rewşên ku fonksiyona kilît biha ye de ji [`sort_by_cached_key`](#method.sort_by_cached_key) hêdîtir be.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Sermaseyê ji nû ve sererast bikin ku hêmana li `index` di rewşa xweya dabeşkirî ya dawî de ye.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Bi fonksiyonek berawirdî qulikê ji nû ve sererast bikin ku hêman li `index` di rewşa xweya dabeşkirî ya dawî de be.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Bi fonksiyonek jêgirtina mifte qulikê ji nû ve sererast bikin ku hêman li `index` di rewşa xweya dabeşkirî ya dawî de be.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Sermaseyê ji nû ve sererast bikin ku hêmana li `index` di rewşa xweya dabeşkirî ya dawî de ye.
    ///
    /// Vê reordering xwedan taybetmendiyek din e ku her nirxek di pozîsyona `i < index` de dê ji nirxek di pozîsyona `j > index` de kêmtir be an jî wekhev be.
    /// Wekî din, ev ji nû ve rêzkirin bêîstîkrar e (ango
    /// her hejmarek hêmanên wekhev dikare li rewşa `index` biqede), li cîh (ango
    /// dabeş nake), û *O*(*n*) rewşa herî xirab.
    /// Ev fonksiyon di pirtûkxaneyên din de wekî "kth element" jî/tê zanîn.
    /// Ew sêyek ji nirxên jêrîn vedigerîne: hemî hêmanên ji yekê di navnîşa dayîn de kêmtir in, nirxa navnîşê tête dayîn, û hemî hêmanên ji yekê mezintir in.
    ///
    ///
    /// # Pêkanîna heyî
    ///
    /// Algorîtmaya heyî li ser beşa zû-bijartî ya heman algorîtmaya quicksort-a ku ji bo [`sort_unstable`]-ê hatî bikar anîn bingeh digire.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics dema `index >= len()`, wateya wê ew her gav panics li ser pelikên vala ye.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Navînî bibînin
    /// v.select_nth_unstable(2);
    ///
    /// // Em tenê garantî ne ku dê perçe yek ji yên jêrîn be, li ser bingeha awayê ku em li ser navnîşa diyarkirî rêz dikin.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Bi fonksiyonek berawirdî qulikê ji nû ve sererast bikin ku hêman li `index` di rewşa xweya dabeşkirî ya dawî de be.
    ///
    /// Vê reordering xwedan taybetmendiyek din e ku her nirxek di pozîsyona `i < index` de dê bi kar anîna fonksiyona berawirdî re ji nirxek di pozîsyona `j > index` de kêmtir be an jî wekhev be.
    /// Wekî din, ev rêzkirin ne aram e (ango dibe ku hejmarek hêmanên wekhev li pozîsyona `index` biqedin), di cîh de (ango veqetîne), û *O*(*n*) rewşa herî xirab.
    /// Ev fonksiyon di pirtûkxaneyên din de wekî "kth element" jî tê zanîn.
    /// Ew sêyek ji nirxên jêrîn vedigerîne: hemî hêmanên ji yekê di navnîşa dayîn de kêmtir in, nirxa di navnîşê dayîn de, û hemî hêmanên ji yekê mezintir di navnîşa dayîn de, fonksiyona berawirdkirî ya bikar anîn.
    ///
    ///
    /// # Pêkanîna heyî
    ///
    /// Algorîtmaya heyî li ser beşa zû-bijartî ya heman algorîtmaya quicksort-a ku ji bo [`sort_unstable`]-ê hatî bikar anîn bingeh digire.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics dema `index >= len()`, wateya wê ew her gav panics li ser pelikên vala ye.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Mîna ku parçe bi rêça daketinê hatine veqetandin navînî bibînin.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Em tenê garantî ne ku dê perçe yek ji yên jêrîn be, li ser bingeha awayê ku em li ser navnîşa diyarkirî rêz dikin.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Bi fonksiyonek jêgirtina mifte qulikê ji nû ve sererast bikin ku hêman li `index` di rewşa xweya dabeşkirî ya dawî de be.
    ///
    /// Vê reordering xwedan taybetmendiyek din e ku her nirxek di pozîsyona `i < index` de dê bi kar anîna fonksiyona derxistina mifteyê kêmtir be an bi qasî nirxek di pozîsyona `j > index` de be.
    /// Wekî din, ev rêzkirin ne aram e (ango dibe ku hejmarek hêmanên wekhev li pozîsyona `index` biqedin), di cîh de (ango veqetîne), û *O*(*n*) rewşa herî xirab.
    /// Ev fonksiyon di pirtûkxaneyên din de wekî "kth element" jî tê zanîn.
    /// Ew sêyek ji nirxên jêrîn vedigerîne: hemî hêmanên ji yekê di navnîşa dayîn de kêmtir in, nirxa navnîşê tête dayîn, û hemî hêmanên ji yekê mezintir di navnîşa dayîn de, fonksiyona vekêşana mifteya pêşkêşî bikar tînin.
    ///
    ///
    /// # Pêkanîna heyî
    ///
    /// Algorîtmaya heyî li ser beşa zû-bijartî ya heman algorîtmaya quicksort-a ku ji bo [`sort_unstable`]-ê hatî bikar anîn bingeh digire.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics dema `index >= len()`, wateya wê ew her gav panics li ser pelikên vala ye.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Mîna ku array li gorî nirxa mutleq hatine rêzkirin vegerin navîn.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Em tenê garantî ne ku dê perçe yek ji yên jêrîn be, li ser bingeha awayê ku em li ser navnîşa diyarkirî rêz dikin.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Li gorî bicihanîna [`PartialEq`] trait hemî hêmanên dubarekirî yên li pey hev vediguhêze dawiya perçeyê.
    ///
    ///
    /// Du tebeqeyan vedigire.Ya yekem hêmanên dubarekirî yên li pey hev nagire.
    /// Ya duyemîn hemî duplîkan bi rengek ne diyar diyar dike.
    ///
    /// Ger perçeyek were rêz kirin, yekem perçeya vegerandî ducar tune.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Tevî ya yekê hêmanên li pey hev ber bi dawiya perçê ve diçe ku têkiliyek wekheviya diyarkirî têr dike.
    ///
    /// Du tebeqeyan vedigire.Ya yekem hêmanên dubarekirî yên li pey hev nagire.
    /// Ya duyemîn hemî duplîkan bi rengek ne diyar diyar dike.
    ///
    /// Fonksiyona `same_bucket` ji parçeyê referansên du hêmanan derbas dibe û divê diyar bike ka hêman wekhev in an na.
    /// Hêmanên bi rêza berevajî ya ji rêza wan a li perçeyê derbas dibin, lewma heke `same_bucket(a, b)` `true` vegerîne, `a` li dawiya perçeyê tê veguheztin.
    ///
    ///
    /// Ger perçeyek were rêz kirin, yekem perçeya vegerandî ducar tune.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Her çend referansa me ya mutable li ser `self` heye, lê em nikarin guharînên *keyfî* bikin.Bangên `same_bucket` dikare panic be, ji ber vê yekê divê em piştrast bikin ku qert her gav di rewşek derbasdar de ye.
        //
        // Awayê ku em vê yekê rêve dikin bi karanîna swapan e;em li ser hemî hêmanan dûbare dikin, gava ku em diçin li hevûdu dikin da ku di dawiyê de hêmanên ku em dixwazin biparêzin li pêş in, û yên ku em dixwazin wan red bikin li paş in.
        // Paşê em dikarin parçe parçe bikin.
        // Ev operasyon hîn jî `O(n)` e.
        //
        // Mînak: Em di vê dewletê de, ku `r` "next" temsîl dike, dest pê dikin
        // bixwîne "û `w` temsîl dike" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Bi berhevdana self[r] li hember xwe [w-1], ev ne duçel e, ji ber vê yekê em self[r] û self[w] diguherin (wekî r==w bandorek tune) û dûv re herdu r û w zêde dikin, ji me re dimîne:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Bi berhevdana self[r] li hember xwe [w-1], ev nirx duçel e, ji ber vê yekê em `r` zêde dikin lê her tiştê din bê guhertin dihêlin:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Beramberkirina self[r] li hember xwe [w-1], ev ne dubare ye, ji ber vê yekê self[r] û self[w] biguhezînin û r û w pêşve bixin:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Dûbare ne, dubare bikin:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Duplicate, advance r. End perçe.Li w dabeş kirin.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // EWLEH: : rewşa `while` `next_read` û `next_write` garantî dike
        // ji `len` kêmtir in, lewma di hundurê `self` de ne.
        // `prev_ptr_write` berî `ptr_write` yek hêmanê nîşan dike, lê `next_write` di 1-ê de dest pê dike, ji ber vê yekê `prev_ptr_write` qet ji 0 kêmtir nine û di hundurê perçeyê de ye.
        // Ev hewcedariyên ji bo derevekirina `ptr_read`, `prev_ptr_write` û `ptr_write`, û ji bo bikaranîna `ptr.add(next_read)`, `ptr.add(next_write - 1)` û `prev_ptr_write.offset(1)` bicîh tîne.
        //
        //
        // `next_write` her weha bi piranî carekê serê xelekekê tête zêdekirin herî zêde tê wateya ku çu hêmanek hewce nake ku were guhertin.
        //
        // `ptr_read` û `prev_ptr_write` carî heman hêmanê nîşan nakin.Ev pêdivî ye ku `&mut *ptr_read`, `&mut* prev_ptr_write` ewle be.
        // Ravekirin bi hêsanî ev e ku `next_read >= next_write` her dem rast e, lewma `next_read > next_write - 1` jî rast e.
        //
        //
        //
        //
        //
        unsafe {
            // Bi karanîna nîşangirên rawe ji kontrolên sînoran dûr bikevin.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Tevî ya yekê hêmanên li pey hev ber bi dawiya perçeyê ve diçe ku bi heman mifteyê re çareser dibin.
    ///
    ///
    /// Du tebeqeyan vedigire.Ya yekem hêmanên dubarekirî yên li pey hev nagire.
    /// Ya duyemîn hemî duplîkan bi rengek ne diyar diyar dike.
    ///
    /// Ger perçeyek were rêz kirin, yekem perçeya vegerandî ducar tune.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Pelê di cîh de wisa dizivirîne ku hêmanên `mid`-ê yên pêşîn diçin dawiyê dema ku hêmanên `self.len() - mid`-ên paşîn diçin pêş.
    /// Piştî gazîkirina `rotate_left`, hêmana ku berê di index `mid` de bû dê bibe hêmana yekem a perçeyê.
    ///
    /// # Panics
    ///
    /// Ger `mid` ji dirêjahiya perçeyê mezintir be ev fonksiyon dê panic bike.Zanibe ku `mid == self.len()` _not_ panic dike û zivirînek no-op ye.
    ///
    /// # Complexity
    ///
    /// Rêzikî digire (di dema `self.len()`) de).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Zivirandina jêrzemînê:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // EWLEHIY: : Rêzeya `[p.add(mid) - mid, p.add(mid) + k)` sivik e
        // ji bo xwendin û nivîsandinê, ji hêla `ptr_rotate` ve pêdivî ye, derbasdar e.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Pelê di cîh de wisa dizivirîne ku hêmanên `self.len() - k`-ê yên pêşîn diçin dawiyê dema ku hêmanên `k`-ên paşîn diçin pêş.
    /// Piştî gazîkirina `rotate_right`, hêmana ku berê di index `self.len() - k` de bû dê bibe hêmana yekem a perçeyê.
    ///
    /// # Panics
    ///
    /// Ger `k` ji dirêjahiya perçeyê mezintir be ev fonksiyon dê panic bike.Zanibe ku `k == self.len()` _not_ panic dike û zivirînek no-op ye.
    ///
    /// # Complexity
    ///
    /// Rêzikî digire (di dema `self.len()`) de).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Zencîreyek bizivirînin:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // EWLEHIY: : Rêzeya `[p.add(mid) - mid, p.add(mid) + k)` sivik e
        // ji bo xwendin û nivîsandinê, ji hêla `ptr_rotate` ve pêdivî ye, derbasdar e.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// `self` bi hêmanan bi klonkirina `value` dagire.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// `self` bi hêmanan vedigerîne ku bi banga girtinek bi berdewamî vedigere.
    ///
    /// Ev rêbaz ji bo afirandina nirxên nû girtinek bikar tîne.Heke hûn nirxek dayînek li şûna [`Clone`] dixwazin, [`fill`] bikar bînin.
    /// Heke hûn dixwazin [`Default`] trait bikar bînin da ku nirxan çêbikin, hûn dikarin [`Default::default`] wekî arguman derbas bikin.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Hêmanên ji `src` nav `self` kopî dike.
    ///
    /// Dirêjahiya `src` divê wekî `self` be.
    ///
    /// Ger `T` `Copy` bicîh bike, ew dikare çêtir be ku [`copy_from_slice`] bikar bîne.
    ///
    /// # Panics
    ///
    /// Ger du dirêjahiyên wan dirêjahiyên cûda hebin ev fonksiyon dê panic be.
    ///
    /// # Examples
    ///
    /// Dabeşkirina du hêmanan ji perçeyek li ya din:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Ji ber ku neçar in ku bi heman dirêjahî bin, em qurmê çavkaniyê ji çar hêmanan davêjin du.
    /// // Ger em vê nekin wê panic.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust ferz dike ku dikare tenê referansa guhêrbar hebe ku bi referansên neguhêrbar li perçeyek daneya taybetî di çarçoveyek taybetî de hebe.
    /// Ji ber vê yekê, hewildana karanîna `clone_from_slice` li ser perçeyek tenê dê têkçûna berhevokê encam bide:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Ji bo ku em li dora vê bixebitin, em dikarin [`split_at_mut`] bikar bînin ku ji binî perçeyek du bin-perçe cuda çêbikin:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Hemî hêmanan ji `src` nav `self` kopî dike, bi kar anîna memcpy.
    ///
    /// Dirêjahiya `src` divê wekî `self` be.
    ///
    /// Ger `T` `Copy` bicîh neke, [`clone_from_slice`] bikar bînin.
    ///
    /// # Panics
    ///
    /// Ger du dirêjahiyên wan dirêjahiyên cûda hebin ev fonksiyon dê panic be.
    ///
    /// # Examples
    ///
    /// Kopîkirina du hêmanan ji perçeyek li yekê din:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Ji ber ku neçar in ku bi heman dirêjahî bin, em qurmê çavkaniyê ji çar hêmanan davêjin du.
    /// // Ger em vê nekin wê panic.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust ferz dike ku dikare tenê referansa guhêrbar hebe ku bi referansên neguhêrbar li perçeyek daneya taybetî di çarçoveyek taybetî de hebe.
    /// Ji ber vê yekê, hewildana karanîna `copy_from_slice` li ser perçeyek tenê dê têkçûna berhevokê encam bide:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Ji bo ku em li dora vê bixebitin, em dikarin [`split_at_mut`] bikar bînin ku ji binî perçeyek du bin-perçe cuda çêbikin:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Riya kodê ya panic hate fonksiyonek sar da ku malpera bangê nehêle.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // EWLEH: : `self` ji hêla hêmanan ve ji bo hêmanên `self.len()` derbasdar e, û `src` bû
        // kontrol kirin ku xwedî heman dirêjahî ne.
        // Dabeş nikarin li hev bikin ji ber ku referansên guhêrbar taybetî ne.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Hêmanên ji beşek perçeyê ji perçeyek din ji xwe re kopî dike, memmovekê bikar tîne.
    ///
    /// `src` di nav `self` de rêzik e ku jê tê kopî kirin.
    /// `dest` di nav `self` de pêgirta destpêkirina rêzeyê ye, ku dê heman dirêjahiya wê `src` hebe.
    /// Dibe ku her du rêz li ser hev bin.
    /// Divê dawiya her du rêzikan ji `self.len()` kêmtir an jî wekhev be.
    ///
    /// # Panics
    ///
    /// Ev fonksiyon dê panic be heke an range ji dawiya perçeyê derbas bibe, an jî heke dawiya `src` berî destpêkirinê be.
    ///
    ///
    /// # Examples
    ///
    /// Di nav perçeyek de çar byte kopî kirin:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // EWLEH: : mercên ji bo `ptr::copy` hemî li jor hatine kontrol kirin,
        // wek yên `ptr::add` jî hene.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Hemî hêmanên di `self` de bi yên di `other` de vedigire.
    ///
    /// Dirêjahiya `other` divê wekî `self` be.
    ///
    /// # Panics
    ///
    /// Ger du dirêjahiyên wan dirêjahiyên cûda hebin ev fonksiyon dê panic be.
    ///
    /// # Example
    ///
    /// Lihevguhertina du hêmanan li ser perçeyan:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust ferz dike ku di çarçoveyek taybetî de tenê li ser perçeyek taybetî ya daneyê referansek guherbar heye.
    ///
    /// Ji ber vê yekê, hewildana karanîna `swap_with_slice` li ser perçeyek tenê dê têkçûna berhevokê encam bide:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Ji bo ku em li dora vê bixebitin, em dikarin [`split_at_mut`] bikar bînin da ku ji binî perçeyek du bin-perçeyên berbiçav ên cihêreng biafirînin:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // EWLEH: : `self` ji hêla hêmanan ve ji bo hêmanên `self.len()` derbasdar e, û `src` bû
        // kontrol kirin ku xwedî heman dirêjahî ne.
        // Dabeş nikarin li hev bikin ji ber ku referansên guhêrbar taybetî ne.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Fonksiyon ku ji bo `align_to{,_mut}` dirêjahiya qurmê navîn û paşîn dihejmire.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Ya ku em ê di derheqê `rest` de bikin ev e ku em fêr bibin ka kîjan pirjimara `U` yê em dikarin di jimara herî jêrîn a`T`-yê deynin.
        //
        // How ji bo her "multiple" weha me çiqas `T` hewce dike.
        //
        // Mînak T=u8 U=u16 bifikirin.Wê hingê em dikarin 1 U-yê têxin nav 2 Ts.Asan.
        // Naha, mînakek li dozek binêrin ku mezinahiya: :<T>=16, mezinahiya::<U>=24.</u>
        // Em dikarin di perçê `rest` de li şûna her 3 Ts 2 Usan deynin.
        // Hinekî tevlihevtir.
        //
        // Formula ku vê hesab bike ev e:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/mezinahiya: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/mezinahiya::</u><T>
        //
        // Berfireh û hêsan kirin:
        //
        // Me=mezinahiya: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=mezinahiya::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Bi kêfxweşî ji ber ku ev hemî bi domdarî têne nirxandin ... performansa li vir ne girîng e!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // algorîtmaya steinê ya dubare Em hîn jî pêdivî ye ku em vê `const fn` çêbikin (û ger ku em bikin vegerin algorîtmaya paşverû) ji ber ku xwe bisipêre llvm ku tevhev bike ev hemî…baş e, ew min nerehet dike.
            //
            //

            // BELAW: : `a` û `b` têne kontrol kirin ku nirxên ne-sifir in.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // hemî faktorên 2-ê ji b derxînin
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // BELAW: : `b` tê kontrol kirin ku ne sifir be.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Bi vê zanînê ve çekdar, em dikarin çend `U` ên ku em dikarin lê bicîh bikin bibînin!
        let us_len = self.len() / ts * us;
        // How dê çiqas `T` di perçeya paşîn de be!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Pelê veguherînin perçeyek ji celebek din, piştrast bikin ku lihevnêzîkirina cûreyan tê domandin.
    ///
    /// Ev rêbaza perçeyê dike nav sê perçeyên veqetandî: pêşpirtûk, dirûvê navîn ê bi rengek rast rêzkirî û celebek paşpirtik.
    /// Rêbaz dikare ji bo celebek dabeşkirî û pargîdaniya navîn dirûvê navîn dirêjtirîn gengaz bike, lê tenê performansa algorîtmaya we divê bi wê ve girêdayî be, ne rastbûna wê.
    ///
    /// Destûr heye ku hemî daneyên ketinê wekî pêşgir an paşpirtik vegerin.
    ///
    /// Armanca vê rêbazê tune dema ku an hêmana têkevinê `T` an hêmana derketinê `U` sifir be û dê pelika orîjînal vegerîne bêyî ku tiştek parçe bike.
    ///
    /// # Safety
    ///
    /// Ev rêbaz bi bingehî `transmute` bi rêzgirtina hêmanên di navgîna navîn a vegeriyayî de ye, ji ber vê yekê hemî hişyariyên asayî yên bi `transmute::<T, U>` re jî li vir derbas dibin.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Zanibe ku piraniya vê fonksiyonê dê berdewam-nirxandin,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // ZST-an bi taybetî birêve bibin, ku ev e-wan hîç nekin.
            return (self, &[], &[]);
        }

        // Pêşîn, bibînin ka em li kîjan nuqteyê di navbêna yekem û duyemîn de dabeş dibin.
        // Bi ptr.align_offset hêsan e.
        let ptr = self.as_ptr();
        // EWLEH: : Ji bo şiroveya ewlehiya hûrgulî rêbaza `align_to_mut` bibînin.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // EWLEHIYA: naha `rest` bi verastî ye, lewma `from_raw_parts` li jêr baş e,
            // ji ber ku bangker garantî dike ku em dikarin `T` bi `U` bi ewlehî veguherînin.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Pelê veguherînin perçeyek ji celebek din, piştrast bikin ku lihevnêzîkirina cûreyan tê domandin.
    ///
    /// Ev rêbaza perçeyê dike nav sê perçeyên veqetandî: pêşpirtûk, dirûvê navîn ê bi rengek rast rêzkirî û celebek paşpirtik.
    /// Rêbaz dikare ji bo celebek dabeşkirî û pargîdaniya navîn dirûvê navîn dirêjtirîn gengaz bike, lê tenê performansa algorîtmaya we divê bi wê ve girêdayî be, ne rastbûna wê.
    ///
    /// Destûr heye ku hemî daneyên ketinê wekî pêşgir an paşpirtik vegerin.
    ///
    /// Armanca vê rêbazê tune dema ku an hêmana têkevinê `T` an hêmana derketinê `U` sifir be û dê pelika orîjînal vegerîne bêyî ku tiştek parçe bike.
    ///
    /// # Safety
    ///
    /// Ev rêbaz bi bingehî `transmute` bi rêzgirtina hêmanên di navgîna navîn a vegeriyayî de ye, ji ber vê yekê hemî hişyariyên asayî yên bi `transmute::<T, U>` re jî li vir derbas dibin.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Zanibe ku piraniya vê fonksiyonê dê berdewam-nirxandin,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // ZST-an bi taybetî birêve bibin, ku ev e-wan hîç nekin.
            return (self, &mut [], &mut []);
        }

        // Pêşîn, bibînin ka em li kîjan nuqteyê di navbêna yekem û duyemîn de dabeş dibin.
        // Bi ptr.align_offset hêsan e.
        let ptr = self.as_ptr();
        // EWLEH: : Li vir em piştrast dikin ku em ê ji bo U nîşankerên rêzkirî bikar bînin
        // rêbaza mayî.Ev bi derbaskirina pêşnumayek bi&[T] yê verastkirinek ji bo U. tê hedef kirin.
        // `crate::ptr::align_offset` bi pêşnumayek bi rêk û pêk `ptr` tê vexwendin (ew ji referansa `self` tê) û bi mezinahiyek ku hêza du ye (ji ber ku ew ji alignement ji bo U tê), tixûbên ewlehiya wê têr dike.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Em piştî vê yekê carek din nikarin `rest` bikar bînin, ku ew ê bi nasnav `mut_ptr` bêbandor bibe!EWLEH: : ji bo `align_to` şîroveyan bibînin.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Kontrol dike ka hêmanên vê perçeyê hatine rêzkirin.
    ///
    /// Ango, ji bo her hêmanê `a` û hêmana jêrîn `b`, `a <= b` divê hebe.Ger perçeyek tam sifir an yek hêmanê bide, `true` vedigere.
    ///
    /// Zanibe ku heke `Self::Item` tenê `PartialOrd` be, lê ne `Ord` be, pênaseya jorîn tê wateya ku ev fonksiyon `false` vedigerîne heke du heb tiştên li pey hev hebin neyên berhevdan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Kontrol dike ka hêmanên vê perçeyê bi karanîna fonksiyona berawirdkirî ya dabeşkirî hatine rêzkirin.
    ///
    /// Di şûna karanîna `PartialOrd::partial_cmp` de, ev fonksiyon fonksiyona `compare` ya hatî dayîn bikar tîne da ku rêzkirina du hêmanan diyar bike.
    /// Ji xeynî vê, ew bi [`is_sorted`] re wekhev e;ji bo bêtir agahdariyê belgeya wê bibînin.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Kontrol dike ka hêmanên vê perçeyê têne karanîn bi karanîna fonksiyona jêgirtina kilîta hatî dayîn.
    ///
    /// Li şûna berhevdana hêmanên qurmê rasterast, ev fonksiyon mifteyên hêmanan, ku ji hêla `f` ve hatî diyarkirin, dide ber hev.
    /// Ji xeynî vê, ew bi [`is_sorted`] re wekhev e;ji bo bêtir agahdariyê belgeya wê bibînin.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Indeksa xala dabeşkirinê li gorî pêşnûma dayîn vedigerîne (nîşana hêmana yekem a dabeşa duyemîn).
    ///
    /// Tê texmîn kirin ku qat li gorî pêşnûma dayîn hatî dabeş kirin.
    /// Ev tê vê wateyê ku hemî hêmanên ku pêşîn li wan vedigere rast in di destpêka perçeyê de ne û hemî hêmanên ku pêşîn li wan vedigere derewîn li dawiyê ne.
    ///
    /// Mînakî, [7, 15, 3, 5, 4, 12, 6] di bin pêşnûma x% 2 de dabeşkirî ye!=0 (hemî hejmarên xerîb di destpêkê de ne, hemî jî di dawiyê de).
    ///
    /// Ger ev perçe neyê dabeş kirin, encama vegeriyayî ne diyar û bêwate ye, ji ber ku ev rêbaz celebek lêgerîna binaryê pêk tîne.
    ///
    /// [`binary_search`], [`binary_search_by`], û [`binary_search_by_key`] jî bibînin.
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // BELAW: Gava `left < right`, `left <= mid < right`.
            // Ji ber vê yekê `left` her dem zêde dibe û `right` her dem kêm dibe, û yek ji wan tê hilbijartin.Di her du bûyeran de `left <= right` razî ye.Ji ber vê yekê ger `left < right` di gavek de be, `left <= right` di gava pêş de razî ye.
            //
            // Ji ber vê yekê heya ku `left != right`, `0 <= left < right <= len` razî ye û ger vê rewşê `0 <= mid < len` jî razî be.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Em hewce ne ku bi eşkereyî wan bi dirêjahiya heman darbestî bikin
        // da ku ew ji bo optimizer hêsantir bibe ku venihêrtina sînoran.
        // Lê ji ber ku ew nayê bawer kirin ku ji bo T jî pisporiyek eşkere heye: Pêgirt.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Parçeyek vala diafirîne.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Parçeyek vala ya guhêrbar diafirîne.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Patablonên di tebeqeyan de, naha, tenê ji hêla `strip_prefix` û `strip_suffix` ve têne bikar anîn.
/// Li ser xalek future, em hêvî dikin ku `core::str::Pattern` (ku di dema nivîsandinê de `str` bi sînor e) li ser perçeyan giştî bikin, û hingê dê ev trait were guhertin an hilweşandin.
///
pub trait SlicePattern {
    /// Celebê hêmanê qurmê ku li hev tê.
    type Item;

    /// Vêga, xerîdarên `SlicePattern` hewceyê perçeyek in.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}