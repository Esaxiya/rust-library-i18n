//! Fonksiyonên belaş ên afirandina `&[T]` û `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Ji pointer û dirêjahiyekê perçeyek çêdike.
///
/// Argumana `len` jimara **hêmanan** e, ne jimara bayîtan e.
///
/// # Safety
///
/// Heke ji mercên jêrîn binpê kirin tevger nayê diyar kirin:
///
/// * `data` divê [valid] be ji bo xwendina ji bo `len * mem::size_of::<T>()` gelek byte, û divê ew bi rêkûpêk were rêz kirin.Ev bi taybetî tê vê wateyê:
///
///     * Pêdivî ye ku tevahiya bîranîna vê perçeyê di nav yek tiştê veqetandî de hebe!
///       Slices carî nikare li seranserê gelek tiştên veqetandî dorpêç bike.[below](#incorrect-usage) binihêrin ji bo mînakek bi xeletî ev nayê hesibandin.
///     * `data` divê ne-null û lihevkirî be jî ji bo slices-sifir-length.
///     Sedemek vê yekê ev e ku optimîzasyonên nexşeya enumê dibe ku xwe bispêre referansan (di nav wan de perçên her dirêjahiyê jî jî hene) hevgirtî û ne-null da ku wan ji daneyên din cuda bike.
///     Hûn dikarin pêşnumayek ku wekî `data` ji bo pelikên sifir-dirêje [`NonNull::dangling()`] bikar tîne bikar bînin.
///
/// * `data` divê `len` nirxên bi rêkûpêk ên destpêkirî yên type `T` nîşan bikin.
///
/// * Bîra ku ji hêla perçê vegerandî ve hatî referans kirin divê ji bo domandina jiyana `'a` neguhezîne, ji xeynî hundurê `UnsafeCell`.
///
/// * Pêdivî ye ku mezinahiya tevahî `len * mem::size_of::<T>()` ya perçeyê ji `isize::MAX` ne mezintir be.
///   Belgeya ewlehiyê ya [`pointer::offset`] bibînin.
///
/// # Caveat
///
/// Jiyana ji bo perçê vegerandin ji karanîna wê tête fam kirin.
/// Ji bo pêşîgirtina li karanîna karesatî, tê pêşniyar kirin ku meriv jiyana ku bi çavkaniya ku di jiyanê de ewledar e ve girêbide, wek mînak bi peydakirina fonksiyonek alîkar ku ji bo perçeyê jiyana nirxa mêvandar digire, an jî bi vegotinek eşkere.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // ji bo hêmanek tenê perçeyek diyar dike
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Bikaranîna çewt
///
/// Fonksiyona `join_slices` ya jêrîn **bê deng e**
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Daxuyaniya jorîn piştrast dike ku `fst` û `snd` li pey hev in, lê dibe ku ew hîn jî di nav _different allocated objects_ de bin, ku di vê rewşê de afirandina vê perçê tevgerek ne diyar e.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` û `b` tiştên cuda hatine veqetandin ...
///     let a = 42;
///     let b = 27;
///     // ... ku dibe ku dîsa jî di bîranînê de bi rêkûpêk were danîn: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // EWLEHIY: : bangker divê peymana ewlehiyê ya `from_raw_parts` biparêze.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Çawa ku [`from_raw_parts`] heman fonksiyonelê pêk tîne, ji xeynî ku perçek mutable vedigere.
///
/// # Safety
///
/// Heke ji mercên jêrîn binpê kirin tevger nayê diyar kirin:
///
/// * `data` divê hem ji bo `len * mem::size_of::<T>()` gelek byte were xwendin û nivîsandin [valid] be, û divê ew bi rêkûpêk were rêz kirin.Ev bi taybetî tê vê wateyê:
///
///     * Pêdivî ye ku tevahiya bîranîna vê perçeyê di nav yek tiştê veqetandî de hebe!
///       Slices carî nikare li seranserê gelek tiştên veqetandî dorpêç bike.
///     * `data` divê ne-null û lihevkirî be jî ji bo slices-sifir-length.
///     Sedemek vê yekê ev e ku optimîzasyonên nexşeya enumê dibe ku xwe bispêre referansan (di nav wan de perçên her dirêjahiyê jî jî hene) hevgirtî û ne-null da ku wan ji daneyên din cuda bike.
///
///     Hûn dikarin pêşnumayek ku wekî `data` ji bo pelikên sifir-dirêje [`NonNull::dangling()`] bikar tîne bikar bînin.
///
/// * `data` divê `len` nirxên bi rêkûpêk ên destpêkirî yên type `T` nîşan bikin.
///
/// * Bîra ku ji hêla perçê vegeriyayî ve hatî referans kirin, ji bo domandina jiyana `'a` ne pêdivî ye ku bi pêşnumayek din (ji nirxa vegerê nehatiye girtin).
///   Hem destkeftinên xwendin û nivîsandinê qedexe ne.
///
/// * Pêdivî ye ku mezinahiya tevahî `len * mem::size_of::<T>()` ya perçeyê ji `isize::MAX` ne mezintir be.
///   Belgeya ewlehiyê ya [`pointer::offset`] bibînin.
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // EWLEHIY: : bangker divê peymana ewlehiyê ya `from_raw_parts_mut` biparêze.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Çavkaniyek ji T re veguherîne perçeyek dirêjahiya 1 (bêyî kopîkirinê).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Çavkaniyek ji T re veguherîne perçeyek dirêjahiya 1 (bêyî kopîkirinê).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}