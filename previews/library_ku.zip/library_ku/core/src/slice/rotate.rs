// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Rêzeya `[mid-left, mid+right)` wisa vedigire ku hêmana li `mid` dibe hêmana yekem.Hevseng, hêmanên `left` ber bi çepê ve an hêmanên `right` ber bi rastê ve dizivirîne.
///
/// # Safety
///
/// Divê rêza diyarkirî ji bo xwendin û nivîsînê derbasdar be.
///
/// # Algorithm
///
/// Algorîtm 1 ji bo nirxên piçûk ên `left + right` an ji bo `T` mezin tê bikar anîn.
/// Hêmanên yek bi yek ji `mid - left` dest pê dikin û ji hêla modulo `left + right` gavên `right` pêşve diçin, di rewşên xweyên paşîn de têne veguheztin, wusa ku tenê yek demkî hewce dike.
/// Di dawiyê de, em vedigerin `mid - left`.
/// Lêbelê, heke `gcd(left + right, right)` ne 1 be, gavên jor li ser hêmanan vekişiyan.
/// Bo nimûne:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Bi kêfxweşî, hejmara hêmanên di navbera hêmanên qedandî de hatine paşguh kirin her dem wekhev e, ji ber vê yekê em dikarin tenê pozîsyona xwe ya destpêkî berevajî bikin û geryanên din jî bikin (hejmara giştî ya gerdûnan `gcd(left + right, right)` value) ye.
///
/// Encama dawiyê ev e ku hemî hêman carek û tenê carek têne dawîkirin.
///
/// Algorîtm 2 tê bikar anîn heke `left + right` mezin be lê `min(left, right)` têra xwe piçûk e ku li tamponek stackê bigere.
/// Hêmanên `min(left, right)` li ser tampon têne kopî kirin, `memmove` li yên din tê sepandin, û yên li ser tampon dîsa têne veguheztin qulika aliyê dijberî yê ku jê re hatine.
///
/// Algorîtmayên ku dikarin werin vektorîkirin ji yên jorîn gava `left + right` têra xwe mezin bibe ji performansê baştir dibin.
/// Algorîtm 1 dikare bi dabeşkirin û pêkanîna gelek dewran bi carekê vektorîze bibe, lê heya navînî pir hindik dor hene heya ku `left + right` pir mezin e, û rewşa herî xirab a dorpêçek tenê her dem heye.
/// Di şûna wê de, algorîtmaya 3 veguherîna dubare ya hêmanên `min(left, right)` bikar tîne heya ku pirsgirêkek dorpêçek piçûktir hişt.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// dema `left < right` li şûna wê çepgirî ji çepê pêk tê.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. ger van rewşan neyên kontrol kirin algorîtmayên jêrîn dikarin têk biçin
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algorîtm 1 Microbenchmarks diyar dikin ku performansa navînî ya ji bo veguherînên bêserûber heya heya `left + right == 32` çêtir e, lê performansa bûyera herî xirab jî dora 16-ê dişikêne.
            // 24 wekî navîn hate hilbijartin.
            // Heke mezinahiya `T` ji 4 `sûdê mezintir be, ev algorîtm ji algorîtmayên din jî baştir e.
            //
            //
            let x = unsafe { mid.sub(left) };
            // destpêka tûra yekem
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` bi hesibandina `gcd(left + right, right)` dikare li ber destê were dîtin, lê ew zûtir e ku meriv yek xelekek çêbike ku gcd wekî bandorek aliyî dihesibîne, dûv re mayîna çengelê dike
            //
            //
            let mut gcd = right;
            // pîvan diyar dikin ku li şûna xwendina yeka demkî carek, kopîkirina paşde, û dûv re nivîsandina wê ya demkî di dawiya dawîn de veguheztina hemdeman zûtir zûtir e.
            // Ev dibe ku ji ber vê rastiyê be ku swapkirin an şûna demboriyan di şûnê de hewceyê birêvebirina du navnîşanek bîranînê tenê yek bikar tîne.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // li şûna zêdekirina `i` û dûv re kontrol bikin ka ew li derveyî sînoran e, em kontrol dikin ka `i` dê li zêdebûna paşîn derkeve derveyî sînoran.
                // Ev rê li ber pêça nîşangiran an `usize` digire.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // dawiya tûra yekem
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // ev merc divê ger `left + right >= 15` li vir be
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // Qirikê bi gerdûnên din biqedînin
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` ne celebek sifir-sized e, ji ber vê yekê baş e ku meriv bi mezinahiya xwe parve bike.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algorîtm 2 Li vir `[T; 0]` e ku piştrast bike ku ev ji bo T bi guncanî li hev hatî ye
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algorîtm 3 Rêyek alternatîf a veguheztinê heye ku tê de lêgerîna ku swapa dawî ya vê algorîtmayê dê çi be, û veguheztina karanîna wê perçeya paşîn li şûna veguheztina perçeyên cîran wekî vê algorîtmayê dike, lê ev rê hîn zûtir e.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algorîtm 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}