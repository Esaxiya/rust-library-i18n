#![stable(feature = "core_hint", since = "1.27.0")]

//! Intsîretên berhevokê ku bandorê li ser çawaniya weşandin an çêtirkirina kod dike.
//! Pêşniyar dibe ku dem an demjimêr berhevkar bin.

use crate::intrinsics;

/// Ji berhevkar re agahdar dike ku ev xala kodê ne gihîştbar e, hêj baştirbûnan dike.
///
/// # Safety
///
/// Gihîştina vê fonksiyonê bi tevahî *tevgerek ne diyar*(UB) e.Bi taybetî, berhevkar difikire ku pêdivî ye ku hemî UB carî çênebin, û ji ber vê yekê dê hemî şaxên ku digihîjin banga `unreachable_unchecked()` ji holê rabike.
///
/// Wekî hemî nimûneyên UB, heke ev raman çewt derkeve, ango, banga `unreachable_unchecked()` bi rastî di nav hemî herika kontrolê ya gengaz de bigihîje hev, dê berhevkar stratejiya optîmîzasyonê ya çewt bi kar bîne, û dibe ku carinan jî kodê xuya dike negirêdayî be, dibe sedema dijwar-pirsgirêkên rakirina pirsgirêkan.
///
///
/// Vê fonksiyonê bikar bînin tenê dema ku hûn dikarin îsbat bikin ku kod dê carî jê re bang neke.
/// Wekî din, karanîna makroya [`unreachable!`] bifikirin, ku rê nade optimîzasyonan lê dema ku were bicîh kirin dê panic bike.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` her gav erênî ye (ne sifir e), ji ber vê yekê `checked_div` dê carî `None` venagerîne.
/////
///     // Ji ber vê yekê, branch ya din nagihîje.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // SAFETY: divê peymana ewlehiyê ji bo `intrinsics::unreachable`
    // ji hêla gazîvan ve were piştgirî kirin.
    unsafe { intrinsics::unreachable() }
}

/// Rêwerzek makîneyê dihêle da ku îşaretê bi processor re bike ku ew di spin-loop-a-mijûl-benda de dixebite ("spin lock").
///
/// Bi stendina îşareta spin-loopê re pêvajoger dikare tevgera xwe baştir bike, ji bo nimûne, ji hêla hêzê ve bihêle an jî têlên hyper veguherîne.
///
/// Ev fonksiyon ji [`thread::yield_now`] cuda ye ku rasterast radiwestera pergalê dide, lê `spin_loop` bi pergala xebitandinê re têkiliyê nade.
///
/// Dozek karanîna hevpar a ji bo `spin_loop` bicîhkirina dorpêçkirina xweşbîniya sînorkirî ya di xelekek CAS-ê de di prîmîtîfên hevdemkirinê de ye.
/// Ji bo ku ji pirsgirêkên mîna berevajîkirina pêşîn dûr nekevin, bi tundî tê pêşniyar kirin ku pişti ducariyek bi sînor a dubareyan xelas bibe û xelekek guncan a syscall were çêkirin.
///
///
/// **Nîşe**: Li ser platformên ku piştgirî nadin nîşeyên spin-loopê ev fonksiyon jixwe tiştek nake.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Nirxek atomî ya hevbeş ku têlan dê bikar bînin ku hevrêz bikin
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Di xelekek paşnavê de em ê di dawiyê de nirxê destnîşan bikin
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Hin kar bikin, paşê nirxê zindî bikin
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Vegerin ser mijara xweya nuha, em li bende ne ku nirx were saz kirin
/// while !live.load(Ordering::Acquire) {
///     // Rêzeya spîn nîşeyek CPU-yê ye ku em li bendê ne, lê dibe ku ne pir dirêj be
/////
///     hint::spin_loop();
/// }
///
/// // Nirx niha hatî danîn
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // SAFETY: `cfg` attr piştrast dike ku em tenê vê yekê li ser hedefên x86 bicîh dikin.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // SAFETY: `cfg` attr piştrast dike ku em tenê vê yekê li ser hedefên x86_64 bicîh dikin.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // SAFETY: `cfg` attr piştrast dike ku em tenê vê yekê li ser hedefên aarch64 bicîh dikin.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // SAFETY: `cfg` attr piştrast dike ku em tenê vê yekê li ser hedefên çekdar dimeşînin
            // bi piştgiriya taybetmendiya v6.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Fonksiyonek nasnameyê ku *__ nîşana __* dide berhevkar ku li ser tiştê ku `black_box` dikare çi bike herî zêde reşbîn be.
///
/// Berevajî [`std::convert::identity`], berhevokarek Rust tête teşwîq kirin ku `black_box` dikare `dummy` bi awayek derbasdar a gengaz bikar bîne ku koda Rust destûr tê dayin bêyî ku tevgerê nevekirî di koda bangkirinê de destnîşan bike.
///
/// Vê taybetmendiyê ji bo nivîsandina koda ku hin optimîzasyonên naxwazin, wekî pîvan, `black_box` bikêr tîne.
///
/// Lêbelê, bîr bînin, ku `black_box` tenê (û tenê dikare) li ser bingeha "best-effort" tête peyda kirin.Asta ku ew dikare optîmîzasyonan asteng bike, dibe ku li gorî platform û paşnavê kod-gen-ê ku hatî bikar anîn, biguhere.
/// Bername ji bo *rastbûn* bi her awayî nikarin li `black_box` bisekinin.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Em pêdivî ye ku argumana "use" bi rengekî LLVM nikaribe çavnêriya bike, û li ser hedefên ku wê piştgirî dikin em bi gelemperî dikarin civata inline bi kar bînin da ku vê yekê bikin.
    // Interpretationîroveya civata inline ya LLVM ev e ku, ew qutiyek reş e.
    // Ev pêkanîna herî mezin ne ji ber ku ew dibe ku ji ya me zêdetir deoptîmîze dike, lê ew heya nuha têra xwe baş e.
    //
    //

    #[cfg(not(miri))] // Ev tenê şîretek e, ji ber vê yekê xweş e ku meriv li Miri derbikeve.
    // EWLEHIY: : civata inline ne-op ye.
    unsafe {
        // FIXME: Nikare `asm!` bikar bîne ji ber ku ew piştgirî nade MIPS û avahiyên din.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}