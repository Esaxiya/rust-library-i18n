//! Veguherînên karakterî.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// `u32` veguherîne `char`.
///
/// Zanibe ku hemî [`char`] s ['u32`] s derbasdar in, û dikare bi yekê re were avêtin
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Lêbelê, berevajî ne rast e: ne hemî [`u32`] yên derbasdar [`char`]-yên derbasdar in.
/// `from_u32()` dê `None` vegerîne heke input ji bo [`char`] nirxek ne derbasdar be.
///
/// Ji bo guhertoyek ne ewle ya vê fonksiyonê ku van venêran paşguh dike, li [`from_u32_unchecked`] binihêrin.
///
///
/// # Examples
///
/// Bikaranîna bingehîn:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Vegerîna `None` dema ku input ne [`char`] derbasdar be:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// `u32` bi `char` veguherîne, rastdariyê paşguh dike.
///
/// Zanibe ku hemî [`char`] s ['u32`] s derbasdar in, û dikare bi yekê re were avêtin
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Lêbelê, berevajî ne rast e: ne hemî [`u32`] yên derbasdar [`char`]-yên derbasdar in.
/// `from_u32_unchecked()` dê vê yekê paşguh bike, û kor bi [`char`] ve bavêje, dibe ku yeka nederbasdar biafirîne.
///
///
/// # Safety
///
/// Ev fonksiyon ne ewle ye, ji ber ku ew dikare nirxên `char` yên nederbasdar ava bike.
///
/// Ji bo guhertoyek ewlekariya vê fonksiyonê, fonksiyona [`from_u32`] bibînin.
///
/// # Examples
///
/// Bikaranîna bingehîn:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // EWLEHIY: : divê bangker garantî bike ku `i` nirxek char derbasdar e.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// [`char`] veguherîne [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// [`char`] veguherîne [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Char bi nirxê xala kodê ve tê birrîn, dûvre bi sifir 64 bit tê dirêj kirin.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] bibînin
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// [`char`] veguherîne [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Char bi nirxê xala kodê ve tête birrîn, dûvre bi sifir-dirêjî 128 bit.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] bibînin
        c as u128
    }
}

/// Di 0x00 de byteyek nexşe dike ..=0xFF heya `char` ku xala kodê wê xwedan heman nirx e, di U + 0000 ..=U + 00FF.
///
/// Unicode wisa hatiye sêwirandin ku ev bi bandor bi kodkirina karakterê ku IANA gazî ISO-8859-1 dike, byte deşîfre dike.
/// Ev kodkirin bi ASCII re lihevhatî ye.
///
/// Têbînî ku ev ji ISO/IEC 8859-1 anko cuda ye
/// ISO 8859-1 (bi yek xêzikek kêm), ku hin "blanks", nirxên baytê yên ku ji her tîpekê re nayên veqetandin dihêle.
/// ISO-8859-1 (ya IANA) wan bi kodên kontrolê yên C0 û C1 dide wan.
///
/// Zanibe ku ev *jî* ji Windows-1252 aka cuda ye
/// rûpela kod 1252, ku superset ISO/IEC 8859-1 e ku hin (ne hemî!) valahiyan ji bo xalbendî û cûrbecûr tîpên Latînî vedibêje.
///
/// Ji bo ku tiştan bêtir tevlihev bikin, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1`, û `windows-1252` hemî navnîşên ji bo supersetek Windows-1252 ne ku valahiyên mayî yên bi kodên kontrolê yên C0 û C1 yên têkildar dagirtî ne.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// [`u8`] veguherîne [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Xeletiyek ku dema parsekek cerdevanek dikare were vegerandin.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // SAFETY: kontrol kir ku ew nirxek unicode-ya qanûnî ye
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Dema ku veguherînek ji u32 li char têk çû tîpa çewtiyê vegeriya.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Di radixe dane de reqemek diguheze `char`.
///
/// A 'radix' li vir carinan wekî 'base' jî tê gotin.
/// Radikek du hejmar binaryek, radikek deh, dehik, û radikek şazdehan, hexadecimal, nîşan dide ku hin nirxên hevpar bide.
///
/// Radikên keyfî têne piştgirî kirin.
///
/// `from_digit()` dê `None` vegerîne heke input di radixe dayîn de ne reqemek e.
///
/// # Panics
///
/// Heke radîksek ji 36-an mezintir were dayîn Panics.
///
/// # Examples
///
/// Bikaranîna bingehîn:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Decimal 11 di bingeha 16 de yekjimarek e
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Dema ku input ne reqemek be `None` vedigere:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Radikek mezin derbas dikin, dibe sedema panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}