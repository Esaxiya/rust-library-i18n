//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Koda kodê ya herî derbasdar a `char` dikare hebe.
    ///
    /// `char` [Unicode Scalar Value] e, ku tê vê wateyê ku ew [Code Point] e, lê tenê yên di nav rêzek diyar de ne.
    /// `MAX` xala koda derbasdar a herî bilind e ku ew [Unicode Scalar Value] derbasdar e.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () di Unicode de tê bikar anîn ku çewtiyek deşîfrebûnê temsîl bike.
    ///
    /// Ew dikare çêbibe, mînakî, dema ku byteyên UTF-8-ê yên nexşandî dane [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Guhertoya [Unicode](http://www.unicode.org/) ku beşên Unicode-yên `char` û `str`-ê li ser bingeha wê ne.
    ///
    /// Guhertoyên nû yên Unicode bi rêkûpêk têne belav kirin û paşê hemî rêbazên di pirtûkxaneya standard de girêdayî Unicode têne nûve kirin.
    /// Ji ber vê yekê tevgera hin rêbazên `char` û `str` û nirxa vê domdar bi demê re diguhere.
    /// Ev * nayê guhertin.
    ///
    /// Nexşeya hejmartina guhertoyê di [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) de tê vegotin.
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Li ser xalên kodê kodkirî yên UTF-16 di `iter` de iterator diafirîne, cîgirên nevekirî wekî `Err` vedigerîne.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Dekodekek windabûyî dikare bi veguheztina encamên `Err` bi karakterê veguheztin were bidestxistin:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// `u32` veguherîne `char`.
    ///
    /// Bala xwe bidinê ku her `char` ['u32`] s derbasdar e, û dikare bi yekê re were avêtin
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Lêbelê, berevajî ne rast e: ne her derbasdar [`u32`] s`char` derbasdar in.
    /// `from_u32()` dê `None` vegerîne heke input ji bo `char` nirxek ne derbasdar be.
    ///
    /// Ji bo guhertoyek ne ewle ya vê fonksiyonê ku van venêran paşguh dike, li [`from_u32_unchecked`] binihêrin.
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Vegerîna `None` dema ku input ne `char` derbasdar be:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// `u32` bi `char` veguherîne, rastdariyê paşguh dike.
    ///
    /// Bala xwe bidinê ku her `char` ['u32`] s derbasdar e, û dikare bi yekê re were avêtin
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Lêbelê, berevajî ne rast e: ne her derbasdar [`u32`] s`char` derbasdar in.
    /// `from_u32_unchecked()` dê vê yekê paşguh bike, û kor bi `char` ve bavêje, dibe ku yeka nederbasdar biafirîne.
    ///
    ///
    /// # Safety
    ///
    /// Ev fonksiyon ne ewle ye, ji ber ku ew dikare nirxên `char` yên nederbasdar ava bike.
    ///
    /// Ji bo guhertoyek ewlekariya vê fonksiyonê, fonksiyona [`from_u32`] bibînin.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // EWLEH: : divê peymana ewlehiyê ji hêla bangker ve were pejirandin.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Di radixe dane de reqemek diguheze `char`.
    ///
    /// A 'radix' li vir carinan wekî 'base' jî tê gotin.
    /// Radikek du hejmar binaryek, radikek deh, dehik, û radikek şazdehan, hexadecimal, nîşan dide ku hin nirxên hevpar bide.
    ///
    /// Radikên keyfî têne piştgirî kirin.
    ///
    /// `from_digit()` dê `None` vegerîne heke input di radixe dayîn de ne reqemek e.
    ///
    /// # Panics
    ///
    /// Heke radîksek ji 36-an mezintir were dayîn Panics.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Decimal 11 di bingeha 16 de yekjimarek e
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Dema ku input ne reqemek be `None` vedigere:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Radikek mezin derbas dikin, dibe sedema panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Kontrol dike ka `char` di radixe dayîn de hejmar e an na.
    ///
    /// A 'radix' li vir carinan wekî 'base' jî tê gotin.
    /// Radikek du hejmar binaryek, radikek deh, dehik, û radikek şazdehan, hexadecimal, nîşan dide ku hin nirxên hevpar bide.
    ///
    /// Radikên keyfî têne piştgirî kirin.
    ///
    /// Li gorî [`is_numeric()`], ev fonksiyon tenê tîpên `0-9`, `a-z` û `A-Z` nas dike.
    ///
    /// 'Digit' tête diyar kirin ku tenê tîpên jêrîn in:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Ji bo têgihiştinek berfirehtir a 'digit', li [`is_numeric()`] binihêrin.
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Heke radîksek ji 36-an mezintir were dayîn Panics.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Radikek mezin derbas dikin, dibe sedema panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Di radixe dayîn de `char` veguherîne reqemekê.
    ///
    /// A 'radix' li vir carinan wekî 'base' jî tê gotin.
    /// Radikek du hejmar binaryek, radikek deh, dehik, û radikek şazdehan, hexadecimal, nîşan dide ku hin nirxên hevpar bide.
    ///
    /// Radikên keyfî têne piştgirî kirin.
    ///
    /// 'Digit' tête diyar kirin ku tenê tîpên jêrîn in:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Ger `char` di radixa daneyî de neqeyde reqalekê venagerîne `None` vedigerîne.
    ///
    /// # Panics
    ///
    /// Heke radîksek ji 36-an mezintir were dayîn Panics.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Derbarê encamek ne-reqemî de têkçûn:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Radikek mezin derbas dikin, dibe sedema panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // kod li vir dabeş dibe da ku ji bo rewşên ku `radix` berdewam û 10 an piçûktir e, leza darvekirinê baştir bike
        //
        let val = if likely(radix <= 10) {
            // Heke ne reqemek be, dê hejmarek ji radixê mezintir were afirandin.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Iteratorê vedigerîne ku heksadecimal Unicode reviya karakterê wekî `char` dide.
    ///
    /// Ev ê ji tîpên bi hevoksaziya Rust ya forma `\u{NNNNNN}` ku `NNNNNN` nûnertiya hexadecimal e, bireve.
    ///
    ///
    /// # Examples
    ///
    /// Wekî veberhêner:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` rasterast bikar tînin:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Herdu jî wekhev in:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// `to_string` bikar tînin:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // an-ing 1 piştrast dike ku ji bo c==0 kod hesab dike ku yek reqem divê were çap kirin û (ku yek e) pêşî li biniya (31, 32) digire
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // nîşana hejmar hejmar a herî girîng
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Guhertoyek dirêjkirî ya `escape_debug` ku bi vebijarkî destûr dide revîna şîfreyên Grapheme ya Berfireh.
    /// Ev dihêle ku em tîpên mîna nîşanên neveqetandî çêtir format bikin dema ku ew di destpêka rêzê de ne.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Iteratorê vedigerîne ku koda revê ya karektera rastîn wekî `char` dide.
    ///
    /// Ev ê ji karakterên mîna pêkanînên `Debug` ên `str` an `char` bireve.
    ///
    ///
    /// # Examples
    ///
    /// Wekî veberhêner:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` rasterast bikar tînin:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Herdu jî wekhev in:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// `to_string` bikar tînin:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Iteratorê vedigerîne ku koda revê ya karektera rastîn wekî `char` dide.
    ///
    /// Default bi alîgirî ber bi hilberîna herfên ku di cûrbecûr zimanan de qanûnî ne, C++ 11 û zimanên wekhev ên C-malbatê tê hilbijartin.
    /// Rêzikên rastîn ev in:
    ///
    /// * Tab wekî `\t` reviyaye.
    /// * Vegera Kêliyê wekî `\r` reviyaye.
    /// * Feed xeta wek `\n` reviyan.
    /// * Pêşniyara yekta wekî `\'` reviyaye.
    /// * Gotina duçar wekî `\"` reviyaye.
    /// * Paşverû wekî `\\` reviyaye.
    /// * Çi karakter ji rêzeya 'çapkirî ASCII' `0x20` .. `0x7e` tê de nayê xilas kirin.
    /// * Ji hemî karakterên din re revên Unicode hexadecimal têne dayîn;[`escape_unicode`] bibînin.
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Wekî veberhêner:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` rasterast bikar tînin:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Herdu jî wekhev in:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// `to_string` bikar tînin:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Heger ku di UTF-8 de were şîfre kirin, hejmara bajarên ku vê `char` hewce dike vedigere.
    ///
    /// Ew hejmara baytan her gav, di nav de 1 û 4 e.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Tîpa `&str` garantî dike ku naveroka wê UTF-8 ne, û ji ber vê yekê em dikarin dirêjahiya ku dê bigire heke her xala kodê wekî `char` vs li `&str` bixwe were temsîl kirin em dikarin berawird bikin:
    ///
    ///
    /// ```
    /// // wek chars
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // her du jî dikarin wekî sê bayt werin nimandin
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // wekî &str, ev her du di UTF-8 de têne şîfre kirin
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // em dibînin ku ew bi tevahî şeş byte digirin ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... hema mîna &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Hejmara yekeyên kodên 16-bit ên vê `char`-ê hewce dike ku ger di UTF-16-ê de were kodkirin vedigerîne.
    ///
    ///
    /// Ji bo bêtir ravekirina vê têgehê belgeyên [`len_utf8()`] bibînin.
    /// Ev fonksiyon neynikek e, lê ji bo UTF-16 li şûna UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Vê karakterê wekî UTF-8 di tampona byte ya peyda kirî de şîfre dike, û dûv re subslîska tampona ku karakterê kodkirî vedigire vedigerîne.
    ///
    ///
    /// # Panics
    ///
    /// Heke tampon ne têra xwe mezin be Panics.
    /// Tamponek bi dirêjahiya çar bes mezin e ku dikare `char` kod bike.
    ///
    /// # Examples
    ///
    /// Di van her du mînakan de, 'ß' du bayt digire ku şîfre bike.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Tamponek ku pir piçûk e:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // EWLEH: : `char` ne cîgir e, ji ber vê yekê ev UTF-8 derbasdar e.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Vê karakterê wekî UTF-16 vediguhêze nav tampona `u16` ya hatî peyda kirin, û dûv re jînenişta tampona ku karakterê kodkirî vedigire vedigerîne.
    ///
    ///
    /// # Panics
    ///
    /// Heke tampon ne têra xwe mezin be Panics.
    /// Tamponek bi dirêjahiya 2 têra xwe mezin e ku dikare her `char` kod bike.
    ///
    /// # Examples
    ///
    /// Di van her du mînakan de, '𝕊' du `u16` digire ku kod bike.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Tamponek ku pir piçûk e:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Ger vê taybetmendiya `char` xwedan taybetmendiya `Alphabetic` be, `true` vedigerîne.
    ///
    /// `Alphabetic` di Beşa 4-an de (Taybetmendiyên Karakterê) ya [Unicode Standard] tête vegotin û di [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] de tête diyar kirin.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // evîn gelek tişt e, lê ne alfabe ye
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Ger vê taybetmendiya `char` xwedan taybetmendiya `Lowercase` be, `true` vedigerîne.
    ///
    /// `Lowercase` di Beşa 4-an de (Taybetmendiyên Karakterê) ya [Unicode Standard] tête vegotin û di [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] de tête diyar kirin.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Nivîsên cûrbecûr û xalbendî yên Çînî ne xwediyê dozê ne, û wusa jî:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Ger vê taybetmendiya `char` xwedan taybetmendiya `Uppercase` be, `true` vedigerîne.
    ///
    /// `Uppercase` di Beşa 4-an de (Taybetmendiyên Karakterê) ya [Unicode Standard] tête vegotin û di [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] de tête diyar kirin.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Nivîsên cûrbecûr û xalbendî yên Çînî ne xwediyê dozê ne, û wusa jî:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Ger vê taybetmendiya `char` xwedan taybetmendiya `White_Space` be, `true` vedigerîne.
    ///
    /// `White_Space` di [Unicode Character Database][ucd] [`PropList.txt`] de tête diyar kirin.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // cîhek neşikestî
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Ger ev `char` an [`is_alphabetic()`] an [`is_numeric()`] têr bike vedigere `true`.
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// `true` vedigerîne heke ev `char` ji bo kodên kontrolê kategoriya gelemperî hebe.
    ///
    /// Kodên kontrolê (xalên kodê bi kategoriya gelemperî ya `Cc`) di Beşa 4-an de (Taybetmendiyên Karakterê) ya [Unicode Standard] têne vegotin û di [Unicode Character Database][ucd] [`UnicodeData.txt`] de têne diyar kirin.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// // U + 009C, BERXWEDANA BELA
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Ger vê taybetmendiya `char` xwedan taybetmendiya `Grapheme_Extend` be, `true` vedigerîne.
    ///
    /// `Grapheme_Extend` di [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] de tête vegotin û di [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] de tête diyar kirin.
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// `true` vedigerîne heke ev `char` ji bo hejmaran yek ji kategoriyên gelemperî hebe.
    ///
    /// Kategoriyên gelemperî ji bo hejmaran (`Nd` ji bo reqemên dehjimarî, `Nl` ji bo tîpên hejmarî yên mîna herfê, û `No` ji bo tîpên din ên hejmarî) di [Unicode Character Database][ucd] [`UnicodeData.txt`] de têne diyar kirin.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Iteratorê vedigerîne ku nexşeya hûrguliya vê `char` wekî yek an jî zêdetir dide
    /// `char`s.
    ///
    /// Ger ev `char` nexşeyek hûrgelan tune, iterator heman `char` dide.
    ///
    /// Ger ev `char` nexşeyek yek-yek a ji hêla [Unicode Character Database][ucd] [`UnicodeData.txt`] ve hatî dayîn hebe, veberhêner wê `char` dide.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Heke ev `char` hewceyê ramanên taybetî be (mînakî `pir` char`) iterator`` char` (ên) ku ji hêla [`SpecialCasing.txt`] ve hatî dayîn dide.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Vê operasyonê nexşeyek bê şert û merc bêyî dirûvê pêk tîne.Ango, veguherîn ji kontekst û ziman serbixwe ye.
    ///
    /// Di [Unicode Standard] de, Beşa 4-an (Taybetmendiyên Nîşan) bi gelemperî nexşeya dozê û Beşa 3-an jî (Conformance) behsa algorîtmaya pêşkeftî ya ji bo veguheztina dozê dike.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Wekî veberhêner:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` rasterast bikar tînin:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Herdu jî wekhev in:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// `to_string` bikar tînin:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Carinan encam ji yekê zêdetir karakterek e:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Karakterên ku hem mezin û hem jî piçûk ne li wan vediguhêzin.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Iteratorê vedigerîne ku nexşeya mezin a vê `char` wekî yek an jî zêdetir dide
    /// `char`s.
    ///
    /// Ger ev `char` nexşeyek mezin nîn be, iterator heman `char` dide.
    ///
    /// Ger ev `char` nexşeyek mezin a yek bi yek heye ku ji hêla [Unicode Character Database][ucd] [`UnicodeData.txt`] ve hatî dayîn, iterator wê `char` dide.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Heke ev `char` hewceyê ramanên taybetî be (mînakî `pir` char`) iterator`` char` (ên) ku ji hêla [`SpecialCasing.txt`] ve hatî dayîn dide.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Vê operasyonê nexşeyek bê şert û merc bêyî dirûvê pêk tîne.Ango, veguherîn ji kontekst û ziman serbixwe ye.
    ///
    /// Di [Unicode Standard] de, Beşa 4-an (Taybetmendiyên Nîşan) bi gelemperî nexşeya dozê û Beşa 3-an jî (Conformance) behsa algorîtmaya pêşkeftî ya ji bo veguheztina dozê dike.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Wekî veberhêner:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` rasterast bikar tînin:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Herdu jî wekhev in:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// `to_string` bikar tînin:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Carinan encam ji yekê zêdetir karakterek e:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Karakterên ku hem mezin û hem jî piçûk ne li wan vediguhêzin.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Nîşe li ser locale
    ///
    /// Di tirkî de, di Latin de hevwateya 'i' di şûna du de pênc form hene:
    ///
    /// * 'Dotless': Ez/ı, carinan written dinivîsim
    /// * 'Dotted': İ/ez
    ///
    /// Bala xwe bidinê ku 'i' xalxalokî piçûk eynî Latînî ye.Ji ber vê yekê:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Nirxa `upper_i` li vir xwe dispêre zimanê nivîsarê: heke em di `en-US` de ne, divê ew `"I"` be, lê heke em di `tr_TR` de bin, divê ew `"İ"` be.
    /// `to_uppercase()` viya li ber çav nagire, û wusa:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// li seranserê zimanan digire.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Kontrol dike ku gelo nirx di nav ASCII de ye.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Di hevkêşeya xweya mezin a ASCII de nusxeyek ji nirxê çêdike.
    ///
    /// Nameyên ASCII 'a' bo 'z' bi 'A' bo 'Z' têne nexşekirin, lê tîpên ne-ASCII neguhêrîn.
    ///
    /// Ji bo ku nirxê di cîh de mezin bikin, [`make_ascii_uppercase()`] bikar bînin.
    ///
    /// Ji bo tîpên ASCII mezin jî bila karakterên ne-ASCII, [`to_uppercase()`] bikar bînin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Di hevkêşeya xweya piçûk a ASCII de nusxeyek ji nirxê çêdike.
    ///
    /// Nameyên ASCII 'A' bo 'Z' bi 'a' bo 'z' têne nexşekirin, lê tîpên ne-ASCII neguhêrîn.
    ///
    /// Ji bo ku nirxê di cîh de biçûk bikin, [`make_ascii_lowercase()`] bikar bînin.
    ///
    /// Ji bo ku ji bilî tîpên ne-ASCII tîpên ASCII biçûk bin jî, [`to_lowercase()`] bikar bînin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Kontrol dike ku du nirx hevahengîyek ASSII-mesele ne-hesas in.
    ///
    /// Bi `to_ascii_lowercase(a) == to_ascii_lowercase(b)` re wekhev e.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Vî celebî di cîh de wekheviya xwe ya mezin ASCII vedigire.
    ///
    /// Nameyên ASCII 'a' bo 'z' bi 'A' bo 'Z' têne nexşekirin, lê tîpên ne-ASCII neguhêrîn.
    ///
    /// Ji bo ku bêyî guhertina ya heyî nirxek mezin nû vegerînin, [`to_ascii_uppercase()`] bikar bînin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Vî celebî di cîh de wekheviya xweya piçûk a ASCII vedigire.
    ///
    /// Nameyên ASCII 'A' bo 'Z' bi 'a' bo 'z' têne nexşekirin, lê tîpên ne-ASCII neguhêrîn.
    ///
    /// Ji bo ku bêyî guhertina ya heyî, nirxek nû ya jêrîn vegerînin, [`to_ascii_lowercase()`] bikar bînin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Kontrol dike ka gelo nirx qarekterek elfabeya ASCII e an na:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', an
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Kontrol dike ku gelo nirx qarekterek mezin a ASCII ye:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Kontrol dike ka gelo nirxê tîpek piçûk a ASCII ye:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Kontrol dike ku gelo nirxê kesayetek alfanî ya ASCII e an na:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', an
    /// - U + 0061 'a' ..=U + 007A 'z', an
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Kontrol dike ku gelo nirxê reqemî ya dehanî ya ASCII ye:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Kontrol dike ku gelo nirx hejmar hejmar-hejmar ASCII ye:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', an
    /// - U + 0041 'A' ..=U + 0046 'F', an
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Kontrol dike ku gelo nirx nirxê xalbendiya ASCII e:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, an
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, an
    /// - U + 005B ..=U + 0060 "[\] ^ _" ``, an
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Kontrol dike ku gelo nirx qarektera grafîkî ya ASCII e an na:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Kontrol dike ku gelo nirxê kesayetiyek qada spî ya ASCII e an na:
    /// U + 0020 SPACE, U + 0009 HORIZONTAL TAB, U + 000A FINE FINE, U + 000C FORM FEED, or U + 000D CARRIAGE RETURN.
    ///
    /// Rust WhatWG Infra Standard's [definition of ASCII whitespace][infra-aw] bikar tîne.Di karanîna pirfireh de çend pênaseyên din jî hene.
    /// Mînakî, [the POSIX locale][pct] U + 000B TAB VERTICAL û her weha hemî tîpên jorîn tê de hene, lê-ji heman taybetmendiyê ve-[qaîdeya xwerû ji bo "field splitting" li Bourne shell][bfs]*tenê* CIH, TOROR HORIZONTAL, û LINE FEED wekî qada spî.
    ///
    ///
    /// Heke hûn bernameyek dinivîsin ku dê formatek pelê ya heyî pêvajoyê bike, berî karanîna vê fonksiyonê binihêrin ka pênaseya wê formatê ya qada spî çi ye.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Kontrol dike ku gelo nirxê kesayetiyek kontrolê ya ASCII ye:
    /// U + 0000 NUL ..=U + 001F Dabeşkerê YEKT, an U + 007F JLEDE.
    /// Zanibe ku piraniya karakterên spî ASCII tîpên kontrolê ne, lê SPACE ne ew e.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Nirxek u32 ya xav wekî UTF-8 dixe nav tampona byte ya peyda kirî de, û dûv re subsalava tampona ku karakterê kodkirî vedigire vedigerîne.
///
///
/// Berevajî `char::encode_utf8`, ev rêbaza di heman demê de kodepointên di qada cîgir de jî digire dest.
/// (Afirandina `char` di qada cîgir de UB ye.) Encam [generalized UTF-8] derbasdar e lê UTF-8 ne derbasdar e.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Heke tampon ne têra xwe mezin be Panics.
/// Tamponek bi dirêjahiya çar bes mezin e ku dikare `char` kod bike.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Nirxek u32 ya xav wekî UTF-16 vedigire nav tampona `u16` ya hatî peyda kirin, û dûv re subsalava tampona ku karakterê kodkirî vedigire vedigerîne.
///
///
/// Berevajî `char::encode_utf16`, ev rêbaza di heman demê de kodepointên di qada cîgir de jî digire dest.
/// (Afirandina `char` di qada cîgir de UB ye.)
///
/// # Panics
///
/// Heke tampon ne têra xwe mezin be Panics.
/// Tamponek bi dirêjahiya 2 têra xwe mezin e ku dikare her `char` kod bike.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // EWLEHIY: : her dest kontrol dike ka têra bes bît hene ku werin nivîsandin
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP dikeve
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Balafirên pêvek dikeve cîgir.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}