//! Bawermendên berhevkar.
//!
//! Pênaseyên pêwendîdar di `compiler/rustc_codegen_llvm/src/intrinsic.rs` de ne.
//! Pêkanînên pêkhatî yên têkildar di `compiler/rustc_mir/src/interpret/intrinsics.rs` de ne
//!
//! # Hûndirê saz
//!
//! Note: her guherînek di sabitiya hundirîn de divê bi tîmê ziman re were nîqaş kirin.
//! Di vê yekê de guherînên aramiya zexmbûnê hene.
//!
//! Ji bo ku di dema berhevkirinê de xwerûyek bikêr were, pêdivî ye ku meriv ji <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> bo `compiler/rustc_mir/src/interpret/intrinsics.rs` pêkanînê kopî bike û `#[rustc_const_unstable(feature = "foo", issue = "01234")]` li xwemalî zêde bike.
//!
//!
//! Ger tê xwestin ku xwerûyek ji `const fn` bi taybetmendiya `rustc_const_stable` were bikar anîn, divê taybetmendiya xwerû jî `rustc_const_stable` be.
//! Pêdivî ye ku guherînek wusa bêyî şêwirmendiya T-lang neyê kirin, ji ber ku ew taybetmendiyek dixe nav zimên ku bêyî piştgiriya berhevkar di kodê bikarhêner de nayê dubare kirin.
//!
//! # Volatiles
//!
//! Navgînên berbiçav operasyonên armanc dikin ku li ser bîranîna I/O tevbigerin, yên ku têne garantîkirin ku ji hêla berhevkar ve li nav deverên din ên berbiçav ên din nayên rêz kirin.Li ser [[volatile]] belgeya LLVM bibînin.
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Jînewerên atomê li ser peyvên makîneyê, bi gelek rêzikên bîranîna gengaz, karûbarên atomî yên hevpar peyda dikin.Ew ji heman semantîkî wekî C++ 11 guhdarî dikin.Li ser [[atomics]] belgeya LLVM bibînin.
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Nûvekirina bilez a li ser rêzkirina bîranînê:
//!
//! * Wergirtin, astengiyek ji bo bidestxistina qeflek.Paşê xwendin û nivîsandin piştî bendê pêk tê.
//! * Serbestberdan, astengiyek ji bo berdana qeflek.Pêşiya xwendin û nivîsînê li ber bendê pêk tê.
//! * Rêzkirinên li pey hev, operasyonên li pey hev têne garantîkirin ku bi rêzê pêk tên.Ev awayê standard e ku ji bo xebata bi celebên atomî re ye û bi Java's `volatile` re hevber e.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Van îthal ji bo hêsankirina girêdanên hundur-dok têne bikar anîn
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // BELA: `ptr::drop_in_place` binihêrin
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, van xwerû nîşangirên xav digirin ji ber ku ew bîranîna aliased mutate dikin, ku ne ji bo `&` an `&mut` ne derbasdar e.
    //

    /// Heke nirxa heyî heman nirxê `old` be, nirxek tomar dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `compare_exchange` derbas dibe ku [`Ordering::SeqCst`] wekî hem parametreyên `success` û `failure` derbas dike.
    ///
    /// Bo nimûne, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Heke nirxa heyî heman nirxê `old` be, nirxek tomar dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `compare_exchange` derbas dibe [`Ordering::Acquire`] wekî `success` û `failure` mîhengan derbas dike.
    ///
    /// Bo nimûne, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Heke nirxa heyî heman nirxê `old` be, nirxek tomar dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `compare_exchange` derbas dibe [`Ordering::Release`] wekî `success` û [`Ordering::Relaxed`] wekî pîvanên `failure` derbas dike.
    /// Bo nimûne, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Heke nirxa heyî heman nirxê `old` be, nirxek tomar dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `compare_exchange` derbas dibe [`Ordering::AcqRel`] wekî `success` û [`Ordering::Acquire`] wekî pîvanên `failure` derbas dike.
    /// Bo nimûne, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Heke nirxa heyî heman nirxê `old` be, nirxek tomar dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `compare_exchange` derbas dibe [`Ordering::Relaxed`] wekî `success` û `failure` mîhengan derbas dike.
    ///
    /// Bo nimûne, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Heke nirxa heyî heman nirxê `old` be, nirxek tomar dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `compare_exchange` derbas dibe [`Ordering::SeqCst`] wekî `success` û [`Ordering::Relaxed`] wekî pîvanên `failure` derbas dike.
    /// Bo nimûne, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Heke nirxa heyî heman nirxê `old` be, nirxek tomar dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `compare_exchange` derbas dibe [`Ordering::SeqCst`] wekî `success` û [`Ordering::Acquire`] wekî pîvanên `failure` derbas dike.
    /// Bo nimûne, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Heke nirxa heyî heman nirxê `old` be, nirxek tomar dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `compare_exchange` derbas dibe [`Ordering::Acquire`] wekî `success` û [`Ordering::Relaxed`] wekî pîvanên `failure` derbas dike.
    /// Bo nimûne, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Heke nirxa heyî heman nirxê `old` be, nirxek tomar dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `compare_exchange` derbas dibe [`Ordering::AcqRel`] wekî `success` û [`Ordering::Relaxed`] wekî pîvanên `failure` derbas dike.
    /// Bo nimûne, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Heke nirxa heyî heman nirxê `old` be, nirxek tomar dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `compare_exchange_weak` derbas dibe [`Ordering::SeqCst`] wekî `success` û `failure` mîhengan derbas dike.
    ///
    /// Bo nimûne, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Heke nirxa heyî heman nirxê `old` be, nirxek tomar dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `compare_exchange_weak` derbas dibe [`Ordering::Acquire`] wekî `success` û `failure` mîhengan derbas dike.
    ///
    /// Bo nimûne, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Heke nirxa heyî heman nirxê `old` be, nirxek tomar dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::Release`] wekî `success` û [`Ordering::Relaxed`] wekî pîvanên `failure` li ser celebên [`atomic`] bi rêbaza `compare_exchange_weak` heye.
    /// Bo nimûne, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Heke nirxa heyî heman nirxê `old` be, nirxek tomar dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::AcqRel`] wekî `success` û [`Ordering::Acquire`] wekî pîvanên `failure` li ser celebên [`atomic`] bi rêbaza `compare_exchange_weak` heye.
    /// Bo nimûne, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Heke nirxa heyî heman nirxê `old` be, nirxek tomar dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `compare_exchange_weak` derbas dibe [`Ordering::Relaxed`] wekî `success` û `failure` mîhengan derbas dike.
    ///
    /// Bo nimûne, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Heke nirxa heyî heman nirxê `old` be, nirxek tomar dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `compare_exchange_weak` derbas dibe [`Ordering::SeqCst`] wekî `success` û [`Ordering::Relaxed`] wekî pîvanên `failure` derbas dike.
    /// Bo nimûne, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Heke nirxa heyî heman nirxê `old` be, nirxek tomar dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `compare_exchange_weak` derbas dibe [`Ordering::SeqCst`] wekî `success` û [`Ordering::Acquire`] wekî pîvanên `failure` derbas dike.
    /// Bo nimûne, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Heke nirxa heyî heman nirxê `old` be, nirxek tomar dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `compare_exchange_weak` derbas dibe [`Ordering::Acquire`] wekî `success` û [`Ordering::Relaxed`] wekî pîvanên `failure` derbas dike.
    /// Bo nimûne, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Heke nirxa heyî heman nirxê `old` be, nirxek tomar dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `compare_exchange_weak` derbas dibe [`Ordering::AcqRel`] wekî `success` û [`Ordering::Relaxed`] wekî pîvanên `failure` derbas dike.
    /// Bo nimûne, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Nirxa heyî ya nîşanker bar dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `load` derbas dibe [`Ordering::SeqCst`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Nirxa heyî ya nîşanker bar dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `load` derbas dibe [`Ordering::Acquire`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Nirxa heyî ya nîşanker bar dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `load` derbas dibe [`Ordering::Relaxed`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Nirxê li cîhê bîranîna diyarkirî tomar dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `store` derbas dibe [`Ordering::SeqCst`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Nirxê li cîhê bîranîna diyarkirî tomar dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `store` derbas dibe [`Ordering::Release`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Nirxê li cîhê bîranîna diyarkirî tomar dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `store` derbas dibe [`Ordering::Relaxed`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Nirxê li cîhê bîranîna diyarkirî tomar dike, nirxa kevn vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `swap` derbas dibe [`Ordering::SeqCst`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nirxê li cîhê bîranîna diyarkirî tomar dike, nirxa kevn vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `swap` derbas dibe [`Ordering::Acquire`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nirxê li cîhê bîranîna diyarkirî tomar dike, nirxa kevn vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `swap` derbas dibe [`Ordering::Release`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nirxê li cîhê bîranîna diyarkirî tomar dike, nirxa kevn vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `swap` derbas dibe [`Ordering::AcqRel`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nirxê li cîhê bîranîna diyarkirî tomar dike, nirxa kevn vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `swap` derbas dibe [`Ordering::Relaxed`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Nirxa heyî zêde dike, nirxa berê vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `fetch_add` derbas dibe [`Ordering::SeqCst`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nirxa heyî zêde dike, nirxa berê vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `fetch_add` derbas dibe [`Ordering::Acquire`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nirxa heyî zêde dike, nirxa berê vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `fetch_add` derbas dibe [`Ordering::Release`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nirxa heyî zêde dike, nirxa berê vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `fetch_add` derbas dibe [`Ordering::AcqRel`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nirxa heyî zêde dike, nirxa berê vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `fetch_add` derbas dibe [`Ordering::Relaxed`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ji nirxa heyî dakêşin, nirxa berê vegerînin.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `fetch_sub` derbas dibe [`Ordering::SeqCst`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ji nirxa heyî dakêşin, nirxa berê vegerînin.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `fetch_sub` derbas dibe [`Ordering::Acquire`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ji nirxa heyî dakêşin, nirxa berê vegerînin.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `fetch_sub` derbas dibe [`Ordering::Release`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ji nirxa heyî dakêşin, nirxa berê vegerînin.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `fetch_sub` derbas dibe [`Ordering::AcqRel`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ji nirxa heyî dakêşin, nirxa berê vegerînin.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `fetch_sub` derbas dibe [`Ordering::Relaxed`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise û bi nirxa heyî, vegera nirxa berê.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `fetch_and` derbas dibe [`Ordering::SeqCst`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise û bi nirxa heyî, vegera nirxa berê.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `fetch_and` derbas dibe [`Ordering::Acquire`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise û bi nirxa heyî, vegera nirxa berê.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `fetch_and` derbas dibe [`Ordering::Release`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise û bi nirxa heyî, vegera nirxa berê.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `fetch_and` derbas dibe [`Ordering::AcqRel`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise û bi nirxa heyî, vegera nirxa berê.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `fetch_and` derbas dibe [`Ordering::Relaxed`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise nand bi nirxa heyî, vedigere nirxa berê.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::SeqCst`] wekî `order` bi rêbaza `fetch_nand` li ser celebê [`AtomicBool`] heye.
    /// Bo nimûne, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand bi nirxa heyî, vedigere nirxa berê.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::Acquire`] wekî `order` bi rêbaza `fetch_nand` li ser celebê [`AtomicBool`] heye.
    /// Bo nimûne, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand bi nirxa heyî, vedigere nirxa berê.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::Release`] wekî `order` bi rêbaza `fetch_nand` li ser celebê [`AtomicBool`] heye.
    /// Bo nimûne, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand bi nirxa heyî, vedigere nirxa berê.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::AcqRel`] wekî `order` bi rêbaza `fetch_nand` li ser celebê [`AtomicBool`] heye.
    /// Bo nimûne, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand bi nirxa heyî, vedigere nirxa berê.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::Relaxed`] wekî `order` bi rêbaza `fetch_nand` li ser celebê [`AtomicBool`] heye.
    /// Bo nimûne, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise an bi nirxa heyî, vegera nirxa berê.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `fetch_or` derbas dibe [`Ordering::SeqCst`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise an bi nirxa heyî, vegera nirxa berê.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `fetch_or` derbas dibe [`Ordering::Acquire`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise an bi nirxa heyî, vegera nirxa berê.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `fetch_or` derbas dibe [`Ordering::Release`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise an bi nirxa heyî, vegera nirxa berê.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `fetch_or` derbas dibe [`Ordering::AcqRel`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise an bi nirxa heyî, vegera nirxa berê.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `fetch_or` derbas dibe [`Ordering::Relaxed`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor bi nirxê heyî, vedigere nirxa berê.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `fetch_xor` derbas dibe [`Ordering::SeqCst`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor bi nirxê heyî, vedigere nirxa berê.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `fetch_xor` derbas dibe [`Ordering::Acquire`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor bi nirxê heyî, vedigere nirxa berê.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `fetch_xor` derbas dibe [`Ordering::Release`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor bi nirxê heyî, vedigere nirxa berê.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `fetch_xor` derbas dibe [`Ordering::AcqRel`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor bi nirxê heyî, vedigere nirxa berê.
    ///
    /// Guhertoya aramkirî ya vê xwemalî li ser cûrên [`atomic`] bi rêbaza `fetch_xor` derbas dibe [`Ordering::Relaxed`] wekî `order` derbas dibe.
    /// Bo nimûne, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ya herî zêde bi nirxa heyî re berhevdanek îmzekirî bikar tîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::SeqCst`] wekî `order` ve li ser cûreyên jimare yên îmze kirin [`atomic`] bi rêbaza `fetch_max` heye.
    /// Bo nimûne, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ya herî zêde bi nirxa heyî re berhevdanek îmzekirî bikar tîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::Acquire`] wekî `order` ve li ser cûreyên jimare yên îmze kirin [`atomic`] bi rêbaza `fetch_max` heye.
    /// Bo nimûne, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ya herî zêde bi nirxa heyî re berhevdanek îmzekirî bikar tîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::Release`] wekî `order` ve li ser cûreyên jimare yên îmze kirin [`atomic`] bi rêbaza `fetch_max` heye.
    /// Bo nimûne, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ya herî zêde bi nirxa heyî re berhevdanek îmzekirî bikar tîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::AcqRel`] wekî `order` ve li ser cûreyên jimare yên îmze kirin [`atomic`] bi rêbaza `fetch_max` heye.
    /// Bo nimûne, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bi nirxa heyî re herî zêde.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::Relaxed`] wekî `order` ve li ser cûreyên jimare yên îmze kirin [`atomic`] bi rêbaza `fetch_max` heye.
    /// Bo nimûne, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Kêmtirîn bi nirxa heyî re berawirdek îmzekirî bikar tîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::SeqCst`] wekî `order` ve li ser cûreyên jimare yên îmze kirin [`atomic`] bi rêbaza `fetch_min` heye.
    /// Bo nimûne, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kêmtirîn bi nirxa heyî re berawirdek îmzekirî bikar tîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::Acquire`] wekî `order` ve li ser cûreyên jimare yên îmze kirin [`atomic`] bi rêbaza `fetch_min` heye.
    /// Bo nimûne, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kêmtirîn bi nirxa heyî re berawirdek îmzekirî bikar tîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::Release`] wekî `order` ve li ser cûreyên jimare yên îmze kirin [`atomic`] bi rêbaza `fetch_min` heye.
    /// Bo nimûne, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kêmtirîn bi nirxa heyî re berawirdek îmzekirî bikar tîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::AcqRel`] wekî `order` ve li ser cûreyên jimare yên îmze kirin [`atomic`] bi rêbaza `fetch_min` heye.
    /// Bo nimûne, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kêmtirîn bi nirxa heyî re berawirdek îmzekirî bikar tîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::Relaxed`] wekî `order` ve li ser cûreyên jimare yên îmze kirin [`atomic`] bi rêbaza `fetch_min` heye.
    /// Bo nimûne, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Kêmtirîn bi nirxa heyî re berawirdek nenaskirî bikar tîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::SeqCst`] wekî `order` ve li ser cûreyên jimare yên nevekirî [`atomic`] bi rêbaza `fetch_min` heye.
    /// Bo nimûne, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kêmtirîn bi nirxa heyî re berawirdek nenaskirî bikar tîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::Acquire`] wekî `order` ve li ser cûreyên jimare yên nevekirî [`atomic`] bi rêbaza `fetch_min` heye.
    /// Bo nimûne, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kêmtirîn bi nirxa heyî re berawirdek nenaskirî bikar tîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::Release`] wekî `order` ve li ser cûreyên jimare yên nevekirî [`atomic`] bi rêbaza `fetch_min` heye.
    /// Bo nimûne, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kêmtirîn bi nirxa heyî re berawirdek nenaskirî bikar tîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::AcqRel`] wekî `order` ve li ser cûreyên jimare yên nevekirî [`atomic`] bi rêbaza `fetch_min` heye.
    /// Bo nimûne, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kêmtirîn bi nirxa heyî re berawirdek nenaskirî bikar tîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::Relaxed`] wekî `order` ve li ser cûreyên jimare yên nevekirî [`atomic`] bi rêbaza `fetch_min` heye.
    /// Bo nimûne, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ya herî zêde bi nirxa heyî re berhevdanek nevekirî bikar tîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::SeqCst`] wekî `order` ve li ser cûreyên jimare yên nevekirî [`atomic`] bi rêbaza `fetch_max` heye.
    /// Bo nimûne, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ya herî zêde bi nirxa heyî re berhevdanek nevekirî bikar tîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::Acquire`] wekî `order` ve li ser cûreyên jimare yên nevekirî [`atomic`] bi rêbaza `fetch_max` heye.
    /// Bo nimûne, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ya herî zêde bi nirxa heyî re berhevdanek nevekirî bikar tîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::Release`] wekî `order` ve li ser cûreyên jimare yên nevekirî [`atomic`] bi rêbaza `fetch_max` heye.
    /// Bo nimûne, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ya herî zêde bi nirxa heyî re berhevdanek nevekirî bikar tîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::AcqRel`] wekî `order` ve li ser cûreyên jimare yên nevekirî [`atomic`] bi rêbaza `fetch_max` heye.
    /// Bo nimûne, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ya herî zêde bi nirxa heyî re berhevdanek nevekirî bikar tîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::Relaxed`] wekî `order` ve li ser cûreyên jimare yên nevekirî [`atomic`] bi rêbaza `fetch_max` heye.
    /// Bo nimûne, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// `prefetch` navxweyî şîretek li jeneratorê kodê ye ku heke piştgirî be talîmatek pêşdîtinê têxe;wekî din, ew ne-op ye.
    /// Prefetches li ser tevgera bernameyê bandor nake lê dikare taybetmendiyên performansa wê biguheze.
    ///
    /// Nîqaşa `locality` divê jimareyek domdar be û diyarkeriyek cîgayî ya demkî ye ku ji (0), no herêmî, heya (3), pir herêmî di cache de bimîne.
    ///
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// `prefetch` navxweyî şîretek li jeneratorê kodê ye ku heke piştgirî be talîmatek pêşdîtinê têxe;wekî din, ew ne-op ye.
    /// Prefetches li ser tevgera bernameyê bandor nake lê dikare taybetmendiyên performansa wê biguheze.
    ///
    /// Nîqaşa `locality` divê jimareyek domdar be û diyarkeriyek cîgayî ya demkî ye ku ji (0), no herêmî, heya (3), pir herêmî di cache de bimîne.
    ///
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// `prefetch` navxweyî şîretek li jeneratorê kodê ye ku heke piştgirî be talîmatek pêşdîtinê têxe;wekî din, ew ne-op ye.
    /// Prefetches li ser tevgera bernameyê bandor nake lê dikare taybetmendiyên performansa wê biguheze.
    ///
    /// Nîqaşa `locality` divê jimareyek domdar be û diyarkeriyek cîgayî ya demkî ye ku ji (0), no herêmî, heya (3), pir herêmî di cache de bimîne.
    ///
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// `prefetch` navxweyî şîretek li jeneratorê kodê ye ku heke piştgirî be talîmatek pêşdîtinê têxe;wekî din, ew ne-op ye.
    /// Prefetches li ser tevgera bernameyê bandor nake lê dikare taybetmendiyên performansa wê biguheze.
    ///
    /// Nîqaşa `locality` divê jimareyek domdar be û diyarkeriyek cîgayî ya demkî ye ku ji (0), no herêmî, heya (3), pir herêmî di cache de bimîne.
    ///
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Razorek atomî.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::SeqCst`] wekî `order` di [`atomic::fence`] de heye.
    ///
    ///
    pub fn atomic_fence();
    /// Razorek atomî.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::Acquire`] wekî `order` di [`atomic::fence`] de heye.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Razorek atomî.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::Release`] wekî `order` di [`atomic::fence`] de heye.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Razorek atomî.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::AcqRel`] wekî `order` di [`atomic::fence`] de heye.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Astengiya bîranînê ya tenê berhevkar.
    ///
    /// Destkeftiyên bîranînê dê ji hêla berhevkar ve li çaraliyê vê astê ji nû ve neyê rêkûpêk kirin, lê ji bo wê ti talîmat nayê weşandin.
    /// Ev ji bo operasyonên li ser heman tîrêja ku dibe ku pêşî lê were girtin, guncan e, mînakî dema ku bi kargêrên sînyalê re têkilî danîn.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::SeqCst`] wekî `order` di [`atomic::compiler_fence`] de heye.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Astengiya bîranînê ya tenê berhevkar.
    ///
    /// Destkeftiyên bîranînê dê ji hêla berhevkar ve li çaraliyê vê astê ji nû ve neyê rêkûpêk kirin, lê ji bo wê ti talîmat nayê weşandin.
    /// Ev ji bo operasyonên li ser heman tîrêja ku dibe ku pêşî lê were girtin, guncan e, mînakî dema ku bi kargêrên sînyalê re têkilî danîn.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::Acquire`] wekî `order` di [`atomic::compiler_fence`] de heye.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Astengiya bîranînê ya tenê berhevkar.
    ///
    /// Destkeftiyên bîranînê dê ji hêla berhevkar ve li çaraliyê vê astê ji nû ve neyê rêkûpêk kirin, lê ji bo wê ti talîmat nayê weşandin.
    /// Ev ji bo operasyonên li ser heman tîrêja ku dibe ku pêşî lê were girtin, guncan e, mînakî dema ku bi kargêrên sînyalê re têkilî danîn.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::Release`] wekî `order` di [`atomic::compiler_fence`] de heye.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Astengiya bîranînê ya tenê berhevkar.
    ///
    /// Destkeftiyên bîranînê dê ji hêla berhevkar ve li çaraliyê vê astê ji nû ve neyê rêkûpêk kirin, lê ji bo wê ti talîmat nayê weşandin.
    /// Ev ji bo operasyonên li ser heman tîrêja ku dibe ku pêşî lê were girtin, guncan e, mînakî dema ku bi kargêrên sînyalê re têkilî danîn.
    ///
    /// Guhertoya aramkirî ya vê xwemalî bi derbaskirina [`Ordering::AcqRel`] wekî `order` di [`atomic::compiler_fence`] de heye.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Sêrbaziya navxweyî ku wateya xwe ji taybetmendiyên bi fonksiyonê ve girêdayî digire.
    ///
    /// Mînakî, gerguhêza daneyê vê yekê bikar tîne da ku îdiayên statîk derzîne da ku `rustc_peek(potentially_uninitialized)` bi rastî du carî venêran ku gera daneyê bi rastî hesab kir ku ew di wê xalê de di herika kontrolê de nezewicî ye.
    ///
    ///
    /// Divê ev xwerû li derveyî berhevkar neyê bikar anîn.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Pêkanîna pêvajoyê kurt dike.
    ///
    /// Guhertoyek bêtir bikarhêner-heval û aram a vê operasyonê [`std::process::abort`](../../std/process/fn.abort.html) e.
    ///
    pub fn abort() -> !;

    /// Optimîzatorê agahdar dike ku ev xala kodê ne gihîştbar e, çêtirîn optimîzasyonan dike.
    ///
    /// NB, ev ji makroya `unreachable!()` pir cuda ye: Berevajî makroya, ku panics dema ku tê darve kirin,*ew tevgerek ne diyar e* ku bigihîje koda ku bi vê fonksiyonê hatî nîşankirin.
    ///
    ///
    /// Guhertoya aramkirî ya vê xwemalî [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked) e.
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Optîmîzerê agahdar dike ku rewş her dem rast e.
    /// Ger şert derew e, tevger nayê diyar kirin.
    ///
    /// Ji bo vê xwerû kodek çênebûye, lê çêker dê hewl bide ku wê (û rewşa wê) di navbera pasan de biparêze, ku dibe ku bi optimîzasyona koda dorhêlê re têkeve navberê û performansê kêm bike.
    /// Pêdivî ye ku ew neyê bikar anîn heke neguhêrbar ji hêla optimîzatorê ve bi serê xwe ve were kifş kirin, an heke ew çêtirîn optimîzasyonan çênekir.
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Ji berhevkar re şîretan dike ku rewşa branch dibe ku rast be.
    /// Nirxa ku jê re derbas bûye vedigerîne.
    ///
    /// Her karanîna ji bil daxuyaniyên `if` dê belkî bandorek neke.
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Ji berhevkar re şîretan dike ku dibe ku rewşa branch derew be.
    /// Nirxa ku jê re derbas bûye vedigerîne.
    ///
    /// Her karanîna ji bil daxuyaniyên `if` dê belkî bandorek neke.
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Xefikek xala veqetandinê, ji bo venêrana ji hêla çewtî ve.
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    pub fn breakpoint();

    /// Mezinahiya celebek li byte.
    ///
    /// Bi taybetî, ev di nav bayîtan de di navbera hêmanên li pey hev ên bi eynî cûreyê de, di nav wan de pileya rêzkirinê jî, vezelîne.
    ///
    ///
    /// Guhertoya aramkirî ya vê xwemalî [`core::mem::size_of`](crate::mem::size_of) e.
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Rêzkirina herî kêm a celebek.
    ///
    /// Guhertoya aramkirî ya vê xwemalî [`core::mem::align_of`](crate::mem::align_of) e.
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Rêzkirina bijartekek celebek.
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Mezinahiya nirxa referanskirî di bajaran de.
    ///
    /// Guhertoya aramkirî ya vê xwemalî [`mem::size_of_val`] e.
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Rêzkirina hewceyê nirxa referanskirî.
    ///
    /// Guhertoya aramkirî ya vê xwemalî [`core::mem::align_of_val`](crate::mem::align_of_val) e.
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Navê cûreyekê tê de qurmek stantîk a statîkî digire.
    ///
    /// Guhertoya aramkirî ya vê xwemalî [`core::any::type_name`](crate::any::type_name) e.
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Nasnameyek werdigire ku li seranserê cîhanê ji celebê diyarkirî re yekta ye.
    /// Ev fonksiyon dê ji bo celebek heman nirxê vegerîne bê ka li kîjan crate tê vexwendin.
    ///
    ///
    /// Guhertoya aramkirî ya vê xwemalî [`core::any::TypeId::of`](crate::any::TypeId::of) e.
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Cerdevanek ji bo fonksiyonên ewle ku heke `T` neşênebûyî çênabe were darve kirin:
    /// Ev dê bi statîkî an panic be, an jî tiştek neke.
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Cerdevanek ji bo fonksiyonên ewledar ku ger `T` nahêle destpêkirina sifir destûrê nede tu carî nayê darve kirin: Ev ê bi statîkî an panic, an jî tiştek neke.
    ///
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    pub fn assert_zero_valid<T>();

    /// Cerdevanek ji bo fonksiyonên ewledar ku ger `T` nimûneyên bitek nederbasdar hebin tu carî nayê darve kirin: Ev dê bi statîkî an panic be, an jî tiştek neke.
    ///
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    pub fn assert_uninit_valid<T>();

    /// Li ser `Location`-a statîk referansê digire û diyar dike ku ew li ku derê hatiye bang kirin.
    ///
    /// Li şûna [`core::panic::Location::caller`](crate::panic::Location::caller) bikar bînin bifikirin.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Bêyî ku lepikê dilopê bavêje nirxek ji qadê bar dike.
    ///
    /// Ev tenê ji bo [`mem::forget_unsized`] heye;normal `forget` li şûna `ManuallyDrop` bikar tîne.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Bitên nirxek celebek wekî celebek din şîrove dike.
    ///
    /// Pêdivî ye ku her du celeb xwedan eynî mezinahî bin.
    /// Ne orjînal, ne jî encam, dibe ku nebe [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` ji hêla semantîkî ve wekhev e ku bi celebek veguherînek celebek din re derbas dibe.Ew bitên ji nirxê çavkanî di nirxa armancê de kopî dike, paşê orjînal ji bîr dike.
    /// Ew wek `transmute_copy` di binê kulikê de wekhevî ya C's `memcpy` ye.
    ///
    /// Ji ber ku `transmute` operasyonek bi-nirx e, rêzkirina *nirxên veguheztî bixwe* ne xem e.
    /// Wekî her fonksiyonek din, berhevkar jixwe piştrast dike ku hem `T` hem jî `U` bi rêkûpêk li hev hatine.
    /// Lêbelê, dema ku nirxên ku *li cîhek* din didin veguhezîne (wekî nîşanker, çavkanî, qutiyên), bangvan pêdivî ye ku lihevnêzîkkirina guncan a nirxên berbiçav piştrast bike.
    ///
    /// `transmute` **bêhempa** ne ewle ye.Gelek awayên ku bi vê fonksiyonê re dibe sedema [undefined behavior][ub] hene.`transmute` divê çareya dawîn a mutleq be.
    ///
    /// [nomicon](../../nomicon/transmutes.html) belgeyek din heye.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Çend tişt hene ku `transmute` ji bo wan bi rastî kêrhatî ye.
    ///
    /// Zivirandina pêşnumayekê nav pêşekek fonksiyonê.Ev *ne* barkêş e bo makîneyên ku nîşankerên fonksiyonê û nîşankerên daneyê xwedan mezinahiyên cuda ne.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Jiyana xwe dirêj kirin, an jîyanek neguhêz kurt kirin.Ev Rust pêşkeftî ye, pir ewle ne!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Bêhêvî nebin: gelek karanînên `transmute` dikarin bi rêyên din werin bidest xistin.
    /// Li jêr serîlêdanên hevpar ên `transmute` hene ku dikarin bi avahiyên ewletir werin guhertin.
    ///
    /// Zivirandina bytes(`&[u8]`) ya xav bo `u32`, `f64`, hwd .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // Li şûna `u32::from_ne_bytes` bikar bînin
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // an jî `u32::from_le_bytes` an `u32::from_be_bytes` bikar bînin da ku dawiya xwe diyar bikin
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Vebijêrkek veguherîne `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Li şûna wê castek `as` bikar bînin
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// `*mut T` veguherînin `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Li şûna wê rebarrow bikar bînin
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// `&mut T` veguherînin `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Vêga, `as` û hevûdu danîn, not bikin zincîrakirina `as` `as` ne gerguhêz e
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// `&str` veguherînin `&[u8]`:
    ///
    /// ```
    /// // ev ne awayek baş e ji bo vê yekê.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Hûn dikarin `str::as_bytes` bikar bînin
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // An jî, heke hûn kontrola we li ser têlê biwêjî hebe, tenê têlekek byte bikar bînin
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// `Vec<&T>` veguherînin `Vec<Option<&T>>`.
    ///
    /// Ji bo ku hûn celebê hundurîn ê naverokek konteynirê veguherînin, divê hûn pê ewle bine ku yek ji nehêlên konteyner binpê nakin.
    /// Ji bo `Vec`, ev tê vê wateyê ku hem mezinahî *û hem jî rêzekirina* celebên hundurîn divê hevûdu bikin.
    /// Dibe ku konteynerên din xwe bisipêrin mezinahiya cûrbecûr, lihevrasthatî, an jî heya `TypeId`, ku di vê rewşê de veguherîn bêyî ku binpêkirinên konteyner binpê neke ne mumkun e.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // vector klon bikin ji ber ku em ê paşê wan ji nû ve bikar bînin
    /// let v_clone = v_orig.clone();
    ///
    /// // Transmute bikar tîne: ev xwe dispêre daneya nediyarkirî ya `Vec`, ku ramanek xirab e û dikare bibe sedema Tevgerek nediyarkirî.
    /////
    /// // Lêbelê, ew nusxe ye.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Ev awayê pêşniyazkirî, ewlehî ye.
    /// // Ew, tevê vector-ê kopî dike, lêbelê, di nav rêzek nû de.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Ev awayê ne-kopiyek, ewledar a "transmuting" a `Vec` e, bêyî ku xwe bisipêre sazkirina daneyê.
    /// // Li şûna ku bi rastî bi navê `transmute` bête kirin, em pişkek nîşanker pêk tînin, lê di warê veguhertina xwerû ya xwerû (`&i32`) de bi (`Option<&i32>`) ya nû re, ev xwedan eynî şîretan in.
    /////
    /// // Ji bilî agahdariya li jor hatî pêşkêş kirin, bi belgeyên [`from_raw_parts`] jî bişêwirin.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Dema ku vec_into_raw_parts sabit kirin vê yekê nû bikin.
    ///     // Piştrast bike ku vector ya orjînal nehatiye avêtin.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Pêkanîna `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Gelek awayên vê yekê hene, û bi awayê jêrîn (transmute) re gelek pirsgirêk hene.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // yekem: transmute ne celeb ewledar e;hemî ku ew kontrol dike ev e ku T û
    ///         // U ji eynî mezinahî ne.
    ///         // Ya duyemîn, li vir, du referansên weyên guhêrbar hene ku heman bîranîn nîşan dikin.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Ev ji pirsgirêkên ewlehiya celebê xilas dibe;`&mut *` dê* tenê *ji `&mut T` an `* mut T` `&mut T` bide we.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // lêbelê, hîn jî du referansên weyên guhêrbar hene ku heman bîranînê nîşan dikin.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Bi vî rengî pirtûkxaneya standard vê dike.
    /// // Heke hûn hewce ne ku tiştek wusa bikin ev rêbaza çêtirîn e
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Vêga sê referansên guhêrbar hene ku li heman bîranînê radiwestin.`slice`, rvalue ret.0, û rvalue ret.1.
    ///         // `slice` piştî `let ptr = ...` qet nayê bikar anîn, û ji ber vê yekê meriv dikare wê wekî "dead" derman bike, û ji ber vê yekê, tenê du heb pelikên mutabîl ên rastîn hene.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Digel ku ev pêkhateya navxweyî stabîl dike, di const fn de hin koda meya xwerû heye
    // kontrolên ku karanîna wê di nav `const fn` de asteng dikin.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// `true` vedigerîne heke celebê rastîn ê ku wekî `T` hatî dayîn hewceyê lepika dakêşanê be;`false` vedigerîne heke celebê rastîn ê ku ji bo `T` hatî peyda kirin `Copy` bicîh dike.
    ///
    ///
    /// Ger celebek rastîn ne hewceyê gloverê ye û ne jî `Copy` bicîh bîne, hingê nirxa vegera vê fonksiyonê ne diyar e.
    ///
    /// Guhertoya aramkirî ya vê xwemalî [`mem::needs_drop`](crate::mem::needs_drop) e.
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Dabeşandina ji nîşanderê dihejmêre.
    ///
    /// Ev ji bo ku xwe ji zivirandinê û ji jimareyekê ve nezivirîne wekî navgînek tête bicîh kirin, ji ber ku veguherîn dê agahdariya aliasing bavêje.
    ///
    /// # Safety
    ///
    /// Hem nîşanderê destpêk hem jî nîşanderê encam divê di nav sînoran de be an jî yek bayt be ji dawiya tiştê veqetandî re.
    /// Heke an pointer ji sînoran be an jî serûberiya hejmarî çêbibe wê hingê her karanîna nirxa vegerandî ya din dê bibe sedema reftarek nediyarkirî.
    ///
    ///
    /// Guhertoya aramkirî ya vê xwemalî [`pointer::offset`] e.
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Berevajîkirina ji pointer, potansiyel pêça.
    ///
    /// Ev ji bo ku xwe ji zivirandinê û vegerandina jimareyekê dûr nexe, wekî xwerû tête bicîh kirin, ji ber ku veguherîn hin optimizasyonan asteng dike.
    ///
    /// # Safety
    ///
    /// Berevajî `offset` ya xwerû, ev xwerû ne nîşanderê encamgirtî sînor dike ku di dawiya tiştê veqetandî re derbikeve an yek bayt be, û ew bi reqema du hejmar pêve dike.
    /// Nirxa encam ne hewce ye ku were bikar anîn ku bi rastî bigihîje bîranînê.
    ///
    /// Guhertoya aramkirî ya vê xwemalî [`pointer::wrapping_offset`] e.
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Bihevhatî ya xwerû ya guncan `llvm.memcpy.p0i8.0i8.*` e, bi mezinahiya `count`*`size_of::<T>()` û rêzkirinek ji
    ///
    /// `min_align_of::<T>()`
    ///
    /// Parametera berbiçav li `true` hatî saz kirin, ji ber vê yekê heya ku mezinahiya wê ne sifir be dê ji nû ve were optimîzekirin.
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Hevwateya xwerû ya guncan `llvm.memmove.p0i8.0i8.*`, bi mezinahiya `count* size_of::<T>()` û rêzkirinek ji
    ///
    /// `min_align_of::<T>()`
    ///
    /// Parametera berbiçav li `true` hatî saz kirin, ji ber vê yekê heya ku mezinahiya wê ne sifir be dê ji nû ve were optimîzekirin.
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Bihevhatî ya xwerû ya guncan `llvm.memset.p0i8.*`, bi mezinahiya `count* size_of::<T>()` û lihevnêzîkbûna `min_align_of::<T>()`.
    ///
    ///
    /// Parametera berbiçav li `true` hatî saz kirin, ji ber vê yekê heya ku mezinahiya wê ne sifir be dê ji nû ve were optimîzekirin.
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Ji nîşanderê `src` barkêşek berbiçav pêk tîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî [`core::ptr::read_volatile`](crate::ptr::read_volatile) e.
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Firotgehek berbiçav li ser pêşangeha `dst` pêk tîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî [`core::ptr::write_volatile`](crate::ptr::write_volatile) e.
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Ji nîşanderê `src` barkêşek berbiçav pêk tîne Nîşan ne hewce ye ku were rêz kirin.
    ///
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Firotgehek berbiçav li ser pêşangeha `dst` pêk tîne.
    /// Nîşan ne hewce ye ku were rêz kirin.
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Koka çargoşe ya `f32` vedigerîne
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Koka çargoşe ya `f64` vedigerîne
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// `f32` bi hêzek jimare raber dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// `f64` bi hêzek jimare raber dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Sînora `f32` vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Sînora `f64` vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Kozînusê `f32` vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Kozînusê `f64` vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// `f32` bi hêza `f32` bilind dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// `f64` bi hêza `f64` bilind dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Vegotina `f32` vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Vegotina `f64` vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Vegere 2 ku bi hêza `f32` ve hatî rakirin.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Vegere 2 ku bi hêza `f64` ve hatî rakirin.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Logarîtma xwezayî ya `f32` vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Logarîtma xwezayî ya `f64` vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Logarîtma bingehîn a 10 a `f32` vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Logarîtma bingehîn a 10 a `f64` vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Logarîtma bingeha 2 a `f32` vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Logarîtma bingeha 2 a `f64` vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Ji bo nirxên `f32` `a * b + c` vedigire.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Ji bo nirxên `f64` `a * b + c` vedigire.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Nirxa mutleq a `f32` vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Nirxa mutleq a `f64` vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Kêmtirîn du nirxên `f32` vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Kêmtirîn du nirxên `f64` vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Herî zêde du nirxên `f32` vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Herî zêde du nirxên `f64` vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Ji bo nirxên `f32` nîşana ji `y` ber `x` kopî dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Ji bo nirxên `f64` nîşana ji `y` ber `x` kopî dike.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Hejmara herî mezin a ji `f32` kêmtir an jî wekhev vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Hejmara herî mezin a ji `f64` kêmtir an jî wekhev vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Hejmara herî biçûk a ji `f32` mezintir an jî wekhev vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Hejmara herî biçûk a ji `f64` mezintir an jî wekhev vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Beşa jimare ya `f32` vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Beşa jimare ya `f64` vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Hejmara yekta ya herî nêz vegerîne `f32`.
    /// Heke nîqaş ne jimareyek be, dibe ku îstîsnayek bêkêmasî ya xala gerînbar rabe.
    pub fn rintf32(x: f32) -> f32;
    /// Hejmara yekta ya herî nêz vegerîne `f64`.
    /// Heke nîqaş ne jimareyek be, dibe ku îstîsnayek bêkêmasî ya xala gerînbar rabe.
    pub fn rintf64(x: f64) -> f64;

    /// Hejmara yekta ya herî nêz vegerîne `f32`.
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Hejmara yekta ya herî nêz vegerîne `f64`.
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Hejmara yekta ya herî nêz vegerîne `f32`.Bûyerên nîv-rê ji sifirê dûr digire.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Hejmara yekta ya herî nêz vegerîne `f64`.Bûyerên nîv-rê ji sifirê dûr digire.
    ///
    /// Guhertoya aramkirî ya vê xwemalî ye
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Pêveka float ku dihêle optimîzasyonên li ser bingeha rêgezên cebîrê.
    /// Dikare texmîn bike ku dahatin bi sînor in.
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Dabeşandina float ku rê dide optimîzasyonên li ser bingeha rêgezên cebîr.
    /// Dikare texmîn bike ku dahatin bi sînor in.
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Zêdekirina floatê ku dihêle optimîzasyonên li ser bingeha rêgezên cebîrê.
    /// Dikare texmîn bike ku dahatin bi sînor in.
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Dabeşandina float ku rê dide optimîzasyonên li ser bingeha rêgezên cebîrê.
    /// Dikare texmîn bike ku dahatin bi sînor in.
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Bermayiya float ku rê dide optimîzasyonên li ser bingeha rêgezên cebîr.
    /// Dikare texmîn bike ku dahatin bi sînor in.
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Bi LLVM's fptoui/fptosi veguherînin, ku dibe ku ji bo nirxên ji rêzê undef vegere
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Wekî [`f32::to_int_unchecked`] û [`f64::to_int_unchecked`] stabîlîze bû.
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Hejmara bîtên ku di celebek rastîn de `T` hatine danîn vedigerîne
    ///
    /// Guhertoyên aramkirî yên vê xwemalî li ser prîmîtîfên jimare bi rêbaza `count_ones` hene.
    /// Bo nimûne,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Hejmara bîtên pêşîn ên neçareserkirî (zeroes) di jimareyek rast de `T` vedigerîne.
    ///
    /// Guhertoyên aramkirî yên vê xwemalî li ser prîmîtîfên jimare bi rêbaza `leading_zeros` hene.
    /// Bo nimûne,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `x` bi nirxê `0` dê firehiya bit ya `T` vegerîne.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Mîna `ctlz`, lê zêde-neewle ew `undef` vedigerîne dema ku `x` bi nirxê `0` tê dayîn.
    ///
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Hejmara bitikên neçareserkirî yên paşperdeya (zeroes) di yekjimar de `T` vedigerîne.
    ///
    /// Guhertoyên aramkirî yên vê xwemalî li ser prîmîtîfên jimare bi rêbaza `trailing_zeros` hene.
    /// Bo nimûne,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `x` bi nirxê `0` dê firehiya bit ya `T` vegerîne:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Mîna `cttz`, lê zêde-neewle ew `undef` vedigerîne dema ku `x` bi nirxê `0` tê dayîn.
    ///
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Bytes di celebek hejmarek `T` de berevajî dike.
    ///
    /// Guhertoyên aramkirî yên vê xwemalî li ser prîmîtîfên jimare bi rêbaza `swap_bytes` hene.
    /// Bo nimûne,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Bitan di celebek hejmarek `T` de berevajî dike.
    ///
    /// Guhertoyên aramkirî yên vê xwemalî li ser prîmîtîfên jimare bi rêbaza `reverse_bits` hene.
    /// Bo nimûne,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Zêdekirina jimare ya seqetkirî pêk tîne.
    ///
    /// Guhertoyên aramkirî yên vê xwemalî li ser prîmîtîfên jimare bi rêbaza `overflowing_add` hene.
    /// Bo nimûne,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Dakêşana jimar ya seyrkirî pêk tîne
    ///
    /// Guhertoyên aramkirî yên vê xwemalî li ser prîmîtîfên jimare bi rêbaza `overflowing_sub` hene.
    /// Bo nimûne,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Pirjimariya rastvekirî ya rastandî pêk tîne
    ///
    /// Guhertoyên aramkirî yên vê xwemalî li ser prîmîtîfên jimare bi rêbaza `overflowing_mul` hene.
    /// Bo nimûne,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Dabeşkirinek rastîn pêk tîne, di encama reftara nediyarkirî de ku derê `x % y != 0` an `y == 0` an `x == T::MIN && y == -1`
    ///
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Dabeşek nevekirî pêk tîne, di encama reftara nediyarkirî de ku derê `y == 0` an `x == T::MIN && y == -1`
    ///
    ///
    /// Pelên ewledar ên ji bo vê xwemalî li ser prîmîtîfên jimare bi rêbaza `checked_div` hene.
    /// Bo nimûne,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Vegere ya dabeşek nevekirî vedigerîne, dema ku `y == 0` an `x == T::MIN && y == -1` tevdigere nediyarkirî
    ///
    ///
    /// Pelên ewledar ên ji bo vê xwemalî li ser prîmîtîfên jimare bi rêbaza `checked_rem` hene.
    /// Bo nimûne,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Guherînek çepê ya neçêkirî pêk tîne, di encama reftara nediyarkirî de dema `y < 0` an `y >= N`, ku N firehiya T ya bit e.
    ///
    ///
    /// Pelên ewledar ên ji bo vê xwemalî li ser prîmîtîfên jimare bi rêbaza `checked_shl` hene.
    /// Bo nimûne,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Guherînek rastê ya neçêkirî pêk tîne, dema ku `y < 0` an `y >= N`, ku N firehiya T ya bit e, tevgera nediyarkirî encam dide.
    ///
    ///
    /// Pelên ewledar ên ji bo vê xwemalî li ser prîmîtîfên jimare bi rêbaza `checked_shr` hene.
    /// Bo nimûne,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Encama lêzêdekirina nevekirî vedigerîne, dema ku `x + y > T::MAX` an `x + y < T::MIN` tevdigere nediyarkirî.
    ///
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Encama veqetandekek neçêkirî vedigerîne, dema ku `x - y > T::MAX` an `x - y < T::MIN` tevdigere nediyarkirî.
    ///
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Encama pirjimariya neçêkirî vedigerîne, dema ku `x *y > T::MAX` an `x* y < T::MIN` tevdigere nediyarkirî.
    ///
    ///
    /// Vê navxweyî hevpişkek stabîl tune.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Performansa çepê zivirî.
    ///
    /// Guhertoyên aramkirî yên vê xwemalî li ser prîmîtîfên jimare bi rêbaza `rotate_left` hene.
    /// Bo nimûne,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Rast rast dike.
    ///
    /// Guhertoyên aramkirî yên vê xwemalî li ser prîmîtîfên jimare bi rêbaza `rotate_right` hene.
    /// Bo nimûne,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Vegere (a + b) mod 2 <sup>N</sup>, ku N firehiya T-ya bit e.
    ///
    /// Guhertoyên aramkirî yên vê xwemalî li ser prîmîtîfên jimare bi rêbaza `wrapping_add` hene.
    /// Bo nimûne,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Vegere (a, b) mod 2 <sup>N</sup>, ku N firehiya T-ya bit e.
    ///
    /// Guhertoyên aramkirî yên vê xwemalî li ser prîmîtîfên jimare bi rêbaza `wrapping_sub` hene.
    /// Bo nimûne,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Vegere (a * b) mod 2 <sup>N</sup>, ku N firehiya T-ya bit e.
    ///
    /// Guhertoyên aramkirî yên vê xwemalî li ser prîmîtîfên jimare bi rêbaza `wrapping_mul` hene.
    /// Bo nimûne,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// `a + b` dihesibîne, li tixûbên hejmarî têr dibe.
    ///
    /// Guhertoyên aramkirî yên vê xwemalî li ser prîmîtîfên jimare bi rêbaza `saturating_add` hene.
    /// Bo nimûne,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// `a - b` dihejmêre, li tixûbên hejmarî têr dibe.
    ///
    /// Guhertoyên aramkirî yên vê xwemalî li ser prîmîtîfên jimare bi rêbaza `saturating_sub` hene.
    /// Bo nimûne,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Nirxa veqetandek ji bo guhertoya li 'v' vedigerîne;
    /// heke `T` cûdakar tune, `0` vedigerîne.
    ///
    /// Guhertoya aramkirî ya vê xwemalî [`core::mem::discriminant`](crate::mem::discriminant) e.
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Hejmara cûrbecûrên celebê `T` avêtî li `usize` vedigerîne;
    /// heke variantên `T` tune, `0` vedigerîne.Wê cûrbecûrên niştecîh werin hesibandin.
    ///
    /// Guhertoya ku dê were aramkirin a vê xwerû [`mem::variant_count`] e.
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Avakirina "try catch" ya Rust ku nîşana fonksiyonê `try_fn` bi nîşana daneyê `data` vedixwîne.
    ///
    /// Argumana sêyemîn fonksiyonek e ku heke panic çêbibe tê gotin.
    /// Vê fonksiyonê nîşanderê daneyê û nîşangirekê digihîne armanca îstîsnayê ya hedef-taybetî ku hate girtin.
    ///
    /// Ji bo bêtir agahdarî çavkaniya berhevkar û her weha pêkanîna girtina std bibînin.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Li gorî LLVM firoşgehek `!nontemporal` derdikeve (li belgeyên wan binihêrin).
    /// Dibe ku dê tu carî ne aram bibe.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Ji bo hûragahiyan li belgekirina `<*const T>::offset_from` binêrin.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Ji bo hûragahiyan li belgekirina `<*const T>::guaranteed_eq` binêrin.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Ji bo hûragahiyan li belgekirina `<*const T>::guaranteed_ne` binêrin.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Di dema berhevkirinê de veqetînin.Pêdivî ye ku di demjimêran de neyê bang kirin.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Hin fonksiyon li vir têne diyarkirin ji ber ku ew bi bêhemdî di vê modulê de li ser stabîl peyda bûne.
// <https://github.com/rust-lang/rust/issues/15702> bibînin.
// (`transmute` jî dikeve nav vê kategoriyê, lê ji ber kontrolkirina ku mezinahiya `T` û `U` xwedî ne, ew nayê pêçandin.)
//

/// Kontrol dike ka `ptr` bi rêzgirtina `align_of::<T>()` bi rêkûpêk e an na.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// `count *size_of::<T>()` byte ji `src` bo `dst` kopî dike.Divê çavkanî û cîh* bi hev re nebin.
///
/// Ji bo herêmên bîranînê yên ku dibe ku li hev bikin, li şûna wê [`copy`] bikar bînin.
///
/// `copy_nonoverlapping` ji hêla semantîkî ve bi C-ya [`memcpy`] re hevwate ye, lê digel rêza argumanan veguherîn.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Heke ji mercên jêrîn binpê kirin tevger nayê diyar kirin:
///
/// * `src` ji bo xwendina bajarên `count * size_of::<T>()` divê [valid] be.
///
/// * `dst` ji bo nivîsandina byteyên `count * size_of::<T>()` divê [valid] be.
///
/// * Divê `src` û `dst` bi rêkûpêk werin rêz kirin.
///
/// * Navçeya bîranînê ya bi `src` bi mezinahiya `jimartinê dest pê dike *
///   mezinahiya: :<T>() `byte divê *bi herêma bîranînê ya ku di `dst` de bi heman mezinahî dest pê dike nebin*.
///
/// Mîna [`read`], `copy_nonoverlapping` kopiyek bitwise a `T` diafirîne, bêyî ku `T` [`Copy`] e.
/// Heke `T` ne [`Copy`] be,* **nirxên li herêmê ji `* src` dest pê dike û herêma ku ji `*dst` dest pê dike dikare [violate memory safety][read-ownership] bikar bîne.
///
///
/// Zanibe ku heke mezinahiya bi bandor jibergirtî be jî (`count * size_of: :<T>()`) `0` e, divê nîşanker ne-NULL bin û bi rêkûpêk werin rêz kirin.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// [`Vec::append`] bi desta bicîh bikin:
///
/// ```
/// use std::ptr;
///
/// /// Hemî hêmanên `src` dixe nav `dst`, `src` vala dihêle.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Piştrast bikin ku kapasîteya `dst` têra girtina hemî `src` dike.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Banga ji bo berdanê her gav ewle ye ji ber ku `Vec` dê carî bêtir ji `isize::MAX` byte veqetîne.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // `src` bêyî daxistina naveroka wê kurt bikin.
///         // Em vê yekê yekem dikin, da ku ji pirsgirêkan dûr nekevin heke tiştek ji panics-ê dûrtir be.
///         src.set_len(0);
///
///         // Her du herêm nikarin li ser hev bin ji ber ku referansên guhêrbar alias nakin, û du vectors-yên cûda nikarin bibin xwediyê heman bîranînê.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // `dst` agahdar bikin ku ew nuha naveroka `src` digire.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Van kontrolan tenê di dema run de pêk bînin
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Ne panîkê ku bandora kodjenê piçûktir bike.
        abort();
    }*/

    // SAFETY: divê peymana ewlehiyê ji bo `copy_nonoverlapping` be
    // ji hêla bangker ve tê piştgirî kirin.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// `count * size_of::<T>()` byte ji `src` bo `dst` kopî dike.Çavkanî û cîh dibe ku li hevûdu bikin.
///
/// Ger çavkanî û cîh dê *carî* nekeve ser hev, li şûna wê [`copy_nonoverlapping`] dikare were bikar anîn.
///
/// `copy` ji hêla semantîkî ve bi C-ya [`memmove`] re hevwate ye, lê digel rêza argumanan veguherîn.
/// Kopkirin mîna ku bayît ji `src` li rêzeyek demkî hatibe kopî kirin û paşê jî ji rêzê li `dst` were kopî kirin pêk tê.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Heke ji mercên jêrîn binpê kirin tevger nayê diyar kirin:
///
/// * `src` ji bo xwendina bajarên `count * size_of::<T>()` divê [valid] be.
///
/// * `dst` ji bo nivîsandina byteyên `count * size_of::<T>()` divê [valid] be.
///
/// * Divê `src` û `dst` bi rêkûpêk werin rêz kirin.
///
/// Mîna [`read`], `copy` kopiyek bitwise a `T` diafirîne, bêyî ku `T` [`Copy`] e.
/// Ger `T` ne [`Copy`] be, hem nirxên li herêmê ji `*src` dest pê dikin û hem jî herêma ku ji `* dst` dest pê dike dikarin [violate memory safety][read-ownership] bikar bînin.
///
///
/// Zanibe ku heke mezinahiya bi bandor jibergirtî be jî (`count * size_of: :<T>()`) `0` e, divê nîşanker ne-NULL bin û bi rêkûpêk werin rêz kirin.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Bi bandorek Rust vector ji tamponek ne ewle biafirînin:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` divê ji bo celebê wê û ne-sifir bi rêkûpêk were rêz kirin.
/// /// * `ptr` divê ji bo xwendina hêmanên lihevhatî yên `elts` ji celebê `T` derbasdar be.
/// /// * Heya ku `T: Copy` nexwendî ne hewce ye ku ew hêman bêne bikar anîn.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // EWLEH: : Pêşniyara me çavkaniyê hevrast û derbasdar dike,
///     // û `Vec::with_capacity` piştrast dike ku me cîhek bikêrhatî heye ku em wan binivîsin.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // EWLEHIY: : Me bi vê kapasîteya pêştir ew afirand,
///     // û ya berê `copy` van hêmanan destnîşan kiriye.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Van kontrolan tenê di dema run de pêk bînin
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Ne panîkê ku bandora kodjenê piçûktir bike.
        abort();
    }*/

    // EWLEHIY: : divê peymana ewlehiyê ya ji bo `copy` ji hêla bangdêr ve were pejirandin.
    unsafe { copy(src, dst, count) }
}

/// Bîtên bîranînê yên `count * size_of::<T>()` destnîşan dike ku ji `dst` heya `val` dest pê dike.
///
/// `write_bytes` dişibe C's [`memset`], lê `count * size_of::<T>()` byte datîne ser `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Heke ji mercên jêrîn binpê kirin tevger nayê diyar kirin:
///
/// * `dst` ji bo nivîsandina byteyên `count * size_of::<T>()` divê [valid] be.
///
/// * `dst` divê bi rêkûpêk were rêz kirin.
///
/// Wekî din, divê bangker piştrast bike ku bi nivîsandina `count * size_of::<T>()` byteyên li herêma daneyê ya bîranînê re nirxek derbasdar a `T` heye.
/// Bikaranîna herêmek bîranînê ku wekî `T` hatî nivîsandin û ku nirxek nederbasdar a `T` tê de ye tevgerek ne diyar e.
///
/// Zanibe ku heke mezinahiya bi bandor jibergirtî be jî (`count * size_of: :<T>()`) `0` e, pêdivî ye ku nîşander ne-NULL be û bi rêkûpêk were rêz kirin.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Bikaranîna bingehîn:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Nirxek nederbasdar afirandin:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Nirxa ku berê lê hatibû girtin ji hêla `Box<T>` ve bi niqterek nal vedihewîne diherike.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Di vê demê de, karanîn an daketina `v` bi tevgereke nediyarkirî encam dide.
/// // drop(v); // ERROR
///
/// // Heya ku wê `v` "uses" diherike, û ji ber vê yekê tevgerek ne diyar e.
/// // mem::forget(v); // ERROR
///
/// // Di rastiyê de, `v` li gorî nexşeyên dabeşandina celebê bingehîn nerast e, ji ber vê yekê *her* operasyona ku pê re têkilî dibe tevgerek ne diyar e.
/////
/// // bila v2 =v;//ÇETOR
///
/// unsafe {
///     // Ka em li şûna wê nirxek derbasdar bavêjin
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Naha sindoq baş e
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // EWLEHIY: : divê peymana ewlehiyê ya ji bo `write_bytes` ji hêla bangdêr ve were pejirandin.
    unsafe { write_bytes(dst, val, count) }
}