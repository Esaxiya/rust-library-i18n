use crate::iter::{FusedIterator, TrustedLen};

/// Bi vexwendina li dorpêçandî ve vebêjer diafirîne ku bi lalkî yekcar nirxek çêdike.
///
/// Ev bi gelemperî tête bikar anîn ku hilberîneriyek nirxa yekbûyî di nav [`chain()`] celebên din ên dubarekirinê de biguncîne.
/// Dibe ku we iterator hebe ku hema hema her tiştî digire, lê ji we re dozek taybetî ya taybetî hewce dike.
/// Dibe ku we fonksiyonek hebe ku li ser veberhêneran dixebite, lê hûn tenê hewce ne ku nirxek nirx bikin.
///
/// Berevajî [`once()`], ev fonksiyon dê li ser daxwazê bi lalaqî nirxê çêbike.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Bikaranîna bingehîn:
///
/// ```
/// use std::iter;
///
/// // yek jimareya tenêtî ye
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // tenê yek, ew tiştê ku em bistînin ev e
/// assert_eq!(None, one.next());
/// ```
///
/// Zincîrkirina bi iteratorê din re.
/// Ka em bibêjin ku em dixwazin li ser her pelê pelrêça `.foo`, lê di heman demê de pelê vesazkirinê jî dubare bikin,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // em hewce ne ku ji iteratorê DirEntry-s veguherînin iteratorê PathBufs, ji ber vê yekê em nexşeyê bikar tînin
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // naha, iteratorê me tenê ji bo pelê mîhengê me ye
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // zencîra her du dubarekaran bi hev re di yek iteratorê mezin de
/// let files = dirs.chain(config);
///
/// // ev ê di pelên .foo û hem jî .foorc de hemî pelan bide me
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Iterator ku bi sepandina dorpêça `F: FnOnce() -> A` ve yek hêmanek ji celebê `A` dide.
///
///
/// Ev `struct` ji hêla fonksiyona [`once_with()`] ve tê afirandin.
/// Ji bo bêtir belgeya wê bibînin.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}