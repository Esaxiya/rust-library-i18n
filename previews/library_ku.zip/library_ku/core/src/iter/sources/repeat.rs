use crate::iter::{FusedIterator, TrustedLen};

/// Iteratorek nû ku bêdawî hêmanek tenê dubare dike diafirîne.
///
/// Fonksiyona `repeat()` nirxek yekane dubare û dubare dike.
///
/// Pêşkêşkerên bêdawî yên mîna `repeat()` bi gelemperî bi adapterên mîna [`Iterator::take()`] re têne bikar anîn, da ku wan bidawî bikin.
///
/// Heke celebê hêmana veberhênerê ku hûn hewce ne `Clone` bicîh bîne, an heke hûn nexwazin hêmana dubarekirî di bîra xwe de bihêlin, hûn dikarin li şûna wê fonksiyona [`repeat_with()`] bikar bînin.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Bikaranîna bingehîn:
///
/// ```
/// use std::iter;
///
/// // hejmara çar 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // yup, hîn jî çar
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Bi [`Iterator::take()`] re sînor diçin:
///
/// ```
/// use std::iter;
///
/// // ew mînaka paşîn pir çar bû.Bila tenê çar çar meyên me hebin.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... û naha em xelas bûn
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Iterator ku hêmanek bêdawî dubare dike.
///
/// Ev `struct` ji hêla fonksiyona [`repeat()`] ve tê afirandin.Ji bo bêtir belgeya wê bibînin.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}