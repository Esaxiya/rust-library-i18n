use crate::{fmt, iter::FusedIterator};

/// Iteratorek nû diafirîne ku her tişta li pey hev li gorî ya pêşîn tê hesibandin.
///
/// Iterator bi xala yekê ya yekem (heke hebe) dest pê dike û gazî xala girtina `FnMut(&T) -> Option<T>` dike da ku paşnavê her tiştî hesab bike.
///
///
/// ```
/// use std::iter::successors;
///
/// let powers_of_10 = successors(Some(1_u16), |n| n.checked_mul(10));
/// assert_eq!(powers_of_10.collect::<Vec<_>>(), &[1, 10, 100, 1_000, 10_000]);
/// ```
#[stable(feature = "iter_successors", since = "1.34.0")]
pub fn successors<T, F>(first: Option<T>, succ: F) -> Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    // Ger vê fonksiyonê `impl Iterator<Item=T>` vegerîne ew dikare li ser bingeha `unfold` be û hewceyê celebek taybetî ne.
    //
    // Lêbelê hebûna celebek navê `Successors<T, F>` dihêle ew `Clone` be dema ku `T` û `F` be.
    Successors { next: first, succ }
}

/// Iteratorek nû ku her tişta li pey hev li gorî ya pêşîn tê hesibandin.
///
/// Ev `struct` ji hêla fonksiyona [`iter::successors()`] ve tê afirandin.
/// Ji bo bêtir belgeya wê bibînin.
///
/// [`iter::successors()`]: successors
#[derive(Clone)]
#[stable(feature = "iter_successors", since = "1.34.0")]
pub struct Successors<T, F> {
    next: Option<T>,
    succ: F,
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> Iterator for Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        let item = self.next.take()?;
        self.next = (self.succ)(&item);
        Some(item)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.next.is_some() { (1, None) } else { (0, Some(0)) }
    }
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> FusedIterator for Successors<T, F> where F: FnMut(&T) -> Option<T> {}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T: fmt::Debug, F> fmt::Debug for Successors<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Successors").field("next", &self.next).finish()
    }
}