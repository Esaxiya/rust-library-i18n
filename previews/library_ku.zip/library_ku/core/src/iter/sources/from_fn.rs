use crate::fmt;

/// Iteratorek nû diafirîne ku her dubare bang li girtina `F: FnMut() -> Option<T>` ya dabînkirî dike.
///
/// Ev dihêle ku bêyî ku hevoksaziya lêker zêdetir a afirandina celebek xwerû û bicihanîna [`Iterator`] trait, bi her tevgerî re iteratorek xwerû çêbike.
///
/// Zanibe ku `FromFn` iterator li ser tevgera girtinê texmînan nake, û ji ber vê yekê bi kevneperestî [`FusedIterator`] bicîh nayîne, an [`Iterator::size_hint()`] ji `(0, None)` ya xweya xwerû derbas nake.
///
///
/// Girtîgeh dikare girtinan û hawîrdora wê bikar bîne da ku dewletê li seranserê dubareyan bişopîne.Bi karanîna karanîna iterator ve girêdayî, dibe ku ev hewce bike ku li ser girtinê bêjeya sereke [`move`] diyar bike.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Ka em ji [module-level documentation] ji nû ve sazkerê kontra bikin:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Hejmara me zêde bikin.Ji ber vê yekê me di sifirê de dest pê kir.
///     count += 1;
///
///     // Kontrol bikin ka em jimartinê xilas kirine an na.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Iterator ku her dubare gazî girtina `F: FnMut() -> Option<T>` ya dabînkirî dike.
///
/// Ev `struct` ji hêla fonksiyona [`iter::from_fn()`] ve tê afirandin.
/// Ji bo bêtir belgeya wê bibînin.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}