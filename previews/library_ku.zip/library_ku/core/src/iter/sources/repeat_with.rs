use crate::iter::{FusedIterator, TrustedLen};

/// Dîtinek nû diafirîne ku hêmanên celebê `A` bêdawî dubare dike bi karanîna dorpêçê vegirtî, dubareker, `F: FnMut() -> A`.
///
/// Fonksiyona `repeat_with()` dubare bang dike û dubare dike.
///
/// Pêşkêşkerên bêdawî yên mîna `repeat_with()` bi gelemperî bi adapterên mîna [`Iterator::take()`] re têne bikar anîn, da ku wan bidawî bikin.
///
/// Heke celebê elementa veberhênerê ku hûn hewce ne [`Clone`] bicîh bike, û baş e ku hûn ê elementa çavkaniyê di bîra xwe de bigirin, divê hûn li şûna wê fonksiyona [`repeat()`] bikar bînin.
///
///
/// Iterator ku ji hêla `repeat_with()` ve hatî hilberandin ne [`DoubleEndedIterator`] ye.
/// Heke ji we re `repeat_with()` hewce ye ku [`DoubleEndedIterator`] vegerînin, ji kerema xwe pirsgirêkek GitHub vebikin û rewşa karanîna xwe vebêjin.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Bikaranîna bingehîn:
///
/// ```
/// use std::iter;
///
/// // ka em bihesibînin ku hin nirxek celebek me heye ku ne `Clone` e an ku naxwazin tenê di bîra min de bimînin ji ber ku biha ye:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // nirxek taybetî ya herheyî:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Bi karanîna mutasyonê û çûyîna sînor:
///
/// ```rust
/// use std::iter;
///
/// // Ji sifirê heya hêza sêyemîn a du:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... û naha em xelas bûn
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Iterator ku hêmanên celebê `A` bêdawî bi sepandina girtina `F: FnMut() -> A` ya bêdawî dubare dike.
///
///
/// Ev `struct` ji hêla fonksiyona [`repeat_with()`] ve tê afirandin.
/// Ji bo bêtir belgeya wê bibînin.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}