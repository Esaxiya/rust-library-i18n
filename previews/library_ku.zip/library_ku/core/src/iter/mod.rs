//! Dubarekirina pêkve ya derve.
//!
//! Heke we xwe bi berhevokek celebek dît, û hewce be ku hûn li ser hêmanên berhevoka gotî operasyonekê pêk bînin, hûn ê bilez bikevin 'iterators'.
//! Iterator bi giranî di koda Rust ya idiomatîkî de têne bikar anîn, ji ber vê yekê hêja ye ku hûn bi wan nas bibin.
//!
//! Berî ku bêtir şirove bike, ka em li ser awayê sazkirina vê modulê biaxifin:
//!
//! # Organization
//!
//! Ev modul bi piranî ji hêla celeb ve hatî saz kirin:
//!
//! * [Traits] beşa bingehîn in: ev traits diyar dikin ka çi cûre dûbareker hene û hûn dikarin bi wan re çi bikin.Rêbazên van traits hêjayî ye ku meriv demek xwendinê ya zêde têxe nav.
//! * [Functions] hin awayên alîkar peyda bikin da ku hin dubareyên bingehîn biafirînin.
//! * [Structs] bi gelemperî li ser traits-a vê modulê celebên vegerandina cûrbecûr rêbazan in.Hûn ê bi gelemperî bixwazin li şûna `struct` bixwe li rêbaza ku `struct` diafirîne binêrin.
//! Ji bo berfirehtir li ser çima, li '[Implementing Iterator](#implementer-iterator)' binihêrin.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Her eve!Ka em werin ser tekrarkaran.
//!
//! # Iterator
//!
//! Dil û giyanê vê modulê [`Iterator`] trait ye.Bingeha [`Iterator`] wiha xuya dike:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Vebijêrkek xwedan rêbazek e, [`next`], ku gava tê gazî kirin, ["Vebijêrk"] vedigire<Item>`.
//! [`next`] dê [`Some(Item)`] vegere heya ku hêman hebin, û gava ku ew hemî xilas bûn, dê `None` vegerîne da ku diyar bike ku dûbarekirin qediya ye.
//! Terakkerên takekesî dikarin hilbijêrin ku dûbare dubarebûnê dest pê bikin, û ji ber vê yekê dîsa bangkirina [`next`] dibe ku di demekê de dîsa dest bi vegera [`Some(Item)`] bike an na (mînakek, [`TryIter`] binihêre).
//!
//!
//! Danasîna tevahî ya ["Iterator`] gelek rêbazên din jî tê de hene, lê ew rêbazên pêşkeftî ne, li ser [`next`] hatine çêkirin, û ji ber vê yekê hûn wan belaş digirin.
//!
//! Iterator di heman demê de têne berhev kirin, û gelemperî ye ku meriv wan bi hev ve girêbide da ku formên pêvajoyê yên tevlihevtir bikin.Ji bo bêtir agahdarî li jêr li beşa [Adapters](#adapters) binêrin.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Sê awayên vegêranê
//!
//! Sê rêbazên hevpar hene ku dikarin ji berhevokekê iteratoran biafirînin:
//!
//! * `iter()`, ku li ser `&T` dubare dike.
//! * `iter_mut()`, ku li ser `&mut T` dubare dike.
//! * `into_iter()`, ku li ser `T` dubare dike.
//!
//! Tiştên cihêreng ên di pirtûkxaneya standard de dibe ku li gorî guncan, ji sêyan yek an jî zêdetir bicîh bîne.
//!
//! # Iterator bicîhkirin
//!
//! Afirandina veberhênerê xwe bi xwe du gav hene: afirandina `struct` ku dewleta iterator bigire, û dûv re jî bicîhkirina [`Iterator`] ji bo wê `struct`.
//! Loma di vê modulê de gelek `struk` hene: ji bo her iterator û adapterê iterator yek heye.
//!
//! Werin em iteratorek bi navê `Counter` çêbikin ku ji `1` heya `5` jimartiye:
//!
//! ```
//! // Ya yekem, damezrandin:
//!
//! /// Iterator ku ji yekê heya pênc dihejmire
//! struct Counter {
//!     count: usize,
//! }
//!
//! // em dixwazin jimartina me ji yekê dest pê bike, ji ber vê yekê em bila rêbaza new() zêde bikin ku bibe alîkar.
//! // Ev ne zor hewce ye, lê hêsan e.
//! // Zanibe ku em `count` di sifirê de dest pê dikin, em ê bibînin ka çima li jêr pêkanîna `next()`'s.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Wê hingê, em ji bo `Counter` xwe `Iterator` bicîh dikin:
//!
//! impl Iterator for Counter {
//!     // em ê bi karanîna hejmar bihesibînin
//!     type Item = usize;
//!
//!     // next() tenê rêbazek pêdivî ye
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Hejmara me zêde bikin.Ji ber vê yekê me di sifirê de dest pê kir.
//!         self.count += 1;
//!
//!         // Kontrol bikin ka em jimartinê xilas kirine an na.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Now naha em dikarin wê bikar bînin!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Bi vî rengî gazî kirina [`next`] dubare dibe.Rust avahiyek heye ku dikare [`next`] li iteratorê we bigerîne, heya ku digihîje `None`.Ka em herin ser ya din.
//!
//! Di heman demê de not bikin ku `Iterator` pêkanînek pêşdibistanê ya rêbazên wekî `nth` û `fold` ku navxweyî `next` dibêjin, peyda dike.
//! Lêbelê, her weha gengaz e ku meriv pêkanînek xwerû ya rêbazên mîna `nth` û `fold` binivîse heke iterator bêyî ku gazî `next` bike dikare wan bi bandortir bihesibîne.
//!
//! # `for` xelek û `IntoIterator`
//!
//! Hevoksaziya xeleka Rust ya `for` di rastiyê de ji bo tekrarkerên şekir e.Li vir mînakek bingehîn a `for` heye:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Ev ê hejmaran yek bi pêncan, her yek li ser xeta xwe çap bike.Lê hûn ê li vir tiştek ferq bikin: me tucarî li vector-ê tiştek neda ku em iterator çêbikin.Çi dide?
//!
//! Di pirtûkxaneya standard de trait heye ku ji bo veguheztina tiştek nav iterator: [`IntoIterator`].
//! Vê trait yek rêbazek heye, [`into_iter`], ku tiştê ku [`IntoIterator`] bicîh tîne veguherîne iterator.
//! Ka em carek din li wê xeleka `for` binihêrin, û ya ku berhevkar wê vediguhêzîne:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust ev şekir dişîne:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Pêşîn, em li ser nirxê `into_iter()` dibêjin.Wê hingê, em li ser iteratorê ku vedigere li hev dikin, gazî [`next`] dikin ser û her dem heya ku em `None` dibînin.
//! Di wê gavê de, em `break` ji xelekê derdikevin, û me xilas kir.
//!
//! Li vir bitek hûriktir jî heye: pirtûkxaneya standard pêkanînek balkêş a [`IntoIterator`] vedigire:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Bi gotinên din, hemî [`Iterator`] [`IntoIterator`] bicîh dikin, bi tenê vedigerin xwe.Wateya vê du tişt e:
//!
//! 1. Heke hûn [`Iterator`] dinivîsin, hûn dikarin wê bi xelekek `for` bikar bînin.
//! 2. Heke hûn berhevokek diafirînin, bicîhkirina [`IntoIterator`] ji bo wê dihêle ku berhevoka we bi xeleka `for` were bikar anîn.
//!
//! # Bi referansê vedigerînin
//!
//! Ji ber ku [`into_iter()`] ji hêla nirxê ve `self` digire, xelekek `for` bikar tîne ku li ser berhevokek dubare bike wê berhevokê dixwe.Pir caran, dibe ku hûn bixwazin bêyî berhevkirina wê berhevokek li ser xwe dubare bikin.
//! Gelek berhevok rêbazên ku veberhêneran li ser çavkanîyan peyda dikin, bi peywendî bi `iter()` û `iter_mut()` têne rêz kirin, pêşkêş dikin:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` hîn jî xwediyê vê fonksiyonê ye.
//! ```
//!
//! Ger celebek komkirinê `C` `iter()` peyda dike, ew bi gelemperî `IntoIterator` ji bo `&C` jî bicîh dike, bi pêkanînek ku tenê bangî `iter()` dike.
//! Bi heman awayî, berhevokek `C` ku `iter_mut()` peyda dike bi gelemperî `IntoIterator` ji bo `&mut C` bi delegekirina `iter_mut()` pêk tîne.Ev kurtenivîsek guncan dihêle:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // wek `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // wek `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Dema ku gelek berhevok `iter()` pêşkêşî dikin, hemî `iter_mut()` pêşkêş nakin.
//! Mînakî, mutasyona tûşên [`HashSet<T>`] an [`HashMap<K, V>`] dikare berhevokê bixe rewşek nakokî heke mifteyên mifteyê biguhezîne, ji ber vê yekê van berhevokan tenê `iter()` pêşkêşî dikin.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Fonksiyonên ku [`Iterator`] digirin û [`Iterator`] din vedigirin bi gelemperî 'adapterên îterator' têne gotin, ji ber ku ew formek 'adapterê ne
//! pattern'.
//!
//! Adapterên iterator ên hevpar [`map`], [`take`], û [`filter`] hene.
//! Ji bo bêtir, belgeyên wan bibînin.
//!
//! Ger adapterê îteatorê panics, dê iterator di rewşek ne diyar de (lê bîranîn ewle) be.
//! Di heman demê de ev dewlet nayê garantîkirin ku li seranserê guhertoyên Rust heman bimîne, ji ber vê yekê divê hûn xwe ji baweriya bi nirxên rastîn ên ji hêla iterator ve hatî panîk vegerandin dûr bixin.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iterator (û iterator [adapters](#adapters))*lal in*. Ev tê vê wateyê ku tenê afirandina iteratorek _do_ bi tevahî nake. Tiştek bi rastî çê nabe heya ku hûn bangî [`next`] nekin.
//! Vê carinan çavkaniyek tevliheviyê ye dema ku iterator tenê ji bo bandorên wê diafirîne.
//! Mînakî, rêbaza [`map`] li ser her hêmana ku ew li ser wê dûbare dike digire bang dike:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Ev dê ti nirxan çap neke, ji ber ku me tenê iterator çêkir, ji dêvla ku em bikar bînin.Berhevkar dê di derheqê vî rengî reftarê de me hişyar bike:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Awayê xwerû yê nivîsandina [`map`] ji bo bandorên wê ev e ku hûn xelekek `for` bikar bînin an jî rêbaza [`for_each`] bang bikin:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Awayek din a hevpar a nirxandina an iterator e ku karanîna rêbaza [`collect`] e ku berhevokek nû hilberîne.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iterator ne hewce ne ku bi sînor bin.Wekî mînakek, dorpêçek vekirî-veberhênerek bêdawî ye:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Ew gelemperî ye ku meriv adapterê [`take`]-ê bikar bîne ku veberhênerek bêdawî bike nav yeka dawîn:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Ev ê hejmarên `0` heya `4`, her yek li ser rêza xwe çap bike.
//!
//! Di hişê xwe de bimînin ku rêbazên li ser dûbareyên bêdawî, heta yên ku encamek bi matematîkî di dema bêdawî de dikare were diyar kirin, dibe ku biqedin.
//! Bi taybetî, rêbazên wekî [`min`], ku di rewşa gelemperî de hewce dike ku her elementek di iterator de derbas bibe, dibe ku ji bo her dûbareyên bêdawî bi serfirazî venegerin.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Ax na!Lûleyek bêdawî!
//! // `ones.min()` dibe sedema xelekek bêdawî, ji ber vê yekê em ê negihîjin vê nuqteyê!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;