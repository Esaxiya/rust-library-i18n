/// Ittorekarek ku her dem xilas dibe ku `None` bide.
///
/// Gazî li ser iteratorê fuzûlî yê ku carek `None` vegeriyaye kirî ye ku dê dîsa [`None`] vegerîne.
/// Divê ev trait ji hêla hemî dubareyên ku bi vî rengî tevdigerin ve were pêkanîn ji ber ku ew dihêle optimîzekirina [`Iterator::fuse()`].
///
///
/// Note: Bi gelemperî, heke we pêdivî bi iteratorê fuse heye divê hûn `FusedIterator` di sînorên gelemperî de bikar neynin.
/// Di şûna wê de, divê hûn tenê li ser iteratorê bangî [`Iterator::fuse()`] bikin.
/// Ger iterator jixwe fuzûlî be, dê pêveka [`Fuse`]-ya pêvek bê cezayê karûbarê ne-op be.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Iterator ku dirêjahiyek rastîn bi kar tîne size_hint bikar tîne.
///
/// Iterator ravekek mezinahiyê radigihîne ku ew an rast e (benda jêrîn bi bendê jorîn re yeksan e), an jî girêka jorîn [`None`] ye.
///
/// Ger dirêjahiya rasterast ji [`usize::MAX`] mezintir be divê tixûbê jorîn tenê [`None`] be.
/// Di rewşê de, pêdivî ye ku bendê jêrîn [`usize::MAX`] be, û di encama [`Iterator::size_hint()`] de `(usize::MAX, None)`.
///
/// Pêdivî ye ku iterator berî ku bigihîje dawiyê, hêjmara hêmanên ku ragihandiye an ji hev cûdane tam çê bike.
///
/// # Safety
///
/// Pêdivî ye ku ev trait tenê dema ku peyman were piştrast kirin were cîbicîkirin.
/// Bikarhênerên vê trait divê [`Iterator::size_hint()`]’s qeraxa jorîn kontrol bikin.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Ittîfadekarek ku dema ku tiştek jê derdikeve dê bi kêmanî yek hêmanek ji [`SourceIter`]-ya xweya bingehîn bistîne.
///
/// Bangkirina her rêbaza ku iterator pêşve dibe, mînak
/// [`next()`] an [`try_fold()`], garantî dike ku ji bo her gavê bi kêmî ve yekê nirxa jêderka bingehîn a iterator ji cîhê xwe hatî veguheztin û encama zincîra iterator dikare li şûna wî were bicîh kirin, bihesibînin ku tixûbên avahiyê yên çavkaniyê destûrê dide ku têxînek wusa.
///
/// Bi gotinên din ev trait diyar dike ku xetek iterator dikare li cîh were berhev kirin.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}