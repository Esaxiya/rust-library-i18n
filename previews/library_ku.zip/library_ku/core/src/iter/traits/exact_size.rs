/// Iterator ku bi dirêjahiya xwe rast dizane.
///
/// Gelek [`Iterator`] nizanin ka ew ê çend caran dubare bikin, lê hinek jî dikin.
/// Ger vebêjer zanibe ku çend caran dikare dubare bike, peydakirina gihîştina wê agahdariyê dikare kêrhatî be.
/// Mînakî, heke hûn dixwazin dubare bikin, destpêkek baş ew e ku hûn bizanin ka dawiya li ku ye.
///
/// Dema ku `ExactSizeIterator` bicîh dikin, divê hûn [`Iterator`] jî bicîh bikin.
/// Dema ku wiya dikin, pêkanîna [`Iterator::size_hint`]*divê* mezinahiya rastîn a iterator vegerîne.
///
/// Metoda [`len`] xwedan sepandinek xwerû ye, ji ber vê yekê hûn bi gelemperî divê wê pêk neynin.
/// Lêbelê, dibe ku hûn bikaribin ji pêşdibistanê pêkanînek performansek pêşkêşî bikin, ji ber vê yekê di vê rewşê de derbaskirin watedar e.
///
///
/// Bala xwe bidinê ku ev trait trait ewledar e û wekî wiya *ne* û *nikare* misoger bike ku dirêjahiya vegerandî rast e.
/// Ev tê vê wateyê ku kodê `unsafe`**pêdivî ne ku** bi rastbûna [`Iterator::size_hint`] bisekine.
/// [`TrustedLen`](super::marker::TrustedLen) trait ya nearam û ewledar vê garantiya pêvek dide.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Bikaranîna bingehîn:
///
/// ```
/// // dorpêçek bi sînor dizane ka ew ê çend caran dubare bike
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Di [module-level docs] de, me [`Iterator`] bicîh kir, `Counter`.
/// Bila ji bo wê jî `ExactSizeIterator` bicîh bikin:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Em dikarin bi hêsanî hejmara dubareyên mayî bihesibînin.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Now naha em dikarin wê bikar bînin!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Dirêjahiya rastîn a iterator vedigere.
    ///
    /// Pêkanînê piştrast dike ku veberhêner dê berî ku [`None`] vegerîne `len()` bêtir carî nirxek [`Some(T)`] vegerîne.
    ///
    /// Vê rêbazê sepandinek xwerû heye, ji ber vê yekê hûn bi gelemperî hewce ne ku wê rasterast pêk bînin.
    /// Lêbelê, heke hûn karibin pêkanînek bi bandortirîn peyda bikin, hûn dikarin wiya bikin.
    /// Ji bo mînakek belgeyên [trait-level] bibînin.
    ///
    /// Vê fonksiyonê heman fonksiyonên ewlehiyê yên wekî fonksiyona [`Iterator::size_hint`] hene.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// // dorpêçek bi sînor dizane ka ew ê çend caran dubare bike
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Ev angaşt zêde parastî ye, lê ew neguhêzbar kontrol dike
        // ji hêla trait ve hatî garantîkirin.
        // Ger ev trait rust-navxweyî bûya, me dikarî debug_assert bikar bînin !;assert_eq!dê hemî pêkanînên bikarhêner ên Rust jî kontrol bikin.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Ger iterator vala be `true` vedigerîne.
    ///
    /// Vê rêbazê bi karanîna [`ExactSizeIterator::len()`] re karanîna pêşdibistanê heye, ji ber vê yekê hûn ne hewce ne ku ew bixwe wê pêk bînin.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}