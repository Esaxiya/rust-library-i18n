// ignore-tidy-filelength Ev pel hema hema bi tenê ji pênaseya `Iterator` pêk tê.
// Em nikarin wiya li gelek pelan parve bikin.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Navgînek ji bo danûstandina bi dûbareker.
///
/// Ev iteratorê sereke trait ye.
/// Ji bo bêtir li ser têgeha dûbareker bi gelemperî, ji kerema xwe [module-level documentation] bibînin.
/// Bi taybetî, dibe ku hûn dixwazin fêr bibin çawa [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Celebê hêmanên ku li ser têne dubare kirin.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Iterator pêşve diçe û nirxa paşîn vedigire.
    ///
    /// Dema ku vegotin xelas bû [`None`] vedigerîne.
    /// Pêkanînên takekesî yên takekesî dikarin dubarekirinê ji nû ve hilbijêrin, û ji ber vê yekê bangkirina `next()` dîsa dibe ku di demekê de dîsa dest bi vegera [`Some(Item)`] bike yan jî neke.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Bangek ji next() re nirxa paşîn vedigire ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... û paşî Çu carî ku ew xelas bû.
    /// assert_eq!(None, iter.next());
    ///
    /// // Zêde bang dibe ku venegere `None`.Li vir, ew ê her dem bikin.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Sînorên li ser dirêjahiya mayî ya iterator vedigerîne.
    ///
    /// Bi taybetî, `size_hint()` tûpek vedigerîne ku hêmana yekem biniya jêrîn e, û hêmana duyemîn girêka jorîn e.
    ///
    /// Nîvê duyemîn ê tupê ya ku vedigere ["Vebijêrk"] "<" ["bikar bîne"] "> e.
    /// A [`None`] li vir tê vê wateyê ku yan bendek jorîn a naskirî tune, an jî girêka jorîn ji [`usize`] mezintir e.
    ///
    /// # Nîşeyên tetbîqkirinê
    ///
    /// Nayê sepandin ku pêkanînek iteratorê hêjmara ragihandî dide.Iteratorê bugî dikare ji bendika jêrîn an ji bendera jorîn ya hêmanan kêmtir bide.
    ///
    /// `size_hint()` di serî de armanc ew e ku ji bo optimizasyonên wekî veqetandina cîhê ji bo hêmanên iterator were bikar anîn, lê pêdivî ye ku pê ewle nebin ku mînak, venêranên sînoran di koda ne ewle de.
    /// Pêkanîna çewt a `size_hint()` divê nebe sedema binpêkirinên ewlehiya bîranînê.
    ///
    /// Wê got, pêdivî ye ku nirxandinek rast peyda bike, ji ber ku wekî din ew ê binpêkirina protokola trait be.
    ///
    /// Pêkanîna vedigere vedigere `(0,` [[None "]") "ku ji bo her dûbareker rast e.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Mînakek tevlihevtir:
    ///
    /// ```
    /// // Hejmarên çiftê ji sifir heya deh.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Em dikarin ji sifir heya deh caran dubare bikin.
    /// // Dizanin ku pênc rast e bêyî darvekirina filter() ne gengaz e.
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Ka em bi chain() re pênc hejmarên din jî zêde bikin
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // niha her du sînor bi pênc zêde dibin
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// `None` ji bo bendek jorîn vegerînin:
    ///
    /// ```
    /// // îteratorek bêdawî sînorê jorîn û sînorê jêrîn ê herî zêde gengaz tune
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Iterator dixwe, hejmarek dubareyan dihejmêre û vedigerîne.
    ///
    /// Vê rêbaz dê bi [`next`] re çend caran bang bike heya ku [`None`] neyê dîtin, hejmarek caran [`Some`] dît vegerîne.
    /// Zanibe ku [`next`] ne hewce ye ku bi kêmanî carekê were gazî kirin heke veberhêner hêmanên wê tunebin.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Tevgerîna Zêde
    ///
    /// Rêbaz li hember zêdebûna avê nahêle, lewma jimartina hêmanên iteratorê yên ji [`usize::MAX`] zêdetir hêman jî encamek çewt an panics çêdike.
    ///
    /// Ger vegotinên xeletiyê werin çalak kirin, panic garantî ye.
    ///
    /// # Panics
    ///
    /// Vê fonksiyonê dibe ku panic heke iterator ji hêmanên [`usize::MAX`] zêdetir hebe.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Ittatorê dixwe, hêmana paşîn vedigire.
    ///
    /// Ev rêbaz dê iterator binirxîne heya ku ew [`None`] vegerîne.
    /// Dema ku wiya dike, ew şopdarê hêmana heyî ye.
    /// Piştî ku [`None`] vegeriya, `last()` wê hingê hêmana paşîn a ku dîtî vegerîne.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Ji hêla hêmanên `n` ve pêşveker pêşve diçe.
    ///
    /// Ev rêbaz dê bi dilgermî hêmanên `n` bi banga [`next`] heya `n` caran heya ku [`None`] neyê dîtin bi paş ve bavêje.
    ///
    /// `advance_by(n)` dê [`Ok(())`][Ok] vegerîne heke iterator bi hêmanên `n` bi serfirazî pêş bikeve, an jî [`Err(k)`][Err] heke [`None`] were dîtin, ku `k` hejmara hêmanên ku iterator ji hêla hêmanan ve xilaskirî ye pêşve diçe (ango
    /// dirêjahiya iterator).
    /// Zanibe ku `k` her gav ji `n` kêmtir e.
    ///
    /// Bangkirina `advance_by(0)` hêmanan naxwe û her dem [`Ok(())`][Ok] vedigerîne.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // tenê `&4` hate paşguh kirin
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Vegere `n`yê hêmana veberhênerê.
    ///
    /// Mîna piraniya karûbarên navnîşkirinê, jimartin ji sifir dest pê dike, lewma `nth(0)` nirxa yekem, `nth(1)` ya duyemîn û hwd vedigerîne.
    ///
    /// Zanibe ku hemî hêmanên pêşîn, û hem jî hêmana vegeriyan, dê ji dahêner werin xerckirin.
    /// Ew tê wê wateyê ku hêmanên pêşîn dê werin avêtin, û her weha ku gelek caran bangkirina `nth(0)` li ser heman iterator dê hêmanên cûda vegerîne.
    ///
    ///
    /// `nth()` dê [`None`] vegerîne heke `n` ji dirêjahiya dirêjahî mezintir an wekhev be.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Gelek caran bangkirina `nth()` paşvekêşker paşve venagerîne:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Heke ji hêmanên `n + 1` kêmtir bin vegerin `None`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Iterator di heman xalê de dest pê dike, lê li gorî her hejmarê gav bi gav diavêje diafirîne.
    ///
    /// Nîşe 1: Hêmana yekem a iterator dê her gav were vegerandin, bêyî ku gavek were dayîn.
    ///
    /// Nîşe 2: Dema ku hêmanên paşguhkirî têne kişandin ne sabît e.
    /// `StepBy` mîna rêza `next(), nth(step-1), nth(step-1),…` tevdigere, lê di heman demê de serbest e ku mîna rêzê tevbigere
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Kîjan rê tê bikar anîn dibe ku ji ber hin sedeman ji ber sedemên karûbarê biguheze.
    /// Awayê duyemîn dê iterator zûtir pêşde bibe û dibe ku bêtir tiştan bixwe.
    ///
    /// `advance_n_and_return_first` hevwate ya:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Ger gava gava `0` be dê rêbaz dê panic be.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Du rêzker digire û li dû hev li pey hev iteratorek nû diafirîne.
    ///
    /// `chain()` dê veberhênerekî nû vegerîne ku dê pêşî li ser nirxên ji yekem iterator û dûv re jî li ser nirxên ji iterator duyemîn dubare bike.
    ///
    /// Bi gotinên din, ew du tekrarker bi hev re, di zincîrekê de girêdide.🔗
    ///
    /// [`once`] bi gelemperî tête bikar anîn ku nirxek yekgirtî li zincîreyek celebên din ên dubarekirinê biguncîne.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ji ber ku argumana `chain()` [`IntoIterator`] bikar tîne, em dikarin her tiştê ku dikare were veguheztin [`Iterator`], ne tenê [`Iterator`] bixwe, derbas bikin.
    /// Mînakî, pelikên (`&[T]`) [`IntoIterator`] bicîh dikin, û wusa dikare rasterast derbasî `chain()` bibe:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Heke hûn bi Windows API re dixebitin, hûn dikarin bixwazin [`OsStr`] li `Vec<u16>` veguherînin:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Zip up' du iterateran di nav yek tekkerê cotan de.
    ///
    /// `zip()` veberhênerekî nû vedigerîne ku dê li ser du dubareyên din dubare bike, tûpalek vedigerîne ku hêmana yekem ji iteratorê yekem re tê, û hêmana duyemîn jî ji iteratorê duyemîn tê.
    ///
    ///
    /// Bi gotinên din, ew du dubareker bi hev re zip dike, dibe yek.
    ///
    /// Ger yek iterator [`None`] vegerîne, [`next`] ji iterator zip dê [`None`] vegerîne.
    /// Ger veberhênerê yekem [`None`] vegerîne, dê `zip` kurt-girêde û `next` dê li ser iteratorê duyemîn neyê bang kirin.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ji ber ku argumana `zip()` [`IntoIterator`] bikar tîne, em dikarin her tiştê ku dikare were veguheztin [`Iterator`], ne tenê [`Iterator`] bixwe, derbas bikin.
    /// Mînakî, pelikên (`&[T]`) [`IntoIterator`] bicîh dikin, û wusa dikare rasterast derbasî `zip()` bibe:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` bi gelemperî ji bo zipkirina iteratorek bêdawî bi yeka sînor tê bikar anîn.
    /// Ev dixebite ji ber ku iteratorê sînor dê di dawiyê de [`None`] vegerîne, dawiya zerikê.Zipping bi `(0..)` dikare pir mîna [`enumerate`] xuya bike:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Iteratorek nû diafirîne ku kopiyek `separator` dixe navbera hêmanên tenişta iteratorê orjînal.
    ///
    /// Di doza ku `separator` [`Clone`] bicîh nake an hewce dike ku her car were hesibandin, [`intersperse_with`] bikar bînin.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Hêmana yekem ji `a`.
    /// assert_eq!(a.next(), Some(&100)); // Dabeşker.
    /// assert_eq!(a.next(), Some(&1));   // Hêmana paşîn ji `a`.
    /// assert_eq!(a.next(), Some(&100)); // Dabeşker.
    /// assert_eq!(a.next(), Some(&2));   // Hêmana paşîn ji `a`.
    /// assert_eq!(a.next(), None);       // Iterator qediya.
    /// ```
    ///
    /// `intersperse` dibe ku pir kêrhatî be ku meriv bi hêmanek hevpar re beşdarî tiştên iterator bibe:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Iteratorek nû diafirîne ku hêmanek ku ji hêla `separator` ve hatî afirandin di navbera hêmanên tenişta iteratorê orjînal de cih dike.
    ///
    /// Girtîgehê dê carek carek were bang kirin her carê ku tiştek ji iteratorê bingehek di navbera du hêmanên cîran de were danîn;
    /// bi taybetî, heke iteratorê bingehîn ji du heban kêmtir bide û piştî ku tişta paşîn were hilberandin, girtinê nayê gotin.
    ///
    ///
    /// Ger tiştê iterator [`Clone`] bicîh bike, dibe ku hêsantir be ku hûn [`intersperse`] bikar bînin.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Hêmana yekem ji `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Dabeşker.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Hêmana paşîn ji `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Dabeşker.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Hêmana paşîn ji `v`.
    /// assert_eq!(it.next(), None);               // Iterator qediya.
    /// ```
    ///
    /// `intersperse_with` dikare di rewşên ku pêdivî ye ku veqetandêr were hesibandin de were bikar anîn:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Girtîbûn muttefîk konteksa xwe deyn dike ku tiştek çêbike.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Girtinek digire û iteratorek çêdike ku wê girtinê li her hêmanê bang dike.
    ///
    /// `map()` bi saya argumana wê yekê vedigerîne yekê din:
    /// tiştek ku [`FnMut`] pêk tîne.Ew iteratorek nû çêdike ku vê girtinê li her hêmanê iteratorê ya eslî bang dike.
    ///
    /// Heke hûn di celebên ramanê de baş in, hûn dikarin `map()` wiha bifikirin:
    /// Heke îteratorek we heye ku hêmanên hin celebên `A` dide we, û hûn iteratorek ji hin celebên din ên `B` dixwazin, hûn dikarin `map()` bikar bînin, deriyek ku `A` digire û `B` vedigerîne derbas bikin.
    ///
    ///
    /// `map()` ji hêla têgînî ve dişibe xelekek [`for`].Lêbelê, ji ber ku `map()` tembel e, ew çêtirîn tête bikar anîn dema ku hûn berê bi veberhênerên din re dixebitin.
    /// Heke hûn ji bo bandorek aliyek celebek looping dikin, ew ji `map()` bêtir [`for`] bikar anîn bêtir idiomatîkî tête hesibandin.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Heke hûn rengek bandora alî dikin, [`for`] ji `map()` tercîh bikin:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // viya neke:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // ew ê neyê darvekirin jî, ji ber ku tembel e.Rust dê we di vê derbarê de hişyar bike.
    ///
    /// // Di şûna wê de, ji bo bikar bînin:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Bang li girtina her hêmanê iteratorê dike.
    ///
    /// Ev bi karanîna xelekek [`for`] li ser iteratorê hevseng e, her çend `break` û `continue` ji girtinê ne gengaz e.
    /// Bi gelemperî karanîna xelekek `for` bêtir idiomatîk e, lê dibe ku `for_each` dema ku hêmanan li dawiya zincîrên dirêjtir ên îteratorê pêvajoyê dike, pirtirîn xwendî be.
    ///
    /// Di hin rewşan de dibe ku `for_each` ji xelekek jî zûtir be, ji ber ku ew ê li ser adapterên mîna `Chain` dubareya navxweyî bikar bîne.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Ji bo nimûneyek wusa piçûk, dibe ku xelekek `for` paqijtir be, lê dibe ku `for_each` çêtir be ku şêwazek fonksiyonel bi dûbarekerên dirêj re bimîne:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Iterator-ê ku girtinê bikar tîne destnîşan dike ku divê hêmanek were hilberandin.
    ///
    /// Hêmanek tê dayîn divê dorpêç `true` an `false` vegere.Iteratorê vegerandî dê tenê hêmanên ku girtîbûn rast vedigere bide.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ji ber ku girtina ku ji `filter()` re derbas bûye referansek digire, û gelek dûbareker li ser çavkanîyan dubare dikin, ev dibe sedema rewşek tevlihev, ku celebê girtinê referansek ducar e:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // du du * hewce dike!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ew hevpar e ku meriv li şûna wê argumanê bikar bîne da ku meriv yekê dûr bixe:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // hem&û *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// an herdu jî:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // du &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ji van tebeqeyan.
    ///
    /// Zanibe ku `iter.filter(f).next()` bi `iter.find(f)` re hevseng e.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Iterator ku hem parzûn û nexşeyan jî diafirîne.
    ///
    /// Iteratorê vegerandî tenê `nirxa` ya ku girtina pêvekirî `Some(value)` vedigerîne dide.
    ///
    /// `filter_map` dikare were bikar anîn ku zincîrên [`filter`] û [`map`] kurttir werin çêkirin.
    /// Mînaka jêrîn nîşan dide ku çawa `map().filter().map()` dikare bi bangek yek ji `filter_map` re kurt bibe.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Li vir heman mînak heye, lê digel [`filter`] û [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Iterator diafirîne ku hem jimareya dubarekirina heyî û hem jî nirxa paşîn dide.
    ///
    /// Iterator vegeriyan cotên `(i, val)` dide, ku `i` nîşana niha ya dubarebûnê ye û `val` nirxa ku ji hêla iterator vedigere ye.
    ///
    ///
    /// `enumerate()` jimartina xwe wekî [`usize`] diparêze.
    /// Heke hûn dixwazin bi jimareyek mezinahiya cûda bihejmêrin, fonksiyona [`zip`] fonksiyonên wekhev peyda dike.
    ///
    /// # Tevgerîna Zêde
    ///
    /// Rêbaz li hember zêdehiyan neparêze, ji ber vê yekê jimartina ji hêmanên [`usize::MAX`] zêdetir an encamek çewt an panics çêdike.
    /// Ger vegotinên xeletiyê werin çalak kirin, panic garantî ye.
    ///
    /// # Panics
    ///
    /// Heke nîşana ku dê were vegerandin dê [`usize`] zêde bibe, dibe ku veberhêner vegerî panic.
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Iterator çêdike ku dikare [`peek`] bikar bîne da ku bêyî xerckirin li hêmana din a iterator binêre.
    ///
    /// Metoda [`peek`] li iteratorê zêde dike.Ji bo bêtir agahdariyê belgeya wê bibînin.
    ///
    /// Bala xwe bidinê ku dema ku [`peek`] cara yekem tê gazî kirin iteratorê bingehîn hîn jî pêşve diçe: Ji bo ku hêmana paşîn bistîne, ji [`next`] re tê gotin iteratorê binyadî, ji ber vê yekê jî bandorên alî (ango
    ///
    /// tiştek din ji bilî anîna nirxa din) rêbaza [`next`] dê pêk were.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() dihêle em li future binêrin
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // em dikarin gelek caran peek() bikin, iterator dê pêş nekeve
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // piştî ku iterator xelas bû, peek() jî wusa ye
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Iterator ku hêmanên [`skip`} li ser bingehek pêşwext saz dike diafirîne.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` girtinê wekî arguman digire.Ew ê vê girtinê li her hêmanê veberhênerê bi nav bike, û hêmanan paşguh bike heya ku ew `false` vegerîne.
    ///
    /// Piştî ku `false` vegeriya, karê `skip_while()`'s qediya, û hêmanên mayî têne hilberandin.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ji ber ku dorpêça ku ji `skip_while()` re hatî derbas kirin referansek digire, û gelek dûbareker li ser çavkanîyan dubare dikin, ev dibe sedema rewşek tevlihev, ku celebê argumana girtinê referansek ducar e:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // du du * hewce dike!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Rawestandina piştî `false`-a destpêkê:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // dema ku ev dê derew bûya, ji xwe me derewek kir, skip_while() êdî nayê bikar anîn
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Ittorek çêdike ku hêmanên li ser bingehek pêş ve dibe.
    ///
    /// `take_while()` girtinê wekî arguman digire.Ew ê vê girtinê li ser her hêmanê veberhênerê bi nav bike, û hêmanên hilberînê dema ku ew `true` vedigerîne.
    ///
    /// Piştî ku `false` vegeriya, karê `take_while()`'s qediya, û hêmanên mayî têne paşguh kirin.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ji ber ku girtina ku ji `take_while()` re derbas bûye referansek digire, û gelek dûbareker li ser çavkanîyan dubare dikin, ev dibe sedema rewşek tevlihev, ku celebê girtinê referansek ducar e:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // du du * hewce dike!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Rawestandina piştî `false`-a destpêkê:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Zêde hêmanên me hene ku ji sifirê kêmtir in, lê ji ber ku me berê derewek girt, take_while() êdî nayê bikar anîn
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ji ber ku `take_while()` hewce dike ku li nirxê binihêre da ku bibîne gelo ew pêdivî ye an na, dê dubarekerên xwar dê bibînin ku ew jê hatî rakirin:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` êdî ne li wir e, ji ber ku ew hat vexwarin da ku bibîne gelo dê dûbare sekinî be, lê dîsa nehate danîn nav îteratorê.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Ittorek çêdike ku hem hêmanan li gorî pêşîn û nexşeyan dide.
    ///
    /// `map_while()` girtinê wekî arguman digire.
    /// Ew ê vê girtinê li ser her hêmanê veberhênerê bi nav bike, û hêmanên hilberînê dema ku ew [`Some(_)`][`Some`] vedigerîne.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Li vir heman mînak heye, lê digel [`take_while`] û [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Rawestandina piştî [`None`]-a destpêkê:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Hêmanên me yên din hene ku dikarin di u32 (4, 5) de cih bigirin, lê `map_while` `None` ji bo `-3` vegerand (wekî `predicate` vegeriya `None`) û `collect` di `None` ya yekem de rûdide.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Ji ber ku `map_while()` hewce dike ku li nirxê binihêre da ku bibîne gelo ew pêdivî ye an na, dê dubarekerên xwar dê bibînin ku ew jê hatî rakirin:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` êdî ne li wir e, ji ber ku ew hat vexwarin da ku bibîne gelo dê dûbare sekinî be, lê dîsa nehate danîn nav îteratorê.
    ///
    /// Bala xwe bidinê ku berevajî [`take_while`] ev iterator **ne** fuse.
    /// Her weha ne diyar e ku piştî ku [`None`] ya yekem vegeriya ev iterator çi vedigerîne.
    /// Heke hûn hewceyê iteratorê fuzkirî ne, [`fuse`] bikar bînin.
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Ittorek çêdike ku hêmanên yekem `n` vedişêre.
    ///
    /// Piştî ku ew hatin vexwarin, hêmanên mayî têne hilberandin.
    /// Li şûna ku vê rêbazê rasterast derbas bike, li şûna rêbaza `nth` paşde bixe.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Iteratorek ku hêmanên xweyên `n`-yên pêşîn dide hev diafirîne.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` bi gelemperî bi vebêjek bêdawî re tê bikar anîn, da ku ew bi sînor be:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Heke ji hêmanên `n` kêmtir hebe, `take` dê xwe bi mezinahiya iteratorê bingehîn ve bisînor bike:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Adapterek iterator dişibihe [`fold`] ku rewşa hundurîn digire û iteratorek nû çêdike.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` du argumanan digire: nirxek destpêkê ku dewleta navxweyî diçîne, û girtinek bi du argumanan, ya yekem referansa guhêrbar a rewşa navxweyî ye û ya duyemîn jî hêmanek iterator.
    ///
    /// Girtî dikare ji dewleta navxweyî re peywirdar bike ku dewletê di navbera dubareyan de parve bike.
    ///
    /// Li ser dûbarekirinê, dorpêçkirin dê li her hêmanê dahêner were sepandin û nirxa vegera ji dorpêçê, an [`Option`], ji hêla vebêjer ve tête dayîn.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // her dubare, em ê dewletê li hêmanê pirr bikin
    ///     *state = *state * x;
    ///
    ///     // wê hingê, em ê înkara dewletê bidin
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Iterator ku wekî nexşeyê dixebite, çêdike, lê avahiya hêlînkirî radizê, diafirîne.
    ///
    /// Adapter [`map`] pir bikêr e, lê tenê dema ku argumana girtinê nirxan hilberîne.
    /// Ger li şûna wê iterator çêbibe, tebeqeyek bêserûber a zêde heye.
    /// `flat_map()` dê vê tebeqeya jêzêde ji xwe rake.
    ///
    /// Hûn dikarin `flat_map(f)` wekî hevwateya semantîk a [`nexşeya`] ping-ê bifikirin, û dûv re jî``flatten`` wekî `map(f).flatten()`-ê.
    ///
    /// Awayek din a ramîna li ser `flat_map()`: Girtina ["nexşeya"] ji bo her hêmanê yekê vedigerîne, û girtina `flat_map()`'s ji bo her hêmanê iterator vedigerîne.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() vedigere vedigere
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Ittorek çêdike ku avahiya hêlînê radizê.
    ///
    /// Ev kêrhatî ye dema ku we re veberhêner dûbareker an dûbarekerê tiştan hebe ku dikare were vegerandin û hûn dixwazin yek astek bêserûberiyê jê bikin.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Nexşekirin û dûv re xapandin:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() vedigere vedigere
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Di heman demê de hûn dikarin vê yekê li gorî [`flat_map()`] ji nû ve binivîsin, ku di vê rewşê de çêtir e ji ber ku ew mebest zelaltir radigihîne:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() vedigere vedigere
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Flattening tenê yek carî astek hêlînê radike:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Li vir em dibînin ku `flatten()` xanîyek "deep" pêk nayne.
    /// Di şûna wê de, tenê astek hêlînê tê rakirin.Ango, heke hûn `flatten()` rêzikek sê-dimîne, dê encam bibe du-alî û ne yek-alî.
    /// Ji bo ku avahiyek yek-dîmen bistînin, divê hûn dîsa `flatten()` bikin.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Iterator çêdike ku piştî [`None`] ya yekem xilas dibe.
    ///
    /// Piştî ku veberhêner [`None`] vedigerîne, bangên future dibe ku [`Some(T)`] dîsa nede an na.
    /// `fuse()` an iterator adapte dike, piştrast dike ku piştî ku [`None`] hate dayîn, ew ê her dem [`None`] her û her vegerîne.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// // iteratorê ku di navbera Hin û Neçê de diguhere
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // heke ew jî be, Some(i32), din Na
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // em dikarin bibînin ku iteratorê me paş û paş diçe
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // lêbelê, gava ku em wê fuse bikin ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // ew ê her dem piştî cara yekem `None` vegere.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Tiştek bi her hêmana vegêranê re dike, nirxê derbas dike.
    ///
    /// Dema ku dûbareker bikar tînin, hûn ê timûtim çend ji wan bi hev re zincîr bikin.
    /// Gava ku hûn li ser kodek wusa dixebitin, dibe ku hûn bixwazin ka li deverên cihêreng ên boriyê çi diqewime binihêrin.Ji bo vê yekê, bang li `inspect()` bikin.
    ///
    /// Ji `inspect()` re hevpartir e ku ji koda xweya dawîn re wekî amûrek xeletiyê were bikar anîn, lê serîlêdan dikarin di hin rewşan de kêrhatî bibînin dema ku çewtî hewce ne ku werin avêtin berî ku werin avêtin.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // ev rêza iterator tevlihev e.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // ka em hin bangên inspect() lê zêde bikin ku lêpirsîn ka çi diqewime
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Ev dê çap bike:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Çewtiyên têketinê berî avêtina wan:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Ev dê çap bike:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Li şûna xerckirinê, iterator-ê boros dike.
    ///
    /// Ev kêrhatî ye ku destûr were danîna adapterên iterator dema ku hîn jî xwedaniya iterator ya orjînal didome.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // heke em careke din hewl bidin ku iter bikar bînin, ew ê nexebite.
    /// // Rêzeya jêrîn "xeletî dide": karanîna nirxa barbar: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // ka em carek din wiya biceribînin
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // li şûna wê, em li .by_ref() zêde dikin
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // niha ev tenê baş e:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Itteratorek veguherîne berhevokê.
    ///
    /// `collect()` dikare her tiştî bigire, û wê veguherîne berhevokek têkildar.
    /// Ev di pirtûkxaneya standard de, di cûrbecûr kontekstan de tê bikar anîn, yek ji wan rêbazên bihêztir e.
    ///
    /// Nimûneya herî bingehîn a ku `collect()` tê de bikar anîn ev e ku berhevokek veguherîne berhevokek din.
    /// Hûn berhevokek bistînin, li [`iter`] lê bigerin, komek veguherînan bikin, û paşê li dawiya `collect()`.
    ///
    /// `collect()` her weha dikare nimûneyên celebên ku ne berhevokên tîpîk in biafirîne.
    /// Mînakî, [`String`] dikare ji [`char`] s were çêkirin, û veberhênerek tiştên [`Result<T, E>`][`Result`] dikare di `Result<Collection<T>, E>` de were berhev kirin.
    ///
    /// Ji bo bêtir li nimûneyên li jêr binêrin.
    ///
    /// Ji ber ku `collect()` pir gelemperî ye, ew dikare bibe sedema pirsgirêkên bi rêzgirtina celebê.
    /// Bi vî rengî, `collect()` yek ji çend carinan e ku hûn ê hevoksaziyê bi dilovanî wekî 'turbofish' têne zanîn bibînin: `::<>`.
    /// Ev alîkariya algorîtmaya encamnameyê dike ku bi taybetî fam bike ka kîjan berhevoka ku hûn hewl didin ku tê de kom bikin.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Têbînî ku li milê çepê me hewceyê `: Vec<i32>` bû.Ji ber ku em dikarin, li şûna wê, [`VecDeque<T>`] kom bikin:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Li şûna têgihiştina `doubled` 'turbofish' bikar bînin:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Ji ber ku `collect()` tenê li tiştê ku hûn berhev dikin xem dike, hûn hîn jî dikarin bi turbofish re hincetek celebek qismî, `_` bikar bînin:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// `collect()` bikar tînin da ku [`String`] çêbikin:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Heke navnîşek we ya [`Encam<T, E>"]["Encam"] s, hûn dikarin `collect()` bikar bînin ku bibînin ka yek ji wan têk çû:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // xeletiya yekem dide me
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // navnîşa bersivan dide me
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Itteratorek dixwe, jê du berhevokan diafirîne.
    ///
    /// Pêşgotin ji `partition()` re hatî derbas kirin dikare `true`, an `false` vegerîne.
    /// `partition()` cotek vedigerîne, hemî hêmanên ku `true` lê vegerandiye, û hemî hêmanên ku `false` lê vegerandiye.
    ///
    ///
    /// [`is_partitioned()`] û [`partition_in_place()`] jî bibînin.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Li gorî pêşpirtika daneyî hêmanên vê iterator *di cîh de* ji nû ve rêz dike, wusa ku hemî yên ku vedigerin `true` li pêşiya yên ku `false` vedigerin vedigerin.
    ///
    /// Hejmara hêmanên `true` ên hatine dîtin vedigerîne.
    ///
    /// Rêza têkildar a tiştên dabeşkirî nayê domandin.
    ///
    /// [`is_partitioned()`] û [`partition()`] jî bibînin.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Dabeşkirina di navbêna êvan û astengiyan de
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: gelo divê em ji ber jimar serûbin bibin endîşe bikin?Awayê yekane ku ji zêdetir hebe
        // `usize::MAX` referansên guhêrbar bi ZST re ne, ku ji bo dabeşkirinê ne kêrhatî ne ...

        // Van fonksiyonên girtina "factory" hene ku di `Self` de dev ji ceribandinê bernedin.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Bi dubareî `false`-a yekem bibînin û bi `true`-a paşîn re veguherînin.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Kontrol dike ka hêmanên vê iteratorê li gorî pêşnûma dayîn hatî dabeş kirin, wusa ku hemî yên ku vedigerin `true` li pêşiya yên ku `false` vedigerin vedigerin.
    ///
    ///
    /// [`partition()`] û [`partition_in_place()`] jî bibînin.
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // An hemî tişt `true` diceribînin, an jî bendê yekem li `false` disekine û em kontrol dikin ku piştî wê re hêmanên `true` tune.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Rêbazek iterator ku fonksiyonek bi kar tîne heya ku ew bi serfirazî vegere, nirxek yekane, paşîn hilberîne.
    ///
    /// `try_fold()` du argumanan digire: nirxek destpêkê, û girtinek bi du argumanan: 'accumulator', û hêmanek.
    /// Girtîgeh an bi serfirazî vedigere, bi nirxa ku divê berhevkar ji bo dubareya din hebe, an jî ew têkçûnê vedigire, bi nirxek çewtiyê re ku yekser (short-circuiting) vedigere gazîvan.
    ///
    ///
    /// Nirxa destpêkê ew nirx e ku berhevkar dê li ser banga yekem hebe.Ger serlêdana girtinê li hember her hêmana veberhêner bi ser keve, `try_fold()` berhevoka paşîn wekî serfirazî vedigerîne.
    ///
    /// Folding kêrhatî ye her gava ku we berhevokek tiştek hebe, û hûn dixwazin jê re nirxek tenê hilberînin.
    ///
    /// # Nîşe ji Bicîhkeran
    ///
    /// Di warê vê yekê de çend rêbazên (forward) yên din sepandinên nerît hene, ji ber vê yekê hewl bidin ku vê yekê bi zelalî bicîh bînin heke ew dikare ji pêkanîna xeletiya pêşnumayê ya `for` çêtir tiştek bike.
    ///
    /// Bi taybetî, hewl bidin ku vê bangê `try_fold()` li ser perçeyên navxweyî yên ku ev iterator ji wan pêk tê, hebe.
    /// Heke gelek bang hewce ne, dibe ku kargêrê `?` ji bo zincîrkirina nirxê berhevokê hêsantir be, lê hay ji her tiştê ku naxwaze berî wan vegera zû were raber kirin hebe.
    /// Ev rêbazek `&mut self` e, ji ber vê yekê hewce ye ku dubarekirin piştî xistina xeletiyek li vir ji nû ve were dest pê kirin.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // berhema nîşankirî ya hemî hêmanên array
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Dema ku hêmana 100-ê zêde bikin ev hejmar zêde dibe
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Ji ber ku wê kurt-dorpêçandî, hêmanên mayî hîn jî bi saya iteratorê peyda dibin.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Rêbazek iterator ku li her tiştê di iterator de fonksiyonek çewt bikar tîne, li xeletiya yekem disekine û wê xeletiyê vedigire.
    ///
    ///
    /// Ev jî dikare wekî forma xelet a [`for_each()`] an wekî guhertoya bêwelat a [`try_fold()`] were fikirîn.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Ew kurt-girêdan, ji ber vê yekê tiştên mayî hîn jî di iterator de ne:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Bi pêkanîna emeliyatekê, û vegera encama dawîn, her elementê davêje berhevkarekê.
    ///
    /// `fold()` du argumanan digire: nirxek destpêkê, û girtinek bi du argumanan: 'accumulator', û hêmanek.
    /// Girtî nirxa ku divê berhevkar ji bo dubareya din hebe vedigerîne.
    ///
    /// Nirxa destpêkê ew nirx e ku berhevkar dê li ser banga yekem hebe.
    ///
    /// Piştî ku vê girtinê li her hêmanê dahêner bikar tîne, `fold()` berhevokê vedigire.
    ///
    /// Ji vê operasyonê re carinan 'reduce' an 'inject' tê gotin.
    ///
    /// Folding kêrhatî ye her gava ku we berhevokek tiştek hebe, û hûn dixwazin jê re nirxek tenê hilberînin.
    ///
    /// Note: `fold()`, û rêbazên wekhev ên ku li tevahiya iteratorê digerin, dibe ku ji bo dubareyên bêdawî biqedin, heta li ser traits ku di dema bêdawî de encamek diyar dibe.
    ///
    /// Note: [`reduce()`] dikare were bikar anîn ku hêmana yekem wekî nirxa destpêkê bikar bîne, heke celebê berhevkar û celebê tişt yek be.
    ///
    /// # Nîşe ji Bicîhkeran
    ///
    /// Di warê vê yekê de çend rêbazên (forward) yên din sepandinên nerît hene, ji ber vê yekê hewl bidin ku vê yekê bi zelalî bicîh bînin heke ew dikare ji pêkanîna xeletiya pêşnumayê ya `for` çêtir tiştek bike.
    ///
    ///
    /// Bi taybetî, hewl bidin ku vê bangê `fold()` li ser perçeyên navxweyî yên ku ev iterator ji wan pêk tê, hebe.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // berhevoka hemî hêmanên array
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Ka em li her gavê dubarekirinê li vir bimeşin:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// So ji ber vê yekê, encama meya dawî, `6`.
    ///
    /// Ew gelemperî ye ku mirovên ku dubareyan pir bikar neanîne ku xelekek `for` bi navnîşek tiştan bikar bînin ku encamek çêbikin.Ew dikarin werin veguheztin `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // ji bo loop:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // ew yek in
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Hêmanên bi yek-yek re kêm dike, bi berdewamî operasyona kêmkirinê têxe meriyetê.
    ///
    /// Ger iterator vala be, [`None`] vedigerîne;wekî din, encama kêmkirinê vedigerîne.
    ///
    /// Ji bo vegêranên ku bi kêmî ve hêmanek wan heye, ev eynî wek [`fold()`] bi hêmana yekem a iteratorê re wekî nirxa destpêkê ye, her hêmana paşîn tê de qat dike.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Nirxa herî zêde bibînin:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Test dike ku heke her elementa iteratorê li gorî pêşekekê li hev bîne.
    ///
    /// `all()` girtinek digire ku `true` an `false` vedigerîne.Ew vê girtinê li her hêmanê veberhêner bikar tîne, û heke ew hemî `true` vegerînin, wê hingê `all()` jî wusa dike.
    /// Ger yek ji wan `false` vegerîne, ew `false` vedigerîne.
    ///
    /// `all()` kurt-girêdan e;bi gotinek din, ew ê gava ku `false` bibîne, dê pêvajoyê rawestîne, ji ber ku çi çi dibe bila bibe, encam jî `false` be.
    ///
    ///
    /// Pêşniyarek vala `true` vedigerîne.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Li `false` yekem rawestîn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // em hîn jî dikarin `iter` bikar bînin, ji ber ku hêman zêdetir in.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Test dike ku heke hêmanek iteratorê li gorî pêşekekê li hev bîne.
    ///
    /// `any()` girtinek digire ku `true` an `false` vedigerîne.Ew vê girtinê li her hêmanê veberhêner bikar tîne, û heke yek ji wan `true` vegerîne, wê hingê `any()` jî dike.
    /// Ger ew hemî `false` vegerînin, ew `false` vedigerîne.
    ///
    /// `any()` kurt-girêdan e;bi gotinek din, ew ê gava ku `true` bibîne, dê pêvajoyê rawestîne, ji ber ku çi çi dibe bila bibe, encam jî `true` be.
    ///
    ///
    /// Pêşniyarek vala `false` vedigerîne.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Li `true` yekem rawestîn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // em hîn jî dikarin `iter` bikar bînin, ji ber ku hêman zêdetir in.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Lêgerîna hêmanek iteratorê dike ku tewangê têr dike.
    ///
    /// `find()` girtinek digire ku `true` an `false` vedigerîne.
    /// Ew vê girtinê li her hêmanê veberhêner bikar tîne, û heke yek ji wan `true` vegerîne, hingê `find()` [`Some(element)`] vedigerîne.
    /// Ger ew hemî `false` vegerînin, ew [`None`] vedigerîne.
    ///
    /// `find()` kurt-girêdan e;bi gotinên din, ew ê pêvajoyê rawestîne hema ku dorpêç `true` vegerîne.
    ///
    /// Ji ber ku `find()` referansek digire, û gelek dûbareker li ser referansan dubare dikin, ev dibe sedema rewşek tevlihev a ku argumana referansek du qat e.
    ///
    /// Hûn dikarin vê bandorê di nimûneyên li jêr de, bi `&&x` re bibînin.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Li `true` yekem rawestîn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // em hîn jî dikarin `iter` bikar bînin, ji ber ku hêman zêdetir in.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Têbînî ku `iter.find(f)` bi `iter.filter(f).next()` re hevseng e.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Fonksiyonê li hêmanên iteratorê dike û encama yekem-ne-yek yekem vedigire.
    ///
    ///
    /// `iter.find_map(f)` wekhevî `iter.filter_map(f).next()` e.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Fonksiyonê li hêmanên iteratorê dike û yekem encama rastîn an xeletiya yekem vedigire.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Elementek di iteratorê de digere, indexa xwe vedigire.
    ///
    /// `position()` girtinek digire ku `true` an `false` vedigerîne.
    /// Ew vê girtinê li her hêmanê veberhêner bikar tîne, û heke yek ji wan `true` vegerîne, wê hingê `position()` [`Some(index)`] vedigerîne.
    /// Heke hemî `false` vegerin, ew [`None`] vedigerîne.
    ///
    /// `position()` kurt-girêdan e;bi gotinek din, ew ê zûtirîn pêvajoyê rawestîne gava ku ew `true` bibîne.
    ///
    /// # Tevgerîna Zêde
    ///
    /// Rêbaz li hember zêdebûna avê nahêle, ji ber vê yekê heke ji [`usize::MAX`] hêmanên nehevgirtî zêdetir hebin, ew yan encamek çewt an panics çêdike.
    ///
    /// Ger vegotinên xeletiyê werin çalak kirin, panic garantî ye.
    ///
    /// # Panics
    ///
    /// Vê fonksiyonê dibe ku panic heke iterator ji `usize::MAX` hêmanên ne-hevber zêdetir hebe.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Li `true` yekem rawestîn:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // em hîn jî dikarin `iter` bikar bînin, ji ber ku hêman zêdetir in.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Indeksa vegerî girêdayî dewleta iterator e
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Elementek di iterator de ji rastê digere, indexa xwe vedigire.
    ///
    /// `rposition()` girtinek digire ku `true` an `false` vedigerîne.
    /// Ew vê girtinê li her hêmanê veberhêner dike, ji dawiyê dest pê dike, û heke yek ji wan `true` vegerîne, hingê `rposition()` [`Some(index)`] vedigerîne.
    ///
    /// Heke hemî `false` vegerin, ew [`None`] vedigerîne.
    ///
    /// `rposition()` kurt-girêdan e;bi gotinek din, ew ê zûtirîn pêvajoyê rawestîne gava ku ew `true` bibîne.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Li `true` yekem rawestîn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // em hîn jî dikarin `iter` bikar bînin, ji ber ku hêman zêdetir in.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Li vir ne hewceyê venêrana zêdebûnê ye, ji ber ku `ExactSizeIterator` tê wê wateyê ku hejmara hêmanan dikeve nav `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Hêmana herî zêde ya iterator vedigerîne.
    ///
    /// Ger çend hêman bi heman rengî herî zêde bin, hêmana paşîn tê vegerandin.
    /// Ger iterator vala be, [`None`] vedigere.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Hêmana herî kêm a iterator vedigerîne.
    ///
    /// Ger çend hêman bi wekhevî kêm be, hêmana yekem vedigere.
    /// Ger iterator vala be, [`None`] vedigere.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Hêmana ku ji fonksiyona diyarkirî nirxa herî zêde dide vedigerîne.
    ///
    ///
    /// Ger çend hêman bi heman rengî herî zêde bin, hêmana paşîn tê vegerandin.
    /// Ger iterator vala be, [`None`] vedigere.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Hêmana ku bi nirxê herî zêde dide li gorî fonksiyona berhevdana diyarkirî vedigere.
    ///
    ///
    /// Ger çend hêman bi heman rengî herî zêde bin, hêmana paşîn tê vegerandin.
    /// Ger iterator vala be, [`None`] vedigere.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Hêmana ku ji fonksiyona diyarkirî nirxa herî kêm dide, vedigerîne.
    ///
    ///
    /// Ger çend hêman bi wekhevî kêm be, hêmana yekem vedigere.
    /// Ger iterator vala be, [`None`] vedigere.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Hêmana ku li gorî fonksiyona berawirdkirina diyarkirî ya herî hindik dide, vedigerîne.
    ///
    ///
    /// Ger çend hêman bi wekhevî kêm be, hêmana yekem vedigere.
    /// Ger iterator vala be, [`None`] vedigere.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Riya rêvekera vedigere.
    ///
    /// Bi gelemperî, dûbareker ji çepê ber bi rastê vedigerin.
    /// Piştî karanîna `rev()`, dê iterator li şûna wê ji rastê ber bi çepê ve biçe.
    ///
    /// Ev tenê gengaz e heke dawiya iterator hebe, ji ber vê yekê `rev()` tenê li ser ["DoubleEndedIterator"] ê dixebite.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Itteratorek cotan veguherîne cotek konteyner.
    ///
    /// `unzip()` iteratorek tevahî ya cotan dixwe, du berhevokan çêdike: yek ji hêmanên çepê yên cot, û yek jî ji hêmanên rast.
    ///
    ///
    /// Ev fonksiyon, di hinek wateyê de dijberê [`zip`] ye.
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Iterator ku hemî hêmanên xwe kopî dike diafirîne.
    ///
    /// Ev kêrhatî ye dema ku we regerek li ser `&T` hebe, lê hûn hewceyê heteroriyek li ser `T` bin.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // kopî kirin wekî .map(|&x| x) e
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Iteratorek ku [`klon`] wê hemî hêmanên wê ne diafirîne.
    ///
    /// Ev kêrhatî ye dema ku we regerek li ser `&T` hebe, lê hûn hewceyê heteroriyek li ser `T` bin.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // klonkirî ji bo jimareyan eynî wekî .map(|&x| x) e
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Ittorek bêdawî dubare dike.
    ///
    /// Li şûna ku li [`None`] bisekine, dê iterator li şûna wê, ji destpêkê ve, dîsa dest pê bike.Piştî ku dîsa dûbare bû, ew ê di destpêkê de dîsa dest pê bike.Again dîsa.
    /// Again dîsa.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Hêmanên îteratora berhev dike.
    ///
    /// Her hêmanê digire, wan li hev zêde dike, û encamê vedigerîne.
    ///
    /// Iteratorek vala nirxa sifir a tipê vedigire.
    ///
    /// # Panics
    ///
    /// Gava ku gazî `sum()` tê kirin û celebek jimareyek prîmîtîf tê vegerandin, ev rêbaza dê panic be ger hejmar zêde bibihure û verastkirinên verastkirinê werin çalak kirin.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Bi tevê iteratorê vedigere, hemî hêmanan zêde dike
    ///
    /// Pêşkêşkarek vala yek nirxa tipê vedigire.
    ///
    /// # Panics
    ///
    /// Dema ku gazî `product()` tê kirin û celebek jimareyek prîmîtîf tê vegerandin, heke hejmar zêde bibe û vebêjên verastkirinê werin çalak kirin dê rêbaza wê panic be.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) hêmanên vê [`Iterator`] bi yên din re dide ber hev.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) hêmanên vê [`Iterator`] bi yên fonksiyona berhevdana diyarkirî re bi yên yekê re hevber dike.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) hêmanên vê [`Iterator`] bi yên din re dide ber hev.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) hêmanên vê [`Iterator`] bi yên fonksiyona berhevdana diyarkirî re bi yên yekê re hevber dike.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Diyar dike ka hêmanên vê [`Iterator`] bi yên din re wekhev in an na.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Diyar dike ka hêmanên vê [`Iterator`] bi yên fonksiyona wekheviya diyarkirî re yên yên din in an na.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Diyar dike ka hêmanên vê [`Iterator`] bi yên din re ne wekhev in.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Diyar dike ka hêmanên vê [`Iterator`] ji yên yekê din [lexicographically](Ord#lexicographical-comparison) kêmtir in.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Diyar dike ka hêmanên vê [`Iterator`] [lexicographically](Ord#lexicographical-comparison) kêmtir in an jî yên yên din in an ne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Diyar dike ka hêmanên vê [`Iterator`] ji yên yekê din [lexicographically](Ord#lexicographical-comparison) mezintir in an na.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Diyar dike ka hêmanên vê [`Iterator`] [lexicographically](Ord#lexicographical-comparison) ji yên din mezintir an wekhev in.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Kontrol dike ka hêmanên vê iteratorê hatine rêzkirin.
    ///
    /// Ango, ji bo her hêmanê `a` û hêmana jêrîn `b`, `a <= b` divê hebe.Ger iterator tam sifir an yek hêmanê bide, `true` vedigere.
    ///
    /// Zanibe ku heke `Self::Item` tenê `PartialOrd` be, lê ne `Ord` be, pênaseya jorîn tê wateya ku ev fonksiyon `false` vedigerîne heke du heb tiştên li pey hev hebin neyên berhevdan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Kontrol dike ka hêmanên vê iteratorê bi karanîna fonksiyona berawirdkirî ya dabeşkirî hatine rêzkirin.
    ///
    /// Di şûna karanîna `PartialOrd::partial_cmp` de, ev fonksiyon fonksiyona `compare` ya hatî dayîn bikar tîne da ku rêzkirina du hêmanan diyar bike.
    /// Ji xeynî vê, ew bi [`is_sorted`] re wekhev e;ji bo bêtir agahdariyê belgeya wê bibînin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Kontrol dike ka hêmanên vê iteratorê bi karanîna fonksiyona jêgirtina mifteyê ya dane hatî dabeş kirin.
    ///
    /// Li şûna berhevdana hêmanên iterator rasterast, ev fonksiyon kilîtên hêmanan, ku ji hêla `f` ve hatî diyarkirin, dide ber hev.
    /// Ji xeynî vê, ew bi [`is_sorted`] re wekhev e;ji bo bêtir agahdariyê belgeya wê bibînin.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// [TrustedRandomAccess] bibînin
    // Navê awarte ev e ku di çareseriya rêbazê de ji pevçûna navan dûr bisekinin binihêrin #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}