/// Ji [`Iterator`] veguherîn.
///
/// Bi bicîhkirina `FromIterator` ji bo celebek, hûn diyar dikin ka ew ê çawa ji iterator were afirandin.
/// Ev ji bo celebên ku berhevokek ji celebek vedibêje hevpar e.
///
/// [`FromIterator::from_iter()`] kêm kêm bi zelalî tê gotin, û li şûna wê bi rêbaza [`Iterator::collect()`] tê bikar anîn.
///
/// Ji bo bêtir mînakan li belgekirina [`Iterator::collect()`]'s binêrin.
///
/// Her weha bibînin: [`IntoIterator`].
///
/// # Examples
///
/// Bikaranîna bingehîn:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// [`Iterator::collect()`] bikar tînin da ku bi nehênî `FromIterator` bikar bînin:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Ji bo celebê xwe `FromIterator` bicîh dikin:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Berhevokek nimûneyî, ew tenê pêça li ser Vec e<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ka em çend rêgezan bidin wê da ku em bikaribin yekê biafirînin û tiştan lê zêde bikin.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // û em ê FromIterator bicîh bikin
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Naha em dikarin iteratorek nû çêbikin ...
/// let iter = (0..5).into_iter();
///
/// // ... û jê MyCollection çêbikin
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // xebatan jî berhev bikin!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Ji iterator nirxek diafirîne.
    ///
    /// Ji bo bêtir [module-level documentation] bibînin.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Zivirîna nav [`Iterator`].
///
/// Bi bicîhkirina `IntoIterator` ji bo celebek, hûn diyar dikin ka ew ê çawa veguherîne iterator.
/// Ev ji bo celebên ku berhevokek ji celebek vedibêje hevpar e.
///
/// Yek sûd ji bicîhkirina `IntoIterator` ev e ku celebê we dê [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) be.
///
///
/// Her weha bibînin: [`FromIterator`].
///
/// # Examples
///
/// Bikaranîna bingehîn:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Ji bo celebê xwe `IntoIterator` bicîh dikin:
///
/// ```
/// // Berhevokek nimûneyî, ew tenê pêça li ser Vec e<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ka em çend rêgezan bidin wê da ku em bikaribin yekê biafirînin û tiştan lê zêde bikin.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // û em ê IntoIterator bicîh bikin
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Naha em dikarin berhevokek nû çêbikin ...
/// let mut c = MyCollection::new();
///
/// // ... hin tiştan lê zêde bike ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... û paşê wê veguherînin Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Ew gelemperî ye ku meriv `IntoIterator` wekî trait bound bikar bîne.Ev dihêle ku celebê berhevoka input biguhere, heya ku ew hîn jî tekrar be.
/// Sînorên zêde bi tixûbdarkirinê ve têne diyar kirin
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Celebê hêmanên ku li ser têne dubare kirin.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Em ê vê yekê veguherînin kîjan cûreyê iterator?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Ji nirxek iterator diafirîne.
    ///
    /// Ji bo bêtir [module-level documentation] bibînin.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Bi naveroka veberhênerekî berhevokekê dirêj bikin.
///
/// Iterator rêzeyek nirxan hilberandin, û berhevok jî dikarin wekî rêzeyek nirxan werin fikirîn.
/// `Extend` trait vê valahiyê pire dike, dihêle hûn berhevokek bi navkirina naverokên wê veberhênerê dirêj bikin.
/// Dema ku berhevokek bi mifteyek heyî ya dirêjkirî, ew navnîş tê nûve kirin an jî, di mijara berhevokên ku destûrê didin gelek têketinên bi tûşên wekhev de, ew navnîş tê de tête kirin.
///
///
/// # Examples
///
/// Bikaranîna bingehîn:
///
/// ```
/// // Hûn dikarin Tevnek bi hin tîpan dirêj bikin:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Pêkanîna `Extend`:
///
/// ```
/// // Berhevokek nimûneyî, ew tenê pêça li ser Vec e<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ka em çend rêgezan bidin wê da ku em bikaribin yekê biafirînin û tiştan lê zêde bikin.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ji ber ku MyCollection navnîşek i32 heye, em Extend for i32 bicîh dikin
/// impl Extend<i32> for MyCollection {
///
///     // Ev bi îmzeya betonek hinekî hêsantir e: em dikarin li her tiştê ku dikare bibe Iterator ku i32s dide me bang bikin.
///     // Ji ber ku ji me re i32 hewce dike ku têxin MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Pêkanîn pir rasterast e: bi vegêranê vegerin, û her elementek add() bi xwe re bikin.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // ka em berhevoka xwe bi sê hejmarên din dirêj bikin
/// c.extend(vec![1, 2, 3]);
///
/// // me van hêmanan li dawiya xwe zêde kir
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Bi naveroka veberhênerekî berhevokê dirêj dike.
    ///
    /// Ji ber ku ev ji bo vê trait tenê rêbaza pêwîst e, belgeyên [trait-level] bêtir agahdarî hene.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// // Hûn dikarin Tevnek bi hin tîpan dirêj bikin:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Bi yek hêmanê ve berhevokek dirêj dike.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Di berhevokekê de ji bo jimara danî ya hêmanên din kapasîteyê vedihewîne.
    ///
    /// Pêkanîna default tiştek nake.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}