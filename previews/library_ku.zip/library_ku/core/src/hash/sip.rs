//! Pêkanîna SipHash.

#![allow(deprecated)] // celebên vê modulê têne betal kirin

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// Pêkanîna SipHash 1-3.
///
/// Vêga ev fonksiyona heşandina pêşdibistanê ya ku ji hêla pirtûkxaneya standard ve tê bikar anîn e (mînakî, `collections::HashMap` ew bixwe bikar tîne).
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// Pêkanîna SipHash 2-4.
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// Pêkanîna SipHash 2-4.
///
/// See: <https://131002.net/siphash/>
///
/// SipHash fonksiyonek heşînkerî ya gelemperî-armanc e: ew bi lezek baş dimeşe (bi Spooky û City re reqabet) û destûr dide heşandina _keyed_ ya bihêz.
///
/// Ev dihêle hûn maseyên xweya hash ji RNG-ya xurt, mînakî [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html) kilît bikin.
///
/// Her çend algorîtmaya SipHash bi gelemperî xurt tête hesibandin jî, ew ne ji bo armancên kriptografîk e.
/// Bi vî rengî, hemî karanînên şîfre yên vê bicîhkirinê _strongly discouraged_ in.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // me çend bayt pêvajo kiriye
    state: State,  // hash Dewlet
    tail: u64,     // byteyên neçareserkirî le
    ntail: usize,  // çend bayt di dûvikê de derbasdar in
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, v2 û v1, v3 di algorîtmayê de duçok xuya dikin, û pêkanînên simd ên SipHash dê vectors yên v02 û v13 bikar bînin.
    //
    // Bi cîhkirina wan di vê rêzê de di struktura de, berhevkar dikare bi serê xwe tenê çend optimîzasyonên simd hilbijêre.
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// Bi rêza LE, hejmarek ji tîpa ku tê xwestin ji herikînek byte bar dike.
/// `copy_nonoverlapping` bikar tîne da ku bila berhevkar awayê herî bikêrhatî biafirîne da ku wê ji navnîşanek bi îhtîmalek bêpergal barkirin.
///
///
/// Ne ewle ji ber ku: li i..i+size_of(int_ty) nîşankirina neçêkirî
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// u64 bi karanîna heya 7 bayt qurmek baytekê bar dike.
/// Ew qeşeng xuya dike lê bangên `copy_nonoverlapping` ku çêdibe (bi rêya `load_int_le!`) hemî xwedan mezinahiyên sabît in û xwe ji gazîkirina `memcpy` dûr digirin, ku ji bo lezgîniyê baş e.
///
///
/// Ne ewle ji ber ku: di destpêkirinê de endekskirina neçêkirî..start + len
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // di hilberîna u64 de indexa byte ya heyî (ji LSB)
    let mut out = 0;
    if i + 3 < len {
        // EWLEHIY: : `i` ji `len` mezintir nabe, û divê bangker garantî bike
        // ku index dest pê dike.. destpêkirin + len di sînoran de ye.
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // EWLEH: : wek jorîn.
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // EWLEH: : wek jorîn.
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// Bi du tûşên destpêkê yên li 0-yê `SipHasher` nû diafirîne.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// `SipHasher` diafirîne ku ji kilîtên peydabûyî tê kilît kirin.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// Bi du tûşên destpêkê yên li 0-yê `SipHasher13` nû diafirîne.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// `SipHasher13` diafirîne ku ji kilîtên peydabûyî tê kilît kirin.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: tu rêbazên hejmar ên jimareyê (`binivîse_u *`, `write_i*`) nayên diyarkirin
    // ji bo vî rengî.
    // Em dikarin wan zêde bikin, pêkanîna `short_write` li librustc_data_structures/sip128.rs kopî bikin, û rêbazên `write_u *`/`write_i*` li `SipHasher`, `SipHasher13`, û `DefaultHasher` zêde bikin.
    //
    // Ev ê ji hêla wan heşkeran ve, bi bihayê ku hinekî hêdî dibe, leza berhevdana li ser hin pîvanan kêm bike zûtir zûtir dike.
    // Ji bo hûragahiyan li #69152 binêrin.
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // EWLEHIY: : `cmp::min(length, needed)` garantî ye ku ne di ser `length` re be
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // Dûvika tampon niha tê şûştin, pêveka nû pêvajoyê bike.
        let len = length - needed;
        let left = len & 0x7; // len% 8

        let mut i = needed;
        while i < len - left {
            // EWLEH: ji ber ku `len - left` pirça herî mezin a 8 bin e
            // `len`, û ji ber ku `i` li `needed` dest pê dike ku `len` `length - needed` e, `i + 8` tête garantîkirin ku ji `length` kêmtir an jî wekhev be.
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // EWLEH: `i` niha `needed + len.div_euclid(8) * 8` e,
        // ji ber vê yekê `i + left` = `needed + len` = `length`, ku ji hêla wateyê ve wekhevî bi `msg.len()` re ye.
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// `Hasher<S>`-ê bi du bişkokên destpêkê yên 0 ve hatî çêkirin diafirîne.
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}