use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` lê ne sifir û kovariyant.
///
/// Ev bi gelemperî tiştê rast e ku meriv bikar bîne dema ku avahiyên danûstendinê bi karanîna nîşangirên rawe têne bikar anîn, lê di dawiyê de karanîna ji ber taybetmendiyên wêyên zêde xeternaktir e.Heke hûn ne ewle ne ku gerek hûn `NonNull<T>` bikar bînin, tenê `*mut T` bikar bînin!
///
/// Berevajî `*mut T`, pêdivî ye ku nîşander hertim ne-null be, her çend ku pêşnumêr carî ji referansê dernekeve.Ji ber vê yekê ye ku enum dikarin vê nirxa qedexe wekî cûdakar bikar bînin-`Option<NonNull<T>>` xwedan eynî mezinahî `* mut T` ye.
/// Lêbelê heke nîşander neyê paşguhxistin dibe ku hîn jî dangle bibe.
///
/// Berevajî `*mut T`, `NonNull<T>` hate hilbijartin ku ji `T` re hevkar be.Vê yekê gengaz dike ku meriv `NonNull<T>` bikar bîne dema ku cûrbecûr cûrbecûr ava dike, lê xetera neheqbûnê destnîşan dike heke ku ew di celebek ku ne hewce be kovariant be de tê bikar anîn.
/// (Hilbijartina berevajî ji bo `*mut T` hate çêkirin tevî ku ji hêla teknîkî ve neheqbûn tenê bi banga fonksiyonên ewle ve çêdibe.)
///
/// Kovariance ji bo pir abstrasyonên ewle, wekî `Box`, `Rc`, `Arc`, `Vec`, û `LinkedList` rast e.Ev rewş e ji ber ku ew API-ya gelemperî peyda dikin ku rêzikên normal ên hevpar ên XOR-ê yên hevpar ên Rust dişopîne.
///
/// Heke celebê we nekare bi ewlehî hevkar be, divê hûn piştrast bikin ku ew hin zeviyên din jî hene da ku neçareseriyê peyda bike.Pir caran ev zevî dê mîna `PhantomData<Cell<T>>` an `PhantomData<&'a mut T>` celebek [`PhantomData`] be.
///
/// Bala xwe bidinê ku `NonNull<T>` ji bo `&T` mînakek `From` heye.Lêbelê, ev rastiyê naguherîne ku mutasyona bi navgîniya (pêşnavka ku ji a) ve hatî parve kirin tevgerek ne diyar e heya ku mutasyon di hundurê [`UnsafeCell<T>`] de pêk neyê.Heman tişt ji bo afirandina referansa guherbar a ji referansa hevpar jî derbas dibe.
///
/// Dema ku bêyî `UnsafeCell<T>` vê nimûneya `From` bikar tînin, berpirsiyariya we ye ku hûn piştrast bikin ku ji `as_mut` re carî nayê gotin, û `as_ptr` ji bo mutasyonê qet nayê bikar anîn.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` nîşanker `Send` ne ji ber ku daneya ku ew referans dikin dibe ku aliasî be.
// NB, ev daxwaz ne hewce ye, lê divê peyamên çewtiyê çêtir peyda bikin.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` nîşanker `Sync` ne ji ber ku daneya ku ew referans dikin dibe ku aliasî be.
// NB, ev daxwaz ne hewce ye, lê divê peyamên çewtiyê çêtir peyda bikin.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// `NonNull` nû diafirîne ku dangling e, lê baş-rêzkirî ye.
    ///
    /// Ev ji bo destpêkirina celebên ku bi lalkî dabeş dikin, wek `Vec::new` dike, bikêr e.
    ///
    /// Bala xwe bidinê ku dibe ku nirxa pointer potansiyelî ji `T` re pêşnumayek derbasdar temsîl dike, ku tê vê wateyê ku divê ev wekî nirxa sentîl a "not yet initialized" neyê bikar anîn.
    /// Cûreyên ku bi lalbûnek veqetandî ne, divê destpêkirina bi hin rêyên din bişopînin.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // EWLEH: mem::align_of() karanîna ne sifir vedigerîne ku paşê tê qewirandin
        // ji * mut T.
        // Ji ber vê yekê, `ptr` betal nine û mercên bangkirina new_unchecked() têne rêz kirin.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Çavkaniyên hevpar ên li ser nirxê vedigerîne.Berevajî [`as_ref`], ev hewce nake ku nirx bi dest pê bike.
    ///
    /// Ji bo hevparê mutable [`as_uninit_mut`] binihêrin.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Dema ku bang li vê rêbazê dikin, divê hûn piştrast bikin ku hemî jêrîn rast e:
    ///
    /// * Pêdivî ye ku nîşander bi rêkûpêk were rêz kirin.
    ///
    /// * Divê ew di wateya ku di [the module documentation] de hatî diyarkirin "dereferencable" be.
    ///
    /// * Pêdivî ye ku hûn qaîdeyên aliasing ên Rust bicîh bînin, ji ber ku jiyana vegerandî `'a` bi keyfî tête bijartin û ne hewce ye ku jiyana rastîn a daneyê nîşan bide.
    ///
    ///   Bi taybetî, ji bo dirêjahiya vê heyatê, divê bîranîna ku nîşangir nîşan dide divê neguhere (ji bilî hundurê `UnsafeCell`).
    ///
    /// Ev encam digire heke encama vê rêbazê neyê bikar anîn!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // EWLEHIY: : divê bangker garantî bike ku `self` hemî hevdîtinan pêk tîne
        // hewcedariyên ji bo referansê.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Li nirxê referansên yekta vedigerîne.Berevajî [`as_mut`], ev hewce nake ku nirx bi dest pê bike.
    ///
    /// Ji bo hevparê hevpar [`as_uninit_ref`] binihêrin.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Dema ku bang li vê rêbazê dikin, divê hûn piştrast bikin ku hemî jêrîn rast e:
    ///
    /// * Pêdivî ye ku nîşander bi rêkûpêk were rêz kirin.
    ///
    /// * Divê ew di wateya ku di [the module documentation] de hatî diyarkirin "dereferencable" be.
    ///
    /// * Pêdivî ye ku hûn qaîdeyên aliasing ên Rust bicîh bînin, ji ber ku jiyana vegerandî `'a` bi keyfî tête bijartin û ne hewce ye ku jiyana rastîn a daneyê nîşan bide.
    ///
    ///   Bi taybetî, ji bo dirêjahiya vê heyatê, divê bîranîna ku nîşander nîşan dide divê bi rêya dîwanek din neyê gihandin (xwendin an nivîsandin).
    ///
    /// Ev encam digire heke encama vê rêbazê neyê bikar anîn!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // EWLEHIY: : divê bangker garantî bike ku `self` hemî hevdîtinan pêk tîne
        // hewcedariyên ji bo referansê.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// `NonNull` nû diafirîne.
    ///
    /// # Safety
    ///
    /// `ptr` divê ne-pûç be.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // EWLEHIY: : divê bangker garantî bike ku `ptr` ne betal e.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Ger `ptr` ne-pûç be `NonNull` nû diafirîne.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // EWLEHIYE: Nîşanek jixwe ve tê kontrol kirin û ne betal e
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Wekî [`std::ptr::from_raw_parts`] heman fonksiyonê pêk tîne, ji xeynî ku pêşnumayek `NonNull` vedigere, berevajî pêşnumaya `*const` ya xav.
    ///
    ///
    /// Ji bo bêtir agahdariyê belgekirina [`std::ptr::from_raw_parts`] bibînin.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // EWLEHIY: : Encama `ptr::from::raw_parts_mut` ne-pûç e ji ber ku `data_address` e.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Nîşanek (dibe ku fereh) veqetînin nav pêkhateyên navnîşan û metadata ye.
    ///
    /// Nîşanek dikare paşê bi [`NonNull::from_raw_parts`] ji nû ve were çêkirin.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Nîşaneya bingehîn a `*mut` peyda dike.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Li nirxê referansek hevpar vedigere.Ger dibe ku nirx bê unitialized be, divê li şûna [`as_uninit_ref`] were bikar anîn.
    ///
    /// Ji bo hevparê mutable [`as_mut`] binihêrin.
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Dema ku bang li vê rêbazê dikin, divê hûn piştrast bikin ku hemî jêrîn rast e:
    ///
    /// * Pêdivî ye ku nîşander bi rêkûpêk were rêz kirin.
    ///
    /// * Divê ew di wateya ku di [the module documentation] de hatî diyarkirin "dereferencable" be.
    ///
    /// * Pêdivî ye ku nîşander mînakek destpêkirî ya `T` nîşan bike.
    ///
    /// * Pêdivî ye ku hûn qaîdeyên aliasing ên Rust bicîh bînin, ji ber ku jiyana vegerandî `'a` bi keyfî tête bijartin û ne hewce ye ku jiyana rastîn a daneyê nîşan bide.
    ///
    ///   Bi taybetî, ji bo dirêjahiya vê heyatê, divê bîranîna ku nîşangir nîşan dide divê neguhere (ji bilî hundurê `UnsafeCell`).
    ///
    /// Ev encam digire heke encama vê rêbazê neyê bikar anîn!
    /// (Beşa di derbarê destpêkirinê de hêj bi tevahî biryar nehatiye girtin, lê heya ku ew be, nêzîkatiya tenê ewledar ew e ku ew bi rastî werin destpêkirin.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // EWLEHIY: : divê bangker garantî bike ku `self` hemî hevdîtinan pêk tîne
        // hewcedariyên ji bo referansê.
        unsafe { &*self.as_ptr() }
    }

    /// Li nirxê referansek bêhempa vedigerîne.Ger dibe ku nirx bê unitialized be, divê li şûna [`as_uninit_mut`] were bikar anîn.
    ///
    /// Ji bo hevparê hevpar [`as_ref`] binihêrin.
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Dema ku bang li vê rêbazê dikin, divê hûn piştrast bikin ku hemî jêrîn rast e:
    ///
    /// * Pêdivî ye ku nîşander bi rêkûpêk were rêz kirin.
    ///
    /// * Divê ew di wateya ku di [the module documentation] de hatî diyarkirin "dereferencable" be.
    ///
    /// * Pêdivî ye ku nîşander mînakek destpêkirî ya `T` nîşan bike.
    ///
    /// * Pêdivî ye ku hûn qaîdeyên aliasing ên Rust bicîh bînin, ji ber ku jiyana vegerandî `'a` bi keyfî tête bijartin û ne hewce ye ku jiyana rastîn a daneyê nîşan bide.
    ///
    ///   Bi taybetî, ji bo dirêjahiya vê heyatê, divê bîranîna ku nîşander nîşan dide divê bi rêya dîwanek din neyê gihandin (xwendin an nivîsandin).
    ///
    /// Ev encam digire heke encama vê rêbazê neyê bikar anîn!
    /// (Beşa di derbarê destpêkirinê de hêj bi tevahî biryar nehatiye girtin, lê heya ku ew be, nêzîkatiya tenê ewledar ew e ku ew bi rastî werin destpêkirin.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // EWLEHIY: : divê bangker garantî bike ku `self` hemî hevdîtinan pêk tîne
        // hewcedariyên referansa guhêrbar.
        unsafe { &mut *self.as_ptr() }
    }

    /// Derdixe ser pointerek ji celebek din.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // EWLEH: : `self` pêşnumayek `NonNull` e ku pêdivî ye ku ne-pûç e
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Ji nîşangirek tenik û dirêjahî perçeyek xav a ne null diafirîne.
    ///
    /// Argumana `len` jimara **hêmanan** e, ne jimara bayîtan e.
    ///
    /// Ev fonksiyon ewle ye, lê paşvekêşandina nirxa vegerê ne ewle ye.
    /// Ji bo hewceyên ewlehiya perçeyê belgekirina [`slice::from_raw_parts`] bibînin.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // dema ku hûn bi pointerê hêmana yekem re dest pê bikin pêşekek slice biafirînin
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Bala xwe bidinê ku vê mînakê karanîna vê rêbazê bi rengek sûnî nîşan dide, lê `bila pelçiqîne= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // EWLEH: : `data` pêşnumayek `NonNull` e ku pêdivî ye ku ne-pûç e
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Dirêjahiya perçek raweya ne-null vedigerîne.
    ///
    /// Nirxa vegeriyanî hejmar **hêman** e, ne jimara byte ye.
    ///
    /// Ev fonksiyon ewledar e, her çend gava perçeya xav a ne-null nekaribe were veqetandin li perçeyek ji ber ku nîşanker navnîşanek derbasdar nîne.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Pointerek ne-null vedigerîne tampona perçeyê.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // EWLEH: Em dizanin `self` ne-pûç e.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Pointerek raweyî vedigerîne tampona perçeyê.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Vebijarkek hevbeş vedigerîne perçeyek nirxên dibe ku nezanin.Berevajî [`as_ref`], ev hewce nake ku nirx bi dest pê bike.
    ///
    /// Ji bo hevparê mutable [`as_uninit_slice_mut`] binihêrin.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Dema ku bang li vê rêbazê dikin, divê hûn piştrast bikin ku hemî jêrîn rast e:
    ///
    /// * Pêdivî ye ku nîşanker ji bo `ptr.len() * mem::size_of::<T>()` gelek byte [valid] be, û divê ew bi rêkûpêk were rêz kirin.Ev bi taybetî tê vê wateyê:
    ///
    ///     * Pêdivî ye ku tevahiya bîranîna vê perçeyê di nav yek tiştê veqetandî de hebe!
    ///       Slices carî nikare li seranserê gelek tiştên veqetandî dorpêç bike.
    ///
    ///     * Pêdivî ye ku nîşander ji bo perçeyên dirêjahiya sifir jî werin rêz kirin.
    ///     Sedemek vê yekê ev e ku optimîzasyonên nexşeya enumê dibe ku xwe bispêre referansan (di nav wan de perçên her dirêjahiyê jî jî hene) hevgirtî û ne-null da ku wan ji daneyên din cuda bike.
    ///
    ///     Hûn dikarin pêşnumayek ku wekî `data` ji bo pelikên sifir-dirêje [`NonNull::dangling()`] bikar tîne bikar bînin.
    ///
    /// * Pêdivî ye ku mezinahiya tevahî `ptr.len() * mem::size_of::<T>()` ya perçeyê ji `isize::MAX` ne mezintir be.
    ///   Belgeya ewlehiyê ya [`pointer::offset`] bibînin.
    ///
    /// * Pêdivî ye ku hûn qaîdeyên aliasing ên Rust bicîh bînin, ji ber ku jiyana vegerandî `'a` bi keyfî tête bijartin û ne hewce ye ku jiyana rastîn a daneyê nîşan bide.
    ///   Bi taybetî, ji bo dirêjahiya vê heyatê, divê bîranîna ku nîşangir nîşan dide divê neguhere (ji bilî hundurê `UnsafeCell`).
    ///
    /// Ev encam digire heke encama vê rêbazê neyê bikar anîn!
    ///
    /// [`slice::from_raw_parts`] jî bibînin.
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // EWLEHIY: : bangker divê peymana ewlehiyê ya `as_uninit_slice` biparêze.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Vebijarkek bêhempa vedigerîne perçeyek nirxên ku dibe ku nezanin.Berevajî [`as_mut`], ev hewce nake ku nirx bi dest pê bike.
    ///
    /// Ji bo hevparê hevpar [`as_uninit_slice`] binihêrin.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Dema ku bang li vê rêbazê dikin, divê hûn piştrast bikin ku hemî jêrîn rast e:
    ///
    /// * Pêdivî ye ku ji bo xwendin û nivîsandina ji bo `ptr.len() * mem::size_of::<T>()` gelek bayt [valid] be, û divê ew bi rêkûpêk were rêz kirin.Ev bi taybetî tê vê wateyê:
    ///
    ///     * Pêdivî ye ku tevahiya bîranîna vê perçeyê di nav yek tiştê veqetandî de hebe!
    ///       Slices carî nikare li seranserê gelek tiştên veqetandî dorpêç bike.
    ///
    ///     * Pêdivî ye ku nîşander ji bo perçeyên dirêjahiya sifir jî werin rêz kirin.
    ///     Sedemek vê yekê ev e ku optimîzasyonên nexşeya enumê dibe ku xwe bispêre referansan (di nav wan de perçên her dirêjahiyê jî jî hene) hevgirtî û ne-null da ku wan ji daneyên din cuda bike.
    ///
    ///     Hûn dikarin pêşnumayek ku wekî `data` ji bo pelikên sifir-dirêje [`NonNull::dangling()`] bikar tîne bikar bînin.
    ///
    /// * Pêdivî ye ku mezinahiya tevahî `ptr.len() * mem::size_of::<T>()` ya perçeyê ji `isize::MAX` ne mezintir be.
    ///   Belgeya ewlehiyê ya [`pointer::offset`] bibînin.
    ///
    /// * Pêdivî ye ku hûn qaîdeyên aliasing ên Rust bicîh bînin, ji ber ku jiyana vegerandî `'a` bi keyfî tête bijartin û ne hewce ye ku jiyana rastîn a daneyê nîşan bide.
    ///   Bi taybetî, ji bo dirêjahiya vê heyatê, divê bîranîna ku nîşander nîşan dide divê bi rêya dîwanek din neyê gihandin (xwendin an nivîsandin).
    ///
    /// Ev encam digire heke encama vê rêbazê neyê bikar anîn!
    ///
    /// [`slice::from_raw_parts_mut`] jî bibînin.
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Ev ewle ye ji ber ku `memory` ji bo xwendin û nivîsandina ji bo `memory.len()` gelek byte derbasdar e.
    /// // Zanibe ku gazîkirina `memory.as_mut()` li vir nayê destûr dan ji ber ku dibe ku naverok bê unitialized be.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // EWLEHIY: : bangker divê peymana ewlehiyê ya `as_uninit_slice_mut` biparêze.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Bêyî ku kontrolkirina sînoran bike, pêşekek raweyek vedigerîne ser hêmanek an jêrîn.
    ///
    /// Bangkirina vê rêbazê bi navnîşek derveyî sînor an dema ku `self` dereferencable nine *[tevgera nediyarkirî]* be jî heke nîşanderê encamek neyê bikar anîn.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // EWLEHIYE: bangker piştrast dike ku `self` dereferencable û `index` li sînor e.
        // Wekî encamek, nîşanderê encam nabe NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // EWLEHIYE: Nîşanek yekta nikare pûç be, ji ber vê yekê şert û mercên ji bo
        // new_unchecked() têne rêz kirin.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // EWLEHIY: : Referansek guhêrbar nikare pûç be.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // EWLEH: : A referansek pûç nabe, ji ber vê yekê şert û mercên ji bo
        // new_unchecked() têne rêz kirin.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}