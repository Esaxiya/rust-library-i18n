//! Bi destan bîranînê bi navgîniya nîşangirên rawe birêve bibin.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Di vê modulê de gelek fonksiyon nîşankerên xav wekî arguman digirin û ji wan re dixwînin an ji wan re dinivîsin.Ji bo ku ew ewledar be, divê van nîşanker *derbasdar* bin.
//! Ka nîşanderek derbasdar e, girêdayî operasyona ku jê re tê bikar anîn (xwendin an nivîsandin), û berfirehiya bîra ku tête barkirin (ango, çend byte read/written in).
//! Piraniya fonksiyonan `*mut T` û `* const T` bikar tînin da ku tenê nirxek tenê bigihînin, di vê rewşê de belgekirin mezinahiyê ji dest xwe derdixe û bi awayek neyînî wê bayiyên `size_of::<T>()` digire.
//!
//! Rêgezên rastîn ên rastdariyê hîn ne diyar in.Garantiyên ku di vê nuqteyê de têne peyda kirin pir kêm in:
//!
//! * Nîşanek [null]*ne* derbasdar e, ne jî ji bo gihiştinên [size zero][zst].
//! * Ji bo ku pêvekek rast be, pêdivî ye, lê ne ku her dem têr dike, ku pêvek *dereferî* be: dora bîranîna mezinahiya dayînê ya ku ji pointerê dest pê dike, divê hemî di nav tixûbên yek tiştê veqetandî de bin.
//!
//! Zanibe ku di Rust de, her guhêrbar (stack-allocated) wekî tiştek veqetandî cuda tête hesibandin.
//! * Tewra ji bo operasyonên [size zero][zst] jî, pêdivî ye ku nîşanker bîranîna veqetandî nîşan neke, ango, veqetandin ji bo karûbarên nîv-mezinahî jî nîşanekan nederbasdar dike.
//! Lêbelê, avêtina jimareyek ne-sifir *biwêj* li ser pointerê ji bo gihîştinên bi sifir-sized derbasdar e, heke hin bîranîn jî li wê navnîşanê hebe û were veqetandin.
//! Ev bi nivîsandina dabeşkerê xwe re têkildar e: veqetandina tiştên bi sifir sifir ne pir zor e.
//! Awayê kanonîkî ji bo bidestxistina pêşnumayek ku ji bo gihîştinên bi sifir-sized derbasdar e [`NonNull::dangling`] e.
//! * Hemî gihîştinên ku di vê modulê de ji hêla fonksiyonan ve hatine kirin *di wateya [atomic operations] de ne-atomî* ne ku ji bo hevdemkirina têlan têne bikar anîn.
//! Ev tê wê wateyê ku ew tevgerek ne diyar e ku ji têlên cihêreng du destketiyên li heman cihî pêk werin heya ku herdu gihîştin tenê ji bîra neyên xwendin.
//! Bala xwe bidinê ku ev bi zelalî [`read_volatile`] û [`write_volatile`] digire nav xwe: Destketiyên gihîştî ji bo hevdemkirina nav-têl nayê bikar anîn.
//! * Encama avêtina referansa bo pointerek heya ku hêmana bingehîn zindî be û ji bo ku bigihîje heman bîranînê ti referans (tenê nîşankên xav) nayê bikar anîn derbasdar e.
//!
//! Van axiomên hanê, digel ku bi baldarî bikar anîna [`offset`]-ê ji bo hejmartina pointer, bes in ku gelek tiştên kêrhatî di koda ne ewle de bi rêkûpêk werin bicîh kirin.
//! Garantiyên bihêztir dê di dawiyê de werin peyda kirin, ji ber ku qaîdeyên [aliasing] têne diyar kirin.
//! Ji bo bêtir agahdarî, li [book] û hem jî li beşa di referansa ku ji [undefined behavior][ub] re hatî veqetandin binihêrin.
//!
//! ## Alignment
//!
//! Nîşaneyên raweyên derbasdar ên ku li jor hatine diyarkirin ne hewce ne ku bi rêkûpêk werin rêz kirin (li cihê ku alozkirina "proper" ji hêla celebê pointee ve tête diyar kirin, ango, divê `*const T` bi `mem::align_of::<T>()` re were yek kirin).
//! Lêbelê, pir fonksiyon hewce dike ku nîqaşên wan bi rêkûpêk werin rêz kirin, û dê vê belgeyê bi zelalî vê belgeyê diyar bikin.
//! Ji vê yekê awarteyên berbiçav [`read_unaligned`] û [`write_unaligned`] ne.
//!
//! Gava ku fonksiyonek rêzkirinek guncan hewce dike, wusa dike heke gihiştina xwediyê size 0 be, ango, heke bîranîn di rastiyê de neyê destgirtin.Di rewşên weha de [`NonNull::dangling`] bikar bînin bifikirin.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Hilweşîner (heke hebe) ya nirxa berbiçav pêk tîne.
///
/// Ev ji hêla semantîkî ve wekhev e ku [`ptr::read`] bang bike û encamê paşde bavêje, lê xwedan avantajên jêrîn e:
///
/// * *Pêdivî ye* ku `drop_in_place` bikar bînin ku cûreyên bêserûber mîna tiştên trait bavêjin, ji ber ku ew li ser stackê nayên xwendin û bi asayî davêjin.
///
/// * Gava ku bîra bi desta hatî veqetandin davêjin (mînakî, di pêkanînên `Box`/`Rc`/`Vec`) de, ji optimîzerê re hevaltir e ku meriv vê yekê li ser [`ptr::read`] bike, ji ber ku berhevker ne hewce ye ku îsbat bike ku ew deng e ku kopî jê bibire.
///
///
/// * Dema `T` ne `repr(packed)` be ew dikare daneyên [pinned] were avêtin (daneyên pinned berî ku dakeve divê neyê bar kirin).
///
/// Nirxên nevekirî di cîh de nayên avêtin, divê ew pêşî li [`ptr::read_unaligned`] bi cîhek lihevkirî werin kopî kirin.Ji bo darbestên pakkirî, ev tevger ji hêla berhevkar ve bixweber tê kirin.
/// Ev tê vê wateyê ku zeviyên lêkerên pakkirî li cîh nayên hiştin.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Heke ji mercên jêrîn binpê kirin tevger nayê diyar kirin:
///
/// * `to_drop` divê hem ji bo xwendin û nivîsandinê [valid] be.
///
/// * `to_drop` divê bi rêkûpêk were rêz kirin.
///
/// * Nirxa xalên `to_drop`-ê divê ji bo dakêşanê derbasdar be, ku dibe ku wateya ku ew pêdivî ye ku binavkirinên din jî biparêze, ev bi celeb-ê ve girêdayî ye.
///
/// Wekî din, heke `T` ne [`Copy`] be, piştî gazî kirina `drop_in_place` bi karanîna nirxa nîşangir re dibe sedema reftarek nediyarkirî.Zanibe ku `*to_drop = foo` wekî karanînê dihesibîne ji ber ku ew ê bibe sedem ku nirx dîsa were daketin.
/// [`write()`] bêyî ku bibe sedema daketinê dikare ji nû ve binivîse.
///
/// Zanibe ku heke `T` xwediyê mezinahiya `0` be jî, divê nîşander ne-NULL be û bi rêk û pêk were.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Tişta dawî ji vector bi destan rakin:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Di `v` de hêmana pêşîn bigirin heya hêmana paşîn.
///     let ptr = &mut v[1] as *mut _;
///     // `v` kurt bikin da ku nehêle tişta paşîn were avêtin.
///     // Em pêşî wiya dikin, da ku pêşî li pirsgirêkan bigirin heke `drop_in_place` li jêr panics be.
///     v.set_len(1);
///     // Bêyî banga `drop_in_place`, tişta paşîn dê carî neyê avêtin, û bîranîna ku ew îdare dike dê derkeve.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Piştrast bikin ku hêmana paşîn hatiye avêtin.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Bala xwe bidinê ku berhevkar dema ku darikên pakkirî davêjin vê kopî bixweber pêk tîne, ango, hûn ne hewce ne ku bi gelemperî li ser mijarên weha bi fikar bin heya ku hûn bi destan bangî `drop_in_place` nekin.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Koda li vir ne girîng e, ev ji hêla berhevkar ve bi glika dilopa rastîn tê guhertin.
    //

    // EWLEH: : li şiroveya li jor binêrin
    unsafe { drop_in_place(to_drop) }
}

/// Nîşanek rakêş a null diafirîne.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Nîşaneyek raweya mutabîl a null diafirîne.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Pêdivî ye ku ji bo `T: Clone` neçar bimîne pêdivî ye.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Pêdivî ye ku ji bo `T: Copy` neçar bimîne pêdivî ye.
impl<T> Copy for FatPtr<T> {}

/// Ji pointer û dirêjahiyek qurmek rawe çêdike.
///
/// Argumana `len` jimara **hêmanan** e, ne jimara bayîtan e.
///
/// Ev fonksiyon ewle ye, lê bi rastî karanîna nirxa vegerê ne ewle ye.
/// Ji bo hewceyên ewlehiya perçeyê belgekirina [`slice::from_raw_parts`] bibînin.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // dema ku hûn bi pointerê hêmana yekem re dest pê bikin pêşekek slice biafirînin
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // EWLEH: : Ji gihîştina nirxa ji yekîtiya `Repr` ji ber ku * const [T] ewle ye
        //
        // û FatPtr xwedan heman rêzikên bîranînê ne.Tenê std dikare vê garantiyê bike.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Wekî [`slice_from_raw_parts`] heman fonksiyonelê pêk tîne, ji xeynî ku perçek mutable ya xav vedigere, berevajî perçeyek neguhêzbar a raw.
///
///
/// Ji bo bêtir agahdariyê belgekirina [`slice_from_raw_parts`] bibînin.
///
/// Ev fonksiyon ewle ye, lê bi rastî karanîna nirxa vegerê ne ewle ye.
/// Ji bo hewceyên ewlehiya perçeyê belgekirina [`slice::from_raw_parts_mut`] bibînin.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // nirxek li ser indexek di perçeyê de destnîşan bikin
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // EWLEH: : Ji * mut [T] ve gihîştina nirxa ji yekîtiya `Repr` ewle ye
        // û FatPtr xwedan heman rêzikên bîranînê ne
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Nirxên li du deveran guherbar ên ji eynî cûreyê, bêyî deinitialîzasyonê jî diguheze.
///
/// Lê ji bo du veqetandinên jêrîn, ev fonksiyon ji hêla semantîkî ve bi [`mem::swap`] re hevber e:
///
///
/// * Ew li şûna referansan li ser nîşangirên rawe dixebite.
/// Dema ku referans hene, divê [`mem::swap`] were tercîh kirin.
///
/// * Du nirxên nîşankirî dikarin li hev bikin.
/// Ger nirxên li hevûdu bikin, wê hingê dê herêma jihevdexistinî ya bîranînê ji `x` were bikar anîn.
/// Ev di mînaka duyemîn a li jêr de tê diyar kirin.
///
/// # Safety
///
/// Heke ji mercên jêrîn binpê kirin tevger nayê diyar kirin:
///
/// * Hem `x` hem jî `y` hem ji bo xwendin û nivîsînê divê [valid] bin.
///
/// * Divê `x` û `y` bi rêkûpêk werin rêz kirin.
///
/// Zanibe ku heke `T` xwedî mezinahiya `0` be jî, divê nîşanker ne-NULL bin û bi rêkûpêk werin rêz kirin.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Lihevguhertina du herêmên ku ne li ser hev in:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // ev `array[0..2]` e
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // ev `array[2..4]` e
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Lihevguhertina du herêmên li ser hev:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // ev `array[0..3]` e
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // ev `array[1..4]` e
///
/// unsafe {
///     ptr::swap(x, y);
///     // Indeksa `1..3` ya qurmê di navbera `x` û `y` de li hevûdu dikin.
///     // Encamên maqûl dê ji wan re bibin `[2, 3]`, da ku nîşanên `0..3` `[1, 2, 3]` bin (lihevhatina `y` berî `swap`);an jî ji bo wan bibin `[0, 1]` da ku nîşanên `1..4` `[0, 1, 2]` be (`x` li pêş `swap` lihevhatî be).
/////
///     // Ev pêkanîn ji bo hilbijartina paşîn tête diyar kirin.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Hinek cîhê xirbe bidin xwe ku em pê re bixebitin.
    // Em ne hewce ne ku li ser dilopan bifikirin: `MaybeUninit` dema ku dakeve tiştek nake.
    let mut tmp = MaybeUninit::<T>::uninit();

    // SFQETIYA swapê pêk bînin: Divê bangker garantî bike ku `x` û `y` ji bo nivîsandinê derbasdar in û bi rêkûpêk hatine rêz kirin.
    // `tmp` nekare `x` an `y` li ser hev bin ji ber ku `tmp` tenê li ser stackê wekî tiştek veqetandî ya veqetandî hate veqetandin.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` û `y` dibe ku li hev bikin
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// `count * size_of::<T>()` byte di navbera her du herêmên bîranînê de ku li `x` û `y` dest pê dike diguhezîne.
/// Pêdivî ye ku her du herêm bi hev re nebin.
///
/// # Safety
///
/// Heke ji mercên jêrîn binpê kirin tevger nayê diyar kirin:
///
/// * Hem `x` hem jî `y` ji bo xwendin û nivîsandina `jimartinê` divê [valid] bin *
///   mezinahiya: :<T>() `bayt.
///
/// * Divê `x` û `y` bi rêkûpêk werin rêz kirin.
///
/// * Navçeya bîranînê ya bi `x` bi mezinahiya `jimartinê dest pê dike *
///   mezinahiya: :<T>() `byte divê *bi herêma bîranînê ya ku di `y` de bi heman mezinahî dest pê dike nebin*.
///
/// Zanibe ku heke mezinahiya bi bandor jibergirtî be jî (`count * size_of: :<T>()`) `0` e, divê nîşanker ne-NULL bin û bi rêkûpêk werin rêz kirin.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Bikaranîna bingehîn:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // EWLEH: Y::Divê bangker garantî bike ku `x` û `y` ne
    // ji bo nivîsandinê derbasdar û bi rêkûpêk rêzkirî.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Ji bo celebên ji optimîzasyona blokê piçûktir, tenê rasterast biguherin da ku hûn ji kodagenê reşbîn nemînin.
    //
    if mem::size_of::<T>() < 32 {
        // EWLEHIY: : divê bangker garantî bike ku `x` û `y` derbasdar in
        // ji bo nivîsandinê, bi rêkûpêk rêzkirî, û ne-li hevûdu.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // EWLEHIY: : bangker divê peymana ewlehiyê ya `swap_nonoverlapping` biparêze.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Nêzîkatiya li vir ew e ku simd were bikar anîn da ku x&y bi bandor were veguheztin.
    // Testkirin dide xuyakirin ku pevguhertina an 32 bayt an 64 bayt yekcar ji bo pêvajoyên Intel Haswell E herî bikêrhatî ye.
    // LLVM heke em bi saz #[repr(simd)] bidin hêj çêtir e ku baştir bike, her çend em di rastiyê de rasterast vê sazûmanê bikar neynin.
    //
    //
    // FIXME repr(simd) li ser emscriptê şkandin û reşandin
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // X û y-ê dorpêç bikin, di yek carekê de wan `Block` kopî bikin Divê optimîzator ji bo pir celebên hanê xelek bi tevahî vebike
    // Em nekarin loopek bikar bînin ji ber ku `range` impl bi Xursî vedigere gazî dike
    //
    let mut i = 0;
    while i + block_size <= len {
        // Hinek bîra uninitialized wekî qada jêbirinê biafirînin Daxuyaniya `t` li vir rê li ber rêzkirina stack digire dema ku ev xelek bêkêr be
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // EWLEHIY: : Wekî `i < len`, û wekî bangker divê garantî bike ku `x` û `y` derbasdar in
        // ji bo byteyên `len`, divê `x + i` û `y + i` navnîşanên derbasdar bin, ku peymana ewlehiyê ji bo `add` pêk tîne.
        //
        // Di heman demê de, bangker divê garantî bike ku `x` û `y` ji bo nivîsandinê, bi rêkûpêk rêzkirî û ne-hevgirtî, ku peymana ewlehiyê ji bo `copy_nonoverlapping` pêk tîne, derbasdar in.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Blokek byteyên x&y veguherînin, t-yê wekî tamponek demkî bikar bînin Divê ev di nav kiryarên SIMD-yên bi bandor de li cîhê ku çêdibe were optimîzekirin
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Bîteyên mayî biguhezînin
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // BELA: şîroveya ewlehiya berê bibînin.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// `src` dixe nav `dst` nîşankirî, nirxa `dst` ya berê vedigire.
///
/// Ne nirx tê avêtin.
///
/// Ev fonksiyon ji hêla semantîkî ve bi [`mem::replace`] re hevseng e ji bilî ku ew li şûna referansan li ser nîşangirên xav dixebite.
/// Dema ku referans hene, divê [`mem::replace`] were tercîh kirin.
///
/// # Safety
///
/// Heke ji mercên jêrîn binpê kirin tevger nayê diyar kirin:
///
/// * `dst` divê hem ji bo xwendin û nivîsandinê [valid] be.
///
/// * `dst` divê bi rêkûpêk were rêz kirin.
///
/// * `dst` divê li ser nirxek bi rêkûpêk a destpêkirî ya type `T` nîşan bike.
///
/// Zanibe ku heke `T` xwediyê mezinahiya `0` be jî, divê nîşander ne-NULL be û bi rêk û pêk were.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` bêyî ku bloka ne ewledar hewce bike dê heman bandor hebe.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // EWLEHIY: : divê bangker garantî bike ku `dst` derbasdar e
    // bavêjin ser referansa guhêrbar (ji bo nivîsandinê derbasdar e, rêzkirî, destpêkirî), û nikare `src` li hev bigire ji ber ku `dst` divê li ser veqetandek veqetandî diyar bike.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // nikare li hev bike
    }
    src
}

/// Bêyî ku wê bar bike nirxa ji `src` dixwîne.Ev di `src` de bîranînê bê guhertin dihêle.
///
/// # Safety
///
/// Heke ji mercên jêrîn binpê kirin tevger nayê diyar kirin:
///
/// * `src` ji bo xwendinê divê [valid] be.
///
/// * `src` divê bi rêkûpêk were rêz kirin.Ger wilo nebe [`read_unaligned`] bikar bînin.
///
/// * `src` divê li ser nirxek bi rêkûpêk a destpêkirî ya type `T` nîşan bike.
///
/// Zanibe ku heke `T` xwediyê mezinahiya `0` be jî, divê nîşander ne-NULL be û bi rêk û pêk were.
///
/// # Examples
///
/// Bikaranîna bingehîn:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// [`mem::swap`] bi desta bicîh bikin:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Li `a`-a `tmp`-ê nermalavek bitwise ya nirxê biafirînin.
///         let tmp = ptr::read(a);
///
///         // Di vê nuqteyê de derketin (an bi vegera eşkere an jî banga fonksiyonek ku panics) dê bibe sedem ku nirxê `tmp` were daxistin dema ku heman nirx hêj ji hêla `a` ve tê referans kirin.
///         // Ger `T` ne `Copy` be ev dikare tevgerek nediyarkirî bide alî.
/////
/////
///
///         // Li `b`-a `a`-ê nermalavek bitwise ya nirxê biafirînin.
///         // Ev ewle ye ji ber ku referansên guhêrbar nikarin bi navê din bin.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Wekî ku li jor, derketina ji vir dikare tevgerek nediyarkirî bide destpêkirin ji ber ku heman nirx ji hêla `a` û `b` ve tête referans kirin.
/////
///
///         // `tmp` têxin nav `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` hatiye veguhastin (`write` xwediyê nîqaşa xweya duyemîn e), ji ber vê yekê tiştek li vir bi zelalî nayê avêtin.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Xwedîtiya Nirxê Vegerandî
///
/// `read` bêyî ku `T` [`Copy`] e, nusxeyek bitewîn a `T` diafirîne.
/// Ger `T` ne [`Copy`] be, karanîna hem nirxa vegerandin û hem jî nirxa li `*src` dikare ewlehiya bîra binpê bike.
/// Zanibe ku danîna `*src` wekî karanînê tête hesibandin ji ber ku ew ê hewl bide ku nirxê `* src` bavêje.
///
/// [`write()`] bêyî ku bibe sedema daketinê dikare ji nû ve binivîse.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` naha `s` nîşanî heman bîrdariya bingehîn dide.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Dabeşandina `s2` dibe sedema ku nirxa wêya xwerû were avêtin.
///     // Ji derveyî vê xalê, pêdivî ye ku `s` nema were bikar anîn, ji ber ku bîra bingehîn hate azad kirin.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Dabeşandina `s` dê bibe sedem ku nirxa kevn dîsa were avêtin, û di encamê de tevgerek ne diyar.
/////
///     // s= String::from("bar");//ÇETOR
///
///     // `ptr::write` dikare bê bikar anîn ku nirxek ji nû ve were nivîsandin.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // EWLEHIY: : divê bangker garantî bike ku `src` ji bo xwendinan derbasdar e.
    // `src` nikare `tmp` li hev bigire ji ber ku `tmp` tenê li ser stackê wekî tiştek veqetandî ya veqetandî hate veqetandin.
    //
    //
    // Di heman demê de, ji ber ku me tenê nirxek derbasdar di `tmp` de nivîsand, ew garantî ye ku bi rêkûpêk were destpêkirin.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Bêyî ku wê bar bike nirxa ji `src` dixwîne.Ev di `src` de bîranînê bê guhertin dihêle.
///
/// Berevajî [`read`], `read_unaligned` bi nîşangirên bêserûber dixebite.
///
/// # Safety
///
/// Heke ji mercên jêrîn binpê kirin tevger nayê diyar kirin:
///
/// * `src` ji bo xwendinê divê [valid] be.
///
/// * `src` divê li ser nirxek bi rêkûpêk a destpêkirî ya type `T` nîşan bike.
///
/// Mîna [`read`], `read_unaligned` kopiyek bitwise a `T` diafirîne, bêyî ku `T` [`Copy`] e.
/// Ger `T` ne [`Copy`] be, hem nirxa vegerandin û hem jî nirxa li `*src` bikar tîne dikare [violate memory safety][read-ownership].
///
/// Zanibe ku heke `T` xwediyê mezinahiya `0` be jî, divê nîşander ne-NULL be.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Li ser lêdanên `packed`
///
/// Vêga ne gengaz e ku meriv nîşankên raweyên zeviyên bêserûber ên sazûmanek pakkirî biafirîne.
///
/// Hewldana afirandina pointerek rawe li qada `unaligned` struct bi vegotinek wekî `&packed.unaligned as *const FieldType` berî veguhastina wê li pointerê rawe, referansek bêserûber a navîn diafirîne.
///
/// Ku ev referans demkî ye û yekser tê avêtin bê encam e ji ber ku berhevkar her gav hêvî dike ku referans bi rêkûpêk werin rêz kirin.
/// Wekî encamek, karanîna `&packed.unaligned as *const FieldType` di bernameya we de dibe sedema yekser* tevgerîn nediyarkirî *.
///
/// Mînakek ku nayê kirin û ev çawa bi `read_unaligned` ve girêdayî ye ev e:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Li vir em hewl didin ku navnîşana jimareyek 32-bitî ya ku ne lihevkirî ye bigirin.
///     let unaligned =
///         // Li vir referansek bêserûber a demkî çêdibe ku di encama tevgerek nediyarkirî de çêdibe ka referans tê bikar anîn an na.
/////
///         &packed.unaligned
///         // Kastina ser pointerek rawe feyde nade;xeletî berê qewimî.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Lêbelê gihîştina zeviyên bêserûber rasterast bi mînaka `packed.unaligned` ewle ye.
///
///
///
///
///
///
// FIXME: Li gorî encama RFC #2582 û hevalên xwe belgeyan nûve bikin.
/// # Examples
///
/// Nirxek karanîna ji tamponek byte bixwînin:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // EWLEHIY: : divê bangker garantî bike ku `src` ji bo xwendinan derbasdar e.
    // `src` nikare `tmp` li hev bigire ji ber ku `tmp` tenê li ser stackê wekî tiştek veqetandî ya veqetandî hate veqetandin.
    //
    //
    // Di heman demê de, ji ber ku me tenê nirxek derbasdar di `tmp` de nivîsand, ew garantî ye ku bi rêkûpêk were destpêkirin.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Bêyî xwendin an daketina nirxa kevn, cîhek bîrayê bi nirxa dayîn re ji nû ve dinivîse.
///
/// `write` naveroka `dst` naxe.
/// Ev ewledar e, lê ew dikare veqetandin an çavkaniyan derxîne, ji ber vê yekê divê baldar be ku tiştê ku divê were avêtin ji nû ve nenivîsîne.
///
///
/// Wekî din, ew `src` davêje.Bi wateya semantîkî, `src` tête nav cîhê ku ji hêla `dst` ve hatî nîşankirin.
///
/// Ev ji bo destpêkirina bîra uninitialized, an zêdekirina bîra ku berê [`read`] jê hatî, guncan e.
///
/// # Safety
///
/// Heke ji mercên jêrîn binpê kirin tevger nayê diyar kirin:
///
/// * `dst` ji bo nivîsandinê divê [valid] be.
///
/// * `dst` divê bi rêkûpêk were rêz kirin.Ger wilo nebe [`write_unaligned`] bikar bînin.
///
/// Zanibe ku heke `T` xwediyê mezinahiya `0` be jî, divê nîşander ne-NULL be û bi rêk û pêk were.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Bikaranîna bingehîn:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// [`mem::swap`] bi desta bicîh bikin:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Li `a`-a `tmp`-ê nermalavek bitwise ya nirxê biafirînin.
///         let tmp = ptr::read(a);
///
///         // Di vê nuqteyê de derketin (an bi vegera eşkere an jî banga fonksiyonek ku panics) dê bibe sedem ku nirxê `tmp` were daxistin dema ku heman nirx hêj ji hêla `a` ve tê referans kirin.
///         // Ger `T` ne `Copy` be ev dikare tevgerek nediyarkirî bide alî.
/////
/////
///
///         // Li `b`-a `a`-ê nermalavek bitwise ya nirxê biafirînin.
///         // Ev ewle ye ji ber ku referansên guhêrbar nikarin bi navê din bin.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Wekî ku li jor, derketina ji vir dikare tevgerek nediyarkirî bide destpêkirin ji ber ku heman nirx ji hêla `a` û `b` ve tête referans kirin.
/////
///
///         // `tmp` têxin nav `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` hatiye veguhastin (`write` xwediyê nîqaşa xweya duyemîn e), ji ber vê yekê tiştek li vir bi zelalî nayê avêtin.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Em rasterast gazî xwerû dikin da ku ji bangên fonksiyonê yên di koda çêkirî de dûr bisekinin ji ber ku `intrinsics::copy_nonoverlapping` fonksiyonek pêça ye.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // EWLEH: Y::Divê bangker garantî bike ku `dst` ji bo nivîsandinê derbasdar e.
    // `dst` nikare `src` li hev bigire ji ber ku gazîvan gihîştina guhêrbar a `dst` heye dema ku `src` xwediyê vê fonksiyonê ye.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Bêyî xwendin an daketina nirxa kevn, cîhek bîrayê bi nirxa dayîn re ji nû ve dinivîse.
///
/// Berevajî [`write()`], dibe ku nîşander bêserûber be.
///
/// `write_unaligned` naveroka `dst` naxe.Ev ewledar e, lê ew dikare veqetandin an çavkaniyan derxîne, ji ber vê yekê divê baldar be ku tiştê ku divê were avêtin ji nû ve nenivîsîne.
///
/// Wekî din, ew `src` davêje.Bi wateya semantîkî, `src` tête nav cîhê ku ji hêla `dst` ve hatî nîşankirin.
///
/// Ev ji bo destpêkirina bîra uninitialized, an zêdekirina bîranîna ku berê bi [`read_unaligned`] hatî xwendin guncan e.
///
/// # Safety
///
/// Heke ji mercên jêrîn binpê kirin tevger nayê diyar kirin:
///
/// * `dst` ji bo nivîsandinê divê [valid] be.
///
/// Zanibe ku heke `T` xwediyê mezinahiya `0` be jî, divê nîşander ne-NULL be.
///
/// [valid]: self#safety
///
/// ## Li ser lêdanên `packed`
///
/// Vêga ne gengaz e ku meriv nîşankên raweyên zeviyên bêserûber ên sazûmanek pakkirî biafirîne.
///
/// Hewldana afirandina pointerek rawe li qada `unaligned` struct bi vegotinek wekî `&packed.unaligned as *const FieldType` berî veguhastina wê li pointerê rawe, referansek bêserûber a navîn diafirîne.
///
/// Ku ev referans demkî ye û yekser tê avêtin bê encam e ji ber ku berhevkar her gav hêvî dike ku referans bi rêkûpêk werin rêz kirin.
/// Wekî encamek, karanîna `&packed.unaligned as *const FieldType` di bernameya we de dibe sedema yekser* tevgerîn nediyarkirî *.
///
/// Mînakek ku nayê kirin û ev çawa bi `write_unaligned` ve girêdayî ye ev e:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Li vir em hewl didin ku navnîşana jimareyek 32-bitî ya ku ne lihevkirî ye bigirin.
///     let unaligned =
///         // Li vir referansek bêserûber a demkî çêdibe ku di encama tevgerek nediyarkirî de çêdibe ka referans tê bikar anîn an na.
/////
///         &mut packed.unaligned
///         // Kastina ser pointerek rawe feyde nade;xeletî berê qewimî.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Lêbelê gihîştina zeviyên bêserûber rasterast bi mînaka `packed.unaligned` ewle ye.
///
///
///
///
///
///
///
///
///
// FIXME: Li gorî encama RFC #2582 û hevalên xwe belgeyan nûve bikin.
/// # Examples
///
/// Nirxek karanîna ji bo tamponek byte binivîse:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // EWLEH: Y::Divê bangker garantî bike ku `dst` ji bo nivîsandinê derbasdar e.
    // `dst` nikare `src` li hev bigire ji ber ku gazîvan gihîştina guhêrbar a `dst` heye dema ku `src` xwediyê vê fonksiyonê ye.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Em rasterast gazî xwerû dikin da ku ji bangên fonksiyonê yên di koda çêkirî de dûr bisekinin.
        intrinsics::forget(src);
    }
}

/// Bêyî ku ew bilivîne ji `src`-ê xwendinek berbiçav pêk tîne.Ev di `src` de bîranînê bê guhertin dihêle.
///
/// Operasyonên berbiçav têne armanc kirin ku li ser bîranîna I/O tevbigerin, û garantî ne ku ji hêla berhevkar ve li seranserê din ên kirrûbirrîn neyên elî kirin an ji nû de sererast kirin.
///
/// # Notes
///
/// Rust naha ne xwediyê modeleke bîranînê ya hişk û fermî ye, ji ber vê yekê wateya rastîn a ku "volatile" li vir tê wateya bi demê re diguhere.
/// Dema ku tê gotin, dê semantîk hema hema her dem bi xweşikî dişibihe [C11's definition of volatile][c11].
///
/// Divê berhevkar rêzê an jimara tevgerên bîrayê yên berbiçav neguherîne.
/// Lêbelê, operasyonên bîranînê yên li ser celebên sifir-sized (mînakî, heke celebek sifir-sized derbasî `read_volatile` bibe) noop in û dibe ku werin paşguh kirin.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Heke ji mercên jêrîn binpê kirin tevger nayê diyar kirin:
///
/// * `src` ji bo xwendinê divê [valid] be.
///
/// * `src` divê bi rêkûpêk were rêz kirin.
///
/// * `src` divê li ser nirxek bi rêkûpêk a destpêkirî ya type `T` nîşan bike.
///
/// Mîna [`read`], `read_volatile` kopiyek bitwise a `T` diafirîne, bêyî ku `T` [`Copy`] e.
/// Ger `T` ne [`Copy`] be, hem nirxa vegerandin û hem jî nirxa li `*src` bikar tîne dikare [violate memory safety][read-ownership].
/// Lêbelê, depokirina celebên ne [[Copy`] di bîra volatile de hema hema nerast e.
///
/// Zanibe ku heke `T` xwediyê mezinahiya `0` be jî, divê nîşander ne-NULL be û bi rêk û pêk were.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Mîna ku di C de, gelo operasyonek vala ye çi têkilî bi pirsên ku têkevtina hemdem ji gelek têl hene ve heye.Gihîştinên gerguhêz di wî warî de tam mîna gihîştinên ne-atomî tevdigerin.
///
/// Bi taybetî, pêşbaziyek di navbera `read_volatile` û her operasyona nivîsandinê de li heman cîhê tevgerek ne diyar e.
///
/// # Examples
///
/// Bikaranîna bingehîn:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Ne panîkê ku bandora kodjenê piçûktir bike.
        abort();
    }
    // EWLEHIY: : bangker divê peymana ewlehiyê ya `volatile_load` biparêze.
    unsafe { intrinsics::volatile_load(src) }
}

/// Bêyî xwendina an daketina nirxa kevn, bi nirxê dayînê re cîhê bîranînek volatile pêk tîne.
///
/// Operasyonên berbiçav têne armanc kirin ku li ser bîranîna I/O tevbigerin, û garantî ne ku ji hêla berhevkar ve li seranserê din ên kirrûbirrîn neyên elî kirin an ji nû de sererast kirin.
///
/// `write_volatile` naveroka `dst` naxe.Ev ewledar e, lê ew dikare veqetandin an çavkaniyan derxîne, ji ber vê yekê divê baldar be ku tiştê ku divê were avêtin ji nû ve nenivîsîne.
///
/// Wekî din, ew `src` davêje.Bi wateya semantîkî, `src` tête nav cîhê ku ji hêla `dst` ve hatî nîşankirin.
///
/// # Notes
///
/// Rust naha ne xwediyê modeleke bîranînê ya hişk û fermî ye, ji ber vê yekê wateya rastîn a ku "volatile" li vir tê wateya bi demê re diguhere.
/// Dema ku tê gotin, dê semantîk hema hema her dem bi xweşikî dişibihe [C11's definition of volatile][c11].
///
/// Divê berhevkar rêzê an jimara tevgerên bîrayê yên berbiçav neguherîne.
/// Lêbelê, operasyonên bîranînê yên li ser celebên sifir-sized (mînakî, heke celebek sifir-sized derbasî `write_volatile` bibe) noop in û dibe ku werin paşguh kirin.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Heke ji mercên jêrîn binpê kirin tevger nayê diyar kirin:
///
/// * `dst` ji bo nivîsandinê divê [valid] be.
///
/// * `dst` divê bi rêkûpêk were rêz kirin.
///
/// Zanibe ku heke `T` xwediyê mezinahiya `0` be jî, divê nîşander ne-NULL be û bi rêk û pêk were.
///
/// [valid]: self#safety
///
/// Mîna ku di C de, gelo operasyonek vala ye çi têkilî bi pirsên ku têkevtina hemdem ji gelek têl hene ve heye.Gihîştinên gerguhêz di wî warî de tam mîna gihîştinên ne-atomî tevdigerin.
///
/// Bi taybetî, pêşbaziyek di navbera `write_volatile` û her operasyonek din de (xwendin an nivîsandin) li ser heman cîhê tevgerek ne diyar e.
///
/// # Examples
///
/// Bikaranîna bingehîn:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Ne panîkê ku bandora kodjenê piçûktir bike.
        abort();
    }
    // EWLEHIY: : bangker divê peymana ewlehiyê ya `volatile_store` biparêze.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Xoşnav `p` rast bikin.
///
/// Dabeşandina (di warê hêmanên x01X gavavêtinê de) ku divê li ser pointer `p` were sepandin bihesibîne da ku pêşnumaya `p` bi `a` re lihevkirî be.
///
/// Note: Ev pêkanîn bi baldarî li panic nehatiye nerît kirin.Ew ji bo vê yekê ZB ye panic.
/// Guherîna rastîn a tenê ku li vir dikare were çêkirin, guhertina `INV_TABLE_MOD_16` û domên têkildar e.
///
/// Ger em carî biryar bidin ku em gengaz bikin ku bi `a` ya xwerû re bêje ku ne hêza-du-yek e, ew ê dibe ku bêtir hişmend be ku tenê veguherînek pêkanînek naîf ji dêvla ku em vê biguherînin da ku wê guherînê bi cih bînin.
///
///
/// Pirsek biçin@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Bikaranîna rasterast a van xwerû kodjenê di asta opt-ê de bi girîngî çêtir dike <=
    // 1, ku versiyonên rêbazê yên van operasyonan nayên xêz kirin.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Berevajî modulê pirjimar ê `x` modulo `m` hesab bike.
    ///
    /// Ev pêkanîn ji bo `align_offset` tête çêkirin û mercên jêrîn hene:
    ///
    /// * `m` hêza-du-ê ye;
    /// * `x < m`; (heke `x ≥ m`, li şûna `x % m` derbas bibin)
    ///
    /// Pêkanîna vê fonksiyonê ne panic.Herdem.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Modulê tabloya berevajî ya modulkerî ya pirjimar 2⁴=16.
        ///
        /// Têbînî, ku ev tablo nirxên ku berevajî tune tune (ango ji bo `0⁻¹ mod 16`, `2⁻¹ mod 16`, û hwd.) Tune.
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo ku `INV_TABLE_MOD_16` tê armanc kirin.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // BELAW: `m` hewce ye ku bibe hêza-du-ê, ji ber vê yekê ne-sifir.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Em "up" bi karanîna formula jêrîn dubare dikin:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // heya 2²ⁿ ≥ m.Wê hingê em dikarin bi girtina encamê `mod m` ve `m`-a xwesteka xwe kêm bikin.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Bala xwe bidinê, ku em li vir bi zanebûn karûbarên pêçandinê bikar tînin-formula bingehîn wekî mînak, veqetandina `mod n` bikar tîne.
                // Bi tevahî baş e ku meriv li şûna wan `mod usize::MAX` bike, ji ber ku em herhal di dawiyê de encama `mod n` digirin.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // EWLEHIYA: `a` hêza-du-e, ji ber vê yekê ne-sifir.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` doz dikare bi `-p (mod a)` hêsantir were hesibandin, lê kirina vê yekê kapasîteya LLVM ya hilbijartina talîmatên mîna `lea` asteng dike.Di şûna me de em hesab dikin
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // ku li dora barkêşê operasyonan belav dike, lê ji bo LLVM têra xwe pesnê `and` digire da ku karibe optimîzasyonên cihêreng ên ku ew pê dizane bikar bîne.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Jixwe rêz kirin.Yay!
        return 0;
    } else if stride == 0 {
        // Ger pêşnumayek ne lihevkirî be, û hêman bi sifir be, hingê dê hêjmarek hêmanan carî rêzkerê nexe ber hev.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // EWLEH: : a-hêza-du-hence ne-sifir e.gav==0 doz li jor tê rêve birin.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // EWLEHIY: : gcdpow bi bendek jorîn heye ku bi piranî hejmara bîtên di karanînê de ye.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // EWLEHIY: : gcd her dem bi 1 re mezintir an jî wekhev e.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Ev branch ji bo hevkêşeya rêzikî ya jêrîn çareser dike:
        //
        // ` p + so = 0 mod a `
        //
        // `p` li vir hêjayî nîşangir, `s`, gavavêtina `T`, `o` li `T` û `a`, rêzkirina daxwazkirî ye.
        //
        // Bi `g = gcd(a, s)`, û şerta jorîn ku `p` bi `g` jî tê dabeş kirin, em dikarin `a' = a/g`, `s' = s/g`, `p' = p/g` nîşan bikin, wê hingê ev dibe hevber:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Terma yekem "the relative alignment of `p` to `a`" e (bi `g` hatî dabeş kirin), terma duyemîn "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (dîsa bi `g` hatî parve kirin) e.
        //
        // Dabeşkirina bi `g` hewce ye ku berevajî baş çêbibe ger `a` û `s` ne hev-serokwezîr bin.
        //
        // Wekî din, encama ku ji hêla vê çareseriyê ve hatî hilberandin ne "minimal" e, ji ber vê yekê hewce ye ku encam `o mod lcm(s, a)` bigirin.Em dikarin `lcm(s, a)` tenê bi `a'` veguherînin.
        //
        //
        //
        //
        //

        // EWLEHIY: : `gcdpow` xwedan bendek jorîn e ku ji hejmara paş-0-bitên `a`-ê ne mezintir e.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // BELAW: : `a2` ne sifir e.Guherandina `a` bi `gcdpow` nikare yek ji bitên sazkirî veguherîne
        // li `a` (ya ku tam yek jê heye).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // EWLEHIY: : `gcdpow` xwedan bendek jorîn e ku ji hejmara paş-0-bitên `a`-ê ne mezintir e.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // EWLEHIY: : `gcdpow` xwedan bendek jorîn e ku ji hejmara paş-0 bîtên hundir ne mezintir e
        // `a`.
        // Wekî din, veqetandin nikare zêde bibe, ji ber ku `a2 = a >> gcdpow` dê her dem bi zor ji `(p % a) >> gcdpow` mezintir be.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // EWLEHIY: : `a2` hêza-du-du ye, wekî ku li jor jî hate îsbat kirin.`s2` bi zor ji `a2` kêmtir e
        // ji ber ku `(s % a) >> gcdpow` bi zor ji `a >> gcdpow` kêmtir e.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Çu carî nayê rast kirin.
    usize::MAX
}

/// Nîşaneyên raweyên ji bo wekheviyê dide ber hev.
///
/// Ev heman karanîna kargêrê `==` e, lê kêm gelemperî ye:
/// divê nîqaş `*const T` pêşekên xav bin, ne ku tiştek ku `PartialEq` bicîh tîne ne.
///
/// Ev dikare were bikar anîn da ku referansên `&T` (ku bi zorê `*const T` bi zorê dixin) bi navnîşana xwe ve li şûna nirxên ku ew nîşan dikin bidin hev (ev tiştê ku pêkanîna `PartialEq for &T` dike).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Pelik ji hêla dirêjahiya wan ve (nîşangirên qelew) jî têne qiyas kirin:
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits jî ji hêla pêkanîna wan ve têne berhev kirin:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Navnîşan navnîşanên wekhev hene.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Nîşaneyên navnîşan wekhev in, lê `Trait` pêkanînên cûda hene.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Veguheztina referansa li ser `*const u8` bi navnîşanê re hevber dike.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash pêşekek rawe.
///
/// Ev dikare were bikar anîn ku ji hêla navnîşana xwe ve ji nirxa ku ew nîşan dike (ku ev pêkanîna `Hash for &T` çi dike) referansek `&T` (ku bi neçarî `*const T` bi zorê dide zorê) hash bike.
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impls ji bo nîşankerên fonksiyonê
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Casta navîn wekî karanînê ji bo AVR hewce ye
                // da ku qada navnîşana nîşana fonksiyona çavkaniyê di nîşana fonksiyona dawîn de were parastin.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Casta navîn wekî karanînê ji bo AVR hewce ye
                // da ku qada navnîşana nîşana fonksiyona çavkaniyê di nîşana fonksiyona dawîn de were parastin.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Bi 0 parametre fonksiyonên guherbar tune
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Bêyî ku referansek navîn biafirîne, li cîhekî pêşnumaya `const` xav biafirînin.
///
/// Afirandina referansek bi `&`/`&mut` tenê heke destûr hebe ku nîşander bi rêkûpêk were rêzkirin û daneyên destpêkirî nîşan bide.
/// Ji bo rewşên ku ew hewcedarî nayên girtin, divê li şûna wan nîşankerên rawe werin bikar anîn.
/// Lêbelê, `&expr as *const _` referansek çêdike berî ku wê bavêje ser pêşnumayek rawe, û ew referans bi hemî rêzikên din ve girêdayî heman rêzikan e.
///
/// Ev makro dikare pêşnumayek rawe *bêyî* pêşî referansek çêbike.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` dê referansek bêserûber biafirîne, û bi vî rengî reftarek nediyarkirî be!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Bêyî ku referansek navîn biafirîne, li cîhekî pêşnumaya `mut` xav biafirînin.
///
/// Afirandina referansek bi `&`/`&mut` tenê heke destûr hebe ku nîşander bi rêkûpêk were rêzkirin û daneyên destpêkirî nîşan bide.
/// Ji bo rewşên ku ew hewcedarî nayên girtin, divê li şûna wan nîşankerên rawe werin bikar anîn.
/// Lêbelê, `&mut expr as *mut _` referansek çêdike berî ku wê bavêje ser pêşnumayek rawe, û ew referans bi hemî rêzikên din ve girêdayî heman rêzikan e.
///
/// Ev makro dikare pêşnumayek rawe *bêyî* pêşî referansek çêbike.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` dê referansek bêserûber biafirîne, û bi vî rengî reftarek nediyarkirî be!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` hêzên li şûna afirandina referansekê qadê kopî dikin.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}