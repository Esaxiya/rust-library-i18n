use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Dorpêçek li dora `*mut T` ya xav a ne-null ku diyar dike ku xwediyê vê pêçê xwediyê referansê ye.
/// Ji bo avakirina abstraktên mîna `Box<T>`, `Vec<T>`, `String`, û `HashMap<K, V>` bikêr e.
///
/// Berevajî `*mut T`, `Unique<T>` "as if" tevdigere ew mînakek `T` bû.
/// Ger `T` `Send`/`Sync` be ew `Send`/`Sync` bicîh tîne.
/// Ew herweha wateya celebek aliasing ya bihêz dide ku mînakek `T` dikare hêvî bike:
/// referansa nîşanderê pêdivî ye ku bêyî rêyek bêhempa ya xwedanenasiya xwe neyê guhertin.
///
/// Heke hûn nebawer in ka ka ji bo mebestên xwe `Unique` bikar tîne rast e, `NonNull` bikar bînin, ku semantîkek wê qelstir e.
///
///
/// Berevajî `*mut T`, pêdivî ye ku hertim nîşander ne-null be, her çend ku pêşnumêr carî neyê paşguh kirin.
/// Ji ber vê yekê ye ku enum dikarin vê nirxa qedexe wekî cûdakar bikar bînin-`Option<Unique<T>>` xwedan eynî mezinahî `Unique<T>` ye.
/// Lêbelê heke nîşander neyê paşguhxistin dibe ku hîn jî dangle bibe.
///
/// Berevajî `*mut T`, `Unique<T>` li ser `T` hevpar e.
/// Divê ev her gav ji bo her cûreyê ku pêdiviyên biyanîbûnê yên Yekta diparêze rast be.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: ev nîşanker ji bo cûdabûnê encamek nagire, lê hewce ye
    // ji bo dropck fêhm bike ku em bi mantiqî xwedî `T` ne.
    //
    // Ji bo hûrguliyan, binihêrin:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` pointers `Send` in heke `T` `Send` be ji ber ku daneya ku ew behs dikin bêalî ye.
/// Zanibe ku ev neguhêzbar a alias ji hêla pergala celeb ve nayê zorê kirin;abstraksiyona ku `Unique` bikar tîne divê ew wê bicîh bîne.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` pointers `Sync` in heke `T` `Sync` be ji ber ku daneya ku ew behs dikin bêalî ye.
/// Zanibe ku ev neguhêzbar a alias ji hêla pergala celeb ve nayê zorê kirin;abstraksiyona ku `Unique` bikar tîne divê ew wê bicîh bîne.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// `Unique` nû diafirîne ku dangling e, lê baş li hev hatî.
    ///
    /// Ev ji bo destpêkirina celebên ku bi lalkî dabeş dikin, wek `Vec::new` dike, bikêr e.
    ///
    /// Bala xwe bidinê ku dibe ku nirxa pointer potansiyelî ji `T` re pêşnumayek derbasdar temsîl dike, ku tê vê wateyê ku divê ev wekî nirxa sentîl a "not yet initialized" neyê bikar anîn.
    /// Cûreyên ku bi lalbûnek veqetandî ne, divê destpêkirina bi hin rêyên din bişopînin.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // EWLEH: : mem::align_of() pêşnumayek derbasdar, ne-null vedigerîne.Ew
        // şertên ku new_unchecked() bang dikin bi vî rengî têne rêz kirin.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// `Unique` nû diafirîne.
    ///
    /// # Safety
    ///
    /// `ptr` divê ne-pûç be.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // EWLEHIY: : divê bangker garantî bike ku `ptr` ne betal e.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Ger `ptr` ne-pûç be `Unique` nû diafirîne.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // EWLEHIYE: Nîşanek berê hate kontrol kirin û ne betal e.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Nîşaneya bingehîn a `*mut` peyda dike.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Naverokê derefer dike.
    ///
    /// Jiyana ku di encamê de bi xwe ve girêdayî ye ji ber vê yekê ev "as if" tevdigere ew bi rastî bû mînakek T ya ku tê deyn kirin.
    /// Ger jiyanek dirêjtir a (unbound) hewce be, `&*my_ptr.as_ptr()` bikar bînin.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // EWLEHIY: : divê bangker garantî bike ku `self` hemî hevdîtinan pêk tîne
        // hewcedariyên ji bo referansê.
        unsafe { &*self.as_ptr() }
    }

    /// Bi guhêrbar naverokê paşguh dikin.
    ///
    /// Jiyana ku di encamê de bi xwe ve girêdayî ye ji ber vê yekê ev "as if" tevdigere ew bi rastî bû mînakek T ya ku tê deyn kirin.
    /// Ger jiyanek dirêjtir a (unbound) hewce be, `&mut *my_ptr.as_ptr()` bikar bînin.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // EWLEHIY: : divê bangker garantî bike ku `self` hemî hevdîtinan pêk tîne
        // hewcedariyên referansa guhêrbar.
        unsafe { &mut *self.as_ptr() }
    }

    /// Derdixe ser pointerek ji celebek din.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // BELAW: Unique::new_unchecked() yekta û hewcedariyên nû diafirîne
        // nîşana dayîn da ku pûç nebe.
        // Ji ber ku em ji xwe wekî pointer derbas dibin, ew nikare pûç be.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // EWLEHIY: : Referansek guhêrbar nikare pûç be
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}