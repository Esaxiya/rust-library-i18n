use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// Ger pêşnumayek vala ye `true` vedigerîne.
    ///
    /// Bala xwe bidinê ku celebên bêserûber gelek nîşanderên null ên gengaz hene, ji ber ku tenê nîşana daneya xav tête hesibandin, ne dirêjahiya wan, vtable, hwd.
    /// Ji ber vê yekê, dibe ku du nîşanên ku pûç in dîsa jî bi hevûdu re wekhev nabin.
    ///
    /// ## Di dema nirxandina const de tevger
    ///
    /// Dema ku ev fonksiyon di dema nirxandina const de tê bikar anîn, dibe ku ew `false` ji bo nîşangirên ku di dema dorê de pûç dibin vegerîne.
    /// Bi taybetî, dema ku pêşnumayek hin bîranînê li derveyî sînorên xwe be, bi rengek ku nîşanderê encam pûç be, dê fonksiyon dîsa jî `false` vegerîne.
    ///
    /// Çu rê tune ku CTFE pozîsyona mutleq a wê bîranînê bizanibe, ji ber vê yekê em nekarin bêjin ka pointer pûç e an na.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Bi kelekekê bi pointerek zirav bidin hev, ji ber vê yekê nîşangirên qelew tenê ji bo betalbûnê beşa "data"-a xwe difikirin.
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// Derdixe ser pointerek ji celebek din.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// Nîşanek (dibe ku fereh) veqetînin nav pêkhateyên navnîşan û metadata ye.
    ///
    /// Nîşanek dikare paşê bi [`from_raw_parts`] ji nû ve were çêkirin.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// `None` vedigerîne heke pointer vala ye, an na referansa hevpar a nirxa ku di `Some` de pêçayî vedigerîne.Ger dibe ku nirx bê unitialized be, divê li şûna [`as_uninit_ref`] were bikar anîn.
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// Dema ku bang li vê rêbazê dikin, divê hûn piştrast bikin ku *yan* nîşander NULL * e an jî hemî jêrîn rast e:
    ///
    /// * Pêdivî ye ku nîşander bi rêkûpêk were rêz kirin.
    ///
    /// * Divê ew di wateya ku di [the module documentation] de hatî diyarkirin "dereferencable" be.
    ///
    /// * Pêdivî ye ku nîşander mînakek destpêkirî ya `T` nîşan bike.
    ///
    /// * Pêdivî ye ku hûn qaîdeyên aliasing ên Rust bicîh bînin, ji ber ku jiyana vegerandî `'a` bi keyfî tête bijartin û ne hewce ye ku jiyana rastîn a daneyê nîşan bide.
    ///   Bi taybetî, ji bo dirêjahiya vê heyatê, divê bîranîna ku nîşangir nîşan dide divê neguhere (ji bilî hundurê `UnsafeCell`).
    ///
    /// Ev encam digire heke encama vê rêbazê neyê bikar anîn!
    /// (Beşa di derbarê destpêkirinê de hêj bi tevahî biryar nehatiye girtin, lê heya ku ew be, nêzîkatiya tenê ewledar ew e ku ew bi rastî werin destpêkirin.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Guhertoya nederbasdar
    ///
    /// Heke hûn pê ewle ne ku nîşander qet nahêle û li celebek `as_ref_unchecked`-ê digerin ku li şûna `Option<&T>`-yê `&T` vedigerîne, bizanin ku hûn dikarin rasterast nîşanderê paşve bixin.
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // EWLEHIY: : divê bangker garantî bike ku `self` derbasdar e
        // ji bo referansek heke ew betal nebe.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// `None` vedigerîne heke pointer vala ye, an na referansa hevpar a bi nirxê di `Some` de pêçayî vedigerîne.
    /// Berevajî [`as_ref`], ev hewce nake ku nirx bi dest pê bike.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Dema ku bang li vê rêbazê dikin, divê hûn piştrast bikin ku *yan* nîşander NULL * e an jî hemî jêrîn rast e:
    ///
    /// * Pêdivî ye ku nîşander bi rêkûpêk were rêz kirin.
    ///
    /// * Divê ew di wateya ku di [the module documentation] de hatî diyarkirin "dereferencable" be.
    ///
    /// * Pêdivî ye ku hûn qaîdeyên aliasing ên Rust bicîh bînin, ji ber ku jiyana vegerandî `'a` bi keyfî tête bijartin û ne hewce ye ku jiyana rastîn a daneyê nîşan bide.
    ///
    ///   Bi taybetî, ji bo dirêjahiya vê heyatê, divê bîranîna ku nîşangir nîşan dide divê neguhere (ji bilî hundurê `UnsafeCell`).
    ///
    /// Ev encam digire heke encama vê rêbazê neyê bikar anîn!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // EWLEHIY: : divê bangker garantî bike ku `self` hemî hevdîtinan pêk tîne
        // hewcedariyên ji bo referansê.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Dabeşandina ji nîşanderê dihejmêre.
    ///
    /// `count` di yekeyên T de ye;mînak, `count` ji 3-ê nîşanek pointer a `3 * size_of::<T>()` byte dike.
    ///
    /// # Safety
    ///
    /// Ger yek ji mercên jêrîn were binpê kirin, encam Reftara Bênavkirî ye:
    ///
    /// * Hem nîşanderê destpêk û hem jî yê encam divê di nav sînoran de be an jî yek bayt be dawiya dawiya heman tiştê veqetandî be.
    /// Zanibe ku di Rust de, her guhêrbar (stack-allocated) wekî tiştek veqetandî cuda tête hesibandin.
    ///
    /// * Dabeşandina hesabkirî,**li byte**, nikare `isize` zêde bike.
    ///
    /// * Çêbûna di nav sînoran de nikare xwe bispêre "wrapping around" cîhê navnîşanê.Ango, mîqdara rastîniya bêdawî,**di byte** de divê di karanînê de cih bigire.
    ///
    /// Berhevkar û pirtûkxaneya standard bi gelemperî hewl dide ku dabeşkirin qet negihîje mezinahiya ku lêvegerandin xemgîn e.
    /// Mînakî, `Vec` û `Box` piştrast dikin ku ew carî bêtir ji `isize::MAX` byte veqetînin, ji ber vê yekê `vec.as_ptr().add(vec.len())` her gav ewle ye.
    ///
    /// Piraniya platforman di bingeh de ne jî dikarin dabeşkirinek wusa çêbikin.
    /// Mînakî, tu platforma 64-bit-a ku tê zanîn ji ber sînorkirinên rûpel-maseyê an dabeşkirina qada navnîşanê, carî nikare daxwazek ji bo 2 <sup>63</sup> byte bike.
    /// Lêbelê, dibe ku hin platformên 32-bit û 16-bit bi serfirazî ji bo zêdetirî `isize::MAX` bayt tiştan wekî Zêdekirina Navnîşana Fîzîkî daxwazek bikin.
    ///
    /// Bi vî rengî, bîranîn ku rasterast ji dabeşker an pelên nexşeya bîranînê hatî stendin *dibe ku* pir mezin be ku bi vê fonksiyonê re rêve bibe.
    ///
    /// Heke van astengiyan têr kirin zor e ku hûn li şûna [`wrapping_offset`] bikar bînin bifikirin.
    /// Avantaja tenê ya vê rêbazê ev e ku ew optimîzasyonên berhevkar ên êrişker çêtir dike.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // EWLEHIY: : bangker divê peymana ewlehiyê ya `offset` biparêze.
        unsafe { intrinsics::offset(self, count) }
    }

    /// Dabeşandina ji pointer bi karanîna arîtmetîk ve hesab dike.
    ///
    /// `count` di yekeyên T de ye;mînak, `count` ji 3-ê nîşanek pointer a `3 * size_of::<T>()` byte dike.
    ///
    /// # Safety
    ///
    /// Vê operasyonê bixwe her gav ewle ye, lê karanîna nîşangirê encam ne ew e.
    ///
    /// Nîşaneya encam bi heman tiştê veqetandî ve girêdayî ye ku `self` nîşan dike.
    /// Dibe ku ew *nebe* ji bo gihîştina tiştiyek veqetandî ya cûda.Zanibe ku di Rust de, her guhêrbar (stack-allocated) wekî tiştek veqetandî cuda tête hesibandin.
    ///
    /// Bi gotinên din, `let z = x.wrapping_offset((y as isize) - (x as isize))`*heke em texmîn bikin ku `T` mezinahiya `1` heye û serûbinbûnek tune, `z`* bi `y` re nake *: `z` hîn jî bi tiştê ku `x` pê ve girêdayî ye ve girêdayî ye, û dereferîfa wê Tevger nediyar e heya ku `x` û `y` dixe nav heman tiştê veqetandî.
    ///
    /// Li gorî [`offset`], ev rêbaza hanê di bingeh de pêdiviya mayîna di nav eynî tiştê veqetandî de dereng dixe: [`offset`] dema derbaskirina tixûbên tiştikê Reftara Bênavber a Yekser e;`wrapping_offset` pêşekek çêdike lê heke pêşnumayek gava ku ji der û dora tişta ku pê ve hatî girêdan paşve were vegerandin, hê jî ber bi Tevgerînek Nediyarkirî ve diçe.
    /// [`offset`] çêtir dikare were optimîzekirin û ji ber vê yekê di koda hesas a performansê de çêtir e.
    ///
    /// Kontrola derengmayî tenê nirxa nîşanderê ku hatî paşguh kirin, ne nirxên navîn ên di dema hesibandina encama dawîn de hatine bikar anîn hesab dike.
    /// Mînakî, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` her dem wekî `x` eynî ye.Bi gotinên din, terikandina tiştê hatî veqetandin û dûv re ji nû ve ketina wê destûr heye.
    ///
    /// Heke hûn hewce ne ku tixûbên tiştikan derbas bikin, nîşangirê bavêjin ser jimareyek jimar û li wir hejmar bikin.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// // Bi zêdekirina du hêmanan ve karanîna pointerek xav dubare bikin
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // Ev xelek "1, 3, 5, " çap dike
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // EWLEHIY: : `arith_offset` ya xwerû ti mercên pêşîn tune ku werin gotin.
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// Dûrahiya di navbera du nîşangiran de hesab dike.Nirxa vegerandin di yekeyên T de ye: mesafeya byteyan bi `mem::size_of::<T>()` ve hatî dabeş kirin.
    ///
    /// Ev fonksiyon berevajî ya [`offset`] e.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// Ger yek ji mercên jêrîn were binpê kirin, encam Reftara Bênavkirî ye:
    ///
    /// * Pêdivî ye ku nîşana destpêkî û nîşana din jî di sînoran de bin an jî yek bayt be ji dawiya heman tiştê veqetandî re.
    /// Zanibe ku di Rust de, her guhêrbar (stack-allocated) wekî tiştek veqetandî cuda tête hesibandin.
    ///
    /// * Pêdivî ye ku herdu nîşanker jî ji * nîşangirek ber bi heman tiştî ve bêne girtin.
    ///   (Ji bo mînakek li jêr binêrin.)
    ///
    /// * Dûrahiya di navbera nîşangiran de, di byteyan de, divê pirjimara teqez a mezinahiya `T` be.
    ///
    /// * Dûrahiya di navberan de,**di byte** de, nikare `isize`-ê zêde bike.
    ///
    /// * Dûrahiya ku di nav sînoran de ye nikare xwe bispêre "wrapping around" qada navnîşanê.
    ///
    /// Cûreyên Rust ji veqetandinên `isize::MAX` û Rust qet mezintir nabin li dora navnîşanê, ji ber vê yekê du nîşangirên di nav nirxê her Rust de tîpa `T` dê her du mercên paşîn têr bikin.
    ///
    /// Pirtûkxaneya standard di heman demê de bi gelemperî piştrast dike ku dabeşkirin qet nagihîje mezinahiya ku veqetandek xemgîn e.
    /// Mînakî, `Vec` û `Box` piştrast dikin ku ew qet ji `isize::MAX` bayt zêdetir veqetînin, ji ber vê yekê `ptr_into_vec.offset_from(vec.as_ptr())` her dem du mercên paşîn têr dike.
    ///
    /// Piraniya platforman bi bingehî nekarin dabeşkirinek ew qas mezin jî ava bikin.
    /// Mînakî, tu platforma 64-bit-a ku tê zanîn ji ber sînorkirinên rûpel-maseyê an dabeşkirina qada navnîşanê, carî nikare daxwazek ji bo 2 <sup>63</sup> byte bike.
    /// Lêbelê, dibe ku hin platformên 32-bit û 16-bit bi serfirazî ji bo zêdetirî `isize::MAX` bayt tiştan wekî Zêdekirina Navnîşana Fîzîkî daxwazek bikin.
    /// Bi vî rengî, bîranîn ku rasterast ji dabeşker an pelên nexşeya bîranînê hatî stendin *dibe ku* pir mezin be ku bi vê fonksiyonê re rêve bibe.
    /// (Zanibe ku di [`offset`] û [`add`] de jî sînorek wekhev heye û ji ber vê yekê li ser veqetandinên weha mezin jî nayê bikar anîn.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Vê fonksiyona panics heke `T` Zero-Sized Type ("ZST") be.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Bikaranîna çewt*:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Ptr2_ yê din bikin "alias" ya ptr2, lê ji ptr1 were.
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Ji ber ku ptr2_other û ptr2 ji nîşangiran ber bi tiştên cûda ve hatine girtin, computing qeweta wan tevgerek nediyarkirî ye, her çend ew heman navnîşanê nîşan dikin jî!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Tevgerek nediyarkirî
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // EWLEHIY: : bangker divê peymana ewlehiyê ya `ptr_offset_from` biparêze.
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// Vedigere ka du nîşangir garantî bûne ku wekhev bin.
    ///
    /// Di dema dirêjahiyê de ev fonksiyon mîna `self == other` tevdigere.
    /// Lêbelê, di hin çarçoveyan de (mînakî, nirxandina dema berhevkirinê), her dem ne gengaz e ku meriv wekheviya du nîşangiran diyar bike, ji ber vê yekê ev fonksiyon dikare bi derewan `false` vegerîne ji bo nîşankerên ku paşê paşê bi rastî wekhev dibin.
    ///
    /// Lê gava ku ew `true` vedigerîne, nîşanker wekhev têne garantîkirin.
    ///
    /// Ev fonksiyon neynika [`guaranteed_ne`] e, lê ne berevajiya wê ye.Hevberdanên pointer hene ku ji bo wan her du fonksiyon `false` vedigerin.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Nirxa vegerê dibe ku li gorî guhertoya berhevkar biguhere û koda ne ewle dibe ku li ser encama vê fonksiyonê ji bo saxlemiyê bisekine.
    /// Tête pêşniyar kirin ku tenê vê fonksiyonê ji bo optimîzasyonên çalakiyê bikar bînin ku nirxên vegerandî yên derewîn `false` ji hêla vê fonksiyonê ve li encamê bandor nakin, lê tenê li ser performansê.
    /// Encamên karanîna vê rêbazê ji bo ku demjimêr û koda berhevkar-demê cûda tevbigerin nehatine vekolandin.
    /// Pêdivî ye ku ev rêbaz ji bo danasîna cûdahiyên bi vî rengî neyê bikar anîn, û her weha divê ew neyê aram kirin berî ku em ji vê pirsgirêkê baştir fêhm bikin.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// Vedigere ka du nîşangir garantî ne ku newekhev in.
    ///
    /// Di dema dirêjahiyê de ev fonksiyon mîna `self != other` tevdigere.
    /// Lêbelê, di hin çarçoveyan de (mînakî, nirxandina dema berhevkirinê), her dem ne gengaz e ku meriv newekheviya du nîşangiran diyar bike, ji ber vê yekê dibe ku ev fonksiyon bi derewan `false` vegerîne ji bo nîşankerên ku paşê paşê rastî neheqî derkevin.
    ///
    /// Lê gava ku ew `true` vedigerîne, nîşangir garantî dibin ku newekhev bin.
    ///
    /// Ev fonksiyon neynika [`guaranteed_eq`] e, lê ne berevajiya wê ye.Hevberdanên pointer hene ku ji bo wan her du fonksiyon `false` vedigerin.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Nirxa vegerê dibe ku li gorî guhertoya berhevkar biguhere û koda ne ewle dibe ku li ser encama vê fonksiyonê ji bo saxlemiyê bisekine.
    /// Tête pêşniyar kirin ku tenê vê fonksiyonê ji bo optimîzasyonên çalakiyê bikar bînin ku nirxên vegerandî yên derewîn `false` ji hêla vê fonksiyonê ve li encamê bandor nakin, lê tenê li ser performansê.
    /// Encamên karanîna vê rêbazê ji bo ku demjimêr û koda berhevkar-demê cûda tevbigerin nehatine vekolandin.
    /// Pêdivî ye ku ev rêbaz ji bo danasîna cûdahiyên bi vî rengî neyê bikar anîn, û her weha divê ew neyê aram kirin berî ku em ji vê pirsgirêkê baştir fêhm bikin.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// Ji nîşanderê (ji bo `.offset(count as isize)`) rehetiya) veqetandinê hesab dike.
    ///
    /// `count` di yekeyên T de ye;mînak, `count` ji 3-ê nîşanek pointer a `3 * size_of::<T>()` byte dike.
    ///
    /// # Safety
    ///
    /// Ger yek ji mercên jêrîn were binpê kirin, encam Reftara Bênavkirî ye:
    ///
    /// * Hem nîşanderê destpêk û hem jî yê encam divê di nav sînoran de be an jî yek bayt be dawiya dawiya heman tiştê veqetandî be.
    /// Zanibe ku di Rust de, her guhêrbar (stack-allocated) wekî tiştek veqetandî cuda tête hesibandin.
    ///
    /// * Dabeşandina hesabkirî,**li byte**, nikare `isize` zêde bike.
    ///
    /// * Çêbûna di nav sînoran de nikare xwe bispêre "wrapping around" qada navnîşanê.Ango, mîqdara rastîniya bêdawî divê di `usize` de cih bigire.
    ///
    /// Berhevkar û pirtûkxaneya standard bi gelemperî hewl dide ku dabeşkirin qet negihîje mezinahiya ku lêvegerandin xemgîn e.
    /// Mînakî, `Vec` û `Box` piştrast dikin ku ew carî bêtir ji `isize::MAX` byte veqetînin, ji ber vê yekê `vec.as_ptr().add(vec.len())` her gav ewle ye.
    ///
    /// Piraniya platforman di bingeh de ne jî dikarin dabeşkirinek wusa çêbikin.
    /// Mînakî, tu platforma 64-bit-a ku tê zanîn ji ber sînorkirinên rûpel-maseyê an dabeşkirina qada navnîşanê, carî nikare daxwazek ji bo 2 <sup>63</sup> byte bike.
    /// Lêbelê, dibe ku hin platformên 32-bit û 16-bit bi serfirazî ji bo zêdetirî `isize::MAX` bayt tiştan wekî Zêdekirina Navnîşana Fîzîkî daxwazek bikin.
    ///
    /// Bi vî rengî, bîranîn ku rasterast ji dabeşker an pelên nexşeya bîranînê hatî stendin *dibe ku* pir mezin be ku bi vê fonksiyonê re rêve bibe.
    ///
    /// Heke van astengiyan têr kirin zor e ku hûn li şûna [`wrapping_add`] bikar bînin bifikirin.
    /// Avantaja tenê ya vê rêbazê ev e ku ew optimîzasyonên berhevkar ên êrişker çêtir dike.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // EWLEHIY: : bangker divê peymana ewlehiyê ya `offset` biparêze.
        unsafe { self.offset(count as isize) }
    }

    /// Ji nîşanderê (ji bo `.offset`ê hêsankirinê) hesab dike. ((Wekî isize).wrapping_neg())`) bihesibîne).
    ///
    /// `count` di yekeyên T de ye;mînak, `count` ji 3-ê nîşanek pointer a `3 * size_of::<T>()` byte dike.
    ///
    /// # Safety
    ///
    /// Ger yek ji mercên jêrîn were binpê kirin, encam Reftara Bênavkirî ye:
    ///
    /// * Hem nîşanderê destpêk û hem jî yê encam divê di nav sînoran de be an jî yek bayt be dawiya dawiya heman tiştê veqetandî be.
    /// Zanibe ku di Rust de, her guhêrbar (stack-allocated) wekî tiştek veqetandî cuda tête hesibandin.
    ///
    /// * Dabeşandina hesabkirî nikare ji `isize::MAX`**byte** derbas bibe.
    ///
    /// * Çêbûna di nav sînoran de nikare xwe bispêre "wrapping around" cîhê navnîşanê.Ango, mîqdara teqeziya bêsînor divê di karanînê de cih bigire.
    ///
    /// Berhevkar û pirtûkxaneya standard bi gelemperî hewl dide ku dabeşkirin qet negihîje mezinahiya ku lêvegerandin xemgîn e.
    /// Mînakî, `Vec` û `Box` piştrast dikin ku ew carî bêtir ji `isize::MAX` byte veqetînin, ji ber vê yekê `vec.as_ptr().add(vec.len()).sub(vec.len())` her gav ewle ye.
    ///
    /// Piraniya platforman di bingeh de ne jî dikarin dabeşkirinek wusa çêbikin.
    /// Mînakî, tu platforma 64-bit-a ku tê zanîn ji ber sînorkirinên rûpel-maseyê an dabeşkirina qada navnîşanê, carî nikare daxwazek ji bo 2 <sup>63</sup> byte bike.
    /// Lêbelê, dibe ku hin platformên 32-bit û 16-bit bi serfirazî ji bo zêdetirî `isize::MAX` bayt tiştan wekî Zêdekirina Navnîşana Fîzîkî daxwazek bikin.
    ///
    /// Bi vî rengî, bîranîn ku rasterast ji dabeşker an pelên nexşeya bîranînê hatî stendin *dibe ku* pir mezin be ku bi vê fonksiyonê re rêve bibe.
    ///
    /// Heke van astengiyan têr kirin zor e ku hûn li şûna [`wrapping_sub`] bikar bînin bifikirin.
    /// Avantaja tenê ya vê rêbazê ev e ku ew optimîzasyonên berhevkar ên êrişker çêtir dike.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // EWLEHIY: : bangker divê peymana ewlehiyê ya `offset` biparêze.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Dabeşandina ji pointer bi karanîna arîtmetîk ve hesab dike.
    /// (hêsanî ji bo `.wrapping_offset(count as isize)`)
    ///
    /// `count` di yekeyên T de ye;mînak, `count` ji 3-ê nîşanek pointer a `3 * size_of::<T>()` byte dike.
    ///
    /// # Safety
    ///
    /// Vê operasyonê bixwe her gav ewle ye, lê karanîna nîşangirê encam ne ew e.
    ///
    /// Nîşaneya encam bi heman tiştê veqetandî ve girêdayî ye ku `self` nîşan dike.
    /// Dibe ku ew *nebe* ji bo gihîştina tiştiyek veqetandî ya cûda.Zanibe ku di Rust de, her guhêrbar (stack-allocated) wekî tiştek veqetandî cuda tête hesibandin.
    ///
    /// Bi gotinên din, `let z = x.wrapping_add((y as usize) - (x as usize))`*heke em texmîn bikin ku `T` mezinahiya `1` heye û dorpêçek tune, `z`* wekî `y` nake *: `z` hîn jî bi tiştê ve girêdayî ye `y` dixe nav heman tiştê veqetandî.
    ///
    /// Li gorî [`add`], ev rêbaza hanê di bingeh de pêdiviya mayîna di nav eynî tiştê veqetandî de dereng dixe: [`add`] dema derbaskirina tixûbên tiştikê Reftara Bênavber a Yekser e;`wrapping_add` pêşekek çêdike lê heke pêşnumayek gava ku ji der û dora tişta ku pê ve hatî girêdan paşve were vegerandin, hê jî ber bi Tevgerînek Nediyarkirî ve diçe.
    /// [`add`] çêtir dikare were optimîzekirin û ji ber vê yekê di koda hesas a performansê de çêtir e.
    ///
    /// Kontrola derengmayî tenê nirxa nîşanderê ku hatî paşguh kirin, ne nirxên navîn ên di dema hesibandina encama dawîn de hatine bikar anîn hesab dike.
    /// Mînakî, `x.wrapping_add(o).wrapping_sub(o)` her dem wekî `x` eynî ye.Bi gotinên din, terikandina tiştê hatî veqetandin û dûv re ji nû ve ketina wê destûr heye.
    ///
    /// Heke hûn hewce ne ku tixûbên tiştikan derbas bikin, nîşangirê bavêjin ser jimareyek jimar û li wir hejmar bikin.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// // Bi zêdekirina du hêmanan ve karanîna pointerek xav dubare bikin
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Ev xelek "1, 3, 5, " çap dike
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Dabeşandina ji pointer bi karanîna arîtmetîk ve hesab dike.
    /// (hêsanî ji bo `.pêçandina_offset ((wekî isize).wrapping_neg())`) bijmêrin)
    ///
    /// `count` di yekeyên T de ye;mînak, `count` ji 3-ê nîşanek pointer a `3 * size_of::<T>()` byte dike.
    ///
    /// # Safety
    ///
    /// Vê operasyonê bixwe her gav ewle ye, lê karanîna nîşangirê encam ne ew e.
    ///
    /// Nîşaneya encam bi heman tiştê veqetandî ve girêdayî ye ku `self` nîşan dike.
    /// Dibe ku ew *nebe* ji bo gihîştina tiştiyek veqetandî ya cûda.Zanibe ku di Rust de, her guhêrbar (stack-allocated) wekî tiştek veqetandî cuda tête hesibandin.
    ///
    /// Bi gotinên din, `let z = x.wrapping_sub((x as usize) - (y as usize))`*heke em texmîn bikin ku `T` mezinahiya `1` heye û dorpêçek tune, `z`* wekî `y` nake *: `z` hîn jî bi tiştê ve girêdayî ye `y` dixe nav heman tiştê veqetandî.
    ///
    /// Li gorî [`sub`], ev rêbaza hanê di bingeh de pêdiviya mayîna di nav eynî tiştê veqetandî de dereng dixe: [`sub`] dema derbaskirina tixûbên tiştikê Reftara Bênavber a Yekser e;`wrapping_sub` pêşekek çêdike lê heke pêşnumayek gava ku ji der û dora tişta ku pê ve hatî girêdan paşve were vegerandin, hê jî ber bi Tevgerînek Nediyarkirî ve diçe.
    /// [`sub`] çêtir dikare were optimîzekirin û ji ber vê yekê di koda hesas a performansê de çêtir e.
    ///
    /// Kontrola derengmayî tenê nirxa nîşanderê ku hatî paşguh kirin, ne nirxên navîn ên di dema hesibandina encama dawîn de hatine bikar anîn hesab dike.
    /// Mînakî, `x.wrapping_add(o).wrapping_sub(o)` her dem wekî `x` eynî ye.Bi gotinên din, terikandina tiştê hatî veqetandin û dûv re ji nû ve ketina wê destûr heye.
    ///
    /// Heke hûn hewce ne ku tixûbên tiştikan derbas bikin, nîşangirê bavêjin ser jimareyek jimar û li wir hejmar bikin.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// // Bi zêdebûna du hêmanan (backwards) karanîna pêşekek xav dubare bikin
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Ev xelek "5, 3, 1, " çap dike
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Nirxa nîşaneyê li `ptr` saz dike.
    ///
    /// Di rewşê de ku `self` nîşangirek (fat) e ji bo celebek neçêkirî, ev karûbar dê tenê bandorê li beşa nîşangir bike, lê ji bo (thin) nîşankerên celebên mezinahî, ev bandorek wek wezîfeyek hêsan heye.
    ///
    /// Dê nîşankerê encamdariyê xwediyê `val` be, ango, ji bo pointerek qelew, ev operasyon ji hêla semantîkî ve eynî wekî çêkirina pointerek qelew a nû ye ku bi nirxa pointerê daneyê `val` lê metadata `self` heye.
    ///
    ///
    /// # Examples
    ///
    /// Ev fonksiyon di serî de ji bo destûrdayîna arîtmetîka nîşankerê byte-şehreza li ser pointerên potansiyel qelew e:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // dê "3" çap bike
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // EWLEHIYA: Di rewşa nîşanderê zirav de, ev operasyon wekhev in
        // ji bo wezîfeyek hêsan.
        // Di rewşa nîşanderê qelew de, bi cîbicîkirina dîzayna nîşanderê qelew ê nuha, qada yekem a pêşêkerê wusa her gav nîşana daneyê ye, ku bi heman rengî tê veqetandin.
        //
        unsafe { *thin = val };
        self
    }

    /// Bêyî ku wê bar bike nirxa ji `self` dixwîne.
    /// Ev di `self` de bîranînê bê guhertin dihêle.
    ///
    /// Ji bo fikar û nimûneyên ewlehiyê li [`ptr::read`] binêrin.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // EWLEHIY: : bangker divê peymana ewlehiyê ya `read` biparêze.
        unsafe { read(self) }
    }

    /// Bêyî ku ew bilivîne ji `self`-ê xwendinek berbiçav pêk tîne.Ev di `self` de bîranînê bê guhertin dihêle.
    ///
    /// Operasyonên berbiçav têne armanc kirin ku li ser bîranîna I/O tevbigerin, û garantî ne ku ji hêla berhevkar ve li seranserê din ên kirrûbirrîn neyên elî kirin an ji nû de sererast kirin.
    ///
    ///
    /// Ji bo fikar û nimûneyên ewlehiyê li [`ptr::read_volatile`] binêrin.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // EWLEHIY: : bangker divê peymana ewlehiyê ya `read_volatile` biparêze.
        unsafe { read_volatile(self) }
    }

    /// Bêyî ku wê bar bike nirxa ji `self` dixwîne.
    /// Ev di `self` de bîranînê bê guhertin dihêle.
    ///
    /// Berevajî `read`, dibe ku nîşander bêserûber be.
    ///
    /// Ji bo fikar û nimûneyên ewlehiyê li [`ptr::read_unaligned`] binêrin.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // EWLEHIY: : bangker divê peymana ewlehiyê ya `read_unaligned` biparêze.
        unsafe { read_unaligned(self) }
    }

    /// `count * size_of<T>` byte ji `self` bo `dest` kopî dike.
    /// Çavkanî û cîh dibe ku li hevûdu bikin.
    ///
    /// NOTE: ev rêzika argumana * eynî wekî [`ptr::copy`] heye.
    ///
    /// Ji bo fikar û nimûneyên ewlehiyê li [`ptr::copy`] binêrin.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // EWLEHIY: : bangker divê peymana ewlehiyê ya `copy` biparêze.
        unsafe { copy(self, dest, count) }
    }

    /// `count * size_of<T>` byte ji `self` bo `dest` kopî dike.
    /// Çavkanî û cîh dibe ku * li hev neke.
    ///
    /// NOTE: ev rêzika argumana * eynî wekî [`ptr::copy_nonoverlapping`] heye.
    ///
    /// Ji bo fikar û nimûneyên ewlehiyê li [`ptr::copy_nonoverlapping`] binêrin.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // EWLEHIY: : bangker divê peymana ewlehiyê ya `copy_nonoverlapping` biparêze.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Dabeşandina ku hewce ye ku li ser nîşander were sepandin hesab dike da ku wê li `align` bike yek.
    ///
    /// Heke ne gengaz be ku rêzkerê rêz bikin, pêkanîn `usize::MAX` vedigerîne.
    /// Ew ji bo pêkanînê ku her gav * `usize::MAX` vegerîne destûr e.
    /// Tenê performansa algorîtmaya we dikare li ser bingeha ku li vir veguherînek bikêr tê, ne rastbûna wê.
    ///
    /// Offset di hejmara hêmanên `T` de, û ne byte, tê derbirîn.Nirxa vegerandî dikare bi rêbaza `wrapping_add` were bikar anîn.
    ///
    /// Çi garantî tune ku tixûbdarkirina nîşanker dê zêde nebe an ji dabeşkirina ku nîşander nîşan dide derbas bibe.
    ///
    /// Li ser bangawazî ye ku piştrast bike ku tezmînata ku hatî vegerandin di hemî waran de ji xêzkirinê ve rast e.
    ///
    /// # Panics
    ///
    /// Fonksiyona panics heke `align` ne hêz-du-yek be.
    ///
    /// # Examples
    ///
    /// Wekî `u16` xwe digihînin `u8` cîran
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // dema ku nîşangir dikare bi rêya `offset` were rêz kirin, ew ê derveyî veqetandinê nîşan bide
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // EWLEHIYA: `align` hate kontrol kirin ku li jor hêza 2 be
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// Dirêjahiya perçek rawe vedigerîne.
    ///
    /// Nirxa vegeriyanî hejmar **hêman** e, ne jimara byte ye.
    ///
    /// Ev fonksiyon ewle ye, her çend dema ku perçeya xav nikare were avêtin ser referansek perçeyê ji ber ku pêşnumayek pûç e an jî nerastkirî ye.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // EWLEH: : ev ewledar e ji ber ku `*const [T]` û `FatPtr<T>` nexşeya wan yek e.
            // Tenê `std` dikare vê garantiyê bike.
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Pointerek raweyî vedigerîne tampona perçeyê.
    ///
    /// Ev wekhev e ku `self` bi `*const T` were avêtin, lê bêtir bi ewle-tîpî.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// Bêyî ku kontrolkirina sînoran bike, pêşekek raweyek vedigerîne ser hêmanek an jêrîn.
    ///
    /// Bangkirina vê rêbazê bi navnîşek derveyî sînor an dema ku `self` dereferencable nine *[tevgera nediyarkirî]* be jî heke nîşanderê encamek neyê bikar anîn.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // EWLEHIYE: bangker piştrast dike ku `self` dereferencable û `index` li sînor e.
        unsafe { index.get_unchecked(self) }
    }

    /// `None` vedigerîne heke pointer vala ye, an na qatek parvekirî vedigerîne nirxa ku di `Some` de pêçayî ye.
    /// Berevajî [`as_ref`], ev hewce nake ku nirx bi dest pê bike.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Dema ku bang li vê rêbazê dikin, divê hûn piştrast bikin ku *yan* nîşander NULL * e an jî hemî jêrîn rast e:
    ///
    /// * Pêdivî ye ku nîşanker ji bo `ptr.len() * mem::size_of::<T>()` gelek byte [valid] be, û divê ew bi rêkûpêk were rêz kirin.Ev bi taybetî tê vê wateyê:
    ///
    ///     * Pêdivî ye ku tevahiya bîranîna vê perçeyê di nav yek tiştê veqetandî de hebe!
    ///       Slices carî nikare li seranserê gelek tiştên veqetandî dorpêç bike.
    ///
    ///     * Pêdivî ye ku nîşander ji bo perçeyên dirêjahiya sifir jî werin rêz kirin.
    ///     Sedemek vê yekê ev e ku optimîzasyonên nexşeya enumê dibe ku xwe bispêre referansan (di nav wan de perçên her dirêjahiyê jî jî hene) hevgirtî û ne-null da ku wan ji daneyên din cuda bike.
    ///
    ///     Hûn dikarin pêşnumayek ku wekî `data` ji bo pelikên sifir-dirêje [`NonNull::dangling()`] bikar tîne bikar bînin.
    ///
    /// * Pêdivî ye ku mezinahiya tevahî `ptr.len() * mem::size_of::<T>()` ya perçeyê ji `isize::MAX` ne mezintir be.
    ///   Belgeya ewlehiyê ya [`pointer::offset`] bibînin.
    ///
    /// * Pêdivî ye ku hûn qaîdeyên aliasing ên Rust bicîh bînin, ji ber ku jiyana vegerandî `'a` bi keyfî tête bijartin û ne hewce ye ku jiyana rastîn a daneyê nîşan bide.
    ///   Bi taybetî, ji bo dirêjahiya vê heyatê, divê bîranîna ku nîşangir nîşan dide divê neguhere (ji bilî hundurê `UnsafeCell`).
    ///
    /// Ev encam digire heke encama vê rêbazê neyê bikar anîn!
    ///
    /// [`slice::from_raw_parts`][] jî bibînin.
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // EWLEHIY: : bangker divê peymana ewlehiyê ya `as_uninit_slice` biparêze.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// Ji bo nîşangiran wekhevî
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// Berawirdkirina nîşangiran
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}