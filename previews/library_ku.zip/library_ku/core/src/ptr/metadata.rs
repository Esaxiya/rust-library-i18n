#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Cûreyek metadata pointerê ji her celebê nîşankirî peyda dike.
///
/// # Metadata pointer
///
/// Di Rust de cûreyên nîşangir ên rawe û celebên referansê dikare wekî du beşan were fikirîn:
/// pêşnumayek daneyê ku navnîşana bîrayê ya nirxê, û hin metadata vedigire.
///
/// Ji bo celebên bi statîstîkî-mezinahî (ku `Sized` traits bicîh dikin) û her weha ji bo celebên `extern`, ji nîşanker re "tenik" tê gotin: metadata sifir-sized e û celebê wê `()` ye.
///
///
/// Nîşaneyên [dynamically-sized types][dst] têne gotin ku "fireh" an "qelew" in, ew xwediyê metadata ne sifir-mezinahî ne:
///
/// * Ji bo darbestên ku qada wan a dawî DST ye, metadata metadata ji bo qada paşîn e
/// * Ji bo celebê `str`, metadata dirêjahiya byte wekî `usize` e
/// * Ji bo celebên perçeyên mîna `[T]`, metadata dirêjahiya di tiştan de wekî `usize` e
/// * Ji bo tiştên trait mîna `dyn SomeTrait`, metadata [`DynMetadata<Self>`][DynMetadata] e (mînak `DynMetadata<dyn SomeTrait>`)
///
/// Di future de, dibe ku zimanê Rust cûreyên nû yên ku bi metadata nîşanderê cûda ne bi dest bixe.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Xala vê trait tîpa `Metadata` ya têkildar e, ku `()` an `usize` an `DynMetadata<_>` e ku li jor hatî vegotin.
/// Ew bixweber ji bo her cûreyê tê pêkanîn.
/// Ew dikare bête pejirandin ku di çarçoveyek gelemperî de, bêyî ku pêwendiyek pêwendîdar jî were pêkanîn.
///
/// # Usage
///
/// Nîşaneyên raweyan dikarin bi rêbaza [`to_raw_parts`] di navnîşana daneyê û pêkhateyên metadata de werin veqetandin.
///
/// Wekî din, bi tenê metadata dikare bi fonksiyona [`metadata`] ve were derxistin.
/// Çavkaniyek dikare ji [`metadata`] re were derbas kirin û bi zorê bête zor kirin.
///
/// Nîşanek (possibly-wide) dikare ji navnîşan û metadata xwe ya bi [`from_raw_parts`] an [`from_raw_parts_mut`] paşve were danîn.
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Di nîşanker û referansên `Self` de ji bo metadata celeb.
    #[lang = "metadata_type"]
    // NOTE: trait bounds li `static_assert_expected_bounds_for_metadata` bigirin
    //
    // li `library/core/src/ptr/metadata.rs` bi yên li vir re di nav hevrêziyê de:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Nîşaneyên li ser celebên ku ev nasnava trait pêk tînin "zirav" in.
///
/// Ev celebên statîk-"Mezin" û celebên `extern` vedigire.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: vê yekê aram nekin berî ku navnîşên trait di zimên de stabîl in?
pub trait Thin = Pointee<Metadata = ()>;

/// Hêmana metadata ya pointerê derxînin.
///
/// Nirxên celebê `*mut T`, `&T`, an `&mut T` dikarin rasterast ji vê fonksiyonê re bêne derbas kirin ji ber ku ew bi neçarî `* const T` zorê dikin.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // EWLEH: : Ji gihîştina nirxa ji yekîtiya `PtrRepr` ji ber ku * const T ewle ye
    // û PtrComponents<T>heman rêzikên bîranînê hene.
    // Tenê std dikare vê garantiyê bike.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Ji navnîşana danûstendinê û metadata nîşangirek xav (possibly-wide) çêdike.
///
/// Ev fonksiyon ewle ye lê nîşanderê vegeriyayî ne pêdivî ye ku ji dereferê ewledar be.
/// Ji bo slices, ji bo hewceyên ewlehiyê belgekirina [`slice::from_raw_parts`] bibînin.
/// Ji bo tiştên trait, pêdivî ye ku metadata ji nîşangirekê bi eynî tîpî zêdebûyî ya bingehîn were.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // EWLEH: : Ji gihîştina nirxa ji yekîtiya `PtrRepr` ji ber ku * const T ewle ye
    // û PtrComponents<T>heman rêzikên bîranînê hene.
    // Tenê std dikare vê garantiyê bike.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Çawa ku [`from_raw_parts`] heman fonksiyonelê pêk tîne, ji xeynî ku pêşnumayek `*mut` ya xav vedigere, berevajî pêşnumaya `* const` ya xav.
///
///
/// Ji bo bêtir agahdariyê belgekirina [`from_raw_parts`] bibînin.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // EWLEH: : Ji gihîştina nirxa ji yekîtiya `PtrRepr` ji ber ku * const T ewle ye
    // û PtrComponents<T>heman rêzikên bîranînê hene.
    // Tenê std dikare vê garantiyê bike.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Pêdivî ye ku ji bo `T: Copy` neçar bimîne pêdivî ye.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Pêdivî ye ku ji bo `T: Clone` neçar bimîne pêdivî ye.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Metadata ji bo celebek tiştê `Dyn = dyn SomeTrait` trait.
///
/// Ew nîşangirek ji vtable re ye (maseya banga virtual) ku hemî agahdariya hewce dike ku ji bo manipulkirina celebê betonî yê ku di hundurê tiştê trait de hatî veşartin temsîl dike.
/// Vtable bi taybetî ew tê de:
///
/// * size size
/// * aligning type
/// * pêşnumayek ji bo implsa `drop_in_place` ya tîpî (dibe ku ji bo daneyên hêsan-kevn qedexe be)
/// * ji bo pêkanîna celebê trait hemî rêbazan nîşan dide
///
/// Bala xwe bidinê ku sêyên yekem taybetî ne ji ber ku ew hewce ne ku ji bo dabeşkirin, daketin û veqetandina her tiştê trait.
///
/// Gengaz e ku meriv navê vê strukturekê bi parametreyek tîpî bide ku ew ne objeyek `dyn` trait ye (bo nimûne `DynMetadata<u64>`) lê nirxek watedar a wê struktura neyê stendin.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Pêşgîra hevpar a hemî vtebelan.Ew ji hêla rêbazên fonksiyonê ve ji bo rêbazên trait tê şopandin.
///
/// Detaliya pêkanîna taybet a `DynMetadata::size_of` hwd.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Mezinahiya tîpa bi vê vtable ve têkildar vedigerîne.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Rêzkirina celebê bi vê vtable ve girêdayî vedigere.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Mezinahî û lihevnêzîkbûnê bi hev re wekî `Layout` vedigerîne
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // EWLEH: berhevkar vê vtableyê ji bo celebek betonî ya Rust ku weşandî derxist
        // tê zanîn ku xwedan pêşnumayek derbasdar e.Heman aqilane wekî `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Ji bo ku ji sînorên `Dyn: $Trait` dûr nekevin, pêdivî ye ku destnişan werin dayîn.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}