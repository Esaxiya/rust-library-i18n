//! Piştgiriya Panic ji bo libcore
//!
//! Pirtûkxaneya bingehîn nikare panîkê diyar bike, lê ew *panîk* îlan dike.
//! Ev tê vê wateyê ku fonksiyonên di hundurê libcore de ji panic re têne destûr kirin, lê ji bo ku kêrhatî be divê crate ya berjêr panîkê ji bo libcore bikar bîne diyar bike.
//! Navnîşa heyî ya ji bo panîkê ev e:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Vê pênaseyê panîk bi her peyamek gelemperî re dihêle, lê ew rê nade ku bi nirxek `Box<Any>` têk biçin.
//! (`PanicInfo` tenê `&(dyn Any + Send)` vedigire, ji bo ku em di `PanicInfo: : nav_konstruktor` de nirxek dumanî dagirin.) Sedema vê yekê ev e ku destûr nayê dayîn ku libcore were veqetandin.
//!
//!
//! Di vê modulê de çend fonksiyonên panîkê yên din jî hene, lê ev ji bo berhevkar tenê tiştên lang ên hewce ne.Hemî panics bi vê fonksiyona yek têne rêve kirin.
//! Sembola rastîn bi navgîniya `#[panic_handler]` ve tê ragihandin.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Dema ku formatkirin neyê bikar anîn bingeha pêkanîna makroya `panic!` ya libcore.
#[cold]
// heya panic_immediate_abort qet nekevin rêzê ku li malperên bangê qasî ku mimkûn e ku hûn ji kodê neherin
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // ji hêla codegen ve ji bo panic li ser zêdebûnê û termînatorên din ên `Assert` MIR hewce ne
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Li şûna format_args Arguments::new_v1 bikar bînin! ("{}}, Expr) da ku potansiyelî serê jorîn kêm bikin.
    // Format_args!makro Display trait ya str bikar tîne da ku expr binivîse, ku Formatter::pad bang dike, ku pêdivî ye ku jêkirina string û padding were cih (tevî ku li vir çu yek nayê bikar anîn).
    //
    // Bikaranîna Arguments::new_v1 dikare bihêle ku berhevkar Formatter::pad ji binaryê ya derketinê veqetîne, heya çend kilobayîtan bide hev.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // ji bo panics-ê tête-nirxandin pêdivî ye
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // ji hêla codegen ve ji bo panic li ser gihîştina OOB array/slice pêdivî ye
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Dema ku formatkirin tê bikar anîn bingeha pêkanîna makroya `panic!` ya libcore.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // HIYAR This Ev fonksiyon qet sînorê FFI derbas nake;ew bangawaziyek Rust-to-Rust ye ku bi fonksiyona `#[panic_handler]` çareser dibe.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // EWLEH: `panic_impl` di koda ewlehiya Rust de tête diyar kirin û ji ber vê yekê bangkirina ewledar e.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Fonksiyona navxweyî ji bo makroyên `assert_eq!` û `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}