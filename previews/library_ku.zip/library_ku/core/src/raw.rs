#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Ji bo danasîna celebên berhevkar ên avaker pênasnameyên strukturel vedihewîne.
//!
//! Ew dikarin wekî hedefên veguherînan di koda ne ewle de werin bikar anîn da ku rasterast nûneriyên raweyê manipûle bikin.
//!
//!
//! Divê pênaseya wan her dem bi ABI ya ku di `rustc_middle::ty::layout` de hatî diyarkirin re hevbîr be.
//!

/// Nûneratiya tiştek trait mîna `&dyn SomeTrait`.
///
/// Damezrandina vê strukturê wekî celebên mîna `&dyn SomeTrait` û `Box<dyn AnotherTrait>` heye.
///
/// `TraitObject` misogerkirî ye ku lihevrastkirinan li hev bike, lê ew ne celebê tiştên trait ye (mînakî, qadên li ser `&dyn SomeTrait` rasterast negihîşt in) û ne jî wê venêranê kontrol dike (guhertina pênaseyê dê nexşeya `&dyn SomeTrait` neguhere).
///
/// Ew tenê tête sêwirandin ku ji hêla kodek ne ewle ve tê bikar anîn ku hewce dike ku hûrguliyên asta nizm manîpule bike.
///
/// Çu çare tune ku meriv bi gistî serî li hemî tiştên trait bide, lewma awayê tenê yê afirandina nirxên vî rengî bi fonksiyonên mîna [`std::mem::transmute`][transmute] e.
/// Bi heman rengî, awayê yekane ku ji hêjayiyek `TraitObject` ji trait re tiştek çêbike bi `transmute` e.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Sentezkirina hêmanek trait bi cûreyên lihevnekirî-yek ku vtable bi celebê nirxê ku nîşanderê daneyê jê re nîşan dike re têkildar nabe-pir bi îhtîmal e ku bibe sedema tevgereke nediyarkirî.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // mînakek trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // bila berhevkar objeyek trait çêbike
/// let object: &dyn Foo = &value;
///
/// // li temsîla xav binihêrin
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // nîşana daneyê navnîşana `value` ye
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // Tiştek nû çêbikin, `i32` cûda nîşan bidin, hay ji xwe hebin ku `i32` vtable ji `object` bikar bînin
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // pêdivî ye ku ew bixebite mîna ku me ji `other_value` rasterast tiştek trait çêkiribe
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}