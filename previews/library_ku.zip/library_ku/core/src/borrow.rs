//! Modulek ji bo xebata bi daneyên deynkirî.

#![stable(feature = "rust1", since = "1.0.0")]

/// Ji bo dane kirina deyn trait.
///
/// Di Rust de, gelemperî ye ku ji bo rewşên karanîna cûda cûda cûreyên cuda têne pêşkêş kirin.
/// Mînakî, cîhê hilanînê û rêveberiya ji bo nirxek dikare bi taybetî ji bo karanîna taybetî bi navgîniya cûreyên pointer ên wekî [`Box<T>`] an [`Rc<T>`] wekî guncan were hilbijartin.
/// Ji derveyî van pêçikên gelemperî yên ku bi her celebî dikarin werin bikar anîn, hin celeb rûyên vebijarkî peyda dikin ku karbidestên potansiyel lêçûyî peyda dikin.
/// Mînakek ji bo celebek weha [`String`] e ku kapasîteya dirêjkirina têlek li [`str`]-ya bingehîn zêde dike.
/// Vê pêdivî ye ku agahdariya pêvek ji bo têlek sade, neguhêzbar ne hewce be.
///
/// Van celeb bi navgîniya referansên li ser celebê wan daneyan gihîştina daneyên bingehîn peyda dikin.Tête gotin ku ew celeb wekî 'hatine deyn kirin'.
/// Mînakî, [`Box<T>`] dikare wekî `T` were deyn kirin lê [`String`] dikare wekî `str` were deyn kirin.
///
/// Cûre diyar dikin ku ew bi pêkanîna `Borrow<T>` wekî hin cûreyên `T` têne deyn kirin, di rêbaza [`borrow`] ya trait de referansek ji bo `T` peyda dikin.Celebek wekî çend celebên cûda belaş deyn dike.
/// Heke ew bixwaze ku bi mutabaqî wekî celeb deyn bike-bihêle ku daneyên bingehîn werin guhertin, ew dikare bi [`BorrowMut<T>`]-ê re jî bicîh bike.
///
/// Wekî din, dema ku sepandinên ji bo traits-yên din têne peyda kirin, pêdivî ye ku were nerîn ka gelo ew neçar in ku bi wan ên ji celebê bingehîn re wekhev tevbigerin ji ber ku ji ber ku ew wekî temsîla wî celebê bingehîn tevdigerin.
/// Koda gelemperî bi gelemperî `Borrow<T>` bikar tîne dema ku xwe dispêre tevgera yeksan a van pêkanînên trait yên din.
/// Dê van traits wekî trait bounds-yên din xuya bibin.
///
/// Bi taybetî `Eq`, `Ord` û `Hash` divê ji bo nirxên deyn û xwedan wekhev bin: `x.borrow() == y.borrow()` divê heman encam wekî `x == y` bide.
///
/// Heke koda gelemperî tenê hewce dike ku ji bo her cûreyên ku dikarin referansek bi celebê têkildar `T` re peyda bikin bixebitin, ew timûtim çêtir e ku meriv [`AsRef<T>`] bikar bîne ji ber ku celebên din dikarin bi ewlehî wê bicîh bikin.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Wekî berhevkirina daneyê, [`HashMap<K, V>`] xwedan hem keys û hem nirxan e.Ger daneya rastîn a mifteyê di celebek rêveberiyê de hatibe pêçandin, lêbelê, ew hîn jî gengaz e ku meriv li nirxek bi karanîna referansek daneyên mifteyê geriyan.
/// Mînakî, heke mifteyek têl be, wê hingê ew bi nexşeya hash wekî [`String`] tê hilanîn, dema ku pêdivî ye ku hûn bi karanîna [`&str`][`str`] lêgerîn bikin.
/// Ji ber vê yekê, `insert` hewce dike ku li ser `String` bixebite dema ku `get` hewce ye ku karibe `&str` bikar bîne.
///
/// Hinekî hêsan kirin, beşên têkildar ên `HashMap<K, V>` wiha xuya dikin:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // zeviyên jêbirin
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Nexşeya tevahî hash li ser celebek key `K` gelemperî ye.Ji ber ku ev keys bi nexşeya hash hatine hilanîn, pêdivî ye ku ev celeb xwediyê daneyên mifteyê be.
/// Gava ku têxe cotek key-nirx, nexşeyek bi vî rengî `K` tê dayîn û pêdivî ye ku hebek rastîn a heş bibîne û kontrol bike ka mifte li gorî wê `K` heye an na.Ji ber vê yekê ew `K: Hash + Eq` hewce dike.
///
/// Gava ku hûn li nexşeyê li nirxek digerin, lêbelê, pêdivî ye ku hûn referansek li `K` wekî kilîta lêgerînê peyda bikin ku hewce bike ku her dem nirxek xwedan wusa çêbikin.
/// Ji bo kilîtên têlan, ev tê wê wateyê ku pêdivî ye ku nirxek `String` tenê ji bo lêgerîna dozên ku tenê `str` heye, were afirandin.
///
/// Di şûna wê de, rêbaza `get` li ser celebê daneya sereke ya bingehîn, ku li jorîn di îmzeya rêbazê de `Q` tê gotin, gelemperî ye.Ew diyar dike ku `K` wekî `Q` hewce dike ku ew `K: Borrow<Q>` hewce dike.
/// Bi zêdeyî pêdiviya `Q: Hash + Eq`, ew îşaret dike ku pêdivî ye ku `K` û `Q` xwedî pêkanînên `Hash` û `Eq` traits bin ku encamên yeksan didin.
///
/// Pêkanîna `get` bi taybetî bi pêkanînên yeksan ên `Hash` ve girêdayî ye ku bi diyarkirina kepçeya heşîşê ya kilît bi bangkirina `Hash::hash` re li ser nirxê `Q` her çend ew kilîta li gorî nirxa hash a ji nirxa `K` hatî hesibandin têxe jî.
///
///
/// Wekî encamek, heke nexşeya `K` pêça nirxek `Q` ji `Q`-an heşekek cuda hilberîne, nexşeya hash dişikîne.Mînakî, xiyal bikin ku celebek we heye ku têlek pêça, lê tîpên ASCII li ber rewşa wan paşguh dike:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Ji ber ku du nirxên wekhev hewce ne ku heman nirxa hash hilberînin, pêkanîna `Hash` hewce dike ku rewşa ASCII jî paşguh bike:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// `CaseInsensitiveString` dikare `Borrow<str>` bicîh bîne?Ew bê guman dikare bi navgîniya têlika xwedan xwediyê wê ve referansek li ser perçek têl peyda bike.
/// Lê ji ber ku pêkanîna `Hash` ciyawaz e, ew ji `str` cûda tevdigere û ji ber vê yekê divê, bi rastî, `Borrow<str>` bicîh neke.
/// Heke ew dixwaze destûrê bide yên din ku bigihîjin `str` ya bingehîn, ew dikare wiya bi `AsRef<str>` bike ku hewcehiyên zêde nagire.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Bi neguhêzbar ji nirxek xwedan deyn dike.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// trait ji bo danûstandina bihevra deynkirin.
///
/// Wekî hevparê [`Borrow<T>`] ev trait dihêle ku celebek wekî celebek bingehîn deyn bike bi pêşkêşkirina referansek guhêrbar.
/// Ji bo bêtir agahdariya li ser deyn wekî celebek din li [`Borrow<T>`] binêrin.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Bi guherbar ji nirxek xwedan deyn dike.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}