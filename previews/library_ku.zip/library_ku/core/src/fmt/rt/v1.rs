//! Ev modulek navxweyî ye ku ji hêla ifmt ve tê bikar anîn!demjimêr.Van avahiyan li rêzikên statîk têne weşandin da ku têlên formatên pêşwext berhev bikin.
//!
//! Van danasînan dişibihin hevwateyên wan ên `ct`, lê ji ber ku ew dikarin bi statîkî bên veqetandin û ji bo dema xebitandinê hinekî çêtirîn ji hev cûdane.
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Rêzkirinên gengaz ên ku dikarin wekî beşek rêwerziya formatkirinê werin xwestin.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Nîşan dan ku divê naverok li gorî çepê werin rêz kirin.
    Left,
    /// Nîşan dan ku divê naverok rast-rast werin.
    Right,
    /// Nîşan dan ku naverok divê li navendî-yekkirî be.
    Center,
    /// Rêzkirin nehat xwestin.
    Unknown,
}

/// Ji hêla diyarkerên [width](https://doc.rust-lang.org/std/fmt/#width) û [precision](https://doc.rust-lang.org/std/fmt/#precision) ve tê bikar anîn.
#[derive(Copy, Clone)]
pub enum Count {
    /// Bi hejmarek rastnivîsandî tête diyar kirin, nirxê tomar dike
    Is(usize),
    /// Bikaranîna hevoksazên `$` û `*` têne diyar kirin, navnîşê di nav `args` de tomar dike
    Param(usize),
    /// Nehatiye diyarkirin
    Implied,
}