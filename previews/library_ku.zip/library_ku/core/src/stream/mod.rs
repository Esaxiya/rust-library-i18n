//! Dubareya asînronî ya pêkhatî.
//!
//! Ger futures nirxên asynkronî ne, wê hîngê herikîn tekrarkerên asinkron in.
//! Ger we xwe bi rengek berhevokek asinkron dît, û hewce be ku hûn li ser hêmanên berhevoka gotî operasyonekê pêk bînin, hûn ê bilez bikevin 'streams'.
//! Streams di koda Rust idiomatic asynchronous de pir têne bikar anîn, ji ber vê yekê hêja ye ku hûn bi wan nas bibin.
//!
//! Berî ku bêtir şirove bike, ka em li ser awayê sazkirina vê modulê biaxifin:
//!
//! # Organization
//!
//! Ev modul bi piranî ji hêla celeb ve hatî saz kirin:
//!
//! * [Traits] beşa bingehîn in: ev traits diyar dikin ka çi celeb herik hene û hûn dikarin bi wan re çi bikin.Rêbazên van traits hêjayî ye ku meriv demek xwendinê ya zêde têxe nav.
//! * Fonksiyon ji bo afirandina hin herikên bingehîn çend awayên alîkar peyda dikin.
//! * Structs bi gelemperî li ser traits-a vê modulê celebên vegerandina cûrbecûr rêbazan in.Hûn ê bi gelemperî bixwazin li şûna `struct` bixwe li rêbaza ku `struct` diafirîne binêrin.
//! Ji bo hûrgulî li ser çima, li '[Pêkanîna Rêzê](#pêkanîn-pêl)' binihêrin.
//!
//! [Traits]: #traits
//!
//! Her eve!Ka em herikan bikolin.
//!
//! # Stream
//!
//! Dil û giyanê vê modulê [`Stream`] trait ye.Bingeha [`Stream`] wiha xuya dike:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Berevajî `Iterator`, `Stream` cûdahiyê dixe navbera rêbaza [`poll_next`] ku dema cîbicîkirina `Stream` tê bikar anîn, û rêbaza (to-be-implemented) `next` ku dema xerckirina herikekê tê bikar anîn.
//!
//! Bikarhênerên `Stream` tenê hewce ne ku `next` bifikirin, ku gava tê bang kirin, future vedigere ku `Option<Stream::Item>` dide.
//!
//! future ku ji hêla `next` ve vegeriyaye heya ku hêman hebin wê `Some(Item)` bide, û gava ku ew hemî xilas bûn, dê `None` bide da ku diyar bike ku dûbarekirin qediyaye.
//! Ger em li bendê ne ku tiştek asynkron were çareser kirin, future dê bisekine ta ku çem amade be ku dîsa bide.
//!
//! Dibe ku herikên takekesî hilbijêrin ku dubarekirinê ji nû ve dest pê bikin, û ji ber vê yekê bangkirina `next` dîsa dibe ku di demekê de dîsa `Some(Item)` bide.
//!
//! Danasîna tevahî ya ["Stream`] gelek rêbazên din jî hene, lê ew rêbazên nehf in, li ser [`poll_next`] hatine çêkirin, û ji ber vê yekê hûn wan belaş digirin.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Pêkanîna Stream
//!
//! Afirandina herikînek ji xwe re du gavan digire nav xwe: `struct` diafirîne da ku dewleta çemê bigire, û dûv re jî [`Stream`] ji bo wê `struct` bicîh tîne.
//!
//! Ka em bi navê `Counter` herikek çêbikin ku ji `1` heya `5` jimartiye:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Ya yekem, damezrandin:
//!
//! /// Çemek ku ji yekê heya pênc hejmar tê hesibandin
//! struct Counter {
//!     count: usize,
//! }
//!
//! // em dixwazin jimartina me ji yekê dest pê bike, ji ber vê yekê em bila rêbaza new() zêde bikin ku bibe alîkar.
//! // Ev ne zor hewce ye, lê hêsan e.
//! // Zanibe ku em `count` di sifirê de dest pê dikin, em ê bibînin ka çima li jêr pêkanîna `poll_next()`'s.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Wê hingê, em ji bo `Counter` xwe `Stream` bicîh dikin:
//!
//! impl Stream for Counter {
//!     // em ê bi karanîna hejmar bihesibînin
//!     type Item = usize;
//!
//!     // poll_next() tenê rêbazek pêdivî ye
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Hejmara me zêde bikin.Ji ber vê yekê me di sifirê de dest pê kir.
//!         self.count += 1;
//!
//!         // Kontrol bikin ka em jimartinê xilas kirine an na.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Çem *lal in*.Ev tê vê wateyê ku tenê çêkirina herikek bi tevahî _do_ nake.Tiştek bi rastî çê nabe heya ku hûn bangî `next` nekin.
//! Gava ku herikek tenê ji bo bandorên wê diafirîne ev carinan çavkaniya tevliheviyê ye.
//! Berhevkar dê di derheqê vî rengî reftarê de me hişyar bike:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;