use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Navgînek ji bo danûstendina bi veberhênerên asinkron.
///
/// Ev herika sereke trait ye.
/// Ji bo bêtir li ser têgeha herikên gelemperî, ji kerema xwe [module-level documentation] bibînin.
/// Bi taybetî, dibe ku hûn dixwazin fêr bibin çawa [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Cûreyek tiştên ku ji hêla çemê ve têne hilberandin.
    type Item;

    /// Hewil bidin ku nirxa paşîn a vê herikê derxînin, heke ku hêjayî wê tune be ji bo şiyarkirinê qeydkirina peywira heyî, û heke herik xilas bû `None` vegerînin.
    ///
    /// # Nirxê vegerînin
    ///
    /// Gelek nirxên vegera gengaz hene, her yek dewletek cûda diyar dike:
    ///
    /// - `Poll::Pending` tê vê wateyê ku nirxa paşîn a vê riyê hêj ne amade ye.Pêkanîn dê piştrast bikin ku dema nirxa pêşîn amade be dê peywira heyî were agahdarkirin.
    ///
    /// - `Poll::Ready(Some(val))` tê wê wateyê ku herika bi serfirazî nirxek, `val`, hilberandiye û dibe ku li ser bangên paşê `poll_next` nirxên din jî hilberîne.
    ///
    /// - `Poll::Ready(None)` tê wateya ku herikîn bi dawî bûye, û pêdivî ye ku `poll_next` dîsa neyê vexwendin.
    ///
    /// # Panics
    ///
    /// Gava ku herikek xilas bû (`Ready(None)` from `poll_next`) lê vegeriya, gazî rêbaza `poll_next` dike dîsa dibe panic, heya hetayê bloke bike, an bibe sedema celebên din ên pirsgirêkan; `Stream` trait li ser bandorên bangek wusa hewce nake.
    ///
    /// Lêbelê, ji ber ku rêbaza `poll_next` bi `unsafe` nehatiye nîşankirin, rêzikên asayî yên Rust derbasdar in: bang divê çu carî nebe sedema reftara nediyarkirî (gendeliya bîranînê, karanîna çewt a fonksiyonên `unsafe`, an jî mîna wan), bêyî ku rewşa çemê hebe.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Sînorên li ser dirêjahiya mayî ya herikê vedigerîne.
    ///
    /// Bi taybetî, `size_hint()` tûpek vedigerîne ku hêmana yekem biniya jêrîn e, û hêmana duyemîn girêka jorîn e.
    ///
    /// Nîvê duyemîn ê tupê ya ku vedigere ["Vebijêrk"] "<" ["bikar bîne"] "> e.
    /// A [`None`] li vir tê vê wateyê ku yan bendek jorîn a naskirî tune, an jî girêka jorîn ji [`usize`] mezintir e.
    ///
    /// # Nîşeyên tetbîqkirinê
    ///
    /// Nayê sepandin ku pêkanîna herikînek jimareya hêmanên ragihandî dide.Çemek buggy dikare ji bendika jêrîn an ji bendera jorîn ya hêmanan kêmtir bide.
    ///
    /// `size_hint()` di serî de armanc ew e ku ji bo optimizasyonên wekî veqetandina cîhê ji bo hêmanên rûkê were bikar anîn, lê pêdivî ye ku pê ewle nebin ku mînakî, venêranîna kontrolên sînoran di koda ne ewle de.
    /// Pêkanîna çewt a `size_hint()` divê nebe sedema binpêkirinên ewlehiya bîranînê.
    ///
    /// Wê got, pêdivî ye ku nirxandinek rast peyda bike, ji ber ku wekî din ew ê binpêkirina protokola trait be.
    ///
    /// Pêkanîna vedigere vedigere `(0,` ["None"] ")" ku ji bo her tiştî rast e.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}