//! Nirxên lazy û destpêkirina yek-carî ya daneyên statîk.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// Cellaneyek ku tenê carekê dikare were nivîsandin.
///
/// Berevajî `RefCell`, `OnceCell` tenê referansên parvekirî `&T` ji nirxa xwe re peyda dike.
/// Berevajî `Cell`, `OnceCell` ji bo gihîştina wê nirxê kopî kirin an şûna wê hewce nake.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // Neguhêrbar: herî zêde carekê ji bo wê hatiye nivîsandin.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// Cellaneyek vala ya nû diafirîne.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// Çavdêriya nirxa bingehîn dike.
    ///
    /// Ger şane vala be `None` vedigire.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // BELA: Ji ber neguhêrîna `hundir` ewle
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// Bi nirxa bingehîn re referansa mutable digire.
    ///
    /// Ger şane vala be `None` vedigire.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // BELAW: : Ewle ji ber ku gihiştina meya yekta heye
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// Naveroka şaneyê li `value` saz dike.
    ///
    /// # Errors
    ///
    /// Ger şane vala bû û `Err(value)` heke tijî bû ev rêbaza vedigerîne `Ok(())`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // BELAW: Ewledar e ji ber ku em nikarin deynên guhêrbar ên hevpişk hebin
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // EWLEH: : Ev der devera ku me lê hêlînê daniye, pêşbaz nîn e
        // ji ber reentrancy/concurrency gengaz e, û me seh kir ku hêdî hêdî `None` e, ji ber vê yekê ev nivîsîn `hundir` ê neguhêrbar diparêze.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// Naveroka şaneyê digire, heke şane vala bû wê bi `f` destnîşan dike.
    ///
    /// # Panics
    ///
    /// Ger `f` panics, panic li bangdêr tê belav kirin, û şaneyê bê unîter bimîne.
    ///
    ///
    /// Çewtiyek e ku meriv ji nû ve dest bi şaneyê ji `f` dike.Kirina vê yekê dibe sedema panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// Naveroka şaneyê digire, heke şane vala bû wê bi `f` destnîşan dike.
    /// Ger şane vala bû û `f` têk çû, xeletiyek tê vegerandin.
    ///
    /// # Panics
    ///
    /// Ger `f` panics, panic li bangdêr tê belav kirin, û şaneyê bê unîter bimîne.
    ///
    ///
    /// Çewtiyek e ku meriv ji nû ve dest bi şaneyê ji `f` dike.Kirina vê yekê dibe sedema panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // Zanibe ku *hin* formên destpêkirina reentrant dikare bibe UB (li testa `reentrant_init` binihêre).
        // Ez bawer dikim ku tenê rakirina vê `assert`, dema ku `set/get` tê hiştin dê xweş be, lê ji panic re çêtir xuya dike, ji dêvla ku bi bêdengî nirxek kevn bikar tîne.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// Hucreyê dixwe, nirxa pêçayî vedigerîne.
    ///
    /// Ger şane vala bû `None` vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // Ji ber ku `into_inner` bi nirxê `self` digire, berhevkar bi statîkî piştrast dike ku ew naha ne deynkirî ye.
        // Ji ber vê yekê ew ewledar e ku meriv `Option<T>` bar bike.
        self.inner.into_inner()
    }

    /// Nirxê ji vê `OnceCell` digire, wê vediguhêzîne dewletek nezanî.
    ///
    /// Heya ku `OnceCell` nehatiye destpêkirin ti bandor tune û vedigere `None`.
    ///
    /// Ewlehî ji hêla hewceyê referansa guhêrbar ve tête garantîkirin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// Nirxek ku li ser gihîştina yekem dest pê dike.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   destpêkirin amade ye
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// Bi fonksiyona danasînê ya dayînek nirxek nû ya lazîkî diafirîne.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// Nirxandina vê nirxa tembelî ferz dike û referansek li encam vedigerîne.
    ///
    ///
    /// Ev wekhevî ya `Deref` impl e, lê eşkere ye.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// Wekî fonksiyona destpêkirinê bi karanîna `Default` nirxek nû ya lazy diafirîne.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}