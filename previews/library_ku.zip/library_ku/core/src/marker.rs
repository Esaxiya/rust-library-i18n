//! traits-ya prîmîtîf û cûreyên ku taybetmendiyên bingehîn ên cûreyan temsîl dikin.
//!
//! Cûreyên Rust li gorî taybetmendiyên wan ên xwemalî bi gelek awayên bikêr têne dabeş kirin.
//! Van senifandinan wekî traits têne nimandin.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Cûreyên ku dikarin li ser sînorên têl werin veguheztin.
///
/// Dema ku berhevkar guncan dibîne ev trait bixweber tête bicîh kirin.
///
/// Mînakek ji celebek ne-``andin`` pêşnumaya hejmartina referansê [`rc::Rc`][`Rc`] e.
/// Heke du mijar hewl bidin ku [`Rc`]-yên ku bi heman nirxê referans-jimartî nîşan dikin klon bikin, dibe ku ew hewl bidin ku di heman demê de jimareya referansê nûve bikin, ku ew [undefined behavior][ub] e ji ber ku [`Rc`] karûbarên atomî bikar nayîne.
///
/// Pismamê wê [`sync::Arc`][arc] karûbarên atomî bikar tîne (hin serûbinî hev dike) û bi vî rengî `Send` e.
///
/// Ji bo bêtir agahdarî li [the Nomicon](../../nomicon/send-and-sync.html) binihêrin.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Cureyên bi mezinahiya domdar di dema berhevokê de têne zanîn.
///
/// Hemî pîvanên celebê bi `Sized` ve girêdayî bendek heye.Ger ne guncan be hevoksaziya taybetî `?Sized` dikare were bikar anîn ku vê bendê were rakirin.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struktur FooUse(Foo<[i32]>);//xelet: Mezinahî ji bo [i32] nayê pêkanîn
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Yek îstîsna tîpên nexşandî `Self` a trait ye.
/// trait ne xwediyê `Sized` nexuyayî ye ku ji ber ku ev bi [object trait]-yên ku ji hêla vegotinê ve, trait hewce dike ku bi hemî bicîhkerên gengaz re bixebite, naşibile, û bi vî rengî dikare her mezinahî be.
///
///
/// Her çend Rust dê bihêle ku hûn `Sized` bi trait ve girêbidin, hûn ê nekarin wê bikar bînin ku paşê trait çêbikin:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // bila y: Barê &dyn = &Impl;//xelet: trait `Bar` nikare bibe nesne
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // ji bo Default, ji bo nimûne, ku hewce dike ku `[T]: !Default` were nirxandin
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Cûreyên ku dikarin bibin "unsized" bi celebek dînamîk-mezin.
///
/// Mînakî, tîpa mezinahiya `[i8; 2]` `Unsize<[i8]>` û `Unsize<dyn fmt::Debug>` bicîh dike.
///
/// Hemî pêkanînên `Unsize` ji hêla berhevkar ve bixweber têne peyda kirin.
///
/// `Unsize` ji bo:
///
/// - `[T; N]` `Unsize<[T]>` e
/// - `T` dema `T: Trait` `Unsize<dyn Trait>` e
/// - `Foo<..., T, ...>` `Unsize<Foo<..., U, ...>>` e heke:
///   - `T: Unsize<U>`
///   - Foo strukturek e
///   - Tenê zeviya paşîn a `Foo` xwedan celebek e ku tê de `T`
///   - `T` ne beşek ji celebê warên din e
///   - `Bar<T>: Unsize<Bar<U>>`, heke qada paşîn a `Foo` xwediyê type `Bar<T>` be
///
/// `Unsize` li gel [`ops::CoerceUnsized`] tête bikar anîn ku destûr bide konteynerên "user-defined" yên wekî [`Rc`] celebên bi dînamîk-mezin.
/// Ji bo bêtir agahdariyê [DST coercion RFC][RFC982] û [the nomicon entry on coercion][nomicon-coerce] bibînin.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Ji bo domandinên ku di maçên nimûneyê de têne bikar anîn trait hewce dike.
///
/// Her celebek ku `PartialEq` jê werdigire vê trait bixweber bicîh tîne,*bêyî* ka-parametreyên wî celebî `Eq` bicîh dikin an na.
///
/// Ger hêmanek `const` hin celeb hebe ku vê trait pêk nayne, wê hingê ew type an (1.) `PartialEq` bicîh nayne (ku tê vê wateyê ku domdar wê rêbaza berawirdkirinê peyda nake, ya ku nifşê kodê texmîn dike ku heye), an (2.) ew *ya xwe bicîh tîne* Guhertoya `PartialEq` (ku em texmîn dikin ku li gorî berawirdek avahiya-wekheviyê nine).
///
///
/// Di her du senaryoyên li jor de, em karanîna domdariyek wusa di hevkêşek nimûneyê de red dikin.
///
/// [structural match RFC][RFC1445], û [issue 63438] jî binihêrin ku ji sêwirana bingeha taybetmendiyê koçberî vê trait kir.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Ji bo domandinên ku di maçên nimûneyê de têne bikar anîn trait hewce dike.
///
/// Her celebek ku `Eq` jê werdigire vê trait bixweber bicîh tîne,*bêyî* ka gelo parametreyên celebê wê `Eq` bicîh dikin.
///
/// Ev hackek e ku di pergala celebê me de li dor sînorkirinê dixebite.
///
/// # Background
///
/// Em dixwazin hewce bike ku celebên sazgehan di pêşbirkên nimûneyê de têne bikar anîn xwedan taybetmendiya `#[derive(PartialEq, Eq)]` be.
///
/// Di cîhanek îdealtir de, em dikarin wê hewcedariyê bi tenê kontrol bikin ku celebê dayîn hem `StructuralPartialEq` trait *û*`Eq` trait pêk tîne.
/// Lêbelê, hûn dikarin ADTyên *ku*`derive(PartialEq, Eq)` dikin hebin, û bibin dozek ku em dixwazin ku berhevkar bipejirîne, û dîsa jî celebê domdar `Eq` bicîh nayne.
///
/// Ango, dozek bi vî rengî:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Pirsgirêka di kodê jorîn de ev e ku `Wrap<fn(&())>` ne `PartialEq`, ne jî `Eq` bicîh nake, ji ber ku `ji bo <'a> fn(&'a _)` does not implement those traits.)
///
/// Ji ber vê yekê, em nikarin ji bo `StructuralPartialEq` û tenê `Eq` bisekinin kontrola naîf.
///
/// Wekî hackek ku li dora vê xebitîne, em du traits-ê cuda yên ku ji hêla her du deveran ve (`#[derive(PartialEq)]` û `#[derive(Eq)]`) hatine derzandin bikar tînin û kontrol dikin ku herdu jî wekî beşek ji venêrana sazûmanî-maç hene.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Cûreyên ku nirxên wan bi tenê bi kopîkirina bitan dikarin bên dubare kirin.
///
/// Bi default, girêdanên guhêrbar 'semantîka tevgerê hene.'Bi gotinên din:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` ketiye nav `y`, û ji ber vê yekê nayê bikar anîn
///
/// // println! ("{: ?}", x);//xelet: karanîna nirxa barbar
/// ```
///
/// Lêbelê, heke celebek `Copy` bicîh bike, li şûna wê 'semantîka kopî' heye:
///
/// ```
/// // Em dikarin pêkanînek `Copy` derxînin.
/// // `Clone` jî hewce ye, ji ber ku ew supertrait a `Copy` ye.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` nusxeyek `x` e
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Girîng e ku meriv bibîne ku di van her du mînakan de, tenê cûdahî ev e ku gelo hûn piştî wezîfeyê destûr têne dayîn ku hûn bigihîjin `x`.
/// Di bin kumikê de, hem nusxeyek û hem jî tevgerek dikare di bîteyan de were bîranîn ku di bîranînê de werin kopî kirin, her çend ev carinan ji dûr ve çêtir be jî.
///
/// ## Ez çawa dikarim `Copy` bicîh bikim?
///
/// Du celeb hene ku hûn `Copy` li ser celebê xwe bicîh bikin.Ya hêsantir karanîna `derive` e:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Hûn dikarin `Copy` û `Clone` jî bi destan bicîh bikin:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Di navbera her duyan de cûdahiyek piçûk heye: stratejiya `derive` dê `Copy` jî bi parametreyên tîpî ve girêbide, ku her dem nayê xwestin.
///
/// ## Çi cûdahî di navbera `Copy` û `Clone` de heye?
///
/// Kopî bi dizî çêdibe, mînakî wekî beşek ji peywirê `y = x`.Reftara `Copy` ne zêde barbar e;ew her gav nusxeyek bit-aqil a sade ye.
///
/// Klonkirin çalakiyek eşkere ye, `x.clone()`.Pêkanîna [`Clone`] dikare her tevgerek taybetî-celeb hewce bike ku nirxên bi ewlehî dubare bikin.
/// Mînakî, pêkanîna [`Clone`] ji bo [`String`] hewce dike ku tampona têl-nîşankirî ya di heapê de kopî bike.
/// Kopiyek bitewîn a hêsan a nirxên [`String`] dê tenê pêşnumayê kopî bike, û bibe sedema daketina rêzê ya du qat.
/// Ji bo vê sedemê, [`String`] [`Clone`] e lê ne `Copy`.
///
/// [`Clone`] supertrait a `Copy` e, ji ber vê yekê her tiştê ku `Copy` e divê [`Clone`] jî pêk bîne.
/// Ger celebek `Copy` be wê hingê pêkanîna [`Clone`] tenê hewce dike ku `*self` vegerîne (li mînaka jorîn binihêrin).
///
/// ## Kengî dikare tîpa min `Copy` be?
///
/// Ger hemî pêkhateyên wê `Copy` bicîh bikin celebek dikare `Copy` bicîh bike.Mînakî, ev struktur dikare `Copy` be:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// A struct dikare `Copy` be, û [`i32`] `Copy` e, ji ber vê yekê `Point` mafdar e ku bibe `Copy`.
/// Bi berevajî, bifikirin
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Struktur `PointList` nikare `Copy` bicîh bîne, ji ber ku [`Vec<T>`] ne `Copy` e.Ger em hewl bidin ku pêkanîna `Copy` derxînin, em ê xeletiyek bistînin:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Çavkaniyên parvekirî (`&T`) di heman demê de `Copy` in jî, ji ber vê yekê celebek dikare `Copy` be, her çend dema ku ew xwediyê referansên parvekirî yên celebên `T` be ku *ne*`Copy` ne.
/// Avakirina jêrîn, ku dikare `Copy` bicîh bîne, bifikirin, ji ber ku ew tenê ji jor ve *referansa hevpar* a ji bo jorê-type-Copy-ya me `PointList` nagire:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Kengî *nekare* tîpa min `Copy` be?
///
/// Hin celeb bi ewlehî nayên kopî kirin.Mînakî, kopîkirina `&mut T` dê referansek guhêrbar a aliased çêbike.
/// Kopîkirina [`String`] dê berpirsiyariya birêvebirina tampona ["String"] dubare bike, û dibe sedema du qat belaş.
///
/// Giştîkirina rewşa paşîn, her cûre bicîhkirina [`Drop`] nikare `Copy` be, ji ber ku ew ji bilî baytên xweyê [`size_of::<T>`] hin çavkaniyan birêve dibe.
///
/// Heke hûn hewl bidin ku `Copy` li ser sazûmanek an enumek ku daneyên ne-`Kopî` tê de hene bicîh bînin, hûn ê xeletiya [E0204] bistînin.
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Kengê *divê* tîpa min `Copy` be?
///
/// Bi gelemperî dipeyivin, heke celebê we _can_ `Copy` bicîh bike, ew pêdivî ye.
/// Her çend di hişê xwe de bimînin, ku bicîhkirina `Copy` beşek ji API-ya gelemperî ya celebê we ye.
/// Heke dibe ku celeb di future de ne-Copy-yê bibe, ew ê bi aqilane be ku niha pêkanîna `Copy` ji holê were rakirin, da ku ji guhertina API-ya şikestî dûr bikeve.
///
/// ## Pêkanînên pêvek
///
/// Ji bilî [implementors listed below][impls], celebên jêrîn jî `Copy` bicîh dikin:
///
/// * Celebên hêmanên fonksiyonê (ango, celebên cihêreng ên ji bo her fonksiyonê hatine diyarkirin)
/// * Cûreyên pointerê fonksiyonê (mînak, `fn() -> i32`)
/// * Heke celeb celeb `Copy` jî bicîh bike ji bo her mezinahiyan celebên rêzikan, mînakî `[i32; 123456]`
/// * Cûreyên duqolî, heke her pêkhateyek `Copy` jî bicîh bike (mînakî, `()`, `(i32, bool)`)
/// * Cûreyên girtinê, heke ew ji jîngehê re qîmetek nagirin an heke hemî nirxên wusa girtî `Copy` bixwe bicîh bînin.
///   Zanibe ku guhêrbarên ku ji hêla referansa hevpar ve hatine girtin her gav `Copy`-ê pêk tînin (heke referans jî neke), lê guherbarên ku ji hêla referansa-guhêrbar-ê ve hatine girtin qet `Copy` bicîh nakin.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Ev dihêle ku celebek ku `Copy` ji ber tixûbên jiyanê yên nerazî bicîh nayne kopî bike (kopîkirina `A<'_>` dema ku tenê `A<'static>: Copy` û `A<'_>: Clone` ye).
// Vê taybetmendiya me li vir ji bo naha tenê heye ji ber ku li ser `Copy` çend pisporiyên heyî hene ku jixwe di pirtûkxaneya standard de hene, û çu çare tune ku vê tevgerê aniha bi ewle hebe.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Makro hilberandin û hilberînek ji trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Cûreyên ku ji bo wan ewledar e ku meriv referansan di navbera têlan de parve bike.
///
/// Dema ku berhevkar guncan dibîne ev trait bixweber tête bicîh kirin.
///
/// Diyarkirina rast ev e: celebek `T` heke û tenê heke `&T` [`Send`] be [`Sync`] e.
/// Bi gotinên din, heke dema derbaskirina `&T` referansên di navbera mijaran de ne gengaz e ku [undefined behavior][ub] (pêşbaziyên danûstendinê jî tê de).
///
/// Wekî ku meriv hêvî dike, cûrên pêşîn ên mîna [`u8`] û [`f64`] hemî [`Sync`] in, û ji ber vê yekê jî celebên hêsan ên hevpar ên ku wan tê de ne, mîna tuples, daran û enum in.
/// Nimûneyên bêtir celebên bingehîn ên [`Sync`] celebên "immutable" wekî `&T`, û yên bi guhêrbariya mîras a sade, wekî [`Box<T>`][box], [`Vec<T>`][vec] û pir celebên komkirinê yên din hene.
///
/// (Pêdivî ye ku parametreyên gelemperî [`Sync`] bin ku konteynera wan [[Sync »] be.)
///
/// Encamek hinekî sosret a pênasînê ev e ku `&mut T` `Sync` e (heke `T` `Sync` be) her çend wisa xuya dike ku ew dibe ku mutasyonek ne-hemdemkirî peyda bike.
/// Fen ew e ku referansa guhêrbar a li paş referansa hevpar (ango `& &mut T`) tenê-tenê dixwîne, wekî ku ew `& &T` be.
/// Ji ber vê yekê xetereya pêşbaziyek daneyê tune.
///
/// Cûreyên ku `Sync` ne ew in ku "interior mutability" di formek ne-pêl-ewle de hene, wekî [`Cell`][cell] û [`RefCell`][refcell].
/// Van celeb destûrê didin ku guherîna naveroka wan jî bi navgîniyek bêguhêr, parvekirî.
/// Mînakî rêbaza `set` li ser [`Cell<T>`][cell] `&self` digire, ji ber vê yekê ew tenê referansek hevpar a [`&Cell<T>`][cell] hewce dike.
/// Metod ti senkronîzekirinê pêk nayne, lewma [`Cell`][cell] nikare `Sync` be.
///
/// Mînakek din a celebek ne-`Sync` pêşangeha hejmartina referansê [`Rc`][rc] e.
/// Her referansek [`&Rc<T>`][rc] tê dayîn, hûn dikarin [`Rc<T>`][rc] nû klon bikin, hejmarên referansê bi rengek ne-atomî biguherînin.
///
/// Ji bo rewşên ku yek pêdivî bi guherbariya hundirîn a bi têl-ewled heye, Rust [atomic data types] peyda dike, û hem jî bi [`sync::Mutex`][mutex] û [`sync::RwLock`][rwlock] kilîta eşkere dike.
/// Van celeb piştrast dikin ku her mutasyon nikare bibe sedema pêşbaziyên danûstendinê, ji ber vê yekê celeb `Sync` ne.
/// Bi heman awayî, [`sync::Arc`][arc] analogek xet-ewle ya [`Rc`][rc] peyda dike.
///
/// Her celebên ku bi guhêrîna hundurîn re hene jî divê dorpêça [`cell::UnsafeCell`][unsafecell] li dora value(s) bikar bînin ku dikare bi navgîniyek parvekirî ve were mutasyon kirin.
/// Çênebûna vê yekê [undefined behavior][ub] e.
/// Mînakî, ["veguherîn"][veguherîn]-ing ji `&T` bo `&mut T` nederbasdar e.
///
/// Ji bo bêtir agahdarî li ser `Sync` li [the Nomicon][nomicon-send-and-sync] binêrin.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): carekê piştgirî da ku notan li `rustc_on_unimplemented` li beta zêde bike, û ew hate dirêj kirin da ku were kontrol kirin ka li cîhek zincîra pêdivî ye an na, wusa dirêj bikin (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Cûreyek sifir-sized ji bo nîşankirina tiştên ku "act like" ew xwediyê `T` ne tê bikar anîn.
///
/// Zeviyek `PhantomData<T>` li tîpa xwe zêde bikin ji berhevkar re dibêje ku tîpa we wekî ku nirxek ji celebê `T` di xwe de vehewîne tevdigere, her çend ew ne bi rastî jî be.
/// Ev agahdarî dema ku hin taybetmendiyên ewlehiyê dihejmêrin tê bikar anîn.
///
/// Ji bo vegotinek kûrtir a karanîna `PhantomData<T>`, ji kerema xwe [the Nomicon](../../nomicon/phantom-data.html) bibînin.
///
/// # Nîşeyek tirsnak
///
/// Her çend navên wan ên tirsnak hebin jî, `PhantomData` û 'celebên fantom' têkildar in, lê ne yeksan.Parametera celebê fantomî bi tenê pîvanek celebek e ku qet nayê bikar anîn.
/// Di Rust de, ev yek pir caran dibe sedema gilîkirina berhevkar, û çareserî ew e ku karanîna "dummy" bi riya `PhantomData` zêde bike.
///
/// # Examples
///
/// ## Parametreyên jiyanê yên bêkêr
///
/// Dibe ku rewşa karanîna herî hevpar a ji bo `PhantomData` strukturek e ku xwedan pîvanek jiyana bêkar e, bi gelemperî wekî beşek ji hin koda bê ewle.
/// Mînakî, li vir struktura `Slice` heye ku du heb type of type `*const T` hene, dibe ku li cîhek rêzeyek nîşan dike:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Armanc ev e ku daneyên bingehîn tenê ji bo jiyanê `'a` derbasdar e, ji ber vê yekê divê `Slice` ji `'a` zêdetir neçe.
/// Lêbelê, ev armanc di kodê de nayê vegotin, ji ber ku tu karûbarên jiyanê yên `'a` tune û ji ber vê yekê ew ne diyar e ku ew daneya kîjan serîlêdanê dike.
/// Em dikarin vê yekê rast bikin ku ji berhevkar re bêje bila *wekî ku*`Slice` saz `&'a T` referansek heye tevbigere:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Di heman demê de ev hewceyê şîrovekirina `T: 'a` e, ku nîşan dide ku her referansên di `T` de li ser jiyana `'a` derbasdar in.
///
/// Dema ku `Slice` destpêdikin hûn bi tenê nirxa `PhantomData` ji bo qada `phantom` peyda dikin:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Parametreyên type bêkêr
///
/// Carcarinan diqewime ku we pê parametreyên celebê bê karanîn hene ku diyar dikin ka kîjan daneya XNUMXXXXXXXXXXXXXXXXXXQ e, her çend ew danegeh bi rastî di xwe de neyê dîtin
/// Li vir mînakek heye ku ev bi [FFI] radibe.
/// Navrûya biyanî destikên ji celebê `*mut ()` bikar tîne ku ji bo nirxên celebên cûda yên Rust bi nav bike.
/// Em celebê Rust bi karanîna parametreyek tîpa fantomî li ser damezirandina `ExternalResource` ya ku desteyek pêça dike dişopînin.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Xwedîderketin û venêrîna daketinê
///
/// Zêdekirina zeviyek celebê `PhantomData<T>` diyar dike ku celebê we xwediyê daneyên celebê `T` ye.Vê yekê ev tê wê wateyê ku dema tîpa we tê daketin, dibe ku ew yek an çend mînakan ji celebê `T` bavêje.
/// Ev li ser analîza [drop check] ya berhevkar Rust heye.
///
/// Ger struktura we di rastiyê de *xwedan* daneyên celebê `T` nebe, çêtir e ku hûn celebek referansê bikar bînin, mîna `PhantomData<&'a T>` (ideally) an `PhantomData<*const T>` (heke jiyanek we derbas nebe), da ku xwedantiyê nîşan neke.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Berhevkar-navxweyî trait tê bikar anîn ku celebê cûdakarên enumê nîşan bike.
///
/// Ev trait bixweber ji bo her cûreyê tê pêkanîn û ti mîsogeriyê li [`mem::Discriminant`] nake.
/// Ew **tevgerek nediyarkirî ye** ku di navbera `DiscriminantKind::Discriminant` û `mem::Discriminant` de veguherîne.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Cûreyek cûdakar, ku divê trait bounds ya ku `mem::Discriminant` hewce dike têr bike.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Berhevkar-navxweyî trait ji bo destnîşankirina ka celebek navxweyî `UnsafeCell` heye tê bikar anîn, lê ne bi navgîniyek.
///
/// Ev bandor dike, mînakî, ka `static` ji wî rengî di bîra statîk-tenê-xwendî de an bîhna statîk-a nivîsandî de tê danîn?
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Cûreyên ku piştî pînekirinê bi ewlehî têne veguheztin.
///
/// Ji xwe Rust têgihiştinek celebên neguhêzbar nîne, û tevgeran (mînakî, bi navgîniya an [`mem::replace`]) ve her gav ewle dibîne.
///
/// Tîpa [`Pin`][Pin] li şûna wê tê bikar anîn ku pêşî li tevgerên bi pergala pergalê bigire.Nîşaneyên `P<T>` ên di pêçeka [`Pin<P<T>>`][Pin] de pêçandî ne dikarin werin derxistin.
/// Ji bo bêtir agahdarî li ser pînekirinê belgeya [`pin` module] bibînin.
///
/// Pêkanîna `Unpin` trait ji bo `T` tixûbên pînekirinê ji ser tipê radike, ku dûv re dihêle ku `T` ji [`Pin<P<T>>`][Pin] bi fonksiyonên wekî [`mem::replace`] derkeve.
///
///
/// `Unpin` ji bo daneyên ne-pinîn qet encamek tune.
/// Bi taybetî, [`mem::replace`] bi kêfxweşî daneya `!Unpin` bar dike (ew ji bo her `&mut T`, ne tenê dema `T: Unpin` dixebite).
/// Lêbelê, hûn nekarin [`mem::replace`] li ser daneyên di hundurê [`Pin<P<T>>`][Pin] de pêçayî bikar bînin ji ber ku hûn nekarin `&mut T`-ê ku ji bo vê yekê hewce ne bistînin, û *ew* e ku vê pergalê dixebitîne.
///
/// Ji ber vê yekê, wek nimûne, tenê li ser celebên ku `Unpin` bicîh dikin dikare were kirin:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Em hewceyê referansek guhêrbar in ku em bangî `mem::replace` bikin.
/// // Em dikarin bi (implicitly) `Pin::deref_mut` vexwendin referansek wusa peyda bikin, lê ew tenê ji ber ku `String` `Unpin` bicîh tîne gengaz e.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Ev trait hema hema ji bo her celebî bixweber tê pêkanîn.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Celebek nîşanker ku `Unpin` bicîh nake.
///
/// Ger celebek `PhantomPinned` tê de hebe, ew ê `Unpin` ji hêla default ve bicîh neke.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Pêkanînên `Copy` ji bo celebên prîmîtîf.
///
/// Pêkanînên ku di Rust de nayê vegotin di `traits::SelectionContext::copy_clone_conditions()` de di `rustc_trait_selection` de têne pêkanîn.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Çavkaniyên hevpar dikarin werin kopî kirin, lê referansên guhêrbar *nekarin*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}