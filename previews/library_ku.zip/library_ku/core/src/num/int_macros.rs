macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Nirxa piçûktirîn ku dikare ji hêla vî celebê jimare ve were temsîl kirin.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// Nirxa herî mezin ku dikare bi vî rengê jimar temsîl bike.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// Mezinahiya vî celebê jimar di bitan de.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Parçeyek têlê di bingehek diyarkirî de vediguhêze ser jimareyek.
        ///
        /// Tête hêvî kirin ku têl dê nîşanek `+` an `-`-ya bijare be û li dû wê reqemî jî were.
        /// Cihê spî yê pêşeng û paş ve xeletiyek temsîl dike.
        /// Digits bi `radix` ve girêdayî, binbeşek ji van tîpan e:
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// Ger `radix` ne di navbera 2 û 36 de be ev fonksiyon panics.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Hejmara yên di nimûneya binary a `self` de vedigerîne.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 1);
        ///
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// Di nimûneya binary a `self` de hejmara sifiran vedigerîne.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Di nimûneya binary a `self` de hejmara sifirên pêşîn vedigerîne.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// Di nimûneya binary a `self` de hejmara sifirên paşîn vedigerîne.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// Di nimûneya binary a `self` de hejmara kesên pêşeng vedigerîne.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]

        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// Di nimûneya binary a `self` de hejmara yên paşîn vedigerîne.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// Bitan bi mîqdarek diyarkirî, `n`, vediguhêzîne çepê, bitikên qutkirî li dawiya jimareya encam digire.
        ///
        ///
        /// Ji kerema xwe not bikin ev ne heman xebata ku operatorê veguheztina `<<` e!
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// Bitan bi mîqdarek diyarkirî, `n`, ber bi rastê ve vediguhêze, bitikên qutkirî li destpêka jimareya encam digire.
        ///
        ///
        /// Ji kerema xwe not bikin ev ne heman xebata ku operatorê veguheztina `>>` e!
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// Rêziknameya byte ya jimareyê paşde vedigire.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// bila m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// Rêzeya bîtan di jimare de vedigire.
        /// Bîçeya herî hindik girîng dibe bitê herî girîng, duyemîn bîteya kêm-girîng dibe duyemîn girîng-girîng, hwd.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// bila m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// Integer-ê ji endian-a mezin vediguhêze endiannessa armancê.
        ///
        /// Li ser mezin endian ev qedexe ye.Li ser endianek piçûk byte têne guhertin.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ger cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } other {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Integerek ji hindika hindik vediguhêze dawiya paşiya hedefê.
        ///
        /// Li ser hindika hindik ev no-op ye.Li ser endian mezin byte têne guhertin.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ger cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } other {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// `self` ji endiannessa hedef diguherîne endîana mezin.
        ///
        /// Li ser mezin endian ev qedexe ye.Li ser endianek piçûk byte têne guhertin.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ger cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } din { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // an na?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// `self` ji endiannessa hedef diguhezîne hindik endian.
        ///
        /// Li ser hindika hindik ev no-op ye.Li ser endian mezin byte têne guhertin.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ger cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } din { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Zêdekirina jimareyê ya rastîn kontrol kir.
        /// Heke serma zêde çêbibe `self + rhs` dihesibîne, `None` vedigire.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Zêdekirina hejmarê ya neçêkirî.`self + rhs` dihesibîne, bihesibîne ku zêdehî çênabe.
        /// Ev gava ku tevdigere di nediyarkirî de encam dide
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // EWLEHIY: : bangker divê peymana ewlehiyê ya `unchecked_add` biparêze.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Dakêşana jimar ya rastîn kontrol kir.
        /// Heke serma zêde çêbibe `self - rhs` dihesibîne, `None` vedigire.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Dakêşana jimar ya nevekirî.`self - rhs` dihesibîne, bihesibîne ku zêdehî çênabe.
        /// Ev gava ku tevdigere di nediyarkirî de encam dide
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // EWLEHIY: : bangker divê peymana ewlehiyê ya `unchecked_sub` biparêze.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Pirjimariya jimareyê rastandî.
        /// Heke serma zêde çêbibe `self * rhs` dihesibîne, `None` vedigire.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Pirjimariya hejmarê ya neçêkirî.`self * rhs` dihesibîne, bihesibîne ku zêdehî çênabe.
        /// Ev gava ku tevdigere di nediyarkirî de encam dide
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // EWLEHIY: : bangker divê peymana ewlehiyê ya `unchecked_mul` biparêze.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Dabeşa jimareyê rastandî.
        /// `self / rhs` dihesibîne, ger `rhs == 0` an dabeş di encama zêdebûnê de vedigere `None` vedigire.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // EWLEHIYA: div bi sifir û bi INT_MIN li jor hatine kontrol kirin
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Dabeşa Euclidean kontrol kir.
        /// `self.div_euclid(rhs)` dihesibîne, ger `rhs == 0` an dabeş di encama zêdebûnê de vedigere `None` vedigire.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// Bermayiya jimare ya rastîn hatî kontrol kirin.
        /// `self % rhs` dihesibîne, ger `rhs == 0` an dabeş di encama zêdebûnê de vedigere `None` vedigire.
        ///
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // EWLEHIYA: div bi sifir û bi INT_MIN li jor hatine kontrol kirin
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Bermayiya Euclidean kontrol kir.
        /// `self.rem_euclid(rhs)` dihesibîne, ger `rhs == 0` an dabeş di encama zêdebûnê de vedigere `None` vedigire.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Neyînî kontrol kirin.
        /// `-self` dihesibîne, ger `self == MIN` `None` vedigire.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Cihê çepê kontrol kir.
        /// `self << rhs` dihejmêre, `None` vedigerîne heke `rhs` di `self`-ê de ji hejmaran bitikan mezintir an wekhev e.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Shift rast hat kontrol kirin.
        /// `self >> rhs` dihejmêre, `None` vedigerîne heke `rhs` di `self`-ê de ji hejmaran bitikan mezintir an wekhev e.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Nirxa mutleq kontrol kir.
        /// `self.abs()` dihesibîne, ger `self == MIN` `None` vedigire.
        ///
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// Ronahî kontrol kirin.
        /// Heke serma zêde çêbibe `self.pow(exp)` dihesibîne, `None` vedigire.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // ji ber ku exp!=0, di dawiyê de divê exp 1 be.
            // Bi bitekiya paşîn a vebir veqetandî ve mijûl bibin, ji ber ku dûv re çarçikkirina bingehê ne hewce ye û dibe ku bibe sedema zêdebûnek bêwate.
            //
            //
            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Têrkirina zêdebûna jimar.
        /// `self + rhs` dihesibîne, li şûna ku biherike, li tixûbên hejmarî têr dibe.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Têrkirina dakêşana jimar ya jimar.
        /// `self - rhs` dihesibîne, li şûna ku biherike, li tixûbên hejmarî têr dibe.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Têrkirina înkara hejmarê.
        /// `-self` dihesibîne, li şûna ku zêde bibe `MAX` vedigerîne heke `self == MIN`.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// Têrkirina nirxa mutleq.
        /// `self.abs()` dihesibîne, li şûna ku zêde tijî nebe `MAX` vedigerîne heke `self == MIN`.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// Têrkirina pirjimariya hejmarê.
        /// `self * rhs` dihesibîne, li şûna ku biherike, li tixûbên hejmarî têr dibe.
        ///
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// Têrkirina ravekirina jimareyê.
        /// `self.pow(exp)` dihesibîne, li şûna ku biherike, li tixûbên hejmarî têr dibe.
        ///
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// Pêvekirina (modular) pêça.
        /// `self + rhs` dihesibîne, li sînorê celebê dorpêç dike.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Daxistina veqetandina (modular).
        /// `self - rhs` dihesibîne, li sînorê celebê dorpêç dike.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Pirkirina (modular) pêça.
        /// `self * rhs` dihesibîne, li sînorê celebê dorpêç dike.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Dabeşkirina (modular) pêça.`self / rhs` dihesibîne, li sînorê celebê dorpêç dike.
        ///
        /// Doza yekane ku pêlhevokek wusa dikare çêbibe ev e ku meriv yek `MIN / -1` li ser celebek îmzekirî dabeş bike (ku `MIN` ji bo celebê nirxa herî kêm a negatîf e);ev wekhevî `-MIN` e, nirxek erênî ya ku pir mezin e ku meriv di celebê de temsîl nake.
        /// Di rewşek wusa de, ev fonksiyon `MIN` bixwe vedigire.
        ///
        /// # Panics
        ///
        /// Ger `rhs` 0 be ev fonksiyon dê panic be.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// Dabeşkirina Euclidean pêça.
        /// `self.div_euclid(rhs)` dihesibîne, li sînorê celebê dorpêç dike.
        ///
        /// Dorpêçandin dê tenê di `MIN / -1` de li ser celebek îmzekirî pêk were (ku `MIN` ji bo celebê nirxa herî kêm a negatîf e).
        /// Ev wekhevî `-MIN` e, nirxek erênî ya ku pir mezin e ku meriv di celebê de temsîl nake.
        /// Di vê rewşê de, ev rêbaz `MIN` bixwe vedigire.
        ///
        /// # Panics
        ///
        /// Ger `rhs` 0 be ev fonksiyon dê panic be.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// Xirabkirina mayîna (modular).`self % rhs` dihesibîne, li sînorê celebê dorpêç dike.
        ///
        /// Dorpêça wusa qet bi rastî bi matematîkî pêk nayê;Berhemên pêkanînê `x % y` ji bo `MIN / -1` li ser celebek îmzekirî neheq dike (ku `MIN` nirxa kêmîneya neyînî ye).
        ///
        /// Di rewşek wusa de, ev fonksiyon `0` vedigerîne.
        ///
        /// # Panics
        ///
        /// Ger `rhs` 0 be ev fonksiyon dê panic be.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// Bermayiya Euklîdiyan pêça.`self.rem_euclid(rhs)` dihesibîne, li sînorê celebê dorpêç dike.
        ///
        /// Dorpêçandin dê tenê di `MIN % -1` de li ser celebek îmzekirî pêk were (ku `MIN` ji bo celebê nirxa herî kêm a negatîf e).
        /// Di vê rewşê de, ev rêbaz 0 vedigire.
        ///
        /// # Panics
        ///
        /// Ger `rhs` 0 be ev fonksiyon dê panic be.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// Nerazîbûna (modular) pêça.`-self` dihesibîne, li sînorê celebê dorpêç dike.
        ///
        /// Doza yekane ku pêlhevokek weha dikare çêbibe ev e ku meriv `MIN` li ser celebek îmzekirî înkar dike (ku `MIN` ji bo celebê nirxa herî kêm a negatîf e);ev nirxek erênî ye ku pir mezin e ku meriv nikare di celebê de temsîl bike.
        /// Di rewşek wusa de, ev fonksiyon `MIN` bixwe vedigire.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// - panic-bit bit-shift-çep;`self << mask(rhs)` dide, ku `mask` her bitên rêza bilind a `rhs` radike ku dê bibe sedem ku veguherîn ji bitwidth a celebî derbas bibe.
        ///
        /// Bala xwe bidinê ku ev *ne* eynî wekî çep-zivirî ye;RHS-a shift-çepê ya dorpêçê ji hêla celebê ve tête tixûbdar kirin, ji bila bîtên ji LHS-ê veguheztin paşiya din.
        ///
        /// Celebên jimar ên prîmîtîf hemî fonksiyonek [`rotate_left`](Self::rotate_left) bicîh dikin, ku dibe ku ya ku hûn li şûna wê dixwazin.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // EWLEH: : maskeya ji hêla bitsize ya celeb ve piştrast dike ku em neguherin
            // ji derveyî sînoran
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-belaş bitwise guherîn-rast;`self >> mask(rhs)` dide, ku `mask` her bitên rêza bilind a `rhs` radike ku dê bibe sedem ku veguherîn ji bitwidth a celebî derbas bibe.
        ///
        /// Bala xwe bidinê ku ev *ne* eynî wekî rast-zivirî ye;RHS-a-shift-rastê ya dorpêçê ji hêla celebê ve tête tixûb kirin, ji dêvla ku bîtên ji LHS-ê hatine veguheztin vegerin dawiya din.
        ///
        /// Celebên jimar ên prîmîtîf hemî fonksiyonek [`rotate_right`](Self::rotate_right) bicîh dikin, ku dibe ku ya ku hûn li şûna wê dixwazin.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // EWLEH: : maskeya ji hêla bitsize ya celeb ve piştrast dike ku em neguherin
            // ji derveyî sînoran
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Dorpêçkirina nirxa mutleq a (modular).`self.abs()` dihesibîne, li sînorê celebê dorpêç dike.
        ///
        /// Tenê rewşa ku pêlhevokek wusa dikare çêbibe ev e ku meriv ji bo celebê nirxa mutleq a nirxa kêmîneya negatîf digire;ev nirxek erênî ye ku pir mezin e ku meriv nikare di celebê de temsîl bike.
        /// Di rewşek wusa de, ev fonksiyon `MIN` bixwe vedigire.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// Bêyî pêçandin û panîk nirxa mutleq a `self` hesab dike.
        ///
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// Daxuyaniya (modular) pêça.
        /// `self.pow(exp)` dihesibîne, li sînorê celebê dorpêç dike.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // ji ber ku exp!=0, di dawiyê de divê exp 1 be.
            // Bi bitekiya paşîn a vebir veqetandî ve mijûl bibin, ji ber ku dûv re çarçikkirina bingehê ne hewce ye û dibe ku bibe sedema zêdebûnek bêwate.
            //
            //
            acc.wrapping_mul(base)
        }

        /// `self` + `rhs` hesab dike
        ///
        /// Pirtûkek lêzêdekirinê li gel boolean vedigerîne û diyar dike ka dê serûbiniyek arîtmetîkî çêbibe.
        /// Heke serhildanek çêbûba wê hingê nirxa pêçayî vedigere.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self`, `rhs` hesab dike
        ///
        /// Tewra veqetandinê li gel boolean vedigerîne ku diyar dike ka dê serûbiniyek arîtmetîkî çêbibe.
        /// Heke serhildanek çêbûba wê hingê nirxa pêçayî vedigere.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Pirbûna `self` û `rhs` dihejmêrin.
        ///
        /// Tewra pirjimariyê li gel boolean vedigerîne ku nîşan dide ka dê zêdehiyek arîtmetîkî çêbibe.
        /// Heke serhildanek çêbûba wê hingê nirxa pêçayî vedigere.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (1410065408, rast));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Dema ku `self` bi `rhs` tê dabeş kirin dabeşkêr dihesibîne.
        ///
        /// Tewekek dabeşkerê digel boolean vedigerîne ku diyar dike ka dê serûbiniyek arîtmetîkî çêbibe.
        /// Ger serhildanek çêbibe wê hingê xwe tê vegerandin.
        ///
        /// # Panics
        ///
        /// Ger `rhs` 0 be ev fonksiyon dê panic be.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// Pirtûka dabeşa Euclidean `self.div_euclid(rhs)` hesab dike.
        ///
        /// Tewekek dabeşkerê digel boolean vedigerîne ku diyar dike ka dê serûbiniyek arîtmetîkî çêbibe.
        /// Ger serhildanek çêbibe wê hingê `self` vedigere.
        ///
        /// # Panics
        ///
        /// Ger `rhs` 0 be ev fonksiyon dê panic be.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// Dema ku `self` bi `rhs` tê dabeş kirin bermayî dihejmire.
        ///
        /// Piştî parvekirinê bi hev re boolean tûpek bermayî vedigerîne û diyar dike ka dê serûbiniyek arîtmetîkî çêbibe.
        /// Ger serhildanek çêbibe wê hingê 0 vedigere.
        ///
        /// # Panics
        ///
        /// Ger `rhs` 0 be ev fonksiyon dê panic be.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self % rhs, false)
            }
        }


        /// Bermayiya Euclîdeyî ya zêdebar.`self.rem_euclid(rhs)` hesab dike.
        ///
        /// Piştî parvekirinê bi hev re boolean tûpek bermayî vedigerîne û diyar dike ka dê serûbiniyek arîtmetîkî çêbibe.
        /// Ger serhildanek çêbibe wê hingê 0 vedigere.
        ///
        /// # Panics
        ///
        /// Ger `rhs` 0 be ev fonksiyon dê panic be.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// Xwe negatîf dike, heke ev bi qîmeta kêmtirîn re yeksan be, diherike.
        ///
        /// Tîpek versiyona înkarkirî ya xweser vedigerîne û bi boolean nîşan dide ka gelo zêdebûnek çêbûye.
        /// Ger `self` nirxa herî kêm e (mînakî, `i32::MIN` ji bo nirxên celebê `i32`), wê hingê nirxa kêmtirîn dê dîsa were vegerandin û `true` jî dê ji bo rûdanek zêde were vegerandin.
        ///
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// Xwe ji hêla `rhs` bit ve mayî vediguhêze.
        ///
        /// Pirtûka guhertoya xwerû ya xwerû li gel boolean vedigerîne ku nîşan dike ka nirxa guherînê ji hejmara bîtan mezintir an wekhev bû.
        /// Ger nirxa guherînê pir mezin be, wê hingê nirx bi maskkirî ye (N-1) ku N hejmara bîtan e, û paşê ev nirx ji bo pêkanîna veguherînê tê bikar anîn.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (0x10, rast));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Xwe bi bitsên `rhs` rast diguheze.
        ///
        /// Pirtûka guhertoya xwerû ya xwerû li gel boolean vedigerîne ku nîşan dike ka nirxa guherînê ji hejmara bîtan mezintir an wekhev bû.
        /// Ger nirxa guherînê pir mezin be, wê hingê nirx bi maskkirî ye (N-1) ku N hejmara bîtan e, û paşê ev nirx ji bo pêkanîna veguherînê tê bikar anîn.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (0x1, rast));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Nirxa mutleq a `self` dihesibîne.
        ///
        /// Pirtûka guhertoya xweser a mutleq vedigere û digel boolean nîşan dide ka gelo zêdebûnek çêbûye.
        /// Ger bixwe nirxa herî kêm e
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// wê hingê nirxa kêmtirîn dê dîsa were vegerandin û ya rastîn dê ji bo serhildanek rû bide vegeriya.
        ///
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// Xwe bi hêza `exp` radike, bi karanîna çarçovê ve pêşandanê bikar tîne.
        ///
        /// Tîpek ravekirinê digel bool vedigerîne ku nîşan dike ka zêdehiyek çêbûye.
        ///
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13, rast));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Cihê xêzkirinê ji bo tomarkirina encamên pir_şolê.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // ji ber ku exp!=0, di dawiyê de divê exp 1 be.
            // Bi bitekiya paşîn a vebir veqetandî ve mijûl bibin, ji ber ku dûv re çarçikkirina bingehê ne hewce ye û dibe ku bibe sedema zêdebûnek bêwate.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// Xwe bi hêza `exp` radike, bi karanîna çarçovê ve pêşandanê bikar tîne.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // ji ber ku exp!=0, di dawiyê de divê exp 1 be.
            // Bi bitekiya paşîn a vebir veqetandî ve mijûl bibin, ji ber ku dûv re çarçikkirina bingehê ne hewce ye û dibe ku bibe sedema zêdebûnek bêwate.
            //
            //
            acc * base
        }

        /// Kota dabeşbûna Euclidean a `self` bi `rhs` dihejmêre.
        ///
        /// Ev jimareya `n` bi vî rengî `self = n * rhs + self.rem_euclid(rhs)`, bi `0 <= self.rem_euclid(rhs) < rhs` re dihejmêre.
        ///
        ///
        /// Bi gotinên din, encam `self / rhs` dorpêçandî ye bo jimare `n` wusa ku `self >= n * rhs`.
        /// Ger `self > 0`, ev bi gerdena ber bi sifirê ve (wekhevî di Rust de) wekhev e;
        /// heke `self < 0`, ev bi dor ber bi +/-bêdawîbûnê ve wekhev e.
        ///
        /// # Panics
        ///
        /// Ger `rhs` 0 be an dabeşbûn di encama zêdebûnê de be dê ev fonksiyon panic bike.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// bila b=4;
        ///
        /// assert_eq!(a.div_euclid(b), 1); //7>=4 *1 assert_eq!(a.div_euclid(-b), -1);//7>= -4*-1 assert_eq!((-a).div_euclid(b), -2);//-7>=4 *-2 assert_eq!((-a).div_euclid(-b), 2);//-7>= -4* 2
        ///
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// Bermayiya herî kêm neyînî ya `self (mod rhs)` hesab dike.
        ///
        /// Ev wekî ku ji hêla algorîtmaya dabeşkirina Euclidean ve tête kirin-tête dayîn `r = self.rem_euclid(rhs)`, `self = rhs * self.div_euclid(rhs) + r`, û `0 <= r < abs(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Ger `rhs` 0 be an dabeşbûn di encama zêdebûnê de be dê ev fonksiyon panic bike.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// bila b=4;
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                if rhs < 0 {
                    r - rhs
                } else {
                    r + rhs
                }
            } else {
                r
            }
        }

        /// Nirxa mutleq a `self` dihesibîne.
        ///
        /// # Tevgeriya zêdebûnê
        ///
        /// Nirxa mutleq ya
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// nikare wekî were temsîl kirin
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// û hewildana hejmartina wê dê bibe sedema zêdebûnek.
        /// Ev tê vê wateyê ku kod di moda xeletiyê de dê li ser vê rewşê panic bişkîne û koda çêtirîn vedigere
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// bê panic.
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // Têbînî ku#[xêzika] jorîn tê vê wateyê ku semantîka zêdekirina veqetandinê bi crate ve girêdayî ye ku em tê de têne rêz kirin.
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// Hejmarek nîşana `self`-ê vedigerîne vedigerîne.
        ///
        ///  - `0` heke hejmar sifir be
        ///  - `1` heke hejmar erênî be
        ///  - `-1` heke hejmar neyînî be
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[inline]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// Ger `self` erênî û `false` heke hejmar sifir an neyînî be `true` vedigerîne.
        ///
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// Ger `self` neyînî û `false` heger hejmar sifir an erênî be `true` vedigerîne.
        ///
        ///
        /// # Examples
        ///
        /// Bikaranîna bingehîn:
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// Vebijêrka bîranîna vê jimareyê wekî rêzeyek byte di rêza bajêtê ya big-endian (network) de vegerînin.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Vebijêrka bîranîna vê jimareyê wekî rêzeyek byte li gorî rêza byte ya kêm-endian vegerînin.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Vebijêrka bîranînê ya vê jimareyê wekî rêzikek byte di rêza byte ya xwemalî de vegerînin.
        ///
        /// Gava ku endiannessa xwemalî ya platforma armanc tê bikar anîn, divê koda veguhêzbar li şûna wê, [`to_be_bytes`] an [`to_le_bytes`] bikar bîne.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     byte, heke cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } other {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // EWLEHIY const: dengê const ji ber ku hejmarên yekjimar datapîpên kevn in ji ber vê yekê em dikarin hertim bikin
        // wan veguherîne rêzikên baytan
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // EWLEH: : jimar daneyên celebên kevn ên derewîn in ji ber vê yekê em dikarin hertim wan veguherînin
            // rêzikên byteyan
            unsafe { mem::transmute(self) }
        }

        /// Vebijêrka bîranînê ya vê jimareyê wekî rêzikek byte di rêza byte ya xwemalî de vegerînin.
        ///
        ///
        /// [`to_ne_bytes`] kengê gengaz be divê li ser vê yekê were tercîh kirin.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// bila byte= num.as_ne_bytes();
        /// assert_eq!(
        ///     byte, heke cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } other {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // EWLEH: : jimar daneyên celebên kevn ên derewîn in ji ber vê yekê em dikarin hertim wan veguherînin
            // rêzikên byteyan
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Ji temsîliyeta xwe wekî arrayek byte di big endian de nirxek jimar biafirînin.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto bikar bînin;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=mayîn;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Ji temsîliyeta xwe wekî arrayek byte di hindik endian de nirxek jimar biafirînin.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto bikar bînin;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=mayîn;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Di nimûneya bîranîna xwe de wekî arrayek byte di endianbûna xwecihî de nirxek jimareyek çêbikin.
        ///
        /// Gava ku endiannessa xwemalî ya platforma armanc tê bikar anîn, koda barkêş dibe ku dixwaze [`from_be_bytes`] an [`from_le_bytes`], wekî guncan li şûna wê bikar bîne.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// } other {
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto bikar bînin;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=mayîn;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // EWLEHIY const: dengê const ji ber ku hejmarên yekjimar datapîpên kevn in ji ber vê yekê em dikarin hertim bikin
        // ji wan re veguherîne
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // EWLEH: : jimar daneyên daneyên kevn ên derewîn in ji ber vê yekê em dikarin hertim wan veguherînin
            unsafe { mem::transmute(bytes) }
        }

        /// Pêdivî ye ku koda nû bikar bîne
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Nirxa herî piçûk a ku dikare bi vî celebê jimare were temsîl kirin vedigerîne.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// Pêdivî ye ku koda nû bikar bîne
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Nirxa herî mezin a ku dikare bi vî rengê jimar temsîl bike vedigerîne.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}