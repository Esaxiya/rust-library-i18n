//! Cureyên çewtiyê ji bo veguherîna li celebên entegre.

use crate::convert::Infallible;
use crate::fmt;

/// Dema ku veguherînek celebê ya entegre ya kontrolkirî têk çû, tîpa çewtiyê vegeriya.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Li şûna zorê li hev bikin da ku bicîh bikin ku koda mîna `From<Infallible> for TryFromIntError` ya jorîn dê xebate bidomîne dema ku `Infallible` ji `!` re bibe aliyek.
        //
        //
        match never {}
    }
}

/// Çewtiyek ku dikare were vegerandin dema parsekkirina jimareyek rast.
///
/// Ev xeletî ji bo fonksiyonên `from_str_radix()` ên li ser cûrbecûr hejmarên prîmîtîf, wekî [`i8::from_str_radix`], wekî celebê çewtiyê tê bikar anîn.
///
/// # Sedemên potansiyel
///
/// Di nav sedemên din de, `ParseIntError` dikare were avêtin ji ber ku qada spî ya pêşîn an li paş têl e, mînakî, dema ku ew ji têke standard tê stendin.
///
/// Bikaranîna rêbaza [`str::trim()`] piştrast dike ku berî parsekirinê cîhek spî namîne.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum ji bo depokirina cûrbecûr çewtiyên ku dibe sedema parsekirina jimareyek rast.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Nirxa tê parsekirin vala ye.
    ///
    /// Di nav sedemên din de, dema ku parsekek zincîreyek vala dihête çêkirin, ev variant dê were çêkirin.
    Empty,
    /// Di çarçoveya xwe de reqemek nederbasdar heye.
    ///
    /// Di nav sedemên din de, dema ku parsekek têl ku tê de carkek ne-ASCII heye, ev variant dê were çêkirin.
    ///
    /// Dema ku `+` an `-` di nav rêzê de yan bi serê xwe an jî di orta hejmarekê de bê cîh be ev variant jî tê çêkirin.
    ///
    ///
    InvalidDigit,
    /// Integer pir mezin e ku meriv nikare di tîpa integer-hedef de tomar bike.
    PosOverflow,
    /// Integer pir piçûk e ku di celebê jimareya hedef de were hilanîn.
    NegOverflow,
    /// Nirx Sifir bû
    ///
    /// Dema ku nirxa sifrê ya têl a parseker be, ev variant dê were weşandin, ku ew ê ji bo celebên ne-sifir neqanûnî be.
    ///
    Zero,
}

impl ParseIntError {
    /// Sedema hûrgulî ya parsengkirina serjimêrekê têk dibe.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}