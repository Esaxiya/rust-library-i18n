//! Stendinên ji bo 16-bit tîpa jimare ya nevekirî.
//!
//! *[See also the `u16` primitive type][u16].*
//!
//! Pêdivî ye ku koda nû konstantên têkildar rasterast li ser tîpa primitive bikar bîne.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u16`"
)]

int_module! { u16 }