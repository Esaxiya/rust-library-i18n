//! Berdestên ji bo tîpa jimare ya ne-îmze 64-bit.
//!
//! *[See also the `u64` primitive type][u64].*
//!
//! Pêdivî ye ku koda nû konstantên têkildar rasterast li ser tîpa primitive bikar bîne.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u64`"
)]

int_module! { u64 }