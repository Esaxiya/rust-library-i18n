//! Berdestên ji bo hejmar-hejmar tîpa jimare ya nivisandî.
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! Pêdivî ye ku koda nû konstantên têkildar rasterast li ser tîpa primitive bikar bîne.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }