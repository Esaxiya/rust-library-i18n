//! Wergerandina Rust hema hema rasterast (lê hinekî çêtirîn) a Zencîreya 3 ya "Çapkirina Jimareyên Nûve-Xwe Zû û Bi Rastî" [^ 1].
//!
//!
//! [^1]: Burger, RG û Dybvig, RK 1996. Çapkirina hejmarên xal-float
//!   bi lez û bez.SIGPLAN Na.31, 5 (Gulan. 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// rêzikên jihejmartî yên `Digit`s ji bo 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// tenê dema `x < 16 * scale` bikêr tê;`scaleN` divê `scale.mul_small(N)` be
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Ji bo Dragon pêkanîna moda herî kurt.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // hejmara `v` ya ku format dike tê zanîn ku ev e:
    // - wekhevî `mant * 2^exp`;
    // - di pêşîn de ji hêla `(mant - 2 *minus)* 2^exp` ve;û
    // - di pey re di tîpa xwerû de `(mant + 2 *plus)* 2^exp` tê şopandin.
    //
    // eşkere, `minus` û `plus` nabe sifir.(ji bo bêdawîbûnê, em nirxên ji rêzê bikar tînin.) her weha em difikirin ku bi kêmî ve yek reqem çêdibe, ango, `mant` jî nabe sifir.
    //
    // ev di heman demê de tê vê wateyê ku her hejmarek di navbera `low = (mant - minus)*2^exp` û `high = (mant + plus)* 2^exp` de dê nexşeya vê hejmara nuqteya berbiçav a rastîn bike, digel sînor dema ku mantîsa orjînal jî bû (ango, `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` `if d.inclusive {a <= b} else {a < b}` e
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // texmîn bikin `k_0` ji inputên xwerû ku `10^(k_0-1) < high <= 10^(k_0+1)` têr dikin.
    // `k` ya ku bi `10^(k-1) < high <= 10^k` têrker ve girêdayî ye paşê tê hesibandin.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // `{mant, plus, minus} * 2^exp` veguherînin forma perçeyî da ku:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // `mant` bi `10^k` parve bikin.naha `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // fixing dema `mant + plus > scale` (an `>=`).
    // em di rastiyê de `scale` naguherînin, ji ber ku em dikarin li şûna wê ji pirjimariya destpêkê derbikevin.
    // naha `scale < mant + plus <= scale * 10` û em amade ne ku reqeman çêbikin.
    //
    // not bikin ku `d[0]`*dikare* sifir be, dema `scale - plus < mant < scale`.
    // di vê rewşê de rewşa dorpêçê (`up` li jêr) dê tavilê were şandin.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // wekhev bi pîvandina `scale` bi 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // cache `(2, 4, 8) * scale` ji bo hilberîna reqemî.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // neguhêrbar, ku `d[0..n-1]` hejmar heya niha hatine çêkirin:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (bi vî awayî `mant / scale < 10`) ku `d[i..j]` kurtenivîsek ji bo `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // yek reqemî çêbikin: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // ev ravekek hêsantir a algorîtmaya Dragon-a guherandin e.
        // ji bo hêsaniyê gelek derivînên navîn û nîqaşên bêkêmasî ji holê radibin.
        //
        // ji ber ku me `n` nûve kirî bi neguhêrbarên guhertî dest pê bikin:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // ferz bikin ku `d[0..n-1]` di navbera `low` û `high` de temsîliyeta herî kin e, ango, `d[0..n-1]` her du yên jêrîn têr dike lê `d[0..n-2]` wiya nake:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijarebûn: reqemên dora `v`);û
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (reqema paşîn rast e).
        //
        // rewşa duyemîn `2 * mant <= scale` hêsan dike.
        // çareserkirina neguhêzbar di warê `mant`, `low` û `high` de guhertoyek hêsantir a mercê yekem derdixe holê: `-plus < mant < minus`.
        // ji `-plus < 0 <= mant` ve, dema `mant < minus` û `2 * mant <= scale` temsîla meya kurttirîn a rast heye.
        // (yê yekem dema ku mantîsa orîjînal jî be `mant <= minus` dibe.)
        //
        // gava ya duyem nagire (`2 * mant> pîvan`), pêdivî ye ku em reqema paşîn zêde bikin.
        // ev ji bo vegerandina wê rewşê bes e: em jixwe dizanin ku nifşa reqemî `0 <= v / 10^(k-n) - d[0..n-1] < 1` garantî dike.
        // di vê rewşê de, rewşa yekem dibe `-plus < mant - scale < minus`.
        // ji ber ku `mant < scale` piştî nifşê, me `scale < mant + plus` heye.
        // (dîsa, dema ku mantîsa orîjînal jî be, ev dibe `scale <= mant + plus`.)
        //
        // bi kurtî:
        // - dema `mant < minus` (an `<=`) `down` rawestînin û dor bikin (reqeman wekî xwe bihêlin).
        // - `up` rawestînin û dor bikin (reqema paşîn zêde bikin) dema `scale < mant + plus` (an `<=`).
        // - wekî din hilberînê berdewam bikin.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // temsîla meya herî kin heye, ber bi dorpêçê ve biçin

        // neguhêrbariyan vegerînin.
        // ev algorîtmayê her gav diqedîne: `minus` û `plus` her dem zêde dibe, lê `mant` qut dibe modulo `scale` û `scale` sabît e.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // dorpêçandin çêdibe dema ku i) tenê rewşa dorpêçê çêdibe, an ii) her du merc hatine destpêkirin û girêdana bendê dorpêçê tercîh dike.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // ger dorpêçê dirêjahî biguhezîne, divê vebêjer jî biguhere.
        // wusa dixuye ku rakirina vê şertê pir dijwar e (dibe ku ne gengaz be), lê em li vir tenê ewledar û domdar in.
        //
        // EWLEH: me wê bîranîna li jor destnîşan kir.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // EWLEH: me wê bîranîna li jor destnîşan kir.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Ji bo Dragon pêkanîna moda rast û sabît.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // texmîn bikin `k_0` ji inputên xwerû ku `10^(k_0-1) < v <= 10^(k_0+1)` têr dikin.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // `mant` bi `10^k` parve bikin.naha `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // fixing dema `mant + plus >= scale`, ku `plus / scale = 10^-buf.len() / 2`.
    // ji bo ku em bignum-a sabît bimînin, em bi rastî `mant + floor(plus) >= scale` bikar tînin.
    // em di rastiyê de `scale` naguherînin, ji ber ku em dikarin li şûna wê ji pirjimariya destpêkê derbikevin.
    // dîsa bi algorîtmaya herî kurt, `d[0]` dikare sifir be lê dê di dawiyê de were dorpêç kirin.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // wekhev bi pîvandina `scale` bi 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // heke em bi sînorkirina reqema paşîn re dixebitin, pêdivî ye ku em tampona berî rendering-a rastîn kurt bikin da ku ji dorpêçkirina du qat dûr bisekinin.
    //
    // not bikin ku dema dorpêçkirin çêdibe ku em dîsa tamponê mezin bikin!
    let mut len = if k < limit {
        // wey, em nikarin *yek* reqemî jî hilberînin.
        // ev gengaz e dema ku, bêje, me tiştek mîna 9.5 girtibe û ew were dorpêçkirin 10.
        // em tamponek vala vedigerînin, ji xeynî rewşa dorpêçê ya paşê ku dema `k == limit` rû dide û pêdivî ye ku tam yekjimarek hilberîne.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // cache `(2, 4, 8) * scale` ji bo hilberîna reqemî.
        // (ev dikare biha be, ji ber vê yekê dema ku tampon vala ye wan hesab nekin.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // reqemên jêrîn hemî sifir in, em li vir radiwestin *ne* hewl didin ku dorpêçê bikin!belkî, reqemên mayî dagirin.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // EWLEH: me wê bîranîna li jor destnîşan kir.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // ger em di jimara jimaran de bisekinin ger reqemên jêrîn bi tevahî 5000 be ... dorpêç bikin, reqema pêşîn kontrol bikin û hewl bidin ku heya (ango, dema ku reqema pêşîn hevaheng be ji dorpêçê dûr bikin).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // EWLEH: : `buf[len-1]` destpêkirî ye.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // ger dorpêçê dirêjahî biguhezîne, divê vebêjer jî biguhere.
        // lê ji me re hejmarek diyarkirî reqem hat xwestin, ji ber vê yekê tamponê neguherînin ...
        // EWLEH: me wê bîranîna li jor destnîşan kir.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... heya ku li şûna me ji me re rastbûna sabît neyê xwestin.
            // di heman demê de pêdivî ye ku em kontrol bikin ku, heke tampona orjînal vala bû, reqema pêvek tenê dema `k == limit` (doza edge) dikare were zêdekirin.
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // EWLEH: me wê bîranîna li jor destnîşan kir.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}