//! Adaptasyona Rust ya algorîtmaya Grisu3 a ku di "Çapkirina Jimareyên Xalbend-Xalê Zêde û Rast bi Integer" re hatî vegotin [^ 1].
//! Ew bi qasî 1KB masa pêşbînîkirî bikar tîne, û di dorê de, ji bo piraniya têkelan pir zû ye.
//!
//! [^1]: Florian Loitsch.2010. Çapkirina hejmarên floating-point zû û
//!   bi rastîn bi jimaran re.SIGPLAN Na.45, 6 (Hezîran 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// ji bo maqûl şîroveyên li `format_shortest_opt` bibînin.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-ez;e=4* ez, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// `x > 0` dane, `(k, 10^k)` wiha vedigerîne ku `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Ji bo Grisu pêkanîna moda herî kurt.
///
/// Ew `None` vedigerîne dema ku ew ê nûnertiyek nerast vegerîne rewşek din.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // ji me re herî kêm sê bit teqeziya pêvek hewce dike

    // bi nirxên normalîzekirî re bi pêşangeha hevpar re dest pê bikin
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // her `cached = 10^minusk` weha `ALPHA <= minusk + plus.e + 64 <= GAMMA` bibînin.
    // ji ber ku `plus` normalîze bûye, ev tê vê wateyê `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // hilbijartinên me yên `ALPHA` û `GAMMA` dane, ev `plus * cached` dixe nav `[4, 2^32)`.
    //
    // ev eşkere tête xwestin ku `GAMMA - ALPHA` zêde bibe, da ku ji me re gelek hêzên cached ên 10 ne hewce ne, lê hin raman hene:
    //
    //
    // 1. em dixwazin ku `floor(plus * cached)` di nav `u32` de bimînin ji ber ku ew hewceyê dabeşek biha ye.
    //    (ev ne bi rastî nayê parastin, mayî ji bo nirxandina rastbûnê hewce ye.)
    // 2.
    // ya mayî ya `floor(plus * cached)` bi berdewamî li 10 zêde dibe, û pêdivî ye ku ew biherike.
    //
    // ya yekem `64 + GAMMA <= 32` dide, ya duyem jî `10 * 2^-ALPHA <= 2^64` dide;
    // -60 û -32 bi vê astengiyê re qada herî zêde ye, û V8 jî wan bikar tîne.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // pîvana fps.ev xeletiya herî zêde ya 1 ulp dide (ji Teorema 5.1 îspat kir).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-Rêjeya rastîn a minus
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // li jor `minus`, `v` û `plus`*texmînên* kantantî * ne (xelet <1 ulp).
    // ji ber ku em nizanin çewtî erênî an neyînî ye, em du texmînan ji hev dûr veqetandî bikar tînin û xeletiya herî zêde ya 2 ulps heye.
    //
    // "unsafe region" navberek lîberal e ku em di destpêkê de diafirînin.
    // "safe region" navberek kevneperest e ku em tenê wê qebûl dikin.
    // em bi reprê rast di nav devera ne ewle de dest pê dikin, û hewl didin ku reprên herî nêzîkê `v` bibînin ku ew jî di nav herêma ewledar de ye.
    // heke em nekarin, em dev jê berdin.
    //
    let plus1 = plus.f + 1;
    // bila plus0 = plus.f, 1;//tenê ji bo ravekirinê bila minus0 = minus.f + 1;//tenê ji bo ravekirinê
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // vebêjerê hevpar

    // `plus1` li beşên entegral û perçeyî parve bikin.
    // Parçeyên entegre têne garantîkirin ku di u32 de bicîh bibin, ji ber ku hêza kaşkirî `plus < 2^32` garantî dike û `plus.f` normalîzebûyî jî ji ber pêdiviya rastbûnê her tim ji `2^64 - 2^4` kêmtir e.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // `10^max_kappa`-a herî mezin ji `plus1`-an zêdetir nahesibînin (bi vî rengî `plus1 < 10^(max_kappa+1)`).
    // ev bendek jorîn a `kappa` li jêr e.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Teorema 6.2: heke `k` mezintirîn jimare ya st e
    // `0 <= y mod 10^k <= y - x`,              wê hingê `V = floor(y / 10^k) * 10^k` di `[x, y]` de ye û yek ji nimînendeyên herî kurt e (digel hejmara hindiktirîn reqemên girîng) di wê navberê de.
    //
    //
    // li gorî Teorema 6.2 di navbera `(minus1, plus1)` de dirêjahiya reqemî `kappa` bibînin.
    // Teorema 6.2 dikare were pejirandin da ku li şûna `y mod 10^k < y - x` hewce nebe `x` derxîne.
    // (mînak, `x` =32000, `y` =32777; `kappa` =2 ji ber ku `y mod 10 ^ 3=777 <y, x=777`.) algorithm xwe dispêre qonaxa piştrastkirinê ya paşê da ku `y` derxîne.
    //
    let delta1 = plus1 - minus1;
    // bila delta1int=(delta1>> e) wekî bikar bîne;//tenê ji bo ravekirinê
    let delta1frac = delta1 & ((1 << e) - 1);

    // dema ku li her gavê rastbûnê kontrol dikin, perçeyên entegre bikin.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // reqemên ku hêj ne hatine dayîn
    loop {
        // her gav bi kêmî ve yek hejmar heye ku em bidin, wekî `plus1 >= 10^kappa` neguhêzbar:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (ev diyar dike ku `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // `remainder` bi `10^kappa` parve bikin.herdu jî ji hêla `2^-e` ve têne pîvan kirin.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; me `kappa` rast dît.
            let ten_kappa = (ten_kappa as u64) << e; // pîvana 10 ^ kappa vedigere vebêjerê hevpar
            return round_and_weed(
                // EWLEH: me wê bîranîna li jor destnîşan kir.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // dema ku me hemî reqemên entegre rêz kir, xelekê bişkînin.
        // hejmara rastîn ya reqeman `max_kappa + 1` wek `plus1 < 10^(max_kappa+1)` e.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // neguhêrînan vegerînin
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // dema ku li her gavê rastbûnê kontrol dikin, parçeyên perçeyî bidin hev.
    // vê carê em xwe dispêrin pirjimariyên dubare, ji ber ku dabeş dê rastbûnê winda bike.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // reqema paşîn divê girîng be ku me ceribandibû ku berî nehiştina nehêlan, ku `m = max_kappa + 1` (#reqemên di beşa yekpare) de:
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // dê zêde nebe, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // `remainder` bi `10^kappa` parve bikin.
        // herdu jî ji hêla `2^e / 10^kappa` ve têne pîvan kirin, ji ber vê yekê ya paşîn li vir bi zelalî ye.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // dabeşkerê nepenî
            return round_and_weed(
                // EWLEH: me wê bîranîna li jor destnîşan kir.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // neguhêrînan vegerînin
        kappa -= 1;
        remainder = r;
    }

    // me hemî reqemên girîng ên `plus1` çêkiriye, lê ne ewle ye ku ya çêtirîn e.
    // ji bo nimûne, heke `minus1` 3.14153 ... û `plus1` 3.14158 be ..., ji 3.14154 heya 3.14158 5 temsîliyeta kurttirîn a cuda hene lê tenê ya meya herî mezin tenê heye.
    // divê em bi rehetî reqema paşîn kêm bikin û bipirsin gelo ev rep ya çêtirîn e.
    // herî zêde 9 namzet hene (..1 heya ..9), ji ber vê yekê ev zû zû ye.(Qonaxa "rounding")
    //
    // fonksiyonê kontrol dike ka ev reweya "optimal" bi rastî di nav rêzikên ulp de ye, û her weha, dibe ku ji ber xeletiya dorpêçê "second-to-optimal" repr bi rastî çêtirîn be.
    // di her du bûyeran de jî ev vedigere `None`.
    // (Qonaxa "weeding")
    //
    // hemî nîqaşên li vir ji hêla nirxa hevpar `k` ve (lêbelê eşkere) têne pîvan kirin, da ku:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (û her weha, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (û her weha, `threshold > plus1v` ji navberên berê)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // di nav ulpsên 1.5 de du nêzîkê `v` (bi rastî `plus1 - v`) bikin.
        // divê temsîliyeta encamgirtî ji her duyan re jî temsîla herî nêz be.
        //
        // li vir `plus1 - v` tê bikar anîn ji ber ku hesabkirin bi rêzgirtina `plus1` ve têne kirin da ku ji overflow/underflow dûr bikevin (ji ber vê yekê navên ku têne xuyandin).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // reqema paşîn kêm bikin û li nûnertiya herî nêz a `v + 1 ulp` rawestin.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // em bi reqemên nêzîkê `w(n)` re dixebitin, ku di destpêkê de `plus1 - plus1 % 10^kappa` e.piştî ku laşê loopê `n` carî meşand, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // me `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` danî (bi vî rengî `mayî= plus1w(0)`)-ê ku kontrolan hêsan bikin.
            // not bikin ku `plus1w(n)` her gav zêde dibe.
            //
            // sê mercên me hene ku em biqedînin.yek ji wan dê loop nikaribe berdewam bike, lê wê hingê me bi kêmî ve yekê temsîlkariyek derbasdar heye ku tê zanîn ku nêzîkê `v + 1 ulp` ye.
            // em ê wan ji bo kurtahî wekî TC1 bi TC3 nîşan bikin.
            //
            // TC1: `w(n) <= v + 1 ulp`, ango, ev reprika paşîn e ku dikare ya herî nêz be.
            // ev bi `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up` re hevwate ye.
            // digel TC2 (ku `w(n+1)` is valid) kontrol dike an na, ev rê li ber zêdebûna gengaz a li ser hesabkirina `plus1w(n)` digire).
            //
            // TC2: `w(n+1) < minus1`, ango, repa din teqez bi `v` re naşibe.
            // ev bi `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold` re hevwate ye.
            // milê çepê dikare zêde bibe, lê em `threshold > plus1v` dizanin, ji ber vê yekê heke TC1 derew e, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` û em dikarin bi ewlehî li şûna `threshold - plus1w(n) < 10^kappa` biceribînin.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, ango, repa paşîn e
            // ji repr-a nuha bêtir nêzîkê `v + 1 ulp`-yê nine.
            // `z(n) = plus1v_up - plus1w(n)` hatî dayîn, ev dibe `abs(z(n)) <= abs(z(n+1))`.dîsa bihesibînin ku TC1 derew e, `z(n) > 0` ya me heye.du dozên me hene ku em bifikirin:
            //
            // - dema `z(n+1) >= 0`: TC3 dibe `z(n) <= z(n+1)`.
            // her ku `plus1w(n)` zêde dibe, divê `z(n)` kêm bibe û ev eşkere derew e.
            // - dema `z(n+1) < 0`:
            //   - TC3a: mercê pêşîn `plus1v_up < plus1w(n) + 10^kappa` e.bihesibînin ku TC2 derew e, `threshold >= plus1w(n) + 10^kappa` ji ber vê yekê ew nikare zêde bibe.
            //   - TC3b: TC3 dibe `z(n) <= -z(n+1)`, ango, `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   TC1 înkar `plus1v_up > plus1w(n)` dide, ji ber vê yekê dema ku bi TC3a re têkildar be ew nikare zêde bibe an binê avê bike.
            //
            // di encamê da, divê em dema `TC1 || TC2 || (TC3a && TC3b)` rawestin.ya jêrîn bi berevajiya wê ve wekhev e, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // reprika herî kurt nikare bi `0` biqede
                plus1w += ten_kappa;
            }
        }

        // kontrol bikin ka ev nûnertî di heman demê de nûnertiya herî nêzikî `v - 1 ulp` e jî.
        //
        // ev ji bo mercên bidawîbûna `v + 1 ulp` bi tenê yek e, li şûna wê hemî `plus1v_up` bi `plus1v_down` tê guhertin.
        // analîza zêdebûnê wekhev digire.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // naha di navbera `plus1` û `minus1` de nûnertiya meya herî nêz bi `v` re heye.
        // ev pir lîberal e, her çend, ji ber vê yekê em her `w(n)` red dikin ne di navbera `plus0` û `minus0`, ango, `plus1 - plus1w(n) <= minus0` an `plus1 - plus1w(n) >= plus0`.
        // em rastiyên ku `threshold = plus1 - minus1` û `plus1 - plus0 = minus0 - minus1 = 2 ulp` bikar tînin bikar tînin.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Pêkanîna moda herî kurt ji bo Grisu bi paşdaçûna Dragon.
///
/// Divê ev ji bo pir rewşan were bikar anîn.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // EWLEH: : Kontrola deyn ne têra xwe aqilmend e ku bihêle em `buf` bikar bînin
    // di branch ya duyemîn de, ji ber vê yekê em li vir temenê jiyanê şûştin.
    // Lê heke `format_shortest_opt` `None` vegerîne em tenê `buf`-ê ji nû ve bikar tînin da ku ev baş e.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Ji bo Grisu pêkanîna awayê rast û sabît.
///
/// Ew `None` vedigerîne dema ku ew ê nûnertiyek nerast vegerîne rewşek din.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // ji me re herî kêm sê bit teqeziya pêvek hewce dike
    assert!(!buf.is_empty());

    // `v` normal bikin û pîvan bikin.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // `v` li beşên entegral û perçeyî parve bikin.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // `v` kevn û `v` nû (ji hêla `10^-k` ve hatî pîvankirin) xeletiyek <1 ulp (Teorema 5.1) heye.
    // ji ber ku em nizanin çewtî erênî an neyînî ye, em du texmînan ji hevûdu veqetandî bikar tînin û xeletiya herî zêde ya 2 ulps heye (heman bi rewşa herî kurt).
    //
    //
    // armanc ew e ku meriv rêzikên reqemên ku bi `v - 1 ulp` û `v + 1 ulp` hem jî hevpar in, rast bibîne, da ku em herî zêde ji xwe ewle bin.
    // heke ev ne gengaz be, em nizanin kîjan ji bo `v` derketina rast e, ji ber vê yekê em dev jê berdidin û paş ve vedigerin.
    //
    // `err` li vir wekî `1 ulp * 2^e` tête diyar kirin (di ulpoya `vfrac` de heman tişt e), û her ku `v` mezin bibe em ê wê pîvan bikin.
    //
    //
    //
    let mut err = 1;

    // `10^max_kappa`-a herî mezin ji `v`-an zêdetir nahesibînin (bi vî rengî `v < 10^(max_kappa+1)`).
    // ev bendek jorîn a `kappa` li jêr e.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // heke em bi sînorkirina reqema paşîn re dixebitin, pêdivî ye ku em tampona berî rendering-a rastîn kurt bikin da ku ji dorpêçkirina du qat dûr bisekinin.
    //
    // not bikin ku dema dorpêçkirin çêdibe ku em dîsa tamponê mezin bikin!
    let len = if exp <= limit {
        // wey, em nikarin *yek* reqemî jî hilberînin.
        // ev gengaz e dema ku, bêje, me tiştek mîna 9.5 girtibe û ew were dorpêçkirin 10.
        //
        // di prensîbê de em dikarin tavilê bi tamponek vala bangî `possibly_round` bikin, lê pîvandina `max_ten_kappa << e` bi 10-an dikare bibe sedema zêdebûnê.
        //
        // bi vî rengî em li vir bênamûs in û xeletiya xeletiyê bi faktorê 10 fireh dikin.
        // ev ê rêjeya neyînî ya derewîn zêde bike, lê tenê pir,*pir* hindik;
        // ew tenê dikare bi berbiçavî girîng bibe dema ku mantissa ji 60 bîtan mezintir be.
        //
        // EWLEH: : `len=0`, ji ber vê yekê ferzkirina destpêkirina vê bîranînê sivik e.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // parçeyên yekpare bidin.
    // çewtî bi tevahî perçeyî ye, ji ber vê yekê em ne hewce ne ku wê di vê beşê de kontrol bikin.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // reqemên ku hêj ne hatine dayîn
    loop {
        // her gav bi kêmî ve yek reqemek me heye ku em nehêsan bidin hev:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (ev diyar dike ku `remainder = vint % 10^(kappa+1)`)
        //
        //

        // `remainder` bi `10^kappa` parve bikin.herdu jî ji hêla `2^-e` ve têne pîvan kirin.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // tampon tijî ye?pasa dorpêçê bi ya mayî re bimeşînin.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // EWLEH: : me `len` gelek bayt destnîşan kirin.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // dema ku me hemî reqemên entegre rêz kir, xelekê bişkînin.
        // hejmara rastîn ya reqeman `max_kappa + 1` wek `plus1 < 10^(max_kappa+1)` e.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // neguhêrînan vegerînin
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // parçeyên perçeyî bidin.
    //
    // di prensîbê de em dikarin heya reqema berdest a paşîn berdewam bikin û rastbûnê kontrol bikin.
    // mixabin em bi jimareyên hejmar-qediyayî re dixebitin, ji ber vê yekê ji me re hin pîvanek hewce dike ku da ku em zêdehiyê destnîşan bikin.
    // V8 `remainder > err` bikar tîne, ku derew dibe dema ku yekem hejmarên girîng ên `i` yên `v - 1 ulp` û `v` ji hev cûda dibin.
    // lêbelê ev gelek inputên wekî din derbasdar red dike.
    //
    // ji ber ku di qonaxa paşîn de tespîta serrast a rast heye, em li şûna wê pîvana tundtir bikar tînin:
    // em berdewam dikin heya ku `err` `10^kappa / 2` derbas dike, da ku di navbera `v - 1 ulp` û `v + 1 ulp` de teqez du an zêdetir nûneriyên dorpêçkirî hebin.
    //
    // ev ji bo referansê, ji `possibly_round` re du berhevdanên yekem e.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // neguhêrbar, ku `m = max_kappa + 1` (#reqemên di beşa yekpare):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // dê zêde nebe, `2^e * 10 < 2^64`
        err *= 10; // dê zêde nebe, `err * 10 < 2^e * 5 < 2^64`

        // `remainder` bi `10^kappa` parve bikin.
        // herdu jî ji hêla `2^e / 10^kappa` ve têne pîvan kirin, ji ber vê yekê ya paşîn li vir bi zelalî ye.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // tampon tijî ye?pasa dorpêçê bi ya mayî re bimeşînin.
        if i == len {
            // EWLEH: : me `len` gelek bayt destnîşan kirin.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // neguhêrînan vegerînin
        remainder = r;
    }

    // bêtir hesabkirin bêkêr e (`possibly_round` teqez têk diçe), ji ber vê yekê em dev jê berdidin.
    return None;

    // me hemî reqemên xwestî yên `v` çêkirine, ku divê ew jî bi reqemên têkildar ên `v - 1 ulp` re be.
    // naha em kontrol dikin ka temsîliyetek bêhempa heye ku hem ji hêla `v - 1 ulp` û `v + 1 ulp` ve hatî parve kirin heye;ev dikare yan ji reqemên çêkirî re, an jî ji bo guhertoya dorpêçkirî ya wan reqeman yek be.
    //
    // heke rêze navnîşanên pirjimar ên heman dirêjahî hebin, em nekarin pê ewle bin û divê li şûna `None` vegerin.
    //
    // hemî nîqaşên li vir ji hêla nirxa hevpar `k` ve (lêbelê eşkere) têne pîvan kirin, da ku:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // EWLEH: : yekem `len` byteyên `buf` divê werin destpêkirin.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (ji bo referansê, xeta xalxalok nirxa rastîn ji bo nimînendeyên gengaz ên di jimareya dayîn de diyar dike.)
        //
        //
        // xelet pir mezin e ku di navbera `v - 1 ulp` û `v + 1 ulp` de herî kêm sê nimûneyên gengaz hene.
        // em nikarin diyar bikin ka kîjan rast e.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // bi rastî, 1/2 ulp bes e ku du nimînendeyên gengaz destnîşan bike.
        // (ji bîr mekin ku hem ji bo `v - 1 ulp` û hem jî `v + 1 ulp` ji me re temsîliyetek bêhempa lazim e.) ev ê zêde nebe, ji ber ku `ulp < ten_kappa` ji kontrola yekem.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // heke `v + 1 ulp` nêzîkê temsîla dorpêçkirî ye (ku jixwe di `buf` de ye), wê hingê em dikarin bi ewlehî vegerin.
        // not bikin ku `v - 1 ulp`*dikare* ji nimînendeya heyî kêmtir be, lê wekî `1 ulp < 10^kappa / 2`, ev merc bes e:
        // mesafe di navbera `v - 1 ulp` û nûneratiya heyî de nikare ji `10^kappa / 2` derbas bibe.
        //
        // şert bi `remainder + ulp < 10^kappa / 2` re dibe.
        // ji ber ku ev dikare bi hêsanî biherike, pêşî `remainder < 10^kappa / 2` kontrol bike.
        // me berê wê `ulp < 10^kappa / 2` piştrast kiriye, ji ber vê yekê heya ku `10^kappa` piştî her tiştî zêde nebe, venêrana duyemîn baş e.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // EWLEH: : bangvanê me ew bîranîn destpêkir.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------mayîn------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // ji hêla din ve, heke `v - 1 ulp` nêzîkê temsîla dorpêçkirî ye, divê em dor bikin û vegerin.
        // ji ber heman sedemê hewce nake ku em `v + 1 ulp` kontrol bikin.
        //
        // şert bi `remainder - ulp >= 10^kappa / 2` re dibe.
        // dîsa em yekemcar kontrol dikin ka `remainder > ulp` (not bikin ku ev ne `remainder >= ulp` e, ji ber ku `10^kappa` carî sifir nine).
        //
        // jî not bikin ku `remainder - ulp <= 10^kappa`, ji ber vê yekê kontrola duyemîn zêde nabe.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // EWLEHIY: : Divê bangkerê me ew bîranîn destnîşan kiribe.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // tenê ku ji me re rastbûna sabit hat xwestin hejmarek zêde lê zêde bikin.
                // di heman demê de pêdivî ye ku em kontrol bikin ku, heke tampona orjînal vala bû, reqema pêvek tenê dema `exp == limit` (doza edge) dikare were zêdekirin.
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // EWLEH: : me û bangvanê xwe ew bîranîn destpêkir.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // wekî din em mehkûm in (ango, hin nirxên di navbera `v - 1 ulp` û `v + 1 ulp` de dorpêç dikin û yên din jî dor dikin) û dev jê berdidin.
        //
        None
    }
}

/// Pêkanîna moda rast û sabît ji bo Grisu bi paşdaçûna Dragon.
///
/// Divê ev ji bo pir rewşan were bikar anîn.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // EWLEH: : Kontrola deyn ne têra xwe aqilmend e ku bihêle em `buf` bikar bînin
    // di branch ya duyemîn de, ji ber vê yekê em li vir temenê jiyanê şûştin.
    // Lê heke `format_exact_opt` `None` vegerîne em tenê `buf`-ê ji nû ve bikar tînin da ku ev baş e.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}