//! Nirxek xala gerdûnî di nav perçeyên şexsî û rêzikên çewtiyê de vedişêre.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Nirxa qedandî ya bê îmze şîfre kirin, wusa ku:
///
/// - Nirxa orjînal bi `mant * 2^exp` re dibe.
///
/// - Her hejmarek ji `(mant - minus)*2^exp` heya `(mant + plus)* 2^exp` dê li nirxa xwerû dor were.
/// Range tenê dema ku `inclusive` `true` be tê de ye.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Mantîsa pîvandî.
    pub mant: u64,
    /// Rêzeya xeletiya jêrîn.
    pub minus: u64,
    /// Rêzeya çewtiya jorîn.
    pub plus: u64,
    /// Nîşaneya hevpar a di bingeha 2 de.
    pub exp: i16,
    /// Rast e dema ku xeletiya xeletiyê tê de be.
    ///
    /// Di IEEE 754-an de, ev rast e dema ku mantîsa orjînal jî bû.
    pub inclusive: bool,
}

/// Nirxa nevekirî ya deşîfrekirî.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Bêdawî, an erênî an jî neyînî.
    Infinite,
    /// Zero, an erênî an jî neyînî.
    Zero,
    /// Hejmarên qedandî yên bi zeviyên bêtir deşîfre kirin.
    Finite(Decoded),
}

/// Cûreyek xala gerok ku dibe `dekod``.
pub trait DecodableFloat: RawFloat + Copy {
    /// Nirxa normalîzekirî ya herî kêm erênî.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Nîşanek (dema neyînî rast e) û nirxa `FullDecoded` ji jimareya xala gerînbar vedigerîne.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // cîran: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode her dem pêşnumayê diparêze, ji ber vê yekê mantissa ji bo binormalan tê pîvan kirin.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // cîran: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // li wir maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // cîran: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}