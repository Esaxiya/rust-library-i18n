//! Algorîtmayên cihêreng ên ji kaxezê.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Hejmara girîng û bitên li Fp
const P: u32 = 64;

// Em bi tenê ji bo *hemî* pêşkeşkeran nêzîkbûna çêtirîn tomar dikin, ji ber vê yekê guherbara "h" û mercên pêwendîdar dikarin werin hilanîn.
// Ev ji bo çend kilobayt cîh performansê bazirganî dike.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Di piraniya avahîsaziyan de, operasyonên xala floating xwedan mezinahiyek bit eşkere ye, ji ber vê yekê rastiya hesabê li ser bingehek per-operasyonê tête diyar kirin.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Li ser x86, heke pêvekên SSE/SSE2 tune ne, x87 FPU ji bo operasyonên float tê bikar anîn.
// x87 FPU bi rasterast bi 80 bit rastîn dixebite, ku tê vê wateyê ku operasyon dê bi 80 bitan dorpêç bikin ku bibe sedema dorpêçkirina du qat dema ku nirx di dawiyê de wekî temsîl kirin
//
// 32/64 nirxên float bit.Ji bo derbaskirina viya, peyva kontrolê ya FPU dikare were saz kirin da ku hesaban di pîvana xwestî de pêk bîne.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Avahiyek ku ji bo parastina nirxa xwerû ya peyva kontrolê ya FPU tê bikar anîn, da ku dema avahî tê avêtin dikare were vegerandin.
    ///
    ///
    /// x87 FPU tomarek 16 bîtan e ku zeviyên wê wiha ne:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Belgekirin ji bo hemî waran di Manualê Pêşvebirê Nermalava IA-32 Architectures de (Volume 1) heye.
    ///
    /// Tenê qada ku ji bo koda jêrîn têkildar e PC, Kontrola Precision e.
    /// Ev qad rastbûna operasyonên ku ji hêla FPU ve têne kirin diyar dike.
    /// Ew dikare were saz kirin ku:
    ///  - 0b00, yek rastîn ango, 32-bit
    ///  - 0b10, teqeziya ducar ango, 64-bit
    ///  - 0b11, teqeziya duqatî dirêjkirî ango, 80-bit (rewşa pêşwext) Nirxa 0b01 hatî parastin û divê neyê bikar anîn.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // EWLEH: : talîmata `fldcw` hatî vekolîn kirin ku karibe pê re rast bixebite
        // her `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Em ji bo piştgiriya LLVM 8 û LLVM 9 hevoksaziya ATT bikar tînin.
                options(att_syntax, nostack),
            )
        }
    }

    /// Zeviya rastîn a FPU li `T` saz dike û `FPUControlWord` vedigerîne.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Nirxê ji bo qada Kontrola Precision ya ku ji bo `T` guncan e hesab bikin.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bit
            8 => 0x0200, // 64 bit
            _ => 0x0300, // default, 80 bit
        };

        // Nirxa xwerû ya bêjeya kontrolê bistînin da ku paşê vegerînin, dema ku avahiya `FPUControlWord` davêje SAFETY: talîmata `fnstcw` hatî kontrol kirin ku bi her `u16` re rast kar bike
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Em ji bo piştgiriya LLVM 8 û LLVM 9 hevoksaziya ATT bikar tînin.
                options(att_syntax, nostack),
            )
        }

        // Peyva kontrolê li gorî rastbûna xwestin saz bikin.
        // Ev bi maskkirina rastkirina kevn (bitên 8 û 9, 0x300) û li şûna wê ala rastîn a li jor hatî jimartin pêk tê.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Riya lezgîn a Bellerophon bi karanîna hejmarên rastîn û dirûşmên makîner.
///
/// Ev di nav fonksiyonek veqetandî de tête derxistin, da ku ew berî ceribandina bignumê were ceribandin.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Em nirxa rastîn bi MAX_SIG-ê re nêzê hev dikin, ev tenê redkirinek bilez, erzan e (û her weha kodê mayî ji fikara binê avê azad dike).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Riya bilez bi giringî ve girêdayî ye ku bi arîtmetîk ve bêyî dorpêçek navîn li hejmara rastê ya bîtan were gerandin.
    // Li ser x86 (bêyî SSE an SSE2) ev pêdivî ye ku rastbûna stacka x87 FPU were guhertin da ku ew rasterast li 64/32 bit dor were.
    // Fonksiyona `set_precision` lênihêrîna danîna rastbûna li ser avahîsazên ku pêdivî bi danîna wê bi guhertina dewleta cîhanî digire (mîna peyva kontrolê ya x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Doza e <0 li branch-a din nayê qatkirin.
    // Hêzên negatîf di binaryê de, ku têne dorpêçkirin, beşek dabeşker a dûbare dubare dikin, ku dibe sedema çewtiyên rastîn (û carinan jî pir girîng!) Di encama paşîn de.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algorîtmaya Bellerophon koda sivik e ku ji hêla analîzên hejmarî yên ne-sêwiranî ve tête rastdar kirin.
///
/// Ew "f" li ser floatek bi 64 bit giringî dorpêç dike û wê bi nêzikbûna herî baş a `10^e` (di heman formatê xala gemarî de) zêde dike.Ev bi gelemperî bes e ku encamek rast werbigire.
/// Lêbelê, dema ku encam di navbera du lehiyên (ordinary) cîran de nêzîkê nîvê be, xeletiya dorpêçê ya pêkvejiyanê ji pirbûna du texmînan tê vê wateyê ku encam dikare bi çend bîtan be.
/// Dema ku ev çêdibe, Algorîtmaya dubare R tiştan sererast dike.
///
/// "close to halfway"-destê wavy bi analîzkirina hejmarî ya di kaxezê de rast tête çêkirin.
/// Bi gotinên Clinger:
///
/// > Slop, ku di yekeyên bitika herî hindik girîng de tê vegotin, ji bo xeletiyê ve girêdayî ye
/// > di dema hejmartina xala gemarî ya nêzikbûna f * 10 ^ e de komkirî ye.(Slop e
/// > ne ji xeletiya rastîn ve girêdayî ye, lê cûdahiya di navbera nêzikbûna z û
/// > nêzîkbûna çêtirîn çêtirîn ku p bitên girîng û girîng bikar tîne.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Dozên abs(e) <log5(2^N) di fast_path() de ne
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Gelo qurûş ew qas mezin e ku cûdahiyek çêbike dema ku dor li n bîtan were gerandin?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Algorîtmayek dubare ku nêzikbûna xala gemarê ya `f * 10^e` çêtir dike.
///
/// Her dubare di cîhê paşîn de yekîneyek nêztir dibe, ku bê guman ger `z0` jî bi nermî dûr be pir bi dem dirêj digire.
/// Bi kêfxweşî, gava ku ji bo Bellerophon wekî paşverû were bikar anîn, nêzikbûna destpêkî bi piranî yek ULP dûr e.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Hejmarên erênî `x`, `y` bibînin ku `x / y` tam `(f *10^e) / (m* 2^k)` e.
        // Ev ne tenê ji danûstendina bi nîşanên `e` û `k` dûr dikeve, di heman demê de em hêza du hevpar a `10^e` û `2^k` jî ji holê radikin da ku hejmaran piçûktir bikin.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Vê yekê hinekî bêserûber nivîsandiye ji ber ku bignûmên me hejmarên neyînî piştgirî nakin, ji ber vê yekê em nirxa mutleq + agahdariya nîşanê bikar tînin.
        // Pirbûna bi m_digît nikare zêde bibe.
        // Heke `x` an `y` têra xwe mezin in ku em hewce ne ku li ser zêdebûnê bi fikar bin, wê hingê ew jî têra xwe mezin in ku `make_ratio` perçeyek ji hêla faktorê 2 ^ 64 an zêdetir kêm kiriye.
        //
        //
        let (d2, d_negative) = if x >= y {
            // X bêtir hewce nekin, clone() xilas bikin.
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Hê jî pêdivî bi y e, nusxeyek çêbike.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// `x = f` û `y = m` hatine danîn ku `f` wekî hejmar reqemên dehsala navnîşê nîşan dide û `m` girîngiya xaleke nêzikbûnê ye, rêjeya `x / y` bi `(f *10^e) / (m* 2^k)` re bikin yek, dibe ku bi hêza du hevbeş hebe.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, ji xeynî ku em perçeyê bi hin hêza du kêm dikin.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Ev nikare zêde bibe ji ber ku ew `e` erênî û `k` negatîf hewce dike, ku tenê dikare ji bo nirxên pir nêzîkê 1-ê çêbibe, ku tê vê wateyê ku `e` û `k` dê berawirdî piçûk be.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Ev jî nikare zêde bibe, li jor binihêrin.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), dîsa bi hêza hevpar a du kêm dibe.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Bi têgihiştinî, Algorîtm M awayê herî hêsan e ku veguheztina dehjimar li float.
///
/// Em rêjeyek ku wekhevî `f * 10^e` ye pêk tînin, dûv re hêzên du davêjin heta ku ew girîngiya floatek derbasdar dide.
/// Nîşaneya binary `k` çend carî ye ku me hejmar an danasîn bi du qatan zêde kir, ango, her dem `f *10^e` bi `(u / v)* 2^k` re ye.
/// Dema ku me girîngî fêr bû, em tenê hewce ne ku bi sehkirina mayîna dabeşê, ku di karûbarên arîkar ên jêrîn de têne çêkirin, dorpêç bikin.
///
///
/// Ev algorîtmaya super hêdî, tevî ku bi optimîzasyona ku di `quick_start()` de hatî vegotin jî hêdî ye.
/// Lêbelê, ew ji algorîtmayên herî hêsan e ku ji bo zêdebûn, binavbûn û encamên binormal xwe biguncîne.
/// Dema ku Bellerophon û Algorîtm R zêde dibin ev pêkanîn digire ser xwe.
/// Tespîtkirina binavbûn û zêdebûnê hêsan e: Rêjî hîn jî ne girîngiyek nav-range ye, lêbelê pêşangeha minimum/maximum gihîştiye.
/// Di bûyera zêdebûnê de, em bi tenê bêdawiyê vedigerin.
///
/// Destwerdana binav û binormalan aloztir e.
/// Pirsgirêkek mezin ev e ku, bi vebêjerê herî kêm, dibe ku rêje hîn jî ji bo girîngiyek pir mezin be.
/// Ji bo hûragahiyan li underflow() binêrin.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // Optimîzasyona gengaz FIXME: big_to_fp giştî bike da ku em li vir, tenê bêyî dorpêçkirina duqatî, hevkêşeya fp_to_float(big_to_fp(u)) bikin.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Em neçar in ku li pêşangeha herî kêm bisekinin, heke em heya `k < T::MIN_EXP_INT` bisekinin, wê hingê em ê ji hêla faktorê du ve bimînin.
            // Mixabin ev tê vê wateyê ku em neçar in ku hejmarên normal ên bi vebêjerê herî kêm-taybetî binxêz bikin.
            // FIXME formûlek xweşiktir bibîne, lê testa `tiny-pow10` bixebitîne da ku pê ew rast be rast e!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Bi kontrola dirêjahiya bit re li ser pir dubareyên Algorîtm M derbas dibe.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Dirêjahiya bit texmîna du logarîtma bingehîn, û log(u / v) = log(u), log(v) e.
    // Texmîn ji hêla herî zêde 1 ve tête dûr e, lê her dem her gav kêm-texmînek heye, ji ber vê yekê xeletiya li ser log(u) û log(v) ji heman nîşaneyê ne û betal dibin (ger her du mezin bin).
    // Ji ber vê yekê xeletiya ji bo log(u / v) jî herî zêde yek e.
    // Rêjeya hedef yek e ku u/v di nav-giringiyek girîng de ye.Ji ber vê yekê rewşa bidawîbûna me log2(u / v) bîtên girîng û plus/minus yek e.
    // FIXME Li bitika duyemîn nihêrîn dikare texmînê baştir bike û ji hin dabeşbûnên din dûr bisekine.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Binavbûn an binormal.Wê ji fonksiyona sereke re bihêlin.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Seravgirtin.Wê ji fonksiyona sereke re bihêlin.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Ratio ne girîngiyek di nav-range de ye û bi vebêjerê herî kêm heye, ji ber vê yekê em hewce ne ku bitsên zêdeyî dorpêç bikin û pêşnuma li gorî wê sererast bikin.
    // Nirxa rastîn nuha wiha xuya dike:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(ji hêla rem ve tê nimînandin)
    //
    // Ji ber vê yekê, dema ku bitikên dorpêçandî!!= 0.5 ULP, ew bi xwe biryara dorpêçê didin.
    // Gava ku ew wekhev in û mayî ne-sifir e, hêjayî pêdivî ye ku were dorpêç kirin.
    // Tenê dema ku bitikên dorpêçandî 1/2 bin û yê mayî jî sifir be, rewşek me ya nîv-hetanî heye.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Dor-bi-hev-asayî, ji hêla dorpêçê ve li ser bingeha mayî ya dabeşkê ve qeşeng dibe.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}