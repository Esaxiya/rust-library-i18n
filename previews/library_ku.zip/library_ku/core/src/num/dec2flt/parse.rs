//! Rêzkirin û dabeşkirina rêzika dehanî ya formê:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Bi gotinên din, hevoksaziya xalî-xalî ya standard, bi du îstisnayan: Nîşanek tune, û destgirtina "inf" û "NaN" tune.Vana ji hêla fonksiyona ajokar (super::dec2flt) ve têne rêve kirin.
//!
//! Her çend naskirina têketinên derbasdar bi rengek hêsan e jî, ev modul jî neçar e ku guherînên nederbasdar, qet panic red bike, û gelek venêran pêk bîne ku modûlên din pişta xwe dispêrin ne panic (an zêde diherike).
//!
//! Ji bo ku xerabtir bibe, hemî tiştên ku di derbasbûnek tenê de li ser inputê diqewimin.
//! Ji ber vê yekê, dema ku tiştek guhartin bikin, hişyar bimînin, û bi modulên din re dubare bikin.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Parçeyên balkêş ên têlek dehek.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Pêşkêşkera dehjimarî, garantî kir ku ji 18 reqemên dehsalan kêmtir e.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Kontrol dike ka rêzika têketinê hejmar a nuqteya gêrûzê ya derbasdar e û heke wusa be, beşa yekpare, beşa perçeyî û pêşangeha tê de bicîh bike.
/// Nîşanan hilnagire.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Berî 'e' reqem tune
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Ji me re berî an piştî xalê bi kêmî ve hejmar yek pêdivî ye.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Li pey beşa perçeyî ya paşverû
            }
        }
        _ => Invalid, // Li pey rêzika reqema yekê ya paşîn
    }
}

/// Reqemên dehanî heya yekem tîpa ne-reqemî radike.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Vebijêrk û lêpirsîna çewtiyê ya pêşangehê.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Li pey exponentê çopê dişopînin
    }
    if number.is_empty() {
        return Invalid; // Pêşkêşkera vala
    }
    // Di vê nuqteyê de, bê guman rêzeyek jimareyên me yên derbasdar hene.Dibe ku pir dirêj be ku meriv têxe nav `i64`, lê heke ew ew qas mezin be, têgihiştin bê guman sifir an bêdawî ye.
    // Ji ber ku her sifir di reqemên dehsalî de tenê vesazê bi +/-1 eyar dike, li exp=10 ^ 18 pêdivî ye ku têkevtinê 17 exabyte (!) sifir be da ku ji dûr ve jî nêzê sînorkirî be.
    //
    // Ev ne tam meseleyek karanînê ye ku pêdivî ye ku em jê re têr bikin.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}