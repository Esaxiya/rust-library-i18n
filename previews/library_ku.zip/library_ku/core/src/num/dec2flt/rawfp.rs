//! Li ser IEEE 754 erênî gemî dibezîn.Hejmarên negatîf nayên destgirtin û hewce nebin.
//! Jimareyên xala gerdûnî yên normal wekî (frac, exp) temsîliyeta kanonîkî heye ku wusa ye ku nirx 2 <sup>exp</sup> * e (1 + sum(frac[N-i] / 2<sup>i</sup>)) li wir N hejmara bîtan e.
//!
//! Subnormal hinekî cuda û ecêb in, lê heman prensîp derbasdar e.
//!
//! Lêbelê, li vir, em wan wekî (sig, k) bi f erênî temsîl dikin, wusa ku nirx f * e
//! 2 <sup>e</sup> .Ji xeynî ku "hidden bit" eşkere dike, ev vebêjer bi navê veguherîna mantissa diguheze.
//!
//! Bi rengek din vebêjin, bi gelemperî float wekî (1) têne nivîsandin lê li vir ew wekî (2) têne nivîsandin:
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Em ji (1) re **nûnertiya perçeyî** û (2) dibêjin **nûnertiya entegre**.
//!
//! Di vê modulê de gelek fonksiyon tenê jimarên normal digirin.Rûtinên dec2flt bi kevneperestî ji bo hejmarên pir piçûk û pir mezin riya hêdî ya gerdûnî-rast (Algorîtm M) digirin.
//! Ew algorîtm tenê next_float() hewce dike ku binnormal û sifiran rêve dibe.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Alîkarek trait ku pêşî li duplicasyonê bigire hemî koda veguherînê ya `f32` û `f64`.
///
/// Ji bo ku ev pêdivî ye şîroveya doktora module dêûbav bibînin.
///
/// Pêdivî ye ku **qet carî** ji bo celebên din neyê bicîh kirin an jî li derveyî moduleya dec2flt were bikar anîn.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Tîpa ku ji hêla `to_bits` û `from_bits` ve tê bikar anîn.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Transmutasyonek raweyî ya bi jimareyek rast pêk tîne.
    fn to_bits(self) -> Self::Bits;

    /// Ji hejmarekê veguherînek xav pêk tîne.
    fn from_bits(v: Self::Bits) -> Self;

    /// Kategoriya ku ev hejmar dikeve nav xwe vedigerîne.
    fn classify(self) -> FpCategory;

    /// Mantissa, pêşan û nîşana wekî hejmarên yekbûyî vedigerîne.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Float deşîfre dike.
    fn unpack(self) -> Unpacked;

    /// Ji jimareyek piçûk a ku tam dikare were temsîlkirin tê avêtin.
    /// Panic heke hejmar nekare were temsîl kirin, koda din a di vê modulê de piştrast dike ku wê çu carî nehêle.
    fn from_int(x: u64) -> Self;

    /// Nirxa 10 <sup>e</sup> ji maseyek pêş-hesabkirî digire.
    /// Panics ji bo `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Nav çi dibêje.
    /// Ji kodkirina hişk hêsantir e ku ji jînwergirtina xwezayî û hêviya ku LLVM berdewam wê qat dike.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Kevneperestek bi reqemên dehsal ên têkelan ve girêdayî ye ku nikare zêdehî an sifir an
    /// binormal.Dibe ku vebêjera dehsal a nirxa normal a herî zêde, ji ber vê yekê navê lê kiriye.
    const MAX_NORMAL_DIGITS: usize;

    /// Gava ku hêjmara dehsal a herî girîng xwedî qîmetek cîh ji vê mezintir be, bê guman hejmar heya bêdawîtiyê tê dorpêç kirin.
    ///
    const INF_CUTOFF: i64;

    /// Gava ku hejmarek dehjimarî ya herî girîng xwedî qîmetek cîh ji vê kêmtir be, bê guman hejmar bi sifirê tê zivirandin.
    ///
    const ZERO_CUTOFF: i64;

    /// Di dîmenderê de hejmara bîtan.
    const EXP_BITS: u8;

    /// Hejmara bitên di nîşankirin û * de bitika veşartî jî tê de.
    const SIG_BITS: u8;

    /// Hejmara bitên di nîşankirin û
    const EXPLICIT_SIG_BITS: u8;

    /// Di temsîliyeta perçeyî de dîmenderê herî zagonî.
    const MAX_EXP: i16;

    /// Di temsîliyeta perçeyî de vebijarka herî kêm a qanûnî, ji derveyî binormalan.
    const MIN_EXP: i16;

    /// `MAX_EXP` ji bo temsîliyeta entegre, ango, bi veguheztina serlêdayî.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` şîfrekirî (ango, bi alîgiriya berdêlê)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` ji bo temsîliyeta entegre, ango, bi veguheztina serlêdayî.
    const MIN_EXP_INT: i16;

    /// Di temsîliyeta entegre de girîngiya normalîzekirî ya herî zêde
    const MAX_SIG: u64;

    /// Di temsîliyeta entegre de girîngiya normalîzekirî ya herî kêm
    const MIN_SIG: u64;
}

// Bi piranî çareseriyek ji bo #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Mantissa, pêşan û nîşana wekî hejmarên yekbûyî vedigerîne.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Bias exponent + guherîna mantissa
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe nediyar e gelo `as` li hemî platforman rast dorê digire.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Mantissa, pêşan û nîşana wekî hejmarên yekbûyî vedigerîne.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Bias exponent + guherîna mantissa
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe nediyar e gelo `as` li hemî platforman rast dorê digire.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// `Fp` veguherîne celebê float ê herî nêz ê makîneyê.
/// Encamên bin normal nagire.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 64 bit e, ji ber vê xe xelasiya 63-ya mantissa heye
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Bi nîşana 64-bit ve bi T::SIG_BITS bitên bi nîv-bi-yek.
/// Bi zêdebûna pêşangehê re mijûl nabe.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Guherîna mantissa sererast bikin
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Berevajî ya `RawFloat::unpack()` ji bo hejmarên normalîzekirî.
/// Heke nîşanker an pêşangeh ji bo hejmarên normalîzekirî ne derbasdar be Panics.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Bitek veşartî derxînin
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Ji bo pêşbirka nîşangir û guherîna mantissayê verastkerê rast bikin
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Bişkoja nîşanê li 0 ("+") bihêlin, hejmarên me hemî erênî ne
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Binormalek ava bikin.Mantîsa 0 destûr dide û sifir çêdike.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Pêşniyara kodkirî 0 ye, nîşana 0 0 ye, ji ber vê yekê em tenê neçar in ku bîtan ji nû ve şîrove bikin.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Bignumek bi Fp nêzîkê bikin.Di nav 0.5 ULP de bi nîv-bi-hevûdu dorpêç dike.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Me hemî bîtên ber nîşana `start` qut kirin, ango, em bi bandorek bi mîqyasek `start` rast-rast diguherin, ji ber vê yekê jî pêşangeha ku ji me re hewce dike ev e.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Dor (half-to-even) bi bîtên qutkirî ve girêdayî ye.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Hejmara xala gemarî ya herî mezin ji argumanê bi hişkî piçûktir dibîne.
/// Bi binormal, sifir, an binavbûna nîşangir re mijûl nabe.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Hejmara xala gemarî ya herî piçûk ji argumanê bi hişkî mezintir bibînin.
// Vê xebitandinê têr dibe, ango, next_float(inf) ==inf.
// Berevajî piraniya kodê di vê modulê de, ev fonksiyon sifir, binormal û bêdawîtiyê dike.
// Lêbelê, wekî hemî kodên din ên li vir, ew bi NaN û hejmarên neyînî re mijûl nabe.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Ev pir baş xuya dike ku rast be, lê ew kar dike.
        // 0.0 wekî bêjeya hemî-sifir tête kodkirin.Subnormal 0x000m ... m ne ku m mantissa ye.
        // Bi taybetî, binormaliya herî piçûk 0x0 ... 01 û ya herî mezin jî 0x000F ... F.
        // Hejmara normal a herî piçûk 0x0010 ... 0 e, ji ber vê yekê ev rewşa goşeyê jî dixebite.
        // Ger zêdebûn ji mantissayê biherike, gava ku em dixwazin, beşa hilgirtinê pêşangehê zêde dike, û perçeyên mantissayê sifir dibin.
        // Ji ber peymana bit veşartî, ya ku em dixwazin jî ev e!
        // Di dawiyê de, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}