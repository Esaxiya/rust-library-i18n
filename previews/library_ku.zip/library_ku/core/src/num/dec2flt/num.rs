//! Fonksiyonên kêrhatî yên ji bo bignumên ku zêde manedar nabin ku veguherin metodan.

// FIXME Navê vê modulê hebkî mixabin, ji ber ku modulên din jî `core::num` tînin.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Test bikin ka kurtkirina hemî bitên ji `ones_place` kêmtir girîng çewtiyek têkildar a ji 0.5 ULP kêmtir, wekhev, an mezintir destnîşan dike an na.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Heke hemî bîtên mayî sifir in, ew= 0.5 ULP, wekî din> 0.5 Ger êdî bits tune (half_bit==0), li jêr jî rast wekhev vedigere.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Zincîreyek ASCII veguherîne ku tenê reqemên dehjimarî li `u64` digire.
///
/// Kontrolên ji bo tîpên zêde an nederbasdar nake, ji ber vê yekê heke gazî ne baldar be, encam derew e û dikare panic bike (her çend ew `unsafe` nebe).
/// Wekî din, têlên vala wekî sifir têne destgirtin.
/// Ev fonksiyon ji ber ku heye
///
/// 1. bikaranîna `FromStr` li `&[u8]` hewceyê `from_utf8_unchecked` e, ku xirab e, û
/// 2. perçekirina encamên `integral.parse()` û `fractional.parse()` ji vê fonksiyona tevde aloztir e.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Zincîreyek reqemên ASCII veguherîne bignum.
///
/// Mîna `from_str_unchecked`, vê fonksiyonê jî xwe dispêre parserê da ku ne-reqemî ji hev derxîne.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Bignumek vedigire nav jimareyek 64 bit.Heke hejmar pir mezin be Panics.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Rêzeyek bîtan derdixe.

/// Indeksa 0 bitika herî kêm girîng e û rêze asayî nîv-vekirî ye.
/// Heke ji wî were xwestin Panics bila ji cûrê vegerînê pirtirîn bîtan derxe.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}