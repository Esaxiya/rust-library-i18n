//! Cûreyên atomî
//!
//! Cûreyên atomî têkiliya bîrdariya hevpar a primitive di navbera têlan de peyda dikin, û blokên avahiyên celebên din ên hevdem in.
//!
//! Vê modulê guhertoyên atomî ya hejmarek bijartî ya celebên prîmîtîf, [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], û hwd.
//! Cûreyên atomê operasyonên ku gava rast têne bikar anîn, nûvekirinên di navbera têlan de hevdem dikin.
//!
//! Her rêbazek [`Ordering`] digire ku hêza astengiya bîranînê ya ji bo wê operasyonê temsîl dike.Van rêzan heman [C++20 atomic orderings][1] in.Ji bo bêtir agahdarî li [nomicon][2] binihêrin.
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Guherbarên atomî ewle ne ku di navbera têlan de werin parvekirin (ew [`Sync`] bicîh dikin) lê ew bi xwe mekanîzmaya parvekirinê peyda nakin û [threading model](../../../std/thread/index.html#the-threading-model) ya Rust dişopînin.
//!
//! Awayê herî hevpar ê parvekirina guherbara atomî ev e ku meriv têxe nav [`Arc`][arc] (pêşnumayek parvekirî ya bi atomî-referans-jimartî).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Cûreyên atomê dikarin di guhêrbarên statîk de werin hilanîn, bi karanîna destpêkerên domdar ên mîna [`AtomicBool::new`] ve destpêkirin.Statîkên atomê bi gelemperî ji bo destpêkirina gerdûnî ya tembel têne bikar anîn.
//!
//! # Portability
//!
//! Hemî celebên atomî yên di vê modulê de heke berdest bin [lock-free] têne garantîkirin.Ev tê vê wateyê ku ew di hundurê xwe de mutexek cîhanî wernagirin.Cûre û karûbarên atomî ne garantî ne ku bê benda bimînin.
//! Ev tê vê wateyê ku dibe ku operasyonên mîna `fetch_or` bi xelekek danberhev-û-swap werin pêkanîn.
//!
//! Operasyonên atomî dibe ku li tebeqa talîmatê bi atomên mezinahî werin bicîh kirin.Mînakî hin platform ji bo pêkanîna `AtomicI8` talîmatên atomî yên 4-byte bikar tînin.
//! Têbînî ku divê ev emilandin bandorê li rastbûna kod neke, ew tenê tiştek hay jê heye.
//!
//! Dibe ku celebên atomî yên di vê modulê de li ser hemî platforman peyda nebin.Cûreyên atomê li vir hemî bi firehî hene, lêbelê, û bi gelemperî dikarin li ser yên heyî bisekinin.Hin awarteyên berbiçav ev in:
//!
//! * PowerPC û platformên MIPS yên bi nîşangirên 32-bit ne xwediyê celebên `AtomicU64` an `AtomicI64` ne.
//! * ARM platformên mîna `armv5te` ku ne ji bo Linux ne tenê karûbarên `load` û `store` peyda dikin, û piştgirî nadin Compare û Swap operasyonên (CAS), wekî `swap`, `fetch_add`, û hwd.
//! Wekî din li ser Linux, ev karûbarên CAS bi [operating system support] têne bicîh kirin, ku dibe ku bi cezayê performansê were.
//! * ARM armancên bi `thumbv6m` tenê karûbarên `load` û `store` peyda dikin, û piştgiriyê nadin Compare û Swap (CAS) operasyonan, wekî `swap`, `fetch_add`, û hwd.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Zanibe ku dibe ku platformên future werin zêdekirin ku di heman demê de piştgiriya hin karûbarên atomî jî tune.Koda herî barkêş dê bixwaze ku li ser kîjan celebên atomî têne bikar anîn hişyar bimîne.
//! `AtomicUsize` û `AtomicIsize` bi gelemperî herî veguhêzbar in, lê wê hingê jî ew li her derê peyda nabin.
//! Ji bo referansê, pirtûkxaneya `std` hewceyê atomiya pîvana-pîvane ye, her çend `core` vê yekê naxwaze.
//!
//! Vêga hûn ê hewce ne ku di serî de `#[cfg(target_arch)]` bikar bînin da ku bi koda bi atomî ve kodê berhev bikin.`#[cfg(target_has_atomic)]` ne aram jî heye ku dibe ku di future de were aram kirin.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Spinlockek hêsan:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Li benda têlên din bimînin ku qeflê berde
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Hejmarek gerdûnî ya mijarên zindî bigirin:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Cûreyek boolean ku bi ewlehî dikare di nav têlan de were parve kirin.
///
/// Vê celeb wekî [`bool`] xwedan heman nûneriya bîranîn e.
///
/// **Nîşe**: Ev celeb tenê li ser platformên ku barkirina atomî û firotgehên `u8` piştgirî dikin heye.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// `AtomicBool` ji `false` destpêkirî diafirîne.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Send ji bo AtomicBool bi awayek nependî tê pêkanîn.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Cûreyek nîşanderê xav ku dikare bi ewlehî di nav têlan de were parve kirin.
///
/// Vê celeb wekî `*mut T` xwedan heman nûneriya bîranîn e.
///
/// **Nîşe**: Ev celeb tenê li ser platformên ku barkêşên atomî û pargîdaniyên nîşangiran piştgirî dikin heye.
/// Mezinahiya wê bi mezinahiya nîşangirê armancê ve girêdayî ye.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// `AtomicPtr<T>` pûçek diafirîne.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Rêzikên bîranîna atomî
///
/// Rêzikên bîranînê awayê ku karûbarên atomê bîranînê hevdem dikin diyar dikin.
/// Di [`Ordering::Relaxed`]-a xweya herî lawaz de, tenê bîranîn ku rasterast ji hêla operasyonê ve hatî destgirtin tê senkronîzekirin.
/// Ji aliyê din ve, cotek barkirina barkirina karûbarên [`Ordering::SeqCst`] bîranîna din hevdem dikin û di heman demê de li seranserê hemî mijaran rêzikek tevahî ya van karan diparêzin.
///
///
/// Rêzikên bîranîna Rust [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order) ne.
///
/// Ji bo bêtir agahdarî li [nomicon] binihêrin.
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Ne astengên rêzkirinê, tenê operasyonên atomî.
    ///
    /// [`memory_order_relaxed`] di C++ 20 de têkildar dibe.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Dema ku bi firotgehek re têkildar be, hemî karûbarên berê ji berî barkirina vê nirxê bi [`Acquire`] (an bihêztir) ferman têne ferman kirin.
    ///
    /// Bi taybetî, hemî nivîsarên berê ji hemî mijarên ku barkirina [`Acquire`] (an bihêztir) vê nirxê pêk tînin re xuya dibin.
    ///
    /// Bala xwe bidinê ku karanîna vê rêzkirinê ji bo emeliyatek ku barkêş û pargîdaniyan li hev tîne, dibe sedema operasyona barkirina [`Relaxed`]!
    ///
    /// Vê rêzkirin tenê ji bo operasyonên ku dikanek pêk tînin derbasdar e.
    ///
    /// [`memory_order_release`] di C++ 20 de têkildar dibe.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Dema ku bi barkêşek re têkildar be, heke nirxa barkirî ji hêla xebitînek firotanê ve bi [`Release`] (an bihêztir) hatî nivîsandin, wê hingê hemî operasyonên paşîn piştî wê firotanê têne rêz kirin.
    /// Bi taybetî, hemî barkêşên paşîn dê daneyên berî firotanê hatine nivîsandin bibînin.
    ///
    /// Bala xwe bidinê ku karanîna vê rêzkirinê ji bo emeliyatek ku barkêş û firoşgehan bi hev ve girêdide dibe sedema operasyona firoşgeha [`Relaxed`]!
    ///
    /// Vê rêzkirin tenê ji bo operasyonên ku dikarin barkêşek pêk bînin derbasdar e.
    ///
    /// [`memory_order_acquire`] di C++ 20 de têkildar dibe.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Bandorên herdu [`Acquire`] û [`Release`] bi hev re hene:
    /// Ji bo barkêşan ew rêziknameya [`Acquire`] bikar tîne.Ji bo firotgehan ew rêzana [`Release`] bikar tîne.
    ///
    /// Bala xwe bidinê ku di mijara `compare_and_swap` de, dibe ku emeliyat di encamê de ti dikanek pêk neyne û ji ber vê yekê jî tenê rêzkirina [`Acquire`] heye.
    ///
    /// Lêbelê, `AcqRel` dê carî destkeftinên [`Relaxed`] pêk neyîne.
    ///
    /// Ev rêzkirin tenê ji bo karûbarên ku hem bar û firoşgehan bi hev ve girêdide derbasdar e.
    ///
    /// [`memory_order_acq_rel`] di C++ 20 de têkildar dibe.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Mîna ["Acquire"]/["Release"]/["AcqRel"](ji bo operasyonên barkêş, pargîdanî, û barkirina bi pargîdanî, bi rêzdarî) bi pêbaweriya pêvek ku hemî mijar hemî operasyonên li pey hev di heman rêzê de dibînin .
    ///
    ///
    /// [`memory_order_seq_cst`] di C++ 20 de têkildar dibe.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// [`AtomicBool`] bi `false` ve hate destpêkirin.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// `AtomicBool` nû diafirîne.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Li [`bool`] ya bingehîn referansa mutabîk vedigerîne.
    ///
    /// Ev ewledar e ji ber ku referansa guhêrbar garantî dike ku tu têlên din bi hevdemî digihîjin daneyên atomê.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // EWLEH: : referansa guhêrbar xwedaniya yekta garantî dike.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Gihîştina atomî bigihînin `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // EWLEH: : referansa guhêrbar xwedaniya yekta garantî dike, û
        // aligning hem `bool` û `Self` 1 e.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Atomê dixwe û nirxa tê de vedigerîne.
    ///
    /// Ev ewle ye ji ber ku derbasbûna `self` bi hêjayî garantî dike ku tu têlên din bi hevdemî nagihin daneyên atomê.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Nirxek ji bool bar dike.
    ///
    /// `load` argumanek [`Ordering`] digire ku rêzkirina bîranîna vê operasyonê vedibêje.
    /// Nirxên gengaz [`SeqCst`], [`Acquire`] û [`Relaxed`] ne.
    ///
    /// # Panics
    ///
    /// Panics heke `order` [`Release`] an [`AcqRel`] be.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // EWLEH: her pêşbaziya daneyê ji hêla xwezayî û raweya atomî ve tê asteng kirin
        // nîşanderê derbaskirî derbasdar e ji ber ku me ew ji referansekê girt.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Nirxek di bool de tomar dike.
    ///
    /// `store` argumanek [`Ordering`] digire ku rêzkirina bîranîna vê operasyonê vedibêje.
    /// Nirxên gengaz [`SeqCst`], [`Release`] û [`Relaxed`] ne.
    ///
    /// # Panics
    ///
    /// Panics heke `order` [`Acquire`] an [`AcqRel`] be.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // EWLEH: her pêşbaziya daneyê ji hêla xwezayî û raweya atomî ve tê asteng kirin
        // nîşanderê derbaskirî derbasdar e ji ber ku me ew ji referansekê girt.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Nirxek di bool de tomar dike, nirxa berê vedigire.
    ///
    /// `swap` argumanek [`Ordering`] digire ku rêzkirina bîranîna vê operasyonê vedibêje.Hemî modên rêzkirinê gengaz in.
    /// Zanibe ku karanîna [`Acquire`] pargîdaniya pargîdaniyê dike beşek vê operasyonê [`Relaxed`], û karanîna [`Release`] beşa barkirinê [`Relaxed`] dike.
    ///
    ///
    /// **Note:** Ev rêbaz tenê li ser platformên ku operasyonên atomî li ser `u8` piştgirî dikin heye.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // EWLEH: : pêşbaziyên danûstendinê ji hêla xwezayên atomî ve têne asteng kirin.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Ger nirxa heyî heman nirxê `current` be nirxek di [`bool`] de tomar dike.
    ///
    /// Nirxa vegerandin her gav nirxa berê ye.Ger ew bi `current`-ê re wekhev e, wê hingê nirx hate nûve kirin.
    ///
    /// `compare_and_swap` her weha argumanek [`Ordering`] digire ku rêzkirina bîranîna vê operasyonê vedibêje.
    /// Bala xwe bidinê ku dema ku [`AcqRel`] tê bikar anîn jî, dibe ku operasyon têk biçe û ji ber vê yekê jî tenê barkirina `Acquire` pêk tîne, lê semantîka `Release` tune.
    /// Bikaranîna [`Acquire`] heke çêbibe pargîdaniya pargîdaniyê ya vê operasyonê dike [`Relaxed`], û karanîna [`Release`] beşê barkêşê dike [`Relaxed`].
    ///
    /// **Note:** Ev rêbaz tenê li ser platformên ku operasyonên atomî li ser `u8` piştgirî dikin heye.
    ///
    /// # Koçî `compare_exchange` û `compare_exchange_weak` dike
    ///
    /// `compare_and_swap` ji bo rêzikên bîranînê bi nexşeya jêrîn re `compare_exchange` wekhev e:
    ///
    /// Eslî |Serkeftin |Têkçûnî
    /// -------- | ------- | -------
    /// Relax |Relax |Relaxed Acquire |Bi dest bixin |Serbestberdanê Bi dest bixin |Berdan |AcqRel rehet |AcqRel |SeqCst bistînin |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` destûr heye ku bi derewan têk biçe dema ku berawirdbûn serfiraz be jî, ku dihêle berhevkar koda civînê çêtir çêbike dema ku berhevdan û swap di xelekekê de tê bikar anîn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Ger nirxa heyî heman nirxê `current` be nirxek di [`bool`] de tomar dike.
    ///
    /// Nirxa vegerîn encamek e ku nîşan dide ka nirxa nû hatiye nivîsandin û nirxa berê jî tê de heye.
    /// Li ser serfiraziyê ev nirx misogerkirî ye ku bi `current` re wekhev be.
    ///
    /// `compare_exchange` du argumanên [`Ordering`] digire da ku rêzkirina bîranîna vê operasyonê vebêje.
    /// `success` rêzkirina pêdivî ya ji bo xebata xwendin-guherandin-nivîsînê ya ku pêk tê heke berawirdkirina bi `current` re biserkeve diyar dike.
    /// `failure` ji bo operasyona barkirinê ya ku dema berawirdbûn têk diçe pêk tê rêzkirina pêdivî diyar dike.
    /// Bikaranîna [`Acquire`] wekî serfiraziya serfirazî pargîdaniyê dike beşek ji vê operasyonê [`Relaxed`], û karanîna [`Release`] barkirinê serkeftî dike [`Relaxed`].
    ///
    /// Biryara têkçûyînê tenê dikare [`SeqCst`], [`Acquire`] an [`Relaxed`] be û pêdivî ye ku ji emrê serfiraziyê wekhev an qelstir be.
    ///
    /// **Note:** Ev rêbaz tenê li ser platformên ku operasyonên atomî li ser `u8` piştgirî dikin heye.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // EWLEH: : pêşbaziyên danûstendinê ji hêla xwezayên atomî ve têne asteng kirin.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Ger nirxa heyî heman nirxê `current` be nirxek di [`bool`] de tomar dike.
    ///
    /// Berevajî [`AtomicBool::compare_exchange`], ev fonksiyon destûr heye ku bi derewan têk biçe dema ku berawirdbûn bi ser bikeve jî, ku dikare li hin platforman koda jêhatîtir encam bide.
    ///
    /// Nirxa vegerîn encamek e ku nîşan dide ka nirxa nû hatiye nivîsandin û nirxa berê jî tê de heye.
    ///
    /// `compare_exchange_weak` du argumanên [`Ordering`] digire da ku rêzkirina bîranîna vê operasyonê vebêje.
    /// `success` rêzkirina pêdivî ya ji bo xebata xwendin-guherandin-nivîsînê ya ku pêk tê heke berawirdkirina bi `current` re biserkeve diyar dike.
    /// `failure` ji bo operasyona barkirinê ya ku dema berawirdbûn têk diçe pêk tê rêzkirina pêdivî diyar dike.
    /// Bikaranîna [`Acquire`] wekî serfiraziya serfirazî pargîdaniyê dike beşek ji vê operasyonê [`Relaxed`], û karanîna [`Release`] barkirinê serkeftî dike [`Relaxed`].
    /// Biryara têkçûyînê tenê dikare [`SeqCst`], [`Acquire`] an [`Relaxed`] be û pêdivî ye ku ji emrê serfiraziyê wekhev an qelstir be.
    ///
    /// **Note:** Ev rêbaz tenê li ser platformên ku operasyonên atomî li ser `u8` piştgirî dikin heye.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // EWLEH: : pêşbaziyên danûstendinê ji hêla xwezayên atomî ve têne asteng kirin.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// "and" mentiqî bi nirxek boolean.
    ///
    /// Li ser nirxa heyî û argumana `val` emeliyatek "and" ya mantiqî pêk tîne, û nirxa nû li encam dide.
    ///
    /// Nirxa berê vedigerîne.
    ///
    /// `fetch_and` argumanek [`Ordering`] digire ku rêzkirina bîranîna vê operasyonê vedibêje.Hemî modên rêzkirinê gengaz in.
    /// Zanibe ku karanîna [`Acquire`] pargîdaniya pargîdaniyê dike beşek vê operasyonê [`Relaxed`], û karanîna [`Release`] beşa barkirinê [`Relaxed`] dike.
    ///
    ///
    /// **Note:** Ev rêbaz tenê li ser platformên ku operasyonên atomî li ser `u8` piştgirî dikin heye.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // EWLEH: : pêşbaziyên danûstendinê ji hêla xwezayên atomî ve têne asteng kirin.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// "nand" mentiqî bi nirxek boolean.
    ///
    /// Li ser nirxa heyî û argumana `val` emeliyatek "nand" ya mantiqî pêk tîne, û nirxa nû li encam dide.
    ///
    /// Nirxa berê vedigerîne.
    ///
    /// `fetch_nand` argumanek [`Ordering`] digire ku rêzkirina bîranîna vê operasyonê vedibêje.Hemî modên rêzkirinê gengaz in.
    /// Zanibe ku karanîna [`Acquire`] pargîdaniya pargîdaniyê dike beşek vê operasyonê [`Relaxed`], û karanîna [`Release`] beşa barkirinê [`Relaxed`] dike.
    ///
    ///
    /// **Note:** Ev rêbaz tenê li ser platformên ku operasyonên atomî li ser `u8` piştgirî dikin heye.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Em nikarin atomî_n bikar bînin li vir ji ber ku ew dikare bi bool re xwedî nirxek nederbasdar encam bide.
        // Ev diqewime ji ber ku xebata atomî bi hundurê hundurê ve, bi tevnavkarek 8-bit ve tête kirin, ku dê 7 bitên jorîn saz bike.
        //
        // Ji ber vê yekê em li şûna wê tenê fetch_xor an swap bikar tînin.
        if val {
            // ! (x&rast)== !x Divê em bool berevajî bikin.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==rast Divê em bool rast binivîsin.
            //
            self.swap(true, order)
        }
    }

    /// "or" mentiqî bi nirxek boolean.
    ///
    /// Li ser nirxa heyî û argumana `val` emeliyatek "or" ya mantiqî pêk tîne, û nirxa nû li encam dide.
    ///
    /// Nirxa berê vedigerîne.
    ///
    /// `fetch_or` argumanek [`Ordering`] digire ku rêzkirina bîranîna vê operasyonê vedibêje.Hemî modên rêzkirinê gengaz in.
    /// Zanibe ku karanîna [`Acquire`] pargîdaniya pargîdaniyê dike beşek vê operasyonê [`Relaxed`], û karanîna [`Release`] beşa barkirinê [`Relaxed`] dike.
    ///
    ///
    /// **Note:** Ev rêbaz tenê li ser platformên ku operasyonên atomî li ser `u8` piştgirî dikin heye.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // EWLEH: : pêşbaziyên danûstendinê ji hêla xwezayên atomî ve têne asteng kirin.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// "xor" mentiqî bi nirxek boolean.
    ///
    /// Li ser nirxa heyî û argumana `val` emeliyatek "xor" ya mantiqî pêk tîne, û nirxa nû li encam dide.
    ///
    /// Nirxa berê vedigerîne.
    ///
    /// `fetch_xor` argumanek [`Ordering`] digire ku rêzkirina bîranîna vê operasyonê vedibêje.Hemî modên rêzkirinê gengaz in.
    /// Zanibe ku karanîna [`Acquire`] pargîdaniya pargîdaniyê dike beşek vê operasyonê [`Relaxed`], û karanîna [`Release`] beşa barkirinê [`Relaxed`] dike.
    ///
    ///
    /// **Note:** Ev rêbaz tenê li ser platformên ku operasyonên atomî li ser `u8` piştgirî dikin heye.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // EWLEH: : pêşbaziyên danûstendinê ji hêla xwezayên atomî ve têne asteng kirin.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Nîşanek guhêrbar vedigere [`bool`] ya bingehîn.
    ///
    /// Li ser jimareya encamgirtî xwendin û nivîsandina ne-atomî dikare bibe pêşbaziyek daneyê.
    /// Ev rêbaz bi piranî ji bo FFI bikêr e, ku li ku îmzeya fonksiyonê dikare `*mut bool` li şûna `&AtomicBool` bikar bîne.
    ///
    /// Vegerîna pêşnumayek `*mut` ji referansa hevpar a li ser vê atomê ewledar e ji ber ku celebên atomî bi guhêrîna hundurîn re dixebitin.
    /// Hemî guherandinên atomê bi navgîniyek hevbeş nirxê diguherînin, û heya ku ew karûbarên atomî bikar bînin dikarin wiya bi ewlehî bikin.
    /// Her karanîna nîşanderê xav ê vegerandî blokek `unsafe` hewce dike û hîn jî pêdivî ye ku heman sînorkirin biparêze: karûbarên li ser wê divê atomî bin.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Nirxê digire, û fonksiyonek jê re bikar tîne ku nirxek nû ya vebijarkî vedigire.Ger fonksiyon `Some(_)`, din `Err(previous_value)` vegerîne `Result` ya `Ok(previous_value)` vedigerîne.
    ///
    /// Note: Heke di vê navberê de nirx ji têlên din hatibe guhertin, dibe ku ev fonksiyonê çend caran bi nav bike, heya ku fonksiyon `Some(_)` vegerîne, lê fonksiyon dê tenê carekê li nirxa tomarkirî were sepandin.
    ///
    ///
    /// `fetch_update` du argumanên [`Ordering`] digire da ku rêzkirina bîranîna vê operasyonê vebêje.
    /// Ya yekem rêzkirina hewceyê ji bo dema ku operasyon di dawiyê de biserdikeve şirove dike ya duyemîn jî ji bo barkêşan rêzkirina pêdivî diyar dike.
    /// Vana bi rêzê ve rêzikên serkeftin û têkçûnê yên [`AtomicBool::compare_exchange`] digirin.
    ///
    /// Bikaranîna [`Acquire`] wekî serfiraziya serfiraziyê pargîdaniyê dike beşek ji vê operasyonê [`Relaxed`], û karanîna [`Release`] barkirina serfiraz a dawîn [`Relaxed`] dike.
    /// Biryarnameya barkirina (failed) tenê dikare [`SeqCst`], [`Acquire`] an [`Relaxed`] be û pêdivî ye ku ji emrê serkeftinê re hevseng be an jî qelstir be.
    ///
    /// **Note:** Ev rêbaz tenê li ser platformên ku operasyonên atomî li ser `u8` piştgirî dikin heye.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// `AtomicPtr` nû diafirîne.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Çavkaniyek guhêrbar vegerîne nîşana bingehîn.
    ///
    /// Ev ewledar e ji ber ku referansa guhêrbar garantî dike ku tu têlên din bi hevdemî digihîjin daneyên atomê.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Gihîştina atomî bigihîjin pointer.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - referansa guhêrbar xwedaniya yekta garantî dike.
        //  - lihevnêzîkbûna `*mut T` û `Self` li hemî platformên ku ji hêla rust ve têne piştgirî kirin yek e, wekî ku li jor hatî rastandin.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Atomê dixwe û nirxa tê de vedigerîne.
    ///
    /// Ev ewle ye ji ber ku derbasbûna `self` bi hêjayî garantî dike ku tu têlên din bi hevdemî nagihin daneyên atomê.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Nirxek ji nîşankerê bar dike.
    ///
    /// `load` argumanek [`Ordering`] digire ku rêzkirina bîranîna vê operasyonê vedibêje.
    /// Nirxên gengaz [`SeqCst`], [`Acquire`] û [`Relaxed`] ne.
    ///
    /// # Panics
    ///
    /// Panics heke `order` [`Release`] an [`AcqRel`] be.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // EWLEH: : pêşbaziyên danûstendinê ji hêla xwezayên atomî ve têne asteng kirin.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Nirxek di nîşanderê de tomar dike.
    ///
    /// `store` argumanek [`Ordering`] digire ku rêzkirina bîranîna vê operasyonê vedibêje.
    /// Nirxên gengaz [`SeqCst`], [`Release`] û [`Relaxed`] ne.
    ///
    /// # Panics
    ///
    /// Panics heke `order` [`Acquire`] an [`AcqRel`] be.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // EWLEH: : pêşbaziyên danûstendinê ji hêla xwezayên atomî ve têne asteng kirin.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Nirxek di nîşanderê de tomar dike, nirxa berê vedigire.
    ///
    /// `swap` argumanek [`Ordering`] digire ku rêzkirina bîranîna vê operasyonê vedibêje.Hemî modên rêzkirinê gengaz in.
    /// Zanibe ku karanîna [`Acquire`] pargîdaniya pargîdaniyê dike beşek vê operasyonê [`Relaxed`], û karanîna [`Release`] beşa barkirinê [`Relaxed`] dike.
    ///
    ///
    /// **Note:** Ev rêbaz tenê li ser platformên ku operasyonên atomê li ser nîşangiran piştgirî dikin heye.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // EWLEH: : pêşbaziyên danûstendinê ji hêla xwezayên atomî ve têne asteng kirin.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Heke nirxa heyî heman nirxa `current` be, nirxek di nîşanderê de tomar dike.
    ///
    /// Nirxa vegerandin her gav nirxa berê ye.Ger ew bi `current`-ê re wekhev e, wê hingê nirx hate nûve kirin.
    ///
    /// `compare_and_swap` her weha argumanek [`Ordering`] digire ku rêzkirina bîranîna vê operasyonê vedibêje.
    /// Bala xwe bidinê ku dema ku [`AcqRel`] tê bikar anîn jî, dibe ku operasyon têk biçe û ji ber vê yekê jî tenê barkirina `Acquire` pêk tîne, lê semantîka `Release` tune.
    /// Bikaranîna [`Acquire`] heke çêbibe pargîdaniya pargîdaniyê ya vê operasyonê dike [`Relaxed`], û karanîna [`Release`] beşê barkêşê dike [`Relaxed`].
    ///
    /// **Note:** Ev rêbaz tenê li ser platformên ku operasyonên atomê li ser nîşangiran piştgirî dikin heye.
    ///
    /// # Koçî `compare_exchange` û `compare_exchange_weak` dike
    ///
    /// `compare_and_swap` ji bo rêzikên bîranînê bi nexşeya jêrîn re `compare_exchange` wekhev e:
    ///
    /// Eslî |Serkeftin |Têkçûnî
    /// -------- | ------- | -------
    /// Relax |Relax |Relaxed Acquire |Bi dest bixin |Serbestberdanê Bi dest bixin |Berdan |AcqRel rehet |AcqRel |SeqCst bistînin |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` destûr heye ku bi derewan têk biçe dema ku berawirdbûn serfiraz be jî, ku dihêle berhevkar koda civînê çêtir çêbike dema ku berhevdan û swap di xelekekê de tê bikar anîn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Heke nirxa heyî heman nirxa `current` be, nirxek di nîşanderê de tomar dike.
    ///
    /// Nirxa vegerîn encamek e ku nîşan dide ka nirxa nû hatiye nivîsandin û nirxa berê jî tê de heye.
    /// Li ser serfiraziyê ev nirx misogerkirî ye ku bi `current` re wekhev be.
    ///
    /// `compare_exchange` du argumanên [`Ordering`] digire da ku rêzkirina bîranîna vê operasyonê vebêje.
    /// `success` rêzkirina pêdivî ya ji bo xebata xwendin-guherandin-nivîsînê ya ku pêk tê heke berawirdkirina bi `current` re biserkeve diyar dike.
    /// `failure` ji bo operasyona barkirinê ya ku dema berawirdbûn têk diçe pêk tê rêzkirina pêdivî diyar dike.
    /// Bikaranîna [`Acquire`] wekî serfiraziya serfirazî pargîdaniyê dike beşek ji vê operasyonê [`Relaxed`], û karanîna [`Release`] barkirinê serkeftî dike [`Relaxed`].
    ///
    /// Biryara têkçûyînê tenê dikare [`SeqCst`], [`Acquire`] an [`Relaxed`] be û pêdivî ye ku ji emrê serfiraziyê wekhev an qelstir be.
    ///
    /// **Note:** Ev rêbaz tenê li ser platformên ku operasyonên atomê li ser nîşangiran piştgirî dikin heye.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // EWLEH: : pêşbaziyên danûstendinê ji hêla xwezayên atomî ve têne asteng kirin.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Heke nirxa heyî heman nirxa `current` be, nirxek di nîşanderê de tomar dike.
    ///
    /// Berevajî [`AtomicPtr::compare_exchange`], ev fonksiyon destûr heye ku bi derewan têk biçe dema ku berawirdbûn bi ser bikeve jî, ku dikare li hin platforman koda jêhatîtir encam bide.
    ///
    /// Nirxa vegerîn encamek e ku nîşan dide ka nirxa nû hatiye nivîsandin û nirxa berê jî tê de heye.
    ///
    /// `compare_exchange_weak` du argumanên [`Ordering`] digire da ku rêzkirina bîranîna vê operasyonê vebêje.
    /// `success` rêzkirina pêdivî ya ji bo xebata xwendin-guherandin-nivîsînê ya ku pêk tê heke berawirdkirina bi `current` re biserkeve diyar dike.
    /// `failure` ji bo operasyona barkirinê ya ku dema berawirdbûn têk diçe pêk tê rêzkirina pêdivî diyar dike.
    /// Bikaranîna [`Acquire`] wekî serfiraziya serfirazî pargîdaniyê dike beşek ji vê operasyonê [`Relaxed`], û karanîna [`Release`] barkirinê serkeftî dike [`Relaxed`].
    /// Biryara têkçûyînê tenê dikare [`SeqCst`], [`Acquire`] an [`Relaxed`] be û pêdivî ye ku ji emrê serfiraziyê wekhev an qelstir be.
    ///
    /// **Note:** Ev rêbaz tenê li ser platformên ku operasyonên atomê li ser nîşangiran piştgirî dikin heye.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // EWLEH: : Ev navxweyî ne ewle ye ji ber ku ew li ser pêşnumayek rawe dixebite
        // lê em bi teqezî dizanin ku pêşnumayek derbasdar e (me ew tenê ji `UnsafeCell` stend ku bi referansa me heye) û xebata atomî bixwe dihêle ku em bi ewlehî naverokên `UnsafeCell` biguherînin.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Nirxê digire, û fonksiyonek jê re bikar tîne ku nirxek nû ya vebijarkî vedigire.Ger fonksiyon `Some(_)`, din `Err(previous_value)` vegerîne `Result` ya `Ok(previous_value)` vedigerîne.
    ///
    /// Note: Heke di vê navberê de nirx ji têlên din hatibe guhertin, dibe ku ev fonksiyonê çend caran bi nav bike, heya ku fonksiyon `Some(_)` vegerîne, lê fonksiyon dê tenê carekê li nirxa tomarkirî were sepandin.
    ///
    ///
    /// `fetch_update` du argumanên [`Ordering`] digire da ku rêzkirina bîranîna vê operasyonê vebêje.
    /// Ya yekem rêzkirina hewceyê ji bo dema ku operasyon di dawiyê de biserdikeve şirove dike ya duyemîn jî ji bo barkêşan rêzkirina pêdivî diyar dike.
    /// Vana bi rêzê ve rêzikên serkeftin û têkçûnê yên [`AtomicPtr::compare_exchange`] digirin.
    ///
    /// Bikaranîna [`Acquire`] wekî serfiraziya serfiraziyê pargîdaniyê dike beşek ji vê operasyonê [`Relaxed`], û karanîna [`Release`] barkirina serfiraz a dawîn [`Relaxed`] dike.
    /// Biryarnameya barkirina (failed) tenê dikare [`SeqCst`], [`Acquire`] an [`Relaxed`] be û pêdivî ye ku ji emrê serkeftinê re hevseng be an jî qelstir be.
    ///
    /// **Note:** Ev rêbaz tenê li ser platformên ku operasyonên atomê li ser nîşangiran piştgirî dikin heye.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// `bool` veguherîne `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Ev makro bi dawî dibe ku li ser hin avahiyan nayê bikar anîn.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Cûreyek jimare ya ku bi ewlehî dikare di nav têlan de were parve kirin.
        ///
        /// Bi vî rengî re heman nimûneya di bîranînê de wekî ya jimareya jimare ya bingehîn heye, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Ji bo bêtir agahdarî li ser cûdahiyên di navbera celebên atomî û celebên ne-atomî de û her weha agahdariya li ser veguhastina vî rengî, ji kerema xwe [module-level documentation] bibînin.
        ///
        ///
        /// **Note:** Ev celeb tenê li ser platformên ku barkêş û firotgehên atomî piştgirî dikin [`heye
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Hejmarek atomî ya ku bi `0` hate destpêkirin.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Sendandin bi nehînî tê pêkanîn.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Hejmarek nû ya atomî diafirîne.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Çavkaniyek guhêrbar vegerîne ser jimara jêrîn.
            ///
            /// Ev ewledar e ji ber ku referansa guhêrbar garantî dike ku tu têlên din bi hevdemî digihîjin daneyên atomê.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// bila mut hin_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (hin_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - referansa guhêrbar xwedaniya yekta garantî dike.
                //  - lihevnêzîkbûna `$int_type` û `Self` yek e, wekî ku ji hêla $cfg_align ve hatî soz kirin û li jor hatî rastandin.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Atomê dixwe û nirxa tê de vedigerîne.
            ///
            /// Ev ewle ye ji ber ku derbasbûna `self` bi hêjayî garantî dike ku tu têlên din bi hevdemî nagihin daneyên atomê.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Nirxek ji jimareya atomî bar dike.
            ///
            /// `load` argumanek [`Ordering`] digire ku rêzkirina bîranîna vê operasyonê vedibêje.
            /// Nirxên gengaz [`SeqCst`], [`Acquire`] û [`Relaxed`] ne.
            ///
            /// # Panics
            ///
            /// Panics heke `order` [`Release`] an [`AcqRel`] be.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // EWLEH: : pêşbaziyên danûstendinê ji hêla xwezayên atomî ve têne asteng kirin.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Nirxek di jimareya atomê de tomar dike.
            ///
            /// `store` argumanek [`Ordering`] digire ku rêzkirina bîranîna vê operasyonê vedibêje.
            ///  Nirxên gengaz [`SeqCst`], [`Release`] û [`Relaxed`] ne.
            ///
            /// # Panics
            ///
            /// Panics heke `order` [`Acquire`] an [`AcqRel`] be.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // EWLEH: : pêşbaziyên danûstendinê ji hêla xwezayên atomî ve têne asteng kirin.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Nirxek di jimara atomê de tomar dike, nirxa berê vedigire.
            ///
            /// `swap` argumanek [`Ordering`] digire ku rêzkirina bîranîna vê operasyonê vedibêje.Hemî modên rêzkirinê gengaz in.
            /// Zanibe ku karanîna [`Acquire`] pargîdaniya pargîdaniyê dike beşek vê operasyonê [`Relaxed`], û karanîna [`Release`] beşa barkirinê [`Relaxed`] dike.
            ///
            ///
            /// **Nîşe**: Ev rêbaz tenê li ser platformên ku li ser operasyonên atomê piştgirî dikin heye
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // EWLEH: : pêşbaziyên danûstendinê ji hêla xwezayên atomî ve têne asteng kirin.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Heke nirxa heyî heman nirxê `current` be, nirxek di jimareya atomî de tomar dike.
            ///
            /// Nirxa vegerandin her gav nirxa berê ye.Ger ew bi `current`-ê re wekhev e, wê hingê nirx hate nûve kirin.
            ///
            /// `compare_and_swap` her weha argumanek [`Ordering`] digire ku rêzkirina bîranîna vê operasyonê vedibêje.
            /// Bala xwe bidinê ku dema ku [`AcqRel`] tê bikar anîn jî, dibe ku operasyon têk biçe û ji ber vê yekê jî tenê barkirina `Acquire` pêk tîne, lê semantîka `Release` tune.
            ///
            /// Bikaranîna [`Acquire`] heke çêbibe pargîdaniya pargîdaniyê ya vê operasyonê dike [`Relaxed`], û karanîna [`Release`] beşê barkêşê dike [`Relaxed`].
            ///
            /// **Nîşe**: Ev rêbaz tenê li ser platformên ku li ser operasyonên atomê piştgirî dikin heye
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Koçî `compare_exchange` û `compare_exchange_weak` dike
            ///
            /// `compare_and_swap` ji bo rêzikên bîranînê bi nexşeya jêrîn re `compare_exchange` wekhev e:
            ///
            /// Eslî |Serkeftin |Têkçûnî
            /// -------- | ------- | -------
            /// Relax |Relax |Relaxed Acquire |Bi dest bixin |Serbestberdanê Bi dest bixin |Berdan |AcqRel rehet |AcqRel |SeqCst bistînin |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` destûr heye ku bi derewan têk biçe dema ku berawirdbûn serfiraz be jî, ku dihêle berhevkar koda civînê çêtir çêbike dema ku berhevdan û swap di xelekekê de tê bikar anîn.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Heke nirxa heyî heman nirxê `current` be, nirxek di jimareya atomî de tomar dike.
            ///
            /// Nirxa vegerîn encamek e ku nîşan dide ka nirxa nû hatiye nivîsandin û nirxa berê jî tê de heye.
            /// Li ser serfiraziyê ev nirx misogerkirî ye ku bi `current` re wekhev be.
            ///
            /// `compare_exchange` du argumanên [`Ordering`] digire da ku rêzkirina bîranîna vê operasyonê vebêje.
            /// `success` rêzkirina pêdivî ya ji bo xebata xwendin-guherandin-nivîsînê ya ku pêk tê heke berawirdkirina bi `current` re biserkeve diyar dike.
            /// `failure` ji bo operasyona barkirinê ya ku dema berawirdbûn têk diçe pêk tê rêzkirina pêdivî diyar dike.
            /// Bikaranîna [`Acquire`] wekî serfiraziya serfirazî pargîdaniyê dike beşek ji vê operasyonê [`Relaxed`], û karanîna [`Release`] barkirinê serkeftî dike [`Relaxed`].
            ///
            /// Biryara têkçûyînê tenê dikare [`SeqCst`], [`Acquire`] an [`Relaxed`] be û pêdivî ye ku ji emrê serfiraziyê wekhev an qelstir be.
            ///
            /// **Nîşe**: Ev rêbaz tenê li ser platformên ku li ser operasyonên atomê piştgirî dikin heye
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // EWLEH: : pêşbaziyên danûstendinê ji hêla xwezayên atomî ve têne asteng kirin.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Heke nirxa heyî heman nirxê `current` be, nirxek di jimareya atomî de tomar dike.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// ev fonksiyon destûr tê dayîn ku bi derewan têk biçe dema ku berawirdbûn bi ser bikeve, ku dikare li hin platforman koda jêhatîtir encam bide.
            /// Nirxa vegerîn encamek e ku nîşan dide ka nirxa nû hatiye nivîsandin û nirxa berê jî tê de heye.
            ///
            /// `compare_exchange_weak` du argumanên [`Ordering`] digire da ku rêzkirina bîranîna vê operasyonê vebêje.
            /// `success` rêzkirina pêdivî ya ji bo xebata xwendin-guherandin-nivîsînê ya ku pêk tê heke berawirdkirina bi `current` re biserkeve diyar dike.
            /// `failure` ji bo operasyona barkirinê ya ku dema berawirdbûn têk diçe pêk tê rêzkirina pêdivî diyar dike.
            /// Bikaranîna [`Acquire`] wekî serfiraziya serfirazî pargîdaniyê dike beşek ji vê operasyonê [`Relaxed`], û karanîna [`Release`] barkirinê serkeftî dike [`Relaxed`].
            ///
            /// Biryara têkçûyînê tenê dikare [`SeqCst`], [`Acquire`] an [`Relaxed`] be û pêdivî ye ku ji emrê serfiraziyê wekhev an qelstir be.
            ///
            /// **Nîşe**: Ev rêbaz tenê li ser platformên ku li ser operasyonên atomê piştgirî dikin heye
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// bila mut kevn= val.load(Ordering::Relaxed);
            /// loop {bila nû=kevn * 2;
            ///     hevber val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // EWLEH: : pêşbaziyên danûstendinê ji hêla xwezayên atomî ve têne asteng kirin.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Nirxa heyî zêde dike, nirxa berê vedigerîne.
            ///
            /// Ev operasyon dorpêçê dorpêç dike.
            ///
            /// `fetch_add` argumanek [`Ordering`] digire ku rêzkirina bîranîna vê operasyonê vedibêje.Hemî modên rêzkirinê gengaz in.
            /// Zanibe ku karanîna [`Acquire`] pargîdaniya pargîdaniyê dike beşek vê operasyonê [`Relaxed`], û karanîna [`Release`] beşa barkirinê [`Relaxed`] dike.
            ///
            ///
            /// **Nîşe**: Ev rêbaz tenê li ser platformên ku li ser operasyonên atomê piştgirî dikin heye
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // EWLEH: : pêşbaziyên danûstendinê ji hêla xwezayên atomî ve têne asteng kirin.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Ji nirxa heyî kêm dibe, nirxa berê vedigire.
            ///
            /// Ev operasyon dorpêçê dorpêç dike.
            ///
            /// `fetch_sub` argumanek [`Ordering`] digire ku rêzkirina bîranîna vê operasyonê vedibêje.Hemî modên rêzkirinê gengaz in.
            /// Zanibe ku karanîna [`Acquire`] pargîdaniya pargîdaniyê dike beşek vê operasyonê [`Relaxed`], û karanîna [`Release`] beşa barkirinê [`Relaxed`] dike.
            ///
            ///
            /// **Nîşe**: Ev rêbaz tenê li ser platformên ku li ser operasyonên atomê piştgirî dikin heye
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // EWLEH: : pêşbaziyên danûstendinê ji hêla xwezayên atomî ve têne asteng kirin.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" bi nirxa heyî.
            ///
            /// Operasyonek bitwise "and" li ser nirxê heyî û argumana `val` pêk tîne, û nirxa nû dide encamê.
            ///
            /// Nirxa berê vedigerîne.
            ///
            /// `fetch_and` argumanek [`Ordering`] digire ku rêzkirina bîranîna vê operasyonê vedibêje.Hemî modên rêzkirinê gengaz in.
            /// Zanibe ku karanîna [`Acquire`] pargîdaniya pargîdaniyê dike beşek vê operasyonê [`Relaxed`], û karanîna [`Release`] beşa barkirinê [`Relaxed`] dike.
            ///
            ///
            /// **Nîşe**: Ev rêbaz tenê li ser platformên ku li ser operasyonên atomê piştgirî dikin heye
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // EWLEH: : pêşbaziyên danûstendinê ji hêla xwezayên atomî ve têne asteng kirin.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" bi nirxa heyî.
            ///
            /// Operasyonek bitwise "nand" li ser nirxê heyî û argumana `val` pêk tîne, û nirxa nû dide encamê.
            ///
            /// Nirxa berê vedigerîne.
            ///
            /// `fetch_nand` argumanek [`Ordering`] digire ku rêzkirina bîranîna vê operasyonê vedibêje.Hemî modên rêzkirinê gengaz in.
            /// Zanibe ku karanîna [`Acquire`] pargîdaniya pargîdaniyê dike beşek vê operasyonê [`Relaxed`], û karanîna [`Release`] beşa barkirinê [`Relaxed`] dike.
            ///
            ///
            /// **Nîşe**: Ev rêbaz tenê li ser platformên ku li ser operasyonên atomê piştgirî dikin heye
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // EWLEH: : pêşbaziyên danûstendinê ji hêla xwezayên atomî ve têne asteng kirin.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" bi nirxa heyî.
            ///
            /// Operasyonek bitwise "or" li ser nirxê heyî û argumana `val` pêk tîne, û nirxa nû dide encamê.
            ///
            /// Nirxa berê vedigerîne.
            ///
            /// `fetch_or` argumanek [`Ordering`] digire ku rêzkirina bîranîna vê operasyonê vedibêje.Hemî modên rêzkirinê gengaz in.
            /// Zanibe ku karanîna [`Acquire`] pargîdaniya pargîdaniyê dike beşek vê operasyonê [`Relaxed`], û karanîna [`Release`] beşa barkirinê [`Relaxed`] dike.
            ///
            ///
            /// **Nîşe**: Ev rêbaz tenê li ser platformên ku li ser operasyonên atomê piştgirî dikin heye
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // EWLEH: : pêşbaziyên danûstendinê ji hêla xwezayên atomî ve têne asteng kirin.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" bi nirxa heyî.
            ///
            /// Operasyonek bitwise "xor" li ser nirxê heyî û argumana `val` pêk tîne, û nirxa nû dide encamê.
            ///
            /// Nirxa berê vedigerîne.
            ///
            /// `fetch_xor` argumanek [`Ordering`] digire ku rêzkirina bîranîna vê operasyonê vedibêje.Hemî modên rêzkirinê gengaz in.
            /// Zanibe ku karanîna [`Acquire`] pargîdaniya pargîdaniyê dike beşek vê operasyonê [`Relaxed`], û karanîna [`Release`] beşa barkirinê [`Relaxed`] dike.
            ///
            ///
            /// **Nîşe**: Ev rêbaz tenê li ser platformên ku li ser operasyonên atomê piştgirî dikin heye
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // EWLEH: : pêşbaziyên danûstendinê ji hêla xwezayên atomî ve têne asteng kirin.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Nirxê digire, û fonksiyonek jê re bikar tîne ku nirxek nû ya vebijarkî vedigire.Ger fonksiyon `Some(_)`, din `Err(previous_value)` vegerîne `Result` ya `Ok(previous_value)` vedigerîne.
            ///
            /// Note: Heke di vê navberê de nirx ji têlên din hatibe guhertin, dibe ku ev fonksiyonê çend caran bi nav bike, heya ku fonksiyon `Some(_)` vegerîne, lê fonksiyon dê tenê carekê li nirxa tomarkirî were sepandin.
            ///
            ///
            /// `fetch_update` du argumanên [`Ordering`] digire da ku rêzkirina bîranîna vê operasyonê vebêje.
            /// Ya yekem rêzkirina hewceyê ji bo dema ku operasyon di dawiyê de biserdikeve şirove dike ya duyemîn jî ji bo barkêşan rêzkirina pêdivî diyar dike.Vana bi rêzikên serfirazî û serneketî yên hevbeş in
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Bikaranîna [`Acquire`] wekî serfiraziya serfiraziyê pargîdaniyê dike beşek ji vê operasyonê [`Relaxed`], û karanîna [`Release`] barkirina serfiraz a dawîn [`Relaxed`] dike.
            /// Biryarnameya barkirina (failed) tenê dikare [`SeqCst`], [`Acquire`] an [`Relaxed`] be û pêdivî ye ku ji emrê serkeftinê re hevseng be an jî qelstir be.
            ///
            /// **Nîşe**: Ev rêbaz tenê li ser platformên ku li ser operasyonên atomê piştgirî dikin heye
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Rêzkirin: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Rêzkirin: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Bi nirxa heyî re herî zêde.
            ///
            /// Mezinahiya nirxa heyî û argumana `val` dibîne, û nirxa nû bi encam dike.
            ///
            /// Nirxa berê vedigerîne.
            ///
            /// `fetch_max` argumanek [`Ordering`] digire ku rêzkirina bîranîna vê operasyonê vedibêje.Hemî modên rêzkirinê gengaz in.
            /// Zanibe ku karanîna [`Acquire`] pargîdaniya pargîdaniyê dike beşek vê operasyonê [`Relaxed`], û karanîna [`Release`] beşa barkirinê [`Relaxed`] dike.
            ///
            ///
            /// **Nîşe**: Ev rêbaz tenê li ser platformên ku li ser operasyonên atomê piştgirî dikin heye
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// bila bar=42;
            /// bila max_foo=foo.fetch_max (bar, Ordering::SeqCst).max(bar);
            /// bisekinin! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // EWLEH: : pêşbaziyên danûstendinê ji hêla xwezayên atomî ve têne asteng kirin.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Kêmtirîn bi nirxa heyî re.
            ///
            /// Kêmtirîn nirxa heyî û argumana `val` dibîne, û nirxa nû li encam dide.
            ///
            /// Nirxa berê vedigerîne.
            ///
            /// `fetch_min` argumanek [`Ordering`] digire ku rêzkirina bîranîna vê operasyonê vedibêje.Hemî modên rêzkirinê gengaz in.
            /// Zanibe ku karanîna [`Acquire`] pargîdaniya pargîdaniyê dike beşek vê operasyonê [`Relaxed`], û karanîna [`Release`] beşa barkirinê [`Relaxed`] dike.
            ///
            ///
            /// **Nîşe**: Ev rêbaz tenê li ser platformên ku li ser operasyonên atomê piştgirî dikin heye
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// bila bar=12;
            /// bila min_foo=foo.fetch_min (bar, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // EWLEH: : pêşbaziyên danûstendinê ji hêla xwezayên atomî ve têne asteng kirin.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Pointerek guhêrbar vegerîne ser jimara jêrîn.
            ///
            /// Li ser jimareya encamgirtî xwendin û nivîsandina ne-atomî dikare bibe pêşbaziyek daneyê.
            /// Ev rêbaz bi piranî ji bo FFI-yê, ku dibe ku îmzeya fonksiyonê bikar bîne, bikêr e
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Vegerîna pêşnumayek `*mut` ji referansa hevpar a li ser vê atomê ewledar e ji ber ku celebên atomî bi guhêrîna hundurîn re dixebitin.
            /// Hemî guherandinên atomê bi navgîniyek hevbeş nirxê diguherînin, û heya ku ew karûbarên atomî bikar bînin dikarin wiya bi ewlehî bikin.
            /// Her karanîna nîşanderê xav ê vegerandî blokek `unsafe` hewce dike û hîn jî pêdivî ye ku heman sînorkirin biparêze: karûbarên li ser wê divê atomî bin.
            ///
            ///
            /// # Examples
            ///
            /// "" (extern-declaration) paşguh bikin
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// extern "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // EWLEHIYA: Heya ku `my_atomic_op` atomî ye ewledar e.
            /// neewle {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // EWLEHIY: : bangker divê peymana ewlehiyê ya `atomic_store` biparêze.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // EWLEHIY: : bangker divê peymana ewlehiyê ya `atomic_load` biparêze.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // EWLEHIY: : bangker divê peymana ewlehiyê ya `atomic_swap` biparêze.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Nirxa berê vedigerîne (mîna __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // EWLEHIY: : bangker divê peymana ewlehiyê ya `atomic_add` biparêze.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Nirxa berê vedigerîne (mîna __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // EWLEHIY: : bangker divê peymana ewlehiyê ya `atomic_sub` biparêze.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // EWLEHIY: : bangker divê peymana ewlehiyê ya `atomic_compare_exchange` biparêze.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // EWLEHIY: : bangker divê peymana ewlehiyê ya `atomic_compare_exchange_weak` biparêze.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // EWLEHIY: : bangker divê peymana ewlehiyê ya `atomic_and` biparêze
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // EWLEHIY: : bangker divê peymana ewlehiyê ya `atomic_nand` biparêze
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // EWLEHIY: : bangker divê peymana ewlehiyê ya `atomic_or` biparêze
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // EWLEHIY: : bangker divê peymana ewlehiyê ya `atomic_xor` biparêze
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// nirxa max vedigerîne (berawirdkirina îmzekirî)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // EWLEHIY: : bangker divê peymana ewlehiyê ya `atomic_max` biparêze
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// nirxa mînîn vedigerîne (berawirdkirina îmzekirî)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // EWLEHIY: : bangker divê peymana ewlehiyê ya `atomic_min` biparêze
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// nirxa max vedigerîne (berawirdkirina bê îmze)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // EWLEHIY: : bangker divê peymana ewlehiyê ya `atomic_umax` biparêze
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// nirxa mînîn vedigerîne (berawirdkirina bê îmze)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // EWLEHIY: : bangker divê peymana ewlehiyê ya `atomic_umin` biparêze
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Razorek atomî.
///
/// Bi emrê diyarkirî ve girêdayî, têlek nahêle ku berhevkar û CPU li gorî xwe hin rêze operasyonên bîranînê ji nû ve rêz bike.
/// Ku têkiliyên di navbera wê û tevgerên atomî an têlên di têlên din de hevdemkirî-çêdike.
///
/// Razora 'A' ku xwediyê (kêmzêde) [`Release`] semantîka rêzkirinê ye, bi têl 'B' bi (bi kêmî) semantîka [`Acquire`] re hevdem dibe, heke û tenê heke operasyonên X û Y hebin, her du jî li ser hin tişta atomî 'M' dixebitin wusa ku A berê rêzkirî ye X, Y berî B tê senkronîzekirin û Y guherîna M dibîne.
/// Ev di navbera A û B de girêdanek-çêdibe peyda dike.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Operasyonên atomî bi semantîka [`Release`] an [`Acquire`] jî dikarin bi dorpêçekê re hevdem bikin.
///
/// Dirûvek ku nîzama [`SeqCst`] heye, ji bilî hebûna hem semantîka [`Acquire`] û [`Release`], beşdarî rêza bernameya cîhanî ya operasyonên [`SeqCst`] û/an têlên din dibe.
///
/// Fermanên [`Acquire`], [`Release`], [`AcqRel`] û [`SeqCst`] qebûl dike.
///
/// # Panics
///
/// Panics heke `order` [`Relaxed`] be.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // A primitive veqetandina hevbeş ku li ser bingeha spinlock.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Heya ku nirxa kevn `false` e bisekinin.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Ev dorpêç di `unlock` de bi pargîdaniyê re hevdemkirî ye.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // EWLEHIYA: karanîna dorpêça atomê ewledar e.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Razorek bîranîna berhevkar.
///
/// `compiler_fence` ti kodê makîneyê dernaxe, lê cûreyên bîranînê yên ku ji nû ve rêzkirina berhevkar destûr dide ku sînor dike.Bi taybetî, bi semantîka [`Ordering`] ve hatî girêdan, dibe ku berhevkar ji xwendin an nivîsandina ji pêş an piştî banga aliyek din a bangê ya `compiler_fence` were qedexekirin.Bala xwe bidinê ku ew **nahêle ku* hardware * ji nû ve rêzkirina wusa bike.
///
/// Ev di çerçoveyek darvekirinê ya yek-têl de ne pirsgirêk e, lê dema ku têlên din dikarin di heman demê de bîranînê biguherînin, prîmîtîfên hevdemkirinê yên bihêztir ên wekî [`fence`] hewce ne.
///
/// Rêzkirin ji hêla semantîkên dabeşkirina cuda ve têne asteng kirin ev in:
///
///  - bi [`SeqCst`] re, ji nû ve rêzkirina xwendin û nivîsandina li seranserê vê xalê destûr nayê dayîn.
///  - bi [`Release`] re, xwendin û nivîsandinên pêşîn ji paşiya paşîn nayê veguheztin.
///  - bi [`Acquire`] re, xwendin û nivîsandinên paşîn nikarin li pêş xwendinên pêşîn werin veguheztin.
///  - bi [`AcqRel`] re, her du qaîdeyên jorîn têne domandin.
///
/// `compiler_fence` bi gelemperî tenê ji bo pêşîgirtina li pêşbaziyek *bi xwe* re bikêr e.Ango, heke xelekek diyarkirî yek perçek kodê dimeşîne, û dûv re tê qutkirin, û dest bi pêkanîna kodê li cîhek din dike (dema ku hîn di heman têl de ye, û bi têgînî hîn li ser heman bingehek e).Di bernameyên kevneşopî de, ev tenê dibe ku dema ku kargirek sinyalek were tomarkirin.
/// Di koda bêtir asta nizm de, rewşên weha di heman demê de dema ku destwerdanan têdikoşin, dema ku têlên kesk bi pêş-tercîhkirinê têne bicîh kirin, û hwd jî dikarin derkevin holê.
/// Xwendevanên meraq têne teşwîq kirin ku nîqaşa kernelê Linux ya [memory barriers] bixwînin.
///
/// # Panics
///
/// Panics heke `order` [`Relaxed`] be.
///
/// # Examples
///
/// Bêyî `compiler_fence`, `assert_eq!` di kodê jêrîn de * ne garantî ye ku biserkeve, digel ku her tişt di tekek tek de diqewime.
/// Ji bo ku bibînin ka çima, ji bîr mekin ku berhevkar belaş e ku firoşgehan li `IMPORTANT_VARIABLE` û `IS_READ` digire ji ber ku ew her du jî `Ordering::Relaxed` in.Ger wiya bike, û kargêrê îşaretê piştî ku `IS_READY` nûve dibe rast tê vexwendin, wê hingê dê kargêrê sînyalê `IS_READY=1`, lê `IMPORTANT_VARIABLE=0` bibîne.
/// Vê rewşê bi dermanên `compiler_fence` bikar tînin.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // nahêlin ku nivîsên berê ji vê xalê derbas bibin
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // EWLEHIYA: karanîna dorpêça atomê ewledar e.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Theşaretê dide pêvajoyê ku ew di hundurê xelek-bendê ya mijûl-bendê de ye ("spin lock").
///
/// Vê fonksiyonê di berjewendiya [`hint::spin_loop`] de tête betal kirin.
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}