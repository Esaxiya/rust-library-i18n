Panics mijara heyî.

Ev dihêle ku bernameyek tavilê biqede û bersiva bangkerê bernameyê bide.
`panic!` dema ku bernameyek digihîje rewşek nevegerbar divê were bikar anîn.

Ev makro awayê bêkêmasî ye ku mercên di kodê mînak û testan de destnîşan dike.
`panic!` ji nêz ve bi rêbaza `unwrap` hem enumên [`Option`][ounwrap] û [`Result`][runwrap] ve girêdayî ye.
Herdu pêkanîn dema ku li ser vebijarkên [`None`] an [`Err`] têne saz kirin `panic!` dibêjin.

Gava ku hûn `panic!()` bikar tînin hûn dikarin payloadek têl diyar bikin, ku bi karanîna hevoksaziya [`format!`] hatiye çêkirin.
Ew payload dema ku panic dixe nav têlika gazî ya Rust tê bikar anîn, dibe sedema tevhevbûna panic bi tevahî.

Reftara default `std` hook, ango
koda ku rasterast piştî vexwendina panic direve, ev e ku ji bo `stderr` li gel agahdariya file/line/column ya banga `panic!()` payloadê peyamê çap bike.

Hûn dikarin panic hook bikar bînin û [`std::panic::set_hook()`] bikar bînin.
Di hundurê hook de panic wekî `&dyn Any + Send` tête peyda kirin, ku ji bo vexwendinên birêkûpêk `panic!()` an `&str` an `String` tê de heye.
Ji panic re bi nirxek celebek din, [`panic_any`] dikare were bikar anîn.

[`Result`] enum bi gelemperî ji karanîna makroya `panic!` ji bo vegera ji xeletiyan çareseriyek çêtir e.
Divê ev makro were bikar anîn ku pêşî li karanîna nirxên çewt, wek ji çavkaniyên derveyî bigire.
Agahdariya berfireh a di derbarê xebitandina xeletiyê de di [book] de tê dîtin.

Di heman demê de makroya [`compile_error!`] jî bibînin, ji bo ku di dema berhevkirinê de çewtî zêde dibin.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Pêkanîna heyî

Ger mijara sereke panics ew ê hemî mijarên we biqedîne û bernameya we bi kodê `101` biqedîne.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





