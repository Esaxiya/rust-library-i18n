#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Li gorî çapa bangker li `$crate::panic::panic_2015` an `$crate::panic::panic_2021` fireh dibe.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Diyar dike ku du vegotin bi hev re wekhev in ([`PartialEq`] bikar tînin).
///
/// Li ser panic, ev makro dê nirxên derbirînan bi nimînendeyên verastkirina wan çap bike.
///
///
/// Mîna [`assert!`], ev makro formek duyemîn jî heye, ku li wir peyamek xwerû panic dikare were peyda kirin.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Rebarên li jêr bi qestî ne.
                    // Bêyî wan, hêlîna stackê ya ji bo deyn hêj berî ku nirx bi hev bêne destpêkirin, dibe sedema hêdîbûna hêdî.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Rebarên li jêr bi qestî ne.
                    // Bêyî wan, hêlîna stackê ya ji bo deyn hêj berî ku nirx bi hev bêne destpêkirin, dibe sedema hêdîbûna hêdî.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Diyar dike ku du bêje ne wek hev in ([`PartialEq`] bikar tînin).
///
/// Li ser panic, ev makro dê nirxên derbirînan bi nimînendeyên verastkirina wan çap bike.
///
///
/// Mîna [`assert!`], ev makro formek duyemîn jî heye, ku li wir peyamek xwerû panic dikare were peyda kirin.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Rebarên li jêr bi qestî ne.
                    // Bêyî wan, hêlîna stackê ya ji bo deyn hêj berî ku nirx bi hev bêne destpêkirin, dibe sedema hêdîbûna hêdî.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Rebarên li jêr bi qestî ne.
                    // Bêyî wan, hêlîna stackê ya ji bo deyn hêj berî ku nirx bi hev bêne destpêkirin, dibe sedema hêdîbûna hêdî.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Bawer dike ku vegotinek boolean di dema xebitandinê de `true` ye.
///
/// Heke vegotina pêşkêşî di dema karînê de ji `true` re neyê nirxandin ev dê makroya [`panic!`] vegerîne.
///
/// Mîna [`assert!`], vê makroyê guhertoyek duyemîn jî heye, ku li wir peyamek xwerû panic dikare were peyda kirin.
///
/// # Uses
///
/// Berevajî [`assert!`], daxuyaniyên `debug_assert!` tenê di avahiyên ne optimîze de ji hêla default ve têne çalak kirin.
/// Heya ku `-C debug-assertions` ji berhevkar re neyê derbas kirin çêkirinek çêtirîn dê daxuyaniyên `debug_assert!` bicîh neîne.
/// Ev `debug_assert!` ji bo kontrolên ku pir biha ne ku di avahiyek belavbûnê de hene lê dibe ku di dema pêşkeftinê de bibe alîkar.
/// Encama firehkirina `debug_assert!` her gav tîp tê kontrol kirin.
///
/// Daxuyaniyek nehilbijarkî dihêle ku bernameyek di rewşek ne lihevhatî de bidomîne, ku dibe ku encamên bêhêvî hebin lê heya ku ev tenê di koda ewle de çêdibe bêewlehîtiyê nade.
///
/// Lêbelê lêçûna performansê, bi gelemperî bi pîvan nayê pîvandin.
/// Li şûna [`assert!`] bi `debug_assert!` bi vî rengî tenê piştî profîlkirina kûr, û ya girîngtir, tenê di koda ewle de teşwîq tê kirin!
///
/// # Examples
///
/// ```
/// // peyama panic ji bo van angaştan nirxa têlkirî ya vegotinê ye.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // fonksiyonek pir hêsan e
/// debug_assert!(some_expensive_computation());
///
/// // bi peyamek xwerû îdîa bikin
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Diyar dike ku du bêje bi hevûdu re wekhev in.
///
/// Li ser panic, ev makro dê nirxên derbirînan bi nimînendeyên verastkirina wan çap bike.
///
/// Berevajî [`assert_eq!`], daxuyaniyên `debug_assert_eq!` tenê di avahiyên ne optimîze de ji hêla default ve têne çalak kirin.
/// Heya ku `-C debug-assertions` ji berhevkar re neyê derbas kirin çêkirinek çêtirîn dê daxuyaniyên `debug_assert_eq!` bicîh neîne.
/// Ev `debug_assert_eq!` ji bo kontrolên ku pir biha ne ku di avahiyek belavbûnê de hene lê dibe ku di dema pêşkeftinê de bibe alîkar.
///
/// Encama firehkirina `debug_assert_eq!` her gav tîp tê kontrol kirin.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Diyar dike ku du bêje ne wek hev in.
///
/// Li ser panic, ev makro dê nirxên derbirînan bi nimînendeyên verastkirina wan çap bike.
///
/// Berevajî [`assert_ne!`], daxuyaniyên `debug_assert_ne!` tenê di avahiyên ne optimîze de ji hêla default ve têne çalak kirin.
/// Heya ku `-C debug-assertions` ji berhevkar re neyê derbas kirin çêkirinek çêtirîn dê daxuyaniyên `debug_assert_ne!` bicîh neîne.
/// Ev `debug_assert_ne!` ji bo kontrolên ku pir biha ne ku di avahiyek belavbûnê de hene lê dibe ku di dema pêşkeftinê de bibe alîkar.
///
/// Encama firehkirina `debug_assert_ne!` her gav tîp tê kontrol kirin.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Vedigerîne ka vegotina dayî li gorî yek ji qalibên hatî dayîn lihevhatî ye.
///
/// Mîna di vegotinek `match` de, nimûneyek bi vebijarkî dikare bi `if` û vegotinek cerdevanî ya ku bigihîje navên ku bi şêweyê ve hatine girêdan were şopandin.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Encamekê vedigire an xeletiya wê belav dike.
///
/// Operator `?` hate zêdekirin ku li şûna `try!` were şandin û divê li şûna wê were bikar anîn.
/// Wekî din, `try` di Rust 2018 de peyvek parastî ye, ji ber vê yekê heke hûn hewce ne ku wê bikar bînin, hûn ê hewce ne ku [raw-identifier syntax][ris] bikar bînin: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` bi [`Result`] dane re hevber dike.Di rewşa guhertoya `Ok` de, vegotin xwedî nirxê nirxê pêçayî ye.
///
/// Di rewşa guhertoya `Err` de, ew xeletiya hundurîn vedigire.`try!` paşê veguherînê bi karanîna `From` dike.
/// Ev veguherîna otomatîkî di navbera çewtiyên pispor û yên gelemperî de peyda dike.
/// Xeletiya encama wê paşê yekser vedigere.
///
/// Ji ber vegera zû, `try!` tenê di fonksiyonên ku [`Result`] vedigerin dikare were bikar anîn.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Metoda tercîhkirî ya vegera zû ya Çewtiyên
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Rêbaza berê ya zû vegerandina Çewtiyên
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Ev wekhev e:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Daneyên formatkirî di tamponekê de dinivîse.
///
/// Ev makro 'writer', têlek format û navnîşek argumanan qebûl dike.
/// Dê arguman li gorî rêzika formatê ya diyarkirî bêne formatkirin û encam dê bigihîje nivîskêr.
/// Nivîskar dikare bi rêbaza `write_fmt` her nirxek be;bi gelemperî ev ji pêkanîna [`fmt::Write`] an [`io::Write`] trait tê.
/// Makro her ku vedigere rêbaza `write_fmt` vedigere;bi gelemperî [`fmt::Result`], an [`io::Result`].
///
/// Ji bo bêtir agahdarî li ser hevoksaziya têlê format li [`std::fmt`] binihêrin.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Modulek dikare hem `std::fmt::Write` û `std::io::Write` jî îthal bike û hem li ser tiştên ku bicîh dikin bang li `write!` bike, ji ber ku tişt bi gelemperî her du jî pêk naynin.
///
/// Lêbelê, pêdivî ye ku modul traits jêhatî bîne hundur da ku navên wan nakok bin:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt bikar tîne
///     write!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt bikar tîne
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Ev makro dikare di sazkirinên `no_std` de jî were bikar anîn.
/// Di sazkirina `no_std` de hûn ji ber detayên bicihanîna pêkhateyan berpirsiyar in.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Daneyên formatkirî di nav tamponekê de, bi xêzek nû ve pêvekirî, binivîsin.
///
/// Li ser hemî platforman, xeta nû xeteya LINE FEED (`\n`/`U+000A`) tenê ye (CARRIAGE RETURN (`\r`/`U+000D`) zêde tune.
///
/// Ji bo bêtir agahdarî, li [`write!`] binihêrin.Ji bo agahdariya li ser hevoksaziya têlê format, li [`std::fmt`] binihêrin.
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Modulek dikare hem `std::fmt::Write` û `std::io::Write` jî îthal bike û hem li ser tiştên ku bicîh dikin bang li `write!` bike, ji ber ku tişt bi gelemperî her du jî pêk naynin.
/// Lêbelê, pêdivî ye ku modul traits jêhatî bîne hundur da ku navên wan nakok bin:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt bikar tîne
///     writeln!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt bikar tîne
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// .Îfreya negihîştbar nîşan dide.
///
/// Ev kêrhatî ye her carê ku berhevkar nekaribe diyar bike ku hin kod jêhatî nabe.Bo nimûne:
///
/// * Çekên bi mercên cerdevaniyê re hevber bikin.
/// * Xelekên ku bi dînamîk diqedin.
/// * Iteratorên ku bi dînamîk diqedin.
///
/// Ger tespîta ku kod ne gihîşt xelet be, bername yekser bi [`panic!`] bi dawî dibe.
///
/// Hevpeymana ne ewle ya vê makroyê fonksiyona [`unreachable_unchecked`] e, ku ger koda gihîştî dê bibe sedema reftara nediyarkirî.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Ev ê her dem [`panic!`].
///
/// # Examples
///
/// Çekên maçê:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // ger were şîrove kirin xeletiya berhevkirinê
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // yek ji pêkanînên herî xizan ên x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Ji hêla panîk ve bi peyamek "not implemented" ve koda nevekirî nîşan dide.
///
/// Vê yekê dihêle ku koda we tîp-seh bike, ku ev feyde ye heke hûn trait-ê prototîp bikin an bicîh bînin ku pêdivî bi gelek rêbazan heye ku hûn nexşeya karanîna hemîyan dikin.
///
/// Cûdaiya di navbera `unimplemented!` û [`todo!`] de ev e ku dema ku `todo!` armanca pêkanîna karbidestiyê paşê radigihîne û peyama "not yet implemented" e, `unimplemented!` tu îddîayên wiha nake.
/// Peyama wê "not implemented" ye.
/// Her weha hin IDE dê `todo!` S nîşan bikin.
///
/// # Panics
///
/// Ev ê her dem [`panic!`] be ji ber ku `unimplemented!` ji bo `panic!` tenê kurtenivîsek bi peyamek sabit, taybetî ye.
///
/// Mîna `panic!`, ev makro ji bo nîşandanê nirxên xwerû formek duyemîn heye.
///
/// # Examples
///
/// Dibêjin trait `Foo`-a me heye:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Em dixwazin `Foo`-ê ji bo 'MyStruct'-ê pêk bînin, lê ji ber hin sedeman tenê watedar e ku fonksiyona `bar()`-ê were meşandin.
/// `baz()` û `qux()` dê hîn jî hewce be ku di pêkanîna `Foo` de were diyarkirin, lê em dikarin di pênasên wan de `unimplemented!` bikar bînin da ku destûrê bidin ku koda me were berhev kirin.
///
/// Em hîn jî dixwazin ku ger rê û rêbazên nayên bicîh anîn gihîştin bernameya me rawestîne.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Ji `baz` a `MyStruct` re watedar nine, ji ber vê yekê li vir qet mantiqa me tune.
/////
///         // Ev ê "thread 'main' panicked at 'not implemented'" nîşan bide.
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Li vir hin mantiqa me heye, Em dikarin peyamek li nayên bicihanîn zêde bikin!ji bo ku kêmasiya me nîşan bide.
///         // Ev ê nîşan bide: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Kodê neqedandî nîşan dike.
///
/// Heke hûn prototîpê dikin û tenê lê digerin ku hûn tîpnivîsa xweya kodê hebin ev dikare bikêr be.
///
/// Cûdaiya di navbera [`unimplemented!`] û `todo!` de ev e ku dema ku `todo!` armanca pêkanîna karbidestiyê paşê radigihîne û peyama "not yet implemented" e, `unimplemented!` îddîayên weha nake.
/// Peyama wê "not implemented" ye.
/// Her weha hin IDE dê `todo!` S nîşan bikin.
///
/// # Panics
///
/// Ev ê her dem [`panic!`].
///
/// # Examples
///
/// Li vir mînakek hin kodên di-pêşkeftinê de hene.trait `Foo`-a me heye:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Em dixwazin `Foo`-ê li ser yek ji celebên xwe pêk bînin, lê di heman demê de em dixwazin pêşî tenê li ser `bar()`-ê bixebitin.Ji bo ku kodê me berhev bike, pêdivî ye ku em `baz()` bicîh bînin, da ku em bikaribin `todo!` bikar bînin:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // pêkanîn diçe vir
///     }
///
///     fn baz(&self) {
///         // ka em ji bo bicîhkirina baz() naha xem nekin
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // em baz()-ê jî bikar nakin, ji ber vê yekê baş e.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Pênaseyên makroyên çêkirî.
///
/// Piraniya taybetmendiyên makro (aramî, xuyangkirin û hwd.) Li vir ji koda çavkaniyê têne girtin, ji bilî fonksiyonên berfirehkirinê veguherîna ketinên makro di encaman de, ew fonksiyon ji hêla berhevkar ve têne peyda kirin.
///
///
pub(crate) mod builtin {

    /// Dema ku pêkhatin bi peyama xeletiya dayîn re dibe sedem ku berhevdan têk biçe.
    ///
    /// Divê ev makro were bikar anîn dema ku crate stratejiyek berhevkirina bi merc bikar tîne da ku ji bo mercên çewt peyamên çewtiyê çêtirîn peyda bike.
    ///
    /// Ew forma berhevkar-asta [`panic!`] e, lê di dema *berhevkirinê* de ji xêncî *dema xebitandinê* xeletiyek derdixe.
    ///
    /// # Examples
    ///
    /// Du mînakên weha macro û derdorên `#[cfg]` ne.
    ///
    /// Heke makroyek nirxên nederbasdar derbas kir çewtiyek çêkerê çêtir derxe.
    /// Bêyî branch-ya dawîn, berhevkar dê hê jî xeletiyek derxe, lê peyama xeletiyê dê qala du nirxên derbasdar neke.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Ger yek ji hejmarek taybetmendiyan tune be xeletiya berhevkar derxînin.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Parametreyên ji bo makorên din ên teşekirina-strandinê ava dike.
    ///
    /// Vê makro fonksiyonan digire dema ku ji bo her argumana pêvek derbasbûyî rêzek formatkirinê ya ku tê de `{}` tê de ye.
    /// `format_args!` Parametreyên pêvek amade dike da ku encam derxe wekî rêzek were şîrove kirin û argumanan li ser celebek yekane canonicalize dike.
    /// Her nirxek ku [`Display`] trait bicîh dike dikare ji `format_args!` re were derbas kirin, her weha her pêkanîna [`Debug`] dikare bi `{:?}` re di nav rêza formatkirinê de were derbas kirin.
    ///
    ///
    /// Ev makro nirxek ji celebê [`fmt::Arguments`] hilberîne.Ev nirx dikare ji bo pêkanîna veguherîna kêrhatî ji makroyên di nav [`std::fmt`] re were derbas kirin.
    /// Hemî makroyên formatkirinê yên din ([`format!`], [`write!`], [`println!`], û hwd.) Bi rêya vê yekê têne prox kirin.
    /// `format_args!`, berevajî makroyên xwe yên jêderkirî, ji dabeşkirinên komê dûr dikeve.
    ///
    /// Hûn dikarin nirxa [`fmt::Arguments`] bikar bînin ku `format_args!` di konteksên `Debug` û `Display` de vedigerîne ku li jêr tê dîtin.
    /// Mînak di heman demê de nîşan dide ku `Debug` û `Display` format bi heman tiştî re: Têlika formatê ya interpolated di `format_args!` de.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Ji bo bêtir agahdariyê, belgeyên li [`std::fmt`] bibînin.
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Heman wekî `format_args`, lê di dawiyê de xêzek nû zêde dike.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Di dema berhevokê de guhêrbarek jîngehê kontrol dike.
    ///
    /// Ev makro dê di dema berhevokê de bigihîje nirxa guherbara hawîrdora bi navkirî, û vegotinek ji tîpa `&'static str` bide.
    ///
    ///
    /// Ger guhêrbara jîngehê neyê terîf kirin, wê hingê dê xeletiyek berhevkirinê derkeve.
    /// Ji bo ku hûn xeletiyek berhevkirinê dernexin, li şûna wê makroya [`option_env!`] bikar bînin.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Hûn dikarin peyama çewtiyê bi derbaskirina têlek wekî parametreya duyemîn vebînin:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Heke guhêrbar a derdorê `documentation` neyê diyar kirin, hûn ê çewtiya jêrîn bistînin:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Di dema berhevkirinê de bi vebijarkî guhêrbariyek jîngehê kontrol dike.
    ///
    /// Ger guhêrbariya hawîrdorê ya bi navkirî di dema berhevokê de hebe, ev ê di vegotinek celebê `Option<&'static str>` de ku nirxê wê `Some` ya nirxê guherbara jîngehê ye, berfireh bibe.
    /// Ger guhêrbara jîngehê tune be, wê hingê ev dê heya `None` berfireh bibe.
    /// Ji bo bêtir agahdariya li ser vî rengî [`Option<T>`][Option] bibînin.
    ///
    /// Çewtiyek dema berhevkirinê dema ku vê makroyê bikar tîne qet nayê weşandin bê ka guhêrbar a hawîrdorê heye an na.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Nasnameyan bi yek nasnameyê ve girêdide.
    ///
    /// Ev makro hejmarek nasnameyên veqetandek bi veqetînê digire, û hemî bi hev re dike yek, vegotinek ku nasnameyek nû ye dide hev.
    /// Zanibe ku paqijî wusa dike ku ev makro nikare guherbarên herêmî bigire.
    /// Her weha, wekî rêgezek gelemperî, makro tenê di mijar, daxuyanî an helwesta vegotinê de têne destûr kirin.
    /// Ew tê wê wateyê ku hûn dikarin vê makroyê ji bo behskirina guhêrbar, fonksiyon an modulên heyî û hwd bikar bînin, lê hûn nekarin pê re yekê nû diyar bikin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn hevkêşan! (nû, kêf, nav) { }//bi vî rengî nayê bikar anîn!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Wergeran di nav rêzek têl a statîk de girêdide.
    ///
    /// Ev makro her hejmarek bêjeyên ji hev-veqetandî digire, derbirînek ji tîpa `&'static str` dide ku hemî bêjeyên çep-rast-ê hevgirtî temsîl dike.
    ///
    ///
    /// Rastnavêjên yekpare û xalî yên avî ji bo ku bêne girêdan têl in.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Hejmara rêzika ku lê hatî vexwendin berfireh dibe.
    ///
    /// Bi [`column!`] û [`file!`] re, van makroyan ji bo pêşdebiran di derbarê cîhê di nav çavkaniyê de agahdariya çewtkirinê peyda dikin.
    ///
    /// Daxuyaniya berfirehkirî tîpa `u32` heye û 1-bingeh e, ji ber vê yekê di her pelan de rêza yekem 1-ê, ya duyemîn-2-ê din jî dinirxîne.
    /// Ev bi peyamên çewtiyê yên ji hêla berhevkarên hevpar an edîtorên populer ve lihevhatî ye.
    /// Rêza vegeriyayî *ne hewce* xeta vexwendina `line!` bixwe ye, lê berevajî vexwendina makroya yekem a ber bi vexwendina makroya `line!` ve ye.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Ber bi jimara stûna ku lê vexwendî vedibe.
    ///
    /// Bi [`line!`] û [`file!`], van makroyan ji bo pêşdebiran di derheqê cîhê di nav çavkaniyê de agahdariya çewtkirinê peyda dikin.
    ///
    /// Bi vegotina vegirtî re tîpa `u32` heye û 1-bingeh e, ji ber vê yekê di her rêzê de stûna yekem bi 1-ê, ya duyemîn jî bi 2-ê re dinirxîne.
    /// Ev bi peyamên çewtiyê yên ji hêla berhevkarên hevpar an edîtorên populer ve lihevhatî ye.
    /// Stûna vegeriyayî *ne hewce* xeta vexwendina `column!` bixwe ye, lê berevajî vexwendina makroya yekem a ber bi vexwendina makroya `column!` ve ye.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Navê pelê ku lê tê vexwendin berfireh dibe.
    ///
    /// Bi [`line!`] û [`column!`] re, van makroyan ji bo pêşdebiran di derbarê cîhê di nav çavkaniyê de agahdariya çewtkirinê peyda dikin.
    ///
    /// Di vegotina berfereh de tîpa `&'static str` heye, û pelê vegerandî ne gazîkirina makroya `file!` bixwe ye, lê berevajî vexwendina makroya yekem a ber bi bangkirina makroya `file!` ve ye.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Argumanên xwe rêz dike.
    ///
    /// Ev makro dê derbirînek ji celebê `&'static str` bide ku ew têlika hemî tokens e ku derbasî makroyê ye.
    /// Tu sînorkirin li ser hevoksaziya vexwendina makro bixwe nayên danîn.
    ///
    /// Zanibe ku encamên berfirehkirî yên tokens ya têketinê dikare di future de biguhere.Heke hûn xwe bisipêrin derketinê divê hûn hay jê hebin.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Pelê kodkirî yê UTF-8 wekî têl vedigire.
    ///
    /// Pel li gorî pelê heyî (bi heman rengî çawa modul têne dîtin) cih digire.
    /// Riya dabînkirî di dema berhevkirinê de bi rengek taybetî-platform tête şîrove kirin.
    /// Ji ber vê yekê, wek nimûne, vexwendinek bi rêça Windows ku paşpirtikên `\` vedigire dê li ser Unix bi rêkûpêk neyê berhev kirin.
    ///
    ///
    /// Ev makro dê vegotinek ji tîpa `&'static str` bide ku naveroka pelê ye.
    ///
    /// # Examples
    ///
    /// Bawer bikin ku di heman pelrêçê de du pel hene ku bi naverokên jêrîn hene:
    ///
    /// Pel 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Pel 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// B berhevkirina 'main.rs' û xebitandina binarya encam dê "adiós" çap bike.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Pelê wekî referansa li rêzeyek byte vedigire.
    ///
    /// Pel li gorî pelê heyî (bi heman rengî çawa modul têne dîtin) cih digire.
    /// Riya dabînkirî di dema berhevkirinê de bi rengek taybetî-platform tête şîrove kirin.
    /// Ji ber vê yekê, wek nimûne, vexwendinek bi rêça Windows ku paşpirtikên `\` vedigire dê li ser Unix bi rêkûpêk neyê berhev kirin.
    ///
    ///
    /// Ev makro dê vegotinek ji tîpa `&'static [u8; N]` bide ku naveroka pelê ye.
    ///
    /// # Examples
    ///
    /// Bawer bikin ku di heman pelrêçê de du pel hene ku bi naverokên jêrîn hene:
    ///
    /// Pel 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Pel 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// B berhevkirina 'main.rs' û xebitandina binarya encam dê "adiós" çap bike.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Berfireh dibe ser têlek ku rêça modulê ya heyî temsîl dike.
    ///
    /// Riya modulê ya heyî dikare wekî hiyerarşiya modulên ku paş ve digihin crate root were fikirîn.
    /// Yekem yekem rêça vegeriyayî navê crate ye ku niha tê berhev kirin.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Di dema berhevkirinê de têkelên boolean ên alayên vesazkirinê dinirxîne.
    ///
    /// Ji bilî taybetmendiya `#[cfg]`, ev makro tête peyda kirin ku destûrê bide nirxandina vegotina boolean alayên verastkirinê.
    /// Ev bi gelemperî dibe sedema koda kêmtir dubare.
    ///
    /// Hevoksaziya ku ji vê makroyê re hatî dayîn, heman hevoksazî wekî taybetmendiya [`cfg`] e.
    ///
    /// `cfg!`, berevajî `#[cfg]`, ti kodê jê nagire û tenê rast an derew dinirxîne.
    /// Mînakî, hemî blokên di vegotinek if/else de hewce ne ku derbasdar bin dema ku `cfg!` ji bo rewşê tê bikar anîn, bêyî ku `cfg!` çi dinirxîne.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Li gorî konteksê pelê wekî vegotinek an tiştê parsek dike.
    ///
    /// Pel li gorî pelê heyî (bi heman rengî çawa modul têne dîtin) cih digire.Riya dabînkirî di dema berhevkirinê de bi rengek taybetî-platform tête şîrove kirin.
    /// Ji ber vê yekê, wek nimûne, vexwendinek bi rêça Windows ku paşpirtikên `\` vedigire dê li ser Unix bi rêkûpêk neyê berhev kirin.
    ///
    /// Bikaranîna vê makroyê timûtim ramanek xirab e, ji ber ku heke pel wekî vegotinek were pars kirin, ew ê nehîjyenîkî li koda derûdorê were bicîh kirin.
    /// Dibe ku ev bibe sedema ku guhêrbar an fonksiyonên ji pelê hêvî dikin cuda be heke hebin guherbar an fonksiyonên ku di pelê heyî de heman navî hene.
    ///
    ///
    /// # Examples
    ///
    /// Bawer bikin ku di heman pelrêçê de du pel hene ku bi naverokên jêrîn hene:
    ///
    /// Pel 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Pel 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// B berhevkirina 'main.rs' û xebitandina binarya encam dê "🙈🙊🙉🙈🙊🙉" çap bike.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Bawer dike ku vegotinek boolean di dema xebitandinê de `true` ye.
    ///
    /// Heke vegotina pêşkêşî di dema karînê de ji `true` re neyê nirxandin ev dê makroya [`panic!`] vegerîne.
    ///
    /// # Uses
    ///
    /// Daxuyanî her gav hem di çêkirina bezandin û berdanê de têne kontrol kirin, û ne dikarin bêne sekinandin.
    /// [`debug_assert!`] binihêrin ji bo îddîayên ku di avakên serbestberdanê de ji hêla default ve neçalak in.
    ///
    /// Koda ne ewle dibe ku xwe bispêre `assert!` da ku neçarbûnên dema-run bicîh bîne ku, ger werin binpê kirin dibe sedema bêewlehiyê.
    ///
    /// Dozên din ên karanîna `assert!` di kodê ewle de ceribandin û bicîhkirina neguhêzbarên demjimêran hene (ku binpêkirina wan nikare bibe sedema bêewlehiyê).
    ///
    ///
    /// # Mesajên xwerû
    ///
    /// Ev makro formek duyemîn heye, ku tê de peyamek xwerû panic dikare bi argumanan an ji bo formatkirinê bê peyda kirin.
    /// Ji bo vê formê ji bo hevoksaziyê li [`std::fmt`] binihêrin.
    /// Gotinên ku wekî argumanên formatê têne bikar anîn dê tenê heke îdîa têk biçe dê werin nirxandin.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // peyama panic ji bo van angaştan nirxa têlkirî ya vegotinê ye.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // fonksiyonek pir hêsan e
    ///
    /// assert!(some_computation());
    ///
    /// // bi peyamek xwerû îdîa bikin
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Meclîsa Inline.
    ///
    /// Ji bo karanînê [unstable book] bixwînin.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM-meclîsa inline.
    ///
    /// Ji bo karanînê [unstable book] bixwînin.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Civîna rêzkirî ya asta-modulê.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Çapan tokens di derketina standard de derbas kir.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Fonksiyonên şopandinê yên ji bo debugkirina makroyên din têne bikar anîn çalak dike an na.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Makroya taybetmendiyê ku ji bo sepandina makroyên jêder tê bikar anîn.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Makroya taybetmendiyê ya ku li fonksiyonekê tê sepandin da ku wê veguherîne testa yekîneyê.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Makroya taybetmendiyê ji bo fonksiyonekê tê sepandin da ku wê bike ceribandinek pîvanê.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Detayek pêkanînê ya makroyên `#[test]` û `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Makroya taybetmendiyê li statîkek sepandin da ku wê wekî veqetandek cîhanî tomar bike.
    ///
    /// [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html) jî bibînin.
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Tişta ku jê re tê sepandin heke rêça derbasbûyî bigihîje wê biparêze, û bi rengek din jê dike.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Hemî taybetmendiyên `#[cfg]` û `#[cfg_attr]` di perçeya kodê ya ku jê re hatî sepandin berfireh dike.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Berfirehiya pêkanîna bêstatûr ya berhevkar `rustc`, bikar neynin.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Berfirehiya pêkanîna bêstatûr ya berhevkar `rustc`, bikar neynin.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}