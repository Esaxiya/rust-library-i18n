//! Cureyê xeleta utf8 diyar dike.

use crate::fmt;

/// Xeletiyên ku dema ku hewl didin rêzek ji [`u8`] wekî têl şîrove bikin çêdibe.
///
/// Bi vî rengî, malbata fonksiyon û rêbazên `from_utf8` ji bo her du [`String`] û [`&str`] jî vê xeletiyê bikar tînin, ji bo nimûne.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Rêbazên vî celebê çewtiyê bêyî dabeşkirina bîra heap dikare ji bo afirandina fonksiyonên mîna `String::from_utf8_lossy` were bikar anîn:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Indeksa di rêza dayîn de vedigerîne ya ku UTF-8-ya derbasdar hate pejirandin.
    ///
    /// Ew navnîşa herî zêde ye ku `from_utf8(&input[..index])` dê `Ok(_)` vegerîne.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// use std::str;
    ///
    /// // hin byteyên nederbasdar, di vector de
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 vedigere Çewtiyek Utf8
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // byte duyemîn li vir ne derbasdar e
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Di derbarê têkçûnê de bêtir agahdariyê dide:
    ///
    /// * `None`: dawiya têkevinê ji nedîtî ve hat.
    ///   `self.valid_up_to()` ji dawiya ketinê 1 û 3 bayt e.
    ///   Ger herikînek byte (wekî pel an soketek torê) gav bi gav tê deşîfre kirin, ev dikare bibe `char`-a derbasdar ku rêzeya byte ya UTF-8-ê gelek beşan dorpêç dike.
    ///
    ///
    /// * `Some(len)`: byteyek çaverêkirî hate dîtin.
    ///   Dirêjahiya pêşkêşkirî ya rêzeya byte ya nederbasdar e ku ji indexa ku ji hêla `valid_up_to()` ve hatî dayîn dest pê dike.
    ///   Divê deşîfrekirin piştî wê rêzê (piştî xistina [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) di rewşa deşîfrekirina windabûyî de ji nû ve dest pê bike.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Dema ku parsekirina `bool` bi karanîna [`from_str`] têk diçe xeletiyek vegeriya
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}