//! Ji bo `str` pêkanînên Trait.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Rêzkirina têlan bicîh tîne.
///
/// Rêzikan ji hêla nirxên wan ên byte ve [lexicographically](Ord#lexicographical-comparison) têne rêz kirin.
/// Ev nokteyên koda Unicode li gorî helwestên wan ên di nexşeyên kodê de rêz dike.
/// Ev ne hewce ye ku wek rêza "alphabetical" be, ku ji hêla ziman û herêmî ve diguhere.
/// Rêzkirina rêzikên li gorî standardên çandî-pejirandî hewceyê daneya herêmî-taybetî ye ku li derveyî çarçova `str` ye.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Operasyonên berawirdkirina li ser têlan bicîh tîne.
///
/// Têlên [lexicographically](Ord#lexicographical-comparison) ji hêla nirxên wan ên byte ve têne berhevdan.
/// Ev xalên koda Unicode li gorî helwestên wan ên di nexşeyên kodê de dide ber hev.
/// Ev ne hewce ye ku wek rêza "alphabetical" be, ku ji hêla ziman û herêmî ve diguhere.
/// Bi berhevdana têlan li gorî standardên çandî-pejirandî pêdivî bi daneyên herêmî-taybetî heye ku li derveyî çarçewa `str` ye.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Slickirina binkomê bi hevoksaziya `&self[..]` an `&mut self[..]` bicîh tîne.
///
/// Parçeyek ji tevê rêzê vedigire, ango, `&self` an `&mut self` vedigerîne.Hevwateya `&bixwe [0 ..
/// len] `an`&mut [0 ..
/// len]`.
/// Berevajî operasyonên dîndankirinê yên din, ev carî nikare panic.
///
/// Ev operasyon *O*(1) e.
///
/// Berî 1.20.0, van operasyonên navnîşkirinê hîn jî bi pêkanîna rasterast ya `Index` û `IndexMut` piştgirî bûn.
///
/// Bi `&self[0 .. len]` an `&mut self[0 .. len]` re wekhev e.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Slickirina binkomê bi hevoksaziya `&self[begin .. end]` an `&mut self[begin .. end]` bicîh tîne.
///
/// Parçeyek rêzeya dayîn ji rêzika byte vedigerîne [`destpê bike`, `end`).
///
/// Ev operasyon *O*(1) e.
///
/// Berî 1.20.0, van operasyonên navnîşkirinê hîn jî bi pêkanîna rasterast ya `Index` û `IndexMut` piştgirî bûn.
///
/// # Panics
///
/// Panics heke `begin` an `end` nîşana nîşankirina byte-destpêkirina kesayetek nede (wekî ku ji hêla `is_char_boundary` ve hatî diyarkirin), heke `begin > end`, an jî `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // ev ê panic:
/// // byte 2 di nav `ö` de ye:
/// // &s [2 ..3];
///
/// // byte 8 di nav `老`&s de ye [1 ..
/// // 8];
///
/// // byte 100 li derveyî rêzê&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // EWLEH: tenê kontrol kir ku `start` û `end` li ser tixûbek kar in,
            // û em di referansek ewledar re derbas dibin, ji ber vê yekê nirxa vegerê jî dê yek be.
            // Me tixûbên char jî kontrol kir, ji ber vê yekê ev UTF-8 derbasdar e.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // EWLEH: tenê kontrol kir ku `start` û `end` li ser tixûbek kar in.
            // Em dizanin pointer bêhempa ye ji ber ku me ew ji `slice` girt.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SAFETY: bangker garantî dike ku `self` di sînorên `slice` de ye
        // ku hemî mercan ji bo `add` têr dike.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // EWLEH: : ji bo `get_unchecked` şîroveyan bibînin.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary kontrol dike ku index di [0 de ye, .len()] ji ber pirsgirêka NLL nikare `get`-ê wekî jorîn ji nû ve bikar bîne
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // EWLEH: tenê kontrol kir ku `start` û `end` li ser tixûbek kar in,
            // û em di referansek ewledar re derbas dibin, ji ber vê yekê nirxa vegerê jî dê yek be.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Slickirina binkomê bi hevoksaziya `&self[.. end]` an `&mut self[.. end]` bicîh tîne.
///
/// Parçeyek rêzeya dayîn ji rêzika byte vedigerîne [`0`, `end`).
/// Bi `&self[0 .. end]` an `&mut self[0 .. end]` re wekhev e.
///
/// Ev operasyon *O*(1) e.
///
/// Berî 1.20.0, van operasyonên navnîşkirinê hîn jî bi pêkanîna rasterast ya `Index` û `IndexMut` piştgirî bûn.
///
/// # Panics
///
/// Panics heke `end` nîşana nîşankirina byte-destpêk a karakterê nede (wekî ku ji hêla `is_char_boundary` ve hatî diyarkirin), an jî heke `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // EWLEH: tenê kontrol kir ku `end` li ser sînorek char e,
            // û em di referansek ewledar re derbas dibin, ji ber vê yekê nirxa vegerê jî dê yek be.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // EWLEH: tenê kontrol kir ku `end` li ser sînorek char e,
            // û em di referansek ewledar re derbas dibin, ji ber vê yekê nirxa vegerê jî dê yek be.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // EWLEH: tenê kontrol kir ku `end` li ser sînorek char e,
            // û em di referansek ewledar re derbas dibin, ji ber vê yekê nirxa vegerê jî dê yek be.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Slickirina binkomê bi hevoksaziya `&self[begin ..]` an `&mut self[begin ..]` bicîh tîne.
///
/// Parçeyek rêzeya dayîn ji rêzika byte vedigerîne [`destpê bike`, `len`).Hevwateya `&bixwe [destpê bike ..
/// len] `an`&mut xwe [destpê bike ..
/// len]`.
///
/// Ev operasyon *O*(1) e.
///
/// Berî 1.20.0, van operasyonên navnîşkirinê hîn jî bi pêkanîna rasterast ya `Index` û `IndexMut` piştgirî bûn.
///
/// # Panics
///
/// Panics heke `begin` nîşana nîşankirina byte-destpêk a karakterê nede (wekî ku ji hêla `is_char_boundary` ve hatî diyarkirin), an jî heke `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // EWLEH: tenê kontrol kir ku `start` li ser sînorek char e,
            // û em di referansek ewledar re derbas dibin, ji ber vê yekê nirxa vegerê jî dê yek be.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // EWLEH: tenê kontrol kir ku `start` li ser sînorek char e,
            // û em di referansek ewledar re derbas dibin, ji ber vê yekê nirxa vegerê jî dê yek be.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SAFETY: bangker garantî dike ku `self` di sînorên `slice` de ye
        // ku hemî mercan ji bo `add` têr dike.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // EWLEH: : bi `get_unchecked` re yeksan e.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // EWLEH: tenê kontrol kir ku `start` li ser sînorek char e,
            // û em di referansek ewledar re derbas dibin, ji ber vê yekê nirxa vegerê jî dê yek be.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Slickirina binkomê bi hevoksaziya `&self[begin ..= end]` an `&mut self[begin ..= end]` bicîh tîne.
///
/// Parçeyek rêzeya dayîn ji rêzeya byte [`begin`, `end`] vedigerîne.Hevwate `&self [begin .. end + 1]` an `&mut self[begin .. end + 1]`, ji bilî ku `end` ji bo `usize` xwedî nirxa herî zêde ye.
///
/// Ev operasyon *O*(1) e.
///
/// # Panics
///
/// Panics heke `begin` nîşana nîşankirina byte-destpêk a karakterekê nede (wekî ku ji hêla `is_char_boundary` ve hatî diyarkirin), heke `end` nîşana byte-a-paşiya kesayetiyek nede (`end + 1` an byteyek destpêkî ye an wekhevî `len` ye), heke `begin > end`, an heke `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // EWLEHIY: : bangker divê peymana ewlehiyê ya `get_unchecked` biparêze.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // EWLEHIY: : bangker divê peymana ewlehiyê ya `get_unchecked_mut` biparêze.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Slickirina binkomê bi hevoksaziya `&self[..= end]` an `&mut self[..= end]` bicîh tîne.
///
/// Parçeyek rêzeya dayîn ji rêzeya byte [0, `end`] vedigerîne.
/// Hevwate `&self [0 .. end + 1]` ye, ji bilî ku `end` ji bo `usize` xwedî nirxa herî zêde ye.
///
/// Ev operasyon *O*(1) e.
///
/// # Panics
///
/// Panics heke `end` nîşana xilaskirina byteya bidawî ya kesayetek nede (`end + 1` an bayt destpêkek e ku ji hêla `is_char_boundary` ve hatî diyarkirin, an jî wekhevî `len` e), an jî heke `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // EWLEHIY: : bangker divê peymana ewlehiyê ya `get_unchecked` biparêze.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // EWLEHIY: : bangker divê peymana ewlehiyê ya `get_unchecked_mut` biparêze.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Nirxek ji rêzê veqetînin
///
/// Rêbaza [`from_str`] ya `FromStr` bi gelemperî, bi rêbaza [`parse`] ya [str]] bi eşkereyî tête bikar anîn.
/// Ji bo mînakan li belgeya ["parse"] binêrin.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` parametreyek jiyana we tune, û ji ber vê yekê hûn tenê dikarin celebên ku bi xwe parametreyek jiyanê ne tê de parçe bikin.
///
/// Bi gotinên din, hûn dikarin `i32` bi `FromStr` parsek bikin, lê ne `&i32`.
/// Hûn dikarin struktura ku `i32` tê de ye, lê ne ku ya ku `&i32` tê de ye, parsek bikin.
///
/// # Examples
///
/// Pêkanîna bingehîn a `FromStr` li ser mînakek celebê `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Çewtiya têkildar a ku dikare ji parsekirinê were vegerandin.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Zencîreyek `s` parçe dike ku nirxek ji vî rengî vegerîne.
    ///
    /// Heke parsek biserkeve, nirxa hundurê [`Ok`] vegerînin, nexwe dema ku têl ne-formatkirî ye xeletiyek taybetî ya [`Err`]-ya hundurîn vegerînin.
    /// Cureyê çewtiyê ji bo pêkanîna trait taybetî ye.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn bi [`i32`], celebek ku `FromStr` bicîh dike:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Ji rêzê `bool`-ê parçe bikin.
    ///
    /// `Result<bool, ParseBoolError>` dide, ji ber ku `s` dibe an jî nabe ku bi rastî were parsel kirin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Têbînî, di pir rewşan de, rêbaza `.parse()` li ser `str` guncantir e.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}