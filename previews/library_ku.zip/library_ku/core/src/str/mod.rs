//! Manîpulasyona têlê.
//!
//! Ji bo bêtir agahdariyê, modulê [`std::str`] bibînin.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. ji derveyî sînoran
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. destpêkirin <=bidawîbûn
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. sînorê karakterî
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // karakter bibînin
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` divê ji len û tixûbek char kêmtir be
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Dirêjahiya `self` vedigerîne.
    ///
    /// Ev dirêjahî di byte de ye, ne [`char`] an grafemên.
    /// Bi gotinên din, dibe ku ya ku mirov dirêjahiya têlê dihesibîne nebe.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // fancy f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// `true` vedigerîne ger `self` dirêjahiya wê sifir bayt be.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Kontrol dike ku `index`-th byte di rêza xala kodê UTF-8 an dawiya têlê de byta yekem e.
    ///
    ///
    /// Destpêk û dawiya rêzê (dema ku `index== self.len()`) wekî tixûb têne hesibandin.
    ///
    /// Ger `index` ji `self.len()` mezintir be `false` vedigire.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // destpêkirina `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // duyemîn byte ya `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // sêyemîn byte ya `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 û len her gav baş in.
        // Ji bo 0 eşkere biceribînin da ku ew bikaribe bi hêsanî check-ê xweş bike û ji bo wê rewşê ji daneyên stringê bixwîne.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Ev bit efsûnî ya hevseng e: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Qertalek têl veguherîne pişkek byte.
    /// Ji bo ku perçê byteyê dîsa veguherîne perçek têl, fonksiyona [`from_utf8`] bikar bînin.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // EWLEH: dengê const ji ber ku em du tebeqeyên bi heman danasînê veguherînin
        unsafe { mem::transmute(self) }
    }

    /// Qertalek têl a guherbar veguherîne qurmek bîte ya guhêrbar.
    ///
    /// # Safety
    ///
    /// Divê bangker piştrast bike ku naveroka perçeyê UTF-8 derbasdar e berî ku deyn bidawî bibe û `str` ya bingehîn neyê bikar anîn.
    ///
    ///
    /// Bikaranîna `str` ya ku naveroka wê ne derbasdar e UTF-8 tevgerek ne diyar e.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // EWLEHIYA: cast ji `&str` bo `&[u8]` ji `str` ewle ye
        // wek `&[u8]` heman pêşnûma heye (tenê libstd dikare vê garantiyê bike).
        // Paşvekêşana pointer ewle ye ji ber ku ew ji referansek guhêrbar tê ku ji bo nivîsandinê derbasdar e.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Qertalek têl veguherîne pêşekvana xav.
    ///
    /// Ji ber ku perçeyên têl perçeyek byte ne, pêşanderê xav [`u8`] nîşan dide.
    /// Dê ev pêşek nîşanî beyta yekem a fena têlê bide.
    ///
    /// Divê bangker piştrast bike ku nîşana vegeriyayî qet nehatiye nivîsandin.
    /// Heke hûn hewce ne ku naverokên perçê têl veguherînin, [`as_mut_ptr`] bikar bînin.
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Qertafa têlê ya guhêrbar veguherîne pêşekvana rawe.
    ///
    /// Ji ber ku perçeyên têl perçeyek byte ne, pêşanderê xav [`u8`] nîşan dide.
    /// Dê ev pêşek nîşanî beyta yekem a fena têlê bide.
    ///
    /// Ew berpirsiyariya we ye ku hûn pê ewle bine ku têlika têlê tenê bi rengek ku UTF-8 derbasdar bimîne were guhertin.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Zindanek `str` vedigerîne.
    ///
    /// Ev alternatîfek ne-panîkî ya nîşankirina `str` ye.
    /// [`None`] vedigere kengê ku operasyona navnîşkirina wekhev dê panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // nexşeyên li ser sînorên rêza UTF-8 ne
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // ji derveyî sînoran
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Zencîreyek guhêrbar a `str` vedigerîne.
    ///
    /// Ev alternatîfek ne-panîkî ya nîşankirina `str` ye.
    /// [`None`] vedigere kengê ku operasyona navnîşkirina wekhev dê panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // dirêjahiya rast
    /// assert!(v.get_mut(0..5).is_some());
    /// // ji derveyî sînoran
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Xelekek neçêkirî ya `str` vedigerîne.
    ///
    /// Ev alternatîfek neçêkirî ye ku ji bo danasîna `str`.
    ///
    /// # Safety
    ///
    /// Bangdêrên vê fonksiyonê berpirsiyar in ku ev mercên pêşwext têr dibin:
    ///
    /// * Indeksa destpêkê divê ji endeksê bidawîbûnê derbas nebe;
    /// * Pêdivî ye ku navnîş di nav sînorên pirtûka xwerû de bin;
    /// * Divê navnîşan li ser sînorên rêza UTF-8 derewan bikin.
    ///
    /// Heke wiya nebe, pelika têl a vegeriyayî dikare bîranîna nederbasdar binav bike an binpêkirinên ku ji hêla celebê `str` ve hatine ragihandin binpê bike.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // EWLEHIY: : bangker divê peymana ewlehiyê ya `get_unchecked` biparêze;
        // perçe dereferencable ye ji ber ku `self` referansek ewledar e.
        // Nîşaneya vegeriyayî ewle ye ji ber ku impls of `SliceIndex` mecbûr in garantî bikin ku ew e.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Xerzek mutable, neçêkirî ya `str` vedigerîne.
    ///
    /// Ev alternatîfek neçêkirî ye ku ji bo danasîna `str`.
    ///
    /// # Safety
    ///
    /// Bangdêrên vê fonksiyonê berpirsiyar in ku ev mercên pêşwext têr dibin:
    ///
    /// * Indeksa destpêkê divê ji endeksê bidawîbûnê derbas nebe;
    /// * Pêdivî ye ku navnîş di nav sînorên pirtûka xwerû de bin;
    /// * Divê navnîşan li ser sînorên rêza UTF-8 derewan bikin.
    ///
    /// Heke wiya nebe, pelika têl a vegeriyayî dikare bîranîna nederbasdar binav bike an binpêkirinên ku ji hêla celebê `str` ve hatine ragihandin binpê bike.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // EWLEHIY: : bangker divê peymana ewlehiyê ya `get_unchecked_mut` biparêze;
        // perçe dereferencable ye ji ber ku `self` referansek ewledar e.
        // Nîşaneya vegeriyayî ewle ye ji ber ku impls of `SliceIndex` mecbûr in garantî bikin ku ew e.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Ji perçeyek têl a din qertek têl diafirîne, kontrola ewlehiyê dorpêç dike.
    ///
    /// Ev gelemperî nayê pêşniyar kirin, bi hişyarî bikar bînin!Ji bo alternatîfek ewle [`str`] û [`Index`] bibînin.
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Ev pişka nû ji `begin` diçe `end`, tevî `begin` lê `end` tune.
    ///
    /// Ji bo ku li şûna wê perçek têl a mutabîl bigire, li rêbaza [`slice_mut_unchecked`] binihêrin.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Bangkerên vê fonksiyonê berpirsiyar in ku sê mercên pêşwext têr dibin:
    ///
    /// * `begin` divê ji `end` derbas nebe.
    /// * `begin` û `end` divê di hundurê perçê string de helwestên bayteyê bin.
    /// * `begin` û `end` divê li ser sînorên rêza UTF-8 razên.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // EWLEHIY: : bangker divê peymana ewlehiyê ya `get_unchecked` biparêze;
        // perçe dereferencable ye ji ber ku `self` referansek ewledar e.
        // Nîşaneya vegeriyayî ewle ye ji ber ku impls of `SliceIndex` mecbûr in garantî bikin ku ew e.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Ji perçeyek têl a din qertek têl diafirîne, kontrola ewlehiyê dorpêç dike.
    /// Ev gelemperî nayê pêşniyar kirin, bi hişyarî bikar bînin!Ji bo alternatîfek ewle [`str`] û [`IndexMut`] bibînin.
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Ev pişka nû ji `begin` diçe `end`, tevî `begin` lê `end` tune.
    ///
    /// Ji bo ku li şûna wê felqek têl a neguhêrbar, rêbaza [`slice_unchecked`] bibînin.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Bangkerên vê fonksiyonê berpirsiyar in ku sê mercên pêşwext têr dibin:
    ///
    /// * `begin` divê ji `end` derbas nebe.
    /// * `begin` û `end` divê di hundurê perçê string de helwestên bayteyê bin.
    /// * `begin` û `end` divê li ser sînorên rêza UTF-8 razên.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // EWLEHIY: : bangker divê peymana ewlehiyê ya `get_unchecked_mut` biparêze;
        // perçe dereferencable ye ji ber ku `self` referansek ewledar e.
        // Nîşaneya vegeriyayî ewle ye ji ber ku impls of `SliceIndex` mecbûr in garantî bikin ku ew e.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Qertalek zincîreyek li ser indexek dabeş bikin du.
    ///
    /// Nîqaş, `mid`, divê ji destpêka têlê ve bibe bytek.
    /// Divê ew jî li ser sînorê xaleke kodê UTF-8 be.
    ///
    /// Du pelikên ku vegeriyane ji despêka têlika têlê heya `mid`, û ji `mid` heya dawiya pelika têl diçin.
    ///
    /// Ji bo ku li şûna wê têlên têlên guhêrbar, rêbaza [`split_at_mut`] bibînin.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics heke `mid` ne li ser sînorê xala kodê UTF-8 be, an jî heke ew ji dawiya xala kodê ya paşîn ya têlê derbas bibe.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary kontrol dike ku index di [0, .len()]
        if self.is_char_boundary(mid) {
            // EWLEH: tenê kontrol kir ku `mid` li ser sînorek char e.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Qertalek têlekê ya guhêrbar li pêşekekê dabeş bike du.
    ///
    /// Nîqaş, `mid`, divê ji destpêka têlê ve bibe bytek.
    /// Divê ew jî li ser sînorê xaleke kodê UTF-8 be.
    ///
    /// Du pelikên ku vegeriyane ji despêka têlika têlê heya `mid`, û ji `mid` heya dawiya pelika têl diçin.
    ///
    /// Ji bo ku li şûna wê têlên têlên neguhêrbar, rêbaza [`split_at`] bibînin.
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics heke `mid` ne li ser sînorê xala kodê UTF-8 be, an jî heke ew ji dawiya xala kodê ya paşîn ya têlê derbas bibe.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary kontrol dike ku index di [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // EWLEH: tenê kontrol kir ku `mid` li ser sînorek char e.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Iterator li ser [`char`]-yên qurmê têlê vedigerîne.
    ///
    /// Çawa ku qertek têl ji UTF-8-ya derbasdar pêk tê, em dikarin ji hêla [`char`]-ê ve bi navgînek têlê vegerin.
    /// Ev rêbaz vegerek wusa vedigire.
    ///
    /// Vê girîng e ku hûn bîr bînin ku [`char`] Nirxek Scalar-a Unicode temsîl dike, û dibe ku bi ramana we ya 'character' çi be hev nagire.
    ///
    /// Dûbarebûna li ser komikên grafemê dibe ku ya ku hûn bi rastî dixwazin.
    /// Ev karbidestiyê ji hêla pirtûkxaneya standard a Rust ve nayê peyda kirin, li şûna wê crates.io kontrol bikin.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Bînin bîra xwe, dibe ku [`char`] s li ser intuition-a weya tîpan li hev nekin:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // ne 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Iterator li ser [`char`]-yên qurmê têlê, û pêgehên wan vedigerîne.
    ///
    /// Çawa ku qertek têl ji UTF-8-ya derbasdar pêk tê, em dikarin ji hêla [`char`]-ê ve bi navgînek têlê vegerin.
    /// Ev rêbaz hem iteratorê van [`char`]-an, hem jî helwestên wan ên byte vedigerîne.
    ///
    /// Iterator tupê dide.Rewş yekem e, [`char`] duyemîn e.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Bînin bîra xwe, dibe ku [`char`] s li ser intuition-a weya tîpan li hev nekin:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // ne (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // 3-ê li vir binihêrin, karakterê paşîn du bayt girt
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Iterator li ser byteyên perçeyek têlê.
    ///
    /// Çawa ku perçek têl ji rêzeyek byteyan pêk tê, em dikarin bi riya perçeyek têl byte dubare bikin.
    /// Ev rêbaz vegerek wusa vedigire.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Parçeyek têlê ji hêla qada spî ve dabeş dike.
    ///
    /// Iteratorê ku vegeriyaye dê qertên têlê vegerîne ku bin-perçeyên qurmê têlê ya orîjînal in, û ji hêla her cîhekî spî veqetandî ne.
    ///
    ///
    /// 'Whitespace' li gorî şertên Unicode Derived Core Property `White_Space` tête diyar kirin.
    /// Heke hûn tenê dixwazin li şûna wê li qada spî ya ASCII dabeş bibin, [`split_ascii_whitespace`] bikar bînin.
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Her celeb qada spî têne hesibandin:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Ji hêla qada spî ya ASCII ve rêzek têl parve dike.
    ///
    /// Iteratorê ku vegeriyaye dê qertên têlê vegerîne ku bin-perçeyên qurmê têlê ya orîjînal in, û ji hêla her cîhê spî yê ASCII ve hatine veqetandin.
    ///
    ///
    /// Li şûna wê ji hêla Unicode `Whitespace` ve parçe bibe, [`split_whitespace`] bikar bînin.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Her celeb qada spî ya ASCII têne hesibandin:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Iterator li ser xetên têl, wekî pelikên têl.
    ///
    /// Rêze an bi x01X-ya nû an vegerek barkêş a bi xeta (`\r\n`)-ê vedigerin bi dawî dibin.
    ///
    /// Dawiya rêza dawîn vebijarkî ye.
    /// Têlika ku bi bidawîbûna rêza dawîn ve diqede dê heman rêzikên wekî têlên din ên yeksan bêyî veqetandina rêza dawî vegerîne.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Dawiya rêza dawîn ne hewce ye:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Iterator li ser rêzên têlek.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Itteratorek `u16` li ser têla ku wekî UTF-16 hatî kodkirî vedigerîne.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Ger nimûneya dayîn li jêr-perçeyek vê qurmê têlê li hev bike `true` vedigerîne.
    ///
    /// Ger neke vedigere `false`.
    ///
    /// [pattern] dikare bibe `&str`, [`char`], perçek [`char`] ê, an fonksiyonek an girtinek ku diyar dike ka karakterek li hev dike an na.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Ger nimûneya dayîn bi pêşpirtika vê qurmê têlê re li hev were `true` vedigerîne.
    ///
    /// Ger neke vedigere `false`.
    ///
    /// [pattern] dikare bibe `&str`, [`char`], perçek [`char`] ê, an fonksiyonek an girtinek ku diyar dike ka karakterek li hev dike an na.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Ger nimûneya dayînî bi paşpirtika vê qurmê rêzê re li hev were `true` vedigerîne.
    ///
    /// Ger neke vedigere `false`.
    ///
    /// [pattern] dikare bibe `&str`, [`char`], perçek [`char`] ê, an fonksiyonek an girtinek ku diyar dike ka karakterek li hev dike an na.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Indeksa byte ya karakterê yekem ê vê perçeya stringê ku li gorî nimûneyê li hev tîne vedigerîne.
    ///
    /// Ger nimûneya hev nagire [`None`] vedigerîne.
    ///
    /// [pattern] dikare bibe `&str`, [`char`], perçek [`char`] ê, an fonksiyonek an girtinek ku diyar dike ka karakterek li hev dike an na.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Nimûneyên hêsan:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Nimûneyên tevlihev ên ku şêwaz û girtinên bê-xal bikar tînin:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Findingêweyê nabînin:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Di vê pişka string de ji bo karakterê yekem ê rastnasî ya nimûneyê indexa byte vedigerîne.
    ///
    /// Ger nimûneya hev nagire [`None`] vedigerîne.
    ///
    /// [pattern] dikare bibe `&str`, [`char`], perçek [`char`] ê, an fonksiyonek an girtinek ku diyar dike ka karakterek li hev dike an na.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Nimûneyên hêsan:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Nimûneyên tevlihev ên bi girtinan:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Findingêweyê nabînin:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Iterator li jêrî jêrzemînên vê çerxa têlê, ji hêla karakterên ku bi qalibekî lihevhatî vedibe veqetandî.
    ///
    /// [pattern] dikare bibe `&str`, [`char`], perçek [`char`] ê, an fonksiyonek an girtinek ku diyar dike ka karakterek li hev dike an na.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tevgera Iterator
    ///
    /// Heke nimûneyek lêgerînek berevajî bihêle û lêgerîna forward/reverse heman hêmanan bide hev iteratorê vegerî dê [`DoubleEndedIterator`] be.
    /// Ev ji bo nimûne, [`char`] rast e, lê ne ji bo `&str`.
    ///
    /// Heke nimûneyek lêgerînek berevajî dihêle lê dibe ku encamên wê ji lêgerînek pêş cuda bibin, rêbaza [`rsplit`] dikare were bikar anîn.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Nimûneyên hêsan:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Heke nimûneyek qalibek cûrbecûr e, li ser her rûdana kesayetan dabeş bibe:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Nimûneyek tevlihevtir, karanînek bikar tîne:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Heke têlek gelek veqetandekên li rex hev vehewîne, hûn ê di encam de bi têlên vala biqedin:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Dabeşkerên lihevhatî ji hêla têla vala ve têne veqetandin.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Dabeşkerên di destpêk an dawiya têlek de bi têlên vala ve cîran dibin.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Gava ku têla vala wekî veqetandek tê bikar anîn, ew her tîpên têlê, digel destpêk û dawiya têlê ji hev vediqetîne.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Dema ku cîhê spî wekî veqetîner tê bikar anîn dibe ku veqetandekên lihevhatî bibin sedema tevgerek belkî sosret.Ev kod rast e:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Ew _not_ dide we:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Ji bo vê tevgerê [`split_whitespace`] bikar bînin.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Iterator li jêrî jêrzemînên vê çerxa têlê, ji hêla karakterên ku bi qalibekî lihevhatî vedibe veqetandî.
    /// Cûda ji iteratorê ku ji hêla `split` ve hatî hilberandin di `split_inclusive` de beşa lihevhatî wekî bidawîbûna binkomê dihêle.
    ///
    ///
    /// [pattern] dikare bibe `&str`, [`char`], perçek [`char`] ê, an fonksiyonek an girtinek ku diyar dike ka karakterek li hev dike an na.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Ger hêmana paşîn a string li hev were, wê ew hêman dê bidawîbûna binyata pêşîn were hesibandin.
    /// Ew binûpel dê bibe xala herî paşîn ku ji hêla vebêjer ve hatî vegerandin.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Ittorek li ser jêrzemînên perçeya têlê ya hatî dayîn, bi tîpên ku bi rengek hevahengî ji hev hatine veqetandin û bi rêza berevajî derket.
    ///
    /// [pattern] dikare bibe `&str`, [`char`], perçek [`char`] ê, an fonksiyonek an girtinek ku diyar dike ka karakterek li hev dike an na.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tevgera Iterator
    ///
    /// Iteratorê vegerandî hewce dike ku nimûneyek lêgerînek berevajî piştgirî dike, û ew ê [`DoubleEndedIterator`] be heke lêgerînek forward/reverse heman hêman bide.
    ///
    ///
    /// Ji bo iterating ji pêş, rêbaza [`split`] dikare were bikar anîn.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Nimûneyên hêsan:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Nimûneyek tevlihevtir, karanînek bikar tîne:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Iterator li ser jêrzemînên perçê têlên dayîn, ji hêla karakterên ku bi rengek hevahengî ve têne veqetandin.
    ///
    /// [pattern] dikare bibe `&str`, [`char`], perçek [`char`] ê, an fonksiyonek an girtinek ku diyar dike ka karakterek li hev dike an na.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Hevwateyê [`split`] e, ji xeynî ku jêrzemîna paşîn heke vala be tê paşve xistin.
    ///
    /// [`split`]: str::split
    ///
    /// Ev rêbaz dikare ji bo daneyên têl ên ku _terminated_ e, li şûna _separated_ ji hêla nimûneyekê ve were bikar anîn.
    ///
    /// # Tevgera Iterator
    ///
    /// Heke nimûneyek lêgerînek berevajî bihêle û lêgerîna forward/reverse heman hêmanan bide hev iteratorê vegerî dê [`DoubleEndedIterator`] be.
    /// Ev ji bo nimûne, [`char`] rast e, lê ne ji bo `&str`.
    ///
    /// Heke nimûneyek lêgerînek berevajî dihêle lê dibe ku encamên wê ji lêgerînek pêş cuda bibin, rêbaza [`rsplit_terminator`] dikare were bikar anîn.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Ittorek li ser jêrzemînên `self`, bi tîpên ku bi rengek hevahengî hatine veqetandin û bi rêza berevajî derketin.
    ///
    /// [pattern] dikare bibe `&str`, [`char`], perçek [`char`] ê, an fonksiyonek an girtinek ku diyar dike ka karakterek li hev dike an na.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Hevwateyê [`split`] e, ji xeynî ku jêrzemîna paşîn heke vala be tê paşve xistin.
    ///
    /// [`split`]: str::split
    ///
    /// Ev rêbaz dikare ji bo daneyên têl ên ku _terminated_ e, li şûna _separated_ ji hêla nimûneyekê ve were bikar anîn.
    ///
    /// # Tevgera Iterator
    ///
    /// Iteratorê vegerandî hewce dike ku şêweyek lêgerînek berevajî piştgirî dike, û heke lêgerînek forward/reverse heman hêmanan bide ew ê du carî biqede.
    ///
    ///
    /// Ji bo iterating ji pêş, rêbaza [`split_terminator`] dikare were bikar anîn.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Ittorek li ser jêrzemînên perçeya têlê ya hatî dayîn, ji hêla nimûneyekê ve veqetandî, vegerandina herî zêde `n` hêman qedexe kir.
    ///
    /// Heke zencîreyên `n` werin vegerandin, dê rêzika paşîn (binyata `n`-yê) ya mayî têl hebe.
    ///
    /// [pattern] dikare bibe `&str`, [`char`], perçek [`char`] ê, an fonksiyonek an girtinek ku diyar dike ka karakterek li hev dike an na.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tevgera Iterator
    ///
    /// Iteratorê vegerî dê du carî biqede, ji ber ku ew piştgirî ne kêrhatî ye.
    ///
    /// Ger nimûneyek lêgerînek berevajî dihêle, rêbaza [`rsplitn`] dikare were bikar anîn.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Nimûneyên hêsan:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Nimûneyek tevlihevtir, karanînek bikar tîne:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Iterator li binê zincîrên vê perçê têl, ku bi nexşeyek ji hev veqetandî, ji dawiya têlê dest pê dike, vegera herî zêde `n` hêmanan qedexe dike.
    ///
    ///
    /// Heke zencîreyên `n` werin vegerandin, dê rêzika paşîn (binyata `n`-yê) ya mayî têl hebe.
    ///
    /// [pattern] dikare bibe `&str`, [`char`], perçek [`char`] ê, an fonksiyonek an girtinek ku diyar dike ka karakterek li hev dike an na.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tevgera Iterator
    ///
    /// Iteratorê vegerî dê du carî biqede, ji ber ku ew piştgirî ne kêrhatî ye.
    ///
    /// Ji bo perçebûna ji pêş, rêbaza [`splitn`] dikare were bikar anîn.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Nimûneyên hêsan:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Nimûneyek tevlihevtir, karanînek bikar tîne:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Têl li ser bûyera yekem a tixûbdarê diyarkirî dabeş dike û pêşgira berî veqetandek û paşpirtika piştî veqetandinê vedigerîne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Têl li ser rûdana dawîn a veqetandek diyarkirî dabeş dike û pêşgira berî veqetandek û paşpirtika piştî veqetandinê vedigerîne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Iterator li ser maçên jihevdeqetandî yên qalibek ku di nav qurmê têlê dayîn de ye.
    ///
    /// [pattern] dikare bibe `&str`, [`char`], perçek [`char`] ê, an fonksiyonek an girtinek ku diyar dike ka karakterek li hev dike an na.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tevgera Iterator
    ///
    /// Heke nimûneyek lêgerînek berevajî bihêle û lêgerîna forward/reverse heman hêmanan bide hev iteratorê vegerî dê [`DoubleEndedIterator`] be.
    /// Ev ji bo nimûne, [`char`] rast e, lê ne ji bo `&str`.
    ///
    /// Heke nimûneyek lêgerînek berevajî dihêle lê dibe ku encamên wê ji lêgerînek pêş cuda bibin, rêbaza [`rmatches`] dikare were bikar anîn.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Iterator li ser maçên jihevdeqetandî yên qalibek ku di nav vê çerxa têlê de ye, bi rêzê berevajî derket.
    ///
    /// [pattern] dikare bibe `&str`, [`char`], perçek [`char`] ê, an fonksiyonek an girtinek ku diyar dike ka karakterek li hev dike an na.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tevgera Iterator
    ///
    /// Iteratorê vegerandî hewce dike ku nimûneyek lêgerînek berevajî piştgirî dike, û ew ê [`DoubleEndedIterator`] be heke lêgerînek forward/reverse heman hêman bide.
    ///
    ///
    /// Ji bo iterating ji pêş, rêbaza [`matches`] dikare were bikar anîn.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Iterator li ser maçên veqetandî yên qalibek ku di hundurê vê çerxa stringê de ye û hem jî indexa ku maç li wir dest pê dike.
    ///
    /// Ji bo maçên `pat` di nav `self` de ku li hevûdu dikin, tenê nîşanên ku bi pêşbirka yekem re têkildar in têne vegerandin.
    ///
    /// [pattern] dikare bibe `&str`, [`char`], perçek [`char`] ê, an fonksiyonek an girtinek ku diyar dike ka karakterek li hev dike an na.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tevgera Iterator
    ///
    /// Heke nimûneyek lêgerînek berevajî bihêle û lêgerîna forward/reverse heman hêmanan bide hev iteratorê vegerî dê [`DoubleEndedIterator`] be.
    /// Ev ji bo nimûne, [`char`] rast e, lê ne ji bo `&str`.
    ///
    /// Heke nimûneyek lêgerînek berevajî dihêle lê dibe ku encamên wê ji lêgerînek pêş cuda bibin, rêbaza [`rmatch_indices`] dikare were bikar anîn.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // tenê `aba` yekem
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Iterator li ser pêşbirkên jihevkirî yên nexşeyek di nav `self` de, bi rêza berevajî digel indeksa hevrikê derket.
    ///
    /// Ji bo maçên `pat` di nav `self` de ku li hevûdu dikin, tenê nîşanên ku bi maça paşîn re têkildar in têne vegerandin.
    ///
    /// [pattern] dikare bibe `&str`, [`char`], perçek [`char`] ê, an fonksiyonek an girtinek ku diyar dike ka karakterek li hev dike an na.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tevgera Iterator
    ///
    /// Iteratorê vegerandî hewce dike ku nimûneyek lêgerînek berevajî piştgirî dike, û ew ê [`DoubleEndedIterator`] be heke lêgerînek forward/reverse heman hêman bide.
    ///
    ///
    /// Ji bo iterating ji pêş, rêbaza [`match_indices`] dikare were bikar anîn.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // tenê `aba` ya paşîn
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Valahiya stringê ya ku qada spî ya pêşeng û paş ve hatî rakirin vedigerîne.
    ///
    /// 'Whitespace' li gorî şertên Unicode Derived Core Property `White_Space` tête diyar kirin.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Valahiya stringê ya ku qada spî ya sereke hatî rakirin vedigerîne.
    ///
    /// 'Whitespace' li gorî şertên Unicode Derived Core Property `White_Space` tête diyar kirin.
    ///
    /// # Rêberiya nivîsê
    ///
    /// String rêzeyek byte ye.
    /// `start` di vê çerçoveyê de tê wateya yekem helwesta wê rêzika byte;ji bo zimanek çep-ber-rast mîna Englishngilîzî an Rûsî, ev ê bibe milê çepê, û ji bo zimanên rast-ber-çep mîna Erebî an Hebrewbranî, ev ê bibe aliyê rastê.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Valahiya têl a ku qada valahiya paşîn jêkirî ye vedigerîne.
    ///
    /// 'Whitespace' li gorî şertên Unicode Derived Core Property `White_Space` tête diyar kirin.
    ///
    /// # Rêberiya nivîsê
    ///
    /// String rêzeyek byte ye.
    /// `end` di vê çerçoveyê de tê wateya pozîsyona dawî ya wê rêzika byte;ji bo zimanek çep-ber-rast mîna Englishngilîzî an Rûsî, ev ê bibe aliyê rastê, û ji bo zimanên rast-bi-çep wekî Erebî an Hebrewbranî, ev ê bibe aliyê çepê.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Valahiya stringê ya ku qada spî ya sereke hatî rakirin vedigerîne.
    ///
    /// 'Whitespace' li gorî şertên Unicode Derived Core Property `White_Space` tête diyar kirin.
    ///
    /// # Rêberiya nivîsê
    ///
    /// String rêzeyek byte ye.
    /// 'Left' di vê çerçoveyê de tê wateya yekem helwesta wê rêzika byte;ji bo zimanek mîna Erebî an Hebrewbranî ku 'rast ber bi çep ve' ne ji 'çep ber rast', ev dê aliyê _right_ be, ne çep.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Valahiya têl a ku qada valahiya paşîn jêkirî ye vedigerîne.
    ///
    /// 'Whitespace' li gorî şertên Unicode Derived Core Property `White_Space` tête diyar kirin.
    ///
    /// # Rêberiya nivîsê
    ///
    /// String rêzeyek byte ye.
    /// 'Right' di vê çerçoveyê de tê wateya pozîsyona dawî ya wê rêzika byte;ji bo zimanek mîna Erebî an Hebrewbranî ku 'rast ber bi çep ve' ne ji 'çep ber rast', ev ê aliyê _left_ be, ne rast e.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Bi hemî pêşgir û paşpirtikên ku bi şêweyek ku çend carî hatine jêbirin re li hev dikin, perçeyek têl vedigerîne.
    ///
    /// [pattern] dikare [`char`], perçek [`char`] an, an fonksiyonek an girtinek be ku diyar dike ka tîpek lihevhatî ye.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Nimûneyên hêsan:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Nimûneyek tevlihevtir, karanînek bikar tîne:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Maça pêşîn a ku tê zanîn ji bîr mekin, heke wê li jêr rast bikin
            // maça dawî cuda ye
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // BELAW: : `Searcher` tê zanîn ku veberhênanên derbasdar vedigerîne.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Bi hemî pêşgirên ku bi şêweyek ku çend caran hatî jêbirin re li hev dikin, qertek têl vedigerîne.
    ///
    /// [pattern] dikare bibe `&str`, [`char`], perçek [`char`] ê, an fonksiyonek an girtinek ku diyar dike ka karakterek li hev dike an na.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Rêberiya nivîsê
    ///
    /// String rêzeyek byte ye.
    /// `start` di vê çerçoveyê de tê wateya yekem helwesta wê rêzika byte;ji bo zimanek çep-ber-rast mîna Englishngilîzî an Rûsî, ev ê bibe milê çepê, û ji bo zimanên rast-ber-çep mîna Erebî an Hebrewbranî, ev ê bibe aliyê rastê.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // BELAW: : `Searcher` tê zanîn ku veberhênanên derbasdar vedigerîne.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Bi pêşpirtika rakirî perçeyek têlê vedigerîne.
    ///
    /// Ger têl bi nimûneya `prefix` dest pê dike, piştî pêşpirtikê, ku di `Some` de pêçayî ye, zencîrê vedigerîne.
    /// Berevajî `trim_start_matches`, ev rêbaza hanê pêşpirtûkê tam carekê radike.
    ///
    /// Heke têl bi `prefix` dest pê neke, `None` vedigerîne.
    ///
    /// [pattern] dikare bibe `&str`, [`char`], perçek [`char`] ê, an fonksiyonek an girtinek ku diyar dike ka karakterek li hev dike an na.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Bi paşpirtika rakirî qertek têl vedigerîne.
    ///
    /// Heke têl bi nimûneya `suffix` bidawî bibe, rêzika li paşpirtikê, ya ku di `Some` de pêçayî ye, vedigerîne.
    /// Berevajî `trim_end_matches`, ev rêbaza paşpirtûkê tam carekê radike.
    ///
    /// Heke têl bi `suffix` neqede, `None` vedigerîne.
    ///
    /// [pattern] dikare bibe `&str`, [`char`], perçek [`char`] ê, an fonksiyonek an girtinek ku diyar dike ka karakterek li hev dike an na.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Bi hemî paşpirtikên ku bi şêweyek ku çend caran hatî jêbirin re hevûdu digirin rêzek têl vedigerîne.
    ///
    /// [pattern] dikare bibe `&str`, [`char`], perçek [`char`] ê, an fonksiyonek an girtinek ku diyar dike ka karakterek li hev dike an na.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Rêberiya nivîsê
    ///
    /// String rêzeyek byte ye.
    /// `end` di vê çerçoveyê de tê wateya pozîsyona dawî ya wê rêzika byte;ji bo zimanek çep-ber-rast mîna Englishngilîzî an Rûsî, ev ê bibe aliyê rastê, û ji bo zimanên rast-bi-çep wekî Erebî an Hebrewbranî, ev ê bibe aliyê çepê.
    ///
    ///
    /// # Examples
    ///
    /// Nimûneyên hêsan:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Nimûneyek tevlihevtir, karanînek bikar tîne:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // BELAW: : `Searcher` tê zanîn ku veberhênanên derbasdar vedigerîne.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Bi hemî pêşgirên ku bi şêweyek ku çend caran hatî jêbirin re li hev dikin, qertek têl vedigerîne.
    ///
    /// [pattern] dikare bibe `&str`, [`char`], perçek [`char`] ê, an fonksiyonek an girtinek ku diyar dike ka karakterek li hev dike an na.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Rêberiya nivîsê
    ///
    /// String rêzeyek byte ye.
    /// 'Left' di vê çerçoveyê de tê wateya yekem helwesta wê rêzika byte;ji bo zimanek mîna Erebî an Hebrewbranî ku 'rast ber bi çep ve' ne ji 'çep ber rast', ev dê aliyê _right_ be, ne çep.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Bi hemî paşpirtikên ku bi şêweyek ku çend caran hatî jêbirin re hevûdu digirin rêzek têl vedigerîne.
    ///
    /// [pattern] dikare bibe `&str`, [`char`], perçek [`char`] ê, an fonksiyonek an girtinek ku diyar dike ka karakterek li hev dike an na.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Rêberiya nivîsê
    ///
    /// String rêzeyek byte ye.
    /// 'Right' di vê çerçoveyê de tê wateya pozîsyona dawî ya wê rêzika byte;ji bo zimanek mîna Erebî an Hebrewbranî ku 'rast ber bi çep ve' ne ji 'çep ber rast', ev ê aliyê _left_ be, ne rast e.
    ///
    ///
    /// # Examples
    ///
    /// Nimûneyên hêsan:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Nimûneyek tevlihevtir, karanînek bikar tîne:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Vê têlê parçe dike nav celebek din.
    ///
    /// Ji ber ku `parse` pir gelemperî ye, ew dikare bibe sedema pirsgirêkên bi rêzgirtina celebê.
    /// Bi vî rengî, `parse` yek ji çend carinan e ku hûn ê hevoksaziyê bi dilovanî wekî 'turbofish' têne zanîn bibînin: `::<>`.
    ///
    /// Ev alîkariya algorîtmaya encamnameyê dike ku bi taybetî têbigihêje ka kîjan celeb hûn hewl didin ku li hev bikin.
    ///
    /// `parse` dikare li her celebê ku [`FromStr`] trait bicîh dike parsê bike.
    ///

    /// # Errors
    ///
    /// Heke ne mimkun be ku meriv vê qurmê têlê li celebê xwestî veqetîne dê [`Err`] vegerîne.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Li şûna têgihiştina `four` 'turbofish' bikar bînin:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Neçêkirin:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Kontrol dike ku gelo hemî karakterên vê rêzê di nav ASCII de ne.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Em dikarin li vir her baytekê wekî xeysetê binirxînin: hemî tîpên pirbyteyî bi baytekê ku ne di rêza ascii de ye dest pê dikin, ji ber vê yekê em ê li wir rawestin.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Kontrol dike ku du têl hevberdanê ASCII-mesele ne-hesas in.
    ///
    /// Heman wekî `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, lê bêyî veqetandin û kopîkirina hemdeman.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Vê têlê li cîhê xwe wekhevê mezin a ASCII vedigire.
    ///
    /// Nameyên ASCII 'a' bo 'z' bi 'A' bo 'Z' têne nexşekirin, lê tîpên ne-ASCII neguhêrîn.
    ///
    /// Ji bo ku bêyî guhertina ya heyî nirxek mezin nû vegerînin, [`to_ascii_uppercase()`] bikar bînin.
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // EWLEH: ewledar e ji ber ku em du tebeqeyên bi heman şêwekariyê veguherînin.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Vê têlê veguherîne hevkêşeya xweya biçûk a ASCII.
    ///
    /// Nameyên ASCII 'A' bo 'Z' bi 'a' bo 'z' têne nexşekirin, lê tîpên ne-ASCII neguhêrîn.
    ///
    /// Ji bo ku bêyî guhertina ya heyî, nirxek nû ya jêrîn vegerînin, [`to_ascii_lowercase()`] bikar bînin.
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // EWLEH: ewledar e ji ber ku em du tebeqeyên bi heman şêwekariyê veguherînin.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Iteratorê ku di `self` de bi [`char::escape_debug`] ji her char direve vegerînin.
    ///
    ///
    /// Note: dê tenê xalên kodê yên grafema dirêjkirî yên ku rêzê dest pê dikin werin xilas kirin.
    ///
    /// # Examples
    ///
    /// Wekî veberhêner:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` rasterast bikar tînin:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Herdu jî wekhev in:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// `to_string` bikar tînin:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Iteratorê ku di `self` de bi [`char::escape_default`] ji her char direve vegerînin.
    ///
    ///
    /// # Examples
    ///
    /// Wekî veberhêner:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` rasterast bikar tînin:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Herdu jî wekhev in:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// `to_string` bikar tînin:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Iteratorê ku di `self` de bi [`char::escape_unicode`] ji her char direve vegerînin.
    ///
    ///
    /// # Examples
    ///
    /// Wekî veberhêner:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` rasterast bikar tînin:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Herdu jî wekhev in:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// `to_string` bikar tînin:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Str-a vala diafirîne
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Str a mutable vala diafirîne
    #[inline]
    fn default() -> Self {
        // BELAW: Rêzika vala UTF-8 derbasdar e.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Navdêr, celebek fon a klonebar
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // BELA: ne ewledar e
        unsafe { from_utf8_unchecked(bytes) }
    };
}