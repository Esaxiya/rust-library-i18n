//! Awayên afirandina `str`-a ji perçê byteyan.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Parçeyek byteyan veguherîne beşek têl.
///
/// ([`&str`]) xelekek têl ji byte ([`u8`]) tête çêkirin, û beşek byte ([`&[u8]`][byteslice]) ji byte tête çêkirin, ji ber vê yekê ev fonksiyon di navbera her duyan de vedigire.
/// Ne ku hemî perçeyên byte pelikên têlên derbasdar in, lêbelê: [`&str`] hewce dike ku ew UTF-8 derbasdar e.
/// `from_utf8()` kontrol dike ku bayît UTF-8 derbasdar in, û paşê veguherînê dike.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Heke hûn pê ewle ne ku beşa byte UTF-8 derbasdar e, û hûn naxwazin serê jorîn ê kontrola rastdariyê bistînin, guhertoyek ne ewle ya vê fonksiyonê heye, [`from_utf8_unchecked`], ku heman reftar heye lê venêrana kontrolê dike.
///
///
/// Heke di şûna `&str` de ji we re `String` hewce be, [`String::from_utf8`][string] bifikirin.
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Ji ber ku hûn dikarin `[u8; N]`-ê stack-veqetînin, û hûn dikarin jê [`&[u8]`][byteslice] bigirin, ev fonksiyon yek awayek e ku hûn têl-veqetandek veqetandî bin.Di beşa mînakan a li jêr de mînakek vê heye.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Ger pişk ne UTF-8 be bi vegotinê vedigere `Err` lê vedigere ka çima pelika dabînkirî ne UTF-8 ye.
///
/// # Examples
///
/// Bikaranîna bingehîn:
///
/// ```
/// use std::str;
///
/// // hin byte, di vector de
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Em dizanin van bayît derbasdar in, ji ber vê yekê tenê `unwrap()` bikar bînin.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Bîtên çewt:
///
/// ```
/// use std::str;
///
/// // hin byteyên nederbasdar, di vector de
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Ji bo bêtir agahdarî li ser cûreyên çewtiyên ku dikarin werin vegerandin ji bo [`Utf8Error`] belgeyan bibînin.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // hin byte, di rêzeyek dabeşkirî de
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Em dizanin van bayît derbasdar in, ji ber vê yekê tenê `unwrap()` bikar bînin.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // EWLEH: Tenê pejirandinê meşand.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Parçeyek guhêrbar a byteyan veguherîne perçeyek têl a mutable.
///
/// # Examples
///
/// Bikaranîna bingehîn:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" wekî vector mutabîl
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Wekî ku em dizanin ev bayt derbasdar in, em dikarin `unwrap()` bikar bînin
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Bîtên çewt:
///
/// ```
/// use std::str;
///
/// // Di vector ya guhêrbar de hin byteyên nederbasdar
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Ji bo bêtir agahdarî li ser cûreyên çewtiyên ku dikarin werin vegerandin ji bo [`Utf8Error`] belgeyan bibînin.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // EWLEH: Tenê pejirandinê meşand.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Bêyî kontrol bike ku têl UTF-8-ya derbasdar heye, perçeyek byteyan veguherîne beşek têl.
///
/// Ji bo bêtir agahdariyê guhertoya ewledar, [`from_utf8`], bibînin.
///
/// # Safety
///
/// Ev fonksiyon ne ewle ye ji ber ku ew venêran dike ku baytên ku jê re hatine derbas kirin UTF-8 derbasdar in.
/// Ger ev astengî were binpê kirin, encama tevgera nediyarkirî, wekî ku Rust ya mayî ferz dike ku [`&str`] s UTF-8 derbasdar in.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Bikaranîna bingehîn:
///
/// ```
/// use std::str;
///
/// // hin byte, di vector de
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // EWLEH: Y::Divê bangker garantî bike ku byteyên `v` UTF-8 derbasdar in.
    // Her weha xwe dispêre `&str` û `&[u8]` ku xwedan heman verastkirinê ne.
    unsafe { mem::transmute(v) }
}

/// Bêyî kontrol bike ku têl UTF-8-ya derbasdar heye, perçeyek byteyan veguherîne beşek têl;guhertoya guhêrbar.
///
///
/// Ji bo bêtir agahdariyê guhertoya neguhêrbar, [`from_utf8_unchecked()`] bibînin.
///
/// # Examples
///
/// Bikaranîna bingehîn:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // EWLEH: Y::Divê bangker garantî bike ku byteyên `v`
    // UTF-8 derbasdar in, lewma kasta `*mut str` ewledar e.
    // Jî, dereference pointer ewle ye ji ber ku ew pointer ji referansa ku ji bo nivîsandinê derbasdar e tê.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}