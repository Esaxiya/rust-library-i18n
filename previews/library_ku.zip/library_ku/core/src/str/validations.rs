//! Operasyonên têkildarî pejirandina UTF-8.

use crate::mem;

use super::Utf8Error;

/// Ji bo bîteya yekem berhevkarê kodê ya destpêkê vedigire.
/// Bîta yekem taybetî ye, tenê ji bo firehiya 2, 5 bit ji bo firehiya 3, û 3 bit ji bo firehiya 4 5 bitikên jêrîn dixwazin.
///
#[inline]
fn utf8_first_byte(byte: u8, width: u32) -> u32 {
    (byte & (0x7F >> width)) as u32
}

/// Nirxa `ch` bi berdewamiya byte `byte` ve nûvekirî vedigerîne.
#[inline]
fn utf8_acc_cont_byte(ch: u32, byte: u8) -> u32 {
    (ch << 6) | (byte & CONT_MASK) as u32
}

/// Kontrol dike ka bayt bytek berdewamiya UTF-8 e (ango, bi bits `10` dest pê dike).
///
#[inline]
pub(super) fn utf8_is_cont_byte(byte: u8) -> bool {
    (byte & !CONT_MASK) == TAG_CONT_U8
}

#[inline]
fn unwrap_or_0(opt: Option<&u8>) -> u8 {
    match opt {
        Some(&byte) => byte,
        None => 0,
    }
}

/// Xala kodê ya paşîn ji a byte iterator (bihesibandina kodkirina mîna UTF-8) dixwîne.
///
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn next_code_point<'a, I: Iterator<Item = &'a u8>>(bytes: &mut I) -> Option<u32> {
    // Decode UTF-8
    let x = *bytes.next()?;
    if x < 128 {
        return Some(x as u32);
    }

    // Mesela pirbyte Decode ji kombînasyona baytekê dişopîne: [[[x y] z] w]
    //
    // NOTE: Performansa li vir ji formulasyona rastîn re hesas e
    let init = utf8_first_byte(x, 2);
    let y = unwrap_or_0(bytes.next());
    let mut ch = utf8_acc_cont_byte(init, y);
    if x >= 0xE0 {
        // [[x y z] w] doz
        // Di 0xE0 de bitika 5-an .. 0xEF her gav zelal e, lewma `init` hîn jî derbasdar e
        let z = unwrap_or_0(bytes.next());
        let y_z = utf8_acc_cont_byte((y & CONT_MASK) as u32, z);
        ch = init << 12 | y_z;
        if x >= 0xF0 {
            // [x y z w] rewşê tenê 3 bitikên jêrîn ên `init` bikar bînin
            //
            let w = unwrap_or_0(bytes.next());
            ch = (init & 7) << 18 | utf8_acc_cont_byte(y_z, w);
        }
    }

    Some(ch)
}

/// Xala kodê ya paşîn ji iteratorê bajarek (bihesibandina kodkirina mîna UTF-8) dixwîne.
///
#[inline]
pub(super) fn next_code_point_reverse<'a, I>(bytes: &mut I) -> Option<u32>
where
    I: DoubleEndedIterator<Item = &'a u8>,
{
    // Decode UTF-8
    let w = match *bytes.next_back()? {
        next_byte if next_byte < 128 => return Some(next_byte as u32),
        back_byte => back_byte,
    };

    // Doza Multibyte Decode ji kombînasyona baytekê dişopîne: [x [y [z w]]]
    //
    let mut ch;
    let z = unwrap_or_0(bytes.next_back());
    ch = utf8_first_byte(z, 2);
    if utf8_is_cont_byte(z) {
        let y = unwrap_or_0(bytes.next_back());
        ch = utf8_first_byte(y, 3);
        if utf8_is_cont_byte(y) {
            let x = unwrap_or_0(bytes.next_back());
            ch = utf8_first_byte(x, 4);
            ch = utf8_acc_cont_byte(ch, y);
        }
        ch = utf8_acc_cont_byte(ch, z);
    }
    ch = utf8_acc_cont_byte(ch, w);

    Some(ch)
}

// truncation bikar bînin ku u64 di nav karanînê de bicîh bikin
const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;

/// Heke di peyva `x` de bytek hebe, ne-fas e `true` vedigerîne (>=128).
#[inline]
fn contains_nonascii(x: usize) -> bool {
    (x & NONASCII_MASK) != 0
}

/// Bi `v` re digere ku ew rêzeyek UTF-8 derbasdar e, di wê rewşê de `Ok(())` vedigerîne, an jî, heke nerast e, `Err(err)`.
///
#[inline(always)]
pub(super) fn run_utf8_validation(v: &[u8]) -> Result<(), Utf8Error> {
    let mut index = 0;
    let len = v.len();

    let usize_bytes = mem::size_of::<usize>();
    let ascii_block_size = 2 * usize_bytes;
    let blocks_end = if len >= ascii_block_size { len - ascii_block_size + 1 } else { 0 };
    let align = v.as_ptr().align_offset(usize_bytes);

    while index < len {
        let old_offset = index;
        macro_rules! err {
            ($error_len: expr) => {
                return Err(Utf8Error { valid_up_to: old_offset, error_len: $error_len })
            };
        }

        macro_rules! next {
            () => {{
                index += 1;
                // me hewceyê daneyê bû, lê tune bû: xelet!
                if index >= len {
                    err!(None)
                }
                v[index]
            }};
        }

        let first = v[index];
        if first >= 128 {
            let w = UTF8_CHAR_WIDTH[first as usize];
            // Kodkirina 2-byte ji bo xalên kodê ye\u {0080} ji bo\u {07ff} yekem C2 80 dawîn DF BF
            // Kodkirina 3-bayt ji bo xalên kodê ye\u {0800} ji bo\u {ffff} yekem E0 A0 80 dawîn EF BF BF ji xeynî codepoints\u {d800} heya\u {dfff} ED A0 80 ber ED BF BF
            // Kodkirina 4-baytê ji bo xalên kodê ye\u {1000} 0 heya\u {10ff} ff yekem F0 90 80 80 dawîn F4 8F BF BF
            //
            // Ji RFC-yê hevoksaziya UTF-8 bikar bînin
            //
            // https://tools.ietf.org/html/rfc3629
            // UTF8-1=% x00-7F UTF8-2=% xC2-DF UTF8-dûvik UTF8-3= %xE0% xA0-BF UTF8-dûvik/% xE1-EC 2( UTF8-tail )/%xED% x80-9F UTF8-dûvik/% xEE-EF 2( UTF8-tail ) UTF8-4= %xF0% x90-BF 2( UTF8-tail )/% xF1-F3 3( UTF8-tail )/%xF4% x80-8F 2( UTF8-tail )
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            match w {
                2 => {
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(1))
                    }
                }
                3 => {
                    match (first, next!()) {
                        (0xE0, 0xA0..=0xBF)
                        | (0xE1..=0xEC, 0x80..=0xBF)
                        | (0xED, 0x80..=0x9F)
                        | (0xEE..=0xEF, 0x80..=0xBF) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                }
                4 => {
                    match (first, next!()) {
                        (0xF0, 0x90..=0xBF) | (0xF1..=0xF3, 0x80..=0xBF) | (0xF4, 0x80..=0x8F) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(3))
                    }
                }
                _ => err!(Some(1)),
            }
            index += 1;
        } else {
            // Doza Ascii, hewl bidin ku zû bavêjin pêş.
            // Dema ku nîşander lihevhatî be, her dubare 2 peyvên daneyê bixwînin heya ku em peyvekê bibînin ku byteke ne-ascii tê de ye.
            //
            if align != usize::MAX && align.wrapping_sub(index) % usize_bytes == 0 {
                let ptr = v.as_ptr();
                while index < blocks_end {
                    // EWLEH: : ji `align - index` û `ascii_block_size` in
                    // pirjimarên `usize_bytes`, `block = ptr.add(index)` her gav bi `usize` re lihevhatî ye ji ber vê yekê ew ji `block` û `block.offset(1)` veqetîna ewledar e.
                    //
                    //
                    unsafe {
                        let block = ptr.add(index) as *const usize;
                        // bişkînin heke byteyek nonascii hebe
                        let zu = contains_nonascii(*block);
                        let zv = contains_nonascii(*block.offset(1));
                        if zu | zv {
                            break;
                        }
                    }
                    index += ascii_block_size;
                }
                // gav ji xala ku xeleka bêjeyê lê sekinî
                while index < len && v[index] < 128 {
                    index += 1;
                }
            } else {
                index += 1;
            }
        }
    }

    Ok(())
}

// https://tools.ietf.org/html/rfc3629
static UTF8_CHAR_WIDTH: [u8; 256] = [
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x1F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x3F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x5F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x7F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0x9F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0xBF
    0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, // 0xDF
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, // 0xEF
    4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0xFF
];

/// Bîtek yekem dane, diyar dike ka di vê karektera UTF-8 de çend bayt hene.
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn utf8_char_width(b: u8) -> usize {
    UTF8_CHAR_WIDTH[b as usize] as usize
}

/// Maska bitikên nirxê ya byteke domdar.
const CONT_MASK: u8 = 0b0011_1111;
/// Nirxa bits tag (mask mask !CONT_MASK e) ya byteke domdar.
const TAG_CONT_U8: u8 = 0b1000_0000;

// `&str` kurt bike ku bi dirêjahiya wê herî zêde bi `max` vegere `true` vegerîne ger ew were qut kirin, û str nû.
//
pub(super) fn truncate_to_char_boundary(s: &str, mut max: usize) -> (bool, &str) {
    if max >= s.len() {
        (false, s)
    } else {
        while !s.is_char_boundary(max) {
            max -= 1;
        }
        (true, &s[..max])
    }
}