//! String Pattern API.
//!
//! Pattern API mekanîzmayek gelemperî peyda dike ji bo karanîna celebên nimûneyên cihêreng dema ku hûn li têlek digerin.
//!
//! Ji bo bêtir agahdariyê, li traits [`Pattern`], [`Searcher`], [`ReverseSearcher`], û [`DoubleEndedSearcher`] binihêrin.
//!
//! Her çend ev API bêîstîkrar be jî, ew bi rêya APIyên stabîl li ser celebê [`str`] tê xuyang kirin.
//!
//! # Examples
//!
//! [`Pattern`] ji bo [`&str`][`str`], [`char`], pelikên [`char`], û fonksiyon û girtinên `FnMut(char) -> bool` di API aram de [implemented][pattern-impls] e.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // nimûneya char
//! assert_eq!(s.find('n'), Some(2));
//! // perçe qaliba qaliban
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // nimûneya girtinê
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Êweyek têl.
///
/// A `Pattern<'a>` îfade dike ku celebê bicîhkirinê dikare ji bo lêgerîna li [`&'a str`][str] wekî rêgezek têl were bikar anîn.
///
/// Mînakî, her du `'a'` û `"aa"` qalibên ku dê li index `1` ya têl `"baaaab"` li hev bikin in.
///
/// trait bixwe ji bo celebek têkildar [`Searcher`] wekî avakarek tevdigere, ku karê rastîn a dîtina rûdanên nimûneyê di têlekekê de dike.
///
///
/// Bi celebê nimûneyê ve girêdayî, tevgera rêbazên mîna [`str::find`] û [`str::contains`] dikare biguhere.
/// Tabloya li jêr hin ji wan reftaran diyar dike.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Ji bo vê şêweyê lêgerînerê peywendîdar
    type Searcher: Searcher<'a>;

    /// Ji `self` û `haystack` lêgerînerê têkildar çêdike ku lê bigere.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Kontrol dike ka gelo pêşnûma li cîhê axê dikeve
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Kontrol dike ka nimûneyek li pêş haystanê li hev tê an na
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Kontrol dike ka gelo nimûneya li paş haystokê li hev tê an na
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Heke lihevhatî be, nimûneyê ji pêş haystackê radike.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // BELAW: : `Searcher` tê zanîn ku veberhênanên derbasdar vedigerîne.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Heke lihevhatî be, nimûneyê ji paş haystackê radike.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // BELAW: : `Searcher` tê zanîn ku veberhênanên derbasdar vedigerîne.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Encama gazîkirina [`Searcher::next()`] an [`ReverseSearcher::next_back()`].
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Expressfade dike ku lihevkirinek nimûneyê li `haystack[a..b]` hatiye dîtin.
    ///
    Match(usize, usize),
    /// Diyar dike ku `haystack[a..b]` wekî pêşbirkek gengaz a nimûneyê hatiye red kirin.
    ///
    /// Bala xwe bidinê ku dibe ku di navbera du `Match`-ê de ji yekê zêdetir `Reject` hebe, hewce nake ku ew di yek de bêne yek kirin.
    ///
    ///
    Reject(usize, usize),
    /// Esfade dike ku her bajarek haystack hatiye ziyaret kirin, dûbarekirin bi dawî dibe.
    ///
    Done,
}

/// Lêgerînek ji bo qalibek têl.
///
/// Ev trait ji bo lêgerîna maçên ne-lihevhatî yên qalibek ku ji pêşiya (left) a têl dest pê dike, rêbazan peyda dike.
///
/// Ew ê ji hêla celebên têkildar `Searcher` yên [`Pattern`] trait ve were bicîh kirin.
///
/// trait ne ewledar tête nîşankirin ji ber ku nîşanên ku bi rêbazên [`next()`][Searcher::next] vegeriyane hewce ne ku li ser sînorên derbasdar ên utf8 di nav kayê de derewan bikin.
/// Ev dihêle ku xerîdarên vê trait-ê bêyî venêranên dirêjahiyê yên din haystakê qut bikin.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter ji bo rêzika bingehîn ku dê lê bigere
    ///
    /// Dê her dem heman [`&str`][str] vegerîne.
    fn haystack(&self) -> &'a str;

    /// Gava pêşîn a lêgerînê ji pêş ve destpê dike pêk tîne.
    ///
    /// - [`Match(a, b)`][SearchStep::Match] vedigerîne heke `haystack[a..b]` li gorî nimûneyê be.
    /// - [`Reject(a, b)`][SearchStep::Reject] vedigerîne heke `haystack[a..b]` nekaribe bi qalibê xwe, bi qismî jî li hev bike.
    /// - Ger her bajarekî haystanê were ziyaret kirin [`Done`][SearchStep::Done] vedigere.
    ///
    /// Rêjeya nirxên [`Match`][SearchStep::Match] û [`Reject`][SearchStep::Reject] heya [`Done`][SearchStep::Done] dê rêzikên navnîşê yên ku cîran in, ne li hevûdu ne, tevaya haystanê vedigire, û li ser sînorên utf8 danîne.
    ///
    ///
    /// Pêdivî ye ku encamek [`Match`][SearchStep::Match] tevahî nimûneya lihevkirî hebe, lêbelê dibe ku encamên [`Reject`][SearchStep::Reject] di gelek perçeyên cîranên keyfî de werin parve kirin.Dibe ku dirêjahiya sifir a her du rêzikan hebe.
    ///
    /// Wekî mînakek, nimûneya `"aaa"` û haystack `"cbaaaaab"` dibe ku çem hilberînin
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Encama [`Match`][SearchStep::Match]-ya paşîn dibîne.[`next()`][Searcher::next] bibînin.
    ///
    /// Berevajî [`next()`][Searcher::next], çu garantî tune ku rêzikên vegerandî yên vê û [`next_reject`][Searcher::next_reject] li hevûdu bikin.
    /// Ev dê `(start_match, end_match)` vegerîne, ku start_match nîşana cihê ku pêşbirk dest pê dike ye, û end_match nîşana piştî bidawîbûna maçê ye.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Encama [`Reject`][SearchStep::Reject]-ya paşîn dibîne.[`next()`][Searcher::next] û [`next_match()`][Searcher::next_match] bibînin.
    ///
    /// Berevajî [`next()`][Searcher::next], çu garantî tune ku rêzikên vegerandî yên vê û [`next_match`][Searcher::next_match] li hevûdu bikin.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Lêgerînek berevajî ji bo qalibek têl.
///
/// Ev trait ji bo lêgerîna maçên ne-lihevhatî yên qalibek ku ji paşiya (right) a rêzê dest pê dike, rêbazan peyda dike.
///
/// Heke nimûneyek piştgirî dide lêgerîna wê ji paş ve dê ji hêla celebên têkildar [`Searcher`] yên [`Pattern`] trait ve were bicîh kirin.
///
///
/// Rêjeyên navnîşê yên ku ji hêla vê trait ve hatine vegerandin ne hewce ne ku bi rastî yên berevajî yên lêgerîna pêşberî hev bikin.
///
/// Ji ber sedema ku ev trait ne ewle tête nîşankirin, li wan bav trait [`Searcher`] binêrin.
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Gava paşîn a lêgerînê ya paşîn pêk tîne.
    ///
    /// - Ger `haystack[a..b]` li gorî nimûneyê be [`Match(a, b)`][SearchStep::Match] vedigerîne.
    /// - [`Reject(a, b)`][SearchStep::Reject] vedigerîne heke `haystack[a..b]` nekaribe bi qalibê xwe, bi qismî jî li hev bike.
    /// - Ger her bajarekî haystanê were ziyaret kirin [`Done`][SearchStep::Done] vedigere
    ///
    /// Rêjeya nirxên [`Match`][SearchStep::Match] û [`Reject`][SearchStep::Reject] heya [`Done`][SearchStep::Done] dê rêzikên navnîşê yên ku cîran in, ne li hevûdu ne, tevaya haystanê vedigire, û li ser sînorên utf8 danîne.
    ///
    ///
    /// Pêdivî ye ku encamek [`Match`][SearchStep::Match] tevahî nimûneya lihevkirî hebe, lêbelê dibe ku encamên [`Reject`][SearchStep::Reject] di gelek perçeyên cîranên keyfî de werin parve kirin.Dibe ku dirêjahiya sifir a her du rêzikan hebe.
    ///
    /// Wekî mînakek, nimûneya `"aaa"` û haystack `"cbaaaaab"` dibe ku herika `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Encama [`Match`][SearchStep::Match]-ya paşîn dibîne.
    /// [`next_back()`][ReverseSearcher::next_back] bibînin.
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Encama [`Reject`][SearchStep::Reject]-ya paşîn dibîne.
    /// [`next_back()`][ReverseSearcher::next_back] bibînin.
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Nîşanek trait ku îfade bike ku [`ReverseSearcher`] dikare ji bo pêkanîna [`DoubleEndedIterator`] were bikar anîn.
///
/// Ji bo vê yekê, têkela [`Searcher`] û [`ReverseSearcher`] hewce dike ku van şertan bişopîne:
///
/// - Pêdivî ye ku hemî encamên `next()` di rêza berevajî de bi encamên `next_back()` re yeksan bin.
/// - `next()` û `next_back()` hewce ye ku wekî du dawiya rêzeyek nirxan tevbigerin, ango ew nekarin "walk past each other".
///
/// # Examples
///
/// `char::Searcher` `DoubleEndedSearcher` e ji ber ku lêgerîna [`char`] tenê hewce dike ku meriv li yek carek binihêre, ku ji her du aliyan ve yeksan tevdigere.
///
/// `(&str)::Searcher` ne `DoubleEndedSearcher` e ji ber ku qalibê `"aa"` di haystack `"aaa"` de wek `"[aa]a"` an `"a[aa]"` li hev dikeve, ji kîjan alî ve tê lêgerîn.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Impl bo char
/////////////////////////////////////////////////////////////////////////////

/// Ji bo `<char as Pattern<'a>>::Searcher` tîpa têkildar.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // neguhêzbar a ewlehiyê: Divê `finger`/`finger_back` indexek baytê utf8 derbasdar ê `haystack` be Ev neguhêzbar dikare were veqetandin *di nav* pêşbirka_pêşberî û pêşbirka_pêşiyê de, lêbelê divê ew bi tiliyan derkevin ser sînorên xala koda derbasdar.
    //
    //
    /// `finger` nîşana byte ya heyî ya lêgerîna pêşîn e.
    /// Xiyal bikin ku ew berî baytê di navnîşa xwe de, ango heye
    /// `haystack[finger]` yekem byta perçeyê ye ku divê em di dema lêgerîna pêş de kontrol bikin
    ///
    finger: usize,
    /// `finger_back` nîşana byte ya niha ya lêgerîna berevajî ye.
    /// Xiyal bikin ku ew piştî baytê di navnîşa xwe de, ango heye
    /// haystack [tiliya_paşê, 1] byteya dawîn a perçeyê ye ku divê em di dema lêgerîna pêş de teftîş bikin (û bi vî awayî yekem byteya ku dema bangkirina next_back()) tê kontrol kirin.
    ///
    finger_back: usize,
    /// Karaktera ku tê lêgerîn
    needle: char,

    // ewlehiya neguhêzbar: Divê `utf8_size` ji 5î kêmtir be
    /// Hejmara byteyên `needle` dema ku di utf8 de tête kodkirin digire.
    utf8_size: usize,
    /// Kopiyek kodkirî ya utf8 ya `needle`
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // BELAW: : 1-4 ewlehiya `get_unchecked` garantî dike
        // 1. `self.finger` û `self.finger_back` li ser sînorên unicode têne girtin (ev neguhêrbar e)
        // 2. `self.finger >= 0` ji ber ku ew ji 0 dest pê dike û tenê zêde dibe
        // 3. `self.finger < self.finger_back` ji ber ku wekî din char `iter` dê `SearchStep::Done` vegerîne
        // 4.
        // `self.finger` tê berî dawiya hastanê ji ber ku `self.finger_back` di dawiyê de dest pê dike û tenê kêm dibe
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // bêyî ku wekî utf-8 ji nû ve-şîfre kirin, byte kesayetiya heyî zêde bikin
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // piştî karaktera paşîn hat dîtin hastackê bigirin
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // byta paşîn a utf8 derziya kodkirî EWLEHIYETA: me nerast e ku `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Tiliya nû nîşana baytê ye ku me dît, plus yek jî, ji ber ku me ji bo bayta paşîn a karakterê memchr'd kir.
                //
                // Bala xwe bidinê ku ev her gav tiliyek li ser sînorê UTF8 nade me.
                // Ger me karakter *xwe nedît* dibe ku me li byta ne-paşîn a karakterê 3-byte an 4-byte endeks kiribe.
                // Em nekarin tenê bavêjin ser byta destpêkî ya derbasdar a din ji ber ku karakterek mîna ꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` dê dema ku em li sêyemîn digerin, me hergav byta duyemîn bibînin.
                //
                //
                // Lêbelê, ev bi tevahî baş e.
                // Dema ku em neguhêzbar in ku self.finger li ser sînorek UTF8 e, di vê rêbazê de li ser vê neguhêrbar nayê bawer kirin (ew di CharSearcher::next()) de tê bawer kirin.
                //
                // Em tenê dema ku em digihîjin dawiya têlan, an heke em tiştek bibînin em ji vê rêbazê derdikevin.Dema ku em tiştek bibînin `finger` dê li ser sînorek UTF8 were danîn.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // tiştek nedît, derket
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // bila next_red redkirina sepanê ji Searcher trait bikar bîne
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // EWLEH: : ji bo next() li jor şîroveyê bibînin
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // bêyî ku wekî utf-8 ji nû ve were şîfre kirin, byte kesayetiya heyî kêm bike
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // haystackê bigirin lê karakterê dawîn ê lêgerîn ne tê de
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // byta paşîn a utf8 derziya kodkirî EWLEHIYETA: me nerast e ku `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // me li perçeyek ku ji hêla self.finger ve hatibû vegerandin geriya, self.finger lê zêde bike da ku pêşpirtûka bingehîn paşde bistîne
                //
                let index = self.finger + index;
                // memrchr dê indexa baytê ku em dixwazin bibînin vegerîne.
                // Di rewşa karekterekî ASCII de, bi rastî ev e ku em dixwazin tiliya xweya nû be ("after" char di paradîgmaya dubarekirina berevajî de).
                //
                // Ji bo karakterên pirbîbît pêdivî ye ku em ji hêla ASCII ve bêtir bi byteyên wan hebin dakêşin
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // tiliya xwe ber bi karakterê ku hatî dîtin ve bikişîne (ango, di nîşana destpêkê de)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Em nekarin li vir tiliya_ge=index, mezinahî + 1 bikar bînin.
                // Ger me char-a paşîn a karakterê-cûrbecûr cûrbecûr (an jî byta navîn a karekterek cûda) dît em hewce ne ku tiliya_paşê heya `index` bişkînin.
                // Ev bi heman awayî dibe ku potansiyela `finger_back` hebe ku nema li ser sînorek be, lê ev baş e ji ber ku em tenê ji vê fonksiyonê li ser sînorek derdikevin an dema ku haystack bi tevahî lê geriya.
                //
                //
                // Berevajî next_match ev di utf-8 de pirsgirêka byteyên dubare tune ye ji ber ku em li benda paşîn digerin, û me tenê dema ku berevajî lêgerîn em tenê dikarin byteya paşîn bibînin.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // tiştek nedît, derket
                return None;
            }
        }
    }

    // bila next_reject_back ji Searcher trait pêkanîna pêşdibistanê bikar bîne
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Lêgerînên ji bo carkên ku bi [`char`]-ya danehev re wekhev in.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Ji bo pêçek MultiCharEq veke
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Dirêjahiyên bera byte ya navxweyî bidin hev da ku dirêjahiya char heyî bibînin
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Dirêjahiyên bera byte ya navxweyî bidin hev da ku dirêjahiya char heyî bibînin
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Ji bo&[kar] têkevim
/////////////////////////////////////////////////////////////////////////////

// Todo: Guherîn/Jêvekirin ji ber nezelaliya di wateyê de.

/// Ji bo `<&[char] as Pattern<'a>>::Searcher` tîpa têkildar.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Lêgerînên ji bo karakterên ku bi yek ji [`char`]-ên perçeyê re wekhev in.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl ji bo F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Ji bo `<F as Pattern<'a>>::Searcher` tîpa têkildar.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Lêgerînên [`char`]-yên ku bi rayeka diyarkirî re hev digirin.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Ji bo&&str
/////////////////////////////////////////////////////////////////////////////

/// Nûnerên impl `&str`.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Ji bo &str bicîh bikin
/////////////////////////////////////////////////////////////////////////////

/// Lêgerîna binerdê ne-veqetandin.
///
/// Dê nimûneya `""` wekî vegerandina maçên vala li her sînorê karakterî bigire dest.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Kontrol dike ka nimûneyek li pêş haystanê li hev tê an na.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Heke lihevhatî be, nimûneyê ji pêş haystackê radike.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // EWLEH: : pêşgir tenê hebûna xwe hate piştrast kirin.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Kontrol dike ka gelo nimûneya li paş haystokê li hev tê an na.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Heke lihevhatî be, nimûneyê ji paş haystackê radike.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // EWLEH: paşpirtûk tenê hate piştrast kirin ku heye.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Lêgerînek jêrzemînê ya du rê
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Ji bo `<&str as Pattern<'a>>::Searcher` tîpa têkildar.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // derziya vala her char red dike û her têla vala di navbera wan de li hev tîne
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher nîşaneyên derbasdar *Match* ên ku li tixûbên kar parçe dibin çêdike heya ku ew hevberdanê rast bike û haystack û derziyê derbasdar be UTF-8 *Ji algorîtmayê red dike* dikare li ser her indeksan bikeve, lê em ê wan bi destan biçin ser sînorê karakterê din, da ku ew utf-8 ewledar bin.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // derbasî sînorê karûbarê din bibin
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // rewşên `true` û `false` binivîsin da ku berhevkar teşwîq bikin ku du rewşan ji hev cuda bike.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // derbasî sînorê karûbarê din bibin
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // `true` û `false` binivîsin, mîna `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// Rewşa navxweyî ya algorîtmaya lêgerînê ya jêr-du-rê.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// index faktorîzasyona krîtîk
    crit_pos: usize,
    /// ji bo derziya berevajî index faktorîzekirina krîtîk
    crit_pos_back: usize,
    period: usize,
    /// `byteset` pêvekek e (ne algorîtmaya du rê ye);
    /// ew "fingerprint" 64-bit e ku her bit bit `j` bi a (byte&63)==j di derziyê re têkildar dibe.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// index nav derziyê berî ku me berê xwe da hev
    memory: usize,
    /// navnîşa nav derziyê piştî ku me berê xwe da hev
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Daxuyaniyek taybetî ya ku li vir diqewime bixwîne dikare di pirtûka "Text Algorithms", C 13 ya Crochemore û Rytter de were dîtin.
        // Bi taybetî kodê ji bo "Algorithm CP" li ser p bibînin.
        // 323.
        //
        // Ya ku diqewime ev e ku me hin faktorîzekirina krîzê (u, v) ya derziyê heye, û em dixwazin diyar bikin ka u paşpirtika&v [.. dewrê] ye.
        // Ger ew be, em "Algorithm CP1" bikar tînin.
        // Wekî din em "Algorithm CP2" bikar tînin, ku ji bo dema ku derziya derziyê mezin e çêtir dibe.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // Bûyera dema kurt-dem bihur rast e faktorîzekirina krîtîk a cihêreng ji bo derziyê berevajî hesab bike x=u 'v' li ku | v '|<period(x).
            //
            // Ev bi dema ku jixwe tê zanîn zûtir dibe.
            // Zanibe ku dozek wekî x= "acba" dibe ku rast bi pêş ve were faktor kirin (crit_pos=1, serdem=3) dema ku bi heyama texmînî bi berevajî ve were faktor kirin (crit_pos=2, serdem=2).
            // Em faktorîzasyona berevajî ya dayî bikar tînin lê serdema rast diparêzin.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // Doza demdirêj-me nêzîkê heyama rastîn heye, û ezberkirinê bikar nakin.
            //
            //
            // Dema ji hêla max(|u|, |v|) + 1-a jêrîn ve nêzîk bikin.
            // Faktoriya krîtîk bandor e ku ji bo lêgerîna pêş û berevajî bikar bîne.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Nirxa dummy ku destnîşan dike ku heyam dirêj e
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Yek ji ramanên sereke yên Du-Rê ev e ku em derziyê di nav du nîvan de, (u, v) faktora dikin, û dest bi hewildana dîtina v di kumika havînê de bi şopandina çepê rastê dikin.
    // Ger v lihevhatî be, em hewl didin ku hûn bi skankirina rastê çepê hev bidin hev.
    // Çiqas ku em dikarin bikevin gava ku em bi nehevsengiyekê re rû bi rû dimînin hemî li ser bingeha ku (u, v) ji bo derziyê faktorîzekirinek krîtîk e.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` `self.position` wekî kursorê xwe bikar tîne
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Kontrol bikin ku li me cîh heye ku em li cîhê lêgerînê bigerin + derzî_ku ma dibe ku em texmîn dikin ku pelikên ji hêla rêzeya isize ve hatine sînorkirin zêde nabe.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Zû zû beşên mezin ên ku bi binhişka me ve negirêdayî ne, paşde bavêjin
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Bibînin ka beşa rastê ya derziyê li hev dike an na
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Bibînin ka beşa çepê derziyê li hev dikeve
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Me maçek dît!
            let match_pos = self.position;

            // Note: self.period li şûna needle.len() zêde bikin da ku maçên hevûdu hebin
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // ji bo maçên li ser hev needle.len(), self.period danîne
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Ramanên li `next()` dişopîne.
    //
    // Pênaseyên simetrîkî ne, bi period(x) = period(reverse(x)) û local_period(u, v) = local_period(reverse(v), reverse(u)), ji ber vê yekê heke (u, v) faktorîzasyonek krîtîk e, (reverse(v) jî wiha ye, reverse(u)).
    //
    //
    // Ji bo rewşa berevajî me faktorîzekirinek x=u 'v' (qada `crit_pos_back`) hesibandiye.Em hewce ne | u |<period(x) ji bo rewşa pêş û bi vî awayî | v '|<period(x) ji bo berevajî.
    //
    // Ji bo ku bi berevajî di nav haystackê de bigerin, em bi riya hay berevajî ya bi derziyek berepaş digerin, pêşî li u 'û paşê v' li hev dikin.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` `self.end` wekî kursorê xwe bikar tîne-da ku `next()` û `next_back()` serbixwe bin.
        //
        let old_end = self.end;
        'search: loop {
            // Kontrol bikin ku di encamê de me odeya lêgerînê heye, dê needle.len() dorpêç bike gava ku cîh nemîne, lê ji ber sînorên dirêjahiya perçê ew carî nikare hemî rê vegere nav dirêjahiya axê.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Zû zû beşên mezin ên ku bi binhişka me ve negirêdayî ne, paşde bavêjin
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Bibînin ka beşa çepê derziyê li hev dikeve
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Bibînin ka beşa rastê ya derziyê li hev dike an na
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Me maçek dît!
            let match_pos = self.end - needle.len();
            // Note: sub self.period li şûna needle.len() ku maçên li ser hev hebin
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Paşgiriya herî zêde ya `arr` hesab bike.
    //
    // Paşgiriya herî zêde faktorîzekirinek krîtîk (u, v) ya `arr` ye.
    //
    // Vedigere (`i`, `p`) ku `i` nîşana destpêkê ya v ye û `p` serdema v ye.
    //
    // `order_greater` destnîşan dike ka rêzika lêksîkî `<` an `>` ye.
    // Divê her du ferman werin hesibandin-rêzkirina bi `i`-a herî mezin re faktorîzekirinek krîtîk dide.
    //
    //
    // Ji bo rewşên demdirêj, dema encam ne rast e (ew pir kurt e).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Di kaxezê de bi i re têkildar dibe
        let mut right = 1; // Di kaxezê de bi j re têkildar dibe
        let mut offset = 0; // Di kaxezê de bi k re têkildar e, lê ji 0 dest pê dike
        // ji bo navnîşkirina 0-bingeh li hev bike.
        let mut period = 1; // Di kaxezê de bi p re têkildar dibe

        while let Some(&a) = arr.get(right + offset) {
            // `left` dema `right` be dê bênavber be.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Paşgir piçûktir e, serjimar heya nuha tev pêşgir e.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Bi dubarekirina dema niha pêşve biçin.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Paşgir mezintir e, ji cîhê heyî dest pê bikin.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Paşpirtûka herî zêde ya berevajî ya `arr` hesab bike.
    //
    // Paşgiriya herî zêde faktorîzekirinek krîtîk a gengaz (u ', v') ya `arr` e.
    //
    // `i` ku `i` nîşana destpêkirina v 'ye, ji paş ve vedigerîne;
    // dema ku serdemek `known_period` gihîşt yekser vedigere.
    //
    // `order_greater` destnîşan dike ka rêzika lêksîkî `<` an `>` ye.
    // Divê her du ferman werin hesibandin-rêzkirina bi `i`-a herî mezin re faktorîzekirinek krîtîk dide.
    //
    //
    // Ji bo rewşên demdirêj, dema encam ne rast e (ew pir kurt e).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Di kaxezê de bi i re têkildar dibe
        let mut right = 1; // Di kaxezê de bi j re têkildar dibe
        let mut offset = 0; // Di kaxezê de bi k re têkildar e, lê ji 0 dest pê dike
        // ji bo navnîşkirina 0-bingeh li hev bike.
        let mut period = 1; // Di kaxezê de bi p re têkildar dibe
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Paşgir piçûktir e, serjimar heya nuha tev pêşgir e.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Bi dubarekirina dema niha pêşve biçin.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Paşgir mezintir e, ji cîhê heyî dest pê bikin.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy dihêle ku algorîtm an zû-zû ne-maçan derbas bike, an jî di moda ku ew Relatî bi rengek zûtir diweşîne bixebite.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Zû zû bi zû navberên maçê derbas bikin
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Emit Bi Rêkûpêk Red dike
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}