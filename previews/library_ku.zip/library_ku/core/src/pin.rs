//! Cûreyên ku daneyê di bîranînê de bi cîhê wê ve pin dikin.
//!
//! Car carna kêrhatî ye ku meriv bi tiştên ku misoger nayên tevgerîn hebe, di wateya ku cîhê wan di bîranînê de naguhere, û bi vî rengî dikare xwe bispêre wan.
//! Nimûneyek sereke ya senaryoyek weha dê avahiyên lêvekirinê yên xweser be, ji ber ku veguheztina objeyek bi nîşangiran ber bi xwe ve dê wan betal bike, ku dibe sedema reftarek nediyarkirî.
//!
//! Di astek bilind de, [`Pin<P>`] misoger dike ku pointee ji her cûreyê pointer `P` di bîrekê de xwediyê cihekî stabîl e, wate ew nikare li cîhek din were veguheztin û heya ku ew dakeve bîra wî nayê veqetandin.Em dibêjin ku pointee "pinned" e.Tiştên ku dema nîqaşkirina li ser cûreyên ku bi daneyên ne-pînkirî re pînekirî ne;[see below](#projections-and-structural-pinning) ji bo bêtir agahdarî.
//!
//! Wekî standard, hemî celebên li Rust guhêzbar in.
//! Rust dihêle ku her cûre ji hêla-nirxê derbas bibin, û celebên hevpar-nîşanderê hevpar ên wekî [`Box<T>`] û `&mut T` rê didin ku nirxên ku ew tê de hene biguherînin û bar bikin: hûn dikarin ji [`Box<T>`] derbikevin, an jî hûn dikarin [`mem::swap`] bikar bînin.
//! [`Pin<P>`] type pointer `P` pêça, lewma [`Pin`]"<"["Box"]"<T>>`fonksiyonên mîna rêkûpêk in
//!
//! [`Box<T>`]: when a [`Pin`]"<"["Sindoq"]"<T>>`davêje, naveroka wê jî bike, û bîr dibe
//!
//! veqetandin.Bi heman awayî, [`Pin`]``<&mut T>`` pir mîna `&mut T` e.Lêbelê, [`Pin<P>`] nahêle xerîdar bi rastî [`Box<T>`] an `&mut T` ji daneyên pinned re peyda bikin, ku tê vê wateyê ku hûn nekarin operasyonên wekî [`mem::swap`] bikar bînin:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` pêdivî bi `&mut T` heye, lê em nikarin wiya bigirin.
//!     // Em asê ne, em nekarin naveroka van referansan bidin hev.
//!     // Em dikarin `Pin::get_unchecked_mut` bikar bînin, lê ew ji ber sedemek ne ewledar e:
//!     // ji me re destûr nayê dayîn ku em wê ji bo derketina tiştan ji `Pin` bikar bînin.
//! }
//! ```
//!
//! Hêjayî gotinê ye ku [`Pin<P>`]*rastiyê* naguherîne ku berhevkarek Rust hemî cûreyan livbar dihesibîne.[`mem::swap`] ji bo her `T` bangî dimîne.Di şûna wê de, [`Pin<P>`] nahêle hin nirxên * *(bi nîşankerên ku di [`Pin<P>`] de pêçandî têne xuyang kirin) werin veguhastin ji ber vê yekê gengaz nabe ku meriv bang li rêbazên ku `&mut T` hewce dike li ser wan bike (mîna [`mem::swap`]).
//!
//! [`Pin<P>`] dikare were bikar anîn ku her cûreyê pointer `P` were pêçandin, û wekî wê ew bi [`Deref`] û [`DerefMut`] re têkiliyê dide.A [`Pin<P>`] ku divê `P: Deref` wekî "`P`-style pointer" ji `P::Target` re pîne were hesibandin-ji ber vê yekê, a [`Pin`]"<"["Box"]"<T>>"nîşanderê xwedan `T` pînekirî ye, û ["Pin"]"<"["Rc"]"<T>>`ji bo `T` pînekirî hejmar-referans tê hesibandin.
//! Ji bo rastbûnê, [`Pin<P>`] xwe dispêre pêkanînên [`Deref`] û [`DerefMut`] ku ji parametreya xweya `self` dernekeve, û tenê hergav vegerîne pointerek li daneyên pinned gava ku ew li pointer pinned têne bang kirin.
//!
//! # `Unpin`
//!
//! Pir celeb her gav bi serbestî têne guhastin, her çend ku bên pînekirin jî, ji ber ku ew pişta xwe nadin navnîşanek aram.Ev hemî cûreyên bingehîn (wekî [`bool`], [`i32`], û çavkanî) û her weha celebên ku tenê ji van celeban pêk tê digire nav xwe.Cûreyên ku ne girîng e ku pînek bikin [`Unpin`] auto-trait bicîh dikin, ku bandora [`Pin<P>`] betal dike.
//! Ji bo `T: Unpin`, ["Pin"] "<" ["Sindoq"] "<T>>`û [`Box<T>`] wekhev fonksiyon dikin, wekî [`Pin`] `<&mut T>` û `&mut T`.
//!
//! Bala xwe bidinê ku pînekirin û [`Unpin`] tenê bandorê li ser xala nîşankirî `P::Target` dikin, ne ku li type `P` pointer ê ku di [`Pin<P>`] de pêça bû.Mînakî, gelo [`Box<T>`] [`Unpin`] e an na, li ser tevgera ["Pin"] "<" ["Box"] "ti bandor tune.<T>>`(li vir, `T` tîpa balkeş e).
//!
//! # Nimûne: struktura xweser
//!
//! Berî ku em têkevin bêtir hûrguliyan da ku garantî û vebijarkên bi `Pin<T>` ve girêdayî ne, vebêjin, em çend mînakan nîqaş dikin ka ew çawa dikare were bikar anîn.
//! [skip to where the theoretical discussion continues](#drop-guarantee) azad bibin.
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Ev damezrandinek xweser-referansî ye ji ber ku qada perçeyê nîşanî qada daneyê dide.
//! // Em nekarin bi referansek normal berhevkar di derheqê wê de agahdar bikin, ji ber ku ev şêwe bi rêgezên deynkirina adetî nayê vegotin.
//! //
//! // Di şûna me de em pêşnumayek rawe bikar tînin, her çend yek tê zanîn ku pûç nabe jî, ji ber ku em dizanin ew li ser têlê radiweste.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Ji bo ku gava fonksiyon vedigere daneyê naşewite, em wê datînin nav koma ku ew ê ji bo heyata heyberê bimîne, û riya yekane ya gihîştinê dê bi riya pointerek pê re be.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // em tenê nîşankerê diafirînin gava ku daneyên di cîh de be nexwe ew ê berî ku em dest pê bikin jî bar kiribe
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // em dizanin ku ev ewle ye ji ber ku guhartina zeviyek tevahî struktura bar nake
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Pêdivî ye ku nîşander cîhê rast nîşan bike, heya ku struktûr neçûye.
//! //
//! // Di vê navberê de, em serbest in ku pointerê li dora xwe bigerînin.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Ji ber ku celebê me Unpin-ê nayne cîbicîkirin, ev ê berhev nebe:
//! // bila mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Mînak: navnîşa du qat-girêdayî ya destdirêjker
//!
//! Di navnîşek du qat-girêdayî ya destdirêjker de, berhevok bi rastî bîranînê ji bo hêmanan bixwe veqetîne.
//! Dabeşandin ji hêla xerîdaran ve tê kontrol kirin, û hêman dikarin li ser çarçovek stackê bijîn ku ji berhevokê kurtirîn jiyan dike.
//!
//! Ji bo çêkirina vê xebatê, di her hêmanê de di navnîşê de nîşangirên selef û pêşengê xwe hene.Hêmanên tenê dema ku têne pînekirin dikarin werin zêdekirin, ji ber ku gerguhêza hêmanan li dora dê nîşangiran bêbandor bike.Wekî din, bicîhkirina [`Drop`] ya hêmanek navnîşa girêdanê dê nîşangirên selef û pêşengê xwe patch bike da ku xwe ji navnîşê derxîne.
//!
//! Ya girîng, divê em bikaribin xwe bisipêrin [`drop`] ya ku tê bang kirin.Ger hêmanek bêyî bangkirina [`drop`] were delet kirin an bi rengek din were betal kirin, dê nîşankerên tê de ji hêmanên cîranên wê neheq bin, ku dê avahiya daneyê bişikîne.
//!
//! Ji ber vê yekê, pînek bi garantîyek têkildarî [`drop`] re jî tê.
//!
//! # `Drop` guarantee
//!
//! Armanca pînekirinê ew e ku meriv xwe bispêre cîhkirina hin daneyan di bîranînê de.
//! Ji bo ku vê xebatê çêbike, ne tenê veguhastina daneyê tê sînorkirin;dellocating, repurposing, an wekî din bêbandorkirina bîranîna ku ji bo hilanîna daneyê tê bikar anîn, jî qedexe ye.
//! Bi teybetî, ji bo daneyên pinnedkirî divê hûn neguhêrbar bimînin ku *bîranîna wê ji kêliyê ve pêçandî de nayê betal kirin û ji nû ve nayê sazkirin heya ku ji [`drop`] re tê gotin*.Tenê carek [`drop`] vegere an panics, dibe ku bîranîn ji nû ve were bikar anîn.
//!
//! Bîra dikare bi deallocation "invalidated" be, lê di heman demê de bi şûna [`Some(v)`] bi [`None`], an gazî [`Vec::set_len`] bo "kill" hin hêmanên ji vector dike.Ew dikare bi karanîna [`ptr::write`] ji nû ve were nûve kirin bêyî ku pêşî bang li hilweşîner bike.Bêyî ku li [`drop`] bang bike, ji vana yek ji bo daneyên pinned nayê destûr kirin.
//!
//! Ev tam celebê garantîbûnê ye ku hewce ye ku navnîşa girêbidest a ji beşa berê bi rêkûpêk bixebite.
//!
//! Bala xwe bidinê ku ev garantî nayê wê wateyê ku bîra dernakeve!Hê jî bi tevahî ne baş e ku meriv carî li hêmanek pînekirî bangî [`drop`] neke (mînakî, hûn hîn jî dikarin li [`mem::forget`] li ser [`Pin`]"<<["Box"]"<T>> `).Di mînaka navnîşa du-girêdan de, ew hêman dê tenê di navnîşê de bimîne.Lêbelê dibe ku hûn depokirin *bêyî gazîkirina [`drop`]* azad nekin an ji nû ve bikar bînin.
//!
//! # `Drop` implementation
//!
//! Heke celebê we pînek bikar tîne (mînakî du nimûneyên jorîn), hûn neçar in ku gava [`Drop`] bicîh bikin.Fonksiyona [`drop`] `&mut self` digire, lê ji vê re *tê gotin* heke tîpa we berê hatibe zincîr kirin *!Mîna ku berhevkar bixweber gazî [`Pin::get_unchecked_mut`] dike.
//!
//! Ev qet nikare di koda ewle de bibe sedema pirsgirêkek ji ber ku cîbicîkirina celebek ku xwe dispêre pînekirinê hewceyê kodek ne ewledar e, lê hay jê hebe ku biryar e ku hûn di celebê xwe de pîneyê bikar bînin (mînakî bi pêkanîna hin operasyona li ser "`Pin`] "<&Xwe>`an [`Pin`] "<&mut Self>") ji bo pêkanîna [`Drop`] we jî encam heye: heke hêmanek ji celebê we were pînekirin, divê hûn [`Drop`] wekî ku bi nehfî ["Pin"] digirin derman bikin "<&mut Xwe>`.
//!
//!
//! Mînakî, hûn dikarin `Drop` wiha bicîh bikin:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` baş e ji ber ku em dizanin ev nirx piştî daketinê carek din nayê bikar anîn.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Koda daketinê ya rastîn diçe vir.
//!         }
//!     }
//! }
//! ```
//!
//! Fonksiyona `inner_drop` celebek ku [`drop`]*heye* divê hebe, ji ber vê yekê ew piştrast dike ku hûn bi neheqî `self`/`this` bi awayek ku bi pînekirinê re nakok e bikar neynin.
//!
//! Wekî din, heke celebê we `#[repr(packed)]` be, berhevkar dê bixweber zeviyan dorpêç bike da ku karibe wan bavêje.Tewra dibe ku wiya ji bo zeviyên ku tê de bi têra xwe lihevrastkirî bikin.Wekî encamek, hûn nikarin pînekirina bi celebek `#[repr(packed)]` bikar bînin.
//!
//! # Pêşniyar û Pîneya Avahî
//!
//! Dema ku bi darbestên pînekirî re dixebitin, pirs çêdibe ku meriv çawa dikare bi rêbaza ku tenê [`Pin`]"<&mut Struktur"digire xwe bigihîne warên wê strukturekê.
//! Nêzîkatiya asayî ev e ku meriv metodên alîkar binivîse (bi vî navî *pêşniyaran*) ku [`Pin`]"<&mut Struktura>"vediguhêzin qadê, lê divê ew referans xwedî çi celeb be?[<Pin`]"<&mut Field>` an `&mut Field` e?
//! Heman pirs bi zeviyên `enum`, û her weha dema ku meriv celebên container/wrapper wekî [`Vec<T>`], [`Box<T>`], an [`RefCell<T>`] li ber çav digire jî çêdibe.
//! (Ev pirs hem ji bo referansên guhêrbar û hem jî ji bo parvekirinan derbas dibe, em tenê ji bo nimûneyê li vir rewşa gelemperî ya referansên guherbar bikar tînin.)
//!
//! Derdikeve holê ku bi rastî ya nivîskarê avahiya daneyê ye ku biryar bide ka gelo projection pinned ji bo zeviyek taybetî [[Pin`]"<&mut Structure>"veguherîne ["Pin"]"<&mut Field>` an `&mut Field`.Her çend hin astengî hene, û astengiya herî girîng *domdar* e:
//! her zevî dikare *yan* bi referansek pînekirî re were pêşnîyar kirin,*an jî* wekî beşek ji pêşnûmeyê pînek jê bibe.
//! Ger her du jî ji bo heman zeviyê werin kirin, ew ê îhtîmal e ku bêaqil be!
//!
//! Wekî nivîskarê avahiyek daneyê hûn ji bo her qadê biryar didin ka gelo "propagates" li vê qadê pîne bikin an na.
//! Ji pîneya ku belav dibe re "structural" jî tê gotin, ji ber ku ew li pey avahiya celebê ye.
//! Di bin beşên jêrîn de, em ramanên ku ji bo her du hilbijartinan divê bêne vegotin.
//!
//! ## Pinning *ji bo `field` ne pêkhatî* ye
//!
//! Dibe ku dij-bînbar xuya bike ku zeviyê struktûrek pînekirî neyê pîne kirin, lê ew bi rastî hilbijartina herî hêsan e: heke ['Pin`]"<&mut Field>" çu carî neyê afirandin, tiştek çênabe xelet here!Ji ber vê yekê, heke hûn biryar bidin ku li hin zeviyan pînekirina avahî tune, ya ku hûn pê ewle ne ew e ku hûn qet referansek pînekirî li ser wî warî çênakin.
//!
//! Di zeviyên bêyî pînekirina avahiyê de dibe ku rêbaza pêşniyazkirinê hebe ku [`Pin`]"<&mut Structure>"veguherîne `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Ev baş e ji ber ku `field` carî nayê pînekirin.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Di heman demê de dibe ku hûn `impl Unpin for Struct`*jî heke* celebê `field` ne [`Unpin`] be.Çi ku ew celeb li ser pînek difikire ne girîng e dema ku qet [`Pin`]"<&mut Field>"neyê afirandin.
//!
//! ## Pinning *ji bo `field` avahî* ye
//!
//! Vebijarka din ev e ku biryar were dayîn ku pînek ji bo `field` "structural" e, wate ku heke struktura pîne be hingê zevî jî wusa ye.
//!
//! Ev dihêle ku pêşnumayek ku ["Pin"] "<&mut Field>" diafirîne binivîse, bi vî rengî şahidiyê dike ku zevî tête pîne kirin:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Ev baş e ji ber ku `field` dema ku `self` e tê pîne kirin.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Lêbelê, pînekirina avahiyê bi çend hewceyên din re tê:
//!
//! 1. Pêdivî ye ku struktûr tenê [`Unpin`] be heke hemî warên avahiyê [`Unpin`] bin.Ev default e, lê [`Unpin`] trait ewle ye, ji ber vê yekê wekî nivîskarê struktura berpirsiyariya we *ne* ye ku hûn tiştek wekî `impl<T> Unpin for Struct<T>` zêde bikin.
//! (Bala xwe bidinê ku zêdekirina operasyona pêşnumayînê pêdivî bi kodek ne ewle heye, ji ber vê yekê rastiya ku [`Unpin`] trait ewle ye prensîpê naşkîne ku hûn tenê ji bo viya heke hûn ne `ewledar` bikar bînin fikar dikin.)
//! 2. Wêrankerê sazûmanê divê qadên pêkhatî ji argumana xwe dernexîne.Ev xala rastîn e ku di [previous section][drop-impl] de hate raber kirin: `drop` `&mut self` digire, lê dibe ku struktura (û ji ber vê yekê zeviyên wê) berê hatibe zeliqandin.
//!     Divê hûn garantî bikin ku hûn zeviyek li hundurê pêkanîna [`Drop`]-a xwe bar nakin.
//!     Bi taybetî, wekî ku berê hatî şirove kirin, ev tê vê wateyê ku divê struktura we *ne*`#[repr(packed)]` be.
//!     Wê beşê bibînin ka meriv çawa [`drop`] bi awayê nivîsandinê dinivîse ku berhevkar dikare ji we re bibe alîkar ku hûn pînekiyê bêhemdî neşkînin.
//! 3. Divê hûn pê ewle bine ku hûn [`Drop` guarantee][drop-guarantee] diparêzin:
//!     gava ku struktura we hate zeliqandin, bîranîna ku naverokê tê de ye, bêyî gazîkirina hilweşînerên naverokê, nayê nivîsandin an veqetandin.
//!     Ev dikare xapînok be, wekî ku ji hêla [`VecDeque<T>`] ve hatî şahidî kirin: hilweşînerê [`VecDeque<T>`] heke yek ji hilweşîner panics be nikare bang li [`drop`] li ser hemî hêmanan bike.Ev garantîkirina [`Drop`] binpê dike, ji ber ku ew dikare bibe sedem ku hêman werin veqetandin bêyî ku hilweşînerê wan were gazîkirin.([`VecDeque<T>`] pêşbîniyên pînekirinê tune, ji ber vê yekê ev nabe sedema bê dengiyê.)
//! 4. Gava ku tîpa we pîne be divê hûn karûbarên din pêşkêş nekin ku bibe sedem ku dane ji zeviyên avahiyê werin derxistin.Mînakî, heke di teşeyê de [`Option<T>`] hebe û bi type `fn(Pin<&mut Struct<T>>) -> Option<T>` re tevgereke mîna-bigire hebe, ew operasyon dikare were bikar anîn ku `T` ji `Struct<T>` pîne were derxistin-ku tê vê wateyê ku pînek ji bo qada ku ev digire ne pêkhatî be jimare.
//!
//!     Ji bo nimûneyek tevlihevtir a veguhastina daneyê ji celebek pînekirî, bifikirin ku [`RefCell<T>`] xwediyê rêbazek `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>` bû.
//!     Wê hingê em dikarin jêrîn bikin:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Ev felaket e, ew tê vê wateyê ku em dikarin pêşî naveroka [`RefCell<T>`] (bi karanîna `RefCell::get_pin_mut`) pin bikin û dûv re jî wê naverokê bi karanîna referansa guhêrbar a ku me paşê stendî bar bikin.
//!
//! ## Examples
//!
//! Ji bo celebek mîna [`Vec<T>`], her du îmkan (pînekirina avahiyê an na) manedar in.
//! A [`Vec<T>`] bi pînekirina avahiyê dikare xwediyê rêbazên `get_pin`/`get_pin_mut` be ku referansên pîne yên hêmanan bistîne.Lêbelê, ew nikaribû * destûr nede bangkirina [`pop`][Vec::pop] li ser [`Vec<T>`] pînekirî ji ber ku ew ê naverokên (bi avakî pînekirî) bar bike!Ne jî dikare destûrê bide [`push`][Vec::push], ku dibe ku ji nû ve veqetîne û bi vî rengî jî naverokan bar bike.
//!
//! [`Vec<T>`] bêyî pînekirina avahiyê dikare `impl<T> Unpin for Vec<T>` bike, ji ber ku naverok qet nayên pîne kirin û [`Vec<T>`] bi xwe jî bi veguheztin xweş e.
//! Di wê demê de pînekirin tenê li vector bandor nabe.
//!
//! Di pirtûkxaneya standard de, celebên pointer bi gelemperî pînekirina avahiyê tune, û bi vî awayî ew pêşnumayên pînekirinê pêşkêş nakin.Ji ber vê yekê ye ku `Box<T>: Unpin` hemî `T` digire.
//! Wateya wê yekê ye ku meriv vê yekê ji bo cûreyên pointer bike, ji ber ku veguheztina `Box<T>` bi rastî `T` bar nake: [`Box<T>`] dikare bi serbestî were bar kirin (ango `Unpin`) heke `T` ne be jî.Di rastiyê de, hetta [`Pin`]``` ```` ```` ```` ```` ``<T>>`û [`Pin`] "<&mut T>" her gav bixwe [`Unpin`] in, ji ber heman sedemê: naverokên wan (`T`) têne girêdan, lê nîşangir bixwe dikarin bêne veguheztin bêyî ku daneyên pînekirî bar bikin.
//! Hem ji bo [`Box<T>`] û ["Pin"] "<" ["Box"] "<T>>`, gelo naverok tê pînekirin bi tevahî serbixwe ye ka nîşander pînekirî ye, ango pînekirin *ne* pêkhatî ye.
//!
//! Gava ku hûn kombînatorê [`Future`] bicîh dikin, hûn ê bi gelemperî hewceyê pînekirina avahiyê ya futures ya hêlînê bin, ji ber ku hûn hewce ne ku ji wan re referansên pînekirî bistînin da ku bangî [`poll`] bikin.
//! Lê heke heke hevahengkerê we daneyek din hebe ku ne hewce ye ku were pîne kirin, hûn dikarin wan zeviyan bikin ne pêkhatî û ji ber vê yekê jî bi serbestî bigihîjin wan bi referansek guhêrbar dema ku hûn tenê [`Pin`]"<&mut Self>"hebin (wusa wekî di pêkanîna xweya [`poll`] de).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Nîşanek pînekirî.
///
/// Ev dorpêçek li dora celebek pêşekkerê ye ku wî nîşanderê "pin" nirxê xwe di cîh de dihêle, nahêle ku nirxa ku ji hêla wî pêşekker ve hatî referanskirin were veguheztin heya ku ew [`Unpin`] bicîh neke.
///
///
/// *Ji bo ravekirina pînekirinê belgeya [`pin` module] bibînin.*
///
/// [`pin` module]: self
///
// Note: `Clone` li jêr derdikeve sedema bêaqilîbûnê wekî ku pêkan e ku were pêkanîn
// `Clone` ji bo referansên guhêrbar.
// Ji bo bêtir agahdarî li <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> binihêrin.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Ji bo ku ji pirsgirêkên saxlemiyê dernekeve, pêkanînên jêrîn ne têne derxistin.
// `&self.pointer` pêdivî ye ku ji pêkanînên trait yên nebawer re peyda nebe.
//
// Ji bo bêtir agahdarî li <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> binihêrin.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// `Pin<P>`-ya nû li dora nîşankerê saz bikin da ku hin daneyên celebek ku [`Unpin`] bicîh dike.
    ///
    /// Berevajî `Pin::new_unchecked`, ev rêbaz ewledar e ji ber ku pêşnîyar `P` vedigere celebek [`Unpin`], ku garantiyên pînekirinê betal dike.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // EWLEH: : nirxa ku nîşanî `Unpin` e, û ji ber vê yekê hewcedariyên wê tune
        // li dora pînekirinê.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Vê `Pin<P>` vedibe nîşana bingehîn vedigerîne.
    ///
    /// Vê yekê hewce dike ku daneyên di hundurê vê `Pin` de [`Unpin`] be da ku em karibin gava vekirina wê pîneyên neguhêzbar paşguh bikin.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// `Pin<P>`-ya nû li dora referansa hin daneyên celebek ava bikin ku dibe ku `Unpin` bicîh bîne an nebe.
    ///
    /// Ger `pointer` derengketinên li celebek `Unpin`, divê li şûna `Pin::new` were bikar anîn.
    ///
    /// # Safety
    ///
    /// Ev konstruktor ne ewledar e ji ber ku em nekarin piştrast bikin ku daneya ku `pointer` nîşanî wî daye, tê pîne kirin, ango heya ku davêjin daneyê nayê veguheztin an depoya wê nayê betal kirin.
    /// Ger `Pin<P>` çêkirî garantî neke ku daneya x01X xalên ku têne pînekirin, ew binpêkirina peymana API ye û dibe ku di operasyonên paşê (safe) de bibe sedema reftarek nediyarkirî.
    ///
    /// Bi karanîna vê rêbazê, hûn li ser pêkanînên `P::Deref` û `P::DerefMut`, heke ew hene, promise dikin.
    /// Ya herî girîng, divê ew ji nîqaşên xwe yên `self` dernekevin: `Pin::as_mut` û `Pin::as_ref` dê `DerefMut::deref_mut` û `Deref::deref`*li pointer* pinned bang bikin * û ji van rêbazan hêvî dikin ku guhêrbarên pîneyê biparêzin.
    /// Wekî din, bi gazîkirina vê rêbarê hûn promise dikin ku derefên referansa `P` yên ku dê ji nû ve neyên derxistin;bi taybetî, ne gengaz e ku meriv `&mut P::Target` peyda bike û dûv re ji wê referansê derkeve (bi karanîn, mînakî [`mem::swap`]).
    ///
    ///
    /// Mînakî, gazî kirina `Pin::new_unchecked` li ser `&'a mut T` ne ewledar e, çimkî dema ku hûn bikaribin wê ji bo jîna diyarkirî `'a` pin bikin, hûn ne xwediyê kontrolê ne ku gelo piştî ku `'a` bidawî bibe ew pîne tê hiştin:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Divê ev were vê wateyê ku pointee `a` carek din nikare bar bike.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Navnîşana `a` li hêlîna stack ``b` guherî, ji ber vê yekê `a` tevgeriyam tevî ku me berê ew pîne kir!Me peymana API-ya pînekirinê binpê kir.
    /////
    /// }
    /// ```
    ///
    /// Nirxek, gava ku hat zincîr kirin, divê her û her bimîne (heya ku celebê wê `Unpin` bicîh neke).
    ///
    /// Bi heman awayî, bangkirina `Pin::new_unchecked` li ser `Rc<T>` ne ewle ye ji ber ku dibe ku navnîşên heman daneyê hebin ku ne bin astengên pînekirinê ne:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Divê ev were vê wateyê ku pointee carek din nikare bar bike.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Naha, heke `x` referansek tenê bû, referansa me ya guhêrbar heye ku daneyên ku me li jor pînekirî, ku em dikarin bikar bînin ku wê veguhezînin wekî ku me di mînaka berê de dîtiye.
    ///     // Me peymana API-ya pînekirinê binpê kir.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Ji vê pêşangeha pînekirî referansa hevpar a pînekirî distîne.
    ///
    /// Ev rêbazek gelemperî ye ku ji `&Pin<Pointer<T>>` diçe `Pin<&T>`.
    /// Ew ewledar e ji ber ku, wekî beşek ji peymana `Pin::new_unchecked`, piştî ku `Pin<Pointer<T>>` hate afirandin, pointee nikare bar bike.
    ///
    /// "Malicious" pêkanînên `Pointer::Deref` jî bi heman awayî ji hêla peymana `Pin::new_unchecked` ve têne derxistin.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SAFETY: li ser vê fonksiyonê belgekirinê bibînin
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Vê `Pin<P>` vedibe nîşana bingehîn vedigerîne.
    ///
    /// # Safety
    ///
    /// Ev fonksiyon ne ewle ye.Pêdivî ye ku hûn garantî bikin ku hûn ê piştî ku hûn ji vê fonksiyonê re bang dikin, xezîneya `P` wekî pinnedekirî derman bikin, da ku neguhêrbariyên li ser celebê `Pin` werin parastin.
    /// Heke koda ku `P` encam bikar tîne berdewam neke domandina invasiyonên pînekirinê ku binpêkirina peymana API ye û dibe ku di operasyonên paşê yên (safe) de bibe sedema reftarek nediyarkirî.
    ///
    ///
    /// Ger daneya bingehîn [`Unpin`] be, divê li şûna [`Pin::into_inner`] were bikar anîn.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Ji vê pêşangeha pînekirî referansa guhêrbar a pînekirî distîne.
    ///
    /// Ev rêgezek gelemperî ye ku ji `&mut Pin<Pointer<T>>` diçe `Pin<&mut T>`.
    /// Ew ewledar e ji ber ku, wekî beşek ji peymana `Pin::new_unchecked`, piştî ku `Pin<Pointer<T>>` hate afirandin, pointee nikare bar bike.
    ///
    /// "Malicious" pêkanînên `Pointer::DerefMut` jî bi heman awayî ji hêla peymana `Pin::new_unchecked` ve têne derxistin.
    ///
    /// Dema ku gelek bang li fonksiyonên ku tîpa pînekirî dixwin ev rêbaza kêrhatî ye.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // tiştekî bike
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` `self` dixwe, ji ber vê yekê bi navgîniya `as_mut` `Pin<&mut Self>` ji nû ve bişewitîne.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SAFETY: li ser vê fonksiyonê belgekirinê bibînin
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Ji bo bîranîna li paş referansa pînek nirxek nû destnîşan dike.
    ///
    /// Ev daneyên pinnedê ji nû ve dinivîse, lê ew baş e: hilweşînerê wê berî ku ji nû ve were nivîsandin bi rêve dibe, ji ber vê yekê garantiya pînekirinê nayê binpê kirin.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Bi nexşeya nirxa hundurîn pîneyek nû çêdike.
    ///
    /// Mînakî, heke we dixwest `Pin`-an zeviyek tiştek bistînin, hûn dikarin vê yekê bikar bînin ku di yek rêzek kodê de bigihîjin wê qadê.
    /// Lêbelê, bi van "pinning projections" re çend gotbaz hene;
    /// ji bo bêtir agahdarî li ser wê mijarê belgeya [`pin` module] bibînin.
    ///
    /// # Safety
    ///
    /// Ev fonksiyon ne ewle ye.
    /// Divê hûn garantî bikin ku daneya ku hûn vedigerin dê tevnegere heya ku nirxa argumanê neçe (mînakî, ji ber ku ew yek ji qadên wê nirxê ye), û her weha ku hûn ji argumana ku hûn bistînin dernekevin fonksiyona hundurîn.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SAFETY: divê peymana ewlehiyê ji bo `new_unchecked` be
        // ji hêla bangker ve tê piştgirî kirin.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Ji pînê referansek hevpar digire.
    ///
    /// Ev ewle ye ji ber ku ne gengaz e ku meriv ji referansa hevpar derkeve.
    /// Ew dikare wusa xuya bike ku li vir pirsgirêkek bi guhêrîna hundurîn heye: bi rastî,* * gengaz e ku meriv `T` ji `&RefCell<T>` derxîne.
    /// Lêbelê, ev ne pirsgirêk e heya ku `Pin<&T>` tune be ku heman daneyê nîşan dike, û `RefCell<T>` nahêle ku hûn ji bo naveroka wê referansek pînekirî biafirînin.
    ///
    /// Ji bo bêtir agahdarî li nîqaşa li ser ["pinning projections"] binêrin.
    ///
    /// Note: `Pin` di heman demê de `Deref` jî dike hedef, ku dikare were bikar anîn da ku bigihîje nirxa hundurîn.
    /// Lêbelê, `Deref` tenê referansek peyda dike ku heya deynê `Pin`, ne jî jiyana `Pin` bixwe, dijî.
    /// Ev rêbaza dihêle ku `Pin` veguhere referansek bi eynî heyatî ya `Pin` ya orjînal.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Vê `Pin<&mut T>` di heman heyatê de veguherîne `Pin<&T>`.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Ji daneyên hundurê vê `Pin` re referansek mutabîl digire.
    ///
    /// Vê yekê hewce dike ku daneya hundurê vê `Pin` `Unpin` be.
    ///
    /// Note: `Pin` di heman demê de `DerefMut` li daneyê, ku dikare were bikar anîn da ku bigihîje nirxa hundurîn.
    /// Lêbelê, `DerefMut` tenê referansek peyda dike ku heya deynê `Pin`, ne jî jiyana `Pin` bixwe, dijî.
    ///
    /// Ev rêbaza dihêle ku `Pin` veguhere referansek bi eynî heyatî ya `Pin` ya orjînal.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Ji daneyên hundurê vê `Pin` re referansek mutabîl digire.
    ///
    /// # Safety
    ///
    /// Ev fonksiyon ne ewle ye.
    /// Pêdivî ye ku hûn garantî bikin ku hûn ê çu carî daneyê ji referansa guhêrbar a ku hûn distînin gava ku hûn vê fonksiyonê bang dikin, bar nekin, da ku neguhêrbariyên li ser celebê `Pin` werin piştrast kirin.
    ///
    ///
    /// Ger daneya bingehîn `Unpin` be, divê li şûna `Pin::get_mut` were bikar anîn.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Bi nexşeya nirxa hundurîn pîneyek nû ava bikin.
    ///
    /// Mînakî, heke we dixwest `Pin`-an zeviyek tiştek bistînin, hûn dikarin vê yekê bikar bînin ku di yek rêzek kodê de bigihîjin wê qadê.
    /// Lêbelê, bi van "pinning projections" re çend gotbaz hene;
    /// ji bo bêtir agahdarî li ser wê mijarê belgeya [`pin` module] bibînin.
    ///
    /// # Safety
    ///
    /// Ev fonksiyon ne ewle ye.
    /// Divê hûn garantî bikin ku daneya ku hûn vedigerin dê tevnegere heya ku nirxa argumanê neçe (mînakî, ji ber ku ew yek ji qadên wê nirxê ye), û her weha ku hûn ji argumana ku hûn bistînin dernekevin fonksiyona hundurîn.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // EWLEH: : bangker berpirsiyar e ku ne bar dike
        // nirx ji vê referansê.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // EWLEH: wekî nirxa `this` garantî ye ku tune
        // hatiye derxistin, ev bang li `new_unchecked` ewle ye.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Ji referansek statîk referansek pînekirî bistînin.
    ///
    /// Ev ewle ye, ji ber ku `T` ji bo jiyana `'static` tête deyn kirin, ku qet xilas nabe.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // EWLEHIYA: 'Deynek statîk garantî dike ku dê dan nebin
        // moved/invalidated heya ku dakeve (ku qet nabe).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Ji referansa guhêrbar a statîk referansa guherbar a pînekirî bistînin.
    ///
    /// Ev ewle ye, ji ber ku `T` ji bo jiyana `'static` tête deyn kirin, ku qet xilas nabe.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // EWLEHIYA: 'Deynek statîk garantî dike ku dê dan nebin
        // moved/invalidated heya ku dakeve (ku qet nabe).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: ev tê vê wateyê ku her impliya `CoerceUnsized` ku destûrê dide zorê ji
// celebek ku `Deref<Target=impl !Unpin>` bi tîpek ku `Deref<Target=Unpin>` nîşan dide bê deng e.
// Lêbelê, dibe ku ji ber sedemên din bêhêvîbûnek wusa bê deng be, ji ber vê yekê em tenê hewce ne ku lênihêrin ku destûr nedin ku implên wusa li std dakevin.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}