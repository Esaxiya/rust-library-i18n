//! Vê modulê `Any` trait bicîh dike, ku bi navgîniya rûtînê ve tîpên dînamîk ên her cûre `'static` dihêle.
//!
//! `Any` bixwe dikare were bikar anîn ku `TypeId` werbigire, û dema ku wekî object trait tê bikar anîn bêtir taybetmendiyên wê hene.
//! Wekî `&dyn Any` (trait-an deyn kirî ye), ew xwediyê rêbazên `is` û `downcast_ref` e, ku biceribîne ka nirxa tê de ji celebek diyarkirî ye, û ji bo nirxa hundirîn wekî celebek bistîne.
//! Wekî `&mut dyn Any`, ji bo stendina referansa guhêrbar a li nirxa hundurîn, rêbaza `downcast_mut` jî heye.
//! `Box<dyn Any>` rêbaza `downcast` zêde dike, ku hewl dide ku veguherîne `Box<T>`.
//! Ji bo agahdariyên tevahî li belgekirina [`Box`] binêrin.
//!
//! Zanibe ku `&dyn Any` bi ceribandinê ve heye ka gelo nirxek ji celebek betonî ya diyarkirî ye, û nayê bikar anîn ku ceribandin ka celebek trait bicîh dike an na.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Pointşaretên zîrek û `dyn Any`
//!
//! Yek perçeyek tevgerê ku divê hûn di hişê xwe de bigirin dema ku `Any` wekî trait bikar tînin, nemaze bi celebên mîna `Box<dyn Any>` an `Arc<dyn Any>`, ew e ku bi tenê gazî kirina `.type_id()` li ser nirxê dê `TypeId`*konteynir*, ne tiştê bingehîn trait hilberîne.
//!
//! Ev bi zivirîna pointerê zîrek di şûna `&dyn Any` de, ku dê `TypeId` ya tiştê vegerîne, dikare jê dûr bikeve.
//! Bo nimûne:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Morehtimal heye ku hûn vê yekê bixwazin:
//! let actual_id = (&*boxed).type_id();
//! // ... ji viya:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Rewşek bifikirin ku em dixwazin nirxek ji fonksiyonek re derbas bûyî derxin.
//! Em nirxa ku em lê dixebitin Debug-ê bicîh dike dizanin, lê em celebê wêya konkret nizanin.Em dixwazin dermankirina taybetî bidin hin celeban: di vê rewşê de çapkirina dirêjahiya nirxên String ên berî nirxa wan.
//! Em di dema berhevokê de celebek berbiçav a nirxa xwe nizanin, ji ber vê yekê hewce ye ku em li şûna wê ramanê ya rûtînê bikar bînin.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Fonksiyona logger ji bo her celebê ku Debugê bicîh tîne.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Biceribînin ku nirxa me veguherînin `String`.
//!     // Ger serketî be, em dixwazin dirêjahiya Rêzeya`` û her weha nirxa wê derxînin.
//!     // Heke ne be, ew celebek cûda ye: tenê wê bê xemilandî çap bikin.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Ev fonksiyon dixwaze berî ku karê pê re bike, parametreya xwe derxe.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... hin karên din bikin
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Her trait
///////////////////////////////////////////////////////////////////////////////

/// trait ku tîpên dînamîk ji xwe re bike mînak.
///
/// Pir celeb `Any` bicîh dikin.Lêbelê, her celebek ku referansek ne-"statîk" tê de tune.
/// Ji bo bêtir agahdarî li [module-level documentation][mod] binêrin.
///
/// [mod]: crate::any
// Ev trait ne ewledar e, her çend em xwe dispêrin taybetmendiyên wê fonksiyona `type_id` ya impl-ê ya yekane di kodek ne ewle de (mînak `downcast`).Bi gelemperî, ew ê bibe pirsgirêkek, lê ji ber ku tenê têgeha `Any` pêkanîna betaniyekê ye, tu kodek din nikare `Any` bicîh bîne.
//
// Em dikarin bi guman vê trait ne ewledar bikin-ew ê nebe sedema şikestinê, ji ber ku em hemî sepandinan kontrol dikin-lê em hildibijêrin ku ew hem ne bi rastî ne hewce ye û hem jî dibe ku bikarhêneran di derheqê cudakirina traits û rêbazên ewledar de tevlihev bikin (ango, `type_id` dê hîn ewle be ku meriv bang bike, lê dibe ku em dixwazin bi vî rengî di belgekirinê de nîşan bikin).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// `TypeId` ya `self` digire.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Rêbazên dirêjkirinê ji bo Tiştikên trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Piştrast bikin ku encama mînak, tevlîbûna têlekek dikare were çap kirin û ji ber vê yekê bi `unwrap` re were bikar anîn.
// Dibe ku heke şandina bi vekişînê re bixebite êdî hewce nake.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// `true` vedigerîne heke celebê qutikê `T` yek be.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Ji celebê vê fonksiyonê `TypeId` bistînin.
        let t = TypeId::of::<T>();

        // Di trait objeya (`self`) de tîpa `TypeId` bistînin.
        let concrete = self.type_id();

        // Li ser wekheviyê her du `TypeId` bidin hev.
        t == concrete
    }

    /// Heke ew ji type `T`, an `None` heke ne be, hin referansan vedigerîne ser hêjayî ya qutikî.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // EWLEH: tenê kontrol kir ka em celebê rast nîşan didin an na, û em dikarin pê bisekinin
            // ew ji bo ewlehiya bîranînê kontrol dikin ji ber ku me ji her cûreyê re Any bicîh kiriye;çu implên din çênabin ku ew ê bi impl me re nakok bin.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Heke ew ji type `T` be, an heke ne `None` be hin referansa guhêrbar vedigerîne ser hêjayî ya qutikî.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // EWLEH: tenê kontrol kir ka em celebê rast nîşan didin an na, û em dikarin pê bisekinin
            // ew ji bo ewlehiya bîranînê kontrol dikin ji ber ku me ji her cûreyê re Any bicîh kiriye;çu implên din çênabin ku ew ê bi impl me re nakok bin.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Pêş de diçe rêbaza ku li ser celebê `Any` hatî diyarkirin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Pêş de diçe rêbaza ku li ser celebê `Any` hatî diyarkirin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Pêş de diçe rêbaza ku li ser celebê `Any` hatî diyarkirin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Pêş de diçe rêbaza ku li ser celebê `Any` hatî diyarkirin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Pêş de diçe rêbaza ku li ser celebê `Any` hatî diyarkirin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Pêş de diçe rêbaza ku li ser celebê `Any` hatî diyarkirin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID û rêbazên wê
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` ji bo celebek nasnameyek bêhempa ya cîhanê temsîl dike.
///
/// Her `TypeId` tiştek nehf e ku destûrê nade venêrana ya ku di hundur de ye lê rê dide operasyonên bingehîn ên wekî klonkirin, berhevdan, çapkirin, û nîşan kirin.
///
///
/// A `TypeId` niha tenê ji bo celebên ku `'static` vedibêjin heye, lê dibe ku ev sînor di future de bê rakirin.
///
/// Dema ku `TypeId` `Hash`, `PartialOrd`, û `Ord` bicîh tîne, hêjayê gotinê ye ku heş û rêkûpêk dê di navbera weşanên Rust de cûda bibe.
/// Hay ji we hebe ku hûn di hundurê koda xwe de xwe bisipêrin wan!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// `TypeId` ji celebê vegerîne ku vê fonksiyona giştî bi vî rengî hatiye nîşankirin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Navê celebek wekî perçeyek têl vedigerîne.
///
/// # Note
///
/// Ev ji bo karanîna teşhîsê ye.
/// Naverok û teşeya rastîn a têla vegeriyayî ne diyar e, ji xeynî ku ew şirovekirina celeb-çêtirîn e.
/// Mînakî, di nav têlên ku dibe ku `type_name::<Option<String>>()` vegere `"Option<String>"` û `"std::option::Option<std::string::String>"` ne.
///
///
/// Divê rêzika vegeriyayî wekî nasnameyek yekta ya celebek neyê hesibandin ji ber ku gelek celeb dikarin nexşeya heman navî bin.
/// Bi heman rengî, garantî tune ku dê hemî beşên celebek di rêza vegeriyayî de xuya bikin: mînakî, diyarkerên jiyanê niha ne tê de ne.
/// Wekî din, dibe ku encam di navbera guhertoyên berhevkar de biguhere.
///
/// Bicîhkirina heyî heman binesaziyê wekî teşhîs û berhevkirina berhevkar bikar tîne, lê ev nayê garantîkirin.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Navê celebê nirxê nîşankirî wekî perçeyek têl vedigerîne.
/// Ev heman `type_name::<T>()` e, lê li ku celebê guhêrbar bi hêsanî peyda nabe tê bikar anîn.
///
/// # Note
///
/// Ev ji bo karanîna teşhîsê ye.Naverok û teşeya rastîn a têlê ne diyar e, ji xeynî ku ew şirovekirina celeb-çêtirîn e.
/// Mînakî, `type_name_of_val::<Option<String>>(None)` dikare `"Option<String>"` an `"std::option::Option<std::string::String>"` vegerîne, lê ne `"foobar"`.
///
/// Wekî din, dibe ku encam di navbera guhertoyên berhevkar de biguhere.
///
/// Vê fonksiyonê tiştên trait çareser nake, tê wateya ku `type_name_of_val(&7u32 as &dyn Debug)` dikare `"dyn Debug"` vegerîne, lê `"u32"` venagerîne.
///
/// Pêdivî ye ku navê celeb wekî nasnameyek yekta ya celebek neyê hesibandin;
/// cûrbecûr cûrbecûr dibe ku navê yek tîpî hebe.
///
/// Bicîhkirina heyî heman binesaziyê wekî teşhîs û berhevkirina berhevkar bikar tîne, lê ev nayê garantîkirin.
///
/// # Examples
///
/// Celebên jimare û float ên pêşdibistanê çap dike.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}