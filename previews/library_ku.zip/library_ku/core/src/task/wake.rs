#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// A `RawWaker` dihêle ku bicîhkerê karanînek peywirê [`Waker`] biafirîne ku tevgera şiyarbûnê ya xwerû peyda dike.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Ew ji nîşanderê daneyê û [virtual function pointer table (vtable)][vtable]-ê ku tevgera `RawWaker`-ê xwerû dike, pêk tê.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Nîşanek danûstendinê, ku dikare ji bo tomarkirina daneyên keyfî ku ji hêla îcrakar ve hewce dike were bikar anîn.
    /// Ev dikare bibe mînak
    /// pêşnumayek type-jêbirin a `Arc`-ê ku bi peywirê re têkildar e.
    /// Nirxa vê qadê ji hemî fonksiyonên ku wekî pîvana yekem in vtable ne re derbas dibe.
    ///
    data: *const (),
    /// Fonksiyona rastîn maseya nîşangirê ku tevgera vê şiyarbûnê xwerû dike.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Ji nîşangirê `data` û `vtable` ve `RawWaker` nû diafirîne.
    ///
    /// Xoşnav `data` dikare ji bo tomarkirina daneyên keyfî ku ji hêla tetbîqker ve hewce dike were bikar anîn.Ev dikare bibe mînak
    /// pêşnumayek type-jêbirin a `Arc`-ê ku bi peywirê re têkildar e.
    /// Nirxa vê pointerê dê ji hemî fonksiyonên ku perçeyek `vtable`-ê ne wekî pîvana yekem re derbas bibe.
    ///
    /// `vtable` tevgera `Waker`-ya ku ji `RawWaker`-ê tê afirandin çêdike.
    /// Ji bo her operasyona li ser `Waker`, dê fonksiyona têkildar di `vtable` ya `RawWaker` ya bingehîn de bê gotin.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Fonksiyonek fonksiyonek sifrê (vtable) ya nîşanker ku tevgera [`RawWaker`] diyar dike.
///
/// Nîşankerê ku ji hemî fonksiyonên di hundurê vtable re derbas dibe nîşanderê `data` ye ji objeya [`RawWaker`] ya dorpêçkirî ye.
///
/// Fonksiyonên di hundurê vê sazûmanê de tenê armanc dikin ku ji navnîşa X001X ya ji hundurê pêkanîna [`RawWaker`] ve li pointer `data` ya tiştê [`RawWaker`] bi rêkûpêk hatî çêkirin bête gazîkirin.
/// Gazîkirina yek ji fonksiyonên tê de bi karanîna nîşanderê `data` yê din dê bibe sedema reftara nediyarkirî.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Dema ku [`RawWaker`] tê klon kirin, ji bo nimûne dema ku [`Waker`] ya ku [`RawWaker`] tê de hatî tomarkirin tê klon kirin ji vê fonksiyonê re tê gotin.
    ///
    /// Pêkanîna vê fonksiyonê divê hemî çavkaniyên ku ji bo vê nimûneya pêvek a [`RawWaker`] û peywireke têkildar hewce ne, ragire.
    /// Bangkirina `wake` li ser [`RawWaker`] encam divê di şiyarbûna heman karî de be ku dê ji hêla [`RawWaker`] ya orjînal ve şiyar bibûya.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Dema ku `wake` li [`Waker`] were bang kirin dê ji vê fonksiyonê re bê gotin.
    /// Divê ew peywira ku bi vê [`RawWaker`] ve girêdayî ye şiyar bibe.
    ///
    /// Pêkanîna vê fonksiyonê divê piştrast bike ku çavkaniyên ku bi vê nimûneya [`RawWaker`] û peywireke têkildar re têkildar in serbest berde.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Dema ku `wake_by_ref` li [`Waker`] were bang kirin dê ji vê fonksiyonê re bê gotin.
    /// Divê ew peywira ku bi vê [`RawWaker`] ve girêdayî ye şiyar bibe.
    ///
    /// Ev fonksiyon dişibe `wake` e, lê pêdivî ye ku nîşana daneya pêşkêşkirî nexwe.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Dema ku [`RawWaker`] daket ev fonksiyon tê bang kirin.
    ///
    /// Pêkanîna vê fonksiyonê divê piştrast bike ku çavkaniyên ku bi vê nimûneya [`RawWaker`] û peywireke têkildar re têkildar in serbest berde.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Ji fonksiyonên `clone`, `wake`, `wake_by_ref`, û `drop` yên peydakirî `RawWakerVTable` nû diafirîne.
    ///
    /// # `clone`
    ///
    /// Dema ku [`RawWaker`] tê klon kirin, ji bo nimûne dema ku [`Waker`] ya ku [`RawWaker`] tê de hatî tomarkirin tê klon kirin ji vê fonksiyonê re tê gotin.
    ///
    /// Pêkanîna vê fonksiyonê divê hemî çavkaniyên ku ji bo vê nimûneya pêvek a [`RawWaker`] û peywireke têkildar hewce ne, ragire.
    /// Bangkirina `wake` li ser [`RawWaker`] encam divê di şiyarbûna heman karî de be ku dê ji hêla [`RawWaker`] ya orjînal ve şiyar bibûya.
    ///
    /// # `wake`
    ///
    /// Dema ku `wake` li [`Waker`] were bang kirin dê ji vê fonksiyonê re bê gotin.
    /// Divê ew peywira ku bi vê [`RawWaker`] ve girêdayî ye şiyar bibe.
    ///
    /// Pêkanîna vê fonksiyonê divê piştrast bike ku çavkaniyên ku bi vê nimûneya [`RawWaker`] û peywireke têkildar re têkildar in serbest berde.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Dema ku `wake_by_ref` li [`Waker`] were bang kirin dê ji vê fonksiyonê re bê gotin.
    /// Divê ew peywira ku bi vê [`RawWaker`] ve girêdayî ye şiyar bibe.
    ///
    /// Ev fonksiyon dişibe `wake` e, lê pêdivî ye ku nîşana daneya pêşkêşkirî nexwe.
    ///
    /// # `drop`
    ///
    /// Dema ku [`RawWaker`] daket ev fonksiyon tê bang kirin.
    ///
    /// Pêkanîna vê fonksiyonê divê piştrast bike ku çavkaniyên ku bi vê nimûneya [`RawWaker`] û peywireke têkildar re têkildar in serbest berde.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// `Context` wezîfeyek asinkron.
///
/// Vêga, `Context` tenê xizmetê dike ku bigihîje `&Waker` ku dikare ji bo şiyarkirina karê heyî were bikar anîn.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Bawer bikin ku em future-delîl li dijî guhertinên variance bi darê zorê di jiyanê de neguhêrbar in (jiyanên nîqaş-pozîsyon berevajî ne dema ku jiyanên vegera-pozîsyon hevgirtî ne).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Ji `&Waker`-ya `Context`-ya nû çêbikin.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Ji bo karê heyî referansek li `Waker` vedigerîne.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` ji bo şiyarbûna wezîfeyek e ku bi agahdar kirina serwerê xwe ku ew amade ye ku were meşandin.
///
/// Ev destan mînakek [`RawWaker`] vedigire, ku tevgera şiyarbûna-îcrakar-taybetî diyar dike.
///
///
/// [`Clone`], [`Send`], û [`Sync`] bicîh tîne.
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Karê ku bi vê `Waker` ve girêdayî ye şiyar bibin.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Banga şiyarbûnê ya rastîn bi riya bangek fonksiyona virtual ji bo pêkanîna ku ji hêla darveker ve tê vegotin ve tê vegerandin.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // `drop` nexwendin-şûşe dê ji hêla `wake` ve were xerckirin.
        crate::mem::forget(self);

        // BELAW: Ev ewledar e ji ber ku `Waker::from_raw` awayê tenê ye
        // ji bo destpêkirina `wake` û `data` pêdivî ye ku bikarhêner bipejirîne ku peymana `RawWaker` tête parastin.
        //
        unsafe { (wake)(data) };
    }

    /// Karê ku bi vê `Waker` ve girêdayî ye bêyî ku `Waker` bikişîne şiyar bibin.
    ///
    /// Ev dişibe `wake` e, lê dibe ku di rewşa ku xwediyê `Waker` heye de hinekî kêmtir karîger be.
    /// Pêdivî ye ku ev rêbaz ji bangkirina `waker.clone().wake()` re were tercîh kirin.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Banga şiyarbûnê ya rastîn bi riya bangek fonksiyona virtual ji bo pêkanîna ku ji hêla darveker ve tê vegotin ve tê vegerandin.
        //

        // BELA: `wake` binihêrin
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// `true` vedigerîne heke vê `Waker` û `Waker` din heman peywir şiyar kiribe.
    ///
    /// Ev fonksiyon li ser bingehek çêtirîn-xebitîn dixebite, û dibe ku derewîn jî vegere dema ku `Waker` ê heman peywirê hişyar bike.
    /// Lêbelê, heke ev fonksiyon `true` vegerîne, ew garantî ye ku `Waker` dê heman peywirê şiyar bike.
    ///
    /// Ev fonksiyon di serî de ji bo armancên optimîzasyonê tê bikar anîn.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Ji [`RawWaker`] `Waker`-ya nû diafirîne.
    ///
    /// Ger peymana ku di belgeya ["RawWaker"] û ["RawWakerVTable"] de hatî diyarkirin neyê pejirandin tevgera `Waker` ya hatî vegerandin nayê diyar kirin.
    ///
    /// Ji ber vê yekê ev rêbaz ne ewle ye.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // BELAW: Ev ewledar e ji ber ku `Waker::from_raw` awayê tenê ye
            // ji bo destpêkirina `clone` û `data` pêdivî ye ku bikarhêner bipejirîne ku peymana [`RawWaker`] tête parastin.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // BELAW: Ev ewledar e ji ber ku `Waker::from_raw` awayê tenê ye
        // ji bo destpêkirina `drop` û `data` pêdivî ye ku bikarhêner bipejirîne ku peymana `RawWaker` tête parastin.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}