use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Cûreyek pêlavê ku ji bo x00X nimûneyên uninitialized ava bike.
///
/// # Destpêka destpêkirinê
///
/// Berhevkar, bi gelemperî, ferz dike ku guhêrbar li gorî pêdiviyên celebê guhêrbar bi rêkûpêk dest pê dike.Mînakî, pêdivî ye ku guhêrbariyek ji celebê referansê lihevkirî û ne-NULL be.
/// Ev neguhêrbar e ku divê *hertim* were piştguh kirin, tewra di koda ewlehiyê de jî.
/// Wekî encamek, sifir-destpêkirina guherbarek ji celebê referansê dibe sedema [undefined behavior][ub] tavilê, ne girîng e gelo ew referans carî tête bikar anîn ku bigihîje bîrayê:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // tevgera nediyarkirî!⚠️
/// // Koda wekhev a bi `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // tevgera nediyarkirî!⚠️
/// ```
///
/// Ev ji hêla berhevkar ve ji bo xweşbîniyên cûrbecûr, wekî veneşartina kontrolên dema run-ê û optimîzasyona dîmenderiya `enum` ve tête bikar anîn.
///
/// Bi heman rengî, dibe ku bîranîna bi tevahî uninitialized xwediyê naverok be, dema ku `bool` divê her dem `true` an `false` be.Ji ber vê yekê, afirandina `bool` uninitialized tevgerek ne diyar e:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // tevgera nediyarkirî!⚠️
/// // Koda wekhev a bi `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // tevgera nediyarkirî!⚠️
/// ```
///
/// Wekî din, bîra uninitialized taybetî ye ku ew nirxek sabît tune ("fixed" wateya "it won't change without being written to").Pir caran xwendina heman byte-ya uninitialized dikare encamên cûda bide.
/// Ev dike tevgerek nediyarkirî ku di guhêrbar de daneyên uninitialized hebin heke ew guhêrbar celebek jimare hebe, ku wekî din dikare her nimûneyek *sabît* bit bigire:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // tevgera nediyarkirî!⚠️
/// // Koda wekhev a bi `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // tevgera nediyarkirî!⚠️
/// ```
/// (Bala xwe bidinê ku qaîdeyên li dora jimareyên uninitialized hêj neqediyaye, lê heta ku ew nebin, tê pêşniyar kirin ku ji wan dûr bisekinin.)
///
/// Li ser vê yekê, ji bîr mekin ku ji pir tîpan re ji bilî ku tenê di asta tîpê de hatine destnîşankirin de gelek binavên din hene.
/// Ji bo nimûne, [`Vec<T>`]-a-destpêkirî tête hesibandin destpêkirin (di binê sepandina heyî de; ev garantiyek stabîl nîn e) ji ber ku tenê pêdiviya berhevkar di derheqê wê de ew e ku pêşnumara daneyê divê ne-pûç be.
/// Afirandina `Vec<T>` ya wusa nabe sedema tevgera *yekser* ya nediyarkirî, lê dê bi tevgerên herî ewledar re bibe sedema reftara nediyarkirî (daketina wê jî).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` xizmetê dike ku koda ne ewle çalak bike da ku bi daneyên uninitialized re têkildar be.
/// Ew îşaretek e ji berhevkar re ku diyar dike ku daneyên li vir dibe ku *ne* werin destpêkirin:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Çavkaniyek eşkere uninitialized biafirînin.
/// // Berhevkar dizane ku dibe ku daneyên di hundurê `MaybeUninit<T>` de nederbasdar be, û ji ber vê yekê ev ne UB ye:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Wê li ser nirxek derbasdar saz bikin.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Daneyên destpêkî derxînin-ev tenê *piştî* bi rêkûpêk destpêkirina `x` destûr heye!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Wê hingê berhevkar dizane ku li ser vê kodê tu texmîn an optimîzasyonên çewt nake.
///
/// Hûn dikarin `MaybeUninit<T>` wekî hinekî mîna `Option<T>` bifikirin lê bêyî ku yek ji şopandina dema run-ê hebe û bêyî ti kontrolên ewlehiyê.
///
/// ## out-pointers
///
/// Hûn dikarin `MaybeUninit<T>` bikar bînin da ku "out-pointers" bicîh bînin: li şûna ku daneyên ji fonksiyonekê vegerînin, wê pêşekek bi hin bîra (uninitialized) re derbas bikin da ku encamê têxe nav.
/// Ev dikare kêrhatî be dema ku ji bangdêr re girîng e ku kontrol bike ka bîranîn encama ku tê de hatî hilanîn tê veqetandin, û hûn dixwazin ji tevgerên nehewce dûr bisekinin.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` naveroka kevn davêje, ku girîng e.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Naha em dizanin `v` destpêkirî ye!Ev jî piştrast dike ku vector bi rêkûpêk dikeve.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Destpêkkirina hêmanek-ê-hêmanek array
///
/// `MaybeUninit<T>` dikare were bikar anîn ji bo destpêkirina hêmanek-hêmanek rêzeyek mezin:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Rêzeyek uninitialized ya `MaybeUninit` biafirînin.
///     // `assume_init` ewledar e ji ber ku tîpa ku em îdîa dikin ku me li vir destpêkiriye komek `MaybeUninit` e, ku destpêkirin hewce nake.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Daketin `MaybeUninit` tiştek nake.
///     // Ji ber vê yekê li şûna `ptr::write` bikar anîna nîşana raweyê nahêle ku nirxa kevn a uninitialized were avêtin.
/////
///     // Her weha heke di dema vê xelekê de panic hebe, leza bîra me heye, lê pirsgirêka ewlehiya bîranînê tune.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Her tişt destpêkirî ye.
///     // Array bi celebê destpêkirî veguherîne.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Di heman demê de hûn dikarin bi rêzikên destpêkî yên qismî ve, yên ku dikarin di danezana avahiyên nizm de werin dîtin, bixebitin.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Rêzeyek uninitialized ya `MaybeUninit` biafirînin.
/// // `assume_init` ewledar e ji ber ku tîpa ku em îdîa dikin ku me li vir destpêkiriye komek `MaybeUninit` e, ku destpêkirin hewce nake.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Hejmara hêmanên ku me destnîşan kirine bijmêrin.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Ji bo her tiştê di rêzê de, heke me ew veqetandî bavêje.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Destpêkirina zeviyek bi zevî ya damezirandin
///
/// Hûn dikarin `MaybeUninit<T>`, û makroya [`std::ptr::addr_of_mut`] bikar bînin, da ku zeviyan bi zeviyê bidin destpêkirin:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Destpêkirina qada `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Destpêkirina qada `list` Ger li vir panic hebe, wê hingê `String` di qada `name` de diherike.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Hemî zevî têne destpêkirin, ji ber vê yekê em ji `assume_init` re dibêjin ku Foo-ya destpêkî bistînin.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` misogerkirî ye ku xwedan eynî mezinahî, hevrêzî û ABI wek `T` be:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Lêbelê ji bîr mekin ku celebek *ku*`MaybeUninit<T>` tê de ne pêdivî ye ku heman pêvek be;Rust bi gelemperî garantî nake ku zeviyên `Foo<T>` heman rêzê wekî `Foo<U>` hebin heke `T` û `U` xwedan heman pîvandin û rêzkirinê bin.
///
/// Wekî din ji ber ku her nirxek bit ji bo `MaybeUninit<T>` derbasdar e, berhevkar nikare optimîzasyonên non-zero/niche-filling bi kar bîne, dibe ku di mezinahiyek mezintir de encam bide:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Ger `T` FFI-ewleh be, wê hingê `MaybeUninit<T>` jî ew e.
///
/// Gava ku `MaybeUninit` `#[repr(transparent)]` e (nîşan dide ku ew mîqdara hevgirtin, lihevnêzîkbûn û ABI-ya wekî `T` garantî dike), ev * yek ji pêşnumayên berê naguherîne.
/// `Option<T>` û `Option<MaybeUninit<T>>` dibe ku hîn xwedan mezinahiyên cûda bin, û celebên ku zeviyek ji celebê `T` vedigire dikarin ji bilî ku ew zevî `MaybeUninit<T>` be cuda werin danîn (û mezinahî).
/// `MaybeUninit` celebek yekîtiyê ye, û `#[repr(transparent)]` li ser sendîkayan nearam e (binihêrin [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Bi demê re, dibe ku temînatên rastîn ên `#[repr(transparent)]` li ser sendîkayan pêş bikevin, û `MaybeUninit` dikare `#[repr(transparent)]` bimîne an jî nemîne.
/// Wê got, `MaybeUninit<T>` dê *her gav* garantî bike ku ew xwedan eynî mezinahî, rêzkirin û ABI-ya `T` e;tenê ev e ku awayê bicîhkirina `MaybeUninit` ku garantî dibe pêşve diçe.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Tiştika lang da ku em bikaribin celebên din jî tê de pêça.Ev ji bo hilberîneran bikêr e.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Gazî `T::clone()` nakin, em nikarin bizanin ka ji bo wê têra xwe destpêkirine.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Bi nirxa dayîn ve `MaybeUninit<T>` nû ya destpêkirî diafirîne.
    /// Ew ewledar e ku meriv li ser nirxa vegera vê fonksiyonê bangî [`assume_init`] bike.
    ///
    /// Bala xwe bidinê ku daketina `MaybeUninit<T>` dê carî bangî kodê davêjin `T` neke.
    /// Ew berpirsiyariya we ye ku hûn bihêlin bila `T` dest pê bike eger ew destpêkirî be.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Di dewletek nezanî de `MaybeUninit<T>` nû diafirîne.
    ///
    /// Bala xwe bidinê ku daketina `MaybeUninit<T>` dê carî bangî kodê davêjin `T` neke.
    /// Ew berpirsiyariya we ye ku hûn bihêlin bila `T` dest pê bike eger ew destpêkirî be.
    ///
    /// Ji bo hin mînakan li [type-level documentation][MaybeUninit] binêrin.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Di dewletek nezanî de rêzeyek nû ya hêmanên `MaybeUninit<T>` biafirînin.
    ///
    /// Note: di guhertoyek future Rust de dema ku hevoksaziya rasterast arayetê destûrê dide [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) dibe ku ev rêbaz ne pêdivî be.
    ///
    /// Mînaka li jêr wê hingê dikare `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` bikar bîne.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Pûçek daneya ku dibe ku hatibe xwendin vedigerîne (dibe ku piçûktir be)
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // EWLEH: : `[MaybeUninit<_>; LEN]` uninitialized derbasdar e.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Di bîranîna ku bi `0` byte tê dagirtin de, di rewşek nezanî de `MaybeUninit<T>` nû diafirîne.Ew bi `T` ve girêdayî ye gelo ew jixwe ji bo destpêkirina guncan çêdike an na.
    ///
    /// Mînakî, `MaybeUninit<usize>::zeroed()` destpêkirî ye, lê `MaybeUninit<&'static i32>::zeroed()` ne ji ber ku divê çavkanî pûç nebin.
    ///
    /// Bala xwe bidinê ku daketina `MaybeUninit<T>` dê carî bangî kodê davêjin `T` neke.
    /// Ew berpirsiyariya we ye ku hûn bihêlin bila `T` dest pê bike eger ew destpêkirî be.
    ///
    /// # Example
    ///
    /// Bikaranîna rast a vê fonksiyonê: destpêkirina sazûmanek bi sifir, ku hemû zeviyên sazkirinê dikarin nimreya bit-ê 0 wekî nirxek derbasdar bigirin.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Nerast* karanîna vê fonksiyonê: bangkirina `x.zeroed().assume_init()` dema `0` ji bo celebê nexşeyek bit derbasdar e:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Di hundurê cotek de, em `NotZero` diafirînin ku cûdaxwazek wê ya derbasdar tune.
    /// // Ev tevgerek ne diyar e.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // EWLEH: : `u.as_mut_ptr()` xalên bîranîna veqetandî.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Nirxa `MaybeUninit<T>` saz dike.
    /// Vê nirxê berê bêyî avêtin ji nû de dinivîse, ji ber vê yekê hişyar bimînin ku hûn vê yekê du carî bikar neynin heya ku hûn nexwazin ku destûra hilweşîner derbas bikin.
    ///
    /// Ji bo rehetiya we, ev jî referansa guhêrbar vedigerîne naveroka (aniha bi ewlehî destpêkirî) ya `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // EWLEH: Me tenê vê nirxê destnîşan kir.
        unsafe { self.assume_init_mut() }
    }

    /// Nîşanek bi nirxê vegirtî re digire.
    /// Xwendina ji vê pointerê an zivirandina wê wekî referansek heya ku `MaybeUninit<T>` neyê destpêkirin tevgerek ne diyar e.
    /// Nivîsandina ji bîra ku ev nîşangir (non-transitively) nîşan dide tevgerek ne diyar e (ji xeynî hundurê `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Bikaranîna rast a vê rêbazê:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Di `MaybeUninit<T>` de referansek çêbikin.Ev baş e ji ber ku me ew destpêkir.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Bikaranîna çewt* vê rêbazê:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Me referansek li ser vector ya uninitialized çêkir!Ev tevgerek ne diyar e.⚠️
    /// ```
    ///
    /// (Bala xwe bidinê ku qaîdeyên dora referansên daneyên nezanin hîn nehatine qedandin, lê heta ku ew nebin, tê pêşniyar kirin ku ji wan dûr bisekinin.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` û `ManuallyDrop` her du jî `repr(transparent)` in ji ber vê yekê em dikarin pointerê bavêjin.
        self as *const _ as *const T
    }

    /// Nîşanek guhêrbar digire ser nirxa vehewandî.
    /// Xwendina ji vê pointerê an zivirandina wê wekî referansek heya ku `MaybeUninit<T>` neyê destpêkirin tevgerek ne diyar e.
    ///
    /// # Examples
    ///
    /// Bikaranîna rast a vê rêbazê:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Di `MaybeUninit<Vec<u32>>` de referansek çêbikin.
    /// // Ev baş e ji ber ku me ew destpê kir.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Bikaranîna çewt* vê rêbazê:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Me referansek li ser vector ya uninitialized çêkir!Ev tevgerek ne diyar e.⚠️
    /// ```
    ///
    /// (Bala xwe bidinê ku qaîdeyên dora referansên daneyên nezanin hîn nehatine qedandin, lê heta ku ew nebin, tê pêşniyar kirin ku ji wan dûr bisekinin.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` û `ManuallyDrop` her du jî `repr(transparent)` in ji ber vê yekê em dikarin pointerê bavêjin.
        self as *mut _ as *mut T
    }

    /// Nirxê ji konteynera `MaybeUninit<T>` derdixe.Ev rêgezek girîng e ku piştrast bike ku dê daneyên dakêşin, ji ber ku `T`-ê encam bi karanîna dakêşanê ya gelemperî ve girêdayî ye.
    ///
    /// # Safety
    ///
    /// Bi vexwendinê ve girêdayî ye ku garantî bike ku `MaybeUninit<T>` bi rastî di rewşek destpêkî de ye.Bangkirina viya dema ku naverok hîn bi tevahî neyê destpêkirin dibe sedema tevgera tavilê nediyarkirî.
    /// [type-level documentation][inv] di derbarê vê neguhêrîna destpêkirinê de bêtir agahdarî hene.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Li ser vê yekê, ji bîr mekin ku ji pir tîpan re ji bilî ku tenê di asta tîpê de hatine destnîşankirin de gelek binavên din hene.
    /// Ji bo nimûne, [`Vec<T>`]-a-destpêkirî tête hesibandin destpêkirin (di binê sepandina heyî de; ev garantiyek stabîl nîn e) ji ber ku tenê pêdiviya berhevkar di derheqê wê de ew e ku pêşnumara daneyê divê ne-pûç be.
    ///
    /// Afirandina `Vec<T>` ya wusa nabe sedema tevgera *yekser* ya nediyarkirî, lê dê bi tevgerên herî ewledar re bibe sedema reftara nediyarkirî (daketina wê jî).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Bikaranîna rast a vê rêbazê:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Bikaranîna çewt* vê rêbazê:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` hêj nehatibû destpêkirin, ji ber vê yekê ev xeta paşîn bû sedema reftarek nediyarkirî.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // EWLEHIY: : Divê bangker garantî bike ku `self` destpêkirî ye.
        // Ev jî tê vê wateyê ku divê `self` cûrbecûr `value` be.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Nirxê ji konteynir `MaybeUninit<T>` dixwîne.Di encama `T` de bi karanîna dilopa adetî ve girêdayî ye.
    ///
    /// Kengê ku gengaz be, çêtir e ku meriv li şûna wê [`assume_init`] bikar bîne, ku pêşî li dubarekirina naveroka `MaybeUninit<T>` digire.
    ///
    /// # Safety
    ///
    /// Bi vexwendinê ve girêdayî ye ku garantî bike ku `MaybeUninit<T>` bi rastî di rewşek destpêkî de ye.Bangkirina viya dema ku naverok hîn bi tevahî neyê destpêkirin dibe sedema reftarek nediyarkirî.
    /// [type-level documentation][inv] di derbarê vê neguhêrîna destpêkirinê de bêtir agahdarî hene.
    ///
    /// Wekî din, ev kopiyek heman daneyê li paş `MaybeUninit<T>` dihêle.
    /// Dema ku gelek nusxeyên daneyê bikar tînin (bi bangkirina gelek caran `assume_init_read`, an yekem bangkirina `assume_init_read` û dûv re jî [`assume_init`]), berpirsiyariya we ye ku hûn piştrast bikin ku ew dane bi rastî ducar dibin.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Bikaranîna rast a vê rêbazê:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` `Copy` e, ji ber vê yekê em dikarin gelek caran bixwînin.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Duplickirina nirxek `None` baş e, ji ber vê yekê em dikarin gelek caran bixwînin.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Bikaranîna çewt* vê rêbazê:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Naha me du kopiyên heman vector-ê çêkir, ber bi du qat-azad ve dema ku ew her du jî daketin!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // EWLEHIY: : Divê bangker garantî bike ku `self` destpêkirî ye.
        // Ji `self.as_ptr()` xwendin ewle ye ji ber ku divê `self` were destpêkirin.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Nirxa tê de di cîh de davêje.
    ///
    /// Ger xwedaniya `MaybeUninit` hebe, hûn dikarin li şûna wê [`assume_init`] bikar bînin.
    ///
    /// # Safety
    ///
    /// Bi vexwendinê ve girêdayî ye ku garantî bike ku `MaybeUninit<T>` bi rastî di rewşek destpêkî de ye.Bangkirina viya dema ku naverok hîn bi tevahî neyê destpêkirin dibe sedema reftarek nediyarkirî.
    ///
    /// Li ser vê yekê, hemî nexşeyên din ên celebê `T` divê razî bin, ji ber ku pêkanîna `Drop` ya `T` (an endamên wê) dibe ku xwe dispêrin vê.
    /// Ji bo nimûne, [`Vec<T>`]-a-destpêkirî tête hesibandin destpêkirin (di binê sepandina heyî de; ev garantiyek stabîl nîn e) ji ber ku tenê pêdiviya berhevkar di derheqê wê de ew e ku pêşnumara daneyê divê ne-pûç be.
    ///
    /// Daketina `Vec<T>` ya wusa dê bibe sedema reftarek nediyarkirî.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // EWLEHIY: : divê bangker garantî bike ku `self` destpêkirî ye û
        // hemî nehfên `T` têr dike.
        // Heke wilo be daketina nirxê di cîh de ewle ye.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Li ser nirxa vegirtî referansek hevpar digire.
    ///
    /// Dema ku em dixwazin bigihîjin `MaybeUninit`-ê ku hatî destpêkirin lê xwediyê `MaybeUninit`-ê tune (pêşî li karanîna `.assume_init()`) digire) ev dikare bikêr be.
    ///
    /// # Safety
    ///
    /// Bangkirina viya dema ku naverok hîn bi tevahî nehatiye destpêkirin dibe sedema reftara nediyarkirî: ew ê gazî bike ku garantî bike ku `MaybeUninit<T>` bi rastî di rewşek destpêkî de ye.
    ///
    ///
    /// # Examples
    ///
    /// ### Bikaranîna rast a vê rêbazê:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // `x` destpê bikin:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Naha ku tê zanîn ku `MaybeUninit<_>` me destpêkiriye, baş e ku meriv jê re referansek hevpar biafirîne:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // EWLEH: : `x` hate destpêkirin.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Bikaranînên* çewt ên vê rêbazê:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Me referansek li ser vector ya uninitialized çêkir!Ev tevgerek ne diyar e.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // `MaybeUninit` bi karanîna `Cell::set` destpê bikin:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Çavkanî ji bo `Cell<bool>` uninitialized: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // EWLEHIY: : Divê bangker garantî bike ku `self` destpêkirî ye.
        // Ev jî tê vê wateyê ku divê `self` cûrbecûr `value` be.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Bi nirxa vegirtî re referansa (unique) ya mutable digire.
    ///
    /// Dema ku em dixwazin bigihîjin `MaybeUninit`-ê ku hatî destpêkirin lê xwediyê `MaybeUninit`-ê tune (pêşî li karanîna `.assume_init()`) digire) ev dikare bikêr be.
    ///
    /// # Safety
    ///
    /// Bangkirina viya dema ku naverok hîn bi tevahî nehatiye destpêkirin dibe sedema reftara nediyarkirî: ew ê gazî bike ku garantî bike ku `MaybeUninit<T>` bi rastî di rewşek destpêkî de ye.
    /// Mînakî, `.assume_init_mut()` ji bo destpêkirina `MaybeUninit` nayê bikar anîn.
    ///
    /// # Examples
    ///
    /// ### Bikaranîna rast a vê rêbazê:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// *Hemî* baytên tampona têketinê destnîşan dike.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // `buf` destpê bikin:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Naha em dizanin ku `buf` hatiye destpêkirin, ji ber vê yekê em dikarin wê `.assume_init()` bikin.
    /// // Lêbelê, karanîna `.assume_init()` dibe ku `memcpy` ya 2048 byte derxîne.
    /// // Ji bo ku tampona me bêyî ku wê were kopî kirin destpêkiriye, em `&mut MaybeUninit<[u8; 2048]>` bi `&mut [u8; 2048]` nûve dikin:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // EWLEH: : `buf` hate destpêkirin.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Naha em dikarin `buf`-ê wekî perçek normal bikar bînin:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Bikaranînên* çewt ên vê rêbazê:
    ///
    /// Hûn nikarin `.assume_init_mut()` bikar bînin da ku nirxek destnîşan bikin:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Me ji `bool`-a nezanî re referansek (mutable) çêkir!
    ///     // Ev tevgerek ne diyar e.⚠️
    /// }
    /// ```
    ///
    /// Mînakî, hûn nekarin [`Read`] têxin tamponek uninitialized:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) referans ji bîra uninitialized!
    ///                             // Ev tevgerek ne diyar e.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Ne jî hûn dikarin têkevin qada rasterast bikar bînin ku destpêkirina gav bi gav a zevî-zevî bikin:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) referans ji bîra uninitialized!
    ///                  // Ev tevgerek ne diyar e.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) referans ji bîra uninitialized!
    ///                  // Ev tevgerek ne diyar e.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Em naha xwe dispêrin jorîn a çewt, ango, referansên me hene li daneyên uninitialized (mînakî, li `libcore/fmt/float.rs`).
    // Pêdivî ye ku em berî stabîlîzasyonê di derbarê qaîdeyan de biryara dawîn bidin.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // EWLEHIY: : Divê bangker garantî bike ku `self` destpêkirî ye.
        // Ev jî tê vê wateyê ku divê `self` cûrbecûr `value` be.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Nirxan ji rêzeyek konteynerên `MaybeUninit` derdixe.
    ///
    /// # Safety
    ///
    /// Ew ji hêla bangker ve ye ku garantî bike ku hemî hêmanên array di rewşek destpêkî de ne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // EWLET: Naha ewledar e ku me hemî hêman destnîşan kir
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Bangker garantî dike ku hemî hêmanên array têne destpêkirin
        // * `MaybeUninit<T>` û T têne garantî kirin ku xwedan heman şêwekariyê ne
        // * MaybeUnint nakeve, ji ber vê yekê du-belaş tune And bi vî rengî veguherîn ewle ye
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Bihesibînin ku hemî hêman têne destpêkirin, qurmek ji wan re bigirin.
    ///
    /// # Safety
    ///
    /// Ew bi bangawazî re ye ku garantî bike ku hêmanên `MaybeUninit<T>` bi rastî di rewşek destpêkî de ne.
    ///
    /// Bangkirina viya dema ku naverok hîn bi tevahî neyê destpêkirin dibe sedema reftarek nediyarkirî.
    ///
    /// Ji bo bêtir agahdarî û mînakan li [`assume_init_ref`] binêrin.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // EWLEHIYE: Ji ber ku bangker garantî dike, perçeya avêtina li `*const [T]` ewledar e
        // `slice` destpêkirî ye, û `BelkîUninit` garantî bibe ku heman xûya `T` hebe.
        // Nîşaneya ku hatî girtin derbasdar e ji ber ku ew behsa bîra xwedan `slice` dike ku ew referansek e û bi vî rengî ji bo xwendinan derbasdar garantî dibe.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Bihesibînin ku hemî hêman têne destpêkirin, jê re perçeyek guhêrbar bigirin.
    ///
    /// # Safety
    ///
    /// Ew bi bangawazî re ye ku garantî bike ku hêmanên `MaybeUninit<T>` bi rastî di rewşek destpêkî de ne.
    ///
    /// Bangkirina viya dema ku naverok hîn bi tevahî neyê destpêkirin dibe sedema reftarek nediyarkirî.
    ///
    /// Ji bo bêtir agahdarî û mînakan li [`assume_init_mut`] binêrin.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // SAFETY: dişibe notên ewlehiyê yên ji bo `slice_get_ref`, lê me heye
        // referansa guhêrbar ku di heman demê de ji bo nivîsandinê jî derbasdar e.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Nîşanek digihîje hêmana yekem a array.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Nîşanek guhêrbar digire ser hêmana yekem a array.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Hêmanên ji `src` bo `this` kopî dike, referansa guhêrbar vedigerîne naverokên `this` yên nuha enitalîzekirî.
    ///
    /// Ger `T` `Copy` bicîh neke, [`write_slice_cloned`] bikar bînin
    ///
    /// Ev dişibihe [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Ger du dirêjahiyên wan dirêjahiyên cûda hebin ev fonksiyon dê panic be.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // EWLEH: me nû hêmanên lenê di kapasîteya vala de kopî kir
    /// // yekem hêmanên src.len() yên vec niha derbasdar in.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // EWLET: &[T] û&[MaybeUninit<T>] xwedan heman şêwekariyê ne
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // EWLEHIY: : Hêmanên hêja tenê di `this` de hatine kopî kirin ji ber vê yekê ew tê şehîn kirin
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Hêmanên ji `src` heya `this` klon dikin, referansa guhêrbar vedigerînin naverokên `this` ên nuha enitalîzekirî.
    /// Hêmanên jixwe enitalîzekirî neyên avêtin.
    ///
    /// Ger `T` `Copy` bicîh tîne, [`write_slice`] bikar bînin
    ///
    /// Ev dişibe [`slice::clone_from_slice`] lê hêmanên heyî davêje.
    ///
    /// # Panics
    ///
    /// Heke her du perçe xwedan dirêjahiyên cûda bin, an jî ger pêkanîna `Clone` panics ev fonksiyon dê panic be.
    ///
    /// Ger panic hebe, dê hêmanên jixwe klonkirî werin avêtin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // EWLEH: me nû hêmanên lenê bi kapasîteya vala ve klon kir
    /// // yekem hêmanên src.len() yên vec niha derbasdar in.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // bervajî copy_from_slice ev ji klone_from_slice re nabêje ser perçeyê ev e ji ber ku `MaybeUninit<T: Clone>` Clone bicîh nake.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // EWLEH: ev perçeya xav dê tenê tiştên destpêkirî hebin
                // ji ber vê yekê, destûr tê dayîn ku wê bavêjin.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Em hewce ne ku bi eşkereyî wan bi dirêjahiya heman darbestî bikin
        // ji bo venêrîna sînoran bête elît kirin, û optimizer dê ji bo rewşên hêsan memcpy çêbike (mînak T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // cerdevan hewce ye b/c panic dibe ku di dema klonek de çêbibe
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // EWLEH: Hêmanên hêjayî nû di `this` de hatine nivisandin ji ber vê yekê ew tê şehîn kirin
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}