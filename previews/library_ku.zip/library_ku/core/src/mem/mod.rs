//! Fonksiyonên bingehîn ên ji bo têkiliya bi bîranînê re.
//!
//! Di vê modulê de fonksiyonên ji bo pirskirina mezinahî û rêzkirina celeban, destpêkirin û manipulkirina bîranînê hene.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Di derheqê nirxê **de xwedan û "forgets" digire bêyî hilweşandina wê**.
///
/// Çavkaniyên ku nirx bi rêve dibe, wekî bîranîna heap an pelgeya pelê, dê her û her di rewşek negihiştî de bimînin.Lêbelê, ew garantî nake ku nîşanên vê bîranînê dê bimînin.
///
/// * Heke hûn dixwazin bîranînê derxînin, li [`Box::leak`] binihêrin.
/// * Heke hûn dixwazin pointerek rawe ya bîranînê bi dest xwe bixin, li [`Box::into_raw`] binihêrin.
/// * Heke hûn dixwazin nirxek bi rêkûpêk bavêjin, hilweşînerê wê dimeşînin, li [`mem::drop`] binihêrin.
///
/// # Safety
///
/// `forget` wekî `unsafe` nehatiye nîşankirin, ji ber ku garantiyên ewlehiyê yên Rust garantî nîne ku hilweşîner dê her gav bimeşin.
/// Mînakî, bernameyek dikare bi karanîna [`Rc`][rc] çerxek referansê biafirîne, an [`process::exit`][exit] bixwaze da ku bêyî hilweşîner neherike.
/// Ji ber vê yekê, destûrdayîna `mem::forget` ji koda ewle garantiyên ewlehiya Rust di bingeh de naguheze.
///
/// Wê got, vekişîna çavkaniyên wekî bîranîn an tiştên I/O bi gelemperî nayê xwestin.
/// Pêdivî di hin rewşên karanîna pispor de ji bo FFI an koda bêewle tê, lê hingê jî, [`ManuallyDrop`] bi gelemperî tête bijartin.
///
/// Ji ber ku jibîrkirina nirxek destûr heye, her kodek `unsafe` ku hûn dinivîsin divê ji bo vê îhtîmalê bihêle.Hûn nekarin nirxek vegerînin û hêvî bikin ku bangker dê pêdivî ye ku hilweşandina nirxê bimeşîne.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Bikaranîna ewlehî ya kanonîkî ya `mem::forget` dorpêçkirina nirxek e ku ji hêla `Drop` trait ve hatî pêkanîn.Mînakî, ev ê `File` derxîne, ango
/// valahiya ku ji hêla guhêrbar ve hatî stendin paşde bistînin lê çavkanîya bingehîn a pergalê qet venagerînin:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Ev kêrhatî ye dema ku xwedaniya çavkaniya bingehîn berê ji kodê re li derveyî Rust hate veguhastin, ji bo nimûne bi veguhastina ravekarê pelê xav ji kodê C re.
///
/// # Têkiliya bi `ManuallyDrop` re
///
/// Dema ku `mem::forget` dikare were bikar anîn ku xwedan *bîranîn* jî were veguheztin, kirina vê yekê xeternak e.
/// [`ManuallyDrop`] divê li şûna wê were bikar anîn.Mînakî vê kodê bifikirin:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // `String` bi karanîna naverokên `v` ava bikin
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // `v` derxe ji ber ku bîra wê niha ji hêla `s` ve tê rêve birin
/// mem::forget(v);  // ÇEWT, v ne derbasdar e û divê neyê fonksiyonek
/// assert_eq!(s, "Az");
/// // `s` bi awayek veşartî tê daxistin û bîra wê tê veqetandin.
/// ```
///
/// Du mînak hene bi mînaka jorîn:
///
/// * Heke di navbera avakirina `String` û vexwendina `mem::forget()` de bêtir kod hatibe zêdekirin, panic di hundurê wê de dê bibe sedema du qat belaş ji ber ku heman bîranîn hem ji hêla `v` û `s` ve tê rêve kirin.
/// * Piştî ku gazî `v.as_mut_ptr()` kirin û xwedîkirina daneyê ji `s` re şandin, nirxa `v` ne derbasdar e.
/// Gava ku nirxek tenê li `mem::forget` were veguheztin (ku ew venêran nake), li hin nirxan li ser nirxên wan hewcehiyên hişk hene ku dema dangilandin an jî nema xwedî dibin wan neheq dike.
/// Bi rengek bikar anîna nirxên nederbasdar, derbaskirina wan an vegerandina wan ji fonksiyonan, tevgerek nediyarkirî pêk tîne û dibe ku ramanên ji hêla berhevkar ve hatine şkandin.
///
/// Bi `ManuallyDrop` veguherîn ji her du pirsgirêkan dûr dikeve:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Berî ku em `v` di nav deverên wê yên xav de bicîh bikin, bila ew nekeve xwarê!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Naha `v` hilweşînin.Van operasyonan nekarin panic, ji ber vê yekê jî nabe ku derdanek hebe.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Di dawiyê de, `String` ava bikin.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` bi awayek veşartî tê daxistin û bîra wê tê veqetandin.
/// ```
///
/// `ManuallyDrop` bi xurtî pêşî li duçar-azad digire ji ber ku em hilweşînerê `v`-yê berî ku tiştek din nekin asteng dikin.
/// `mem::forget()` destûrê nade vê yekê ji ber ku ew argumana xwe dixwe, mecbûr dike ku em tenê piştî ku em ji `v` hewceyê jêgirtinê derxistin jê re bang bikin.
/// Her çend panic di navbera avakirina `ManuallyDrop` û çêkirina têlê de were danasîn (ku wekî ku di kodê de nekare pêk were), ew ê encamek derxe û ne du qat belaş.
/// Bi gotinên din, `ManuallyDrop` li şûna ku li rexê (ducar-) daketinê bikeve, li kêleka lekeyê xelet dibe.
///
/// Di heman demê de, `ManuallyDrop` nahêle ku em xwediyê "touch" `v` bibin ku xwediyê xwediyê `s` veguhezîne-gava paşîn a têkiliya bi `v` re ku wê bavêje bêyî xebitandina hilweşînerê wê bi tevahî tête dûr xistin.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Mîna [`forget`], lê nirxên bêserûber jî qebûl dike.
///
/// Ev fonksiyon tenê şimikek e ku tête rakirin dema ku taybetmendiya `unsized_locals` aram bibe.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Mezinahiya celebek li byteyan vedigerîne.
///
/// Bi taybetîtir, ev di byteyên di navbera hêmanên li pey hev rêzikekê de bi wî rengî re di nav de pileya rêzkirinê ve tê zeliqandin.
///
/// Ji ber vê yekê, ji bo her celebî `T` û dirêjahiya `n`, `[T; n]` xwedî mezinahiya `n * size_of::<T>()` ye.
///
/// Bi gelemperî, mezinahiya celebek di berhevokan de ne aram e, lê celebên taybetî yên wekî prîmîtîf in.
///
/// Tabloya jêrîn ji bo primitives mezinbûnê dide.
///
/// Type |mezinahiya: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Wekî din, `usize` û `isize` xwedan heman mezinahî ne.
///
/// Cûreyên `*const T`, `&T`, `Box<T>`, `Option<&T>`, û `Option<Box<T>>` hemî bi heman mezinahî ne.
/// Ger `T` Mezinahî be, di wan gişt tîpan de heman pîvana `usize` heye.
///
/// Guheztina pointer pîvana wê naguheze.Bi vî rengî, `&T` û `&mut T` xwedan heman mezinahî ne.
/// Her weha ji bo `*const T` û `* mut T`.
///
/// # Mezinahiya tiştên `#[repr(C)]`
///
/// Nûneratiya `C` ji bo tiştan xwedan vesazkirinek diyarkirî ye.
/// Bi vê teşeyê, mezinahiya hêmanan jî stabîl e heya ku hemî qadên xwedan mezinahiyek stabîl bin.
///
/// ## Mezinahiya Structs
///
/// Ji bo `structs`, mezinahî bi algorîtmaya jêrîn tête diyar kirin.
///
/// Ji bo her zeviyê di damezrandinê de ku bi rêznameya daxuyaniyê hatî rêz kirin
///
/// 1. Mezinahiya zeviyê zêde bikin.
/// 2. Mezinahiya heyî heya pirjimara herî nêzîk a [alignment]-a qada paşîn dorpêç bikin.
///
/// Di dawiyê de, mezinahiya sazûmanê heya pirjimara [alignment] ya wê dorpêç bikin.
/// Lihevrasthatina sazûmanê bi gelemperî rêzkirina herî mezin a hemî warên xwe;ev dikare bi karanîna `repr(align(N))` were guhertin.
///
/// Berevajî `C`, qewareyên sifir bi qasî yek bayte ne hatine dorpêç kirin.
///
/// ## Mezinahiya Enums
///
/// Enumên ku ji bilî cûdakar daneyên din nagirin li ser platforma ku ew ji bo wan têne berhev kirin xwedan eynî mezinbûna C enuman in.
///
/// ## Mezinahiya Sendîkayan
///
/// Mezinahiya yekîtiyê mezinahiya qada wêya herî mezin e.
///
/// Berevajî `C`, sendîkayên sifir mezinahî di mezinahiyê de yek bayt nayên dorpêç kirin.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Hin prîmîtîf
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Hin array
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Wekheviya pîvana pointer
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// `#[repr(C)]` bikar tînin.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Mezinahiya qada yekem 1 e, ji ber vê yekê 1 bi mezinahiyê zêde bikin.Mezin 1 e.
/// // Lihevnêzîkbûna qada duyemîn 2 ye, ji ber vê yekê ji bo pijandinê 1 mezin bikin.Mezinahî 2 ye.
/// // Mezinahiya qada duyemîn 2 ye, ji ber vê yekê 2 bi mezinahiyê zêde bikin.Mezin 4 e.
/// // Lihevnêzîkbûna qada sêyemîn 1 e, ji ber vê yekê ji bo pijandinê 0 mezin bikin.Mezin 4 e.
/// // Mezinahiya qada sêyemîn 1 e, ji ber vê yekê 1 li mezinahiyê zêde bikin.Mezinahî 5 e.
/// // Di dawiyê de, lihevnêzîkirina struktura 2 ye (ji ber ku di nav zeviyên wê de rêzkirina herî mezin 2 e), ji ber vê yekê ji bo pijandinê 1 mezin bikin.
/// // Mezin 6 e.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tûpikên heman qaîdeyan dişopînin.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Zanibe ku ji nû ve rêzkirina zeviyan dikare mezinahiyê kêm bike.
/// // Em dikarin bi danîna `third` berî `second` her du byteyên paddingê derxînin.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Mezinahiya yekîtiyê mezinahiya qada herî mezin e.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Mezinahiya nirxa nîşankirî li byteyan vedigerîne.
///
/// Ev bi gelemperî heman wekî `size_of::<T>()` e.
/// Lêbelê, dema ku `T`* * mezinahiyek statîk-naskirî tune, mînakî, perçek [`[T]`][slice] an [trait object], wê hingê `size_of_val` dikare were bikar anîn ku mezinahiya dînamîk-naskirî bistîne.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // EWLEH: : `val` referansek e, ji ber vê yekê ew pêşnumayek raweya derbasdar e
    unsafe { intrinsics::size_of_val(val) }
}

/// Mezinahiya nirxa nîşankirî li byteyan vedigerîne.
///
/// Ev bi gelemperî heman wekî `size_of::<T>()` e.Lêbelê, dema ku `T` * mezinahiyek statîk-naskirî tune, mînakî, perçeyek [`[T]`][slice] an [trait object], wê hingê `size_of_val_raw` dikare were bikar anîn ku mezinahiya dînamîk-naskirî bistîne.
///
/// # Safety
///
/// Vê fonksiyonê tenê ewle ye ku meriv bang bike heke şertên jêrîn hebe:
///
/// - Ger `T` `Sized` e, bangkirina vê fonksiyonê her gav ewle ye.
/// - Ger dûvê bêserûber `T` e:
///     - [slice], wê hingê divê dirêjahiya dûvikê perçê hejmarek destpêkî be, û mezinahiya *tevahiya nirxê*(dirêjahiya dûvikê dînamîk + pêşpirtika bi pîvana statîk) divê di `isize` de bicîh bibe.
///     - a [trait object], wê hingê beşa vtable ya nîşanderê divê vtableyek derbasdar a ku bi zorê bêvekirin bi dest xistiye nîşan bide, û divê mezinahiya *tevahiya nirxê*(dirêjahiya dûvê dînamîk + pêşpirtika bi pîvana statîk) di `isize` de cih bigire.
///
///     - an (unstable) [extern type], wê hingê ev fonksiyon her gav ewle ye ku meriv lê bigere, lê dibe ku panic an wekî din nirxek çewt vegerîne, ji ber ku teşeya celebê derveyî nayê zanîn.
///     Ev eynî reftarî ye wekî [`size_of_val`] li ser referansek li ser celebek bi dûvikek celebek derveyî.
///     - wekî din, bi kevneperestî nayê destûr kirin ku ji vê fonksiyonê re were gotin.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // EWLEHIY: : bangker divê pêşnumayek raweya derbasdar peyda bike
    unsafe { intrinsics::size_of_val(val) }
}

/// [ABI]-hevrastkirina kêmtirîn a celebek vedigerîne.
///
/// Pêdivî ye ku her referansa li ser nirxek celebê `T` pirjimara vê hejmarê be.
///
/// Ev rêzkirin ku ji bo zeviyên damezrandin tê bikar anîn.Dibe ku ew ji rêzkirina bijarte piçûktir be.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// [ABI]-hevrastkirina kêmtirîn a hewceyê celebê nirxa ku `val` nîşan dike vedigerîne.
///
/// Pêdivî ye ku her referansa li ser nirxek celebê `T` pirjimara vê hejmarê be.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // EWLEHIY: : val referansek e, ji ber vê yekê ew pêşnumayek raweya derbasdar e
    unsafe { intrinsics::min_align_of_val(val) }
}

/// [ABI]-hevrastkirina kêmtirîn a celebek vedigerîne.
///
/// Pêdivî ye ku her referansa li ser nirxek celebê `T` pirjimara vê hejmarê be.
///
/// Ev rêzkirin ku ji bo zeviyên damezrandin tê bikar anîn.Dibe ku ew ji rêzkirina bijarte piçûktir be.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// [ABI]-hevrastkirina kêmtirîn a hewceyê celebê nirxa ku `val` nîşan dike vedigerîne.
///
/// Pêdivî ye ku her referansa li ser nirxek celebê `T` pirjimara vê hejmarê be.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // EWLEHIY: : val referansek e, ji ber vê yekê ew pêşnumayek raweya derbasdar e
    unsafe { intrinsics::min_align_of_val(val) }
}

/// [ABI]-hevrastkirina kêmtirîn a hewceyê celebê nirxa ku `val` nîşan dike vedigerîne.
///
/// Pêdivî ye ku her referansa li ser nirxek celebê `T` pirjimara vê hejmarê be.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Vê fonksiyonê tenê ewle ye ku meriv bang bike heke şertên jêrîn hebe:
///
/// - Ger `T` `Sized` e, bangkirina vê fonksiyonê her gav ewle ye.
/// - Ger dûvê bêserûber `T` e:
///     - [slice], wê hingê divê dirêjahiya dûvikê perçê hejmarek destpêkî be, û mezinahiya *tevahiya nirxê*(dirêjahiya dûvikê dînamîk + pêşpirtika bi pîvana statîk) divê di `isize` de bicîh bibe.
///     - a [trait object], wê hingê beşa vtable ya nîşanderê divê vtableyek derbasdar a ku bi zorê bêvekirin bi dest xistiye nîşan bide, û divê mezinahiya *tevahiya nirxê*(dirêjahiya dûvê dînamîk + pêşpirtika bi pîvana statîk) di `isize` de cih bigire.
///
///     - an (unstable) [extern type], wê hingê ev fonksiyon her gav ewle ye ku meriv lê bigere, lê dibe ku panic an wekî din nirxek çewt vegerîne, ji ber ku teşeya celebê derveyî nayê zanîn.
///     Ev eynî reftarî ye wekî [`align_of_val`] li ser referansek li ser celebek bi dûvikek celebek derveyî.
///     - wekî din, bi kevneperestî nayê destûr kirin ku ji vê fonksiyonê re were gotin.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // EWLEHIY: : bangker divê pêşnumayek raweya derbasdar peyda bike
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Ger nirxên celebê `T` dakêşin girîng e `true` vedigere.
///
/// Ev tenê pêşniyarek optimîzasyonê ye, û dibe ku bi kevneperestî were pêkanîn:
/// dibe ku ew `true` ji bo cûreyên ku bi rastî ne hewce ne ku werin avêtin vegerîne.
/// Wekî wusa her dem vegera `true` dê pêkanîna derbasdar a vê fonksiyonê be.Lêbelê heke ev fonksiyon bi rastî `false` vegerîne, wê hingê hûn dikarin hinekî bibêjin ku davêjin `T` bandorek aliyî tune.
///
/// Pêkanînên asta nizm ên tiştên wekî berhevok, ku hewce ne ku bi destan daneyên xwe bavêjin, divê vê fonksiyonê bikar bînin da ku dema ku werin hilweşandin hewce neke ku hewce bike ku hemî naveroka wan bavêjin.
///
/// Dibe ku ev di avahiyên belavkirinê de cûdahiyek çênebe (li ku xelekek ku bandorek wê tune be bi hêsanî tê kifş kirin û ji holê radibe), lê ji bo çêkirina xeletiyan timûtim serketinek mezin e.
///
/// Zanibe ku [`drop_in_place`] jixwe vê kontrolê pêk tîne, ji ber vê yekê heke barê xebata te dikare li hindik hejmarek bangên [`drop_in_place`] were kêm kirin, bikar anîna vê yekê ne hewce ye.
/// Bi taybetî not bikin ku hûn dikarin perçek [`drop_in_place`] bikin, û ew ê ji bo hemî nirxan yek-yek venihêrtina pêdiviyan bike.
///
/// Cûreyên mîna Vec ji ber vê yekê tenê `drop_in_place(&mut self[..])` bêyî ku bi eşkere `needs_drop` bikar tîne.
/// Li aliyê din, celebên mîna [`HashMap`], neçar in ku yek bi yek nirxan bavêjin û divê vê API-yê bikar bînin.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Li vir mînakek heye ka çawa berhevokek dikare `needs_drop` bikar bîne:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // daneyê bavêjin
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Nirxa tîpa `T` a ku ji hêla qalibê-byte-sifir ve tê temsîl kirin vedigerîne.
///
/// Ev tê vê wateyê ku, mînakî, di `(u8, u16)`-ê de byteya padding ne pêdivî ye ku sifir bibe.
///
/// Tu garantî tune ku byte-nexşeyek hemî-sifir nirxek derbasdar a hin tîpên `T` temsîl dike.
/// Mînakî, bête-nimûneya hemî-sifir ji bo celebên referansê (`&T`, `&mut T`) û nîşankerên fonksiyonan ne nirxek derbasdar e.
/// Bikaranîna `zeroed` li ser celebên wusa dibe sedema [undefined behavior][ub] tavilê ji ber ku [the Rust compiler assumes][inv] ku her gav di guherbarek ku ew destpêkirî dihesibîne de nirxek derbasdar heye.
///
///
/// Vê heman bandorê wekî [`MaybeUninit::zeroed().assume_init()`][zeroed] heye.
/// Ew carinan ji bo FFI bikêr e, lê divê bi gelemperî jê were dûrxistin.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Bikaranîna rast a vê fonksiyonê: destpêkirina jimareyek bi sifir.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Nerast* Bikaranîna vê fonksiyonê: destpêkirina referansek bi sifir.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Reftara nediyarkirî!
/// let _y: fn() = unsafe { mem::zeroed() }; // Again dîsa!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // EWLEHIY: : divê bangker garantî bike ku nirxek hemî-sifir ji bo `T` derbasdar e.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Kontrolên destpêkirina bîranîna normal a Rust-ê derbas dike û destnîşan dike ku nirxek ji celebê `T`-ê hilberîne, di heman demê de tiştek tine dike.
///
/// **Ev fonksiyon nayê pejirandin.** Li şûna wê [`MaybeUninit<T>`] bikar bînin.
///
/// Sedema vemirandinê ev e ku fonksiyon di bingeh de bi rêkûpêk nayê bikar anîn: ew heman bandora [`MaybeUninit::uninit().assume_init()`][uninit] heye.
///
/// Wekî [`assume_init` documentation][assume_init] diyar dike, [the Rust compiler assumes][inv] ku nirx bi rêkûpêk têne destpêkirin.
/// Wekî encamek, bangkirina mînak
/// `mem::uninitialized::<bool>()` ji bo vegera `bool` dibe sedema tevgerek yekser a nediyarkirî ku teqez ne `true` an `false` ye.
/// Ya xerabtir, bi rastî bîranîna uninitialized mîna ya ku li vir vedigere taybetî ye ji ber ku berhevkar dizane ku ew ne xwediyê nirxek sabit e.
/// Ev dike tevgerek nediyarkirî ku daneyên uninitialized di guherbarê de hebe jî ku ew guhêrbar celebek jimar hebe.
/// (Bala xwe bidinê ku qaîdeyên li dora jimareyên uninitialized hêj neqediyaye, lê heta ku ew nebin, tê pêşniyar kirin ku ji wan dûr bisekinin.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // EWLEHIY: : divê bangker garantî bike ku nirxek yekbûyî ji bo `T` derbasdar e.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Nirxan li du deverên guhêrbar diguhezîne, bêyî ku yek jê deinitialize bike.
///
/// * Heke hûn dixwazin bi nirxek xwerû an dummy swap bikin, li [`take`] binihêrin.
/// * Heke hûn dixwazin bi nirxek derbasbûyî swap bikin, nirxa kevn vegerînin, li [`replace`] binihêrin.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // EWLEH: nîşanderên xav ji çavkaniyên guhêrbar ên ewledar ên ku hemî têr dike hatine afirandin
    // astengiyên li ser `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// `dest` bi nirxa xwerû ya `T` veguherîne, nirxa `dest` ya berê vedigerîne.
///
/// * Heke hûn dixwazin nirxên du guhêrbaran li şûna xwe bigirin, li [`swap`] binihêrin.
/// * Heke hûn dixwazin li şûna nirxa xwerû bi nirxek derbasbûyî veguherînin, [`replace`] binihêrin.
///
/// # Examples
///
/// Mînakek hêsan:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` dihêle ku hûn xwediyê zeviyek sazûmanî bigirin ku bi nirxek "empty" veguherîne.
/// Bêyî `take` hûn dikarin bi pirsgirêkên mîna van re rû bi rû bimînin:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Zanibe ku `T` ne hewce ye ku [`Clone`] bicîh bîne, ji ber vê yekê ew nekare `self.buf` jî klon bike û şûnda bike.
/// Lê `take` dikare were bikar anîn ku nirxa `self.buf` ya `self` ji `self` veqetîne, da ku ew were vegerandin:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// `src` dixe nav `dest` ya referanskirî, nirxa `dest` ya berê vedigire.
///
/// Ne nirx tê avêtin.
///
/// * Heke hûn dixwazin nirxên du guhêrbaran li şûna xwe bigirin, li [`swap`] binihêrin.
/// * Heke hûn dixwazin bi nirxek xwerû veguherînin, [`take`] binihêrin.
///
/// # Examples
///
/// Mînakek hêsan:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` dihêle ku vexwarina zeviyek strukturel bi şûna wê re nirxek din.
/// Bêyî `replace` hûn dikarin bi pirsgirêkên mîna van re rû bi rû bimînin:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Zanibe ku `T` ne hewce ye ku [`Clone`] bicîh bîne, ji ber vê yekê em nekarin `self.buf[i]` jî klon bikin da ku ji tevgerê dûr nekevin.
/// Lê `replace` dikare were bikar anîn ku nirxa xwerû ya li ser vê indexê ji `self` veqetîne, dihêle ew were vegerandin:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // EWLEH: Em ji `dest` dixwînin lê paşê yekser `src` tê de dinivîsin,
    // wusa ku qîmeta kevn nayê ducar kirin.
    // Tiştek nayê avêtin û tiştek li vir nikare panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Nirxek xilas dike.
///
/// Vê yekê bi banga sepandina argumana [`Drop`][drop] dike.
///
/// Ev ji bo celebên ku `Copy` bicîh dikin, bi bandor tiştek nake
/// integers.
/// Nirxên weha têne kopîkirin û _then_ dikeve nav fonksiyonê, ji ber vê yekê nirx piştî banga vê fonksiyonê berdewam dike.
///
///
/// Ev fonksiyon ne efsûn e;ew biwêjî wekî tê pênasekirin
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Ji ber ku `_x` dikeve nav fonksiyonê, ew jixweber tê daketin berî ku fonksiyon vegere.
///
/// [drop]: Drop
///
/// # Examples
///
/// Bikaranîna bingehîn:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // bi zelalî vector davêjin
/// ```
///
/// Ji ber ku [`RefCell`] qaîdeyên deyn di dema kar de bi cî tîne, `drop` dikare deynek [`RefCell`] serbest berde:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // dev ji deynê mutable li ser vê hêlînê berdin
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Integer û celebên din ên ku [`Copy`] bicîh dikin ji hêla `drop` ve bandor nabin.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // nusxeyek `x` tê veguheztin û dadiket
/// drop(y); // nusxeyek `y` tê veguheztin û dadiket
///
/// println!("x: {}, y: {}", x, y.0); // hîn jî heye
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// `src` wekî tîpa `&U` şîrove dike, û dûv re `src` dixwîne bêyî ku nirxa tê de bar bike.
///
/// Ev fonksiyon dê bi ewlehî pêşnumayê `src` ji bo B0yên [`size_of::<U>`][size_of] derbas bike bi veguheztina `&T` bo `&U` û dûv re jî xwendina `&U` (ji xeynî ku ev bi rengek rast tête kirin jî dema ku `&U` ji `&T` daxwazên rêzkirinê tundtir dike).
/// Ew ê di heman demê de li şûna ku ji `src` bar bike wê kopiyek nirxa tê de biafirîne.
///
/// Heke `T` û `U` mezinahiyên cûda hebin ew ne xeletiyek berhevkirinê ye, lê ew pir tête teşwîq kirin ku tenê vê fonksiyonê li ku `T` û `U` xwedan heman mezinahî ne bang bikin.Ger `U` ji `T` mezintir be ev fonksiyon [undefined behavior][ub] dide alî.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Daneyên ji 'foo_array' kopî bikin û wekî 'Foo' derman bikin
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Daneyên kopîkirî biguherînin
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Pêdivî ye ku naveroka 'foo_array' nehatibe guhertin
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Ger U hewcedariyek rêzkirinê mezintir hebe, dibe ku src bi guncanî neyê rêz kirin.
    if align_of::<U>() > align_of::<T>() {
        // EWLEH: : `src` referansek e ku ji bo xwendinan derbasdar e.
        // Divê bangker garantî bike ku veguherîna rastîn ewledar e.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // EWLEH: : `src` referansek e ku ji bo xwendinan derbasdar e.
        // Me tenê kontrol kir ku `src as *const U` bi rêkûpêk hatî rastandin.
        // Divê bangker garantî bike ku veguherîna rastîn ewledar e.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Tîpa nebaş cihêkerê enumê temsîl dike.
///
/// Ji bo bêtir agahdarî di vê modulê de fonksiyona [`discriminant`] bibînin.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Van pêkanînên trait nekarin werin derxistin ji ber ku em li ser T. tixûb naxwazin.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Nirxek vedigerîne ku bi yekta guhertoya enum-a `v`-ê nas dike.
///
/// Heke `T` ne enum e, gazîkirina vê fonksiyonê dê bi reftarek nediyar encam nede, lê nirxa vegerê ne diyar e.
///
///
/// # Stability
///
/// Heke pênaseya enumê biguhere dibe ku cihêkerê variantek enumê biguhere.
/// Cûdahiyek hin variant dê di navbera berhevokên bi heman berhevkar de neguhere.
///
/// # Examples
///
/// Ev dikare were bikar anîn ji bo berhevdana enûmên ku dane hilgirtin, dema ku daneyên rastîn paşguh dikin:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Hejmara variyantan di tîpa enum `T` de vedigerîne.
///
/// Heke `T` ne enum e, gazîkirina vê fonksiyonê dê bi reftarek nediyar encam nede, lê nirxa vegerê ne diyar e.
/// Bi heman awayî, heke `T` ji `usize::MAX`-an bêtir guhêrbar enumek e ku nirxa vegerê nayê diyar kirin.
/// Wê cûrbecûrên niştecîh werin hesibandin.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}