use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Zexmek ku ji berhevkar re nahêle ku jixweber bang li `hilweşîner` T` bike.
/// Ev pêça 0-lêçûn e.
///
/// `ManuallyDrop<T>` bi `T` re di heman optimîzasyonên dabeşkirinê de ye.
/// Wekî encamek, ew *bandorê* li ser ramanên ku berhevkar di derbarê naveroka xwe de dike nake.
/// Mînakî, destpêkirina `ManuallyDrop<&mut T>` bi [`mem::zeroed`] reftarek nediyarkirî ye.
/// Heke hûn hewce ne ku daneyên uninitialized bigirin, li şûna [`MaybeUninit<T>`] bikar bînin.
///
/// Zanibe ku gihîştina nirxa hundurê `ManuallyDrop<T>` ewledar e.
/// Ev tê vê wateyê ku divê `ManuallyDrop<T>` ku naveroka wê hatî daxistin bi navgîniya API-ya ewlekarî ve neyê eşkere kirin.
/// Bi peywendîdar, `ManuallyDrop::drop` ne ewle ye.
///
/// # `ManuallyDrop` û rêzê davêjin.
///
/// Rust xwedan nirxên [drop order]-baş-diyarkirî ye.
/// Ji bo ku piştrast bibin ku zevî an dever bi rêzikek taybetî têne dakêşandin, danezanan ji nû ve sererast bikin da ku rêza daketinê ya nepenî rast e.
///
/// Gengaz e ku meriv `ManuallyDrop` bikar bîne da ku emrê dakêşanê kontrol bike, lê ev pêdivî bi kodek ne ewledar e û li ber nebûna vebûnê zor e ku meriv bi durustî bike.
///
///
/// Mînakî, heke hûn dixwazin pê ewle bine ku qadek taybetî li dû yên din hatiye avêtin, wê bikin qada paşîn a struktura:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` dê piştî `children` were avêtin.
///     // Rust garantî dike ku zevî di rêza daxuyaniyê de têne avêtin.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Nirxek pêçan ku bi destan were avêtin.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Hûn hîn jî dikarin bi ewlehî li ser nirxê kar bikin
    /// assert_eq!(*x, "Hello");
    /// // Lê `Drop` dê li vir neyê xebitandin
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Nirxê ji konteynera `ManuallyDrop` derdixe.
    ///
    /// Ev dihêle ku nirx dîsa were avêtin.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Ev `Box` davêje.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Nirxê ji konteynir `ManuallyDrop<T>` derdixe.
    ///
    /// Ev rêbaza hanê di serî de ji bo derketina nirxan di dilopê de ye.
    /// Di şûna karanîna [`ManuallyDrop::drop`] de ku hûn nirxê bi desta bavêjin, hûn dikarin vê rêbazê bikar bînin ku nirxê bigirin û lêbelê ku tê xwestin bikar bînin.
    ///
    /// Kengê ku gengaz be, çêtir e ku meriv li şûna wê [`into_inner`][`ManuallyDrop::into_inner`] bikar bîne, ku pêşî li dubarekirina naveroka `ManuallyDrop<T>` digire.
    ///
    ///
    /// # Safety
    ///
    /// Ev fonksiyon ji hêla semantîkî ve bêyî ku pêşî li karanîna wê bigire, nirxa tê de derdikeve holê, rewşa vê konteynirê nayê guhertin.
    /// Ew berpirsiyariya we ye ku hûn piştrast bikin ku ev `ManuallyDrop` careke din nayê bikar anîn.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // EWLEH: em ji referansek dixwînin, ku garantî ye
        // ji bo xwendinan derbasdar be.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Bi desta nirxa tê de davêje.Ev tam wekhev e ku [`ptr::drop_in_place`] bi nîşangirek li nirxa têdeyî bang dike.
    /// Bi vî rengî, heya ku nirxa tê de ne struktûrek pakkirî be, hilweşîner bêyî ku nirxê bar bike dê li cîh bê gazî kirin, û bi vî rengî dikare were bikar anîn ku daneyên [pinned] bi ewlehî bavêje.
    ///
    /// Ger xwediya nirxê we hebe, hûn dikarin li şûna wê [`ManuallyDrop::into_inner`] bikar bînin.
    ///
    /// # Safety
    ///
    /// Ev fonksiyon hilweşandina nirxa tê de dimeşîne.
    /// Ji xeynî guhertinên ku ji hêla desteserker ve hatine çêkirin, bîranîn bê guhertin tê hiştin, û ji ber vê yekê heya ku berhevkar têkildar e hîn jî qalibek bit heye ku ji bo tîpa `T` derbasdar e.
    ///
    ///
    /// Lêbelê, pêdivî ye ku vê nirxa "zombie" bi koda ewlehiyê re rûbirû nebe, û divê ji vê fonksiyonê re carek zêdetir neyê gazîkirin.
    /// Ji bo ku nirxek piştî daketinê bikar bînin, an nirxek pir caran dakêşin, dibe sedema Reftara Nediyarkirî (li gorî tiştê ku `drop` dike).
    /// Ev bi gelemperî ji hêla pergala celebê ve tê asteng kirin, lê bikarhênerên `ManuallyDrop` divê bêyî alîkariya ji berhevkar wan garantiyan biparêzin.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // EWLEH: : em nirxa ku ji hêla referansa guhêrbar ve hatî diyar kirin davêjin
        // ku ji bo nivîsandinê derbasdar e.
        // Li ser bangawazî ye ku bisekine ku `slot` dîsa dernakeve.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}