/// trait ji bo xwerûkirina tevgera kargêrê `?`.
///
/// Cureyek bicîhkirina `Try` yek e ku awayek kanonîkî heye ku ew li gorî dubendiya success/failure binihêre.
/// Ev trait dihêle hem wan nirxên serfirazî an têkçûnê ji mînakek heyî derxîne û hem jî ji nirxek serkeftin an têkçûnek mînakek nû biafirîne.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Cureyê vê nirxê dema ku serfiraz tê dîtin.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Cureyê vê nirxê dema ku wekî têkçûyî tê dîtin.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Kargêrê "?" bikar tîne.Vegera `Ok(t)` tê vê wateyê ku divê darvekirin bi asayî berdewam bike, û encama `?` nirxa `t` ye.
    /// Vegerandina `Err(e)` tê vê wateyê ku darvekirin divê branch li `catch` ya hundurîn dorpêçkirî be, an jî ji fonksiyonê vegere.
    ///
    /// Ger encamek `Err(e)` vegere, dê nirxa `e` di celebê vegera qada dorpêçê de "wrapped" be (ku divê xwe `Try` bicîh bike).
    ///
    /// Bi taybetî, nirxa `X::from_error(From::from(e))` vedigere, ku `X` celebê vegera fonksiyona dorpêçê ye.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Ji bo avakirina encama pêkhatî nirxek çewtiyê pêça.
    /// Mînakî, `Result::Err(x)` û `Result::from_error(x)` wekhev in.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Ji bo avakirina encama pêkhatî nirxek OK pêça.
    /// Mînakî, `Result::Ok(x)` û `Result::from_ok(x)` wekhev in.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}