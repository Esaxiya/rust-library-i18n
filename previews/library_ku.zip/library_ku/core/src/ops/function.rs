/// Guhertoya operatorê bangê ku wergirek neguhêrbar digire.
///
/// Mînakên `Fn` bêyî ku dewleta guhêrbar hebe dikare bête dubare kirin.
///
/// *Ev trait (`Fn`) bi [function pointers] (`fn`) nayê xapandin.*
///
/// `Fn` ji hêla girtinan ve ku tenê referansên guhêrbar diguherîne guhêrbarên hatine girtin an tiştek bi dest naxe, û her weha (safe) [function pointers] (bi hin vebêjan, ji bo bêtir agahdariyê li belgekirina wan binihêrin) jixweber tê pêkanîn.
///
/// Wekî din, ji bo her cûreyê `F` ku `Fn` bicîh dike, `&F` jî `Fn` bicîh dike.
///
/// Ji ber ku hem [`FnMut`] hem jî [`FnOnce`] supertraits of `Fn` in, her nimûneyek `Fn` dikare wekî pîvanek ku [`FnMut`] an [`FnOnce`] tê hêvî kirin were bikar anîn.
///
/// `Fn` wekî bendek bikar bînin dema ku hûn dixwazin pîvanek celebek mîna-fonksiyonê qebûl bikin û hewce ne ku jê re bi berdewamî û bêyî rewşa guherînê bang bikin (mînakî, dema ku ew bi hev re bang dikin).
/// Heke ji we re hewcedariyên weha hişk ne hewce ne, [`FnMut`] an [`FnOnce`] wekî sînor bikar bînin.
///
/// Li ser vê mijarê ji bo çend agahdariyên bêtir li [chapter on closures in *The Rust Programming Language*][book] binêrin.
///
/// Di heman demê de baldar e ku hevoksaziya taybetî ji bo `Fn` traits (mînakî)
/// `Fn(usize, bool) -> bikar bînin`).Kesên ku bi hûrguliyên teknîkî yên vê yekê eleqedar dibin dikarin serî li [the relevant section in the *Rustonomicon*][nomicon] bidin.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Gazî girtinê dikin
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Bikaranîna pîvanek `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // da ku regex karibe xwe bispêre `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Operasyona bangê pêk tîne.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Guhertoya operatorê bangê ku wergirek guhêrbar digire.
///
/// Mînakên `FnMut` dikare bi berdewamî were gazî kirin û dibe ku dewleta mutasyonê bide.
///
/// `FnMut` ji hêla girtinan ve ku bi referansên guhêrbar diguherin guherbarên girtî, û her weha her cûreyên ku [`Fn`] bicîh dikin, jixweber tê cîbicîkirin, mînak (safe) [function pointers] (ji ber ku `FnMut` supertitika [`Fn`] e).
/// Wekî din, ji bo her cûreyê `F` ku `FnMut` bicîh dike, `&mut F` jî `FnMut` bicîh dike.
///
/// Ji ber ku [`FnOnce`] supertîva `FnMut` e, her nimûneyek `FnMut` dikare were bikar anîn ku [`FnOnce`] tê hêvî kirin, û ji ber ku [`Fn`] jêreng `FnMut` e, her nimûneyek [`Fn`] dikare were bikar anîn ku `FnMut` tê hêvî kirin.
///
/// `FnMut` wekî bendek bikar bînin dema ku hûn dixwazin pîvanek celeb-wek-fonksiyonê qebûl bikin û hewce bikin ku hûn wê bi berdewamî bang bikin, dema ku destûr dide ku ew dewletê veguherîne.
/// Heke hûn naxwazin parametre dewletê veguherîne, [`Fn`] wekî bendek bikar bînin;heke hûn ne hewce ne ku wê çend caran bang bikin, [`FnOnce`] bikar bînin.
///
/// Li ser vê mijarê ji bo çend agahdariyên bêtir li [chapter on closures in *The Rust Programming Language*][book] binêrin.
///
/// Di heman demê de baldar e ku hevoksaziya taybetî ji bo `Fn` traits (mînakî)
/// `Fn(usize, bool) -> bikar bînin`).Kesên ku bi hûrguliyên teknîkî yên vê yekê eleqedar dibin dikarin serî li [the relevant section in the *Rustonomicon*][nomicon] bidin.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Gazîkirina girtinek mutabîl girtin
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Bikaranîna pîvanek `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // da ku regex karibe xwe bispêre `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Operasyona bangê pêk tîne.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Guhertoya operatorê bangê ku wergirek ji-nirx digire.
///
/// Mînakên `FnOnce` dikarin bêne gazî kirin, lê dibe ku gelek caran neyên gazîkirin.Ji ber vê yekê, heke di derheqê celebek de tenê tiştê ku tê zanîn ew e ku ew `FnOnce` bicîh dike, ew dikare tenê carekê were gazî kirin.
///
/// `FnOnce` ji hêla girtinan ve ku dibe ku guhêrbarên dîlgirtî bixwe, û her weha her cûreyên ku [`FnMut`] bicîh dikin, jixweber tê cîbicîkirin, mînak (safe) [function pointers] (ji ber ku `FnOnce` supertrait a [`FnMut`] e).
///
///
/// Ji ber ku herdu [`Fn`] û [`FnMut`] subtraits yên `FnOnce` in, her nimûneyek [`Fn`] an [`FnMut`] dikare li cihê ku `FnOnce` tê hêvî kirin were bikar anîn.
///
/// `FnOnce` wekî girêdan bikar bînin dema ku hûn dixwazin pîvanek celeb-wek-fonksiyonê qebûl bikin û tenê hewce ye ku carek lê bigerin.
/// Heke hûn hewce ne ku parametreyê bi berdewamî bang bikin, [`FnMut`] wekî bendek bikar bînin;heke hûn jî hewce ne ku dewleta xwe neguherînin, [`Fn`] bikar bînin.
///
/// Li ser vê mijarê ji bo çend agahdariyên bêtir li [chapter on closures in *The Rust Programming Language*][book] binêrin.
///
/// Di heman demê de baldar e ku hevoksaziya taybetî ji bo `Fn` traits (mînakî)
/// `Fn(usize, bool) -> bikar bînin`).Kesên ku bi hûrguliyên teknîkî yên vê yekê eleqedar dibin dikarin serî li [the relevant section in the *Rustonomicon*][nomicon] bidin.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Bikaranîna pîvanek `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` guherbarên xwe yên girtî dixwe, ji ber vê yekê ew nikare carek bêtir were xebitandin.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Hewldana ji nû ve bangkirina `func()` dê xeletiyek `use of moved value` ji bo `func` bavêje.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` di vê nuqteyê de nema dikare were gazîkirin
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // da ku regex karibe xwe bispêre `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Tîpa vegeriyayî piştî ku operatorê bangê tê bikar anîn.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Operasyona bangê pêk tîne.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}