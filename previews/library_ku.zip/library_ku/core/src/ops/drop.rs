/// Koda xwerû di nav hilweşîner de.
///
/// Dema ku nirxek êdî hewce nebe, Rust dê "destructor" li ser wê nirxê bimeşîne.
/// Awayê herî hevpar ku nirxek êdî hewce dike dema ku ew ji çarçova xwe derkeve ye.Wêranker dibe ku hîn jî di rewşên din de bimeşin, lê em ê li ser mijarên li vir bisekinin.
/// Ji bo ku hûn di derbarê hin ji wan rewşên din de fêr bibin, ji kerema xwe li beşa [the reference] ya li ser rûxînkaran binêrin.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Ev hilweşîner ji du pêkhateyan pêk tê:
/// - Ji bo vê nirxê bang li `Drop::drop` dibe, heke ev `Drop` trait ya taybetî ji bo celebê xwe were pêkanîn.
/// - "drop glue"-ê ku bixweber çêkirî ye ku bi vegerînî bang li hilweşînerên hemî zeviyên vê nirxê dike.
///
/// Ji ber ku Rust jixweber bang li hilweşînerên hemî zeviyên tê de dike, hûn ne hewce ne ku di piraniya rewşan de `Drop` bicîh bînin.
/// Lê hin rewş hene ku ew bikêr e, mînakî ji bo celebên ku çavkaniyek yekser birêve dibin.
/// Ew çavkanî dibe ku bîranîn be, dibe ku ew beyankirina pelê be, dibe ku bibe soketek torê.
/// Gava ku nirxek ji wî rengî êdî nema tê bikar anîn, divê ew "clean up" çavkaniya xwe bi azadkirina bîranînê an girtina pelê an soketê ve girêde.
/// Ev karê hilweşîner e, û ji ber vê yekê jî karê `Drop::drop`.
///
/// ## Examples
///
/// Ji bo ku hilweşîner di çalakiyê de bibînin, ka em li bernameya jêrîn binêrin:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust dê pêşî ji `Drop::drop` re ji bo `_x` û dûv re ji bo her du `_x.one` û `_x.two` bang bike, tê vê wateyê ku xebitandina vê dê çap bike
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Heke em pêkanîna `Drop` ji bo `HasTwoDrop` ji holê rakin jî, hilweşînerên zeviyên wê hîn jî têne gotin.
/// Ev ê encam bide
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Hûn bi xwe nikarin bangî `Drop::drop` bikin
///
/// Ji ber ku `Drop::drop` ji bo paqijkirina nirxek tê bikar anîn, dibe ku xeternak be ku meriv vê nirxê bikar bîne piştî ku rêbaz bang kirin.
/// Ji ber ku `Drop::drop` xwediyê têketina xwe nagire, Rust pêşî li karanînê digire û nahêle hûn rasterast li `Drop::drop` bigerin.
///
/// Bi gotinên din, heke we hewl da ku hûn di mînaka jorîn de eşkere bangî `Drop::drop` bikin, hûn ê çewtiyek berhevkar bistînin.
///
/// Heke hûn dixwazin bi zelalî bang li hilweşîner a nirxê bikin, li şûna wê [`mem::drop`] dikare were bikar anîn.
///
/// [`mem::drop`]: drop
///
/// ## Emrê davêjin
///
/// Kîjan ji du `HasDrop`-an me davêje pêş, her çend?Ji bo lêdanê, ew heman rêza ku ew têne ragihandin e: yekem `one`, paşê `two`.
/// Heke hûn dixwazin viya bi xwe biceribînin, hûn dikarin li jor `HasDrop` biguherînin da ku hin daneyan, mîna jimareyek rast hebe, û dûv re jî ew di `println!` hundirê `Drop` de bikar bînin.
/// Ev tevger ji hêla zimên ve hatî garantîkirin.
///
/// Berevajî kolanan, guherbarên herêmî bi rêzê berevajî têne avêtin:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Ev dê çap bike
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Ji kerema xwe ji bo rêzikên tevahî [the reference] bibînin.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` û `Drop` taybetî ne
///
/// Hûn nekarin herdu [`Copy`] û `Drop` li ser yek celeb bicîh bikin.Cûreyên ku `Copy` in ji hêla berhevkar ve bi zelalî ducar dibin, lewma pêşbînîkirina kengê, û çiqas caran wêranker dê werin darve kirin pir dijwar e.
///
/// Bi vî rengî, ev celeb nikarin hilweşîner hebin.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Destxetkar ji bo vî rengî dimeşîne.
    ///
    /// Dema ku nirx ji çarçova xwe derdikeve, bi zelalî tê gotin ku ev rêbaz bi zelalî nayê gazîkirin (ev xeleta berhevkar [E0040] e).
    /// Lêbelê, fonksiyona [`mem::drop`] di prelude de dikare were bikar anîn ku banga pêkanîna `Drop` bike.
    ///
    /// Dema ku ji vê rêbazê re tê gotin, `self` hîn nehatiye veqetandin.
    /// Ku tenê piştî ku rêbaza xelas dibe pêk tê.
    /// Ger ev nebûya, `self` dê bibûya referansek dangling.
    ///
    /// # Panics
    ///
    /// Ji ber ku [`panic!`] dema ku xwe vedike dê bangî `drop` bike, di pêkanîna `drop` de dê her [`panic!`] kurt bibe.
    ///
    /// Bala xwe bidinê ku heke ev panics be jî, hêjayî tête avêtin tête hesibandin;
    /// divê hûn nebin sedem ku `drop` dîsa were gazî kirin.
    /// Ev di normalê de ji hêla berhevkar ve bixweber tête birêve birin, lê dema ku kodek ne ewle tê bikar anîn, carinan dikare bi nezanî pêk were, nemaze dema ku [`ptr::drop_in_place`] bikar tê.
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}