/// Ji bo operasyonên paşveguhêzbar ên neguhêrbar, wekî `*v`, tê bikar anîn.
///
/// Ji bilî ku ji bo karûbarên dereferferensê yên eşkere bi kargêrê (unary) `*` re di kontekstên neguhêrbar de tê bikar anîn, `Deref` di gelek şert û mercan de ji hêla berhevkar ve jî bi zelalî tê bikar anîn.
/// Ji vê mekanîzmayê re ['`Deref` coercion'][more] tê gotin.
/// Di çarçoveyên guhêrbar de, [`DerefMut`] tê bikar anîn.
///
/// Pêkanîna `Deref` ji bo nîşankerên aqilmend gihîştina daneyên li paş wan hêsantir dike, ji ber vê yekê ew `Deref` bicîh dikin.
/// Li aliyê din, qaîdeyên di derbarê `Deref` û [`DerefMut`] de bi taybetî ji bo cîhgirtina nîşangirên zîrek hatine çêkirin.
/// Ji ber viya, divê **`Deref` tenê ji bo nîşankerên aqilmend werin sepandin** da ku tevlihevî dernekeve.
///
/// Ji ber sedemên wekhev,**divê ku ev trait qet têk neçe**.Têkçûna di dema dereferêdanê de dema ku `Deref` bi veşartî tête vexwendin dibe ku pir tevlihev be.
///
/// # Zêdetir li ser zorê `Deref`
///
/// Ger `T` `Deref<Target = U>` bicîh dike, û `x` nirxek ji celebê `T` e, wê hingê:
///
/// * Di çarçoveyên neguhêrbar de, `*x` (ku `T` ne referans û ne jî pêşnumayek rawe ye) bi `* Deref::deref(&x)` re hevseng e.
/// * Nirxên celebê `&T` bi nirxên celebê `&U` têne zor kirin
/// * `T` bi vegotinî hemî rêbazên (immutable) ên celebê `U` bicîh tîne.
///
/// Ji bo bêtir agahdarî, biçin [the chapter in *The Rust Programming Language*][book] û her weha beşên referansê yên li ser [the dereference operator][ref-deref-op], [method resolution] û [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Damezrandinek bi zeviyek yekta ku ji hêla dereferîfezekirina struct ve tête peyda kirin.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Cureyê encamgirtî piştî dereferêkirinê.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Nirxê derefer dike.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Ji bo operasyonên dereferferensê yên guhêrbar, mîna `*v = 1;`, tê bikar anîn.
///
/// Ji bilî ku ji bo karûbarên dereferenskirina eşkere bi kargêrê (unary) `*` re di kontekstên guhêrbar de tê bikar anîn, `DerefMut` di gelek rewşan de ji hêla berhevkar ve jî bi vebêjî tê bikar anîn.
/// Ji vê mekanîzmayê re ['`Deref` coercion'][more] tê gotin.
/// Di çarçoveyên neguhêrbar de, [`Deref`] tê bikar anîn.
///
/// Pêkanîna `DerefMut` ji bo nîşankerên aqilmend mutasyona daneyên li pişta wan hêsan dike, ji ber vê yekê ew `DerefMut` bicîh dikin.
/// Li aliyê din, qaîdeyên di derbarê [`Deref`] û `DerefMut` de bi taybetî ji bo cîhgirtina nîşangirên zîrek hatine çêkirin.
/// Ji ber viya, divê **`DerefMut` tenê ji bo nîşangirên zîrek bêne bicîh kirin** da ku tevlihevî dernekeve.
///
/// Ji ber sedemên wekhev,**divê ku ev trait qet têk neçe**.Têkçûna di dema dereferêdanê de dema ku `DerefMut` bi veşartî tête vexwendin dibe ku pir tevlihev be.
///
/// # Zêdetir li ser zorê `Deref`
///
/// Ger `T` `DerefMut<Target = U>` bicîh dike, û `x` nirxek ji celebê `T` e, wê hingê:
///
/// * Di çarçoveyên guhêrbar de, `*x` (ku `T` ne referansek e û ne jî pêşnumayek rawe ye) wekhevî `* DerefMut::deref_mut(&mut x)` e.
/// * Nirxên celebê `&mut T` bi nirxên celebê `&mut U` têne zor kirin
/// * `T` bi vegotinî hemî rêbazên (mutable) ên celebê `U` bicîh tîne.
///
/// Ji bo bêtir agahdarî, biçin [the chapter in *The Rust Programming Language*][book] û her weha beşên referansê yên li ser [the dereference operator][ref-deref-op], [method resolution] û [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Damezrandinek bi zeviyek yekane ku ji hêla dereferîfezekirin ve tête guhartin.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Bi guhêrbar nirxê paşguh dikin.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Nîşan dide ku strukturek bêyî taybetmendiya `arbitrary_self_types` dikare wekî wergirek rêbazê were bikar anîn.
///
/// Ev ji hêla celebên pointer ên stdlib wekî `Box<T>`, `Rc<T>`, `&T`, û `Pin<P>` ve tê pêkanîn.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}