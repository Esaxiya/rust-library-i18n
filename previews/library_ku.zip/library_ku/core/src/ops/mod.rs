//! Operatorên overloadable.
//!
//! Pêkanîna van traits dihêle hûn hin operatorên xwe zêde bar bikin.
//!
//! Hin ji van traits ji hêla prelude ve têne derxistin, ji ber vê yekê ew di her bernameya Rust de hene.Tenê operatorên ku ji hêla traits ve têne piştgirî kirin dikarin zêde barkirin.
//! Mînakî, operatorê lêzêdekirinê (`+`) dikare bi [`Add`] trait ve were barkirin, lê ji ber ku ji operatorê peywirdarkirinê re (`=`) pişta trait tune, çu awayek ku semantîkên wê zêde bikişîne tune.
//! Wekî din, ev modul ti mekanîzmayekê nahîne ji bo afirandina operatorên nû.
//! Heke ji barkirina bêyom an operatorên xwerû hewce ne, divê hûn li makro an pêvekên berhevkar binêrin ku hevoksaziya Rust dirêj bikin.
//!
//! Pêdivî ye ku pêkanînên operatorê traits di warên wan de ne surprîz be, û wateyên wan ên asayî û [operator precedence] li ber çavan bigirin.
//! Mînakî, dema ku [`Mul`] tê tetbîq kirin, pêdivî ye ku pêdivî be ku hin dişibihe pirbûnê (û xwedan taybetmendiyên bendewar ên mîna komeletiyê).
//!
//! Têbînî ku operatorên `&&` û `||` kurt-çerx dikin, ango, ew tenê heke ew beşdarî encamê bibe operandana xweya duyemîn dinirxînin.Ji ber ku ev tevger ji hêla traits ve nayê sepandin, `&&` û `||` wekî operatorên barbar nayê piştgirî kirin.
//!
//! Gelek operator ji hêla nirxê ve operandên xwe digirin.Di çarçoveyên ne-gelemperî de ku bi celebên çêkirî ve tê de, ev bi gelemperî ne pirsgirêk e.
//! Lêbelê, karanîna van kargêran di koda gelemperî de, heke pêdivî ye ku nirxên ku ji nû ve werin bikar anîn berevajî ku bila kargêr wan bixwe, hin baldariyê hewce dike.Vebijarek yek e ku carinan carî [`clone`] bikar bînin.
//! Vebijarek din jî ew e ku xwe bisipêrin celebên ku tê de pêkanînên operatorên din ên ji bo çavkaniyan peyda dikin.
//! Mînakî, ji bo celebek `T`-ê ku ji hêla bikarhêner ve hatî destnîşankirin ku tê xwestin piştgiriyê bide pêvekê, dibe ku ramanek baş e ku hem `T` hem jî `&T` traits [`Add<T>`][`Add`] û [`Add<&T>`][`Add`] bicîh bikin da ku koda gelemperî bêyî klonkirina nehewce bê nivîsandin.
//!
//!
//! # Examples
//!
//! Ev mînak avahiyek `Point` diafirîne ku [`Add`] û [`Sub`] bicîh dike, û dûv re nîşankirin û zêdekirina du `Point` ê.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Ji bo pêkanîna mînakê belgeyên ji bo her trait bibînin.
//!
//! [`Fn`], [`FnMut`], û [`FnOnce`] traits ji hêla celebên ku wekî fonksiyonan ve têne vexwendin ve têne bicîh kirin.Zanibe ku [`Fn`] `&self`, [`FnMut`] `&mut self` digire û [`FnOnce`] `self` digire.
//! Ev bi sê cûre rêbazên ku dikarin li ser nimûneyekê werin vexwendin re têkildar in: bang-bi-çavkanî, bang-ji-mutable-referans, û bang-ji-nirx.
//! Bikaranîna herî hevpar a van traits ew e ku wekî sînorên fonksiyonên asta jortirîn ên ku fonksiyonan an girtinan wekî arguman digirin, tevbigere.
//!
//! [`Fn`] wekî pîvanek digirin:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! [`FnMut`] wekî pîvanek digirin:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! [`FnOnce`] wekî pîvanek digirin:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` guherbarên xwe yên girtî dixwe, ji ber vê yekê ew nikare ji carekê zêdetir were xebitandin
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Hewldana ji nû ve bangkirina `func()` dê xeletiyek `use of moved value` ji bo `func` bavêje
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` di vê nuqteyê de nema dikare were gazîkirin
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;