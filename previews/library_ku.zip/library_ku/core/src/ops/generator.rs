use crate::marker::Unpin;
use crate::pin::Pin;

/// Encama ji nû ve destpêkirina jeneratorê.
///
/// Ev enum ji rêbaza `Generator::resume` vedigere û nirxên vegera gengaz a jeneratorê nîşan dide.
/// Vêga ev bi xala rawestandinê ya (`Yielded`) an jî xalek bidawîbûna (`Complete`) re têkildar e.
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Jenerator bi nirxek sekinî.
    ///
    /// Ev dewlet diyar dike ku jeneratorek hatiye rawestandin, û bi gelemperî bi daxuyaniyek `yield` re têkildar dibe.
    /// Nirxa ku di vê variantê de tête peyda kirin bi vegotina ku ji `yield` re hatî derbas kirin re hevûdu ye û dihêle ku jenerator her carê ku ew hilberînek bidin.
    ///
    ///
    Yielded(Y),

    /// Jenerator bi nirxa vegerê qedand.
    ///
    /// Ev dewlet diyar dike ku jeneratorê bi nirxê dabînkirî bidarvekirin qedandiye.
    /// Gava ku jeneratorek `Complete` vegerand ew xeletiyek bernamenûs tête hesibandin ku hûn dîsa bangî `resume` bikin.
    ///
    Complete(R),
}

/// trait ji hêla celebên hilberînerê ve hatî çêkirin ve tête bicîh kirin.
///
/// Generator, ku bi gelemperî wekî korûtîn jî têne binavkirin, niha di Rust de taybetmendiyek zimanê ceribandî ne.
/// Di generatorên [RFC 2033] de hatine zêdekirin ji bo ku di serî de bloka avahiyê ji bo hevoksaziya async/await peyda dikin lê ew ê dirêj bikin ku ji bo vegêran û prîmîtîfên din jî danasînek ergonomîk peyda dike.
///
///
/// Hevoksazî û semantîka ji bo jeneratoran bêîstîkrar e û ji bo aramkirinê dê RFC-ya din jî hewce bike.Di vê demê de, her çend, hevoksazî wek-girtinê ye:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Di pirtûka nearamî de bêtir belgeyên hilberîneran têne dîtin.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Celebê nirxê ku vê jenerator dide.
    ///
    /// Ev celebê têkildar bi vegotina `yield` û nirxên ku destûr tê dayîn ku her carê hilberînerek vedigere vedigere.
    ///
    /// Mînakî dibe ku îteratorek-wekî-hilberînerek vî rengî wekî `T` hebe, celebê ku li ser tê dubare kirin.
    ///
    type Yield;

    /// Celebê nirxê ku vê jenerator vedigerîne.
    ///
    /// Ev bi tîpa ku ji jeneratorê vegeriyaye re an bi vegotinek `return` an bi eşkere wekî vegotina dawîn a jeneratorê rasterast têkildar e.
    /// Mînakî futures dê vê wekî `Result<T, E>` bikar bîne ji ber ku ew future-a qediyayî temsîl dike.
    ///
    ///
    type Return;

    /// Ji nû ve darvekirina vê jeneratorê.
    ///
    /// Vê fonksiyonê dê darvekirina jeneratorê ji nû ve dest pê bike an heke ew hîn nebûbe darvekirinê dest pê dike.
    /// Ev bang dê vegere nav xala sekinandina dawîn a jeneratorê, ji nû ve darvekirin ji `yield`-ya herî paşîn.
    /// Jenerator dê bidomîne heya ku ew bide an vegere, li vê gavê ev fonksiyon dê vegere.
    ///
    /// # Nirxê vegerînin
    ///
    /// `GeneratorState` enumê ku ji vê fonksiyonê vegeriyaye diyar dike ku jenerator di vegerê de di çi rewşê de ye.
    /// Heke vebijêrka `Yielded` vegere wê hingê jenerator giheştiye xaleke rawestandinê û nirxek jê derketî.
    /// Jeneratorên li vê dewletê di xalek paşê de ji bo ji nû ve berdestê hene.
    ///
    /// Ger `Complete` vegere wê hingê jenerator bi nirxê dabînkirî bi tevahî qediyaye.Ew neheq e ku jenerator dîsa ji nû ve were dest pê kirin.
    ///
    /// # Panics
    ///
    /// Ev fonksiyon dikare panic be heke piştî ku vebijêrka `Complete` berê vegeriyane bang lê were kirin.
    /// Dema ku peyvên hilberîner ên di ziman de ji panic re piştrast dibin ku piştî `Complete` ji nû ve dest pê dike, ev ji bo hemî pêkanînên `Generator` trait nayê garantîkirin.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}