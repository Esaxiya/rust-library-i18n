use crate::marker::Unsize;

/// Trait ku diyar dike ku ev nîşangir an pêçek ji bo yekê ye, ku nehiştin dikare li ser pointee were kirin.
///
/// Ji bo bêtir agahdariyê [DST coercion RFC][dst-coerce] û [the nomicon entry on coercion][nomicon-coerce] bibînin.
///
/// Ji bo celebên nîşanderê çêkirî, nîşangirên `T` dê `U` bi zorê veguherînin ji pointerek zirav bi pointerek qelew.
///
/// Ji bo celebên xwerû, zordarî li vir bi zorê `Foo<T>` bo `Foo<U>` dixebite ku bandora `CoerceUnsized<Foo<U>> for Foo<T>` heye.
/// Lêgerînek wusa tenê dikare were nivîsandin ku `Foo<T>` tenê yek qada ne-fantomdata ku tê de `T` hebe hebe.
/// Ger celebê wê qadê `Bar<T>` be, divê pêkanînek `CoerceUnsized<Bar<U>> for Bar<T>` hebe.
/// Dê zorê bi xebitandina zeviya `Bar<T>` nav `Bar<U>` û tijîkirina zeviyên mayî ji `Foo<T>` bixebite ku `Foo<U>` biafirîne.
/// Ev ê bi bandor li qada pointer bimeşîne û zorê bide wê.
///
/// Bi gelemperî, ji bo nîşangirên zîrek hûn ê `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` bicîh bikin, bi `?Sized` vebijarkî bi `T` bixwe ve girêdayî.
/// Ji bo celebên pêçayî yên ku rasterast `T` wekî `Cell<T>` û `RefCell<T>` tê de ne, hûn dikarin rasterast `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` bicîh bikin.
///
/// Ev ê bihêle ku zordariyên celebên mîna `Cell<Box<T>>` bixebitin.
///
/// [`Unsize`][unsize] tête bikar anîn ku celebên ku bi DST-an re bêne zordar kirin heke li paş nîşangiran be zeliqandî ye.Ew ji hêla berhevkar ve jixweber tê pêkanîn.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Ev ji bo ewlehiya tiştê tête bikar anîn, da ku bicîh bike ku celebê wergirê rêbazek dikare were şandin.
///
/// Mînakek pêkanîna trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}