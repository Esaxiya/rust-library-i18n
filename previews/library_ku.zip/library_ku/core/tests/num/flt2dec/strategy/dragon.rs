use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri pir hêdî ye
fn exact_sanity_test() {
    // Vê ceribandinê xilas dibe çi ku ez tenê dikarim bihesibînim ku hin quncikê xebata pirtûkxaneya `exp2`-ê ye, ku di kîjan demjimêr C de em bikar tînin diyar kirin.
    // Di VS 2013-an de ev fonksiyon bi rengek çewtî hebû ku ev ceribandin dema girêdan têk diçe, lê bi VS 2015 re çewtî sax dibe ku ceribandin baş derbas dibe.
    //
    // Xuya ye ku çewtî cûdahiyek di nirxa vegera `exp2(-1057)` de ye, ku li VS 2013 ew bi nimûneya bit 0x2 du qat vedigerîne û li VS 2015 jî 0x20000 vedigerîne.
    //
    //
    // Vêga tenê vê ceribandinê bi tevahî li MSVC paşguh bikin ku ew bi her awayî li cîhek din hatiye ceribandin û em ne pir ceribandî ne ku ceribandina pêkanîna exp2 ya her platformê.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}