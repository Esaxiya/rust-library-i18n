// Bi du bayîtan re lihevkirî
const DATA: [u16; 2] = [u16::from_ne_bytes([0x01, 0x23]), u16::from_ne_bytes([0x45, 0x67])];

const fn unaligned_ptr() -> *const u16 {
    // Ji ber ku DATA.as_ptr() bi du bayîtan ve hatî girêdan, 1 baytê bi wê ve zêde dike ku u16 *bêpergal* çêdike
    unsafe { (DATA.as_ptr() as *const u8).add(1) as *const u16 }
}

#[test]
fn read() {
    use core::ptr;

    const FOO: i32 = unsafe { ptr::read(&42 as *const i32) };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { ptr::read_unaligned(&42 as *const i32) };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *const u16 = unaligned_ptr();

    const UNALIGNED: u16 = unsafe { ptr::read_unaligned(UNALIGNED_PTR) };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

#[test]
fn const_ptr_read() {
    const FOO: i32 = unsafe { (&42 as *const i32).read() };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { (&42 as *const i32).read_unaligned() };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *const u16 = unaligned_ptr();

    const UNALIGNED: u16 = unsafe { UNALIGNED_PTR.read_unaligned() };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

#[test]
fn mut_ptr_read() {
    const FOO: i32 = unsafe { (&42 as *const i32 as *mut i32).read() };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { (&42 as *const i32 as *mut i32).read_unaligned() };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *mut u16 = unaligned_ptr() as *mut u16;

    const UNALIGNED: u16 = unsafe { UNALIGNED_PTR.read_unaligned() };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

// #[test]
// fn write() {core::ptr bikar bînin;
//
//    const fn write_aligned()-> i32 {bila mut res=0;
//        neewle {
//            ptr::write(&mut res as *mut _, 42);
//        }
//        res} const ALIGNED: i32 = write_aligned();
//    assert_eq! (ALIGNED, 42);
//
//    const fn write_unaligned()-> [u16; 2] {bila mut du_alîng= [0u16; 2];
//        ne ewle {bila unaligned_ptr= (two_aligned.as_mut_ptr() wekî *mut u8).add(1) wekî* mut u16;
//            ptr: : binivîse_nezivirandî (nezivirandî_ptr, u16::from_ne_bytes([0x23, 0x45]));} du_rastkirî} const UNALIGNED: [u16; 2] = write_unaligned();
//
//    assert_eq! (UNALIGNED, [u16::from_ne_bytes([0x00, 0x23]), u16::from_ne_bytes([0x45, 0x00])]);})
//
//
//
//
//
//
//
//
//
//

// #[test]
// fn mut_ptr_write() {const fn aligned()-> i32 {bila mut res=0;
//        { (&mut res as *mut i32).write(42); } ne ewle res} const ALIGNED: i32 = aligned();
//
//    assert_eq! (ALIGNED, 42);
//
//    const fn write_unaligned()-> [u16; 2] {bila mut du_alîng= [0u16; 2];
//        ne ewle {bila unaligned_ptr= (two_aligned.as_mut_ptr() wekî *mut u8).add(1) wekî* mut u16;
//            unaligned_ptr.write_unaligned(u16::from_ne_bytes([0x23, 0x45]));
//        }
//        two_aligned} const UNALIGNED: [u16; 2] = write_unaligned();
//    assert_eq! (UNALIGNED, [u16::from_ne_bytes([0x00, 0x23]), u16::from_ne_bytes([0x45, 0x00])]);})
//
//
//
//
//
//
//
//
//
//
//