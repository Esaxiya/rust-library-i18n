use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Ev rûberê ne aram e, lê dibe alîkar ku `?` di navbera wan de erzan bimîne, her çend niha LLVM nekare her dem jê sûd werbigire.
    //
    // (Mixabin Encam û Vebijêrk ne lihevhatî ne, ji ber vê yekê ControlFlow nikare herduyan li hev bîne.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}