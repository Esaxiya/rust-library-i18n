#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// [`prefetch`](fn._prefetch.html) bibînin.
pub const _PREFETCH_READ: i32 = 0;

/// [`prefetch`](fn._prefetch.html) bibînin.
pub const _PREFETCH_WRITE: i32 = 1;

/// [`prefetch`](fn._prefetch.html) bibînin.
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// [`prefetch`](fn._prefetch.html) bibînin.
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// [`prefetch`](fn._prefetch.html) bibînin.
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// [`prefetch`](fn._prefetch.html) bibînin.
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// Rêzeya kaşka ku navnîşana `p` tê de ye bi karanîna `rw` û `locality` dane felq bikin.
///
/// `rw` divê yek ji van be:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): prefetch xwe ji bo xwendinê amade dike.
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): prefetch xwe ji bo nivîsandinê amade dike.
///
/// `locality` divê yek ji van be:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): Pêşdîtina herikbar an ne-demkî, ji bo daneyên ku tenê carek tê bikar anîn.
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): Cacheya asta 3-yê bikişînin.
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): Cacheya asta 2-yê bikişînin.
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): Vedin nav kaşeya asta 1.
///
/// Rêwerzên bîranînê yên pêşwext ji pergala bîranînê re îşaret dikin ku bîranîn ji navnîşanek diyarkirî digihîje dibe ku li nêzê future pêk werin.
/// Pergala bîranînê dikare bi kiryarên ku tê çaverê kirin ku gihîştina bîranînê gava ku çêdibe zûtir bibin, bersiv bide, wekî mînak navnîşana diyarkirî di yek an çend kaşan de pêşî lê bike.
///
/// Ji ber ku ev sînyal tenê şîret in, ji bo CPU-ya taybetî derbasdar e ku her an hemî talîmatên pêşdibistanê wekî NOP-ê derman bike.
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // Em bi `cache type` =1 re rêwerza `llvm.prefetch` bikar tînin (şîfreya daneyê).
    // `rw` û `strategy` li ser bingeha pîvanên fonksiyonê ne.
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}