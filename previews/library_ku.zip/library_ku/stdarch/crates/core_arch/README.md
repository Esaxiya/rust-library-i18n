`core::arch` - Jînewerên taybetî-mîmarî ya pirtûkxaneya bingehîn a Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Modûla `core::arch` peywirên xwemalî yên mîmarî pêk tîne (mînakî SIMD).

# Usage 

`core::arch` wekî beşek `libcore` heye û ew ji hêla `libstd` ve ji nû ve tê şandin.Bikaranîna wê bi `core::arch` an `std::arch` tercîh dikin ji ya crate.
Taybetmendiyên bêstatû bi gelemperî di Rust-ê bi şev de bi navgîniya `feature(stdsimd)` hene.

Bikaranîna `core::arch` bi navgîniya vê crate hewceyê Rust bi şev e, û ew dikare (û dike) gelek caran bişkîne.Tenê rewşên ku divê hûn bi karanîna vê crate bifikirin ev in:

* heke hûn hewce ne ku xwe `core::arch` ji nû ve berhev bikin, mînakî, bi taybetî-hedefên taybetî yên ku ji bo `libcore`/`libstd` neçêkirî ne, hatine çalakirin.
Note: heke hûn hewce ne ku wê ji bo armancek ne-standard ji nû ve berhev bikin, ji kerema xwe li şûna karanîna vê crate bikaranîna `xargo` û ji nû ve berhevkirina `libcore`/`libstd` wekî guncan tercîh bikin.
  
* hin taybetiyên ku dibe ku li pişta taybetmendiyên Rust yên bêîstîkrar jî tune bin bikar bînin.Em hewl didin ku van bi kêmî ve bimînin.
Heke hûn hewce ne ku hin ji van taybetmendiyan bikar bînin, ji kerema xwe pirsgirêkek vekin da ku em wan bi şevê Rust eşkere bikin û hûn wan ji wir bikar bînin.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` di serî de di bin mercên lîsansa MIT û Apache License de (Guhertoya 2.0) tête belav kirin, bi beşên ku ji hêla cûrbecûr lîsansên mîna BSD ve têne nixamtin.

Ji bo hûragahiyan li LICENSE-APACHE, û LICENSE-MIT binihêrin.

# Contribution

Heya ku hûn bi zelalî berevajî vê yekê nebêjin, her tevkariyek ku bi mebest ji bo tevlêbûnê di `core_arch` de ji hêla we ve hatî şandin, wekî ku di lîsansa Apache-2.0 de hatî diyarkirin, dê wekî jorîn, bêyî şert û mercên din, du destûr hebe.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












