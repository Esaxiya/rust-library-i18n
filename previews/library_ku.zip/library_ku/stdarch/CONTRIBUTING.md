# Beşdariya stdarch

`stdarch` crate ji dilxwazî ye ku tevkariyan qebûl bike!Pêşîn dibe ku hûn ê bixwazin depoyê vekolînin û pê ewle bine ku ceribandin ji bo we derbas dibin:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Cihê ku `<your-target-arch>` sêgoşe hedef e ku ji hêla `rustup` ve tê bikar anîn, mînak `x86_x64-unknown-linux-gnu` (bêyî `nightly-`-an pêşîn a berî wê).
Di heman demê de bîr bînin ku ev depo hewceyê kanala şevê ya Rust dike!
Testên jorîn di rastiyê de hewce dike ku rust bi şev li ser pergala we bibe pêşek, ji bo sazkirina ku `rustup default nightly` bikar tîne (û `rustup default stable` vedigere).

Heke yek ji gavên jorîn nexebite, [please let us know][new]!

Dûv re hûn dikarin [find an issue][issues] bikin alîkar, me çend heb bi tagên [`help wanted`][help] û [`impl-period`][impl] hilbijartine ku bi taybetî dikarin hin alîkariyê bikar bînin. 
Dibe ku hûn herî zêde bi [#40][vendor] re eleqedar bin, hemî xalên hundurfiroş ên li ser x86 bicîh bikin.Di wê pirsgirêkê de hin nîşanên baş hene ku meriv li ku dest pê dike!

Heke we pirsên gelemperî hene ji [join us on gitter][gitter] re azad bibin û li dora xwe bipirsin!Ji bo ku hûn bi pirsan yan@BurntSushi an@alexcrichton ping bikin dikarin xwe azad bikin.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Meriv çawa ji bo navdêrên stdarch mînakan dinivîse

Çend taybetmendî hene ku divê bêne çespandin da ku navxweyî ya dayî bi rêkûpêk bixebite û mînakek tenê dema ku taybetmendî ji hêla CPU ve were piştgirî kirin divê tenê ji hêla `cargo test --doc` ve were rêve kirin.

Wekî encamek, default `fn main` ku ji hêla `rustdoc` ve hatî çêkirin dê nexebite (di pir rewşan de).
Jêrîn bikar bînin ku rêber bikar bînin da ku nimûneya we wekî ku hêvî dikir dixebite.

```rust
/// # // Ji me re cfg_target_feature hewce dike ku nimûneyek tenê bisekinin
/// # // dema ku CPU taybetmendiyê piştgirî dike ji hêla `cargo test --doc` ve tê meşandin
/// # #![feature(cfg_target_feature)]
/// # // Em hewce ne ku target_feature ji bo navxweyî bixebite
/// # #![feature(target_feature)]
/// #
/// # // rustdoc bi xwerû `extern crate stdarch` bikar tîne, lê ji me re pêdivî ye
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // Fonksiyona sereke ya rastîn
/// # fn main() {
/// #     // Tenê ger `<target feature>` piştgirî be vê yekê bimeşînin
/// #     heke cfg_feature_enabled be! ("<target feature>"){
/// #         // Fonksiyonek `worker` biafirînin ku tenê heke hedefa hedef were meşandin
/// #         // tête piştgirî kirin û piştrast bikin ku `target_feature` ji bo karkerê we vekirî ye
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         ne ewle fn worker() {
/// // Mînaka xwe li vir binivîsin.Taybetmendiyên navxweyî yên taybetî dê li vir bixebitin!Biçe çolê!
///
/// #         }
///
/// #         { worker(); } ne ewle
/// #     }
/// # }
```

Heke hin ji hevoksaziya jorîn nas xuya neke, beşa [Documentation as tests] ya [Rust Book] hevoksaziya `rustdoc` pir baş vedibêje.
Wekî her dem, ji [join us on gitter][gitter] re azad bifikirin û ji me bipirsin ka hûn qefesan li dar dixin, û ji we re spas dikim ji bo alîkariya çêtirkirina belgekirina `stdarch`!

# Rêwerzên Testkirina Alternatîf

Bi gelemperî tête pêşniyar kirin ku hûn `ci/run.sh` bikar bînin da ku testan bimeşînin.
Lêbelê dibe ku ev ji bo we nexebite, mînakî heke hûn li ser Windows bin.

Di wê rewşê de hûn dikarin ji bo ceribandina nifşa kodê vegerin ser xebitandina `cargo +nightly test` û `cargo +nightly test --release -p core_arch`.
Bala xwe bidinê ku vana pêdivî ye ku zincîra amûran a şevê were saz kirin û ji bo `rustc` di derbarê sêyemîn hedefa we û CPU-ya wê de bizane.
Bi taybetî hûn hewce ne ku guherbara hawîrdora `TARGET` saz bikin wekî ku hûn ji bo `ci/run.sh` bikin.
Wekî din hûn hewce ne ku `RUSTCFLAGS` saz bikin (`C` hewce dike) ku taybetmendiyên hedef nîşan bike, mînak `RUSTCFLAGS="-C -target-features=+avx2"`.
Hûn dikarin `-C -target-cpu=native` jî saz bikin heke hûn "just" li hember CPU-ya xweya nuha pêşve diçin.

Hişyar bibin ku dema ku hûn van talîmatên alternatîf bikar bînin, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], mînak
Testên nifşê fêrkirinê dibe ku têk biçin ji ber ku disassembler navê wan cuda kir, mînak
dibe ku ew li şûna talîmatên `aesenc` tevî ku ew heman tevdigerin `vaesenc` çêbike.
Di heman demê de van talîmatan ji ya ku dê normal were kirin kêmtir ceribandinan pêk tînin, ji ber vê yekê hûn şaş nemînin ku gava hûn di dawiyê de daxwaz-daxwazê bikin hin çewtî dikarin ji bo ceribandinên li vir nayên xuyang kirin.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






