//! Dema ku makroyên nû diyar dikin pirtûkxaneyek piştgiriyê ji bo nivîskarên makro.
//!
//! Vê pirtûkxaneyê, ku ji hêla belavkirina standard ve hatî peyda kirin, celebên ku di navrûyên pênasnameyên makroyê yên bi prosedurî hatine diyarkirin de wekî makroyên fonksiyon `#[proc_macro]`, taybetmendiyên makro `#[proc_macro_attribute]` û taybetmendiyên xwerû yên derhêner têne xerckirin "#[proc_macro_derive]".
//!
//!
//! Ji bo bêtir [the book] bibînin.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Diyar dike ka gelo proc_macro ji bernameya ku niha dimeşîne re gihîştî ye an na.
///
/// Proc_macro crate tenê ji bo karanîna hundurê pêkanîna makroyên prosedurî ye.Hemî fonksiyonên di vê crate panic de heke ji derveyî makroyek prosedurî were vexwendin, wek mînak ji nivîsandina avahiyê an testa yekîneyê an binarya Rust ya normal.
///
/// Bi berçavgirtina pirtûkxaneyên Rust ku ji bo piştgirîkirina dozên karanîna makro û ne-makro hatine sêwirandin, `proc_macro::is_available()` awayek ne-panîkî peyda dike da ku bibîne ka binesaziya ku ji bo karanîna API-ya proc_macro pêdivî ye an na aniha heye.
/// Ger ji hundurê makroyek pêvajoyê were vexwendin rast vedigere, heke ji binaryek din were vexwendin derewîn.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Cureya sereke ya ku ji hêla vê crate ve hatî peyda kirin, temsîla herikînek abstrakt a tokens, an, bi taybetîtir, rêzek darên token dike.
/// Cûre ji bo dubarekirina ser wan darên token navrûyan peyda dike û berevajî, hejmarek darên token di yek çemî de kom dike.
///
///
/// Ev hem danasîn hem jî derketina danasînên `#[proc_macro]`, `#[proc_macro_attribute]` û `#[proc_macro_derive]` e.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Çewtî ji `TokenStream::from_str` vegeriya.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// `TokenStream`-a vala ya ku tê de darên token tune vedigerîne.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Kontrol dike ka ev `TokenStream` vala ye.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Hewldanên ji bo şikandina têla tokens û parsekirina wan tokens di herika token de.
/// Dibe ku ji ber çend sedeman sernekeve, mînakî, heke têl veqetandekên nehevseng an tîpên ku di zimên de tune ne.
///
/// Hemî tokens-ê di herika parsekirî de `Span::call_site()` spanî digirin.
///
/// NOTE: hin çewtî li şûna vegera `LexError` dibe sedema panics.Em mafê xwe hiltînin ku van xeletiyan paşê veguherînin `LexError`.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, pire tenê `to_string` peyda dike, `fmt::Display` li ser bingeha wê bicîh tîne (berevajî têkiliya adetî ya di navbera her duyan de).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Çerxa token wekî têlek çap dike ku tê xwestin ku bê windabûn were veguherandin di heman çerxa token de (modul spans), ji xeynî `TokenTree: : Group` bi veqetandekên `Delimiter::None` û herfên hejmarî yên neyînî.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// token di formek guncan de ji bo çewtkirinê çap dike.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Çemek token diafirîne ku darek token tê de heye.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Hejmarek darên token di yek çemî de kom dike.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Operasyonek "flattening" li ser çemên token, darên token ji gelek çemên token di yek çemî de kom dike.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Pêkanîna çêtirîn if/when gengaz bikar bînin.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Agahdariyên pêkanîna gelemperî ji bo celebê `TokenStream`, wekî veberhêneran.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Iterator li ser `TokenTree`` TokenStream`.
    /// Dûbarekirin "shallow" e, mînakî, dûbareker nav komên veqetandî paşde venagerîne, û koman tevde wekî darên token vedigerîne.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` tokens keyfî qebûl dike û di nav `TokenStream` de danasîna têketinê berfireh dibe.
/// Mînakî, `quote!(a + b)` dê vegotinek hilberîne, ku, dema ku were nirxandin, `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Rakirina nirxandinê bi `$` re tête kirin, û bi girtina yeka yekbûyî ya paşîn wekî terma bêber dixebite.
/// Ji bo ku `$` bixwe bêje, `$$` bikar bînin.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Herêmek koda çavkaniyê, digel agahdariya berfirehkirina makro.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Li ser span `self` bi `message` re `Diagnostic` nû diafirîne.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Dirêjahiyek ku di malpera danasîna makro de çareser dibe.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Berfirehiya vexwendina makroya prosedûrê ya heyî.
    /// Nasnameyên ku bi vê spanê hatine afirandin dê werin çareser kirin wekî ku ew rasterast li cîhê banga makroyê hatine nivîsandin (paqijiya malpera-bangê) û koda din jî li malpera banga makro dê bikaribin wan jî binav bikin.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Pîvanek ku paqijiya `macro_rules` temsîl dike, û carinan li malpera danasîna makro (guherbarên herêmî, etîket, `$crate`) û carinan jî li malpera banga makro (her tiştê din) çareser dibe.
    ///
    /// Cihê span ji malpera-bangê tê girtin.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Pela çavkaniya orjînal ku ev span tê de nîşan dide.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` ji bo tokens di berfirehkirina makroya berê de ku `self` jê hatî çêkirin, heke hebe.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Dirêjahiya ji bo koda çavkaniya jêderkê ku `self` jê hatî çêkirin.
    /// Ger ev `Span` ji berfirehkirina makroyên din nehatibe afirandin wê hingê nirxa vegerê wekî `*self` e.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Ji bo vê zemanê di pelê çavkaniyê de line/column-yê dest pê dike.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Ji bo vê zemanê di pelê çavkaniyê de dawiya line/column digire.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Dansek nû ya ku `self` û `other` li xwe digire diafirîne.
    ///
    /// Ger `self` û `other` ji pelên cûda ne `None` vedigerîne.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Bi heman agahdariya line/column wekî `self` spanek nû diafirîne lê ew sembolên wekî li `other` bûn çareser dike.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Bi heman reftara çareseriyê ya navî wekî `self` lê bi agahdariya line/column ya `other` spanek nû diafirîne.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Bi danberhevan re berawird dike ka ka ew wekhev in.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Nivîsara çavkaniyê li paş hevûdu vedigerîne.
    /// Ev koda çavkaniya bingehîn diparêze, valahî û şîroveyan jî di nav de.
    /// Tenê ku span bi koda çavkaniya rastîn re têkildar dibe encamek vedigire.
    ///
    /// Note: Encama berbiçav a makroyek tenê divê xwe bispêre tokens û ne vê nivîsara çavkaniyê.
    ///
    /// Encama vê fonksiyonê hewlek çêtirîn e ku tenê ji bo teşhîs were bikar anîn.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Di formekê de ji bo çewtkirinê guncan çap dike.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Pêvek rêzik-stûnek ku destpêkê an dawiya `Span`-ê temsîl dike.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Di pelê çavkaniyê de rêza 1-navnîşkirî ya ku span li ser (inclusive) dest pê dike an diqede.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Stûna 0-endekskirî (bi tîpên UTF-8) di pelê çavkaniyê de ku span li ser wê (inclusive) dest pê dike an diqede.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Pelê çavkanî ya `Span` dane.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Riya vê pelê çavkaniyê digire.
    ///
    /// ### Note
    /// Ger qada kodê ya ku bi vê `SourceFile` ve girêdayî ye ji hêla makroyek derveyî ve hatî çêkirin, ev makro, dibe ku ev li ser pergala pelan ne rêyek rastîn be.
    /// [`is_real`] bikar bînin ku kontrol bikin.
    ///
    /// Di heman demê de not bikin ku heke `is_real` `true` vegerîne jî, heke `--remap-path-prefix` li ser rêzika fermanê re derbas bûbe, riya ku hatî dayîn dibe ku ne rast derbasdar be.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// `true` vedigerîne heke ev pelê çavkaniyê pelê çavkaniyek rastîn e, û ji hêla berfirehkirina makroya derveyî ve nehatiye çêkirin.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Ev hack e heya ku spansên intercrate têne bicîh kirin û em dikarin pelên çavkaniya rastîn ên ji bo spansan ên di makroyên derveyî de hatine afirandin hene.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// token-an yek rêzek ji darên token-ê veqetandî (mînakî, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Çemek token ku bi veqetandekên qulikê dorpêçkirî ye.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Nasnameyek.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Karakterek xalbendiyê ya yekta (`+`, `,`, `$`, û hwd.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Karakterek xwerû (`'a'`), têla (`"hello"`), hejmar (`2.3`), û hwd.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Rûbera vê darê vedigerîne, delegeyan dide rêbaza `span` ya token ya tê de heye an herikek veqetandî.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Dema ji bo *tenê vê token* mîheng dike.
    ///
    /// Zanibe ku heke ev token `Group` be wê hingê dê vê rêbazê rûbera her yek ji tokens ya navxweyî vesaz neke, ev ê bi hêsanî rêbaza `set_span` ya her cûreyê bişîne.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Dara token bi rengek guncan ji bo çewtkirinê çap dike.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Di vana deçek çêkirî de navê vana ji her yekê re di teşe de heye, ji ber vê yekê hûn bi qatek dî ya indirection aciz nebin
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, pire tenê `to_string` peyda dike, `fmt::Display` li ser bingeha wê bicîh tîne (berevajî têkiliya adetî ya di navbera her duyan de).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Dara token wekî têlek çap dike ku tê îdia kirin ku dê bê windabûn were veguherandin di heman dara token de (modul span), ji xeynî `TokenTree: : Group` bi veqetandekên `Delimiter::None` û herfên hejmarî yên neyînî.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Çemek sînorkirî ya token.
///
/// `Group` navxweyî de `TokenStream` heye ku ji hêla `Delimiter` ve dorpêçkirî ye.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Diyar dike ka çawa rêzeyek darên token tê veqetandin.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Tixûbdarek nepenî, ku dibe ku, wek nimûne, li dora tokens ji "macro variable" `$var` tê xuya bibe.
    /// Vê girîng e ku meriv di rewşên mîna `$var * 3` de ku `$var` `1 + 2` e, pêşanîyên operator biparêze.
    /// Dabeşkerên nehfbar dibe ku li dora xelekek token-ê di nav rêzê re sax bimînin.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Bi dabeşkerê danîn û herika token ve `Group` nû diafirîne.
    ///
    /// Ev avakar dê spaniya vê komê li `Span::call_site()` saz bike.
    /// Ji bo guheztina zemînê hûn dikarin li jêrê rêbaza `set_span` bikar bînin.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Veqetandekara vê `Group` vedigerîne
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// `TokenStream` ya tokens ya ku di vê `Group` de veqetandî vedigerîne.
    ///
    /// Bala xwe bidinê ku herika token ya vegerandî veqetandek li jor vegeriyanî nagire.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Zeviyê ji bo veqetandekên vê herika token vedigerîne, tevahiya `Group` digire.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Zivirandinê vedigerîne nîşankerê vekirina vê komê.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Vedigere zivirandin û veqetandekera veqetandek a vê komê nîşan dike.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Rêjeya ji bo veqetandekên vê `Komê` verast dike, lê ne tokens-ya wê ya hundurîn.
    ///
    /// Ev rêbaz dê ** nexşeya hemî tokens-a navxweyî ya ku ji hêla vê komê ve hatî vesazkirin, neyê danîn, lê li şûna wê ew ê tenê dirêjahiya veqetandekarê tokens-ê li ser asta `Group` saz bike.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, pire tenê `to_string` peyda dike, `fmt::Display` li ser bingeha wê bicîh tîne (berevajî têkiliya adetî ya di navbera her duyan de).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Komê wekî têlek çap dike ku divê bê windakirin li heman komê were vegerandin (modul span), ji xeynî `TokenTree: : Group` bi veqetandekên `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` karakterek xalbendîyek yekta ye wekî `+`, `-` an `#`.
///
/// Operatorên pir-karakterî wekî `+=` wekî du nimûneyên `Punct` bi formên cihêreng ên `Spacing` vedigerin têne nimandin.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Ma `Punct` di cih de ji hêla `Punct` din ve tê şopandin an ji hêla token an qada spî ya din ve tê şopandin.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// mînak, `+` di `+ =`, `+ident` an `+()` de `Alone` ye.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// mînak, `+` `Joint` di `+=` an `'#` de ye.
    /// Wekî din, teklîfa `'` dikare bi nasnameyan re bibe yek da ku jiyanên `'ident` çêbike.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Ji karaktera dayîn û navberê `Punct` nû diafirîne.
    /// Nîqaşa `ch` divê tîpek xalbendîyeka derbasdar be ku ji hêla zimên ve hatî destûr kirin, nebe ku fonksiyon wê panic be.
    ///
    /// `Punct` ya vegerandî dê xwediyê spaniya xwerû ya `Span::call_site()` be ku dikare bi rêbaza `set_span` ya jêrîn bêtir were verastkirin.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Nirxa vê karakterê xalbendî wekî `char` vedigire.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Valahiya vê karakterê xalbendî vedigerîne, nîşan dide ka gelo ew tavilê ji hêla `Punct`-yê din ve di herika token de tê şopandin, ji ber vê yekê ew bi potansiyelî dikarin di operatorê pir-karakter (`Joint`) de werin hev, an ew ji hêla hin token an qada spî (`Alone`) ve li dû wî tê ji ber vê yekê operator bê guman heye qediya.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Ji bo vê karakterê xalbendî zivirandin.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Ji bo vê karakterê xalbendî span vesaz bikin.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, pire tenê `to_string` peyda dike, `fmt::Display` li ser bingeha wê bicîh tîne (berevajî têkiliya adetî ya di navbera her duyan de).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Karaktera xalbendiyê wekî têlek çap dike ku divê bê windabûn were vegerandin nav heman karekterê.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Nasnameyek (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Bi `string` ya dayî û her weha `span` ya diyarkirî `Ident` nû diafirîne.
    /// Divê argumana `string` nasnameyek derbasdar be ku ji hêla zimên ve hatî destûr kirin (bêjeyên sereke, mînak `self` an `fn` jî tê de).Wekî din, fonksiyon dê panic.
    ///
    /// Zanibe ku `span`, niha di rustc de ye, ji bo vê nasnameyê agahdariya paqijiyê saz dike.
    ///
    /// Di vê demê de `Span::call_site()` bi eşkereyî paqijiya "call-site" vedibêje ku wateya ku nasnameyên bi vê spanê hatine afirandin dê werin çareser kirin mîna ku ew rasterast li cîhê banga makroyê hatibin nivîsandin, û koda din li malpera banga makro dê bikaribin serî lê bidin wan jî.
    ///
    ///
    /// Piştre dorpêçên mîna `Span::def_site()` dê bihêle ku meriv paqijiya "definition-site" hilbijêre wateya ku nasnameyên ku bi vê spanê hatine afirandin dê li cîhê danasîna makro bêne çareser kirin û koda din li malpera banga makro dê nekaribe ku wan binav bike.
    ///
    /// Ji ber girîngiya paqijiya heyî ev konstruktor, berevajî tokens yên din, hewce dike ku `Span` li avahiyê were diyar kirin.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Heman wekî `Ident::new`, lê nasnameyek xav (`r#ident`) diafirîne.
    /// Argumana `string` nasnameyek derbasdar be ku ji hêla zimên ve hatî destûr kirin (bêjeyên sereke, mînak `fn` jî tê de).
    /// Bêjeyên sereke ku di beşên rê de têne bikar anîn (mînak
    /// `self`, `super`) nayê piştgirî kirin, û dê bibe sedema panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Rêjeya vê `Ident` vedigerîne, tevahiya rêzika ku ji hêla [`to_string`](Self::to_string) ve vegeriyaye vedihewîne.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Berfirehiya vê `Ident` mîheng dike, dibe ku çarçoveya paqijiya wê biguheze.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, pire tenê `to_string` peyda dike, `fmt::Display` li ser bingeha wê bicîh tîne (berevajî têkiliya adetî ya di navbera her duyan de).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Nasnameyê wekî rêzika ku divê bê windabûn were vegerandin nav heman nasnameyê çap dike.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Xencera rastîn a (`"hello"`), têla byte (`b"hello"`), karakter (`'a'`), karakter byte (`b'a'`), jimareyek hejmar an xaleke gerok bi paşpirtikek an bêyî wê (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Bêjeyên Boolean ên mîna `true` û `false` ne li vir in, ew `Nasname` ne.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Bi nirxa diyarkirî ve hejmarek paşpirtika nû ya xwerû ya xwerû diafirîne.
        ///
        /// Ev fonksiyon dê jimareyek mîna `1u32` biafirîne ku nirxa jimare ya diyar kirî beşa yekem a token ye û yekpare jî di dawiya paşîn de tête paşpirtik kirin.
        /// Lêkerên ku ji hejmarên negatîf hatine afirandin dibe ku di gerdûnên bi `TokenStream` an têlan de sax nemînin û dikarin bibin du tokens (`-` û rasterast erênî).
        ///
        ///
        /// Wêjeyên ku bi vê rêbazê hatine afirandin xwedan spasiya `Span::call_site()` e, ku dikare bi rêbaza `set_span` ya li jêr were vesazkirin.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Bi nirxa diyarkirî ve jimareyek nû ya nerastkirî ya xwerû diafirîne.
        ///
        /// Ev fonksiyon dê jimareyek mîna `1` çêbike ku li wir nirxa jimare ya diyarbûyî beşa yekem a token ye.
        /// Li ser vê token paşpirtikek nehatiye diyar kirin, wateya ku vexwendinên mîna `Literal::i8_unsuffixed(1)` bi `Literal::u32_unsuffixed(1)` re hevwate ne.
        /// Lêkerên ji jimarên neyînî hatine afirandin dibe ku di rontripsên bi `TokenStream` an têlan de sax nemînin û bibin du tokens (`-` û rasterast erênî) werin parçe kirin.
        ///
        ///
        /// Wêjeyên ku bi vê rêbazê hatine afirandin xwedan spasiya `Span::call_site()` e, ku dikare bi rêbaza `set_span` ya li jêr were vesazkirin.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Zehfek nû ya bêserûber floating-point-ê diafirîne.
    ///
    /// Ev konstruktor dişibihe wan ên mîna `Literal::i8_unsuffixed` ku nirxa floatê rasterast di token de tête weşandin lê paşpirtikek nayê bikar anîn, ji ber vê yekê dibe ku were destnîşankirin ku paşê di berhevkar de `f64` be.
    ///
    /// Lêkerên ji jimarên neyînî hatine afirandin dibe ku di rontripsên bi `TokenStream` an têlan de sax nemînin û bibin du tokens (`-` û rasterast erênî) werin parçe kirin.
    ///
    /// # Panics
    ///
    /// Vê fonksiyonê hewce dike ku flora diyarkirî bidawî be, mînakî heke ew bêdawîbûn an NaN be dê ev fonksiyon panic be.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Qertafek nuqteyî ya paşpirtik a xwerû çêdike.
    ///
    /// Ev konstruktor dê rasterast mîna `1.0f32` biafirîne ku nirxa hatî diyar kirin beşa pêşîn a token ye û `f32` paşpirtika token ye.
    /// Ev token dê her gav were vegotin ku di berhevkar de `f32` be.
    /// Lêkerên ji jimarên neyînî hatine afirandin dibe ku di rontripsên bi `TokenStream` an têlan de sax nemînin û bibin du tokens (`-` û rasterast erênî) werin parçe kirin.
    ///
    ///
    /// # Panics
    ///
    /// Vê fonksiyonê hewce dike ku flora diyarkirî bidawî be, mînakî heke ew bêdawîbûn an NaN be dê ev fonksiyon panic be.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Zehfek nû ya bêserûber floating-point-ê diafirîne.
    ///
    /// Ev konstruktor dişibihe wan ên mîna `Literal::i8_unsuffixed` ku nirxa floatê rasterast di token de tête weşandin lê paşpirtikek nayê bikar anîn, ji ber vê yekê dibe ku were destnîşankirin ku paşê di berhevkar de `f64` be.
    ///
    /// Lêkerên ji jimarên neyînî hatine afirandin dibe ku di rontripsên bi `TokenStream` an têlan de sax nemînin û bibin du tokens (`-` û rasterast erênî) werin parçe kirin.
    ///
    /// # Panics
    ///
    /// Vê fonksiyonê hewce dike ku flora diyarkirî bidawî be, mînakî heke ew bêdawîbûn an NaN be dê ev fonksiyon panic be.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Qertafek nuqteyî ya paşpirtik a xwerû çêdike.
    ///
    /// Ev konstruktor dê rasterast mîna `1.0f64` biafirîne ku nirxa hatî diyar kirin beşa pêşîn a token ye û `f64` paşpirtika token ye.
    /// Ev token dê her gav were vegotin ku di berhevkar de `f64` be.
    /// Lêkerên ji jimarên neyînî hatine afirandin dibe ku di rontripsên bi `TokenStream` an têlan de sax nemînin û bibin du tokens (`-` û rasterast erênî) werin parçe kirin.
    ///
    ///
    /// # Panics
    ///
    /// Vê fonksiyonê hewce dike ku flora diyarkirî bidawî be, mînakî heke ew bêdawîbûn an NaN be dê ev fonksiyon panic be.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// String biwêjî.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Karakter biwêjî.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Têlika Bîtê biwêjî.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Vedigere ser dorpêça vê rasterast.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Rêjeya ku ji bo vê rastnivîsê têkildar dibe mîheng dike.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// `Span` vedigerîne ku jêrînek `self.span()` e ku tenê baytên çavkaniyê di nav rêza `range` de digire.
    /// Ger rûbera ku dê were qutkirin li derveyî sînorên `self` be vedigere `None`.
    ///
    // FIXME(SergioBenitez): kontrol bikin ku rêzika byte dest pê dike û li sînorê UTF-8 ê çavkaniyê diqede.
    // wekî din, dibe ku panic li cîhek din çêbibe dema ku nivîsa çavkaniyê were çap kirin.
    // FIXME(SergioBenitez): çu çare tune ku bikarhêner zanibe ka `self.span()` bi rastî çi nexşeyê çêdike, ji ber vê yekê ev rêbaza hanê niha tenê bi kor tête gotin.
    // Mînakî, `to_string()` ji bo karakterê 'c' "'\u{63}'" vedigire;çu rê tune ku bikarhêner bizanibe ka nivîsa jêderk 'c' bû an '\u{63}' bû.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) tiştek dişibe `Option::cloned`, lê ji bo `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, pire tenê `to_string` peyda dike, `fmt::Display` li ser bingeha wê bicîh tîne (berevajî têkiliya adetî ya di navbera her duyan de).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Wêjeyê wekî têlek çap dike ku divê bê windahî li heman rastnivîsê were veguheztin (ji xeynî dorpêçandina gengaz a rastnivîsên xala gemarî).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Gihîştina guherbarên hawîrdorê şopandin.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Vebijêrkek hawîrdorê bistînin û wê lê zêde bikin da ku agahdariya pêbaweriyê çêbikin.
    /// Sîstema avakirinê ya ku berhevkar bicîh dike dê zanibe ku guhêrbar di dema berhevkirinê de hate peyda kirin, û dema ku nirxê wê guhêrbar diguhere dê karibe avahiyê dubare bike.
    ///
    /// Ji bilî şopandina girêdanê divê ev fonksiyon ji pirtûkxaneya standard re `env::var` be, ji bilî ku divê arguman UTF-8 be.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}